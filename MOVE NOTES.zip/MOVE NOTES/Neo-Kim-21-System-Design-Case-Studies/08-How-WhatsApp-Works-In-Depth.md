# How WhatsApp Works - In Depth (Easy Language)

> Companion to: [08-How-WhatsApp-Works.md](08-How-WhatsApp-Works.md)

---

## What Problem Does WhatsApp Solve?

Sending a message from your phone in India to your friend's phone in the US in **under 500 milliseconds**, reliably, for **2 billion users** -- and making sure no message is ever lost.

---

## WebSockets - Why Not Regular HTTP?

### Understanding the Three Options

**Option 1: HTTP Polling (Bad)**
```
Your phone: "Any new messages?"     → Server: "No"
(wait 3 seconds)
Your phone: "Any new messages?"     → Server: "No"
(wait 3 seconds)
Your phone: "Any new messages?"     → Server: "Yes! Here's one"
(wait 3 seconds)
Your phone: "Any new messages?"     → Server: "No"

Problem: 80% of these requests return NOTHING
  → Wastes battery, bandwidth, and server resources
  → 3-second delay before you see a new message
```

**Option 2: Long Polling (Better but Not Great)**
```
Your phone: "Tell me when there's a message (I'll wait)"
→ Server holds the connection open...
→ ... waits ...
→ Message arrives!
→ Server: "Here's your message!"
→ Connection closes
→ Your phone immediately opens a NEW connection
→ "Tell me when there's another message (I'll wait)"

Problem: Constantly opening and closing connections
  → Each new connection = TCP handshake overhead
  → Server manages millions of half-open connections
```

**Option 3: WebSocket (WhatsApp's Choice)**
```
Your phone: "Let's open a permanent connection" → Server: "OK!"

Now the pipe is ALWAYS open:
  → Server pushes message instantly when it arrives
  → Your phone can also send messages anytime
  → No polling, no reconnecting
  → Minimal overhead after initial handshake
  
Heartbeat every 30 seconds:
  Phone: "ping" → Server: "pong" (I'm still here!)
  If no pong for 60 seconds → connection is dead, reconnect
```

**Why WebSocket wins**: It's like having a phone call that stays connected. With HTTP polling, you'd be calling your friend every 3 seconds asking "anything to say?" and hanging up between each call.

---

## How Messages Actually Travel

### Scenario 1: Both Users Online

```
Alice (India) sends "Hello!" to Bob (USA)

Step 1: Alice's phone → WebSocket → Chat Server 5 (India)
Step 2: Chat Server 5 → sends ACK to Alice ("sent ✓")
Step 3: Chat Server 5 → Redis: "Where is Bob?"
        Redis: "Bob is connected to Chat Server 12 (USA)"
Step 4: Chat Server 5 → Chat Server 12 → WebSocket → Bob's phone
Step 5: Bob's phone → delivery ACK → Chat Server 12 → Alice ("delivered ✓✓")
Step 6: Bob opens the chat → read ACK → Alice ("read ✓✓" blue ticks)
```

**The check marks explained:**
- ✓ (one gray tick) = Message left your phone and reached WhatsApp server
- ✓✓ (two gray ticks) = Message delivered to recipient's phone
- ✓✓ (two blue ticks) = Recipient opened and read the message

### Scenario 2: Recipient Is Offline

```
Alice sends "Hello!" to Bob (Bob's phone is off)

Step 1: Alice's phone → WebSocket → Chat Server 5
Step 2: Chat Server 5 → ACK to Alice ("sent ✓")
Step 3: Chat Server 5 → Redis: "Where is Bob?"
        Redis: "Bob is OFFLINE"
Step 4: Message stored in:
        - Redis inbox: Bob's pending messages (fast access)
        - Cassandra: permanent storage (durability)
Step 5: Push notification sent via APNs (iPhone) / FCM (Android)
        Bob sees: "Alice: Hello!" on lock screen

...later, Bob turns on his phone...

Step 6: Bob's phone reconnects WebSocket
Step 7: Chat Server pulls all pending messages from Bob's inbox
Step 8: Delivers all messages to Bob
Step 9: Delivery ACKs sent back → Alice sees ✓✓
```

**Key insight**: Messages are NEVER lost. If you're offline, they wait for you (up to 30 days).

---

## Redis - The Speed Layer

### Why Redis for Connection Tracking?

When a message needs to reach Bob, the system needs to answer: "Which chat server is Bob connected to?" This must be FAST (microseconds, not milliseconds).

```
Redis (in-memory, microsecond lookups):
  "user_Bob" → { server: "chat-server-12", status: "online", last_seen: "10:42 AM" }
  "user_Alice" → { server: "chat-server-5", status: "online", last_seen: "10:43 AM" }
  "user_Charlie" → { server: null, status: "offline", last_seen: "yesterday" }
```

If this were in a regular database (PostgreSQL), each lookup would take 5-10ms instead of 0.001ms. At 500,000 messages/second, that difference is catastrophic.

---

## Cassandra - The Storage Layer

### Why Cassandra for Messages?

WhatsApp stores 10 BILLION messages per day. That's ~115,000 writes per second. You need a database that's amazing at writes.

```
Cassandra strengths:
  ✓ Write-optimized (LSM tree, like S3's ShardStore)
  ✓ Distributed (data spread across many nodes)
  ✓ No single point of failure
  ✓ Simple query patterns

Query pattern for messages:
  "Get all messages in conversation X, sorted by time"
  → Partition key: conversation_id
  → Clustering key: timestamp
  → Perfect for Cassandra!
```

**Why NOT PostgreSQL for messages?**
- Postgres is good for complex queries (JOINs, transactions)
- WhatsApp's message query is simple: "get messages by conversation + time"
- At 115K writes/sec, Postgres would struggle; Cassandra is designed for this

---

## Media Handling - Why Chat Servers Don't Touch Your Photos

### The Problem

If Alice sends a 5MB photo through the chat server:
```
BAD approach:
  Alice → [5MB] → Chat Server → [5MB] → Bob
  
  Problem: Chat server is now a bottleneck!
  If 1000 users send photos simultaneously:
    1000 × 5MB = 5 GB flowing through the chat server
    The server chokes and ALL messages (even text) slow down!
```

### The Solution: Pre-Signed URLs (Like YouTube/S3)

```
GOOD approach:
  1. Alice's phone asks: "I want to upload a photo"
  2. Server returns a pre-signed S3 URL: "Upload directly here"
  3. Alice's phone uploads 5MB photo DIRECTLY to S3 (chat server untouched!)
  4. S3 returns a media_id: "media_abc123"
  5. Alice's phone sends a TINY message through chat server:
     { to: "Bob", type: "photo", media_id: "media_abc123" }
  6. Bob's phone receives the message
  7. Bob's phone downloads the photo from CDN using media_id
  
  Chat server only handled a ~100 byte message, not 5MB!
```

The **CDN** caches popular files at edge locations worldwide, so if 100 people in Mumbai download the same group photo, it's served from a Mumbai server, not from the US.

---

## Presence Service - How "Online" Status Works

### The Heartbeat Mechanism

```
Bob opens WhatsApp:
  → Phone sends heartbeat to Presence Service: "I'm alive!" (every 5 seconds)
  → Presence Service marks Bob as "online" in Redis
  → Alice's phone shows: "Bob is online"

Bob closes WhatsApp:
  → No heartbeat for 60 seconds
  → Presence Service marks Bob as "offline"
  → Updates "last seen" timestamp
  → Alice's phone shows: "Last seen today at 10:42 AM"
```

**Why 60 seconds before marking offline?**

Network glitches happen. Your phone might lose signal for 10 seconds in an elevator. You don't want it to show "offline" and "online" rapidly. 60 seconds smooths out temporary disconnections.

---

## Group Messaging - The Fan-Out Challenge

### How It Works

```
Alice sends "Hey everyone!" to a group of 50 members:

Step 1: Alice's phone → Chat Server 5
Step 2: Chat Server 5: "This is a group message to 50 people"
Step 3: For each member:
  → Redis lookup: "Where is this member?"
  → If online: route to their chat server → deliver via WebSocket
  → If offline: store in their inbox + push notification

Fan-out work:
  1 message from Alice → 49 deliveries (to other members)
```

### Why Groups Are Capped at 100 Members

```
Group of 100 members:
  1 message = 99 fan-out deliveries + 99 Redis lookups
  
Group of 10,000 members (hypothetical):
  1 message = 9,999 fan-out deliveries + 9,999 Redis lookups
  If group is active (100 messages/minute):
    = 999,900 deliveries per minute FOR ONE GROUP!
    That's unsustainable at WhatsApp's scale.
```

WhatsApp caps groups at 100 (recently increased) to keep fan-out costs manageable. Slack handles larger groups (10K) because it uses a different architecture (channel-based, not phone-based).

---

## Sticky Sessions - Why Your WebSocket Stays on One Server

```
WITHOUT sticky sessions:
  Request 1: Alice → Server A (opens WebSocket)
  Request 2: Alice → Server B (load balancer sends here)
  
  Problem: Alice now has WebSocket on Server A,
  but Server B doesn't know about it!
  Messages to Alice might go to wrong server.

WITH sticky sessions:
  Request 1: Alice → Server A (opens WebSocket)
  Load balancer remembers: "Alice always goes to Server A"
  Request 2: Alice → Server A ✓
  Request 3: Alice → Server A ✓
  
  All of Alice's traffic goes to the same server.
```

This is **Layer 4 load balancing** (works at TCP level, not HTTP level) because WebSocket connections are long-lived TCP connections that can't be bounced between servers.

---

## Revision Flashcards

**Q: Why does WhatsApp use WebSockets instead of HTTP polling?**
A: WebSocket maintains a permanent bidirectional connection. Server can push messages instantly. No wasted requests (polling asks "anything new?" even when there's nothing). Minimal overhead after initial handshake.

**Q: How does WhatsApp handle offline users?**
A: Messages are stored in the user's inbox (Redis + Cassandra) and a push notification is sent. When the user comes online, all pending messages are delivered. Messages are kept for 30 days.

**Q: Why doesn't WhatsApp send photos through chat servers?**
A: Photos are uploaded directly to S3 via pre-signed URLs. Chat servers only handle a tiny message with a media_id reference. This prevents large files from bottlenecking the messaging system.

**Q: How does the presence ("online") system work?**
A: Client sends a heartbeat every 5 seconds. If no heartbeat for 60 seconds, user is marked offline. The 60-second buffer prevents rapid online/offline toggling from network glitches.

**Q: Why are WhatsApp groups capped at ~100 members?**
A: Each message fans out to all members. A 100-member group means 99 deliveries per message. Larger groups would cause unsustainable fan-out costs at WhatsApp's 2-billion-user scale.
