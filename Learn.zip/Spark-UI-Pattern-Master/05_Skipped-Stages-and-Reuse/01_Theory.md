# Skipped Stages & Shuffle Output Reuse

Yeh pattern un mysterious *"skipped"* labels ko explain karta hai jo Jobs aur Stages tab mein "(2 skipped)" / "(22 skipped)" type appear hote hain. Beginners isko bug samajhte hain — actually yeh Spark ka **best optimization** hai.

**DSA Analogy**: Memoization. Pehle compute kar liya hai? Reuse kar lo. Spark map output ko local disk pe rakhta hai aur agle job mein wahi bytes use kar leta hai.

---

## Core Idea (2 Lines)

Jab dusra job same lineage wala data maange jo pehle se shuffle output ya cache mein available hai, Spark woh stages **execute nahi karta** — sirf "skipped" mark karta hai. UI mein yeh "(N skipped)" ke roop mein dikhta hai.

---

## Two Sources of "Skipped"

| Source                       | Trigger                                                | UI Hint                                                  |
|------------------------------|--------------------------------------------------------|----------------------------------------------------------|
| **Shuffle output reuse**      | A previous stage already wrote shuffle files; new job's child stage just reads them | Skipped stage shows "Shuffle Read" only, no compute       |
| **Cache reuse**               | A `.cache()` / `.persist()` materialized partitions in memory/disk | Skipped stage's input is `InMemoryTableScan`             |

> Both look like "skipped" in the Jobs tab. The Stages tab and SQL tab tell you *which* one.

---

## Visual: Why Stages Get Skipped

```
JOB 0 (count) — first time, nothing reused
  +----+    +----+    +----+
  | S0 |--> | S1 |--> | S2 |       all stages run
  +----+    +----+    +----+
   16 t      6 t       1 t

JOB 1 (show iter 1) — cache+shuffle reused from Job 0
  +----+    +----+    +----+    +----+
  |skip|--> |skip|--> | S6 |--> | S7 |
  +----+    +----+    +----+    +----+
   16 t      6 t       6 t       1 t   (skipped tasks shown but not run)
```

> "Skipped" doesn't mean *failed*. It means *no work needed*.

---

## Reading the Jobs Tab Again

```
| Id | Description                  | Stages         | Tasks                        |
|----|------------------------------|----------------|-------------------------------|
|  1 | showString at app.py:51 (i=1)| 2/2 (1 skipped)| 7/23 (16 skipped)             |
|  2 | showString at app.py:51 (i=2)| 1/3 (2 skipped)| 4/26 (22 skipped)             |
|  3 | showString at app.py:51 (i=3)| 1/3 (2 skipped)| 3/25 (22 skipped)             |
|  4 | collect at app.py:54         | 2/3 (1 skipped)| 14/30 (16 skipped)            |
```

**The two parts of the Tasks column:**

```
"7 / 23 (16 skipped)"
   |     |       |
   |     |       +-- tasks NOT executed (output already available)
   |     +---------- total tasks expected by the plan
   +---------------- tasks actually executed in this job
```

> Sometimes you'll see `7 / 7 (16 skipped)` — that means: 7 tasks ran, plan expected 7 to run, and 16 more were skipped because they were already done in a prior job.

---

## Worked Example — The Reference Run

For the 5-job script with `spark.sql.shuffle.partitions = 8`:

### Job 0 — `count()` (no reuse possible — first job)
```
Stage 0 (16 tasks)  createDataFrame parallelize + withColumn + repartition shuffle write
Stage 1 ( 6 tasks)  shuffle read + filter + cache materialize + partial count
Stage 2 ( 1 task )  shuffle read + final count
```
After Job 0: cache has 6 partitions of `df_filtered`; shuffle output of Stage 1 sits on local disk.

### Job 1 — `show()` iter 1
```
Reused (skipped) :
  - Stage 0 output (16 tasks)  shuffle output already on disk
  - Cache materialization      already in Storage tab

New stages:
  - Stage 3 (6 tasks)   read cached df_filtered + withColumn + groupBy partial agg
  - Stage 4 (1 task)    final agg for partition 0 of df_final
```
UI shows `7 / 23 (16 skipped)` → 16 = the original Stage 0 tasks reused.

### Job 2 — `show()` iter 2
```
Reused (skipped):
  - Stage 0 (16 tasks)
  - Stages computed in Job 1 also skipped because their shuffle output is now persisted
  - Total skipped: 22

New work: only the leaf partitions of df_final not yet computed
  - Stage 5 (4 tasks)
```
UI shows `4 / 26 (22 skipped)`.

### Job 3 — `show()` iter 3 (last 3 partitions)
```
Same reuse pattern; only 3 new partitions of df_final to compute.
  - Stage 6 (3 tasks)
UI: 3 / 25 (22 skipped)
```

### Job 4 — `collect()`
```
Skipped: 16 deep upstream tasks (createDataFrame + first repartition)
New:  6 tasks (read cached + df2 derivation) + 8 tasks (df_final final agg, all partitions)
UI:   14 / 30 (16 skipped)
```

> **Why does collect re-do 14 tasks if `show()` already touched all 8 final partitions?**
> Because `executeTake` writes results directly to driver — it does *not* materialize a new shuffle.
> The deep upstream shuffles ARE reused (16 skipped), but the leaf computations are re-run.
> This is *executeTake's* incremental nature: it doesn't cache its own output.

---

## When Does Spark Reuse Shuffle Output?

Spark stores shuffle output in **map output files** on each executor's local disk. The key conditions:

1. **Same lineage**: The new job's plan must reference the same RDD/DataFrame upstream.
2. **Same partitioning**: The shuffle was hashed/range-partitioned the same way.
3. **Output still alive**: The block manager has not evicted the files yet (default lifetime = until app exits or executor lost).

If all 3 hold → DAGScheduler marks those stages as `ShuffleMapStage` with output already available → no compute needed.

---

## Cache Reuse vs Shuffle Reuse — How To Tell Apart

| Symptom                                            | Likely Cause                                          |
|----------------------------------------------------|-------------------------------------------------------|
| Storage tab is non-empty                           | Cache reuse possible                                  |
| Stage description starts with `InMemoryTableScan`  | Cache reuse                                           |
| Skipped stage's input was an `Exchange`            | Shuffle output reuse                                  |
| `df.unpersist()` makes future jobs slower          | Confirms cache reuse was happening                    |
| Output reuse persists across multiple subsequent jobs | Definitely shuffle/cache, not just "fast"          |

---

## Behavior of `cache()` Across Jobs

```python
df.cache()
df.count()    # Job A: materializes cache  (no reuse since first)
df.count()    # Job B: reads from cache    (most stages skipped)
df.show()     # Job C, D, E: leaf-only work + cache reused
```

```
Visual lifecycle:
  Action 1  -> "warm up"  -> Storage tab fills
  Action 2  -> "fast"     -> mostly skipped
  Action 3  -> "very fast" -> shuffle output also reused

  unpersist() -> Storage tab empties; future actions are full re-runs again
```

---

## Behavior of Shuffle Reuse WITHOUT cache

```python
df_join = df_a.join(df_b, "k")     # not cached; just lazy
df_join.count()      # Job A: 4 stages, full pipeline
df_join.show()       # Job B: many stages skipped (shuffle output of join still on disk)
df_join.collect()    # Job C: same skip pattern
```

> Spark's shuffle output behaves like an *implicit* cache for downstream jobs in the same application.

---

## When Skipped Disappears (Things Get Slow Again)

| Event                                                     | Effect                                          |
|-----------------------------------------------------------|-------------------------------------------------|
| `spark.unpersist()` on a cached DataFrame                 | Cache invalidated → next action re-runs full lineage |
| Executor lost / OOM kill                                  | Shuffle blocks on that executor lost → re-run upstream |
| `df.localCheckpoint(eager=False)` not yet materialized    | No reuse until first action                     |
| `spark.cleaner.referenceTracking.cleanShuffles = true`    | GC reclaims shuffle output once unreachable     |
| Application restart                                       | All shuffle output lost                         |

---

## Why "Skipped Tasks" Helps You Estimate Real Cost

**Trick**: when reading job duration, look at `succeeded / total (skipped)`:

```
Job 1: 7 / 23 (16 skipped)  -> Real work: 7 tasks (the 16 are free)
Job 2: 4 / 26 (22 skipped)  -> Real work: 4 tasks
Job 3: 3 / 25 (22 skipped)  -> Real work: 3 tasks
```

The 25-millisecond Job 2 is fast precisely *because* of the 22 skipped tasks. Without the skip, it would re-do everything.

---

## Common Mistakes

| Mistake                                              | Why                                                | Fix                                                                  |
|------------------------------------------------------|----------------------------------------------------|----------------------------------------------------------------------|
| Reading "skipped" as "failed"                        | They're successful by reuse                        | Check stage status: green = succeeded, gray = skipped, red = failed  |
| Counting skipped tasks toward parallelism            | They never run                                     | Use only "succeeded" for performance reasoning                       |
| Expecting cache to help when not used twice          | First action materializes; benefit shows on 2nd+   | Cache only DataFrames used in ≥ 2 actions                            |
| Hoping `df.unpersist()` will free shuffle output     | Unpersist only frees explicit cache, not shuffle   | Restart app or rely on GC for shuffle blocks                          |
| `spark.show()` shows fast 2nd time → "must be cached"| Could be shuffle reuse, not cache                  | Check Storage tab — empty? Then it was shuffle reuse                 |

---

## Verifying Reuse in the UI

```
1. Jobs Tab     -> "(N skipped)" appears
2. Stage Page   -> stages with grey "Skipped" badge, no per-task table
3. SQL Tab      -> physical plan reuses the same Exchange node
                    (look for the green "ReusedExchange" hint)
4. Storage Tab  -> entries when cache reuse is the cause
```

> **`ReusedExchange`** is your friend. Spotting it in the SQL tab is the cleanest evidence of shuffle reuse.

---

## Cache vs Persist vs Checkpoint — Effect on Reuse

| API                          | Where Stored                | Reuse Persistence Across Jobs    |
|------------------------------|------------------------------|-----------------------------------|
| `cache()` / `persist()`      | Memory (and optionally disk) | Until `unpersist()` or eviction   |
| `persist(MEMORY_AND_DISK)`   | Memory + disk fallback        | Robust against memory eviction    |
| `localCheckpoint()`          | Executor disk                  | Not durable across executor loss  |
| `checkpoint()`                | Reliable filesystem (HDFS/S3) | Survives failures                 |

For day-to-day notebook work, `cache()` is what you want. For production ETL with retries, `checkpoint()` is more durable.

---

## Real-World Use Cases

```
1. ETL pipeline running 5 actions on same df ->
   cache() once, reuse 5x. Storage tab fills, jobs after first one are fast.

2. df.show() then df.collect() in a notebook ->
   collect job is fast not because data is small, but because shuffle output
   is reused.

3. unpersist before final write ->
   intentional to free memory; trade-off is final job gets longer.

4. Shuffle skew where one task is 10x longer ->
   even reused shuffle can have skew; reuse doesn't fix bad partitioning.

5. Streaming micro-batch jobs that always recompute ->
   no reuse across batches because lineage resets each batch.
```

---

## Cross-References

| Topic                                       | Pattern |
|---------------------------------------------|---------|
| What `Exchange` and `ReusedExchange` look like | 06    |
| Why `show()` jobs benefit so much from reuse | 03      |
| Cache health and Storage tab details        | 07      |
| Why repeated jobs sometimes slow down (eviction) | 07, 08 |

---

## Key Takeaway

> "Skipped" is the most beautiful word in Spark UI — it means Spark is reusing previous work for free.
> Two sources: **shuffle output on local disk** + **cached DataFrames in memory/disk**.
> Read the `(N skipped)` count alongside succeeded tasks to know how much *real* work each job did.
> Master this pattern, and the entire 5-job reference run (Pattern 03) suddenly makes total sense.
