import { useRef, useEffect, useCallback, useState } from 'react';
import { LeakyBucket } from '../../lib/algorithms/leaky-bucket';
import { useLeakyBucketStore } from '../../stores/leaky-bucket-store';
import LeakyBucketCanvas from './LeakyBucketCanvas';
import CodePanel from './CodePanel';
import EventLog from './EventLog';

export default function LeakyBucketVisualizer({ config }) {
  const bucketRef = useRef(new LeakyBucket(8, 3));
  const canvasRef = useRef(null);
  const autoIntervalRef = useRef(null);
  const codeStepTimeoutRef = useRef(null);
  const {
    capacity, leakRate, autoRate, autoActive,
    accepted, rejected, total, currentStep,
    addLog, recordAccept, recordReject, setStep, reset, startTime,
  } = useLeakyBucketStore();
  const [codeOpen, setCodeOpen] = useState(false);

  useEffect(() => { bucketRef.current.capacity = capacity; }, [capacity]);
  useEffect(() => { bucketRef.current.leakRate = leakRate; }, [leakRate]);

  const highlightSteps = useCallback((steps) => {
    if (codeStepTimeoutRef.current) clearTimeout(codeStepTimeoutRef.current);
    let i = 0;
    function next() {
      if (i >= steps.length) { setTimeout(() => setStep(null), 600); return; }
      setStep(steps[i]); i++;
      codeStepTimeoutRef.current = setTimeout(next, 150);
    }
    next();
  }, [setStep]);

  const sendRequest = useCallback(() => {
    const result = bucketRef.current.allow(performance.now());
    const t = ((performance.now() - startTime) / 1000).toFixed(1);
    if (result.accepted) {
      recordAccept();
      addLog({ time: t + 's', type: 'allow', message: `\u2713 ACCEPT queue=${result.queueSize}/${capacity}` });
      canvasRef.current?.addAnim('req-accept', 900);
      highlightSteps(config.stepsAllow);
    } else {
      recordReject();
      addLog({ time: t + 's', type: 'deny', message: `\u2717 REJECT queue full (${result.queueSize}/${capacity})` });
      canvasRef.current?.addAnim('req-reject', 800);
      highlightSteps(config.stepsDeny);
    }
  }, [capacity, startTime, recordAccept, recordReject, addLog, highlightSteps, config]);

  const handleBurst = useCallback(() => { let i = 0; const iv = setInterval(() => { if (i++ >= 5) { clearInterval(iv); return; } sendRequest(); }, 80); }, [sendRequest]);
  const handleReset = useCallback(() => {
    bucketRef.current.capacity = capacity; bucketRef.current.leakRate = leakRate; bucketRef.current.reset();
    reset(); addLog({ time: '0.0s', type: 'refill', message: 'Bucket reset' });
  }, [capacity, leakRate, reset, addLog]);

  useEffect(() => {
    if (autoActive) autoIntervalRef.current = setInterval(sendRequest, 1000 / autoRate);
    else if (autoIntervalRef.current) { clearInterval(autoIntervalRef.current); autoIntervalRef.current = null; }
    return () => { if (autoIntervalRef.current) clearInterval(autoIntervalRef.current); };
  }, [autoActive, autoRate, sendRequest]);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); sendRequest(); }
      if (e.key === 'b' || e.key === 'B') handleBurst();
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [sendRequest, handleBurst, handleReset]);

  const { setCapacity, setLeakRate, setAutoRate, toggleAuto } = useLeakyBucketStore();

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <div className="dc-stats-inline">
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: 'var(--accent)' }}>{accepted}</span>
            <span className="dc-stat-chip__label">Accepted</span>
          </div>
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: 'var(--accent-warm)' }}>{rejected}</span>
            <span className="dc-stat-chip__label">Rejected</span>
          </div>
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value">{total}</span>
            <span className="dc-stat-chip__label">Total</span>
          </div>
          <div className="dc-stats-inline__bar">
            <div className="dc-stats-inline__bar-fill" style={{ width: `${total > 0 ? (accepted / total) * 100 : 0}%`, background: 'var(--accent)' }} />
          </div>
        </div>
      </div>

      <LeakyBucketCanvas ref={canvasRef} bucketRef={bucketRef} />

      <div className="dc-control-bar">
        <button className="dc-btn dc-btn--primary" onClick={sendRequest}>Send Request</button>
        <button className="dc-btn dc-btn--secondary" onClick={handleBurst}>Burst x5</button>
        <button className={`dc-btn ${autoActive ? 'dc-btn--success' : 'dc-btn--outline'}`} onClick={toggleAuto}>
          {autoActive ? 'Stop Auto' : 'Auto Send'}
        </button>
        <div className="dc-control-bar__sep" />
        <div className="dc-slider-group">
          <label>Capacity</label>
          <input type="range" min={3} max={20} value={capacity} onChange={(e) => setCapacity(+e.target.value)} />
          <span className="dc-slider-val">{capacity}</span>
        </div>
        <div className="dc-slider-group">
          <label>Leak Rate</label>
          <input type="range" min={1} max={10} step={0.5} value={leakRate} onChange={(e) => setLeakRate(+e.target.value)} />
          <span className="dc-slider-val">{leakRate}/s</span>
        </div>
        <div className="dc-slider-group">
          <label>Auto Rate</label>
          <input type="range" min={1} max={15} value={autoRate} onChange={(e) => setAutoRate(+e.target.value)} />
          <span className="dc-slider-val">{autoRate}/s</span>
        </div>
        <div className="dc-control-bar__sep" />
        <button className="dc-btn dc-btn--danger" onClick={handleReset}>Reset</button>
      </div>

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="16 18 22 12 16 6" /><polyline points="8 6 2 12 8 18" /></svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: codeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9" /></svg>
          </button>
          {codeOpen && <div className="dc-visualizer__code-wrap"><CodePanel code={config.code} activeStep={currentStep} languages={config.meta.languages} storeFn={useLeakyBucketStore} /></div>}
        </div>
        <div className="dc-visualizer__log-col"><EventLog storeFn={useLeakyBucketStore} /></div>
      </div>
      <div className="dc-visualizer__shortcuts"><kbd>Space</kbd> Send <kbd>B</kbd> Burst <kbd>R</kbd> Reset</div>
    </div>
  );
}
