# SQL in Plain English — Execution Order, CTEs, and Window Functions

This note is a **slow, English-only walkthrough** of ideas that are often shortened to “hints” in cheat sheets. Use it together with [[04-SQL-Clauses-and-Filtering]] (execution order), [[06-Subqueries-and-Nested-Queries]] (CTEs), and [[08-Window-Functions]] (syntax and examples).

---

## 1. Why “execution order” matters

You write a query top to bottom: `SELECT … FROM … WHERE …`. The database does **not** run it in that order. It uses a **logical order** so that each step only uses data that already exists.

Think of it like cooking: you cannot “serve the dish” before you have chopped the vegetables. In SQL, you cannot filter on a column alias from `SELECT` inside `WHERE`, because **when `WHERE` runs, that alias does not exist yet**.

**Typical logical order (what you should remember for interviews):**

1. **FROM / JOIN** — Build the working table (all joined rows).
2. **WHERE** — Throw away rows you do not want (row-by-row conditions).
3. **GROUP BY** — Collapse rows into groups (for aggregates like `SUM`, `COUNT`).
4. **HAVING** — Filter **groups** (after aggregation).
5. **SELECT** — Compute output columns and expressions.
6. **DISTINCT** — Remove duplicate result rows (if used).
7. **ORDER BY** — Sort the final result.
8. **LIMIT / OFFSET** — Cut the result to N rows.

**Window functions** (things like `RANK() OVER (…)`) are evaluated in a phase that comes **after** `GROUP BY` / `HAVING` in the logical model. That is why this fails:

```sql
-- Not allowed: WHERE runs before window functions are available
SELECT name, RANK() OVER (ORDER BY salary DESC) AS rnk
FROM employees
WHERE rnk = 1;  -- error: unknown column "rnk"
```

You fix it with a **subquery** or **CTE**: first compute `rnk`, then filter.

---

## 2. What a CTE (`WITH`) actually is

**CTE** means *Common Table Expression*. The `WITH` clause gives a **name** to a subquery result for the **rest of one statement**.

**Plain English:** “First, imagine a temporary result table called `ranked`. Build it. Then run the final `SELECT` as if `ranked` were a real table.”

```sql
WITH ranked AS (
    SELECT
        name,
        salary,
        RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT name, salary
FROM ranked
WHERE rnk <= 3;
```

**Mental model for execution:**

1. Run the query inside `ranked AS ( … )`. You get a virtual table with columns `name`, `salary`, `rnk`.
2. Run the outer `SELECT … FROM ranked WHERE …` on that virtual table.

**Why people use CTEs:**

- **Readability** — You name each step (“ranked”, “monthly_totals”) instead of nesting five subqueries.
- **Reuse** — The same named result can be referenced twice in one query (e.g. join a CTE to itself).
- **Interview clarity** — You can say: “I first rank everyone, then I filter to the top three.”

**Important:** A CTE is **scoped to one statement**. It is not a permanent table. When the statement ends, that name is gone.

**CTE vs subquery:** Same idea (a query inside a query). A CTE is usually easier to read. Performance is often similar; the optimizer may “inline” a CTE like a subquery.

---

## 3. What a window function does (without jargon)

**Aggregate with `GROUP BY`:** You combine many rows into **few** rows (one per group).

**Window function:** You keep **every row**, and add a new column whose value is computed from a **window** of rows related to the current row.

**Simple picture:**

- `PARTITION BY department` means: “Restart the logic for each department.” Like separate little races: IT has its own ranking, HR has its own ranking.
- `ORDER BY salary DESC` inside `OVER` means: “Within that partition, order rows by salary so that ‘first’, ‘previous’, ‘next’, and ‘rank’ make sense.”

So a window function always needs **`OVER ( … )`**. That `OVER` clause defines **which rows** are visible when we compute the value for **this** row.

---

## 4. `ROW_NUMBER`, `RANK`, and `DENSE_RANK` — explained slowly

Imagine students and exam scores. Several students can have the **same score**.

### `ROW_NUMBER()`

- Assigns **1, 2, 3, …** with **no duplicates** in the ordered list.
- If two people tie, the database still gives them **different** numbers; the choice between tied rows is **not specified** by the standard (implementation-dependent).

**When to use:** “I need exactly one row labeled 1, one labeled 2…” — pagination, deduplication (“keep one row per user”), or “pick any one of the ties.”

### `RANK()`

- Gives the **same rank** to tied values.
- After a tie, it **skips** the next ranks (like sports medals: two golds, then no silver — next is bronze).

Example scores highest to lowest: 100, 90, 90, 80.

- Ranks: **1**, **2**, **2**, **4** (there is no rank 3).

**When to use:** “Official standing” where tied people share a place and the next place reflects how many people are ahead (olympic-style ranking, “top 10 distinct positions”).

### `DENSE_RANK()`

- Same rank for ties, but **no gaps** after ties.

Same scores: 100, 90, 90, 80.

- Dense ranks: **1**, **2**, **2**, **3**.

**When to use:** “Nth highest **distinct** salary” problems. If you want “2nd highest salary value,” ties behave more predictably with `DENSE_RANK` than with `RANK`.

### Quick decision guide

| Goal | Function |
|------|----------|
| Exactly N rows, ties broken arbitrarily | `ROW_NUMBER` |
| Competition-style rank with gaps after ties | `RANK` |
| Rank levels without gaps; Nth distinct value | `DENSE_RANK` |

---

## 5. How CTE + window function flow together (one story)

**Problem:** “Show the top 2 earners **per department**.”

**Idea in English:**

1. For each employee row, compute a row number **within their department**, ordered by salary descending.
2. Then keep only rows where that number is 1 or 2.

```sql
WITH numbered AS (
    SELECT
        name,
        department,
        salary,
        ROW_NUMBER() OVER (
            PARTITION BY department
            ORDER BY salary DESC
        ) AS rn
    FROM employees
)
SELECT name, department, salary
FROM numbered
WHERE rn <= 2;
```

**Flow:**

1. `FROM employees` builds the input rows.
2. Inside the CTE, the window function runs **after** the working set for the CTE is known (no `GROUP BY` here, so the working set is all employees).
3. For each row, `ROW_NUMBER` looks only at rows in the **same** `department` partition and orders them by `salary DESC`, then assigns `rn`.
4. The outer query filters `rn <= 2`.

If the question were “everyone who is in the **top 2 salary bands** in the company” with ties, you might use `RANK` or `DENSE_RANK` instead of `ROW_NUMBER`, because `ROW_NUMBER` would arbitrarily split ties.

---

## 6. `LAG` / `LEAD` in one sentence each

- **`LAG(column)`** — Value from **earlier** row in the window order (often used for “yesterday vs today”, “previous month”).
- **`LEAD(column)`** — Value from **later** row (often used for “next event”, “forward-looking” gaps).

They only make sense when `ORDER BY` inside `OVER` defines what “previous” and “next” mean.

---

## 7. Short interview lines you can say out loud

- **Execution order:** “`WHERE` filters rows before grouping; `HAVING` filters after `GROUP BY`. Aliases from `SELECT` are not available in `WHERE` because `WHERE` runs earlier.”
- **Window vs aggregate:** “`GROUP BY` collapses rows; window functions keep all rows and add a computed column over a partition.”
- **CTE:** “It names a subquery result for one statement so the main query is easier to read and I can filter on computed columns like rank.”
- **RANK vs DENSE_RANK:** “Both tie the same; `RANK` leaves gaps, `DENSE_RANK` does not — I pick based on whether we want olympic-style positions or dense levels.”

---

*Companion to the numbered SQL notes — plain English explanations for execution flow, CTEs, and window functions.*
