import { useEffect, useState } from 'react';
import { supabase, getAuthHeaders as supaGetAuthHeaders } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

/*
 * AuthGate — Supabase Auth UI + a thin compat surface.
 *
 * Supports:
 *   - Email magic link (passwordless) — primary path
 *   - Google OAuth
 *   - GitHub OAuth
 *
 * Legacy `getAuthHeaders()` / `firebaseLogout()` are kept as named exports
 * so call sites that haven't migrated yet still compile. They now read the
 * Supabase access token instead of localStorage 'inkdrop-token', so any
 * server endpoint that switched to verifySupabaseJwt sees the right JWT.
 */

const InkDropLogo = () => (
  <svg width="40" height="40" viewBox="0 0 100 100" fill="none">
    <defs>
      <linearGradient id="ag" x1="0.15" y1="0.1" x2="0.85" y2="0.9">
        <stop offset="0%" stopColor="#6366F1" />
        <stop offset="100%" stopColor="#10B981" />
      </linearGradient>
    </defs>
    <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#ag)" />
    <rect x="35" y="49" width="30" height="3" rx="1.5" fill="white" opacity="0.92" />
    <rect x="35" y="59" width="22" height="3" rx="1.5" fill="white" opacity="0.65" />
  </svg>
);

const GoogleIcon = () => (
  <svg width="16" height="16" viewBox="0 0 48 48">
    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
  </svg>
);

const GitHubIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <path d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56 0-.28-.01-1.02-.02-2-3.2.7-3.88-1.54-3.88-1.54-.52-1.32-1.27-1.67-1.27-1.67-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.02 1.76 2.69 1.25 3.35.96.1-.74.4-1.25.72-1.54-2.55-.29-5.24-1.28-5.24-5.71 0-1.26.45-2.29 1.18-3.1-.12-.29-.51-1.46.11-3.04 0 0 .96-.31 3.15 1.18a10.97 10.97 0 0 1 5.74 0c2.18-1.49 3.15-1.18 3.15-1.18.62 1.58.23 2.75.11 3.04.74.81 1.18 1.84 1.18 3.1 0 4.44-2.69 5.41-5.25 5.7.41.36.78 1.06.78 2.15 0 1.55-.01 2.8-.01 3.18 0 .31.21.67.8.55C20.21 21.39 23.5 17.08 23.5 12 23.5 5.65 18.35.5 12 .5z" />
  </svg>
);

export default function AuthGate({ children }) {
  const { loading, session, user } = useAuth();
  const [email, setEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [oauthLoading, setOauthLoading] = useState(null);
  const [info, setInfo] = useState('');
  const [error, setError] = useState('');

  /* If we landed here from an OAuth/magic-link callback, getSession will
   * pick up the new session and the AuthProvider re-renders us. */
  useEffect(() => {
    if (session) setError('');
  }, [session]);

  const handleMagicLink = async (e) => {
    e?.preventDefault?.();
    if (!email || submitting) return;
    setSubmitting(true);
    setError('');
    setInfo('');
    try {
      const { error: err } = await supabase.auth.signInWithOtp({
        email: email.trim(),
        options: { emailRedirectTo: `${window.location.origin}` },
      });
      if (err) throw err;
      setInfo('Check your inbox — we just sent a sign-in link to ' + email.trim());
    } catch (err) {
      setError(err?.message || 'Could not send magic link');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOAuth = async (provider) => {
    setOauthLoading(provider);
    setError('');
    try {
      const { error: err } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo: `${window.location.origin}` },
      });
      if (err) throw err;
      /* The browser is redirected; nothing else to do here. */
    } catch (err) {
      setError(err?.message || `${provider} sign-in failed`);
      setOauthLoading(null);
    }
  };

  if (loading) {
    return (
      <div className="auth">
        <div className="auth__bg-orbs" aria-hidden="true">
          <div className="auth__orb auth__orb--1" />
          <div className="auth__orb auth__orb--2" />
          <div className="auth__orb auth__orb--3" />
        </div>
        <div className="auth__card" style={{ gap: '24px' }}>
          <div className="auth__logo"><InkDropLogo /></div>
          <div className="auth__spinner" />
          <p className="auth__subtitle">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="auth">
        <div className="auth__bg-orbs" aria-hidden="true">
          <div className="auth__orb auth__orb--1" />
          <div className="auth__orb auth__orb--2" />
          <div className="auth__orb auth__orb--3" />
        </div>
        <div className="auth__card">
          <div className="auth__logo"><InkDropLogo /></div>
          <div className="auth__header-text">
            <h1 className="auth__title">Welcome back</h1>
            <p className="auth__subtitle">Sign in to your workspace</p>
          </div>

          <div className="auth__oauth-row">
            <button
              className="auth__oauth-btn"
              onClick={() => handleOAuth('google')}
              disabled={oauthLoading !== null || submitting}
            >
              {oauthLoading === 'google' ? <div className="auth__oauth-spinner" /> : <GoogleIcon />}
              <span>{oauthLoading === 'google' ? 'Redirecting…' : 'Google'}</span>
            </button>

            <button
              className="auth__oauth-btn auth__oauth-btn--github"
              onClick={() => handleOAuth('github')}
              disabled={oauthLoading !== null || submitting}
            >
              {oauthLoading === 'github' ? <div className="auth__oauth-spinner" /> : <GitHubIcon />}
              <span>{oauthLoading === 'github' ? 'Redirecting…' : 'GitHub'}</span>
            </button>
          </div>

          <div className="auth__divider">
            <span className="auth__divider-line" />
            <span className="auth__divider-text">or</span>
            <span className="auth__divider-line" />
          </div>

          <form onSubmit={handleMagicLink} className="auth__form">
            <div className="auth__input-wrap">
              <svg className="auth__input-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
              </svg>
              <input
                className="auth__email-input"
                type="email"
                placeholder="name@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoFocus
                required
              />
            </div>
            <button
              type="submit"
              className="auth__submit"
              disabled={!email || submitting || oauthLoading !== null}
            >
              {submitting ? (
                <>
                  <div className="auth__oauth-spinner" />
                  Sending…
                </>
              ) : 'Continue with email'}
            </button>
          </form>

          {info && <p className="auth__info-msg">{info}</p>}
          {error && <p className="auth__error">{error}</p>}

          <p className="auth__hint">
            No password needed — we'll send a magic link to your inbox.
          </p>
        </div>
      </div>
    );
  }

  return typeof children === 'function' ? children(user) : children;
}

/* ── Compat exports ─────────────────────────────────────────────────────
 * Older modules import these by name; they now operate on the Supabase
 * session so existing call sites keep working while we migrate. */

export function getAuthHeaders() {
  return supaGetAuthHeaders();
}

export async function firebaseLogout() {
  try { await supabase.auth.signOut(); } catch { /* ignore */ }
  /* Drop legacy keys so we don't accidentally re-hydrate the old paths. */
  try {
    localStorage.removeItem('inkdrop-token');
    localStorage.removeItem('inkdrop-user');
  } catch { /* ignore */ }
  window.location.reload();
}
