# Date Series Fill

Generate a complete sequence of dates (or numbers) and LEFT JOIN it with actual data to fill in missing entries with zeros or defaults. This ensures reports have no gaps — every day, week, or month appears.

**DSA Analogy**: Sparse array with defaults — like creating an array of size N initialized to 0, then filling in only the positions that have actual data. Missing positions remain 0 instead of being absent.

---

## Core Idea (2 Lines)

Real data is sparse — not every date has an event. Reports need every date. Generate a continuous date series, then LEFT JOIN actual data onto it. Missing dates get NULL (or COALESCE to 0), creating a gap-free timeline.

---

## The Problem

```
Actual data:                         Report needs:

date       | orders                  date       | orders
───────────┼────────                 ───────────┼────────
2024-01-01 | 5                       2024-01-01 | 5
2024-01-03 | 8                       2024-01-02 | 0        ← was missing
2024-01-05 | 3                       2024-01-03 | 8
                                     2024-01-04 | 0        ← was missing
                                     2024-01-05 | 3
```

---

## Step 1: Generate the Date Series

### PostgreSQL: generate_series()

```sql
SELECT generate_series(
    '2024-01-01'::date,
    '2024-01-31'::date,
    '1 day'::interval
)::date AS date;
```

### MySQL: Recursive CTE

```sql
WITH RECURSIVE dates AS (
    SELECT '2024-01-01' AS date
    UNION ALL
    SELECT date + INTERVAL 1 DAY
    FROM dates
    WHERE date < '2024-01-31'
)
SELECT date FROM dates;
```

### SQL Server: Recursive CTE or Numbers Table

```sql
WITH dates AS (
    SELECT CAST('2024-01-01' AS DATE) AS date
    UNION ALL
    SELECT DATEADD(DAY, 1, date)
    FROM dates
    WHERE date < '2024-01-31'
)
SELECT date FROM dates
OPTION (MAXRECURSION 400);
```

### BigQuery: GENERATE_DATE_ARRAY

```sql
SELECT date
FROM UNNEST(GENERATE_DATE_ARRAY('2024-01-01', '2024-01-31')) AS date;
```

---

## Step 2: LEFT JOIN with Actual Data

```sql
-- PostgreSQL example
WITH date_series AS (
    SELECT generate_series('2024-01-01'::date, '2024-01-31'::date, '1 day')::date AS date
)
SELECT ds.date,
       COALESCE(COUNT(o.id), 0) AS order_count,
       COALESCE(SUM(o.amount), 0) AS total_revenue
FROM date_series ds
LEFT JOIN orders o ON o.order_date = ds.date
GROUP BY ds.date
ORDER BY ds.date;
```

**How it works:**

```
date_series (generated):     orders (actual):           LEFT JOIN result:

2024-01-01                   2024-01-01 | $100          2024-01-01 | $100
2024-01-02                   2024-01-03 | $200          2024-01-02 | NULL → 0
2024-01-03                   2024-01-03 | $150          2024-01-03 | $350
2024-01-04                   2024-01-05 | $80           2024-01-04 | NULL → 0
2024-01-05                                              2024-01-05 | $80
```

---

## Common Patterns

### Pattern 1: Daily Order Count (Fill Missing Days)

```sql
WITH date_series AS (
    SELECT generate_series(
        (SELECT MIN(order_date) FROM orders),
        (SELECT MAX(order_date) FROM orders),
        '1 day'::interval
    )::date AS date
)
SELECT ds.date,
       COALESCE(COUNT(o.id), 0) AS orders
FROM date_series ds
LEFT JOIN orders o ON o.order_date = ds.date
GROUP BY ds.date
ORDER BY ds.date;
```

### Pattern 2: Monthly Revenue (Fill Missing Months)

```sql
WITH month_series AS (
    SELECT generate_series(
        DATE_TRUNC('month', '2024-01-01'::date),
        DATE_TRUNC('month', '2024-12-01'::date),
        '1 month'::interval
    )::date AS month
)
SELECT ms.month,
       COALESCE(SUM(o.amount), 0) AS revenue
FROM month_series ms
LEFT JOIN orders o ON DATE_TRUNC('month', o.order_date) = ms.month
GROUP BY ms.month
ORDER BY ms.month;
```

### Pattern 3: Per-User Daily Activity (Multi-Dimension Fill)

```sql
-- Fill missing dates for EACH user
WITH date_series AS (
    SELECT generate_series('2024-01-01'::date, '2024-01-31'::date, '1 day')::date AS date
),
users AS (
    SELECT DISTINCT user_id FROM logins
)
SELECT u.user_id, ds.date,
       CASE WHEN l.user_id IS NOT NULL THEN 1 ELSE 0 END AS logged_in
FROM users u
CROSS JOIN date_series ds
LEFT JOIN logins l ON l.user_id = u.user_id AND l.login_date = ds.date
ORDER BY u.user_id, ds.date;
```

**Technique**: CROSS JOIN users with dates to create a complete grid, then LEFT JOIN actual data.

### Pattern 4: Fill with Previous Value (Forward Fill)

When missing values should carry the last known value:

```sql
WITH date_series AS (
    SELECT generate_series('2024-01-01'::date, '2024-01-31'::date, '1 day')::date AS date
),
joined AS (
    SELECT ds.date, p.price,
           COUNT(p.price) OVER (ORDER BY ds.date) AS grp
    FROM date_series ds
    LEFT JOIN prices p ON p.effective_date = ds.date
)
SELECT date,
       FIRST_VALUE(price) OVER (PARTITION BY grp ORDER BY date) AS filled_price
FROM joined;
```

The trick: COUNT(non-null) creates groups that share the same last-known value.

### Pattern 5: Number Series for Sequences

```sql
-- Fill gaps in a numbered sequence
WITH nums AS (
    SELECT generate_series(1, 100) AS n
)
SELECT n.n AS expected_id
FROM nums n
LEFT JOIN actual_table a ON a.id = n.n
WHERE a.id IS NULL;   -- shows missing IDs
```

---

## Dynamic Date Range (Auto-Detect Boundaries)

```sql
-- Automatically use min/max dates from the data
WITH bounds AS (
    SELECT MIN(order_date) AS start_date,
           MAX(order_date) AS end_date
    FROM orders
),
date_series AS (
    SELECT generate_series(start_date, end_date, '1 day'::interval)::date AS date
    FROM bounds
)
SELECT ds.date, COALESCE(COUNT(o.id), 0) AS orders
FROM date_series ds
LEFT JOIN orders o ON o.order_date = ds.date
GROUP BY ds.date
ORDER BY ds.date;
```

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| INNER JOIN instead of LEFT JOIN | Missing dates get dropped | Always use LEFT JOIN |
| Forgetting COALESCE | NULLs for missing dates instead of 0 | `COALESCE(SUM(amount), 0)` |
| Date truncation mismatch | `order_date` has timestamp, series is date | Truncate or cast consistently |
| Missing GROUP BY | Multiple orders per day not aggregated | Add GROUP BY ds.date |
| Recursive CTE without limit | Infinite loop if end date misconfigured | Add WHERE date < end_date guard |
| CROSS JOIN explosion | Users × Dates can be huge | Filter users or limit date range |

---

## Performance Considerations

```
Date Series Size:
  1 year daily   = 365 rows      (trivial)
  10 years daily = 3,650 rows    (still trivial)
  1 year hourly  = 8,760 rows    (fine)

CROSS JOIN Explosion:
  1000 users × 365 days = 365,000 rows   (manageable)
  1M users × 365 days   = 365M rows      (too large!)
  → For large user sets, filter to active users first

Optimization:
  1. Index the date column in the actual data table
  2. Filter the date range as tightly as possible
  3. Aggregate actual data first, THEN join with series
```

---

## Key Takeaway

> Date Series Fill = generate a complete calendar, LEFT JOIN actual data onto it, and COALESCE nulls to zeros. Use `generate_series()` in PostgreSQL, recursive CTE in MySQL/SQL Server, or `GENERATE_DATE_ARRAY` in BigQuery. For multi-dimensional fills (per user per day), use CROSS JOIN to create the complete grid first.
