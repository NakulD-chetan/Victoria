# File Formats — Parquet vs ORC vs Avro

Choosing the right file format can make your Spark jobs 10x faster or 10x slower. Here's when to use each.

---

## The Three Formats at a Glance

| Format  | Storage Type | Best For                    | Default In      |
|---------|-------------|-----------------------------|--------------------|
| Parquet | Columnar    | Analytics, Spark workloads  | Spark, Hive, Presto |
| ORC     | Columnar    | Hive, ACID transactions     | Hive               |
| Avro    | Row-based   | Streaming, Kafka, CDC       | Kafka, Schema Registry |

---

## 1. Parquet (Columnar) — Spark's Default

### What Is Columnar Storage?

Instead of storing data row by row, Parquet stores data **column by column**:

```
Row-based (CSV/Avro):
  Row 1: [name="Alice", age=30, city="Mumbai"]
  Row 2: [name="Bob",   age=25, city="Pune"]
  Row 3: [name="Carol", age=35, city="Delhi"]

Columnar (Parquet):
  Column "name": ["Alice", "Bob", "Carol"]
  Column "age":  [30, 25, 35]
  Column "city": ["Mumbai", "Pune", "Delhi"]
```

### Why Columnar Is Great for Analytics

When you run:
```sql
SELECT AVG(age) FROM people
```

- **Row-based**: Must read ALL columns (name, age, city) to get to age → wastes I/O
- **Columnar**: Reads ONLY the age column → much less data read

### Key Benefits
- **Column pruning** — reads only the columns you select
- **Excellent compression** — same-type values compress well (dictionary encoding, run-length encoding)
- **Predicate pushdown** — skips row groups that don't match filters (using min/max statistics)
- **Spark's default** — most optimized format in Spark
- Great for analytics, aggregations, filters, joins

### When to Use Parquet
- Batch analytics / OLAP workloads
- Data lakes (S3, HDFS, ADLS)
- Spark ETL pipelines
- ML feature stores
- Any "read few columns from wide table" pattern

### Example
```python
df.write.parquet("output/data.parquet")
df = spark.read.parquet("output/data.parquet")
```

---

## 2. ORC (Columnar) — Hive Optimized

ORC (Optimized Row Columnar) is similar to Parquet but optimized for Hive.

### Key Benefits
- **Better compression** than Parquet (typically 10–30% smaller files)
- **Built-in lightweight indexes** in every stripe → faster data skipping
- **Native ACID support** — insert, update, delete operations (Hive 3.x)
- **Very strong predicate pushdown** — stripe-level statistics

### When to Use ORC
- Hive is your primary query engine
- You need **ACID transactions** (update/delete rows)
- You want the absolute **best compression**
- Hadoop + Hive ecosystem

### Example
```python
df.write.format("orc").save("output/data.orc")
df = spark.read.format("orc").load("output/data.orc")
```

---

## 3. Avro (Row-based) — Streaming & Schema Evolution

Avro stores data **row by row** and embeds the schema in every file.

### Key Benefits
- **Row-based** — great for write-heavy workloads (each row is written as a unit)
- **Strong schema evolution** — add/remove/rename fields without breaking readers
  - Backward compatible (new reader can read old data)
  - Forward compatible (old reader can read new data)
- **Compact** — binary format with embedded schema
- **Splittable** — Spark can process different parts in parallel
- **Kafka standard** — most Kafka pipelines use Avro with Schema Registry

### When to Use Avro
- Kafka message serialization
- CDC (Change Data Capture) pipelines
- Row-level ingestion (OLTP-style writes)
- When schema changes frequently
- Data exchange between microservices

### Example
```python
df.write.format("avro").save("output/data.avro")
df = spark.read.format("avro").load("output/data.avro")
```

---

## Detailed Comparison

| Feature             | Parquet          | ORC              | Avro             |
|---------------------|------------------|-------------------|------------------|
| Storage Type        | Columnar         | Columnar          | Row-based        |
| Best For            | Analytics/Spark  | Hive/ACID         | Streaming/Kafka  |
| Compression         | Excellent        | Best              | Good             |
| Predicate Pushdown  | Yes              | Very strong       | No               |
| Schema Evolution    | Moderate         | Moderate          | Excellent        |
| Write Performance   | OK               | Slower            | Fast             |
| Read Performance    | Fast             | Fastest           | Slow (for analytics) |
| Column Pruning      | Yes              | Yes               | No               |
| ACID Support        | No (use Delta)   | Yes (Hive native) | No               |
| Typical Use Case    | Data lakes, ETL  | Hive warehouse    | Kafka, CDC       |

---

## Modern Alternatives Worth Knowing

### Delta Lake (Built on Parquet)
- Adds ACID transactions to Parquet
- Time travel (query old versions of data)
- Schema enforcement and evolution
- Used with Databricks

### Apache Iceberg (Table Format)
- Works with Parquet, ORC, or Avro underneath
- Hidden partitioning
- Snapshot isolation
- Growing in popularity

### Apache Hudi (Table Format)
- Built for incremental processing
- Upserts on data lakes
- Used heavily with streaming + lake architectures

---

## Decision Guide

```
What's your primary use case?

Analytics (SELECT, GROUP BY, JOIN on large tables)?
  → Parquet (default for Spark)

Hive warehouse with UPDATE/DELETE needed?
  → ORC (ACID native in Hive)

Streaming / Kafka / CDC pipeline?
  → Avro (schema evolution, row-level writes)

Need ACID on Spark/Data Lake?
  → Delta Lake (Parquet + transactions)
```

---

## Key Takeaway

> **Parquet** = columnar, best for analytics, Spark's default. Use for data lakes and batch workloads.
> **ORC** = columnar, better compression, Hive optimized. Use for Hive ACID workloads.
> **Avro** = row-based, best for streaming and schema evolution. Use for Kafka and CDC pipelines.
