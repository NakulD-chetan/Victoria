# Design URL Shortener — Question List

> **Permanent Recall:** Core variations: add analytics, custom domains, link expiry at scale, QR code service, 1B URLs. Related problems: Pastebin (same + content storage), file sharing (same + large objects). Difficulty: Easy = basic shortener; Medium = analytics, custom domains; Hard = 1B scale, global distribution.

---

## Core Variations & Follow-Ups

| # | Question | Difficulty | Key Additions |
|---|----------|------------|---------------|
| 1 | Design a URL shortener like bit.ly | Easy | Base design; shorten + redirect |
| 2 | Add analytics tracking (clicks, geo, referrer) | Medium | Async events, Kafka, analytics service, data warehouse |
| 3 | Support custom domains (e.g., link.mycompany.com) | Medium | DNS CNAME, domain → service mapping, validation |
| 4 | How to handle link expiry at scale? | Medium | expires_at, background cleanup job, cache TTL, lazy 404 |
| 5 | Design a QR code service on top of the shortener | Medium | Short URL → QR generator; same redirect backend |
| 6 | How would you handle 1B URLs? | Hard | Sharding by short_code hash, KGS per shard, distributed cache |
| 7 | Add rate limiting and abuse prevention | Medium | Token bucket, blocklist, CAPTCHA for anonymous |
| 8 | Support bulk URL shortening (API batch) | Medium | Batch endpoint, async processing, webhook or poll for result |
| 9 | How would you implement custom alias collision handling? | Easy | DB unique check, 409 Conflict, reserved word blocklist |
| 10 | Design for multi-region (US, EU, Asia) | Hard | Geo-routing, regional caches, eventual consistency |
| 11 | What if we need to change the destination of a short URL? | Easy | Update DB, invalidate cache (delete Redis key) |
| 12 | How do you prevent enumeration attacks? | Medium | Unpredictable keys (base62, not sequential); rate limit |
| 13 | Design a dashboard for users to see their shortened URLs | Medium | User_id in schema, list by user, pagination |
| 14 | How would you handle malicious/phishing URLs? | Medium | Blocklist, user reports, crawler validation, interstitial warning |
| 15 | Design for write-heavy during viral events | Hard | Queue writes, async persist, KGS prefetch, horizontal scale |

---

## Related Problems

| Problem | Similarity | Key Difference |
|---------|------------|---------------|
| **Pastebin** | Short key, redirect-like fetch | Store content (text) not just URL; larger payload |
| **File sharing (Dropbox link)** | Short link to resource | Large file storage; CDN for delivery |
| **Tiny URL with preview** | Same base | Add metadata fetch (title, thumbnail) before redirect |
| **Deep link shortener (app links)** | Same flow | Redirect to app store or in-app; platform-specific |

---

## Difficulty Guide

| Level | Typical Questions |
|-------|-------------------|
| **Easy** | Basic shorten + redirect, schema, simple cache |
| **Medium** | Analytics, custom domains, expiry, rate limiting |
| **Hard** | 1B+ scale, multi-region, viral spikes, sharding |

---

## Quick Answer Templates

### "Add analytics"
Async event on redirect → Kafka → analytics worker → DW. Don't block redirect.

### "Custom domains"
User adds CNAME pointing to our servers. We map domain in DB; redirect validates host.

### "Link expiry at scale"
`expires_at` in schema. Background job batches delete. Cache TTL = min(expires_at - now, 24h). Lazy 404 on access.

### "QR code on top"
Short URL API unchanged. New service: given long URL → shorten → generate QR image with short URL. Same redirect backend.

### "1B URLs"
Shard DB by `hash(short_url) % N`. KGS per shard or single KGS with range allocation. Redis cluster. Stateless API scale horizontally.

---

## 30-SECOND REVISION BOX

```
VARIATIONS: Analytics (async), custom domains (CNAME), expiry (job + lazy)
QR: Shorten → QR with short URL
1B: Sharding, KGS per shard
RELATED: Pastebin, file share, deep links
DIFFICULTY: Easy base, Medium +features, Hard scale
```

---

**Prev: [[07_Tricks-and-Recognition]]**
