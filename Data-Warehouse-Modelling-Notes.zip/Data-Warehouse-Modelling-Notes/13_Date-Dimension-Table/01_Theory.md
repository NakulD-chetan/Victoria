# Date Dimension Table

> "Time is the dimension that every fact table touches; model it once, conformed everywhere."

**Real-world analogy:** A date dimension is like the master calendar hanging in a retail chain’s head office: every store, promotion, and shipment refers to the same definitions of “weekend,” “fiscal week 14,” and “Black Friday,” so nobody argues whether a sale counted as November or December revenue.

---

## Core Idea (2 Lines)

A date dimension is a single table of calendar attributes keyed by one row per chosen time grain, joined to facts so reporting stays fast, consistent, and rich without recomputing holidays or fiscal periods at query time. It trades a modest number of rows for predictable joins and shared business rules across every fact in the warehouse.

---

## Why the Date Dimension Is Ubiquitous

Retail analytics almost always slices revenue, inventory, and labor by calendar concepts that go beyond a raw SQL `DATE` type. A conformed date dimension centralizes those concepts so the same “Fiscal Q3” label appears on store sales, e-commerce orders, and warehouse shipments.

| Reason | Retail example |
|--------|----------------|
| Shared definitions | “Same-store sales week” aligns POS and loyalty data |
| Performance | Precomputed flags avoid `CASE` expressions on billions of fact rows |
| Conformance | One `date_key` joins every fact for integrated dashboards |
| Tooling | BI tools map hierarchies (Year → Quarter → Week → Day) cleanly |

**Interview Tip:** Mention that the date dimension is often the first conformed dimension you build and the one most heavily reused across subject areas.

**Watch Out!** Building multiple incompatible date tables (e.g., one with ISO weeks and one with retail 4-5-4) without naming them clearly causes double-counting when analysts blend reports.

---

## Grain: Daily Default and Alternatives

Grain is the smallest time unit represented by one row in the date dimension.

| Grain | Typical use | Approx. rows (20 years) | Notes |
|-------|----------------|-------------------------|--------|
| Daily | Default for store sales, inventory snapshots | ~7,305 (365.25 × 20) | Most common; easy surrogate key as YYYYMMDD integer |
| Hourly | Clickstream, intraday labor | ~175,320 | Larger; often paired with separate time-of-day dim |
| Per minute | Sensor-level, some POS line timing | ~10.5M | Usually specialized; consider fact table design first |
| Weekly | High-level executive rollups only | ~1,040 | Loses day-level drill-down unless facts also carry day |

ASCII overview of grain choice:

```
        COARSE  <------------------------>  FINE
          |                                      |
       WEEKLY ---- DAILY ---- HOURLY ---- MINUTE
          |           |          |            |
    few rows    ~7.3K rows   large      very large
    limited      retail      intraday    edge cases
    drill-down   default     web/ops     IoT / logs
```

**Interview Tip:** State row-count math explicitly: 20 × 365.25 ≈ 7,305 rows for daily grain, which is trivial for modern engines.

**Watch Out!** Mixing grains (e.g., weekly dimension joined to daily facts without allocation) produces wrong averages and non-additive metrics unless you document allocation rules.

---

## Typical Columns (Retail Context)

Assume a national grocery chain: `dim_date` supports stores, `fact_store_sales`, and `fact_shipment`.

| Column group | Example columns | Purpose |
|----------------|------------------|---------|
| Calendar | `calendar_date`, `date_key`, `year`, `quarter`, `month`, `day_of_month` | Filtering, sorting, drill paths |
| Week | `iso_week`, `retail_week`, `week_start_date` | Replenishment and promotional calendars |
| Day semantics | `day_name`, `day_of_week`, `is_weekend`, `is_weekday` | Labor planning vs customer traffic |
| Fiscal | `fiscal_year`, `fiscal_period`, `fiscal_week` | Finance close and buyer reporting |
| Retail events | `is_holiday`, `holiday_name`, `is_promo_season` | Demand forecasting and post-mortems |

Example DDL sketch:

```sql
CREATE TABLE dim_date (
    date_key            INT         NOT NULL PRIMARY KEY,  -- e.g., 20260413
    calendar_date       DATE        NOT NULL UNIQUE,
    day_of_week         TINYINT     NOT NULL,              -- 1=Monday ... 7=Sunday
    day_name            VARCHAR(9)  NOT NULL,
    is_weekend          BIT         NOT NULL,
    retail_year         SMALLINT    NOT NULL,
    retail_week         TINYINT     NOT NULL,
    fiscal_year         SMALLINT    NOT NULL,
    fiscal_month        TINYINT     NOT NULL,
    is_holiday          BIT         NOT NULL,
    holiday_name        VARCHAR(64) NULL,
    current_row_indicator CHAR(1)   NOT NULL DEFAULT 'Y'    -- if SCD ever needed
);
```

**Watch Out!** Storing redundant strings (`'Monday'`) without integers for sorting forces lexical tricks or extra expressions in ORDER BY.

---

## Why Not Only a DATE Column on the Fact?

You could store `sale_date DATE` on `fact_store_sales` and derive attributes at query time. In practice, warehouses still add `date_key` to `dim_date`.

| Approach | Join cost | Consistency | Fiscal / holiday |
|----------|-----------|-------------|-------------------|
| Fact has only `DATE` | Fewer tables; may still need joins for fiscal | Logic duplicated in every report | Risk of divergent `CASE` logic |
| Fact has `date_key` → `dim_date` | One extra join; often tiny hash/lookup | Single source of truth | Centralized flags and names |

Join cost is usually low because `dim_date` is small and heavily cached; the optimizer often treats it as a dimension probe. Consistency wins when finance changes fiscal period boundaries once per year in one place.

**Interview Tip:** Contrast OLTP normalization mindset with dimensional modeling: the date table is intentional denormalization for analytic usability.

**Watch Out!** Skipping `dim_date` for “simplicity” often recreates a hidden, inconsistent mini-dimension inside every analyst’s SQL.

---

## Holiday Encoding: Verbose vs Compact

| Style | Representation | Pros | Cons |
|-------|----------------|------|------|
| Verbose | `is_thanksgiving`, `is_christmas_eve`, … | Very explicit filters | Wide table; sparse columns |
| Compact | `holiday_code` (`'NONE'`, `'THANKS'`, `'XMAS'`, …) + `is_holiday` | Narrower; extensible code list | Requires reference lookup |
| Hybrid | `is_holiday` BIT + `holiday_name` | Good for dashboards | Name changes need governance |

Retail example: Thanksgiving drives grocery spikes; a compact `holiday_code` feeds forecasting models while `is_holiday` supports simple “holiday vs non-holiday” labor rules.

**Watch Out!** Moving holidays (Easter) and regional differences (Provincial holidays in Canada) need either separate rows per region or a bridge table; a single global `dim_date` row per calendar day cannot capture every jurisdiction without design care.

---

## Star Schema Position (ASCII)

```
                    dim_store
                        |
                        |
dim_product ---- fact_store_sales ---- dim_date
                        |
                        |
                   dim_promotion
```

Facts hold `date_key`; `dim_date` does not point to facts. Date is a classic single-table dimension at the points of the star.

---

## SQL Join Example (Retail)

Daily sales by fiscal month with weekend split:

```sql
SELECT
    d.fiscal_year,
    d.fiscal_month,
    d.is_weekend,
    SUM(f.net_sales_amount) AS net_sales
FROM fact_store_sales AS f
JOIN dim_date AS d
  ON f.sale_date_key = d.date_key
WHERE d.calendar_date >= '2024-01-01'
  AND d.calendar_date <  '2025-01-01'
GROUP BY
    d.fiscal_year,
    d.fiscal_month,
    d.is_weekend
ORDER BY
    d.fiscal_year,
    d.fiscal_month,
    d.is_weekend;
```

Optional role-playing pattern (ship vs sale date) uses two foreign keys on the fact (`sale_date_key`, `ship_date_key`) referencing the same `dim_date`—implemented as one physical table and two aliases in SQL.

**Interview Tip:** Mention role-playing dates as a common extension without duplicating physical date data.

---

## Row Count and Storage Sanity Check

For daily grain over twenty years:

```
rows ≈ 20 years × 365.25 days/year ≈ 7,305 rows
```

Even with thirty descriptive columns, this is megabytes, not gigabytes—negligible compared to terabyte-scale sales facts.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Omitting fiscal columns from `dim_date` | Finance rebuilds logic in Excel; numbers disagree | Add fiscal attributes early; govern changes |
| Using local timezone dates inconsistently for e-commerce | Same UTC moment maps to different “days” | Standardize on business calendar + document timezone rules |
| Encoding holidays only as free text | Typos break joins to promotion tables | Use controlled codes + optional display name |
| Storing time-of-day in `dim_date` | Blurs grain; explodes row count wrongly | Split date and time dimensions |
| Duplicate date dimensions per subject area | Non-conformed keys block enterprise reporting | Publish one conformed `dim_date` |

---

## Key Takeaway

> Model time once at a clear grain, enrich it with fiscal and retail semantics, and join every fact through a conformed date key so analytics stays fast, comparable, and governed.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) Date dim = one row per grain (daily default ~7.3K / 20 yrs). |
| 2) Centralizes fiscal, weekend, holiday, week definitions.     |
| 3) Fact keeps date_key; avoids scattered CASE logic in facts.  |
| 4) Star position: facts point to dim_date, not reverse.         |
| 5) Holiday: prefer code + flag over dozens of sparse columns.   |
| 6) Role-play: sale_date_key vs ship_date_key same physical dim.  |
| 7) Join cost small; consistency and conformance are the win.     |
+------------------------------------------------------------------+
```
