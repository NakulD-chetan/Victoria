# What is a Data Mart

> *"Divide and conquer — but do not divide without a map."* — Common data architecture paraphrase

**Real-world analogy:** A **data warehouse** is the **national wholesaler** that consolidates goods from many suppliers. A **data mart** is the **specialty aisle** your neighborhood grocer sets up: **wine**, **organic produce**, or **holiday candy** — each aisle is still fed from the wholesaler, but **stocked for a specific shopper mission** with **faster navigation** and **clearer signage**.

---

## Core Idea (2 Lines)

A **data mart** is a **focused subset** of the enterprise warehouse (or data platform) tailored to a **department, region, or subject area**. It exists to deliver **faster, simpler, and more secure** access patterns for a defined audience without forcing every user to navigate the full enterprise model.

---

## Definition: Subset for a Department or Subject Area

| Term | Meaning |
|------|---------|
| **Subset** | Narrower tables, fewer joins, often pre-aggregated for common questions |
| **Subject area** | Sales, inventory, promotions, HR, finance |
| **Department** | Merchandising analytics vs store operations vs corporate finance |

**Interview Tip:** Say *"A mart is not a different universe — it is a **curated window** with aligned keys to the broader warehouse program."*

---

## Pipeline: DW to Marts to BI to Users

```
+----------------+     +----------------+     +----------------+
| DATA WAREHOUSE | --> | ETL / ELT to    | --> | DATA MART(S)   |
| enterprise     |     | marts           |     | dept-specific  |
| conformed core |     | (filters,       |     | fast, simple   |
|                |     |  aggregates)    |     |                |
+--------+-------+     +--------+--------+     +--------+-------+
         |                        |                     |
         v                        v                     v
  (optional direct)         (governance)          +----------------+
  power users only                               | BI / Metrics   |
                                                 +--------+-------+
                                                          |
                                                          v
                                                 +----------------+
                                                 | Business Users |
                                                 +----------------+
```

**Watch Out!** If marts bypass the warehouse without **conformed dimensions**, you recreate **siloed answers** at a smaller scale.

---

## Example Marts in a Retail Enterprise

| Mart | Audience | Typical contents |
|------|----------|------------------|
| **Sales mart** | Category managers, ecommerce leads | Orders, revenue, returns, channel performance |
| **Promotion mart** | Marketing | Lift, redemption, coupon families, vendor funding |
| **Finance mart** | FP&A, accounting | GL ties, recognition rules, store P&L rollups |
| **HR mart** | People ops | Headcount, turnover (heavily governed for privacy) |
| **Inventory mart** | Supply chain | Stock positions, fill rate, shrink proxies |

```sql
-- Mart-friendly shape: fewer joins for a common dashboard
CREATE TABLE mart_sales_daily AS
SELECT
  d.calendar_date,
  s.store_id,
  p.category,
  SUM(f.gross_sales)   AS gross_sales,
  SUM(f.net_sales)     AS net_sales,
  SUM(f.units_sold)    AS units_sold
FROM fact_sales f
JOIN dim_date d ON f.order_date_sk = d.date_sk
JOIN dim_store s ON f.store_sk = s.store_sk
JOIN dim_product p ON f.product_sk = p.product_sk
GROUP BY 1, 2, 3;
```

**Interview Tip:** Explain **why pre-aggregation** is optional: modern engines can scan big facts quickly — marts still help for **standardization**, **security**, and **simpler semantic models**.

---

## Characteristics: Subject-Specific, Summarized, Fast, Secure

| Characteristic | Benefit | Trade-off |
|----------------|---------|-----------|
| **Subject-specific** | Users see relevant nouns (promotion, vendor) | Requires maintenance per domain |
| **Summarized** | Dashboards snap open | Risk of **losing drill-down grain** if oversummarized |
| **Fast** | Smaller tables, targeted indexes/partitions | Extra storage and build time |
| **Secure** | Row/column policies scoped to HR vs public teams | More policy objects to manage |

**Watch Out!** Oversummarized marts become a **dead end** when users ask unexpected drill paths. Keep **grain** explicit in documentation.

---

## Disadvantages: Extra Build and Redundancy

| Disadvantage | Why teams still accept it |
|--------------|---------------------------|
| **Extra pipelines** | More jobs to test, monitor, and recover | Department agility is worth ops cost at scale |
| **Redundant storage** | Same facts exist in core + mart | Cheaper than **lost productivity** and **ad hoc extracts** |
| **Drift risk** | Mart diverges from enterprise definitions | Needs **shared conformed keys** and **metric ownership** |

---

## Supply Chain Analogy (Extended)

| Stage | Analogy | Data parallel |
|-------|---------|---------------|
| **Supplier** | Many factories | Source systems |
| **Wholesaler** | Consolidation + standards | Enterprise data warehouse |
| **Retailer** | Aisles optimized for shoppers | Data marts |
| **Customer** | Buys what they need quickly | Business users + BI |

```
Suppliers --> Wholesaler (conform) --> Retail aisles (marts) --> Customers (users)
```

**Interview Tip:** Use this analogy to explain **why duplication is intentional**: the wholesaler is not the shopping experience.

---

## Dependent vs Independent Data Marts

| Type | Definition | Pros | Cons |
|------|------------|------|------|
| **Dependent mart** | Built **from** the enterprise DW using conformed dimensions | Consistent KPIs, governed lineage | Depends on DW delivery cadence |
| **Independent mart** | Built **directly** from sources, sometimes without a central DW | Fast local delivery in a siloed org | **Inconsistent definitions**, duplicate cleansing |

```
DEPENDENT (preferred in enterprises)          INDEPENDENT (risk pattern)

Sources --> DW --> Mart --> BI                Sources --> Mart --> BI
               ^                                      ^
               |                                      |
         conformed keys                         often divergent keys
```

**Watch Out!** "Independent" is not evil for a **pilot**, but at enterprise scale it becomes **metric tribalism**.

---

## Data Warehouse vs Data Mart: Comparison Table

| Dimension | **Enterprise DW** | **Data Mart** |
|-----------|-------------------|---------------|
| **Scope** | Cross-functional enterprise model | Department / subject focus |
| **Model complexity** | Higher (many conformed entities) | Lower (narrower star or flat aggregates) |
| **Users** | Mixed: power users + curated consumers | Mostly business teams with guided questions |
| **Refresh** | Coordinated enterprise batch / stream | Often aligned to DW, sometimes more frequent slices |
| **Security model** | Broad RBAC + sensitive zones | Tighter scoping per department |

---

## Modeling Choices Inside a Mart

| Choice | When to use |
|--------|-------------|
| **Star schema at mart grain** | Users need flexible slicing by common dimensions |
| **Wide flat table** | Fixed dashboard set; extreme performance simplicity |
| **Semantic layer only** | Engine is fast enough; mart physicalization not needed |

```sql
-- Example: mart exposes role-friendly names
CREATE VIEW mart_promotion.vw_campaign_performance AS
SELECT
  campaign_name,
  campaign_start_date,
  SUM(attributed_net_sales) AS attributed_net_sales,
  SUM(attributed_orders)    AS attributed_orders
FROM dw_curated.fact_promo_attribution
GROUP BY 1, 2;
```

**Interview Tip:** Mention **role-based views** as a lightweight mart pattern when physical tables are unnecessary.

---

## Governance: Making Marts Trustworthy

| Control | Purpose |
|---------|---------|
| **Conformed `date_sk`, `product_sk`, `store_sk`** | Prevents mart-specific reinvented keys |
| **Metric definitions pinned** | *Net sales* is identical in DW and mart |
| **Lineage tags** | Know which DW version built a mart snapshot |

**Watch Out!** Local Excel "marts" on laptops are the shadow IT cousin — they **bypass** audit and reproducibility.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Creating marts without conformed dimensions | **Two sales numbers** for the same quarter | Enforce **enterprise conformed keys** in dependent marts |
| Confusing a mart with an ODS | ODS integrates ops near-real-time; mart serves **analytics** | Name layers honestly; document SLAs |
| Over-aggregating until grain is lost | Cannot investigate outliers | Keep **detail marts** where needed; document grain |
| Independent marts everywhere | Enterprise reporting becomes political | Migrate to **hub-and-spoke** with DW as spine |
| Skipping security because "it's internal" | HR/PII leakage | Apply **least privilege** in mart databases |

---

## Key Takeaway

> A **data mart** is a **purpose-built analytical slice** — often **dependent** on a warehouse for **conformed truth** — that trades some **redundancy and build effort** for **speed, simplicity, and tighter security** for a domain audience. Treat marts as **distribution aisles** fed by a wholesaler, not as **shadow warehouses** that reinvent definitions.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Mart = focused subset for dept/subject; not a second universe    |
| Pipeline: DW -> ETL/ELT -> mart(s) -> BI -> users               |
| Examples: sales, promotion, finance, HR, inventory marts         |
| Traits: subject-specific, summarized, fast, secure               |
| Cons: extra pipelines + redundancy; mitigate with conformance     |
| Dependent vs independent: governance vs speed-to-silo trade        |
| Supply chain analogy: wholesaler (DW) -> aisles (marts)         |
+------------------------------------------------------------------+
```
