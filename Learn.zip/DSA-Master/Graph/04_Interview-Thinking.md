# Graph — Interview Thinking

> **Permanent Recall:** Identify graph implicitly: nodes = ?, edges = ?. Communicate: "This is a graph where... I'll use BFS/DFS/Dijkstra because...". BFS = shortest unweighted; DFS = path/cycle/components; Dijkstra = weighted shortest.

---

## How to Identify Graph Problems (Even Hidden Ones)

### Explicit Graphs
- "Given adjacency list/matrix..."
- "N nodes, M edges..."
- "Find shortest path between A and B"

### Implicit / Hidden Graphs
- **Matrix/grid** → cells = nodes, adjacent cells = edges (4 or 8 dirs)
- **Prerequisites** → courses/tasks = nodes, "A before B" = edge A→B
- **Word ladder** → words = nodes, 1-char diff = edge
- **Social network** → people = nodes, friendship = edge
- **State machine** → states = nodes, transitions = edges
- **Game board** → positions = nodes, valid moves = edges

### The "Implicit Graph" Sentence
> "This is implicitly a graph where **nodes are** [X] and **edges are** [Y]. I'll use [algorithm] because [reason]."

| Problem Type | Nodes | Edges |
|--------------|-------|-------|
| Word Ladder | Words | 1-char difference |
| Rotten Oranges | Cell (r,c) | Adjacent cells |
| Course Schedule | Courses | Prerequisite A→B |
| Number of Islands | Cells | Adjacent land |
| Clone Graph | Graph nodes | Same neighbors |
| Surrounded Regions | Cells | Adjacent |

---

## BFS vs DFS vs Dijkstra Decision

```
                    "What do we need?"
                           |
        +-----------------+------------------+
        |                 |                  |
   "Shortest path"   "Ordering/Deps"   "Reachability/
   (unweighted)"     (prerequisites)    Components/Cycle"
        |                 |                  |
       BFS              Topo              DFS or BFS
        |
   "Shortest path
   (weighted, non-neg)"
        |
     Dijkstra
```

### Decision Table

| Goal | Unweighted | Weighted (non-neg) | Weighted (negative) |
|------|------------|--------------------|---------------------|
| Shortest path | BFS | Dijkstra | Bellman-Ford |
| Level/distance | BFS | — | — |
| Topological order | — | — | Topo sort |
| Cycle detection | DFS | DFS | DFS |
| Connected components | BFS or DFS | BFS or DFS | — |
| Multi-source spread | Multi-source BFS | Multi-source Dijkstra | — |

---

## Communication Strategy

### 1. Restate + Model (30 sec)
- "So we have [X]. I'll model this as a graph: nodes are [Y], edges are [Z]."
- "It's [directed/undirected], [weighted/unweighted]."

### 2. Algorithm Choice (15 sec)
- "For shortest path in unweighted graph, BFS is optimal — first reach = shortest."
- "For dependencies, topological sort on the DAG."
- "For weighted shortest path with no negative edges, Dijkstra."

### 3. Complexity (10 sec)
- "Time O(V+E) for BFS/DFS, O((V+E) log V) for Dijkstra."
- "Space O(V) for visited and queue."

### 4. Edge Cases (5 sec)
- "I'll handle disconnected graph, single node, empty input."

---

## Interview Script Template

```
1. "Let me clarify — [repeat problem in graph terms]"
2. "I'll model: nodes = [X], edges = [Y]. [Directed/undirected]."
3. "We need [shortest path / ordering / components / cycle]. 
    I'll use [BFS / DFS / Dijkstra / Topo] because [reason]."
4. "I'll build adjacency list, then run [algorithm]. 
    Time O(...), space O(...)."
5. "Edge cases: disconnected, single node, empty."
6. [Code]
```

---

## Red Flags (Don't Say)

| Wrong | Right |
|-------|-------|
| "I'll use DFS for shortest path" | BFS for unweighted shortest |
| "Dijkstra works with negative weights" | Bellman-Ford for negative |
| "Topo sort on cyclic graph" | Detect cycle first; topo only on DAG |
| "Adjacency matrix for sparse graph" | Adjacency list for sparse |
| "BFS for topological sort" | Kahn's BFS is valid; DFS postorder also |

---

## Matrix-as-Graph Recognition

```
Grid:     [1][1][0]      Graph:    (0,0)—(0,1)  (0,2)
          [1][1][0]                |     |       |
          [0][0][1]               (1,0)—(1,1)  (1,2)
                                   |     |
                                  (2,0) (2,1)  (2,2)

Nodes = (r, c)
Edges = up/down/left/right (or 8 dirs)
```

- **4 directions:** `[(0,1),(1,0),(0,-1),(-1,0)]`
- **8 directions:** add diagonals
- **Node id:** `r * cols + c` for 1D indexing

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Interview Thinking
WHEN TO USE:       Any graph problem — before coding
CORE IDEA:         Identify nodes + edges; pick BFS/DFS/Dijkstra/Topo by goal
TIME:              N/A (thinking phase)
SPACE:             N/A
INTERVIEW SENTENCE: "This is a graph where nodes are X, edges are Y. 
                     I'll use BFS for shortest path because unweighted."
```

---

## 30-SECOND REVISION BOX

```
Hidden graph: matrix→cells, prereqs→tasks, word ladder→words
Sentence: "Nodes are X, edges are Y"
Shortest unweighted → BFS
Shortest weighted → Dijkstra (no neg)
Dependencies → Topo
Components/cycle → DFS
Communicate: model → algorithm → complexity → edge cases
```
