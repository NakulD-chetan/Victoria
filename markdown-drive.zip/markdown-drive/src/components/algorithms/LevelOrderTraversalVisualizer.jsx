import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function sampleTree() {
  const nodes = [
    { id: 0, value: 50, left: 1, right: 2 },
    { id: 1, value: 30, left: 3, right: 4 },
    { id: 2, value: 70, left: 5, right: 6 },
    { id: 3, value: 20, left: 7, right: 8 },
    { id: 4, value: 40, left: 9, right: null },
    { id: 5, value: 60, left: null, right: 10 },
    { id: 6, value: 80, left: 11, right: 12 },
    { id: 7, value: 15, left: null, right: null },
    { id: 8, value: 25, left: null, right: null },
    { id: 9, value: 35, left: null, right: null },
    { id: 10, value: 65, left: null, right: null },
    { id: 11, value: 75, left: null, right: null },
    { id: 12, value: 90, left: null, right: null },
  ];
  const edges = [];
  nodes.forEach((n) => {
    if (n.left != null) edges.push([n.id, n.left]);
    if (n.right != null) edges.push([n.id, n.right]);
  });
  return { nodes, edges };
}

function colors(front, q, done) {
  const nodeColors = {};
  q.forEach((id) => { nodeColors[id] = 'visited'; });
  done.forEach((id) => { nodeColors[id] = 'result'; });
  if (front != null) nodeColors[front] = 'current';
  return nodeColors;
}

function generateSteps(tree) {
  const { nodes } = tree;
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const steps = [];
  const q = [0];
  const result = [];
  const done = new Set();

  steps.push({
    caption: 'Initialize queue with root',
    stack: [],
    queue: q.map((id) => byId[id].value),
    result: [],
    nodeColors: colors(0, q, done),
  });

  while (q.length) {
    const n = q.shift();
    result.push(byId[n].value);
    done.add(n);
    steps.push({
      caption: `Dequeue ${byId[n].value}, visit → level-order output`,
      stack: [],
      queue: q.map((id) => byId[id].value),
      result: [...result],
      nodeColors: colors(null, q, done),
      visitAnim: n,
    });
    const l = byId[n].left;
    const r = byId[n].right;
    if (l != null) {
      q.push(l);
      steps.push({
        caption: `Enqueue left child ${byId[l].value}`,
        stack: [],
        queue: q.map((id) => byId[id].value),
        result: [...result],
        nodeColors: colors(l, q, done),
      });
    }
    if (r != null) {
      q.push(r);
      steps.push({
        caption: `Enqueue right child ${byId[r].value}`,
        stack: [],
        queue: q.map((id) => byId[id].value),
        result: [...result],
        nodeColors: colors(r, q, done),
      });
    }
  }
  steps.push({
    caption: 'Level-order (BFS) complete',
    stack: [],
    queue: [],
    result: [...result],
    nodeColors: colors(null, [], done),
  });
  return steps;
}

export default function LevelOrderTraversalVisualizer({ config }) {
  const treeRef = { current: sampleTree() };

  const onInit = useCallback((canvasRef) => {
    treeRef.current = sampleTree();
    const steps = generateSteps(treeRef.current);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Breadth-first traversal with queue' });
    canvasRef.current?.setState({
      ...treeRef.current,
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Ready',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    if (step.visitAnim != null) canvasRef.current?.addAnim('visit', { nodeId: step.visitAnim }, 300);
    canvasRef.current?.setState({
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
