# Tree — Common Mistakes

> These are the mistakes almost everyone makes. Read once, avoid forever.

---

## Mistake 1: Not Handling NULL / None

**Wrong:**
```python
def height(node):
    return 1 + max(height(node.left), height(node.right))  # CRASHES on None!
```

**Right:**
```python
def height(node):
    if node is None:
        return -1   # base case FIRST, always
    return 1 + max(height(node.left), height(node.right))
```

> **Rule:** The FIRST line of every tree function must check `if node is None`.

---

## Mistake 2: Wrong Height Base Case (-1 vs 0)

Both are used — but they mean different things:

| Base case | Meaning | Height of leaf | Height of single-node tree |
|-----------|---------|----------------|---------------------------|
| `return -1` for null | Height = number of edges | 0 | 0 |
| `return 0` for null | Height = number of nodes | 1 | 1 |

**Be consistent.** Pick one and stick with it throughout your function.

> **Lecture uses:** `return -1` for null (edge-counting convention)

---

## Mistake 3: Confusing BST with Binary Tree

- Binary Tree: NO ordering constraint. You must visit EVERY node to find something.
- BST: Has ordering. You can **skip subtrees** based on comparison.

**Wrong (treating BST like Binary Tree):**
```python
def search_bst(node, key):
    if node is None: return False
    if node.data == key: return True
    return search_bst(node.left, key) or search_bst(node.right, key)  # visits both!
```

**Right:**
```python
def search_bst(node, key):
    if node is None: return False
    if node.data == key: return True
    if key < node.data: return search_bst(node.left, key)   # only go left
    return search_bst(node.right, key)                       # only go right
```

---

## Mistake 4: Checking BST Validity with Only Local Comparison

**Wrong (most common BST mistake):**
```python
def is_bst_wrong(node):
    if node is None: return True
    if node.left and node.left.data >= node.data: return False   # WRONG!
    if node.right and node.right.data <= node.data: return False  # WRONG!
    return is_bst_wrong(node.left) and is_bst_wrong(node.right)
```

**Why wrong?** This tree passes the wrong check but is NOT a valid BST:
```
    10
   /  \
  5    15
      /
     6      ← 6 < 10, should be in LEFT subtree of 10!
```

**Right (pass min/max bounds):**
```python
def is_bst(node, min_val=float('-inf'), max_val=float('inf')):
    if node is None: return True
    if not (min_val < node.data < max_val): return False
    return (is_bst(node.left,  min_val, node.data) and
            is_bst(node.right, node.data, max_val))
```

---

## Mistake 5: Using Global/Mutable Variable Wrong for Diameter

**Wrong:** Forgetting to track max across all nodes:
```python
def diameter_wrong(node):
    if node is None: return 0
    left_h  = height(node.left)
    right_h = height(node.right)
    return left_h + right_h + 2   # WRONG — only computes for root!
```

**Right:** Track diameter as a running maximum:
```python
def diameter(root):
    max_d = [0]
    def helper(node):
        if node is None: return -1
        left_h  = helper(node.left)
        right_h = helper(node.right)
        max_d[0] = max(max_d[0], left_h + right_h + 2)  # update global max
        return 1 + max(left_h, right_h)
    helper(root)
    return max_d[0]
```

---

## Mistake 6: Pre-order + Post-order Cannot Reconstruct a Unique Tree

If someone gives you Pre-order AND Post-order, you **cannot always** reconstruct a unique binary tree.

You need **In-order** as the anchor.

**Exception:** If you know the tree is a **Full Binary Tree** (every node has 0 or 2 children), then Pre+Post is sufficient.

---

## Mistake 7: Confusing Level-Order Index Formula

For **0-indexed** array representation of a heap/CBT:

```
Node at index i:
  Left child  = 2*i + 1   (NOT 2*i)
  Right child = 2*i + 2   (NOT 2*i + 1)
  Parent      = (i-1) // 2
```

For **1-indexed** (common in textbooks):
```
Node at index i:
  Left child  = 2*i
  Right child = 2*i + 1
  Parent      = i // 2
```

> **Lecture uses 0-indexed.** Python lists are 0-indexed. Stick with one.

---

## Mistake 8: Forgetting to Update Height in AVL Tree

When you perform a rotation in AVL, you MUST update the heights of affected nodes **bottom-up**.

```python
def right_rotate(z):
    y = z.left
    T3 = y.right
    y.right = z
    z.left = T3
    # UPDATE HEIGHTS — z first (it's now lower), then y
    z.height = 1 + max(get_height(z.left), get_height(z.right))
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    return y
```

---

## Mistake 9: Off-by-One in Height Comparison for Balanced Check

```python
# Wrong:
if abs(left_h - right_h) > 2: not_balanced   # allows difference of 2!

# Right:
if abs(left_h - right_h) > 1: not_balanced   # AVL allows max difference of 1
```

---

## Mistake 10: Heap — Inserting vs Heapifying

- **heapq.heappush(heap, val)** — insert one element → O(log n)
- **heapq.heapify(arr)** — convert entire array → O(n) (do NOT push element by element if you have a full array)

```python
# Slow — O(n log n):
heap = []
for val in arr:
    heapq.heappush(heap, val)

# Fast — O(n):
heap = arr[:]
heapq.heapify(heap)
```
