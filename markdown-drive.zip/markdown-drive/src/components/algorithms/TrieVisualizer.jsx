import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

class TrieNode {
  constructor(id, ch = '∅') {
    this.id = id;
    this.ch = ch;
    this.children = new Map();
    this.end = false;
  }
}

function trieToGraph(root) {
  const nodes = [];
  const edges = [];
  const edgeLabels = [];
  function walk(n) {
    nodes.push({
      id: n.id,
      value: n.ch,
      label: n.ch,
      children: [...n.children.values()].map((c) => c.id),
    });
    n.children.forEach((child, ch) => {
      edges.push([n.id, child.id]);
      edgeLabels.push({ from: n.id, to: child.id, label: ch });
      walk(child);
    });
  }
  walk(root);
  return { nodes, edges, edgeLabels };
}

function generateSteps(words) {
  const steps = [];
  let nextId = 0;
  const root = new TrieNode(nextId++, '∅');

  const snap = (caption, focus, colors = {}) => {
    const g = trieToGraph(root);
    steps.push({
      caption,
      nodes: g.nodes,
      edges: g.edges,
      edgeLabels: g.edgeLabels,
      nodeColors: { ...colors, ...(focus != null ? { [focus]: 'current' } : {}) },
      stack: [],
      queue: [],
      result: [...words],
    });
  };

  words.forEach((w) => {
    snap(`Insert word "${w}"`, root.id, {});
    let cur = root;
    for (let i = 0; i < w.length; i += 1) {
      const ch = w[i];
      if (!cur.children.has(ch)) {
        cur.children.set(ch, new TrieNode(nextId++, ch));
        snap(`Create edge '${ch}'`, cur.children.get(ch).id, { [cur.id]: 'visited' });
      }
      cur = cur.children.get(ch);
      snap(`Follow '${ch}'`, cur.id, { [cur.id]: 'visited' });
    }
    cur.end = true;
    snap(`Mark terminal for "${w}"`, cur.id, { [cur.id]: 'result' });
  });

  const search = 'car';
  snap(`Search "${search}"`, root.id, {});
  let c = root;
  let found = true;
  for (let i = 0; i < search.length; i += 1) {
    const ch = search[i];
    if (!c.children.has(ch)) {
      found = false;
      snap(`Missing edge '${ch}' — not found`, c.id, { [c.id]: 'red' });
      break;
    }
    c = c.children.get(ch);
    snap(`Match '${ch}'`, c.id, { [c.id]: 'visited' });
  }
  if (found && c.end) snap('Search ends at terminal — found', c.id, { [c.id]: 'result' });

  return steps;
}

export default function TrieVisualizer({ config }) {
  const words = ['cat', 'car', 'card', 'camera', 'camp'];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(words);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Trie insert + search' });
    canvasRef.current?.setState({
      nodes: [],
      edges: [],
      edgeLabels: [],
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Trie',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      edgeLabels: step.edgeLabels || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
