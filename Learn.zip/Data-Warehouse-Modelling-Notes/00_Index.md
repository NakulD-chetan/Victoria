# Data Warehouse Modelling — Index

> **19 topics. Master these and you can crack any data engineering interview or build production-grade warehouse pipelines. Each topic has a Theory file (how it works) and a Practice file (drill exercises).**

---

## Sample Context (Used Across All Notes)

```sql
-- Common retail scenario used in examples throughout the notes
-- A nationwide grocery retailer with:
--   1,000 stores across 4 zones (North, South, East, West)
--   10,000 active products (from a 50,000-row master catalog)
--   Millions of daily POS transactions

-- Fact table (simplified)
SELECT date_key, store_key, product_key, promotion_key,
       sales_qty, unit_price, discount_amt, sales_amount
FROM retail_sales_fact;

-- Dimension tables
-- dim_date, dim_store, dim_product, dim_promotion
```

---

## Table of Contents

| #  | Topic                                  | Real-World Analogy                           | Theory | Practice |
|----|----------------------------------------|----------------------------------------------|--------|----------|
| 01 | What is a Data Warehouse               | Big organized library vs scattered notebooks | [Theory](01_What-is-Data-Warehouse/01_Theory.md) | [Practice](01_What-is-Data-Warehouse/02_Practice.md) |
| 02 | Why Do We Need a Data Warehouse        | Kitchen (ops) vs Dining Table (analytics)    | [Theory](02_Why-Data-Warehouse/01_Theory.md) | [Practice](02_Why-Data-Warehouse/02_Practice.md) |
| 03 | Data Warehouse vs Data Lake            | Filing cabinet vs storage locker             | [Theory](03_DW-vs-Data-Lake/01_Theory.md) | [Practice](03_DW-vs-Data-Lake/02_Practice.md) |
| 04 | What is a Data Mart                    | Supplier -> Wholesaler -> Retailer           | [Theory](04_What-is-Data-Mart/01_Theory.md) | [Practice](04_What-is-Data-Mart/02_Practice.md) |
| 05 | Data Warehouse Internals               | Backstage (staging) vs Front stage (BI)      | [Theory](05_DW-Internals/01_Theory.md) | [Practice](05_DW-Internals/02_Practice.md) |
| 06 | Data Warehouse Transformations         | Raw ingredients -> Cooked meal               | [Theory](06_DW-Transformations/01_Theory.md) | [Practice](06_DW-Transformations/02_Practice.md) |
| 07 | Incremental Loads                      | Daily newspaper vs full encyclopedia         | [Theory](07_Incremental-Loads/01_Theory.md) | [Practice](07_Incremental-Loads/02_Practice.md) |
| 08 | Fact Table and Dimension Table         | Receipt numbers + context labels             | [Theory](08_Fact-and-Dimension-Table/01_Theory.md) | [Practice](08_Fact-and-Dimension-Table/02_Practice.md) |
| 09 | Dimensional Modelling Fundamentals     | Architect's blueprint before construction    | [Theory](09_Dimensional-Modelling-Fundamentals/01_Theory.md) | [Practice](09_Dimensional-Modelling-Fundamentals/02_Practice.md) |
| 10 | Types of Facts                         | Cash (additive) vs Temperature (non-additive)| [Theory](10_Type-of-Facts/01_Theory.md) | [Practice](10_Type-of-Facts/02_Practice.md) |
| 11 | Types of Fact Tables                   | Diary (txn) vs Photo album (snapshot)        | [Theory](11_Types-of-Fact-Table/01_Theory.md) | [Practice](11_Types-of-Fact-Table/02_Practice.md) |
| 12 | Factless Fact Table                    | Attendance register (no numbers, just marks) | [Theory](12_Factless-Fact-Table/01_Theory.md) | [Practice](12_Factless-Fact-Table/02_Practice.md) |
| 13 | Date Dimension Table                   | Pre-printed calendar on the wall             | [Theory](13_Date-Dimension-Table/01_Theory.md) | [Practice](13_Date-Dimension-Table/02_Practice.md) |
| 14 | Product Dimension and Snowflake        | Product catalog with sub-catalogs            | [Theory](14_Product-Dimension-and-Snowflake/01_Theory.md) | [Practice](14_Product-Dimension-and-Snowflake/02_Practice.md) |
| 15 | Types of Dimensions                    | Many roles of one actor on stage             | [Theory](15_Type-of-Dimensions/01_Theory.md) | [Practice](15_Type-of-Dimensions/02_Practice.md) |
| 16 | Star and Snowflake Schema              | Flat map vs detailed atlas                   | [Theory](16_Star-and-Snowflake-Schema/01_Theory.md) | [Practice](16_Star-and-Snowflake-Schema/02_Practice.md) |
| 17 | Primary Key and Foreign Key            | ID card (PK) and visitor pass reference (FK) | [Theory](17_Primary-and-Foreign-Key/01_Theory.md) | [Practice](17_Primary-and-Foreign-Key/02_Practice.md) |
| 18 | Surrogate Key                          | Library barcode vs book title                | [Theory](18_Surrogate-Key/01_Theory.md) | [Practice](18_Surrogate-Key/02_Practice.md) |
| 19 | Slowly Changing Dimension              | Passport renewal with old + new address      | [Theory](19_Slowly-Changing-Dimension/01_Theory.md) | [Practice](19_Slowly-Changing-Dimension/02_Practice.md) |

---

## Real-World Analogy Map

```
Real-World Concept               DW Topic                             Why Similar
─────────────────────────────    ───────────────────────────────      ─────────────────────────────────────────
Organized library                What is Data Warehouse               Central, structured, query-optimized store
Kitchen vs dining table          Why Data Warehouse                   Operational work vs analytical consumption
Filing cabinet vs storage locker DW vs Data Lake                      Structured+curated vs raw+everything
Wholesaler -> Retailer           Data Mart                            Broad warehouse -> focused departmental slice
Backstage vs front stage         DW Internals                         Staging (technical) vs user layer (business)
Raw ingredients -> cooked meal   Transformations                      Cleanse, conform, shape before serving
Daily newspaper delivery         Incremental Loads                    Only new changes, not the entire archive
Receipt = numbers + labels       Fact + Dimension Tables              Measures need context to make sense
Architect's blueprint            Dimensional Modelling                Plan grain, dims, facts before building
Cash vs temperature              Types of Facts                       Additive (summable) vs non-additive
Diary vs photo album             Types of Fact Tables                 Events vs snapshots vs lifecycle tracking
Attendance register              Factless Fact Table                  Record presence/absence, no numeric value
Wall calendar                    Date Dimension                       Pre-computed, universal time context
Product catalog                  Product Dim & Snowflake              Hierarchy normalization trade-offs
Actor playing many roles         Types of Dimensions                  Conformed, role-playing, junk, degenerate
Flat map vs atlas                Star vs Snowflake Schema             Simple-fast vs normalized-clean
ID card + visitor pass           PK and FK                            Identity + referential relationships
Library barcode                  Surrogate Key                        System-generated, stable, meaningless ID
Passport renewal                 SCD                                  Track attribute changes over time
```

---

## Recommended Study Order

### Beginner (Start Here — Build Foundation)

```
01  What is Data Warehouse        <- Definition, OLTP vs OLAP, why it exists
02  Why Data Warehouse            <- Problems without DW, 5 key benefits
03  DW vs Data Lake               <- ETL vs ELT, schema-on-write vs read, lakehouse
04  What is Data Mart             <- Departmental subsets, dependent vs independent
05  DW Internals                  <- Staging vs user access layer, persistent vs non-persistent
```

### Intermediate (Core Modelling — The Interview Zone)

```
06  Transformations               <- Cleansing, conforming, deduplication
07  Incremental Loads             <- Full vs incremental, CDC, watermarks
08  Fact and Dimension Table      <- Core building blocks of dimensional modelling
09  Dimensional Modelling         <- Four-step method, grain is king
10  Types of Facts                <- Additive / semi-additive / non-additive
11  Types of Fact Tables          <- Transaction / periodic / accumulating snapshot
12  Factless Fact Table           <- Events and coverage without measures
```

### Advanced (Schema Design, Keys, and SCD)

```
13  Date Dimension                <- Universal dimension, grain, fiscal/holiday
14  Product Dim & Snowflake       <- Hierarchy, normalization, roll up/drill down
15  Types of Dimensions           <- Conformed, role-playing, junk, degenerate
16  Star vs Snowflake Schema      <- Design trade-offs, when to use each
17  Primary and Foreign Key       <- DW key patterns, referential integrity
18  Surrogate Key                 <- Why integer keys beat business keys on facts
19  Slowly Changing Dimension     <- SCD Types 0-3, hybrids, history tracking
```

---

## Topic Dependency Graph

```
                    ┌───────────────────┐
                    │  01 What is DW    │
                    └────────┬──────────┘
                             │
                    ┌────────▼──────────┐
                    │  02 Why DW        │
                    └────────┬──────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              ▼              ▼              ▼
     ┌────────────┐  ┌─────────────┐  ┌──────────┐
     │ 03 DW vs   │  │ 04 Data     │  │ 05 DW    │
     │ Data Lake  │  │ Mart        │  │ Internals│
     └──────┬─────┘  └──────┬──────┘  └─────┬────┘
            │               │               │
            └───────────────┼───────────────┘
                            │
              ┌─────────────┼─────────────┐
              │             │             │
              ▼             ▼             ▼
     ┌────────────┐  ┌───────────┐  ┌───────────┐
     │ 06 Transf. │  │ 07 Incr.  │  │ 08 Fact & │
     │            │  │ Loads     │  │ Dimension │
     └────────────┘  └───────────┘  └─────┬─────┘
                                          │
                               ┌──────────┼──────────┐
                               │          │          │
                               ▼          ▼          ▼
                          ┌────────┐ ┌────────┐ ┌────────┐
                          │09 Dim  │ │10 Fact │ │11 Fact │
                          │Modellng│ │Types   │ │Table   │
                          └────────┘ └────────┘ │Types   │
                                                └───┬────┘
                                                    │
                                               ┌────▼────┐
                                               │12 Fact- │
                                               │less     │
                                               └─────────┘

  Schema & Dimensions (after 08-12):
  ┌──────────┐  ┌──────────────┐  ┌────────────────┐  ┌────────────┐
  │ 13 Date  │  │ 14 Product & │  │ 15 Dimension   │  │ 16 Star vs │
  │ Dim      │  │ Snowflake    │  │ Types          │  │ Snowflake  │
  └──────────┘  └──────────────┘  └────────────────┘  └────────────┘

  Capstone (learn after all others):
  ┌──────────────┐  ┌──────────────────┐  ┌───────────────┐
  │ 17 PK & FK   │  │ 18 Surrogate Key │  │ 19 SCD        │
  └──────────────┘  └──────────────────┘  └───────────────┘
```

---

## Quick Concept Glossary

| Term                | One-Liner                                                              |
|---------------------|------------------------------------------------------------------------|
| OLTP                | Online Transaction Processing — optimized for writes (INSERT/UPDATE)   |
| OLAP                | Online Analytical Processing — optimized for reads (SELECT, analytics) |
| ETL                 | Extract, Transform, Load — transform before loading into DW            |
| ELT                 | Extract, Load, Transform — load raw first, transform later             |
| Schema-on-Write     | Define structure before loading data (DW pattern)                      |
| Schema-on-Read      | Define structure when reading data (Data Lake pattern)                 |
| Fact Table          | Stores numeric measurements at a defined grain                         |
| Dimension Table     | Stores descriptive context (who, what, when, where, why)               |
| Grain               | The level of detail one fact row represents                            |
| Star Schema         | Fact table surrounded by denormalized dimensions                       |
| Snowflake Schema    | Star with normalized (split) dimension tables                          |
| Surrogate Key       | System-generated integer PK with no business meaning                   |
| Natural Key         | Business-meaningful identifier from source systems                     |
| SCD                 | Slowly Changing Dimension — how to handle attribute changes over time  |
| Conformed Dimension | One shared dimension table used across multiple facts                  |
| Junk Dimension      | Combined low-cardinality flags in one small dimension                  |
| Degenerate Dimension| Dimension value stored directly on the fact (e.g., order_id)           |
| Data Mart           | Departmental subset of the data warehouse                              |
| CDC                 | Change Data Capture — detect source changes for incremental loads      |
| Referential Integrity | Every FK on fact resolves to a valid dimension PK                    |

---

## Recurring Themes Across Lessons

- **OLTP vs OLAP** — operational writes vs analytical reads (appears in Lec 1, 2, 5, 17)
- **ETL vs ELT** — transform-first vs load-first (appears in Lec 1, 3, 5, 6)
- **Schema-on-Write vs Schema-on-Read** — DW vs Lake philosophy (appears in Lec 3)
- **Grain** — the single most important modelling decision (appears in Lec 9, 10, 11, 13)
- **Star vs Snowflake** — denormalized vs normalized dimensions (appears in Lec 14, 16)
- **Surrogate Keys** — foundation for SCD and efficient joins (appears in Lec 17, 18, 19)

---

## Source

- **Playlist:** [Data Warehouse Modelling by MANISH KUMAR](https://www.youtube.com/playlist?list=PLTsNSGeIpGnGP8A74Ie1PgqHhewsqD3fv)
- **Notes:** All 19 lectures with full theory and interview-ready practice exercises.

---

## Key Takeaway

> Data warehouse modelling is a discipline where **grain is law** and **context gives meaning to numbers**. If you master these 19 topics — from foundations to SCD — you can handle any interview question, design any dimensional model, and build pipelines that your team actually trusts. The patterns here map to real-world analogies: think of facts as receipt numbers, dimensions as context labels, and surrogate keys as library barcodes. Learn the concept, write the SQL, understand the "why."
