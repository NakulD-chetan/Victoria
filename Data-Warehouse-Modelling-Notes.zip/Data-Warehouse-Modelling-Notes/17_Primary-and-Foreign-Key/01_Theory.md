# Primary Key and Foreign Key in Data Warehouse

> "Keys are the contracts between facts and dimensions—break the contract and every dashboard becomes fiction."

**Real-world analogy:** Warehouse keys are like the chain-wide SKU and store numbering standards used for replenishment: if two different stores use the same back-room sticker for different products, the automated ordering system ships the wrong stock; surrogate keys are the corporate barcode that stays unique even when suppliers rename items.

---

## Core Idea (2 Lines)

Primary and foreign keys in a data warehouse make joins deterministic, integrate heterogeneous retail sources, and anchor slowly changing history so facts always point at the correct dimension version. Surrogate primary keys on dimensions paired with foreign keys on facts are the dominant pattern for stable analytics at scale.

---

## Why Keys Matter in the Data Warehouse

| Need | Keying role | Retail example |
|------|-------------|----------------|
| Stable joins | Surrogate PK on `dim_store` | Legacy mall code changes; key stays |
| Integration | Conformed `product_key` | POS and e-commerce facts combine |
| History tracking | Type 2 rows differentiated by surrogate | Private label repackaging |
| ETL idempotence | Natural key + hash for staging | Reload Tuesday sales safely |
| Lineage | Business keys preserved as attributes | Traceability to ERP SKU |

**Interview Tip:** Contrast operational uniqueness (transaction id) with analytic surrogate stability across source changes.

**Watch Out!** Using source system row IDs that recycle after archival replays orphan facts.

---

## Primary Key on Dimensions

Dimensions almost always use a **surrogate primary key** (integer or bigint) with uniqueness enforced.

```sql
CREATE TABLE dim_store (
    store_key       INT         NOT NULL PRIMARY KEY,
    store_id        VARCHAR(10) NOT NULL,  -- natural / business key
    store_name      VARCHAR(80) NOT NULL,
    region          VARCHAR(40) NOT NULL
);
```

| PK style | When used in DW |
|----------|-----------------|
| Surrogate | Default for `dim_*` |
| Composite | Rare; sometimes bridge tables |
| Natural | Discouraged as PK for SCD dimensions |

**Watch Out!** Composite PKs on wide Type 2 dimensions complicate fact FKs and BI tools.

---

## Natural / Business Key vs Surrogate Key

| Concept | Definition | Retail examples |
|---------|------------|-----------------|
| Natural / business key | Meaningful identifier in source | `store_id` = '1842', UPC, loyalty card number |
| Surrogate key | Warehouse-generated opaque integer | `store_key` = 910017 |

| Dimension | Typical business key | Typical surrogate |
|-----------|---------------------|-------------------|
| Store | Retail banner store code | `store_key` |
| Product | UPC / style-color-size code | `product_key` |
| Customer | Loyalty id (careful with privacy) | `customer_key` |

**Interview Tip:** Business keys remain as **columns** for lookup and reconciliation even when they are not the PK.

**Watch Out!** Using UPC alone can collide across private-label packs with reused codes; integration rules may require composite business keys.

---

## Foreign Key Pattern: Fact to Dimension

Facts hold **foreign keys** referencing dimension PKs, plus degenerate identifiers and measures.

```
fact_store_sales.store_key   --> dim_store.store_key
fact_store_sales.product_key --> dim_product.product_key
fact_store_sales.sale_date_key -> dim_date.date_key
```

```sql
CREATE TABLE fact_store_sales (
    sale_line_key      BIGINT NOT NULL PRIMARY KEY,
    store_key          INT    NOT NULL REFERENCES dim_store(store_key),
    product_key        BIGINT NOT NULL REFERENCES dim_product(product_key),
    sale_date_key      INT    NOT NULL REFERENCES dim_date(date_key),
    quantity           INT    NOT NULL,
    net_sales_amount   DECIMAL(12,2) NOT NULL
);
```

Not every platform enforces `REFERENCES` in the published mart; the logical pattern still holds.

**Watch Out!** Nullable FKs to “optional” dimensions invite double-counting when analysts use outer joins carelessly.

---

## Star vs Snowflake Key Paths

| Schema | Key path from fact |
|--------|-------------------|
| Star | Fact → `dim_product` (contains category columns) |
| Snowflake | Fact → `dim_product.subcategory_key` → `dim_subcategory` → `dim_category` → … |

ASCII key path snowflake:

```
fact_store_sales.product_key --> dim_product.subcategory_key
                                        |
                                        v
                                 dim_subcategory.category_key
                                        |
                                        v
                                   dim_category ...
```

**Interview Tip:** Snowflake adds **intermediate foreign keys** on dimensions, not on facts (usually).

---

## Referential Integrity: OLTP vs DW

| Aspect | OLTP | Typical DW mart |
|--------|------|-----------------|
| RI enforcement | Strong DB constraints | Mixed |
| Late-arriving facts | Rare | Occasional |
| Dimension versioning | Immediate updates | Batch SCD loads |
| Unknown members | Uncommon | Patterned handling |

Many warehouses **logically** enforce FK relationships while **physically** deferring constraints to reduce load locking—especially on columnar appliances.

**Watch Out!** Turning off all checks without ETL validation produces facts pointing at missing dimension keys (“-1 holes” in reports).

---

## ETL Validation for Referential Integrity

| Check | Technique | Retail benefit |
|-------|-----------|----------------|
| FK existence | Left anti-join staging to dims | Catch new SKUs before publish |
| Grain | Group-by counts on keys | Detect duplicate dimension rows |
| Conformance | Cross-source key maps | Align web and store `product_key` |
| Orphan facts | `NOT EXISTS` after load | Nightly data quality scorecard |

```sql
-- Example orphan detection
SELECT f.store_key, COUNT(*) AS orphan_rows
FROM fact_store_sales AS f
LEFT JOIN dim_store AS s
  ON f.store_key = s.store_key
WHERE s.store_key IS NULL
GROUP BY f.store_key;
```

**Interview Tip:** Describe RI as a pipeline contract: reject, default, or quarantine rows that fail validation.

---

## Unknown Member Row Pattern

Dimensions include synthetic rows for missing context:

| `store_key` | `store_id` | `store_name` |
|-------------|------------|----------------|
| -1 | `UNKNOWN` | `Unknown store` |
| -2 | `NOT_APPLICABLE` | `Not applicable` |

Facts reference `-1` when the source lacks a reliable store id rather than NULLing the FK.

**Watch Out!** Analysts summing sales including `-1` without disclosure misstate “all stores” totals.

---

## Load Order: Dimensions First

Typical batch sequence:

```
1) Stage source extracts
2) Upsert dimensions (SCD1/2 logic)
3) Resolve business keys to surrogate keys in fact staging
4) Load facts with validated FKs
5) Build aggregates / indexes
```

ASCII:

```
 STAGING --> DIMENSIONS --> FACT RESOLUTION --> FACT LOAD --> AGGS
```

**Interview Tip:** Late-arriving dimensions may force facts to sit in a holding table until keys exist.

---

## Composite Keys

| Use case | Example | Note |
|----------|---------|------|
| Bridge table | (`promotion_key`, `product_key`) | Composite PK common |
| Fact at composite grain | (`store_key`, `snapshot_date_key`) for inventory | Fact PK may be composite |
| Avoid on Type 2 customer | (`customer_id`, `effective_date`) as only key | Prefer surrogate `customer_key` on fact |

```sql
CREATE TABLE bridge_promotion_product (
    promotion_key INT    NOT NULL,
    product_key   BIGINT NOT NULL,
    PRIMARY KEY (promotion_key, product_key)
);
```

**Watch Out!** Encoding composite business logic into a single string surrogate without parsing rules confuses ETL consumers.

---

## SCD Preview Tied to Keys

| SCD type | Key behavior |
|----------|--------------|
| Type 1 | Same surrogate; overwrite attributes |
| Type 2 | New surrogate row; new `effective_date`/`end_date` |
| Type 3 | Same surrogate; limited prior-value columns |

Facts loaded for a sale on a Type 2 dimension must capture the **surrogate key active that day**, not merely the business `customer_id`.

**Interview Tip:** “Point-in-time join” means fact’s `customer_key` maps to the dimension row version valid for the fact’s date.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Fact stores only business keys | Slow joins; ambiguous SCD rows | Store surrogate FK on fact |
| Reusing surrogate after dimension delete | Silent wrong attributes | Never recycle keys |
| No unknown row | Loads fail or NULL FKs | Add `-1` / `-2` members |
| Enforcing hard RI before late facts | Blocks pipeline | Staging quarantine + soft RI |
| Natural PK on Type 2 dimension | Cannot distinguish versions | Surrogate per version |

---

## Key Takeaway

> Treat surrogate primary keys and fact foreign keys as the integration backbone of retail warehousing, validate them rigorously in ETL, and align key strategy with SCD so historical reporting stays faithful to the business as stores, products, and customers evolve.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) Dim PK: surrogate default; keep business key as column.      |
| 2) Fact FKs point to dim PKs; degenerates stay on fact.         |
| 3) Snowflake adds FK chains inside dimensions.                  |
| 4) DW RI may be logical; ETL must still enforce checks.         |
| 5) Unknown member rows prevent NULL FK chaos.                 |
| 6) Load dimensions before facts; resolve keys in staging.     |
| 7) SCD2 = new surrogate; facts must store version-specific FK. |
+------------------------------------------------------------------+
```
