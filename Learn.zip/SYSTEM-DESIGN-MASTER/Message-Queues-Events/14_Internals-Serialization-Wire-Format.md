# Internals: Serialization and Wire Format

> **Permanent Recall:** Serialization converts objects → bytes for transmission/storage. JSON is human-readable but slow and large. Binary formats (Protocol Buffers, Avro, Thrift) are 2-10x smaller and 10-100x faster. Kafka uses its own binary protocol for request/response framing. Schema Registry (Confluent) stores Avro/Protobuf schemas centrally; messages carry only a 5-byte schema ID prefix. Schema evolution (backward/forward compatibility) is critical for decoupled producers and consumers. Choose: JSON for debugging, Avro for Kafka ecosystem, Protobuf for cross-language RPC.

---

## Why This Matters

Serialization is not just a data-format topic.

At messaging scale, it affects:

- CPU cost
- network bandwidth
- disk usage
- schema compatibility across teams

This file connects application objects to actual bytes on the wire, which is why it sits after the broker internals.

---

## Why Serialization Matters at This Level

```
THE COST OF SERIALIZATION:

At 1 million messages/sec:
  JSON serialization:   ~50 µs/msg × 1M = 50 seconds of CPU per second!
  Protobuf:             ~1 µs/msg × 1M  = 1 second of CPU per second

  JSON message size:    ~500 bytes average
  Protobuf same data:   ~150 bytes

  Network:
    JSON:     500 bytes × 1M = 500 MB/s
    Protobuf: 150 bytes × 1M = 150 MB/s
    Savings: 350 MB/s of network bandwidth

  Disk (Kafka):
    JSON:     500 MB/s × 86400s = 43 TB/day
    Protobuf: 150 MB/s × 86400s = 13 TB/day
    Savings: 30 TB/day of disk storage (and faster I/O)

Serialization is in the HOT PATH of every single message.
It directly impacts: CPU, memory, network, disk, latency.
```

---

## JSON — How It Works at Byte Level

```
JSON SERIALIZATION:

Input (Java object):
  Order { id=123, product="laptop", price=999.99, qty=2 }

Output (JSON bytes):
  {"id":123,"product":"laptop","price":999.99,"qty":2}

BYTE REPRESENTATION (UTF-8):
  { = 0x7B
  " = 0x22
  i = 0x69
  d = 0x64
  " = 0x22
  : = 0x3A
  1 = 0x31
  2 = 0x32
  3 = 0x33
  , = 0x2C
  ... (every character is at least 1 byte)

Total: 52 bytes for this message

PROBLEMS:
  1. FIELD NAMES REPEATED:
     Every message carries "id", "product", "price", "qty"
     With 1M messages: 1M × ~20 bytes of field names = 20 MB wasted

  2. NUMBERS AS TEXT:
     999.99 = 6 bytes as text (0x39 0x39 0x39 0x2E 0x39 0x39)
     999.99 = 8 bytes as double (IEEE 754, fixed)
     But: integer 123 = 3 bytes text vs 4 bytes int32
     For large numbers: text is worse
     123456789 = 9 bytes text vs 4 bytes int32

  3. NO SCHEMA ENFORCEMENT:
     Any producer can send any JSON shape
     Consumer discovers missing fields at runtime
     Silently breaks downstream processing

  4. PARSING COST:
     Must scan character by character
     Build string tokens, convert numbers from text
     Handle escape sequences (\", \\, \n, \uXXXX)
     Allocate strings on heap (GC pressure)

JACKSON (Java JSON library) PIPELINE:
  bytes → tokenizer (char-by-char scan) → JsonParser (token stream)
  → ObjectMapper (reflection, field matching) → Java object
  Each step: memory allocation, CPU work

WHEN TO USE JSON:
  - Debugging and human readability needed
  - Low throughput (< 10K msg/sec)
  - REST APIs (standard format)
  - Configuration data
```

---

## Protocol Buffers (Protobuf) — Binary Encoding

```
PROTOBUF — HOW IT ENCODES DATA:

Schema definition (.proto file):
  message Order {
    int32 id = 1;          // field number 1
    string product = 2;    // field number 2
    double price = 3;      // field number 3
    int32 qty = 4;         // field number 4
  }

THE KEY INSIGHT: field numbers, not field names!
  Field number (1-4) is encoded, NOT the name ("id", "product"...)
  Schema shared out-of-band (compiled into code)
  Message only carries: [field_number + type] [value]

WIRE FORMAT:

Each field encoded as: [TAG] [VALUE]
  TAG = (field_number << 3) | wire_type
  wire_type:
    0 = varint (int32, int64, bool, enum)
    1 = 64-bit (fixed64, double)
    2 = length-delimited (string, bytes, embedded messages)
    5 = 32-bit (fixed32, float)

ENCODING OUR ORDER:
  Order { id=123, product="laptop", price=999.99, qty=2 }

  Field 1 (id=123, type=int32, wire_type=0):
    TAG: (1 << 3) | 0 = 0x08  (1 byte)
    VALUE: varint(123) = 0x7B  (1 byte)
    Total: 2 bytes

  Field 2 (product="laptop", type=string, wire_type=2):
    TAG: (2 << 3) | 2 = 0x12  (1 byte)
    LENGTH: varint(6) = 0x06   (1 byte)
    VALUE: "laptop" = 0x6C 0x61 0x70 0x74 0x6F 0x70  (6 bytes)
    Total: 8 bytes

  Field 3 (price=999.99, type=double, wire_type=1):
    TAG: (3 << 3) | 1 = 0x19  (1 byte)
    VALUE: IEEE 754 double = 8 bytes (0x40 0x8F 0x3F 0xF5 0xC2 0x8F 0x5C 0x29)
    Total: 9 bytes

  Field 4 (qty=2, type=int32, wire_type=0):
    TAG: (4 << 3) | 0 = 0x20  (1 byte)
    VALUE: varint(2) = 0x02    (1 byte)
    Total: 2 bytes

  TOTAL MESSAGE: 2 + 8 + 9 + 2 = 21 bytes
  JSON equivalent: 52 bytes
  Savings: 60% smaller!

VARINT ENCODING (variable-length integer):
  ┌──────────────────────────────────────────────────────┐
  │ Small numbers use fewer bytes:                       │
  │                                                      │
  │ Value    Binary             Varint bytes   Size      │
  │ 1        00000001           0x01           1 byte    │
  │ 127      01111111           0x7F           1 byte    │
  │ 128      10000000 00000001  0x80 0x01      2 bytes   │
  │ 300      10101100 00000010  0xAC 0x02      2 bytes   │
  │ 16383    11111111 01111111  0xFF 0x7F      2 bytes   │
  │ 16384    10000000 10000000  0x80 0x80 0x01 3 bytes   │
  │                            00000001                  │
  │                                                      │
  │ MSB = 1: more bytes follow                           │
  │ MSB = 0: this is the last byte                       │
  │ Lower 7 bits of each byte carry the value            │
  │ Little-endian: least significant group first         │
  └──────────────────────────────────────────────────────┘

DESERIALIZATION (parsing protobuf):
  1. Read TAG byte → extract field_number and wire_type
  2. Based on wire_type, read the VALUE:
     varint: read bytes until MSB=0
     64-bit: read exactly 8 bytes
     length-delimited: read length varint, then that many bytes
     32-bit: read exactly 4 bytes
  3. Map field_number to struct field (compiled code)
  4. No string parsing, no tokenization, no heap allocation for field names

  Speed: ~10-100x faster than JSON parsing
  Memory: minimal allocation (direct struct population)
```

---

## Apache Avro — Schema in Registry, Data on Wire

```
AVRO — SCHEMA EVOLUTION CHAMPION:

Avro schema (JSON format):
  {
    "type": "record",
    "name": "Order",
    "fields": [
      {"name": "id", "type": "int"},
      {"name": "product", "type": "string"},
      {"name": "price", "type": "double"},
      {"name": "qty", "type": "int", "default": 1}
    ]
  }

KEY DIFFERENCE FROM PROTOBUF:
  - Protobuf: field numbers in wire format (schema compiled into code)
  - Avro: NO field numbers or names in wire format!
  - Reader and writer both need the schema to encode/decode
  - Fields are encoded IN ORDER defined by schema
  - Schema stored externally (Schema Registry)

AVRO BINARY ENCODING:

  Order { id=123, product="laptop", price=999.99, qty=2 }

  Encoded (no tags, no field names, just values in schema order):

  id (int): zigzag varint(123) = 0xF6 0x01  (2 bytes)
    zigzag: (n << 1) ^ (n >> 31) maps signed → unsigned
    positive 123 → 246 → varint(246)

  product (string): length varint(6) + "laptop"
    0x0C 0x6C 0x61 0x70 0x74 0x6F 0x70  (7 bytes)
    (length 6 zigzag-encoded = 12 = 0x0C)

  price (double): 8 bytes IEEE 754 (same as protobuf)
    (8 bytes)

  qty (int): zigzag varint(2) = 0x04  (1 byte)
    zigzag: 2 → 4

  TOTAL: 2 + 7 + 8 + 1 = 18 bytes
  Even smaller than protobuf (21 bytes)!
  Because: no field tags at all

WHY SCHEMA REGISTRY IS ESSENTIAL FOR AVRO:
  Without schema, you can't decode Avro bytes.
  There are no field markers in the data.
  You must know the exact schema used to write the data.
```

---

## Confluent Schema Registry — How It Works

```
SCHEMA REGISTRY ARCHITECTURE:

┌────────────────────────────────────────────────────────────────┐
│                                                                │
│  Producer                 Schema Registry            Kafka     │
│  ┌──────────┐            ┌──────────────┐         ┌─────────┐│
│  │          │            │              │         │         ││
│  │ 1. Check │──────────► │ Register     │         │         ││
│  │    schema │            │ schema       │         │         ││
│  │          │◄────────── │              │         │         ││
│  │ 2. Get   │  schema_id │ Store:       │         │         ││
│  │    ID=42 │  = 42      │  ID=42 →     │         │         ││
│  │          │            │  {schema}    │         │         ││
│  │ 3. Encode│            │              │         │         ││
│  │ [0][42]  │            │ Stored in:   │         │         ││
│  │ [avro    │            │ _schemas     │         │         ││
│  │  bytes]  │───────────────────────────────────► │ Topic   ││
│  │          │            │ topic        │         │         ││
│  └──────────┘            └──────────────┘         │         ││
│                                                    │         ││
│  Consumer                                          │         ││
│  ┌──────────┐            ┌──────────────┐         │         ││
│  │          │◄───────────────────────────────────  │         ││
│  │ 1. Read  │            │              │         │         ││
│  │ [0][42]  │            │              │         └─────────┘│
│  │ [avro]   │            │              │                    │
│  │          │            │              │                    │
│  │ 2. Get   │──────────► │ Lookup       │                    │
│  │  schema  │            │ ID=42        │                    │
│  │  for     │◄────────── │ Return       │                    │
│  │  ID=42   │  schema    │ {schema}     │                    │
│  │          │            │              │                    │
│  │ 3. Decode│            │              │                    │
│  │  using   │            │              │                    │
│  │  schema  │            │              │                    │
│  └──────────┘            └──────────────┘                    │
│                                                                │
└────────────────────────────────────────────────────────────────┘

MESSAGE FORMAT WITH SCHEMA REGISTRY:

  ┌──────────────────────────────────────────────────────┐
  │ Byte 0:      Magic byte = 0x00                       │
  │ Bytes 1-4:   Schema ID (int32, big-endian) = 42      │
  │ Bytes 5..N:  Avro-encoded payload (no schema needed)  │
  └──────────────────────────────────────────────────────┘

  Total overhead: 5 bytes per message
  Schema looked up by ID (cached on producer/consumer)
  First lookup: HTTP call to Schema Registry
  Subsequent: in-memory cache (schema doesn't change often)

SCHEMA CACHING:
  Producer caches: schema_hash → schema_id
    Check cache before every send (avoid HTTP call)
  Consumer caches: schema_id → schema object
    One HTTP call per new schema_id, then cached

SCHEMA SUBJECTS:
  Subject = {topic}-value  (for message values)
  Subject = {topic}-key    (for message keys)
  Each subject has its own schema evolution history
```

---

## Schema Evolution — Backward and Forward Compatibility

```
SCHEMA EVOLUTION — THE CRITICAL CONCERN:

In a decoupled system, producers and consumers evolve independently.
Producer deploys new schema → old consumers must still work.
Consumer deploys new schema → old messages must still parse.

COMPATIBILITY TYPES:
  ┌──────────────────────────────────────────────────────────────┐
  │                                                              │
  │ BACKWARD COMPATIBLE (default, most common):                  │
  │   New schema can READ data written with old schema           │
  │   "New consumer can read old messages"                       │
  │                                                              │
  │   Allowed:                                                   │
  │     ✓ Add field WITH default value                           │
  │     ✓ Remove field (new code ignores it if present)          │
  │   Forbidden:                                                 │
  │     ✗ Add required field without default                     │
  │     ✗ Change field type                                      │
  │     ✗ Rename field (Avro has aliases for this)               │
  │                                                              │
  │ FORWARD COMPATIBLE:                                          │
  │   Old schema can READ data written with new schema           │
  │   "Old consumer can read new messages"                       │
  │                                                              │
  │   Allowed:                                                   │
  │     ✓ Remove field (old code has default)                    │
  │     ✓ Add field (old code ignores unknown fields)            │
  │   Forbidden:                                                 │
  │     ✗ Remove field without default in old schema             │
  │                                                              │
  │ FULL COMPATIBLE:                                             │
  │   Both backward AND forward compatible                       │
  │   Safest but most restrictive                                │
  │   Can only: add/remove OPTIONAL fields with defaults         │
  │                                                              │
  │ NONE:                                                        │
  │   No compatibility checking                                  │
  │   Any change allowed (dangerous in production)               │
  └──────────────────────────────────────────────────────────────┘

AVRO SCHEMA EVOLUTION EXAMPLE:

  Schema V1 (producer writes):
    { "fields": [
      {"name": "id", "type": "int"},
      {"name": "product", "type": "string"}
    ]}

  Schema V2 (backward compatible — new consumer reads old data):
    { "fields": [
      {"name": "id", "type": "int"},
      {"name": "product", "type": "string"},
      {"name": "qty", "type": "int", "default": 1}  ← NEW, has default
    ]}

  Old message (V1): {id=123, product="laptop"}
  New consumer (V2): reads it → id=123, product="laptop", qty=1 (default!)

  Works because: qty has a default value (1)
  If qty had no default: old messages would fail to parse → INCOMPATIBLE

PROTOBUF EVOLUTION RULES:
  - Field numbers must NEVER be reused
  - New fields: use new field numbers (old code ignores them)
  - Removed fields: mark as "reserved" (prevent reuse)
  - Don't change field types
  - Every field is optional by default (proto3)
  - Unknown fields preserved during parsing (forward compatible)
```

---

## Kafka Protocol Framing — Binary Wire Format

```
KAFKA BINARY PROTOCOL (request/response framing):

All communication between clients and brokers uses Kafka's
custom binary protocol over TCP.

REQUEST FRAME:
  ┌──────────────────────────────────────────────────────────┐
  │ Bytes 0-3:    request_size (int32) — total bytes after   │
  │ Bytes 4-5:    api_key (int16) — request type             │
  │ Bytes 6-7:    api_version (int16) — protocol version     │
  │ Bytes 8-11:   correlation_id (int32) — request/response  │
  │ Bytes 12-13:  client_id_length (int16)                   │
  │ Bytes 14..N:  client_id (string)                         │
  │ Bytes N+1..:  request body (varies by api_key)           │
  └──────────────────────────────────────────────────────────┘

RESPONSE FRAME:
  ┌──────────────────────────────────────────────────────────┐
  │ Bytes 0-3:    response_size (int32)                      │
  │ Bytes 4-7:    correlation_id (int32) — matches request   │
  │ Bytes 8..:    response body (varies by api_key)          │
  └──────────────────────────────────────────────────────────┘

API KEYS (commonly used):
  0  = Produce
  1  = Fetch
  2  = ListOffsets
  3  = Metadata
  8  = OffsetCommit
  9  = OffsetFetch
  10 = FindCoordinator
  11 = JoinGroup
  12 = Heartbeat
  14 = SyncGroup
  18 = ApiVersions
  19 = CreateTopics
  22 = InitProducerId

PRODUCE REQUEST BODY (api_key=0):
  ┌──────────────────────────────────────────────────────────┐
  │ transactional_id: nullable_string                        │
  │ acks: int16 (0, 1, or -1)                               │
  │ timeout: int32 (ms)                                      │
  │ topic_data: [array of]:                                  │
  │   topic: string                                          │
  │   partition_data: [array of]:                            │
  │     partition: int32                                      │
  │     record_set: bytes (the actual RecordBatch binary)    │
  └──────────────────────────────────────────────────────────┘

FETCH REQUEST BODY (api_key=1):
  ┌──────────────────────────────────────────────────────────┐
  │ replica_id: int32 (-1 for consumers, broker_id for ISR)  │
  │ max_wait: int32 (ms, long polling)                       │
  │ min_bytes: int32 (min data before responding)            │
  │ max_bytes: int32 (max response size)                     │
  │ isolation_level: int8 (0=read_uncommitted, 1=read_committed)
  │ topics: [array of]:                                      │
  │   topic: string                                          │
  │   partitions: [array of]:                                │
  │     partition: int32                                      │
  │     fetch_offset: int64 (where to start reading)         │
  │     partition_max_bytes: int32                            │
  └──────────────────────────────────────────────────────────┘

STRING ENCODING IN KAFKA PROTOCOL:
  Nullable string:
    Length (int16): -1 means null, otherwise string length
    Content: UTF-8 bytes

  Compact string (newer versions):
    Length (unsigned varint): 0 means null, length+1 otherwise
    Content: UTF-8 bytes (saves bytes for short strings)

ARRAY ENCODING:
  Length (int32): number of elements
  Elements: encoded sequentially

READING A RESPONSE (client side):
  1. Read 4 bytes → response_size (know how many bytes to read)
  2. Read response_size bytes into buffer
  3. Read 4 bytes → correlation_id (match to pending request)
  4. Parse remaining bytes according to api_key + api_version
```

---

## Performance Comparison — Real Numbers

```
SERIALIZATION BENCHMARK (typical results):

Message: {"userId":12345,"action":"purchase","amount":99.99,
          "timestamp":1710000000,"items":["laptop","mouse"]}

┌────────────┬────────────┬────────────┬────────────┬──────────┐
│ Format     │ Size       │ Serialize  │ Deserialize│ Total    │
│            │ (bytes)    │ (µs)       │ (µs)       │ CPU (µs) │
├────────────┼────────────┼────────────┼────────────┼──────────┤
│ JSON       │ 105        │ 12.5       │ 18.3       │ 30.8     │
│ JSON (no   │ 105        │ 5.2        │ 8.1        │ 13.3     │
│  pretty)   │            │            │            │          │
│ Protobuf   │ 38         │ 0.8        │ 0.6        │ 1.4      │
│ Avro       │ 32         │ 1.2        │ 0.9        │ 2.1      │
│ MessagePack│ 65         │ 2.1        │ 1.8        │ 3.9      │
│ Thrift     │ 45         │ 1.5        │ 1.1        │ 2.6      │
│ FlatBuffers│ 56         │ 0.1        │ 0.0*       │ 0.1      │
└────────────┴────────────┴────────────┴────────────┴──────────┘
  * FlatBuffers: zero-copy deserialization (no parsing!)

AT SCALE (1 million messages/sec):
  ┌────────────┬────────────┬───────────┬──────────┐
  │ Format     │ Bandwidth  │ CPU cores │ Disk/day │
  │            │ (MB/s)     │ (for ser) │ (TB)     │
  ├────────────┼────────────┼───────────┼──────────┤
  │ JSON       │ 105        │ 30.8      │ 9.1      │
  │ Protobuf   │ 38         │ 1.4       │ 3.3      │
  │ Avro       │ 32         │ 2.1       │ 2.8      │
  └────────────┴────────────┴───────────┴──────────┘
  (CPU cores = total CPU microseconds / 1M µs per core)

KAFKA ECOSYSTEM RECOMMENDATIONS:
  Confluent/Kafka community: Avro with Schema Registry
  Google ecosystem (gRPC): Protobuf
  Simple use cases: JSON (with compression)
  Analytics/columnar: Avro (self-describing for schema evolution)
  Ultra-low latency: FlatBuffers or Cap'n Proto (zero-copy)
```

---

## Compression at Wire Level

```
COMPRESSION IN MESSAGE QUEUES:

KAFKA COMPRESSION (batch-level):
  Producer compresses entire RecordBatch before sending.
  Broker stores compressed bytes AS-IS.
  Consumer decompresses after receiving.

  ┌──────────────────────────────────────────────────────┐
  │ Producer:                                            │
  │   10 records × 100 bytes = 1000 bytes (raw)          │
  │   compress(snappy, all_records) = 350 bytes           │
  │   Send 350 bytes over network                        │
  │                                                      │
  │ Broker:                                              │
  │   Store 350 bytes on disk (stays compressed!)        │
  │   sendfile() sends 350 bytes to consumer             │
  │                                                      │
  │ Consumer:                                            │
  │   Receive 350 bytes                                  │
  │   decompress() = 1000 bytes                          │
  │   Parse 10 records                                   │
  └──────────────────────────────────────────────────────┘

  Batch compression >> per-message compression
  10 messages together have more redundancy
  Better compression ratio with batching

RABBITMQ COMPRESSION:
  Not built-in at protocol level
  Application-level: compress message body before publish
  Consumer decompresses after receive
  Content-encoding header: "gzip" or "deflate"

COMPRESSION ALGORITHM INTERNALS:

  LZ4 (fastest):
    ┌──────────────────────────────────────────────────────┐
    │ Block-based: process input in 64KB blocks             │
    │ Match finder: hash first 4 bytes → find match         │
    │ Output: [literal_length][literal_data][match_offset]  │
    │         [match_length]                                 │
    │ Hash table in L1 cache → very fast                    │
    │ Single pass: no look-ahead or entropy coding          │
    └──────────────────────────────────────────────────────┘

  ZSTD (best ratio with good speed):
    ┌──────────────────────────────────────────────────────┐
    │ Combines: LZ77 (match finding) + Huffman + FSE       │
    │ Dictionary support: pre-train on similar messages     │
    │ Levels 1-19: trade speed for ratio                    │
    │ Level 1: ~500 MB/s compress, ~2x ratio               │
    │ Level 3 (default): ~300 MB/s, ~3x ratio              │
    │ Level 19: ~10 MB/s, ~5x ratio                        │
    │                                                      │
    │ Dictionary mode for small messages:                   │
    │   Train dictionary on 1000 sample messages            │
    │   Dictionary captures common patterns                 │
    │   Individual 100-byte message: without dict ~1.5x     │
    │   With dict: ~3x compression!                         │
    │   Kafka doesn't use dict mode (batch compression      │
    │   achieves similar benefit)                            │
    └──────────────────────────────────────────────────────┘
```

---

## End-to-End: Message Bytes on the Wire

```
COMPLETE WIRE TRACE — Publishing an Avro message to Kafka:

Application data:
  Order { id=123, product="laptop", price=999.99, qty=2 }

Step 1: AVRO SERIALIZE
  Schema registry lookup → schema_id = 42
  [0x00] [0x00 0x00 0x00 0x2A] [0xF6 0x01 0x0C laptop 8bytes 0x04]
   magic    schema_id=42         avro payload (18 bytes)
  Total Avro message: 23 bytes

Step 2: KAFKA RECORD (within RecordBatch)
  Record:
    length: varint
    attributes: 0x00
    timestampDelta: varint
    offsetDelta: varint
    keyLength: varint(key_bytes)
    key: "order-123" (9 bytes)
    valueLength: varint(23)
    value: [23 bytes avro from step 1]
    headers: 0 (no headers)
  ~40 bytes per record

Step 3: KAFKA RECORD BATCH (with 10 records, snappy compressed)
  RecordBatch header: 57 bytes
  10 records compressed: ~150 bytes (from ~400 bytes raw)
  Total batch: ~207 bytes

Step 4: KAFKA PRODUCE REQUEST
  Request header: ~30 bytes (api_key, version, correlation_id, client_id)
  Request body: acks, timeout, topic, partition, batch bytes
  Total request: ~260 bytes

Step 5: TCP SEGMENT
  TCP header: 20 bytes (+ options)
  IP header: 20 bytes
  Total IP packet: ~300 bytes

Step 6: ETHERNET FRAME
  Ethernet header: 14 bytes
  FCS: 4 bytes
  Total frame: ~318 bytes

Step 7: ON THE WIRE
  Preamble: 8 bytes
  Frame: 318 bytes
  Inter-frame gap: 12 bytes
  Total bits: 338 × 8 = 2704 bits

  At 10 Gbps: 2704 bits × 0.1 ns/bit = 270 nanoseconds
  That's 270 NANOSECONDS for 10 Avro messages!

OVERHEAD BREAKDOWN:
  Application data (10 orders): ~230 bytes (45%)
  Avro schema IDs:               50 bytes (10%)
  Kafka protocol:                ~80 bytes (16%)
  Compression savings:          -250 bytes
  TCP/IP/Ethernet:               ~58 bytes (11%)
  Wire encoding:                 ~20 bytes
  ─────────────────────────────────────
  Effective payload ratio: ~45% (with compression)
  Without compression: ~25%
```

---

## 30-SECOND REVISION BOX

```
JSON: text-based, 52 bytes, ~30µs/msg, human-readable, no schema
PROTOBUF: binary, field numbers + varints, 21 bytes, ~1.4µs/msg
AVRO: binary, no field tags, schema-dependent, 18 bytes, ~2.1µs/msg
SCHEMA REGISTRY: schema_id (5 bytes) prefix, HTTP lookup, cached
EVOLUTION: backward (new reads old), forward (old reads new), full (both)
VARINT: small numbers = fewer bytes, MSB = "more bytes follow"
KAFKA PROTOCOL: size + api_key + version + correlation_id + body
COMPRESSION: batch-level, snappy/lz4/zstd, stored compressed on disk
WIRE: Avro→Kafka record→batch→compress→request→TCP→IP→Ethernet→bits
```

---

**Prev: [[13_Internals-RabbitMQ-Deep-Dive]] | Next: [[15_Internals-OS-Kernel-Interactions]]**
