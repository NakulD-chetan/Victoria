import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(items) {
  const n = items.length;
  const steps = [];
  const total = 2 ** n;
  for (let mask = 0; mask < total; mask++) {
    const bits = Array.from({ length: n }, (_, i) => ((mask >> (n - 1 - i)) & 1 ? '1' : '0'));
    const subset = [];
    for (let i = 0; i < n; i++) if ((mask >> (n - 1 - i)) & 1) subset.push(items[i]);
    steps.push({
      type: 'mask',
      mask,
      cells: bits,
      subset,
      title: `mask ${mask} → {${subset.join(', ')}}`,
    });
  }
  steps.push({ type: 'done', mask: total - 1, cells: Array(n).fill('1'), subset: [...items], title: '✓ All subsets' });
  return steps;
}

export default function PowerSetVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const items = ['A', 'B', 'C'];
    const steps = generateSteps(items);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Enumerate masks 0..2^n-1' });
    canvasRef.current?.setState({
      cells: steps[0].cells,
      colors: {},
      title: steps[0].title,
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'mask') {
      for (let i = 0; i < step.cells.length; i++) {
        if (step.cells[i] === '1') colors[i] = 'compare';
      }
    }
    if (step.type === 'done') for (let i = 0; i < step.cells.length; i++) colors[i] = 'sorted';
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.title || step.type });
    canvasRef.current?.setState({
      cells: step.cells,
      colors,
      title: step.title,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
