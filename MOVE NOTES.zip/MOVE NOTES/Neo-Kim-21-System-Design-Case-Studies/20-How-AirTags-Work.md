# 20. How AirTags Work

## One-Line Summary
AirTags use Bluetooth Low Energy (BLE) to broadcast a public key; nearby iPhones (including strangers') relay encrypted location data to Apple servers, enabling crowdsourced tracking without GPS/WiFi/cellular—all with end-to-end encryption.

## Key Requirements
- **No GPS, WiFi, or cellular** — AirTag must work without these (low power, small form factor)
- **Privacy**: Owner's location never exposed; strangers' locations never readable by Apple or others
- **Battery life**: 1+ year on a coin cell
- **Accuracy**: Works when owner is nearby (direct) or far away (crowdsourced)

## High-Level Architecture
```
[AirTag] --BLE broadcast--> [Nearby iPhones] --HTTP--> [Apple Servers] --Download--> [Owner's iPhone]
     |                            |                         |                          |
  Public key only           Encrypts own location      Stores encrypted blob      Decrypts with private key
```

## Core Components Deep Dive

### 1. Setup
- Generate elliptic curve public-private key pair
- Key pair shared between AirTag and user's iCloud account
- Private key stays on owner's device; AirTag only knows public key

### 2. Broadcasting
- AirTag broadcasts **public key only** every ~2 seconds over BLE
- No location data ever sent by the AirTag
- BLE = minimal power consumption

### 3. When Owner's iPhone Is Nearby
- Direct Bluetooth or Ultra Wideband (UWB) communication
- Precise "Find My" experience with directional guidance

### 4. When Owner's iPhone Is Far (Crowdsourced Network)
1. AirTag broadcasts public key via BLE
2. Nearby stranger's iPhone receives the broadcast
3. Stranger's iPhone encrypts **its own location** with the AirTag's public key
4. Encrypted blob uploaded to Apple servers via HTTP
5. Owner downloads encrypted data and decrypts with private key
6. Owner sees approximate location of their AirTag (where the stranger's phone was)

### 5. Privacy Model
- **Stranger's iPhone**: Has only public key; cannot read decrypted location
- **Apple servers**: Store encrypted blobs; cannot decrypt (no private key)
- **End-to-end encryption**: Elliptic curve cryptography ensures only owner can decrypt

## Key Design Decisions
1. **BLE over GPS/WiFi/cellular** — enables 1+ year battery, no SIM, no antenna
2. **Crowdsourced relay** — hundreds of millions of iPhones act as location relays
3. **Public key broadcast** — AirTag never sends location; only identifies itself
4. **Encrypt with recipient's public key** — only AirTag owner can decrypt

## Scaling Strategies
- Apple's Find My network scales with iPhone adoption (network effect)
- Servers store encrypted blobs; minimal compute (no decryption)
- BLE broadcast is stateless; no connection overhead
- Rate limiting and abuse detection on upload endpoints

## Interview Tips
- Emphasize **privacy-first design** — Apple can't read the data
- Explain the "inversion": stranger encrypts *their* location for the *owner*
- Contrast with GPS trackers: no cellular cost, no subscription, works globally
- Mention UWB for precision when nearby; BLE for crowdsourced when far

## Quick Revision
- No GPS/WiFi/cellular; BLE only; 1+ year battery
- AirTag broadcasts public key every 2 seconds; never sends location
- Stranger's iPhone encrypts its location with AirTag's public key → uploads to Apple
- End-to-end encryption: only owner's private key can decrypt
- Crowdsourced: hundreds of millions of iPhones = location relays
