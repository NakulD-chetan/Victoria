# Database Scaling — Design Template

> **Permanent Recall:** Reusable patterns: replication setup (1 master + N replicas, async/sync choice), sharding (hash-based with consistent hashing), shard key framework (cardinality, query pattern, hot spot check), migration strategy (online schema migration, dual-write), and database proxy pattern (Vitess, ProxySQL). Each template has architecture diagrams and "when to use" criteria. Always plan for re-sharding and failover.

---

## Pattern 1: Replication Setup Template

**When to use:** Read-heavy workload, need HA, single-write source.

```
ARCHITECTURE:

                    ┌─────────────────┐
                    │   App Servers    │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              │ Write        │ Read         │
              ▼              ▼              │
    ┌──────────────┐  ┌──────────────┐     │
    │   Master     │  │  Replica 1   │     │
    │  (Primary)   │  └──────────────┘     │
    └──────┬───────┘  ┌──────────────┐     │
           │          │  Replica 2   │     │
           │ async    └──────────────┘     │
           └────────►┌──────────────┐     │
                     │  Replica N   │     │
                     └──────────────┘     │
```

**Config (conceptual):**
```yaml
replication:
  mode: async  # or sync for consistency
  replicas: 3
  read_routing: round_robin  # or least_lag
  failover: automatic  # promote replica on master fail
```

---

## Pattern 2: Sharding Implementation Template

**When to use:** Write or storage bottleneck, read replicas and caching exhausted.

```
ARCHITECTURE:

    ┌─────────────────────────────────────────────────────────┐
    │                    Application Layer                     │
    └─────────────────────────┬─────────────────────────────────┘
                             │
                    ┌────────┴────────┐
                    │ Shard Router   │  hash(key) % N or lookup
                    │ (or Proxy)     │
                    └────────┬────────┘
          ┌──────────────────┼──────────────────┐
          ▼                  ▼                  ▼
    ┌──────────┐       ┌──────────┐       ┌──────────┐
    │ Shard 0  │       │ Shard 1  │       │ Shard 2  │
    │ Master   │       │ Master   │       │ Master   │
    │ + Replica│       │ + Replica│       │ + Replica│
    └──────────┘       └──────────┘       └──────────┘
```

---

## Pattern 3: Consistent Hashing Implementation

```
ALGORITHM:

1. Create ring (0 to 2^32 or 2^64)
2. Place each physical node with V virtual nodes (e.g., V=150)
   - N1 → N1-0, N1-1, ..., N1-149
3. For key K:
   - hash(K) → position on ring
   - Find next node clockwise
   - Route to that node
4. On add node: only keys in new node's arc move
5. On remove node: keys reassign to next node
```

**Virtual node count:** 150–200 per physical node for even distribution.

---

## Pattern 4: Shard Key Selection Framework

| Step | Question | Action |
|------|----------|--------|
| 1 | What is the primary access pattern? | Identify most common query (e.g., by user_id) |
| 2 | Is the key high cardinality? | Prefer UUID, composite (user_id + order_id) |
| 3 | Will it cause hot spots? | Avoid time-based, low-cardinality |
| 4 | Do we need range queries? | Range-based sharding if yes; else hash |
| 5 | Can cross-shard queries be avoided? | Design so most queries hit one shard |

---

## Pattern 5: Migration Strategy (Online Schema Migration)

```
PHASE 1: Dual-write (both old and new)
  - Write to old schema AND new schema
  - Reads from old
  - Backfill historical data to new

PHASE 2: Switch reads
  - Reads from new
  - Verify consistency

PHASE 3: Remove old
  - Stop writing to old
  - Decommission old
```

---

## Pattern 6: Database Proxy Pattern (Vitess, ProxySQL)

**When to use:** Connection pooling, read/write split, sharding routing without app changes.

```
ARCHITECTURE:

    ┌──────────┐ ┌──────────┐ ┌──────────┐
    │ App 1    │ │ App 2    │ │ App N    │
    └────┬─────┘ └────┬─────┘ └────┬─────┘
         │            │            │
         └────────────┼────────────┘
                      │
             ┌────────┴────────┐
             │  DB Proxy        │
             │  (Vitess/ProxySQL)│
             │  - Pooling       │
             │  - Read/Write    │
             │    split        │
             │  - Shard routing │
             └────────┬────────┘
                      │
         ┌────────────┼────────────┐
         ▼            ▼            ▼
    ┌─────────┐  ┌─────────┐  ┌─────────┐
    │Master   │  │Replica 1│  │ Shard 2 │
    └─────────┘  └─────────┘  └─────────┘
```

| Proxy | Strengths |
|-------|-----------|
| **Vitess** | Kubernetes-native, MySQL sharding, VSchema |
| **ProxySQL** | Lightweight, MySQL read/write split |
| **PgBouncer** | PostgreSQL pooling |

---

## 30-SECOND REVISION BOX

```
REPLICATION: 1 master + N replicas, async/sync, read routing
SHARDING: Router → hash(key) → shard
CONSISTENT HASH: Ring + virtual nodes (150-200)
SHARD KEY: Cardinality, query pattern, hot spot check
MIGRATION: Dual-write → switch reads → remove old
PROXY: Vitess (sharding), ProxySQL (split), PgBouncer (pool)
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
