# Subqueries and CTE — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Focus: IN/EXISTS, correlated subquery, CTE pipelines.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Customers Who Never Order | Easy | 183 | NOT IN / NOT EXISTS | Purest anti-pattern via subquery |
| 2 | Second Highest Salary | Medium | 176 | Subquery + IFNULL | Classic "handle NULL if no result" |
| 3 | Nth Highest Salary | Medium | 177 | Parameterized subquery | Generalized Nth with LIMIT/OFFSET |
| 4 | Department Highest Salary | Medium | 184 | Correlated subquery / IN | Subquery returning (dept, max_sal) |
| 5 | Department Top Three Salaries | Hard | 185 | Correlated count / CTE | Top-N via < 3 higher distinct salaries |
| 6 | Consecutive Numbers | Medium | 180 | Self-join or CTE+LAG | Three consecutive same values |
| 7 | Exchange Seats | Medium | 626 | CASE + subquery | Swap adjacent with total-row awareness |
| 8 | Investments in 2016 | Medium | 585 | IN subquery double | tiv_2015 shared, lat+lon unique |
| 9 | Friend Requests II: Who Has Most Friends | Medium | 602 | UNION CTE | Symmetric relation → union → count |
| 10 | Last Person to Fit in the Bus | Medium | 1204 | CTE running sum | Cumulative ≤ limit |

---

## Complete 30-Problem Progression

### Easy — Subquery Basics (Problems 1-8)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Customers Who Never Order | 183 | NOT IN | Anti-join via subquery |
| 2 | Employees Earning > Managers | 181 | Scalar subquery alt | Compare via subquery or join |
| 3 | Duplicate Emails | 182 | GROUP subquery | Find dups via GROUP + HAVING |
| 4 | Biggest Single Number | 619 | Subquery + MAX | GROUP → HAVING → outer MAX |
| 5 | Classes More Than 5 Students | 596 | GROUP + HAVING | Count per class |
| 6 | Customer Placing Largest Number of Orders | 586 | Subquery for MAX count | ORDER + LIMIT or subquery |
| 7 | Find Customer Referee | 584 | NOT IN + NULL | Subquery NULL pitfall |
| 8 | Second Highest Salary | 176 | IFNULL + subquery | Handle empty result |

### Medium — Correlated & CTE (Problems 9-22)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 9 | Nth Highest Salary | 177 | LIMIT OFFSET function | CREATE FUNCTION + subquery |
| 10 | Department Highest Salary | 184 | IN (dept, max) | Tuple IN subquery |
| 11 | Department Top Three Salaries | 185 | Correlated count | COUNT(DISTINCT higher) < 3 |
| 12 | Consecutive Numbers | 180 | CTE + LAG or self-join | Detect 3 consecutive |
| 13 | Exchange Seats | 626 | CASE + (SELECT COUNT) | Handle odd last row |
| 14 | Investments in 2016 | 585 | Double IN subquery | Shared 2015 AND unique location |
| 15 | Friend Requests II | 602 | UNION CTE + GROUP | Count friends symmetrically |
| 16 | Last Person to Fit in Bus | 1204 | CTE + running SUM | Self-join or window cumulative |
| 17 | Movie Rating | 1341 | UNION ALL + CTE | Two separate queries combined |
| 18 | Product Price at a Given Date | 1164 | CTE + last change | COALESCE with default |
| 19 | Market Analysis I | 1158 | LEFT JOIN subquery | Subquery as derived table |
| 20 | Monthly Transactions I | 1193 | CTE cleanup → agg | Multi-step aggregation |
| 21 | Immediate Food Delivery II | 1174 | CTE for first order | MIN per user then check |
| 22 | Game Play Analysis IV | 550 | CTE + date arithmetic | Retention: next-day login |

### Hard — Advanced CTE & Recursive (Problems 23-30)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Trips and Users | 262 | Subquery filter + ratio | Multi-condition subquery join |
| 24 | Human Traffic of Stadium | 601 | CTE + consecutive | 3+ consecutive ids ≥ 100 |
| 25 | Report Contiguous Dates | 1225 | CTE + island gap | Group consecutive date ranges |
| 26 | Find the Start and End Number of Continuous Ranges | 1285 | CTE + island gap | ROW_NUMBER diff trick |
| 27 | Count Salary Categories | 1907 | CTE + UNION values | Generate categories, LEFT JOIN counts |
| 28 | Median Employee Salary | 569 | CTE + ROW_NUMBER | Find middle row(s) per group |
| 29 | Find Cumulative Salary | 579 | CTE + running sum | 3-month rolling excl. latest |
| 30 | Tournament Winners | 1194 | CTE chain | Multi-step: score → rank → filter |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Second Highest Salary (LC 176)
```
Type: Subquery + NULL handling
Key: SELECT IFNULL((SELECT DISTINCT salary ORDER BY salary DESC LIMIT 1 OFFSET 1), NULL)
Trap: If only one salary exists, must return NULL — not empty
One-liner: OFFSET 1 for second; wrap in IFNULL for empty-result safety.
```

### Problem 5: Department Top Three Salaries (LC 185)
```
Type: Correlated subquery
Key: WHERE (SELECT COUNT(DISTINCT e2.salary) FROM Employee e2
     WHERE e2.departmentId = e1.departmentId AND e2.salary > e1.salary) < 3
Alt: CTE with DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC) ≤ 3
One-liner: "Top N per group" — correlated count or window rank.
```

### Problem 22: Game Play Analysis IV (LC 550)
```
Type: CTE + retention
Key: CTE for first_login per player, then check if login exists on first_login + 1
One-liner: Retention = fraction of users active day after first login.
```

### Problem 25: Report Contiguous Dates (LC 1225)
```
Type: Island-gap with CTE
Key: ROW_NUMBER difference trick to identify contiguous groups
One-liner: date - ROW_NUMBER gives same value for consecutive dates.
```

---

## Pattern Distribution

```
NOT IN / NOT EXISTS:     4 problems  (1, 7, 14, 23)
SCALAR SUBQUERY:         3 problems  (2, 4, 8)
CORRELATED:              4 problems  (5, 11, 14, 16)
CTE PIPELINE:            8 problems  (12, 15, 17-22)
CTE + WINDOW:            5 problems  (11, 16, 24-26, 28)
ISLAND/GAP:              3 problems  (24-26)
RECURSIVE CTE:           1 problem   (25 variant)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-3 (NOT IN, scalar, Nth)
- Day 2: Problems 4-6 (tuple IN, correlated count, consecutive)
- Day 3: Problems 7-8 (NULL in NOT IN, double filter)

### Week 2: Core CTE (Days 4-7)
- Day 4: Problems 9-11 (dept top, correlated)
- Day 5: Problems 12-15 (CTE + LAG, UNION CTE)
- Day 6: Problems 16-19 (running sum, product price, derived table)
- Day 7: Problems 20-22 (multi-step CTE, retention)

### Week 3: Hard (Days 8-10)
- Day 8: Problems 23-25 (Trips, consecutive, island gap)
- Day 9: Problems 26-28 (ranges, categories, median)
- Day 10: Problems 29-30 (rolling sum, tournament chain)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy, 14 Medium, 8 Hard)
MUST-DO:            LC 183, 176, 177, 184, 185, 180, 626, 585, 602, 1204
TOP 3 MOST ASKED:   LC 176 (2nd Highest), LC 185 (Top 3 Dept), LC 180 (Consecutive)
PATTERN SPLIT:      NOT IN/EXISTS (4), Scalar (3), Correlated (4),
                    CTE pipeline (8), CTE+Window (5), Island/Gap (3)
STUDY ORDER:        NOT IN → Scalar → Correlated → CTE → Island/Gap
INTERVIEW LINE:     "I prefer NOT EXISTS over NOT IN for NULL safety,
                     and CTE pipelines for multi-step readability."
```

---

## 30-SECOND REVISION BOX

```
ANTI-JOIN SUB:  LC 183 — NOT IN or NOT EXISTS
2ND HIGHEST:    LC 176 — OFFSET 1 + IFNULL
TOP-N PER GRP:  LC 185 — correlated count < N or DENSE_RANK CTE
ISLAND GAP:     LC 1225 — date - ROW_NUMBER constant trick
RETENTION:      LC 550 — CTE first_login, check first_login + 1
```
