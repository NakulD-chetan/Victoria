import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function h(seed, x, m) {
  return (seed * 31 + x * 17) % m;
}

function generateSteps(m = 12) {
  const bits = Array(m).fill(0);
  const steps = [];
  const items = [7, 15, 22];
  items.forEach((x) => {
    const hs = [h(1, x, m), h(2, x, m), h(3, x, m)];
    steps.push({ type: 'hash', x, hashes: hs, bits: [...bits], arrows: hs });
    hs.forEach((idx) => {
      bits[idx] = 1;
      steps.push({ type: 'set-bit', x, idx, bits: [...bits], arrows: [idx] });
    });
  });
  const probe = 30;
  const hsP = [h(1, probe, m), h(2, probe, m), h(3, probe, m)];
  steps.push({ type: 'check', x: probe, hashes: hsP, bits: [...bits], arrows: hsP });
  const maybe = hsP.every((i) => bits[i] === 1);
  steps.push({ type: 'membership', x: probe, maybe, bits: [...bits], arrows: hsP });
  steps.push({ type: 'done', bits: [...bits] });
  return steps;
}

export default function BloomFilterVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(12);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'm=12 bits, 3 hash functions' });
    const first = steps[0];
    canvasRef.current?.setState({
      cells: first.bits.map((b) => String(b)),
      colors: {},
      title: 'Bit array (0/1)',
      pointers: {},
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    (step.arrows || []).forEach((i) => {
      if (i >= 0 && i < step.bits.length) colors[i] = 'compare';
    });
    if (step.type === 'set-bit') colors[step.idx] = 'swap';
    if (step.type === 'membership') {
      (step.hashes || []).forEach((i) => {
        colors[i] = step.maybe ? 'sorted' : 'pivot';
      });
    }
    if (step.type === 'done') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Bloom filter walk complete' });
    } else if (step.type === 'hash') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Hash ${step.x} → [${step.hashes.join(', ')}]` });
    } else if (step.type === 'set-bit') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Set bit ${step.idx} for ${step.x}` });
    } else if (step.type === 'check') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Membership check ${step.x}` });
    } else if (step.type === 'membership') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.maybe ? 'Bits all 1 → maybe in set' : 'Definitely not in set' });
    }
    canvasRef.current?.setState({
      cells: step.bits.map((b) => String(b)),
      colors,
      title: `Bloom: ${step.type === 'check' || step.type === 'membership' ? 'lookup' : 'insert'}`,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
