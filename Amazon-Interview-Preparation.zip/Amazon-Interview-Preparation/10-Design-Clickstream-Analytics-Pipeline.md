# Design a Clickstream Analytics Pipeline - Interview Answer Format

## One-Line Answer

A clickstream analytics pipeline collects app events, processes them in near real-time for dashboards and alerts, stores raw events in S3 for replay, and builds curated datasets for sessions, funnels, and user behavior analysis.

---

## Step 1: Clarify Requirements (1-2 min)

### What to ask

- What does near-real-time mean here: seconds or minutes?
- What is the peak event volume?
- Which events are required: views, clicks, search, add-to-cart, purchase?
- Do we need sessions, funnels, experimentation, or personalization outputs?
- How much lateness should we tolerate from mobile clients?
- What retention do we need for raw events?

### Good interview line

> "Before I design the clickstream pipeline, I want to clarify the event volume, freshness target, downstream use cases, and how much late client data we expect."

---

## Step 2: High-Level Design (2-3 min)

### Say this clearly

```text
Apps -> Event Collector -> Kafka/Kinesis -> Stream Processing -> S3 + Real-Time Serving
```

### Short explanation you can speak

1. Web and mobile apps emit events to a collector
2. The collector validates and publishes to Kafka/MSK or Kinesis
3. A stream processor deduplicates, enriches, and aggregates events
4. Raw events are archived to S3
5. Real-time metrics go to serving systems
6. Curated lake tables support offline analytics and data science

### Architecture

```text
Web / Mobile Apps
       |
  Event Collector API
       |
 Kafka (MSK) / Kinesis
       |
 Stream Processing Layer
       |            \
       |             \--> Real-Time Aggregates
       |                    |
    Raw S3              Redshift / OpenSearch
       |
  Curated Lake Tables
       |
 Athena / BI / Data Science
```

### Good interview line

> "My design has an event collector in front, a durable stream for buffering, a processing layer for real-time metrics, and S3 as the long-term raw and replay store."

---

## Step 3: Deep Dive (This Is Where You Win)

### A. Event Design and Collection

#### What each event should contain

- `event_id`
- `event_type`
- `user_id` or anonymous ID
- `session_id` if available
- `event_time`
- app or page metadata
- schema version

#### Why schema standardization matters

- easier downstream parsing
- easier evolution
- fewer bad events

### Good interview line

> "I would standardize event names and include metadata like event ID, event time, user ID, and schema version so the downstream pipeline is more reliable."

---

### B. Processing and Sessionization

#### What stream processing does

- deduplicate by `event_id`
- normalize events
- enrich payloads
- compute near-real-time metrics

#### Typical metrics

- page views
- active users
- clicks per campaign
- conversion rate

#### Sessionization

Typical rule:

- same user
- gap less than 30 minutes

Example:

```text
10:00 view
10:05 click
10:18 add_to_cart
11:10 return

Session 1 = 10:00, 10:05, 10:18
Session 2 = 11:10
```

### Good interview line

> "A common follow-up is sessionization, so I would define a session by user and inactivity gap, often 30 minutes, and build curated session tables instead of forcing analysts to rebuild sessions every time."

---

### C. Late Events, Duplicates, and Replay

#### Duplicates

- mobile retries can resend the same event
- deduplicate using `event_id`

#### Late-arriving events

- clients may buffer and send later
- use event time and watermarks

#### Why archive raw events to S3?

- replay
- debugging
- offline recomputation
- compliance and audit

### Good interview line

> "In clickstream systems, duplicates and late events are normal, so I would use event-time processing, dedupe by event ID, and always archive raw events to S3."

---

### D. Serving and Curated Analytics

#### Real-time outputs

- Redshift for dashboards
- OpenSearch for operational exploration
- alerting systems for anomalies

#### Curated outputs

- session tables
- funnel tables
- user journey tables
- campaign performance

### Good interview line

> "I would separate real-time aggregates from offline curated analytics, because dashboards and historical recomputation have different latency and cost requirements."

---

## Step 4: Scaling

### Main scaling points

#### Partitioning

- partition stream by `user_id` or `session_id`
- helps ordering and session reconstruction

#### Efficient event design

- compact schema
- lightweight collector
- avoid heavy per-event blocking logic

#### Serving scale

- pre-aggregate high-volume metrics
- separate hot real-time use cases from slower offline jobs

### Good interview line

> "To scale, I would partition by user or session key, keep the collector lightweight, and pre-aggregate expensive metrics before loading dashboards."

---

## Step 5: Trade-Offs

### Example trade-offs

#### Real-time vs offline recomputation

- real-time gives freshness
- offline jobs give more complete and cheaper historical recomputation

#### Rich event payloads vs smaller events

- richer payloads help downstream consumers
- but increase network and processing cost

#### Strict correctness vs simpler operations

- stronger correctness may need more complex dedupe and watermark logic
- simpler systems are easier to operate

### Good interview line

> "I would separate real-time aggregates from offline recomputation, because not every clickstream metric needs the same freshness, and this keeps the architecture simpler and cheaper."

---

## Strong 2-Minute Answer Script

> "First, I would clarify the event volume, latency target, downstream consumers, and how much late mobile data we expect. My design would have web and mobile apps sending events to a collector API, which validates basic payloads and publishes them into Kafka, MSK, or Kinesis. A stream processing layer would deduplicate events using `event_id`, normalize payloads, enrich them, and compute near-real-time metrics such as active users, page views, and conversion rates.
>
> I would archive all valid raw events to S3 because replay and offline analytics are critical in clickstream systems. On top of that, I would build curated lake datasets such as sessions, funnels, and user journeys. For real-time serving, I would write aggregates to systems like Redshift or OpenSearch depending on the use case.
>
> In the deep dive, I would focus on partitioning by `user_id` or `session_id`, sessionization rules, and late-event handling using event time and watermarks. For scale, I would keep the collector lightweight, increase partitions as needed, and pre-aggregate hot metrics. The main trade-off is that real-time analytics improves freshness, but a lot of heavy historical analytics is still better done offline using the archived raw data in S3."

---

## Common Failure Cases

### Duplicate events

- deduplicate using `event_id`

### Late-arriving events

- use event-time windows and watermarks

### Bad event schema

- send malformed events to quarantine or DLQ

### Traffic spike

- increase partitions and consumer parallelism
- keep collector lightweight

---

## Interview Tips

- This is one of the most common streaming questions
- Mention **sessionization**, **funnels**, and **late mobile events**
- Always say **raw events must be archived to S3**
- Discuss **dedupe by event_id**
- Explain the difference between real-time aggregates and offline recomputation

---

## Quick Revision (5 points)

1. Clarify event volume, latency, and downstream consumers first
2. Explain the flow as `Apps -> Collector -> Kafka/Kinesis -> Processing -> S3 + Serving`
3. Deep dive on sessionization, dedupe, and late data
4. Mention raw S3 archival, curated session/funnel tables, and pre-aggregation
5. Close with freshness vs complexity trade-offs
