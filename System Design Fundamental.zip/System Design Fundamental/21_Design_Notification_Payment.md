# Design Notification + Payment System

> **Notification = Right message, right time, right channel**
> **Payment = Paise ka mamla — idempotency aur consistency MUST hai!**

---

## Table of Contents

1. [Part 1 — Notification System](#part-1--notification-system)
2. [Part 2 — Payment System](#part-2--payment-system)
3. [1 Minute Recall Block + 5 Bullet Memory Hooks](#1-minute-recall-block--5-bullet-memory-hooks)

---

# Part 1 — Notification System

## 1.1 Requirements Clarification

### Functional Requirements

```
NOTIFICATION TYPES
│
├── Push Notification (Mobile)
│   ├── APNs (Apple)
│   └── FCM (Firebase - Android)
│
├── SMS
│   └── Twilio, AWS SNS
│
├── Email
│   └── SendGrid, SES, SMTP
│
└── In-App
    └── WebSocket / Polling
```

### Non-Functional Requirements

| Requirement | Target |
|-------------|--------|
| **Delivery rate** | > 99% |
| **Latency** | < 5 sec (push), < 30 sec (email) |
| **Rate limiting** | Per user, per channel |
| **Retry** | Failed → DLQ → Retry |

### Real-World Analogy — Post Office

```
POST OFFICE (Notification System)
══════════════════════════════════

Letter (Event) → Post Office (Notification Service) → Route by type
                                                          │
                    ┌─────────────────────────────────────┼─────────────────────┐
                    ▼                                     ▼                     ▼
              Speed Post (Push)                    Registered (Email)     Courier (SMS)
              Fast, immediate                      Reliable, track        Urgent, short
```

---

## 1.2 High Level Design — Notification System

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                 NOTIFICATION SYSTEM                           │
                    └─────────────────────────────────────────────────────────────┘

[Event] Order placed, Payment done, etc.
    │
    ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Event Producer │────▶│  Message Queue   │────▶│  Notification   │
│  (Order Service)│     │  (Kafka/SQS)     │     │  Worker         │
└─────────────────┘     └─────────────────┘     └────────┬────────┘
                                                          │
                                                          │ 1. Check user prefs
                                                          │ 2. Select channel
                                                          │ 3. Apply template
                                                          │ 4. Rate limit check
                                                          ▼
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    CHANNEL ROUTER                             │
                    └─────────────────────────────────────────────────────────────┘
                                        │
        ┌───────────────────────────────┼───────────────────────────────┐
        ▼                               ▼                               ▼
┌───────────────┐             ┌───────────────┐             ┌───────────────┐
│  Push Service │             │  Email Service│             │  SMS Service  │
│  (APNs, FCM)  │             │  (SendGrid)   │             │  (Twilio)     │
└───────┬───────┘             └───────┬───────┘             └───────┬───────┘
        │                             │                             │
        ▼                             ▼                             ▼
   [User Device]                 [User Inbox]                  [User Phone]
```

---

## 1.3 API Design — Notification

```
POST /api/v1/notifications/send
  Request: {
    user_id,
    template_id,
    channel: "push" | "email" | "sms",
    data: { key: value },  // Template variables
    priority: "high" | "normal" | "low"
  }
  Response: { notification_id, status }

GET /api/v1/notifications/preferences/{user_id}
PUT /api/v1/notifications/preferences/{user_id}
  // Opt-in/opt-out per channel, category
```

---

## 1.4 Data Model — Notification

```sql
-- Templates
CREATE TABLE notification_templates (
    template_id VARCHAR(50) PRIMARY KEY,
    channel ENUM('push', 'email', 'sms'),
    subject VARCHAR(255),  -- For email
    body_template TEXT,
    created_at TIMESTAMP
);

-- User preferences
CREATE TABLE user_notification_prefs (
    user_id BIGINT,
    channel VARCHAR(20),
    category VARCHAR(50),  -- order, marketing, etc.
    enabled BOOLEAN,
    PRIMARY KEY (user_id, channel, category)
);

-- Notification log (for retry, analytics)
CREATE TABLE notifications (
    id BIGINT PRIMARY KEY,
    user_id BIGINT,
    channel VARCHAR(20),
    template_id VARCHAR(50),
    status ENUM('pending', 'sent', 'failed', 'delivered'),
    provider_response TEXT,
    created_at TIMESTAMP,
    INDEX idx_user_status (user_id, status)
);
```

---

## 1.5 Deep Dive — Key Components

### Priority Levels

```
PRIORITY QUEUES
═══════════════

High:   OTP, Password reset → Immediate, retry 3x
Normal: Order confirmation → Within 1 min
Low:    Marketing, newsletter → Batch, can delay
```

### Rate Limiting

```
RATE LIMIT PER USER
═══════════════════

Push: 10/hour (spam avoid)
SMS:  5/day (cost + carrier limit)
Email: 20/day (inbox protection)

Redis: user:{id}:notif_count → INCR, EXPIRE
```

### Template System

```
TEMPLATE EXAMPLE
════════════════

template_id: "order_confirmed"
channel: email
subject: "Order {{order_id}} confirmed!"
body: "Hi {{user_name}}, your order of Rs {{amount}} is confirmed."

Data: { order_id: "123", user_name: "Rahul", amount: "999" }
→ Rendered: "Hi Rahul, your order of Rs 999 is confirmed."
```

### Retry and DLQ

```
RETRY FLOW
══════════

Send → Failed (provider error)
    │
    ▼
Retry 1 (after 1 min)
    │
    ▼
Retry 2 (after 5 min)
    │
    ▼
Retry 3 (after 15 min)
    │
    ▼
Still failed → Dead Letter Queue (DLQ)
    │
    ▼
Manual review / Alert
```

---

## 1.6 Scaling — Notification System

| Strategy | How |
|----------|-----|
| **Queue per channel** | Push queue, Email queue, SMS queue — separate workers |
| **Workers** | Scale workers per queue based on lag |
| **Provider fallback** | Primary FCM down → fallback to alternate |
| **Analytics** | Delivery rate, open rate — monitor per template |

---

# Part 2 — Payment System

## 2.1 Requirements Clarification

### Functional Requirements

```
PAYMENT FLOW
│
├── Initiate payment
├── Process (gateway)
├── Webhook (async confirmation)
├── Refund
└── Reconciliation
```

### Non-Functional (CRITICAL)

| Requirement | Why |
|-------------|-----|
| **Idempotency** | Double charge = disaster! Same request = same result |
| **Consistency** | Money balance kabhi inconsistent nahi |
| **Audit** | Har transaction log, immutable |

---

## 2.2 High Level Design — Payment System

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    PAYMENT SYSTEM                           │
                    └─────────────────────────────────────────────────────────────┘

[User] Pay Rs 500
    │
    ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Payment API    │────▶│  Idempotency    │────▶│  Payment        │
│  (idempotency   │     │  Check (Redis)  │     │  Service        │
│   key in header)│     │  Key exists?    │     │                 │
└─────────────────┘     │  → Return cached│     └────────┬────────┘
                        └─────────────────┘              │
                                                         │ Create payment record
                                                         │ State: INITIATED
                                                         ▼
                        ┌─────────────────────────────────────────────┐
                        │           PAYMENT GATEWAY                    │
                        │  (Razorpay, Stripe, PayU)                    │
                        └─────────────────────┬───────────────────────┘
                                              │
                                              ▼
                        ┌─────────────────────────────────────────────┐
                        │           BANK / CARD NETWORK                │
                        └─────────────────────┬───────────────────────┘
                                              │
                                              │ Webhook (async)
                                              ▼
                        ┌─────────────────┐     ┌─────────────────┐
                        │  Webhook        │────▶│  Update payment │
                        │  Handler        │     │  state, Ledger   │
                        └─────────────────┘     └─────────────────┘
```

---

## 2.3 Payment States (State Machine)

```
PAYMENT STATE MACHINE
═════════════════════

    INITIATED ──▶ PROCESSING ──▶ COMPLETED
         │              │
         │              └──────▶ FAILED
         │
         └─────────────────────▶ CANCELLED

COMPLETED ──▶ REFUNDED (partial/full)
```

### State Transitions

| From | To | Trigger |
|------|-----|---------|
| INITIATED | PROCESSING | Sent to gateway |
| PROCESSING | COMPLETED | Webhook: success |
| PROCESSING | FAILED | Webhook: failed / Timeout |
| INITIATED | CANCELLED | User cancel / Timeout |
| COMPLETED | REFUNDED | Refund request |

---

## 2.4 Idempotency (CRITICAL!)

```
IDEMPOTENCY — Same request = Same result
════════════════════════════════════════

Problem: User double-clicks "Pay" → 2 requests → 2 charges? NO!

Solution: Idempotency Key
  - Client sends: Idempotency-Key: "order_123_pay_xyz"
  - Server: First request → Process, store result in Redis
  - Server: Same key again → Return cached result, DON'T process again

  Redis: idempotency:{key} → { response, status }
  TTL: 24 hours
```

```
FLOW WITH IDEMPOTENCY
═════════════════════

Request 1 (key=K1): Process → Charge → Store result for K1
Request 2 (key=K1): Check K1 exists → Return stored result, NO charge
```

---

## 2.5 API Design — Payment

```
POST /api/v1/payments
  Headers: Idempotency-Key: <unique_key>
  Request: {
    order_id,
    amount_in_paise,
    currency: "INR",
    method: "card" | "upi" | "netbanking",
    user_id
  }
  Response: {
    payment_id,
    status: "initiated" | "processing",
    gateway_url  // Redirect user to gateway
  }

GET /api/v1/payments/{payment_id}
  Response: { status, amount, created_at, ... }

POST /api/v1/payments/{payment_id}/refund
  Request: { amount_in_paise, reason }
```

---

## 2.6 Data Model — Payment

```sql
CREATE TABLE payments (
    payment_id UUID PRIMARY KEY,
    order_id VARCHAR(50) NOT NULL,
    user_id BIGINT NOT NULL,
    amount_paise BIGINT NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    status ENUM('INITIATED', 'PROCESSING', 'COMPLETED', 'FAILED', 'CANCELLED', 'REFUNDED'),
    gateway_payment_id VARCHAR(100),  -- Gateway's reference
    gateway_response JSONB,
    idempotency_key VARCHAR(100) UNIQUE,  -- Critical!
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    INDEX idx_order (order_id),
    INDEX idx_user (user_id),
    INDEX idx_status (status)
);

-- Ledger (double-entry, simplified)
CREATE TABLE ledger_entries (
    id BIGINT PRIMARY KEY,
    payment_id UUID,
    account_type VARCHAR(50),  -- user_wallet, revenue, etc.
    amount_paise BIGINT,  -- + credit, - debit
    balance_after BIGINT,
    created_at TIMESTAMP
);
```

---

## 2.7 Webhook Handling

```
WEBHOOK — Gateway calls US when payment done
═══════════════════════════════════════════

1. Gateway sends POST to our /webhooks/razorpay
2. Verify signature (HMAC) — CRITICAL! Fraud prevent
3. Idempotent: Same webhook twice? Process once (webhook_id)
4. Update payment status
5. Trigger downstream (order confirm, etc.)
6. Return 200 quickly — Gateway retries on non-2xx
```

---

## 2.8 Ledger & Double-Entry (Basics)

```
DOUBLE-ENTRY BOOKKEEPING
════════════════════════

Every transaction = 2 entries (debit + credit)

User pays Rs 100:
  Debit:  User wallet -100
  Credit: Company revenue +100

Balance always = 0 (sum of all entries)
Reconciliation = Ledger vs Bank statement match
```

---

## 2.9 Fraud Detection (Basics)

```
FRAUD SIGNALS
═════════════

- Velocity: Too many payments in short time
- Amount: Unusual high amount
- Location: Login from new country, payment from same
- Device: New device
- ML: Historical patterns

Action: Flag → Manual review / Block
```

---

## 2.10 PCI Compliance (Overview)

```
PCI DSS — Card data handle karte waqt
════════════════════════════════════

- Card number store mat karo (use tokenization)
- Gateway token deta hai (e.g., card_xxx)
- HTTPS everywhere
- Access logs, audit
- Use certified gateway (Razorpay, Stripe) — they handle PCI
```

---

## 2.11 Retry with Idempotency

```
RETRY SAFETY
════════════

Client retries (network failure) with SAME idempotency key
→ Server: Already processed? Return same result
→ No double charge
```

---

# 1 Minute Recall Block + 5 Bullet Memory Hooks

## Notification System

> **Notification = Event → Queue → Worker → Channel Router → APNs/FCM/Email/SMS**
> Template + user preferences + rate limit. Retry → DLQ. Queue per channel for scaling.

**5 Hooks:**
1. **Multi-channel** — Push, Email, SMS, In-app
2. **Template + data** — Variables replace
3. **Rate limit** — Per user, per channel
4. **Retry → DLQ** — Failed notifications
5. **User prefs** — Opt-in/opt-out

## Payment System

> **Payment = Idempotency key MUST + State machine + Webhook + Ledger**
> Same request = same result. Webhook verify signature. Double-entry for reconciliation.

**5 Hooks:**
1. **Idempotency key** — No double charge, Redis store
2. **State machine** — INITIATED → PROCESSING → COMPLETED/FAILED
3. **Webhook** — Gateway calls us, verify HMAC
4. **Ledger** — Double-entry, audit trail
5. **PCI** — Don't store card, use tokenization

---

*End of Notification + Payment Design — FAANG Interview Ready!*
