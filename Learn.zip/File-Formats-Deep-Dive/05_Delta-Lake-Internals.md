# 05 — Delta Lake Internals

> Delta Lake adds **ACID transactions**, **time travel**, and **schema enforcement** to Parquet files using a **JSON transaction log** (`_delta_log/`) — turning a plain collection of Parquet files into a reliable **lakehouse** table.

---

## 1. What Is Delta Lake

Delta Lake is not a file format — it's a **table format** (also called a storage layer). The data files are standard Parquet. Delta Lake's intelligence is entirely in the `_delta_log/` directory, which tracks every change as an ordered sequence of JSON log entries.

```
Regular Parquet directory:                Delta Lake directory:
  /orders/                                  /orders/
    part-00000.parquet                        part-00000.snappy.parquet
    part-00001.parquet                        part-00001.snappy.parquet
    part-00002.parquet                        part-00002.snappy.parquet
    (no coordination, no ACID)                _delta_log/                     ← THE MAGIC
                                                00000000000000000000.json
                                                00000000000000000001.json
                                                00000000000000000002.json
                                                00000000000000000010.checkpoint.parquet
```

| Property | Detail |
|----------|--------|
| **Created by** | Databricks (2019), now Linux Foundation project |
| **Data files** | Standard Parquet (any Parquet reader can read individual files) |
| **Metadata** | `_delta_log/` — JSON files + periodic Parquet checkpoints |
| **Key capabilities** | ACID transactions, time travel, schema enforcement, OPTIMIZE, Z-ORDER, MERGE |

---

## 2. Transaction Log — The Core Innovation

The transaction log is a sequence of JSON files, each representing one atomic commit (version).

### What Each Log Entry Contains

```json
// _delta_log/00000000000000000001.json
{"commitInfo": {
    "timestamp": 1711900000000,
    "operation": "WRITE",
    "operationParameters": {"mode": "Append"}
}}
{"add": {
    "path": "part-00003.snappy.parquet",
    "size": 134217728,
    "modificationTime": 1711900000000,
    "dataChange": true,
    "stats": "{\"numRecords\":100000,\"minValues\":{\"amount\":1},\"maxValues\":{\"amount\":99999}}"
}}
{"remove": {
    "path": "part-00001.snappy.parquet",
    "deletionTimestamp": 1711900000000,
    "dataChange": true
}}
```

### Log Entry Action Types

| Action | Meaning |
|--------|---------|
| **add** | New Parquet file becomes part of the table |
| **remove** | Parquet file is logically deleted (no longer part of current table state) |
| **metaData** | Schema change, partition columns change, table properties update |
| **txn** | Application-level transaction ID (enables idempotent writes) |
| **protocol** | Reader/writer protocol version requirements |
| **commitInfo** | Who committed, when, what operation, parameters |

### How a Read Works — Building Table State

```
Reader wants the current table state:

1. Find latest checkpoint (e.g., version 10 checkpoint — a Parquet file)
2. Read checkpoint → get baseline list of active files
3. Read subsequent JSON log entries (11, 12, 13, ... up to latest)
4. Replay adds and removes → compute current set of valid Parquet files
5. Read only those Parquet files

Current state = Checkpoint + subsequent log entries
```

**Deep concept — Why Checkpoints Exist:**
Without checkpoints, reading a table with 10,000 versions would require reading 10,000 JSON files. A checkpoint (created every 10 versions by default) is a single Parquet file that captures the full table state at that version. The reader only needs to read the checkpoint + the few log entries after it. This keeps read latency constant regardless of table age.

**Deep concept — Stats in the Log:**
Each `add` action includes data-level statistics (min, max, null count per column) extracted from the Parquet file. This enables **data skipping at the file level** without reading any Parquet footers. Delta reads the log, checks stats, and skips files that can't match the filter — before opening any data files.

---

## 3. ACID Guarantees — How They Work

| Property | How Delta Achieves It |
|----------|----------------------|
| **Atomicity** | Each commit is a single JSON file write — it either fully exists or doesn't |
| **Consistency** | Schema enforcement rejects writes that don't match the table schema |
| **Isolation** | Optimistic concurrency control — writers don't block readers, conflicts detected at commit time |
| **Durability** | Files on cloud storage (S3, ADLS, GCS) with built-in durability |

### Optimistic Concurrency Control

```
Writer A: reads version 5 → does work → tries to commit as version 6
Writer B: reads version 5 → does work → tries to commit as version 6

Who wins? Whoever writes 00000000000000000006.json to storage first.

Loser: 
  1. Reads version 6 (winner's commit)
  2. Checks for conflicts:
     - No conflict (modified different partitions) → re-commit as version 7
     - Conflict (modified same files) → FAIL → must retry or error
```

**How to explain it:** "Delta uses optimistic concurrency — it assumes conflicts are rare. Both readers and writers proceed without blocking. Conflicts are detected only at commit time by checking if anyone else committed first. If there's no conflict (different data touched), it automatically retries. If there is a conflict, it fails and the application must handle it."

---

## 4. Time Travel

Every version of the table is preserved as long as the underlying Parquet files haven't been physically deleted by VACUUM.

```python
# Read a specific version
df = spark.read.format("delta").option("versionAsOf", 5).load("/orders/")

# Read as of a timestamp
df = spark.read.format("delta").option("timestampAsOf", "2024-01-15").load("/orders/")

# View full table history
from delta.tables import DeltaTable
dt = DeltaTable.forPath(spark, "/orders/")
dt.history().show()
```

### How It Works Internally

```
Want version 5?
  → Read log entries 0–5 (or latest checkpoint before 5 + entries up to 5)
  → Build file list as of version 5
  → Read those Parquet files (still physically on disk)

Files from old versions are NOT deleted until VACUUM runs.
```

---

## 5. OPTIMIZE — File Compaction

### The Problem

Streaming appends, frequent small writes, and over-partitioning create thousands of tiny Parquet files. Each file = one Spark task = scheduling overhead dominates actual work.

```
Before OPTIMIZE:
  /orders/
    part-00000.parquet  (1 MB)
    part-00001.parquet  (2 MB)
    part-00002.parquet  (500 KB)
    ... (thousands of tiny files)

After OPTIMIZE:
  /orders/
    part-00000-compacted.parquet  (128 MB)
    part-00001-compacted.parquet  (128 MB)
    (old files logically removed in log, physically removed by VACUUM later)
```

```sql
-- Compact all files
OPTIMIZE orders;

-- Compact only one partition (more efficient)
OPTIMIZE orders WHERE date = '2024-01-15';
```

---

## 6. Z-ORDER — Multi-Dimensional Data Clustering

### The Problem

A table has queries that filter on **both** `customer_id` AND `order_date`. You can only sort data by one column. Sorting by `customer_id` makes `order_date` ranges overlap across files and vice versa.

### The Solution

Z-ORDER interleaves the bits of multiple columns into a single sort key, clustering data in **both dimensions simultaneously**.

```
Z-ORDER interleaves bits of multiple columns:

  customer_id: [1, 2, 3, 4]       Z-value: interleave bits of
  order_date:  [D1, D2, D3, D4]   both columns into one value

Result: Files are clustered in BOTH dimensions.
Queries filtering on EITHER column (or both) get good data skipping.
```

```sql
OPTIMIZE orders ZORDER BY (customer_id, order_date);
```

**Deep concept — How many columns to Z-ORDER:**
Z-ORDER works best with 2–4 columns. Adding more columns dilutes the clustering effect — each additional column spreads the data thinner across dimensions. Pick the columns most commonly used in WHERE clauses.

### Z-Order vs Snowflake Clustering

| Feature | Delta Z-Order | Snowflake Clustering |
|---------|--------------|---------------------|
| **When** | Manual — run `OPTIMIZE ... ZORDER BY` | Automatic — background reclustering |
| **Cost** | Compute cost of rewriting files | Automatic compute cost (Snowflake credits) |
| **Columns** | 2–4 recommended | 2–4 recommended |
| **Monitoring** | `DESCRIBE DETAIL table` | `SYSTEM$CLUSTERING_INFORMATION()` |

---

## 7. VACUUM — Physical File Cleanup

```sql
-- Remove files older than 7 days that are no longer in current table state
VACUUM orders RETAIN 168 HOURS;

-- Default retention: 7 days (168 hours)
```

### VACUUM vs Time Travel — The Fundamental Tension

```
VACUUM RETAIN 24 HOURS   → Can only time-travel 24 hours back → less storage
VACUUM RETAIN 720 HOURS  → Can time-travel 30 days back → more storage

Trade-off: Storage cost ↔ Time travel window
```

After VACUUM runs, the physical Parquet files for old versions are permanently deleted. Time travel to versions older than the retention period becomes **impossible**.

**How to explain it:** "VACUUM and time travel are in tension. Aggressive VACUUM saves storage but destroys history. Set retention based on business needs — typically 7 days for operational tables, 30 days for audit-critical tables."

---

## 8. Schema Enforcement & Evolution

| Feature | Behavior |
|---------|----------|
| **Schema enforcement** | Rejects writes with extra columns, wrong types, or missing non-nullable columns |
| **Schema evolution** | Explicitly allow new columns with `mergeSchema` option |
| **Auto merge** | `spark.databricks.delta.schema.autoMerge.enabled = true` — evolves automatically |

```python
# This FAILS — new column "discount" not in table schema
df_with_discount.write.format("delta").mode("append").save("/orders/")
# AnalysisException: A schema mismatch detected when writing to the Delta table

# This WORKS — explicitly merge schema
df_with_discount.write.format("delta") \
    .mode("append") \
    .option("mergeSchema", "true") \
    .save("/orders/")
```

**Deep concept — Schema enforcement vs evolution:**
Schema enforcement is the **default** — it protects against accidental schema drift. Schema evolution must be explicitly opted into. This is a deliberate design: in production pipelines, you want writes to fail loudly when the schema doesn't match, rather than silently adding columns and corrupting downstream expectations.

### Delta Write Modes

| Mode | Behavior | Typical Use |
|------|----------|-------------|
| **`errorifexists`** (default) | Fails if table already exists | First-time table creation |
| **`overwrite`** | Replaces all data (but previous versions remain for time travel) | Full refresh pipelines |
| **`append`** | Adds new data alongside existing data | Incremental / streaming loads |
| **`ignore`** | Does nothing if table exists | Idempotent initial loads |

**Dynamic partition overwrite** — overwrite only specific partitions, not the entire table:

```python
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")

df.write.format("delta") \
    .mode("overwrite") \
    .partitionBy("date") \
    .save("/orders/")
# Only partitions present in df are overwritten — other partitions remain untouched
```

### Other Important Delta Table Properties

| Property | Purpose |
|----------|---------|
| `delta.logRetentionDuration` | How long transaction log entries are kept (default 30 days) |
| `delta.deletedFileRetentionDuration` | How long deleted files are kept before VACUUM can remove them (default 7 days) |
| `delta.autoOptimize.optimizeWrite` | Automatically coalesce small files during writes (Databricks) |
| `delta.autoOptimize.autoCompact` | Automatically trigger small file compaction after writes (Databricks) |
| `delta.enableChangeDataFeed` | Enable Change Data Feed — track row-level changes (inserts, updates, deletes) |

---

## 9. MERGE (Upsert) — CDC and SCD Pattern

MERGE is how CDC events (e.g., from Debezium) are applied to Delta tables. One statement handles inserts, updates, and deletes.

```sql
MERGE INTO target_orders t
USING source_changes s
ON t.order_id = s.order_id
WHEN MATCHED AND s.op = 'update' THEN
    UPDATE SET t.amount = s.amount, t.status = s.status
WHEN MATCHED AND s.op = 'delete' THEN
    DELETE
WHEN NOT MATCHED THEN
    INSERT (order_id, amount, status) VALUES (s.order_id, s.amount, s.status);
```

**How MERGE works internally:**
1. Find matching rows by joining target and source on the merge key
2. For matched rows — apply UPDATE or DELETE logic
3. For unmatched source rows — INSERT
4. All changes are written as new Parquet files (adds) + logical deletes of old files (removes)
5. Committed atomically as a single version in the transaction log

---

## 10. Interview Questions & How to Answer

**Q: "What is Delta Lake?"**
> Delta Lake is an ACID storage layer on top of Parquet. Data files are standard Parquet. The `_delta_log/` directory contains a sequence of JSON files tracking every add and remove — giving you transactions, time travel, and schema enforcement on a data lake.

**Q: "How does the transaction log work?"**
> Each commit is a JSON file with add/remove actions. Checkpoints (Parquet files) are created every 10 versions to avoid reading thousands of JSON files. A read builds the current table state by: reading the latest checkpoint + replaying subsequent log entries.

**Q: "How does Delta achieve ACID?"**
> Atomicity: each commit is a single file write. Consistency: schema enforcement rejects mismatched writes. Isolation: optimistic concurrency — conflicts detected at commit time. Durability: files on cloud storage.

**Q: "What is OPTIMIZE and Z-ORDER?"**
> OPTIMIZE compacts small Parquet files into larger files (~128 MB). Z-ORDER clusters data across multiple columns simultaneously using bit-interleaving — so queries filtering on any of those columns get good data skipping. Use OPTIMIZE ZORDER BY for the 2–4 most frequently filtered columns.

**Q: "VACUUM vs Time Travel?"**
> VACUUM physically deletes old Parquet files that are no longer part of the current table state. This limits time travel to the retention window. They're in tension — aggressive VACUUM saves storage but destroys history.

**Q: "How does MERGE work?"**
> MERGE matches source rows against target rows on a key. Matched rows get updated or deleted. Unmatched source rows get inserted. Internally, it writes new Parquet files and logically removes old ones, committed atomically. This is the standard pattern for applying CDC events.

**Q: "Delta vs Iceberg?"**
> Delta Lake is Databricks-native with Z-ORDER clustering and Unity Catalog governance. Iceberg is engine-neutral with hidden partitioning, partition evolution, and column IDs for safe renames. Choose Delta for Databricks-heavy environments. Choose Iceberg for multi-engine environments (Snowflake + Spark + Trino).

---

## Key Takeaways

1. **Delta Lake** = Parquet files + `_delta_log/` (JSON transaction log). Data is standard Parquet — Delta adds ACID on top.
2. **Transaction log** = JSON files with add/remove actions. Checkpoints every 10 versions keep reads fast.
3. **Stats in the log** enable file-level data skipping without opening Parquet files.
4. **Optimistic concurrency** — writers don't block readers. Conflicts detected at commit time.
5. **Time travel** — read any historical version. Limited by VACUUM retention period.
6. **OPTIMIZE** compacts small files. **Z-ORDER** clusters data across 2–4 columns for multi-dimensional data skipping.
7. **VACUUM** physically deletes old files. Tension with time travel — balance storage cost vs history needs.
8. **Schema enforcement** (default) prevents bad writes. **Schema evolution** (`mergeSchema`) allows controlled changes.
9. **MERGE** = upsert pattern for CDC — handles INSERT/UPDATE/DELETE atomically in one statement.

---
