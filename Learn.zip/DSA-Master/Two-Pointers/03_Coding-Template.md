# Two Pointers — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.** Python + C++ + Rust for FAANG interviews.

---

## Template 1: Opposite-Direction (Sorted Array Pair Sum)

### Python
```python
def two_sum_sorted(arr, target):
    left, right = 0, len(arr) - 1

    while left < right:
        current = arr[left] + arr[right]
        if current == target:
            return [left + 1, right + 1]  # 1-indexed; adjust as needed
        if current < target:
            left += 1
        else:
            right -= 1

    return []  # No pair found
```

### C++
```cpp
vector<int> twoSumSorted(vector<int>& arr, int target) {
    int left = 0, right = arr.size() - 1;

    while (left < right) {
        int sum = arr[left] + arr[right];
        if (sum == target)
            return {left + 1, right + 1};
        if (sum < target)
            left++;
        else
            right--;
    }
    return {};
}
```

### Rust
```rust
/// &[i32] slice — borrows array, no ownership transfer. Two-pointer iteration on slices.
fn two_sum_sorted(arr: &[i32], target: i32) -> Vec<usize> {
    let mut left = 0usize;
    let mut right = arr.len().saturating_sub(1);

    while left < right {
        let sum = arr[left] + arr[right];
        match sum.cmp(&target) {
            std::cmp::Ordering::Equal => return vec![left + 1, right + 1],
            std::cmp::Ordering::Less => left += 1,
            std::cmp::Ordering::Greater => right -= 1,
        }
    }
    vec![]
}
```

**Rust Performance Note:** `&[i32]` is a fat pointer (ptr + len) — zero-copy, no allocation. Use `.saturating_sub(1)` to avoid underflow on empty slice.

---

## Template 2: Same-Direction (Fast/Slow — Linked List Cycle)

### Python
```python
def has_cycle(head):
    if not head or not head.next:
        return False

    slow = head
    fast = head.next

    while slow != fast:
        if not fast or not fast.next:
            return False
        slow = slow.next
        fast = fast.next.next

    return True
```

### C++
```cpp
bool hasCycle(ListNode* head) {
    if (!head || !head->next) return false;

    ListNode* slow = head;
    ListNode* fast = head->next;

    while (slow != fast) {
        if (!fast || !fast->next) return false;
        slow = slow->next;
        fast = fast->next->next;
    }
    return true;
}
```

### Rust
```rust
/// Linked list: Option<Box<ListNode>> — Option for null, Box for heap allocation.
/// Fast/slow pattern: slow moves 1 step, fast moves 2 steps.
use std::ptr;

struct ListNode {
    val: i32,
    next: Option<Box<ListNode>>,
}

fn has_cycle(head: Option<&ListNode>) -> bool {
    let Some(h) = head else { return false };
    let Some(n) = h.next.as_deref() else { return false };

    let mut slow: *const ListNode = h;
    let mut fast: *const ListNode = n;

    while !ptr::eq(slow, fast) {
        let f = unsafe { &*fast };
        let Some(nn) = f.next.as_deref() else { return false };
        let Some(nn2) = nn.next.as_deref() else { return false };
        slow = unsafe { &*slow }.next.as_deref().expect("slow has next");
        fast = nn2;  // slow += 1 step, fast += 2 steps
    }
    true
}
```

**Rust Note:** `Option<Box<ListNode>>` = null-safe singly-linked list. Cycle detection uses `ptr::eq()` for pointer comparison. `as_deref()` converts `&Option<Box<T>>` → `Option<&T>`.

---

## Template 3: Three Pointers (3Sum Pattern)

### Python
```python
def three_sum(arr, target=0):
    arr.sort()
    result = []
    n = len(arr)

    for i in range(n - 2):
        if i > 0 and arr[i] == arr[i - 1]:
            continue  # Skip duplicate i

        left, right = i + 1, n - 1
        while left < right:
            total = arr[i] + arr[left] + arr[right]
            if total == target:
                result.append([arr[i], arr[left], arr[right]])
                left += 1
                while left < right and arr[left] == arr[left - 1]:
                    left += 1
            elif total < target:
                left += 1
            else:
                right -= 1

    return result
```

### C++
```cpp
vector<vector<int>> threeSum(vector<int>& arr, int target = 0) {
    sort(arr.begin(), arr.end());
    vector<vector<int>> result;
    int n = arr.size();

    for (int i = 0; i < n - 2; i++) {
        if (i > 0 && arr[i] == arr[i - 1]) continue;

        int left = i + 1, right = n - 1;
        while (left < right) {
            int sum = arr[i] + arr[left] + arr[right];
            if (sum == target) {
                result.push_back({arr[i], arr[left], arr[right]});
                left++;
                while (left < right && arr[left] == arr[left - 1]) left++;
            } else if (sum < target) {
                left++;
            } else {
                right--;
            }
        }
    }
    return result;
}
```

### Rust
```rust
/// .sort() for i32; use .sort_by(|a, b| a.cmp(b)) for custom ordering.
fn three_sum(arr: &mut [i32], target: i32) -> Vec<Vec<i32>> {
    arr.sort();  // In-place sort, mutates slice
    let n = arr.len();
    let mut result = Vec::new();

    for i in 0..n.saturating_sub(2) {
        if i > 0 && arr[i] == arr[i - 1] {
            continue;
        }
        let mut left = i + 1;
        let mut right = n - 1;

        while left < right {
            let sum = arr[i] + arr[left] + arr[right];
            match sum.cmp(&target) {
                std::cmp::Ordering::Equal => {
                    result.push(vec![arr[i], arr[left], arr[right]]);
                    left += 1;
                    while left < right && arr[left] == arr[left - 1] {
                        left += 1;
                    }
                }
                std::cmp::Ordering::Less => left += 1,
                std::cmp::Ordering::Greater => right -= 1,
            }
        }
    }
    result
}
```

**Rust Performance Note:** `arr.sort()` uses pattern-defeating quicksort (pdqsort). For custom types, use `arr.sort_by_key(|x| x.field)` or `arr.sort_by(|a, b| a.cmp(b))`.

---

## Template 4: Partition (Dutch National Flag)

### Python
```python
def dutch_national_flag(arr):
    low, mid, high = 0, 0, len(arr) - 1

    while mid <= high:
        if arr[mid] == 0:
            arr[low], arr[mid] = arr[mid], arr[low]
            low += 1
            mid += 1
        elif arr[mid] == 1:
            mid += 1
        else:  # arr[mid] == 2
            arr[mid], arr[high] = arr[high], arr[mid]
            high -= 1
            # Do NOT increment mid — need to re-check swapped value
```

### C++
```cpp
void dutchNationalFlag(vector<int>& arr) {
    int low = 0, mid = 0, high = arr.size() - 1;

    while (mid <= high) {
        if (arr[mid] == 0) {
            swap(arr[low], arr[mid]);
            low++;
            mid++;
        } else if (arr[mid] == 1) {
            mid++;
        } else {
            swap(arr[mid], arr[high]);
            high--;
        }
    }
}
```

---

## Template 5: Remove Duplicates In-Place

### Python
```python
def remove_duplicates_inplace(arr):
    if not arr:
        return 0

    write = 1  # Next position to write unique element
    for read in range(1, len(arr)):
        if arr[read] != arr[read - 1]:
            arr[write] = arr[read]
            write += 1

    return write  # Length of unique portion
```

### C++
```cpp
int removeDuplicatesInplace(vector<int>& arr) {
    if (arr.empty()) return 0;

    int write = 1;
    for (int read = 1; read < arr.size(); read++) {
        if (arr[read] != arr[read - 1]) {
            arr[write] = arr[read];
            write++;
        }
    }
    return write;
}
```

---

## Template 6: Opposite-Direction (Palindrome Check)

### Python
```python
def is_palindrome(s):
    left, right = 0, len(s) - 1

    while left < right:
        if not s[left].isalnum():
            left += 1
            continue
        if not s[right].isalnum():
            right -= 1
            continue
        if s[left].lower() != s[right].lower():
            return False
        left += 1
        right -= 1

    return True
```

### C++
```cpp
bool isPalindrome(string& s) {
    int left = 0, right = s.size() - 1;

    while (left < right) {
        if (!isalnum(s[left])) { left++; continue; }
        if (!isalnum(s[right])) { right--; continue; }
        if (tolower(s[left]) != tolower(s[right])) return false;
        left++;
        right--;
    }
    return true;
}
```

### Rust
```rust
/// &str is UTF-8 — use .chars() for proper char iteration. Here we use as_bytes() for ASCII.
fn is_palindrome(s: &str) -> bool {
    let bytes = s.as_bytes();  // For ASCII; use s.chars().collect::<Vec<_>>() for Unicode
    let mut left = 0usize;
    let mut right = bytes.len().saturating_sub(1);

    while left < right {
        if !bytes[left].is_ascii_alphanumeric() {
            left += 1;
            continue;
        }
        if !bytes[right].is_ascii_alphanumeric() {
            right = right.saturating_sub(1);
            continue;
        }
        if bytes[left].to_ascii_lowercase() != bytes[right].to_ascii_lowercase() {
            return false;
        }
        left += 1;
        right = right.saturating_sub(1);
    }
    true
}
```

**Rust Note:** `u8::is_ascii_alphanumeric()` — method on primitive. For full Unicode, collect `s.chars()` into `Vec<char>` and use `char::to_lowercase()`.

---

## Template 7: Merge Two Sorted Arrays (In-Place or New Array)

### Python
```python
def merge_sorted(nums1, m, nums2, n):
    # nums1 has space for m+n elements
    p1, p2, write = m - 1, n - 1, m + n - 1

    while p1 >= 0 and p2 >= 0:
        if nums1[p1] >= nums2[p2]:
            nums1[write] = nums1[p1]
            p1 -= 1
        else:
            nums1[write] = nums2[p2]
            p2 -= 1
        write -= 1

    while p2 >= 0:
        nums1[write] = nums2[p2]
        p2 -= 1
        write -= 1
```

### C++
```cpp
void mergeSorted(vector<int>& nums1, int m, vector<int>& nums2, int n) {
    int p1 = m - 1, p2 = n - 1, write = m + n - 1;

    while (p1 >= 0 && p2 >= 0) {
        if (nums1[p1] >= nums2[p2])
            nums1[write--] = nums1[p1--];
        else
            nums1[write--] = nums2[p2--];
    }
    while (p2 >= 0)
        nums1[write--] = nums2[p2--];
}
```

### Rust
```rust
/// Merge nums2 into nums1 in-place. nums1 has capacity m+n; first m elements valid.
fn merge_sorted(nums1: &mut [i32], m: usize, nums2: &[i32], n: usize) {
    let mut p1 = m as i32 - 1;
    let mut p2 = n as i32 - 1;
    let mut write = (m + n) as i32 - 1;

    while p1 >= 0 && p2 >= 0 {
        if nums1[p1 as usize] >= nums2[p2 as usize] {
            nums1[write as usize] = nums1[p1 as usize];
            p1 -= 1;
        } else {
            nums1[write as usize] = nums2[p2 as usize];
            p2 -= 1;
        }
        write -= 1;
    }
    while p2 >= 0 {
        nums1[write as usize] = nums2[p2 as usize];
        p2 -= 1;
        write -= 1;
    }
}
```

**Rust Note:** Using `i32` for indices allows `>= 0` check (usize can't go negative). Cast to `usize` for indexing. Alternative: `checked_sub` or `saturating_sub` with `Option`.

---

## Template 8: Move Zeros to End (Partition Variant)

### Python
```python
def move_zeros(arr):
    write = 0  # Position for next non-zero
    for read in range(len(arr)):
        if arr[read] != 0:
            arr[write], arr[read] = arr[read], arr[write]
            write += 1
```

### C++
```cpp
void moveZeros(vector<int>& arr) {
    int write = 0;
    for (int read = 0; read < arr.size(); read++) {
        if (arr[read] != 0) {
            swap(arr[write], arr[read]);
            write++;
        }
    }
}
```

### Rust
```rust
/// Partition: move non-zeros to front. Vec<T> iteration with index.
fn move_zeros(arr: &mut [i32]) {
    let mut write = 0usize;
    for read in 0..arr.len() {
        if arr[read] != 0 {
            arr.swap(write, read);
            write += 1;
        }
    }
}
```

**Rust Note:** `arr.swap(i, j)` — O(1) swap. Same pattern as Dutch flag: single write pointer, scan with read.

---

## Quick Reference: Which Template?

| Problem Type | Template |
|-------------|----------|
| Two sum in sorted array | Template 1 (Opposite) |
| Linked list cycle | Template 2 (Fast/Slow) |
| 3Sum, 4Sum | Template 3 (Three pointers) |
| Sort 0s, 1s, 2s | Template 4 (Dutch Flag) |
| Remove duplicates (sorted) | Template 5 (Read/Write) |
| Valid palindrome | Template 6 (Opposite) |
| Merge sorted arrays | Template 7 (Two arrays) |
| Move zeros | Template 8 (Partition) |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Two Pointers Templates
OPPOSITE PAIR:      L=0, R=n-1; while L<R; move based on sum
FAST/SLOW:          slow, fast=slow.next; while slow!=fast
3SUM:               for i: two-pointer on [i+1..n]; skip dup i
DUTCH FLAG:         low, mid, high; 0→swap L,M; 1→M++; 2→swap M,H
REMOVE DUP:         write=1; for read: if arr[read]!=arr[read-1]
PALINDROME:         L,R from ends; skip non-alnum; compare
MERGE:              p1,p2 from end; write from m+n-1
MOVE ZEROS:         write=0; swap when arr[read]!=0
KEY RULE:           Opposite: move pointer that fixes constraint
                    Same: fast=2×slow for cycle
```

---

## Language Comparison Quick Reference

| Concept | Python | C++ | Rust |
|---------|--------|-----|------|
| Array/slice param | `list` | `vector<int>&` | `&[i32]` (slice) |
| Sort in-place | `arr.sort()` | `sort(arr.begin(), arr.end())` | `arr.sort()` |
| Swap elements | `a, b = b, a` | `swap(a, b)` | `arr.swap(i, j)` |
| Linked list node | `ListNode` | `ListNode*` | `Option<Box<ListNode>>` |
| Index type | `int` | `int` / `size_t` | `usize` |
| Avoid underflow | N/A | N/A | `saturating_sub(1)` |
| Null/empty | `None` / `[]` | `nullptr` / `{}` | `Option::None` / `vec![]` |

---

## 30-SECOND REVISION BOX

```
OPPOSITE:   L=0, R=n-1; while L<R; cmp sum→move L or R
FAST/SLOW:  slow, fast=2×step; ptr::eq for cycle
3SUM:       sort; for i, two-ptr [i+1..n]; skip dup i
DUTCH:      low,mid,high; match 0,1,2 → swap/move
REMOVE DUP: write=1; read from 1; if different → swap
PALINDROME: L,R; skip non-alnum; compare lower
MERGE:      p1,p2 from end; write from m+n-1
MOVE ZEROS: write=0; swap when arr[read]!=0
RUST:       &[i32], .sort(), .swap(), Option<Box<T>>
```
