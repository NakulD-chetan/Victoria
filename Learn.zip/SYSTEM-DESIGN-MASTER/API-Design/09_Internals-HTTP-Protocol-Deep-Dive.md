# Internals: HTTP Protocol Deep Dive — From HTTP/1.0 to HTTP/3

> **Permanent Recall:** HTTP/1.0 opens a new TCP connection for every request. HTTP/1.1 reuses the connection, but requests can block each other. HTTP/2 sends many requests together on one TCP connection and compresses headers. HTTP/3 uses QUIC over UDP, so one lost packet does not block every stream. Almost every API call uses HTTP, so HTTP internals directly affect latency and performance.

---

## 1. Why HTTP Kept Changing

HTTP improved version by version because the web kept getting heavier.

```text
HTTP/1.0 -> HTTP/1.1 -> HTTP/2 -> HTTP/3
```

### HTTP/1.0

- One request usually meant one new TCP connection.
- If a page needed HTML, CSS, JS, and images, the browser kept opening and closing connections.
- This added a lot of delay because each TCP connection needs a handshake first.

Simple idea:

```text
GET page.html -> close connection
GET style.css -> close connection
GET logo.png  -> close connection
```

### HTTP/1.1

- Added **keep-alive**, so the same TCP connection could be reused.
- This removed the cost of creating a new connection for every request.
- But responses still had an ordering problem called **head-of-line blocking**.

### HTTP/2

- Moved from plain text style messages to **binary frames**.
- Added **multiplexing**, which means many requests can travel together on one connection.
- Added **HPACK header compression** to reduce repeated headers.
- Still had one big problem: because it still uses **TCP**, packet loss can block all streams.

### HTTP/3

- Runs on **QUIC**, which itself runs over **UDP**.
- Fixes the TCP-level head-of-line blocking problem.
- Faster connection setup, especially on reconnect.
- Better for unstable networks like mobile internet.

---

## 2. HTTP/1.1 Basics

HTTP/1.1 is text-based. If you looked at it on the wire, it would look readable.

### Example request

```text
GET /api/v1/users/123 HTTP/1.1
Host: api.example.com
Accept: application/json
Authorization: Bearer eyJhbG...
Connection: keep-alive
Accept-Encoding: gzip, deflate

```

### Example response

```text
HTTP/1.1 200 OK
Content-Type: application/json
Content-Length: 85
Cache-Control: max-age=3600
ETag: "abc123"

{"id":123,"name":"John","email":"john@example.com"}
```

### Important points

- Headers are sent as text.
- Every request repeats many of the same headers.
- That repetition increases bandwidth usage.
- Text format is simple to debug, but not the most efficient.

---

## 3. Keep-Alive: Why HTTP/1.1 Was Better Than HTTP/1.0

In HTTP/1.0, every request often needed a new TCP handshake.

In HTTP/1.1, the client can reuse the same connection:

```text
Open TCP connection once
GET /users
GET /orders
GET /products
Close later
```

Why this matters:

- Fewer TCP handshakes
- Lower latency
- Less CPU and memory overhead

This is one reason HTTP/1.1 was a big improvement.

---

## 4. Head-of-Line Blocking in HTTP/1.1

This is the biggest weakness of HTTP/1.1.

Suppose the client sends 3 requests:

```text
GET /slow
GET /fast
GET /tiny
```

If the first one is slow, the later responses wait behind it.

```text
/slow  -> 5 seconds
/fast  -> must wait
/tiny  -> must wait
```

Even if `/fast` takes only 10 ms, it cannot come first if `/slow` is ahead of it on the same connection.

That waiting problem is called **head-of-line blocking**.

### Browser workaround

Browsers solved this partly by opening multiple TCP connections to the same host.

Example:

- 6 parallel connections to one domain
- More parallel downloads
- But also more memory, more handshakes, and more congestion overhead

This is why old websites often used tricks like multiple image domains.

---

## 5. HTTP/2: The Big Upgrade

HTTP/2 changed the internal format a lot.

### Core idea

Instead of sending one full text request and waiting, HTTP/2 splits communication into small **binary frames**.

Many frames from different requests can be mixed together on the same TCP connection.

That is called **multiplexing**.

### Simple mental model

```text
One TCP connection
  Stream 1 -> /users
  Stream 3 -> /orders
  Stream 5 -> /payment

Frames from all streams can be interleaved
```

So the connection may send data like:

```text
Stream 1 headers
Stream 3 headers
Stream 1 data
Stream 5 headers
Stream 3 data
Stream 1 data
```

This means HTTP/2 removes the HTTP/1.1 request-order bottleneck at the HTTP layer.

---

## 6. HTTP/2 Frame Format

Every HTTP/2 message is broken into frames.

Each frame has:

- a small header
- a payload

### Main fields in a frame header

- **Length**: payload size
- **Type**: what kind of frame it is
- **Flags**: extra information
- **Stream ID**: which request/response this frame belongs to

### Common frame types

- `DATA`: carries body data
- `HEADERS`: carries headers
- `SETTINGS`: connection settings
- `WINDOW_UPDATE`: flow control updates
- `PING`: health check
- `GOAWAY`: tells peer the connection is closing

### Example

For `GET /api/v1/users/123`, HTTP/2 may send:

1. A `HEADERS` frame for the request
2. A `HEADERS` frame for the response headers
3. A `DATA` frame for the response body

So instead of raw text lines, HTTP/2 uses structured binary pieces.

---

## 7. HPACK: Header Compression in HTTP/2

One major problem in HTTP/1.1 was repeated headers.

Example:

- `Host`
- `Accept`
- `Authorization`
- cookies

These same headers are often sent again and again.

HTTP/2 uses **HPACK** to compress them.

### HPACK works using 3 ideas

#### 1. Static table

Common headers are already known in advance.

For example, instead of sending:

```text
:method: GET
```

HTTP/2 can send a small index that means the same thing.

#### 2. Dynamic table

If a connection already sent a header once, it can remember it.

Example:

- First request sends full `authorization` header
- Later requests can send a short reference instead

#### 3. Huffman coding

Frequently used characters are encoded using fewer bits.

### Result

- First request becomes smaller
- Repeated requests become much smaller
- Less bandwidth is wasted on headers

This matters a lot for APIs making many requests.

---

## 8. Multiplexing in HTTP/2

Each request/response pair in HTTP/2 is called a **stream**.

### Important idea

- One stream = one request/response conversation
- Many streams can share one TCP connection
- Streams are identified by stream IDs

This allows the client to do multiple requests in parallel without opening many connections.

### Why this is useful

- better connection reuse
- fewer TCP handshakes
- better network utilization
- lower overhead for modern apps that make many small requests

---

## 9. Flow Control in HTTP/2

HTTP/2 also has **flow control**.

This means the receiver can limit how much data the sender sends at a time.

There are 2 levels:

- **per-stream flow control**
- **per-connection flow control**

Why this exists:

- prevents one huge response from flooding everything
- allows slower receivers to control incoming speed

Simple example:

- Stream 1 can still continue
- Stream 3 may pause if its window becomes full
- Sender waits for `WINDOW_UPDATE`

So flow control helps keep the connection fair and stable.

---

## 10. Stream Priority

HTTP/2 also lets the client say some streams are more important than others.

Example:

- critical CSS should load before images
- important API request before low-priority analytics request

This is called **stream prioritization**.

In practice, support and usage vary, but the idea is to improve user experience by serving important content first.

---

## 11. HTTP/2 Still Has a Problem: TCP Blocking

HTTP/2 fixed head-of-line blocking at the HTTP layer, but not at the TCP layer.

Why?

Because all HTTP/2 streams still travel inside one TCP connection, and TCP guarantees ordered delivery.

### Problem scenario

Suppose frames are being sent for many streams:

```text
Stream 1 packet A
Stream 3 packet B
Stream 1 packet C
Stream 5 packet D
```

If packet B is lost, TCP stops later packets from being delivered until B is retransmitted.

That means:

- Stream 1 is blocked
- Stream 5 is blocked
- Even though their data may already have arrived

This is why HTTP/3 was created.

---

## 12. HTTP/3 and QUIC

HTTP/3 uses **QUIC**, and QUIC runs over **UDP**.

### Stack comparison

```text
HTTP/1.1 -> TCP -> IP
HTTP/2   -> TCP -> IP
HTTP/3   -> QUIC -> UDP -> IP
```

### Why QUIC uses UDP

UDP itself is simple. QUIC builds the smart features in user space:

- reliable delivery
- congestion control
- encryption
- stream management

This makes QUIC easier to improve than TCP in the OS kernel.

### Big benefits of QUIC

- no TCP-style cross-stream blocking
- faster handshakes
- built-in TLS 1.3
- better reconnect behavior
- connection migration

---

## 13. No Cross-Stream Blocking in HTTP/3

QUIC tracks streams separately.

If one packet is lost for one stream, only that stream waits.

Example:

```text
Stream 1 -> keeps going
Stream 3 -> packet lost, retransmit needed
Stream 5 -> keeps going
```

This is the key reason HTTP/3 performs better on lossy or mobile networks.

---

## 14. 0-RTT and Faster Setup

Connection setup time matters a lot.

### Older approach

With TCP + TLS, a new secure connection may need multiple round trips before useful data can flow.

### QUIC approach

QUIC combines transport setup and TLS more tightly.

If the client has connected before, it may use **0-RTT resumption**.

That means:

- client remembers previous session information
- client can start sending data immediately
- reconnects become much faster

This reduces latency noticeably, especially over long-distance networks.

---

## 15. Connection Migration

TCP connections are tied closely to IP and port values.

So if your phone switches from Wi-Fi to mobile data, the TCP connection usually breaks and must be recreated.

QUIC uses a **connection ID**.

That means the network path can change while the logical connection stays alive.

This is useful for:

- mobile devices
- unstable networks
- roaming between networks

---

## 16. What Happens When You Call `fetch('/api/users')`

From the client side, the request usually goes through these steps:

1. DNS lookup finds the server IP.
2. A transport connection is created.
3. TLS sets up encryption if HTTPS is used.
4. The HTTP request is sent.
5. Server processes it and sends a response.
6. Connection is reused or closed.

### Latency idea

For the first request, total time often includes:

- DNS time
- connection setup
- TLS handshake
- request/response round trip

That is why connection reuse is so important.

If the connection is already open:

- later requests are much faster

This is also why HTTP/2 and HTTP/3 help so much in real systems.

---

## 17. How HTTP/2 Connection Setup Happens

Most of the time, HTTP/2 is chosen during the TLS handshake using **ALPN**.

### Simple flow

- Client says: "I support `h2` and `http/1.1`."
- Server says: "Use `h2`."
- After TLS finishes, both sides speak HTTP/2.

There is also an older upgrade path called `h2c`, but it is uncommon on the public internet.

After negotiation, both sides exchange `SETTINGS` frames and the connection becomes ready for streams.

---

## 18. Overhead Comparison

### HTTP/1.1

- Headers are plain text
- Repeated again and again
- Large headers like cookies or auth tokens add a lot of overhead

### HTTP/2

- Binary framing
- HPACK compression
- Repeated headers become much smaller

### Practical effect

At small scale, the savings may look minor.

At large scale, across millions of API calls:

- lower bandwidth use
- lower latency
- better throughput

This is one reason modern APIs prefer HTTP/2 or HTTP/3 when possible.

---

## 19. Server Push in HTTP/2

HTTP/2 introduced **server push**.

Idea:

- client asks for HTML page
- server also sends CSS or JS before the client explicitly asks

This can reduce wait time in theory.

### Why it was not widely loved

- browser may already have the file cached
- server might push the wrong thing
- wasted bandwidth is possible

Because of these issues, server push is much less important today and has mostly been replaced in practice by other optimization techniques like `103 Early Hints`.

---

## 20. Quick Comparison Table

| Version | Main Idea | Main Benefit | Main Problem |
|---|---|---|---|
| HTTP/1.0 | New TCP per request | Simple | Very slow for many resources |
| HTTP/1.1 | Reuse TCP connection | Lower setup cost | Head-of-line blocking |
| HTTP/2 | Multiplexing on one TCP connection | Better parallelism, smaller headers | TCP packet loss still blocks streams |
| HTTP/3 | QUIC over UDP | No TCP cross-stream blocking, faster setup | More complex implementation |

---

## 21. 30-Second Revision Box

```text
HTTP/1.0:
- usually one TCP connection per request
- slow because of repeated handshakes

HTTP/1.1:
- keep-alive reuses connection
- still has head-of-line blocking

HTTP/2:
- binary frames instead of plain text
- multiplexing: many streams on one TCP connection
- HPACK compresses headers
- still suffers if TCP loses a packet

HTTP/3:
- uses QUIC over UDP
- one lost packet does not block all streams
- faster reconnects and better mobile performance
```

---

**Prev: [[08_Question-List]] | Next: [[10_Internals-TLS-Handshake-Cryptography]]**