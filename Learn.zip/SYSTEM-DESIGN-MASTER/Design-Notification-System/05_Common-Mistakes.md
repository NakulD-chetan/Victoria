# Design Notification System — Common Mistakes

> **Permanent Recall:** Top mistakes = synchronous delivery, no rate limiting, ignoring user preferences, no retry, single queue for all channels, not handling device token updates, no deduplication, ignoring notification fatigue. Always treat notification system as a **pipeline with per-channel workers**.

---

## Top 8 Common Mistakes

| # | Mistake | Why It's Wrong | Correct Approach |
|---|---------|----------------|------------------|
| 1 | **Synchronous delivery** | 10B/day blocks API; timeout, poor scalability | Async: API enqueues; worker delivers; return 202 |
| 2 | **No rate limiting** | Spam, fatigue, cost explosion (SMS), provider throttling | Per-user, per-channel, global limits; Redis counters |
| 3 | **Ignoring user preferences** | Legal risk (CAN-SPAM, GDPR); bad UX | Check opt-in before send; respect per-channel, per-type |
| 4 | **No retry for failed deliveries** | Lost notifications; no at-least-once | Retry with backoff; dead-letter after N attempts |
| 5 | **Single queue for all channels** | Push needs <10s; email can wait; no isolation | Separate queue per channel; different workers |
| 6 | **Not handling device token updates** | Tokens invalidate (reinstall); sending to stale tokens | Remove on 410/InvalidRegistration; upsert on app launch |
| 7 | **No deduplication** | Retries → duplicate notifications for same event | Idempotency key; check before send; store in Redis |
| 8 | **Ignoring notification fatigue** | Too many notifications → users disable all | Rate limit marketing; batch digest option; respect prefs |

---

## Detailed Callouts

### Mistake 1: Synchronous Delivery

```
❌ API → Call Twilio → Wait for response → Return 200
    (Blocks; 10B/day = impossible; timeout risk)

✅ API → Enqueue to Kafka/SQS → Return 202 Accepted
    Worker (async) → Call Twilio → Track result
```

### Mistake 5: Single Queue for All Channels

```
❌ One queue: [push, SMS, email, push, email, ...]
    Push needs <10s; email can be delayed
    Push worker and SMS worker compete for same queue

✅ Push Queue → Push Worker → APNS/FCM
   SMS Queue  → SMS Worker  → Twilio
   Email Queue → Email Worker → SendGrid
```

> **FAANG Tip:** Separate queues let you scale workers independently and prioritize push over email.

### Mistake 7: No Deduplication

```
❌ Retry 3x due to timeout → User gets 3 "Order shipped" emails

✅ Idempotency key (user_id + event_id) → Redis
   Retry: Check key → exists? Return; don't send again
```

---

## Anti-Pattern Diagram

```
❌ BAD:
API ─► Call provider directly ─► Block until response
       (No queue, no retry, no rate limit, no prefs check)

✅ GOOD:
API ─► Idempotency check ─► Preferences ─► Rate limit ─► Queue
       Worker ─► Provider ─► Track ─► Retry or dead-letter
```

---

## What Interviewers Listen For

- **"We use async delivery with queues — never block the API"**
- **"We check user preferences before sending"**
- **"Rate limiting per user and per channel"**
- **"Idempotency key to prevent duplicates on retry"**
- **"Separate queues and workers per channel"**
- **"We handle device token invalidation"**

---

## Red Flags to Avoid

- "We call the provider directly from the API" — doesn't scale
- "We don't need rate limiting" — spam and cost
- "User preferences? We can add later" — legal and UX risk
- "One queue for everything" — no isolation, wrong priorities
- "We'll just retry — user might get duplicates" — bad UX
- "Device tokens don't change" — they do; APNS/FCM invalidate

---

## Mistake Severity

| Severity | Mistakes | Impact |
|----------|----------|--------|
| **Critical** | Sync delivery, no rate limit, no idempotency | System won't scale; duplicates; cost explosion |
| **Major** | Single queue, ignoring prefs | Poor architecture; legal risk |
| **Moderate** | No device token handling | Wasted sends; provider errors |
| **Minor** | No fatigue discussion | Shows less product sense |

---

## Correct Architecture Checklist

- [ ] Async delivery (queue + workers)
- [ ] Rate limiting (per-user, per-channel, global)
- [ ] User preference check before send
- [ ] Retry with backoff; dead-letter
- [ ] Separate queue per channel
- [ ] Idempotency for deduplication
- [ ] Device token management (register, update, invalidate)
- [ ] Pipeline: Decide → Format → Deliver → Track
