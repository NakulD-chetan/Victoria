/**
 * Frame scheduler with dirty flags.
 *
 * Invariants:
 *   - At most one rAF callback queued across both layers.
 *   - Layers paint in static → interactive order.
 *   - A dirty(STATIC) implies dirty(INTERACTIVE), because the overlay sits
 *     on top and its transform must be re-evaluated when the backdrop moved.
 *   - `flushSync()` is for test / HUD code only; never call it from a
 *     pointer handler (it re-enters the render and breaks the rAF budget).
 */

export const DIRTY_NONE = 0;
export const DIRTY_INTERACTIVE = 1;
export const DIRTY_STATIC = 2;  // includes interactive
export const DIRTY_BOTH = DIRTY_STATIC;

export function createScheduler(paintFn) {
  let dirty = DIRTY_NONE;
  let rafId = 0;
  let lastMs = 0;
  let paintMs = 0;

  function tick(ts) {
    rafId = 0;
    const toPaint = dirty;
    dirty = DIRTY_NONE;
    const t0 = performance.now();
    paintFn(toPaint);
    paintMs = performance.now() - t0;
    lastMs = ts;
  }

  function markDirty(level) {
    if (level > dirty) dirty = level;
    if (rafId !== 0) return;
    rafId = requestAnimationFrame(tick);
  }

  function cancel() {
    if (rafId !== 0) {
      cancelAnimationFrame(rafId);
      rafId = 0;
    }
  }

  function flushSync() {
    if (rafId !== 0) cancelAnimationFrame(rafId);
    tick(performance.now());
  }

  return {
    markDirty,
    cancel,
    flushSync,
    stats: () => ({ lastMs, paintMs }),
  };
}
