# Design Distributed Cache + Search System

> **Cache = Fast data access at scale | Search = Find anything in billions of documents**
> Dono systems FAANG mein daily use hote hain — samjho kaise build karte hain!

---

## Table of Contents

1. [Part 1 — Distributed Cache](#part-1--distributed-cache)
2. [Part 2 — Search System](#part-2--search-system)
3. [1 Minute Recall Block + 5 Bullet Memory Hooks](#1-minute-recall-block--5-bullet-memory-hooks)

---

# Part 1 — Distributed Cache

## 1.1 Why Build Distributed Cache?

```
SINGLE REDIS vs DISTRIBUTED CACHE
═════════════════════════════════

Single Redis:
  - 100K QPS limit
  - Single point of failure
  - Memory limit (100GB max practical)

Distributed Cache (Redis Cluster style):
  - Millions QPS (horizontal scale)
  - Fault tolerant (replication)
  - Petabytes (sharding)
```

### Real-World Analogy — Kirana vs Supermarket Chain

```
KIRANA (Single cache)              SUPERMARKET CHAIN (Distributed)
┌─────────────────────┐            ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐
│  Ek dukaan          │            │Delhi│ │Mum  │ │Blr  │ │Hyd  │
│  Sab yahan se       │            │Store│ │Store│ │Store│ │Store│
│  Capacity limited   │            └─────┘ └─────┘ └─────┘ └─────┘
└─────────────────────┘                  Har city = shard
         ❌                                ✅ Scale, local access
```

---

## 1.2 Requirements — Distributed Cache

| Requirement | Target |
|-------------|--------|
| **Latency** | < 1ms (in-memory) |
| **Availability** | 99.99% |
| **Throughput** | Millions QPS |
| **Consistency** | Eventual (cache) |

---

## 1.3 High Level Design — Distributed Cache

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                 DISTRIBUTED CACHE SYSTEM                      │
                    └─────────────────────────────────────────────────────────────┘

[Application]  GET key="user:123"
    │
    ▼
┌─────────────────┐
│  Cache Client   │  ← Consistent hashing: key → which node?
│  (Library)      │
└────────┬────────┘
         │
         │  Hash("user:123") → Node C
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    CACHE NODES (Ring)                             │
│                                                                   │
│     Node A ●────────● Node B                                      │
│         ╲            ╱                                            │
│          ╲          ╱     Consistent Hashing Ring                  │
│           ╲        ╱      Key → Hash → Clockwise → Node            │
│            ╲      ╱                                               │
│             ● Node C                                               │
│            ╱      ╲                                               │
│           ╱        ╲                                              │
│          ╱          ╲                                              │
│     Node D ●────────● Node E                                      │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘

Each node: In-memory (RAM), LRU eviction, Replica for failover
```

---

## 1.4 Consistent Hashing (Key Concept!)

```
CONSISTENT HASHING — Add/remove node pe minimal key movement
═══════════════════════════════════════════════════════════

Without consistent hashing (mod N):
  Nodes = 3, key hash % 3 → node
  Add node 4 → hash % 4 → 75% keys move! ❌

With consistent hashing:
  Ring 0 to 2^32
  Nodes placed on ring (virtual nodes = 100-200 per physical)
  Key → hash → clockwise next node

  Add node → only keys between prev and new node move (~1/N)
  Remove node → only that node's keys move

  ┌─────────────────────────────────────────┐
  │  Ring: 0 ────────────────────── 2^32   │
  │                                         │
  │  ... N1 ... N2 ... N3 ... N1 ...       │
  │       ↑     ↑     ↑                     │
  │  Key K → hash(K) → falls in N2's range  │
  │  → Store in N2                          │
  └─────────────────────────────────────────┘
```

### Virtual Nodes (Vnodes)

```
VIRTUAL NODES — Load balance
════════════════════════════

Physical Node A = 100 virtual nodes on ring (A-1, A-2, ..., A-100)
Physical Node B = 100 virtual nodes (B-1, B-2, ...)

→ Keys more evenly distributed
→ No hot spots
```

---

## 1.5 Architecture: Client → Proxy → Nodes

```
OPTION 1: Client-side partitioning (Redis Cluster)
  - Client knows ring, directly talks to node
  - No proxy overhead

OPTION 2: Proxy (Twemproxy, mcrouter)
  - Client → Proxy → Node
  - Proxy does consistent hashing
  - Simpler client, single endpoint

  [App] ──▶ [Proxy] ──▶ [Node A]
              │    ──▶ [Node B]
              │    ──▶ [Node C]
```

---

## 1.6 Cache Eviction — LRU

```
LRU (Least Recently Used)
════════════════════════

Memory full? Evict least recently used key.

Each node maintains:
  - Key → Value
  - Key → Last access time (or doubly linked list)

Eviction policy options:
  - LRU: Least recently used
  - LFU: Least frequently used
  - TTL: Expire after time
  - Random: Simple, sometimes used
```

---

## 1.7 Replication for Fault Tolerance

```
REPLICATION
══════════

Primary-Replica:
  - Write → Primary
  - Primary async/sync replicates to Replica
  - Primary fails → Replica promoted

  Node A (Primary) ──replicate──▶ Node A' (Replica)

Consistent hashing: Each "slot" has primary + replica(s)
```

---

## 1.8 Hot Key Handling

```
HOT KEY PROBLEM
════════════════

Key "trending_videos" → 100K QPS → Single node overload!

Solutions:
1. Local cache (in-app): Cache hot keys in app memory
2. Replicate hot key: Copy to multiple nodes (key duplication)
3. Split key: trending_videos_0, trending_videos_1, ... (shard)
4. Add more replicas for that node
```

---

## 1.9 Cache Warming

```
CACHE WARMING — Startup pe cache fill
════════════════════════════════════

New node added / Restart:
  - Empty cache → All requests miss → DB overload

Warming strategies:
  1. Preload: Batch load top N keys before traffic
  2. Lazy: First request loads, subsequent hit
  3. Background: Worker preloads based on access logs
```

---

## 1.10 Monitoring

| Metric | Why |
|--------|-----|
| **Hit rate** | Low = cache ineffective, tune TTL/eviction |
| **Latency** | P99 < 1ms |
| **Memory** | Per node usage |
| **Eviction rate** | High = need more memory |

---

## 1.11 Redis Cluster Comparison

| Our Design | Redis Cluster |
|------------|---------------|
| Consistent hashing | ✅ Same (hash slots) |
| Sharding | Manual / Proxy | Built-in |
| Replication | Custom | Built-in (replica of each master) |
| Hot key | App-level | Client-side hashing |

---

# Part 2 — Search System

## 2.1 How Search Works (Overview)

```
SEARCH PIPELINE
═══════════════

1. CRAWL    → Documents collect karo (web pages, products)
2. INDEX    → Inverted index banao (word → doc list)
3. QUERY    → User query parse karo
4. SEARCH   → Index mein lookup
5. RANK     → Results ko relevance se sort karo
6. RETURN  → Top K results
```

### Real-World Analogy — Book Index

```
BOOK INDEX (Inverted Index)
══════════════════════════

Book = Document
Index at back = "machine" → page 5, 12, 45

Search "machine learning":
  - "machine" → pages 5, 12, 45
  - "learning" → pages 5, 8, 12
  - Intersection → pages 5, 12 (both words)
  - Rank by relevance
```

---

## 2.2 Requirements — Search System

| Requirement | Target |
|-------------|--------|
| **Latency** | < 100ms (p95) |
| **Relevance** | Good ranking |
| **Scale** | Billions of documents |
| **Freshness** | Near real-time (depends on use case) |

---

## 2.3 High Level Design — Search System

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    SEARCH SYSTEM                             │
                    └─────────────────────────────────────────────────────────────┘

                    ┌─────────────────────────────────────────────────────────┐
                    │                    INDEXING PIPELINE                      │
                    └─────────────────────────────────────────────────────────┘

[Documents]  Products, Web pages, etc.
    │
    ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Crawler /  │────▶│  Parser     │────▶│  Tokenizer  │
│  Ingestion  │     │  (extract   │     │  Stemming   │
│             │     │   text)     │     │  Stop words │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                               │
                                               ▼
                    ┌─────────────────────────────────────┐
                    │         INVERTED INDEX                │
                    │  "laptop" → [doc1, doc5, doc99]       │
                    │  "phone"  → [doc2, doc5, doc100]     │
                    │  (Sharded by term / doc)              │
                    └──────────────────────┬────────────────┘
                                           │
                    ┌──────────────────────┴────────────────┐
                    │           QUERY PIPELINE               │
                    └───────────────────────────────────────┘

[User] Query: "laptop under 50000"
    │
    ▼
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Query      │────▶│  Search     │────▶│  Rank       │
│  Parser     │     │  Index      │     │  (TF-IDF,   │
│  Tokenize   │     │  Lookup     │     │   etc)      │
└─────────────┘     └─────────────┘     └──────┬──────┘
                                               │
                                               ▼
                                        [Top K Results]
```

---

## 2.4 Web Crawler Design

```
CRAWLER (Web Search ke liye)
════════════════════════════

1. Seed URLs (start list)
2. Fetch page (HTTP)
3. Parse HTML, extract links
4. Add new links to queue (BFS/DFS)
5. Extract text for indexing
6. Respect robots.txt, rate limit per domain
7. Deduplication (URL seen? Skip)

  ┌─────────┐     ┌─────────┐     ┌─────────┐
  │ URL     │────▶│ Fetcher │────▶│ Parser  │
  │ Queue   │     │ (worker)│     │ Extract │
  └─────────┘     └─────────┘     └────┬────┘
       ▲                               │
       │         New URLs               │
       └───────────────────────────────┘
```

---

## 2.5 Inverted Index (MOST IMPORTANT!)

```
INVERTED INDEX — Word → Document list
═════════════════════════════════════

Documents:
  Doc1: "laptop computer best"
  Doc2: "phone mobile"
  Doc3: "laptop phone"

Inverted Index:
  "laptop"  → [Doc1, Doc3]
  "computer"→ [Doc1]
  "best"    → [Doc1]
  "phone"   → [Doc2, Doc3]
  "mobile"  → [Doc2]

Query "laptop phone":
  - "laptop" → [Doc1, Doc3]
  - "phone"  → [Doc2, Doc3]
  - Intersection (AND) → [Doc3]
  - Union (OR) → [Doc1, Doc2, Doc3]
```

### Posting List (with position, frequency)

```
ADVANCED: Posting list with metadata
════════════════════════════════════

"laptop" → [
  { doc_id: 1, freq: 2, positions: [0, 5] },  // TF = 2
  { doc_id: 3, freq: 1, positions: [0] }
]

freq = Term Frequency (TF) — ranking mein use
```

---

## 2.6 Tokenization, Stemming, Stop Words

```
TEXT PROCESSING
═══════════════

1. Tokenization: "Machine Learning" → ["machine", "learning"]
2. Lowercase: "Laptop" → "laptop"
3. Stemming: "running" → "run", "learned" → "learn"
4. Stop words: "the", "a", "is" → Remove (noise)

"The quick brown fox" → ["quick", "brown", "fox"]
```

---

## 2.7 Ranking — TF-IDF Basics

```
TF-IDF (Term Frequency - Inverse Document Frequency)
════════════════════════════════════════════════════

TF = How often term in document (more = more relevant)
IDF = How rare term is across all docs (rare = more important)

TF-IDF score = TF × IDF

Example:
  "laptop" in Doc1: TF=3, in 100 docs: IDF=log(10000/100)=high
  "the" in Doc1: TF=5, in 9000 docs: IDF=low
  → "laptop" contributes more to score
```

### PageRank Concept (Web Search)

```
PAGERANK — Link-based ranking
════════════════════════════

More links TO your page = more important
Google's secret sauce (simplified)

  Page A ←── Page B, C, D link to A
  → A gets "votes" from B, C, D
  → Higher PageRank = higher in results
```

---

## 2.8 Query Processing

```
QUERY FLOW
══════════

"laptop under 50000"
    │
    ▼
Parse: ["laptop", "under", "50000"]
    │
    ▼
"under" → stop word? Maybe remove
"50000" → Filter (price < 50000) — structured filter
    │
    ▼
Search index: "laptop" → doc list
Filter: price < 50000
    │
    ▼
Rank: TF-IDF + filters
    │
    ▼
Return top 20
```

---

## 2.9 Autocomplete / Typeahead (Trie)

```
TRIE FOR AUTOCOMPLETE
═════════════════════

User types: "lap"
  → Show: "laptop", "laptop bag", "laptop stand"

  Trie:
        root
       /  |  \
      l   p   m
      |   |   |
      a   h   o
      |   |   |
      p   o   b
      |   |   |
      t   n   i
      o   e   l
      p

  Prefix "lap" → traverse → get all suffixes → "top", "top bag", ...
```

### Implementation Notes

```
AUTOCOMPLETE STORAGE
════════════════════

- Trie in memory (fast)
- Top K suggestions per prefix (precomputed)
- Update when new queries come (learning)
```

---

## 2.10 Spell Correction

```
SPELL CORRECTION
════════════════

"laptp" → "laptop"

Methods:
1. Edit distance (Levenshtein): 1 char diff
2. Symmetric Delete: "laptop" → "lapto", "laptp", ... index
   Query "laptp" → lookup → find "laptop"
3. Phonetic: Soundex, Metaphone (sound-alike)
```

---

## 2.11 Scaling — Shard Index

```
INDEX SHARDING
══════════════

Option 1: Shard by document
  - Doc 1-1M → Shard 1
  - Doc 1M-2M → Shard 2
  - Query → Fan out to all shards → Merge results

Option 2: Shard by term (hash)
  - "laptop" → Shard 3
  - "phone" → Shard 7
  - Query "laptop phone" → Query shard 3 + 7 → Merge

Elasticsearch: Shard by document, each shard has full index for its docs
```

---

## 2.12 Elasticsearch Architecture Overview

```
ELASTICSEARCH (Simplified)
══════════════════════════

Index = Database
Type = Table (deprecated in v7+)
Document = Row
Mapping = Schema

  Index "products"
    ├── Shard 0 (primary) + Replica
    ├── Shard 1 (primary) + Replica
    └── Shard 2 (primary) + Replica

  - Inverted index per shard
  - Query: Coordinating node → Shards → Merge → Return
```

---

## 2.13 Comparison — Cache vs Search

| Aspect | Distributed Cache | Search System |
|--------|-------------------|---------------|
| **Purpose** | Fast key-value lookup | Full-text search |
| **Data structure** | Hash + LRU | Inverted index |
| **Query** | GET key | Free text, filters |
| **Scale** | Consistent hashing | Shard by doc |
| **Latency** | < 1ms | < 100ms |

---

## 2.14 When to Use What

```
CACHE:
  - Session data
  - API response
  - Hot data (DB se load reduce)

SEARCH:
  - Product search
  - Log search
  - Autocomplete
  - "Find anything" in large corpus
```

---

# 1 Minute Recall Block + 5 Bullet Memory Hooks

## Distributed Cache

> **Distributed Cache = Consistent hashing + LRU eviction + Replication**
> Key → hash → ring → node. Add/remove node = minimal key movement. Hot key = local cache / shard. Monitor hit rate.

**5 Hooks:**
1. **Consistent hashing** — Add node = 1/N keys move
2. **Virtual nodes** — Load balance
3. **LRU eviction** — Memory full = evict least recent
4. **Hot key** — Local cache, key split
5. **Replication** — Primary + Replica, failover

## Search System

> **Search = Crawl → Index (Inverted) → Query → Rank → Return**
> Inverted index = word → doc list. TF-IDF = ranking. Trie = autocomplete. Shard by doc for scale.

**5 Hooks:**
1. **Inverted index** — Word → [doc1, doc2, ...]
2. **TF-IDF** — Term freq × Inverse doc freq = relevance
3. **Trie** — Autocomplete prefix search
4. **Shard by document** — Fan out query, merge
5. **Tokenizer + Stemming** — "running" → "run"

---

*End of Distributed Cache + Search Design — FAANG Interview Ready!*
