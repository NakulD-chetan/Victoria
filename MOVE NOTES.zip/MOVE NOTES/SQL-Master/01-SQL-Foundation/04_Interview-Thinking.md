# SQL Foundation — Interview Thinking

---

## What they're testing

1. **Can you name DDL vs DML vs DQL** without mixing them up?
2. **Do you understand PK/FK** beyond syntax (orphans, cascades)?
3. **Do you know trade-offs** of `DELETE` vs `TRUNCATE` vs `DROP`?
4. **Data integrity** — entity, referential, domain?
5. **SQL vs NoSQL** — when to pick which?

---

## Rapid-Fire Q&A (Definition-style)

### Q: What is SQL?
**A:** Structured Query Language — standard language for managing and querying relational databases. It has sub-languages: DDL, DML, DQL, DCL, TCL.

### Q: What is a Database?
**A:** Organized collection of structured data stored electronically. Managed by a DBMS.

### Q: What is RDBMS? How is it different from DBMS?
**A:** RDBMS stores data in tables with relationships enforced by keys and constraints. DBMS is generic (can be file-based, hierarchical). RDBMS supports ACID, SQL, referential integrity.

### Q: What is a Primary Key?
**A:** Column (or set of columns) that uniquely identifies each row. It is NOT NULL + UNIQUE. Only one PK per table.

### Q: Can a table have multiple Primary Keys?
**A:** No. One PK per table. But multiple **candidate keys** can exist — one is chosen as PK, rest are alternate keys.

### Q: What is a Foreign Key?
**A:** Column that references the PK or UNIQUE key of another (or same) table. Enforces referential integrity — child row must point to existing parent.

### Q: Can Foreign Key be NULL?
**A:** Yes, if the column allows NULL. It means "no relationship" (optional association). But non-NULL FK MUST match an existing parent value.

### Q: What is a Composite Key?
**A:** Primary key made of two or more columns together. Example: `(student_id, course_id)` in enrollment table.

### Q: Difference between UNIQUE and PRIMARY KEY?
**A:** PK = NOT NULL + UNIQUE, only one per table. UNIQUE allows one NULL (in most DBs), multiple UNIQUE constraints per table allowed.

### Q: What is a Candidate Key?
**A:** Any minimal set of columns that can uniquely identify rows. One becomes PK, rest are alternate keys.

### Q: Surrogate Key vs Natural Key?
**A:** Surrogate = system-generated (auto-increment, UUID) — stable, narrow, no business meaning. Natural = business value (email, SSN) — meaningful but can change. **Prefer surrogate** for joins and stability.

### Q: What is DELETE vs TRUNCATE vs DROP?
**A:**
- DELETE: Removes specific rows (WHERE), fully logged, fires triggers, DML.
- TRUNCATE: Removes ALL rows fast, minimal logging, no triggers, resets identity, DDL.
- DROP: Removes entire table structure + data, DDL.

### Q: Can we rollback TRUNCATE?
**A:** In PostgreSQL and SQL Server — YES (within explicit transaction). In MySQL with autocommit — NO. Always mention "depends on DB engine."

### Q: What is a Constraint?
**A:** Rule enforced by DB on table/column to ensure data integrity. Types: NOT NULL, UNIQUE, PRIMARY KEY, FOREIGN KEY, CHECK, DEFAULT.

### Q: What is ON DELETE CASCADE?
**A:** When parent row is deleted, all child rows referencing it are automatically deleted. Alternative: SET NULL, RESTRICT, NO ACTION.

### Q: What is Data Integrity?
**A:** Accuracy and consistency of data. Four types: Entity (PK), Referential (FK), Domain (CHECK/types), User-defined (triggers/business rules).

### Q: What is NULL?
**A:** Represents unknown or missing value. NOT equal to zero or empty string. Any comparison with NULL returns UNKNOWN. Use `IS NULL` / `IS NOT NULL` to check.

### Q: What are SQL data types?
**A:** Numeric (INT, DECIMAL, FLOAT), String (CHAR, VARCHAR, TEXT), Date/Time (DATE, TIMESTAMP), Boolean, Binary (BLOB). DECIMAL for exact (money); FLOAT for approximate.

### Q: CHAR vs VARCHAR?
**A:** CHAR(n) = fixed-length, pads with spaces, faster for fixed-size data. VARCHAR(n) = variable-length, saves storage, better for variable-size data.

### Q: What are different SQL sub-languages?
**A:** DDL (CREATE/ALTER/DROP), DML (INSERT/UPDATE/DELETE), DQL (SELECT), DCL (GRANT/REVOKE), TCL (COMMIT/ROLLBACK/SAVEPOINT).

### Q: What is a Schema?
**A:** Logical container/blueprint that defines database structure — tables, columns, types, relationships, constraints, indexes, views.

### Q: What is Cardinality in DB context?
**A:** Two meanings: (1) Number of rows in a table. (2) Relationship type between tables — 1:1, 1:N, M:N.

### Q: SQL vs NoSQL — when to use which?
**A:** SQL: structured data, complex queries, ACID needed, relationships (banking, ERP). NoSQL: flexible schema, massive scale, high write throughput, eventual consistency OK (social media feeds, IoT, caching).

---

## Follow-up traps

- **Can a table have two primary keys?** → No *one* PK; multiple **candidate** keys, **one** chosen as PK.
- **NULL in primary key?** → Not allowed (entity integrity).
- **NULL in foreign key?** → Often allowed (optional relationship); semantics matter.
- **Is TRUNCATE DML or DDL?** → DDL in most DBs (SQL Server, Oracle, MySQL). Some classify differently.
- **Can we use WHERE with TRUNCATE?** → No. TRUNCATE removes ALL rows.

---

*Next: [[05_Common-Mistakes]]*
