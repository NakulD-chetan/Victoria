# Design Twitter/X Feed — Design Template

> **Permanent Recall:** Complete architecture: API → Tweet Service → Fan-out Service → Timeline Cache. Read path: API → Timeline Service → Cache (or merge cache + celebrity pull). Media: S3 + CDN. Search: Elasticsearch. Trending: stream processing. **Redis sorted sets** for timeline; **Snowflake IDs** for globally unique time-ordered tweet IDs.

---

## API Design

| Endpoint | Method | Description |
|----------|--------|-------------|
| `POST /tweet` | POST | Create tweet; body: `{ text, media_urls[], reply_to? }` |
| `GET /feed?user_id=&cursor=&limit=20` | GET | Home timeline (tweets from followed users) |
| `GET /feed/:user_id?cursor=&limit=20` | GET | User timeline (tweets by `user_id`) |
| `POST /follow` | POST | Follow user; `{ follower_id, followee_id }` |
| `POST /unfollow` | POST | Unfollow user |
| `POST /tweet/:id/like` | POST | Like tweet |
| `POST /tweet/:id/retweet` | POST | Retweet (creates new tweet referencing original) |

---

## Database Schema

**users**
| Column | Type |
|--------|------|
| user_id | UUID / Snowflake |
| username | VARCHAR |
| created_at | TIMESTAMP |

**tweets**
| Column | Type |
|--------|------|
| tweet_id | Snowflake |
| user_id | UUID |
| text | VARCHAR(280) |
| media_urls | JSON |
| created_at | TIMESTAMP |
| reply_to_id | Snowflake (nullable) |

**followers**
| Column | Type |
|--------|------|
| followee_id | UUID |
| follower_id | UUID |
| created_at | TIMESTAMP |
| PRIMARY KEY (followee_id, follower_id) |

**timeline** (logical — actually in Redis)
| Key | Value |
|-----|-------|
| timeline:{user_id} | Sorted set: (tweet_id, timestamp) |

---

## High-Level Architecture

```
    WRITE PATH
    ───────────────────────────────────────────────────────
    Client → API Gateway → Tweet Service → [DB: tweets]
                          │
                          └→ Fan-out Service
                                │
                                ├→ [Kafka] (async)
                                └→ Fan-out Workers
                                      │
                                      └→ Redis (timeline:{follower_id})
                                            (skip if followee is celebrity)

    READ PATH
    ───────────────────────────────────────────────────────
    Client → API Gateway → Timeline Service
                                │
                                ├→ Redis (timeline:{user_id})  ← cached timeline
                                │       │
                                │       └→ IF cache miss or partial: merge with
                                │          celebrity tweets (pull from DB)
                                └→ Return merged, sorted feed
```

---

## ASCII Architecture Diagram

```
                         ┌─────────────┐
                         │   Clients   │
                         └──────┬──────┘
                                │
                         ┌──────▼──────┐
                         │ API Gateway │
                         └──────┬──────┘
                    ┌───────────┴───────────┐
                    │                       │
             ┌──────▼──────┐         ┌──────▼──────┐
             │ POST /tweet │         │ GET /feed   │
             └──────┬──────┘         └──────┬──────┘
                    │                       │
             ┌──────▼──────┐         ┌──────▼──────┐
             │Tweet Service│         │   Timeline  │
             └──────┬──────┘         │   Service   │
                    │                └──────┬──────┘
             ┌──────▼──────┐                │
             │ PostgreSQL  │         ┌──────▼──────┐
             │  (tweets)   │         │    Redis    │
             └─────────────┘         │  (timeline) │
                    │                └──────┬──────┘
             ┌──────▼──────┐                │
             │   Kafka     │         ┌──────▼──────┐
             └──────┬──────┘         │ Merge celeb │
                    │                │ tweets if   │
             ┌──────▼──────┐         │ needed      │
             │ Fan-out     │         └──────┬──────┘
             │ Workers     │                │
             └──────┬──────┘         ┌──────▼──────┐
                    │                │ PostgreSQL  │
             ┌──────▼──────┐         │(tweets/celebs)│
             │ Redis       │         └─────────────┘
             │ timeline:   │
             └─────────────┘

    Media: S3 ──→ CDN
    Search: Elasticsearch
    Trending: Kafka → Flink/Spark
```

---

## Fan-Out Service Design

1. **On tweet write:** Tweet Service publishes to Kafka topic `tweets`.
2. **Fan-out worker** consumes, gets `followee_id` (poster).
3. **Check celebrity:** If `followers_count > 100K` → skip push, mark as celebrity.
4. **Otherwise:** Query `followers` table for follower IDs (paginated).
5. **Push to Redis:** For each follower: `ZADD timeline:{follower_id} timestamp tweet_id`.
6. **Trim:** Keep last 800–1000 tweets per timeline (memory bound).

> **FAANG Tip:** Use pipeline/batch Redis writes (e.g., 100 at a time) to reduce round trips. Async is critical—don't block tweet creation on fan-out.

---

## Media Storage

| Layer | Purpose |
|-------|---------|
| **S3** (or equivalent) | Durable storage; transcoding for videos |
| **CDN** | Serve images/videos from edge; never from origin |
| **Upload flow** | Client → API → presigned URL or direct upload → S3 → return URL in tweet |

---

## Search (Elasticsearch)

- Index tweets: `tweet_id`, `user_id`, `text`, `created_at`, `hashtags`.
- Ingest pipeline from Kafka (`tweets` topic) or CDC from DB.
- Query: match on `text`, filter by `user_id` if user timeline search.

---

## Trending (Stream Processing)

- Kafka topic: `tweet_events` (hashtags, tweet creation).
- Flink/Spark: aggregate hashtag counts over rolling window (e.g., 1 hour).
- Store top 50 in Redis/cache; API reads from there.

---

## 30-SECOND REVISION BOX

```
API: POST /tweet, GET /feed, POST /follow
SCHEMA: users, tweets, followers; timeline in Redis
WRITE: Tweet → DB → Kafka → Fan-out → Redis (skip celebrity)
READ: Timeline Service → Redis → merge celeb tweets if needed
MEDIA: S3 + CDN
SEARCH: Elasticsearch
TRENDING: Kafka + Flink/Spark
```

---

**Next: [[04_Interview-Thinking]]**
