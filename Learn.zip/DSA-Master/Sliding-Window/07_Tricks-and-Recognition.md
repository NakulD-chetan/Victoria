# Sliding Window — Tricks & Recognition

> **Quick recall rules for instantly recognizing sliding window problems, hidden signals, constraint clues, and interview shortcuts that save minutes.**

---

## Pattern Triggers — Instant Recognition

### Tier 1: Obvious Signals (100% Sliding Window)

| Keyword in Problem | Pattern Type | Example Problem |
|-------------------|-------------|-----------------|
| "maximum sum subarray of size k" | Fixed | Max Sum Subarray of Size K |
| "minimum size subarray sum" | Variable (shortest) | Minimum Size Subarray Sum |
| "longest substring without repeating" | Variable (longest) | Longest Substring Without Repeating Characters |
| "minimum window substring" | Variable (shortest) | Minimum Window Substring |
| "sliding window maximum" | Fixed + Deque | Sliding Window Maximum |
| "maximum average subarray" | Fixed | Maximum Average Subarray I |

### Tier 2: Strong Signals (90% Sliding Window)

| Keyword / Constraint | Why It's Sliding Window |
|---------------------|------------------------|
| "contiguous subarray" | Window = contiguous range |
| "substring" (not subsequence) | String window = contiguous |
| "at most k distinct" | Variable window + hash map |
| "at most k replacements/flips" | Window where invalid elements ≤ k |
| "contains all characters of" | Frequency matching window |
| "consecutive" | Contiguous = window |
| "subarray product/sum" + all positive | Monotonic window behavior |

### Tier 3: Hidden Signals (Tricky — Need to Decode)

| Problem Description | Hidden Window |
|--------------------|---------------|
| "Maximum consecutive ones with at most k flips" | Window where count of zeros ≤ k |
| "Fruits into baskets" | At most 2 distinct elements |
| "Longest repeating character replacement" | Window where (window_size - max_freq) ≤ k |
| "Permutation in string" | Fixed window of pattern length |
| "Find all anagrams" | Fixed window + frequency match |
| "Grumpy bookstore owner" | Fixed window over grumpy segment |
| "Max points from cards" | Total sum - minimum window sum |
| "Diet plan performance" | Fixed window + counting |

---

## Constraint Clues

### Array Size Hints

| Constraint | Time Expected | Sliding Window? |
|-----------|--------------|-----------------|
| n ≤ 10^6 | O(n) or O(n log n) | Likely — O(n) matches |
| n ≤ 10^4 | O(n²) is OK | Maybe, but brute force might pass |
| n ≤ 20 | O(2^n) is OK | Unlikely — probably backtracking/DP |
| "values are non-negative" | O(n) window approach valid | Strong signal for sliding window |

### Problem Type Hints

| If Problem Asks For... | Window Type | Key Decision |
|-----------------------|-------------|-------------|
| Fixed-size result | Fixed window | Size k is given |
| Longest valid ... | Variable (expand-heavy) | Shrink when invalid |
| Shortest valid ... | Variable (shrink-heavy) | Shrink while valid |
| Count of valid ... | Variable + math | Count subarrays ending at each right |
| Maximum/minimum in window | Fixed + Deque | Monotonic deque pattern |

---

## The "Exactly K" Trick

**One of the most powerful FAANG tricks:**

```
Subarrays with EXACTLY k distinct = 
    atMost(k) - atMost(k-1)
```

**Why it works:**
- `atMost(k)` counts all subarrays with ≤ k distinct elements
- `atMost(k-1)` counts all subarrays with ≤ k-1 distinct elements
- The difference = subarrays with exactly k distinct

**Problems that use this:**
- Subarrays with K Different Integers (LC 992)
- Count Number of Nice Subarrays (LC 1248)
- Binary Subarrays With Sum (LC 930)

---

## The "Complement Window" Trick

**Sometimes the answer is NOT the window — it's everything OUTSIDE the window.**

```
Problem: Maximum points from cards (pick from ends)
         Pick k cards from left end or right end.

Trick:   Minimize the sum of the MIDDLE (n-k) elements.
         Answer = total_sum - min_window_sum(size = n - k)

┌──────────────────────────────────────┐
│  [pick]  [pick]  [  middle  ]  [pick]│
│  ← k1 →          ← n-k →    ← k2 → │
│                                       │
│  Minimize middle = Maximize picks     │
└──────────────────────────────────────┘
```

---

## The "Count Subarrays" Trick

**When asked "how many subarrays satisfy condition X":**

For each position of `right`, all subarrays `[left..right], [left+1..right], ..., [right..right]` are valid.

```python
# Count of valid subarrays ending at right = right - left + 1
count += right - left + 1
```

**Why:** After shrinking, everything from `left` to `right` is valid. That's `(right - left + 1)` subarrays.

---

## The "Two Variable Windows" Trick

**For problems needing longest subarray with condition involving two metrics:**

Maintain two pieces of state simultaneously. Common in problems like:
- Longest subarray with sum ≤ target AND at most k distinct

**Template:**
```python
left = 0
for right in range(n):
    # Update BOTH states
    state1.add(arr[right])
    state2.add(arr[right])
    
    # Shrink when EITHER constraint violated
    while state1.invalid() or state2.invalid():
        state1.remove(arr[left])
        state2.remove(arr[left])
        left += 1
    
    best = max(best, right - left + 1)
```

---

## The "No-Shrink" Optimization

**For "longest" problems, you can avoid shrinking the window:**

Instead of shrinking with `while`, use `if`. The window size never decreases — it either grows or shifts.

```python
# Standard (shrinks window):
while len(freq) > k:
    # remove left
    left += 1

# No-shrink optimization (window only grows or shifts):
if len(freq) > k:
    # remove left  
    left += 1

# Window size NEVER decreases
# Answer = right - left + 1 at the end (final window size)
```

**Why it works:** We only care about the LONGEST valid window. If the current window is invalid, we don't need to find a smaller valid one — we already have a better answer from before.

**Caution:** Only works for "longest/maximum" problems. NOT for counting or shortest.

---

## Quick Decision Flowchart

```mermaid
flowchart TD
    A[READ PROBLEM] --> B{subarray/substring\nmentioned?}
    B -- No --> X[Not Sliding Window]
    B -- Yes --> C{Values all\nnon-negative?}
    C -- Maybe --> D[Ask interviewer!]
    C -- Yes --> E{Window size\ngiven?}
    E -- Yes --> F[FIXED WINDOW]
    E -- No --> G{What to find?}
    G -- Longest --> H[Expand, shrink when invalid]
    G -- Shortest --> I[Expand, shrink while valid]
    G -- Count --> J[Expand, count right-left+1]
    A --> K{Involves\nexactly k?}
    K -- Yes --> L[atMost k - atMost k-1]

    style X fill:#ff6b6b,color:#fff
    style F fill:#51cf66,color:#fff
    style H fill:#339af0,color:#fff
    style I fill:#fcc419,color:#000
    style J fill:#cc5de8,color:#fff
    style L fill:#ff922b,color:#fff
```

<details><summary>ASCII fallback</summary>

```
READ PROBLEM
    │
    ├── "subarray/substring" mentioned? ──── No ──→ Not sliding window
    │       │ Yes
    ├── Values all non-negative? ──── Maybe ──→ Ask interviewer!
    │       │ Yes
    ├── Window size given?
    │       ├── Yes → FIXED WINDOW
    │       └── No  → VARIABLE WINDOW
    │                   ├── Find longest? → Expand, shrink when invalid
    │                   ├── Find shortest? → Expand, shrink while valid
    │                   └── Count valid? → Expand, count (right-left+1)
    │
    └── Involves "exactly k"? → Use atMost(k) - atMost(k-1)
```
</details>

---

## Interview Shortcuts

### Shortcut 1: Frequency Map Initialization
```python
# Don't iterate — use Counter
from collections import Counter
need = Counter(target_string)  # One line
```

### Shortcut 2: Quick Validity Check
```python
# Instead of comparing two full maps, track a 'formed' counter
if ch in need and have[ch] == need[ch]:
    formed += 1
# Valid when formed == len(need)
```

### Shortcut 3: Fixed Window Sum Without Loop
```python
window_sum = sum(arr[:k])  # Pythonic initialization
```

### Shortcut 4: String Anagram Check
```python
# Fixed window of len(p), check if frequency matches
# Use array[26] instead of dict for speed
```

### Shortcut 5: Prefix Sum Alternative
```python
# When sliding window doesn't work (negatives), fall back to:
# prefix[j] - prefix[i] = sum(arr[i..j-1])
# Binary search on prefix sums if sorted
```

---

## Pattern Comparison: What ISN'T Sliding Window

| Problem | Looks Like Window But Isn't | Correct Approach |
|---------|---------------------------|------------------|
| Longest increasing subsequence | "Longest" but NOT contiguous | DP |
| Maximum subarray sum (Kadane's) | Contiguous, but simpler | Kadane's (special case of window) |
| Two Sum | Pair, not range | Hash map |
| Subarray sum equals k (with negatives) | Sum + subarray | Prefix sum + hash map |
| Longest palindromic substring | Contiguous but expand-from-center | Expand around center / DP |

---

## 10-Second Recognition Guide

```
SEE "CONTIGUOUS SUBARRAY" → Sliding Window
SEE "SUBSTRING" (not subsequence) → Sliding Window  
SEE "OF SIZE K" → Fixed Window
SEE "LONGEST/SHORTEST" → Variable Window
SEE "AT MOST K DISTINCT" → Variable + HashMap
SEE "EXACTLY K" → atMost(k) - atMost(k-1)
SEE "NEGATIVE NUMBERS" + SUM → NOT Sliding Window (use prefix sum)
SEE "SUBSEQUENCE" → NOT Sliding Window (use DP/greedy)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Sliding Window Recognition
INSTANT TRIGGERS:   contiguous, substring, of size k, at most k distinct
HIDDEN TRIGGERS:    "at most k flips", "fruits in baskets", "replace at most k"
EXACTLY K:          atMost(k) - atMost(k-1)
COMPLEMENT:         Sometimes answer = total - window (pick from ends)
COUNT TRICK:        Valid subarrays ending at right = right - left + 1
NO-SHRINK:          For longest: use if instead of while (window only grows)
NOT WINDOW:         Subsequence, negative sums, pairs, palindromes
INTERVIEW LINE:     "I see [keyword] which tells me this is a [fixed/variable]
                     sliding window problem because [reasoning]."
```

---

## 30-SECOND REVISION BOX

```
"contiguous/substring" → WINDOW | "of size k" → FIXED | "longest/shortest" → VARIABLE
"at most k distinct" → HashMap | "exactly k" → atMost(k)-atMost(k-1)
"at most k flips" → window where bad_count ≤ k
NOT window: subsequence, negatives+sum, pairs, palindromes
COMPLEMENT: sometimes answer = total - min_window
```
