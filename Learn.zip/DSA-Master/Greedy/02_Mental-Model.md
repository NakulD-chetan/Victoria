# Greedy — Mental Model

> **Permanent Recall:** "Always pick the best available option NOW." No second-guessing. Sort to make "best" obvious. Intervals → which meeting first? Jump → how far can I reach? Gas station → can I complete the loop?

---

## How FAANG Engineers Think About Greedy

1. **Simplify** — What's the single best choice at this moment?
2. **Sort** — Order inputs so "best" is easy to identify
3. **Scan** — One pass, make decisions as you go
4. **Never backtrack** — Commit and move on

---

## The Core Mental Model

```mermaid
flowchart TD
    A[At each step pick the option that maximizes current objective]
    B[Without worrying about future implications]
    A --> B
    style A fill:#339af0,color:#fff
    style B fill:#51cf66,color:#fff
```

<details><summary>ASCII fallback</summary>

```
┌─────────────────────────────────────────────────────────────┐
│  "At each step, pick the option that maximizes my current   │
│   objective — without worrying about future implications."   │
└─────────────────────────────────────────────────────────────┘
```

</details>

**Key:** The "current objective" must align with the global objective. That's what we prove.

---

## Sorting as Preprocessing

| Problem Type | Sort By | Why |
|--------------|---------|-----|
| Interval scheduling | **End time** | Earliest-ending frees most time for others |
| Interval partitioning | **Start time** | Process as events arrive |
| Fractional knapsack | **Value/weight** | Best bang for buck first |
| Task scheduler | **Deadline** (earliest first) | Don't miss deadlines |
| Merge intervals | **Start time** | Process chronologically |

```
Intervals: [1,3], [2,4], [3,5], [1,2]

Sort by END: [1,2], [1,3], [2,4], [3,5]
             ↑ Pick this first — ends earliest, blocks least
```

---

## Interval Problems: "Which Meeting to Attend First?"

**Mental model:** You're in a room. Meetings come. You want to attend as many as possible.

```
Timeline:  |----|----|----|----|----|----|
Meeting A: [====]
Meeting B:    [======]
Meeting C:       [====]
Meeting D:          [======]

Greedy: Pick A (ends first). Then C (next that doesn't overlap). Skip B, D.
Result: 2 meetings. Optimal.
```

**Decision trigger:** "Pick the one that ends soonest — it frees the room fastest."

---

## Jump Game: "How Far Can I Reach?"

**Mental model:** You're at position 0. Each step tells you your max jump. Track the farthest you can go.

```
nums = [2, 3, 1, 1, 4]
Index:  0  1  2  3  4

Step 0: at 0, can reach 0+2 = 2  → max_reach = 2
Step 1: at 1, can reach 1+3 = 4  → max_reach = 4  ✓ (reached end)
```

```
ASCII:
  [2]  3   1   1   4
   ●───●───●───●───●
   |   |       |
   +2  +3      +1
   max_reach: 2 → 4
```

**Decision trigger:** "Update max_reach = max(max_reach, i + nums[i]). If max_reach >= n-1, we're done."

---

## Gas Station: "Can I Complete the Loop?"

**Mental model:** Net gas (gas - cost) must be ≥ 0 for round trip. Start at index where running sum never goes negative.

```
gas  = [1, 2, 3, 4, 5]
cost = [3, 4, 5, 1, 2]
net  = [-2,-2,-2, 3, 3]

Total net = 0 → trip possible
Start at index 3 (first positive net after lowest point)
```

```
Running sum: -2, -4, -6, -3, 0
             ↑ lowest
Start from next index (3) where we "reset"
```

---

## Decision Triggers (Quick Recognition)

| Trigger Phrase | Think |
|----------------|-------|
| "Maximum number of non-overlapping..." | Interval scheduling, sort by end |
| "Minimum number of..." (rooms, arrows, etc.) | Often greedy |
| "Can you reach the end?" | Jump game, max reach |
| "Minimum refueling stops" | Greedy heap (pick largest gas) |
| "Schedule tasks" / "minimize lateness" | Sort by deadline |
| "Best value for capacity" (fractional) | Sort by value/weight |

---

## ASCII: Interval Greedy Visualization

```
Intervals (sorted by end):
  A: |----|
  B:   |------|
  C:      |--|
  D:         |------|
  E:            |--|

Greedy picks: A, C, E (non-overlapping, max count)
              ↑   ↑   ↑
              End End End
```

---

## ASCII: Jump Game Reachability

```
Index:    0   1   2   3   4
nums:    [2] [3] [1] [1] [4]
          │   │   │   │   │
reach:    2   4   4   4   8
          └───┴───┴───┴───┘
          max_reach grows, never shrinks
          If max_reach >= 4 → YES
```

---

## ASCII: Gas Station Circular Greedy

```
     gas[i] - cost[i] = net[i]
     
     Index:  0   1   2   3   4
     net:  [-2][-2][-2][ 3][ 3]
     
     Cumulative: -2 → -4 → -6 → -3 → 0
     
     Start at index where running sum is lowest + 1
     (so we never go negative from there)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL: "Pick best NOW" — no backtracking
SORT: Intervals→end, Knapsack→value/wt, Tasks→deadline
INTERVALS: "Which meeting first?" → Earliest ending
JUMP: "How far can I reach?" → max_reach = max(max_reach, i+nums[i])
GAS: Net gas ≥ 0, start after lowest cumulative point
TRIGGERS: "max non-overlapping", "min number of", "can you reach"
```
