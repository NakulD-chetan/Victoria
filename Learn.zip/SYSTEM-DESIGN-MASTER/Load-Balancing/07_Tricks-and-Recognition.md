# Load Balancing — Tricks and Recognition (Deep Understanding)

> **Permanent Recall:** When to add LB: any design with "multiple servers" or "scale" or "HA." Placement: between clients and server pool. Algorithm shortcuts: Chat → consistent hashing/sticky; API → round robin; cache → consistent hashing; variable duration → least connections. Recognition triggers: "distribute traffic," "high availability," "zero-downtime deploy."

---

## Trick 1: Instant Recognition — When to Add LB

**The simple rule:** If you drew 2+ servers doing the same job, add a load balancer in front.

| What You Hear/Draw in Interview | Instant LB Decision |
|--------------------------------|---------------------|
| "We need multiple servers" | Add LB. Always. |
| "Scale horizontally" | LB + more server instances |
| "High availability" | LB + health checks + at least 2 servers |
| "Zero-downtime deploy" | LB + connection draining |
| "Millions of requests" | LB + auto-scaling behind it |
| "Users worldwide" | GSLB + regional LBs |
| "Microservices" | L7 LB (path routing) or service mesh |
| "Read replicas" | L4 LB in front of replicas |
| "Cache cluster" | Consistent hashing (not a traditional LB, but same distribution concept) |

### What NOT to Add LB For

| Scenario | Why No LB |
|----------|-----------|
| Single server (prototype/MVP) | Nothing to balance |
| Client connecting to one specific DB primary (writes) | One destination, no distribution needed |
| Kafka/SQS consumers | Pull-based — consumers pull messages; no LB needed |
| Serverless (Lambda, Cloud Functions) | Platform manages routing internally |
| Peer-to-peer communication | No central routing point |

---

## Trick 2: Algorithm Selection in 5 Seconds

When the interviewer asks "what algorithm?", use this instant decision framework:

```
┌─────────────────────────────────────────────────────────┐
│          5-SECOND ALGORITHM DECISION                    │
│                                                         │
│  Q1: Does same client need same server?                 │
│      YES → Is it for CACHE? → Consistent Hashing        │
│      YES → Is it for SESSION? → Cookie Sticky Sessions   │
│      NO  → Continue to Q2                               │
│                                                         │
│  Q2: Do requests take very different times?              │
│      YES → Least Connections                            │
│      NO  → Continue to Q3                               │
│                                                         │
│  Q3: Are servers different sizes?                        │
│      YES → Weighted Round Robin                          │
│      NO  → Round Robin ✅ (default)                     │
└─────────────────────────────────────────────────────────┘
```

### Quick Cheat Sheet (Memorize This)

| System Type | Algorithm | One-Sentence Reason |
|-------------|-----------|---------------------|
| Stateless REST API | **Round Robin** | All requests are equal, all servers are equal |
| API with mixed server sizes | **Weighted Round Robin** | Big server = more weight = more traffic |
| Chat / WebSocket | **Sticky + Least Conn** | Long-lived connections need affinity + load awareness |
| Cache pool (memcached, Redis) | **Consistent Hashing** | Scale in/out without destroying all caches |
| File upload / video processing | **Least Connections** | Long uploads; balance by active work, not just count |
| Search / heavy compute | **Least Connections** | Query times vary wildly (10ms vs 5s) |
| Microservices (per service) | **L7 path routing + RR per pool** | Route by path first, then distribute within pool |
| Database read replicas | **Round Robin or Least Conn** | Reads are often similar; LC if query times vary |

---

## Trick 3: L4 vs L7 Decision in 3 Seconds

```
Does your backend speak HTTP?
  YES → L7 (can route by path, terminate SSL, read headers)
  NO  → L4 (raw TCP/UDP forwarding)

Do you need path-based routing?
  YES → MUST use L7
  NO  → L4 is simpler and faster

Do you need SSL termination at the LB?
  YES → L7 (L4 does pass-through; can't decrypt)
  NO  → L4 works fine
```

### Instant Reference

| Protocol | Use L4 or L7 | Why |
|----------|-------------|-----|
| HTTP/HTTPS API | **L7** | Path routing, SSL termination, headers |
| gRPC | **L7** | gRPC is HTTP/2; L7 can route by service |
| WebSocket | **L7** | Starts as HTTP upgrade; L7 handles it |
| PostgreSQL/MySQL | **L4** | Binary TCP protocol; L7 can't parse it |
| Redis | **L4** | RESP protocol over TCP; not HTTP |
| Custom TCP game server | **L4** | Custom protocol; L7 doesn't apply |
| UDP (DNS, gaming, video) | **L4** | L7 is HTTP-only; UDP needs L4 |
| MQTT (IoT) | **L4** | Binary protocol; L4 forwards TCP |

---

## Trick 4: Where to Place LB in Your Architecture Diagram

### The Rule: LB Goes Between Layers

```
LAYER 1: Clients (browsers, mobile apps)
    ↓
  [LB] ← HERE (between internet and your services)
    ↓
LAYER 2: Web servers / API gateway
    ↓
  [LB] ← HERE (between web tier and app tier, IF they're separate)
    ↓
LAYER 3: Application servers
    ↓
  [LB] ← HERE (between app servers and DB read replicas)
    ↓
LAYER 4: Database read replicas
```

### Common LB Placements in System Design

```
TYPICAL WEB APP:
  Internet → [L7 LB (ALB)] → [App Servers x5] → [DB Primary]
                                                    ↓
                                              [L4 LB] → [Read Replicas x3]

MICROSERVICES:
  Internet → [API Gateway / L7 LB]
                  ├─ /users → [User Service x3]
                  ├─ /orders → [Order Service x3]
                  └─ /search → [Search Service x5]
              (Each service may have internal LB to reach its dependencies)

GLOBAL SERVICE:
  User → [DNS/GSLB] → [Regional L4 LB] → [Regional L7 LB] → [Regional Servers]
```

### Places NOT to Put LB

```
❌ Between app and its local in-memory cache (same process, no network)
❌ Between app and message queue consumer (consumers pull, not push)
❌ Between Lambda functions (platform handles it)
❌ Between primary DB and app for writes (one primary, no distribution)
```

---

## Trick 5: Recognize System Type → Instantly Know LB Config

### The Master Recognition Table

| System You're Designing | LB Layer | Algorithm | Special Considerations | Say This in Interview |
|------------------------|----------|-----------|----------------------|----------------------|
| **URL Shortener** | L7 | Round Robin | Stateless reads. Read-heavy. | *"L7 LB with round robin. Reads are stateless and fast. Writes go to primary via separate path."* |
| **Chat (WhatsApp)** | L7 | Sticky (Consistent Hash) | WebSocket, long-lived. Need reconnect strategy. | *"L7 with sticky sessions for WebSocket affinity. State in Redis for reconnect to any server."* |
| **Video Streaming (Netflix)** | L4 + CDN | Least Connections | CDN handles 95% of traffic. LB only for origin. | *"CDN for edge. L4 LB at origin with least-conn (transcoding takes variable time)."* |
| **Twitter/Feed** | L7 | Path routing + RR/LC | Separate read (timeline) and write (tweet). | *"L7 for path routing: /compose → write-service, /feed → read-service. RR within each pool."* |
| **Uber/Ride-sharing** | GSLB + L7 | Geo + Sticky | Real-time matching, location-based. | *"GSLB for geo-routing. L7 with sticky for driver-rider matching within region."* |
| **E-commerce (Amazon)** | L7 | Path routing + Sticky for cart | Cart = stateful, search = stateless. | *"L7 path routing: /search (stateless, RR), /cart (sticky), /checkout (sticky + HTTPS)."* |
| **Gaming server** | L4 | Least Connections | UDP for real-time, TCP for lobby. Low latency critical. | *"L4 for UDP game traffic. Least-conn to balance game sessions."* |
| **Database replicas** | L4 | RR or Least Conn | PostgreSQL binary protocol. | *"L4 TCP load balancer (e.g., PgBouncer or HAProxy TCP mode). Least-conn if queries vary."* |
| **CDN origin** | L7 or L4 | RR | CDN pulls from origin. Simple distribution. | *"Simple L4/L7 LB at origin. CDN handles most traffic; origin LB just distributes cache misses."* |
| **Kafka / Message Queue** | None | N/A | Consumers pull directly from brokers. | *"No LB needed. Kafka clients connect to brokers directly via metadata bootstrap."* |
| **Microservices mesh** | Service mesh (Envoy sidecar) | Varies per service | Sidecar handles inter-service LB. | *"Service mesh with Envoy sidecars. Each sidecar load-balances to the target service instances."* |

---

## Trick 6: Common Interview Patterns That Need LB

### Pattern: "How Would You Handle 10x Traffic?"

```
Current: 1 server handles 100 req/s
10x: Need to handle 1000 req/s

Answer Framework:
1. "Add 10 servers behind a load balancer" (horizontal scaling)
2. "Round robin for stateless API, least-conn if requests vary"
3. "Auto-scaling group so we scale automatically on traffic increase"
4. "LB health checks to handle server failures"
```

### Pattern: "How Do You Ensure Zero Downtime?"

```
Answer Framework:
1. "Multiple servers behind LB" (redundancy)
2. "Rolling deployment: add new servers, drain old ones" (LB connection draining)
3. "Health checks: LB routes only to healthy servers" (auto-recovery)
4. "Blue-green or canary deployment behind LB" (safe rollout)
```

### Pattern: "What if a Server Crashes?"

```
Answer Framework:
1. "LB detects via health checks (5s interval, 3 failure threshold)"
2. "Within 15 seconds, LB removes crashed server from pool"
3. "Traffic redistributed to remaining healthy servers"
4. "Auto-scaling replaces crashed server with a new instance"
5. "Users experience minimal disruption (maybe 1-2 failed requests during detection)"
```

### Pattern: "Design for Global Users"

```
Answer Framework:
1. "GSLB (Route53 latency-based routing) routes to nearest region"
2. "Each region has its own LB + server pool"
3. "Failover: if one region goes down, GSLB routes to next nearest"
4. "Data replication between regions for consistency"
```

---

## Trick 7: Recognizing LB Trigger Phrases

| Phrase You Hear | What It Implies | What to Add |
|-----------------|-----------------|-------------|
| "Distribute traffic" | Need LB | LB with appropriate algorithm |
| "High availability" | Need redundancy | LB + multiple servers + health checks |
| "Fault tolerance" | Need failure handling | LB health checks + auto-recovery |
| "Horizontal scaling" | Need more servers | LB + auto-scaling group |
| "Zero-downtime deploy" | Need graceful transition | LB + connection draining |
| "Multiple instances" | Already have multiple servers | Put LB in front |
| "Stateless services" | Any algorithm works | LB + round robin (simplest) |
| "Session affinity" | Same user → same server | LB + sticky sessions (cookie) |
| "Path-based routing" | Different paths → different services | L7 LB (ALB, Nginx) |
| "SSL termination" | Decrypt HTTPS at one place | L7 LB with certificate |
| "Microservices" | Multiple services, different paths | L7 LB or API gateway or service mesh |
| "Cache cluster" | Distributed cache | Consistent hashing (not traditional LB) |
| "Read replicas" | Multiple DB copies for reads | L4 LB in front of replicas |
| "CDN" | Edge caching | CDN for edge; LB at origin |
| "Real-time / WebSocket" | Long-lived connections | L7 LB with WebSocket support + sticky |

---

## Trick 8: The LB Conversation Flow in Interview

### Step-by-Step What to Do

```
STEP 1: Draw your system (boxes for each component)
  "We have clients, API servers, and a database"

STEP 2: The moment you have 2+ servers, add LB
  "Since we have multiple API servers, we put an LB here"
  [Draw LB box between clients and servers]

STEP 3: Specify the type
  "We'll use an L7 load balancer — we need path-based routing"
  (or "L4" if it's TCP/non-HTTP)

STEP 4: Specify the algorithm with one-line reasoning
  "Round robin, since our API is stateless"
  (or "Least connections, since request duration varies")

STEP 5: Mention health checks (shows production awareness)
  "Active health checks on /health every 5 seconds, 3-failure threshold"

STEP 6: STOP. Don't over-explain unless asked.
  If interviewer asks more → go deeper on SPOF, draining, etc.
```

### Example Flow for URL Shortener Design

```
YOU: "Users send requests to our API to create short URLs and resolve them.
      We have multiple API servers for scale.
      I'll put an L7 load balancer in front — ALB or Nginx —
      using round robin since reads are stateless.
      Health checks on /health every 5 seconds.
      For the write path, requests go through LB to any server,
      which writes to the database.
      For the read path (resolving short URLs), we'd cache in Redis.
      Redis cluster uses consistent hashing so adding/removing nodes
      doesn't invalidate all caches."

INTERVIEWER: "What if the LB fails?"

YOU: "We'd use AWS ALB which is inherently HA across availability zones.
      If self-managed, we'd run an active-passive Nginx pair with
      keepalived for VIP failover. Failover in <5 seconds."
```

---

## Trick 9: Numbers to Have Ready

| Metric | Typical Value | When to Mention |
|--------|--------------|-----------------|
| Health check interval | 5-10 seconds | When discussing health checks |
| Unhealthy threshold | 2-3 failures | When discussing health checks |
| Healthy threshold | 2 successes | When discussing server recovery |
| Connection drain timeout | 30-300 seconds | When discussing deploys |
| LB failover time (active-passive) | 1-5 seconds | When discussing SPOF |
| DNS TTL for LB | 30-60 seconds | When discussing DNS LB |
| Nginx connections per worker | 1000-10000 | When discussing capacity |
| Max connections (tuned) | 100K+ per LB | When discussing scale |
| ALB request rate | Millions per second | When discussing cloud LB |
| NLB connections | Millions concurrent | When discussing L4 performance |

---

## Quick Memory Card

```
WHEN TO ADD LB:     2+ servers doing same job → always add LB
ALGORITHM:          3 questions: Affinity? Duration varies? Server sizes?
L4 vs L7:           HTTP → L7. Non-HTTP → L4.
PLACEMENT:          Between layers (client→app, app→DB replicas)
URL SHORTENER:      L7, RR, stateless
CHAT:               L7, sticky, WebSocket
VIDEO:              L4/CDN, least-conn
E-COMMERCE:         L7, path routing, sticky for cart
DB REPLICAS:        L4, RR or LC
KAFKA:              No LB needed
INTERVIEW FLOW:     Draw → add LB → type → algorithm → health → stop
NUMBERS:            5s health interval, 3 fail threshold, 30-300s drain
```

---

**Next:** [[08_Question-List]]
