# 16. How Airbnb Works

## One-Line Summary
Airbnb is a hotel booking platform that handles ~1.5M bookings/day with a service-oriented architecture, solving the critical double-booking problem through ACID transactions, idempotency keys, and concurrency control (pessimistic/optimistic locking).

## Key Requirements
- **Functional**: Hotel search, availability check, reservation booking, payment processing, notifications
- **Scale**: ~1.5M bookings/day (~17 TPS writes), ~1000 read QPS (read-heavy workload)
- **Storage**: ~85K hotels, 4.3M rooms, 620M inventory rows (~62GB raw)
- **Critical constraint**: Prevent double booking when two users click "Book" on the last room simultaneously

## High-Level Architecture
```
[Client] → [API Gateway] → [Hotel Service] [Rate Service] [Reservation Service] [Payment Service] [Notification Service] [Search Service]
                              ↓                    ↓              ↓
                         [PostgreSQL]         [Redis]      [Elasticsearch]
```

- **API Gateway**: Auth, rate limiting, routing
- **Service-oriented architecture**: Hotel Service, Rate Service, Reservation Service, Payment Service, Notification Service, Search Service
- **PostgreSQL** for ACID transactions (reservations + inventory)
- **Redis** for caching
- **Elasticsearch** for search
- **CDN** for static assets (hotel images)

## Core Components Deep Dive

### The Double Booking Problem
Two users click "Book" on the last available room simultaneously. Both see availability, both get charged. **Solution**: Keep reservation + inventory data in the **same database** for local ACID transactions (avoid distributed transactions).

### Concurrency Handling
- **Pessimistic locking**: `SELECT FOR UPDATE` — lock the row during reservation
- **Optimistic locking**: Version check — compare version before commit, retry on conflict

### Idempotency
- **Idempotency key** on reservation requests to prevent double booking from duplicate UI clicks (e.g., user double-clicks "Book")

### Data Consistency
- **Strong consistency** for inventory and reservations (ACID)
- **Eventual consistency** acceptable for search index

## Key Design Decisions
1. **Reservation + inventory in same DB** — Enables local ACID transactions; avoids distributed transaction complexity
2. **PostgreSQL for transactional data** — ACID guarantees for bookings
3. **Idempotency keys** — Prevent duplicate charges from UI retries
4. **Pessimistic vs optimistic locking** — Trade-off between blocking and retry overhead
5. **CDN for images** — Offload static asset delivery

## Scaling Strategies
- **Read scaling**: Redis cache-aside for hot data
- **Search scaling**: Elasticsearch for full-text and geo search
- **Write scaling**: ~17 TPS is modest; single PostgreSQL can handle; shard by hotel/region if needed
- **Static assets**: CDN for hotel images

## Interview Tips
- Lead with the double-booking problem — it's the core challenge
- Emphasize why reservation + inventory must be in the same DB (ACID)
- Discuss idempotency keys for UI retries
- Compare pessimistic vs optimistic locking trade-offs
- Mention read-heavy vs write-heavy (1000 read QPS vs 17 write TPS)

## Quick Revision
- **Double booking**: Same DB for reservation + inventory; idempotency keys; SELECT FOR UPDATE or version check
- **Scale**: ~1.5M bookings/day, ~17 TPS writes, ~1000 read QPS
- **Stack**: PostgreSQL (ACID), Redis (cache), Elasticsearch (search)
- **Critical**: Strong consistency for inventory; eventual consistency OK for search
- **Services**: Hotel, Rate, Reservation, Payment, Notification, Search
