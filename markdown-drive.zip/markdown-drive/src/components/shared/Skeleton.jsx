import React from 'react';

export function Skeleton({ width, height, rounded, className = '', style = {} }) {
  return (
    <div
      className={`dc-skeleton ${className}`}
      style={{
        width: typeof width === 'number' ? `${width}px` : width,
        height: typeof height === 'number' ? `${height}px` : height,
        borderRadius: rounded || '6px',
        ...style,
      }}
    />
  );
}

export function SkeletonCard() {
  return (
    <div className="dc-algo-card dc-algo-card--skeleton">
      <div className="dc-algo-card__top">
        <Skeleton width={40} height={40} rounded="50%" />
        <div style={{ flex: 1 }}>
          <Skeleton width={140} height={16} style={{ marginBottom: 6 }} />
          <Skeleton width={80} height={12} />
        </div>
        <Skeleton width={50} height={22} rounded="12px" />
      </div>
      <Skeleton width="100%" height={14} style={{ marginTop: 12 }} />
      <Skeleton width="80%" height={14} style={{ marginTop: 6 }} />
      <div style={{ display: 'flex', gap: 4, marginTop: 10 }}>
        <Skeleton width={50} height={18} rounded="9px" />
        <Skeleton width={60} height={18} rounded="9px" />
        <Skeleton width={45} height={18} rounded="9px" />
      </div>
    </div>
  );
}

export function SkeletonDetail() {
  return (
    <div className="dc-skeleton-detail">
      <div className="dc-skeleton-detail__header">
        <Skeleton width={32} height={32} rounded="8px" />
        <Skeleton width={250} height={28} />
      </div>
      <div className="dc-skeleton-detail__tabs">
        <Skeleton width={120} height={36} rounded="18px" />
        <Skeleton width={120} height={36} rounded="18px" />
      </div>
      <div className="dc-skeleton-detail__body">
        <Skeleton width="100%" height={20} style={{ marginBottom: 12 }} />
        <Skeleton width="100%" height={16} style={{ marginBottom: 8 }} />
        <Skeleton width="90%" height={16} style={{ marginBottom: 8 }} />
        <Skeleton width="95%" height={16} style={{ marginBottom: 8 }} />
        <Skeleton width="70%" height={16} style={{ marginBottom: 16 }} />
        <Skeleton width="100%" height={20} style={{ marginBottom: 12 }} />
        <Skeleton width="100%" height={16} style={{ marginBottom: 8 }} />
        <Skeleton width="85%" height={16} style={{ marginBottom: 8 }} />
        <Skeleton width="60%" height={16} />
      </div>
    </div>
  );
}

export function SkeletonTutorial() {
  return (
    <div className="dc-tutorial dc-tutorial--skeleton">
      <div className="dc-tutorial__header">
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          <Skeleton width={80} height={32} rounded="16px" />
          <Skeleton width={80} height={32} rounded="16px" />
        </div>
        <Skeleton width={300} height={16} />
      </div>
      <div className="dc-tutorial__cards">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="dc-tutorial__card dc-tutorial__card--skeleton" style={{ padding: '24px', display: 'flex', gap: '24px', background: 'var(--surface-light)', borderRadius: '12px', border: '1px solid var(--border)' }}>
            <div className="dc-tutorial__text" style={{ flex: 1 }}>
              <Skeleton width="40%" height={28} style={{ marginBottom: 20 }} />
              <Skeleton width="100%" height={16} style={{ marginBottom: 12 }} />
              <Skeleton width="95%" height={16} style={{ marginBottom: 12 }} />
              <Skeleton width="90%" height={16} style={{ marginBottom: 12 }} />
              <Skeleton width="70%" height={16} />
            </div>
            <Skeleton width="300px" height={240} rounded="8px" />
          </div>
        ))}
      </div>
    </div>
  );
}

export function SkeletonPlayground() {
  return (
    <div className="dc-skeleton-playground">
      <div className="dc-skeleton-playground__controls">
        <Skeleton width={80} height={32} rounded="6px" />
        <Skeleton width={80} height={32} rounded="6px" />
        <Skeleton width={60} height={32} rounded="6px" />
      </div>
      <Skeleton width="100%" height={300} rounded="12px" className="dc-skeleton-playground__canvas" />
      <div className="dc-skeleton-playground__bottom">
        <Skeleton width="100%" height={200} rounded="8px" />
      </div>
    </div>
  );
}

export function SkeletonSystemDesignPlayground() {
  return (
    <div className="dc-playground dc-playground--skeleton" aria-busy="true" aria-live="polite">
      <div className="dc-question-panel dc-question-panel--skeleton">
        <div className="dc-question-panel__select-wrap">
          <Skeleton width="100%" height={34} rounded="8px" />
        </div>
        <div className="dc-question-panel__tabs">
          <Skeleton width="33.33%" height={40} rounded="0" />
          <Skeleton width="33.33%" height={40} rounded="0" />
          <Skeleton width="33.33%" height={40} rounded="0" />
        </div>
        <div className="dc-question-panel__body dc-question-panel__body--skeleton">
          <div className="dc-question-panel__title-row">
            <Skeleton width="72%" height={22} />
            <Skeleton width={64} height={22} rounded="12px" />
          </div>
          <Skeleton width="100%" height={14} style={{ marginBottom: 8 }} />
          <Skeleton width="92%" height={14} style={{ marginBottom: 18 }} />

          {Array.from({ length: 3 }).map((_, section) => (
            <div key={section} className="dc-skeleton-sd__section">
              <Skeleton width={150 - (section * 18)} height={12} style={{ marginBottom: 10 }} />
              <Skeleton width="100%" height={14} style={{ marginBottom: 8 }} />
              <Skeleton width="88%" height={14} style={{ marginBottom: 8 }} />
              <Skeleton width="76%" height={14} />
            </div>
          ))}
        </div>
      </div>

      <div className="dc-playground__center dc-playground__center--skeleton">
        <div className="dc-top-bar dc-top-bar--skeleton">
          <div className="dc-skeleton-sd__toolbar-group">
            <Skeleton width={74} height={24} rounded="10px" />
            <Skeleton width={84} height={24} rounded="10px" />
            <Skeleton width={66} height={24} rounded="10px" />
          </div>
          <div className="dc-skeleton-sd__toolbar-group">
            <Skeleton width={30} height={28} rounded="7px" />
            <Skeleton width={30} height={28} rounded="7px" />
            <Skeleton width={52} height={20} rounded="10px" />
          </div>
        </div>

        <div className="dc-skeleton-sd__canvas-wrap">
          <div className="dc-skeleton-sd__config-panel">
            <Skeleton width="100%" height={96} rounded="12px" />
            <Skeleton width="100%" height={74} rounded="12px" />
          </div>
          <div className="dc-skeleton-sd__canvas">
            <div className="dc-skeleton-sd__canvas-grid" />
            <Skeleton className="dc-skeleton-sd__canvas-badge" width={130} height={18} rounded="10px" />
            <Skeleton className="dc-skeleton-sd__canvas-shortcuts" width={168} height={16} rounded="8px" />
          </div>
        </div>

        <div className="dc-test-panel dc-test-panel--skeleton">
          <div className="dc-test-panel__header">
            <Skeleton width={160} height={18} />
            <div className="dc-skeleton-sd__test-actions">
              <Skeleton width={48} height={24} rounded="8px" />
              <Skeleton width={62} height={24} rounded="8px" />
            </div>
          </div>
          <div className="dc-test-panel__body">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="dc-skeleton-sd__test-row">
                <Skeleton width={16} height={16} rounded="50%" />
                <Skeleton width={`${72 - (i * 8)}%`} height={13} />
                <Skeleton width={44} height={14} rounded="6px" />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="dc-comp-sidebar dc-comp-sidebar--skeleton">
        <div className="dc-comp-sidebar__search">
          <Skeleton width="100%" height={24} rounded="6px" />
        </div>
        <div className="dc-comp-sidebar__grid">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="dc-comp-tile dc-comp-tile--skeleton" aria-hidden>
              <Skeleton width={22} height={22} rounded="6px" />
              <Skeleton width="78%" height={10} />
            </div>
          ))}
        </div>
        <div className="dc-comp-sidebar__tools">
          <Skeleton width="100%" height={26} rounded="8px" />
          <Skeleton width="100%" height={26} rounded="8px" />
        </div>
      </div>
    </div>
  );
}

export function SkeletonTableRow() {
  return (
    <div className="dc-problem-row dc-problem-row--skeleton" aria-hidden>
      <span className="dc-problem-row__num">
        <Skeleton width={20} height={12} />
      </span>
      <span className="dc-problem-row__icon-wrap">
        <Skeleton width={28} height={28} rounded="6px" />
      </span>
      <span className="dc-problem-row__title" style={{ display: 'flex', alignItems: 'center' }}>
        <Skeleton width="68%" height={14} />
      </span>
      <span className="dc-problem-row__diff">
        <Skeleton width={56} height={18} rounded="6px" style={{ marginLeft: 'auto' }} />
      </span>
    </div>
  );
}

export function SkeletonTagCloud() {
  return (
    <div className="dc-tag-cloud dc-tag-cloud--skeleton">
      {Array.from({ length: 8 }).map((_, i) => (
        <Skeleton key={i} width={60 + Math.random() * 40} height={28} rounded="14px" />
      ))}
    </div>
  );
}
