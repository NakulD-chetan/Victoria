# Apache Kafka — Complete Mastery Guide for Data Engineers

> **Permanent Recall Note:** Kafka is a **distributed commit log** and **streaming platform**: producers append **immutable records** to **topic partitions**; consumers **pull** and track **offsets**. For a **Data Engineer**, mastery means **ordering vs parallelism**, **replication/ISR**, **exactly-once trade-offs**, **Connect/Streams** in the ecosystem, and **operational signals** (lag, under-replication). This track mirrors the depth style of [../spark/00_Table_of_Contents.md](../spark/00_Table_of_Contents.md): architecture first, internals second, production third — and pairs naturally with **Spark Structured Streaming** when Kafka is the source/sink.

### The 10-Second Summary
- **Broker** = Kafka server; **Topic** = logical stream; **Partition** = ordered, parallel **unit of the log**.
- **Producer** batches + acks; **Consumer Group** divides partitions; **offset** = cursor per (group, partition).
- **KRaft** replaces ZooKeeper for metadata; replication uses **leader + followers** and **ISR**.
- **Data Engineer superpowers:** partition keys, consumer lag, `min.insync.replicas`, idempotent/transactional producers, Connect SMTs, schema evolution.

---

## Symbol Guide

| Symbol | Meaning |
|--------|---------|
| 💡 | Key Insight — understand this deeply |
| ⚠️ | Warning / Common Mistake |
| 🧠 | Memory Trick — for quick recall |
| 🏗️ | Real-World / Production Example |
| 📏 | Golden Rule |
| 🔄 | Trade-off to consider |
| 🎯 | Interview / On-Call Tip |
| 🔥 | Clean Trick / Pro Tip |
| ⚡ | Kafka-specific config / CLI note |

---

## Study Path

### Phase 1: Foundations — Log Model & Cluster Anatomy (Week 1)

| # | Topic | File | Priority |
|---|-------|------|----------|
| 1 | Kafka Architecture & DNA | [01_Kafka_Architecture_DNA.md](./01_Kafka_Architecture_DNA.md) | 🔴 Must |
| 2 | Topics, Partitions & Offsets | [02_Topics_Partitions_Offsets.md](./02_Topics_Partitions_Offsets.md) | 🔴 Must |
| 3 | Producers — Batching, Acks, Idempotence | [03_Producers_Deep_Dive.md](./03_Producers_Deep_Dive.md) | 🔴 Must |

### Phase 2 — Consumers, Brokers & Consistency (Week 2)

| # | Topic | File | Priority |
|---|-------|------|----------|
| 4 | Consumers & Consumer Groups | [04_Consumers_Consumer_Groups.md](./04_Consumers_Consumer_Groups.md) | 🔴 Must |
| 5 | Broker Replication, ISR & Logs | [05_Broker_Replication_ISR.md](./05_Broker_Replication_ISR.md) | 🔴 Must |
| 6 | Exactly-Once & Transactions | [06_Exactly_Once_Transactions.md](./06_Exactly_Once_Transactions.md) | 🔴 Must |

### Phase 3 — Ecosystem: Connect, Streams, Schema (Week 3)

| # | Topic | File | Priority |
|---|-------|------|----------|
| 7 | Kafka Connect | [07_Kafka_Connect.md](./07_Kafka_Connect.md) | 🔴 Must |
| 8 | Kafka Streams & ksqlDB | [08_Kafka_Streams_ksqlDB.md](./08_Kafka_Streams_ksqlDB.md) | 🟡 Important |
| 9 | Schema Registry & Serialization | [09_Schema_Registry_Serialization.md](./09_Schema_Registry_Serialization.md) | 🔴 Must |

### Phase 4 — Production, Pipelines & Interviews (Week 4)

| # | Topic | File | Priority |
|---|-------|------|----------|
| 10 | Performance Tuning & Monitoring | [10_Performance_Tuning_Monitoring.md](./10_Performance_Tuning_Monitoring.md) | 🔴 Must |
| 11 | Kafka in Data Pipelines | [11_Kafka_in_Data_Pipelines.md](./11_Kafka_in_Data_Pipelines.md) | 🔴 Must |
| 12 | Common Mistakes & Tricks | [12_Common_Mistakes_Tricks.md](./12_Common_Mistakes_Tricks.md) | 🔴 Must |
| 13 | Data Engineer Interview Guide | [13_DE_Interview_Guide_Kafka.md](./13_DE_Interview_Guide_Kafka.md) | 🔴 Must |

### Daily Recall

| # | Topic | File | Priority |
|---|-------|------|----------|
| 📝 | Daily Recall — Kafka | [Quick_Revision/Daily_Recall_Kafka.md](./Quick_Revision/Daily_Recall_Kafka.md) | 🔴 Daily |

---

## The One-Page Architecture Cheat Sheet

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  PRODUCERS (batch, compress, partition)                                      │
│       │ acks / retries / idempotence / transactions                          │
└───────┼─────────────────────────────────────────────────────────────────────┘
        │ Produce API
        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  CLUSTER — BROKERS (KRaft or ZK metadata)                                    │
│  TOPIC = logical name                                                        │
│    └── PARTITION 0..N-1  (ordered log, leader broker each)                  │
│           └── SEGMENTS on disk (.log, .index, .timeindex)                      │
│  REPLICATION: Leader + Followers; ISR = in-sync subset                       │
└─────────────────────────────────────────────────────────────────────────────┘
        │ Fetch API (pull)
        ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│  CONSUMER GROUP — one active consumer per partition (assignment)             │
│  OFFSET = position; __consumer_offsets stores commits (group protocol)       │
└─────────────────────────────────────────────────────────────────────────────┘

ECOSYSTEM: Connect (sources/sinks) | Streams/ksql (stateful) | Schema Registry
CROSS-REF: Spark reads Kafka via structured streaming — see ../spark/10_Structured_Streaming_DE.md
```

🧠 **Memory Trick — "TOP-BRO-COG":** **T**opic parts the stream, **B**roker **r**eplicates **o**ffset **g**rids per partition, **C**onsumer **g**roup **o**wns **g**aps in **l**ag if slow.

---

## How to Use These Notes

1. Read **01 → 02 → 04 → 05** first — without ordering, replication, and groups, tuning is guesswork.
2. Run **kafka-console-producer/consumer** and watch **consumer lag** in metrics or UI.
3. Pair with **one** schema story (Avro + Registry) and **one** pipeline (Connect or Spark/Flink).
4. Use **Daily Recall** for 10 minutes each morning; redraw the cheat sheet from memory weekly.

---

> **Scope:** Content targets **Kafka 3.x** concepts (KRaft metadata mode, cooperative rebalancing). Cluster defaults may differ by vendor (Confluent Platform, MSK, Strimzi).
