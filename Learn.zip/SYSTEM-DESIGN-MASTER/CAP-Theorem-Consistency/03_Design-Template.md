# CAP Theorem and Consistency — Design Template

> **Permanent Recall:** CP systems use leader-based replication, quorum writes, and block or reject during partitions. AP systems use multi-master or leaderless replication, allow reads/writes during partitions, and resolve conflicts eventually. Tunable consistency (Cassandra-style) lets you choose read/write level per operation. Quorum config follows R+W>N. Conflict resolution pattern: detect (vector clocks), merge (LWW, CRDT), or escalate (application).

---

## CP System Design Template

**When to use:** Financial data, inventory, config, distributed locks. Stale reads are unacceptable.

```
ARCHITECTURE (CP - Leader-Based):

                    ┌─────────────────┐
                    │     Client      │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │   Leader Node   │  ← Single writer
                    │  (via Raft/     │
                    │   Paxos)        │
                    └────────┬────────┘
                             │
              ┌──────────────┼──────────────┐
              ▼              ▼              ▼
        ┌─────────┐   ┌─────────┐   ┌─────────┐
        │Follower │   │Follower │   │Follower │
        └─────────┘   └─────────┘   └─────────┘

During partition: If quorum lost → reject writes/reads (unavailable)
```

**Config example:**
```yaml
consistency: CP
replication: leader-based
consensus: Raft
quorum: 2 of 3 for read/write
partition_behavior: reject_if_no_quorum
```

---

## AP System Design Template

**When to use:** Social feeds, analytics, session data, likes. Stale reads acceptable.

```
ARCHITECTURE (AP - Leaderless / Multi-Master):

    ┌─────────┐     ┌─────────┐     ┌─────────┐
    │ Node A  │     │ Node B  │     │ Node C  │
    │ Read/   │◄───►│ Read/   │◄───►│ Read/   │
    │ Write   │     │ Write   │     │ Write   │
    └─────────┘     └─────────┘     └─────────┘
         │                │                │
         └────────────────┼────────────────┘
                          │
                   (Eventual sync)

During partition: All nodes accept reads/writes. Conflict resolution later.
```

**Config example:**
```yaml
consistency: AP
replication: multi-master
write_acks: ONE  # or QUORUM for durability
read_consistency: ONE  # or QUORUM for stronger
conflict_resolution: LWW  # or merge, application
```

---

## Tunable Consistency Template (Cassandra-Style)

**When to use:** Mixed workload—some ops need strong, others tolerate eventual.

| Level | Read | Write | Use Case |
|-------|------|-------|----------|
| **ONE** | Any 1 replica | Any 1 ack | Lowest latency, eventual |
| **TWO / LOCAL_QUORUM** | 2 replicas | 2 acks | Balance |
| **QUORUM** | Majority | Majority | Strong consistency |
| **ALL** | All replicas | All acks | Strongest, highest latency |

```
Tunable per operation:

  read(user_id, consistency=QUORUM)   # Balance check
  read(feed, consistency=ONE)         # Feed can be stale
  write(order, consistency=QUORUM)  # Order must persist
  write(like, consistency=ONE)       # Like can be eventual
```

**Config example:**
```yaml
default_read: ONE
default_write: ONE
critical_reads: QUORUM  # Override for balance, etc.
critical_writes: QUORUM
```

---

## Quorum Configuration Template

**Rule:** `R + W > N` for strong consistency. `R + W = N + 1` is common.

| N | R | W | Overlap | Use |
|---|---|---|---------|-----|
| 3 | 2 | 2 | 1 | Balanced strong |
| 3 | 3 | 1 | 0 | Write-optimized, read-heavy |
| 3 | 1 | 3 | 0 | Read-optimized, write-heavy |
| 5 | 3 | 3 | 1 | Higher fault tolerance |

```
Overlap = R + W - N
If overlap >= 1 → reader sees at least one up-to-date replica
```

---

## Conflict Resolution Pattern Template

```
CONFLICT RESOLUTION FLOW:

1. DETECT: Vector clocks, version vectors
2. MERGE:  LWW, CRDT, application merge function
3. ESCALATE: Present to user (Google Docs style)
```

**LWW template:**
```yaml
conflict_resolution: last_writer_wins
timestamp_source: logical_clock  # or hybrid logical clock
```

**Merge template (CRDT):**
```yaml
conflict_resolution: merge
merge_type: CRDT  # e.g., LWW-Element-Set, OR-Set
```

**Application-level template:**
```yaml
conflict_resolution: application
merge_handler: custom_merge_function
```

---

## 30-SECOND REVISION BOX

```
CP: Leader + quorum, reject during partition
AP: Multi-master, serve always, resolve conflicts
TUNABLE: Per-op consistency (ONE, QUORUM, ALL)
QUORUM: R+W>N for strong read
CONFLICT: Detect → Merge (LWW/CRDT) or Escalate
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
