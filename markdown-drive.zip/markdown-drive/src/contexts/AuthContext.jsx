import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { supabase } from '../lib/supabase';

/*
 * AuthContext exposes the live Supabase session and the user's profile row.
 *
 * Components consume this with `const { user, profile, signOut } = useAuth()`
 * instead of reading localStorage directly. The context is also responsible
 * for upserting a row into public.profiles on first sign-in (the SQL trigger
 * does this server-side too, but having a client fallback keeps things smooth
 * during the migration window).
 */

const AuthContext = createContext({
  loading: true,
  session: null,
  user: null,
  profile: null,
  signOut: async () => {},
  refreshProfile: async () => {},
});

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    supabase.auth.getSession().then(({ data }) => {
      if (cancelled) return;
      setSession(data.session || null);
      setLoading(false);
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next || null);
    });

    return () => {
      cancelled = true;
      sub?.subscription?.unsubscribe?.();
    };
  }, []);

  useEffect(() => {
    if (!session?.user) {
      setProfile(null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, display_name, avatar_url')
        .eq('id', session.user.id)
        .maybeSingle();
      if (cancelled) return;
      if (data) {
        setProfile(data);
        return;
      }
      if (error && error.code !== 'PGRST116') {
        console.warn('[Auth] profile fetch failed:', error.message);
      }
      /* Fallback upsert in case the trigger has not run yet. */
      const fallback = {
        id: session.user.id,
        email: session.user.email || '',
        display_name:
          session.user.user_metadata?.full_name ||
          session.user.user_metadata?.name ||
          (session.user.email || '').split('@')[0],
        avatar_url: session.user.user_metadata?.avatar_url || null,
      };
      const { data: upserted } = await supabase
        .from('profiles')
        .upsert(fallback, { onConflict: 'id' })
        .select()
        .maybeSingle();
      if (!cancelled) setProfile(upserted || fallback);
    })();
    return () => {
      cancelled = true;
    };
  }, [session?.user?.id]);

  const value = useMemo(
    () => ({
      loading,
      session,
      user: session?.user || null,
      profile,
      signOut: async () => {
        await supabase.auth.signOut();
      },
      refreshProfile: async () => {
        if (!session?.user) return;
        const { data } = await supabase
          .from('profiles')
          .select('id, email, display_name, avatar_url')
          .eq('id', session.user.id)
          .maybeSingle();
        if (data) setProfile(data);
      },
    }),
    [loading, session, profile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  return useContext(AuthContext);
}
