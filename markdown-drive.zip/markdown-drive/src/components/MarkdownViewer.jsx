import { memo, useEffect, useRef, useState, useCallback, useMemo, lazy, Suspense } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import remarkCallout from '@r4ai/remark-callout';
import rehypeRaw from 'rehype-raw';
import rehypeKatex from 'rehype-katex';
import rehypeSlug from 'rehype-slug';
import rehypeAutolinkHeadings from 'rehype-autolink-headings';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark, oneLight } from 'react-syntax-highlighter/dist/esm/styles/prism';
import 'katex/dist/katex.min.css';
import { getAuthHeaders } from './AuthGate';
import AnnotationOverlay from './AnnotationOverlay';

const DrawCanvas = lazy(() => import('./DrawCanvas'));

const REMARK_PLUGINS = [remarkGfm, remarkMath, remarkCallout];
const REHYPE_PLUGINS = [
  rehypeRaw,
  rehypeKatex,
  rehypeSlug,
  [rehypeAutolinkHeadings, { behavior: 'append' }],
];

/* ── Throttle helper ─────────────────────────────────────────── */

function useThrottledCallback(fn, delay) {
  const lastRun = useRef(0);
  const timer = useRef(null);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  return useCallback((...args) => {
    const now = Date.now();
    const remaining = delay - (now - lastRun.current);
    clearTimeout(timer.current);
    if (remaining <= 0) {
      lastRun.current = now;
      fnRef.current(...args);
    } else {
      timer.current = setTimeout(() => {
        lastRun.current = Date.now();
        fnRef.current(...args);
      }, remaining);
    }
  }, [delay]);
}

/* ── Dark mode hook ──────────────────────────────────────────── */

function useIsDark() {
  const [dark, setDark] = useState(() =>
    document.documentElement.getAttribute('data-theme') === 'dark'
  );
  useEffect(() => {
    const obs = new MutationObserver(() => {
      setDark(document.documentElement.getAttribute('data-theme') === 'dark');
    });
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    return () => obs.disconnect();
  }, []);
  return dark;
}

/* ── Helpers ──────────────────────────────────────────────────── */

function isAsciiArt(code) {
  let score = 0;
  const lines = code.split('\n');
  const check = Math.min(lines.length, 20);
  for (let i = 0; i < check; i++) {
    const line = lines[i];
    if (/[│┌┐└┘─┬┴├┤┼╔╗╚╝═║]/.test(line)) score += 3;
    if (/[→←↓↑▼▲►◄]/.test(line)) score += 2;
    if (/-->|<--|->|<-|==>/.test(line)) score += 2;
    if (/\+[-=+]{2,}\+/.test(line)) score += 3;
    if (/\|.*\|/.test(line) && /[-+]/.test(line)) score += 1;
    if (score >= 4) return true;
  }
  return false;
}

function parseMeta(raw) {
  if (!raw) return {};
  const out = {};
  const titleMatch = raw.match(/title="([^"]+)"/);
  if (titleMatch) out.title = titleMatch[1];
  const hlMatch = raw.match(/\{([\d,\-\s]+)\}/);
  if (hlMatch) {
    const set = new Set();
    hlMatch[1].split(',').forEach(part => {
      const range = part.trim().split('-').map(Number);
      if (range.length === 2) for (let i = range[0]; i <= range[1]; i++) set.add(i);
      else set.add(range[0]);
    });
    out.highlight = set;
  }
  return out;
}

const CALLOUT_TYPES = {
  note: { color: '#3b82f6', icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z' },
  tip: { color: '#10a37f', icon: 'M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z' },
  warning: { color: '#f59e0b', icon: 'M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z' },
  danger: { color: '#ef4444', icon: 'M15.73 3H8.27L3 8.27v7.46L8.27 21h7.46L21 15.73V8.27L15.73 3zM12 17.3c-.72 0-1.3-.58-1.3-1.3 0-.72.58-1.3 1.3-1.3.72 0 1.3.58 1.3 1.3 0 .72-.58 1.3-1.3 1.3zm1-4.3h-2V7h2v6z' },
  info: { color: '#06b6d4', icon: 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z' },
  example: { color: '#8b5cf6', icon: 'M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z' },
};

/* ── CodeBlock ────────────────────────────────────────────────── */

const CodeBlock = memo(function CodeBlock({ className, children, node, isDark }) {
  const match = /language-(\w+)/.exec(className || '');
  const lang = match ? match[1] : '';
  const code = String(children).replace(/\n$/, '');
  const [copied, setCopied] = useState(false);
  const [collapsed, setCollapsed] = useState(true);
  const meta = useMemo(() => parseMeta(node?.data?.meta || node?.properties?.metastring || ''), [node]);
  const lines = useMemo(() => code.split('\n'), [code]);
  const isLong = lines.length > 25;
  const syntaxTheme = isDark ? oneDark : oneLight;

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [code]);

  const lineProps = useCallback((lineNumber) => {
    const style = {};
    if (meta.highlight?.has(lineNumber)) {
      style.backgroundColor = isDark ? 'rgba(255,255,100,0.08)' : 'rgba(245,158,11,0.12)';
      style.borderLeft = '2px solid #f59e0b';
      style.marginLeft = '-2px';
    }
    return { style };
  }, [meta.highlight, isDark]);

  const lineNumStyle = useMemo(() => ({
    color: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.25)',
    fontSize: '11px',
    minWidth: '2em',
  }), [isDark]);

  if (lang === 'mermaid') return <MermaidBlock code={code} />;

  if (!lang && isAsciiArt(code)) {
    return (
      <div className="ascii-block">
        <div className="ascii-block__header">
          <span className="ascii-block__label">Diagram</span>
          <CopyButton copied={copied} onClick={handleCopy} />
        </div>
        <pre className="ascii-block__pre">{code}</pre>
      </div>
    );
  }

  if (lang === 'diff') {
    return (
      <div className="code-wrapper">
        <div className="code-wrapper__header">
          <span className="code-wrapper__lang">{meta.title || 'diff'}</span>
          <CopyButton copied={copied} onClick={handleCopy} />
        </div>
        <pre className="code-diff">
          {lines.map((line, i) => {
            const cls = line.startsWith('+') ? 'diff-add' : line.startsWith('-') ? 'diff-del' : '';
            return <div key={i} className={`diff-line ${cls}`}>{line}</div>;
          })}
        </pre>
      </div>
    );
  }

  if (lang) {
    const displayCode = isLong && collapsed ? lines.slice(0, 15).join('\n') : code;
    return (
      <div className="code-wrapper">
        <div className="code-wrapper__header">
          <span className="code-wrapper__lang">{meta.title || lang}</span>
          <div className="code-wrapper__actions">
            {isLong && (
              <button className="code-toggle-btn" onClick={() => setCollapsed(c => !c)}>
                {collapsed ? `Show all ${lines.length} lines` : 'Collapse'}
              </button>
            )}
            <CopyButton copied={copied} onClick={handleCopy} />
          </div>
        </div>
        <SyntaxHighlighter
          style={syntaxTheme}
          language={lang}
          PreTag="div"
          className="code-block"
          showLineNumbers
          lineNumberStyle={lineNumStyle}
          wrapLines={!!meta.highlight}
          lineProps={meta.highlight ? lineProps : undefined}
        >
          {displayCode}
        </SyntaxHighlighter>
        {isLong && collapsed && <div className="code-fade" />}
      </div>
    );
  }

  if (lines.length > 2) {
    return (
      <div className="code-wrapper">
        <div className="code-wrapper__header">
          <span className="code-wrapper__lang">text</span>
          <CopyButton copied={copied} onClick={handleCopy} />
        </div>
        <pre className="code-plain"><code>{code}</code></pre>
      </div>
    );
  }

  return <code className={className}>{children}</code>;
});

/* ── CopyButton ──────────────────────────────────────────────── */

const CopyButton = memo(function CopyButton({ copied, onClick }) {
  return (
    <button className="code-copy-btn" onClick={onClick}>
      {copied ? (
        <><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg> Copied</>
      ) : (
        <><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg> Copy</>
      )}
    </button>
  );
});

/* ── MermaidBlock ─────────────────────────────────────────────── */

const MermaidBlock = memo(function MermaidBlock({ code }) {
  const ref = useRef(null);
  const isDark = useIsDark();
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { default: mermaid } = await import('mermaid');
        mermaid.initialize({
          startOnLoad: false,
          theme: isDark ? 'dark' : 'default',
          securityLevel: 'loose',
        });
        const id = `mermaid-${Math.random().toString(36).slice(2, 9)}`;
        const { svg } = await mermaid.render(id, code);
        if (!cancelled && ref.current) ref.current.innerHTML = svg;
      } catch (e) {
        if (!cancelled && ref.current) ref.current.innerHTML = `<pre class="mermaid-error">${e.message}</pre>`;
      }
    })();
    return () => { cancelled = true; };
  }, [code, isDark]);
  return <div ref={ref} className="mermaid-container" />;
});

/* ── CalloutBlock ─────────────────────────────────────────────── */

function extractText(children) {
  if (typeof children === 'string') return children;
  if (Array.isArray(children)) return children.map(extractText).join('');
  if (children?.props?.children) return extractText(children.props.children);
  return '';
}

const CalloutBlock = memo(function CalloutBlock({ children, node }) {
  const attrs = node?.properties || {};
  const calloutType = (attrs['data-callout'] || attrs.dataCallout || '').toLowerCase();
  const info = CALLOUT_TYPES[calloutType];

  if (!info) {
    const text = extractText(children);
    let type = 'note';
    if (/^(Warning|Caution)/i.test(text)) type = 'warning';
    else if (/^(Tip|Hint)/i.test(text)) type = 'tip';
    else if (/^(Danger|Error)/i.test(text)) type = 'danger';
    else if (/^(Info)/i.test(text)) type = 'info';
    else if (/^(Example)/i.test(text)) type = 'example';
    const fallback = CALLOUT_TYPES[type];
    return (
      <div className="callout" style={{ '--callout-color': fallback.color }}>
        <div className="callout__header">
          <svg width="16" height="16" viewBox="0 0 24 24" fill={fallback.color}><path d={fallback.icon} /></svg>
          <span className="callout__type">{type}</span>
        </div>
        <div className="callout__body">{children}</div>
      </div>
    );
  }

  const title = attrs['data-callout-title'] || attrs.dataCalloutTitle || calloutType;
  return (
    <div className="callout" style={{ '--callout-color': info.color }}>
      <div className="callout__header">
        <svg width="16" height="16" viewBox="0 0 24 24" fill={info.color}><path d={info.icon} /></svg>
        <span className="callout__type">{title}</span>
      </div>
      <div className="callout__body">{children}</div>
    </div>
  );
});

/* ── HeadingWithLink ──────────────────────────────────────────── */

const HeadingWithLink = memo(function HeadingWithLink({ level, children, id, ...props }) {
  const [copied, setCopied] = useState(false);
  const Tag = `h${level}`;
  const handleClick = useCallback((e) => {
    e.preventDefault();
    const url = `${window.location.origin}${window.location.pathname}#${id}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  }, [id]);

  return (
    <Tag id={id} className="md-heading" {...props}>
      {children}
      <a href={`#${id}`} className="md-heading__link" onClick={handleClick} aria-label="Copy link" title={copied ? 'Copied!' : 'Copy link'}>
        {copied ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></svg>
        )}
      </a>
    </Tag>
  );
});

/* ── ImageWithLightbox ────────────────────────────────────────── */

const ImageWithLightbox = memo(function ImageWithLightbox({ src, alt, onOpen, ...props }) {
  return (
    <figure className="md-figure">
      <img src={src} alt={alt || ''} loading="lazy" onClick={() => onOpen(src, alt)} className="md-figure__img" {...props} />
      {alt && <figcaption>{alt}</figcaption>}
    </figure>
  );
});

const Lightbox = memo(function Lightbox({ src, alt, onClose }) {
  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [onClose]);
  return (
    <div className="lightbox" onClick={onClose}>
      <button className="lightbox__close" onClick={onClose}>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
      </button>
      <img src={src} alt={alt || ''} className="lightbox__img" onClick={e => e.stopPropagation()} />
    </div>
  );
});

/* ── TaskListItem ─────────────────────────────────────────────── */

const TaskListItem = memo(function TaskListItem({ children, node, ...props }) {
  const checked = node?.properties?.checked ?? (node?.children?.[0]?.properties?.checked);
  if (checked === undefined || checked === null) return <li {...props}>{children}</li>;
  return (
    <li className={`task-item ${checked ? 'task-item--done' : ''}`} {...props}>
      <span className={`task-check ${checked ? 'task-check--checked' : ''}`}>
        {checked && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12" /></svg>}
      </span>
      <span className="task-text">{children}</span>
    </li>
  );
});

/* ── TOCSidebar ───────────────────────────────────────────────── */

const TOCSidebar = memo(function TOCSidebar({ headings, activeId }) {
  const navRef = useRef(null);
  const [pill, setPill] = useState({ top: 0, height: 0, visible: false });

  useEffect(() => {
    if (!navRef.current || !activeId) { setPill(p => ({ ...p, visible: false })); return; }
    const el = navRef.current.querySelector(`[data-toc-id="${activeId}"]`);
    if (!el) { setPill(p => ({ ...p, visible: false })); return; }
    const navRect = navRef.current.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    setPill({ top: elRect.top - navRect.top, height: elRect.height, visible: true });
    el.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
  }, [activeId]);

  if (!headings?.length) return null;

  return (
    <aside className="toc-sidebar">
      <div className="toc-sidebar__label"><span>On this page</span></div>
      <nav className="toc-sidebar__nav" ref={navRef}>
        <div
          className={`toc-sidebar__pill ${pill.visible ? 'toc-sidebar__pill--visible' : ''}`}
          style={{ '--pill-top': `${pill.top}px`, '--pill-h': `${pill.height}px` }}
        />
        {headings.map((h) => (
          <a
            key={h.id}
            data-toc-id={h.id}
            href={`#${h.id}`}
            className={`toc-sidebar__item ${activeId === h.id ? 'toc-sidebar__item--active' : ''}`}
            style={{ '--depth': Math.max(0, h.level - 2) }}
            onClick={(e) => { e.preventDefault(); document.getElementById(h.id)?.scrollIntoView({ behavior: 'smooth' }); }}
          >
            <span className="toc-sidebar__text">{h.text}</span>
          </a>
        ))}
      </nav>
    </aside>
  );
});

/* ── ReadingProgress ──────────────────────────────────────────── */

const ReadingProgress = memo(function ReadingProgress({ containerRef }) {
  const barRef = useRef(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const parent = el.closest('.content__scroll') || window;

    let rafId;
    const update = () => {
      const rect = el.getBoundingClientRect();
      const total = el.scrollHeight - window.innerHeight;
      let pct = 100;
      if (total > 0) {
        const scrolled = Math.max(0, -rect.top);
        pct = Math.min(100, (scrolled / total) * 100);
      }
      if (barRef.current) barRef.current.style.width = `${pct}%`;
    };

    const onScroll = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(update);
    };

    parent.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('scroll', onScroll, { passive: true });
    update();
    return () => {
      cancelAnimationFrame(rafId);
      parent.removeEventListener('scroll', onScroll);
      window.removeEventListener('scroll', onScroll);
    };
  }, [containerRef]);

  return <div ref={barRef} className="reading-progress" />;
});

/* ── BackToTop ────────────────────────────────────────────────── */

function BackToTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    let rafId;
    const check = () => {
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => setVisible(window.scrollY > 300));
    };
    window.addEventListener('scroll', check, { passive: true });
    check();
    return () => { cancelAnimationFrame(rafId); window.removeEventListener('scroll', check); };
  }, []);

  if (!visible) return null;
  return (
    <button className="back-to-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} title="Back to top">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="18 15 12 9 6 15" /></svg>
    </button>
  );
}

/* ── Section ──────────────────────────────────────────────────── */

const Section = memo(function Section({ content, onImageOpen, isDark }) {
  const components = useMemo(() => ({
    code: (p) => <CodeBlock {...p} isDark={isDark} />,
    h1: (p) => <HeadingWithLink level={1} {...p} />,
    h2: (p) => <HeadingWithLink level={2} {...p} />,
    h3: (p) => <HeadingWithLink level={3} {...p} />,
    h4: (p) => <HeadingWithLink level={4} {...p} />,
    table: ({ children, ...props }) => (<div className="table-wrapper"><table {...props}>{children}</table></div>),
    blockquote: CalloutBlock,
    img: (p) => <ImageWithLightbox {...p} onOpen={onImageOpen} />,
    li: TaskListItem,
  }), [isDark, onImageOpen]);

  return (
    <div className="md-section">
      <ReactMarkdown remarkPlugins={REMARK_PLUGINS} rehypePlugins={REHYPE_PLUGINS} components={components}>
        {content}
      </ReactMarkdown>
    </div>
  );
});

/* ── MarkdownViewer (main) ────────────────────────────────────── */

const MarkdownViewer = memo(function MarkdownViewer({ fileData: rawFileData, folder, filename, userId, theme, onViewModeChange }) {
  const fileData = rawFileData || { content: '', title: '', headings: [] };
  const isDark = useIsDark();
  const [sections, setSections] = useState([]);
  const [totalSections, setTotalSections] = useState(0);
  const [loadingMore, setLoadingMore] = useState(false);
  const [activeHeadingId, setActiveHeadingId] = useState(null);
  const [lightbox, setLightbox] = useState(null);
  const [viewMode, setViewMode] = useState('read');
  const [annotating, setAnnotating] = useState(false);
  const loaderRef = useRef(null);
  const articleRef = useRef(null);
  const layoutRef = useRef(null);

  useEffect(() => { onViewModeChange?.(viewMode); }, [viewMode, onViewModeChange]);

  useEffect(() => {
    if (!folder || !filename) {
      setSections([{ index: 0, content: fileData.content }]);
      setTotalSections(1);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}/sections?from=0&limit=3`, { headers: getAuthHeaders() });
        const data = await res.json();
        if (!cancelled && data.sections) { setSections(data.sections); setTotalSections(data.total); }
        else if (!cancelled) { setSections([{ index: 0, content: fileData.content }]); setTotalSections(1); }
      } catch { if (!cancelled) { setSections([{ index: 0, content: fileData.content }]); setTotalSections(1); } }
    })();
    return () => { cancelled = true; };
  }, [folder, filename, fileData.content]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !sections || sections.length >= totalSections) return;
    setLoadingMore(true);
    try {
      const from = sections.length;
      const res = await fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}/sections?from=${from}&limit=3`, { headers: getAuthHeaders() });
      const data = await res.json();
      if (data.sections) setSections(prev => [...prev, ...data.sections]);
    } catch { /* ignore */ }
    finally { setLoadingMore(false); }
  }, [loadingMore, sections?.length, totalSections, folder, filename]);

  useEffect(() => {
    if (!loaderRef.current || !sections || sections.length >= totalSections) return;
    const observer = new IntersectionObserver(
      entries => { if (entries[0].isIntersecting) loadMore(); },
      { rootMargin: '300px' }
    );
    observer.observe(loaderRef.current);
    return () => observer.disconnect();
  }, [loadMore, sections?.length, totalSections]);

  const updateActiveHeading = useThrottledCallback(() => {
    const scrollParent = articleRef.current?.closest('.content__scroll');
    if (!articleRef.current || !scrollParent) return;
    const hList = articleRef.current.querySelectorAll('h1[id], h2[id], h3[id], h4[id]');
    if (!hList?.length) return;
    const offset = scrollParent.getBoundingClientRect().top + 80;
    let active = hList[0]?.id;
    for (const h of hList) {
      if (h.getBoundingClientRect().top <= offset) active = h.id;
      else break;
    }
    setActiveHeadingId(active);
  }, 100);

  useEffect(() => {
    const scrollParent = articleRef.current?.closest('.content__scroll');
    if (!articleRef.current || !scrollParent) return;
    scrollParent.addEventListener('scroll', updateActiveHeading, { passive: true });
    updateActiveHeading();
    return () => scrollParent.removeEventListener('scroll', updateActiveHeading);
  }, [sections, updateActiveHeading]);

  const openLightbox = useCallback((src, alt) => setLightbox({ src, alt }), []);

  if (!fileData) return null;

  return (
    <div className={`markdown-viewer ${viewMode === 'draw' ? 'markdown-viewer--draw' : ''}`}>
      {viewMode === 'read' && <ReadingProgress containerRef={articleRef} />}

      {viewMode === 'read' && (
        <div className="viewer-topbar">
          <div className="viewer-topbar__breadcrumb">
            <span className="viewer-topbar__folder">{fileData.folder}</span>
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
            <span className="viewer-topbar__file">{fileData.name}</span>
          </div>

          <div className="viewer-topbar__tabs">
            <button className={`viewer-topbar__tab ${viewMode === 'read' ? 'viewer-topbar__tab--active' : ''}`} onClick={() => setViewMode('read')}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
              Read
            </button>
            <button className={`viewer-topbar__tab ${viewMode === 'draw' ? 'viewer-topbar__tab--active' : ''}`} onClick={() => setViewMode('draw')}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M12 19l7-7 3 3-7 7-3-3z" />
                <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
                <path d="M2 2l7.586 7.586" />
                <circle cx="11" cy="11" r="2" />
              </svg>
              Draw
            </button>
          </div>

          <div className="viewer-topbar__meta">
            <button
              className={`viewer-topbar__highlight-btn ${annotating ? 'viewer-topbar__highlight-btn--active' : ''}`}
              onClick={() => setAnnotating(a => !a)}
              title={annotating ? 'Exit annotation mode' : 'Annotate / Draw on page'}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M12 19l7-7 3 3-7 7-3-3z" />
                <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
                <path d="M2 2l7.586 7.586" />
                <circle cx="11" cy="11" r="2" />
              </svg>
            </button>
            <span className="viewer-topbar__stat">{fileData.wordCount?.toLocaleString()} words</span>
            <span className="viewer-topbar__stat">{fileData.readTime} min read</span>
            <a
              className="viewer-topbar__download"
              href={`data:text/markdown;charset=utf-8,${encodeURIComponent(fileData.content)}`}
              download={fileData.name}
              title="Download"
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
            </a>
          </div>
        </div>
      )}

      {viewMode === 'read' ? (
        <>
          <div className={`markdown-viewer__layout ${annotating ? 'markdown-viewer__layout--annotating' : ''}`} ref={layoutRef}>
            <article className="markdown-viewer__content" ref={articleRef}>
              {(sections || []).map((sec) => (
                <Section key={sec.index} content={sec.content} onImageOpen={openLightbox} isDark={isDark} />
              ))}

              {(sections || []).length < totalSections && (
                <div ref={loaderRef} className="md-section-loader">
                  <div className="md-section-loader__spinner">
                    <div className="skeleton-line skeleton-w80" />
                    <div className="skeleton-line skeleton-w50" />
                    <div className="skeleton-line skeleton-w65" />
                    <div className="skeleton-line skeleton-w40" />
                  </div>
                </div>
              )}

              {(sections || []).length > 0 && (sections || []).length >= totalSections && (
                <div className="md-section-end">
                  <span>End of document</span>
                </div>
              )}
            </article>

            <TOCSidebar headings={fileData.headings} activeId={activeHeadingId} />

            {annotating && (
              <AnnotationOverlay
                containerRef={layoutRef}
                folder={folder}
                filename={filename}
                userId={userId}
                onClose={() => setAnnotating(false)}
              />
            )}
          </div>

          <BackToTop />
          {lightbox && <Lightbox src={lightbox.src} alt={lightbox.alt} onClose={() => setLightbox(null)} />}
        </>
      ) : (
        <Suspense fallback={<div className="draw-canvas-wrap draw-canvas-wrap--loading"><div className="draw-canvas-loader"><span>Loading canvas...</span></div></div>}>
          <DrawCanvas
            folder={folder}
            filename={filename}
            theme={theme}
            userId={userId}
            onSwitchToRead={() => setViewMode('read')}
            displayName={fileData.name}
          />
        </Suspense>
      )}
    </div>
  );
});

export default MarkdownViewer;
