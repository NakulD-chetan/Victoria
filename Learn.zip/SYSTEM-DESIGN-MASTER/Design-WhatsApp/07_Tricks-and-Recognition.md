# Design WhatsApp — Tricks and Recognition

> **Permanent Recall:** Key insights: WebSocket is essential (not HTTP), message queue per user (mailbox), acknowledgment protocol (sent → delivered → read), presence = last-seen heartbeat with TTL, group chat = fan-out to member queues, E2E encryption = Signal protocol (mention but don't deep-dive). This design tests real-time systems knowledge at scale.

---

## Key Insights

| Insight | Implication |
|---------|-------------|
| **WebSocket is essential** | Don't propose HTTP short polling; long polling only as fallback |
| **Message queue per user** | Each user has a mailbox; deliver when online, store when offline |
| **Acknowledgment protocol** | Sent (server) → Delivered (recipient) → Read (recipient opens) |
| **Presence = heartbeat + TTL** | Client pings every 30–60s; Redis TTL 90s; no ping = offline |
| **Group = fan-out** | Write message once; fan-out to N member queues |
| **E2E = Signal protocol** | Client encrypts; server routes ciphertext; mention, don't deep-dive |

---

## Recognition Triggers

| Interview Phrase | What They're Testing |
|------------------|----------------------|
| "Real-time messaging" | WebSocket, not polling |
| "Billions of users" | Connection management, sharding |
| "Group chat" | Fan-out, write once |
| "Offline users" | Store + push + reconnect |
| "Message ordering" | Sequence numbers, partitioning |
| "End-to-end encryption" | Signal protocol, client-side crypto |
| "Read receipts" | Acknowledgment flow |
| "Presence / online status" | Heartbeat, TTL |

---

## Decision Shortcuts

```
IF "real-time"          → WebSocket
IF "offline"             → Store + push notification + deliver on reconnect
IF "group"               → Fan-out via queue; write once
IF "ordering"            → sequence_id per conversation
IF "scale"               → Shard by conversation_id; connection servers
IF "presence"            → Heartbeat + Redis TTL
IF "privacy / E2E"       → Signal protocol
IF "media"               → Separate upload (S3), URL in message
```

---

## What This Design Tests

| Area | What to Demonstrate |
|------|----------------------|
| **Real-time systems** | WebSocket, push vs pull |
| **Distributed systems** | Message queues, sharding, at-least-once |
| **Scalability** | 1B connections, 100B msg/day, fan-out |
| **Reliability** | Offline handling, retry, idempotency |
| **System decomposition** | Chat, Presence, Notification, Media services |

> **FAANG Tip:** "Design WhatsApp" is a classic because it combines real-time, scale, and distributed messaging. Lead with WebSocket and mailbox model—that signals you know the domain.

---

## Tech Stack Quick Reference

| Component | Typical Choices |
|-----------|-----------------|
| **Real-time** | WebSocket (Socket.io, raw WS) |
| **Message queue** | Kafka, RabbitMQ, Amazon SQS |
| **Message store** | Cassandra, DynamoDB, HBase |
| **Presence** | Redis (TTL, keys) |
| **Media** | S3, GCS + CDN |
| **Push** | FCM, APNs |

---

## Interview Script Snippets

**Opening:** "For real-time chat, we need WebSocket—HTTP polling would add too much latency at scale."

**Mailbox:** "Each user has a logical mailbox. When they're online we push; when offline we store and send a push notification."

**Group:** "For groups, we write the message once to the DB and fan-out to a queue. Each member has a consumer; we don't do 256 synchronous writes."

**E2E:** "For end-to-end encryption, we'd use the Signal protocol. The client encrypts before sending; the server only stores and routes ciphertext."

---

## Anti-Patterns to Avoid

| Don't Say | Say Instead |
|-----------|-------------|
| "We'll poll every few seconds" | "WebSocket for real-time; long polling fallback" |
| "We'll write to DB when they come online" | "We store immediately; push notification; deliver on reconnect" |
| "We'll send to each group member via API" | "Fan-out via queue; write once" |
| "Single database for all messages" | "Shard by conversation_id" |
| "We'll skip presence for now" | "Heartbeat every 30s; Redis TTL for online status" |

---

## Interview Flow Recognition

**"Let's design a chat system"** → Assume WhatsApp-like; ask about group, receipts, presence.

**"How would you scale this?"** → Connection servers, sharding by conversation, queue partitioning.

**"What if the user goes offline?"** → Store, push, deliver on reconnect. Core mailbox behavior.

**"How do you handle 256 people in a group?"** → Fan-out via queue; write once.

---

## One-Liner Summaries

- **WebSocket:** Bidirectional, low-latency; 1 connection per client.
- **Mailbox:** Per-user queue; online = push, offline = store + push + deliver on connect.
- **Receipts:** Sent (server) → Delivered (device) → Read (user opens).
- **Presence:** Heartbeat + Redis TTL; no heartbeat = offline.
- **Group:** Write once, fan-out to N queues.
- **E2E:** Signal; client encrypts, server routes ciphertext.

**Scale mental model:** 1B connections = 20K servers × 50K each. 100B msg/day = 1.15M/s = thousands of queue partitions.

**Interview timing:** Spend 5 min on requirements, 15 on HLD, 20 on deep dive. Leave 5 min for wrap-up and follow-ups.

---

## 30-SECOND REVISION BOX

```
WEBSOCKET: Essential; not HTTP polling
MAILBOX: Per-user queue; online push, offline store+push
RECEIPTS: Sent → delivered → read
PRESENCE: Heartbeat + TTL
GROUP: Fan-out; write once
E2E: Signal protocol
TESTS: Real-time, scale, distributed
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
