# Design Google Docs — Mental Model

> **Permanent Recall:** The core challenge: **How do you handle two people typing at the same position at the same time?** This is the **conflict resolution problem**. Two main approaches: **OT** (transform operations against each other — Google's approach) vs **CRDTs** (data structures that auto-merge — Figma's approach). Think: shared whiteboard where edits must never corrupt.

---

## The Core Conflict Problem

```
User A and User B both have: "Hello"

User A inserts "X" at position 0  →  "XHello"
User B inserts "Y" at position 0  →  "YHello"

If we apply both naively (last write wins): we lose one edit.
We need: both edits preserved → "XYHello" or "YXHello" (deterministic)
```

**The question:** How do we **transform** operations so they merge correctly?

---

## Shared Whiteboard Analogy

| Whiteboard | Collaborative Doc |
|------------|-------------------|
| Multiple people draw at once | Multiple users type at once |
| Order of marks matters | Order of inserts matters |
| Can't "overwrite" someone's mark | Can't lose an edit |
| Need rules for overlapping edits | Need OT or CRDT |

> **FAANG Tip:** The analogy helps explain why naive approaches (last write wins, locking) don't work — they lose or block user intent.

---

## OT vs CRDT Comparison

| Aspect | **Operational Transformation (OT)** | **CRDTs (Conflict-free Replicated Data Types)** |
|--------|-------------------------------------|-----------------------------------------------|
| **Used by** | Google Docs | Figma, Yjs, Automerge |
| **Mechanism** | Transform operations against concurrent ops | Data structure with merge rules; ops carry enough info to merge |
| **Authority** | Server is source of truth; transforms ops | Peer-to-peer possible; no central authority needed |
| **Complexity** | Complex transformation rules; server logic | Complex data structures; merge is commutative |
| **Guarantee** | Convergence if transform rules correct | Mathematical convergence (commutative, associative) |
| **Offline** | Harder; needs server to resolve | Easier; merge locally |

---

## OT: High-Level Idea

```
When User B's operation arrives, we don't apply it "as is."
We TRANSFORM it against operations that happened AFTER B's last sync.

Example:
  Doc: "Hi"
  A inserts "X" at 2 → "HiX"
  B deletes at 0 (deleting "H") → would make "i" if applied to "Hi"

  But A's op happened first (from B's view). So we transform B's delete:
    "Delete at 0" against "Insert X at 2"
    → Delete at 0 still deletes "H" (position 0 is before 2)
    → Result: "iX"

  If we hadn't transformed: B's "delete 0" on "HiX" would delete "H" → "iX" (same here)
  But in other cases, wrong transform = corruption.
```

**Key:** `transform(opA, opB)` produces `opA'` and `opB'` such that applying them in any order yields same result.

---

## CRDT: High-Level Idea

```
Each character/block has a unique ID + logical timestamp (e.g., (client_id, seq)).
Insertions are never "overwritten" — they're added with their ID.
Deletes are "tombstones" or range markers.
Merge: combine all inserts, apply deletes by ID; order is deterministic (e.g., by ID).
```

- **No central server** required for merge
- **Offline** works naturally: collect ops, merge when back online
- **Complexity** in the data structure and ID scheme

---

## Why Not "Last Write Wins"?

```
Doc: "Hello"
A types "!" at end → "Hello!"
B types "?" at end → "Hello?"

Last write wins: One of "!" or "?" is lost. BAD.
```

Last write wins loses user intent. Collaborative editing requires **all** edits to be preserved (or explicitly merged, e.g., "XY" vs "YX").

---

## Decomposition

| Component | Responsibility |
|-----------|-----------------|
| **Client** | Local text buffer; send ops on keystroke; receive and apply remote ops |
| **Collaboration service** | Receive ops; transform (OT) or merge (CRDT); broadcast to other clients |
| **Document storage** | Persist snapshot + operation log; periodic checkpoint |
| **Presence service** | Track cursor positions; broadcast via WebSocket |
| **Version history** | Store snapshots or replay log for "view previous version" |

---

## Data Flow Summary

```
WRITE:  User types → Client emits op (insert/delete) → WebSocket → Collaboration Service
        → Transform against pending ops (OT) or merge (CRDT)
        → Broadcast to other clients in session
        → Periodically: snapshot + append to operation log → DB

READ:   Open doc → Load snapshot from DB → Join session via WebSocket
        → Receive ops from server → Apply to local buffer
        → Receive presence (cursors) from server
```

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| OT vs CRDT | OT: server-centric, proven at Google scale; CRDT: P2P, offline-friendly, no single point of failure |
| WebSocket vs polling | WebSocket: low latency, bidirectional; polling: simpler, works everywhere |
| Snapshot + log | Snapshot for fast load; log for history and replay; checkpoint periodically to bound log |
| Block model vs char model | Blocks (paragraphs): simpler OT; char-level: finer granularity, more ops |
