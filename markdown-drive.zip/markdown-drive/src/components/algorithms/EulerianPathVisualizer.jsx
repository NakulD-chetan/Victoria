import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: eulerian-path */
const GRAPH = {
  nodes: [
    { id: 'A', x: 120, y: 200, label: 'A' },
    { id: 'B', x: 280, y: 120, label: 'B' },
    { id: 'C', x: 440, y: 200, label: 'C' },
    { id: 'D', x: 280, y: 280, label: 'D' },
  ],
  edges: [
    { from: 'A', to: 'B', directed: false },
    { from: 'B', to: 'C', directed: false },
    { from: 'C', to: 'D', directed: false },
    { from: 'D', to: 'A', directed: false },
  ],
};

function pairKey(u, v) {
  return u < v ? `${u}-${v}` : `${v}-${u}`;
}

function generateSteps() {
  const walk = [
    ['A', 'B'],
    ['B', 'C'],
    ['C', 'D'],
    ['D', 'A'],
  ];
  const steps = [];
  let trail = 'A';
  walk.forEach(([u, v], i) => {
    steps.push({
      type: 'traverse',
      nodeColors: { [u]: 'current', [v]: 'processing' },
      edgeColors: { [pairKey(u, v)]: 'highlight' },
    });
    trail += `→${v}`;
    steps.push({
      type: 'used',
      nodeColors: { [v]: 'visited' },
      edgeColors: { [pairKey(u, v)]: 'mst' },
      trail,
      stepIdx: i + 1,
    });
  });
  steps.push({ type: 'done', nodeColors: Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function EulerianPathVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Eulerian circuit on 4-cycle (each edge once)' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { A: 'source' },
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: {},
      queue: step.trail ? [step.trail] : [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
