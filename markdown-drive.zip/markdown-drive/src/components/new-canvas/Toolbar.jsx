import { memo, useCallback, useEffect, useRef, useState } from 'react';
import ReactDOM from 'react-dom';
import { useNewCanvasStore } from './state/store';
import DataWidgetMenu from './DataWidgetMenu';

/**
 * Toolbar — premium floating Island at the top of the stage.
 * Clean, professional design inspired by Figma / tldraw toolbars.
 * Each icon is Lucide-quality, rendered at 20×20 within a 36×36 tap target.
 */

const TOOLS = [
  { id: 'select', label: 'Select', shortcut: 'V', icon: IconSelect },
  { id: 'rect', label: 'Rectangle', shortcut: 'R', icon: IconRect },
  { id: 'ellipse', label: 'Ellipse', shortcut: 'O', icon: IconEllipse },
  { id: 'arrow', label: 'Arrow', shortcut: 'A', icon: IconArrow },
  { id: 'line', label: 'Line', shortcut: 'L', icon: IconLine },
  { id: 'pen', label: 'Draw', shortcut: 'P', icon: IconPen },
  { id: 'text', label: 'Text', shortcut: 'T', icon: IconText },
  { id: 'highlighter', label: 'Highlighter', shortcut: 'H', icon: IconHighlighter },
  { id: 'eraser', label: 'Eraser', shortcut: 'E', icon: IconEraser },
  { id: 'laser', label: 'Laser pointer', shortcut: 'K', icon: IconLaser },
];

const WIDGETS = [
  {
    id: 'code',
    label: 'Code',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <path d="M9 9l-3 3 3 3" />
        <path d="M15 9l3 3-3 3" />
      </svg>
    ),
  },
  {
    id: 'note',
    label: 'Note',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
        <line x1="8" y1="13" x2="16" y2="13" />
        <line x1="8" y1="17" x2="12" y2="17" />
      </svg>
    ),
  },
  {
    id: 'sql-pad',
    label: 'SQL Pad',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <ellipse cx="12" cy="5" rx="9" ry="3" />
        <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
        <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
      </svg>
    ),
  },
];

const COLORS = [
  '#e2e8f0', '#ffffff', '#ef4444', '#f97316',
  '#eab308', '#22c55e', '#3b82f6', '#8b5cf6',
  '#ec4899', '#1e293b',
];
const STROKE_WIDTHS = [1, 2, 4, 8];

function applyToolbarColorToSelectedWidget(state, color) {
  const { selection, scenes, activeId, commitElements } = state;
  if (!selection || selection.size !== 1 || !activeId || !scenes[activeId]) return;
  const id = [...selection][0];
  const hit = scenes[activeId].elements?.find((e) => e.id === id && !e.isDeleted);
  if (!hit || hit.type !== 'widget') return;
  commitElements((els) => els.map((e) => {
    if (e.id !== id) return e;
    if (e.widgetType === 'note') {
      return { ...e, style: { ...e.style, stroke: color }, widgetData: { ...e.widgetData, color } };
    }
    return {
      ...e,
      style: { ...e.style, stroke: color },
      widgetData: { ...e.widgetData, chromeBg: color },
    };
  }));
}

function applyToolbarStrokeWidthToSelectedWidget(state, w) {
  const { selection, scenes, activeId, commitElements } = state;
  if (!selection || selection.size !== 1 || !activeId || !scenes[activeId]) return;
  const id = [...selection][0];
  const hit = scenes[activeId].elements?.find((e) => e.id === id && !e.isDeleted);
  if (!hit || hit.type !== 'widget') return;
  commitElements((els) => els.map((e) =>
    (e.id === id ? { ...e, style: { ...e.style, strokeWidth: w } } : e)));
}

function StyleCluster({ stroke, strokeWidth, setToolOptions }) {
  const [open, setOpen] = useState(null);
  const wrapRef = useRef(null);
  const pillRef = useRef(null);
  const [popPos, setPopPos] = useState({ top: 0, left: 0 });
  const selection = useNewCanvasStore((s) => s.selection);
  const activeId = useNewCanvasStore((s) => s.activeId);
  const elements = useNewCanvasStore((s) => (activeId ? s.scenes[activeId]?.elements : null));

  const selectedWidgetType = (() => {
    if (!elements || selection.size !== 1) return null;
    const id = [...selection][0];
    const el = elements.find((e) => e.id === id);
    return el?.type === 'widget' ? el.widgetType : null;
  })();

  useEffect(() => {
    if (!open || !pillRef.current) return;
    const rect = pillRef.current.getBoundingClientRect();
    setPopPos({
      top: rect.bottom + 10,
      left: rect.left + rect.width / 2,
    });
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) {
        const pop = document.querySelector('.nc-pop--portal');
        if (pop && pop.contains(e.target)) return;
        setOpen(null);
      }
    };
    const onKey = (e) => {
      if (e.key === 'Escape') setOpen(null);
    };
    document.addEventListener('mousedown', onDoc, true);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc, true);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const toggle = (which) => setOpen((o) => (o === which ? null : which));

  const portalStyle = {
    position: 'fixed',
    top: popPos.top,
    left: popPos.left,
    transform: 'translateX(-50%)',
    zIndex: 9999,
  };

  return (
    <div className="nc-island__group nc-island__group--style">
      <div ref={wrapRef} className="nc-style-wrap">
        <div ref={pillRef} className="nc-style-pill" role="group" aria-label="Stroke appearance">
          <button
            type="button"
            className={`nc-style-pill__btn ${open === 'color' ? 'is-open' : ''}`}
            onClick={() => toggle('color')}
            aria-expanded={open === 'color'}
            aria-haspopup="dialog"
            title="Stroke color"
          >
            <span className="nc-style-pill__swatch" style={{ background: stroke }} />
            <IconChevron />
          </button>
          <span className="nc-style-pill__divider" aria-hidden />
          <button
            type="button"
            className={`nc-style-pill__btn ${open === 'stroke' ? 'is-open' : ''}`}
            onClick={() => toggle('stroke')}
            aria-expanded={open === 'stroke'}
            aria-haspopup="dialog"
            title="Stroke width"
          >
            <span
              className="nc-style-pill__line"
              style={{
                width: Math.min(20, 8 + strokeWidth * 2),
                height: Math.max(2, Math.min(6, strokeWidth)),
                borderRadius: 999,
                background: 'currentColor',
              }}
            />
            <IconChevron />
          </button>
        </div>

        {open === 'color' && ReactDOM.createPortal(
          <div className="nc-pop nc-pop--style nc-pop--portal" role="dialog" aria-label="Pick color" style={portalStyle}>
            <div className="nc-pop__head">Stroke color</div>
            {selectedWidgetType && (
              <p className="nc-pop__hint">
                Applies to <strong>{selectedWidgetType}</strong> widget
              </p>
            )}
            <div className="nc-pop__grid nc-pop__grid--colors">
              {COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  className={`nc-pop__swatch ${stroke === c ? 'is-active' : ''}`}
                  style={{ background: c }}
                  onClick={() => {
                    setToolOptions({ stroke: c });
                    applyToolbarColorToSelectedWidget(useNewCanvasStore.getState(), c);
                    setOpen(null);
                  }}
                  title={c}
                  aria-label={`Color ${c}`}
                />
              ))}
            </div>
            <label className="nc-pop__custom">
              <span className="nc-pop__custom-label">Custom</span>
              <span className="nc-pop__custom-input-wrap">
                <input
                  type="color"
                  value={stroke}
                  onChange={(e) => {
                    const v = e.target.value;
                    setToolOptions({ stroke: v });
                    applyToolbarColorToSelectedWidget(useNewCanvasStore.getState(), v);
                  }}
                  aria-label="Custom color"
                />
              </span>
            </label>
          </div>,
          document.body
        )}

        {open === 'stroke' && ReactDOM.createPortal(
          <div className="nc-pop nc-pop--style nc-pop--portal" role="dialog" aria-label="Stroke width" style={portalStyle}>
            <div className="nc-pop__head">Stroke width</div>
            {selectedWidgetType && (
              <p className="nc-pop__hint">
                Updates frame border
              </p>
            )}
            <div className="nc-pop__widths">
              {STROKE_WIDTHS.map((w) => (
                <button
                  key={w}
                  type="button"
                  className={`nc-pop__width-row ${strokeWidth === w ? 'is-active' : ''}`}
                  onClick={() => {
                    setToolOptions({ strokeWidth: w });
                    applyToolbarStrokeWidthToSelectedWidget(useNewCanvasStore.getState(), w);
                    setOpen(null);
                  }}
                >
                  <span
                    className="nc-pop__width-dot"
                    style={{ width: Math.max(4, w + 4), height: Math.max(4, w + 4) }}
                  />
                  <span className="nc-pop__width-label">{w}px</span>
                </button>
              ))}
            </div>
          </div>,
          document.body
        )}
      </div>
    </div>
  );
}

function IconChevron() {
  return (
    <svg className="nc-style-pill__chev" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden>
      <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function ToolbarImpl() {
  const tool = useNewCanvasStore((s) => s.tool);
  const setTool = useNewCanvasStore((s) => s.setTool);
  const toolOptions = useNewCanvasStore((s) => s.toolOptions);
  const setToolOptions = useNewCanvasStore((s) => s.setToolOptions);

  return (
    <div className="nc-island nc-island--toolbar">
      <div className="nc-island__inner">
        {/* ─── Drawing tools ─── */}
        <div className="nc-island__group">
          {TOOLS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                className={`nc-tool-btn ${tool === t.id ? 'is-active' : ''}`}
                onClick={() => setTool(t.id)}
                title={`${t.label} — ${t.shortcut}`}
                aria-label={t.label}
                aria-pressed={tool === t.id}
              >
                <Icon />
                <span className="nc-tool-btn__kbd">{t.shortcut}</span>
              </button>
            );
          })}
        </div>

        <div className="nc-island__sep" />

        {/* ─── Widget tools ─── */}
        <div className="nc-island__group">
          {WIDGETS.map((w) => (
            <button
              key={w.id}
              type="button"
              className={`nc-tool-btn ${tool === `widget-${w.id}` ? 'is-active' : ''}`}
              onClick={() => setTool(`widget-${w.id}`)}
              title={`${w.label} — drag on canvas`}
              aria-label={w.label}
              aria-pressed={tool === `widget-${w.id}`}
            >
              {w.icon}
            </button>
          ))}
          <DataWidgetMenu />
        </div>

        <div className="nc-island__sep" />

        {/* ─── Style cluster ─── */}
        <StyleCluster
          stroke={toolOptions.stroke}
          strokeWidth={toolOptions.strokeWidth}
          setToolOptions={setToolOptions}
        />
      </div>
    </div>
  );
}

export default memo(ToolbarImpl);

/* ─── Professional Icons — Lucide-inspired, 20×20 viewBox 24 ──────── */

function IconSelect() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M5 3l14 9-6 1-3 7z" />
    </svg>
  );
}

function IconRect() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2" />
    </svg>
  );
}

function IconEllipse() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <circle cx="12" cy="12" r="9" />
    </svg>
  );
}

function IconArrow() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <line x1="5" y1="19" x2="19" y2="5" />
      <polyline points="12 5 19 5 19 12" />
    </svg>
  );
}

function IconLine() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round">
      <line x1="5" y1="19" x2="19" y2="5" />
    </svg>
  );
}

function IconPen() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 19l7-7 3 3-7 7-3-3z" />
      <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
      <path d="M2 2l7.586 7.586" />
      <circle cx="11" cy="11" r="2" />
    </svg>
  );
}

function IconText() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 7V4h16v3" />
      <line x1="12" y1="4" x2="12" y2="20" />
      <line x1="8" y1="20" x2="16" y2="20" />
    </svg>
  );
}

function IconHighlighter() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 2l4 4-12 12H4v-6L16 0" fill="currentColor" opacity=".15" />
      <path d="M18 2l4 4-12 12H4v-6z" />
      <line x1="2" y1="22" x2="22" y2="22" />
    </svg>
  );
}

function IconEraser() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M7 21h10" />
      <path d="M19.07 4.93a2.83 2.83 0 0 0-4-4L3.59 12.41a2 2 0 0 0 0 2.83L7.76 19.4a2 2 0 0 0 2.83 0z" />
      <path d="M8.5 12.5l5-5" />
    </svg>
  );
}

function IconLaser() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M12 2v4" />
      <path d="M12 18v4" />
      <path d="M4.93 4.93l2.83 2.83" />
      <path d="M16.24 16.24l2.83 2.83" />
      <path d="M2 12h4" />
      <path d="M18 12h4" />
      <path d="M4.93 19.07l2.83-2.83" />
      <path d="M16.24 7.76l2.83-2.83" />
    </svg>
  );
}
