import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const S = 'hello';
const BASE = 131;
const MOD = 1000000007;

function generateSteps() {
  const steps = [];
  let h = 0;
  steps.push({ type: 'init', msg: 'h = 0', S, i: -1, h });
  for (let i = 0; i < S.length; i++) {
    steps.push({
      type: 'mul',
      msg: `h = (h * ${BASE}) % MOD`,
      S,
      i,
      h,
    });
    h = (h * BASE) % MOD;
    steps.push({
      type: 'add',
      msg: `h += code('${S[i]}')`,
      S,
      i,
      h,
      ch: S[i],
    });
    h = (h + S.charCodeAt(i)) % MOD;
    steps.push({ type: 'mod', msg: `After char ${i}: h = ${h}`, S, i, h, table: [h] });
  }
  steps.push({ type: 'done', msg: `Final polynomial hash = ${h}`, S, i: S.length - 1, h });
  return steps;
}

function paint(step) {
  const str = step.S;
  const textColors = {};
  if (step.i != null && step.i >= 0) textColors[step.i] = 'current';
  const vals = str.split('').map((_, idx) => (idx <= step.i ? str.charCodeAt(idx) : ''));
  return {
    text: str.split(''),
    pattern: vals.map((v) => (v === '' ? '' : String(v))),
    textColors,
    patternColors: {},
    offset: 0,
    table: step.h != null ? [step.h] : null,
    tableLabel: 'rolling h',
    matchPositions: [],
    comparePairs: null,
  };
}

export default function StringHashingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Polynomial rolling hash' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
