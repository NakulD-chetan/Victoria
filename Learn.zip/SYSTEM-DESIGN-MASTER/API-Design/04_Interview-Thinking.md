# API Design — Interview Thinking

> **Permanent Recall:** When discussing API design in interviews, lead with requirements—who is the consumer, what do they need, scale? Propose REST for public APIs, GraphQL for mobile/flexible queries, gRPC for internal services. Emphasize clean design: nouns not verbs, proper HTTP methods, versioning, rate limiting, pagination. Be ready to discuss authentication choices (API key vs OAuth vs JWT) and idempotency for POST. Show you think consumer-first.

---

## How to Discuss API Design in Interviews

**Don't jump to a technology.** Start with:

1. **Who are the consumers?** Public, partners, mobile app, internal?
2. **What data do they need?** Simple CRUD? Nested? Varying fields?
3. **Scale?** QPS, payload size, caching needs?
4. **Auth?** Anonymous, API key, OAuth, JWT?

> **FAANG Tip:** "I'd first clarify the consumers and access patterns. REST is great for public APIs; GraphQL for flexible queries; gRPC for internal high-throughput."

---

**Interview line:** "For a public API, I'd use REST with versioning in the URL. For internal microservices needing high throughput, gRPC. For a mobile app with varying data needs, GraphQL."

---

## How to Design Clean APIs

**Structure your answer:**

1. **Resources:** Identify nouns (users, orders, products).
2. **URLs:** Plural nouns, hierarchical (`/users/123/orders`).
3. **Methods:** GET read, POST create, PUT/PATCH update, DELETE remove.
4. **Versioning:** `/v1/` in URL for breaking changes.
5. **Pagination:** Cursor-based for scale.
6. **Errors:** Consistent format with code and message.
7. **Auth:** API key for simple; OAuth for third-party; JWT for stateless.

---

---

## Authentication Choices


| Scenario               | Suggestion              | Rationale          |
| ---------------------- | ----------------------- | ------------------ |
| Internal service       | API key                 | Simple, revocable  |
| Third-party developers | OAuth 2.0               | Delegated consent  |
| Mobile/web, stateless  | JWT                     | No server session  |
| High security          | OAuth + short-lived JWT | Refresh token flow |


**Interview line:** "For third-party access, OAuth 2.0. For our own clients, JWT for stateless auth. API keys for simple machine-to-machine."

---

## Red Flags to Avoid


| Don't Say                             | Do Say                                                         |
| ------------------------------------- | -------------------------------------------------------------- |
| "We'll use REST because it's popular" | "REST fits because we need HTTP caching and it's a public API" |
| "GraphQL for everything"              | "GraphQL when we have over/under-fetch issues"                 |
| "No versioning, we'll be careful"     | "We'll version from day one with /v1/"                         |
| "POST for everything"                 | "GET for read, POST for create, proper methods"                |
| "No rate limiting"                    | "Token bucket rate limiting per user"                          |


---

## Sample Interview Dialogue

**Interviewer:** "Design an API for an e-commerce order system."

**You:** "I'd start with the resources: orders, users, products. REST with `/v1/orders`, `/v1/users`, etc. GET for read, POST for create. Orders would support `POST /orders` with `Idempotency-Key` to handle retries. Pagination for listing—cursor-based. Rate limiting per user. Auth: JWT for logged-in users, API key for partners. Version in URL for breaking changes. I'd add an API gateway for auth, rate limiting, and routing."

---



---

