# Interview Framework — Interview Thinking

> **Permanent Recall:** This is the most important file in this folder. It tells you *exactly what to say* at each phase. Use script-like phrases to structure your thinking out loud. Handle curveballs by acknowledging, reasoning, and proposing—never by going silent or guessing blindly. Manage time by allocating ~5–10–20–5 across the four phases.

---

## Phase 1: Requirements — What to Say

### Opening
- *"Let me start by clarifying the requirements before we dive into the design."*
- *"I want to make sure I understand the scope—is that okay?"*

### Functional Requirements
- *"For functional requirements, I'm thinking we need [list 3–5 features]. Are there others that are critical?"*
- *"Which use cases should we prioritize—[X] or [Y]?"*

### Non-Functional Requirements
- *"For non-functional requirements, I'm thinking we care about latency—something like [X]ms p99?—and availability, maybe 99.9%. Does that align?"*
- *"Should we optimize for consistency or availability here? That will affect our database choices."*

### Constraints & Scope
- *"I'll assume [DAU / read:write ratio / data size] unless you have different numbers. Let me know if those change."*
- *"I'm explicitly excluding [X, Y] from scope for now—we can add those in a follow-up. Sound good?"*

### Confirmation
- *"So to summarize: we're building [X] for [users] at [scale], with [key constraints]. Does that capture it?"*

---

## Phase 2: High-Level Design — What to Say

### Transition
- *"Now let me do a quick back-of-envelope estimation before we look at the architecture."*
- *"Rough numbers: [DAU], [QPS], [storage]. That gives us a sense of scale."*

### Architecture
- *"Here's my high-level architecture. We'll have [clients] hitting a [load balancer], which distributes to [app servers]."*
- *"For storage, we need [cache] for hot data and [database] for persistence. I'm adding a [message queue] for [reason]."*
- *"Let me draw the data flow: [draw and narrate]."*

### API Design
- *"For the API, I'm thinking we need [list 3–5 endpoints]. The key ones are [X] and [Y]."*
- *"Request/response would look like [sketch]."*

### Data Model
- *"For the data model, we'll need tables for [entities]. The main relationships are [describe]."*

---

## Phase 3: Deep Dive — What to Say

### Choosing What to Deep-Dive
- *"I'd like to deep-dive into [X] because it's the most critical/scaling bottleneck for this system."*
- *"The [Y] component has interesting trade-offs—let me walk through those."*
- *"I'll focus on [feed generation / consistency / sharding] since that's where the complexity lives."*

### Explaining Trade-offs
- *"Let me discuss the trade-offs here. Option A gives us [pro] but [con]. Option B gives us [pro] but [con]. I'd go with [choice] because [reason]."*
- *"There's a classic CAP trade-off: we could guarantee consistency but sacrifice availability, or the opposite. For this use case, I'd pick [X]."*
- *"We could use [approach], but that would mean [trade-off]. Given our constraints, I think [alternative] is better."*

### Handling What-Ifs
- *"If traffic 10x, the bottleneck would likely be [X]. We'd address it by [scaling horizontally / caching more / sharding]."*
- *"If this component fails, we'd have [impact]. To mitigate, we'd add [redundancy / circuit breaker / fallback]."*
- *"Good question. Let me think through that... [reason out loud]."*

---

## Phase 4: Wrap-up — What to Say

### Bottlenecks
- *"Potential bottlenecks I see: [1], [2]. For [1], we'd [solution]. For [2], we'd [solution]."*
- *"At 10x scale, we'd need to [add CDN / shard DB / introduce read replicas]."*

### Monitoring
- *"We'd monitor [latency p99, error rate, cache hit ratio, queue depth]. Alerts on [critical thresholds]."*
- *"Key metrics: [list]. Dashboards for [ops / product]."*

### Security & Future
- *"For security: auth tokens, HTTPS, rate limiting, input validation. We'd also consider [DDoS, encryption at rest]."*
- *"Future improvements: [multi-region, event sourcing, better caching]. We could also add [feature]."*

---

## Handling Curveballs — Scripts

### "What if traffic 10x?"
- *"Good question. The bottleneck would shift to [identify]. We'd need to [horizontal scaling / more cache / sharding]. Let me sketch how that would look..."*

### "What if this component fails?"
- *"If [X] fails, [describe impact]. We'd mitigate with [redundancy / failover / circuit breaker]. The recovery time would be [estimate]."*

### "Why not use [technology]?"
- *"We could use [X]. The trade-off is [pro/con]. For our constraints, I went with [Y] because [reason]. But [X] would work if we needed [different property]."*

### "What about consistency?"
- *"For this use case, [strong/eventual] consistency makes more sense because [reason]. That means we'd use [strategy: 2PC, quorum, async replication]."*

### "How would you shard this?"
- *"I'd shard by [key] because [reason—e.g., even distribution, locality]. We'd need a [consistent hash / range partition] to avoid hotspots."*

---

## Recovering from Mistakes

### You Realize You're Wrong Mid-Interview
- *"Actually, I think I misspoke. Let me correct that—[correct explanation]. The right approach would be [X]."*
- *"Good catch. I was wrong about [X]. The better way is [Y] because [reason]."*

### You Don't Know the Answer
- *"I'm not 100% sure about the internals of [X], but my intuition is [educated guess]. In a real scenario, I'd look it up or consult the team."*
- *"I haven't worked with [X] directly, but from what I know, it [general behavior]. I'd want to validate the specifics."*

### You're Stuck
- *"Let me step back. The core problem is [reframe]. So we need [simplified approach]. From there we can build up."*
- *"I'm going to make a simplifying assumption—[assumption]—and work from there. We can refine later."*

> **FAANG Tip:** Admitting you don't know something and reasoning from first principles is often better than confident wrong answers. Interviewers value honesty and recoverability.

---

## Managing Time

### Allocation (45 min total)
| Phase | Target | If Over | If Under |
|-------|--------|---------|----------|
| Requirements | 5 min | Wrap up quickly; move on | Add 1–2 clarifying questions |
| High-Level | 10 min | Skip estimation; simplify API | Add data model detail |
| Deep Dive | 20 min | Prioritize 1 component only | Proactively add second component |
| Wrap-up | 5 min | Compress to 2 min | Expand monitoring/future |

### Time Check Phrases
- *"We have about [X] minutes left—let me quickly cover [wrap-up items]."*
- *"I want to make sure we get to monitoring and bottlenecks—let me fast-forward through [less critical part]."*
- *"I've spent a lot of time on [X]. Should I continue here or move to [Y]?"*

### If Running Out of Time
- *"I'll summarize the remaining pieces: [bullet wrap-up]. The key takeaway is [one sentence]."*
- Prioritize: **bottlenecks** and **one monitoring metric** over exhaustive detail.

---

## The "Thinking Out Loud" Rule

**Always** verbalize your reasoning. Don't go silent while drawing or calculating.

- *"I'm choosing Redis here because we need sub-millisecond lookups and TTL support."*
- *"We need a queue because the write path shouldn't block the read path—async decoupling."*
- *"Let me calculate: 500M users, 10 actions/day = 5B actions. Divided by 86400 ≈ 60K QPS."*

Silence = interviewer can't follow. They may think you're stuck or lost.

---

## Summary: Phrases to Memorize

| Phase | Opening | Transition |
|-------|---------|------------|
| **Requirements** | "Let me start by clarifying requirements..." | "So to summarize: we're building..." |
| **Estimation** | "Let me do a quick back-of-envelope..." | "That gives us a sense of scale." |
| **Architecture** | "Here's my high-level architecture..." | "Let me draw the data flow." |
| **Deep Dive** | "I'd like to deep-dive into [X] because..." | "Let me discuss the trade-offs here." |
| **Wrap-up** | "Potential bottlenecks I see..." | "We'd monitor... Future improvements..." |
