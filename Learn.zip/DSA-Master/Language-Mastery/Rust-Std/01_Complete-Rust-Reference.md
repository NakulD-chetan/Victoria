# Rust Standard Library Complete Reference — DSA Interview Cheatsheet

> **The go-to reference for Rust DSA & FAANG interviews**

---

## 1. Vec<T>

| Operation | Syntax | Notes |
|-----------|--------|-------|
| push | `v.push(x)` | O(1) amortized |
| pop | `v.pop()` → `Option<T>` | O(1) |
| len | `v.len()` | O(1) |
| is_empty | `v.is_empty()` | O(1) |
| sort | `v.sort()` | Ord required |
| sort_by | `v.sort_by(|a,b| a.cmp(b))` | Custom cmp |
| binary_search | `v.binary_search(&x)` → `Result<usize, usize>` | O(log n) |
| iter | `v.iter()` | Borrows, yields &T |
| into_iter | `v.into_iter()` | Consumes |
| drain | `v.drain(..)` | Remove range, yields owned |
| retain | `v.retain(|x| *x > 0)` | Keep if predicate true |
| clear | `v.clear()` | O(n) |

```rust
let mut v = vec![3, 1, 4, 1, 5];
v.push(9);
let x = v.pop();  // Some(9)
println!("{} {}", v.len(), v.is_empty());  // 5 false

// 2D vec init
let grid: Vec<Vec<i32>> = vec![vec![0; m]; n];
let mut adj: Vec<Vec<usize>> = vec![vec![]; n];

// Sort
v.sort();  // ascending
v.sort_by(|a, b| b.cmp(a));  // descending
v.sort_by_key(|x| x.abs());

// Binary search
match v.binary_search(&4) {
    Ok(i) => println!("found at {}", i),
    Err(i) => println!("insert at {}", i),
}

// Iteration
for x in &v { }      // borrow
for x in v.iter() { }
for (i, x) in v.iter().enumerate() { }
```

---

## 2. String / &str

| Operation | Syntax |
|-----------|--------|
| chars() | `s.chars()` — iterator over char |
| as_bytes() | `s.as_bytes()` — &[u8] |
| len() | `s.len()` — bytes, not chars! |
| push_str | `s.push_str("xy")` |
| format! | `format!("{} {}", a, b)` |
| Slicing | `&s[0..3]` — careful with char boundaries |

```rust
let s = String::from("hello");
let chars: Vec<char> = s.chars().collect();
let bytes = s.as_bytes();
s.push_str(" world");
let formatted = format!("{} {}", 1, 2);

// &str from String
let slice: &str = &s[..];

// char to digit: c.to_digit(10)
// digit to char: char::from_digit(n, 10)
let c = '5';
let d = c.to_digit(10).unwrap();  // 5
```

---

## 3. HashMap / BTreeMap

| Operation | Syntax |
|-----------|--------|
| insert | `m.insert(k, v)` → `Option<V>` (old value) |
| get | `m.get(&k)` → `Option<&V>` |
| get_mut | `m.get_mut(&k)` → `Option<&mut V>` |
| entry | `m.entry(k).or_insert(v)`, `or_default()`, `and_modify(|v| *v += 1)` |
| contains_key | `m.contains_key(&k)` |
| remove | `m.remove(&k)` → `Option<V>` |
| iteration | `for (k, v) in &m` |

```rust
use std::collections::HashMap;

let mut freq: HashMap<i32, i32> = HashMap::new();
freq.insert(5, 1);
*freq.entry(5).or_insert(0) += 1;  // frequency counting!

// Entry API — the DSA bread-and-butter
freq.entry(5).or_default();        // insert 0 if missing
freq.entry(5).and_modify(|v| *v += 1).or_insert(1);

if let Some(v) = freq.get(&5) { }
if let Some(v) = freq.get_mut(&5) { *v += 1; }
freq.remove(&5);

for (k, v) in &freq { }
```

**BTreeMap:** Same API, keys sorted. Use when you need ordered iteration.

---

## 4. HashSet / BTreeSet

| Operation | Syntax |
|-----------|--------|
| insert | `s.insert(x)` → `bool` (true if new) |
| contains | `s.contains(&x)` |
| remove | `s.remove(&x)` → `bool` |
| union | `a.union(&b)` |
| intersection | `a.intersection(&b)` |

```rust
use std::collections::HashSet;

let mut seen = HashSet::new();
seen.insert(5);
if seen.contains(&5) { }
seen.remove(&5);

for x in &seen { }
```

---

## 5. BinaryHeap

| Operation | Syntax |
|-----------|--------|
| push | `h.push(x)` |
| pop | `h.pop()` → `Option<T>` |
| peek | `h.peek()` → `Option<&T>` |

**MAX-heap by default!** Use `Reverse` for min-heap.

```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

let mut max_heap: BinaryHeap<i32> = BinaryHeap::new();
max_heap.push(3); max_heap.push(1); max_heap.push(4);
println!("{:?}", max_heap.peek());  // Some(4)
max_heap.pop();

// Min-heap: wrap in Reverse
let mut min_heap: BinaryHeap<Reverse<i32>> = BinaryHeap::new();
min_heap.push(Reverse(3));
let Reverse(x) = min_heap.pop().unwrap();

// Dijkstra: (dist, node)
let mut pq: BinaryHeap<Reverse<(i32, usize)>> = BinaryHeap::new();
pq.push(Reverse((0, start)));
```

---

## 6. VecDeque

| Operation | Syntax |
|-----------|--------|
| push_back | `dq.push_back(x)` |
| push_front | `dq.push_front(x)` |
| pop_back | `dq.pop_back()` → `Option<T>` |
| pop_front | `dq.pop_front()` → `Option<T>` |
| front | `dq.front()` → `Option<&T>` |
| back | `dq.back()` → `Option<&T>` |

```rust
use std::collections::VecDeque;

let mut dq: VecDeque<i32> = VecDeque::new();
dq.push_back(1); dq.push_front(0);
let x = dq.pop_front();
```

---

## 7. Ownership Fundamentals

| Concept | When to use |
|---------|-------------|
| **Move** | Ownership transferred, original invalidated |
| **Borrow &T** | Read-only, many borrows allowed |
| **Borrow &mut T** | Exclusive mutable, no other borrows |
| **Clone** | Explicit copy when needed |

```rust
fn take_ownership(v: Vec<i32>) { }      // consumes v
fn borrow(v: &Vec<i32>) { }             // read-only
fn borrow_mut(v: &mut Vec<i32>) { }     // can modify

let v = vec![1, 2, 3];
borrow(&v);   // v still valid
// take_ownership(v);  // v moved, gone
```

---

## 8. Borrowing in DSA

```rust
// Passing arrays to functions
fn dfs(graph: &[Vec<usize>], u: usize, visited: &mut [bool]) {
    visited[u] = true;
    for &v in &graph[u] {
        if !visited[v] { dfs(graph, v, visited); }
    }
}

// Modifying in loops — use indices or collect first
let mut v = vec![1, 2, 3];
for i in 0..v.len() { v[i] += 1; }
// Or: let indices: Vec<_> = (0..v.len()).collect();
//     for i in indices { v[i] += 1; }

// BFS/DFS: borrow checker often needs indices or RefCell
let mut visited = vec![false; n];
let mut q = VecDeque::new();
q.push_back(0);
while let Some(u) = q.pop_front() {
    for &v in &graph[u] {
        if !visited[v] { visited[v] = true; q.push_back(v); }
    }
}
```

---

## 9. Iterator Patterns

| Method | Usage |
|--------|-------|
| map | `iter.map(|x| x * 2)` |
| filter | `iter.filter(|x| *x > 0)` |
| enumerate | `iter.enumerate()` → (idx, val) |
| zip | `a.iter().zip(b.iter())` |
| collect | `iter.collect::<Vec<_>>()` |
| fold | `iter.fold(0, |acc, x| acc + x)` |
| any | `iter.any(|x| x > 5)` |
| all | `iter.all(|x| x > 0)` |
| position | `iter.position(|x| *x == 5)` |
| windows | `v.windows(3)` — sliding windows |
| chunks | `v.chunks(2)` — non-overlapping |

```rust
let v = vec![1, 2, 3, 4, 5];
let doubled: Vec<_> = v.iter().map(|x| x * 2).collect();
let sum: i32 = v.iter().sum();
let sum2: i32 = v.iter().fold(0, |a, b| a + b);
let has_big = v.iter().any(|x| *x > 4);
for w in v.windows(3) { }   // [1,2,3], [2,3,4], [3,4,5]
for c in v.chunks(2) { }    // [1,2], [3,4], [5]
```

---

## 10. Option<T>

| Method | Usage |
|--------|-------|
| Some/None | `Some(5)`, `None` |
| unwrap | `opt.unwrap()` — panics if None |
| unwrap_or | `opt.unwrap_or(0)` |
| map | `opt.map(|x| x + 1)` |
| and_then | `opt.and_then(|x| Some(x+1))` |
| if let | `if let Some(x) = opt { }` |
| match | `match opt { Some(x) => _, None => _ }` |

```rust
let opt: Option<i32> = Some(5);
let x = opt.unwrap_or(0);
let y = opt.map(|n| n * 2);
if let Some(v) = opt { println!("{}", v); }
```

---

## 11. Common Patterns

**Entry API for frequency counting:**
```rust
let mut freq: HashMap<i32, i32> = HashMap::new();
for x in &arr {
    *freq.entry(*x).or_insert(0) += 1;
}
```

**Reverse wrapper for min-heap:**
```rust
use std::cmp::Reverse;
BinaryHeap::from_iter(vec![Reverse(1), Reverse(2)]);
```

**impl Ord for custom structs (BinaryHeap, BTreeSet):**
```rust
#[derive(Eq, PartialEq)]
struct Node { dist: i32, id: usize }
impl Ord for Node {
    fn cmp(&self, other: &Self) -> Ordering {
        other.dist.cmp(&self.dist)  // min-heap by dist
    }
}
impl PartialOrd for Node { fn partial_cmp(&self, o: &Self) -> Option<Ordering> { Some(self.cmp(o)) } }
```

---

## 12. Performance Notes

| Choice | When |
|--------|------|
| HashMap vs BTreeMap | HashMap O(1) avg; BTreeMap when sorted keys needed |
| Vec vs VecDeque | Vec for stack; VecDeque for queue (pop_front O(1)) |
| Avoid allocations | Reuse buffers, use `with_capacity`, avoid clone in hot loops |
| `collect` cost | Creates new allocation; sometimes loop is faster |

---

## 30-SECOND REVISION BOX

```
VEC: push, pop, len, sort, sort_by, binary_search, iter, retain
STRING: chars(), as_bytes(), push_str, format!
HASHMAP: insert, get, entry().or_insert(0)+=1, contains_key
HASHSET: insert, contains, remove
BINARYHEAP: MAX by default! Reverse for min, push/pop/peek
VECDEQUE: push_back, push_front, pop_front (BFS!)
OWNERSHIP: &T read, &mut T write, clone when copy needed
ITER: map, filter, enumerate, collect, fold, windows, chunks
OPTION: Some/None, unwrap_or, if let Some(x)=
ENTRY API: freq.entry(x).or_insert(0)+=1
REVERSE: BinaryHeap<Reverse<T>> for min-heap
```
