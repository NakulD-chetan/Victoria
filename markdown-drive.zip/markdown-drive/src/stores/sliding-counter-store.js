import { create } from 'zustand';

export const useSlidingCounterStore = create((set) => ({
  windowSize: 5,
  limit: 5,
  autoRate: 3,
  autoActive: false,
  currentLang: 'python',
  currentStep: null,
  allowed: 0,
  denied: 0,
  total: 0,
  logs: [],
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setWindowSize: (v) => set({ windowSize: v }),
  setLimit: (v) => set({ limit: v }),
  setAutoRate: (v) => set({ autoRate: v }),
  toggleAuto: () => set((s) => ({ autoActive: !s.autoActive })),
  setLang: (lang) => set({ currentLang: lang }),
  setStep: (step) => set({ currentStep: step }),
  recordAllow: () => set((s) => ({ allowed: s.allowed + 1, total: s.total + 1 })),
  recordDeny: () => set((s) => ({ denied: s.denied + 1, total: s.total + 1 })),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),
  reset: () => set({
    allowed: 0, denied: 0, total: 0, currentStep: null, logs: [],
    autoActive: false, startTime: performance.now(),
  }),
}));
