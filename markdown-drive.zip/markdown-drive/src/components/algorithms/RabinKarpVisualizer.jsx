import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const TEXT = 'ABACAB';
const PAT = 'AB';
const BASE = 256;
const MOD = 997;

function hashStr(s) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * BASE + s.charCodeAt(i)) % MOD;
  return h;
}

function generateSteps() {
  const steps = [];
  const n = TEXT.length;
  const m = PAT.length;
  if (m > n) return [{ type: 'done', msg: 'Pattern longer than text', text: TEXT, pattern: PAT, offset: 0, hPat: 0, hWin: 0 }];
  const hPat = hashStr(PAT);
  let highPow = 1;
  for (let i = 0; i < m - 1; i++) highPow = (highPow * BASE) % MOD;
  let hWin = 0;
  for (let i = 0; i < m; i++) hWin = (hWin * BASE + TEXT.charCodeAt(i)) % MOD;

  steps.push({
    type: 'init',
    msg: `Pattern hash = ${hPat}`,
    text: TEXT,
    pattern: PAT,
    offset: 0,
    hPat,
    hWin,
    window: [0, m - 1],
  });

  for (let s = 0; s <= n - m; s++) {
    if (s > 0) {
      hWin = (hWin - (TEXT.charCodeAt(s - 1) * highPow) % MOD + MOD) % MOD;
      hWin = (hWin * BASE + TEXT.charCodeAt(s + m - 1)) % MOD;
      steps.push({
        type: 'roll',
        msg: `Slide window to start ${s}`,
        text: TEXT,
        pattern: PAT,
        offset: s,
        hPat,
        hWin,
        window: [s, s + m - 1],
      });
    }
    steps.push({
      type: 'compare-hash',
      msg: `Compare hashes: window=${hWin} vs pattern=${hPat}`,
      text: TEXT,
      pattern: PAT,
      offset: s,
      hPat,
      hWin,
      window: [s, s + m - 1],
    });
    if (hWin === hPat) {
      steps.push({
        type: 'verify',
        msg: 'Hash match — verify characters',
        text: TEXT,
        pattern: PAT,
        offset: s,
        hPat,
        hWin,
        window: [s, s + m - 1],
      });
      let ok = true;
      for (let k = 0; k < m; k++) {
        steps.push({
          type: 'char-cmp',
          msg: `Check T[${s + k}] vs P[${k}]`,
          text: TEXT,
          pattern: PAT,
          offset: s,
          k,
          hPat,
          hWin,
          window: [s, s + m - 1],
        });
        if (TEXT[s + k] !== PAT[k]) {
          ok = false;
          steps.push({
            type: 'spurious',
            msg: 'Hash collision — characters differ',
            text: TEXT,
            pattern: PAT,
            offset: s,
            k,
            hPat,
            hWin,
            window: [s, s + m - 1],
          });
          break;
        }
      }
      if (ok) {
        steps.push({
          type: 'found',
          msg: `Verified match at ${s}`,
          text: TEXT,
          pattern: PAT,
          offset: s,
          matchStart: s,
          hPat,
          hWin,
        });
      }
    }
  }
  steps.push({ type: 'done', msg: 'Scan complete', text: TEXT, pattern: PAT, offset: Math.max(0, n - m), hPat, hWin });
  return steps;
}

function paint(step) {
  const T = step.text;
  const P = step.pattern;
  const off = step.offset ?? 0;
  const textColors = {};
  const patternColors = {};
  const comparePairs = [];
  if (step.window) {
    for (let i = step.window[0]; i <= step.window[1]; i++) textColors[i] = 'current';
  }
  if (step.type === 'char-cmp' && step.k != null) {
    const ti = off + step.k;
    textColors[ti] = T[ti] === P[step.k] ? 'match' : 'mismatch';
    patternColors[step.k] = textColors[ti] === 'match' ? 'match' : 'mismatch';
    comparePairs.push([ti, step.k]);
  }
  if (step.type === 'found' && step.matchStart != null) {
    for (let k = 0; k < P.length; k++) {
      textColors[step.matchStart + k] = 'found';
      patternColors[k] = 'found';
    }
  }
  const table = step.hPat != null ? [step.hWin ?? 0, step.hPat] : null;
  return {
    text: T.split(''),
    pattern: P.split(''),
    textColors,
    patternColors,
    offset: off,
    table,
    tableLabel: 'window hash | pattern hash',
    matchPositions: step.matchStart != null ? [step.matchStart] : [],
    comparePairs: comparePairs.length ? comparePairs : null,
  };
}

export default function RabinKarpVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Rabin–Karp rolling hash' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'compare-hash' || step.type === 'char-cmp') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
