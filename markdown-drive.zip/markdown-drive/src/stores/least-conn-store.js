import { create } from 'zustand';

export const useLeastConnStore = create((set) => ({
  serverCount: 4,
  autoActive: false,
  autoRate: 3,
  processingSpeed: 3,
  currentLang: 'python',
  currentStep: null,
  totalRequests: 0,
  logs: [],
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setServerCount: (v) => set({ serverCount: v }),
  setAutoRate: (v) => set({ autoRate: v }),
  setProcessingSpeed: (v) => set({ processingSpeed: v }),
  toggleAuto: () => set((s) => ({ autoActive: !s.autoActive })),
  setLang: (lang) => set({ currentLang: lang }),
  setStep: (step) => set({ currentStep: step }),
  recordRequest: () => set((s) => ({ totalRequests: s.totalRequests + 1 })),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),
  reset: () => set({
    totalRequests: 0, currentStep: null, logs: [],
    autoActive: false, startTime: performance.now(),
  }),
}));
