# Design URL Shortener — Interview Thinking

> **Permanent Recall:** Walkthrough: (0–2 min) clarify scope, (2–5) requirements + scale, (5–15) high-level design, (15–35) deep dive on key generation, (35–45) follow-ups (analytics, rate limit, expiry). Lead with requirements; draw architecture early; choose key generation as your differentiator—KGS shows scale thinking.

---

## Step-by-Step Interview Walkthrough (45 min)

### 0–2 min: Clarify Scope

**You:** "Before I dive in, a few clarifications:
- Is this like bit.ly—public shorten + redirect?
- Do we need custom aliases, expiry, analytics?
- Scale: millions or billions of URLs per day?
- Any geo distribution requirements?"

> **FAANG Tip:** Never assume. Custom aliases and analytics change the design.

---

### 2–5 min: Requirements & Scale

**You:** "I'll assume:
- **Functional:** Shorten URL, redirect, optional custom alias, expiry, analytics
- **Scale:** 100M writes/day, ~10:1 read:write → ~12K redirect QPS peak
- **NFRs:** <100ms redirect latency, 99.99% availability"

State capacity: "At 100M URLs/day, 5 years, ~500B per record → ~100TB storage."

---

### 5–15 min: High-Level Design

**You:** "I'll draw the architecture."

```
Client → LB → API Servers (shorten + redirect)
                    ↓
              Redis (cache) ←→ DB (source of truth)
                    ↑
              Key Gen Service (KGS)
```

**Explain:** "Stateless API servers. Redirect: cache-aside—check Redis first, then DB. Shorten: get key from KGS or use hash; store in DB. KGS pre-generates keys so we never block on key creation."

---

### 15–35 min: Deep Dive — Key Generation

**Choose this.** It's the differentiator.

**You:** "Three options for key generation:

1. **Hash (MD5 + base62):** Stateless; same URL → same key. Collisions possible—we retry with salt.
2. **Counter + base62:** DB auto-increment or Snowflake; no collisions. Needs coordination.
3. **KGS (Key Generation Service):** Background process pre-generates millions of keys; API pops from pool. No collision, no blocking, scales independently."

"I'd choose KGS for production scale. Base62 gives us 62^7 ≈ 3.5T combinations with 7 chars."

---

### 35–45 min: Follow-Up Questions

| Question | Your Answer |
|----------|-------------|
| **Analytics?** | Async: on redirect, publish event to Kafka → analytics service writes to DW. Don't block redirect path. |
| **Rate limiting?** | Token bucket per IP/user on shorten. Redirect can be less strict; cache absorbs load. |
| **Expiry at scale?** | Background job scans `expires_at`; marks expired or moves to archive. Lazy: 404 on access. |
| **Abuse prevention?** | Rate limit, block known malicious domains, optional CAPTCHA for anonymous. |

---

## What to Say at Each Phase

| Phase | Script |
|-------|--------|
| **Requirements** | "I'll assume shorten, redirect, custom alias, expiry, and analytics. Scale: 100M/day writes, 10:1 read:write." |
| **Architecture** | "Client hits load balancer; stateless API servers. Redirect path: Redis first, DB fallback. Shorten: KGS provides keys." |
| **Key gen** | "KGS pre-generates keys in batches. API pops atomically. Base62 encoding for short codes." |
| **301 vs 302** | "302 for analytics—we see every redirect. 301 if destination never changes and we want browser cache." |

---

## Handling "Add Analytics"

**You:** "Redirect is the critical path. We can't block on analytics. So: on each redirect, we async publish an event—short_url, timestamp, IP, user-agent, referrer—to a message queue (Kafka). A separate analytics service consumes, aggregates, and stores in a data warehouse. Dashboard reads from there. Redirect stays sub-100ms."

---

## Handling "Rate Limiting"

**You:** "Shorten is write-heavy and can be abused. Rate limit per user/IP: token bucket, 100 req/min for anonymous, higher for authenticated. Store counters in Redis. Redirect: less strict; cache absorbs most traffic. Return 429 with Retry-After header."

---

## Red Flags to Avoid

| Don't | Do |
|-------|-----|
| Jump to "we'll use a hash" without collision handling | Explain hash + collision retry, or prefer KGS |
| Use 301 without mentioning analytics tradeoff | Discuss 301 vs 302 explicitly |
| Single database, no cache | Cache for redirect path; DB for persistence |
| Forget capacity estimation | Estimate QPS and storage upfront |

---

## 30-SECOND REVISION BOX

```
PHASES: Clarify → Requirements → HLD → Deep dive key gen → Follow-ups
KEY GEN: Differentiator—KGS best, hash needs collision handling
ANALYTICS: Async to Kafka, don't block redirect
RATE LIMIT: Token bucket on shorten, Redis counters
RED FLAGS: No scale numbers, single DB, wrong 301/302
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
