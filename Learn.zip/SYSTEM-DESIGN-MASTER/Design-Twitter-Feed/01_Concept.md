# Design Twitter/X Feed — Concept

> **Permanent Recall:** A Twitter feed shows tweets from followed users in reverse chronological order. Core flows: **post tweet**, **follow/unfollow**, **view timeline** (home feed + user feed), **like/retweet**, **search**, **trending**. Key challenge: **fan-out problem**—when a user with 10M followers posts, how to deliver to all? Read-heavy ~100:1 ratio. Scale: 500M DAU, 2.5B tweets/day.

---

## Problem Statement

Design a system like **Twitter/X** that:
- Allows users to post tweets (text, images, videos)
- Supports follow/unfollow relationships
- Shows **home timeline** (tweets from people you follow) and **user timeline** (tweets by specific user)
- Supports likes, retweets, search, and trending topics

---

## Functional Requirements

| Requirement | Description |
|-------------|-------------|
| **Post tweet** | Create tweet with text (280 chars), optional media (images/videos), store and publish to followers |
| **Follow / Unfollow** | Subscribe to or unsubscribe from a user's feed |
| **Home timeline** | View tweets from all followed users, reverse chronological order |
| **User timeline** | View tweets by a specific user only |
| **Like / Retweet** | React to tweets; retweet shares tweet to your followers |
| **Search** | Full-text search across tweets by keyword, hashtag |
| **Trending** | Discover top trending topics/hashtags in real time |

---

## Non-Functional Requirements

| Requirement | Target | Rationale |
|-------------|--------|-----------|
| **Read:write ratio** | ~100:1 | Users view feed far more than they post; optimize reads |
| **Feed load latency** | <200ms p99 | User-perceivable delay; critical for engagement |
| **Scale** | 500M DAU | Twitter/X scale; multi-region, horizontal scaling |
| **Consistency** | Eventual OK | Feed can be slightly stale; strong consistency not required |
| **Availability** | 99.99% | Social media expects always-on experience |

> **FAANG Tip:** Always state NFRs with numbers. "Fast" is vague; "<200ms p99" is precise and drives cache/DB design.

---

## Capacity Estimation

**Assumptions:**
- 500M DAU
- 5 tweets per user per day
- 100:1 read:write ratio (feed views vs posts)
- ~300 bytes per tweet (text + metadata)
- Media: images ~200KB, videos ~5MB average

**QPS:**
| Operation | Daily | QPS (avg) | QPS (peak, 3×) |
|-----------|-------|-----------|----------------|
| **Writes (tweets)** | 500M × 5 = 2.5B | ~28K/s | ~84K/s |
| **Reads (feed)** | 100× writes = 250B | ~2.8M/s | ~8.4M/s |

**Storage (tweet text + metadata):**
- 2.5B tweets/day × 300 bytes ≈ **750 GB/day** raw
- 5 years: 2.5B × 365 × 5 × 300B ≈ **1.4 PB** with replication (3×)

**Media storage:**
- Assume 20% tweets have images, 5% videos
- Images: 0.5B × 200KB ≈ 100 TB/day
- Videos: 125M × 5MB ≈ 625 TB/day
- Cold storage + CDN for hot content

---

## Traffic Patterns

| Pattern | Characteristic |
|---------|----------------|
| **Feed read** | Highly skewed; home timeline dominates; cache-friendly |
| **Tweet write** | Bursty; peaks during events, viral moments |
| **Celebrity posts** | 1 user → millions of fan-outs; the core design challenge |
| **Search** | Spike on trending events; Elasticsearch + cache |

```mermaid
flowchart LR
    A[User posts tweet] --> B[Tweet Service]
    B --> C[Fan-out Service]
    C --> D[Timeline Cache]
    E[User views feed] --> F[Timeline Service]
    F --> G[Cache / DB]
    G --> H[Return tweets]
```

---

## Key Design Implications

| Metric | Implication |
|--------|--------------|
| **100:1 read:write** | Cache-heavy; DB optimized for writes; reads from Redis |
| **<200ms feed** | Pre-computed timeline; no complex merge on hot path |
| **500M DAU** | Multi-region; sharding; horizontal scaling |
| **2.8M read QPS** | Hundreds of cache nodes; CDN for media |
| **Eventual consistency** | Async fan-out OK; no sync push to all followers |

---

## Out-of-Scope (Clarify in Interview)

| Feature | Typical scope |
|---------|---------------|
| **DMs** | Separate chat system |
| **Recommendations** | ML ranking; often "design feed" = chronological only |
| **Analytics** | Impressions, engagement; secondary |
| **Auth** | Assume existing auth service |

---

## 30-SECOND REVISION BOX

```
PROBLEM: Twitter feed — post, follow, timeline, like, search, trending
FUNCTIONAL: Post tweet, follow/unfollow, home/user timeline, like/retweet, search, trending
NFRs: 100:1 read:write, <200ms feed, 500M DAU, eventual consistency OK
QPS: ~28K writes/s, ~2.8M reads/s (peak ~8M)
STORAGE: ~280B/tweet text, PB-scale media (S3 + CDN)
FAN-OUT: Core challenge — celebrity with 10M followers
```

---

**Next: [[02_Mental-Model]]**
