import { Parser, Language } from 'web-tree-sitter';

const LANG_CONFIG = {
  cpp: { wasmUrl: '/tree-sitter-cpp.wasm', id: 'cpp' },
  python: { wasmUrl: '/tree-sitter-python.wasm', id: 'python' },
};

const SCOPE_NODE_TYPES = {
  cpp: new Set([
    'translation_unit', 'function_definition', 'class_specifier',
    'struct_specifier', 'namespace_definition', 'for_statement',
    'for_range_loop', 'while_statement', 'do_statement',
    'if_statement', 'else_clause', 'switch_statement', 'case_statement',
    'try_statement', 'catch_clause', 'compound_statement', 'lambda_expression',
  ]),
  python: new Set([
    'module', 'function_definition', 'class_definition',
    'for_statement', 'while_statement', 'if_statement',
    'elif_clause', 'else_clause', 'try_statement',
    'except_clause', 'with_statement', 'block',
  ]),
};

const DECLARATION_NODE_TYPES = {
  cpp: new Set(['declaration', 'parameter_declaration', 'init_declarator', 'field_declaration']),
  python: new Set(['assignment', 'augmented_assignment', 'for_statement']),
};

class SmartEngine {
  constructor() {
    this._parser = null;
    this._language = null;
    this._langId = null;
    this._tree = null;
    this._ready = false;
    this._initPromise = null;
  }

  async init(langId) {
    if (this._langId === langId && this._ready) return;
    if (this._initPromise && this._langId === langId) return this._initPromise;

    this._langId = langId;
    this._initPromise = this._doInit(langId);
    return this._initPromise;
  }

  async _doInit(langId) {
    try {
      const config = LANG_CONFIG[langId];
      if (!config) {
        this._ready = false;
        return;
      }

      if (!this._parser) {
        await Parser.init({
          locateFile: (path) => {
            if (path.endsWith('.wasm')) return '/tree-sitter.wasm';
            return path;
          },
        });
        this._parser = new Parser();
      }

      const lang = await Language.load(config.wasmUrl);
      this._parser.setLanguage(lang);
      this._language = lang;
      this._ready = true;
      this._tree = null;
    } catch (e) {
      console.warn('SmartEngine init failed:', e);
      this._ready = false;
    }
  }

  isReady() {
    return this._ready;
  }

  parse(code) {
    if (!this._ready) return null;
    try {
      this._tree = this._parser.parse(code);
      return this._tree;
    } catch {
      return null;
    }
  }

  getNodeAt(row, col) {
    if (!this._tree) return null;
    return this._tree.rootNode.descendantForPosition({ row, column: col });
  }

  // ── SCOPE ANALYSIS ─────────────────────────────────────────
  getScopeAt(row, col) {
    if (!this._tree) return { type: 'file', node: null, chain: [] };
    const scopeTypes = SCOPE_NODE_TYPES[this._langId] || new Set();
    const node = this._tree.rootNode.descendantForPosition({ row, column: col });

    const chain = [];
    let current = node;
    while (current) {
      if (scopeTypes.has(current.type)) {
        chain.unshift(this._classifyScope(current));
      }
      current = current.parent;
    }

    const innermost = chain.length > 0 ? chain[chain.length - 1] : { type: 'file', node: null };
    return { ...innermost, chain };
  }

  _classifyScope(node) {
    const t = node.type;

    if (t === 'translation_unit' || t === 'module') {
      return { type: 'file', node };
    }
    if (t === 'function_definition') {
      const nameNode = this._langId === 'cpp'
        ? node.childForFieldName('declarator')
        : node.childForFieldName('name');
      const name = nameNode ? this._extractDeclaratorName(nameNode) : '?';

      let returnType = null;
      if (this._langId === 'cpp') {
        const typeNode = node.childForFieldName('type');
        if (typeNode) returnType = typeNode.text;
      }
      return { type: 'function', node, name, returnType };
    }
    if (t === 'class_specifier' || t === 'class_definition') {
      const nameNode = node.childForFieldName('name');
      return { type: 'class', node, name: nameNode?.text || '?' };
    }
    if (t === 'struct_specifier') {
      const nameNode = node.childForFieldName('name');
      return { type: 'struct', node, name: nameNode?.text || '?' };
    }
    if (t === 'namespace_definition') {
      const nameNode = node.childForFieldName('name');
      return { type: 'namespace', node, name: nameNode?.text || '?' };
    }
    if (t.includes('for') || t === 'for_range_loop') {
      return { type: 'loop', subtype: 'for', node };
    }
    if (t.includes('while') || t === 'do_statement') {
      return { type: 'loop', subtype: 'while', node };
    }
    if (t === 'switch_statement') {
      return { type: 'switch', node };
    }
    if (t === 'if_statement' || t === 'elif_clause' || t === 'else_clause') {
      return { type: 'conditional', node };
    }
    if (t === 'try_statement' || t === 'catch_clause' || t === 'except_clause') {
      return { type: 'error_handling', node };
    }
    if (t === 'lambda_expression') {
      return { type: 'lambda', node };
    }
    return { type: 'block', node };
  }

  _extractDeclaratorName(node) {
    if (!node) return '?';
    if (node.type === 'identifier' || node.type === 'field_identifier') return node.text;
    if (node.type === 'function_declarator') {
      const inner = node.childForFieldName('declarator');
      return this._extractDeclaratorName(inner);
    }
    if (node.type === 'qualified_identifier') {
      const name = node.childForFieldName('name');
      return name ? name.text : node.text;
    }
    return node.text?.split('(')[0]?.trim() || '?';
  }

  // ── CONTEXT SUMMARY ───────────────────────────────────────
  getContext(row, col) {
    const scope = this.getScopeAt(row, col);
    const chain = scope.chain;
    const result = {
      scopeType: scope.type,
      inFunction: false,
      inClass: false,
      inLoop: false,
      inSwitch: false,
      functionName: null,
      className: null,
      returnType: null,
    };

    for (const s of chain) {
      if (s.type === 'function') {
        result.inFunction = true;
        result.functionName = s.name;
        result.returnType = s.returnType;
      }
      if (s.type === 'class' || s.type === 'struct') {
        result.inClass = true;
        result.className = s.name;
      }
      if (s.type === 'loop') result.inLoop = true;
      if (s.type === 'switch') result.inSwitch = true;
    }

    return result;
  }

  // ── VARIABLE TRACKING ─────────────────────────────────────
  getVisibleVariables(row, col) {
    if (!this._tree) return [];
    const vars = [];
    const seen = new Set();

    if (this._langId === 'cpp') {
      this._collectCppVariables(this._tree.rootNode, row, col, vars, seen);
    } else if (this._langId === 'python') {
      this._collectPythonVariables(this._tree.rootNode, row, col, vars, seen);
    }

    return vars;
  }

  _collectCppVariables(node, row, col, vars, seen) {
    if (node.startPosition.row > row) return;

    if (node.type === 'declaration' || node.type === 'field_declaration') {
      const typeNode = node.childForFieldName('type');
      const typeName = typeNode ? typeNode.text : 'auto';

      for (let i = 0; i < node.childCount; i++) {
        const child = node.child(i);
        if (child.type === 'init_declarator') {
          const declNode = child.childForFieldName('declarator');
          const name = this._extractDeclaratorName(declNode);
          if (name && !seen.has(name)) {
            seen.add(name);
            vars.push({ name, type: typeName, node: child });
          }
        } else if (child.type === 'identifier' || child.type === 'field_identifier') {
          const name = child.text;
          if (name && name !== typeName && !seen.has(name)) {
            seen.add(name);
            vars.push({ name, type: typeName, node: child });
          }
        }
      }
    }

    if (node.type === 'parameter_declaration') {
      const typeNode = node.childForFieldName('type');
      const declNode = node.childForFieldName('declarator');
      const typeName = typeNode ? typeNode.text : 'auto';
      const name = this._extractDeclaratorName(declNode);
      if (name && !seen.has(name)) {
        seen.add(name);
        vars.push({ name, type: typeName, node });
      }
    }

    if (node.type === 'for_range_loop') {
      const typeNode = node.childForFieldName('type');
      const declNode = node.childForFieldName('declarator');
      const typeName = typeNode ? typeNode.text : 'auto';
      const name = this._extractDeclaratorName(declNode);
      if (name && !seen.has(name)) {
        seen.add(name);
        vars.push({ name, type: typeName, node });
      }
    }

    for (let i = 0; i < node.childCount; i++) {
      this._collectCppVariables(node.child(i), row, col, vars, seen);
    }
  }

  _collectPythonVariables(node, row, col, vars, seen) {
    if (node.startPosition.row > row) return;

    if (node.type === 'assignment') {
      const left = node.childForFieldName('left');
      if (left && left.type === 'identifier') {
        const name = left.text;
        if (!seen.has(name)) {
          seen.add(name);
          const right = node.childForFieldName('right');
          const type = this._inferPythonType(right);
          vars.push({ name, type, node });
        }
      }
    }

    if (node.type === 'for_statement') {
      const left = node.childForFieldName('left');
      if (left && left.type === 'identifier') {
        const name = left.text;
        if (!seen.has(name)) {
          seen.add(name);
          vars.push({ name, type: 'Any', node });
        }
      }
    }

    if (node.type === 'function_definition') {
      const params = node.childForFieldName('parameters');
      if (params) {
        for (let i = 0; i < params.childCount; i++) {
          const p = params.child(i);
          if (p.type === 'identifier') {
            const name = p.text;
            if (!seen.has(name)) {
              seen.add(name);
              vars.push({ name, type: 'Any', node: p });
            }
          } else if (p.type === 'typed_parameter') {
            const nameNode = p.childForFieldName('name') || p.child(0);
            const typeNode = p.childForFieldName('type');
            if (nameNode) {
              const name = nameNode.text;
              if (!seen.has(name)) {
                seen.add(name);
                vars.push({ name, type: typeNode ? typeNode.text : 'Any', node: p });
              }
            }
          }
        }
      }
    }

    for (let i = 0; i < node.childCount; i++) {
      this._collectPythonVariables(node.child(i), row, col, vars, seen);
    }
  }

  // ── TYPE INFERENCE ─────────────────────────────────────────
  inferType(varName, row, col) {
    const vars = this.getVisibleVariables(row, col);
    const v = vars.find(x => x.name === varName);
    if (!v) return null;
    return this._normalizeType(v.type);
  }

  _normalizeType(rawType) {
    if (!rawType) return null;
    const t = rawType.replace(/\s+/g, ' ').trim();

    const templateMatch = t.match(/^(std::)?(vector|map|unordered_map|set|unordered_set|queue|stack|deque|priority_queue|list|array|pair|tuple|optional)\s*</);
    if (templateMatch) return templateMatch[2];

    const simpleMap = {
      'int': 'int', 'long': 'long', 'long long': 'long long',
      'float': 'float', 'double': 'double', 'char': 'char',
      'bool': 'bool', 'void': 'void', 'auto': 'auto',
      'std::string': 'string', 'string': 'string',
    };
    if (simpleMap[t]) return simpleMap[t];

    if (t.startsWith('std::')) return t.slice(5).split('<')[0];
    return t.split('<')[0].trim();
  }

  _inferPythonType(node) {
    if (!node) return 'Any';
    const t = node.type;
    if (t === 'string' || t === 'concatenated_string') return 'str';
    if (t === 'integer') return 'int';
    if (t === 'float') return 'float';
    if (t === 'true' || t === 'false') return 'bool';
    if (t === 'none') return 'None';
    if (t === 'list' || t === 'list_comprehension') return 'list';
    if (t === 'dictionary' || t === 'dictionary_comprehension') return 'dict';
    if (t === 'set' || t === 'set_comprehension') return 'set';
    if (t === 'tuple') return 'tuple';
    if (t === 'call') {
      const fn = node.childForFieldName('function');
      if (fn) {
        const fnName = fn.text;
        const typeMap = { 'int': 'int', 'float': 'float', 'str': 'str', 'list': 'list', 'dict': 'dict', 'set': 'set', 'tuple': 'tuple', 'bool': 'bool' };
        if (typeMap[fnName]) return typeMap[fnName];
      }
    }
    return 'Any';
  }

  // ── GET METHODS FOR TYPE ───────────────────────────────────
  getMethodsForType(typeName) {
    if (this._langId === 'cpp') return CPP_TYPE_METHODS[typeName] || [];
    if (this._langId === 'python') return PYTHON_TYPE_METHODS[typeName] || [];
    return [];
  }

  dispose() {
    if (this._tree) { this._tree.delete(); this._tree = null; }
    if (this._parser) { this._parser.delete(); this._parser = null; }
    this._ready = false;
    this._langId = null;
  }
}

// ── Type → methods databases ─────────────────────────────────
const CPP_TYPE_METHODS = {
  vector: [
    { label: 'push_back', insert: 'push_back(${1:val})', detail: 'Add to end' },
    { label: 'pop_back', insert: 'pop_back()', detail: 'Remove last' },
    { label: 'size', insert: 'size()', detail: 'Element count' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
    { label: 'clear', insert: 'clear()', detail: 'Remove all' },
    { label: 'front', insert: 'front()', detail: 'First element' },
    { label: 'back', insert: 'back()', detail: 'Last element' },
    { label: 'begin', insert: 'begin()', detail: 'Begin iterator' },
    { label: 'end', insert: 'end()', detail: 'End iterator' },
    { label: 'at', insert: 'at(${1:i})', detail: 'Access with bounds check' },
    { label: 'resize', insert: 'resize(${1:n})', detail: 'Change size' },
    { label: 'reserve', insert: 'reserve(${1:n})', detail: 'Reserve capacity' },
    { label: 'emplace_back', insert: 'emplace_back(${1:args})', detail: 'Construct in-place' },
    { label: 'insert', insert: 'insert(${1:pos}, ${2:val})', detail: 'Insert at position' },
    { label: 'erase', insert: 'erase(${1:pos})', detail: 'Erase at position' },
    { label: 'data', insert: 'data()', detail: 'Pointer to data' },
    { label: 'shrink_to_fit', insert: 'shrink_to_fit()', detail: 'Release extra memory' },
  ],
  string: [
    { label: 'length', insert: 'length()', detail: 'String length' },
    { label: 'size', insert: 'size()', detail: 'String size' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
    { label: 'substr', insert: 'substr(${1:pos}, ${2:len})', detail: 'Substring' },
    { label: 'find', insert: 'find(${1:str})', detail: 'Find substring' },
    { label: 'rfind', insert: 'rfind(${1:str})', detail: 'Find last' },
    { label: 'append', insert: 'append(${1:str})', detail: 'Append string' },
    { label: 'replace', insert: 'replace(${1:pos}, ${2:len}, ${3:str})', detail: 'Replace' },
    { label: 'c_str', insert: 'c_str()', detail: 'C-style string' },
    { label: 'clear', insert: 'clear()', detail: 'Clear string' },
    { label: 'front', insert: 'front()', detail: 'First char' },
    { label: 'back', insert: 'back()', detail: 'Last char' },
    { label: 'push_back', insert: 'push_back(${1:ch})', detail: 'Append char' },
    { label: 'pop_back', insert: 'pop_back()', detail: 'Remove last char' },
    { label: 'starts_with', insert: 'starts_with(${1:str})', detail: 'Check prefix (C++20)' },
    { label: 'ends_with', insert: 'ends_with(${1:str})', detail: 'Check suffix (C++20)' },
    { label: 'npos', insert: 'npos', detail: 'Not found sentinel' },
  ],
  map: [
    { label: 'insert', insert: 'insert({${1:key}, ${2:val}})', detail: 'Insert pair' },
    { label: 'erase', insert: 'erase(${1:key})', detail: 'Remove by key' },
    { label: 'find', insert: 'find(${1:key})', detail: 'Find by key' },
    { label: 'count', insert: 'count(${1:key})', detail: 'Count key' },
    { label: 'contains', insert: 'contains(${1:key})', detail: 'Contains key (C++20)' },
    { label: 'size', insert: 'size()', detail: 'Number of entries' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
    { label: 'clear', insert: 'clear()', detail: 'Remove all' },
    { label: 'begin', insert: 'begin()', detail: 'Begin iterator' },
    { label: 'end', insert: 'end()', detail: 'End iterator' },
    { label: 'emplace', insert: 'emplace(${1:key}, ${2:val})', detail: 'Emplace pair' },
  ],
  unordered_map: 'map',
  set: [
    { label: 'insert', insert: 'insert(${1:val})', detail: 'Insert element' },
    { label: 'erase', insert: 'erase(${1:val})', detail: 'Remove element' },
    { label: 'find', insert: 'find(${1:val})', detail: 'Find element' },
    { label: 'count', insert: 'count(${1:val})', detail: 'Count element' },
    { label: 'contains', insert: 'contains(${1:val})', detail: 'Contains? (C++20)' },
    { label: 'size', insert: 'size()', detail: 'Number of elements' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
    { label: 'clear', insert: 'clear()', detail: 'Remove all' },
    { label: 'begin', insert: 'begin()', detail: 'Begin iterator' },
    { label: 'end', insert: 'end()', detail: 'End iterator' },
  ],
  unordered_set: 'set',
  queue: [
    { label: 'push', insert: 'push(${1:val})', detail: 'Enqueue' },
    { label: 'pop', insert: 'pop()', detail: 'Dequeue' },
    { label: 'front', insert: 'front()', detail: 'Front element' },
    { label: 'back', insert: 'back()', detail: 'Back element' },
    { label: 'size', insert: 'size()', detail: 'Queue size' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
  ],
  stack: [
    { label: 'push', insert: 'push(${1:val})', detail: 'Push' },
    { label: 'pop', insert: 'pop()', detail: 'Pop' },
    { label: 'top', insert: 'top()', detail: 'Top element' },
    { label: 'size', insert: 'size()', detail: 'Stack size' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
  ],
  priority_queue: 'stack',
  deque: 'vector',
  list: [
    { label: 'push_back', insert: 'push_back(${1:val})', detail: 'Add to back' },
    { label: 'push_front', insert: 'push_front(${1:val})', detail: 'Add to front' },
    { label: 'pop_back', insert: 'pop_back()', detail: 'Remove from back' },
    { label: 'pop_front', insert: 'pop_front()', detail: 'Remove from front' },
    { label: 'size', insert: 'size()', detail: 'List size' },
    { label: 'empty', insert: 'empty()', detail: 'Is empty?' },
    { label: 'front', insert: 'front()', detail: 'First' },
    { label: 'back', insert: 'back()', detail: 'Last' },
    { label: 'begin', insert: 'begin()', detail: 'Begin iterator' },
    { label: 'end', insert: 'end()', detail: 'End iterator' },
    { label: 'clear', insert: 'clear()', detail: 'Remove all' },
    { label: 'sort', insert: 'sort()', detail: 'Sort list' },
    { label: 'reverse', insert: 'reverse()', detail: 'Reverse list' },
  ],
  pair: [
    { label: 'first', insert: 'first', detail: 'First element' },
    { label: 'second', insert: 'second', detail: 'Second element' },
  ],
  optional: [
    { label: 'value', insert: 'value()', detail: 'Get value' },
    { label: 'has_value', insert: 'has_value()', detail: 'Has value?' },
    { label: 'value_or', insert: 'value_or(${1:default})', detail: 'Value or default' },
  ],
};

const PYTHON_TYPE_METHODS = {
  str: [
    { label: 'strip', insert: 'strip()', detail: 'Remove whitespace' },
    { label: 'split', insert: 'split(${1:sep})', detail: 'Split string' },
    { label: 'join', insert: 'join(${1:iterable})', detail: 'Join' },
    { label: 'replace', insert: 'replace(${1:old}, ${2:new})', detail: 'Replace' },
    { label: 'find', insert: 'find(${1:sub})', detail: 'Find' },
    { label: 'count', insert: 'count(${1:sub})', detail: 'Count' },
    { label: 'startswith', insert: 'startswith(${1:prefix})', detail: 'Check prefix' },
    { label: 'endswith', insert: 'endswith(${1:suffix})', detail: 'Check suffix' },
    { label: 'upper', insert: 'upper()', detail: 'Uppercase' },
    { label: 'lower', insert: 'lower()', detail: 'Lowercase' },
    { label: 'title', insert: 'title()', detail: 'Title case' },
    { label: 'capitalize', insert: 'capitalize()', detail: 'Capitalize' },
    { label: 'isdigit', insert: 'isdigit()', detail: 'All digits?' },
    { label: 'isalpha', insert: 'isalpha()', detail: 'All letters?' },
    { label: 'format', insert: 'format(${1:args})', detail: 'Format' },
    { label: 'encode', insert: 'encode(${1:"utf-8"})', detail: 'Encode' },
    { label: 'lstrip', insert: 'lstrip()', detail: 'Left strip' },
    { label: 'rstrip', insert: 'rstrip()', detail: 'Right strip' },
    { label: 'zfill', insert: 'zfill(${1:width})', detail: 'Zero-fill' },
  ],
  list: [
    { label: 'append', insert: 'append(${1:item})', detail: 'Add to end' },
    { label: 'extend', insert: 'extend(${1:iterable})', detail: 'Extend' },
    { label: 'insert', insert: 'insert(${1:i}, ${2:item})', detail: 'Insert at index' },
    { label: 'remove', insert: 'remove(${1:item})', detail: 'Remove first match' },
    { label: 'pop', insert: 'pop(${1:index})', detail: 'Pop at index' },
    { label: 'clear', insert: 'clear()', detail: 'Clear list' },
    { label: 'index', insert: 'index(${1:item})', detail: 'Find index' },
    { label: 'count', insert: 'count(${1:item})', detail: 'Count' },
    { label: 'sort', insert: 'sort(${1:key=None})', detail: 'Sort' },
    { label: 'reverse', insert: 'reverse()', detail: 'Reverse' },
    { label: 'copy', insert: 'copy()', detail: 'Copy' },
  ],
  dict: [
    { label: 'keys', insert: 'keys()', detail: 'Keys' },
    { label: 'values', insert: 'values()', detail: 'Values' },
    { label: 'items', insert: 'items()', detail: 'Items' },
    { label: 'get', insert: 'get(${1:key}, ${2:default})', detail: 'Get' },
    { label: 'setdefault', insert: 'setdefault(${1:key}, ${2:default})', detail: 'Set default' },
    { label: 'update', insert: 'update(${1:other})', detail: 'Update' },
    { label: 'pop', insert: 'pop(${1:key})', detail: 'Pop key' },
    { label: 'clear', insert: 'clear()', detail: 'Clear' },
    { label: 'copy', insert: 'copy()', detail: 'Copy' },
  ],
  set: [
    { label: 'add', insert: 'add(${1:item})', detail: 'Add' },
    { label: 'discard', insert: 'discard(${1:item})', detail: 'Discard' },
    { label: 'remove', insert: 'remove(${1:item})', detail: 'Remove' },
    { label: 'union', insert: 'union(${1:other})', detail: 'Union' },
    { label: 'intersection', insert: 'intersection(${1:other})', detail: 'Intersection' },
    { label: 'difference', insert: 'difference(${1:other})', detail: 'Difference' },
    { label: 'pop', insert: 'pop()', detail: 'Pop arbitrary' },
    { label: 'clear', insert: 'clear()', detail: 'Clear' },
    { label: 'copy', insert: 'copy()', detail: 'Copy' },
  ],
  int: [],
  float: [],
  bool: [],
  tuple: [
    { label: 'count', insert: 'count(${1:val})', detail: 'Count' },
    { label: 'index', insert: 'index(${1:val})', detail: 'Index of' },
  ],
};

// Resolve aliases (e.g., unordered_map -> map methods)
for (const [key, val] of Object.entries(CPP_TYPE_METHODS)) {
  if (typeof val === 'string') {
    CPP_TYPE_METHODS[key] = CPP_TYPE_METHODS[val] || [];
  }
}

export default SmartEngine;
