# Database Design — Concept (Deep Understanding)

> **Permanent Recall:** Databases store and retrieve data. SQL (relational) gives you ACID, JOINs, and rigid schema — choose for transactions, structured data, and complex queries. NoSQL gives you horizontal scale, flexible schema, and specialized access — choose for high throughput, unstructured data, or specific patterns (key-value, document, graph, column-family). Indexing speeds reads (B-Tree for range, Hash for exact); isolation levels control concurrency correctness. Replication gives HA; sharding gives horizontal write scale.

---

## What is a Database?

**A database** is a structured system for storing, organizing, and retrieving data reliably. It's the **persistent memory** of your application — when the server restarts, your data survives.

### Real-World Analogy

Imagine a **massive library**. Without a database, your data is like books thrown in a pile — finding anything requires scanning everything. A database is the **library system**: shelves (tables), catalog cards (indexes), librarians (query engine), and rules (constraints). The catalog tells you exactly which shelf and position has the book you want.

### How a Database Works Step-by-Step

```
1. Application sends a query (e.g., SELECT * FROM users WHERE id = 42)
2. Query reaches the database server (via TCP connection)
3. Query parser validates the SQL syntax
4. Query optimizer creates an execution plan (which index to use, join order)
5. Storage engine reads data from disk (or memory cache)
6. Results are assembled and sent back to the application
7. Application processes the result set
```

```
Application ──► Connection Pool ──► Database Server
                                        │
                                   ┌────▼────┐
                                   │ Parser  │
                                   └────┬────┘
                                   ┌────▼────────┐
                                   │ Optimizer    │
                                   │ (execution   │
                                   │  plan)       │
                                   └────┬────────┘
                                   ┌────▼──────────┐
                                   │ Storage Engine │
                                   │ (InnoDB,       │
                                   │  PostgreSQL)   │
                                   └────┬──────────┘
                                   ┌────▼────┐
                                   │ Disk /  │
                                   │ Memory  │
                                   └─────────┘
```

**Key insight:** The application never touches the disk directly. The database engine manages all the complexity — parsing, optimizing, caching, locking, and persisting.

### Why Do We Need Databases?

| Problem Without DB | How a Database Solves It |
|--------------------|--------------------------|
| **Data lost on restart** | Durability — committed data survives crashes (write-ahead log) |
| **Concurrent access corrupts data** | Transactions + isolation — multiple users can read/write safely |
| **Finding data in millions of records is slow** | Indexes — B-Tree, Hash indexes turn O(n) scans into O(log n) lookups |
| **Data becomes inconsistent** | Constraints — foreign keys, unique, NOT NULL enforce rules |
| **One server can't handle all queries** | Replication (read replicas) and sharding (split data across servers) |
| **Server crashes = service down** | Replication — promote a replica to primary automatically |

---

## SQL (Relational) Databases — Deep Dive

### What Are They?

Relational databases store data in **tables** (rows and columns) with **strict schemas**. Every row in a table has the same columns. Tables are linked via **foreign keys**. You query them with **SQL** (Structured Query Language).

Examples: **PostgreSQL**, **MySQL**, **Oracle**, **SQL Server**, **SQLite**

### How They Work Internally

```
┌────────────────────────────────────────────────────────┐
│          RELATIONAL DATABASE (PostgreSQL)               │
│                                                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │  TABLES (Heap Files on Disk)                    │   │
│  │                                                 │   │
│  │  users table:                                   │   │
│  │  ┌────┬──────────┬─────────────────┬──────────┐ │   │
│  │  │ id │ name     │ email           │ created  │ │   │
│  │  ├────┼──────────┼─────────────────┼──────────┤ │   │
│  │  │ 1  │ Alice    │ alice@mail.com  │ 2024-01  │ │   │
│  │  │ 2  │ Bob      │ bob@mail.com    │ 2024-02  │ │   │
│  │  │ 3  │ Charlie  │ charlie@x.com   │ 2024-03  │ │   │
│  │  └────┴──────────┴─────────────────┴──────────┘ │   │
│  └─────────────────────────────────────────────────┘   │
│                                                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │  INDEXES (B-Tree Structures)                    │   │
│  │                                                 │   │
│  │  Index on email:                                │   │
│  │       [bob@mail.com]                            │   │
│  │       /            \                            │   │
│  │  [alice@...]    [charlie@...]                   │   │
│  │  → row 1        → row 3                        │   │
│  │                                                 │   │
│  │  Without index: scan ALL rows to find email     │   │
│  │  With index: tree lookup → O(log n)             │   │
│  └─────────────────────────────────────────────────┘   │
│                                                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │  WRITE-AHEAD LOG (WAL)                          │   │
│  │  Every change is logged BEFORE it hits disk     │   │
│  │  Crash? → Replay log → data recovered           │   │
│  └─────────────────────────────────────────────────┘   │
│                                                        │
│  ┌─────────────────────────────────────────────────┐   │
│  │  BUFFER POOL (Memory Cache)                     │   │
│  │  Hot data pages cached in RAM                   │   │
│  │  Reads check buffer first → disk only on miss   │   │
│  └─────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────┘
```

**How a SELECT query works internally (PostgreSQL):**

1. **Parser** receives `SELECT * FROM users WHERE email = 'alice@mail.com'`
2. Parser validates syntax → creates parse tree
3. **Planner/Optimizer** checks: is there an index on `email`?
   - YES → Index Scan (fast: O(log n))
   - NO → Sequential Scan (slow: scan every row)
4. **Executor** runs the plan
5. **Buffer Pool** checked first — if the page is in memory, no disk read
6. If not in memory → read from disk → cache in buffer pool
7. Row returned to application

**Why the WAL (Write-Ahead Log) matters:**

```
Without WAL:
  1. Application: INSERT INTO users (name) VALUES ('Dave')
  2. Database writes to disk
  3. POWER FAILURE mid-write → data corrupted, half-written row

With WAL:
  1. Application: INSERT INTO users (name) VALUES ('Dave')
  2. Database writes to WAL first (sequential write, very fast)
  3. Database acknowledges COMMIT to application
  4. Later, WAL changes are applied to actual data files (checkpoint)
  5. POWER FAILURE at any point?
     → Restart → replay WAL → data is consistent
```

### Tables, Rows, and Columns — The Basics

```
TABLE = a collection of rows with the same structure (like a spreadsheet)

users table:
  ┌────┬──────────┬─────────────────┬──────────┐
  │ id │ name     │ email           │ age      │
  ├────┼──────────┼─────────────────┼──────────┤  ← Each row is one record
  │ 1  │ Alice    │ alice@mail.com  │ 28       │
  │ 2  │ Bob      │ bob@mail.com    │ 35       │
  └────┴──────────┴─────────────────┴──────────┘
        ↑          ↑                 ↑
        columns    columns          columns
        (fixed     (every row       (schema enforced
         types)     has them)        by DB)
```

**Key insight:** In SQL, the schema is **enforced by the database**. You CANNOT insert a row without the required columns. You CANNOT put a string in an integer column. This strictness IS the feature — it prevents bad data from entering.

### JOINs — How Tables Connect

```
users                       orders
┌────┬──────┐              ┌────┬─────────┬────────┐
│ id │ name │              │ id │ user_id │ amount │
├────┼──────┤              ├────┼─────────┼────────┤
│ 1  │ Alice│◄─────────────│ 1  │ 1       │ 100.00 │
│ 2  │ Bob  │◄──┐          │ 2  │ 1       │ 50.00  │
└────┴──────┘   └──────────│ 3  │ 2       │ 75.00  │
                           └────┴─────────┴────────┘

SELECT users.name, orders.amount 
FROM users 
JOIN orders ON users.id = orders.user_id;

Result:
┌──────┬────────┐
│ name │ amount │
├──────┼────────┤
│ Alice│ 100.00 │
│ Alice│ 50.00  │
│ Bob  │ 75.00  │
└──────┴────────┘
```

**How JOINs work internally:**

```
NESTED LOOP JOIN (small tables):
  For each row in users:
    For each row in orders:
      If users.id = orders.user_id → output pair
  Complexity: O(n × m) — fine for small tables

HASH JOIN (medium tables):
  1. Build hash table from smaller table (users): {1: Alice, 2: Bob}
  2. Scan larger table (orders): for each order, hash user_id → find user
  Complexity: O(n + m) — much better

MERGE JOIN (sorted/indexed tables):
  1. Both tables sorted by join key
  2. Walk both in parallel, merge matching rows
  Complexity: O(n + m) — very fast for pre-sorted data

The optimizer CHOOSES which join strategy based on table sizes, indexes, statistics.
```

### Normalization — Deep Explanation

**Why normalization exists:** To eliminate **data redundancy** and prevent **update anomalies**.

```
BEFORE NORMALIZATION (one big table):
┌────┬──────┬───────────┬──────────┬────────┬───────────────┐
│ id │ name │ email     │ order_id │ amount │ product_name  │
├────┼──────┼───────────┼──────────┼────────┼───────────────┤
│ 1  │ Alice│ alice@x   │ 101      │ 100    │ iPhone        │
│ 1  │ Alice│ alice@x   │ 102      │ 50     │ Case          │  ← Alice's data REPEATED
│ 2  │ Bob  │ bob@x     │ 103      │ 75     │ MacBook       │
└────┴──────┴───────────┴──────────┴────────┴───────────────┘

Problems:
  1. UPDATE ANOMALY: Alice changes email → must update EVERY row with Alice
     (miss one = inconsistent data)
  2. INSERT ANOMALY: Can't add a user who hasn't ordered anything
  3. DELETE ANOMALY: Delete Alice's only order → lose Alice's info too
  4. STORAGE WASTE: Alice's name/email stored N times for N orders

AFTER NORMALIZATION (separate tables):
users:                    orders:
┌────┬──────┬───────┐    ┌─────┬─────────┬────────┬──────────┐
│ id │ name │ email │    │ id  │ user_id │ amount │ product  │
├────┼──────┼───────┤    ├─────┼─────────┼────────┼──────────┤
│ 1  │ Alice│ alice@│    │ 101 │ 1       │ 100    │ iPhone   │
│ 2  │ Bob  │ bob@  │    │ 102 │ 1       │ 50     │ Case     │
└────┴──────┴───────┘    │ 103 │ 2       │ 75     │ MacBook  │
                         └─────┴─────────┴────────┴──────────┘

Alice's info stored ONCE. Orders reference Alice by user_id.
Change Alice's email? Update ONE row. Done.
```

**Normal Forms explained simply:**

| Form | Rule | Real Example |
|------|------|-------------|
| **1NF** | Every cell has ONE value (no arrays, no lists) | BAD: `phones: "123, 456"`. GOOD: separate phone table |
| **2NF** | 1NF + every non-key column depends on the WHOLE primary key | If PK is (student_id, course_id) and `student_name` depends only on student_id → violates 2NF |
| **3NF** | 2NF + no column depends on another non-key column | If `zip_code` → `city` and `city` → `state`, then `state` transitively depends on `zip_code` → violates 3NF |
| **BCNF** | Every determinant is a candidate key | Rare edge case of 3NF |

**When to denormalize:**

```
NORMALIZE when:
  ✅ Writes are frequent (avoid updating multiple copies)
  ✅ Data integrity is critical (banking, inventory)
  ✅ Storage costs matter

DENORMALIZE when:
  ✅ Reads dominate (100:1 read:write ratio)
  ✅ JOINs across 5+ tables are killing latency
  ✅ You need single-read access (embed author name in post)
  ✅ You're using NoSQL (no JOINs available — must denormalize)
```

> **Interview Answer:** *"We normalize to 3NF by default to maintain data integrity and reduce redundancy. For read-heavy hot paths where JOINs are expensive, we selectively denormalize — like embedding the author name in a post document for the feed query."*

---

## NoSQL Databases — Deep Dive

### What Are They?

NoSQL ("Not Only SQL") databases are **non-relational** databases designed for specific access patterns, flexible schemas, and horizontal scalability. They sacrifice some SQL features (JOINs, ACID across multiple documents) for performance and flexibility.

### Why NoSQL Exists

```
PROBLEM WITH SQL AT MASSIVE SCALE:

Social media app: 500M users, 10B posts, 50B relationships
  
SQL approach:
  - users table: 500M rows
  - posts table: 10B rows
  - followers table: 50B rows
  
  "Show me my feed" = JOIN users + posts + followers + likes
  On 50B rows? Even with indexes, this JOIN is BRUTAL.
  
  Scaling? SQL scales VERTICALLY (bigger server).
  But there's a limit — you can't buy an infinitely big server.
  
  Horizontal scaling SQL? Sharding is possible but PAINFUL
  (cross-shard JOINs, distributed transactions, rebalancing).

NoSQL approach:
  - Pre-compute the feed per user
  - Store it as a document/list: user:123:feed → [post1, post2, ...]
  - One READ to get the feed. No JOINs.
  - Horizontal scaling is BUILT IN (data auto-partitioned across nodes)
```

### The 4 Types of NoSQL — Deep Explanation

### 1. Key-Value Store (Redis, DynamoDB, Memcached)

```
HOW IT WORKS:
  Think of it as a GIANT hash map / dictionary.
  
  Key → Value
  
  "user:123"        → {"name": "Alice", "email": "alice@x.com"}
  "session:abc456"  → {"user_id": 123, "expires": "2024-12-31"}
  "rate_limit:ip:1.2.3.4" → 47  (request count)
  
  Operations:
    GET key        → returns value       O(1)
    SET key value  → stores value        O(1)
    DELETE key     → removes value       O(1)
    EXPIRE key 300 → auto-delete in 300s
```

**How Redis works internally:**

```
┌──────────────────────────────────────────────────┐
│              REDIS SERVER                         │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │  IN-MEMORY DATA STRUCTURES                 │  │
│  │                                            │  │
│  │  Hash Table:                               │  │
│  │    "user:1" → {name: "Alice"}              │  │
│  │    "user:2" → {name: "Bob"}                │  │
│  │                                            │  │
│  │  Sorted Set (ZSET):                        │  │
│  │    "leaderboard" → [(Alice, 100),          │  │
│  │                      (Bob, 85),            │  │
│  │                      (Charlie, 72)]        │  │
│  │                                            │  │
│  │  List:                                     │  │
│  │    "queue:emails" → [msg1, msg2, msg3]     │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │  PERSISTENCE (optional)                    │  │
│  │                                            │  │
│  │  RDB: Point-in-time snapshot to disk       │  │
│  │       (every 5 minutes)                    │  │
│  │                                            │  │
│  │  AOF: Append-Only File — logs every write  │  │
│  │       (replay to rebuild state)            │  │
│  └────────────────────────────────────────────┘  │
│                                                  │
│  Single-threaded event loop (like Nginx)         │
│  Processes commands sequentially — no locks!     │
│  Typical latency: <1ms                           │
└──────────────────────────────────────────────────┘
```

**When to use Key-Value:**

| Use Case | Why Key-Value Fits |
|----------|-------------------|
| **Session storage** | Fast lookup by session ID; TTL for auto-expiry |
| **Caching** | Cache DB query results; GET is O(1), sub-ms |
| **Rate limiting** | `INCR rate:ip:1.2.3.4` → atomic counter with TTL |
| **Leaderboard** | Redis sorted sets: `ZADD`, `ZRANK`, `ZRANGE` in O(log n) |
| **Pub/Sub** | Redis channels for real-time messaging between services |

### 2. Document Store (MongoDB, CouchDB, Firestore)

```
HOW IT WORKS:
  Each record is a "document" — a JSON/BSON object.
  Documents are grouped into "collections" (like tables).
  
  Collection: users
  ┌────────────────────────────────────────────────┐
  │  {                                             │
  │    "_id": ObjectId("abc123"),                  │
  │    "name": "Alice",                            │
  │    "email": "alice@mail.com",                  │
  │    "address": {                                │  ← Nested object
  │      "street": "123 Main St",                  │
  │      "city": "Mumbai",                         │
  │      "zip": "400001"                           │
  │    },                                          │
  │    "orders": [                                 │  ← Embedded array
  │      {"id": 1, "amount": 100, "product": "iPhone"},
  │      {"id": 2, "amount": 50, "product": "Case"}   
  │    ]                                           │
  │  }                                             │
  └────────────────────────────────────────────────┘
  
  Key difference from SQL:
  - No fixed schema — next document can have different fields
  - Nested objects and arrays are FIRST-CLASS (no JOINs needed)
  - Each document is self-contained — one read gets everything
```

**Why MongoDB is popular:**

```
SQL (3 tables, 2 JOINs):
  SELECT u.name, o.amount, p.name
  FROM users u 
  JOIN orders o ON u.id = o.user_id
  JOIN products p ON o.product_id = p.id
  WHERE u.id = 1;
  
MongoDB (1 read):
  db.users.findOne({_id: 1})
  → Returns user WITH embedded orders WITH product names
  
  ONE query. ZERO joins. Much faster for this read pattern.
```

**When to use Document Store:**

| Use Case | Why Document Fits |
|----------|------------------|
| **User profiles** with varying fields | User A has `bio`, User B has `company` — flexible schema |
| **Content management** (blog, CMS) | Posts with nested comments, tags, media — one document |
| **Product catalog** with varying attributes | Phone has `screen_size`, Book has `pages` — different fields per type |
| **Rapid prototyping** | Schema changes without migrations |

### 3. Column-Family Store (Cassandra, HBase, ScyllaDB)

```
HOW IT WORKS:
  Data organized by ROWS and COLUMN FAMILIES.
  Unlike SQL where rows have fixed columns, each row can have 
  DIFFERENT columns within a column family.
  
  Optimized for: massive writes, time-series data, wide rows
  
  Row Key → {column1: value1, column2: value2, ...}
  
  Example — sensor data:
  ┌─────────────┬──────────────────────────────────────────┐
  │ Row Key     │ Columns (timestamp → reading)            │
  │ (sensor_id) │                                          │
  ├─────────────┼──────────────────────────────────────────┤
  │ sensor_001  │ 2024-01-01T00:00: 72.5                   │
  │             │ 2024-01-01T00:01: 72.8                   │
  │             │ 2024-01-01T00:02: 73.1                   │
  │             │ ... (millions of columns per row)        │
  ├─────────────┼──────────────────────────────────────────┤
  │ sensor_002  │ 2024-01-01T00:00: 68.2                   │
  │             │ 2024-01-01T00:01: 68.5                   │
  └─────────────┴──────────────────────────────────────────┘
```

**How Cassandra writes are fast:**

```
CASSANDRA WRITE PATH:
  1. Client sends write to ANY node (no single primary!)
  2. Node writes to COMMIT LOG (sequential disk write — fast)
  3. Node writes to MEMTABLE (in-memory — instant)
  4. Returns success to client (write complete!)
  5. Later: memtable flushed to SSTABLE on disk (background)
  
  Why it's fast:
  - No locks (no single primary bottleneck)
  - Sequential writes only (no random I/O)
  - Write acknowledged after memory + log (not full disk write)
  
  Result: 100K+ writes/second per node
```

**When to use Column-Family:**

| Use Case | Why Column-Family Fits |
|----------|----------------------|
| **Time-series data** (IoT, metrics, logs) | Wide rows (one row = one device + millions of timestamps) |
| **Write-heavy workloads** | Cassandra's LSM-tree is optimized for writes |
| **Distributed, multi-datacenter** | Cassandra is designed for multi-DC replication |
| **No single point of failure needed** | Every node is equal — no primary/replica distinction |

### 4. Graph Database (Neo4j, Amazon Neptune, JanusGraph)

```
HOW IT WORKS:
  Data stored as NODES (entities) and EDGES (relationships).
  Each node and edge can have properties.
  
  (Alice)──[:FRIENDS {since: 2020}]──>(Bob)
     │                                  │
     └──[:FOLLOWS]──>(Charlie)          └──[:FOLLOWS]──>(Charlie)
     
  Graph query (Cypher):
    "Find all friends of Alice's friends" (2-hop traversal)
    
    MATCH (alice:User {name: "Alice"})-[:FRIENDS]->(friend)-[:FRIENDS]->(fof)
    RETURN fof.name
    
    In SQL, this would be:
    SELECT u3.name
    FROM friends f1
    JOIN friends f2 ON f1.friend_id = f2.user_id
    WHERE f1.user_id = 'alice_id'
    
    Now imagine 6 hops deep. In SQL? 6 self-JOINs on a billion-row table.
    In a graph DB? Just traverse edges. FAST.
```

**When to use Graph:**

| Use Case | Why Graph Fits |
|----------|---------------|
| **Social networks** (friends, followers, connections) | Traversing relationships is the core operation |
| **Recommendation engines** ("people who bought X also bought Y") | Multi-hop path queries |
| **Fraud detection** (find circular money flows) | Pattern matching in connected data |
| **Knowledge graphs** (Wikipedia-style entity relationships) | Rich interconnected data |

### Complete NoSQL Comparison

| Aspect | Key-Value (Redis) | Document (MongoDB) | Column-Family (Cassandra) | Graph (Neo4j) |
|--------|-------------------|-------------------|--------------------------|---------------|
| **Data model** | key → value | JSON documents | Row key → columns | Nodes + edges |
| **Query** | GET/SET by key | Rich queries on fields | Query by partition key | Graph traversal (Cypher) |
| **Schema** | None (blob) | Flexible (per doc) | Flexible (per row) | Property graph |
| **Scaling** | In-memory, cluster | Sharded (auto) | Masterless, multi-DC | Single-server or cluster |
| **Speed** | Sub-ms (in-memory) | Low ms | Low ms (writes), ms (reads) | Fast for graph queries |
| **Best for** | Cache, sessions, counters | CMS, profiles, catalogs | Time-series, IoT, logs | Social, recommendations |
| **Worst for** | Complex queries, large data | Complex JOINs, transactions | Ad-hoc queries, reads | Non-graph queries |

---

## ACID Properties — Deep Explanation

### Why ACID Exists

Without ACID, databases would be unreliable. Imagine a bank where transferring money can leave your account debited but the recipient's account NOT credited. ACID prevents this.

### Atomicity — All or Nothing

```
BANK TRANSFER: Move $100 from Account A to Account B

Step 1: Debit A: balance = balance - 100  ($500 → $400)
Step 2: Credit B: balance = balance + 100  ($300 → $400)

WITHOUT ATOMICITY:
  Step 1 succeeds: A = $400
  Step 2 FAILS (server crash, disk error): B still = $300
  
  RESULT: $100 VANISHED. A lost money, B didn't get it.
  Total money before: $800. After: $700. Money destroyed.

WITH ATOMICITY:
  BEGIN TRANSACTION;
    UPDATE accounts SET balance = balance - 100 WHERE id = 'A';
    UPDATE accounts SET balance = balance + 100 WHERE id = 'B';
  COMMIT;
  
  If Step 2 fails → ROLLBACK → A goes back to $500
  RESULT: Either BOTH happen or NEITHER happens.
```

**How atomicity works internally:**

The database uses the **Write-Ahead Log (WAL)**. Before any change, it writes a "before image" to the log. If the transaction needs to rollback, it reads the log and undoes changes. If the server crashes mid-transaction, on restart it reads the log and rolls back incomplete transactions.

### Consistency — Valid State to Valid State

```
CONSISTENCY means: the database moves from one VALID state to another.
If you define rules (constraints), the database enforces them.

Rules:
  - balance >= 0 (CHECK constraint)
  - Every order must have a valid user_id (FOREIGN KEY)
  - Email must be unique (UNIQUE constraint)

Transfer $600 from A (balance = $500):
  Debit: $500 - $600 = -$100 → VIOLATES balance >= 0 constraint
  Database REJECTS the transaction
  A stays at $500, B stays unchanged
  
Without consistency: A could go negative. Business rule broken.
```

### Isolation — Concurrent Transactions Don't Interfere

```
Two people transfer money from Account A simultaneously:

T1: Transfer $100 from A to B
T2: Transfer $50 from A to C

A's balance: $500

WITHOUT ISOLATION (both read A = $500 at the same time):
  T1 reads A = $500 → calculates $500 - $100 = $400 → writes A = $400
  T2 reads A = $500 → calculates $500 - $50 = $450 → writes A = $450
  
  RESULT: A = $450 (T2 overwrote T1's change!)
  Expected: A = $500 - $100 - $50 = $350
  $100 LOST. This is called the "lost update" problem.

WITH ISOLATION:
  T1 locks A → reads $500 → writes $400 → releases lock
  T2 waits → reads $400 → writes $350 → releases lock
  
  RESULT: A = $350 ✅ Correct!
```

### Durability — Committed = Permanent

```
1. Application: INSERT INTO orders VALUES (...)
2. Database writes to WAL
3. Database returns "COMMIT OK" to application
4. Application tells user: "Order placed!"
5. POWER FAILURE. Server dies.

After restart:
  Database reads WAL → finds committed INSERT → applies it
  Order is in the database. User's order wasn't lost.

WITHOUT DURABILITY:
  Database confirmed "COMMIT" but hadn't written to disk
  Power failure → data gone
  User says "I placed an order!" but database has no record
```

---

## Isolation Levels — Deep Explanation

### Why Different Levels Exist

Stronger isolation = more correct, but SLOWER (more locking).
Weaker isolation = faster, but can see weird results.

**You choose the level based on what your application can tolerate.**

### Level 1: Read Uncommitted (Weakest)

```
T1: UPDATE accounts SET balance = 0 WHERE id = 'A';  (not yet committed)
T2: SELECT balance FROM accounts WHERE id = 'A';  → reads 0 (DIRTY READ!)
T1: ROLLBACK;  (A goes back to $500)

T2 used the value 0, but that value NEVER actually committed.
T2 made decisions based on phantom data.

USE CASE: Almost never. Maybe for approximate counts where accuracy doesn't matter.
```

### Level 2: Read Committed (Default in PostgreSQL)

```
T1: UPDATE accounts SET balance = 0 WHERE id = 'A';  (not yet committed)
T2: SELECT balance FROM accounts WHERE id = 'A';  → reads $500 (sees old committed value) ✅

T1: COMMIT;
T2: SELECT balance FROM accounts WHERE id = 'A';  → reads 0 (sees new committed value)

Problem: Within the SAME transaction, T2 got different results for the same query.
This is called a "Non-Repeatable Read."

USE CASE: Most web applications. Good enough for most queries.
```

### Level 3: Repeatable Read (Default in MySQL InnoDB)

```
T2: BEGIN;
T2: SELECT balance FROM accounts WHERE id = 'A';  → reads $500
T1: UPDATE accounts SET balance = 0 WHERE id = 'A'; COMMIT;
T2: SELECT balance FROM accounts WHERE id = 'A';  → STILL reads $500 ✅

T2 sees a SNAPSHOT from the start of its transaction.
Even though T1 committed a change, T2 doesn't see it until T2 commits and starts a new transaction.

Problem: "Phantom reads" — new ROWS can appear.
T2: SELECT COUNT(*) FROM orders WHERE user_id = 1;  → 5
T1: INSERT INTO orders (user_id, ...) VALUES (1, ...); COMMIT;
T2: SELECT COUNT(*) FROM orders WHERE user_id = 1;  → 6 (phantom row!)

USE CASE: Most financial queries where you need consistent reads within a transaction.
```

### Level 4: Serializable (Strongest)

```
Transactions execute as if they ran ONE AT A TIME, in serial order.
No dirty reads, no non-repeatable reads, no phantoms.

T1 and T2 both try to modify the same data:
  Database either:
  1. Uses locks to force serial execution (slow)
  2. Uses "Serializable Snapshot Isolation" (PostgreSQL) — detects conflicts and aborts one

USE CASE: Critical financial operations, inventory management where phantom reads
could cause overbooking.

TRADEOFF: Slowest. More aborted transactions. Higher retry rate.
```

### Isolation Level Summary

| Level | Dirty Read | Non-Repeatable Read | Phantom Read | Performance |
|-------|-----------|--------------------|--------------| ------------|
| **Read Uncommitted** | YES | YES | YES | Fastest |
| **Read Committed** | NO | YES | YES | Good (default PostgreSQL) |
| **Repeatable Read** | NO | NO | YES (usually) | Moderate (default MySQL) |
| **Serializable** | NO | NO | NO | Slowest |

> **Interview Answer:** *"Read Committed is fine for most web apps. Repeatable Read for financial reports that need consistent snapshots. Serializable only for critical operations like inventory booking or double-entry ledger where phantom reads could cause real money loss."*

---

## Indexing — Deep Explanation

### Why Indexes Exist

Without an index, every query requires a **full table scan** — reading every single row. With 100 million rows, that's unacceptable.

### How a B-Tree Index Works (The Default)

```
WITHOUT INDEX: "Find user where email = 'alice@mail.com'"
  
  Scan row 1: email = 'zack@...' → no
  Scan row 2: email = 'bob@...'  → no
  Scan row 3: email = 'alice@...'→ YES! But DB doesn't know if there's another...
  ...must scan ALL remaining rows
  
  10 million rows → 10 million comparisons = O(n) = SECONDS

WITH B-TREE INDEX on email:

                    [maria@]
                   /        \
          [charlie@]        [sarah@]
         /     \           /      \
    [alice@]  [dave@]  [peter@]  [zack@]
    → row 3   → row 7  → row 5  → row 1
    
  "Find alice@mail.com"
  1. Start at root: alice < maria → go LEFT
  2. alice < charlie → go LEFT
  3. Found alice@ → row 3
  
  3 comparisons instead of 10 million!
  O(log n) — for 10M rows, ~24 comparisons
```

**How a B-Tree actually stores data on disk:**

```
B-TREE (balanced tree, not binary tree — each node has MANY keys):

┌──────────────────────────────────────────────┐
│  ROOT NODE (fits in one 8KB disk page)       │
│  Keys: [F, M, T]                             │
│  Pointers: [→child1, →child2, →child3, →child4] │
└──┬────────┬──────────┬───────────────────┬───┘
   ▼        ▼          ▼                   ▼
 [A-E]    [G-L]      [N-S]              [U-Z]
 (leaf     (leaf      (leaf              (leaf
  pages)   pages)     pages)             pages)
  
Each leaf page contains:
  - Key values (sorted)
  - Pointers to actual table rows (row ID / ctid)
  
Why B-Tree not binary tree?
  - Disk reads are expensive. Each node read = 1 disk I/O.
  - B-Tree nodes are wide (100s of keys) → fewer levels → fewer disk reads
  - 10 million keys, fanout 200: only 3-4 levels deep
  - 3-4 disk reads to find ANY key in 10M records
```

### Hash Index — How It's Different

```
HASH INDEX:
  hash("alice@mail.com") → bucket 42 → row pointer
  
  O(1) lookup — even faster than B-Tree for EXACT match!
  
  BUT: hash("alice@") and hash("bob@") have NO ordering relationship
  
  "Find all users WHERE email BETWEEN 'a%' AND 'c%'" 
  → Hash index CANNOT help (no ordering)
  → Must scan all buckets
  
  "Find user WHERE email = 'alice@mail.com'"
  → Hash index: INSTANT (one hash, one lookup)
```

### When to Use Which Index

| Query Type | Best Index | Why |
|-----------|-----------|-----|
| **Exact match** (`WHERE id = 42`) | B-Tree or Hash | Both work; Hash is O(1) but B-Tree is versatile |
| **Range query** (`WHERE age BETWEEN 20 AND 30`) | B-Tree | Sorted structure enables range scans |
| **Sorting** (`ORDER BY created_at DESC`) | B-Tree | Already sorted; just walk the tree |
| **Prefix match** (`WHERE name LIKE 'Ali%'`) | B-Tree | Sorted; can find starting position |
| **Low-cardinality filter** (`WHERE status IN ('active', 'inactive')`) | Bitmap | Efficient bit operations for few distinct values |

### Composite Index — Order Matters!

```
CREATE INDEX idx ON orders(user_id, created_at);

This index is a B-Tree sorted by user_id FIRST, then created_at WITHIN each user_id.

Stored like:
  (user_1, 2024-01-01) → row 5
  (user_1, 2024-01-15) → row 12
  (user_1, 2024-02-01) → row 20
  (user_2, 2024-01-10) → row 3
  (user_2, 2024-03-01) → row 8
  
QUERIES THIS INDEX HELPS:
  ✅ WHERE user_id = 1                    (uses first column)
  ✅ WHERE user_id = 1 AND created_at > '2024-01-01'  (uses both)
  ✅ WHERE user_id = 1 ORDER BY created_at DESC        (uses both)
  
QUERIES THIS INDEX DOES NOT HELP:
  ❌ WHERE created_at > '2024-01-01'      (second column alone — not leftmost!)
  ❌ ORDER BY created_at                   (second column alone)

RULE: Composite indexes work LEFT TO RIGHT.
Index on (A, B, C) helps: (A), (A,B), (A,B,C). NOT: (B), (C), (B,C).
```

### Covering Index — Avoid Table Lookup

```
NORMAL INDEX:
  Query: SELECT name, email FROM users WHERE email = 'alice@mail.com'
  1. Look up 'alice@mail.com' in email index → find row pointer
  2. Go to table, read row → get name and email
  TWO reads: index + table

COVERING INDEX:
  CREATE INDEX idx ON users(email) INCLUDE (name);
  
  Query: SELECT name, email FROM users WHERE email = 'alice@mail.com'
  1. Look up 'alice@mail.com' in index → index ALREADY HAS name and email!
  2. Return directly from index. No table read needed.
  ONE read: index only (called "index-only scan")
  
  FASTER because: fewer disk reads, less I/O, smaller working set
```

> **Interview Answer:** *"I'd create indexes on columns used in WHERE, JOIN, and ORDER BY for our hot queries. For composite indexes, equality columns first, then range, then sort. If we frequently SELECT a small set of columns, a covering index avoids the table lookup entirely."*

---

## BASE Properties — Deep Explanation

### What BASE Means

BASE is the NoSQL counterpart to ACID — it describes the consistency model of distributed databases that prioritize **availability** over **immediate consistency**.

```
ACID (SQL):
  Your bank balance is ALWAYS correct. If you check from two ATMs,
  both show the same number. No exceptions.

BASE (NoSQL):
  Your Instagram follower count might show 1000 on your phone
  and 1003 on your laptop for a few seconds.
  Eventually (within seconds), both show 1003.
  
  Is that acceptable? For social media, YES.
  For banking, NO — that's why banks use ACID.
```

| Property | Meaning | Real Example |
|----------|---------|-------------|
| **Basically Available** | System always responds, even if data is slightly stale | Amazon: "Add to Cart" always works; price might be 1 second old |
| **Soft state** | Data may change over time without new input (due to replication sync) | Your post shows 5 likes on server A, 6 likes on server B — they'll sync |
| **Eventually consistent** | Given no new writes, ALL replicas will converge to the same value | After 2 seconds, both servers show 6 likes |

---

## CAP Theorem — Deep Explanation

### What Is It?

In a **distributed** database system, you can guarantee only **2 out of 3** properties during a network partition:

```
         C (Consistency)
        / \
       /   \
      /     \
     /       \
    A ─────── P (Partition Tolerance)
 (Availability)

C = Every read receives the most recent write (or error)
A = Every request receives a response (no errors, no timeouts)
P = System continues working despite network partitions between nodes

In the real world, network partitions HAPPEN (P is mandatory).
So the REAL choice is: C or A during a partition?
```

### CP System (Consistency + Partition Tolerance)

```
During a network partition:
  Node A can't talk to Node B.
  
  CP choice: REFUSE to serve requests until partition heals.
  "I'd rather give you NO answer than a WRONG answer."
  
  Example: MongoDB (in some configurations), HBase, Zookeeper
  Use case: Banking, inventory — wrong data is worse than no data
```

### AP System (Availability + Partition Tolerance)

```
During a network partition:
  Node A can't talk to Node B.
  
  AP choice: SERVE requests on both nodes (maybe stale data).
  "I'd rather give you a possibly-stale answer than no answer."
  
  Example: Cassandra, DynamoDB, CouchDB
  Use case: Social media, e-commerce catalog — stale data is acceptable
```

| | CP (Consistency) | AP (Availability) |
|---|------------------|-------------------|
| **During partition** | Some requests fail/block | All requests succeed (maybe stale) |
| **After partition heals** | Data is correct | Data eventually converges |
| **Examples** | MongoDB, ZooKeeper, HBase | Cassandra, DynamoDB, CouchDB |
| **Best for** | Banking, inventory, ledger | Social media, catalog, sessions |

> **Interview Answer:** *"CAP says during a network partition, you choose consistency or availability. For payment processing, we choose CP — we'd rather reject an order than accept two conflicting ones. For a social feed, we choose AP — showing a slightly stale feed is better than showing nothing."*

---

## Replication — Deep Explanation

### Why Replication Exists

One database server is a **single point of failure**. If it dies, your entire application goes down. Replication copies data to multiple servers.

### How Primary-Replica Replication Works

```
┌──────────────┐        ┌──────────────┐
│   PRIMARY     │───────►│  REPLICA 1   │
│  (read+write) │  WAL   │  (read only) │
│              │  stream │              │
└──────────────┘        └──────────────┘
       │                        
       │                 ┌──────────────┐
       └────────────────►│  REPLICA 2   │
                  WAL    │  (read only) │
                  stream └──────────────┘

WRITE: Application → Primary → WAL → stream to Replicas
READ:  Application → Any replica (or primary)

Benefits:
  1. HA: Primary dies → promote Replica 1 to primary
  2. Read scale: 3 replicas = 3× read capacity
  3. Backups: Replica serves as live backup
```

### Synchronous vs Asynchronous Replication

```
SYNCHRONOUS:
  1. App writes to Primary
  2. Primary sends to Replica
  3. Replica confirms "I have it"
  4. Primary returns "COMMIT OK" to App
  
  ✅ Replica is always up-to-date (strong consistency)
  ❌ SLOW — every write waits for replica confirmation
  ❌ If replica is down → writes BLOCK (availability risk)

ASYNCHRONOUS:
  1. App writes to Primary
  2. Primary returns "COMMIT OK" to App immediately
  3. Primary sends to Replica in background
  4. Replica receives it milliseconds to seconds later
  
  ✅ FAST — writes don't wait for replica
  ✅ Replica down? Writes still work
  ❌ REPLICATION LAG — replica might be seconds behind
  ❌ Primary dies before replica got latest data → DATA LOSS
```

| | Synchronous | Asynchronous |
|---|------------|-------------|
| **Write latency** | Higher (waits for replica) | Lower (immediate ack) |
| **Data safety** | No data loss on primary failure | Possible data loss on primary failure |
| **Availability** | Blocked if replica is down | Works even if replica is down |
| **Use case** | Banking, payment systems | Most web apps, social media |

---

## Sharding — Deep Explanation

### Why Sharding Exists

Replication scales **reads** but NOT **writes** — all writes still go to one primary. When your write volume exceeds what one server can handle, you need **sharding**: splitting data across multiple independent database servers.

### How Sharding Works

```
WITHOUT SHARDING:
  ALL data on ONE server
  ┌──────────────────────────────┐
  │ Users: 100M rows             │
  │ Orders: 500M rows            │
  │ ONE server handles ALL reads │
  │ ONE server handles ALL writes│
  └──────────────────────────────┘
  Problem: One server can't handle 50K writes/sec

WITH SHARDING (by user_id):
  Data SPLIT across multiple servers
  
  Shard 1 (user_id 1-25M):     Shard 2 (user_id 25M-50M):
  ┌──────────────────────┐      ┌──────────────────────┐
  │ Users: 25M rows      │      │ Users: 25M rows      │
  │ Orders: 125M rows    │      │ Orders: 125M rows    │
  └──────────────────────┘      └──────────────────────┘
  
  Shard 3 (user_id 50M-75M):   Shard 4 (user_id 75M-100M):
  ┌──────────────────────┐      ┌──────────────────────┐
  │ Users: 25M rows      │      │ Users: 25M rows      │
  │ Orders: 125M rows    │      │ Orders: 125M rows    │
  └──────────────────────┘      └──────────────────────┘
  
  Each shard handles 25% of traffic → 4× total capacity
```

### Sharding Strategies

| Strategy | How It Works | Pros | Cons |
|----------|-------------|------|------|
| **Range-based** | user_id 1-25M → Shard 1, 25M-50M → Shard 2 | Simple; range queries on shard key are efficient | Hotspot risk (new users all hit last shard) |
| **Hash-based** | `hash(user_id) % 4` → shard | Even distribution | Range queries hit ALL shards |
| **Geo-based** | India users → Shard-India, US users → Shard-US | Low latency for local users | Uneven if one region has more users |
| **Directory-based** | Lookup table: user_id → shard_id | Flexible; can move users between shards | Lookup table is SPOF |

### The Biggest Sharding Problem: Cross-Shard Queries

```
User 1 is on Shard 1. User 2 is on Shard 2.

Query: "Show all orders from users in Mumbai"
  → Which shard has Mumbai users? ALL of them might.
  → Must query ALL 4 shards, collect results, merge.
  → SLOW. COMPLEX. This is why sharding is the LAST resort.

Query: "Show User 1's orders"
  → hash(1) → Shard 1. Query ONE shard.
  → FAST. This is the ideal sharded query.

RULE: Shard by a key that your most common queries use.
  E-commerce sharded by user_id: user's orders → one shard ✅
  E-commerce sharded by order_id: user's orders → scattered across shards ❌
```

> **Interview Answer:** *"I'd delay sharding as long as possible — it adds enormous complexity. First: optimize queries and indexes. Then: read replicas for read scaling. Then: vertical scaling (bigger machine). Only when a single primary can't handle write volume do we shard — and we'd choose the shard key based on our most common access pattern."*

---

## Connection Pooling — Deep Explanation

### Why Connection Pooling Exists

Opening a database connection is **expensive**: TCP handshake + TLS negotiation + authentication + session setup = **5-20ms per connection**. If every request opens a new connection, at 1000 requests/second that's 1000 connections being opened and closed every second.

```
WITHOUT POOLING:
  Request 1 → Open connection (5ms) → Query (2ms) → Close → Total: 7ms
  Request 2 → Open connection (5ms) → Query (2ms) → Close → Total: 7ms
  1000 req/s → 1000 connections opened/closed per second
  Database: "Too many connections!" → crashes

WITH POOLING:
  Pool of 20 connections kept OPEN permanently
  Request 1 → Borrow connection from pool (0ms) → Query (2ms) → Return to pool → 2ms
  Request 2 → Borrow connection from pool (0ms) → Query (2ms) → Return to pool → 2ms
  1000 req/s → 20 connections shared. Database happy.
```

```
┌────────────────────────────────────────────────┐
│  APPLICATION                                    │
│                                                │
│  Request 1 ──┐                                 │
│  Request 2 ──┤    ┌──────────────────────┐     │
│  Request 3 ──┼───►│  CONNECTION POOL      │     │
│  ...         │    │  [conn1] [conn2]      │     │
│  Request N ──┘    │  [conn3] ... [conn20] │     │
│                   └──────────┬───────────┘     │
│                              │                 │
└──────────────────────────────┼─────────────────┘
                               │
                    ┌──────────▼───────────┐
                    │  DATABASE SERVER      │
                    │  (20 persistent       │
                    │   connections)        │
                    └──────────────────────┘
```

**Tools:** HikariCP (Java), pgBouncer (PostgreSQL proxy), PgPool-II

---

## SQL vs NoSQL — Complete Comparison

| Aspect | SQL (PostgreSQL, MySQL) | NoSQL (varies by type) |
|--------|------------------------|----------------------|
| **Data model** | Tables, rows, columns with fixed schema | Flexible: key-value, document, column-family, graph |
| **Schema** | Rigid — ALTER TABLE to change | Flexible — add fields anytime (per document) |
| **Scaling** | Vertical first; horizontal via sharding (complex) | Horizontal by design (auto-partitioning) |
| **ACID** | Full ACID support natively | Usually eventual consistency (BASE); some offer ACID per document |
| **JOINs** | Native, optimized JOIN support | No JOINs; denormalize or app-level |
| **Transactions** | Multi-table, multi-row | Single-document (some: multi-document) |
| **Query language** | SQL (standardized, powerful) | Varies: Redis commands, MongoDB query, CQL, Cypher |
| **Best for** | Banking, ERP, reporting, complex relationships | Sessions, caching, feeds, IoT, flexible data |
| **Examples** | PostgreSQL, MySQL, Oracle, SQL Server | Redis, MongoDB, Cassandra, Neo4j, DynamoDB |

> **Interview Answer:** *"SQL when we need ACID transactions, complex queries, and data has clear relationships — like a payment system or inventory. NoSQL when we need horizontal scale, flexible schema, or specialized access patterns — like caching with Redis, social feeds with Cassandra, or user profiles with MongoDB. Most production systems use both: SQL as the source of truth, Redis for caching, maybe Elasticsearch for search."*

---

## Database Placement in Architecture

```
                    ┌─────────────────────────────────────────────────┐
                    │                   CLIENTS                        │
                    └─────────────────────────┬───────────────────────┘
                                              │
                    ┌─────────────────────────▼───────────────────────┐
                    │           LOAD BALANCER (L7)                     │
                    └─────────────────────────┬───────────────────────┘
                                              │
                    ┌─────────────────────────▼───────────────────────┐
                    │           APPLICATION SERVERS                    │
                    │      [App 1]  [App 2]  [App 3]                 │
                    └────────┬────────────────────┬──────────────────┘
                             │                    │
                    ┌────────▼────────┐  ┌───────▼────────┐
                    │  CACHE (Redis)   │  │  SEARCH         │
                    │  Sessions, hot   │  │  (Elasticsearch) │
                    │  data, counters  │  │  Full-text       │
                    └────────┬────────┘  └────────────────┘
                             │
                    ┌────────▼────────────────────────────┐
                    │  PRIMARY DATABASE (PostgreSQL)       │
                    │  Source of truth for all writes      │
                    └────────┬───────────────┬────────────┘
                             │               │
                    ┌────────▼────┐  ┌──────▼─────┐
                    │ Read Replica │  │ Read Replica│
                    │ (reads)      │  │ (reads)     │
                    └─────────────┘  └────────────┘
```

**Where each database type sits:**

| Position | What Database Does | Type |
|----------|-------------------|------|
| **Primary (source of truth)** | All writes, critical reads | SQL (PostgreSQL, MySQL) |
| **Read replicas** | Serve read queries to reduce primary load | Same as primary |
| **Cache layer** | Sub-ms reads for hot data, sessions | Redis, Memcached |
| **Search layer** | Full-text search, autocomplete | Elasticsearch, Solr |
| **Analytics** | Heavy aggregations, reports | Data warehouse (BigQuery, Snowflake) |
| **Message/Event store** | Event sourcing, audit log | Kafka, DynamoDB Streams |

---

## Quick Memory Card

```
WHAT:           Database = persistent, structured storage with query engine
WHY:            Durability, concurrency, integrity, performance, scaling
SQL:            Tables, schema, JOINs, ACID. PostgreSQL, MySQL.
NoSQL:          Key-Value (Redis), Document (MongoDB), Column (Cassandra), Graph (Neo4j)
ACID:           Atomic (all-or-nothing), Consistent (valid state), Isolated (no interference), Durable (crash-safe)
BASE:           Basically Available, Soft state, Eventually consistent (NoSQL tradeoff)
CAP:            During partition: choose Consistency (CP) or Availability (AP)
ISOLATION:      Read Uncommitted < Read Committed < Repeatable Read < Serializable
INDEX:          B-Tree (range+sort), Hash (exact), Composite (left-to-right), Covering (index-only scan)
NORMALIZE:      Reduce redundancy, prevent anomalies. Denormalize for read-heavy paths.
REPLICATION:    Primary → Replicas. HA + read scale. Sync (safe) vs Async (fast).
SHARDING:       Split data across servers by key. Last resort for write scale.
POOL:           Reuse DB connections. 5-20 connections shared across 1000s of requests.
```

---

**Next:** [[02_Mental-Model]]
