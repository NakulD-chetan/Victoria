# Availability and Reliability — Concept

>

---

## What Is Availability?

**Availability** is the percentage of time a system is operational and able to serve requests. Formula:

```
Availability = Uptime / (Uptime + Downtime)
```

Expressed as a percentage (e.g., 99.9%) or "nines" (e.g., "three nines").

> **FAANG Tip:** Interviewers care that you know availability ≠ reliability. Availability = "is it up?" Reliability = "does it work correctly when up?"



# Percentage Quick Revision Notes


| Percent | Fast Trick        |
| ------- | ----------------- |
| 10%     | Move decimal left |
| 1%      | Divide by 100     |
| 5%      | Half of 10%       |
| 20%     | Double 10%        |
| 50%     | Half              |
| 25%     | Divide by 4       |
| 75%     | 50% + 25%         |
| 12.5%   | Divide by 8       |
| 33%     | Approx 1/3        |
| 66%     | Approx 2/3        |


---

# Golden Trick

```text
x% of y = y% of x

```

Example:

```text
18% of 50
=
50% of 18
=
9

```

---

# Mental Formula

```text
Percentage = (part / total) × 100

```

---

# Fast Percentage Build Method

Use:

```text
10%
5%
1%
50%
25%

```

Then combine.

Example:

```text
35% of 200

10% = 20
30% = 60
5% = 10

= 70

```

---

# Increase Formula

```text
New Value = Original + Percentage

```

Example:

```text
20% increase on 500

10% = 50
20% = 100

500 + 100 = 600

```

---

# Discount Formula

```text
Final = Original - Discount

```

Example:

```text
30% off on 2000

10% = 200
30% = 600

2000 - 600 = 1400

```

---

# Reverse Percentage Trick

```text
20 is 10% of what?

1% = 2
100% = 200

```

---

# One-Line Memory Rule

```text
Always find 10% first.

```

---

## The "Nines" Table


| Availability | Nines | Downtime per Year | Downtime per Month |
| ------------ | ----- | ----------------- | ------------------ |
| **90%**      | 1     | 36.5 days         | 3 days             |
| **99%**      | 2     | 3.65 days         | 7.3 hours          |
| **99.9%**    | 3     | 8.76 hours        | 43.8 minutes       |
| **99.95%**   | 3.5   | 4.38 hours        | 21.9 minutes       |
| **99.99%**   | 4     | 52.6 minutes      | 4.38 minutes       |
| **99.999%**  | 5     | 5.26 minutes      | 26.3 seconds       |
| **99.9999%** | 6     | 31.5 seconds      | 2.63 seconds       |


```
NINES QUICK REFERENCE:
99%   → 3.65 days/year
99.9% → 8.76 hours/year
99.99%  → 52.6 min/year
99.999% → 5.26 min/year
```

---

## Availability vs Reliability vs Durability


| Term             | Definition                       | Example                                    |
| ---------------- | -------------------------------- | ------------------------------------------ |
| **Availability** | System is up and reachable       | Server responds to ping                    |
| **Reliability**  | System behaves correctly when up | Returns correct data, no corrupt responses |
| **Durability**   | Data survives failures over time | Data in DB survives disk failure           |


```
AVAILABILITY:  "Can I reach it?"
RELIABILITY:   "Does it return the right answer?"
DURABILITY:    "Will my data still be there tomorrow?"
```

> **FAANG Tip:** A system can be "available" (returns 200 OK) but unreliable (returns wrong data). A database can be available but lose data on crash (not durable).

---

## SLA, SLO, SLI


| Term                              | Definition                               | Example                       |
| --------------------------------- | ---------------------------------------- | ----------------------------- |
| **SLA** (Service Level Agreement) | Contractual commitment; breach = penalty | "99.9% uptime or credit"      |
| **SLO** (Service Level Objective) | Internal target you aim for              | "We target 99.95%"            |
| **SLI** (Service Level Indicator) | Raw measurement                          | "Requests successful / total" |


```
Relationship:
  SLI (measured) → SLO (target) → SLA (contract)

Example:
  SLI:  success_rate = 99.92%
  SLO:  target 99.9%
  SLA:  promise 99.9%, credit if below
```

---

## Fault Tolerance: Core Mechanisms


| Mechanism       | Description                           | Example                    |
| --------------- | ------------------------------------- | -------------------------- |
| **Redundancy**  | Multiple copies of components         | Multiple servers, replicas |
| **Replication** | Data copied across nodes              | DB replicas, cache cluster |
| **Failover**    | Automatic switch to backup on failure | Primary → standby takeover |


```
FAULT TOLERANCE STACK:
  Redundancy → Replication → Failover → Health Monitoring
```

---

## Redundancy Types


| Type               | Description                              | Use Case                      |
| ------------------ | ---------------------------------------- | ----------------------------- |
| **Active-Active**  | All nodes serve traffic; load shared     | Stateless APIs, read replicas |
| **Active-Passive** | One primary, standby idle until failover | Database primary, LB pair     |
| **N+1**            | N nodes needed; N+1 provisioned          | 3 servers need 4 total        |
| **2N**             | Double capacity; full redundancy         | Mission-critical systems      |


```
ACTIVE-ACTIVE:    [A] [B] [C]  — all serve
ACTIVE-PASSIVE:   [A] — [B standby]
N+1:              4 servers for 3 needed
2N:               6 servers (3×2) for 3 needed
```

---

## Failover Strategies


| Strategy | Startup Time    | Cost   | Data State               | Use Case          |
| -------- | --------------- | ------ | ------------------------ | ----------------- |
| **Cold** | Minutes–hours   | Low    | Restored from backup     | Non-critical, DR  |
| **Warm** | Seconds–minutes | Medium | Pre-provisioned, syncing | Most production   |
| **Hot**  | Instant         | High   | Real-time sync           | Payment, critical |


```
COLD:  No standby; spin up on failure (slow)
WARM:  Standby ready, sync in progress (medium)
HOT:   Standby always in sync, instant switch (fast)
```

> **FAANG Tip:** "What failover strategy?" → "Warm for most services; hot for payment/critical path."

---

## Single Points of Failure (SPOF)

**SPOF** = any component whose failure causes total system outage.

```
SPOF IDENTIFICATION:
  Trace every request path → identify components that have no backup
  Common SPOFs: single LB, single DB, single AZ, single DNS
```

---

## Disaster Recovery: RPO and RTO


| Term                               | Definition                      | Question It Answers          |
| ---------------------------------- | ------------------------------- | ---------------------------- |
| **RPO** (Recovery Point Objective) | Max acceptable data loss (time) | "How much data can we lose?" |
| **RTO** (Recovery Time Objective)  | Max acceptable downtime         | "How long can we be down?"   |


```
                    DISASTER OCCURS
                          │
    ┌─────────────────────┼─────────────────────┐
    │                     │                     │
    ▼                     ▼                     ▼
  RPO                 OUTAGE                  RTO
  (data loss)         (down)                (recovery time)
  
  Last backup         [==== DOWNTIME ====]
  to restore          Target: restore within RTO
```

---

## Chaos Engineering

**Chaos engineering** = intentionally inject failures to validate resilience.(ability of system to continue working or recover quickly when failures happen.)


| Tool / Concept           | Purpose                                  |
| ------------------------ | ---------------------------------------- |
| **Netflix Chaos Monkey** | Randomly terminates production instances |
| **Chaos Kong**           | Simulates entire AZ failure              |
| **Fault injection**      | Inject latency, errors, partitions       |


> **FAANG Tip:** "How do you test failover?" → "Chaos engineering: Chaos Monkey for instances, game days for AZ failure."

---

## Health Monitoring


| Component         | Purpose                         |
| ----------------- | ------------------------------- |
| **Health checks** | LB probes; /health endpoint     |
| **Heartbeat**     | Cluster members signal liveness |
| **Metrics**       | Latency, error rate, throughput |
| **Alerting**      | Notify on threshold breach      |


```
HEALTH CHECK HIERARCHY:
  Liveness  → "Is process running?"
  Readiness → "Can it accept traffic?"
  Deep      → "Can it reach DB/cache?"
```

---

## 30-SECOND REVISION BOX

```
AVAILABILITY = uptime %; NINES = 99.9% = 8.76 hrs/year
AVAIL vs RELI vs DUR: up? correct? data persists?
SLA/SLO/SLI: contract → target → measurement
REDUNDANCY: active-active, active-passive, N+1, 2N
FAILOVER: cold (slow), warm (medium), hot (instant)
SPOF: trace path, eliminate single components
RPO/RTO: data loss limit, downtime limit
CHAOS: Chaos Monkey, fault injection
```

---

**Next: [[02_Mental-Model]]**