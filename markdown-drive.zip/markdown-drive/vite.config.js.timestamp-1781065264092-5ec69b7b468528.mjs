// vite.config.js
import { defineConfig } from "file:///Users/chetan/Desktop/Garage/markdown-drive/node_modules/vite/dist/node/index.js";
import react from "file:///Users/chetan/Desktop/Garage/markdown-drive/node_modules/@vitejs/plugin-react/dist/index.js";
var vite_config_default = defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:3001",
        changeOrigin: true
      }
    }
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          "viz-bucket": [
            "./src/components/algorithms/TokenBucketVisualizer.jsx",
            "./src/components/algorithms/TokenBucketCanvas.jsx",
            "./src/components/algorithms/LeakyBucketVisualizer.jsx",
            "./src/components/algorithms/LeakyBucketCanvas.jsx"
          ],
          "viz-window": [
            "./src/components/algorithms/FixedWindowVisualizer.jsx",
            "./src/components/algorithms/FixedWindowCanvas.jsx",
            "./src/components/algorithms/SlidingLogVisualizer.jsx",
            "./src/components/algorithms/SlidingLogCanvas.jsx",
            "./src/components/algorithms/SlidingCounterVisualizer.jsx",
            "./src/components/algorithms/SlidingCounterCanvas.jsx"
          ],
          "viz-lb": [
            "./src/components/algorithms/LeastConnVisualizer.jsx",
            "./src/components/algorithms/LeastConnCanvas.jsx"
          ],
          "viz-morris": [
            "./src/components/algorithms/MorrisTraversalVisualizer.jsx",
            "./src/components/algorithms/MorrisTraversalCanvas.jsx"
          ],
          "notes-app": [
            "./src/components/notes/NotesApp.jsx",
            "./src/components/notes/FileTreeSidebar.jsx",
            "./src/components/notes/NoteEditor.jsx",
            "./src/stores/notes-store.js"
          ],
          "tiptap": ["@tiptap/react", "@tiptap/starter-kit", "@tiptap/extension-image", "@tiptap/extension-placeholder", "@tiptap/extension-task-list", "@tiptap/extension-task-item"],
          "excalidraw": ["@excalidraw/excalidraw"],
          "roughjs": ["roughjs"],
          "react-markdown": ["react-markdown", "remark-gfm"],
          "monaco-editor": ["@monaco-editor/react"],
          "xterm": ["@xterm/xterm", "@xterm/addon-fit", "@xterm/addon-web-links"]
        }
      }
    }
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsidml0ZS5jb25maWcuanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImNvbnN0IF9fdml0ZV9pbmplY3RlZF9vcmlnaW5hbF9kaXJuYW1lID0gXCIvVXNlcnMvY2hldGFuL0Rlc2t0b3AvR2FyYWdlL21hcmtkb3duLWRyaXZlXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ZpbGVuYW1lID0gXCIvVXNlcnMvY2hldGFuL0Rlc2t0b3AvR2FyYWdlL21hcmtkb3duLWRyaXZlL3ZpdGUuY29uZmlnLmpzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9Vc2Vycy9jaGV0YW4vRGVza3RvcC9HYXJhZ2UvbWFya2Rvd24tZHJpdmUvdml0ZS5jb25maWcuanNcIjtpbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlJztcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCc7XG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtyZWFjdCgpXSxcbiAgc2VydmVyOiB7XG4gICAgcG9ydDogNTE3MyxcbiAgICBwcm94eToge1xuICAgICAgJy9hcGknOiB7XG4gICAgICAgIHRhcmdldDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMScsXG4gICAgICAgIGNoYW5nZU9yaWdpbjogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgfSxcbiAgYnVpbGQ6IHtcbiAgICByb2xsdXBPcHRpb25zOiB7XG4gICAgICBvdXRwdXQ6IHtcbiAgICAgICAgbWFudWFsQ2h1bmtzOiB7XG4gICAgICAgICAgJ3Zpei1idWNrZXQnOiBbXG4gICAgICAgICAgICAnLi9zcmMvY29tcG9uZW50cy9hbGdvcml0aG1zL1Rva2VuQnVja2V0VmlzdWFsaXplci5qc3gnLFxuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvYWxnb3JpdGhtcy9Ub2tlbkJ1Y2tldENhbnZhcy5qc3gnLFxuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvYWxnb3JpdGhtcy9MZWFreUJ1Y2tldFZpc3VhbGl6ZXIuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvTGVha3lCdWNrZXRDYW52YXMuanN4JyxcbiAgICAgICAgICBdLFxuICAgICAgICAgICd2aXotd2luZG93JzogW1xuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvYWxnb3JpdGhtcy9GaXhlZFdpbmRvd1Zpc3VhbGl6ZXIuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvRml4ZWRXaW5kb3dDYW52YXMuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvU2xpZGluZ0xvZ1Zpc3VhbGl6ZXIuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvU2xpZGluZ0xvZ0NhbnZhcy5qc3gnLFxuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvYWxnb3JpdGhtcy9TbGlkaW5nQ291bnRlclZpc3VhbGl6ZXIuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvU2xpZGluZ0NvdW50ZXJDYW52YXMuanN4JyxcbiAgICAgICAgICBdLFxuICAgICAgICAgICd2aXotbGInOiBbXG4gICAgICAgICAgICAnLi9zcmMvY29tcG9uZW50cy9hbGdvcml0aG1zL0xlYXN0Q29ublZpc3VhbGl6ZXIuanN4JyxcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvTGVhc3RDb25uQ2FudmFzLmpzeCcsXG4gICAgICAgICAgXSxcbiAgICAgICAgICAndml6LW1vcnJpcyc6IFtcbiAgICAgICAgICAgICcuL3NyYy9jb21wb25lbnRzL2FsZ29yaXRobXMvTW9ycmlzVHJhdmVyc2FsVmlzdWFsaXplci5qc3gnLFxuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvYWxnb3JpdGhtcy9Nb3JyaXNUcmF2ZXJzYWxDYW52YXMuanN4JyxcbiAgICAgICAgICBdLFxuICAgICAgICAgICdub3Rlcy1hcHAnOiBbXG4gICAgICAgICAgICAnLi9zcmMvY29tcG9uZW50cy9ub3Rlcy9Ob3Rlc0FwcC5qc3gnLFxuICAgICAgICAgICAgJy4vc3JjL2NvbXBvbmVudHMvbm90ZXMvRmlsZVRyZWVTaWRlYmFyLmpzeCcsXG4gICAgICAgICAgICAnLi9zcmMvY29tcG9uZW50cy9ub3Rlcy9Ob3RlRWRpdG9yLmpzeCcsXG4gICAgICAgICAgICAnLi9zcmMvc3RvcmVzL25vdGVzLXN0b3JlLmpzJyxcbiAgICAgICAgICBdLFxuICAgICAgICAgICd0aXB0YXAnOiBbJ0B0aXB0YXAvcmVhY3QnLCAnQHRpcHRhcC9zdGFydGVyLWtpdCcsICdAdGlwdGFwL2V4dGVuc2lvbi1pbWFnZScsICdAdGlwdGFwL2V4dGVuc2lvbi1wbGFjZWhvbGRlcicsICdAdGlwdGFwL2V4dGVuc2lvbi10YXNrLWxpc3QnLCAnQHRpcHRhcC9leHRlbnNpb24tdGFzay1pdGVtJ10sXG4gICAgICAgICAgJ2V4Y2FsaWRyYXcnOiBbJ0BleGNhbGlkcmF3L2V4Y2FsaWRyYXcnXSxcbiAgICAgICAgICAncm91Z2hqcyc6IFsncm91Z2hqcyddLFxuICAgICAgICAgICdyZWFjdC1tYXJrZG93bic6IFsncmVhY3QtbWFya2Rvd24nLCAncmVtYXJrLWdmbSddLFxuICAgICAgICAgICdtb25hY28tZWRpdG9yJzogWydAbW9uYWNvLWVkaXRvci9yZWFjdCddLFxuICAgICAgICAgICd4dGVybSc6IFsnQHh0ZXJtL3h0ZXJtJywgJ0B4dGVybS9hZGRvbi1maXQnLCAnQHh0ZXJtL2FkZG9uLXdlYi1saW5rcyddLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9LFxuICB9LFxufSk7XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQW1ULFNBQVMsb0JBQW9CO0FBQ2hWLE9BQU8sV0FBVztBQUVsQixJQUFPLHNCQUFRLGFBQWE7QUFBQSxFQUMxQixTQUFTLENBQUMsTUFBTSxDQUFDO0FBQUEsRUFDakIsUUFBUTtBQUFBLElBQ04sTUFBTTtBQUFBLElBQ04sT0FBTztBQUFBLE1BQ0wsUUFBUTtBQUFBLFFBQ04sUUFBUTtBQUFBLFFBQ1IsY0FBYztBQUFBLE1BQ2hCO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBLE9BQU87QUFBQSxJQUNMLGVBQWU7QUFBQSxNQUNiLFFBQVE7QUFBQSxRQUNOLGNBQWM7QUFBQSxVQUNaLGNBQWM7QUFBQSxZQUNaO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0EsY0FBYztBQUFBLFlBQ1o7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxVQUNBLFVBQVU7QUFBQSxZQUNSO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxVQUNBLGNBQWM7QUFBQSxZQUNaO0FBQUEsWUFDQTtBQUFBLFVBQ0Y7QUFBQSxVQUNBLGFBQWE7QUFBQSxZQUNYO0FBQUEsWUFDQTtBQUFBLFlBQ0E7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFVBQ0EsVUFBVSxDQUFDLGlCQUFpQix1QkFBdUIsMkJBQTJCLGlDQUFpQywrQkFBK0IsNkJBQTZCO0FBQUEsVUFDM0ssY0FBYyxDQUFDLHdCQUF3QjtBQUFBLFVBQ3ZDLFdBQVcsQ0FBQyxTQUFTO0FBQUEsVUFDckIsa0JBQWtCLENBQUMsa0JBQWtCLFlBQVk7QUFBQSxVQUNqRCxpQkFBaUIsQ0FBQyxzQkFBc0I7QUFBQSxVQUN4QyxTQUFTLENBQUMsZ0JBQWdCLG9CQUFvQix3QkFBd0I7QUFBQSxRQUN4RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
