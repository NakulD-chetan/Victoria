# Bit Manipulation — Problem List

> **FAANG Focus:** 30 problems, 10 MUST-DO, structured study plan.

---

## MUST-DO (10 Problems)

| # | Problem | LeetCode | Key Concept |
|---|---------|----------|-------------|
| 1 | Number of 1 Bits | 191 | Popcount / Brian Kernighan |
| 2 | Power of Two | 231 | n & (n-1) == 0 |
| 3 | Single Number | 136 | XOR cancellation |
| 4 | Missing Number | 268 | XOR indices + values |
| 5 | Single Number II | 137 | Bit count mod 3 |
| 6 | Single Number III | 260 | XOR + split by diff bit |
| 7 | Subsets | 78 | Bitmask enumeration |
| 8 | Maximum XOR of Two Numbers | 421 | Trie / Greedy bits |
| 9 | Counting Bits | 338 | DP + n & (n-1) |
| 10 | Shortest Path Visiting All Nodes | 847 | BFS + Bitmask |

---

## Full Problem List (30)

### Easy (1–10)

| # | Problem | LeetCode | Concept |
|---|---------|----------|---------|
| 1 | Number of 1 Bits | 191 | Popcount |
| 2 | Reverse Bits | 190 | Bit extraction |
| 3 | Power of Two | 231 | n & (n-1) |
| 4 | Single Number | 136 | XOR |
| 5 | Missing Number | 268 | XOR |
| 6 | Counting Bits | 338 | DP + LSB |
| 7 | Hamming Distance | 461 | XOR + popcount |
| 8 | Complement of Base 10 Integer | 1009 | XOR with mask |
| 9 | Binary Number with Alternating Bits | 693 | XOR shifted |
| 10 | Power of Four | 342 | Power of 2 + mask |

### Medium (11–22)

| # | Problem | LeetCode | Concept |
|---|---------|----------|---------|
| 11 | Single Number II | 137 | Bit count mod 3 |
| 12 | Single Number III | 260 | XOR + split |
| 13 | Subsets | 78 | Bitmask |
| 14 | Bitwise AND of Numbers Range | 201 | Common prefix |
| 15 | Maximum XOR of Two Numbers | 421 | Trie/Greedy |
| 16 | Total Hamming Distance | 477 | Bit-by-bit |
| 17 | Decode XORed Array | 1720 | XOR properties |
| 18 | XOR Queries of a Subarray | 1310 | Prefix XOR |
| 19 | Gray Code | 89 | i ^ (i>>1) |
| 20 | Minimum Flips to Make a OR b Equal to c | 1318 | Bit analysis |
| 21 | Partition to K Equal Sum Subsets | 698 | Bitmask DP |
| 22 | Can I Win | 464 | Game + Bitmask |

### Hard (23–30)

| # | Problem | LeetCode | Concept |
|---|---------|----------|---------|
| 23 | Shortest Path Visiting All Nodes | 847 | BFS + Bitmask |
| 24 | Maximum AND Sum of Array | 2172 | Bitmask DP |
| 25 | Smallest Sufficient Team | 1125 | Bitmask DP |
| 26 | Stickers to Spell Word | 691 | Bitmask DP |
| 27 | Number of Valid Words for Each Puzzle | 1178 | Submask |
| 28 | Maximum Number of Achievable Transfer Requests | 1601 | Bitmask brute |
| 29 | Find the Shortest Superstring | 943 | Bitmask DP (TSP) |
| 30 | Maximum Students Taking Exam | 1349 | Profile bitmask |

---

## Study Plan

| Week | Focus | Problems |
|------|-------|----------|
| 1 | Basics + XOR | 1–6 (MUST-DO 1–4, 9) |
| 2 | XOR variants + Subsets | 7–13 (MUST-DO 5–7) |
| 3 | Bitmask DP intro | 14–20, 21–22 |
| 4 | Bitmask DP advanced | 23–30 (MUST-DO 10) |

---

## By Pattern

| Pattern | Problems |
|---------|----------|
| Popcount | 191, 338, 461, 477 |
| Power of 2 | 231, 342 |
| XOR | 136, 268, 137, 260, 1720, 1310 |
| Bitmask | 78, 698, 464, 847, 2172, 1125, 691, 1178, 1601, 943, 1349 |
| Trie/XOR | 421 |
| Misc | 190, 1009, 693, 201, 1318 |

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  MUST-DO: 191, 231, 136, 268, 137, 260, 78,     │
│           421, 338, 847                          │
│  XOR: 136, 268, 137, 260  |  Bitmask: 78, 847   │
│  Popcount: 191, 338  |  Power of 2: 231         │
│  Week 1: basics   Week 2: XOR+subsets           │
│  Week 3-4: Bitmask DP                            │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] MUST-DO: 191, 231, 136, 268, 137, 260, 78, 421, 338, 847
- [ ] XOR: 136, 268, 137, 260
- [ ] Bitmask DP: 847, 698, 2172, 1125
- [ ] Week 1: basics; Week 2: XOR+subsets; Week 3–4: Bitmask DP
