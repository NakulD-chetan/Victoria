# Skipped Stages & Shuffle Output Reuse — Problem List

> **15 reuse-prediction tasks.** Goal: predict for each pair of consecutive actions which stages will be skipped in the second job. Then verify in Spark UI.

---

## 8 MUST-DO Tasks

| # | Scenario                                                           | Reuse Prediction                                                     | Concept                       |
|---|--------------------------------------------------------------------|----------------------------------------------------------------------|-------------------------------|
| 1 | `df.cache(); df.count(); df.count()` (2nd time)                    | All upstream stages skipped; only final reduce runs                  | Cache reuse                   |
| 2 | `df.groupBy("k").count(); df.groupBy("k").count()` (2nd time)      | Map-side stages skipped because shuffle output on disk                | Implicit shuffle reuse        |
| 3 | `df.cache(); df.count(); df.unpersist(); df.count()`               | Second count: NO skip (cache invalidated)                             | Unpersist behavior            |
| 4 | `df_filtered.cache(); df_filtered.count(); df_final.show()`        | Show jobs: most upstream skipped                                      | Reference run                 |
| 5 | `df.show(); df.show()` (no cache)                                   | Second show: many skipped due to shuffle reuse                        | Shuffle reuse without cache   |
| 6 | First `count()` on a freshly-built df                                | Zero skipped (nothing to reuse)                                       | Baseline                      |
| 7 | `df.collect()` after `df.show()`                                    | Many upstream skipped, leaf re-executed                               | Why collect re-does 14 tasks  |
| 8 | `df.cache(); action1(); action2(); action3()`                        | action 2 and 3: all upstream skipped (cache + shuffle reuse stack)    | Best-case reuse                |

---

## Complete 15-Task Progression

### Easy (1–6) — First-Action vs Second-Action

| # | Setup                                              | Job 2 Skipped Tasks                | Reasoning                                  |
|---|---------------------------------------------------|------------------------------------|--------------------------------------------|
| 1 | `df.count()` then `df.count()` (no cache)          | All upstream tasks skipped         | Spark reuses shuffle output for `count`    |
| 2 | `df.cache(); df.count(); df.count()`               | All except final reduce            | Cache + shuffle reuse stacked              |
| 3 | `df.count()` then `df.collect()`                   | Upstream skipped                   | Same lineage, different action             |
| 4 | `df.write.parquet(p)` then `df.count()`            | Some upstream skipped              | Write doesn't always shuffle, but reads do |
| 5 | `df.show()` then `df.show()` (no cache)            | Many skipped                       | Each iteration of executeTake reuses shuffle from previous |
| 6 | First action ever on `df`                           | 0 skipped                          | Nothing to reuse                           |

### Medium (7–11) — Shuffle Reuse Without Cache

| # | Setup                                                                              | Skipped Pattern                            | Notes                                                  |
|---|------------------------------------------------------------------------------------|---------------------------------------------|--------------------------------------------------------|
| 7 | `df.groupBy("k").sum("v").count()` then `.collect()`                                 | Map stage skipped                           | Shuffle output for groupBy reused                      |
| 8 | `df.join(df2, "k").count()` then `.show()`                                          | Both join input stages skipped              | Shuffle output of join children reused                 |
| 9 | `df.repartition(8); df.count()` then `df.collect()`                                  | Repartition shuffle skipped                 | Shuffle output reused                                  |
|10 | `df.distinct(); df.count()` then `.collect()`                                        | distinct shuffle skipped                    | Implicit cache on shuffle                              |
|11 | `df.show()` (sparse → 3 jobs) — observe skipped on iter 2/3                         | iter 2 / 3 have many skipped tasks          | Reference run mechanics                                |

### Hard (12–15) — Mixed Cache + Shuffle + Unpersist

| # | Setup                                                                                                   | Skipped Pattern                          | Notes                                                                  |
|---|---------------------------------------------------------------------------------------------------------|------------------------------------------|------------------------------------------------------------------------|
|12 | `df.cache(); df.count(); df.unpersist(); df.count()`                                                    | 2nd count: 0 skipped                     | Unpersist destroys reuse                                               |
|13 | `df.cache(); df.count(); spark.catalog.clearCache(); df.count()`                                        | 2nd count: 0 skipped                     | Catalog-wide clear                                                     |
|14 | `df.cache(); df.count();` (kill executor) `df.count()`                                                   | 2nd count: partial skipped               | Lost partitions are recomputed; rest reused                            |
|15 | `df.checkpoint(); df.count(); df.collect()`                                                              | 2nd action: full reuse via checkpoint    | Checkpoint files persist on FS; great for retries                      |

---

## Strategy Notes

### Task 1 — Implicit Shuffle Reuse

```
Step 1: First df.count() — full pipeline, all stages run.
        - Stage 0: 16 tasks (scan + map + shuffle write)
        - Stage 1:  6 tasks (post-shuffle aggregate)
        - Stage 2:  1 task  (final reduce)

Step 2: Second df.count() — Stage 0 and Stage 1 outputs already on local disk.
        UI shows:
          Job 1: stages 2/2 (1 skipped), tasks 1 / 23 (22 skipped)
        Even without explicit cache, shuffle reuse delivers near-zero second-job time.
```

### Task 5 — Two Shows in a Row

```
First show:   3 jobs (iter 1, 2, 3) -- builds up shuffle output across all 8 partitions
Second show:  may be only 1-2 jobs because:
    - shuffle output exists for the first iter
    - executeTake fills buffer faster (caches help row count too)
```

### Task 9 — Repartition Shuffle Reuse

```python
df = df.repartition(8)
df.count()      # Job A: scans + repartition shuffle write + final agg
df.collect()    # Job B: skipped repartition map stage; only post-shuffle work runs
```

UI: Job B shows `(N skipped)` with N = original input partition count.

### Task 12 — Unpersist Wipes Reuse

```
df.cache()
df.count()       # materializes cache (all stages run)
df.unpersist()   # invalidates cache
df.count()       # Spark falls back to recomputing — could rebuild from
                 # shuffle output if still on disk, or re-scan from source
```

> Unpersist clears the *cache* but doesn't kill *shuffle blocks*. So you may still see partial skipped if shuffle output survives.

### Task 14 — Executor Loss

```
Symptom:    After an executor dies, you see far fewer "skipped" in next job.
Why:        Shuffle blocks on that executor are gone; tasks for those
            partitions must be recomputed.
Fix:        Use external shuffle service for resilience, or checkpoint().
```

---

## How to Distinguish Cache vs Shuffle Reuse — Quick Test

```python
# Run action 1
df.count()

# Open UI:
# - Storage tab populated?       -> cache reuse will help
# - Storage tab empty?            -> only shuffle reuse possible

# Run action 2
df.count()

# Open UI:
# - Job 2 description: stage's input is "InMemoryTableScan"  -> cache hit
# - Job 2 description: stage's input is "Exchange" with empty bar -> shuffle reuse
```

---

## Cheat Decision Tree

```
You see "(N skipped)" in Jobs tab.
   |
   +--> Storage tab has entries?
   |       +--> Cache is part of the reuse.
   |
   +--> SQL tab plan shows ReusedExchange?
   |       +--> Shuffle output reuse.
   |
   +--> Both?
   |       +--> Both contributing.
   |
   +--> Neither, but tasks still fast?
            +--> Look at the skipped count: maybe AQE bookkeeping job.
```

---

## Common "Why is this slow now?" Diagnoses

| Symptom                                                   | Likely Cause                                                |
|-----------------------------------------------------------|--------------------------------------------------------------|
| Pipeline gets slower over time within same app             | Cache eviction or shuffle GC                                |
| Pipeline fast when run twice in same notebook              | Shuffle reuse benefit                                       |
| Same code 10x slower in production vs notebook             | Notebook had warm cache/shuffle; production starts cold     |
| Restart of app makes everything slow                        | All shuffle and cache lost                                  |
| One executor's tasks 100x slower than others                | Cache/shuffle on that exec was lost; recomputing            |

---

## Cross-Reference

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| Why `df.show()` benefits so much from reuse        | 03      |
| Reading skipped count in Jobs tab                   | 02      |
| `ReusedExchange` operator in plan                   | 06      |
| Cache state in Storage tab                          | 07      |

---

## Study Plan

### Day 1 — Cold vs Warm
- Tasks 1, 2, 5, 6.
- Run a `count + count` pair both with and without cache; compare UI.

### Day 2 — Reference Run Drill-In
- Task 4 / Task 11.
- Replicate exactly the 5-job script; click each job and trace skipped counts.

### Day 3 — Unpersist Behavior
- Tasks 12–14.
- Force eviction by calling `unpersist()` between actions; observe.

### Day 4 — Checkpoint vs Cache
- Task 15. Build a small ETL with checkpoint; restart driver; verify reuse.

---

## Final Revision Box

```
SKIPPED        =  reused, NOT failed
SOURCES        =  (1) shuffle output on local disk
                  (2) cached partitions in memory/disk
WHEN APPEARS   =  any job sharing lineage with a prior job in the same app
HOW TO TELL    =  Storage tab non-empty -> cache reuse
                  ReusedExchange in SQL tab -> shuffle reuse
WHEN VANISHES  =  unpersist(), executor loss, cleaner GC, app restart
PRACTICAL HINT =  For multi-action workflows, cache once; observe Storage tab
                  filling; remaining actions get many "(N skipped)".
RULE           =  "Read 'X / Y (Z skipped)' as 'X did real work, Z reused'."
```
