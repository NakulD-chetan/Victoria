export const LANGUAGES = [
  { id: 'cpp', label: 'C++ 17 (GCC)', monacoLang: 'cpp', icon: 'C++', color: '#00599C' },
  { id: 'python', label: 'Python 3.12', monacoLang: 'python', icon: 'Py', color: '#3776AB' },
  { id: 'java', label: 'Java (OpenJDK)', monacoLang: 'java', icon: 'Jv', color: '#ED8B00' },
  { id: 'javascript', label: 'JavaScript (Node.js)', monacoLang: 'javascript', icon: 'JS', color: '#F7DF1E' },
];

export const CODE_TEMPLATES = {
  cpp: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
`,
  python: `def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()
`,
  java: `import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
`,
  javascript: `function main() {
    console.log("Hello, World!");
}

main();
`,
};

export const STATUS_MAP = {
  1: { label: 'In Queue', type: 'pending', icon: '...' },
  2: { label: 'Processing', type: 'pending', icon: '...' },
  3: { label: 'Accepted', type: 'success', icon: 'ok' },
  4: { label: 'Wrong Answer', type: 'error', icon: 'x' },
  5: { label: 'Time Limit Exceeded', type: 'warning', icon: '!' },
  6: { label: 'Compilation Error', type: 'error', icon: 'CE' },
  7: { label: 'Runtime Error (SIGSEGV)', type: 'error', icon: 'RE' },
  8: { label: 'Runtime Error (SIGXFSZ)', type: 'error', icon: 'RE' },
  9: { label: 'Runtime Error (SIGFPE)', type: 'error', icon: 'RE' },
  10: { label: 'Runtime Error (SIGABRT)', type: 'error', icon: 'RE' },
  11: { label: 'Runtime Error (NZEC)', type: 'error', icon: 'RE' },
  12: { label: 'Runtime Error (Other)', type: 'error', icon: 'RE' },
  13: { label: 'Internal Error', type: 'error', icon: 'IE' },
  14: { label: 'Exec Format Error', type: 'error', icon: 'EF' },
};

export function getStatusInfo(status) {
  if (!status) return { label: 'Unknown', type: 'pending', icon: '?' };
  return STATUS_MAP[status.id] || { label: status.description || 'Unknown', type: 'pending', icon: '?' };
}

export async function executeCode(sourceCode, language, stdin) {
  const res = await fetch('/api/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      source_code: sourceCode,
      language,
      stdin: stdin || '',
    }),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Execution failed');
  return data;
}
