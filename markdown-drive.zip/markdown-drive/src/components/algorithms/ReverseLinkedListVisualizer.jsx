import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const ReverseLLCanvas = forwardRef(function ReverseLLCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ values: [], next: [], revHead: null, cur: null, prev: null, phase: '' });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 280;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { values, next, revHead, cur, prev, phase } = stateRef.current;
      const n = values.length;
      if (!n) {
        raf = requestAnimationFrame(draw);
        return;
      }
      const gap = 70;
      const startX = 40;
      const y = 120;
      const pos = {};
      for (let i = 0; i < n; i++) {
        pos[i] = { x: startX + i * gap, y };
      }
      for (let i = 0; i < n; i++) {
        const t = next[i];
        if (t == null) continue;
        const a = pos[i];
        const b = pos[t];
        ctx.beginPath();
        ctx.moveTo(a.x + 26, a.y);
        ctx.lineTo(b.x - 26, b.y);
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      for (let i = 0; i < n; i++) {
        const { x, y: yy } = pos[i];
        const hl = i === cur ? '#ffd43b' : i === prev ? '#74c0fc' : i === revHead ? '#b2f2bb' : '#e0e7ff';
        ctx.fillStyle = hl;
        ctx.strokeStyle = '#1c1917';
        ctx.beginPath();
        ctx.roundRect(x - 26, yy - 18, 52, 36, 8);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1c1917';
        ctx.font = 'bold 13px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(values[i]), x, yy);
      }
      if (phase) {
        ctx.fillStyle = '#44403c';
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(phase, W / 2, 28);
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function buildForward(vals) {
  const next = vals.map((_, i) => (i + 1 < vals.length ? i + 1 : null));
  return next;
}

function generateSteps(vals) {
  const next = buildForward(vals);
  const steps = [];
  steps.push({
    type: 'init',
    values: [...vals],
    next: [...next],
    revHead: null,
    cur: 0,
    prev: null,
    phase: 'prev=null, cur=head',
  });
  let cur = 0;
  let prev = null;
  while (cur != null) {
    const nx = next[cur];
    steps.push({
      type: 'reverse-edge',
      values: [...vals],
      next: [...next],
      revHead: prev,
      cur,
      prev,
      phase: `Reverse ${prev ?? 'null'} ← ${cur}`,
    });
    next[cur] = prev;
    prev = cur;
    cur = nx;
    steps.push({
      type: 'advance',
      values: [...vals],
      next: [...next],
      revHead: prev,
      cur,
      prev,
      phase: 'Move prev/cur',
    });
  }
  steps.push({
    type: 'done',
    values: [...vals],
    next: [...next],
    revHead: prev,
    cur: null,
    prev,
    phase: '✓ New head',
  });
  return steps;
}

export default function ReverseLinkedListVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const vals = [3, 7, 9, 12, 5];
    const steps = generateSteps(vals);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Iterative reversal' });
    canvasRef.current?.setState({ ...steps[0] });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.phase || step.type });
    canvasRef.current?.setState({ ...step });
  }, []);

  return <AlgoVisualizer config={config} canvas={ReverseLLCanvas} onInit={onInit} onStep={onStep} />;
}
