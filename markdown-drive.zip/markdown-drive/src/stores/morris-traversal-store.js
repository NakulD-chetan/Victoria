import { create } from 'zustand';

export const useMorrisStore = create((set) => ({
  treeIdx: 0,
  autoActive: false,
  autoRate: 2,
  speed: 1,
  currentLang: 'python',
  currentStep: null,
  totalSteps: 0,
  logs: [],
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setTreeIdx: (v) => set({ treeIdx: v }),
  setAutoRate: (v) => set({ autoRate: v }),
  setSpeed: (v) => set({ speed: v }),
  toggleAuto: () => set((s) => ({ autoActive: !s.autoActive })),
  setLang: (lang) => set({ currentLang: lang }),
  setStep: (step) => set({ currentStep: step }),
  recordStep: () => set((s) => ({ totalSteps: s.totalSteps + 1 })),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),
  reset: () => set({
    totalSteps: 0, currentStep: null, logs: [],
    autoActive: false, startTime: performance.now(),
  }),
}));
