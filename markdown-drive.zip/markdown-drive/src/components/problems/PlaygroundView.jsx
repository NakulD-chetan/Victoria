import { useRef, useEffect, useCallback, useState } from 'react';
import { usePlaygroundStore } from '../../stores/playground-store';
import { useProblemSessionStore } from '../../stores/problem-session-store';
import { getProblemById } from '../../lib/problems/registry';
import { PROBLEMS } from '../../lib/problems/problems-data';
import { SkeletonSystemDesignPlayground } from '../shared/Skeleton';
import QuestionPanel from './QuestionPanel';
import ComponentSidebar from './ComponentSidebar';
import DesignCanvas from './DesignCanvas';
import TestPanel from './TestPanel';
import ConfigPanel from './ConfigPanel';
import SimToolbar from './SimToolbar';
import ChaosToolbar from './ChaosToolbar';
import ScoreCard from './ScoreCard';

export default function PlaygroundView({ problemId }) {
  const canvasRef = useRef(null);
  const loadTimerRef = useRef(null);
  const frameRef = useRef(null);
  const resetAll = usePlaygroundStore((s) => s.resetAll);
  const resetSession = useProblemSessionStore((s) => s.resetSession);
  const [loading, setLoading] = useState(true);
  const problem = getProblemById(problemId) || PROBLEMS[0];

  useEffect(() => {
    resetAll();
    resetSession();

    setLoading(true);
    frameRef.current = requestAnimationFrame(() => {
      loadTimerRef.current = window.setTimeout(() => {
        setLoading(false);
      }, 220);
    });

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      if (loadTimerRef.current) clearTimeout(loadTimerRef.current);
    };
  }, [problemId, resetAll, resetSession]);

  const handleProblemChange = useCallback((id) => {
    window.history.pushState(null, '', `/systemdesign/${id}`);
    window.dispatchEvent(new PopStateEvent('popstate'));
  }, []);

  if (loading) {
    return <SkeletonSystemDesignPlayground />;
  }

  return (
    <div className="dc-playground">
      <QuestionPanel problem={problem} onProblemChange={handleProblemChange} />
      <div className="dc-playground__center">
        <div className="dc-top-bar">
          <ChaosToolbar problem={problem} />
          <SimToolbar />
        </div>
        <ConfigPanel />
        <DesignCanvas ref={canvasRef} />
        <TestPanel problem={problem} />
      </div>
      <ComponentSidebar canvasRef={canvasRef} />
      <ScoreCard problem={problem} />
    </div>
  );
}
