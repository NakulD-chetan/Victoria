# How Twitter Timeline Works - In Depth (Easy Language)

> Companion to: [14-How-Twitter-Timeline-Works.md](14-How-Twitter-Timeline-Works.md)

---

## The Fan-Out Problem - THE Core Challenge

When you post a tweet, how does it reach all your followers? This is called the **fan-out problem**.

---

## Two Approaches (Both Have Problems)

### Approach 1: Fan-Out on Read (Pull Model)

```
Elon Musk tweets: "I love X"

Nothing happens immediately. Tweet just gets stored in DB.

When Follower A opens Twitter:
  1. "Who do I follow?" → [Elon, Taylor, Obama, ... 500 people]
  2. "Get latest tweets from all 500" → 500 database queries!
  3. Merge all results, sort by time
  4. Return top 50 tweets
  
Time: 200-500ms per user (lots of DB queries)
```

**Pros**: Writing is cheap (just store one tweet)
**Cons**: Reading is expensive (every user opening Twitter triggers hundreds of queries)

### Approach 2: Fan-Out on Write (Push Model)

```
You tweet: "Hello World!"
You have 500 followers.

Immediately:
  Push "Hello World!" into Follower A's timeline cache
  Push "Hello World!" into Follower B's timeline cache
  Push "Hello World!" into Follower C's timeline cache
  ... (500 pushes)
  
When Follower A opens Twitter:
  1. Read Follower A's pre-built timeline cache
  2. Done! No merging, no sorting needed.
  
Time: ~5ms per user (just read from cache)
```

**Pros**: Reading is instant (timeline is pre-built!)
**Cons**: Writing is expensive. If Elon Musk tweets and has 200 million followers... 200 MILLION cache writes for ONE tweet!

### The Problem with Pure Push

```
Elon Musk tweets: 200 million followers
  → 200,000,000 cache writes
  → At 100K writes/sec: takes 33 MINUTES to deliver one tweet!
  → By then, Elon has tweeted 5 more times
  → System can never catch up!
```

---

## Twitter's Solution: Hybrid Fan-Out

### The Clever Compromise

```
Normal users (< ~5,000 followers):
  → FAN-OUT ON WRITE (push model)
  → When you tweet, push to all 500 followers' caches
  → Their timelines are always up-to-date

Celebrities (millions of followers):
  → FAN-OUT ON READ (pull model)
  → When they tweet, just store in DB
  → When you open Twitter, their tweets are MERGED in real-time

When you open Twitter:
  1. Read your pre-built timeline cache (has all normal-user tweets)
  2. Query celebrity tweets (from the few celebrities you follow)
  3. Merge celebrity tweets into your timeline
  4. Return the combined feed
```

```
Your timeline = pre-computed cache + live merge of celebrity tweets

Pre-computed (instant):          Live merge (a few queries):
  Friend A's tweet               Elon's latest tweet
  Friend B's tweet         +     Taylor's latest tweet
  Colleague's tweet               Obama's latest tweet
  Family member's tweet           
```

**Why this works**: Most people follow ~500 accounts, of which maybe 5-10 are celebrities. The expensive pull query only happens for those 5-10 accounts, not all 500.

---

## Frontend Architecture - The Other Half

Twitter isn't just about the backend. The frontend (what you see) has its own challenges.

### DOM Virtualization - Rendering 10,000 Tweets

```
Problem:
  You scroll through 1,000 tweets.
  If all 1,000 are in the DOM (HTML), the browser:
    → Uses tons of memory (each tweet = images, text, buttons)
    → Scrolling becomes janky (browser can't render 1,000 complex elements smoothly)

Solution: DOM Virtualization
  Only render tweets VISIBLE on screen (~10 at a time)
  
  ┌────────────────────┐
  │ (not rendered)     │ ← above viewport
  │ (not rendered)     │
  ├────────────────────┤ ← top of screen
  │ Tweet 45           │ ← RENDERED
  │ Tweet 46           │ ← RENDERED
  │ Tweet 47           │ ← RENDERED (visible to user)
  │ Tweet 48           │ ← RENDERED
  │ Tweet 49           │ ← RENDERED
  ├────────────────────┤ ← bottom of screen
  │ (not rendered)     │ ← below viewport
  │ (not rendered)     │
  └────────────────────┘

  As you scroll DOWN:
    → Tweet 45 exits viewport → REMOVED from DOM
    → Tweet 50 enters viewport → ADDED to DOM
    → Always ~10 elements in DOM, regardless of total tweets
```

**Result**: Smooth scrolling even with 10,000+ tweets loaded. Memory stays constant.

### Lazy Loading Media

```
Without lazy loading:
  Page loads → browser downloads ALL 100 visible and invisible tweet images
  → Massive bandwidth, slow initial load

With lazy loading:
  Page loads → browser only downloads images for tweets IN the viewport
  As you scroll → new images load just before entering viewport
  → Fast initial load, bandwidth-efficient
```

### Infinite Scroll with Cursor-Based Pagination

```
You scroll to the bottom of loaded tweets:
  App: GET /timeline?next_cursor=tweet_789_timestamp_1705312800
  Server: returns next 25 tweets + new cursor
  App: appends to feed, keeps scrolling

Why cursor (not page number)?
  → New tweets constantly appearing
  → Page 2 might show different content than 5 seconds ago
  → Cursor points to a fixed position: "everything after this tweet"
```

---

## Optimistic Updates - The Instant Feel

### What Happens When You Like a Tweet?

```
Traditional approach:
  1. Tap ❤️
  2. Send API: POST /tweets/123/like
  3. Wait for server response... (200ms-500ms)
  4. Server: "200 OK"
  5. UI updates: heart turns red, count +1
  
  User feels: "Hmm, slight delay after tapping like"

Optimistic approach:
  1. Tap ❤️
  2. UI IMMEDIATELY updates: heart turns red, count +1 (before server responds!)
  3. Send API: POST /tweets/123/like (in background)
  4. Server: "200 OK" → great, nothing to do
  
  If server returns error:
  5. ROLLBACK: heart turns back to gray, count -1
  6. Show error message: "Couldn't like this tweet"
  
  User feels: "Wow, that was instant!"
```

**Why this works**: 99.9% of the time, the like succeeds. By updating the UI immediately, the app feels lightning-fast. The rare failure case (0.1%) is handled with a rollback.

This pattern is used for: likes, retweets, bookmarks, follows -- any quick action.

---

## Real-Time Updates - New Tweets While Reading

### The Challenge

```
You're reading your timeline.
20 new tweets arrive in the next minute.

BAD approach: Auto-scroll to show new tweets
  → User is reading tweet X → suddenly tweet X disappears as feed shifts
  → Extremely annoying! Disrupts reading flow.

GOOD approach: "X new tweets" banner
  → "15 new tweets" banner appears at top
  → User taps it when THEY'RE ready to see new content
  → Feed updates smoothly
```

### How New Tweets Arrive

```
Option A: Polling (simple)
  Every 30-60 seconds: GET /timeline/updates?since=latest_tweet_id
  If new tweets: show "X new tweets" banner
  
Option B: WebSocket/SSE (efficient)
  Persistent connection to server
  Server pushes: "3 new tweets for your timeline"
  Show banner immediately
  
Twitter uses polling for the web app (simpler, good enough)
and push for the mobile app (better battery/bandwidth)
```

---

## The Complete Flow

### Tweet Creation
```
1. User types tweet → POST /tweets { text: "Hello!" }
2. Tweet stored in database
3. Fan-out service triggered:
   → For each follower (< 5K followers):
     Push tweet ID to their timeline cache (Redis)
   → For celebrity (> 5K followers):
     Skip fan-out (will be merged at read time)
4. Return 201 Created to user
```

### Timeline Read
```
1. User opens Twitter → GET /timeline?cursor=abc
2. Timeline service:
   → Read pre-built timeline from cache (post IDs from push model)
   → Query latest tweets from followed celebrities (pull model)
   → Merge both, sort by timestamp
   → Return top 25 tweets with next_cursor
3. Client renders with virtualized list
4. Start polling for new tweets
```

---

## Revision Flashcards

**Q: What is the fan-out problem?**
A: When a user tweets, how do you deliver it to all followers? Push to each follower's cache (expensive for celebrities) or pull at read time (expensive for the reader). Neither approach works alone.

**Q: How does Twitter's hybrid fan-out work?**
A: Normal users (< ~5K followers): push tweets to followers' caches at write time. Celebrities (millions of followers): store tweet in DB, merge into followers' timelines at read time.

**Q: What is DOM virtualization?**
A: Only render the ~10 tweets visible on screen in the DOM. As user scrolls, old tweets are removed and new ones are added. Keeps memory constant regardless of total tweets loaded.

**Q: What are optimistic updates?**
A: Update the UI immediately (before server confirms). If the server returns an error, roll back the UI change. Makes interactions feel instant. Used for likes, retweets, bookmarks.

**Q: Why does Twitter show "X new tweets" instead of auto-scrolling?**
A: Auto-scrolling disrupts the user's reading flow. The banner lets users choose when to see new content, providing a better experience.
