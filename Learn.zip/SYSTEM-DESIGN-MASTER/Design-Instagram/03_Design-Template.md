# Design Instagram — Design Template

> **Permanent Recall:** Architecture = **Upload Pipeline** (S3 + async processing) + **Feed Generation** (fan-out + Redis) + **CDN** for media delivery. Never store images in DB; always use **object storage** + **CDN**.

---

## High-Level Architecture (ASCII)

```
                    ┌──────────┐
                    │  Client  │
                    └────┬─────┘
                         │
                    ┌────▼─────┐
                    │    LB    │
                    └────┬─────┘
           ┌─────────────┼─────────────┐
           │             │             │
    ┌──────▼──────┐ ┌────▼────┐ ┌─────▼──────┐
    │   Upload    │ │   Feed   │ │  Explore   │
    │   Service   │ │  Service │ │  Service   │
    └──────┬──────┘ └────┬────┘ └─────┬──────┘
           │             │             │
    ┌──────▼──────┐      │      ┌──────▼──────┐
    │     S3      │      │      │ Recommender │
    └──────┬──────┘      │      └─────────────┘
           │             │
    ┌──────▼──────┐ ┌────▼────┐
    │   Image     │ │  Redis   │
    │  Processor  │ │ Timeline │
    └──────┬──────┘ └────┬────┘
           │             │
    ┌──────▼──────┐ ┌────▼────┐
    │    CDN      │ │  MySQL  │
    └─────────────┘ └─────────┘
```

---

## API Design

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/upload` | Upload photo/video; returns `media_id` |
| GET | `/feed` | Get news feed (paginated) |
| GET | `/explore` | Get explore/discover content |
| POST | `/follow` | Follow user |
| POST | `/like` | Like post |
| POST | `/comment` | Add comment |
| GET | `/stories` | Get stories from followed users |
| POST | `/stories` | Upload story (24h TTL) |

---

## Upload Pipeline

```
Client ─► LB ─► Upload Service ─► S3 (raw)
                                      │
                                      ▼
                            Image Processing (async)
                            • Resize (thumbnail, medium, full)
                            • Apply filter
                            • Compress
                                      │
                                      ▼
                            Write metadata to DB
                            Store URLs in CDN
```

> **FAANG Tip:** Upload returns immediately after S3 write; processing is **async** (queue + workers).

---

## Feed Generation

- **Fan-out on write** (like Twitter): When user posts, push to followers' Redis timelines
- **Redis** stores `user_id → sorted set` of `(post_id, timestamp)`
- On feed request: read from Redis, fetch metadata from DB/cache, **resolve media URLs** (CDN)
- **Hybrid**: Fan-out for normal users; **pull** for celebrities (avoid writing to millions of timelines)

---

## Data Model

| Table | Key Fields |
|-------|------------|
| **users** | id, username, profile_pic_url, created_at |
| **photos** | id, user_id, s3_key, thumbnail_url, medium_url, full_url, created_at |
| **follows** | follower_id, followee_id |
| **likes** | user_id, photo_id |
| **comments** | id, photo_id, user_id, text, created_at |
| **stories** | id, user_id, media_url, expires_at |

---

## Media Storage Strategy

| Resolution | Size | Use Case |
|------------|------|----------|
| Thumbnail | 150×150 | Feed grid, previews |
| Medium | 640×640 | Feed scroll |
| Full | 1080×1080+ | Tap to view |

- **S3** as origin; **CloudFront / CDN** for delivery
- URLs in DB point to CDN, not S3 directly

---

## Explore Feature

- **Collaborative filtering**: Users who liked X also liked Y
- **Content-based**: Similar hashtags, visual features
- **Trending**: Time-weighted engagement (likes, comments, shares)
- Pre-compute explore feed per user; refresh periodically

---

## Mermaid: Upload Flow

```mermaid
flowchart LR
    A[Client] --> B[Upload API]
    B --> C[S3]
    C --> D[Queue]
    D --> E[Processor]
    E --> F[Resize/Filter]
    F --> G[DB + CDN]
```

---

## Sharding Strategy

- **Users:** Shard by `user_id % N` (e.g., 1000 shards)
- **Photos:** Shard by `photo_id` (snowflake or similar)
- **Follows:** Shard by `follower_id` (fan-out reads)
- **Likes:** Shard by `photo_id` (avoid hot key — spread load)

---

## Caching Layers

| Layer | What | TTL |
|-------|------|-----|
| **CDN** | Media (thumb, medium, full) | Days (immutable) |
| **Redis** | User timeline (post IDs) | Minutes |
| **Redis** | User metadata, photo metadata | Minutes |
| **DB** | Source of truth | N/A |
