import { supabase } from '../lib/supabase';

/*
 * subscribeToVault — opens one realtime channel for the given vault
 * and forwards row-level changes to the supplied handlers. Returns
 * an unsubscribe function.
 *
 * Usage in a Zustand store:
 *
 *   useEffect(() => {
 *     const off = subscribeToVault(activeVaultId, {
 *       onFolderChange: (payload) => useNotesStore.getState().applyFolderEvent(payload),
 *       onNoteChange:   (payload) => useNotesStore.getState().applyNoteEvent(payload),
 *       onMemberChange: (payload) => useVaultStore.getState().applyMemberEvent(payload),
 *     });
 *     return off;
 *   }, [activeVaultId]);
 */
export function subscribeToVault(
  vaultId,
  { onFolderChange, onNoteChange, onMemberChange, onInviteChange, onAclChange } = {},
) {
  if (!vaultId) return () => {};

  const channel = supabase.channel(`vault:${vaultId}`);

  if (onFolderChange) {
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'folders', filter: `vault_id=eq.${vaultId}` },
      onFolderChange,
    );
  }
  if (onNoteChange) {
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'notes', filter: `vault_id=eq.${vaultId}` },
      onNoteChange,
    );
  }
  if (onMemberChange) {
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'vault_members', filter: `vault_id=eq.${vaultId}` },
      onMemberChange,
    );
  }
  if (onInviteChange) {
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'vault_invites', filter: `vault_id=eq.${vaultId}` },
      onInviteChange,
    );
  }
  if (onAclChange) {
    /* No vault_id column on resource_acl; we filter in the handler. */
    channel.on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'resource_acl' },
      onAclChange,
    );
  }

  channel.subscribe();
  return () => {
    try { supabase.removeChannel(channel); } catch { /* ignore */ }
  };
}
