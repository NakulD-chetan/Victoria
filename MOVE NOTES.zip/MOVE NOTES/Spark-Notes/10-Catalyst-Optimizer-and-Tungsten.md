# Catalyst Optimizer and Tungsten Engine

These are the two engines that make Spark SQL fast. **Catalyst** optimizes your query plan. **Tungsten** optimizes the execution at CPU and memory level.

---

## Part 1: Catalyst Optimizer

Catalyst is Spark SQL's **query optimization framework**. It takes your code, understands it, optimizes it, and picks the best execution strategy.

### The 4 Phases of Catalyst

```
Your Code
    |
    v
[1. Analysis]         → Resolve column names, types, table references
    |
    v
[2. Logical Optimization] → Apply rules to make the plan better
    |
    v
[3. Physical Planning]    → Choose the best execution strategy
    |
    v
[4. Code Generation]     → Generate optimized JVM bytecode (Tungsten)
    |
    v
Execution on Cluster
```

---

### Phase 1: Analysis (Resolve the Plan)

When you write:
```python
df = spark.read.csv("people.csv", header=True)
df2 = df.filter("age > 30").select("name", "city")
```

Spark first creates an **Unresolved Logical Plan**:
```
Project [name, city]
  Filter (UnresolvedAttribute "age" > 30)
    Relation people.csv (schema unknown)
```

Nothing is validated yet — Spark doesn't even know if "age" exists.

**Catalyst Analysis** then:
- Reads the file schema (column names and types)
- Validates that columns exist
- Assigns data types
- Resolves function names
- Expands `*` into actual column list

If something is wrong (e.g., column "age" doesn't exist), you get an **AnalysisException**.

**After Analysis → Resolved Logical Plan:**
```
Project [name:string, city:string]
  Filter (age:int > 30)
    Relation people.csv [name:string, age:int, city:string]
```

---

### Phase 2: Logical Optimization (Apply Rules)

Catalyst applies **dozens of optimization rules** to rewrite the plan into a better version. Think of it as Spark being smarter than you about SQL.

#### Key Optimizations:

**Predicate Pushdown** — Push filters closer to the data source
```
Before: Read ALL data → then filter age > 30
After:  Read ONLY rows where age > 30 (at source level)
```

**Column Pruning** — Read only columns you actually use
```
Before: Read all 50 columns → select 2
After:  Read only 2 columns from the file
```

**Constant Folding** — Evaluate constant math at compile time
```
Before: salary > (20000 + 30000)
After:  salary > 50000
```

**Boolean Simplification**
```
Before: (age > 30 AND TRUE)
After:  age > 30
```

**Null Propagation**
```
Before: age + NULL
After:  NULL (skip computation)
```

**Join Reordering** — Join smallest tables first to minimize shuffle
```
Before: A JOIN B JOIN C  (B is small)
After:  (A JOIN C) JOIN B  (minimizes data movement)
```

**Combine Nested Projections** — Merge redundant selects
```
Before: select(name, city) → select(name, age, city)
After:  select(name, city)
```

---

### Phase 3: Physical Planning

Catalyst generates **multiple physical plans** and picks the cheapest one.

For a join, it considers:
- Sort-Merge Join (for large-large tables)
- Broadcast Hash Join (if one table is small)
- Shuffle Hash Join (medium table + large table)

It estimates:
- Shuffle cost
- Memory cost
- Join cardinality
- Data size statistics

Then picks the plan with the lowest cost.

---

### Phase 4: Code Generation (Tungsten)

The optimized physical plan is handed to Tungsten for **Whole-Stage Code Generation**.

---

## Part 2: Tungsten Engine

Tungsten is Spark's **low-level performance engine** that optimizes how data is stored and processed at the CPU level.

### What Tungsten Does

#### 1. Off-Heap Memory Management

Instead of storing data as Java objects (which have huge overhead due to object headers, pointers, etc.), Tungsten uses:

- **UnsafeRow** — a compact binary row format stored off-heap
- No Java object overhead
- No garbage collection pressure
- Direct memory access (like C/C++)

**Why Java objects are wasteful:**
```
A simple string "hello" in Java:
  - Object header:     16 bytes
  - Hash code:          4 bytes
  - Array pointer:      8 bytes
  - Char array header: 16 bytes
  - Actual data:       10 bytes (5 chars × 2 bytes)
  Total:              ~54 bytes for 5 characters!

UnsafeRow stores just the bytes: ~7 bytes
```

#### 2. Whole-Stage Code Generation (Codegen)

Instead of executing each operation (filter, project, aggregate) as a separate function call, Tungsten **fuses them into a single compiled function**.

**Before codegen** (volcano model):
```
for each row:
    call filter()        ← function call overhead
    call project()       ← function call overhead
    call aggregate()     ← function call overhead
```

**After codegen**:
```
for each row:
    // All operations inlined in one tight loop
    if (row.age > 30) {          // filter
        name = row.getString(0)  // project
        count[city] += 1         // aggregate
    }
```

This eliminates:
- Virtual function call overhead
- Object boxing/unboxing
- Unnecessary memory allocation

You can see codegen in your Spark physical plan — look for `*(1)` or `WholeStageCodegen`:
```
*(2) HashAggregate(keys=[city], functions=[count(1)])
+- *(2) Project[name, city]
   +- *(1) Filter(age > 30)
      +- FileScan parquet [age, city, name]
```

#### 3. Cache-Aware Computation

Tungsten organizes data to maximize CPU cache hits:
- Data is stored in contiguous memory blocks
- Access patterns are sequential (cache-friendly)
- Avoids random memory access (cache misses)

---

## How Catalyst and Tungsten Work Together

```
Your Code (Python/Scala/SQL)
       |
       v
  [Catalyst Optimizer]
       |
    Phase 1: Resolve column names, types
    Phase 2: Apply optimization rules
             (predicate pushdown, pruning, constant folding, etc.)
    Phase 3: Pick best physical plan
             (broadcast join vs sort-merge, etc.)
       |
       v
  [Tungsten Engine]
       |
    - Generate optimized JVM bytecode
    - Use UnsafeRow (compact binary format)
    - Whole-stage codegen (fuse operators)
    - Off-heap memory (avoid GC)
       |
       v
  [Execute on Cluster]
```

---

## Complete Example

```python
df2 = df.filter(df.age > 30).groupBy("city").count()
```

**Step 1**: Unresolved Plan — columns not yet validated
**Step 2**: Resolved Plan — schema checked, types assigned
**Step 3**: Optimized Logical Plan:
  - Predicate pushdown (filter at file scan)
  - Column pruning (read only age, city)
  - Combine filters
**Step 4**: Physical Plan chosen — HashAggregate
**Step 5**: Tungsten codegen — single compiled loop for filter + group + count
**Step 6**: Execution — Jobs → Stages → Tasks → parallel on cluster

---

## Key Takeaway

> **Catalyst** optimizes WHAT Spark does — it rewrites your query plan using rules like predicate pushdown, column pruning, and join reordering.
>
> **Tungsten** optimizes HOW Spark does it — it generates compiled bytecode, uses compact binary memory format, and eliminates Java object overhead.
>
> Together, they make Spark SQL orders of magnitude faster than raw RDD operations.
