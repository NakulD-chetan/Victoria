# Sliding Window — Mental Model

> **How FAANG engineers actually think about this pattern — visual reasoning, decision triggers, and the internal monologue of a senior engineer solving window problems in real time.**

---

## How FAANG Engineers Think About Sliding Window

### The Train Window Analogy

```
Imagine sitting in a train, looking out a window of fixed width.

  Scenery:  🏠 🌳 🏢 ⛪ 🏫 🏥 🌳 🏠
  Window:        [🌳 🏢 ⛪]
                      ↓ train moves right
            [🏢 ⛪ 🏫]

You NEVER turn your head backward. You only process:
  - What ENTERS the window (new right element)
  - What EXITS the window (old left element)
```

**FAANG mindset:** "I don't recalculate. I update."

### The Internal Monologue

When a FAANG engineer reads a problem, their brain runs this checklist:

```
1. "Is this about a CONTIGUOUS subarray or substring?"
   → Yes? Sliding window is a candidate.

2. "Am I looking for MAXIMUM, MINIMUM, or EXACT match?"
   → This determines if I use fixed or variable window.

3. "Can I maintain a CHEAP STATE that updates in O(1)?"
   → Sum? Yes. Frequency map? Yes. Sorted order? Maybe not.

4. "Are there NEGATIVE NUMBERS in a sum problem?"
   → If yes, sliding window may not work directly.

5. "What triggers SHRINKING the window?"
   → Constraint violated → shrink. Size exceeded → shrink.
```

---

## Visual: Fixed-Size Window

Problem: **Maximum sum subarray of size 3**

```
Array: [1, 4, 2, 10, 2, 3, 1, 0, 20]
k = 3

Step 1: Build initial window
[1, 4, 2] 10  2  3  1  0  20    sum = 7
 L     R

Step 2: Slide — remove left, add right
 1 [4, 2, 10]  2  3  1  0  20   sum = 7 - 1 + 10 = 16  ✓ new max
    L      R

Step 3: Continue sliding
 1  4 [2, 10, 2]  3  1  0  20   sum = 16 - 4 + 2 = 14
       L      R

Step 4:
 1  4  2 [10, 2, 3]  1  0  20   sum = 14 - 2 + 3 = 15
          L      R

Step 5:
 1  4  2  10 [2, 3, 1]  0  20   sum = 15 - 10 + 1 = 6
              L     R

Step 6:
 1  4  2  10  2 [3, 1, 0]  20   sum = 6 - 2 + 0 = 4
                 L     R

Step 7:
 1  4  2  10  2  3 [1, 0, 20]   sum = 4 - 3 + 20 = 21  ✓ new max!
                    L      R

Answer: 21
```

**Mental model:** "I keep a running sum. Each step: subtract the element leaving, add the element entering."

---

## Visual: Variable-Size Window

Problem: **Smallest subarray with sum ≥ 7**

```
Array: [2, 3, 1, 2, 4, 3]
Target = 7

Step 1: Expand right until constraint met
[2] → sum=2 < 7, expand
[2, 3] → sum=5 < 7, expand
[2, 3, 1] → sum=6 < 7, expand
[2, 3, 1, 2] → sum=8 ≥ 7 ✓  → length=4, record answer

Step 2: Try shrinking left (can we do better?)
   [3, 1, 2] → sum=6 < 7  → constraint violated, stop shrinking

Step 3: Expand right again
   [3, 1, 2, 4] → sum=10 ≥ 7 ✓  → length=4

Step 4: Shrink left
      [1, 2, 4] → sum=7 ≥ 7 ✓  → length=3, better!
         [2, 4] → sum=6 < 7 → stop shrinking

Step 5: Expand right
         [2, 4, 3] → sum=9 ≥ 7 ✓  → length=3
            [4, 3] → sum=7 ≥ 7 ✓  → length=2, best!
               [3] → sum=3 < 7 → stop

Answer: 2 (subarray [4,3])
```

---

## Pointer Movement Logic

```mermaid
flowchart LR
    subgraph Fixed["Fixed Window (lockstep)"]
        direction LR
        FL[LEFT] -->|gap = k| FR[RIGHT]
        FL -->|moves every step| FL
        FR -->|moves every step| FR
    end

    subgraph Variable["Variable Window (elastic)"]
        direction LR
        VL[LEFT] -.->|moves only when invalid| VL
        VR[RIGHT] -->|moves every step| VR
        VL -->|gap varies| VR
    end

    style FL fill:#fcc419,color:#000
    style FR fill:#339af0,color:#fff
    style VL fill:#fcc419,color:#000
    style VR fill:#339af0,color:#fff
```

### Fixed Window
```
RIGHT pointer: Moves every iteration (always advances by 1)
LEFT pointer:  Moves every iteration (always advances by 1, maintaining gap = k)
MOVEMENT:      Lockstep — both move together after initialization
```

### Variable Window
```
RIGHT pointer: Moves every iteration in the outer loop
LEFT pointer:  Moves ONLY when constraint is violated (inner while loop)
MOVEMENT:      Right races ahead, left catches up when needed

                    ┌─── right: always advances
                    │
    [  L ........... R  ]
        │
        └─── left: only advances when window invalid
```

### The Caterpillar Analogy
```
Think of a caterpillar:
  - The HEAD (right) always moves forward, exploring
  - The TAIL (left) stays put until the body is too stretched
  - When the body violates the constraint, tail catches up

  ←─ TAIL ─── BODY ─── HEAD →
       L ═══════════════ R
               ↓
  Body too long? Tail moves:
            L ══════════ R
               ↓
  Head advances:
            L ═══════════ R
```

---

## Decision Triggers

### When to EXPAND (move right)?
- **Always** — right moves forward every iteration of the outer loop
- We are exploring new elements to find valid/better windows

### When to SHRINK (move left)?
| Trigger | Example Problem | Shrink Condition |
|---------|----------------|------------------|
| Window too large | Max sum of size k | `right - left + 1 > k` |
| Constraint violated | At most k distinct chars | `distinct_count > k` |
| Sum exceeded | Smallest subarray ≥ target | `current_sum >= target` (shrink while valid to minimize) |
| Invalid state | No repeating chars | `char is duplicate in window` |

### When to UPDATE answer?
| Goal | When to Update |
|------|---------------|
| Maximum window/sum | After expanding (when window is valid) |
| Minimum window | After shrinking (when window is still valid) |
| Count of valid windows | After each valid state |

---

## Pattern Recognition Signals

### Instant Sliding Window Signals

| You See This in Problem | Your Brain Should Say |
|------------------------|----------------------|
| "contiguous subarray" | "Sliding window candidate" |
| "substring" | "Sliding window on characters" |
| "of size k" or "of length k" | "Fixed-size window" |
| "longest/shortest such that..." | "Variable-size window" |
| "at most k distinct" | "Variable window + hash map" |
| "sum ≥ target" | "Variable window (shrink while valid)" |
| "no repeating characters" | "Variable window + hash set" |
| "contains all characters of..." | "Variable window + frequency map" |
| "maximum average" | "Fixed window + running sum" |

### Hidden Sliding Window Problems

Some problems don't obviously say "subarray" but are window problems:

| Problem Description | Hidden Window |
|--------------------|---------------|
| "Replace at most k elements to maximize..." | Variable window — invalid elements ≤ k |
| "Fruits into baskets" | At most 2 distinct (variable window) |
| "Maximum consecutive ones with k flips" | Window where zeros ≤ k |
| "Permutation in string" | Fixed window of pattern length |
| "Minimum window substring" | Variable window with frequency matching |

---

## The FAANG Decision Flowchart

```mermaid
flowchart TD
    A[START: Read Problem] --> B{Contiguous\nsubarray/string?}
    B -- No --> C[Not Sliding Window]
    B -- Yes --> D{Window size\ngiven k?}
    D -- Yes --> E[FIXED WINDOW\nSlide with constant gap]
    D -- No --> F{Looking for\nlongest or shortest?}
    F -- Longest --> G[Expand first\nShrink when invalid\nTrack maximum]
    F -- Shortest --> H[Expand until valid\nShrink while still valid\nTrack minimum]
    F -- Count --> I[Expand\nCount valid: right-left+1]

    style C fill:#ff6b6b,color:#fff
    style E fill:#51cf66,color:#fff
    style G fill:#339af0,color:#fff
    style H fill:#fcc419,color:#000
    style I fill:#cc5de8,color:#fff
```

<!-- ASCII fallback -->
<details><summary>ASCII version (for plain text viewers)</summary>

```
                    START: Read problem
                         │
                ┌────────▼────────┐
                │ Contiguous      │──── No ──→ Not Sliding Window
                │ subarray/string?│
                └────────┬────────┘
                         │ Yes
                ┌────────▼────────┐
                │ Window size     │──── Yes ──→ FIXED WINDOW
                │ given (k)?      │            (slide with constant gap)
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ Looking for     │──── Longest ──→ Expand first,
                │ longest or      │                 shrink when invalid
                │ shortest?       │
                └────────┬────────┘
                         │ Shortest
                         ▼
                   Expand until valid,
                   shrink while still valid,
                   track minimum
```
</details>

---

## State Tracking Patterns

| What You're Tracking | Data Structure | Example |
|---------------------|---------------|---------|
| Running sum | Single variable | Max sum subarray of size k |
| Character frequency | Hash map / array[26] | Anagram, permutation check |
| Distinct count | Hash map + counter | At most k distinct |
| Duplicate detection | Hash set | Longest without repeats |
| Min/Max in window | Monotonic deque | Sliding window maximum |
| Character match count | Two frequency maps + match counter | Minimum window substring |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Sliding Window
WHEN TO USE:        See "contiguous subarray/substring" + optimize
CORE IDEA:          [L...R] window slides forward, never backward
MOVEMENT RULE:      R always advances; L advances when constraint violated
FIXED vs VARIABLE:  Size given → fixed; Size found → variable
EXPAND TRIGGER:     Every iteration (outer loop)
SHRINK TRIGGER:     Window invalid (too large / constraint broken)
UPDATE TRIGGER:     Max → after expand; Min → after shrink
TIME COMPLEXITY:    O(n) — each element enters and leaves once
INTERVIEW LINE:     "I'll maintain a sliding window tracking [state].
                     Right pointer explores, left pointer contracts
                     when [constraint] is violated."
```

---

## 30-SECOND REVISION BOX

```
FIXED:     Both pointers move in lockstep (gap = k)
VARIABLE:  R always moves, L moves when invalid
LONGEST:   Update after shrink (window valid)
SHORTEST:  Update during shrink (window still valid)
CATERPILLAR: Head(R) explores, Tail(L) catches up
STATE:     sum=variable, freq=hashmap, distinct=map.len, max=deque
```
