# Subquery / EXISTS — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers scalar subqueries, IN, EXISTS, NOT EXISTS, correlated subqueries, and anti-joins. Sources: LeetCode, HackerRank, DataLemur.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Customers Who Never Order | LC 183 | Easy | NOT EXISTS / LEFT JOIN | Purest anti-join problem |
| 2 | Employees Earning More Than Managers | LC 181 | Easy | Correlated subquery | Subquery referencing outer table |
| 3 | Department Highest Salary | LC 184 | Medium | Scalar subquery + IN | Subquery for max per group |
| 4 | Customers Who Bought All Products | LC 1045 | Medium | COUNT + subquery | Set completeness check |
| 5 | Managers With At Least 5 Reports | LC 570 | Medium | EXISTS + COUNT | Semi-join with aggregate |
| 6 | Sales Person (No Orders to "RED") | LC 607 | Easy | NOT EXISTS / NOT IN | Anti-join on filtered set |
| 7 | Exchange Seats | LC 626 | Medium | CASE + scalar subquery | Conditional swap using subquery |
| 8 | Investments in 2016 | LC 585 | Medium | IN + NOT IN | Multiple subquery conditions |
| 9 | Employees Earning > Dept Average | Common | Medium | Correlated scalar | Compare row to group aggregate |
| 10 | Second Highest Salary | LC 176 | Medium | Scalar subquery + LIMIT | Nested subquery for Nth value |

---

## Complete 20-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Customers Who Never Order | LC 183 | NOT EXISTS | Anti-join: rows with no match |
| 2 | Employees Earning More Than Managers | LC 181 | Correlated | Subquery references outer row |
| 3 | Sales Person | LC 607 | NOT IN / NOT EXISTS | Exclude based on related table |
| 4 | Big Countries | LC 595 | Simple WHERE | Warm-up before subquery patterns |
| 5 | Combine Two Tables | LC 175 | LEFT JOIN baseline | Foundation for anti-join comparison |
| 6 | Duplicate Emails | LC 182 | IN subquery | Self-referencing IN |

### Medium (Problems 7-15) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 7 | Department Highest Salary | LC 184 | IN (dept, max_sal) | Multi-column IN subquery |
| 8 | Second Highest Salary | LC 176 | Scalar + LIMIT | Subquery for Nth value |
| 9 | Managers With At Least 5 Reports | LC 570 | EXISTS + aggregate | Semi-join with HAVING |
| 10 | Customers Who Bought All Products | LC 1045 | COUNT = (subquery) | Completeness check |
| 11 | Investments in 2016 | LC 585 | IN + NOT IN combo | Multiple membership checks |
| 12 | Exchange Seats | LC 626 | CASE + subquery | Conditional logic with max check |
| 13 | Employees Earning > Dept Avg | Common | Correlated scalar | Per-row comparison to group value |
| 14 | Product Price at Given Date | LC 1164 | Subquery + COALESCE | Most recent value before date |
| 15 | Active Users | LC 1454 | EXISTS + date logic | Semi-join with date constraints |

### Hard (Problems 16-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 16 | Department Top Three Salaries | LC 185 | Correlated COUNT | Count employees with higher salary |
| 17 | Trips and Users | LC 262 | NOT EXISTS + agg | Filter banned users via anti-join |
| 18 | Human Traffic of Stadium | LC 601 | EXISTS + consecutive | Semi-join for sequence detection |
| 19 | Median Employee Salary | LC 569 | Correlated COUNT | Position-based filtering |
| 20 | Find Cumulative Salary | LC 579 | Correlated + range | Sum over correlated date range |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Customers Who Never Order (LC 183)

```
Pattern:     Anti-join (NOT EXISTS)
Approach:    SELECT c.name FROM customers c
             WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.id)
Key Insight: NOT EXISTS is NULL-safe; LEFT JOIN + IS NULL also works
One-liner:   Anti-join customers against orders — keep those with no match.
```

### Problem 7: Department Highest Salary (LC 184)

```
Pattern:     Multi-column IN subquery
Approach:    WHERE (dept, salary) IN (SELECT dept, MAX(salary) FROM emp GROUP BY dept)
Key Insight: Multi-column IN checks tuple membership — elegant for "max per group"
One-liner:   Subquery finds (dept, max_salary) pairs; outer query matches them.
```

### Problem 10: Customers Who Bought All Products (LC 1045)

```
Pattern:     COUNT DISTINCT = total
Approach:    GROUP BY customer_id
             HAVING COUNT(DISTINCT product_key) = (SELECT COUNT(*) FROM product)
Key Insight: "All products" = customer's distinct count equals total product count
One-liner:   Group by customer, having distinct count equals total from products table.
```

### Problem 16: Department Top Three Salaries (LC 185)

```
Pattern:     Correlated COUNT for ranking
Approach:    WHERE (SELECT COUNT(DISTINCT salary) FROM employees e2
             WHERE e2.dept = e.dept AND e2.salary > e.salary) < 3
Key Insight: Count how many distinct salaries are higher — if < 3, you're in top 3
One-liner:   Correlated subquery counts higher salaries; < 3 means top-3 rank.
```

---

## Pattern Distribution

```
ANTI-JOIN (NOT EXISTS / NOT IN):       6 problems  (1, 3, 6, 11, 17, 18)
SEMI-JOIN (EXISTS):                    4 problems  (5, 9, 15, 18)
SCALAR SUBQUERY:                       4 problems  (2, 8, 13, 14)
CORRELATED SUBQUERY:                   4 problems  (13, 16, 19, 20)
IN SUBQUERY (set membership):          2 problems  (7, 11)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 183, LC 607 (anti-join basics)
- Day 2: LC 181, LC 182 (correlated, IN subquery)
- Day 3: LC 176, LC 184 (scalar, multi-column IN)

### Week 2: Core Patterns (Days 4-6)
- Day 4: LC 570, LC 1045 (EXISTS + aggregate, completeness)
- Day 5: LC 585, LC 626 (multi-condition, CASE + subquery)
- Day 6: Correlated scalar (dept avg), LC 1164 (most recent)

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 185, LC 262 (top-3, trips)
- Day 8: LC 569, LC 579 (median, cumulative)
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Replace nested subqueries | Pattern 02 (CTE) — cleaner multi-step logic |
| Top-N per group | Pattern 09 (Top-N Per Group) — ROW_NUMBER approach |
| Duplicate detection | Pattern 04 (Aggregation + HAVING) — GROUP BY approach |
| Set difference | Pattern 10 (Set Operations) — EXCEPT is simpler |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (6 Easy, 9 Medium, 5 Hard)
MUST-DO:            LC 183, 181, 184, 1045, 570, 607, 626, 585, 176
TOP 3 MOST ASKED:   LC 183 (Never Order), LC 184 (Dept Max), LC 185 (Top 3)
PATTERN SPLIT:      Anti-join (6), Semi-join (4), Scalar (4), Correlated (4), IN (2)
STUDY ORDER:        NOT EXISTS → IN → Scalar → Correlated → Combined
KEY INSIGHT:        EXISTS short-circuits; NOT IN breaks on NULLs
INTERVIEW LINE:     "I use EXISTS for semi-joins, NOT EXISTS for anti-joins,
                     and always avoid NOT IN when NULLs are possible."
```

---

## 30-SECOND REVISION BOX

```
EXISTS:        Keep rows WITH at least one match — semi-join
NOT EXISTS:    Keep rows with NO match — anti-join (NULL-safe)
IN:            Set membership check — materializes set
NOT IN:        DANGER: returns empty if subquery has NULL values
SCALAR:        Subquery returning single value — use in SELECT/WHERE
CORRELATED:    References outer query — runs once per outer row
PLACEMENT:     WHERE, SELECT, FROM, HAVING, JOIN
RULE:          Prefer NOT EXISTS over NOT IN; convert deep nesting to CTE
PERFORMANCE:   Non-correlated = O(N+M); Correlated = O(N×M) without optimization
```
