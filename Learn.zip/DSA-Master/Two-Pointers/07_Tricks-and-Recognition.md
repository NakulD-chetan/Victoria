# Two Pointers — Tricks and Recognition

> **Pattern triggers, keyword matching, hidden signals, constraint clues, quick decision flowchart, and comparison with similar patterns.**

---

## Pattern Triggers and Keyword Matching

### Direct Triggers (Say "Two Pointers")


| Keyword/Phrase                | Variant              | Example                |
| ----------------------------- | -------------------- | ---------------------- |
| "sorted array"                | Opposite             | Two Sum II, 3Sum       |
| "pair with sum X"             | Opposite             | Two Sum II             |
| "three numbers that sum to 0" | 3Sum                 | 3Sum, 4Sum             |
| "palindrome"                  | Opposite             | Valid Palindrome       |
| "linked list cycle"           | Fast/Slow            | Linked List Cycle      |
| "middle of linked list"       | Fast/Slow            | Middle of LL           |
| "in-place"                    | Partition/Read-Write | Move Zeros, Remove Dup |
| "O(1) space"                  | Partition/Read-Write | Most in-place problems |
| "sort 0s, 1s, 2s"             | Dutch Flag           | Sort Colors            |
| "merge two sorted"            | Two arrays           | Merge Sorted Array     |


### Indirect Triggers (Think "Maybe Two Pointers")


| Keyword/Phrase               | Why                                 | Verify                     |
| ---------------------------- | ----------------------------------- | -------------------------- |
| "two numbers"                | Could be pair                       | Is array sorted?           |
| "container with most water"  | Width × height, ends have max width | Opposite-direction         |
| "trapping rain water"        | Max from left and right             | Two passes or two pointers |
| "squares of sorted array"    | Largest abs at ends                 | Opposite-direction         |
| "intersection of two arrays" | If sorted, two pointers             | One per array              |
| "remove element in-place"    | Read/write pointers                 | Same-direction             |
| "partition array"            | Move elements to one side           | Partition                  |


---

## Hidden Two-Pointer Signals

### Signal 1: "Can you do it in O(1) space?"

- **Implication:** No extra arrays, no hash maps
- **Pattern:** In-place two pointers (read/write, partition) or opposite-direction (already O(1))

### Signal 2: "Array is sorted" or "Sort the array first"

- **Implication:** Sorted order unlocks opposite-direction
- **Pattern:** Two Sum, 3Sum, Merge, Intersection

### Signal 3: ""sortedFind two indices" + "

- **Implication:** Classic two-pointer pair
- **Pattern:** Two Sum II

### Signal 4: "Detect cycle" + "linked list"

- **Implication:** Fast/slow
- **Pattern:** Linked List Cycle

### Signal 5: "Move all X to one end"

- **Implication:** Partition
- **Pattern:** Move Zeros, Dutch Flag

### Signal 6: "Remove duplicates" + "sorted" + "in-place"

- **Implication:** Read/write pointers
- **Pattern:** Remove Duplicates from Sorted Array

---

## Constraint Clues


| Constraint       | Suggests                                                                               |
| ---------------- | -------------------------------------------------------------------------------------- |
| n ≤ 10^5         | O(n) or O(n log n) — two pointers O(n) fits                                            |
| n ≤ 10^3         | O(n²) OK — 3Sum with two-pointer inner loop                                            |
| "O(1) space"     | In-place two pointers                                                                  |
| "Sorted"         | Opposite-direction                                                                     |
| "No extra space" | Partition or read/write                                                                |
| "Return indices" | If sorted, two pointers change indices — may need to store before sort or use hash map |


---

## Quick Decision Flowchart

```mermaid
flowchart TD
    START([START])
    A{Is it a LINKED LIST?}
    B{Cycle? Middle? Nth from end?}
    C[FAST/SLOW 2× speed]
    D{Is array/list SORTED?}
    E{Pair/Triplet sum?}
    F[OPPOSITE-DIRECTION L←→R converge]
    G{In-place? Partition? Remove dup?}
    H[PARTITION or READ/WRITE]
    I{3Sum?}
    J[FIX one + TWO-POINTER on rest]

    START --> A
    A -- Yes --> B
    B --> C
    A -- No --> D
    D -- Yes --> E
    D -- No --> G
    E -- Yes --> F
    E -- No --> G
    G -- Yes --> H
    F --> I
    I -- Yes --> J

    style A fill:#ffd43b,color:#000
    style B fill:#ffd43b,color:#000
    style D fill:#ffd43b,color:#000
    style E fill:#ffd43b,color:#000
    style G fill:#ffd43b,color:#000
    style I fill:#ffd43b,color:#000
    style C fill:#51cf66,color:#fff
    style F fill:#51cf66,color:#fff
    style H fill:#51cf66,color:#fff
    style J fill:#51cf66,color:#fff
```



ASCII fallback

```
                    START
                      │
        ┌─────────────▼─────────────┐
        │ Is it a LINKED LIST?     │
        └─────────────┬─────────────┘
                 Yes │     │ No
        ┌────────────┘     └────────────┐
        ▼                               ▼
┌───────────────┐              ┌────────────────┐
│ Cycle? Middle?│              │ Is array/list  │
│ Nth from end? │              │ SORTED?        │
└───────┬───────┘              └───────┬───────┘
        │                         Yes  │  No
        ▼                              ▼
   FAST/SLOW              ┌─────────────────────┐
   (2× speed)             │ Pair/Triplet sum?   │
                          └─────────┬───────────┘
                                Yes │    │ No
                          ┌─────────┘    └─────────┐
                          ▼                        ▼
                   OPPOSITE-DIRECTION      ┌──────────────┐
                   (L←→R converge)         │ In-place?    │
                          │                │ Partition?   │
                          │                │ Remove dup?  │
                          │                └──────┬───────┘
                          │                   Yes │
                          │                      ▼
                          │               PARTITION or
                          │               READ/WRITE
                          │
                   ┌──────┴──────┐
                   │ 3Sum?      │
                   └──────┬─────┘
                      Yes │
                          ▼
                   FIX one + TWO-POINTER
                   on rest
```



---

## Comparison with Similar Patterns

### Two Pointers vs Sliding Window


| Aspect      | Two Pointers                                    | Sliding Window                              |
| ----------- | ----------------------------------------------- | ------------------------------------------- |
| Direction   | Often opposite (converging) or different speeds | Same direction (both advance, left may lag) |
| Structure   | Pairs, triplets, partition                      | Contiguous subarray/substring               |
| Movement    | Based on comparison (sum vs target)             | Based on constraint (valid/invalid window)  |
| Typical use | Sorted array pair sum, cycle                    | Longest substring, sum ≥ target             |
| Gap         | Often narrowing (L and R converge)              | Variable (expand right, shrink left)        |


**When confused:** "Am I maintaining a contiguous window that expands/shrinks? → Sliding. Am I finding pairs or converging from ends? → Two pointers."

### Two Pointers vs Binary Search


| Aspect    | Two Pointers                        | Binary Search                          |
| --------- | ----------------------------------- | -------------------------------------- |
| Structure | Two indices in same structure       | One mid, search space halves           |
| Use case  | Pair sum, partition                 | Find single element, search space      |
| Movement  | Both move (often toward each other) | Only mid moves; left/right bound space |
| Sorted?   | Yes (for opposite-direction)        | Yes (required)                         |


**When confused:** "Am I finding a pair? → Two pointers. Am I finding one value? → Binary search."

### Two Pointers vs Hash Map


| Aspect     | Two Pointers                  | Hash Map                        |
| ---------- | ----------------------------- | ------------------------------- |
| Space      | O(1)                          | O(n)                            |
| Sorted?    | Required (opposite-direction) | Not required                    |
| Use case   | Pair in sorted array          | Pair in any array, need indices |
| Duplicates | Handle with skip logic        | Handle with count               |


**When confused:** "Can I sort? Need O(1) space? → Two pointers. Need original indices? Unsorted? → Hash map."

---

## Pattern Recognition Cheat Sheet


| You See...             | Think...                                 |
| ---------------------- | ---------------------------------------- |
| Sorted + pair sum      | Opposite two pointers                    |
| Sorted + triplet sum   | 3Sum: fix i, two-pointer                 |
| Linked list + cycle    | Fast/slow                                |
| Linked list + middle   | Fast/slow (fast at end → slow at middle) |
| In-place + move/remove | Partition or read/write                  |
| 0s, 1s, 2s             | Dutch flag                               |
| Merge sorted           | Two pointers (one per array)             |
| Palindrome             | Opposite from ends                       |
| Container with water   | Opposite (width vs height)               |
| Squares of sorted      | Opposite (max abs at ends)               |


---

## The "Can I Sort?" Test

```
If you can sort the input:
  → Unlocks opposite-direction two pointers
  → O(n log n) sort + O(n) two-pointer = O(n log n)
  → O(1) space (if sort in-place)

If you cannot sort (e.g., need original indices):
  → Use Hash Map for pair sum
  → Or store (value, index) before sort, then two-pointer
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Tricks and Recognition
TRIGGERS:           Sorted + pair → Opposite; Cycle → Fast/slow
                    In-place → Partition/Read-write
HIDDEN:             O(1) space, "move to end", "remove in-place"
VS SLIDING WINDOW:  Opposite/different speed vs same direction
                    Pairs vs contiguous subarray
VS BINARY SEARCH:   Pair vs single element
VS HASH MAP:        Sorted+O(1) space vs unsorted+indices
CAN SORT?           Yes → Two pointers. No → Hash map (for pairs)
INTERVIEW LINE:     "I see sorted array and pair sum — two pointers
                     will give O(n) time and O(1) space."
```

