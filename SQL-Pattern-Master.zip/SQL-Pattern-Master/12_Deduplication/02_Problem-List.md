# Deduplication — Problem List

> **18 problems in progressive difficulty. 10 MUST-DO highlighted. Covers DISTINCT, ROW_NUMBER dedup, DELETE duplicates, merge duplicates, and ETL dedup. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Duplicate Emails | LC 182 | Easy | GROUP BY + HAVING | Find duplicates — foundation |
| 2 | Delete Duplicate Emails | LC 196 | Easy | DELETE + self join | Delete dupes, keep smallest id |
| 3 | Second Highest Salary | LC 176 | Medium | DISTINCT + dedup | Dedup before ranking |
| 4 | Latest Login Per User | Common | Easy | ROW_NUMBER = 1 | Keep most recent per group |
| 5 | Customers With Duplicate Orders | DataLemur | Easy | GROUP BY + HAVING | Detect duplicates |
| 6 | Product Price at Given Date | LC 1164 | Medium | ROW_NUMBER dedup | Latest price per product |
| 7 | Game Play Analysis IV | LC 550 | Medium | DISTINCT + dedup | First login per player |
| 8 | Merge Duplicate Contacts | Common | Medium | GROUP BY + COALESCE | Merge best data from dupes |
| 9 | ETL Staging Dedup | Common | Medium | ROW_NUMBER pattern | Pipeline dedup by business key |
| 10 | Remove Duplicate Rows (no ID) | Common | Medium | DISTINCT / ctid | Dedup identical rows |

---

## Complete 18-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Duplicate Emails | LC 182 | GROUP BY + HAVING > 1 | Identify duplicates |
| 2 | Delete Duplicate Emails | LC 196 | DELETE + self join | Remove dupes keeping min id |
| 3 | Latest Login Per User | Common | ROW_NUMBER = 1 | Keep most recent record |
| 4 | Customers With Duplicate Orders | DataLemur | GROUP BY + HAVING | Count dupes per customer |
| 5 | DISTINCT Product Categories | Common | SELECT DISTINCT | Basic dedup |
| 6 | First Order Per Customer | Common | ROW_NUMBER = 1 ASC | Keep earliest record |

### Medium (Problems 7-14) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 7 | Product Price at Given Date | LC 1164 | ROW_NUMBER DESC | Latest price before date |
| 8 | Game Play Analysis IV | LC 550 | First login dedup | MIN per group or RN = 1 |
| 9 | Merge Duplicate Contacts | Common | GROUP BY + COALESCE | Best non-null from each column |
| 10 | Remove Duplicate Rows (no ID) | Common | DISTINCT / CTE | No unique ID — use ctid or CTE |
| 11 | ETL Staging Dedup | Common | ROW_NUMBER by timestamp | Keep latest per business key |
| 12 | Find Nth Unique Value | Common | DENSE_RANK after dedup | Dedup then rank |
| 13 | Count After Dedup | Common | COUNT(DISTINCT col) | Distinct count vs total count |
| 14 | Dedup With Merge Logic | Common | COALESCE across rows | Merge phone+email from dupes |

### Hard (Problems 15-18) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 15 | Fuzzy Dedup (Similar Names) | Advanced | SOUNDEX / Levenshtein | Approximate matching dedup |
| 16 | Dedup Event Stream | Advanced | ROW_NUMBER + window | Exactly-once from at-least-once |
| 17 | Cross-Source Dedup | Advanced | UNION ALL + ROW_NUMBER | Merge multiple sources, dedup |
| 18 | Incremental Dedup | Advanced | MERGE + ROW_NUMBER | Dedup on insert (upsert pattern) |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Delete Duplicate Emails (LC 196)

```
Pattern:     DELETE with self join
Approach:    DELETE p1 FROM person p1, person p2
             WHERE p1.email = p2.email AND p1.id > p2.id
Key Insight: Keep smallest id → delete where p1.id > p2.id
One-liner:   Self join on email; delete the row with larger id.
```

### Problem 7: Product Price at Given Date (LC 1164)

```
Pattern:     ROW_NUMBER dedup — latest before date
Approach:    ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY change_date DESC)
             WHERE change_date <= '2019-08-16' AND rn = 1
             UNION products with no price change (default 10)
Key Insight: Dedup to get latest change before cutoff date
One-liner:   Rank price changes desc; pick rn=1 before date; default for missing.
```

### Problem 11: ETL Staging Dedup

```
Pattern:     ROW_NUMBER by event_timestamp DESC
Approach:    INSERT INTO clean SELECT * FROM (
               SELECT *, ROW_NUMBER() OVER (
                   PARTITION BY business_key ORDER BY event_ts DESC
               ) AS rn FROM staging
             ) WHERE rn = 1
Key Insight: Standard ETL pattern — latest version per business key
One-liner:   Partition by key, order by timestamp desc, keep rn=1.
```

### Problem 15: Fuzzy Dedup (Similar Names)

```
Pattern:     Approximate matching
Approach:    SOUNDEX(name) or Levenshtein distance < threshold
             Group by SOUNDEX → ROW_NUMBER within group
Key Insight: Exact dedup misses "John Smith" vs "Jon Smith"
One-liner:   SOUNDEX groups similar names; ROW_NUMBER picks representative.
```

---

## Pattern Distribution

```
IDENTIFY DUPLICATES (find them):        5 problems  (1, 4, 5, 8, 13)
ROW_NUMBER DEDUP (keep one):            6 problems  (3, 6, 7, 11, 12, 16)
DELETE DUPLICATES:                      3 problems  (2, 10, 17)
MERGE DUPLICATES (combine):            2 problems  (9, 14)
FUZZY / ADVANCED:                      2 problems  (15, 18)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 182, LC 196 (find + delete duplicates)
- Day 2: Latest login, first order (ROW_NUMBER = 1)
- Day 3: DISTINCT basics, COUNT(DISTINCT)

### Week 2: Core Patterns (Days 4-6)
- Day 4: LC 1164, LC 550 (product price, game play)
- Day 5: Merge duplicate contacts, no-ID dedup
- Day 6: ETL staging dedup, cross-source dedup

### Week 3: Hard + Review (Days 7-8)
- Day 7: Fuzzy dedup, event stream dedup
- Day 8: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Keep top N not just 1 | Pattern 09 (Top-N Per Group) — ROW_NUMBER <= N |
| Find duplicates via aggregate | Pattern 04 (Aggregation + HAVING) — GROUP BY + HAVING |
| Anti-join for set difference | Pattern 05 (Subquery/EXISTS) — NOT EXISTS |
| Dedup + insert (upsert) | Pattern 14 (Merge/Upsert/SCD) — MERGE statement |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     18 (6 Easy, 8 Medium, 4 Hard)
MUST-DO:            LC 182, 196, 176, 1164, 550 + DataLemur/Common
TOP 3 MOST ASKED:   LC 196 (Delete Dupes), LC 182 (Find Dupes), LC 1164 (Price)
PATTERN SPLIT:      Identify (5), ROW_NUMBER dedup (6), DELETE (3), Merge (2), Fuzzy (2)
STUDY ORDER:        Find dupes → ROW_NUMBER dedup → DELETE → Merge → Fuzzy
KEY INSIGHT:        ROW_NUMBER PARTITION BY key ORDER BY preference = 1 → the keeper
INTERVIEW LINE:     "I use ROW_NUMBER partitioned by the dedup key, ordered by
                     my keep preference, and filter rn=1 for SELECT or rn>1 for DELETE."
```

---

## 30-SECOND REVISION BOX

```
FIND DUPES:    GROUP BY key HAVING COUNT(*) > 1
DEDUP SELECT:  ROW_NUMBER() OVER (PARTITION BY key ORDER BY pref DESC) = 1
DEDUP DELETE:  WHERE id IN (SELECT id FROM ranked WHERE rn > 1)
DISTINCT:      Removes exact duplicate rows (all columns must match)
DISTINCT ON:   PostgreSQL — first row per group by ORDER BY (fastest)
GROUP BY:      Loses column detail — need aggregates for non-grouped cols
MERGE DUPES:   GROUP BY key + COALESCE(MAX(col)) for best non-null
TIEBREAK:      Always add secondary ORDER BY for deterministic results
ETL PATTERN:   Staging → ROW_NUMBER by business_key → keep latest → clean table
```
