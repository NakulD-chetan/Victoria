import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    cellEmpty: '#fafaf9',
    cellPlaced: '#b2f2bb',
    cellConflict: '#ffc9c9',
    cellPath: '#ffec99',
    cellWall: '#44403c',
    cellExploring: '#a5d8ff',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    pathLine: '#ca8a04',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.06)',
    stroke: 'rgba(255,255,255,0.55)',
    cellEmpty: '#1c1917',
    cellPlaced: '#1e5631',
    cellConflict: '#7c1d1d',
    cellPath: '#805b10',
    cellWall: '#0c0a09',
    cellExploring: '#1864ab',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    pathLine: '#eab308',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}

function colorFor(p, name) {
  const key = `cell${(name || 'empty').charAt(0).toUpperCase() + (name || 'empty').slice(1)}`;
  return p[key] || p.cellEmpty;
}

const GridCanvasBase = forwardRef(function GridCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    grid: [],
    cellColors: {},
    cellValues: {},
    path: [],
    size: 8,
    cols: null,
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 350) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((patch) => {
    Object.assign(stateRef.current, patch);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 360;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function render() {
      const now = performance.now();
      const p = getPalette();
      const { grid, cellColors, cellValues, path, size, cols: colsOverride } = stateRef.current;
      const n = size || 8;
      const cols = colsOverride != null ? colsOverride : n;

      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.2, 1.2);

      const pad = 32;
      const board = Math.min(W - pad * 2, H - 56);
      const cell = board / Math.max(n, cols, 1);
      const originX = (W - cols * cell) / 2;
      const originY = 40;

      const flashCells = {};
      for (const a of animsRef.current) {
        const t = Math.min((now - a.t0) / a.dur, 1);
        const e = easeOut(t);
        if (a.type === 'backtrack' && a.data.r != null && a.data.c != null) {
          const k = `${a.data.r}-${a.data.c}`;
          flashCells[k] = (1 - e) * 0.65;
        }
      }

      for (let r = 0; r < n; r++) {
        for (let c = 0; c < cols; c++) {
          const x = originX + c * cell;
          const y = originY + r * cell;
          const key = `${r}-${c}`;
          const gRow = grid[r];
          const gVal = gRow && gRow[c];
          const colorName = cellColors[key] || gVal || 'empty';
          ctx.fillStyle = colorFor(p, colorName);
          ctx.fillRect(x + 1, y + 1, cell - 2, cell - 2);
          const fa = flashCells[key];
          if (fa) {
            ctx.fillStyle = `rgba(248, 113, 113, ${fa})`;
            ctx.fillRect(x + 1, y + 1, cell - 2, cell - 2);
          }
        }
      }

      ctx.strokeStyle = p.stroke;
      ctx.lineWidth = 2.5;
      for (let r = 0; r <= n; r++) {
        ctx.beginPath();
        ctx.moveTo(originX, originY + r * cell);
        ctx.lineTo(originX + cols * cell, originY + r * cell);
        ctx.stroke();
      }
      for (let c = 0; c <= cols; c++) {
        ctx.beginPath();
        ctx.moveTo(originX + c * cell, originY);
        ctx.lineTo(originX + c * cell, originY + n * cell);
        ctx.stroke();
      }

      for (let r = 0; r < n; r++) {
        for (let c = 0; c < cols; c++) {
          const key = `${r}-${c}`;
          const val = cellValues[key];
          if (val == null || val === '') continue;
          const x = originX + c * cell;
          const y = originY + r * cell;
          ctx.fillStyle = p.textPrimary;
          const fs = Math.max(10, Math.min(18, cell * 0.42));
          ctx.font = `600 ${fs}px Consolas, monospace`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(val), x + cell / 2, y + cell / 2);
        }
      }

      const pathArr = path || [];
      if (pathArr.length > 1) {
        ctx.strokeStyle = p.pathLine;
        ctx.lineWidth = 3;
        ctx.lineJoin = 'round';
        ctx.beginPath();
        pathArr.forEach(([pr, pc], i) => {
          const x = originX + pc * cell + cell / 2;
          const y = originY + pr * cell + cell / 2;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        });
        ctx.stroke();
      }
      pathArr.forEach(([pr, pc], i) => {
        const x = originX + pc * cell + cell / 2;
        const y = originY + pr * cell + cell / 2;
        ctx.fillStyle = i === pathArr.length - 1 ? p.cellExploring : p.cellPath;
        ctx.beginPath();
        ctx.arc(x, y, Math.max(4, cell * 0.12), 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = p.stroke;
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      for (let i = animsRef.current.length - 1; i >= 0; i--) {
        if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
      }

      rafRef.current = requestAnimationFrame(render);
    };

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default GridCanvasBase;
