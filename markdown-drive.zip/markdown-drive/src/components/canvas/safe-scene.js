import { CaptureUpdateAction } from '@excalidraw/excalidraw';

/**
 * createSafeScene — single gateway for every `api.updateScene` call.
 *
 * Why:
 * Excalidraw holds an in-progress element in `state.newElement` between
 * `pointerdown` and `pointerup`. Any external `updateScene({ elements })`
 * during that window replaces the scene array and wipes `newElement`, so
 * the shape the user is drawing never commits. This is the single most
 * common cause of "I drew but nothing shows up".
 *
 * Strategy:
 *   - If no pointer is down → apply immediately.
 *   - If a pointer IS down → coalesce into a single queued patch and flush
 *     on the next `pointerup` (or when the caller marks gesture end).
 *   - Element-array patches during a gesture are dropped (we must never
 *     replace elements mid-gesture); only appState patches are safe to
 *     re-apply after pointerup. Callers should use `enqueueElements` with
 *     `runAfterGesture: true` if they want a post-gesture mutation.
 *
 * API:
 *   const safe = createSafeScene({ getApi, isPointerDown });
 *   safe.updateScene({ elements?, appState?, captureUpdate?, force? })
 *     - force=true bypasses the guard (use only for tool-initiated ops
 *       triggered BEFORE a gesture, e.g. insertDS, insertWidget, fit).
 *   safe.flushOnGestureEnd()  // call from pointerup listener
 *   safe.enqueueAfterGesture(patchFn)  // patchFn receives {api} and runs post-gesture
 */
export function createSafeScene({ getApi, isPointerDown }) {
  /** @type {Array<(api: any) => void>} */
  const pendingAfterGesture = [];
  /** Last appState patch seen during a gesture — only latest one is applied. */
  let pendingAppStatePatch = null;

  function apply(patch) {
    const api = getApi();
    if (!api) return;
    const { elements, appState, files, captureUpdate = CaptureUpdateAction.NEVER } = patch;
    const payload = { captureUpdate };
    if (elements) payload.elements = elements;
    if (appState) payload.appState = appState;
    if (files) payload.files = files;
    api.updateScene(payload);
  }

  function updateScene(patch) {
    const api = getApi();
    if (!api) return;
    const down = isPointerDown();
    if (!down || patch.force) {
      apply(patch);
      return;
    }
    // Gesture-active guard: never touch `elements` mid-gesture.
    if (patch.elements) {
      // Intentionally dropped. If the caller needs to re-apply after the
      // gesture, they should use enqueueAfterGesture explicitly.
      if (import.meta.env?.DEV) {
        console.warn(
          '[safe-scene] dropped updateScene({ elements }) during active gesture — '
          + 'use enqueueAfterGesture to defer.',
        );
      }
      return;
    }
    if (patch.appState) {
      pendingAppStatePatch = { ...(pendingAppStatePatch || {}), ...patch.appState };
    }
  }

  function enqueueAfterGesture(patchFn) {
    if (!isPointerDown()) {
      const api = getApi();
      if (api) patchFn(api);
      return;
    }
    pendingAfterGesture.push(patchFn);
  }

  function flushOnGestureEnd() {
    const api = getApi();
    if (!api) return;
    if (pendingAppStatePatch) {
      api.updateScene({
        appState: pendingAppStatePatch,
        captureUpdate: CaptureUpdateAction.NEVER,
      });
      pendingAppStatePatch = null;
    }
    while (pendingAfterGesture.length) {
      const fn = pendingAfterGesture.shift();
      try { fn(api); } catch (err) { console.error('[safe-scene] deferred patch failed:', err); }
    }
  }

  return { updateScene, enqueueAfterGesture, flushOnGestureEnd };
}
