# Python Exception Handling

> *"Errors should never pass silently — unless explicitly silenced"* — Zen of Python

`try`/`except`/`else`/`finally`, custom exceptions, hierarchy, `assert`, EAFP vs LBYL, traceback — the backbone of robust Python code. After [[09-Python-Encapsulation-Special-Methods]], learn to handle errors gracefully.

---

## 1. try / except / else / finally

> **Definition:** A **`try`** block runs code that might fail; **`except`** catches specific exception types; **`else`** runs only if no exception occurred; **`finally`** runs always for cleanup.

**Why we need it:** Separating normal flow, error handling, success-only steps, and guaranteed cleanup keeps programs robust and readable instead of crashing or leaking resources.

**Syntax:**
```python
try:
    ...
except <ExceptionType>:
    ...
else:
    ...
finally:
    ...
```

```python
try:
    x = int(input("number: "))    # This might fail (ValueError if user types "abc")
    r = 10 / x                    # This might fail (ZeroDivisionError if x is 0)
except ValueError:                # Catches ONLY ValueError
    print("not an int")
except ZeroDivisionError:         # Catches ONLY ZeroDivisionError
    print("don't divide by zero")
else:                             # Runs ONLY if try block had NO errors
    print("result", r)
finally:                          # Runs ALWAYS — error or no error
    print("cleanup always")
```

| Block | What it does |
|-------|-----------|
| `try` | Put your "risky" code here — code that MIGHT cause an error |
| `except` | Catches a specific error type and handles it (program doesn't crash) |
| `else` | Runs only when try was SUCCESSFUL (no error happened) |
| `finally` | Runs ALWAYS — whether error happened or not (great for cleanup) |

**Watch Out!** Don't write bare `except:` — you'll swallow `KeyboardInterrupt`, `SystemExit` too. Minimum `except Exception:` — better: specific types.

---

## 2. Multiple except and tuple

> **Definition:** You can list **several exception types** in one `except` clause with a tuple, and use **`as name`** to bind the caught exception instance for logging or re-raising.

**Why we need it:** Related failures often share one recovery path; grouping them avoids copy-pasted `except` blocks while still staying more specific than a bare `except Exception`.

**Syntax:**
```python
try:
    ...
except (Exc1, Exc2) as e:
    ...
```

```python
try:
    risky()
except (TypeError, ValueError) as e:  # Catches EITHER TypeError OR ValueError
    print("bad input", e)              # e contains the error message/details
```

- `as e` = saves the error object in variable `e` so you can print/log it
- Tuple `(TypeError, ValueError)` = catch multiple error types with one except block

---

## 3. `raise` — re-raise and chain

> **Definition:** **`raise`** starts or propagates an exception; **`raise New(...) from old`** chains causes; a bare **`raise`** inside `except` re-raises the current exception.

**Why we need it:** Callers should see both a high-level failure and the original root cause, and libraries need a standard way to signal invalid state without losing context.

**Syntax:**
```python
raise <Exception>(...)
raise <Exception>(...) from <cause>
raise
```

```python
def load():
    try:
        open("nope.txt")
    except FileNotFoundError as e:
        raise RuntimeError("config missing") from e
        # raise = THROW a new error manually
        # from e = links the original error so you can see the FULL chain in traceback
```

```python
raise ValueError("bad data")  # Manually throw an error — stops the program unless caught
raise  # Re-throws the SAME error that was caught (use inside except block)
```

---

## 4. Custom exceptions

> **Definition:** **Custom exceptions** are classes that inherit from `Exception` (or a closer built-in) and represent your application’s error categories with optional extra fields or messages.

**Why we need them:** Callers can catch `ValidationError` without catching every `Exception`, logs stay meaningful, and you can attach context (field name, error code) that generic types do not carry.

**Syntax:**
```python
class MyError(Exception):
    pass

raise MyError("message")
```

```python
class AppError(Exception):
    """Base for our app"""

class ValidationError(AppError):
    def __init__(self, field, msg):
        self.field = field
        super().__init__(msg)

raise ValidationError("email", "invalid format")
```

**Interview Tip:** Shallow hierarchy — `AppError` base, 3–6 concrete types is enough.

---

## 5. Exception hierarchy — builtins (sample)

> **Definition:** **Built-in exceptions** form a tree under `BaseException` → `Exception` → more specific types (`ValueError`, `KeyError`, `OSError`, …); subclasses inherit “is a” relationships for `except`.

**Why we need it:** Catching **`LookupError`** before **`KeyError`**, or **`OSError`** before **`FileNotFoundError`**, lets you handle families of errors without listing every concrete type.

**Syntax:**
```python
try:
    ...
except SpecificError:
    ...
except BroaderParentError:
    ...
```

```
BaseException
 ├── SystemExit
 ├── KeyboardInterrupt
 └── Exception
      ├── ArithmeticError → ZeroDivisionError
      ├── LookupError → KeyError, IndexError
      ├── OSError → FileNotFoundError, ...
      ├── ValueError, TypeError
      └── ...
```

Specific **first**, broad **later**:

```python
try:
    ...
except KeyError:
    ...
except LookupError:
    ...
```

---

## 6. `assert` — debug invariant

> **Definition:** **`assert condition, message`** evaluates `condition`; if it is false, Python raises **`AssertionError`** with the optional message—intended for **debug** checks, not user validation.

**Why we need it:** During development you document “this should never happen” invariants at the point they must hold, failing fast when logic breaks.

**Syntax:**
```python
assert <condition>, "optional message"
```

```python
assert x >= 0, "x negative"   # If x < 0, throws AssertionError with message "x negative"
# assert = "I'm 100% sure this should be true. If not, something is very wrong."
```

**Watch Out!** With `python -O` asserts are **stripped** — for production invariants use `if` + `raise`.

---

## 7. EAFP vs LBYL

> **Definition:** **LBYL (Look Before You Leap)** checks preconditions first; **EAFP (Easier to Ask Forgiveness than Permission)** tries the operation and handles the expected exception if it fails.

**Why we need it:** Python often favors EAFP for clarity and, in concurrent code, to avoid races between check and use; sometimes `dict.get` or `in` is simpler than `try`/`except` for dicts.

**Syntax:**
```python
# LBYL
if key in d:
    val = d[key]

# EAFP
try:
    val = d[key]
except KeyError:
    val = default
```

| Style | What it means | Example |
|-------|------|---------|
| **LBYL** | "Look Before You Leap" — check first, then do | `if key in d: val = d[key]` |
| **EAFP** | "Easier to Ask Forgiveness" — just try it, handle error if it fails | `try: val = d[key] except KeyError: ...` |

Python idioms are often **EAFP** — in some multi-thread cases this also feels race-free.

```python
try:
    val = d[key]
except KeyError:
    val = default
```

```python
val = d.get(key, default)   # often cleanest for dicts
```

**Interview Tip:** `pop(key, default)` — avoids KeyError.

---

## 8. Traceback and logging

> **Definition:** A **traceback** is the stack of active calls printed when an exception propagates; **`traceback.print_exc()`** and **`logging.exception()`** record that stack for debugging.

**Why we need it:** Without the stack, you only see the error type and message; logging the full traceback pinpoints where and why the failure happened in production-like runs.

**Syntax:**
```python
import traceback

try:
    ...
except Exception:
    traceback.print_exc()

# or
import logging
logging.exception("message")  # includes traceback
```

```python
import traceback
try:
    1 / 0
except Exception:
    traceback.print_exc()
```

In production: `logging.exception("msg")` — stack trace included automatically.

---

## 9. `else` with try — common pattern

> **Definition:** In **`try` / `except` / `else`**, the **`else`** block runs only when the **`try`** completes **without** raising—so success-only work stays out of the bare `try` body.

**Why we need it:** Putting follow-up steps in `else` avoids accidentally catching bugs from those steps in the same `except` that handled the risky parse, and makes the success path obvious.

**Syntax:**
```python
try:
    ...
except SomeError:
    ...
else:
    # runs only if try had no exception
    ...
```

```python
try:
    data = parse(raw)
except ParseError:
    handle_bad()
else:
    save(data)   # only when parse succeeds
```

---

## 10. Exception notes — `ExceptionGroup` (3.11+ awareness)

> **Definition:** **`ExceptionGroup`** (Python 3.11+) bundles several exceptions so one `raise` can report multiple failures, often in concurrent or structured tasks.

**Why we need it:** When several subtasks fail together, a single exception chain can lose detail; grouping preserves every sub-exception for inspection and `except*` handling.

**Syntax:**
```python
raise ExceptionGroup("msg", [exc1, exc2])
# handling: except* SomeError:
```

Raising multiple errors at once — advanced async / structured concurrency scenarios. Rare in interviews unless the role is specific.

---

## 11. `suppress` context — clean style

> **Definition:** **`contextlib.suppress(ExcTypes...)`** is a context manager that catches the listed exception types inside the block and **ignores** them—no `try`/`except` boilerplate for optional cleanup.

**Why we need it:** “Delete if exists” or “close if open” patterns stay short and readable when failure is expected and harmless, without hiding unrelated errors.

**Syntax:**
```python
from contextlib import suppress

with suppress(FileNotFoundError):
    ...
```

```python
import os
from contextlib import suppress

with suppress(FileNotFoundError):   # If file not found, just ignore the error silently
    os.remove("tmp.txt")            # Try to delete — if it doesn't exist, no crash
```

**Watch Out!** Only when ignoring is **intentional** — don't hide real bugs.

---

## Quick Memory Card

```
+------------------------------------------+
| TRY / EXCEPT / ELSE / FINALLY            |
| - else = success path                    |
| - finally = always                       |
+------------------------------------------+
| SPECIFIC > BROAD                          |
| - bare except avoid                      |
+------------------------------------------+
| RAISE                                     |
| - from e chaining                        |
| - bare raise rethrow                     |
+------------------------------------------+
| CUSTOM                                    |
| - inherit Exception                      |
+------------------------------------------+
| ASSERT                                    |
| - not for security / -O strips           |
+------------------------------------------+
| EAFP vs LBYL                              |
| - dict.get often simpler                 |
+------------------------------------------+
```

---

*Next: [[11-Python-File-IO-Serialization]]*
