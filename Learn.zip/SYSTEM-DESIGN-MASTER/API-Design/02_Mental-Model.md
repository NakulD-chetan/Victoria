# API Design — Mental Model



---

## Consumer-First Thinking

**How to think about API design:**

1. **Who is the consumer?** Mobile app, web app, partner, internal service?
2. **What do they need?** Single resource? Nested data? Varying fields?
3. **How often?** High QPS? Batch? Real-time?
4. **Constraints?** Latency, payload size, caching?

> **FAANG Tip:** Start with "What would make the client's job easiest?" not "What's easiest for the server."

---

## REST: Nouns + Verbs

**Mental model:** Resources are nouns; HTTP methods are verbs.

```
    GET    /users/123        → "Give me user 123"
    POST   /users           → "Create a user"
    PUT    /users/123       → "Replace user 123"
    PATCH  /users/123       → "Update part of user 123"
    DELETE /users/123       → "Remove user 123"
```

**Rule:** URL = resource (noun). Method = action (verb). Never put verbs in the URL.


| Wrong              | Right            |
| ------------------ | ---------------- |
| `POST /getUser`    | `GET /users/123` |
| `GET /createOrder` | `POST /orders`   |


---

## GraphQL: Ask Exactly What You Need

**Mental model:** Client writes a query; server returns only requested fields.

```
    REST:    GET /users/123  → Returns 50 fields (over-fetch)
    REST:    GET /users/123, GET /orders?user=123  → 2 round-trips (under-fetch)
    
    GraphQL: query { user(id: 123) { name, email } }  → Exactly name + email
    GraphQL: query { user(id: 123) { name, orders { id, total } } }  → 1 request
```

**Rule:** One request, exact shape. No over-fetch, no under-fetch.

---

## gRPC: Efficient Internal Phone Calls

**Mental model:** Service-to-service calls in a compact binary format. Like a direct phone line between kitchens.

```
    REST/GraphQL:  JSON over HTTP — human-readable, larger
    gRPC:          Protobuf over HTTP/2 — binary, smaller, multiplexed
    
    Use when: Same company, internal services, need speed
```

**Rule:** Internal microservices, high throughput, streaming. Not for public/browser-first.

---

## API Versioning Decision Tree

```
    Need to break compatibility?
              │
       No ────┴──── Yes
       │            │
       ▼            ▼
    No versioning   How visible?
       needed            │
              URL ───────┼─────── Header/Query
              │          │
              ▼          ▼
         /v1/users   Accept-Version: 2
         (visible)   (cleaner URLs)
```


| Question           | Answer                        |
| ------------------ | ----------------------------- |
| Breaking change?   | Yes → Version (URL or header) |
| Public API?        | Prefer URL (`/v1/`)           |
| Clean URLs matter? | Use header or query param     |


---

---

## Decision Flowchart: API Choice

```mermaid
flowchart TD
    A[Designing API] --> B{Who is client?}
    B -->|Public / Partners| C[REST]
    B -->|Internal services| D{Need streaming?}
    B -->|Mobile / Web UI| E{Varied data needs?}
    D -->|Yes| F[gRPC]
    D -->|No| G[gRPC or REST]
    E -->|Yes, over/under-fetch pain| H[GraphQL]
    E -->|No, stable resources| C
    C --> I[Use HTTP cache, simple]
    H --> J[Schema, resolvers]
    F --> K[Protobuf, HTTP/2]
```



---

## API Choice Summary


| Scenario                             | Best Choice    |
| ------------------------------------ | -------------- |
| **Public API**                       | REST           |
| **Mobile app, varying screens**      | GraphQL        |
| **Internal microservices**           | gRPC           |
| **Real-time (chat, feeds)**          | WebSocket, SSE |
| **Simple CRUD, caching important**   | REST           |
| **Complex nested data, one request** | GraphQL        |


---



