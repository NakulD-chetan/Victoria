# Database Scaling — Tricks and Recognition

> **Permanent Recall:** Quick triggers for DB scaling: high read/write QPS, storage growth, connection exhaustion. Shard key heuristics: user_id/order_id for even distribution; avoid country, created_at. Replication: sync for financial, async for read scaling. Consistent hashing: 150–200 virtual nodes per physical node. When to use which: read bottleneck → replicas; write bottleneck → sharding; both → replicas + sharding.

---

## Quick Triggers for DB Scaling

| Signal | Interpretation | Action |
|--------|----------------|--------|
| **High read QPS** | DB CPU from reads | Read replicas, caching |
| **High write QPS** | Single master saturated | Sharding |
| **Storage growth** | Disk filling | Sharding, archival |
| **Connection exhaustion** | Too many conns to DB | Connection pooling, proxy |
| **Single point of failure** | Master dies = outage | Replication, failover |
| **Cross-DC latency** | Users far from DB | Read replicas in region, geo-sharding |

> **FAANG Tip:** "DB CPU at 80% from reads → add replicas. From writes → shard or vertical first."

---

## Shard Key Selection Heuristics

| Heuristic | Use | Avoid |
|-----------|-----|-------|
| **High cardinality** | `user_id`, `order_id`, UUID | `country`, `status` |
| **In query predicate** | Most queries filter by it | Key not in WHERE |
| **No hot spots** | Random/UUID distribution | `created_at` (recent hot) |
| **Co-location** | Related data same shard | Parent-child on different shards |

**Quick check:** "Will 80% of queries include this key in the WHERE clause? Is it high cardinality?"

---

## Replication Topology Selection Shortcuts

| Scenario | Topology | Sync/Async |
|----------|----------|------------|
| Read scaling, eventual consistency OK | Master-Slave | Async |
| Strong consistency (financial) | Master-Slave | Sync |
| Multi-region writes | Master-Master (careful) | Depends |
| Simple HA | Master-Slave + replicas | Async |

---

## Consistent Hashing: Virtual Node Count

**Rule:** 150–200 virtual nodes per physical node.

| Too few (e.g., 10) | Sweet spot (150–200) | Too many (1000+) |
|--------------------|----------------------|-----------------|
| Uneven distribution | Good balance | Overhead, no gain |

---

## When to Use Which Scaling Strategy

| Bottleneck | Strategy | Why |
|------------|----------|-----|
| **Reads** | Read replicas | Cheap, no schema change |
| **Reads (repeated)** | Caching | Faster than replicas |
| **Writes** | Vertical first | Simplest |
| **Writes (sustained)** | Sharding | Split write load |
| **Storage** | Sharding, archive | Split data |
| **Connections** | Connection pooling | Reuse connections |
| **HA** | Replication + failover | No single point of failure |

---

## Recognition: "Design for Scale" Interview Flow

When interviewer says "scale the database":

1. **Clarify:** Reads or writes? Current QPS? Storage?
2. **Order:** Vertical → Replicas → Cache → Shard
3. **Shard key:** If sharding, justify (cardinality, query pattern)
4. **Consistent hashing:** Mention for adding/removing shards
5. **Edge cases:** Lag, hot shard, cross-shard—mention mitigations

---

## Anti-Patterns (When NOT to Shard)

| Anti-pattern | Why |
|--------------|-----|
| Shard at 1K QPS | Overkill; vertical scale first |
| Shard by low-cardinality key | Hot spots, uneven |
| Need frequent cross-shard joins | Sharding makes it worse |
| No migration plan | Will lose data |

---

## Interview One-Liners

| Topic | One-liner |
|-------|-----------|
| **When to shard** | "Last resort, after vertical, replicas, cache." |
| **Shard key** | "High cardinality, in query predicate, no hot spots." |
| **Consistent hashing** | "Ring, 150–200 virtual nodes, minimal rehash on add/remove." |
| **Replication lag** | "Async = fast writes, stale reads. Sync = consistent, slower." |
| **Cross-shard** | "Avoid if possible; else saga or 2PC." |

---

## 30-SECOND REVISION BOX

```
TRIGGERS: Read QPS → replicas | Write QPS → shard | Storage → shard
SHARD KEY: user_id/order_id, high cardinality, in predicate
REPLICATION: Sync = financial | Async = read scaling
VIRTUAL NODES: 150–200 per physical
ORDER: Vertical → Replicas → Cache → Shard
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
