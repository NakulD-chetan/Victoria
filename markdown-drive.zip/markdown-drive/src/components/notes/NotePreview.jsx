import { useEffect, useRef, memo, useMemo } from 'react';
import { marked } from 'marked';
import mermaid from 'mermaid';
import CodeBlock from './CodeBlock';
import 'highlight.js/styles/github-dark.min.css';

mermaid.initialize({ startOnLoad: false, theme: 'dark', securityLevel: 'loose' });

function MermaidBlock({ code }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    const id = `mermaid-${Math.random().toString(36).slice(2, 8)}`;
    mermaid.render(id, code).then(({ svg }) => {
      if (ref.current) ref.current.innerHTML = svg;
    }).catch(() => {
      if (ref.current) ref.current.innerHTML = `<pre style="color:#ef4444;font-size:12px;">Mermaid syntax error</pre>`;
    });
  }, [code]);
  return <div ref={ref} className="sn-mermaid" />;
}

const CODE_PLACEHOLDER = '<!--CODE_BLOCK_';
const CODE_PLACEHOLDER_END = '-->';

function buildPreviewSections(body) {
  if (!body) return [];

  const codeBlocks = [];
  let index = 0;

  const renderer = new marked.Renderer();
  renderer.code = function ({ text, lang }) {
    const id = index++;
    codeBlocks.push({ id, code: text, lang: lang || '' });
    return `${CODE_PLACEHOLDER}${id}${CODE_PLACEHOLDER_END}`;
  };

  renderer.table = function ({ header, body }) {
    return `<div class="sn-table-wrapper"><table><thead>${header}</thead><tbody>${body}</tbody></table></div>`;
  };

  const html = marked.parse(body, { gfm: true, breaks: true, renderer });
  const parts = html.split(new RegExp(`${CODE_PLACEHOLDER}(\\d+)${CODE_PLACEHOLDER_END}`));

  const sections = [];
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      const prose = parts[i].trim();
      if (prose) sections.push({ type: 'html', html: prose });
    } else {
      const block = codeBlocks[parseInt(parts[i], 10)];
      if (block) {
        if (block.lang === 'mermaid') {
          sections.push({ type: 'mermaid', code: block.code });
        } else {
          sections.push({ type: 'code', code: block.code, lang: block.lang });
        }
      }
    }
  }
  return sections;
}

const NotePreview = memo(function NotePreview({ markdown, title, coverImage, tags, embedded = false }) {
  if (!markdown && !title) return (
    <div style={{ padding: 24, color: 'var(--text-secondary, #888)', textAlign: 'center' }}>
      Nothing to preview yet. Write some content first.
    </div>
  );

  const sections = useMemo(() => buildPreviewSections(markdown || ''), [markdown]);

  return (
    <div className={`ne-preview${embedded ? ' ne-preview--embedded' : ''}`}>
      {!embedded && coverImage && (
        <div style={{ width: '100%', height: 180, backgroundImage: `url(${coverImage})`, backgroundSize: 'cover', backgroundPosition: 'center', borderRadius: 8, marginBottom: 16 }} />
      )}
      {!embedded && title && <h1 style={{ fontSize: 28, fontWeight: 700, margin: '0 0 8px', color: 'var(--text-primary, #fff)' }}>{title}</h1>}
      {!embedded && tags?.length > 0 && (
        <div style={{ display: 'flex', gap: 6, marginBottom: 12, flexWrap: 'wrap' }}>
          {tags.map((t) => <span key={t} className="sn-tag">#{t}</span>)}
        </div>
      )}
      <div className="sn-content">
        {sections.map((sec, i) => {
          if (sec.type === 'mermaid') return <MermaidBlock key={i} code={sec.code} />;
          if (sec.type === 'code') return <CodeBlock key={i} code={sec.code} lang={sec.lang} />;
          return <div key={i} className="sn-prose" dangerouslySetInnerHTML={{ __html: sec.html }} />;
        })}
      </div>
    </div>
  );
});

export default NotePreview;
