# Aggregates and GROUP BY — Concept

> **Permanent recall:** Aggregates (`COUNT`, `SUM`, `AVG`, `MIN`, `MAX`) collapse rows **per group**. **`GROUP BY`** defines the **grain** (bucket key). **`HAVING`** filters groups.

---

## Aggregate Functions (complete list)

| Function | What it does | NULL handling |
|----------|-------------|---------------|
| `COUNT(*)` | Counts all rows (including NULLs) | Counts all |
| `COUNT(col)` | Counts non-NULL values in column | Ignores NULL |
| `COUNT(DISTINCT col)` | Counts unique non-NULL values | Ignores NULL |
| `SUM(col)` | Sum of all non-NULL values | Ignores NULL; returns NULL if all NULL |
| `AVG(col)` | Average of non-NULL values | Ignores NULL (denominator = non-NULL count) |
| `MIN(col)` | Smallest non-NULL value | Ignores NULL |
| `MAX(col)` | Largest non-NULL value | Ignores NULL |
| `GROUP_CONCAT(col)` | Concatenate values (MySQL) | Ignores NULL |
| `STRING_AGG(col, sep)` | Concatenate values (Postgres/SQL Server) | Ignores NULL |
| `ARRAY_AGG(col)` | Collect into array (Postgres) | Includes NULL by default |

---

## Grain rule

Every selected non-aggregated column must be in **`GROUP BY`** (standard SQL) — or be functionally dependent (MySQL permissive mode aside).

**Think:** "One row per what?" The GROUP BY columns define the answer.

---

## COUNT variants (interview favorite)

```sql
-- COUNT(*) = total rows (3)     → includes NULLs
-- COUNT(col) = non-null (2)     → skips NULLs  
-- COUNT(DISTINCT col) = unique non-null (2)

-- Given data: [10, 20, 20, NULL]
-- COUNT(*) = 4
-- COUNT(col) = 3
-- COUNT(DISTINCT col) = 2
```

---

## String Aggregation

Combine multiple row values into a single string:

```sql
-- MySQL
SELECT dept_id, GROUP_CONCAT(name ORDER BY name SEPARATOR ', ') AS members
FROM employees GROUP BY dept_id;

-- PostgreSQL / SQL Server
SELECT dept_id, STRING_AGG(name, ', ' ORDER BY name) AS members
FROM employees GROUP BY dept_id;
```

---

## ROLLUP / CUBE / GROUPING SETS (OLAP extensions)

| Feature | What it generates |
|---------|-------------------|
| **ROLLUP(a, b)** | Groups: (a,b), (a), () — hierarchical subtotals (drill-up) |
| **CUBE(a, b)** | Groups: (a,b), (a), (b), () — all combinations |
| **GROUPING SETS((a), (b))** | Explicit: only (a) and (b) groups |

```sql
-- ROLLUP: region → city → grand total
SELECT COALESCE(region, 'ALL') AS region,
       COALESCE(city, 'ALL') AS city,
       SUM(sales)
FROM store_sales
GROUP BY ROLLUP (region, city);
```

### GROUPING() function

Returns 1 if column is aggregated (NULL due to rollup), 0 if it's a real group:
```sql
SELECT region, city, SUM(sales),
       GROUPING(region) AS is_region_total,
       GROUPING(city) AS is_city_total
FROM sales GROUP BY ROLLUP(region, city);
```

---

## Conditional Aggregation (Pivot pattern)

Use `CASE WHEN` inside aggregate to compute different metrics:

```sql
SELECT 
    user_id,
    COUNT(CASE WHEN status = 'active' THEN 1 END) AS active_count,
    COUNT(CASE WHEN status = 'inactive' THEN 1 END) AS inactive_count,
    AVG(CASE WHEN type = 'premium' THEN amount END) AS avg_premium
FROM orders GROUP BY user_id;
```

This is how you **PIVOT** data without a PIVOT operator.

---

## FILTER Clause (Postgres)

Cleaner alternative to CASE in aggregates:

```sql
SELECT 
    COUNT(*) FILTER (WHERE status = 'active') AS active_count,
    AVG(amount) FILTER (WHERE type = 'premium') AS avg_premium
FROM orders;
```

---

## Double-count trap

Joining **fact** to **detail** before `SUM` can inflate amounts — **join at correct grain** or use subquery/`DISTINCT` strategy.

```sql
-- BAD: if order has 3 line items, order.amount counted 3 times
SELECT SUM(o.amount) FROM orders o JOIN line_items li ON o.id = li.order_id;

-- GOOD: aggregate at correct grain
SELECT SUM(amount) FROM orders;  -- or use DISTINCT
```

---

*Next: [[02_Mental-Model]]*
