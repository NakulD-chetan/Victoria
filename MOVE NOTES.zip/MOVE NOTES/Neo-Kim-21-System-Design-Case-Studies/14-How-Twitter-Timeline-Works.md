# How Twitter Timeline Works - System Design

> Source: https://newsletter.systemdesign.one/p/system-design-interview-twitter

## One-Line Summary
Twitter's timeline uses a hybrid push-pull fan-out model for backend delivery, combined with a frontend architecture focused on virtualized rendering, cursor-based pagination, and optimistic UI updates for real-time social media at scale.

## Key Requirements

### Functional
- Post tweets (text, images, videos)
- Home timeline (aggregated feed from followed accounts)
- User timeline (all tweets from one user)
- Like, retweet, reply
- Real-time updates (new tweets appear without refresh)
- Search tweets

### Non-Functional
- Low latency feed loading
- Handle millions of concurrent users
- High write throughput (thousands of tweets/sec)
- Eventual consistency acceptable for feed
- Real-time feel for interactions

## The Fan-Out Problem (Backend)

When a user posts a tweet, how do you deliver it to all their followers?

### Approach 1: Fan-Out on Read (Pull Model)
```
When User opens timeline:
  → Query: "Get latest tweets from all people I follow"
  → Merge and sort by timestamp
  → Return to client
```
- **Pros**: Write is cheap (just store tweet once)
- **Cons**: Read is expensive (query N followed users, merge, sort)
- **Good for**: Users with millions of followers (celebrities)

### Approach 2: Fan-Out on Write (Push Model)
```
When User posts tweet:
  → Push tweet to every follower's pre-computed timeline cache
  → When follower opens app, timeline is already ready
```
- **Pros**: Read is instant (timeline pre-computed)
- **Cons**: Write is expensive (celebrity with 50M followers = 50M writes)
- **Good for**: Normal users with fewer followers

### Twitter's Hybrid Approach
- **Normal users** (< threshold followers): fan-out on write (push to followers)
- **Celebrities** (millions of followers): fan-out on read (merge at read time)
- When you open timeline: pre-computed cache + live merge of celebrity tweets

## High-Level Architecture

```
Tweet Creation:
  Client → API → Tweet Service → DB + Fan-out Service
                                      |
                            Push to follower timeline caches
                            (for non-celebrity users)

Timeline Read:
  Client → API → Timeline Service
                      |
              Read pre-computed cache
                      +
              Merge celebrity tweets (on-the-fly)
                      |
              Return sorted timeline
```

## Frontend Architecture (RADIO Framework)

### 1. Architecture Layers
```
┌─────────────────────────────┐
│      View Layer (UI)         │  React components, virtual scroll
├─────────────────────────────┤
│    State Management          │  Global store (tweets, user, feed)
├─────────────────────────────┤
│     Data Fetching Layer      │  API client, caching, polling
├─────────────────────────────┤
│      Server APIs             │  REST/GraphQL endpoints
└─────────────────────────────┘
```

### 2. Feed Rendering Optimizations
- **DOM Virtualization**: Only render tweets visible in viewport
  - 1000 tweets loaded but only ~10 in DOM at a time
  - Huge memory and CPU savings
- **Infinite Scroll**: Load more tweets as user scrolls down
- **Cursor-based pagination**: each page returns `next_cursor` for next batch
- **Lazy loading**: images/videos load only when about to enter viewport

### 3. Data Model (Client-Side)
```
Tweet:
  tweet_id, author_id, content, media[], created_at,
  like_count, retweet_count, reply_count,
  is_liked (by current user), is_retweeted

Feed:
  tweets: Tweet[]
  next_cursor: string
  is_loading: boolean
  has_more: boolean

User:
  user_id, name, handle, avatar_url, follower_count
```

### 4. Optimistic Updates
- When user likes a tweet:
  1. **Immediately update UI** (heart turns red, count +1)
  2. Send API request in background
  3. If request fails → **rollback** UI change
- Creates instant feel for user interactions

### 5. Real-Time Updates
- **Polling**: check for new tweets every 30-60 seconds
- **WebSocket/SSE**: push new tweets from server (more efficient)
- Show "X new tweets" banner at top → click to load
- Don't auto-scroll (disrupts user reading)

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Hybrid fan-out (push + pull) | Balance write cost (celebrities) with read speed |
| Pre-computed timeline cache | Instant feed loading for most users |
| DOM virtualization | Render performance with thousands of tweets |
| Cursor-based pagination | Scalable infinite scroll (no skip-N problem) |
| Optimistic UI updates | Instant interaction feedback |
| Lazy loading media | Reduced initial bandwidth and load time |

## Scaling Strategies

1. **Hybrid fan-out**: push for normal users, pull for celebrities
2. **Timeline cache**: pre-computed per user, stored in Redis/Memcached
3. **DOM virtualization**: only render visible tweets (frontend performance)
4. **CDN** for media (images, videos, profile pictures)
5. **Cursor-based pagination**: scalable feed loading
6. **Async fan-out workers**: distribute the push load across worker pool

## Interview Tips

- Explain the **fan-out problem** first -- it's THE core challenge
- Know the **hybrid approach**: push for normal users, pull for celebrities
- If it's a frontend-focused interview, use the **RADIO framework** (Requirements, Architecture, Data, Interface, Optimizations)
- Mention **DOM virtualization** for rendering performance
- Discuss **optimistic updates** for like/retweet interactions
- Know **cursor-based pagination** vs offset (cursor is better at scale)
- Talk about real-time: polling vs WebSocket tradeoff
- Compare with Instagram (similar feed, more image-heavy)

## Quick Revision (5 bullet points)

1. **Hybrid fan-out**: push tweets to followers' caches for normal users; pull and merge at read time for celebrities (millions of followers)
2. **Pre-computed timeline cache** (Redis) makes feed loading instant; celebrity tweets merged on-the-fly during read
3. **DOM virtualization** renders only visible tweets (~10 in DOM out of 1000s loaded) for smooth scrolling performance
4. **Optimistic updates**: UI changes instantly on like/retweet; API call in background; rollback on failure
5. **Cursor-based pagination** for infinite scroll; lazy loading for media; "X new tweets" banner for real-time feel
