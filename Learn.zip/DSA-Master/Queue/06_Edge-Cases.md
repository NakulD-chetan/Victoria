# Queue — Edge Cases

> **Always consider these. Missing them = red flag in FAANG interviews.**

---

## 1. Empty Queue / Empty Input

### BFS

| Input | Behavior | Handle |
|-------|----------|--------|
| `root = null` | No nodes | Return `[]` or `0` |
| `graph = {}` | No edges | Return `[start]` only |
| `start` not in graph | — | Check or assume valid |

```python
def bfs(root):
    if not root:
        return []
    # ...
```

### Sliding Window

| Input | Behavior | Handle |
|-------|----------|--------|
| `arr = []` | No elements | Return `[]` |
| `k = 0` | Invalid | Return `[]` or clarify |
| `k > len(arr)` | Window larger than array | Return single window or `[]` |

```python
if not arr or k <= 0:
    return []
if k >= len(arr):
    return [max(arr)]  # or [min(arr)] — one window
```

### Circular Queue

| Input | Behavior |
|-------|----------|
| `k = 0` | Invalid capacity |
| Enqueue when full | Return false |
| Dequeue when empty | Return false / -1 |

---

## 2. Single Element

### BFS

```
Tree:    [1]        → Level 0: [1]
Graph:   {1: []}    → Start 1, no neighbors → result [1]
```

- Single node = single level
- No children → loop runs once, level = [root]

### Sliding Window

```
arr = [5], k = 1  → One window [5], result = [5]
arr = [5], k = 3  → k > n: one window or empty?
```

**Clarify:** Usually `k > n` → return `[]` or treat as window = whole array.

### Implement Queue Using Stacks

- Push one, pop one → works
- Empty after pop → `out_stack` empty, `in_stack` empty

---

## 3. Queue with All Same Elements

### Sliding Window Max/Min

```
arr = [3, 3, 3, 3], k = 2
Max: [3, 3, 3] — all 3s
Min: [3, 3, 3] — same
```

**Deque behavior:** New element not strictly greater (for max) → don't pop. Deque can hold multiple indices with same value. Front still valid.

**Potential bug:** Using `>` instead of `>=` when popping — with duplicates, might keep too many. Usually `>=` for max (pop when current >= back) ensures we keep rightmost index for same value (better for window boundary).

```python
# For max: arr[dq[-1]] < arr[i]  → pop (strict)
# Or:     arr[dq[-1]] <= arr[i]  → pop (keeps rightmost of equals)
```

---

## 4. BFS on Disconnected Graph

```
    A --- B        C --- D
    (component 1)  (component 2)
```

- BFS from A visits only A, B
- C, D never reached

**Handle:**
- "All nodes reachable from start" → single BFS OK
- "Visit all nodes" → loop over nodes, BFS from each unvisited
- "Number of components" → count BFS calls

```python
def all_components(graph):
    visited = set()
    components = 0
    for node in graph:
        if node not in visited:
            bfs_from(node, graph, visited)
            components += 1
    return components
```

---

## 5. Circular Queue Wrap-Around

```
k = 4, arr = [_, _, _, _]
Enqueue: 1, 2, 3, 4  → front=0, rear=3, full
Dequeue: 1           → front=1, rear=3
Enqueue: 5           → rear = (3+1)%4 = 0 (wrap!)
```

**Edge cases:**
- `rear = -1` initially → first enqueue: `rear = 0`
- `front` and `rear` can be equal when empty OR when full (if not tracking size)
- **Always track `size`** to distinguish empty vs full

---

## 6. Sliding Window: k = 1

```
arr = [1, 2, 3], k = 1
Windows: [1], [2], [3]
Result:  [1, 2, 3]
```

- Each element is its own window
- Deque: add i, remove i-1 (out of window), front = i
- Works correctly

---

## 7. Level-Order: All Nodes Same Level

```
Tree:    1
        / \
       2   3
```

- Level 0: [1]
- Level 1: [2, 3]
- Standard BFS handles this

---

## 8. Graph with Self-Loop

```
A → A
```

- BFS from A: visit A, add A to queue from A's neighbors
- **Visited set critical!** Without it: infinite loop
- With visited: A processed once, neighbor A already visited → skip

---

## 9. Negative Numbers in Sliding Window

```
arr = [-1, -3, -2], k = 2
Max: [-1, -2]  (max of [-1,-3], [-3,-2])
```

- Monotonic deque works with negatives
- No special handling needed

---

## 10. Very Large k in Sliding Window

```
arr = [1, 2, 3], k = 10
```

- k > n: one window = whole array, or return []
- Clarify with interviewer

---

## Edge Case Checklist

| Scenario | BFS | Monotonic Deque | Circular Queue |
|----------|-----|-----------------|----------------|
| Empty input | Return [] | Return [] | — |
| Single element | One level | One result | Enqueue/dequeue |
| All same | Works | Works | — |
| Disconnected | Multi-BFS | N/A | — |
| k > n | N/A | Clarify | N/A |
| k = 1 | N/A | Each elem | — |
| Self-loop | Visited! | N/A | — |

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:       if not root / not arr → return []
SINGLE:      One node / one window — no special case
SAME ELEMS:  Deque keeps indices; >= vs > for duplicates
DISCONNECT:  Loop nodes, BFS per unvisited
CIRCULAR:    Track size; (rear+1)%k for wrap
K>N:         Clarify: [] or full array
```
