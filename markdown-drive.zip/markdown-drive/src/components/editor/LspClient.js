let _reqId = 0;
function nextId() { return ++_reqId; }

const LANG_IDS = { cpp: 'cpp', python: 'python', java: 'java', javascript: 'javascript' };

function fileUri(workDir, filePath) {
  const normalized = filePath.replace(/\\/g, '/').replace(/^\//, '');
  const base = workDir.replace(/\\/g, '/');
  return `file:///${base.replace(/^\//, '')}/${normalized}`;
}

export class LspClient {
  constructor() {
    this.ws = null;
    this.monaco = null;
    this.disposables = [];
    this.pendingRequests = new Map();
    this.workDir = '';
    this.language = '';
    this.initialized = false;
    this.serverCapabilities = {};
    this.diagnosticsMap = new Map();
    this.onStatusChange = null;
    this._version = 0;
    this._reconnectTimer = null;
    this._openedDocs = new Set();
  }

  _mapFileName(filename) {
    const clean = filename.replace(/^\//, '');
    if (this.language === 'cpp' && !/\.(cpp|cc|cxx|c|h|hpp)$/i.test(clean)) {
      const base = clean.replace(/\.[^.]+$/, '') || clean;
      return base + '.cpp';
    }
    if (this.language === 'python' && !/\.py$/i.test(clean)) {
      const base = clean.replace(/\.[^.]+$/, '') || clean;
      return base + '.py';
    }
    return clean;
  }

  async start(monaco, language, files) {
    this.monaco = monaco;
    this.language = language;
    this._status('connecting');

    return new Promise((resolve) => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const isDev = import.meta.env.DEV;
      const host = isDev ? 'localhost:3001' : window.location.host;
      const wsUrl = `${protocol}//${host}/ws/lsp`;

      try {
        this.ws = new WebSocket(wsUrl);
      } catch (e) {
        console.error('[LSP] WebSocket creation failed:', e);
        this._status('error');
        resolve(false);
        return;
      }

      const connectTimeout = setTimeout(() => {
        this._status('unavailable');
        resolve(false);
      }, 15000);

      this.ws.onopen = () => {
        const fileContents = {};
        for (const [path, data] of Object.entries(files)) {
          fileContents[path] = data.content || '';
        }
        this.ws.send(JSON.stringify({ type: 'init', language, files: fileContents }));
      };

      this.ws.onmessage = (event) => {
        let msg;
        try { msg = JSON.parse(event.data); } catch { return; }

        if (msg.type === 'ready') {
          clearTimeout(connectTimeout);
          this.workDir = msg.workDir;
          this._initializeLsp().then(() => {
            this._status('active');
            resolve(true);
          }).catch((err) => {
            console.error('[LSP] Initialize failed:', err);
            this._status('error');
            resolve(false);
          });
        } else if (msg.type === 'unavailable') {
          clearTimeout(connectTimeout);
          this._status('unavailable');
          resolve(false);
        } else if (msg.type === 'lsp') {
          this._handleLspMessage(msg.data);
        } else if (msg.type === 'closed') {
          this._status('closed');
        } else if (msg.type === 'error') {
          clearTimeout(connectTimeout);
          this._status('error');
          resolve(false);
        }
      };

      this.ws.onerror = () => {
        clearTimeout(connectTimeout);
        this._status('error');
        resolve(false);
      };

      this.ws.onclose = () => {
        this._status('closed');
      };
    });
  }

  _status(s) {
    if (this.onStatusChange) this.onStatusChange(s);
  }

  _sendLsp(msg) {
    if (this.ws?.readyState === 1) {
      this.ws.send(JSON.stringify({ type: 'lsp', data: msg }));
    }
  }

  _request(method, params) {
    return new Promise((resolve, reject) => {
      const id = nextId();
      this.pendingRequests.set(id, { resolve, reject });
      this._sendLsp({ jsonrpc: '2.0', id, method, params });
      const timeout = method === 'initialize' ? 30000 : 10000;
      setTimeout(() => {
        if (this.pendingRequests.has(id)) {
          this.pendingRequests.delete(id);
          reject(new Error(`LSP timeout: ${method}`));
        }
      }, timeout);
    });
  }

  _notify(method, params) {
    this._sendLsp({ jsonrpc: '2.0', method, params });
  }

  _handleLspMessage(msg) {
    if (msg.id !== undefined && (msg.result !== undefined || msg.error !== undefined)) {
      const pending = this.pendingRequests.get(msg.id);
      if (pending) {
        this.pendingRequests.delete(msg.id);
        if (msg.error) pending.reject(msg.error);
        else pending.resolve(msg.result);
      }
    } else if (msg.method) {
      this._handleNotification(msg.method, msg.params);
    }
  }

  _handleNotification(method, params) {
    if (method === 'textDocument/publishDiagnostics') {
      this._applyDiagnostics(params);
    }
  }

  async _initializeLsp() {
    const result = await this._request('initialize', {
      processId: null,
      rootUri: `file:///${this.workDir.replace(/\\/g, '/').replace(/^\//, '')}`,
      capabilities: {
        textDocument: {
          synchronization: { dynamicRegistration: false, willSave: false, didSave: true, willSaveWaitUntil: false },
          completion: {
            dynamicRegistration: false,
            completionItem: {
              snippetSupport: true,
              commitCharactersSupport: true,
              documentationFormat: ['markdown', 'plaintext'],
              deprecatedSupport: true,
              preselectSupport: true,
              insertReplaceSupport: true,
              labelDetailsSupport: true,
              resolveSupport: { properties: ['documentation', 'detail', 'additionalTextEdits'] },
            },
            contextSupport: true,
          },
          hover: { dynamicRegistration: false, contentFormat: ['markdown', 'plaintext'] },
          signatureHelp: {
            dynamicRegistration: false,
            signatureInformation: {
              documentationFormat: ['markdown', 'plaintext'],
              parameterInformation: { labelOffsetSupport: true },
            },
          },
          definition: { dynamicRegistration: false },
          references: { dynamicRegistration: false },
          documentSymbol: { dynamicRegistration: false },
          codeAction: { dynamicRegistration: false },
          publishDiagnostics: { relatedInformation: true },
        },
        workspace: {
          workspaceFolders: false,
          didChangeWatchedFiles: { dynamicRegistration: false },
        },
      },
      initializationOptions: {},
      workspaceFolders: null,
    });

    this.serverCapabilities = result.capabilities || {};
    this._notify('initialized', {});
    this.initialized = true;
    this._registerProviders();
  }

  _registerProviders() {
    const monaco = this.monaco;
    const langId = LANG_IDS[this.language] || this.language;

    if (this.serverCapabilities.completionProvider) {
      const triggers = this.serverCapabilities.completionProvider.triggerCharacters || ['.', ':', '<', '"', '/', '#'];
      const d = monaco.languages.registerCompletionItemProvider(langId, {
        triggerCharacters: triggers,
        provideCompletionItems: async (model, position, context) => {
          try {
            const lineContent = model.getLineContent(position.lineNumber);
            const charBefore = position.column > 1 ? lineContent.charAt(position.column - 2) : '';
            const triggerKind = triggers.includes(charBefore) ? 2 : 1;

            const result = await this._request('textDocument/completion', {
              textDocument: { uri: this._modelUri(model) },
              position: { line: position.lineNumber - 1, character: position.column - 1 },
              context: {
                triggerKind,
                triggerCharacter: triggerKind === 2 ? charBefore : undefined,
              },
            });
            const items = Array.isArray(result) ? result : (result?.items || []);
            return {
              suggestions: items.map((item) => this._convertCompletionItem(monaco, item, model, position)),
              incomplete: !Array.isArray(result) && result?.isIncomplete === true,
            };
          } catch (e) {
            console.warn('[LSP] completion error:', e);
            return { suggestions: [] };
          }
        },
      });
      this.disposables.push(d);
    }

    if (this.serverCapabilities.hoverProvider) {
      const d = monaco.languages.registerHoverProvider(langId, {
        provideHover: async (model, position) => {
          try {
            const result = await this._request('textDocument/hover', {
              textDocument: { uri: this._modelUri(model) },
              position: { line: position.lineNumber - 1, character: position.column - 1 },
            });
            if (!result?.contents) return null;
            return {
              contents: this._convertHoverContents(result.contents),
              range: result.range ? this._convertRange(result.range) : undefined,
            };
          } catch (e) {
            console.warn('[LSP] hover error:', e);
            return null;
          }
        },
      });
      this.disposables.push(d);
    }

    if (this.serverCapabilities.signatureHelpProvider) {
      const triggers = this.serverCapabilities.signatureHelpProvider.triggerCharacters || ['(', ','];
      const d = monaco.languages.registerSignatureHelpProvider(langId, {
        signatureHelpTriggerCharacters: triggers,
        provideSignatureHelp: async (model, position) => {
          try {
            const result = await this._request('textDocument/signatureHelp', {
              textDocument: { uri: this._modelUri(model) },
              position: { line: position.lineNumber - 1, character: position.column - 1 },
            });
            if (!result?.signatures?.length) return null;
            return {
              value: {
                signatures: result.signatures.map((s) => ({
                  label: s.label,
                  documentation: s.documentation ? { value: typeof s.documentation === 'string' ? s.documentation : s.documentation.value } : undefined,
                  parameters: (s.parameters || []).map((p) => ({
                    label: p.label,
                    documentation: p.documentation ? { value: typeof p.documentation === 'string' ? p.documentation : p.documentation.value } : undefined,
                  })),
                })),
                activeSignature: result.activeSignature || 0,
                activeParameter: result.activeParameter || 0,
              },
              dispose: () => {},
            };
          } catch (e) {
            console.warn('[LSP] signatureHelp error:', e);
            return null;
          }
        },
      });
      this.disposables.push(d);
    }

    if (this.serverCapabilities.definitionProvider) {
      const d = monaco.languages.registerDefinitionProvider(langId, {
        provideDefinition: async (model, position) => {
          try {
            const result = await this._request('textDocument/definition', {
              textDocument: { uri: this._modelUri(model) },
              position: { line: position.lineNumber - 1, character: position.column - 1 },
            });
            if (!result) return null;
            const locations = Array.isArray(result) ? result : [result];
            return locations.map((loc) => ({
              uri: monaco.Uri.parse(loc.uri),
              range: this._convertRange(loc.range),
            }));
          } catch (e) {
            console.warn('[LSP] definition error:', e);
            return null;
          }
        },
      });
      this.disposables.push(d);
    }

    if (this.serverCapabilities.referencesProvider) {
      const d = monaco.languages.registerReferenceProvider(langId, {
        provideReferences: async (model, position, context) => {
          try {
            const result = await this._request('textDocument/references', {
              textDocument: { uri: this._modelUri(model) },
              position: { line: position.lineNumber - 1, character: position.column - 1 },
              context: { includeDeclaration: true },
            });
            if (!result) return [];
            return result.map((loc) => ({
              uri: monaco.Uri.parse(loc.uri),
              range: this._convertRange(loc.range),
            }));
          } catch (e) {
            console.warn('[LSP] references error:', e);
            return [];
          }
        },
      });
      this.disposables.push(d);
    }
  }

  _modelUri(model) {
    const filename = this._mapFileName(model.uri.path.replace(/^\//, ''));
    if (this.workDir) return fileUri(this.workDir, filename);
    return model.uri.toString();
  }

  _convertRange(range) {
    return new this.monaco.Range(
      range.start.line + 1, range.start.character + 1,
      range.end.line + 1, range.end.character + 1,
    );
  }

  _convertCompletionItem(monaco, item, model, position) {
    const kindMap = {
      1: monaco.languages.CompletionItemKind.Text,
      2: monaco.languages.CompletionItemKind.Method,
      3: monaco.languages.CompletionItemKind.Function,
      4: monaco.languages.CompletionItemKind.Constructor,
      5: monaco.languages.CompletionItemKind.Field,
      6: monaco.languages.CompletionItemKind.Variable,
      7: monaco.languages.CompletionItemKind.Class,
      8: monaco.languages.CompletionItemKind.Interface,
      9: monaco.languages.CompletionItemKind.Module,
      10: monaco.languages.CompletionItemKind.Property,
      11: monaco.languages.CompletionItemKind.Unit,
      12: monaco.languages.CompletionItemKind.Value,
      13: monaco.languages.CompletionItemKind.Enum,
      14: monaco.languages.CompletionItemKind.Keyword,
      15: monaco.languages.CompletionItemKind.Snippet,
      16: monaco.languages.CompletionItemKind.Color,
      17: monaco.languages.CompletionItemKind.File,
      18: monaco.languages.CompletionItemKind.Reference,
      19: monaco.languages.CompletionItemKind.Folder,
      20: monaco.languages.CompletionItemKind.EnumMember,
      21: monaco.languages.CompletionItemKind.Constant,
      22: monaco.languages.CompletionItemKind.Struct,
      23: monaco.languages.CompletionItemKind.Event,
      24: monaco.languages.CompletionItemKind.Operator,
      25: monaco.languages.CompletionItemKind.TypeParameter,
    };

    let range;
    let insertText;

    if (item.textEdit) {
      const te = item.textEdit;
      if (te.range) {
        range = this._convertRange(te.range);
      } else if (te.insert && te.replace) {
        range = {
          insert: this._convertRange(te.insert),
          replace: this._convertRange(te.replace),
        };
      }
      insertText = te.newText;

      if (insertText && range instanceof monaco.Range) {
        const lineContent = model.getLineContent(range.endLineNumber);
        const charAfter = lineContent.charAt(range.endColumn - 1);
        if (insertText.endsWith('>') && charAfter === '>') {
          range = new monaco.Range(range.startLineNumber, range.startColumn, range.endLineNumber, range.endColumn + 1);
        } else if (insertText.endsWith('"') && charAfter === '"') {
          range = new monaco.Range(range.startLineNumber, range.startColumn, range.endLineNumber, range.endColumn + 1);
        }
      }
    }

    if (!insertText) {
      insertText = item.insertText || (typeof item.label === 'string' ? item.label : item.label.label);
    }
    if (!range) {
      const word = model.getWordUntilPosition(position);
      range = new monaco.Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn);
    }

    const isSnippet = item.insertTextFormat === 2;
    const labelStr = typeof item.label === 'string' ? item.label : item.label.label;

    return {
      label: {
        label: labelStr,
        detail: item.labelDetails?.detail,
        description: item.labelDetails?.description || item.detail,
      },
      kind: kindMap[item.kind] || monaco.languages.CompletionItemKind.Text,
      detail: item.detail || '',
      documentation: item.documentation
        ? { value: typeof item.documentation === 'string' ? item.documentation : item.documentation.value }
        : undefined,
      insertText,
      filterText: item.filterText || labelStr,
      insertTextRules: isSnippet ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : undefined,
      range,
      sortText: item.sortText || labelStr,
      preselect: item.preselect,
      commitCharacters: item.commitCharacters,
      additionalTextEdits: item.additionalTextEdits?.map((edit) => ({
        range: this._convertRange(edit.range),
        text: edit.newText,
      })),
    };
  }

  _convertHoverContents(contents) {
    if (typeof contents === 'string') return [{ value: contents }];
    if (contents.kind) return [{ value: contents.value }];
    if (Array.isArray(contents)) {
      return contents.map((c) => {
        if (typeof c === 'string') return { value: c };
        if (c.language) return { value: `\`\`\`${c.language}\n${c.value}\n\`\`\`` };
        return { value: c.value || '' };
      });
    }
    if (contents.language) return [{ value: `\`\`\`${contents.language}\n${contents.value}\n\`\`\`` }];
    return [{ value: String(contents) }];
  }

  _applyDiagnostics(params) {
    const monaco = this.monaco;
    if (!monaco) return;

    const lspFilename = params.uri.split('/').pop();
    const allModels = monaco.editor.getModels();
    let model = null;
    for (const m of allModels) {
      const mName = m.uri.path.replace(/^\//, '');
      if (mName === lspFilename || this._mapFileName(mName) === lspFilename) {
        model = m;
        break;
      }
    }
    if (!model) return;

    const severityMap = {
      1: monaco.MarkerSeverity.Error,
      2: monaco.MarkerSeverity.Warning,
      3: monaco.MarkerSeverity.Info,
      4: monaco.MarkerSeverity.Hint,
    };

    const markers = (params.diagnostics || []).map((d) => {
      let endCol = d.range.end.character + 1;
      let endLine = d.range.end.line + 1;
      if (d.range.start.line === d.range.end.line && d.range.start.character === d.range.end.character) {
        endCol = d.range.end.character + 2;
      }
      return {
        severity: severityMap[d.severity] || monaco.MarkerSeverity.Error,
        startLineNumber: d.range.start.line + 1,
        startColumn: d.range.start.character + 1,
        endLineNumber: endLine,
        endColumn: endCol,
        message: d.message,
        source: d.source || (this.language === 'cpp' ? 'clangd' : 'pyright'),
        code: d.code ? String(d.code) : undefined,
        relatedInformation: d.relatedInformation?.map((ri) => ({
          resource: monaco.Uri.parse(ri.location.uri),
          startLineNumber: ri.location.range.start.line + 1,
          startColumn: ri.location.range.start.character + 1,
          endLineNumber: ri.location.range.end.line + 1,
          endColumn: ri.location.range.end.character + 1,
          message: ri.message,
        })),
      };
    });

    monaco.editor.setModelMarkers(model, 'lsp', markers);
    this.diagnosticsMap.set(params.uri, markers);
  }

  notifyDidOpen(filePath, content, languageId) {
    if (!this.initialized) return;
    const mapped = this._mapFileName(filePath);
    const uri = fileUri(this.workDir, mapped);

    if (this._openedDocs.has(uri)) return;
    this._openedDocs.add(uri);

    this._notify('textDocument/didOpen', {
      textDocument: {
        uri,
        languageId: LANG_IDS[this.language] || LANG_IDS[languageId] || languageId || 'plaintext',
        version: ++this._version,
        text: content,
      },
    });
  }

  notifyDidChange(filePath, content) {
    if (!this.initialized) return;
    const mapped = this._mapFileName(filePath);
    const uri = fileUri(this.workDir, mapped);

    if (!this._openedDocs.has(uri)) {
      this.notifyDidOpen(filePath, content, this.language);
      return;
    }

    this._notify('textDocument/didChange', {
      textDocument: { uri, version: ++this._version },
      contentChanges: [{ text: content }],
    });
    if (this.ws?.readyState === 1) {
      this.ws.send(JSON.stringify({ type: 'sync', path: filePath, content }));
    }
  }

  notifyDidClose(filePath) {
    if (!this.initialized) return;
    const mapped = this._mapFileName(filePath);
    const uri = fileUri(this.workDir, mapped);
    this._openedDocs.delete(uri);
    this._notify('textDocument/didClose', {
      textDocument: { uri },
    });
  }

  async stop() {
    this.initialized = false;
    if (this._reconnectTimer) {
      clearTimeout(this._reconnectTimer);
      this._reconnectTimer = null;
    }
    for (const d of this.disposables) { try { d.dispose(); } catch {} }
    this.disposables = [];
    for (const [uri] of this.diagnosticsMap) {
      try {
        const monacoUri = this.monaco?.Uri.parse(uri);
        const model = monacoUri ? this.monaco.editor.getModel(monacoUri) : null;
        if (model) this.monaco.editor.setModelMarkers(model, 'lsp', []);
      } catch {}
    }
    this.diagnosticsMap.clear();
    this.pendingRequests.clear();
    this._openedDocs.clear();
    if (this.ws) {
      try { this.ws.close(); } catch {}
      this.ws = null;
    }
  }
}
