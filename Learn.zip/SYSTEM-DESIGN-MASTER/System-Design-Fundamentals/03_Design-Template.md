# System Design Fundamentals — Design Template

> **Permanent Recall:** The universal template works for ANY system design problem: (1) Clarify requirements (functional + non-functional), (2) Back-of-envelope estimation (QPS, storage, bandwidth), (3) High-level design (main components), (4) Detailed design (deep dive critical path), (5) Address bottlenecks and failure modes. Never skip steps—each informs the next.

---

## The Universal System Design Template

Use this 5-step template for every problem. It structures your thinking and impresses interviewers.

---

## Step 1: Clarify Requirements (5–10 min)

### Checklist

| Item | Ask |
|------|-----|
| **Functional** | What are the core features? (e.g., post, read feed, follow, search) |
| **Scale** | DAU? Requests per second? Storage growth? |
| **Read vs Write** | Ratio? (e.g., Twitter ~300:1 read:write) |
| **Latency** | p99? Real-time vs batch? |
| **Consistency** | Strong or eventual? |
| **Scope** | In scope: notifications? Analytics? Search? |

> **FAANG Tip:** Write down assumptions. "Assuming 100M DAU, 500 tweets/user/day = 50B tweets/day..."

---

## Step 2: Back-of-Envelope Estimation (5 min)

### Formulas to Know

| Metric | Formula | Example |
|--------|---------|---------|
| **QPS** | (DAU × requests per user) / 86400 | 100M × 10 / 86400 ≈ 12K QPS |
| **Peak QPS** | QPS × 2–3 (traffic spikes) | 12K × 2 = 24K peak |
| **Storage (1 year)** | Records × bytes per record × 365 | 50B × 280 bytes × 1 ≈ 14 PB (with replicas) |
| **Bandwidth** | QPS × avg request/response size | 24K × 10 KB ≈ 240 MB/s |

### Estimation Template

```
DAU:            _______
Requests/user:  _______
QPS:            _______ (× 2–3 for peak)
Storage/day:    _______
Storage/year:   _______
```

---

## Step 3: High-Level Design (10–15 min)

### Draw Main Components

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    STANDARD ARCHITECTURE TEMPLATE                         │
└─────────────────────────────────────────────────────────────────────────┘

    [Clients]  ──────►  [Load Balancer]  ──────►  [App Servers]
                                                      │
                                                      ├──► [Cache]
                                                      │
                                                      └──► [Database]
                                                                │
                                                                └──► [Queue] (for async)
```

### Component Checklist

| Component | When to Add |
|-----------|-------------|
| Load Balancer | Multiple app servers |
| Cache | Read-heavy, hot data |
| Read Replicas | DB read bottleneck |
| Sharding | Storage or write bottleneck |
| Message Queue | Async processing, decoupling |
| CDN | Static assets, global users |
| Search Index | Full-text search |

---

## Step 4: Detailed Design (15–20 min)

### Deep Dive Checklist

- **Data model**: Schema, partitioning key, indexes
- **API design**: Endpoints, request/response format
- **Critical path**: Trace one request end-to-end
- **Scaling strategy**: How does each component scale?

> **FAANG Tip:** Pick 1–2 areas to go deep. "Let me dive into the feed generation logic since that's the core..."

---

## Step 5: Address Bottlenecks and Failure Modes (5–10 min)

| Concern | Mitigation |
|---------|------------|
| Single point of failure | Redundancy, failover |
| Hot keys | Partitioning, caching, local cache |
| DB overload | Read replicas, sharding, caching |
| Cascading failure | Circuit breakers, rate limiting |
| Data loss | Replication, backups, WAL |

---

## Example: Applying Template to "Design a Rate Limiter"

### Step 1: Clarify

- **Functional**: Limit requests per user/IP per time window
- **Scale**: 1M QPS, 100K unique users/sec
- **Latency**: < 1ms (in critical path)

### Step 2: Estimate

- 1M QPS → need distributed solution
- 100K users → need efficient key storage (user_id or IP)

### Step 3: High-Level

```
Client → API Gateway (rate limit check) → App Server
                    │
                    ▼
              [Redis / Sliding Window Log]
```

### Step 4: Detailed

- Algorithm: Token bucket vs sliding window log
- Redis: INCR + EXPIRE, or Lua script for atomicity
- Per-user vs per-IP vs per-API key

### Step 5: Failures

- Redis down? Fail open vs fail closed?
- Clock skew? Use Redis time
- Hot key? Shard by user_id prefix

---

## Reusable Step-by-Step Checklist

```
□ Step 1: Clarify
  □ Functional requirements listed
  □ Scale assumptions written (DAU, QPS, storage)
  □ Read:write ratio identified
  □ Latency/consistency requirements

□ Step 2: Estimate
  □ QPS calculated
  □ Storage estimated
  □ Bandwidth estimated

□ Step 3: High-Level
  □ Client → LB → App → Cache → DB drawn
  □ Each component justified
  □ Data flow clear

□ Step 4: Detailed
  □ Data model defined
  □ API contracts sketched
  □ Critical path traced

□ Step 5: Bottlenecks
  □ Single points of failure addressed
  □ Failure modes discussed
  □ Trade-offs stated
```

---

## Standard Architecture Diagram Template

```
                    ┌──────────────┐
                    │   Clients    │
                    │ (Web/Mobile) │
                    └──────┬───────┘
                           │
                           ▼
                    ┌──────────────┐
                    │ CDN (static) │
                    └──────┬───────┘
                           │
                           ▼
                    ┌──────────────┐
                    │ Load Balancer│
                    └──────┬───────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    ┌────────────┐  ┌────────────┐  ┌────────────┐
    │  App Svc 1 │  │  App Svc 2 │  │  App Svc N │
    └──────┬─────┘  └──────┬─────┘  └──────┬─────┘
           │               │               │
           └───────────────┼───────────────┘
                           │
                    ┌──────┴──────┐
                    │             │
                    ▼             ▼
             ┌──────────┐  ┌──────────────┐
             │  Cache   │  │  Message     │
             │ (Redis)  │  │  Queue       │
             └────┬─────┘  └──────┬───────┘
                  │               │
                  │               ▼
                  │        ┌──────────────┐
                  │        │   Workers    │
                  │        └──────┬───────┘
                  │               │
                  ▼               ▼
             ┌──────────────────────────┐
             │    Database (Primary +   │
             │    Read Replicas)         │
             └──────────────────────────┘
```

---

## Quick Memory Card

```
5 STEPS:    Clarify → Estimate → High-Level → Detailed → Bottlenecks
ESTIMATE:   QPS = DAU × req/user / 86400; Peak = 2–3×
TEMPLATE:   Client → LB → App → Cache → DB (+ Queue if async)
DEEP DIVE:  Pick 1–2 critical areas, trace end-to-end
FAILURES:   Always mention redundancy, failover, circuit breakers
```

---

**Next: [[04_Interview-Thinking]]**
