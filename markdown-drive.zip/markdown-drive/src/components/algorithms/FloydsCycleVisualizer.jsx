import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const FloydCanvas = forwardRef(function FloydCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ n: 0, next: [], slow: 0, fast: 0, phase: '' });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 300;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { n, next, slow, fast, phase } = stateRef.current;
      if (!n) {
        raf = requestAnimationFrame(draw);
        return;
      }
      const xs = [];
      const ys = [];
      const lineY = 120;
      const loopCx = W * 0.72;
      const loopCy = lineY;
      const loopR = 70;
      const lineLen = W * 0.45;
      for (let i = 0; i < n - 1; i++) {
        xs.push(40 + (i / Math.max(1, n - 2)) * lineLen);
        ys.push(lineY);
      }
      for (let i = 0; i < n; i++) {
        const isTail = i < n - 1;
        const x = isTail ? xs[i] : loopCx;
        const y = isTail ? ys[i] : loopCy - loopR;
        ctx.fillStyle = '#e0e7ff';
        ctx.strokeStyle = '#1c1917';
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.roundRect(x - 22, y - 16, 44, 32, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1c1917';
        ctx.font = 'bold 12px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(i), x, y);
        const t = next[i];
        if (t == null) continue;
        let tx;
        let ty;
        if (t < n - 1) {
          tx = xs[t];
          ty = ys[t];
        } else {
          const ang = Math.PI * 1.25;
          tx = loopCx + Math.cos(ang) * loopR;
          ty = loopCy + Math.sin(ang) * loopR;
        }
        ctx.beginPath();
        ctx.moveTo(x + 18, y);
        ctx.lineTo(tx - 18, ty);
        ctx.strokeStyle = '#78716c';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.arc(loopCx, loopCy, loopR, 0, Math.PI * 2);
      ctx.strokeStyle = '#94a3b8';
      ctx.setLineDash([6, 6]);
      ctx.stroke();
      ctx.setLineDash([]);

      function mark(idx, color, label) {
        let x;
        let y;
        if (idx < n - 1) {
          x = xs[idx];
          y = ys[idx];
        } else {
          const ang = Math.PI * 1.25;
          x = loopCx + Math.cos(ang) * loopR;
          y = loopCy + Math.sin(ang) * loopR;
        }
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(x, y, 26, 0, Math.PI * 2);
        ctx.stroke();
        ctx.fillStyle = color;
        ctx.font = 'bold 10px -apple-system, sans-serif';
        ctx.fillText(label, x, y - 32);
      }
      mark(slow, '#2f9e44', 'slow');
      mark(fast, '#e03131', 'fast');

      if (phase) {
        ctx.fillStyle = '#57534e';
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(phase, W / 2, 24);
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function buildList(n, cycleStart) {
  const next = Array(n).fill(null);
  for (let i = 0; i < n - 1; i++) next[i] = i + 1;
  next[n - 1] = cycleStart;
  return next;
}

function generateSteps(n, cycleStart) {
  const next = buildList(n, cycleStart);
  const steps = [];
  let slow = 0;
  let fast = 0;
  steps.push({ type: 'init', next, slow, fast, phase: 'slow+=1, fast+=2' });
  for (let t = 0; t < 20; t++) {
    slow = next[slow];
    fast = next[next[fast]];
    steps.push({ type: 'advance', next, slow, fast, phase: `Step ${t + 1}` });
    if (slow === fast) {
      steps.push({ type: 'meet', next, slow, fast, phase: 'Pointers meet — cycle detected' });
      break;
    }
  }
  steps.push({ type: 'done', next, slow, fast, phase: '✓ Floyd cycle detection' });
  return steps;
}

export default function FloydsCycleVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const n = 7;
    const cycleStart = 2;
    const steps = generateSteps(n, cycleStart);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `List length ${n}, tail links to node ${cycleStart}` });
    canvasRef.current?.setState({ ...steps[0] });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.phase || step.type });
    canvasRef.current?.setState({
      n: step.next.length,
      next: step.next,
      slow: step.slow,
      fast: step.fast,
      phase: step.phase,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={FloydCanvas} onInit={onInit} onStep={onStep} />;
}
