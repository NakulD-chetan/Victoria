import { useRef, useEffect, useCallback, useState, memo } from 'react';
import { useCanvasStore } from '../../stores/canvas-store';
import AppNavbar from '../shared/AppNavbar';
import CanvasTreeSidebar from './CanvasTreeSidebar';
import ExcalidrawCanvas from './ExcalidrawCanvas';
import { DS_SHAPES } from './dsLibrary';

const SYNC_LABELS = {
  idle: '—',
  pending: '● Unsaved',
  syncing: '↻ Syncing…',
  saved: '✓ Saved',
  error: '⚠ Sync error',
};

const CanvasApp = memo(function CanvasApp({ path, theme, onThemeToggle }) {
  const excalidrawRef = useRef(null);

  const canvases = useCanvasStore((s) => s.canvases);
  const folders = useCanvasStore((s) => s.folders);
  const openTabs = useCanvasStore((s) => s.openTabs);
  const activeCanvasId = useCanvasStore((s) => s.activeCanvasId);
  const elements = useCanvasStore((s) => s.elements);
  const files = useCanvasStore((s) => s.files);
  const cloudStatus = useCanvasStore((s) => s.cloudStatus);

  const setActiveCanvas = useCanvasStore((s) => s.setActiveCanvas);
  const closeTab = useCanvasStore((s) => s.closeTab);
  const createCanvas = useCanvasStore((s) => s.createCanvas);
  const setScene = useCanvasStore((s) => s.setScene);
  const loadFromCloud = useCanvasStore((s) => s.loadFromCloud);
  const refreshCanvasList = useCanvasStore((s) => s.refreshCanvasList);

  const [dsNodeCount, setDsNodeCount] = useState(5);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [dsMenuOpen, setDsMenuOpen] = useState(false);
  const moreMenuRef = useRef(null);
  const dsMenuRef = useRef(null);
  const prevActiveRef = useRef(activeCanvasId);

  // Initial load
  useEffect(() => {
    loadFromCloud();
    refreshCanvasList();
     
  }, []);

  // Push scene into Excalidraw when switching active canvas
  useEffect(() => {
    if (prevActiveRef.current !== activeCanvasId) {
      prevActiveRef.current = activeCanvasId;
      if (excalidrawRef.current) {
        excalidrawRef.current.updateScene(elements, files);
      }
    }
  }, [activeCanvasId, elements, files]);

  // Close dropdowns on outside click
  useEffect(() => {
    if (!moreMenuOpen && !dsMenuOpen) return;
    const onDoc = (e) => {
      if (moreMenuOpen && moreMenuRef.current && !moreMenuRef.current.contains(e.target)) {
        setMoreMenuOpen(false);
      }
      if (dsMenuOpen && dsMenuRef.current && !dsMenuRef.current.contains(e.target)) {
        setDsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [moreMenuOpen, dsMenuOpen]);

  const handleSceneChange = useCallback((els, f) => {
    setScene(els, f);
  }, [setScene]);

  const handleNewCanvas = useCallback(() => {
    const id = createCanvas('Untitled Canvas');
    if (id) setActiveCanvas(id);
  }, [createCanvas, setActiveCanvas]);

  const activeCanvas = canvases[activeCanvasId];
  const canvasName = activeCanvas ? activeCanvas.name : 'Untitled Canvas';

  const getCanvasPath = useCallback((id) => {
    const c = canvases[id];
    if (!c) return '';
    const parts = [c.name];
    let folderId = c.folderId;
    while (folderId && folders[folderId]) {
      parts.unshift(folders[folderId].name);
      folderId = folders[folderId].parentId;
    }
    return `/${parts.join('/')}`;
  }, [canvases, folders]);

  const handleExportPNG = useCallback(async () => {
    if (!excalidrawRef.current) return;
    try {
      const blob = await excalidrawRef.current.exportPNG();
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${canvasName || 'canvas'}.png`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Export failed:', e);
    }
  }, [canvasName]);

  return (
    <div className="obs-app cv-app">
      <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />

      <div className="obs-app__body">
        <CanvasTreeSidebar onNewCanvas={handleNewCanvas} onThemeToggle={onThemeToggle} />

        <div className="obs-main">
          <div className="obs-tabbar">
            <div className="obs-tabbar__left">
              <div className="obs-tabs">
                {openTabs.map((tabId) => {
                  const c = canvases[tabId];
                  if (!c) return null;
                  const isActive = tabId === activeCanvasId;
                  return (
                    <div
                      key={tabId}
                      className={`obs-tab ${isActive ? 'obs-tab--active' : ''}`}
                      onClick={() => setActiveCanvas(tabId)}
                      title={getCanvasPath(tabId)}
                    >
                      <span className="obs-tab__title">{c.name}</span>
                      <button
                        className="obs-tab__close"
                        onClick={(e) => { e.stopPropagation(); closeTab(tabId); }}
                      >
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <line x1="18" y1="6" x2="6" y2="18" />
                          <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                      </button>
                    </div>
                  );
                })}
              </div>

              <button className="obs-tabbar__new-btn" onClick={handleNewCanvas} title="New canvas">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </button>
            </div>

            <div className="obs-tabbar__right">
              <span className={`cv-sync-pill cv-sync-pill--${cloudStatus}`} title={`Cloud: ${cloudStatus}`}>
                {SYNC_LABELS[cloudStatus] || '—'}
              </span>

              <div className="cv-ds-wrap" ref={dsMenuRef}>
                <button
                  className={`obs-tabbar__icon-btn ${dsMenuOpen ? 'obs-tabbar__icon-btn--active' : ''}`}
                  onClick={() => setDsMenuOpen((v) => !v)}
                  title="DS Settings"
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="3" />
                    <path d="M12 1v3M12 20v3M4.22 4.22l2.12 2.12M17.66 17.66l2.12 2.12M1 12h3M20 12h3M4.22 19.78l2.12-2.12M17.66 6.34l2.12-2.12" />
                  </svg>
                </button>
                {dsMenuOpen && (
                  <div className="cv-ds-popover">
                    <div className="cv-ds-popover__header">DS Settings</div>
                    <label className="cv-ds-popover__label">
                      <span>Default nodes</span>
                      <input
                        type="number"
                        className="cv-ds-popover__input"
                        value={dsNodeCount}
                        min={1}
                        max={20}
                        onChange={(e) => {
                          const v = parseInt(e.target.value, 10);
                          if (!isNaN(v) && v >= 1 && v <= 20) setDsNodeCount(v);
                        }}
                      />
                    </label>
                    <div className="cv-ds-popover__presets">
                      {DS_SHAPES.map((ds) => (
                        <span key={ds.id} className="cv-ds-popover__preset">
                          {ds.name}: {ds.minSize}–{ds.maxSize}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <button
                className="obs-tabbar__icon-btn"
                onClick={handleExportPNG}
                title="Export as PNG"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
              </button>

              <button
                className={`obs-tabbar__icon-btn ${moreMenuOpen ? 'obs-tabbar__icon-btn--active' : ''}`}
                title="More options"
                onClick={() => setMoreMenuOpen((v) => !v)}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="5" r="1.5" />
                  <circle cx="12" cy="12" r="1.5" />
                  <circle cx="12" cy="19" r="1.5" />
                </svg>
              </button>
              {moreMenuOpen && (
                <div className="obs-more-menu" ref={moreMenuRef}>
                  <button onClick={() => { handleNewCanvas(); setMoreMenuOpen(false); }}>New canvas</button>
                  <button onClick={() => { handleExportPNG(); setMoreMenuOpen(false); }}>Export PNG</button>
                  {activeCanvasId && (
                    <button onClick={() => { closeTab(activeCanvasId); setMoreMenuOpen(false); }}>Close tab</button>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="cv-main">
            {activeCanvasId ? (
              <ExcalidrawCanvas
                ref={excalidrawRef}
                key={activeCanvasId}
                theme={theme}
                canvasId={activeCanvasId}
                canvasName={canvasName}
                initialElements={elements}
                initialFiles={files}
                onSceneChange={handleSceneChange}
                onExportPNG={handleExportPNG}
                dsNodeCount={dsNodeCount}
              />
            ) : (
              <div className="cv-empty">
                <div className="cv-empty__title">No canvas open</div>
                <div className="cv-empty__copy">Pick a canvas from the sidebar or create a new one.</div>
                <button className="cv-empty__btn" onClick={handleNewCanvas}>Create new canvas</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

export default CanvasApp;
