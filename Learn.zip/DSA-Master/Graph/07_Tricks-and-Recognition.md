# Graph — Tricks and Recognition

> **Permanent Recall:** Keywords → algorithm. "Prerequisites" = topo. "Shortest path" = BFS/Dijkstra. Matrix = grid graph. "Spread from multiple sources" = multi-source BFS.

---

## Keyword → Algorithm Mapping

| Keyword / Phrase | Algorithm | Why |
|------------------|-----------|-----|
| **Prerequisites, dependencies, build order** | Topological sort | Order tasks so dependencies come first |
| **Shortest path, minimum steps, minimum distance** | BFS (unweighted) or Dijkstra (weighted) | First reach = shortest |
| **Level order, distance layers, k steps away** | BFS | Level = distance in unweighted |
| **Reachability, can A reach B** | BFS or DFS | Either works |
| **All paths, explore all** | DFS | Backtracking, path enumeration |
| **Connected components, number of islands** | DFS or BFS | Each unvisited start = 1 component |
| **Cycle, circular dependency** | DFS (3-color or parent) or Union-Find | Back edge = cycle |
| **Rotten oranges, spread from multiple sources** | Multi-source BFS | Enqueue all sources at start |
| **Bipartite, two coloring** | BFS/DFS with color | Odd cycle = not bipartite |
| **Negative weights** | Bellman-Ford | Dijkstra fails |

---

## Hidden Graph Recognition

### 1. Matrix / Grid as Graph

```
Problem: "2D grid, move up/down/left/right"
→ Nodes = (r, c)
→ Edges = adjacent cells (4 or 8 dirs)
→ BFS/DFS for traversal
```

**Examples:** Number of Islands, Rotting Oranges, Shortest Path in Binary Matrix, Walls and Gates

### 2. Prerequisites / Dependencies

```
Problem: "Course A must be taken before B"
→ Nodes = courses/tasks
→ Edge A→B = A is prerequisite of B
→ Topological sort
```

**Examples:** Course Schedule I/II, Alien Dictionary, Build Order

### 3. Word / String Transitions

```
Problem: "Transform word A to B by changing one letter"
→ Nodes = words
→ Edge = 1-char difference
→ BFS for shortest transformation
```

**Examples:** Word Ladder I/II

### 4. State Space

```
Problem: "Jug problem, puzzle states"
→ Nodes = states
→ Edges = valid transitions
→ BFS for minimum steps
```

### 5. Tree as Graph

```
Problem: "Lowest common ancestor, distance between nodes"
→ Tree = directed graph (root→children)
→ DFS for LCA, BFS for distance
```

---

## Multi-Source BFS Recognition

**When:** Multiple starting points; "spread" or "infect" from all of them simultaneously.

```
    [2][1][1]     Start BFS from all 2's
    [1][1][0]     → Rotten oranges
    [0][1][1]
```

**Template:** Push all sources with distance 0; single BFS.

---

## BFS vs DFS Quick Choice

| Need | Use |
|------|-----|
| Shortest path (unweighted) | BFS |
| Level / distance | BFS |
| Path exists? | BFS or DFS |
| All paths / backtrack | DFS |
| Topological order | DFS (postorder) or Kahn's |
| Cycle | DFS |
| Components | BFS or DFS |

---

## Dijkstra Recognition

- **"Shortest path"** + **weighted** + **no negative** → Dijkstra
- **"Cheapest", "minimum cost", "minimum time"** → often Dijkstra
- **Matrix with cell weights** → Dijkstra on grid (nodes = cells, edges = adjacent)

---

## Union-Find Recognition

- **"Are u and v connected?"** — Union-Find
- **"Number of components"** — Union-Find or DFS
- **"Cycle in undirected graph"** — Union-Find (add edges; if same component, cycle)
- **"Dynamic connectivity"** — Union-Find

---

## Bipartite Recognition

- **"Two coloring", "no adjacent same"** → Bipartite check
- **"Possible to split into two groups with no edges within group"** → Bipartite
- **Odd cycle** → Not bipartite

---

## Trick: 0-Indexed Conversion

```
Input: "nodes 1 to n"
→ adj = [[] for _ in range(n+1)]
→ Use indices 1..n
→ Or: u-1, v-1 when building
```

---

## Trick: Node ID for Grid

```
(r, c) → id = r * cols + c
id → (id // cols, id % cols)
```

---

## Trick: In-Degree for Topo (Kahn's)

```
Build indeg[v] = count of edges → v
Start with indeg[u]==0
Remove node → decrement indeg of neighbors
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Tricks & Recognition
WHEN TO USE:       Problem reading, algorithm selection
CORE IDEA:         Keywords → algo; hidden graphs (matrix, prereqs, words)
TIME:              N/A
SPACE:             N/A
INTERVIEW SENTENCE: "Prerequisites suggest topo sort. Matrix suggests grid BFS.
                     Multi-source spread suggests multi-source BFS."
```

---

## 30-SECOND REVISION BOX

```
Prerequisites → Topo
Shortest path → BFS (unweighted) / Dijkstra (weighted)
Matrix → grid graph, BFS/DFS
Multi-source spread → multi-source BFS
Cycle → DFS 3-color / Union-Find
Components → DFS/BFS from each unvisited
```
