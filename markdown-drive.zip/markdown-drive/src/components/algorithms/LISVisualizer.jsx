import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const n = arr.length;
  const dp = Array(n).fill(1);
  const steps = [];
  const colLabels = arr.map((_, i) => i);

  const snap = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [arr, dp],
      rowLabels: ['A', 'dp'],
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('dp[i] = length of LIS ending at i (init 1)', {}, null, []);

  for (let i = 0; i < n; i += 1) {
    for (let j = 0; j < i; j += 1) {
      if (arr[j] < arr[i]) {
        const colors = { [`1-${i}`]: 'current', [`1-${j}`]: 'filling', [`0-${i}`]: 'filled', [`0-${j}`]: 'filled' };
        snap(`Relax: arr[${j}]<arr[${i}]`, colors, [1, i], [{ from: [1, j], to: [1, i] }]);
        dp[i] = Math.max(dp[i], dp[j] + 1);
      }
    }
    snap(`After index ${i}, dp[${i}] = ${dp[i]}`, { [`1-${i}`]: 'optimal' }, [1, i], []);
  }

  const best = Math.max(...dp);
  snap(`LIS length = ${best}`, Object.fromEntries(dp.map((_, i) => [`1-${i}`, 'optimal'])), [1, dp.indexOf(best)], []);
  return steps;
}

export default function LISVisualizer({ config }) {
  const arr = [10, 9, 2, 5, 3, 7, 101, 18];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(arr);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `LIS DP on [${arr.join(', ')}]` });
    canvasRef.current?.setState({
      table: [[0]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      caption: 'Longest increasing subsequence',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={DPCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
