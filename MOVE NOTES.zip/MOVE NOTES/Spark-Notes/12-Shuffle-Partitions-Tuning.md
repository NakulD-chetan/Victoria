# Shuffle Partitions Tuning

`spark.sql.shuffle.partitions` controls how many partitions Spark creates **after a shuffle**. Getting this right is critical for performance.

---

## Default Value

```python
spark.sql.shuffle.partitions = 200  # Spark's default
```

200 partitions after every `groupBy()`, `join()`, `distinct()`, `orderBy()`, etc.

But **200 is NOT optimal** for all workloads. Too few or too many partitions cause problems.

---

## The Golden Rule

```
Target: 100–200 MB per shuffle partition
```

Formula:
```
numPartitions = totalShuffleData (in MB) / 200 MB
```

---

## Scenario A: Partitions Too BIG (Common Problem)

**Setup**: 5 executors × 4 cores = 20 cores total. Shuffle data = 300 GB.

**With default 200 partitions:**
```
300 GB × 1024 / 200 = 1536 MB per partition = 1.5 GB per task
```

**Problems:**
- Each core processes 1.5 GB — very slow
- Huge disk spill (execution memory overflows)
- Long GC pauses
- Possible OOM errors

**Fix:**
```
numPartitions = (300 × 1024) / 200 = 1500

spark.conf.set("spark.sql.shuffle.partitions", "1500")
```
Now each partition ≈ 200 MB. Balanced, fast, no spills.

---

## Scenario B: Partitions Too SMALL (Also Bad)

**Setup**: 3 executors × 4 cores = 12 cores total. Shuffle data = 50 MB.

**With default 200 partitions:**
```
50 MB / 200 = 0.25 MB = 250 KB per partition
```

**Problems:**
- 200 tasks doing tiny work — wasted scheduling overhead
- Most cores idle (tasks finish instantly)
- Too many shuffle files created
- Driver overwhelmed managing 200 tasks

**Fix — Match cores for full parallelism:**
```
numPartitions = 12  (one per core)
50 MB / 12 = ~4 MB per partition

spark.conf.set("spark.sql.shuffle.partitions", "12")
```
All 12 cores busy, no idle resources.

---

## Best Formula for Choosing Shuffle Partitions

```
numPartitions = MIN(totalShuffleData / 200MB, totalCores × 3)
```

**Meaning:**
- Don't make partitions bigger than 200 MB (causes spills)
- Don't make fewer tasks than cores (wastes parallelism)
- Don't create way too many tiny partitions (scheduling overhead)
- The `× 3` factor allows for some parallelism overlap (wave scheduling)

---

## Impact on Memory

Shuffle partitions directly affect how much execution memory each task needs:

```
Large partitions → more data per task → more memory needed → spills to disk
Small partitions → less data per task → less memory needed → but more scheduling overhead
```

Tuning shuffle partitions **reduces spills drastically**, which is one of the biggest performance wins.

---

## AQE Fixes This Automatically (Spark 3.x)

With **Adaptive Query Execution** enabled:

```python
spark.conf.set("spark.sql.adaptive.enabled", "true")
```

AQE will:
- **Split large partitions** into smaller ones
- **Coalesce tiny partitions** into larger ones
- Auto-adjust partition count based on actual data size (not estimates)
- Target size per partition:

```python
spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 64MB  # default
```

This means in modern Spark 3.x, you can often leave shuffle.partitions at 200 and let AQE handle it. But understanding the tuning is still critical for interviews and debugging.

---

## Quick Decision Guide

| Shuffle Data Size | Recommended Partitions | Why                        |
|-------------------|-----------------------|----------------------------|
| < 100 MB          | 5–20                  | Match core count           |
| 100 MB – 10 GB    | 50–200                | Default works okay         |
| 10 GB – 100 GB    | 200–1000              | Keep ~200 MB per partition |
| 100 GB – 1 TB     | 1000–5000             | Prevent spills and OOM     |
| > 1 TB            | 5000+                 | Heavy parallelism needed   |

---

## Key Takeaway

> Shuffle partitions control parallelism after a shuffle. Keep each partition **100–200 MB**.
> Too few partitions → huge tasks, spills, OOM.
> Too many partitions → tiny tasks, scheduling overhead.
> Use AQE to auto-tune, but understand manual tuning for debugging and interviews.
