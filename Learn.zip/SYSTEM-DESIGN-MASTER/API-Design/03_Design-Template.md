# API Design — Design Template

> **Permanent Recall:** Reusable templates: REST (URL naming, HTTP methods, status codes, request/response format), GraphQL schema, gRPC proto, API gateway config, rate limiter, and auth flows (OAuth 2.0, JWT). Copy and adapt these patterns for interview designs and production APIs.

---

## REST API Design Template

**URL naming:**

```
    GET    /v1/users              # List
    GET    /v1/users/{id}         # Get one
    POST   /v1/users              # Create
    PUT    /v1/users/{id}         # Replace
    PATCH  /v1/users/{id}         # Partial update
    DELETE /v1/users/{id}         # Delete
    GET    /v1/users/{id}/orders   # Nested resource
```

**HTTP methods mapping:**


| Method | Action         | Idempotent |
| ------ | -------------- | ---------- |
| GET    | Read           | Yes        |
| POST   | Create         | No         |
| PUT    | Replace        | Yes        |
| PATCH  | Partial update | Yes        |
| DELETE | Delete         | Yes        |


**Request/response format:**

```json
// Request
POST /v1/orders
Content-Type: application/json
Idempotency-Key: uuid-xxx

{ "user_id": "123", "items": [...], "total": 99.99 }

// Success
201 Created
Location: /v1/orders/456
{ "id": "456", "user_id": "123", "status": "created", "created_at": "2025-03-10T12:00:00Z" }

// Error
400 Bad Request
{ "error": { "code": "VALIDATION_ERROR", "message": "user_id is required" } }
```

---

## GraphQL Schema Template

```graphql
type User {
  id: ID!
  name: String!
  email: String!
  orders: [Order!]!
}

type Order {
  id: ID!
  total: Float!
  items: [OrderItem!]!
}

type OrderItem {
  productId: ID!
  quantity: Int!
  price: Float!
}

type Query {
  user(id: ID!): User
  users(limit: Int, cursor: String): UserConnection!
}

type UserConnection {
  edges: [UserEdge!]!
  pageInfo: PageInfo!
}
type PageInfo { hasNextPage: Boolean! endCursor: String }

type Mutation {
  createOrder(input: CreateOrderInput!): Order!
}

input CreateOrderInput {
  userId: ID!
  items: [OrderItemInput!]!
}

input OrderItemInput {
  productId: ID!
  quantity: Int!
}
```

**Resolver pattern:** One resolver per field; fetch from DB or other service.

## gRPC Proto File Template

```protobuf
syntax = "proto3";

package api.v1;

service UserService {
  rpc GetUser (GetUserRequest) returns (User);
  rpc CreateUser (CreateUserRequest) returns (User);
  rpc ListUsers (ListUsersRequest) returns (stream User);
}

message GetUserRequest {
  string id = 1;
}

message CreateUserRequest {
  string name = 1;
  string email = 2;
}

message ListUsersRequest {
  int32 limit = 1;
  string cursor = 2;
}

message User {
  string id = 1;
  string name = 2;
  string email = 3;
}
```

---

## API Gateway Configuration Template

```yaml
# Conceptual API Gateway config
api:
  name: user-api
  base_path: /api/v1
  version: v1

routes:
  - path: /users
    methods: [GET, POST]
    backend: user-service:8080
    rate_limit: 100 req/min
    auth: required

  - path: /users/{id}
    methods: [GET, PATCH, DELETE]
    backend: user-service:8080
    rate_limit: 200 req/min
    auth: required

auth:
  type: jwt
  issuer: https://auth.example.com

rate_limiting:
  algorithm: token_bucket
  capacity: 100
  refill_rate: 10/sec
```

---

## Rate Limiter Implementation Template

```python
# Token bucket (conceptual)
class TokenBucket:
    def __init__(self, capacity: int, refill_rate: float):
        self.tokens = capacity
        self.capacity = capacity
        self.refill_rate = refill_rate
        self.last_refill = now()

    def allow(self) -> bool:
        self._refill()
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False

    def _refill(self):
        elapsed = now() - self.last_refill
        self.tokens = min(self.capacity, self.tokens + elapsed * self.refill_rate)
        self.last_refill = now()
```

---

## OAuth 2.0 Flow Template

```
CLIENT → Auth: Redirect → User login → Code → POST /token → access_token
Client → API: Bearer token → Resource
```

**Steps:** 1. Redirect to auth 2. User consent 3. Code back 4. Exchange code for token 5. Use token on API

---

## JWT Flow Template

```
1. Login → Auth validates → JWT (signed)
2. Client: Authorization: Bearer <jwt>
3. API: validate signature, exp → stateless
```

**JWT:** `header.payload.signature` — payload has `sub`, `exp`, `iat`

---



