import { create } from 'zustand';

export const useLeakyBucketStore = create((set) => ({
  capacity: 8,
  leakRate: 3,
  autoRate: 5,
  autoActive: false,
  currentLang: 'python',
  currentStep: null,
  accepted: 0,
  rejected: 0,
  total: 0,
  logs: [],
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setCapacity: (v) => set({ capacity: v }),
  setLeakRate: (v) => set({ leakRate: v }),
  setAutoRate: (v) => set({ autoRate: v }),
  toggleAuto: () => set((s) => ({ autoActive: !s.autoActive })),
  setLang: (lang) => set({ currentLang: lang }),
  setStep: (step) => set({ currentStep: step }),
  recordAccept: () => set((s) => ({ accepted: s.accepted + 1, total: s.total + 1 })),
  recordReject: () => set((s) => ({ rejected: s.rejected + 1, total: s.total + 1 })),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),
  reset: () => set({
    accepted: 0, rejected: 0, total: 0, currentStep: null, logs: [],
    autoActive: false, startTime: performance.now(),
  }),
}));
