import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const GAS = [1, 2, 3, 4, 5];
const COST = [3, 4, 5, 1, 2];

function generateSteps() {
  const steps = [];
  const n = GAS.length;
  for (let start = 0; start < n; start++) {
    let tank = 0;
    steps.push({ type: 'try', msg: `Try starting at station ${start}`, start, array: GAS.map((g, i) => g - COST[i]), tank: 0, colors: { [start]: 'pivot' } });
    let ok = true;
    for (let k = 0; k < n; k++) {
      const i = (start + k) % n;
      tank += GAS[i] - COST[i];
      steps.push({
        type: 'move',
        msg: `Station ${i}: tank ${tank}`,
        start,
        i,
        tank,
        array: GAS.map((g, idx) => g - COST[idx]),
        colors: { [i]: tank < 0 ? 'swap' : 'compare' },
      });
      if (tank < 0) {
        ok = false;
        steps.push({ type: 'fail', msg: `Cannot complete from ${start}`, start, i, tank, array: GAS.map((g, idx) => g - COST[idx]), colors: { [i]: 'swap' } });
        break;
      }
    }
    if (ok) {
      steps.push({ type: 'done', msg: `Start index ${start} works`, start, array: GAS.map((g, idx) => g - COST[idx]), colors: Object.fromEntries(GAS.map((_, idx) => [idx, 'sorted'])) });
      break;
    }
  }
  if (!steps.some((s) => s.type === 'done')) {
    steps.push({ type: 'done', msg: 'No valid start (sample)', array: GAS.map((g, idx) => g - COST[idx]), colors: {} });
  }
  return steps;
}

export default function GasStationVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray(steps[0].array);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Circular tour — net fuel per station' });
    canvasRef.current?.setState({ array: steps[0].array, colors: steps[0].colors || {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.setArray(step.array);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState({ array: step.array, colors: step.colors || {} });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
