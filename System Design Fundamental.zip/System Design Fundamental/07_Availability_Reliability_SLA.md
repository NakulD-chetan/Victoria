# Availability & Reliability — System Hamesha Chale, Sahi Chale

> **Availability = System accessible ho jab user chahiye | Reliability = System sahi result de**
> Dono alag cheezein hain! System "up" hai but galat data de raha ho (available but not reliable)

---

## Table of Contents
1. [Availability Kya Hai?](#1-availability-kya-hai)
2. [Nines of Availability](#2-nines-of-availability)
3. [Availability Calculation](#3-availability-calculation)
4. [Reliability Kya Hai?](#4-reliability-kya-hai)
5. [Availability vs Reliability](#5-availability-vs-reliability)
6. [Fault Tolerance](#6-fault-tolerance)
7. [Redundancy](#7-redundancy)
8. [Failover Mechanisms](#8-failover-mechanisms)
9. [Single Point of Failure (SPOF)](#9-single-point-of-failure-spof)
10. [SLA / SLO / SLI](#10-sla--slo--sli)
11. [Error Budgets](#11-error-budgets)
12. [Disaster Recovery](#12-disaster-recovery)
13. [Multi-Region Deployment](#13-multi-region-deployment)
14. [Real-World Examples](#14-real-world-examples)
15. [Interview Questions](#15-interview-questions)

---

## 1. Availability Kya Hai?

### Core Concept
**Availability** = System kitne time tak accessible hai? Jab user request kare, system respond kare?

**Formula:**
```
Availability = (Total Uptime) / (Total Time) × 100%
```

### Real World Analogy — Restaurant Open Hours
Socho ek restaurant hai:
- **Restaurant open hai** = Available (user order kar sakta hai)
- **Restaurant band hai** = Unavailable (user andar nahi kar sakta)

Agar restaurant 24 din mein 23 din open hai (1 din maintenance band), toh:
- Availability = 23/24 × 100% = **95.83%**

**Matlab yeh hai ki** — Availability sirf "system on hai ya nahi" measure karta hai. Galat data de raha hai ya sahi, yeh availability nahi dekhta!

### How It Works
```
User Request
    |
    v
[System Check]
    |
    +---> Response mila? --> YES --> Available
    |
    +---> Timeout/Error? --> NO --> Unavailable
```

### 1 Minute Recall Block
- Availability = Uptime / Total Time
- "System accessible hai" = Available
- Restaurant analogy: Open = Available, Closed = Unavailable

### 5 Bullet Memory Hooks
1. Availability = uptime percentage
2. Formula: Uptime / Total Time
3. Restaurant open/closed = Available/Unavailable
4. Sirf "reachable" hai ya nahi — correctness nahi
5. Measured in percentage (90%, 99%, 99.9%)

---

## 2. Nines of Availability

### Core Concept
Industry mein "nines" se availability express hoti hai. 99% = 2 nines, 99.9% = 3 nines.

### Downtime Table

| Nines | Availability | Downtime/Year | Downtime/Month | Downtime/Week |
|-------|--------------|---------------|----------------|---------------|
| 90%   | 1 nine       | 36.5 days     | 3 days         | 16.8 hours    |
| 99%   | 2 nines      | 3.65 days     | 7.2 hours      | 1.68 hours    |
| 99.9% | 3 nines      | 8.76 hours    | 43.2 min       | 10.08 min     |
| 99.95%| 3.5 nines    | 4.38 hours    | 21.6 min       | 5.04 min      |
| 99.99%| 4 nines      | 52.56 min     | 4.32 min       | 1.01 min      |
| 99.999%| 5 nines    | 5.26 min      | 26 sec         | 6 sec         |

### Real World Example
- **Netflix**: 99.99% (4 nines) — saal mein ~53 min downtime allowed
- **Banking**: 99.99%+ — paisa ka mamla hai!
- **Gmail**: 99.9% — email thoda late aa jaye, acceptable
- **Internal tools**: 99% — kabhi kabhi band ho, chalega

### Common Interview Trap
**"99.9% vs 99.99% — difference kya hai?"**
- 99.9% = 8.76 hours/year downtime
- 99.99% = 52.56 min/year downtime
- 10x difference! 99.99% achieve karne ke liye 10x more complexity

### 1 Minute Recall Block
- 2 nines (99%) = 3.65 days/year downtime
- 3 nines (99.9%) = 8.76 hours/year
- 4 nines (99.99%) = 52 min/year
- 5 nines (99.999%) = 5.26 min/year — bahut mushkil!

### 5 Bullet Memory Hooks
1. More nines = less downtime
2. 99.9% → 8.76 hours/year
3. 99.99% → 52 min/year
4. 5 nines = 5 min/year — very expensive
5. Banking/Finance = 4+ nines required

---

## 3. Availability Calculation

### Series vs Parallel — Critical Concept!

```
SERIES (Components in sequence):
    User --> [A] --> [B] --> [C] --> Response
    Sab components chahiye! Ek fail = sab fail
    
    Availability = A_avail × B_avail × C_avail
    Example: 0.99 × 0.99 × 0.99 = 97.03%
    (Worse than individual!)

PARALLEL (Redundant components):
    User --> [A] --> Response
    User --> [B] --> Response
    Koi ek bhi chalega!
    
    Availability = 1 - (1-A_avail) × (1-B_avail)
    Example: 1 - (0.01 × 0.01) = 99.99%
    (Better than individual!)
```

### Real World Analogy — Restaurant Kitchen
- **Series**: Order → Waiter → Chef → Waiter → Customer
  - Chef sick hai toh koi order nahi jayega
- **Parallel**: 2 chefs, koi ek bhi order bana sakta hai
  - Dono sick hone ka chance kam

### Formula Summary
| Configuration | Formula | Effect |
|---------------|---------|--------|
| Series (A→B→C) | A × B × C | Availability decreases |
| Parallel (A \|\| B) | 1 - (1-A)(1-B) | Availability increases |

### 1 Minute Recall Block
- Series = multiply availabilities (worse)
- Parallel = 1 - (1-A)(1-B) (better)
- More components in series = more failure points

### 5 Bullet Memory Hooks
1. Series = multiply → availability ghatti hai
2. Parallel = redundancy → availability badhti hai
3. 2 components 99% parallel = 99.99%
4. 3 components 99% series = 97.03%
5. Design parallel for critical path

---

## 4. Reliability Kya Hai?

### Core Concept
**Reliability** = System sahi result de, correct output de. Agar kuch fail ho toh bhi consistent/correct state.

### Real World Analogy — Food Safe to Eat
- **Restaurant available** = Open hai (availability)
- **Food safe** = Khana kha sakte ho (reliability)

Restaurant open hai but food poisoned hai toh:
- Available = YES
- Reliable = NO

### How It Works
```
Reliability = Correctness + Consistency
- Data corruption nahi
- Wrong calculation nahi
- Partial failures handle ho
- User ko galat result nahi mile
```

### Availability vs Reliability
| Scenario | Available? | Reliable? |
|----------|------------|-----------|
| System up, correct data | YES | YES |
| System up, corrupted data | YES | NO |
| System down | NO | N/A |
| System up, stale data | YES | Depends |

### 1 Minute Recall Block
- Reliability = correctness + consistency
- Available but wrong data = not reliable
- Banking: Both critical

### 5 Bullet Memory Hooks
1. Reliability = sahi result
2. Available ≠ Reliable
3. Corrupted data = unreliable
4. Consistency part of reliability
5. Critical systems need both

---

## 5. Availability vs Reliability

### Key Difference
```
AVAILABILITY = "Can I reach it?"
RELIABILITY  = "Can I trust the response?"
```

### Venn Diagram (ASCII)
```
    +------------------+
    |   AVAILABLE      |
    |  (System reachable)|
    |    +--------+    |
    |    |RELIABLE|    |
    |    |(Correct|    |
    |    | result)|    |
    |    +--------+    |
    |                  |
    |  Available but   |
    |  NOT reliable    |
    +------------------+
```

### Real World Example
- **Netflix**: Available (stream chal raha) but video corrupted pixels = Available but not Reliable
- **Banking**: Transfer hua but wrong amount = Available but not Reliable — disaster!

### Common Interview Trap
**"99.9% availability hai, toh reliable bhi hai?"**
NO! Availability sirf uptime. Reliability alag metric — correctness, consistency.

### 1 Minute Recall Block
- Availability = reachable
- Reliability = correct + consistent
- Dono independent — design for both

### 5 Bullet Memory Hooks
1. Availability = uptime percentage
2. Reliability = correctness guarantee
3. System up + wrong data = available, unreliable
4. Design for both in critical systems
5. Different metrics, different solutions

---

## 6. Fault Tolerance

### Core Concept
**Fault Tolerance** = System fail hone pe bhi kaam kare. Components fail ho jayein, system overall chalta rahe.

### Real World Analogy — Car
- Car ek tyre puncture hota hai → 3 tyres bache
- Car chal sakti hai (fault tolerant)
- Spare tyre = redundancy
- Failover = puncture hone pe spare lagana

### How It Works
```
Normal:     [Request] --> [Primary] --> [Response]
                 
Fault:      [Request] --> [Primary FAIL] --> [Standby] --> [Response]
                              |
                              +--> Failover triggered
```

### Fault Tolerance Techniques
1. **Redundancy** — Multiple copies
2. **Failover** — Backup activate
3. **Replication** — Data multiple copies
4. **Circuit Breaker** — Fail fast, don't cascade
5. **Graceful Degradation** — Kam features par bhi chal

### 1 Minute Recall Block
- Fault tolerant = fail hone par bhi kaam
- Redundancy + Failover = main techniques
- Graceful degradation = partial service

### 5 Bullet Memory Hooks
1. Fault tolerance = survive failures
2. Redundancy = backup components
3. Failover = switch to backup
4. No cascade failures
5. Graceful degradation option

---

## 7. Redundancy

### Types of Redundancy

#### Active-Active
```
    [User] --> [Server A] --> Response
           --> [Server B] --> Response
           
    Dono simultaneously active, load share karte hain
    + Fast failover (no startup)
    + Better resource utilization
    - Complex data sync
    - Both need same state
```

#### Active-Passive
```
    [User] --> [Server A - Active] --> Response
           
    [Server B - Passive/Standby] (idle, waiting)
    
    A fail hone par B activate
    + Simpler state management
    - Wasted resources (B idle)
    - Failover time (B cold start)
```

#### N+1 Redundancy
```
    N servers = load handle karne ke liye
    +1 extra = backup
    
    Example: 4 servers load handle, 4th fail = 5th backup
    Need 5 servers for 4 servers worth of load
```

### Comparison Table
| Type | Resource Use | Failover Speed | Complexity | Use Case |
|------|--------------|----------------|------------|----------|
| Active-Active | Efficient | Instant | High | Stateless, APIs |
| Active-Passive | Waste (standby idle) | Slower | Low | Databases |
| N+1 | Moderate | Depends | Medium | Web servers |

### Real World Example
- **Netflix**: Active-Active across regions
- **Database**: Active-Passive (primary + replica)
- **Load balancers**: N+1 (4 servers + 1 backup)

### 1 Minute Recall Block
- Active-Active = both serve, instant failover
- Active-Passive = one idle, slower failover
- N+1 = N for load + 1 backup

### 5 Bullet Memory Hooks
1. Active-Active = parallel serving
2. Active-Passive = standby backup
3. N+1 = N + 1 backup server
4. Active-Active = stateless preferred
5. DB = usually Active-Passive

---

## 8. Failover Mechanisms

### Cold Standby
```
Primary: [Running]
Standby: [OFF - not running]

Failover: Start standby, configure, switch
Time: Minutes to hours
Cost: Cheapest
```

### Warm Standby
```
Primary: [Running]
Standby: [Running but idle, data synced]

Failover: Activate standby, switch traffic
Time: Seconds to minutes
Cost: Medium
```

### Hot Standby
```
Primary: [Running]
Standby: [Running, fully synced, ready]

Failover: Instant switch
Time: Milliseconds
Cost: Highest (2x resources)
```

### Comparison
| Type | Startup State | Failover Time | Cost | Example |
|------|---------------|---------------|------|---------|
| Cold | OFF | Min-Hours | Low | DR site |
| Warm | Running, idle | Sec-Min | Medium | DB replica |
| Hot | Running, synced | Instant | High | HA pairs |

### Real World Analogy
- **Cold**: Spare tyre trunk mein (lagana padega)
- **Warm**: Spare tyre ready, inflated par lagana padega
- **Hot**: Dono wheels same speed par chal rahe (instant switch)

### 1 Minute Recall Block
- Cold = OFF, slowest
- Warm = ON idle, medium
- Hot = ON ready, instant

### 5 Bullet Memory Hooks
1. Cold = minutes to hours
2. Warm = seconds to minutes
3. Hot = milliseconds
4. Hot = 2x cost
5. Choose based on RTO

---

## 9. Single Point of Failure (SPOF)

### Core Concept
**SPOF** = Ek component fail = whole system fail. Identify karo aur eliminate karo!

### How to Identify SPOF
```
    [User] --> [LB] --> [App1] --> [DB]
                    --> [App2]      |
                    --> [App3]      |
                                    v
                              SPOF! Single DB
```

### Common SPOFs
- Single database
- Single load balancer
- Single network link
- Single power supply
- Single region deployment

### How to Eliminate
| SPOF | Solution |
|------|----------|
| Single DB | Database replication, failover |
| Single LB | LB cluster, DNS failover |
| Single network | Multiple ISPs |
| Single region | Multi-region |

### Real World Example
- **AWS us-east-1 outage**: Single region = SPOF for many services
- **Solution**: Multi-region deploy

### Common Interview Trap
**"System design mein SPOF kahan hai?"**
Always trace the path — har component ke liye poocho: "Yeh fail ho jaye toh?"

### 1 Minute Recall Block
- SPOF = one failure = system down
- Trace request path
- Eliminate with redundancy

### 5 Bullet Memory Hooks
1. SPOF = single failure point
2. Trace full request path
3. DB = common SPOF
4. Solution = redundancy
5. Multi-region = region SPOF fix

---

## 10. SLA / SLO / SLI

### The Hierarchy
```
    SLI (Measure) --> SLO (Target) --> SLA (Contract)
    
    SLI = Kya measure karte ho
    SLO = Kya target hai
    SLA = Customer se contract (penalty if breach)
```

### SLI — Service Level Indicator
**What you measure**
- p99 latency
- Error rate
- Availability percentage
- Throughput

### SLO — Service Level Objective
**Your internal target**
- 99.9% availability
- p99 latency < 200ms
- Error rate < 0.1%

### SLA — Service Level Agreement
**Contract with customer**
- 99.5% uptime or refund
- Penalties defined
- Legal binding

### Comparison
| Term | What | Who | Example |
|------|------|-----|---------|
| SLI | Metric | Engineering | p99 = 150ms |
| SLO | Target | Internal | p99 < 200ms |
| SLA | Contract | Customer | 99.5% or refund |

### Real World Example
- **SLI**: Measure API response time
- **SLO**: Target 99.9% requests < 500ms
- **SLA**: Promise customer 99.5% uptime, refund if fail

### Common Interview Trap
**"SLA aur SLO mein difference?"**
SLA = customer contract with penalties. SLO = internal target. SLO usually stricter than SLA!

### 1 Minute Recall Block
- SLI = measure
- SLO = target (internal)
- SLA = contract (with penalty)

### 5 Bullet Memory Hooks
1. SLI = what you measure
2. SLO = target (internal)
3. SLA = contract (with penalty)
4. SLO > SLA (stricter internal)
5. SLA breach = penalty/refund

---

## 11. Error Budgets

### Core Concept
**Error Budget** = 100% - SLO

Agar SLO = 99.9%, Error Budget = 0.1% = 43.2 min/month

### How It Works
```
Month start: 100% budget
Each failure: Budget consumed
Budget exhausted: Freeze releases, fix reliability

Philosophy: "Enough reliability" not "perfect"
```

### Real World Example
- SLO 99.9% = 43 min downtime allowed/month
- 20 min outage = 20/43 budget used
- 30 min more = budget exhausted = no new features, focus on reliability

### 1 Minute Recall Block
- Error budget = 100% - SLO
- 99.9% SLO = 0.1% = 43 min/month
- Exhausted = no releases

### 5 Bullet Memory Hooks
1. Error budget = allowed failures
2. 99.9% → 0.1% = 43 min/month
3. Exhausted = reliability focus
4. Balances velocity vs reliability
5. Google popularized this

---

## 12. Disaster Recovery

### RPO — Recovery Point Objective
**Kitna data loss acceptable?**

```
Last backup: 2 hours ago
System fails: NOW
RPO = 2 hours (max 2 hours data loss)
```

### RTO — Recovery Time Objective
**Kitne time mein recover ho?**

```
System fails: 10:00 AM
Recovery complete: 2:00 PM
RTO = 4 hours

Matlab: 4 hours tak system down reh sakta hai
```

### Comparison
| Term | Question | Example |
|------|----------|---------|
| RPO | Kitna data loss? | 1 hour backup = 1 hour RPO |
| RTO | Kitne time recover? | 4 hour recovery = 4 hour RTO |

### Real World Example
- **Banking**: RPO = 0 (no data loss), RTO = minutes
- **Blog**: RPO = 24 hours, RTO = 24 hours (acceptable)

### 1 Minute Recall Block
- RPO = data loss acceptable
- RTO = recovery time acceptable
- Lower = more expensive

### 5 Bullet Memory Hooks
1. RPO = recovery point (data loss)
2. RTO = recovery time
3. RPO 0 = continuous backup
4. RTO low = hot standby needed
5. Banking = both very low

---

## 13. Multi-Region Deployment

### Core Concept
Multiple geographic regions mein deploy karo. Ek region fail = other serve kare.

```
    [Region US-East]    [Region EU]    [Region Asia]
           |                 |               |
           +--------+--------+---------------+
                    |
              [Global LB / DNS]
                    |
                 [Users]
```

### Benefits
- Fault tolerance (region failure)
- Lower latency (user ke paas)
- Compliance (data residency)
- Disaster recovery

### Challenges
- Data consistency
- Cost (2-3x)
- Complexity

### 1 Minute Recall Block
- Multi-region = geographic redundancy
- Region fail = other serves
- Data sync tricky

### 5 Bullet Memory Hooks
1. Multi-region = geographic redundancy
2. AWS us-east-1 fail = other regions serve
3. Latency + compliance benefits
4. Cost 2-3x
5. Consistency challenge

---

## 14. Real-World Examples

### AWS Outages
- **us-east-1** (Virginia) — bahut services use karte hain
- Single region dependency = SPOF
- **Lesson**: Multi-region critical

### Banking Systems
- 99.99%+ availability
- RPO = 0 (no data loss)
- Active-Active across data centers
- Real-time replication

### 1 Minute Recall Block
- AWS = multi-region lesson
- Banking = highest availability

---

## 15. Interview Questions

### Quick Recall
1. **Availability vs Reliability?** — Available = reachable, Reliable = correct
2. **99.9% downtime?** — 8.76 hours/year
3. **Series vs Parallel?** — Series multiply, Parallel 1-(1-A)(1-B)
4. **SPOF?** — Single failure = system down
5. **SLI vs SLO vs SLA?** — Measure, Target, Contract
6. **RPO vs RTO?** — Data loss, Recovery time
7. **Active-Active vs Active-Passive?** — Both serve vs standby

### Common Questions
- Design system for 99.99% availability
- How to eliminate SPOF?
