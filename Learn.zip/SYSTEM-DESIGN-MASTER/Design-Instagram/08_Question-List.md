# Design Instagram — Question List

> **Permanent Recall:** Instagram variations often add **stories**, **Reels**, **content moderation**, **explore**, or scale to **1B users**. Related designs: Pinterest, Flickr, TikTok — all media-heavy with different discovery models.

---

## Core Variations

| Question | Focus | Difficulty |
|----------|-------|------------|
| Design Instagram | Full system | Medium |
| Add **stories** feature to Instagram | Ephemeral content, TTL | Medium |
| Design **Instagram Reels** | Short-form video, recommendations | Hard |
| Add **content moderation** to Instagram | ML + human review, scale | Hard |
| Design **explore/discover** for Instagram | Recommendation engine | Medium |
| Handle **1B users** on Instagram | Scale, sharding, caching | Medium |
| Design Instagram **upload** flow | Media pipeline, async | Medium |

---

## Follow-Up / Deep-Dive Questions

| Question | What They Test |
|----------|----------------|
| How would you handle a viral post with 50M likes? | Hot key, eventual consistency |
| Design resumable uploads for 4K video | Chunked upload, idempotency |
| How to detect duplicate photos? | Perceptual hash, dedup |
| Add hashtag search with 1B tags | Inverted index, partitioning |
| Design Instagram **DMs** | Messaging system (separate design) |
| Add **live streaming** | Real-time, WebRTC/CDN |

---

## Related Designs

| Design | Overlap with Instagram | Key Difference |
|--------|------------------------|----------------|
| **Pinterest** | Visual discovery, boards, CDN | Pin vs Post; board organization |
| **Flickr** | Photo storage, albums | Older model; less real-time feed |
| **TikTok** | Short video, recommendations | Video-first; FYP algorithm |
| **Snapchat** | Ephemeral stories | Stories-first; less permanent content |

---

## Full Question List (15+)

1. Design Instagram
2. Add stories to Instagram
3. Design Instagram Reels
4. Add content moderation to Instagram
5. Design explore/discover for Instagram
6. Scale Instagram to 1B users
7. Design Instagram's upload pipeline
8. How would you handle a viral post?
9. Design resumable uploads for video
10. Detect duplicate photos at scale
11. Design hashtag search
12. Add Instagram DMs
13. Add live streaming to Instagram
14. Design Instagram's feed ranking algorithm
15. How would you add video calls to Instagram?

---

## Difficulty Guide

| Difficulty | Questions |
|------------|-----------|
| **Medium** | Core Instagram, stories, explore, 1B scale, upload flow |
| **Hard** | Reels, content moderation, viral post, resumable uploads, ranking algorithm |

> **FAANG Tip:** "Design Instagram Reels" = Instagram + TikTok (short video + recommendation algorithm). Cover both media pipeline and recommendation system.

---

## Prep Strategy

1. **Master core Instagram** — upload, feed, CDN, stories
2. **Know Twitter comparison** — media vs text; different bottlenecks
3. **Reels variation** — add short video + FYP-like recommendations
4. **Content moderation** — ML + human; scale considerations
5. **Related systems** — Pinterest (visual), TikTok (video), Flickr (photos)

---

## Quick Reference: What to Design per Question

| Question | Must Include |
|----------|--------------|
| Instagram | S3, CDN, feed, explore, stories |
| + Stories | TTL, ephemeral storage, cleanup |
| + Reels | Video pipeline, recommendation algorithm |
| + Moderation | ML pipeline, review queue, block before publish |
| + Explore | Collaborative filtering, trending |

---

## Bonus Questions

16. Design Instagram's **hashtag** search
17. Add **verified badge** and how it affects feed
18. Design **Instagram Shop** (product tagging)
19. How would you **migrate** from MySQL to distributed DB?
20. Design **analytics** for creators (views, engagement)

---

## Difficulty Quick Ref

- **Medium:** Core design, stories, explore, scale
- **Medium-Hard:** Reels (add video + algo), content moderation
- **Hard:** Viral handling, resumable at scale, full ranking algo

---

## Cross-Reference

- **Design Twitter** → Feed, fan-out, timeline (no media)
- **Design YouTube** → Video pipeline, CDN, transcoding (longer form)
- **Design TikTok** → Short video, FYP algorithm, loop

---

## Summary

20+ question variations; core = Instagram + stories + Reels + moderation + explore. Master core, then variations. Related: Pinterest, Flickr, TikTok.

---

## Last-Minute Prep

Before interview: Review 01_Concept (numbers), 03_Design-Template (diagram), 05_Common-Mistakes (avoid list).

---

## Question Mapping

- "Instagram" → Full stack
- "+ feature" → Add that component to core
- "Scale to X" → Sharding, caching, CDN
- "How would you add X?" → Integrate X into existing architecture
