# Normalization and Transactions — Problem List

> **15 problems: mix of LeetCode SQL + conceptual interview Q&A. Normalization/transactions are theory-heavy — interviews test oral + schema design.**

---

## 6 MUST-DO Problems

| # | Problem | Difficulty | LC# / Type | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Swap Salary | Easy | 627 | UPDATE in transaction | DML atomicity awareness |
| 2 | Delete Duplicate Emails | Easy | 196 | DELETE + consistency | Transaction-safe dedup |
| 3 | Second Highest Salary | Medium | 176 | Query correctness | NULL handling = data integrity |
| 4 | Exchange Seats | Medium | 626 | Multi-row UPDATE | Swap without conflict |
| 5 | Explain 1NF → 3NF with example | Oral | — | Normalization | 90% theory rounds ask this |
| 6 | Explain ACID + isolation levels | Oral | — | Transactions | Every backend interview |

---

## Query Problems (LeetCode)

| # | Problem | LC# | Normalization / TX Thinking |
|---|---------|-----|-----------------------------|
| 1 | Swap Salary | 627 | Single UPDATE atomicity |
| 2 | Delete Duplicate Emails | 196 | Consistent delete — keep min id |
| 3 | Second Highest Salary | 176 | Correct NULL return = consistency |
| 4 | Exchange Seats | 626 | Multi-row swap — order matters |
| 5 | Consecutive Numbers | 180 | Data integrity: ids must be consecutive |
| 6 | Department Highest Salary | 184 | Normalized schema: employees + departments |
| 7 | Rising Temperature | 197 | Consistent date comparison |

---

## Conceptual / Oral Interview Questions

| # | Question | Key Answer |
|---|---------|------------|
| 8 | What is 1NF? Give violation example | Atomic values; violation = comma-separated phones in one cell |
| 9 | What is 2NF? When does violation happen? | No partial dep; only with composite PK |
| 10 | What is 3NF? Give transitive dep example | emp → dept_id → dept_name; dept_name depends on dept_id, not emp PK |
| 11 | What is BCNF? When is 3NF not enough? | Every determinant must be candidate key |
| 12 | Define all 4 ACID properties with example | Bank transfer: debit + credit = atomic; balance valid = consistent |
| 13 | Name isolation levels + phenomena | RU→RC→RR→S; dirty/non-repeatable/phantom reads |
| 14 | What is a deadlock? How to prevent? | Circular wait; prevent with consistent lock order, timeouts |
| 15 | When to denormalize? | Read-heavy analytics, star schema, materialized views |

---

## Problem-by-Problem Notes

### Problem 2: Delete Duplicate Emails (LC 196)
```
Transaction thinking: DELETE in a single statement is atomic.
If done in application with multiple DELETEs, wrap in BEGIN/COMMIT.
Key: Keep MIN(id) per email, delete rest.
```

### Problem 4: Exchange Seats (LC 626)
```
Transaction thinking: Swap id pairs — if done as two UPDATEs, need tx to avoid inconsistent state.
SQL approach: Single SELECT with CASE handles it atomically.
```

### Oral Q10: 3NF Transitive Dependency
```
Example: employees(emp_id, dept_id, dept_name)
  emp_id → dept_id → dept_name
  dept_name transitively depends on emp_id through dept_id
Fix: Split into employees(emp_id, dept_id) + departments(dept_id, dept_name)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL:          15 (7 LeetCode + 8 conceptual)
MUST-DO:        LC 627, 196, 176, 626 + Oral: NF definitions, ACID
KEY CONCEPTS:   1NF (atomic), 2NF (no partial dep), 3NF (no transitive dep)
                ACID (Atomicity, Consistency, Isolation, Durability)
                Isolation: RU < RC < RR < Serializable
INTERVIEW LINE: "I normalize to 3NF for OLTP; denormalize for analytics.
                 I use Read Committed for most apps, Serializable for financial."
```

---

## 30-SECOND REVISION BOX

```
1NF:            Atomic values, no repeating groups
2NF:            1NF + no partial dependency (composite PK issue)
3NF:            2NF + no transitive dependency (A→B→C, remove C)
ACID:           Atomicity (all/nothing), Consistency, Isolation, Durability
ISOLATION:      Read Uncommitted → Read Committed → Repeatable Read → Serializable
DEADLOCK:       Circular wait — consistent lock order + timeout
DENORMALIZE:    Star schema, materialized views, read-heavy systems
```
