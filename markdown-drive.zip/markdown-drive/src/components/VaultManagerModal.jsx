import { useEffect, useMemo, useRef, useState } from 'react';
import { useVaultStore } from '../stores/vault-store';
import ShareDialog from './sharing/ShareDialog';
import './vault-modal.css';

/*
 * Vault picker — `.obs-more-menu` shell; each row is vault name + optional
 * pencil / trash icon actions (non-default vaults).
 */
export default function VaultManagerModal({ open, onClose, anchorRef }) {
  const vaults = useVaultStore((s) => s.vaults);
  const activeVaultId = useVaultStore((s) => s.activeVaultId);
  const creating = useVaultStore((s) => s.creating);
  const createVault = useVaultStore((s) => s.createVault);
  const renameVault = useVaultStore((s) => s.renameVault);
  const deleteVault = useVaultStore((s) => s.deleteVault);
  const switchVault = useVaultStore((s) => s.switchVault);

  const [newName, setNewName] = useState('');
  const [creatingLocal, setCreatingLocal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editName, setEditName] = useState('');
  const [confirmId, setConfirmId] = useState(null);
  const [switchingId, setSwitchingId] = useState(null);
  const [shareTarget, setShareTarget] = useState(null);

  const popoverRef = useRef(null);
  const editInputRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => {
      const pop = popoverRef.current;
      const anchor = anchorRef?.current;
      if (pop && pop.contains(e.target)) return;
      if (anchor && anchor.contains(e.target)) return;
      onClose();
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [open, onClose, anchorRef]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!open) {
      setNewName('');
      setEditingId(null);
      setEditName('');
      setConfirmId(null);
      setSwitchingId(null);
    }
  }, [open]);

  useEffect(() => {
    if (editingId && editInputRef.current) {
      editInputRef.current.focus();
      editInputRef.current.select();
    }
  }, [editingId]);

  const sortedVaults = useMemo(() => {
    return [...vaults].sort((a, b) => {
      if (a.id === 'default' && b.id !== 'default') return -1;
      if (b.id === 'default' && a.id !== 'default') return 1;
      return a.name.localeCompare(b.name);
    });
  }, [vaults]);

  if (!open) return null;

  const handleCreate = async (e) => {
    e?.preventDefault();
    const name = newName.trim();
    if (!name) return;
    setCreatingLocal(true);
    try {
      await createVault(name);
      setNewName('');
    } finally {
      setCreatingLocal(false);
    }
  };

  const handleStartEdit = (vault, e) => {
    e?.stopPropagation();
    setEditingId(vault.id);
    setEditName(vault.name);
  };

  const handleCommitEdit = (vault) => {
    const name = editName.trim();
    if (name && name !== vault.name) renameVault(vault.id, name);
    setEditingId(null);
    setEditName('');
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditName('');
  };

  const handleSwitch = async (id) => {
    if (id === activeVaultId) {
      onClose();
      return;
    }
    setSwitchingId(id);
    try {
      await switchVault(id);
    } finally {
      setSwitchingId(null);
      onClose();
    }
  };

  const handleDelete = async (id, e) => {
    e?.stopPropagation();
    await deleteVault(id);
    setConfirmId(null);
  };

  return (
    <div
      ref={popoverRef}
      className="obs-more-menu obs-more-menu--from-bottom-left ft-vault-menu"
      role="menu"
      aria-label="Switch vault"
    >
      {sortedVaults.map((vault) => {
        const isActive = vault.id === activeVaultId;
        const isEditing = editingId === vault.id;
        const isConfirming = confirmId === vault.id;
        const isSwitching = switchingId === vault.id;
        const isDefault = vault.id === 'default';

        if (isEditing) {
          return (
            <div key={vault.id} className="ft-vault-menu__edit-wrap">
              <input
                ref={editInputRef}
                type="text"
                className="ft-vault-menu__edit-input"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleCommitEdit(vault);
                  } else if (e.key === 'Escape') {
                    e.preventDefault();
                    handleCancelEdit();
                  }
                }}
                onBlur={() => handleCommitEdit(vault)}
                maxLength={60}
                aria-label="Rename vault"
              />
            </div>
          );
        }

        return (
          <div key={vault.id} className="ft-vault-menu__block">
            {!isConfirming ? (
              <div className="ft-vault-menu__row">
                <button
                  type="button"
                  role="menuitem"
                  className={`ft-vault-menu__name${isActive ? ' ft-vault-menu__vault--active' : ''}`}
                  onClick={() => handleSwitch(vault.id)}
                >
                  {isSwitching ? (
                    <span className="ft-vault-menu__switching" aria-hidden="true">… </span>
                  ) : null}
                  <span className="ft-vault-menu__vault-label">
                    {isActive ? '✓ ' : ''}
                    {vault.name}
                  </span>
                </button>
                {!isDefault ? (
                  <div className="ft-vault-menu__icon-actions">
                    <button
                      type="button"
                      className="ft-vault-menu__icon-btn"
                      title="Share vault"
                      aria-label={`Share ${vault.name}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        setShareTarget({ type: 'vault', id: vault.id, vaultId: vault.id, name: vault.name });
                      }}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" />
                        <line x1="8.59" y1="13.51" x2="15.42" y2="17.49" />
                        <line x1="15.41" y1="6.51" x2="8.59" y2="10.49" />
                      </svg>
                    </button>
                    <button
                      type="button"
                      className="ft-vault-menu__icon-btn"
                      title="Rename vault"
                      aria-label={`Rename ${vault.name}`}
                      onClick={(e) => handleStartEdit(vault, e)}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M12 20h9" />
                        <path d="M16.5 3.5a2.121 2.121 0 1 1 3 3L7 19l-4 1 1-4 12.5-12.5Z" />
                      </svg>
                    </button>
                    <button
                      type="button"
                      className="ft-vault-menu__icon-btn ft-vault-menu__icon-btn--danger"
                      title="Delete vault"
                      aria-label={`Delete ${vault.name}`}
                      onClick={() => setConfirmId(vault.id)}
                    >
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                        <path d="M3 6h18" />
                        <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
                        <line x1="10" y1="11" x2="10" y2="17" />
                        <line x1="14" y1="11" x2="14" y2="17" />
                      </svg>
                    </button>
                  </div>
                ) : null}
              </div>
            ) : (
              <>
                <button type="button" className="ft-vault-menu__danger" onClick={(e) => handleDelete(vault.id, e)}>
                  Delete “{vault.name}”
                </button>
                <button type="button" onClick={() => setConfirmId(null)}>
                  Cancel
                </button>
              </>
            )}
          </div>
        );
      })}

      <div className="obs-more-menu__sep" role="presentation" />

      <form className="ft-vault-menu__new" onSubmit={handleCreate}>
        <input
          type="text"
          className="ft-vault-menu__new-input"
          placeholder="New vault name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          onKeyDown={(e) => e.stopPropagation()}
          maxLength={60}
          disabled={creatingLocal || creating}
          aria-label="New vault name"
        />
        <button type="submit" disabled={!newName.trim() || creatingLocal || creating}>
          {creatingLocal || creating ? '…' : 'Add vault'}
        </button>
      </form>

      <ShareDialog
        open={!!shareTarget}
        resource={shareTarget}
        onClose={() => setShareTarget(null)}
      />
    </div>
  );
}
