import { memo, useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useNotesStore } from '../../stores/notes-store';
import { useVaultStore } from '../../stores/vault-store';
import { importFiles, importFolder, importZip } from '../../utils/importer';
import VaultManagerModal from '../VaultManagerModal';

function noteMatchesQuery(note, query) {
  if (!query?.trim()) return true;
  const q = query.trim().toLowerCase();
  const title = (note.title || '').toLowerCase();
  const body = (note.body || '').toLowerCase();
  return title.includes(q) || body.includes(q);
}

function notebookMatchesQuery(notebook, allNotebooks, notes, query) {
  if (!query?.trim()) return true;
  const q = query.trim().toLowerCase();
  if ((notebook.title || '').toLowerCase().includes(q)) return true;
  if (notes.some((n) => n.notebookId === notebook.id && noteMatchesQuery(n, q))) return true;
  const children = allNotebooks.filter((nb) => nb.parentId === notebook.id);
  return children.some((child) => notebookMatchesQuery(child, allNotebooks, notes, q));
}

function sortNotesList(list, sortMode) {
  const notes = [...list];
  notes.sort((a, b) => {
    if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
    if (sortMode === 'title') {
      return (a.title || 'Untitled').localeCompare(b.title || 'Untitled');
    }
    return new Date(b.updatedAt || b.createdAt || 0) - new Date(a.updatedAt || a.createdAt || 0);
  });
  return notes;
}

function clampContextMenuPosition(anchor, menuEl) {
  const margin = 8;
  if (!anchor || !menuEl) return null;
  const rect = menuEl.getBoundingClientRect();
  const width = rect.width || 180;
  const height = rect.height || 120;
  return {
    left: Math.min(Math.max(anchor.x, margin), window.innerWidth - width - margin),
    top: Math.min(Math.max(anchor.y, margin), window.innerHeight - height - margin),
  };
}

function TreeNote({ note, depth, isActive, onOpen, onDelete, onDuplicate, onToggleTodo }) {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const closeOnEscape = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const closeOnScrollOrResize = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('resize', closeOnScrollOrResize);
    window.addEventListener('scroll', closeOnScrollOrResize, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('resize', closeOnScrollOrResize);
      window.removeEventListener('scroll', closeOnScrollOrResize, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  return (
    <div
      className={`ft-node ft-node--file ${isActive ? 'ft-node--active' : ''}`}
      style={{ paddingLeft: 14 }}
      draggable
      onDragStart={(e) => {
        e.dataTransfer.setData('application/x-inkdrop-note', note.id);
        e.dataTransfer.effectAllowed = 'move';
      }}
      onClick={() => onOpen(note.id)}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setMenuAnchor({ x: e.clientX, y: e.clientY });
        setMenuPos(null);
      }}
    >
      {note.isTodo ? (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          {note.todoCompleted
            ? <><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></>
            : <rect x="3" y="3" width="18" height="18" rx="2"/>}
        </svg>
      ) : (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
        </svg>
      )}
      <span className={`ft-node__label ${note.todoCompleted ? 'ft-node__label--done' : ''}`}>
        {note.title || 'Untitled'}
      </span>
      {note.isPinned && (
        <svg className="ft-node__pin" width="8" height="8" viewBox="0 0 24 24" fill="currentColor"><path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/></svg>
      )}

      {menuAnchor && (
        <div
          ref={menuRef}
          className="ft-ctx"
          style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={() => { onOpen(note.id); setMenuAnchor(null); }}>Open</button>
          <button onClick={() => { onDuplicate(note.id); setMenuAnchor(null); }}>Duplicate</button>
          {note.isTodo && (
            <button onClick={() => { onToggleTodo(note.id); setMenuAnchor(null); }}>
              {note.todoCompleted ? 'Mark incomplete' : 'Mark complete'}
            </button>
          )}
          <button className="ft-ctx--danger" onClick={() => { onDelete(note.id); setMenuAnchor(null); }}>Delete</button>
        </div>
      )}
    </div>
  );
}

/* Build the set of descendant notebook ids (incl. self) for cycle-safe folder drops. */
function descendantNotebookIds(rootId, allNotebooks) {
  const out = new Set([rootId]);
  let changed = true;
  while (changed) {
    changed = false;
    for (const nb of allNotebooks) {
      if (!out.has(nb.id) && nb.parentId && out.has(nb.parentId)) {
        out.add(nb.id);
        changed = true;
      }
    }
  }
  return out;
}

function TreeFolder({ notebook, depth, notes, allNotebooks, activeNoteId, deleteNote, duplicateNote, toggleTodo, deleteNotebook, updateNotebook, createNotebook, createNote, openNoteInTabFn, searchQuery, sortMode, foldCommand, moveNote, moveNotebook }) {
  const [collapsed, setCollapsed] = useState(false);
  const [dropOver, setDropOver] = useState(false);
  const hoverExpandTimerRef = useRef(null);

  /* Respond to parent-driven expand/collapse-all commands. `foldCommand`
   * is `{ action: 'collapse' | 'expand', nonce: n }` — the nonce changes
   * on every click so the same action can be replayed. */
  useEffect(() => {
    if (!foldCommand) return;
    if (foldCommand.action === 'collapse') setCollapsed(true);
    else if (foldCommand.action === 'expand') setCollapsed(false);
  }, [foldCommand]);
  const [editing, setEditing] = useState(false);
  const [editVal, setEditVal] = useState(notebook.title);
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const inputRef = useRef(null);
  const menuRef = useRef(null);

  const childNotebooks = allNotebooks.filter((nb) =>
    nb.parentId === notebook.id && notebookMatchesQuery(nb, allNotebooks, notes, searchQuery)
  );
  const childNotes = sortNotesList(
    notes.filter((n) => n.notebookId === notebook.id && noteMatchesQuery(n, searchQuery)),
    sortMode
  );

  useEffect(() => {
    if (editing && inputRef.current) { inputRef.current.focus(); inputRef.current.select(); }
  }, [editing]);

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const closeOnEscape = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const closeOnScrollOrResize = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('resize', closeOnScrollOrResize);
    window.addEventListener('scroll', closeOnScrollOrResize, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('resize', closeOnScrollOrResize);
      window.removeEventListener('scroll', closeOnScrollOrResize, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  const handleRename = () => {
    if (editVal.trim() && editVal !== notebook.title) updateNotebook(notebook.id, { title: editVal.trim() });
    setEditing(false);
  };

  return (
    <>
      <div
        className={`ft-node ft-node--folder ${depth > 0 ? 'ft-node--guided' : ''}${dropOver ? ' ft-node--drop' : ''}`}
        style={{ paddingLeft: 6 }}
        draggable
        onDragStart={(e) => {
          e.dataTransfer.setData('application/x-inkdrop-folder', notebook.id);
          e.dataTransfer.effectAllowed = 'move';
        }}
        onClick={() => setCollapsed(!collapsed)}
        onContextMenu={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setMenuAnchor({ x: e.clientX, y: e.clientY });
          setMenuPos(null);
        }}
        onDragOver={(e) => {
          const types = e.dataTransfer.types;
          /* Note drop is always OK on a folder. */
          if (types.includes('application/x-inkdrop-note')) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            if (!dropOver) setDropOver(true);
            if (collapsed && !hoverExpandTimerRef.current) {
              hoverExpandTimerRef.current = setTimeout(() => {
                setCollapsed(false);
                hoverExpandTimerRef.current = null;
              }, 700);
            }
            return;
          }
          /* Folder drop — disallow self / descendants (cycle). */
          if (types.includes('application/x-inkdrop-folder')) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            if (!dropOver) setDropOver(true);
            if (collapsed && !hoverExpandTimerRef.current) {
              hoverExpandTimerRef.current = setTimeout(() => {
                setCollapsed(false);
                hoverExpandTimerRef.current = null;
              }, 700);
            }
          }
        }}
        onDragLeave={() => {
          setDropOver(false);
          if (hoverExpandTimerRef.current) {
            clearTimeout(hoverExpandTimerRef.current);
            hoverExpandTimerRef.current = null;
          }
        }}
        onDrop={(e) => {
          setDropOver(false);
          if (hoverExpandTimerRef.current) {
            clearTimeout(hoverExpandTimerRef.current);
            hoverExpandTimerRef.current = null;
          }
          const noteId = e.dataTransfer.getData('application/x-inkdrop-note');
          if (noteId && moveNote) {
            e.preventDefault();
            e.stopPropagation();
            moveNote(noteId, notebook.id);
            if (collapsed) setCollapsed(false);
            return;
          }
          const folderId = e.dataTransfer.getData('application/x-inkdrop-folder');
          if (folderId && moveNotebook && folderId !== notebook.id) {
            const blocked = descendantNotebookIds(folderId, allNotebooks);
            if (blocked.has(notebook.id)) return; /* would create a cycle */
            e.preventDefault();
            e.stopPropagation();
            moveNotebook(folderId, notebook.id);
            if (collapsed) setCollapsed(false);
          }
        }}
      >
        <svg className="ft-node__arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3"
          style={{ transform: collapsed ? 'rotate(-90deg)' : 'rotate(0)' }}>
          <polyline points="8 10 12 14 16 10" />
        </svg>
        {editing ? (
          <input
            ref={inputRef}
            className="ft-node__edit"
            value={editVal}
            onChange={(e) => setEditVal(e.target.value)}
            onBlur={handleRename}
            onKeyDown={(e) => { if (e.key === 'Enter') handleRename(); if (e.key === 'Escape') setEditing(false); }}
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <span className="ft-node__label">{notebook.title}</span>
        )}

        {menuAnchor && (
          <div
            ref={menuRef}
            className="ft-ctx"
            style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
            onClick={(e) => e.stopPropagation()}
          >
            <button onClick={() => {
              const id = createNote(notebook.id);
              if (id) openNoteInTabFn(id);
              setMenuAnchor(null);
              setCollapsed(false);
            }}>New note here</button>
            <button onClick={() => { createNotebook('New Folder', notebook.id); setMenuAnchor(null); setCollapsed(false); }}>New sub-folder</button>
            <button onClick={() => { setEditing(true); setEditVal(notebook.title); setMenuAnchor(null); }}>Rename</button>
            <button className="ft-ctx--danger" onClick={() => { deleteNotebook(notebook.id); setMenuAnchor(null); }}>Delete folder</button>
          </div>
        )}
      </div>

      <div className={`ft-children ${collapsed ? 'ft-children--collapsed' : 'ft-children--expanded'}`}>
        <div className="ft-children__inner">
          {childNotebooks.map((child) => (
            <TreeFolder
              key={child.id}
              notebook={child}
              depth={depth + 1}
              notes={notes}
              allNotebooks={allNotebooks}
              activeNoteId={activeNoteId}
              deleteNote={deleteNote}
              duplicateNote={duplicateNote}
              toggleTodo={toggleTodo}
              deleteNotebook={deleteNotebook}
              updateNotebook={updateNotebook}
              createNotebook={createNotebook}
              createNote={createNote}
              openNoteInTabFn={openNoteInTabFn}
              searchQuery={searchQuery}
              sortMode={sortMode}
              foldCommand={foldCommand}
              moveNote={moveNote}
              moveNotebook={moveNotebook}
            />
          ))}
          {childNotes.map((note) => (
            <TreeNote
              key={note.id}
              note={note}
              depth={depth + 1}
              isActive={note.id === activeNoteId}
              onOpen={openNoteInTabFn}
              onDelete={deleteNote}
              onDuplicate={duplicateNote}
              onToggleTodo={toggleTodo}
            />
          ))}
        </div>
      </div>
    </>
  );
}

const FileTreeSidebar = memo(function FileTreeSidebar({ onNewNote }) {
  const notebooks = useNotesStore((s) => s.notebooks);
  const notes = useNotesStore((s) => s.notes);
  const activeTabId = useNotesStore((s) => s.activeTabId);
  const openNoteInTab = useNotesStore((s) => s.openNoteInTab);
  const deleteNote = useNotesStore((s) => s.deleteNote);
  const duplicateNote = useNotesStore((s) => s.duplicateNote);
  const toggleTodo = useNotesStore((s) => s.toggleTodo);
  const deleteNotebook = useNotesStore((s) => s.deleteNotebook);
  const updateNotebook = useNotesStore((s) => s.updateNotebook);
  const createNotebook = useNotesStore((s) => s.createNotebook);
  const createNote = useNotesStore((s) => s.createNote);
  const moveNote = useNotesStore((s) => s.moveNote);
  const moveNotebook = useNotesStore((s) => s.moveNotebook);
  const sidebarCollapsed = useNotesStore((s) => s.sidebarCollapsed);
  const toggleSidebar = useNotesStore((s) => s.toggleSidebar);

  const [creating, setCreating] = useState(null);
  const [newName, setNewName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState('recent');
  const [uploadMenuOpen, setUploadMenuOpen] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null); // { kind, text }
  const [allExpanded, setAllExpanded] = useState(true);
  const [foldCommand, setFoldCommand] = useState(null); // { action, nonce }
  const [foldAnimating, setFoldAnimating] = useState(false);

  /* Resizable sidebar width — persisted so it survives reloads. The
   * bounds match the min/max used by the drag handler so programmatic
   * initial values stay legal. */
  const SIDEBAR_MIN = 210;
  const SIDEBAR_MAX = 520;
  const SIDEBAR_DEFAULT = 250;
  const SIDEBAR_STORAGE_KEY = 'notes.sidebarWidth';
  const [sidebarWidth, setSidebarWidth] = useState(() => {
    if (typeof window === 'undefined') return SIDEBAR_DEFAULT;
    const raw = window.localStorage?.getItem?.(SIDEBAR_STORAGE_KEY);
    const n = raw ? parseInt(raw, 10) : NaN;
    if (Number.isFinite(n)) return Math.max(SIDEBAR_MIN, Math.min(SIDEBAR_MAX, n));
    return SIDEBAR_DEFAULT;
  });
  const [isResizing, setIsResizing] = useState(false);
  const sidebarRef = useRef(null);
  const createRef = useRef(null);
  const searchRef = useRef(null);
  const uploadBtnRef = useRef(null);
  const uploadMenuRef = useRef(null);
  const filesInputRef = useRef(null);
  const folderInputRef = useRef(null);
  const zipInputRef = useRef(null);
  const treeRef = useRef(null);

  const activeVault = useVaultStore((s) => s.getActiveVault());
  const [vaultModalOpen, setVaultModalOpen] = useState(false);
  const vaultTriggerRef = useRef(null);

  const rootNotebooks = notebooks.filter((nb) => nb.parentId === null);
  const showNotebookTree = notes.length > 0 || creating === 'folder';
  const vaultLabel = (activeVault?.name || rootNotebooks[0]?.title || 'MY_DATA').toUpperCase();
  const rootNotebook = rootNotebooks[0] || null;
  const useFlatRootView = rootNotebooks.length === 1 && rootNotebook?.id === 'default';
  const rootChildNotebooks = useMemo(() => (useFlatRootView
    ? notebooks.filter((nb) =>
      nb.parentId === rootNotebook.id && notebookMatchesQuery(nb, notebooks, notes, searchQuery)
    )
    : []), [useFlatRootView, notebooks, rootNotebook, notes, searchQuery]);

  const rootNotes = useMemo(() => (useFlatRootView
    ? sortNotesList(
      notes.filter((n) => n.notebookId === rootNotebook.id && noteMatchesQuery(n, searchQuery)),
      sortMode
    )
    : []), [useFlatRootView, notes, rootNotebook, searchQuery, sortMode]);

  const visibleRootNotebooks = useMemo(() => (
    rootNotebooks.filter((nb) => notebookMatchesQuery(nb, notebooks, notes, searchQuery))
  ), [rootNotebooks, notebooks, notes, searchQuery]);

  const hasResults = useFlatRootView
    ? rootChildNotebooks.length > 0 || rootNotes.length > 0
    : visibleRootNotebooks.length > 0;

  useEffect(() => {
    if (creating && createRef.current) createRef.current.focus();
  }, [creating]);

  useEffect(() => {
    const onFocusSearch = (e) => {
      const key = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && key === 'f') {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
      }
    };
    const onProgrammaticFocus = () => {
      searchRef.current?.focus();
      searchRef.current?.select();
    };
    window.addEventListener('keydown', onFocusSearch, true);
    window.addEventListener('notes-focus-search', onProgrammaticFocus);
    return () => {
      window.removeEventListener('keydown', onFocusSearch, true);
      window.removeEventListener('notes-focus-search', onProgrammaticFocus);
    };
  }, []);

  const handleCreate = useCallback(() => {
    if (!newName.trim()) { setCreating(null); return; }
    if (creating === 'folder') {
      createNotebook(newName.trim());
    } else {
      const nbId = notebooks[0]?.id;
      if (nbId) {
        const id = createNote(nbId, { title: newName.trim() });
        if (id) openNoteInTab(id);
      }
    }
    setNewName('');
    setCreating(null);
  }, [creating, newName, createNotebook, createNote, notebooks, openNoteInTab]);

  const handleToggleSort = useCallback(() => {
    setSortMode((prev) => (prev === 'recent' ? 'title' : 'recent'));
  }, []);

  /* Persist sidebar width when it settles (not while dragging, to avoid
   * thrashing localStorage on every pointermove frame). */
  useEffect(() => {
    if (isResizing) return;
    try { window.localStorage?.setItem?.(SIDEBAR_STORAGE_KEY, String(sidebarWidth)); } catch { /* quota/denied — skip */ }
  }, [isResizing, sidebarWidth]);

  /* Drag-to-resize: pointerdown on the handle starts a rAF-throttled
   * pointermove listener on the window. We read clientX relative to the
   * sidebar's left edge so the handle stays under the cursor regardless
   * of scroll/offset. */
  const handleResizeStart = useCallback((e) => {
    if (sidebarCollapsed) return;
    e.preventDefault();
    const el = sidebarRef.current;
    if (!el) return;
    const leftEdge = el.getBoundingClientRect().left;
    setIsResizing(true);

    let frame = 0;
    let latestX = e.clientX;

    const apply = () => {
      frame = 0;
      const next = Math.max(SIDEBAR_MIN, Math.min(SIDEBAR_MAX, latestX - leftEdge));
      setSidebarWidth(next);
    };
    const onMove = (ev) => {
      latestX = ev.clientX;
      if (!frame) frame = requestAnimationFrame(apply);
    };
    const onUp = () => {
      if (frame) cancelAnimationFrame(frame);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      setIsResizing(false);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);
  }, [sidebarCollapsed]);

  /* While dragging, lock the whole document so iframes / text-selection
   * don't swallow pointermove events and the cursor stays consistent. */
  useEffect(() => {
    if (!isResizing) return;
    const prevCursor = document.body.style.cursor;
    const prevSelect = document.body.style.userSelect;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    return () => {
      document.body.style.cursor = prevCursor;
      document.body.style.userSelect = prevSelect;
    };
  }, [isResizing]);

  /* Expand/Collapse-all — broadcast a command to every TreeFolder via a
   * bumping nonce so the same action fires cleanly on repeated clicks. */
  const handleToggleFoldAll = useCallback(() => {
    setAllExpanded((prev) => {
      const next = !prev;
      setFoldCommand({ action: next ? 'expand' : 'collapse', nonce: Date.now() });
      return next;
    });
    setFoldAnimating(true);
    /* Clear the animation flag after the icon swap completes so repeat
     * clicks can re-trigger the keyframes. */
    setTimeout(() => setFoldAnimating(false), 360);
  }, []);

  /* Close upload dropdown on outside click / escape. */
  useEffect(() => {
    if (!uploadMenuOpen) return;
    const onDown = (e) => {
      if (uploadMenuRef.current && uploadMenuRef.current.contains(e.target)) return;
      if (uploadBtnRef.current && uploadBtnRef.current.contains(e.target)) return;
      setUploadMenuOpen(false);
    };
    const onKey = (e) => { if (e.key === 'Escape') setUploadMenuOpen(false); };
    document.addEventListener('mousedown', onDown);
    window.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      window.removeEventListener('keydown', onKey);
    };
  }, [uploadMenuOpen]);

  /* Auto-dismiss the status toast after a few seconds. */
  useEffect(() => {
    if (!uploadStatus) return;
    const t = setTimeout(() => setUploadStatus(null), 4500);
    return () => clearTimeout(t);
  }, [uploadStatus]);

  /* Tree scrollbar polish:
   *  - Toggle `is-scrolling` during active scroll (keeps thumb visible).
   *  - Toggle top/bottom fade-mask classes so users see there's more content.
   * All runs via plain DOM (no re-renders). */
  useEffect(() => {
    const el = treeRef.current;
    if (!el) return;
    let idleTimer = null;
    const updateEdges = () => {
      const canTop = el.scrollTop > 2;
      const canBottom = el.scrollTop + el.clientHeight < el.scrollHeight - 2;
      el.classList.toggle('ft-tree--can-scroll-top', canTop);
      el.classList.toggle('ft-tree--can-scroll-bottom', canBottom);
    };
    const onScroll = () => {
      el.classList.add('is-scrolling');
      updateEdges();
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(() => el.classList.remove('is-scrolling'), 900);
    };
    updateEdges();
    el.addEventListener('scroll', onScroll, { passive: true });
    const ro = new ResizeObserver(updateEdges);
    ro.observe(el);
    return () => {
      el.removeEventListener('scroll', onScroll);
      ro.disconnect();
      if (idleTimer) clearTimeout(idleTimer);
    };
  }, [sidebarCollapsed, notes.length, notebooks.length]);

  const ensureTargetNotebookId = useCallback(() => {
    const existing = notebooks[0]?.id;
    if (existing) return existing;
    return createNotebook('MY_DATA');
  }, [notebooks, createNotebook]);

  const formatImportSummary = useCallback((result) => {
    const { notebooksCreated = 0, notesCreated = 0, errors = [] } = result || {};
    const parts = [];
    if (notesCreated) parts.push(`${notesCreated} note${notesCreated === 1 ? '' : 's'}`);
    if (notebooksCreated) parts.push(`${notebooksCreated} folder${notebooksCreated === 1 ? '' : 's'}`);
    const base = parts.length ? `Imported ${parts.join(' + ')}` : 'Nothing imported';
    return errors.length ? `${base} (${errors.length} skipped)` : base;
  }, []);

  const runImport = useCallback(async (runner) => {
    setUploadMenuOpen(false);
    setUploadStatus({ kind: 'info', text: 'Importing…' });
    try {
      const rootParentId = ensureTargetNotebookId();
      const storeApi = { createNote, createNotebook };
      const result = await runner({ storeApi, rootParentId });
      setUploadStatus({
        kind: result.errors?.length && !result.notesCreated ? 'error' : 'success',
        text: formatImportSummary(result),
      });
    } catch (e) {
      setUploadStatus({ kind: 'error', text: `Import failed: ${e?.message || e}` });
    }
  }, [ensureTargetNotebookId, createNote, createNotebook, formatImportSummary]);

  const handleUploadFiles = useCallback((e) => {
    const list = Array.from(e.target.files || []);
    e.target.value = '';
    if (!list.length) return;
    runImport((ctx) => importFiles(list, ctx));
  }, [runImport]);

  const handleUploadFolder = useCallback((e) => {
    const list = Array.from(e.target.files || []);
    e.target.value = '';
    if (!list.length) return;
    runImport((ctx) => importFolder(list, ctx));
  }, [runImport]);

  const handleUploadZip = useCallback((e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    runImport((ctx) => importZip(file, ctx));
  }, [runImport]);

  const handleOpenHelp = useCallback(() => {
    const helpNote = notes.find((n) => (n.title || '').toLowerCase() === 'welcome')
      || notes.find((n) => (n.title || '').toLowerCase().includes('help'));
    if (helpNote) {
      openNoteInTab(helpNote.id);
      return;
    }
    const nbId = notebooks[0]?.id;
    if (!nbId) return;
    const id = createNote(nbId, {
      title: 'Help',
      body: [
        '# Help',
        '',
        '- Ctrl/Cmd + N: New note',
        '- Ctrl/Cmd + F: Search in sidebar',
        '- Right click note/folder for actions',
        '- Right click any tab for split / move / close options',
      ].join('\n'),
    });
    if (id) openNoteInTab(id);
  }, [notes, notebooks, createNote, openNoteInTab]);

  /* Navbar Help button → dispatches `app:open-help`; respond from here so
     the help target uses the live notes-store. */
  useEffect(() => {
    const onHelp = () => handleOpenHelp();
    window.addEventListener('app:open-help', onHelp);
    return () => window.removeEventListener('app:open-help', onHelp);
  }, [handleOpenHelp]);

  return (
    <div
      ref={sidebarRef}
      className={`ft-sidebar${sidebarCollapsed ? ' ft-sidebar--collapsed' : ''}${isResizing ? ' ft-sidebar--resizing' : ''}`}
      style={sidebarCollapsed ? undefined : { width: sidebarWidth, minWidth: sidebarWidth }}
    >
      {sidebarCollapsed ? (
        <button
          type="button"
          className="ft-sidebar__toggle"
          onClick={toggleSidebar}
          title="Expand sidebar"
          aria-label="Expand sidebar"
          aria-expanded={false}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
        </button>
      ) : (
      <div className="ft-pane">
        <div className="ft-actions">
          <button className="ft-actions__btn" onClick={onNewNote} title="New note">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="12" y1="18" x2="12" y2="12" /><line x1="9" y1="15" x2="15" y2="15" /></svg>
          </button>
          <button className="ft-actions__btn" onClick={() => setCreating('folder')} title="New folder">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" /><line x1="12" y1="11" x2="12" y2="17" /><line x1="9" y1="14" x2="15" y2="14" /></svg>
          </button>
          <button
            ref={uploadBtnRef}
            className={`ft-actions__btn${uploadMenuOpen ? ' ft-actions__btn--active' : ''}`}
            title="Upload files, folder, or .zip"
            aria-haspopup="menu"
            aria-expanded={uploadMenuOpen}
            onClick={() => setUploadMenuOpen((v) => !v)}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
          </button>
          <button
            className={`ft-actions__btn ft-fold-all${foldAnimating ? ' ft-fold-all--animating' : ''}`}
            title={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-label={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-pressed={!allExpanded}
            onClick={handleToggleFoldAll}
          >
            <span className="ft-fold-all__icon" key={allExpanded ? 'expanded' : 'collapsed'}>
              {allExpanded ? (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="17 11 12 6 7 11" />
                  <polyline points="17 18 12 13 7 18" />
                </svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="7 13 12 18 17 13" />
                  <polyline points="7 6 12 11 17 6" />
                </svg>
              )}
            </span>
          </button>
          <button className="ft-actions__btn" title={`Sort: ${sortMode === 'recent' ? 'Recent' : 'Title'}`} onClick={handleToggleSort}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" y1="6" x2="20" y2="6" /><line x1="4" y1="12" x2="14" y2="12" /><line x1="4" y1="18" x2="10" y2="18" /></svg>
          </button>
          <button className="ft-actions__btn" title="Collapse sidebar" onClick={toggleSidebar}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><line x1="9" y1="3" x2="9" y2="21" /></svg>
          </button>

          {uploadMenuOpen && (
            <div ref={uploadMenuRef} className="ft-upload-menu" role="menu" aria-label="Upload to notes">
              <button type="button" role="menuitem" className="ft-upload-menu__item" onClick={() => { filesInputRef.current?.click(); setUploadMenuOpen(false); }}>
                <span className="ft-upload-menu__icon" aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="12" y1="18" x2="12" y2="12" />
                    <polyline points="9 15 12 12 15 15" />
                  </svg>
                </span>
                <span className="ft-upload-menu__text">
                  <span className="ft-upload-menu__title">Upload files</span>
                  <span className="ft-upload-menu__hint">Markdown, text, JSON…</span>
                </span>
              </button>
              <button type="button" role="menuitem" className="ft-upload-menu__item" onClick={() => { folderInputRef.current?.click(); setUploadMenuOpen(false); }}>
                <span className="ft-upload-menu__icon" aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                  </svg>
                </span>
                <span className="ft-upload-menu__text">
                  <span className="ft-upload-menu__title">Upload folder</span>
                  <span className="ft-upload-menu__hint">Keeps nested structure</span>
                </span>
              </button>
              <button type="button" role="menuitem" className="ft-upload-menu__item" onClick={() => { zipInputRef.current?.click(); setUploadMenuOpen(false); }}>
                <span className="ft-upload-menu__icon" aria-hidden="true">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 8v13H3V8" />
                    <path d="M1 3h22v5H1z" />
                    <path d="M10 12h4" />
                    <path d="M10 16h4" />
                  </svg>
                </span>
                <span className="ft-upload-menu__text">
                  <span className="ft-upload-menu__title">Upload .zip</span>
                  <span className="ft-upload-menu__hint">Extracts automatically</span>
                </span>
              </button>
            </div>
          )}
        </div>

        <input
          ref={filesInputRef}
          type="file"
          multiple
          accept=".md,.markdown,.mdx,.txt,.text,.json,.yaml,.yml,.toml,.html,.htm,.csv,.tsv,.log,text/*,application/json"
          style={{ display: 'none' }}
          onChange={handleUploadFiles}
        />
        <input
          ref={folderInputRef}
          type="file"
          style={{ display: 'none' }}
          webkitdirectory=""
          directory=""
          mozdirectory=""
          multiple
          onChange={handleUploadFolder}
        />
        <input
          ref={zipInputRef}
          type="file"
          accept=".zip,application/zip,application/x-zip-compressed"
          style={{ display: 'none' }}
          onChange={handleUploadZip}
        />

        {uploadStatus && (
          <div className={`ft-upload-toast ft-upload-toast--${uploadStatus.kind}`} role="status">
            {uploadStatus.text}
          </div>
        )}

        <div className="ft-search">
          <svg className="ft-search__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            ref={searchRef}
            className="ft-search__input"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="ft-search__clear" onClick={() => setSearchQuery('')} title="Clear search">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>

        <div className="ft-tree" ref={treeRef} tabIndex={-1}>
          {!creating && notes.length === 0 && (
            <div className="ft-tree__empty-state">
              <div className="ft-tree__empty-title">No notes available</div>
              <div className="ft-tree__empty-copy">Create a new note to get started.</div>
              <button className="ft-tree__empty-btn" onClick={onNewNote}>Create new note</button>
            </div>
          )}

          {creating && (
            <div className="ft-node ft-node--creating" style={{ paddingLeft: 10 }}>
              {creating === 'folder' ? (
                <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" /></svg>
              ) : (
                <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /></svg>
              )}
              <input
                ref={createRef}
                className="ft-node__edit"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onBlur={() => { handleCreate(); }}
                onKeyDown={(e) => { if (e.key === 'Enter') handleCreate(); if (e.key === 'Escape') { setCreating(null); setNewName(''); } }}
                placeholder={creating === 'folder' ? 'Folder name...' : 'Note title...'}
              />
            </div>
          )}

          {showNotebookTree && useFlatRootView && rootChildNotebooks.map((nb) => (
            <TreeFolder
              key={nb.id}
              notebook={nb}
              depth={0}
              notes={notes}
              allNotebooks={notebooks}
              activeNoteId={activeTabId}
              deleteNote={deleteNote}
              duplicateNote={duplicateNote}
              toggleTodo={toggleTodo}
              deleteNotebook={deleteNotebook}
              updateNotebook={updateNotebook}
              createNotebook={createNotebook}
              createNote={createNote}
              openNoteInTabFn={openNoteInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              foldCommand={foldCommand}
              moveNote={moveNote}
              moveNotebook={moveNotebook}
            />
          ))}

          {showNotebookTree && useFlatRootView && rootNotes.map((note) => (
            <TreeNote
              key={note.id}
              note={note}
              depth={0}
              isActive={note.id === activeTabId}
              onOpen={openNoteInTab}
              onDelete={deleteNote}
              onDuplicate={duplicateNote}
              onToggleTodo={toggleTodo}
            />
          ))}

          {showNotebookTree && !useFlatRootView && visibleRootNotebooks.map((nb) => (
            <TreeFolder
              key={nb.id}
              notebook={nb}
              depth={0}
              notes={notes}
              allNotebooks={notebooks}
              activeNoteId={activeTabId}
              deleteNote={deleteNote}
              duplicateNote={duplicateNote}
              toggleTodo={toggleTodo}
              deleteNotebook={deleteNotebook}
              updateNotebook={updateNotebook}
              createNotebook={createNotebook}
              createNote={createNote}
              openNoteInTabFn={openNoteInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              foldCommand={foldCommand}
              moveNote={moveNote}
              moveNotebook={moveNotebook}
            />
          ))}

          {showNotebookTree && notes.length > 0 && !hasResults && (
            <div className="ft-tree__empty">No notes found</div>
          )}
        </div>

        <div className="ft-bottom">
          <button
            ref={vaultTriggerRef}
            type="button"
            className="ft-bottom__vault-btn"
            title={`Active vault: ${activeVault?.name || 'MY_DATA'} — click to manage vaults`}
            aria-haspopup="menu"
            aria-expanded={vaultModalOpen}
            onClick={() => setVaultModalOpen((v) => !v)}
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z" /></svg>
            <span className="ft-bottom__vault-btn-name">{vaultLabel}</span>
          </button>
          <VaultManagerModal
            open={vaultModalOpen}
            onClose={() => setVaultModalOpen(false)}
            anchorRef={vaultTriggerRef}
          />
        </div>
      </div>
      )}

      {!sidebarCollapsed && (
        <div
          className="ft-sidebar__resizer"
          role="separator"
          aria-orientation="vertical"
          aria-label="Resize sidebar"
          aria-valuenow={sidebarWidth}
          aria-valuemin={SIDEBAR_MIN}
          aria-valuemax={SIDEBAR_MAX}
          title="Drag to resize"
          onPointerDown={handleResizeStart}
          onDoubleClick={() => setSidebarWidth(SIDEBAR_DEFAULT)}
        >
          <span className="ft-sidebar__resizer-grip" aria-hidden="true" />
        </div>
      )}
    </div>
  );
});

export default FileTreeSidebar;
