import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

class AVLNode {
  constructor(val, id) {
    this.val = val;
    this.id = id;
    this.left = null;
    this.right = null;
    this.height = 1;
  }
}

function height(n) { return n ? n.height : 0; }
function balance(n) { return n ? height(n.left) - height(n.right) : 0; }
function refresh(n) {
  if (!n) return;
  n.height = 1 + Math.max(height(n.left), height(n.right));
}

function rotateRight(y) {
  const x = y.left;
  const T2 = x.right;
  x.right = y;
  y.left = T2;
  refresh(y);
  refresh(x);
  return x;
}

function rotateLeft(x) {
  const y = x.right;
  const T2 = y.left;
  y.left = x;
  x.right = T2;
  refresh(x);
  refresh(y);
  return y;
}

function collectGraph(root) {
  const nodes = [];
  const edges = [];
  function walk(n) {
    if (!n) return;
    nodes.push({
      id: n.id,
      value: n.val,
      left: n.left ? n.left.id : null,
      right: n.right ? n.right.id : null,
    });
    if (n.left) {
      edges.push([n.id, n.left.id]);
      walk(n.left);
    }
    if (n.right) {
      edges.push([n.id, n.right.id]);
      walk(n.right);
    }
  }
  walk(root);
  return { nodes, edges };
}

function insertBST(root, val, idGen) {
  const nn = new AVLNode(val, idGen());
  const path = [];
  let cur = root;
  while (cur) {
    path.push(cur);
    if (val < cur.val) {
      if (!cur.left) {
        cur.left = nn;
        break;
      }
      cur = cur.left;
    } else {
      if (!cur.right) {
        cur.right = nn;
        break;
      }
      cur = cur.right;
    }
  }
  return { root, path: [...path, nn] };
}

function findParent(root, child) {
  if (!root || !child) return null;
  let cur = root;
  const stack = [];
  while (cur && cur !== child) {
    stack.push(cur);
    cur = child.val < cur.val ? cur.left : cur.right;
  }
  return stack.length ? stack[stack.length - 1] : null;
}

function firstUnbalanced(n) {
  if (!n) return null;
  const L = firstUnbalanced(n.left);
  if (L) return L;
  const R = firstUnbalanced(n.right);
  if (R) return R;
  refresh(n);
  return Math.abs(balance(n)) > 1 ? n : null;
}

function generateSteps(values) {
  const steps = [];
  let root = null;
  let nextId = 0;
  const idGen = () => nextId++;

  const snap = (caption, focusId, stackNote) => {
    const g = root ? collectGraph(root) : { nodes: [], edges: [] };
    const nodeColors = {};
    if (focusId != null) nodeColors[focusId] = 'current';
    steps.push({
      caption,
      nodes: g.nodes,
      edges: g.edges,
      nodeColors,
      stack: stackNote ? [stackNote] : [],
      queue: [],
      result: [...values],
    });
  };

  values.forEach((v) => {
    if (!root) {
      root = new AVLNode(v, idGen());
      snap(`Insert ${v} as root`, root.id, 'insert');
      return;
    }
    const ins = insertBST(root, v, idGen);
    root = ins.root;
    snap(`Attach ${v} in BST position`, ins.path[ins.path.length - 1].id, 'insert');

    let guard = 0;
    while (guard < 12) {
      guard += 1;
      refreshAll(root);
      const z = firstUnbalanced(root);
      if (!z) break;
      const bf = balance(z);
      snap(`Imbalance at ${z.val}, bf=${bf}`, z.id, `bf=${bf}`);
      const p = findParent(root, z);
      if (bf > 1 && balance(z.left) >= 0) {
        const sub = rotateRight(z);
        if (!p) root = sub;
        else if (p.left === z) p.left = sub;
        else p.right = sub;
        snap('LL: right rotate', null, 'LL');
        continue;
      }
      if (bf < -1 && balance(z.right) <= 0) {
        const sub = rotateLeft(z);
        if (!p) root = sub;
        else if (p.left === z) p.left = sub;
        else p.right = sub;
        snap('RR: left rotate', null, 'RR');
        continue;
      }
      if (bf > 1 && balance(z.left) < 0) {
        z.left = rotateLeft(z.left);
        refresh(z.left);
        refresh(z);
        const sub = rotateRight(z);
        if (!p) root = sub;
        else if (p.left === z) p.left = sub;
        else p.right = sub;
        snap('LR: double rotate', null, 'LR');
        continue;
      }
      if (bf < -1 && balance(z.right) > 0) {
        z.right = rotateRight(z.right);
        refresh(z.right);
        refresh(z);
        const sub = rotateLeft(z);
        if (!p) root = sub;
        else if (p.left === z) p.left = sub;
        else p.right = sub;
        snap('RL: double rotate', null, 'RL');
        continue;
      }
      break;
    }
  });

  snap('Final balanced AVL', null, 'done');
  return steps;
}

function refreshAll(n) {
  if (!n) return;
  refreshAll(n.left);
  refreshAll(n.right);
  refresh(n);
}

export default function AVLTreeVisualizer({ config }) {
  const keys = [30, 20, 10, 40, 25, 22, 50];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(keys);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `AVL insert: ${keys.join(', ')}` });
    canvasRef.current?.setState({
      nodes: [],
      edges: [],
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'AVL insert with rotations',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
