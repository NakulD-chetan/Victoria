# Load Balancing — Common Mistakes (Deep Understanding)

> **Permanent Recall:** The top LB mistakes: (1) single LB = SPOF, (2) wrong algorithm for workload, (3) ignoring health checks, (4) not handling session state, (5) overloading one server, (6) ignoring SSL termination, (7) wrong layer (L4 vs L7), (8) no failover, (9) ignoring connection limits, (10) not considering geographic distribution.

---

## Mistake 1: Single Load Balancer (SPOF)

### What Happens

You add 10 backend servers for reliability, but put ONE load balancer in front. If the LB crashes, ALL traffic stops. You made the LB the weakest link.

```
                    ┌──────────┐
   Clients ────────►│  ONE LB  │──────► [S1, S2, S3, S4, S5]
                    └──────────┘
                         ↑
                    If this dies, ALL 5 servers are unreachable.
                    You have 5x backend redundancy but ZERO LB redundancy.
```

### Real-World Scenario

Company X runs their API behind a single Nginx instance on one VM. At 3 AM, the VM's disk fills up (log rotation failed). Nginx can't write temp files → crashes. All API traffic returns "connection refused." The on-call engineer gets paged, takes 20 minutes to respond, another 10 to fix. **30 minutes of total downtime** — all because of one Nginx instance.

### Why People Make This Mistake

- "The LB is simple, it won't fail" — Wrong. LBs run on servers, servers fail.
- "We'll fix it if it breaks" — Manual recovery takes 10-30 minutes. That's 10-30 minutes of downtime.
- Cost avoidance — "Running a second LB costs money." Yes, but downtime costs more.

### How to Fix

| Solution | How It Works | Cost |
|----------|-------------|------|
| **Active-Passive pair** | Second LB on standby; takes over via VIP failover (keepalived) | 2× LB cost |
| **Active-Active cluster** | Multiple LBs all serving traffic; DNS or anycast distributes | 2-3× LB cost |
| **Cloud-managed LB** | AWS ALB/NLB runs across multiple AZs automatically | Pay-per-use |

**Interview Answer:** *"We'd never run a single LB in production. We'd use AWS ALB (HA across AZs) or an active-passive Nginx pair with keepalived for VIP failover."*

---

## Mistake 2: Wrong Algorithm Choice

### What Happens

You use the wrong algorithm for your workload. Traffic is uneven, servers are overloaded or idle, performance is bad.

### Scenario 1: Round Robin for Long-Running Requests

```
You run a video processing API. Some requests take 100ms, others take 60 seconds.

Round Robin sends:
  Request 1 (60s job) → Server 1
  Request 2 (100ms job) → Server 2 (done instantly!)
  Request 3 (60s job) → Server 3
  Request 4 (100ms job) → Server 1 (already busy with 60s job!)
  Request 5 (60s job) → Server 2 (was idle, now got another long job)
  
Result: Server 1 has two 60s jobs running simultaneously → slow.
        Round robin doesn't know Server 1 is already busy.
        
FIX: Use Least Connections. LB sees Server 1 has 1 active connection,
     Server 2 has 0 → sends to Server 2.
```

### Scenario 2: IP Hash Behind NAT/Proxy

```
A corporate office has 5,000 employees behind one NAT gateway.
All 5,000 users share the SAME public IP: 203.0.113.50

IP Hash: hash(203.0.113.50) % 3 = Server 1

ALL 5,000 users hit Server 1. Servers 2 and 3 are idle.
Server 1 is crushed.

FIX: Use cookie-based sticky sessions instead of IP hash.
     Each user gets a unique cookie → distributed across all servers.
```

### Scenario 3: Round Robin for Cache Pool

```
You use memcached with 3 servers. Round Robin for routing:

  Set "user:123" → Server 1
  Get "user:123" → Server 2 (CACHE MISS! Data is on Server 1!)
  
Round Robin sends reads and writes to different servers!

FIX: Use Consistent Hashing.
     hash("user:123") always → Server 1 (for both reads and writes)
```

### Algorithm Decision Table (Memorize This)

| Your Workload | Wrong Algorithm | Right Algorithm | Why |
|---------------|-----------------|-----------------|-----|
| Requests take different times | Round Robin | **Least Connections** | RR ignores load; LC adapts |
| Session affinity behind NAT | IP Hash | **Cookie-based Sticky** | IP hash fails when many users share one IP |
| Cache pool (memcached/Redis) | Round Robin | **Consistent Hashing** | RR routes reads/writes to different servers |
| Servers have different capacity | Round Robin | **Weighted Round Robin** | RR treats all servers equal; WRR respects capacity |
| Simple stateless API | Least Connections | **Round Robin** | LC adds overhead; RR is simpler and sufficient |

---

## Mistake 3: Ignoring Health Checks

### What Happens

Without health checks, the LB sends traffic to crashed/broken servers. Users get connection timeouts, 502 Bad Gateway, or 503 errors.

### Real-World Scenario

```
Server 3 crashes at 2:15 PM (out of memory).

WITHOUT health checks:
  2:15 PM: Server 3 is dead
  2:15 PM: LB still sends 33% of traffic to Server 3
  2:15 PM: Those users see "Connection Refused" or timeout
  2:16 PM: More users hit Server 3 → more errors
  ... continues until someone manually removes Server 3
  
WITH health checks (active, 5s interval, 3 failures):
  2:15:00: Server 3 crashes
  2:15:05: Health check 1 → no response → failure count: 1
  2:15:10: Health check 2 → no response → failure count: 2
  2:15:15: Health check 3 → no response → failure count: 3 → REMOVED
  2:15:15: LB stops sending traffic to Server 3
  
  Users affected: only those who hit Server 3 in the 15-second window
```

### Common Health Check Mistakes

| Mistake | What Goes Wrong | Fix |
|---------|----------------|-----|
| **No health check at all** | Dead servers keep getting traffic | Always configure health checks |
| **Too sensitive (1 failure = unhealthy)** | Server has a brief GC pause → marked dead → removed → other servers overloaded | Set threshold to 2-3 failures |
| **Too lenient (10 failures = unhealthy)** | Takes 50 seconds to detect dead server; many users affected | Set threshold to 2-3 failures, interval 5s |
| **Health endpoint is heavy (queries DB)** | DB slowdown makes ALL servers look unhealthy → LB removes ALL → total outage | Make /health lightweight; separate /health (basic) from /ready (deep) |
| **Health endpoint doesn't check dependencies** | Server is "up" but can't reach DB → serves 500 errors → LB thinks it's healthy | Include critical dependency checks in health response |

### The Right Health Check Design

```
GOOD: Two-tier health check

/health (for LB — lightweight, fast):
  Response: 200 OK if the process is running and can accept connections
  Does NOT check: DB, Redis, external APIs
  Why: Prevents ALL servers from being marked unhealthy if DB is slow

/ready (for monitoring — deep check):
  Response: 200 OK only if DB connected, Redis connected, disk OK
  If DB down: 503 + {"db": "disconnected"}
  Used by: monitoring dashboards, Kubernetes readiness probe
```

---

## Mistake 4: Not Handling Session State

### What Happens

User logs in on Server 1. Next request goes to Server 2. Server 2 doesn't have the session. User is asked to log in again. Frustrating UX.

### Real-World Scenario

```
E-commerce site. User adds items to cart (stored in server memory).

Request 1: Add iPhone to cart → Server 1 (cart: [iPhone])
Request 2: Add Case to cart  → Server 2 (cart: [] ← EMPTY! Server 2 has no cart data)
Request 3: View cart          → Server 3 (cart: [] ← EMPTY AGAIN!)

User sees empty cart 2 out of 3 times. Abandons the site.
```

### Three Solutions (from worst to best)

```
SOLUTION 1: IP Hash (⚠️ Okay but fragile)
  Same IP always goes to same server
  Problem: Mobile user switches WiFi → new IP → different server → session lost
  Problem: Users behind NAT all hit same server

SOLUTION 2: Cookie-based Sticky (✅ Better)
  LB sets cookie: SERVERID=server1
  Browser sends cookie on every request → LB routes to Server 1
  Problem: If Server 1 dies, cookie is useless → session lost

SOLUTION 3: External Session Store (✅✅ Best)
  Session stored in Redis (shared by all servers)
  Any server can read any user's session
  If Server 1 dies, session is still in Redis
  LB uses simple round robin

  Request 1: Add iPhone → Server 1 → writes to Redis {cart: [iPhone]}
  Request 2: Add Case   → Server 2 → reads from Redis {cart: [iPhone]}
                                    → writes to Redis {cart: [iPhone, Case]}
  Request 3: View cart   → Server 3 → reads from Redis {cart: [iPhone, Case]} ✅
```

### When Each Solution is Appropriate

| Situation | Solution |
|-----------|----------|
| Can't use external store (legacy app) | Cookie-based sticky sessions |
| New system, can modify architecture | Stateless backend + Redis session store |
| Cache affinity (not user sessions) | Consistent hashing |
| Simple prototype | IP hash (accept the limitations) |

---

## Mistake 5: Overloading One Server

### What Happens

One server gets more traffic than others due to poor algorithm choice or configuration.

### Real-World Scenario: The Thundering Herd on One Server

```
CAUSE: You use IP hash. A major ISP routes 50,000 users through one proxy IP.

hash(ISP_proxy_IP) % 3 = Server 1

Server 1: 50,000 users (from ISP) + 10,000 other users = 60,000
Server 2: 10,000 users
Server 3: 10,000 users

Server 1 is at 600% capacity → crashes → cascade failure
```

### Common Causes and Fixes

| Cause | Why It Happens | Fix |
|-------|---------------|-----|
| IP hash + NAT | Many users share one public IP | Cookie-based sticky, or round robin |
| Round robin + variable request duration | Long requests pile up on one server | Least connections |
| One server is weaker | 2-core VM mixed with 8-core VMs, same weight | Weighted round robin (match weights to capacity) |
| Consistent hashing hot keys | One key (e.g., celebrity's data) is accessed 1000× more | Virtual nodes + bounded load |
| No connection limits | One server accepts unlimited connections | Set `maxconn` per server in LB config |

---

## Mistake 6: Ignoring SSL Termination

### What Happens

Every backend server handles SSL encryption/decryption. This wastes CPU, complicates certificate management, and slows down responses.

### Why This is Bad

```
WITHOUT SSL termination at LB:
  Client ──HTTPS──► LB ──HTTPS──► Server 1 (decrypts SSL)
  Client ──HTTPS──► LB ──HTTPS──► Server 2 (decrypts SSL)
  Client ──HTTPS──► LB ──HTTPS──► Server 3 (decrypts SSL)
  
  Problems:
  1. Every server wastes CPU on SSL decryption (SSL uses ~20% of CPU)
  2. Every server needs the SSL certificate installed
  3. Certificate renewal: update cert on EVERY server (10 servers = 10 updates)
  4. Different cert versions possible → security risk

WITH SSL termination at LB:
  Client ──HTTPS──► LB (decrypts SSL) ──HTTP──► Server 1 (plain HTTP)
  Client ──HTTPS──► LB (decrypts SSL) ──HTTP──► Server 2 (plain HTTP)
  Client ──HTTPS──► LB (decrypts SSL) ──HTTP──► Server 3 (plain HTTP)
  
  Benefits:
  1. Servers focus on business logic (no SSL overhead)
  2. One certificate, managed at LB only
  3. Certificate renewal: update one place
  4. Backend traffic is plain HTTP (faster, simpler)
```

### When to NOT Terminate SSL at LB

| Scenario | Why Keep SSL End-to-End |
|----------|------------------------|
| **Compliance (PCI-DSS, HIPAA)** | Regulations require encryption in transit everywhere, including internal network |
| **Zero-trust network** | Don't trust internal network; encrypt everything |
| **LB can't handle SSL volume** | CPU-bound LB at very high scale; move SSL to backends |

**In these cases, use SSL re-encryption:** LB terminates client SSL, then opens a NEW SSL connection to the backend. This way, LB can still inspect HTTP, but internal traffic is encrypted too.

---

## Mistake 7: Wrong Layer Choice (L4 vs L7)

### What Happens

You use L4 when you need HTTP routing, or L7 when you need max TCP throughput.

### Scenario 1: Using L4 When You Need Path Routing

```
You have two services: user-service and order-service
You want: /api/users → user-service, /api/orders → order-service

With L4 LB:
  L4 sees: "TCP connection to port 443" → forwards to... one of the servers?
  L4 CANNOT read the URL path. It doesn't know if it's /users or /orders.
  It sends both to the same server pool → you can't separate services!

FIX: Use L7 LB that reads HTTP path and routes accordingly.
```

### Scenario 2: Using L7 for Raw TCP Database Proxy

```
You want to load-balance connections to PostgreSQL read replicas.
PostgreSQL uses its own binary TCP protocol, NOT HTTP.

With L7 LB:
  L7 tries to parse incoming data as HTTP... it's not HTTP → errors/confusion.
  L7 has unnecessary overhead (HTTP parser, header processing).

FIX: Use L4 LB. It just forwards TCP packets without trying to read HTTP.
     HAProxy in TCP mode or AWS NLB.
```

### Decision Helper

```
What protocol does your backend use?

  HTTP/HTTPS → L7 (can route by path, terminate SSL)
  gRPC → L7 (gRPC is HTTP/2 based; L7 can route by gRPC service name)
  WebSocket → L7 (WebSocket starts as HTTP upgrade)
  PostgreSQL/MySQL → L4 (binary TCP protocol)
  Redis → L4 (RESP protocol over TCP)
  Custom TCP → L4 (L7 doesn't understand your protocol)
  UDP (gaming, DNS) → L4 (L7 is HTTP only)
```

---

## Mistake 8: No Failover Plan

### What Happens

LB fails, and there's no automatic recovery. Someone has to wake up at 3 AM, SSH into servers, and manually fix things.

### Real-World Scenario

```
2:47 AM: LB server's kernel panics due to hardware issue
2:47 AM: ALL traffic starts failing
2:52 AM: Monitoring alert fires (5-minute detection delay)
3:10 AM: On-call engineer wakes up, reads alert
3:20 AM: Engineer SSHs in, realizes LB is dead
3:35 AM: Engineer manually starts backup LB, updates DNS
3:45 AM: DNS propagates, traffic starts flowing

Total downtime: ~58 minutes

WITH automated failover:
2:47 AM: LB server's kernel panics
2:47 AM: Passive LB detects missing heartbeat (3 missed × 1s = 3 seconds)
2:47:03: Passive LB takes over VIP via gratuitous ARP
2:47:03: Traffic flows to new LB
Total downtime: ~3 seconds
```

### Failover Options

| Mechanism | How It Works | Failover Time |
|-----------|-------------|---------------|
| **Keepalived (VRRP)** | Active/passive LBs. Passive monitors heartbeat. Takes over VIP on failure. | 1-5 seconds |
| **Cloud-managed LB** | Provider handles failover across AZs | 0-30 seconds (varies) |
| **DNS failover** | Health check removes failed LB IP from DNS | 30-300 seconds (DNS TTL) |
| **Anycast** | Same IP routed by BGP; network routes around dead node | 10-60 seconds (BGP convergence) |
| **Manual** | Human fixes it | 10-60 minutes |

---

## Mistake 9: Ignoring Connection Limits

### What Happens

LB or backend runs out of available connections. New requests queue up and timeout. Users see slow responses or errors.

### Why Connection Limits Matter

```
Every TCP connection uses:
  - A file descriptor on the LB and backend
  - Memory (~10KB per connection)
  - CPU for processing

Linux defaults:
  - Max open files (ulimit): 1024 (WAY too low for a load balancer!)
  - Max connections (somaxconn): 128

If your LB hits 1024 connections with default ulimit:
  Connection 1025 → REFUSED → user sees error
```

### How to Fix

| Limit | Where | Default | Recommended | How to Change |
|-------|-------|---------|-------------|---------------|
| **File descriptors** | LB host OS | 1024 | 100000+ | `ulimit -n 100000` or `/etc/security/limits.conf` |
| **somaxconn** | Kernel | 128 | 65535 | `sysctl -w net.core.somaxconn=65535` |
| **maxconn per backend** | LB config | Unlimited | Match backend capacity | HAProxy: `server s1 ... maxconn 1000` |
| **Backend connection pool** | Application | Varies | Tune to match | DB pool size, HTTP keep-alive count |

### The Connection Budget Calculation

```
Example: 3 backend servers, each can handle 2000 concurrent connections

Total capacity: 3 × 2000 = 6000 concurrent connections

LB should allow: at least 6000 connections to backends
  + some buffer for LB's own connections (health checks, management)
  = set LB maxconn to 8000-10000

Backend maxconn per server in LB config: 2000
  (prevents LB from sending more than backend can handle)
```

---

## Mistake 10: Not Considering Geographic Distribution

### What Happens

All your servers are in one region. Users on the other side of the world experience 200-400ms latency on every request.

### Real-World Impact

```
Server location: Virginia, US

User in Virginia:  API call takes ~20ms (server is nearby)
User in London:    API call takes ~120ms (Atlantic Ocean)
User in Mumbai:    API call takes ~250ms (half the world away)
User in Sydney:    API call takes ~300ms (almost opposite side)

For a chat app, 300ms per message is PAINFUL.
For a trading platform, 300ms can cost millions.
```

### How GSLB Fixes This

```
WITH GSLB (Global Server Load Balancing):

Deploy servers in 3 regions:
  - Virginia (US)
  - London (EU)
  - Mumbai (India)

GSLB (Route53 / Cloudflare):
  User in Virginia → Virginia server (20ms)
  User in London   → London server (20ms)
  User in Mumbai   → Mumbai server (20ms)

Everyone gets ~20ms latency!
```

### When to Add Multi-Region

| Signal | Action |
|--------|--------|
| Users complain about slowness from specific regions | Add server in that region + GSLB |
| Business expanding to new country | Deploy in nearest cloud region |
| Latency-sensitive app (gaming, trading, chat) | Multi-region from day one |
| Compliance (data must stay in-country, GDPR) | Deploy in that country's region |

---

## Mistake Summary Table

| # | Mistake | Real Impact | One-Line Fix | Severity |
|---|---------|------------|--------------|----------|
| 1 | Single LB (SPOF) | LB crash = total outage | Active-passive pair or cloud HA LB | Critical |
| 2 | Wrong algorithm | Uneven load, overloaded servers | Match algorithm to workload type | High |
| 3 | No health checks | Traffic to dead servers → user errors | Active probes, 2-3 failure threshold | Critical |
| 4 | Session state ignored | Users lose sessions across requests | Stateless + Redis, or cookie sticky | High |
| 5 | Overloading one server | One server crushed, others idle | Least conn, cookie sticky, weight tuning | Medium |
| 6 | No SSL termination | Wasted CPU, cert management hell | Terminate at LB; one cert, one place | Medium |
| 7 | Wrong L4/L7 choice | Can't route by path, or wasting resources | L4 for TCP; L7 for HTTP routing | High |
| 8 | No failover | Manual recovery = 30+ min downtime | Automated failover (keepalived, cloud HA) | Critical |
| 9 | Connection limits | Connections refused under load | Tune ulimit, maxconn, connection pooling | Medium |
| 10 | No geo distribution | High latency for distant users | GSLB + multi-region deployment | Medium |

---

## Quick Memory Card

```
SPOF:           Single LB → ALWAYS use pair/cluster/cloud HA
ALGORITHM:      Match to workload (stateless→RR, variable→LC, cache→CH)
HEALTH:         Always configure. 2-3 failures, 5s interval, lightweight endpoint
SESSION:        Stateless + Redis (best) or cookie sticky (fallback)
OVERLOAD:       Check for NAT skew, unequal servers, hot keys
SSL:            Terminate at LB. One cert, one place. Re-encrypt if compliance needs.
LAYER:          HTTP → L7. TCP/UDP/DB → L4. Never the opposite.
FAILOVER:       Automated. Keepalived, cloud HA. Never manual.
CONNECTIONS:    Tune ulimits (100K+), maxconn per backend, connection pooling
GEO:            Multi-region + GSLB for global users
```

---

**Next:** [[06_Edge-Cases]]
