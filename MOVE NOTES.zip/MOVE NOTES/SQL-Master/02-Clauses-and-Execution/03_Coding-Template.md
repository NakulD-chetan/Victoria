# Clauses and Execution — Coding Templates

---

## 1) Filter + sort + page

```sql
SELECT col1, col2
FROM t
WHERE col1 > 100
  AND col2 IS NOT NULL
ORDER BY col1 DESC
LIMIT 20 OFFSET 40;
```

---

## 2) CASE expression

```sql
SELECT
    order_id,
    amount,
    CASE
        WHEN amount >= 1000 THEN 'high'
        WHEN amount >= 100 THEN 'mid'
        ELSE 'low'
    END AS tier
FROM orders;
```

---

## 3) GROUP + HAVING

```sql
SELECT dept_id, COUNT(*) AS cnt
FROM employees
WHERE active = TRUE
GROUP BY dept_id
HAVING COUNT(*) >= 5;
```

---

## 4) Repeat alias workaround (no alias in WHERE)

```sql
SELECT *
FROM (
    SELECT a * b AS area FROM rects
) s
WHERE s.area > 100;
```

---

*Next: [[04_Interview-Thinking]]*
