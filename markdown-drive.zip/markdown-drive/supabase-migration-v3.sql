-- Migration v3: Submissions table for server-side anti-cheat scoring
-- Run this in the Supabase Dashboard SQL editor

CREATE TABLE IF NOT EXISTS submissions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  problem_slug TEXT NOT NULL,
  user_id TEXT,
  components JSONB NOT NULL,
  connections JSONB NOT NULL,
  test_results JSONB NOT NULL,
  chaos_results JSONB,
  arch_score INT NOT NULL DEFAULT 0,
  deep_dive_score INT DEFAULT 0,
  hints_used INT DEFAULT 0,
  total_score INT NOT NULL DEFAULT 0,
  verdict TEXT NOT NULL DEFAULT 'Needs Practice',
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_submissions_problem ON submissions(problem_slug);
CREATE INDEX IF NOT EXISTS idx_submissions_created ON submissions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_submissions_score ON submissions(total_score DESC);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous inserts" ON submissions
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow anonymous reads" ON submissions
  FOR SELECT USING (true);
