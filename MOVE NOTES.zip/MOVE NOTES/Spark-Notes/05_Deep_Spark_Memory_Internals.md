# Spark Memory Internals — The Complete Deep Analysis

This goes far beyond the basics. Here we cover **WHY** each memory region exists, **WHAT** exactly happens inside it, **WHEN** things go wrong, **HOW** to trace and debug, and **real-world scenarios** that will make you truly understand Spark memory.

---

## Part 1: The Big Picture — Why Does Spark Even Need a Memory Model?

### The Problem Spark Solves

Imagine you have 1 TB of data. One machine has 64 GB RAM. You can't fit 1 TB into 64 GB.

Spark's solution: **split the 1 TB across many machines** and process each piece in parallel.

But now you have a NEW problem: each machine has limited memory, and it needs to:

- Read data from disk
- Transform it (filter, map, join)
- Hold intermediate results (hash tables for joins, sort buffers)
- Cache data for reuse
- Shuffle data to other machines
- Run your custom code (UDFs)

**All of this competes for the SAME limited memory.** Without rules, they'd fight and crash.

That's why Spark has a **Memory Model** — a set of rules that divide memory into regions, each with a clear purpose, and define who gets priority when memory runs out.

### The Evolution (Why It Changed)


| Spark Version | Memory Model               | Problem                                                                                                 |
| ------------- | -------------------------- | ------------------------------------------------------------------------------------------------------- |
| Before 1.6    | **Static Memory Manager**  | Fixed boundaries. If execution needed more but storage was empty → wasted memory. No borrowing allowed. |
| 1.6 onwards   | **Unified Memory Manager** | Flexible boundaries. Execution and storage can borrow from each other. Much more efficient.             |


The Static model was like having two rooms with a **brick wall** — even if one room was empty, the other couldn't use it. The Unified model replaced the brick wall with a **curtain** — either side can push it when needed.

---

## Part 2: The Complete Memory Map — Every Byte Accounted For

Let's trace EXACTLY where every byte of memory goes in an executor.

### The Container View (What YARN/K8s Sees)

When Spark requests an executor, the cluster manager (YARN/Kubernetes) allocates a **container** with a fixed amount of memory. This container has HARD limits — if the process exceeds it, the container is killed.

```
┌══════════════════════════════════════════════════════════════════┐
║                    CONTAINER (from YARN/K8s)                     ║
║                                                                  ║
║   Total = spark.executor.memory                                  ║
║         + spark.executor.memoryOverhead                          ║
║         + spark.memory.offHeap.size        (if enabled)          ║
║         + spark.executor.pyspark.memory    (if PySpark UDFs)     ║
║                                                                  ║
║  ┌────────────────────────────────────────────────────────────┐  ║
║  │                                                            │  ║
║  │                   JVM HEAP MEMORY                          │  ║
║  │              (spark.executor.memory)                       │  ║
║  │                                                            │  ║
║  │  ┌──────────────────────────────────────────────────────┐  │  ║
║  │  │ RESERVED MEMORY (300 MB - hardcoded)                  │  │  ║
║  │  │                                                        │  │  ║
║  │  │ Purpose: Spark's own internal objects that MUST        │  │  ║
║  │  │ always be in memory. Safety buffer so Spark itself     │  │  ║
║  │  │ never crashes.                                         │  │  ║
║  │  │                                                        │  │  ║
║  │  │ Contains:                                              │  │  ║
║  │  │   - Spark internal configuration objects               │  │  ║
║  │  │   - Memory manager's own tracking structures           │  │  ║
║  │  │   - Broadcast manager internals                        │  │  ║
║  │  │   - Block manager metadata                             │  │  ║
║  │  │                                                        │  │  ║
║  │  │ NOTE: If executor memory < 1.5× reserved (< 450 MB),  │  │  ║
║  │  │ Spark throws an error and refuses to start.            │  │  ║
║  │  └──────────────────────────────────────────────────────┘  │  ║
║  │                                                            │  ║
║  │  ┌──────────────────────────────────────────────────────┐  │  ║
║  │  │ USABLE MEMORY = Heap - 300 MB                        │  │  ║
║  │  │                                                        │  │  ║
║  │  │  ┌─────────────────────┐  ┌────────────────────────┐  │  │  ║
║  │  │  │                     │  │                        │  │  │  ║
║  │  │  │   SPARK MEMORY      │  │    USER MEMORY         │  │  │  ║
║  │  │  │   (60% default)     │  │    (40% default)       │  │  │  ║
║  │  │  │                     │  │                        │  │  │  ║
║  │  │  │  ┌───────────────┐  │  │  Your code's objects:  │  │  │  ║
║  │  │  │  │  EXECUTION    │  │  │  - UDF variables       │  │  │  ║
║  │  │  │  │  MEMORY       │  │  │  - Custom classes      │  │  │  ║
║  │  │  │  │  (50%)        │  │  │  - HashMap/ArrayList   │  │  │  ║
║  │  │  │  │               │  │  │  - Temp collections    │  │  │  ║
║  │  │  │  │  Active work: │  │  │  - Iterator buffers    │  │  │  ║
║  │  │  │  │  joins,sorts  │  │  │  - Deserialized objs   │  │  │  ║
║  │  │  │  │  shuffles,    │  │  │                        │  │  │  ║
║  │  │  │  │  aggregations │  │  │  NOT managed by Spark  │  │  │  ║
║  │  │  │  ├───────────────┤  │  │  Spark has no control  │  │  │  ║
║  │  │  │  │  STORAGE      │  │  │  over this region.     │  │  │  ║
║  │  │  │  │  MEMORY       │  │  │  If your code creates  │  │  │  ║
║  │  │  │  │  (50%)        │  │  │  too many objects here  │  │  │  ║
║  │  │  │  │               │  │  │  → OOM and Spark can't │  │  │  ║
║  │  │  │  │  cache(),     │  │  │  help you.             │  │  │  ║
║  │  │  │  │  persist(),   │  │  │                        │  │  │  ║
║  │  │  │  │  broadcast    │  │  │                        │  │  │  ║
║  │  │  │  └───────────────┘  │  │                        │  │  │  ║
║  │  │  └─────────────────────┘  └────────────────────────┘  │  │  ║
║  │  └──────────────────────────────────────────────────────┘  │  ║
║  └────────────────────────────────────────────────────────────┘  ║
║                                                                  ║
║  ┌────────────────────────────────────────────────────────────┐  ║
║  │ OVERHEAD MEMORY (off-heap, outside JVM)                    │  ║
║  │ spark.executor.memoryOverhead                              │  ║
║  │                                                            │  ║
║  │ - JVM internal structures (class metadata, JIT code)       │  ║
║  │ - Thread stacks (each thread ~1 MB)                        │  ║
║  │ - Netty direct buffers (network I/O for shuffle)           │  ║
║  │ - NIO buffers for file I/O                                 │  ║
║  │ - Native libraries (compression: snappy, zstd, lz4)       │  ║
║  │ - Memory-mapped files                                      │  ║
║  └────────────────────────────────────────────────────────────┘  ║
║                                                                  ║
║  ┌────────────────────────────────────────────────────────────┐  ║
║  │ OFF-HEAP SPARK MEMORY (optional, Tungsten)                 │  ║
║  │ spark.memory.offHeap.size                                  │  ║
║  │                                                            │  ║
║  │ - UnsafeRow binary data (Tungsten format)                  │  ║
║  │ - Sort buffers for shuffle                                 │  ║
║  │ - Hash tables for joins                                    │  ║
║  │ - Managed by sun.misc.Unsafe (direct memory access)        │  ║
║  │ - NO garbage collection here (huge advantage)              │  ║
║  └────────────────────────────────────────────────────────────┘  ║
║                                                                  ║
║  ┌────────────────────────────────────────────────────────────┐  ║
║  │ PYSPARK MEMORY (if Python UDFs used)                       │  ║
║  │ spark.executor.pyspark.memory                              │  ║
║  │                                                            │  ║
║  │ - Separate Python process (not JVM)                        │  ║
║  │ - Runs your Python UDF code                                │  ║
║  │ - pandas, numpy, scikit-learn objects live here             │  ║
║  │ - Communicates with JVM via socket/pipe                    │  ║
║  └────────────────────────────────────────────────────────────┘  ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## Part 3: Reserved Memory — Why 300 MB? What Happens Without It?

### Why It Exists

Spark itself is a program running inside the JVM. It needs memory for its own objects:

- The `MemoryManager` object that tracks all memory allocations
- The `BlockManager` that manages cached data blocks
- The `ShuffleManager` that manages shuffle operations
- Internal configuration objects
- Metrics and monitoring objects

If a user's task consumed ALL memory, these internal objects would be garbage collected or cause an OOM — and Spark itself would crash, not just the task.

**300 MB is the safety buffer** that guarantees Spark's core always has enough room to function.

### What Happens If You Set Executor Memory Too Low

```python
spark.executor.memory = 400 MB
```

Spark checks: `400 MB < 1.5 × 300 MB = 450 MB` → **ERROR**

```
IllegalArgumentException: Executor memory 400 MB must be at least
450 MB (1.5 * 300 MB reserved memory)
```

Spark refuses to even start because with only 100 MB of usable memory, nothing meaningful can run.

### Can You Change 300 MB?

No. It is **hardcoded** in the Spark source code:

```scala
// In org.apache.spark.memory.UnifiedMemoryManager
val RESERVED_SYSTEM_MEMORY_BYTES = 300 * 1024 * 1024  // 300 MB
```

You cannot configure this. It's a design decision baked into Spark.

---

## Part 4: Execution Memory — Everything That Happens Inside It

Execution memory is where **all active computation** happens. Let's trace exactly what uses it for each operation.

### 4.1: During a JOIN (Sort-Merge Join)

```
Step 1: Task reads its partition of df1
        → Data enters EXECUTION MEMORY as UnsafeRows

Step 2: Sort df1 partition by join key
        → Spark creates a sort buffer in EXECUTION MEMORY
        → If buffer exceeds available execution memory → SPILL TO DISK
        → Spill creates sorted temporary files on local disk

Step 3: Same for df2 partition
        → Read, sort, maybe spill

Step 4: Merge-join the two sorted streams
        → Walk both sorted lists simultaneously
        → Matching keys → output row
        → Only needs a small window of memory (merge is streaming)

Total execution memory needed ≈ size of LARGEST partition being sorted
```

### 4.2: During a JOIN (Broadcast Hash Join)

```
Step 1: Small DataFrame is broadcast to all executors
        → Arrives in STORAGE MEMORY (broadcast variable)

Step 2: Executor builds a HASH MAP from the small DataFrame
        → Hash map goes into EXECUTION MEMORY (or USER MEMORY)
        → hash_map[key] = list of matching rows

Step 3: For each row in the large DataFrame partition:
        → Look up key in hash map → O(1) lookup
        → Output matched rows
        → Only current row needs to be in memory

Total execution memory needed ≈ size of HASH MAP from small DataFrame
```

### 4.3: During a groupBy().agg()

```
Step 1: Task reads its partition
        → Data enters EXECUTION MEMORY

Step 2: For each row, Spark updates an in-memory HASH MAP:
        → hash_map[group_key] = partial_aggregate
        → Example: hash_map["Mumbai"] = {count: 453, sum: 12345.67}

Step 3: If hash map exceeds execution memory → SPILL
        → Sort the hash map entries by key
        → Write sorted entries to disk
        → Clear the hash map, start fresh for remaining rows

Step 4: After all rows processed:
        → Merge all spill files + remaining in-memory data
        → Produce final aggregated results

Step 5: Shuffle write the results (for the next stage to read)

Total execution memory needed ≈ size of HASH MAP
  = number of UNIQUE keys × size of aggregate state per key
```

### 4.4: During a SORT (orderBy)

```
Step 1: Read partition data into sort buffer in EXECUTION MEMORY

Step 2: Sort using Tungsten's UnsafeExternalSorter:
        → Stores data as binary (UnsafeRow format)
        → Uses pointer-based sorting (sort pointers, not actual data)
        → This is MUCH faster than sorting Java objects

Step 3: If sort buffer exceeds memory → SPILL
        → Write sorted run to disk
        → Each spill produces one sorted file

Step 4: Merge all sorted runs (in-memory + spill files)
        → External merge sort (k-way merge)
        → Produces final sorted output

Total execution memory needed ≈ partition size
  (but pointer sorting + binary format reduces memory by ~4x)
```

### 4.5: During SHUFFLE WRITE

```
Step 1: Task finishes its computation
        → Output rows need to be partitioned for next stage

Step 2: For each output row:
        → Compute hash(key) % num_shuffle_partitions
        → Write row into the correct bucket in a SHUFFLE BUFFER

Step 3: Shuffle buffer is in EXECUTION MEMORY
        → If buffer fills up → SORT and SPILL to disk

Step 4: After all rows processed:
        → Merge all spill files into final shuffle data file + index file
        → These files stay on LOCAL DISK for the next stage to fetch

Total execution memory needed ≈ size of shuffle buffer
  (configurable, but typically bounded by available execution memory)
```

---

## Part 5: Storage Memory — Deep Internal Mechanics

### 5.1: What Happens When You Call cache()

```python
df = spark.read.parquet("huge_table.parquet")
df_filtered = df.filter(col("status") == "active")
df_filtered.cache()       # Step 1: MARKS for caching (lazy)
df_filtered.count()       # Step 2: TRIGGERS computation + caching
```

**Internal flow at Step 2:**

```
1. Spark plans the computation (read + filter + count)
2. Tasks are sent to executors
3. Each task reads its partition from parquet
4. Applies filter (status == "active")
5. BEFORE returning results, Spark checks: "Is this RDD/DF marked for caching?"
6. YES → Store the computed partition in STORAGE MEMORY

   How storage works:
   a) Each partition becomes a "Block" with a unique BlockId
      Example: rdd_42_partition_7

   b) Block is stored as either:
      - Deserialized Java objects (MEMORY_ONLY) → fast to read, uses more memory
      - Serialized byte array (MEMORY_ONLY_SER) → slower to read, uses less memory

   c) BlockManager on the executor registers this block
      → Records: blockId, size, storage level, location

   d) BlockManager on Driver also gets notified
      → Maintains a global map of all cached blocks across the cluster

7. count() uses the now-cached data
8. Next time you use df_filtered → reads from STORAGE MEMORY directly
   → Skips reading parquet + filtering again
```

### 5.2: Block Eviction — What Happens When Storage Memory Is Full

```
Scenario: Storage memory = 2.91 GB, already has 2.8 GB of cached data.
You try to cache another 500 MB DataFrame.

Step 1: BlockManager checks: "Is there enough free storage memory?"
        → Free = 2.91 - 2.8 = 0.11 GB = 110 MB
        → Needed = 500 MB
        → Not enough!

Step 2: Can we borrow from Execution memory?
        → Check if Execution has unused space
        → If yes → expand storage boundary temporarily

Step 3: If still not enough → LRU EVICTION
        → Find the OLDEST cached block (Least Recently Used)
        → Check its storage level:

        MEMORY_ONLY:
          → Drop the block from memory entirely
          → Data is LOST (must be recomputed from DAG lineage)
          → Spark logs: "Block rdd_XX_partition_YY dropped from memory"

        MEMORY_AND_DISK:
          → Write the block to LOCAL DISK first
          → Then free the memory
          → Data is NOT lost (can be read back from disk later)

        DISK_ONLY:
          → Already on disk, nothing to evict from memory

Step 4: Repeat eviction until enough space is freed
Step 5: Store the new block

IMPORTANT: If eviction freed space that Execution later needs,
Execution CAN reclaim it (execution has priority).
This might cause a cascade of evictions.
```

### 5.3: Why Different Storage Levels Exist


| Storage Level         | HOW data is stored                     | SPEED                                    | MEMORY                                        | WHY use it                                                                           |
| --------------------- | -------------------------------------- | ---------------------------------------- | --------------------------------------------- | ------------------------------------------------------------------------------------ |
| `MEMORY_ONLY`         | Java objects in heap                   | Fastest read (no deserialization needed) | Highest (object headers, pointers eat memory) | Default. Use when memory is plentiful and you need speed.                            |
| `MEMORY_ONLY_SER`     | Serialized bytes in heap               | Slower read (must deserialize)           | Lower (compact binary, no object overhead)    | Use when memory is tight but you still want RAM-only caching. Trades CPU for memory. |
| `MEMORY_AND_DISK`     | Java objects in heap, overflow to disk | Fast if in memory, slow if on disk       | Uses memory first, disk as backup             | Use for data you MUST not lose (recomputation is very expensive). Safest option.     |
| `MEMORY_AND_DISK_SER` | Serialized bytes, overflow to disk     | Slowest                                  | Lowest memory usage                           | Use for very large datasets where both memory and recomputation are concerns.        |
| `DISK_ONLY`           | Only on local disk                     | Very slow                                | Zero memory usage                             | Use when you need to cache but have no memory to spare. Rare.                        |
| `MEMORY_ONLY_2`       | Java objects, replicated on 2 nodes    | Fast, fault tolerant                     | 2× memory                                     | Use when losing cache causes major delays AND executor failures are common.          |


### Decision Tree: Which Storage Level?

```
Do you have plenty of executor memory?
  YES → MEMORY_ONLY (default, fastest)
  NO  ↓

Is recomputation cheap (simple transformations)?
  YES → MEMORY_ONLY (let eviction handle it, recompute when needed)
  NO  ↓

Is recomputation expensive (complex joins, heavy ETL)?
  YES → MEMORY_AND_DISK (don't lose the data)
  NO  ↓

Are you running out of memory with MEMORY_ONLY?
  YES → MEMORY_ONLY_SER (same speed, less memory)
  
Are executors frequently failing (unstable cluster)?
  YES → MEMORY_ONLY_2 (replicated, survives executor loss)
```

---

## Part 6: User Memory — The Unmanaged Danger Zone

### Why User Memory Is Dangerous

Spark manages Execution and Storage memory carefully — it tracks every byte, handles eviction, handles spilling.

**User Memory is NOT managed by Spark at all.** Whatever objects your code creates go into User Memory, and Spark has ZERO visibility into it.

### What Lives in User Memory

```python
# Example 1: UDF with large object
@udf(returnType=StringType())
def categorize(value):
    big_dict = load_dictionary()  # This dict lives in USER MEMORY
    return big_dict.get(value, "unknown")

# Example 2: mapPartitions with accumulation
def process_partition(iterator):
    results = []          # This list lives in USER MEMORY
    model = load_model()  # This model lives in USER MEMORY
    for row in iterator:
        results.append(model.predict(row))
    return iter(results)  # All results held in memory until returned!

# Example 3: Broadcast hash table on executor side
# When executor receives a broadcast variable and builds a hash map
# from it, that hash map lives in USER MEMORY
```

### Why User Memory OOM Is Hard to Debug

When User Memory causes OOM:

- Spark doesn't log "User Memory exceeded" — there's no such metric
- You just see `java.lang.OutOfMemoryError: Java heap space`
- It looks exactly like an Execution or Storage OOM
- Spark UI doesn't show User Memory usage separately

**How to tell it's User Memory:**

1. If you're using UDFs with large objects → likely User Memory
2. If `mapPartitions` accumulates results in a list → likely User Memory
3. If OOM happens during a simple `map()` or `filter()` (not a join/shuffle) → likely User Memory
4. If Spark UI shows low Storage and low Execution usage but still OOM → User Memory

---

## Part 7: The Unified Memory Manager — Deep Mechanics

### 7.1: How Borrowing Actually Works (Code-Level Logic)

When a task requests execution memory:

```
function acquireExecutionMemory(numBytes):
    
    1. Check: Is there free execution memory?
       → YES: Allocate and return. Done.
       → NO: Continue...

    2. Check: Is there free storage memory (storage not using its full share)?
       → YES: Borrow from storage's unused space.
       → Execution boundary expands, storage boundary shrinks.
       → Allocate and return. Done.
       → NO: Continue...

    3. Check: Can we evict storage blocks?
       → Find LRU storage block
       → Check: Was this block stored in "borrowed" execution space?
         → If storage is using MORE than its guaranteed fraction:
           YES: We can evict it (it was borrowing from execution anyway)
         → If storage is within its guaranteed fraction:
           YES: We can STILL evict it (execution always wins)
       → Evict block, free memory, allocate. Done.
       → NO (nothing to evict): Continue...

    4. No memory available → SPILL current task's data to disk
       → Sort in-memory data, write to disk
       → Free execution memory
       → Continue processing with less memory
       → Performance degrades but task doesn't fail

    5. If even spilling can't help (extremely rare):
       → java.lang.OutOfMemoryError
       → Task fails, Spark may retry on another executor
```

When a task requests storage memory (cache):

```
function acquireStorageMemory(numBytes):
    
    1. Check: Is there free storage memory?
       → YES: Allocate and return. Done.
       → NO: Continue...

    2. Check: Is there free execution memory (execution not using its full share)?
       → YES: Borrow from execution's unused space.
       → Storage boundary expands, execution boundary shrinks.
       → Allocate and return. Done.
       → NO: Continue...

    3. Check: Can we evict OTHER storage blocks?
       → Find LRU block among OTHER cached DataFrames
       → Evict it, free space, allocate new block. Done.
       → NO: Continue...

    4. CANNOT evict execution memory — even if execution is using storage's space
       → The cache request FAILS
       → The block is simply NOT cached
       → Spark logs a warning but the task continues
       → Data will be recomputed next time it's needed

    CRITICAL DIFFERENCE: Execution can evict storage and can spill.
                         Storage can ONLY evict other storage blocks.
                         Storage NEVER causes a task failure.
```

### 7.2: The Guaranteed Minimum

Even though boundaries are flexible, storage has a **guaranteed minimum** = `spark.memory.storageFraction` (default 50% of Spark Memory).

This means:

- Execution can borrow storage memory above the 50% mark freely
- Execution can evict storage memory BELOW the 50% mark too (if needed)
- But Spark tries to keep at least 50% available for storage when possible

**Why?** Without a minimum, aggressive execution tasks could evict ALL cached data, making caching useless. The 50% guarantee means at least some cached data survives heavy computation.

### 7.3: Real Scenario — What Happens During a Join + Cache Conflict

```
Setup:
  Spark Memory = 5.82 GB
  Execution = 2.91 GB
  Storage = 2.91 GB
  Currently cached: 2.5 GB of data in storage

Now a Sort-Merge Join starts. It needs 4 GB of execution memory.

Timeline:

T1: Join task requests 2.91 GB (its execution share)
    → Execution memory has 2.91 GB available
    → GRANTED. Execution is now full.

T2: Join needs more memory (sort buffers). Requests 1 GB more.
    → Execution is full (2.91 GB used)
    → Check storage: 2.91 GB total, 2.5 GB used by cache
    → Free storage space = 0.41 GB
    → Borrow 0.41 GB from storage
    → Still need 0.59 GB more

T3: Execution evicts LRU cached blocks from storage
    → Evicts 0.59 GB of oldest cached data
    → Now execution has 2.91 + 0.41 + 0.59 = 3.91 GB
    → Storage has 2.91 - 0.41 - 0.59 = 1.91 GB (with 1.91 GB cache remaining)

T4: Join still needs more (4 GB total, has 3.91 GB)
    → Needs 0.09 GB more
    → Evicts more cache → now has 4 GB
    → Storage has 1.82 GB cache remaining

T5: Join processes data using 4 GB execution memory
    → SUCCEEDS

T6: Join completes, releases 4 GB
    → Execution memory freed
    → Storage boundary can expand back
    → BUT evicted cache is GONE — must be recomputed if needed

T7: Next action on the cached DataFrame
    → Some partitions are still cached (1.82 GB worth)
    → Missing partitions are recomputed from source (DAG lineage)
    → Recomputed partitions are cached again (if memory available)
```

---

## Part 8: How to Track Memory in Spark UI (Step-by-Step Debugging Guide)

### 8.1: Spark UI — Executors Tab

**URL**: `http://<driver-host>:4040/executors/`

This page shows per-executor memory usage:

```
┌─────────────┬──────────────┬──────────────┬─────────────┬──────────────┐
│ Executor ID │ Storage Mem  │ Storage Used │ Disk Used   │ Active Tasks │
│             │ (total)      │ (cached data)│ (spilled)   │              │
├─────────────┼──────────────┼──────────────┼─────────────┼──────────────┤
│ 0           │ 2.91 GB      │ 1.2 GB       │ 0           │ 4            │
│ 1           │ 2.91 GB      │ 2.8 GB       │ 340 MB      │ 4            │
│ 2           │ 2.91 GB      │ 0.5 GB       │ 0           │ 2            │
└─────────────┴──────────────┴──────────────┴─────────────┴──────────────┘
```

**What to look for:**

- **Storage Used close to Storage Mem** → cache is nearly full, evictions likely
- **Disk Used > 0** → data is being spilled from memory to disk (either cache or execution)
- **Uneven Storage Used** → data is skewed, some executors hold more than others

### 8.2: Spark UI — Stage Details (Task Metrics)

**URL**: `http://<driver-host>:4040/stages/stage/?id=X&attempt=0`

Click on a specific stage to see task-level metrics:

```
┌──────────┬──────────┬──────────────┬─────────────┬──────────────┬───────────┐
│ Task ID  │ Duration │ Shuffle Read │ Shuffle Wrt │ Spill (Mem)  │ Spill (Dk)│
├──────────┼──────────┼──────────────┼─────────────┼──────────────┼───────────┤
│ 0        │ 12s      │ 200 MB       │ 180 MB      │ 0            │ 0         │
│ 1        │ 15s      │ 210 MB       │ 195 MB      │ 450 MB       │ 120 MB    │
│ 2        │ 3 min    │ 4.2 GB       │ 3.8 GB      │ 8 GB         │ 5.2 GB   │  ← PROBLEM!
│ 3        │ 11s      │ 190 MB       │ 175 MB      │ 0            │ 0         │
└──────────┴──────────┴──────────────┴─────────────┴──────────────┴───────────┘
```

**Red flags to watch for:**


| Metric                | What It Means                                                       | Problem If...                                         |
| --------------------- | ------------------------------------------------------------------- | ----------------------------------------------------- |
| **Spill (Memory)**    | Data that was in execution memory but had to be sorted for spilling | Any value > 0 means execution memory was insufficient |
| **Spill (Disk)**      | Data actually written to disk because memory ran out                | Large values = huge performance hit (10-100x slower)  |
| **Duration variance** | Some tasks much slower than others                                  | One task 10x slower = data skew                       |
| **Shuffle Read**      | Data fetched from other executors                                   | Huge values = heavy shuffle                           |
| **GC Time**           | Time spent on garbage collection                                    | > 10% of task duration = GC problem                   |


### 8.3: Spark UI — Storage Tab

**URL**: `http://<driver-host>:4040/storage/`

Shows all cached RDDs/DataFrames:

```
┌──────────────────────┬───────────┬──────────────┬──────────┬──────────┐
│ RDD Name             │ Cached %  │ Size in Mem  │ Size Dsk │ Partitions│
├──────────────────────┼───────────┼──────────────┼──────────┼──────────┤
│ df_customers         │ 100%      │ 1.2 GB       │ 0        │ 200      │
│ df_orders (partial)  │ 65%       │ 0.8 GB       │ 340 MB   │ 200      │
│ df_products          │ 100%      │ 200 MB       │ 0        │ 50       │
└──────────────────────┴───────────┴──────────────┴──────────┴──────────┘
```

**Red flags:**

- **Cached % < 100%** → not enough memory to cache everything. Some partitions were evicted or couldn't be cached.
- **Size on Disk > 0** → some cache blocks spilled to disk (only with MEMORY_AND_DISK storage level)

### 8.4: Spark UI — SQL Tab (Query Plans)

**URL**: `http://<driver-host>:4040/SQL/`

Shows the physical plan for each SQL/DataFrame query. Look for:

- `BroadcastHashJoin` vs `SortMergeJoin` → tells you which join strategy Spark chose
- `*(N) WholeStageCodegen` → codegen enabled
- `Exchange` nodes → shuffle is happening here

### 8.5: GC Logs (Advanced Debugging)

Enable GC logging to understand garbage collection behavior:

```bash
--conf "spark.executor.extraJavaOptions=-verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps"
```

**What to look for in GC logs:**

```
[GC (Allocation Failure) [PSYoungGen: 1048576K->65536K(1223680K)]
  1048576K->524288K(4019200K), 0.1234567 secs]

[Full GC (Ergonomics) [PSYoungGen: 65536K->0K(1223680K)]
  [ParOldGen: 3145728K->2097152K(2795520K)]
  3211264K->2097152K(4019200K), 2.345 secs]
                                              ^^^^^^^
                                              Full GC taking 2.3 seconds = BAD
```

**Key rules:**

- **Minor GC (Young Gen)** < 100ms → normal
- **Full GC** < 1s → acceptable
- **Full GC** > 2s → memory pressure, need more heap or off-heap
- **Frequent Full GCs** → heap is too small for the workload

---

## Part 9: Common Memory Issues — How to Identify and Fix Each One

### Issue 1: java.lang.OutOfMemoryError: Java heap space

**What it means**: JVM heap is exhausted. Some allocation failed.

**How to trace the cause:**

```
Step 1: Check Spark UI → Executors tab
        → Is Storage Memory full? → Too much caching
        → Is one executor's storage much larger? → Uneven caching

Step 2: Check Spark UI → Stage Details
        → Is Spill (Disk) very high? → Execution memory insufficient
        → Is one task's duration/data much larger? → Data skew

Step 3: Check your code
        → Using collect()? → Pulls all data to driver (OOM on driver)
        → Using UDFs that create large objects? → User memory overflow
        → Using mapPartitions that accumulates into a list? → User memory overflow

Step 4: Check partition sizes
        → Run: df.rdd.mapPartitions(lambda it: [sum(1 for _ in it)]).collect()
        → If one partition has 10x more rows than others → skew
```

**Fix matrix:**


| Cause                   | Fix                   | Config/Code                              |
| ----------------------- | --------------------- | ---------------------------------------- |
| Partitions too large    | More partitions       | `spark.sql.shuffle.partitions = 1000`    |
| Data skew               | Salting or AQE        | `spark.sql.adaptive.enabled = true`      |
| Too much cache          | Unpersist unused      | `df.unpersist()`                         |
| UDF creates big objects | Optimize UDF          | Rewrite UDF to use less memory           |
| collect() on large data | Use take() or write() | `df.take(100)` instead of `df.collect()` |
| General heap pressure   | More memory           | `spark.executor.memory = 16g`            |


### Issue 2: Container killed by YARN/K8s (Exit Code 137)

**What it means**: The executor container exceeded its memory limit and was killed by the OS/cluster manager. This is an **off-heap** memory issue.

**Why it happens**: The JVM used more memory than `spark.executor.memory + spark.executor.memoryOverhead`. The extra memory came from:

- Netty direct buffers (network I/O)
- Native compression libraries (snappy, zstd)
- Thread stacks
- JVM internal overhead (class metadata, JIT compiled code)
- Python worker processes (PySpark)

**How to trace:**

```
Step 1: Check YARN/K8s logs for the killed container
        → "Container [id] is running beyond physical memory limits"
        → "Container killed on request. Exit code is 137"

Step 2: Calculate total memory:
        Total = spark.executor.memory + spark.executor.memoryOverhead
        Is the actual usage exceeding this? → Yes, overhead is too small

Step 3: Check if PySpark UDFs are used
        → Python workers consume additional memory outside JVM
```

**Fix:**

```python
# Increase overhead
spark.conf.set("spark.executor.memoryOverhead", "2g")  # Default may be too low

# If using PySpark UDFs
spark.conf.set("spark.executor.pyspark.memory", "1g")

# If using heavy native libraries (compression)
spark.conf.set("spark.executor.memoryOverhead", "3g")
```

### Issue 3: Excessive Spilling (Slow but No OOM)

**What it means**: Tasks complete but are extremely slow because data keeps spilling to disk.

**How to trace:**

```
Step 1: Spark UI → Stage Details
        → Look at "Spill (Memory)" and "Spill (Disk)" columns
        → If Spill (Disk) is significant (> 1 GB per task) → problem

Step 2: Calculate partition size
        → Shuffle data size / number of shuffle partitions
        → If > 200 MB per partition → partitions too large

Step 3: Check execution memory available
        → (executor_memory - 300MB) × 0.6 × 0.5 = execution memory per executor
        → Divide by number of cores = execution memory per task
        → If partition size > execution memory per task → guaranteed spill
```

**Example:**

```
executor_memory = 10 GB
execution memory = (10 - 0.3) × 0.6 × 0.5 = 2.91 GB
cores = 4
execution memory per task = 2.91 / 4 = 0.73 GB

partition size = 300 GB / 200 partitions = 1.5 GB per partition
1.5 GB > 0.73 GB → SPILL GUARANTEED

Fix: shuffle.partitions = 300 GB / 0.5 GB = 600 partitions
```

**Fix matrix:**


| Approach                 | How                                  | When to use                                |
| ------------------------ | ------------------------------------ | ------------------------------------------ |
| More partitions          | `spark.sql.shuffle.partitions = 600` | Partition size > execution memory per task |
| More executor memory     | `spark.executor.memory = 20g`        | You have cluster capacity                  |
| Fewer cores per executor | `spark.executor.cores = 2`           | Memory per task becomes larger             |
| Enable off-heap          | `spark.memory.offHeap.size = 4g`     | Heavy sorts and shuffles                   |
| Enable AQE               | `spark.sql.adaptive.enabled = true`  | Spark 3.x, auto-adjusts                    |


### Issue 4: GC Pauses Killing Performance

**What it means**: JVM spends too much time in garbage collection instead of doing actual work.

**How to trace:**

```
Step 1: Spark UI → Stage Details → look at "GC Time" per task
        → GC Time > 10% of task duration → GC problem

Step 2: Enable GC logging (see Part 8.5)
        → Look for Full GC pauses > 2 seconds
        → Look for frequency: Full GC every few seconds = bad

Step 3: Check what's filling memory
        → Too many deserialized Java objects in cache → switch to SER
        → Too many UDF objects → optimize UDFs
        → Object churn from transformations → use Tungsten-friendly operations
```

**Fix matrix:**


| Fix                    | How                                     | Impact                              |
| ---------------------- | --------------------------------------- | ----------------------------------- |
| Use serialized caching | `persist(StorageLevel.MEMORY_ONLY_SER)` | Fewer objects → less GC             |
| Use Kryo serialization | `spark.serializer = KryoSerializer`     | Smaller objects → less GC           |
| Enable off-heap        | `spark.memory.offHeap.enabled = true`   | Data outside GC scope               |
| More executor memory   | `spark.executor.memory = 20g`           | GC runs less often                  |
| Fewer cores            | `spark.executor.cores = 2`              | Less concurrent allocation pressure |
| Use G1GC               | `-XX:+UseG1GC` in extraJavaOptions      | Better GC for large heaps           |


### Issue 5: Uneven Memory Usage Across Executors

**What it means**: Some executors use all memory while others are nearly empty.

**How to trace:**

```
Step 1: Spark UI → Executors Tab
        → Compare "Storage Memory Used" across executors
        → If some are at 90%+ while others are at 10% → uneven distribution

Step 2: Check partition sizes
        → If some partitions are 10x larger than others → data skew

Step 3: Check cache distribution
        → Cached data might not be evenly distributed
        → Some partitions might be much larger than others
```

**Fix:**

- Repartition data before caching: `df.repartition(200).cache()`
- Fix data skew with salting or AQE
- Use consistent partition counts across the pipeline

---

## Part 10: Memory Tuning Playbook — Production-Ready Configs

### Small Workload (< 10 GB data, simple ETL)

```python
spark.executor.memory = 4g
spark.executor.memoryOverhead = 1g
spark.executor.cores = 2
spark.sql.shuffle.partitions = 20
spark.memory.fraction = 0.6
spark.memory.storageFraction = 0.5
```

### Medium Workload (10–100 GB, joins + aggregations)

```python
spark.executor.memory = 10g
spark.executor.memoryOverhead = 2g
spark.executor.cores = 4
spark.sql.shuffle.partitions = 200
spark.memory.fraction = 0.6
spark.memory.storageFraction = 0.5
spark.sql.adaptive.enabled = true
```

### Large Workload (100 GB – 1 TB, complex pipelines)

```python
spark.executor.memory = 20g
spark.executor.memoryOverhead = 4g
spark.executor.cores = 4
spark.sql.shuffle.partitions = 1000
spark.memory.fraction = 0.7          # More for Spark, less for user code
spark.memory.storageFraction = 0.3   # More execution, less cache
spark.sql.adaptive.enabled = true
spark.serializer = org.apache.spark.serializer.KryoSerializer
```

### Heavy Shuffle Workload (large joins, heavy aggregations)

```python
spark.executor.memory = 20g
spark.executor.memoryOverhead = 4g
spark.memory.offHeap.enabled = true
spark.memory.offHeap.size = 8g      # Additional off-heap for shuffles
spark.executor.cores = 4
spark.sql.shuffle.partitions = 2000
spark.memory.fraction = 0.75
spark.memory.storageFraction = 0.2  # Prioritize execution
spark.sql.adaptive.enabled = true
```

### Heavy Caching Workload (ML pipelines, iterative processing)

```python
spark.executor.memory = 20g
spark.executor.memoryOverhead = 2g
spark.executor.cores = 4
spark.memory.fraction = 0.8         # More total Spark memory
spark.memory.storageFraction = 0.6  # More storage for caching
spark.sql.shuffle.partitions = 200
```

---

## Part 11: The Relationship Between Cores and Memory

This is something many people miss: **the number of cores per executor directly affects memory per task**.

### The Formula

```
Memory per Task = Execution Memory / Number of Cores

Example:
  executor_memory = 10 GB
  execution memory = (10 - 0.3) × 0.6 × 0.5 = 2.91 GB
  cores = 4
  memory per task = 2.91 / 4 = 0.73 GB

  cores = 2
  memory per task = 2.91 / 2 = 1.45 GB  ← 2x more memory per task!
```

### Why This Matters

Each core runs one task at a time. All cores in an executor **share** the same execution memory.

- **More cores** = more parallelism BUT less memory per task
- **Fewer cores** = less parallelism BUT more memory per task

### The Sweet Spot


| Cores per Executor | Good For                   | Risk                                    |
| ------------------ | -------------------------- | --------------------------------------- |
| 1                  | Maximum memory per task    | Too many small executors, high overhead |
| 2–4                | Balanced (most common)     | Good parallelism + reasonable memory    |
| 5+                 | CPU-light, I/O-heavy tasks | Memory starvation per task              |
| > 5                | NOT recommended            | HDFS throughput bottleneck, GC pressure |


**Rule of thumb**: Use 4–5 cores per executor. Go lower if tasks need lots of memory (heavy joins). Never go above 5 per executor.

---

## Part 12: What Happens During Each Spark Operation (Memory Timeline)

### Timeline: Reading a Parquet File

```
T0: Task assigned to executor core
T1: Parquet reader allocates buffers in EXECUTION MEMORY
    → Reads column chunks from disk
    → Decompresses (snappy/zstd) using OVERHEAD MEMORY (native lib)
    → Decodes into UnsafeRow format in EXECUTION MEMORY
T2: Apply predicate pushdown filter (still in execution memory)
T3: Apply column pruning (only requested columns materialized)
T4: If cache() requested → copy rows to STORAGE MEMORY
T5: Apply remaining transformations (execution memory)
T6: Output rows to next operator
T7: Buffers freed, memory returned to pool
```

### Timeline: Complete Join + Aggregation Pipeline

```
df_result = (df_orders                           # 50 GB
    .join(df_customers, "cust_id")               # 5 GB (broadcast)
    .filter(col("amount") > 100)
    .groupBy("region").agg(sum("amount"))
    .orderBy(desc("sum(amount)")))
df_result.show()

STAGE 0 (Read + Broadcast + Hash Join + Filter):
  T0:  Read df_orders partition → EXECUTION MEMORY
  T1:  Receive broadcast df_customers → STORAGE MEMORY (broadcast block)
  T2:  Build hash map from customers → USER MEMORY
  T3:  For each order row, probe hash map → EXECUTION MEMORY (output rows)
  T4:  Apply filter (amount > 100) → same EXECUTION MEMORY (rows filtered in-place)
  T5:  Shuffle write results → EXECUTION MEMORY (sort buffer → spill if needed → disk)

STAGE 1 (Shuffle Read + GroupBy Aggregate):
  T6:  Shuffle read → fetch data from all executors → EXECUTION MEMORY
  T7:  Build aggregation hash map → EXECUTION MEMORY
       hash_map["North"] = {sum: 45678.90}
       hash_map["South"] = {sum: 23456.78}
  T8:  If hash map exceeds memory → SPILL, merge later
  T9:  Shuffle write aggregated results → EXECUTION MEMORY → disk

STAGE 2 (Shuffle Read + Sort):
  T10: Shuffle read aggregated results → EXECUTION MEMORY
  T11: Sort by sum(amount) descending → EXECUTION MEMORY
       → If sort buffer exceeds memory → SPILL (external merge sort)
  T12: Output sorted results to driver
  T13: Driver displays top 20 rows (show())
```

---

## Part 13: Advanced — Off-Heap vs On-Heap Deep Comparison

### On-Heap (Default)

```
Data stored as: Java objects (or serialized byte arrays)
Managed by: JVM Garbage Collector
Allocation: new Object(), arrays, etc.
Pros:
  - Simpler to use
  - JVM handles cleanup automatically
  - Easier debugging
Cons:
  - Object headers add 16 bytes per object
  - Pointers add 8 bytes per reference
  - GC pauses can freeze all threads
  - GC pauses get WORSE as heap size increases
  - String "hello" costs ~54 bytes (vs 7 bytes raw)
```

### Off-Heap (Tungsten)

```
Data stored as: Raw bytes in direct memory (outside JVM)
Managed by: Spark's own memory manager (sun.misc.Unsafe)
Allocation: Platform.allocateMemory(numBytes)
Pros:
  - ZERO GC overhead (GC doesn't see this memory)
  - Compact storage (no object headers/pointers)
  - Predictable performance (no GC pauses)
  - Can handle very large datasets
  - Cache-friendly memory layout
Cons:
  - More complex code
  - Memory leaks possible (no GC safety net)
  - Harder to debug
  - Must manually serialize/deserialize
```

### When Off-Heap Makes a Huge Difference

```
Scenario: 10 GB executor heap, processing 100 GB data with groupBy

On-Heap only:
  - Data stored as Java objects → ~3x memory overhead
  - GC must scan all objects → Full GC pauses of 5-10 seconds
  - Full GC freezes ALL tasks on the executor
  - 100 Full GCs × 5 seconds = 500 seconds wasted on GC

Off-Heap enabled (8 GB off-heap):
  - Sort buffers and hash tables stored as raw bytes off-heap
  - GC only scans the 10 GB heap (mostly empty pointers)
  - Full GC takes < 1 second
  - Maybe 20 Full GCs × 1 second = 20 seconds on GC
  - 480 seconds saved = 25x improvement in GC time
```

---

## Part 14: Memory Debugging Checklist

When a Spark job has memory issues, follow this checklist:

```
□ 1. Check Spark UI → Executors Tab
     → Are all executors alive or did some die?
     → What's the storage memory usage?

□ 2. Check Spark UI → Stages Tab
     → Which stage is slowest?
     → Click into it → check task metrics

□ 3. Check Task Metrics
     → Spill (Disk) > 0? → Execution memory too small
     → GC Time > 10% of duration? → GC problem
     → One task 10x slower? → Data skew
     → Duration > 10 minutes per task? → Partition too large

□ 4. Check Storage Tab
     → Cached % < 100%? → Not enough storage memory
     → Size on Disk > 0? → Cache spilling to disk

□ 5. Check YARN/K8s Logs
     → "Container killed"? → Off-heap memory exceeded
     → Exit code 137? → OOM killed by OS

□ 6. Check Your Code
     → collect() on large data? → Driver OOM
     → UDFs creating large objects? → User memory OOM
     → mapPartitions accumulating lists? → User memory OOM
     → Too many cache() without unpersist()? → Storage overflow

□ 7. Calculate Memory Per Task
     → execution_memory / cores_per_executor = memory_per_task
     → If partition_size > memory_per_task → spill guaranteed

□ 8. Calculate Ideal Partition Count
     → total_data_size / 200 MB = ideal_partition_count
     → Set spark.sql.shuffle.partitions accordingly
```

---

## Key Takeaway

> Spark memory is divided into **Reserved** (300 MB safety), **Spark Memory** (60% — split between Execution for active tasks and Storage for cache), and **User Memory** (40% — unmanaged, for your code's objects). Plus **Overhead** memory off-heap for network/native operations.
>
> **Execution always beats Storage** — running tasks can evict cached data, but cache can never kill a running task.
>
> To debug: check **Spark UI** (executors, stages, storage tabs), look for **spills** (execution memory issue), **GC time** (too many objects), **container kills** (overhead too small), and **skewed tasks** (one partition too large).
>
> The most impactful tuning: right-size **partitions** (100-200 MB each), right-size **cores** (4-5 per executor), and enable **AQE** for automatic runtime optimization.

