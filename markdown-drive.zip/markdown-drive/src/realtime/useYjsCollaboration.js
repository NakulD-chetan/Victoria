import { useEffect, useMemo, useState } from 'react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { supabase, getAccessTokenSync } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

/*
 * useYjsCollaboration — produces a Y.Doc + WebsocketProvider for a note,
 * authenticated against the local yjs-server with the user's Supabase
 * JWT. Returns nullables if Yjs is disabled (no env URL configured).
 *
 * Pair the returned ydoc + provider with TipTap's Collaboration and
 * CollaborationCursor extensions:
 *
 *   const { ydoc, provider } = useYjsCollaboration(noteId);
 *   const editor = useEditor({
 *     extensions: [
 *       StarterKit.configure({ history: false }),  // history is provided by Yjs
 *       ...(ydoc ? [
 *         Collaboration.configure({ document: ydoc }),
 *         CollaborationCursor.configure({ provider, user: { name, color } }),
 *       ] : []),
 *     ],
 *   });
 */

const YJS_WS_URL =
  (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_YJS_WS_URL) ||
  '';

function userColor(id) {
  if (!id) return '#6366F1';
  let h = 0;
  for (let i = 0; i < id.length; i += 1) h = (h * 31 + id.charCodeAt(i)) >>> 0;
  const hue = h % 360;
  return `hsl(${hue}, 70%, 55%)`;
}

export function useYjsCollaboration(noteId) {
  const { user, profile } = useAuth();
  const [provider, setProvider] = useState(null);
  const [status, setStatus] = useState('disconnected');

  const ydoc = useMemo(() => (noteId && YJS_WS_URL ? new Y.Doc() : null), [noteId]);

  useEffect(() => {
    if (!ydoc || !noteId || !YJS_WS_URL || !user?.id) return undefined;

    /* y-websocket appends `?yjs=true` query etc; pass our token via params. */
    const token = getAccessTokenSync();
    if (!token) return undefined;

    const wsProvider = new WebsocketProvider(
      YJS_WS_URL,
      noteId,
      ydoc,
      { params: { token }, connect: true },
    );
    wsProvider.on('status', (e) => setStatus(e.status));
    wsProvider.awareness.setLocalStateField('user', {
      id: user.id,
      name: profile?.display_name || user.email || 'User',
      color: userColor(user.id),
    });
    setProvider(wsProvider);

    return () => {
      try { wsProvider.destroy(); } catch { /* ignore */ }
      try { ydoc.destroy(); } catch { /* ignore */ }
      setProvider(null);
      setStatus('disconnected');
    };
  }, [ydoc, noteId, user?.id, profile?.display_name]);

  return { ydoc, provider, status };
}

/*
 * snapshotToNotesContent — debounced helper for the editor view to
 * persist the current TipTap doc JSON into notes.content. Realtime
 * subscribers reading the row (sidebar previews, search index) get
 * a fresh copy without having to load the Y.Doc.
 */
export function makeContentSnapshotter(noteId, ms = 5000) {
  let timer = null;
  return function schedule(json) {
    if (!noteId) return;
    if (timer) clearTimeout(timer);
    timer = setTimeout(async () => {
      timer = null;
      try {
        await supabase
          .from('notes')
          .update({ content: json, updated_at: new Date().toISOString() })
          .eq('id', noteId);
      } catch { /* RLS may reject; sidebar will fall back to row read */ }
    }, ms);
  };
}
