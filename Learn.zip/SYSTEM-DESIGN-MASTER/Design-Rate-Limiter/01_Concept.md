# Design Rate Limiter — Concept

> **Permanent Recall:** A **rate limiter** controls request rate per user/IP/API key. Functional: limit by identity, configurable rules per endpoint, return **429** with `Retry-After` header, support distributed deployment. Non-functional: **<5ms overhead**, high throughput, **fail open vs fail closed** under faults. Capacity: **millions of requests/second** across distributed nodes.

---

## Problem Statement

Design a **rate limiter** that restricts the number of requests a client can make in a given time window. It protects backend services from abuse, ensures fair usage, and prevents DDoS-style traffic spikes.

---

## Functional Requirements


| Feature                    | Description                                                                 |
| -------------------------- | --------------------------------------------------------------------------- |
| **Limit by identity**      | Per user ID, IP address, or API key                                         |
| **Configurable rules**     | Different limits per endpoint (e.g., `/search`: 100/min; `/upload`: 10/min) |
| **429 response**           | When limit exceeded: HTTP 429 Too Many Requests                             |
| **Retry-After header**     | Inform client when to retry (seconds or HTTP-date)                          |
| **Distributed deployment** | Works across multiple API gateway / app server nodes; shared state          |
| **Multiple dimensions**    | Optional: limit by user AND endpoint AND region                             |


---

## Non-Functional Requirements


| NFR                 | Target                                        | Rationale                                                               |
| ------------------- | --------------------------------------------- | ----------------------------------------------------------------------- |
| **Latency**         | Add <5ms overhead per request                 | Rate check is in the hot path; must not dominate latency                |
| **Throughput**      | Handle millions of requests/second            | Must scale with API traffic                                             |
| **Fault tolerance** | **Fail open** vs **fail closed** configurable | Redis down: allow traffic (open) or reject all (closed)?                |
| **Accuracy**        | Configurable trade-off: exact vs approximate  | Sliding window log = exact; fixed window = approximate (boundary spike) |
| **Memory**          | Bounded per-identity state                    | Avoid unbounded growth for sliding window log                           |


---

## Fail Open vs Fail Closed


| Mode            | When Redis/store fails     | Use case                                                         |
| --------------- | -------------------------- | ---------------------------------------------------------------- |
| **Fail open**   | Allow all requests through | Availability-critical; prefer degraded service over total outage |
| **Fail closed** | Reject all requests        | Security-critical; prefer outage over potential abuse            |


> **FAANG Tip:** Interviewers often ask "What if Redis is down?" — have both options ready and state which you'd choose for the scenario.

---

## Capacity Estimation

### Throughput

- **Target:** Millions of requests/second across all nodes
- **Per-node:** 50–100K QPS through rate limiter layer
- **Bottleneck:** Usually the shared store (Redis); use connection pooling, pipelining, local caching

### Storage (Redis)

- **Per identity:** ~50–200 bytes (key + counter/window data)
- **1M active users:** ~50–200MB
- **10M identities:** ~500MB–2GB (manageable in Redis)

### Latency Budget


| Operation                | Target | Notes                                |
| ------------------------ | ------ | ------------------------------------ |
| Redis round-trip         | <2ms   | Single INCR or sorted set ops        |
| In-memory check (cached) | <1ms   | Local cache for hot keys             |
| Total overhead           | <5ms   | Including serialization, rule lookup |


---

## Key Numbers to Memorize


| Metric                  | Value                   |
| ----------------------- | ----------------------- |
| Latency overhead        | <5ms                    |
| Response when limited   | 429 Too Many Requests   |
| Header for retry timing | Retry-After             |
| Standard shared store   | Redis                   |
| Fail modes              | Fail open / Fail closed |


---

## Out of Scope (Clarify in Interview)

- **Geographic rate limiting** — different limits per region (can extend)
- **Dynamic limits** — ML-based adaptive limits
- **Quota vs rate** — rate = requests per time window; quota = total over longer period (different design)
- **Cost-based limits** — limit by compute cost, not request count

---

## Assumptions (State in Interview)

- Identifiers (user ID, IP, API key) are available in the request
- Rules are preconfigured (YAML/JSON); hot-reload optional
- Clock is reasonably synchronized across nodes (NTP); or use Redis time
- Single or multi-region; if multi-region, discuss global vs per-region limits

