# Resilience Patterns — System Ko Unbreakable Banao

> **Resilience = System fail hone pe bhi kaam karta rahe — gracefully handle kare**
> Socho earthquake-proof building — hilegi but giregi nahi!

---

## Table of Contents
1. [Resilience Kya Hai?](#resilience-kya-hai)
2. [Rate Limiting](#rate-limiting)
3. [Circuit Breaker Pattern](#circuit-breaker-pattern)
4. [Bulkhead Pattern](#bulkhead-pattern)
5. [Retry Mechanism](#retry-mechanism)
6. [Timeout Patterns](#timeout-patterns)
7. [Idempotency](#idempotency)
8. [Graceful Degradation](#graceful-degradation)
9. [Failover](#failover)
10. [Health Checks & Heartbeats](#health-checks--heartbeats)
11. [Chaos Engineering](#chaos-engineering)
12. [Interview Questions & Quick Recall](#interview-questions--quick-recall)

---

## Resilience Kya Hai?

### Core Concept
**Resilience** = System failures, overload, aur unexpected conditions ko **gracefully handle** karna — crash nahi, degrade gracefully.

### Real World Analogy
**Earthquake-proof building:**
- Normal: Sab theek
- Earthquake: Building hilti hai, crack ho sakti hai, but **girti nahi**
- Resilience = absorb shock, survive, recover

### How It Works
```
WITHOUT RESILIENCE:
[Request] ---> [Service] ---> [Downstream fails] ---> 💥 Cascade failure

WITH RESILIENCE:
[Request] ---> [Service] ---> [Downstream fails] ---> Circuit breaker opens
                                                      Retry with backoff
                                                      Fallback response
                                                      ✅ System survives
```

### Key Principles
| Principle | Matlab |
|-----------|--------|
| **Fail fast** | Jaldi pata chale, jaldi handle |
| **Isolate** | Ek failure dusre ko na le jaye |
| **Degrade gracefully** | Full features nahi, but kaam kare |
| **Recover** | Auto ya manual recovery |

### 1 Minute Recall Block
> Resilience = fail hone pe bhi survive. Graceful degradation. Isolate failures. Don't cascade.

### 5 Bullet Memory Hooks
- Resilience = unbreakable mindset
- Fail fast, isolate, degrade
- Circuit breaker, retry, timeout
- Graceful > crash
- Chaos engineering = test resilience

---

## Rate Limiting

### Core Concept
**Request limit** — zyada requests aayein toh reject/queue. System overload se bachao.

### Kyu Zaroori?
- DoS attack prevent
- Fair usage (API quota)
- Cost control
- Backend protect

### Real World Example
**Bank ATM:** Din mein 10 transactions limit. Zyada mat karo — system protect.

---

### 1. Token Bucket Algorithm

**Core Concept:** Bucket mein tokens. Har request = 1 token consume. Tokens refill at fixed rate.

```
Bucket capacity: 10 tokens
Refill rate: 2 tokens/second

[Request] ---> Token available? ---Yes--> Process, remove 1 token
                    |
                    No --> Reject (429 Too Many Requests)
```

**Diagram:**
```
     Refill (2/sec)
         |
         v
    +---------+
    | 10 tokens|  <-- Capacity
    +---------+
         |
    Request = take 1 token
```

**Pros:** Burst allow (bucket full = 10 at once), smooth rate
**Cons:** Implementation slightly complex

---

### 2. Leaky Bucket Algorithm

**Core Concept:** Requests = water. Bucket = leak (fixed rate process). Overflow = reject.

```
[Requests] ---> [Bucket] ---leak at fixed rate---> [Process]
                    |
                    | (overflow)
                    v
                 Reject
```

**Token Bucket vs Leaky Bucket:**
| Aspect | Token Bucket | Leaky Bucket |
|--------|--------------|--------------|
| **Burst** | Allows (tokens) | Smooths (no burst) |
| **Output** | Variable | Fixed rate |
| **Use** | API rate limit | Traffic shaping |

---

### 3. Fixed Window Counter

**Core Concept:** Time window (e.g., 1 minute). Window mein count. Limit exceed = reject.

```
Window 1 (0-60s): 100 requests allowed
Window 2 (60-120s): 100 requests allowed
...
```

**Problem — Boundary burst:**
```
59th second: 100 requests (all allowed)
61st second: 100 requests (new window, all allowed)
= 200 requests in 2 seconds! (exploit)
```

**Pros:** Simple
**Cons:** Boundary problem — burst at window edge

---

### 4. Sliding Window Log

**Core Concept:** Har request ka timestamp store. Current window = last N seconds. Count = requests in window.

```
Window = 60 seconds
Request at T=70: Count requests from T=10 to T=70
If count < limit → allow
```

**Pros:** No boundary burst
**Cons:** Memory — saare timestamps store

---

### 5. Sliding Window Counter

**Core Concept:** Fixed window + previous window ka weighted count. Compromise.

```
count = prev_window_count * (1 - overlap) + current_window_count
```

**Pros:** Memory efficient, no full log
**Cons:** Approximate (not exact)

---

### 6. Distributed Rate Limiting

**Problem:** Multiple servers — each apna count = limit * servers (wrong!)

**Solutions:**
- **Redis:** Central counter, atomic increment
- **Token bucket in Redis:** Shared state
- **Consistent hashing:** User → same server (sticky)

### Rate Limiting Comparison Table
| Algorithm | Burst | Memory | Accuracy | Use Case |
|-----------|-------|--------|----------|----------|
| Token Bucket | Yes | Low | High | API limit |
| Leaky Bucket | No | Low | High | Traffic shape |
| Fixed Window | Yes (boundary) | Low | Low | Simple |
| Sliding Log | No | High | High | Strict |
| Sliding Counter | Yes | Low | Medium | Balanced |

### Common Interview Trap
> "Fixed window problem?" — Boundary burst! 100 at end of window + 100 at start = 200 in 2 sec. Sliding window fix.

### 1 Minute Recall Block
> Rate limit = request cap. Token bucket = burst allow. Leaky = smooth. Fixed window = boundary exploit. Sliding = better.

### 5 Bullet Memory Hooks
- Token bucket = burst + refill
- Leaky bucket = no burst
- Fixed window = boundary problem
- Sliding = no boundary exploit
- Distributed = Redis shared state

---

## Circuit Breaker Pattern

### Core Concept
**Electrical circuit breaker** jaisa — failure detect = circuit "open", requests block. Downstream ko aur stress mat do.

### 3 States

```
     CLOSED (normal)
          |
     Failures > threshold
          |
          v
     OPEN (reject all)
          |
     Timeout (e.g., 30 sec)
          |
          v
     HALF-OPEN (test 1 request)
          |
     Success? --> CLOSED
     Fail? --> OPEN
```

### State Diagram (ASCII)

```
         +------------------+
         |     CLOSED       |
         | (requests pass)  |
         +--------+---------+
                  |
         failures >= threshold
                  |
                  v
         +------------------+
         |      OPEN        |
         | (reject all)     |
         +--------+---------+
                  |
         timeout elapsed
                  |
                  v
         +------------------+
         |   HALF-OPEN      |
         | (try 1 request)  |
         +--------+---------+
                  |
         success --> CLOSED
         fail --> OPEN
```

### How It Prevents Cascade Failure

```
WITHOUT CIRCUIT BREAKER:
[Client] ---> [Service A] ---> [Service B - DOWN]
    |              |                    |
    |         Keeps retrying             |
    |         Threads block              |
    |         Resources exhausted       |
    v
Service A bhi down! Cascade!

WITH CIRCUIT BREAKER:
[Client] ---> [Service A] ---> [Service B - DOWN]
    |              |                    |
    |         Circuit OPEN              |
    |         Fail fast immediately     |
    |         No retry, no block        |
    v
Service A healthy! Returns fallback.
```

### Real World Example
**Netflix:** Payment service down. Circuit breaker open. "Payment temporarily unavailable" — instead of whole app hang.

### Parameters
| Parameter | Matlab |
|-----------|--------|
| **Failure threshold** | Kitni failures pe open (e.g., 5) |
| **Timeout** | Open state kitni der (e.g., 30s) |
| **Half-open requests** | Test ke liye kitne (usually 1) |

### Common Interview Trap
> "Circuit breaker open — kya return?" — Fallback! Cached response, default value, or "service unavailable". Never hang.

### 1 Minute Recall Block
> Circuit breaker = failure pe stop calling. Closed → Open → Half-Open → Closed. Prevents cascade. Fallback required.

### 5 Bullet Memory Hooks
- 3 states: Closed, Open, Half-Open
- Open = reject, don't retry
- Half-Open = test request
- Prevents cascade failure
- Fallback response essential

---

## Bulkhead Pattern

### Core Concept
**Ship compartments** jaisa — ek compartment mein pani aaye, baaki dry. Isolate resources.

### How It Works
```
WITHOUT BULKHEAD:
[Thread Pool - Shared]
  |
  Service A, B, C sab same pool use karte hain
  Service B overload = pool exhausted
  Service A, C bhi block! 💥

WITH BULKHEAD:
[Pool A - 10 threads]  --> Service A
[Pool B - 10 threads]  --> Service B
[Pool C - 10 threads]  --> Service C

Service B overload = only Pool B exhausted
A, C unaffected! ✅
```

### Real World Example
**Database connections:** User service = 20 connections, Order service = 20. Order service overload = user service connections safe.

### Use Case
- Thread pools per dependency
- Connection pools per service
- Isolate noisy neighbor

### 1 Minute Recall Block
> Bulkhead = resource isolation. Separate pools. One failure = others safe. Ship compartment analogy.

### 5 Bullet Memory Hooks
- Ship compartment = isolate
- Separate thread/connection pools
- Noisy neighbor isolation
- One service overload ≠ others down
- Per-dependency limits

---

## Retry Mechanism

### Core Concept
**Transient failures** — retry karo. Network glitch, temporary overload.

### Simple Retry
```
Request → Fail → Retry → Fail → Retry → Success
```
- Fixed delay between retries
- **Problem:** Thundering herd — sab ek saath retry

### Exponential Backoff

**Core Concept:** Retry delay **exponentially badhao**

```
Attempt 1: fail, wait 1s
Attempt 2: fail, wait 2s
Attempt 3: fail, wait 4s
Attempt 4: fail, wait 8s
...
```

**Formula:** `delay = base * 2^attempt`

**Why?** Failed service ko recover ka time do. Sudden retry storm avoid.

### Jitter (Randomness)

**Problem:** 1000 clients retry at same time (all wait 2s, all retry together) = spike!

**Solution:** Add randomness
```
delay = base * 2^attempt + random(0, 1000ms)
```

**Why?** Retries spread out. No thundering herd.

### Retry Best Practices
| Practice | Matlab |
|----------|--------|
| **Max retries** | Limit (e.g., 3-5) |
| **Exponential backoff** | Increase delay |
| **Jitter** | Randomize delay |
| **Idempotency** | Retry safe (duplicate OK) |
| **Circuit breaker** | Retry fail = open circuit |

### Common Interview Trap
> "Why jitter?" — Without jitter, all clients retry together = thundering herd. Jitter = spread retries.

### 1 Minute Recall Block
> Retry = transient failure handle. Exponential backoff = delay increase. Jitter = randomness, no herd.

### 5 Bullet Memory Hooks
- Retry for transient failures
- Exponential backoff = 2^n delay
- Jitter = random offset
- Max retries limit
- Idempotent = retry safe

---

## Timeout Patterns

### Core Concept
**Infinite wait = bad.** Har call pe timeout — nahi to thread block, resource leak.

### How It Works
```
[Client] ---request---> [Service] 
         |
         timeout = 5s
         |
         No response in 5s? --> Fail fast, release resources
```

### Timeout Hierarchy
- **Connection timeout:** TCP connect
- **Read timeout:** Response wait
- **Total timeout:** End-to-end

### Best Practices
- Always set timeout (no infinite)
- Timeout < caller's timeout (propagate)
- Different timeouts for different operations

### Common Interview Trap
> "No timeout — problem?" — Thread block, connection leak, cascade. Always set timeout.

### 1 Minute Recall Block
> Timeout = max wait. No timeout = block, leak. Set at every layer. Fail fast.

---

## Idempotency

### Core Concept
**Same request multiple times = same result** (no extra side effects)

### What It Means
```
Request 1: Deduct 100 → Balance 900
Request 1 (duplicate): Deduct 100 → Balance 900 (NOT 800!)
```

### Idempotency Keys
- Client unique key bhejta hai (e.g., UUID)
- Server: Key pehle process hua? → Return stored result
- Nahi? → Process, store result with key

```
POST /payment
{ idempotency_key: "uuid-123", amount: 100 }

First request: Process, store key
Retry (same key): Return stored result, don't deduct again
```

### Why Critical for Payments
- Network retry = duplicate request
- At-least-once delivery = duplicate possible
- Idempotent = duplicate safe

### HTTP Idempotency
| Method | Idempotent? |
|--------|-------------|
| GET | Yes |
| PUT | Yes (replace) |
| DELETE | Yes |
| POST | No (by default) |
| PATCH | Maybe |

### 1 Minute Recall Block
> Idempotency = same request twice = same result. Idempotency keys for POST. Critical for payments, retries.

### 5 Bullet Memory Hooks
- Same input = same output
- No duplicate side effects
- Idempotency key = unique per request
- Payments = must idempotent
- GET, PUT, DELETE = naturally idempotent

---

## Graceful Degradation

### Core Concept
**Full features nahi, but core kaam kare.** Partial failure = partial service.

### How It Works
```
NORMAL:
[App] --> [Recommendations] --> [Search] --> [Cart]
        All features work

DEGRADED (Recommendations down):
[App] --> [X] --> [Search] --> [Cart]
        Show "Recommendations unavailable"
        Search, Cart still work!
```

### Real World Examples
| Failure | Degradation |
|---------|-------------|
| CDN down | Serve from origin (slower) |
| Recommendations down | Show default/popular |
| Image service down | Placeholder images |
| Payment down | "Try later" message |

### vs Fault Tolerance
- **Fault tolerance:** Failure hide (user ko pata nahi)
- **Graceful degradation:** Failure acknowledge, partial service

### 1 Minute Recall Block
> Graceful degradation = partial service on failure. Core features work. User ko batao "some features limited".

---

## Failover

### Core Concept
**Primary fail = secondary takeover.** High availability.

### Active-Passive (Cold/Hot Standby)

```
[Active]  <--- All traffic
    |
[Passive] <--- Standby, monitoring
    |
Active fails --> Passive becomes Active (VIP flip)
```

- **Cold:** Passive not fully ready, startup time
- **Hot:** Passive ready, quick failover
- **Downtime:** Seconds to minutes

### Active-Active

```
[Active 1] <--- Traffic share
[Active 2] <--- Traffic share
    |
Both serve. One fails = other handles all.
```

- **Zero downtime** (if load shared)
- **Challenge:** State sync, session affinity

### Comparison Table
| Aspect | Active-Passive | Active-Active |
|--------|----------------|---------------|
| **Resources** | Passive idle (waste) | Both used |
| **Failover** | Seconds | Instant |
| **Complexity** | Lower | Higher (state sync) |
| **Cost** | Lower | Higher |

### 1 Minute Recall Block
> Failover = primary fail, secondary take. Active-Passive = standby. Active-Active = both serve.

---

## Health Checks & Heartbeats

### Health Check
**Periodic probe** — service healthy hai?

- **Liveness:** Service running? (restart if no)
- **Readiness:** Service traffic accept kar sakta? (LB exclude if no)

### Heartbeat
**"I am alive"** signal — distributed systems mein

```
[Node A] ---heartbeat every 5s---> [Coordinator]
[Node B] ---heartbeat every 5s---> [Coordinator]

Node A stops sending --> Coordinator marks dead after timeout
```

### Use Cases
- Service discovery (unhealthy remove)
- Leader election (heartbeat = alive)
- Cluster membership

### 1 Minute Recall Block
> Health check = probe. Liveness vs Readiness. Heartbeat = "alive" signal. Timeout = dead.

---

## Chaos Engineering

### Core Concept
**Intentional failure** inject karo — system resilience test karo.

### Netflix Chaos Monkey
- Randomly instances kill karta hai
- Force: redundancy, failover, recovery test
- "If it can't survive Chaos Monkey, it's not production-ready"

### Chaos Engineering Principles
1. **Steady state** define (normal metrics)
2. **Hypothesis** (e.g., "DB fail = fallback works")
3. **Inject failure** (kill DB, network partition)
4. **Observe** (metrics, alerts)
5. **Improve** (fix gaps)

### Types of Experiments
| Experiment | What |
|------------|------|
| **Instance kill** | Random server down |
| **Network partition** | Split network |
| **Latency injection** | Add delay |
| **Resource exhaustion** | CPU, memory fill |

### 1 Minute Recall Block
> Chaos engineering = intentional failure. Test resilience. Chaos Monkey = kill instances. Find weak points before production.

### 5 Bullet Memory Hooks
- Intentional failure injection
- Netflix Chaos Monkey
- Test before production
- Steady state, hypothesis, inject, observe
- Find weak points proactively

---

## Interview Questions & Quick Recall

### Interview Questions

**Q1: Token Bucket vs Leaky Bucket?**
> Token = burst allow, refill. Leaky = no burst, fixed output. API = token. Traffic shaping = leaky.

**Q2: Fixed window rate limit problem?**
> Boundary burst. 100 at end + 100 at start = 200 in 2 sec. Sliding window fix.

**Q3: Circuit breaker states?**
> Closed (normal) → Open (reject) → Half-Open (test) → Closed. Prevents cascade.

**Q4: Why jitter in retry?**
> Thundering herd avoid. All retry together = spike. Jitter = spread.

**Q5: Bulkhead pattern?**
> Resource isolation. Separate pools. One overload ≠ others down. Ship compartment.

**Q6: Idempotency — why critical?**
> Retries, at-least-once = duplicates. Idempotent = safe. Payments must be.

**Q7: Graceful degradation vs fault tolerance?**
> Degradation = partial service, user knows. Fault tolerance = hide failure.

**Q8: Chaos engineering purpose?**
> Test resilience. Intentional failure. Find gaps before production.

### Common Interview Traps
- "Circuit breaker open — hang?" — No! Fail fast, return fallback
- "Retry without limit?" — No! Max retries, else circuit breaker
- "No timeout?" — Always set. Block = leak

### Quick Recall — Full Cheat Sheet

```
RESILIENCE PATTERNS CHEAT SHEET
================================
• Rate limit: Token bucket (burst), Sliding window (no boundary)
• Circuit breaker: Closed → Open → Half-Open. Fallback!
• Bulkhead: Isolate resources, separate pools
• Retry: Exponential backoff + jitter
• Timeout: Always set, fail fast
• Idempotency: Same request = same result. Keys for POST
• Graceful degradation: Partial service
• Failover: Active-Passive, Active-Active
• Health: Liveness, Readiness
• Chaos: Intentional failure, test resilience
```

### 5 Bullet Memory Hooks (Full Topic)
- Rate limit = token bucket, sliding window
- Circuit breaker = 3 states, cascade prevent
- Retry = backoff + jitter
- Idempotency = duplicate safe
- Chaos = test before prod
