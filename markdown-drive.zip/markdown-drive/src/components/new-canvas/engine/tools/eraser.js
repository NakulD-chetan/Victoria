import { worldFromClient } from '../coords';
import { elementContainsPoint } from '../hit-test';

/**
 * Eraser — drags over elements to mark them deleted. We collect the set of
 * ids hit during the gesture and commit them in a single history entry on
 * pointerup, so Ctrl+Z brings back the whole sweep.
 *
 * Visual feedback: while dragging, we record the cursor path in
 * `ctx.getEraserTrail()` so the renderer can paint a soft red trail (same
 * idea as Excalidraw's eraser). Trail points fade by age.
 */

const TRAIL_LIFESPAN_MS = 500;

export const eraserTool = {
  id: 'eraser',
  cursor: 'crosshair',

  onPointerDown(ctx, ev) {
    if (ev.button !== 0) return false;
    ctx.canvasEl.setPointerCapture?.(ev.pointerId);
    ctx._eraserHits = new Set();
    addTrail(ctx, ev);
    startTicker(ctx);
    return eraseAt(ctx, ev);
  },

  onPointerMove(ctx, ev) {
    if (!ctx._eraserHits) return;
    addTrail(ctx, ev);
    eraseAt(ctx, ev);
  },

  onPointerUp(ctx) {
    const hits = ctx._eraserHits;
    ctx._eraserHits = null;
    if (!hits || hits.size === 0) return;
    ctx.commit((els) => els.map((el) => hits.has(el.id) ? { ...el, isDeleted: true } : el));
    ctx.markDirty(2);
  },

  onCancel(ctx) {
    ctx._eraserHits = null;
    ctx.getEraserTrail().length = 0;
    ctx.markDirty(1);
  },
};

function addTrail(ctx, ev) {
  const vp = ctx.getVp();
  const { x, y } = worldFromClient(ev.clientX, ev.clientY, ctx.canvasEl, vp);
  const trail = ctx.getEraserTrail();
  trail.push({ x, y, t: performance.now() });
  if (trail.length > 120) trail.shift();
  ctx.markDirty(1);
}

function startTicker(ctx) {
  if (ctx._eraserRaf) return;
  const tick = () => {
    const trail = ctx.getEraserTrail();
    const now = performance.now();
    while (trail.length && now - trail[0].t > TRAIL_LIFESPAN_MS) trail.shift();
    ctx.markDirty(1);
    if (trail.length === 0 && !ctx._eraserHits) {
      ctx._eraserRaf = 0;
      return;
    }
    ctx._eraserRaf = requestAnimationFrame(tick);
  };
  ctx._eraserRaf = requestAnimationFrame(tick);
}

function eraseAt(ctx, ev) {
  const { canvasEl, getVp, getScene } = ctx;
  const vp = getVp();
  const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, vp);
  const scene = getScene();
  let anyHit = false;
  for (let i = scene.elements.length - 1; i >= 0; i--) {
    const el = scene.elements[i];
    if (el.isDeleted) continue;
    if (ctx._eraserHits.has(el.id)) continue;
    if (elementContainsPoint(el, x, y)) {
      ctx._eraserHits.add(el.id);
      anyHit = true;
    }
  }
  if (anyHit) ctx.markDirty(1);
  return true;
}

/** Renderer helper — paint a fading red stroke under the cursor. */
export function paintEraserTrail(ctx2d, points, vp) {
  if (!points || points.length < 2) return;
  const now = performance.now();
  ctx2d.save();
  ctx2d.lineCap = 'round';
  ctx2d.lineJoin = 'round';
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1];
    const b = points[i];
    const age = now - b.t;
    const life = Math.max(0, 1 - age / TRAIL_LIFESPAN_MS);
    if (life <= 0) continue;
    ctx2d.globalAlpha = 0.35 * life;
    ctx2d.strokeStyle = '#ef4444';
    ctx2d.lineWidth = (14 + 6 * life) / vp.zoom;
    ctx2d.beginPath();
    ctx2d.moveTo(a.x, a.y);
    ctx2d.lineTo(b.x, b.y);
    ctx2d.stroke();
  }
  ctx2d.restore();
}
