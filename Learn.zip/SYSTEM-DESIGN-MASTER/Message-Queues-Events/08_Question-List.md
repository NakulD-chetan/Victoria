# Message Queues and Events — Question List

> **Permanent Recall:** These questions are not random. They test the whole messaging stack: **queue vs pub/sub**, **Kafka vs RabbitMQ**, **delivery guarantees**, **ordering**, **retries + DLQ**, **CQRS**, **event sourcing**, and **Saga**. If you can answer this list cleanly, your messaging fundamentals are interview-ready.

---

## 10 Must-Do Questions

These are the highest-value practice questions for this section.

| # | Question | Difficulty | What It Tests |
|---|---|---|---|
| 1 | Design a notification system that sends email, SMS, and push | Medium | Pub/sub fan-out |
| 2 | Design an order processing pipeline across payment, inventory, and shipping | Medium | Event-driven workflow, Saga |
| 3 | Kafka vs RabbitMQ: when do you choose each? | Easy | Broker selection |
| 4 | Design a pipeline for 1M events per second | Medium | Kafka partitions, throughput, consumer groups |
| 5 | How do you handle duplicates and delivery guarantees? | Medium | At-least-once, idempotency |
| 6 | Design an event-driven e-commerce architecture | Medium | Topics, consumers, decoupling |
| 7 | What happens if the consumer fails repeatedly? | Easy | Retries, DLQ, poison messages |
| 8 | Explain event sourcing for an order domain | Hard | Replay, audit, schema evolution |
| 9 | How do you preserve ordering in a distributed system? | Medium | Partition key, per-entity order |
| 10 | Design a distributed payment workflow across services | Hard | Saga and compensation |

---

## Kafka-Focused Questions

| # | Question | Difficulty |
|---|---|---|
| 11 | How does Kafka achieve high throughput? | Easy |
| 12 | What are topics, partitions, offsets, and consumer groups? | Easy |
| 13 | How do you choose partition count? | Medium |
| 14 | How do Kafka consumers commit progress? | Medium |
| 15 | What is log compaction and when is it useful? | Medium |
| 16 | How would you replay events from yesterday? | Medium |
| 17 | When would you use Kafka Streams or Flink on top of Kafka? | Medium |

---

## RabbitMQ-Focused Questions

| # | Question | Difficulty |
|---|---|---|
| 18 | Explain direct, fanout, topic, and headers exchanges | Easy |
| 19 | How do you build a work queue in RabbitMQ? | Medium |
| 20 | How do you scale RabbitMQ consumers safely? | Medium |
| 21 | How do DLQs work in RabbitMQ? | Easy |

---

## Event-Driven, CQRS, and Event Sourcing Questions

| # | Question | Difficulty |
|---|---|---|
| 22 | When should you use event-driven design instead of sync REST? | Easy |
| 23 | Design CQRS for a read-heavy dashboard | Medium |
| 24 | How do you handle schema evolution in event sourcing? | Hard |
| 25 | Design an event-driven microservices platform for a marketplace or mobility app | Hard |

---

## Saga and Distributed Workflow Questions

| # | Question | Difficulty |
|---|---|---|
| 26 | What is Saga? Choreography vs orchestration? | Medium |
| 27 | Design a hotel or travel booking saga | Hard |
| 28 | How do compensating transactions work? | Medium |
| 29 | Why can you not just use one ACID transaction across services? | Easy |

---

## Failure and Edge-Case Questions

| # | Question | Difficulty |
|---|---|---|
| 30 | At-most-once vs at-least-once vs exactly-once | Easy |
| 31 | How do you make a consumer idempotent? | Medium |
| 32 | What if the broker or queue goes down? | Medium |
| 33 | Consumer lag is rising. What do you do? | Medium |
| 34 | How do you keep ordering with multiple partitions? | Medium |
| 35 | How do you handle poison messages? | Easy |

---

## How To Answer Messaging Questions

### For design questions

Use this sequence:

1. Clarify sync vs async
2. Clarify one consumer vs many
3. Pick queue or pub/sub
4. Pick broker
5. Define delivery guarantee
6. Define ordering strategy
7. Add retry, DLQ, idempotency
8. Add scale and monitoring

### For "how does it work?" questions

Focus on:

- Kafka: partitions, offsets, consumer groups, replication
- RabbitMQ: exchanges, bindings, queues, ack model
- Saga: workflow steps and compensation

### For failure questions

Always talk about:

- retries
- DLQ
- idempotency
- broker HA
- backlog or lag monitoring

---

## Coverage Map

| Concept | Must-Know Questions |
|---|---|
| Queue vs pub/sub | 1, 3, 6, 22 |
| Kafka | 3, 4, 8, 11-17 |
| RabbitMQ | 3, 18-21 |
| Delivery guarantees | 5, 30, 31 |
| Ordering | 9, 34 |
| CQRS | 6, 23 |
| Event sourcing | 8, 24 |
| Saga | 2, 10, 26-29 |
| Failures and DLQ | 7, 32, 33, 35 |

---

## Short Study Checklist

- [ ] Can explain queue vs pub/sub in one minute
- [ ] Can explain Kafka vs RabbitMQ in one minute
- [ ] Can describe at-least-once plus idempotency clearly
- [ ] Can explain ordering without overclaiming
- [ ] Can describe retries and DLQ
- [ ] Can explain CQRS and event sourcing with one example
- [ ] Can explain Saga with one example
- [ ] Can handle broker failure and consumer lag follow-ups

---

## 30-SECOND REVISION BOX

```text
TOP PRACTICE AREAS:
notification fan-out
order workflow
Kafka vs RabbitMQ
high-throughput pipeline
delivery guarantees
consumer failure and DLQ
event sourcing
ordering
Saga

ANSWER FLOW:
async? -> queue or pub/sub? -> broker? -> delivery? -> ordering? -> retry/DLQ? -> scale?
```

---

**Prev: [[07_Tricks-and-Recognition]] | Next: [[09_Internals-From-Bits-to-Broker]]**
