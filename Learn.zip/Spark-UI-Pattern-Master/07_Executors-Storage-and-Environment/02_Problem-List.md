# Executors, Storage & Environment — Problem List

> **15 health-check tasks.** Goal: locate the metric in the right tab, interpret it, and propose a fix.

---

## 8 MUST-DO Tasks

| # | Scenario                                                                       | Tab          | Concept                  |
|---|--------------------------------------------------------------------------------|--------------|--------------------------|
| 1 | Compute the GC ratio of an executor and judge healthy/warning                  | Executors    | GC ratio                 |
| 2 | Find an executor with 90%+ memory usage                                        | Executors    | Memory pressure          |
| 3 | Verify `spark.sql.shuffle.partitions` is what you set                          | Environment  | Config sanity            |
| 4 | Check if a `df.cache()` is fully cached                                        | Storage      | Cache fraction           |
| 5 | Identify whether cache evicted (fraction < 100%)                               | Storage      | Eviction                 |
| 6 | Spot a dead executor                                                           | Executors    | Lost executors           |
| 7 | Detect spill on the executor                                                   | Executors    | Disk spill               |
| 8 | Confirm Java / Spark version match production                                  | Environment  | Version sanity           |

---

## Complete 15-Task Progression

### Easy (1–6) — Single Metric Reading

| # | Task                                                        | Tab          | Where to Look                              |
|---|-------------------------------------------------------------|--------------|--------------------------------------------|
| 1 | Read RDD Used / Max for executor 0                          | Executors    | RDD memory column                          |
| 2 | Read GC Time for driver                                     | Executors    | GC Time column                             |
| 3 | Find total tasks executed by each executor                  | Executors    | Total Tasks column                         |
| 4 | Verify cache fraction is 100%                               | Storage      | Cached Partitions column                   |
| 5 | Read storage level of the cached DataFrame                   | Storage      | Storage Level column                       |
| 6 | List all `spark.sql.*` configs in your app                   | Environment  | Spark Properties section                   |

### Medium (7–11) — Cross-Computations

| # | Task                                                              | Tab(s)               | Approach                                                    |
|---|-------------------------------------------------------------------|----------------------|-------------------------------------------------------------|
| 7 | Compute GC ratio = GC Time / Total Task Time                      | Executors + Stages   | Sum task time across stages, divide                         |
| 8 | Compute spill ratio = Disk Used / Shuffle Read                     | Executors + Stages   | Get shuffle read total from stages                          |
| 9 | Identify cache that is too big and rarely reused                  | Storage + Jobs       | Big size + only 1 action referencing it = candidate to drop |
|10 | Verify AQE flag took effect                                       | Environment + SQL    | Env: `spark.sql.adaptive.enabled = true`; SQL: AQE* operators|
|11 | Reproduce eviction: cache 5 large dfs and watch fraction drop      | Storage              | Watch Cached Partitions live                                |

### Hard (12–15) — Production Debugging

| # | Task                                                            | Tab          | Notes                                                          |
|---|-----------------------------------------------------------------|--------------|----------------------------------------------------------------|
|12 | A config you set is missing from Environment tab                 | Environment  | Likely set after `getOrCreate()` or via Hadoop conf            |
|13 | One executor has 5x the GC time of others                        | Executors    | Skewed cache or skewed task assignment                          |
|14 | Driver GC time is high                                            | Executors    | Likely too much `collect()` / `toPandas()`                      |
|15 | Storage tab shows OnDisk size > Memory size                       | Storage      | Cache spilling beyond memory; lower row count or use SER         |

---

## Strategy Notes

### Task 1 — Healthy/Warning Decision

```
GC ratio < 5%      -> healthy
GC ratio 5-10%     -> warning; consider
                       - reducing cached data
                       - bigger heap
                       - G1GC instead of CMS
GC ratio > 10%     -> unhealthy; act now
```

### Task 7 — Compute GC Ratio Manually

```
Step 1: Open Stages tab, sum total task time.
        Example: 100 stages × avg 1s each × 16 tasks = 1600 task-seconds

Step 2: Open Executors tab, sum GC Time across executors.
        Example: 4 execs × 30s GC each = 120 GC-seconds

Step 3: GC ratio = 120 / 1600 = 7.5% -> warning.
```

### Task 8 — Spill Ratio

```
From Executors tab:    Disk Used = 2.1 GB
From Stages tab:        Shuffle Read total = 30 GB
Spill ratio = 2.1 / 30 = 7%   -> moderate; consider raising memory
```

### Task 12 — Missing Config Detective

```
Symptom:    Set spark.sql.shuffle.partitions=8 in code,
            Environment tab shows 200.
Diagnoses:
  (a) Set after SparkSession.builder.getOrCreate()  -> too late
  (b) Typo in key
  (c) Set on Hadoop conf instead of Spark conf
  (d) Cluster runtime overrides
Fix:
  spark = SparkSession.builder \
      .config("spark.sql.shuffle.partitions", "8") \
      .getOrCreate()        # builder, not after
```

### Task 14 — High Driver GC

```
Symptom: Driver GC rising during collect()
Cause:    Pulling huge results to driver
Fix:
  - Replace collect() with write() to file
  - Use toLocalIterator() to stream
  - Increase spark.driver.memory if can't avoid
```

### Task 15 — Cache Spilling Beyond Memory

```
Storage tab shows:
  df: MEMORY_AND_DISK   240MB in mem  4GB on disk

Diagnoses:
  - Memory not enough for full cache
  - Spilled to disk = future reads will be slow

Fix:
  - df.persist(MEMORY_ONLY_SER) to compress in memory
  - Reduce columns: df.select("a","b").cache()
  - Filter before cache: df.filter(...).cache()
```

---

## Diagnostic Cheat Card

```
SYMPTOM                              -> GO TO TAB(S)             -> ACTION
-------------------------------------- -------------------------- -------------------------
"OOM"                                 Executors -> mem usage     ↑memory or reduce cache
"Pipeline slows over time"            Storage -> fraction drops  Use MEMORY_AND_DISK
"Config not applied"                  Environment                Check builder vs conf.set
"GC > 50% time"                       Executors GC + Stages       Lower cache; tune GC
"One exec hot, others idle"           Executors active tasks      Skew (Pattern 08)
"Cache empty after cache()"           Storage empty                Run an action
"Driver crashes on collect"            Executors driver GC         Replace with write/iter
"Cache > 100% file size"              Storage size + Storage Lvl  Use MEMORY_ONLY_SER
"Spilling on small data"              Stages spill + Executors    ↑memory or reduce shuffle.partitions
"Lost executor"                       Executors Status=Dead       Check logs; resilience
```

---

## Cross-Reference

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| Why some stages spill (links Spill ↔ Executors)    | 04, 08  |
| What "skipped" cache reads look like                 | 05      |
| Reading skew via Stages summary metrics              | 04, 08  |

---

## Study Plan

### Day 1 — Tab Tour
- Tasks 1–6.
- Identify each metric in your local UI.

### Day 2 — Compute Ratios
- Tasks 7–8. Write down GC ratio and spill ratio for your run.

### Day 3 — Cache Stress Test
- Task 11. Cache progressively bigger dfs until fraction drops.

### Day 4 — Production Scenarios
- Tasks 12–15. Simulate each (e.g. set wrong config, force collect on big df).

---

## Final Revision Box

```
EXECUTORS TAB
  - Status: Alive/Dead
  - RDD Used/Max, Storage Mem
  - GC Time, Failed Tasks, Active Tasks
  - Use ratios: GC%, Spill%, Mem%

STORAGE TAB
  - Cached Partitions: N/total (must be 100% for healthy cache)
  - Storage Level: MEMORY_*, DISK_*
  - OnDisk > 0 means cache spilled

ENVIRONMENT TAB
  - Spark Properties (verify your config applied)
  - Java / Scala / Spark version
  - Hadoop properties (S3 / HDFS creds)

RULE
  - Whenever Jobs/Stages says "wrong",
    these 3 tabs say "why".
  - Healthy thresholds: GC < 5%, Mem < 70%, Cache = 100%, Spill = 0.
```
