# Normalization and Transactions — Tricks and Recognition

| Signal | Think |
|--------|--------|
| "Data repeated in many rows" | Normalize — split into parent + child |
| "Update one fact → many rows change" | Update anomaly → needs normalization |
| "Bank transfer, booking" | Transaction with ACID — all or nothing |
| "Two users update same row" | Isolation level + locking strategy |
| "Slow reads on normalized schema" | Consider materialized view / summary table |
| "Data warehouse design" | Star schema = denormalized fact + dimensions |

---

*Next: [[08_Problem-List]]*
