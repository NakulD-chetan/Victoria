# SQL Foundation — Mental Model

---

## Picture: database as Excel sheets with rules

```
SCHEMA (DDL)                 DATA (DML/DQL)
┌─────────────────────┐      ┌──────────────────────────┐
│ users(id PK, email) │  →   │ rows obey PK/FK/CHECK...   │
│ orders(id, user_id FK)     │                            │
└─────────────────────┘      └──────────────────────────┘
```

- **DDL** = create/modify the “boxes.”
- **DML/DQL** = fill and read what’s inside.

---

## Keys mental shortcut

1. **PK** = “this row’s name tag” (unique).
2. **FK** = “this row belongs to that parent row.”

If you forget: **orphan rows** = child without parent → FK usually blocks or cascades (depends on DB).

---

## Statement family drill

Ask yourself: *Am I changing table shape, changing rows, or reading?*

| Changing table shape | Changing rows | Reading |
|----------------------|---------------|---------|
| `CREATE TABLE` … | `INSERT`/`UPDATE`/`DELETE` | `SELECT` |

---

## Hindi-English hook

- **Constraint** = rule jo DB enforce karta hai (galat data andar nahi aane dena).
- **Normalization** (later folder) = tables split karna taaki repeat data kam ho — yahan sirf itna yaad rakho: **PK/FK** normalization ke building blocks hain.

---

*Next: [[03_Coding-Template]]*
