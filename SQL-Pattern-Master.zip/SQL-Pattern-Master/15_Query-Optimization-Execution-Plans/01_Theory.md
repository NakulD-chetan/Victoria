# Query Optimization and Execution Plans

Understanding how the database executes your query is the difference between a 50ms query and a 50-second one. EXPLAIN ANALYZE reveals the execution plan — the sequence of operations, their costs, and where time is spent.

**DSA Analogy**: Algorithm complexity analysis — just like analyzing whether your code is O(n), O(n log n), or O(n^2), EXPLAIN tells you whether your query does a full table scan, index lookup, or hash join.

---

## Core Idea (2 Lines)

The query optimizer transforms your SQL into an execution plan — a tree of physical operations (scans, joins, sorts). **EXPLAIN** shows the plan before execution. **EXPLAIN ANALYZE** runs the query and shows actual vs estimated costs. Understanding this lets you write queries that are orders of magnitude faster.

---

## How a Query Gets Executed

```
Your SQL Query
     |
     v
[Parser]                    → Check syntax, build parse tree
     |
     v
[Analyzer]                  → Resolve names, check types, validate
     |
     v
[Query Optimizer]           → Generate candidate plans, pick cheapest
     |  Considers:
     |  - Available indexes
     |  - Table statistics (row counts, value distribution)
     |  - Join order options
     |  - Scan methods (seq scan, index scan, bitmap scan)
     v
[Execution Engine]          → Run the chosen plan
     |
     v
[Results]
```

---

## EXPLAIN and EXPLAIN ANALYZE

```sql
-- EXPLAIN: show the plan WITHOUT running the query
EXPLAIN
SELECT * FROM orders WHERE customer_id = 42;

-- EXPLAIN ANALYZE: run the query AND show actual timing
EXPLAIN ANALYZE
SELECT * FROM orders WHERE customer_id = 42;

-- PostgreSQL: verbose format with buffers
EXPLAIN (ANALYZE, BUFFERS, FORMAT TEXT)
SELECT * FROM orders WHERE customer_id = 42;
```

### Reading EXPLAIN Output

```
Seq Scan on orders  (cost=0.00..15000.00 rows=100 width=64)
                     ↑            ↑        ↑       ↑
                  startup cost  total cost  est.rows  row width

EXPLAIN ANALYZE adds:
  (actual time=0.01..45.23 rows=98 loops=1)
                 ↑          ↑      ↑
           actual timing   actual rows   number of executions
```

---

## Scan Types (How Data Is Read)

| Scan Type | What It Does | When Used | Cost |
|-----------|-------------|-----------|------|
| Sequential Scan (Seq Scan) | Read every row in the table | No useful index, or table is small | O(N) |
| Index Scan | Use B-tree index to find rows | Selective query on indexed column | O(log N + K) |
| Index Only Scan | Read from index alone (no table) | All needed columns are in the index | Fastest |
| Bitmap Index Scan | Build bitmap from index, then scan | Medium selectivity, multiple conditions | Between seq and index |
| Heap Scan (Table Scan) | Follow row pointers from index | After bitmap or index lookup | Depends |

```
Query: SELECT * FROM orders WHERE customer_id = 42

No Index:
  Seq Scan on orders → reads ALL 1,000,000 rows → filters to 100 matches
  Cost: ~1,000,000 row reads

With Index on customer_id:
  Index Scan using idx_customer_id → reads ~100 index entries + 100 table rows
  Cost: ~200 operations (orders of magnitude faster)
```

---

## Join Strategies

| Join Type | How It Works | Best When | Complexity |
|-----------|-------------|-----------|------------|
| Nested Loop | For each row in A, scan B for matches | Small outer table, indexed inner | O(N × M) worst, O(N × log M) with index |
| Hash Join | Build hash table from smaller table, probe with larger | Medium-large tables, equi-join | O(N + M) |
| Merge Join (Sort-Merge) | Sort both tables, merge in order | Both already sorted, or large equi-join | O(N log N + M log M) |

```
  NESTED LOOP:                    HASH JOIN:                    MERGE JOIN:
  For each row in A:              Build hash(B)                 Sort A, Sort B
    For each row in B:            For each row in A:            Merge in order:
      if match → output             probe hash(B)                advance both
                                     if match → output            if match → output

  Best: small A × indexed B       Best: large + large           Best: pre-sorted data
  Worst: large A × large B        RAM needed: hash fits memory  CPU: sort cost
```

---

## Index Types and When to Use Them

| Index Type | Best For | Example |
|-----------|---------|---------|
| B-tree (default) | Equality, range, ORDER BY, GROUP BY | `WHERE id = 5`, `WHERE date > '2024-01'` |
| Hash | Equality only (no range) | `WHERE status = 'active'` |
| GIN (Generalized Inverted) | Array containment, full-text search, JSONB | `WHERE tags @> ARRAY['sql']` |
| GiST | Spatial, range types, nearest neighbor | PostGIS geometry queries |
| BRIN (Block Range) | Large, naturally ordered tables | Time-series data on timestamp |
| Partial Index | Subset of rows | `CREATE INDEX ... WHERE status = 'active'` |
| Composite Index | Multi-column queries | `CREATE INDEX ON orders(customer_id, order_date)` |
| Covering Index | Index-only scans | `CREATE INDEX ON orders(customer_id) INCLUDE (amount)` |

### Composite Index Column Order Matters

```sql
-- Index: (customer_id, order_date)

-- Uses index (leftmost prefix):
WHERE customer_id = 42                           ✓
WHERE customer_id = 42 AND order_date > '2024-01' ✓

-- Cannot use this index efficiently:
WHERE order_date > '2024-01'                     ✗ (skips first column)

-- Rule: Index columns from left to right must match query conditions
```

---

## The Key Optimization Techniques

### 1. Add the Right Index

```sql
-- Before: Seq Scan (reads 10M rows)
SELECT * FROM orders WHERE customer_id = 42;

-- Fix: Add index
CREATE INDEX idx_orders_customer ON orders(customer_id);

-- After: Index Scan (reads ~100 rows)
```

### 2. Avoid SELECT *

```sql
-- BAD: fetches all columns (table access required)
SELECT * FROM orders WHERE customer_id = 42;

-- GOOD: only columns needed (may enable index-only scan)
SELECT order_date, amount FROM orders WHERE customer_id = 42;

-- BEST: covering index for index-only scan
CREATE INDEX idx_orders_covering ON orders(customer_id) INCLUDE (order_date, amount);
```

### 3. Push Filters Early (Predicate Pushdown)

```sql
-- BAD: filter after join (processes all rows)
SELECT * FROM orders o
JOIN customers c ON o.customer_id = c.id
WHERE c.city = 'NYC';

-- Usually same (optimizer pushes down), but verify with EXPLAIN
-- Add index on customers(city) for best results
```

### 4. Avoid Functions on Indexed Columns

```sql
-- BAD: function on column prevents index use
WHERE YEAR(order_date) = 2024

-- GOOD: range condition uses index
WHERE order_date >= '2024-01-01' AND order_date < '2025-01-01'

-- BAD: LOWER kills index
WHERE LOWER(email) = 'alice@example.com'

-- GOOD: functional index (PostgreSQL)
CREATE INDEX idx_email_lower ON users (LOWER(email));
```

### 5. Optimize JOIN Order

```sql
-- The optimizer usually handles this, but for complex queries:
-- Start with the most selective (smallest result) table
-- Join to the next table that reduces results most
-- Use STRAIGHT_JOIN (MySQL) or hints to force order if needed
```

### 6. Use EXISTS Instead of COUNT

```sql
-- BAD: counts ALL matching rows
SELECT * FROM customers c
WHERE (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) > 0;

-- GOOD: stops at first match
SELECT * FROM customers c
WHERE EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.id);
```

---

## Query Anti-Patterns (Performance Killers)

| Anti-Pattern | Why Slow | Fix |
|-------------|----------|-----|
| `SELECT *` | Fetches unnecessary columns, prevents index-only scan | Select only needed columns |
| `WHERE FUNCTION(col) = val` | Can't use index on col | Rewrite as range, or create functional index |
| `OR` conditions | May prevent index use | Rewrite as UNION ALL |
| `NOT IN` with NULLs | Semantically broken AND slow | Use NOT EXISTS |
| Correlated subquery without index | O(N × M) | Add index on correlated column |
| `ORDER BY RAND()` | Full sort of entire table | Use alternative random sampling |
| `LIKE '%abc'` (leading wildcard) | Can't use B-tree index | Full-text search or reverse index |
| Implicit type conversion | Index may not be used | Match types exactly |
| Over-indexing | Slow writes, extra storage | Index only columns used in WHERE/JOIN/ORDER |

---

## Statistics and the Optimizer

```sql
-- PostgreSQL: update table statistics
ANALYZE table_name;

-- PostgreSQL: view statistics
SELECT * FROM pg_stats WHERE tablename = 'orders';

-- MySQL: update statistics
ANALYZE TABLE orders;

-- Statistics tell the optimizer:
-- - How many rows in the table
-- - Distribution of values (histogram)
-- - Number of distinct values
-- - NULL fraction
-- Without accurate stats, the optimizer picks bad plans
```

---

## Reading an Execution Plan (Example)

```sql
EXPLAIN ANALYZE
SELECT c.name, COUNT(o.id) AS order_count
FROM customers c
JOIN orders o ON o.customer_id = c.id
WHERE c.city = 'NYC'
GROUP BY c.name
ORDER BY order_count DESC
LIMIT 10;
```

```
Limit  (cost=... rows=10)
  → Sort  (cost=... rows=50)
      Sort Key: count(o.id) DESC
      → HashAggregate  (cost=... rows=50)
            Group Key: c.name
            → Hash Join  (cost=... rows=5000)
                  Hash Cond: (o.customer_id = c.id)
                  → Seq Scan on orders  (cost=... rows=1000000)
                  → Hash
                        → Bitmap Index Scan on idx_customers_city  (cost=... rows=50)
                              Index Cond: (city = 'NYC')
```

**Reading bottom-up:**
1. Bitmap scan filters customers in NYC (~50 rows)
2. Build hash table from those customers
3. Sequential scan on orders (potential bottleneck — 1M rows!)
4. Hash join matches orders to NYC customers
5. Group by name, count orders
6. Sort by count descending
7. Take top 10

**Optimization**: Add index on `orders(customer_id)` to replace Seq Scan with Index Scan.

---

## Key Takeaway

> EXPLAIN ANALYZE is your X-ray into query performance. Read execution plans bottom-up: the innermost operations run first. Look for Seq Scans on large tables (add indexes), high row estimates vs actuals (update statistics), and Nested Loop Joins on large tables (consider Hash Join). The most impactful optimizations are: right indexes, selective filters early, avoiding functions on indexed columns, and EXISTS over COUNT.
