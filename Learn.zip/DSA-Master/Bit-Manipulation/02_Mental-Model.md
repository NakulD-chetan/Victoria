# Bit Manipulation — Mental Models

> **FAANG Focus:** Build intuition so you *recognize* bit problems instantly.

---

## 1. Light Switch Analogy

Each bit = a light switch. Operations = flipping switches.

| Operation | Switch Analogy |
|-----------|----------------|
| **XOR** | Toggle: flip switch if mask says so |
| **OR** | Turn ON (never OFF) |
| **AND** | Filter: only switches where mask=1 pass |
| **NOT** | Flip ALL switches |

```
XOR toggles (1 ^ 1 = 0, 0 ^ 1 = 1):
  Before:  [OFF][ON][OFF][ON]
  Mask:    [ON][OFF][ON][OFF]
  XOR:     [ON][ON][ON][ON]  ← toggled where mask=1
```

---

## 2. Binary Number Visualization

```
Decimal 13 = 1101 (binary)

Position:  3   2   1   0
Bit:       1   1   0   1
Value:     8 + 4 + 0 + 1 = 13

  [1] [1] [0] [1]
   ↑   ↑   ↑   ↑
  MSB        LSB
```

---

## 3. Bitmask as Subset Representation

**Each bit = include (1) or exclude (0)**

```
Universe = {A, B, C, D}  (4 items, bits 0–3)

mask = 1011  →  {A, B, D} selected
       │││└─ bit 0: A ✓
       ││└── bit 1: B ✓
       │└─── bit 2: C ✗
       └──── bit 3: D ✓

All subsets: 0000 → 1111  (16 = 2^4)
```

### ASCII: Subset Enumeration

```
n=3, enumerate 2^3=8 subsets:

mask  binary  subset
  0    000    {}
  1    001    {0}
  2    010    {1}
  3    011    {0,1}
  4    100    {2}
  5    101    {0,2}
  6    110    {1,2}
  7    111    {0,1,2}
```

---

## 4. Binary Addition & Subtraction — Quick Reference

> **Full in-depth walkthrough:** See `00_Binary-Arithmetic-Foundation.md` for complete step-by-step addition, subtraction, conversion, two's complement, and why every trick works.

```
  +1 carry:   ripples through trailing 1s → each 1 becomes 0 → first 0 becomes 1
  -1 borrow:  ripples through trailing 0s → each 0 becomes 1 → first 1 becomes 0

  They are MIRRORS:
    Before +1:  X X [0] 1 1 1  →  After: X X [1] 0 0 0
    Before -1:  X X [1] 0 0 0  →  After: X X [0] 1 1 1
```

**Why n & (n-1) removes lowest set bit:**
```
  n     = X X X X [1] 0 0 0    (lowest set bit + trailing zeros)
  n-1   = X X X X [0] 1 1 1    (borrow flips this whole zone)
  ────────────────────────────
  n&(n-1)= X X X X [0] 0 0 0   (left unchanged, rest zeroed)
```

---

## 5. Common Bit Tricks — ASCII

### Remove Lowest Set Bit: `n & (n-1)`

```
n=12 (1100):
  n   = 1 1 0 0
  n-1 = 1 0 1 1   (borrow propagates)
  ─────────────
  &   = 1 0 0 0   (lowest 1 gone)
```

### Isolate Lowest Set Bit: `n & (-n)`

```
n=12 (1100):
  n  = 0 0 1 1 0 0
  -n = 1 1 0 1 0 0   (two's complement)
  ─────────────────
  &  = 0 0 0 1 0 0   (only LSB remains)
```

### Power of 2: `n & (n-1) == 0`

```
n=8 (1000):     n=6 (0110):
  n   = 1000       n   = 0110
  n-1 = 0111       n-1 = 0101
  &   = 0000 ✓     &   = 0100 ≠ 0 ✗
```

### XOR Cancellation

```
a ^ b ^ b ^ a ^ c
= (a^a) ^ (b^b) ^ c
= 0 ^ 0 ^ c
= c
```

---

## 6. Set Operations as Bitwise

| Set Op | Bitwise | Example |
|--------|---------|---------|
| Union | `a \| b` | `1010 \| 0110 = 1110` |
| Intersection | `a & b` | `1010 & 0110 = 0010` |
| Difference | `a & ~b` | `1010 & 1001 = 1000` |
| Symmetric diff | `a ^ b` | `1010 ^ 0110 = 1100` |
| Subset check | `(a & b) == a` | |
| Size | popcount | `__builtin_popcount` |

---

## 7. "Layers" Model — Bit-by-Bit Independence

Many problems: process each bit position independently.

```
Numbers stacked:
  5 = 1 0 1
  3 = 0 1 1
  6 = 1 1 0

Column 2: 1,0,1 → two 1s
Column 1: 0,1,1 → two 1s
Column 0: 1,1,0 → two 1s

AND of column = 1 iff all 1s
OR of column  = 1 iff any 1
XOR of column  = 1 iff odd count of 1s
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  XOR = toggle    OR = turn on    AND = filter    │
│  Bitmask: bit i = 1 → item i in subset          │
│  n & (n-1) removes LSB; n & (-n) isolates LSB   │
│  Set ops: | union, & intersect, ^ sym diff      │
│  Think bit-by-bit when columns independent      │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] XOR = toggle; OR = set; AND = mask
- [ ] Bitmask: 1=include, 0=exclude
- [ ] `n & (n-1)` removes LSB; `n & (-n)` isolates LSB
- [ ] Set ops: `|` union, `&` intersect, `^` sym diff
- [ ] Bit-by-bit when each column independent
