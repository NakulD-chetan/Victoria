# Linked List — Concept

> **Permanent Recall:** Linked List = sequence of nodes where each node stores data + pointer to next. O(1) insert/delete at known position, O(n) search. FAANG tests: reversal, cycle detection, merge, two-pointer tricks. When array random access needed → use array instead.

---

## Core Idea (2 Lines)

**A linked list is a linear data structure where each element (node) contains data and a reference to the next node. Unlike arrays, elements are not stored contiguously — you traverse by following pointers.**

---

## Types of Linked Lists


| Type                | Structure                           | Use Case                   |
| ------------------- | ----------------------------------- | -------------------------- |
| **Singly Linked**   | Node → Node → Node → null           | Most interview problems    |
| **Doubly Linked**   | null ← Node ⇄ Node ⇄ Node → null    | LRU Cache, browser history |
| **Circular**        | Node → Node → Node → (back to head) | Round-robin scheduling     |
| **Circular Doubly** | Head ⇄ ... ⇄ Tail ⇄ Head            | Deque implementations      |


---

## Node Structure

```
Singly:
┌──────┬──────┐    ┌──────┬──────┐    ┌──────┬──────┐
│ data │ next │───►│ data │ next │───►│ data │ null │
└──────┴──────┘    └──────┴──────┘    └──────┴──────┘

Doubly:
         ┌──────┬──────┬──────┐    ┌──────┬──────┬──────┐
null ◄───│ prev │ data │ next │───►│ prev │ data │ next │───► null
         └──────┴──────┴──────┘◄───└──────┴──────┴──────┘
```

---

## Linked List vs Array


| Aspect                | Linked List                           | Array                          |
| --------------------- | ------------------------------------- | ------------------------------ |
| **Access by index**   | O(n) — traverse                       | O(1) — direct                  |
| **Insert at head**    | O(1)                                  | O(n) — shift all               |
| **Insert at tail**    | O(1) with tail pointer, O(n) without  | O(1) amortized (dynamic)       |
| **Insert at middle**  | O(1) if position known (O(n) to find) | O(n) — shift                   |
| **Delete at head**    | O(1)                                  | O(n) — shift                   |
| **Delete at middle**  | O(1) if position known                | O(n) — shift                   |
| **Search**            | O(n)                                  | O(n) unsorted, O(log n) sorted |
| **Memory**            | Extra pointer per node                | Contiguous, cache-friendly     |
| **Cache performance** | Poor (scattered memory)               | Excellent (contiguous)         |


---

## When to Use Linked List

- **Frequent insert/delete** at beginning or known positions
- **Unknown size** — grows dynamically without reallocation
- **No random access needed** — only sequential traversal
- **Building other structures** — stacks, queues, graphs (adjacency list)

---

## When NOT to Use Linked List

- **Need random access** — array is O(1)
- **Cache-sensitive code** — arrays are cache-friendly
- **Small fixed-size data** — array overhead < pointer overhead
- **Binary search needed** — can't efficiently binary search a linked list

---

## Key Operations & Complexity


| Operation         | Singly       | Doubly | Notes                       |
| ----------------- | ------------ | ------ | --------------------------- |
| Access by index   | O(n)         | O(n)   | Must traverse               |
| Insert at head    | O(1)         | O(1)   | Update head pointer         |
| Insert at tail    | O(n) / O(1)* | O(1)   | *O(1) with tail pointer     |
| Insert after node | O(1)         | O(1)   | Given reference to node     |
| Delete head       | O(1)         | O(1)   | Update head                 |
| Delete given node | O(n)         | O(1)   | Singly needs prev traversal |
| Search            | O(n)         | O(n)   | Linear scan                 |
| Reverse           | O(n)         | O(n)   | Swap pointers               |


---

## The Dummy Head Technique

**Most powerful linked list trick.** Add a fake node before the real head to simplify edge cases (empty list, single node, insert/delete at head).

```
Without dummy:
  head → [1] → [2] → [3] → null
  Deleting head? Special case!

With dummy:
  dummy → [1] → [2] → [3] → null
  Deleting first real node? Same as deleting any node.
  Return dummy.next as new head.
```

---

## Common Linked List Patterns at FAANG


| Pattern                 | Key Technique                    | Example Problems                     |
| ----------------------- | -------------------------------- | ------------------------------------ |
| **Reversal**            | Three pointers: prev, curr, next | Reverse Linked List, Reverse Between |
| **Fast & Slow**         | Two pointers at different speeds | Cycle Detection, Find Middle         |
| **Merge**               | Compare and link                 | Merge Two Sorted Lists, Merge K      |
| **Dummy Head**          | Sentinel node                    | Remove Nth From End, Partition       |
| **In-place operations** | Pointer manipulation             | Swap Nodes in Pairs, Reorder List    |
| **Copy**                | HashMap or interleaving          | Copy List with Random Pointer        |


---

## ASCII: Linked List Fundamental Operations

```
INSERT AT HEAD:
  Before: head → [2] → [3] → null
  new_node(1).next = head
  head = new_node
  After:  head → [1] → [2] → [3] → null

DELETE AT HEAD:
  Before: head → [1] → [2] → [3] → null
  head = head.next
  After:  head → [2] → [3] → null

INSERT AFTER NODE:
  Before: ... → [A] → [C] → ...
  new_node(B).next = A.next
  A.next = new_node
  After:  ... → [A] → [B] → [C] → ...
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
LINKED LIST = Node(data, next) chain
TYPES: Singly, Doubly, Circular
vs ARRAY: O(1) insert/delete known pos, O(n) access (array opposite)
DUMMY HEAD: Simplifies all edge cases — always consider
PATTERNS: Reversal(3 ptr), Fast/Slow(cycle/mid), Merge, Dummy
WHEN: Frequent insert/delete, no random access needed
AVOID: Need index access, cache perf, binary search
```

