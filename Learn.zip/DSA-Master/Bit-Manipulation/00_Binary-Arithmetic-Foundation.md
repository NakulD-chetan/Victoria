# Binary Arithmetic — The Complete Foundation

> **Why this page exists:** Every bit manipulation trick (`n & (n-1)`, `n & (-n)`, two's complement) is just a consequence of how binary addition and subtraction work. Understand the arithmetic deeply once, and you'll never need to memorize a single trick again.

---

## 1. What is Binary? (Base-2 Number System)

Decimal (base-10): each position is a power of **10**.
Binary (base-2): each position is a power of **2**.

```
DECIMAL — base 10:
  4   7   3
  ↓   ↓   ↓
  4×100 + 7×10 + 3×1 = 473

  Position:  2      1      0
  Weight:   10²    10¹    10⁰
             100     10      1

BINARY — base 2 (exact same idea, just powers of 2):
  1   0   1   1
  ↓   ↓   ↓   ↓
  1×8 + 0×4 + 1×2 + 1×1 = 11

  Position:  3    2    1    0
  Weight:   2³   2²   2¹   2⁰
             8    4    2    1
```

### Powers of 2 — Burn This Into Memory

```
2⁰  = 1
2¹  = 2
2²  = 4
2³  = 8
2⁴  = 16
2⁵  = 32
2⁶  = 64
2⁷  = 128
2⁸  = 256
2⁹  = 512
2¹⁰ = 1024  (≈ 1K)
2²⁰ = 1,048,576  (≈ 1M)
```

### Why Only 0 and 1?

In decimal, each position has 10 possible digits (0–9).
In binary, each position has **2** possible digits: **0** and **1**.

When you run out of digits, you carry — just like decimal.

```
Decimal:  9 + 1 = 10   (ran out of single digits, carry to next position)
Binary:   1 + 1 = 10   (ran out of single digits, carry to next position)
```

---

## 2. Decimal → Binary Conversion

### Method 1: Repeated Division by 2 (Most Reliable)

Divide by 2 repeatedly. Collect remainders bottom → top.

```
Convert 13 to binary:

  13 ÷ 2 = 6  remainder 1  ←─┐
   6 ÷ 2 = 3  remainder 0     │  Read remainders
   3 ÷ 2 = 1  remainder 1     │  UPWARD
   1 ÷ 2 = 0  remainder 1  ←──┘

  13 in binary = 1 1 0 1  ✓

  Verify: 8 + 4 + 0 + 1 = 13  ✓
```

```
Convert 25 to binary:

  25 ÷ 2 = 12  remainder 1  ←─┐
  12 ÷ 2 = 6   remainder 0    │
   6 ÷ 2 = 3   remainder 0    │  Read UPWARD
   3 ÷ 2 = 1   remainder 1    │
   1 ÷ 2 = 0   remainder 1  ←─┘

  25 in binary = 1 1 0 0 1  ✓

  Verify: 16 + 8 + 0 + 0 + 1 = 25  ✓
```

### Method 2: Subtract Largest Power of 2 (Faster in Head)

Find the largest power of 2 that fits, subtract it, mark a 1. Repeat.

```
Convert 45 to binary:

  45 - 32 = 13  →  bit 5 = 1  (2⁵ = 32)
  13 - 8  = 5   →  bit 3 = 1  (2³ = 8)
   5 - 4  = 1   →  bit 2 = 1  (2² = 4)
   1 - 1  = 0   →  bit 0 = 1  (2⁰ = 1)

  Fill in the gaps with 0:
  Position: 5  4  3  2  1  0
  Bit:      1  0  1  1  0  1

  45 = 101101  ✓
  Verify: 32 + 8 + 4 + 1 = 45  ✓
```

### Method 3: Quick Trick for Small Numbers

Memorize 0–15, and you can build any number:

```
Dec  Binary    Dec  Binary
 0   0000       8   1000
 1   0001       9   1001
 2   0010      10   1010
 3   0011      11   1011
 4   0100      12   1100
 5   0101      13   1101
 6   0110      14   1110
 7   0111      15   1111
```

For larger numbers, split into groups:
```
200 = 128 + 64 + 8 = 11001000
```

---

## 3. Binary → Decimal Conversion

Write each bit's positional value. Add the 1s.

```
Binary: 1 0 1 1 0 1

Position:  5    4    3    2    1    0
Weight:   32   16    8    4    2    1
Bit:       1    0    1    1    0    1
Value:    32 +  0 +  8 +  4 +  0 +  1  = 45  ✓
```

### Quick Trick: Double-and-Add (Left to Right)

Start from the leftmost bit. For each bit: double what you have, then add the bit.

```
Binary: 1 0 1 1 0 1

  Start:                0
  Bit 1:  0 × 2 + 1  =  1
  Bit 0:  1 × 2 + 0  =  2
  Bit 1:  2 × 2 + 1  =  5
  Bit 1:  5 × 2 + 1  = 11
  Bit 0: 11 × 2 + 0  = 22
  Bit 1: 22 × 2 + 1  = 45  ✓
```

This is Horner's method — very fast for mental math.

---

## 4. Binary Addition — In Depth

### The Rules (Only 4 Cases)

```
  0 + 0 = 0                  (nothing + nothing = nothing)
  0 + 1 = 1                  (nothing + one = one)
  1 + 0 = 1                  (one + nothing = one)
  1 + 1 = 10                 (one + one = two, but 2 doesn't exist in binary)
            ↑↑                 so: write 0, CARRY 1 to next position
         carry result

  1 + 1 + 1(carry) = 11      (three = binary 11)
                      ↑↑       write 1, CARRY 1
                   carry result
```

**The CARRY is the entire key.** It's exactly like decimal: `7 + 5 = 12`, write 2, carry 1.

### Example 1: Simple Addition (5 + 3 = 8)

```
        0 1 0 1   (5)
      + 0 0 1 1   (3)
      ──────────

  Working right to left:

  pos 0:  1 + 1       = 10   → write 0, carry 1
  pos 1:  0 + 1 + c:1 = 10   → write 0, carry 1
  pos 2:  1 + 0 + c:1 = 10   → write 0, carry 1
  pos 3:  0 + 0 + c:1 = 01   → write 1, carry 0

  Carries: 1 1 1 0
           0 1 0 1   (5)
         + 0 0 1 1   (3)
         ──────────
           1 0 0 0   (8)  ✓
```

### Example 2: Carry Ripple (7 + 1 = 8)

```
        0 1 1 1   (7)
      + 0 0 0 1   (1)
      ──────────

  pos 0:  1 + 1       = 10   → write 0, carry 1
  pos 1:  1 + 0 + c:1 = 10   → write 0, carry 1
  pos 2:  1 + 0 + c:1 = 10   → write 0, carry 1
  pos 3:  0 + 0 + c:1 = 01   → write 1, no carry

        0 1 1 1   (7)
      + 0 0 0 1   (1)
      ──────────
        1 0 0 0   (8)  ✓

  ★ KEY INSIGHT — CARRY CHAIN:
    When you add 1 to consecutive 1s, the carry RIPPLES through
    all of them, turning each 1 → 0, until it hits a 0 (which becomes 1).

    0 1 1 1      all these 1s get "consumed" by the carry
        + 1      carry ripples left ← ← ←
    ────────
    1 0 0 0      carry stopped at the first 0 (pos 3)
```

### Example 3: Larger Numbers (27 + 14 = 41)

```
        1 1 0 1 1   (27)
      + 0 1 1 1 0   (14)
      ────────────

  pos 0:  1 + 0       = 1    → write 1
  pos 1:  1 + 1       = 10   → write 0, carry 1
  pos 2:  0 + 1 + c:1 = 10   → write 0, carry 1
  pos 3:  1 + 1 + c:1 = 11   → write 1, carry 1
  pos 4:  1 + 0 + c:1 = 10   → write 0, carry 1
  pos 5:  0 + 0 + c:1 = 01   → write 1

        1 1 0 1 1   (27)
      + 0 1 1 1 0   (14)
      ────────────
      1 0 1 0 0 1   (41)  ✓

  Verify: 32 + 8 + 1 = 41  ✓
```

### The Universal Rule of Addition

```
  When you add 1 to a binary number:

  Case 1 — Rightmost bit is 0:
    ...X X X 0  +  1  =  ...X X X 1     (just flips the 0 → 1, done)

  Case 2 — Rightmost bit(s) are 1:
    ...X 0 1 1  +  1  =  ...X 1 0 0     (carry ripples through 1s, stops at first 0)
    ...X 0 1 1 1 1 1  +  1  =  ...X 1 0 0 0 0 0

  Pattern: +1 flips trailing 1s→0, then flips the first 0→1
           (carry turns every 1 it touches into 0, stops when it hits 0)
```

---

## 5. Binary Subtraction — In Depth

### The Rules (Only 4 Cases)

```
  0 - 0 = 0                  (nothing - nothing = nothing)
  1 - 0 = 1                  (one - nothing = one)
  1 - 1 = 0                  (one - one = zero)
  0 - 1 = ?                  PROBLEM! Can't take 1 from 0!

  Solution: BORROW from the next position to the left.

  0 - 1:  borrow 1 from left → position becomes "10" (binary 2)
           10 - 1 = 1         (2 - 1 = 1)
           The position we borrowed FROM loses 1.
```

**The BORROW is the entire key.** It's exactly like decimal: `30 - 7 → borrow from 3, making it 2, and the 0 becomes 10`.

### Example 1: Simple Borrow (10 - 1 = 9)

```
        1 0 1 0   (10)
      - 0 0 0 1   (1)
      ──────────

  pos 0:  0 - 1  → can't! BORROW from pos 1
  pos 1:  1 - borrow → becomes 0
          pos 0 now has 10 (binary 2): 10 - 1 = 1
  pos 2:  0 - 0 = 0    (no borrow needed)
  pos 3:  1 - 0 = 1

        1 0 1 0   (10)
      - 0 0 0 1   (1)
      ──────────
        1 0 0 1   (9)  ✓
```

**What happened:**
```
  Before:  1 0 [1] 0     lowest set bit at pos 1
                ↑
           this gave the borrow

  After:   1 0 [0] 1     the 1 became 0, the trailing 0 became 1
```

### Example 2: Borrow Chain (12 - 1 = 11)

```
        1 1 0 0   (12)
      - 0 0 0 1   (1)
      ──────────

  pos 0:  0 - 1  → can't! borrow from pos 1
  pos 1:  0      → has nothing to give! borrow from pos 2
  pos 2:  1      → gives borrow → becomes 0
          ↓  pos 1 receives borrow, becomes 10 (2)
          ↓  pos 1 gives borrow to pos 0, becomes 1 (2-1)
          ↓  pos 0 receives borrow, becomes 10 (2)
          ↓  pos 0 does: 10 - 1 = 1

  Step by step detail:

  BEFORE borrow:    1  1  0  0
                              ↑ needs to subtract 1, but has 0

  pos 0 asks pos 1: "give me 1"
  pos 1 says:       "I'm 0 too, let me ask pos 2"
  pos 2 says:       "I'm 1, here you go" → pos 2 becomes 0
  pos 1 receives:   gets 2 (binary 10), gives 1 to pos 0 → pos 1 becomes 1
  pos 0 receives:   gets 2 (binary 10), subtracts 1 → pos 0 becomes 1

  AFTER borrow:     1  0  1  1

        1 1 0 0   (12)
      - 0 0 0 1   (1)
      ──────────
        1 0 1 1   (11)  ✓
```

### Example 3: Long Borrow Chain (32 - 1 = 31)

```
        1 0 0 0 0 0   (32)
      - 0 0 0 0 0 1   (1)
      ──────────────

  pos 0: 0 - 1 → borrow from pos 1
  pos 1: 0     → borrow from pos 2
  pos 2: 0     → borrow from pos 3
  pos 3: 0     → borrow from pos 4
  pos 4: 0     → borrow from pos 5
  pos 5: 1     → gives borrow → becomes 0
         ↓ ripples all the way back

        1 0 0 0 0 0   (32)
      - 0 0 0 0 0 1   (1)
      ──────────────
        0 1 1 1 1 1   (31)  ✓

  ★ THE BORROW CHAIN: travels left through ALL zeros
    until it finds a 1, which absorbs it.
    Every 0 it passed through becomes 1.
    The 1 it reached becomes 0.
```

### Example 4: Larger Subtraction (45 - 7 = 38)

```
        1 0 1 1 0 1   (45)
      - 0 0 0 1 1 1   (7)
      ──────────────

  pos 0: 1 - 1 = 0
  pos 1: 0 - 1 → borrow from pos 2
  pos 2: 1 → gives borrow → becomes 0
         pos 1: 10 - 1 = 1
  pos 3: 1 - 1 = 0
  pos 4: 0 - 0 = 0
  pos 5: 1 - 0 = 1

        1 0 1 1 0 1   (45)
      - 0 0 0 1 1 1   (7)
      ──────────────
        1 0 0 1 1 0   (38)  ✓

  Verify: 32 + 4 + 2 = 38  ✓
```

---

## 6. The Universal Pattern of n - 1

Now we can see **exactly why** subtracting 1 does what it does:

```
  Subtracting 1 = borrow starts at pos 0, travels left until
                  it finds the FIRST 1 (the lowest set bit)

  BEFORE:  X X X X [1] 0 0 0
                     ↑
               lowest set bit    trailing zeros

  Borrow chain: starts at pos 0, goes ← ← ← through zeros
                reaches the [1], absorbs it

  AFTER:   X X X X [0] 1 1 1
                     ↑
               became 0         zeros became 1s
               (gave borrow)    (borrow passed through)

  ┌──────────────────────────────────────────────────┐
  │  LEFT of lowest set bit:  UNCHANGED              │
  │     (borrow never reaches here)                  │
  │                                                  │
  │  The LOWEST SET BIT:  1 → 0                      │
  │     (it absorbed and stopped the borrow)         │
  │                                                  │
  │  RIGHT of it (trailing zeros):  0 → 1            │
  │     (each passed the borrow along, becoming 1)   │
  └──────────────────────────────────────────────────┘
```

### Contrast: n + 1 Pattern

```
  Adding 1 is the MIRROR of subtracting 1:

  BEFORE:  X X X X [0] 1 1 1
                     ↑
               lowest CLEAR bit  trailing ones

  Carry chain: starts at pos 0, goes ← ← ← through ones

  AFTER:   X X X X [1] 0 0 0
                     ↑
               became 1         ones became 0s
               (carry stopped)  (carry passed through)

  +1 turns trailing 1s→0 and the first 0→1 (carry)
  -1 turns trailing 0s→1 and the first 1→0 (borrow)

  They are exact mirrors of each other.
```

---

## 7. NOW Every Trick is Obvious

### Trick 1: `n & (n-1)` — Remove Lowest Set Bit

```
  n     = X X X X [1] 0 0 0
  n-1   = X X X X [0] 1 1 1     (from Section 6)
  ────────────────────────────
  n&(n-1)= X X X X [0] 0 0 0   ← lowest set bit GONE

  WHY?
  Left part:   X & X = X    (same bits, AND gives same)
  Lowest bit:  1 & 0 = 0    (n has 1, n-1 has 0 → cleared!)
  Right part:  0 & 1 = 0    (n has 0s, n-1 has 1s → all zero)
```

```
  Worked examples:

  n=12:   1100         n=40:  101000        n=7:   111
  n-1:    1011         n-1:   100111        n-1:   110
  &:      1000 (8)     &:     100000 (32)   &:     110 (6)
```

### Trick 2: Power of 2 Check — `n & (n-1) == 0`

```
  A power of 2 has EXACTLY one set bit:

  n=8:    1000       only one 1
  n-1=7:  0111       all bits flipped (borrow went all the way)
  &:      0000  ✓    zero! → power of 2

  n=6:    0110       two 1s
  n-1=5:  0101       only rightmost 1 flipped
  &:      0100  ✗    not zero! → not power of 2

  WHY? If there's only one 1, subtracting 1 flips EVERYTHING
  (the borrow travels through ALL trailing zeros = all other bits).
  AND gives all zeros.

  If there are multiple 1s, the higher 1s survive the AND.
```

### Trick 3: `n & (-n)` — Isolate Lowest Set Bit

```
  First, what is -n?   (Two's complement — see Section 8)
  -n = ~n + 1

  n     = X X X X [1] 0 0 0
  ~n    = X'X'X'X'[0] 1 1 1     (every bit flipped)
  ~n+1  = X'X'X'X'[1] 0 0 0     (+1 carry ripples through trailing 1s)
  
  So:
  n     = X X X X [1] 0 0 0
  -n    = X'X'X'X'[1] 0 0 0     (left bits are OPPOSITE, rest is SAME)
  ────────────────────────────
  n&(-n)= 0 0 0 0 [1] 0 0 0    ← only the lowest set bit survives!

  WHY?
  Left part:   X & X' = 0   (original vs flipped → always 0)
  Lowest bit:  1 & 1  = 1   (both have 1 here!)
  Right part:  0 & 0  = 0   (both have 0s)
```

### Trick 4: Count Set Bits (Brian Kernighan)

```python
count = 0
while n:
    n = n & (n-1)    # remove lowest set bit
    count += 1
```

```
  n=13 (1101):
    1101 & 1100 = 1100  (removed bit 0)  → count=1
    1100 & 1011 = 1000  (removed bit 2)  → count=2
    1000 & 0111 = 0000  (removed bit 3)  → count=3
    n=0, stop.

  WHY IT'S FAST: Loops only as many times as there are 1-bits.
  Not 32 iterations for a 32-bit number — just popcount iterations.
```

---

## 8. Two's Complement — How Computers Store Negatives

### The Problem

Binary has no minus sign. How do we represent -5?

### The Solution: Two's Complement

```
  To negate a number:  -n = ~n + 1  (flip all bits, then add 1)

  Example: -5 in 8-bit

  Step 1:   5 = 00000101
  Step 2:  ~5 = 11111010    (flip every bit)
  Step 3: +1  = 11111011    (add 1)

  So -5 = 11111011
```

### WHY Does ~n + 1 Give -n?

```
  Think about it:
    n + ~n = 11111111    (every bit: one has 0 where other has 1)
    n + ~n = 2^8 - 1     (all 1s in 8 bits = 255)
  
  So:
    n + ~n = 2^8 - 1
    ~n = 2^8 - 1 - n
    ~n + 1 = 2^8 - n    = -n  (in modular arithmetic)

  This isn't a trick — it's a mathematical identity!
```

### Two's Complement Number Line (8-bit)

```
  Binary        Unsigned    Signed (Two's Complement)
  00000000         0            0
  00000001         1           +1
  00000010         2           +2
  ...             ...          ...
  01111111       127         +127   ← largest positive
  ─────────── FLIP POINT ───────────
  10000000       128         -128   ← most negative
  10000001       129         -127
  ...             ...          ...
  11111110       254           -2
  11111111       255           -1   ← adding 1 to this overflows to 00000000 = 0

  ★ The MSB (leftmost bit) acts as the sign:
    0 = positive,  1 = negative
```

### Verify: 5 + (-5) = 0

```
    00000101   (5)
  + 11111011   (-5)
  ──────────
  1 00000000   carry overflows out → result = 00000000 = 0  ✓
```

---

## 9. Why Does -n Have the Same Lowest Set Bit as n?

This is why `n & (-n)` works — let's prove it step by step.

```
  n      = ...X X [1] 0 0 0    (some bits, lowest set bit, trailing zeros)

  Step 1: ~n
  ~n     = ...X'X'[0] 1 1 1    (all bits flipped)

  Step 2: ~n + 1
  Adding 1 to ~n:
  The trailing 1s cause a carry chain (just like Section 4!):
    [0] 1 1 1  +  1
     ↓
    [1] 0 0 0      carry ripples through trailing 1s, flips the 0 back to 1

  -n = ~n+1 = ...X'X'[1] 0 0 0

  Compare:
  n  = ...X X [1] 0 0 0
  -n = ...X'X'[1] 0 0 0
              ↑
        SAME from here rightward!
        OPPOSITE to the left!

  So n & (-n):
  Left:   X & X' = 0  (opposite bits → 0)
  LSB:    1 & 1  = 1  (both have 1!)
  Right:  0 & 0  = 0  (both have 0s)
  Result: 0 0 0 [1] 0 0 0   ← only the lowest set bit!
```

---

## 10. Addition & Subtraction Summary: The Two Mirror Rules

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│   ADDITION (+1):                                            │
│     Carry starts at rightmost bit, travels LEFT             │
│     Through consecutive 1s → each 1 becomes 0              │
│     Stops at first 0 → that 0 becomes 1                    │
│                                                             │
│     Before:  X X [0] 1 1 1                                  │
│     After:   X X [1] 0 0 0                                  │
│                                                             │
│   SUBTRACTION (-1):                                         │
│     Borrow starts at rightmost bit, travels LEFT            │
│     Through consecutive 0s → each 0 becomes 1              │
│     Stops at first 1 → that 1 becomes 0                    │
│                                                             │
│     Before:  X X [1] 0 0 0                                  │
│     After:   X X [0] 1 1 1                                  │
│                                                             │
│   They are EXACT MIRRORS of each other.                     │
│   +1 eats trailing 1s.    -1 eats trailing 0s.             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 11. Quick-Fire Conversion Tricks

### Trick 1: Multiply/Divide by 2

```
  Left shift (×2):   1011 << 1 = 10110    (11 × 2 = 22)
  Right shift (÷2):  1011 >> 1 = 0101     (11 ÷ 2 = 5, truncated)

  WHY? Same reason adding a 0 to "45" in decimal gives "450" (×10).
  In binary, adding a 0 multiplies by 2.
```

### Trick 2: Odd or Even?

```
  Check the last bit:
  Even: last bit = 0     1010 (10) → 0 → even
  Odd:  last bit = 1     1011 (11) → 1 → odd

  Code: (n & 1) == 0  →  even
```

### Trick 3: Quick Powers of 2

```
  2^k in binary = 1 followed by k zeros

  2^0 = 1        (1)
  2^1 = 10       (2)
  2^3 = 1000     (8)
  2^5 = 100000   (32)

  Code: 1 << k  gives 2^k
```

### Trick 4: 2^k - 1 = All 1s

```
  2^k - 1 = k ones in binary

  2^1 - 1 = 1        (1)
  2^3 - 1 = 111      (7)
  2^4 - 1 = 1111     (15)
  2^8 - 1 = 11111111 (255)

  WHY? 1000...0 - 1 = 0111...1  (borrow chain from Section 5!)
  Code: (1 << k) - 1  gives k ones
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌───────────────────────────────────────────────────────────────┐
│  BINARY = base 2: each position is a power of 2              │
│  Dec→Bin: divide by 2, read remainders upward                │
│  Bin→Dec: multiply each bit by its power of 2, sum           │
│                                                               │
│  ADDITION: carry ripples through trailing 1s → 1s become 0s  │
│  SUBTRACTION: borrow ripples through trailing 0s → 0s→1s     │
│  They are MIRRORS: +1 eats 1s, -1 eats 0s                   │
│                                                               │
│  n-1 flips: lowest set bit → 0, trailing 0s → 1s            │
│  n & (n-1): removes lowest set bit (left part unchanged)     │
│  n & (-n):  isolates lowest set bit (-n has same LSB as n)   │
│  -n = ~n + 1 (two's complement: flip + add 1)               │
│  Power of 2: only one set bit → n & (n-1) == 0              │
└───────────────────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] Dec→Bin: divide by 2, remainders upward (or subtract largest power of 2)
- [ ] Bin→Dec: double-and-add left to right (Horner's method)
- [ ] +1 carry: ripples through trailing 1s → stops at first 0
- [ ] -1 borrow: ripples through trailing 0s → stops at first 1
- [ ] n-1 flips lowest set bit and everything to its right
- [ ] n & (n-1) removes lowest set bit; n & (-n) isolates it
- [ ] -n = ~n + 1 → same LSB zone as n, opposite left zone
- [ ] Power of 2 = single set bit → n & (n-1) == 0
