# File Formats Deep Dive — Index

> This folder covers the **internals** of every file format a Data Engineer needs to know — byte-level structure, encoding mechanics, schema evolution, and the reasoning behind format selection. The depth is tuned for interviews that test whether you **truly understand** what happens inside Parquet, Avro, ORC, Delta, and Iceberg.

---

## How to Use These Notes

1. **Read 01–04 first** — these are the core file formats (Parquet, Avro, ORC, JSON/CSV).
2. **Then 05–06** — table formats (Delta Lake, Iceberg) build on top of file formats.
3. **07** — Protobuf/Thrift is relevant if you work with gRPC or high-performance services.
4. **08** — Compression is a cross-cutting concern across all formats.
5. **09** — The interview guide ties everything together with decision trees and rapid-fire Q&A.

---

## Notes

| # | Topic | What You'll Learn |
|---|-------|-------------------|
| 01 | **Parquet Deep Dive** | Row groups, column chunks, pages, encoding types (dictionary, RLE, delta), predicate pushdown mechanics, small file problem |
| 02 | **Avro Deep Dive** | Schema definition, evolution rules (backward/forward/full compatibility), Object Container File, Schema Registry, wire format |
| 03 | **ORC Deep Dive** | Stripes, three-level indexing, bloom filters, ACID transactions, Hive integration, ORC vs Parquet |
| 04 | **JSON, CSV & Semi-Structured** | Schema inference pitfalls, nested data handling, splittability, medallion pattern, schema-on-read vs schema-on-write |
| 05 | **Delta Lake Internals** | Transaction log (`_delta_log`), ACID mechanics, optimistic concurrency, OPTIMIZE, VACUUM, Z-Order, MERGE |
| 06 | **Apache Iceberg Internals** | Metadata tree architecture, hidden partitioning, partition evolution, snapshot isolation, column IDs, engine neutrality |
| 07 | **Protobuf & Thrift** | Wire format encoding, field numbers, code generation, gRPC, comparison with Avro, Kafka integration |
| 08 | **Compression Codecs Deep Dive** | Snappy, Gzip, Zstd, LZ4, Brotli — internals, splittability, benchmarks, when to use each |
| 09 | **Format Selection Interview Guide** | Decision tree, master comparison matrix, file vs table format, 25+ rapid-fire interview Q&A |

---

## Concept Map — How Everything Connects

```
                    ┌──────────────────────────────┐
                    │      FILE FORMATS            │
                    │  (how bytes are on disk)      │
                    ├──────────┬──────────┬─────────┤
                    │ Columnar │ Row-based│  Text   │
                    │ Parquet  │ Avro     │ JSON    │
                    │ ORC      │ Protobuf │ CSV     │
                    └────┬─────┴─────┬────┴─────────┘
                         │           │
              used by    │           │   used by
                         ▼           ▼
                    ┌──────────────────────────────┐
                    │      TABLE FORMATS           │
                    │  (how files become a table)   │
                    ├──────────────┬────────────────┤
                    │ Delta Lake   │ Apache Iceberg │
                    │ (Parquet +   │ (Parquet +     │
                    │  tx log)     │  metadata tree)│
                    └──────────────┴────────────────┘
                              │
              compressed with │
                              ▼
                    ┌──────────────────────────────┐
                    │   COMPRESSION CODECS         │
                    │  Snappy, Zstd, Gzip, LZ4     │
                    └──────────────────────────────┘
```

---

## Cross-References to Other Notes

| Existing Note | What It Covers | This Folder Adds |
|--------------|----------------|------------------|
| `Spark-Notes/18-File-Formats-Parquet-ORC-Avro.md` | Surface-level comparison | Byte-level internals, encoding types, performance tuning |
| `DE-Master/01-DE-Fundamentals/01_Concept.md` | Format table + compression table | Deep mechanics, decision reasoning, interview scenarios |
| `DE-Master/03-Data-Lakes-and-Lakehouse/01_Concept.md` | Delta/Iceberg/Hudi overview | Internal architecture, transaction log structure, metadata tree |

---
