# Monitoring and Observability — Edge Cases

> **Permanent Recall:** Edge cases: **log volume explosion**, **metric storage at scale**, **trace sampling at high throughput**, **clock skew in distributed traces**, **monitoring the monitoring system**, **alert storms during outages**, **log data privacy (PII)**. Plan for these when designing observability at scale.

---

## 1. Log Volume Explosion

**Scenario:** Black Friday; log volume 100x normal. Elasticsearch overloaded; ingestion falls behind.

| Mitigation | Description |
|------------|-------------|
| **Sampling** | Log 1% of debug; 100% of error |
| **Log level** | Prod = INFO; debug only when needed |
| **Drop non-critical** | Don't log every cache hit |
| **Sharding** | Split by service, time; scale Elasticsearch cluster |
| **Backpressure** | Buffer locally; drop old logs if overwhelmed |

```
TIERED LOGGING:
  ERROR   → 100% (always)
  WARN    → 100%
  INFO    → 100% (key events only)
  DEBUG   → 1-10% sampling in prod
```

---

## 2. Metric Storage at Scale

**Scenario:** Prometheus TSDB growing; retention 15 days; need 90 days.

| Solution | Description |
|----------|-------------|
| **Downsampling** | Keep raw for 15d; 5m rollups for 90d |
| **Federation** | Multiple Prometheus; long-term in Thanos/VictoriaMetrics |
| **Cardinality limits** | Reject high-cardinality metrics |
| **Recording rules** | Pre-aggregate expensive queries |

---

## 3. Trace Sampling at High Throughput

**Scenario:** 1M req/s; 100% tracing = huge cost.

| Strategy | When |
|----------|------|
| **Head-based sampling** | Sample at start (e.g., 1%); fast, may miss rare errors |
| **Tail-based sampling** | Sample based on result (e.g., all errors, slow requests) |
| **Hybrid** | 1% head + 100% of errors/slow in tail |

```
TAIL-BASED SAMPLING (Jaeger):
  - Always keep: status=error, latency > 1s
  - Sample 1% of success, fast requests
```

---

## 4. Clock Skew in Distributed Traces

**Scenario:** Servers have different wall clocks; spans show negative duration or wrong order.

| Mitigation | Description |
|------------|-------------|
| **NTP sync** | Sync all nodes to NTP; typical skew < 10ms |
| **Monotonic clocks** | Use relative timestamps within a span |
| **Don't rely on span order** | Trace ID + parent_id define structure; timestamps for display only |
| **Clock skew metric** | Monitor time drift; alert if high |

---

## 5. Monitoring the Monitoring System

**Scenario:** Prometheus down; no one knows. Elasticsearch full; logs stop.

| Approach | Description |
|----------|-------------|
| **Meta-monitoring** | Monitor Prometheus, Grafana, ES with separate stack or self |
| **Health checks** | Alert if Prometheus scrape fails, ES cluster red |
| **External checks** | UptimeRobot, Pingdom for "is anyone getting data?" |
| **Runbooks** | Document recovery for monitoring failures |

```
META-MONITORING:
  Prometheus → alert if scrape_targets_down > 0
  Elasticsearch → alert if cluster_health != green
  Grafana → alert if datasource down
```

---

## 6. Alert Storms During Outages

**Scenario:** DB fails; 50 services alert (cascading failures). PagerDuty explodes.

| Mitigation | Description |
|------------|-------------|
| **Alert aggregation** | Group by incident; one page per root cause |
| **Dependency mapping** | Know DB is upstream; suppress downstream alerts |
| **On-call runbooks** | "DB down → check DB first; ignore dependent alerts" |
| **Severity tiers** | P0 = page; P1 = Slack; P2 = ticket |

---

## 7. Log Data Privacy (PII in Logs)

**Scenario:** Logs contain passwords, SSN, credit cards. GDPR/PCI violation.

| Mitigation | Description |
|------------|-------------|
| **Never log secrets** | Redact passwords, tokens, API keys |
| **Structured + redaction** | Pipeline redacts PII before storage |
| **Field allowlist** | Only allow specific fields in logs |
| **Access control** | Restrict log access; audit who views |

```
REDACTION RULES:
  - Replace: password=***, ssn=***, card=****1234
  - Drop: full request bodies in prod
  - Hash: user_id for analytics (if needed)
```

---

## 8. Cross-Region / Multi-Cluster Monitoring

**Scenario:** Services in 3 regions; how to get global view?

| Approach | Description |
|----------|-------------|
| **Federation** | Prometheus in each region; central Prometheus scrapes federated targets |
| **Thanos / Mimir** | Global view with long-term retention |
| **Vendor (Datadog, etc.)** | Agent in each region; centralized UI |
| **Trace sampling** | May need to sample more aggressively across regions (cost) |

---

## 9. Cold Start / Serverless Monitoring

**Scenario:** Lambda/Cloud Functions; short-lived; no persistent agent.

| Approach | Description |
|----------|-------------|
| **Logs** | Cloud provider logs (CloudWatch, etc.); forward to central |
| **Metrics** | Custom metrics via SDK; or X-Ray for traces |
| **Traces** | AWS X-Ray, OpenTelemetry with serverless adapter |
| **Duration** | Monitor cold start latency separately from warm |

---

## 30-SECOND REVISION BOX

```
EDGE CASES: log explosion, metric storage, trace sampling,
            clock skew, meta-monitoring, alert storms, PII,
            cross-region, serverless
FIXES: sampling, sharding, tail-based, NTP, meta-monitoring,
       aggregation, PII redaction, federation, X-Ray
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
