# Neo Kim - 21 System Design Case Studies

> Based on Neo Kim's "System Design One" newsletter (0.5M+ audience)
> Rewritten in easy language for quick interview revision

---

## 6-Week Study Roadmap

### Week 1-2: Infrastructure & Core Tech


| #   | Topic                   | Quick Notes | In-Depth (Easy Language) | Difficulty |
| --- | ----------------------- | ----------- | ------------------------ | ---------- |
| 01  | How Kafka Works         | [Quick Notes](01-How-Kafka-Works.md) | [In-Depth](01-How-Kafka-Works-In-Depth.md) | Medium |
| 02  | How Amazon S3 Works     | [Quick Notes](02-How-Amazon-S3-Works.md) | [In-Depth](02-How-Amazon-S3-Works-In-Depth.md) | Medium |
| 03  | How Amazon Lambda Works | [Quick Notes](03-How-Amazon-Lambda-Works.md) | [In-Depth](03-How-Amazon-Lambda-Works-In-Depth.md) | Medium |
| 04  | How LLMs (ChatGPT) Work | [Quick Notes](04-How-LLMs-ChatGPT-Work.md) | [In-Depth](04-How-LLMs-ChatGPT-Work-In-Depth.md) | Hard |


### Week 2-3: Classic Interview Problems


| #   | Topic                    | Quick Notes | In-Depth (Easy Language) | Difficulty |
| --- | ------------------------ | ----------- | ------------------------ | ---------- |
| 05  | How URL Shortener Works  | [Quick Notes](05-How-URL-Shortener-Works.md) | [In-Depth](05-How-URL-Shortener-Works-In-Depth.md) | Easy |
| 06  | How Payment System Works | [Quick Notes](06-How-Payment-System-Works.md) | [In-Depth](06-How-Payment-System-Works-In-Depth.md) | Hard |
| 07  | How Stock Exchange Works | [Quick Notes](07-How-Stock-Exchange-Works.md) | [In-Depth](07-How-Stock-Exchange-Works-In-Depth.md) | Hard |


### Week 3-4: Real-time & Collaboration


| #   | Topic                 | Quick Notes | In-Depth (Easy Language) | Difficulty |
| --- | --------------------- | ----------- | ------------------------ | ---------- |
| 08  | How WhatsApp Works    | [Quick Notes](08-How-WhatsApp-Works.md) | [In-Depth](08-How-WhatsApp-Works-In-Depth.md) | Hard |
| 09  | How Slack Works       | [Quick Notes](09-How-Slack-Works.md) | [In-Depth](09-How-Slack-Works-In-Depth.md) | Medium |
| 10  | How Google Docs Works | [Quick Notes](10-How-Google-Docs-Works.md) | [In-Depth](10-How-Google-Docs-Works-In-Depth.md) | Hard |


### Week 4-5: Social Media & Content


| #   | Topic                      | Quick Notes | In-Depth (Easy Language) | Difficulty |
| --- | -------------------------- | ----------- | ------------------------ | ---------- |
| 11  | How YouTube Works          | [Quick Notes](11-How-YouTube-Works.md) | [In-Depth](11-How-YouTube-Works-In-Depth.md) | Hard |
| 12  | How Spotify Works          | [Quick Notes](12-How-Spotify-Works.md) | [In-Depth](12-How-Spotify-Works-In-Depth.md) | Medium |
| 13  | How Reddit Works           | [Quick Notes](13-How-Reddit-Works.md) | [In-Depth](13-How-Reddit-Works-In-Depth.md) | Medium |
| 14  | How Twitter Timeline Works | [Quick Notes](14-How-Twitter-Timeline-Works.md) | [In-Depth](14-How-Twitter-Timeline-Works-In-Depth.md) | Hard |
| 15  | How Bluesky Works          | [Quick Notes](15-How-Bluesky-Works.md) | [In-Depth](15-How-Bluesky-Works-In-Depth.md) | Medium |


### Week 5-6: Marketplace, Location & Search


| #   | Topic                         | Quick Notes | In-Depth (Easy Language) | Difficulty |
| --- | ----------------------------- | ----------- | ------------------------ | ---------- |
| 16  | How Airbnb Works              | [Quick Notes](16-How-Airbnb-Works.md) | [In-Depth](16-How-Airbnb-Works-In-Depth.md) | Hard |
| 17  | How Tinder Works              | [Quick Notes](17-How-Tinder-Works.md) | [In-Depth](17-How-Tinder-Works-In-Depth.md) | Medium |
| 18  | How Uber Finds Nearby Drivers | [Quick Notes](18-How-Uber-Finds-Nearby-Drivers.md) | [In-Depth](18-How-Uber-Finds-Nearby-Drivers-In-Depth.md) | Hard |
| 19  | How Uber Computes ETA         | [Quick Notes](19-How-Uber-Computes-ETA.md) | [In-Depth](19-How-Uber-Computes-ETA-In-Depth.md) | Hard |
| 20  | How AirTags Work              | [Quick Notes](20-How-AirTags-Work.md) | [In-Depth](20-How-AirTags-Work-In-Depth.md) | Medium |
| 21  | How Google Search Works       | [Quick Notes](21-How-Google-Search-Works.md) | [In-Depth](21-How-Google-Search-Works-In-Depth.md) | Hard |


---

## How to Use These Notes

1. **Read the Quick Notes first** (~15-20 min per topic) for a high-level overview
2. **Read the In-Depth page** when you want concepts explained in simple, easy language with real-world analogies
3. **Focus on the "Quick Revision" section** at the bottom of Quick Notes for last-minute prep
4. **Use the "Revision Flashcards"** at the bottom of In-Depth pages for self-testing
5. **Practice explaining** the High-Level Architecture out loud (as if in an interview)
6. **Cross-reference** related systems (e.g., WhatsApp + Slack both use WebSockets)
7. **Revisit the "Interview Tips"** section before your actual interview

## Key Concepts That Repeat Across Case Studies


| Concept                    | Appears In                                   |
| -------------------------- | -------------------------------------------- |
| Load Balancing             | Almost all                                   |
| Caching (Redis/Memcached)  | WhatsApp, YouTube, Twitter, Reddit           |
| Message Queues (Kafka)     | Kafka, Slack, WhatsApp, Stock Exchange       |
| CDN                        | YouTube, Spotify, Airbnb                     |
| WebSockets                 | WhatsApp, Slack, Google Docs, Stock Exchange |
| Database Sharding          | URL Shortener, Twitter, WhatsApp             |
| Consistent Hashing         | Kafka, S3, WhatsApp                          |
| Geo-indexing (H3/S2)       | Uber, Tinder, Airbnb, AirTags               |
| Event Sourcing             | Stock Exchange, Kafka                        |
| Adaptive Bitrate Streaming | YouTube, Spotify                             |
| Bloom Filters              | S3, URL Shortener, Google Search             |
| Pre-signed URLs            | YouTube, Spotify, WhatsApp                   |
| Idempotency Keys           | Payment System, Airbnb                       |
| Fan-out (Push/Pull)        | Twitter, Reddit, WhatsApp                    |
| Circuit Breaker            | Payment System, Spotify                      |


---

> All notes based on content from [newsletter.systemdesign.one](https://newsletter.systemdesign.one) by Neo Kim
