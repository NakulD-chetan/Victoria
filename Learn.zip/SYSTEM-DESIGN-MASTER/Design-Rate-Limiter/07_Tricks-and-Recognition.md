# Design Rate Limiter — Tricks and Recognition

> **Permanent Recall:** **Token bucket** = most common (Twitter, Stripe). **Sliding window counter** = best practical trade-off. **Redis** = standard for distributed. **Lua scripts** = atomicity. This is a **MUST-KNOW** — asked frequently at all FAANG companies.

---

## How to Recognize the Question

| Phrase | Likely asking for |
|--------|-------------------|
| "Design a rate limiter" | Full design: algorithms, distributed, Redis |
| "How do we limit API requests?" | Rate limiter; maybe throttling |
| "Prevent abuse of our API" | Rate limiter + possibly auth, CAPTCHA |
| "DDoS protection" | Rate limiter is one layer; also CDN, IP blacklist |
| "Fair usage / quota" | Rate limit (per window) or quota (total over period) |

---

## Algorithm Quick Picks

| Need | Algorithm |
|------|-----------|
| "Industry standard" | **Token bucket** |
| "Accurate, bounded memory" | **Sliding window counter** |
| "Simplest" | Fixed window (with boundary caveat) |
| "Exactly correct" | Sliding window log (accept O(n) memory) |
| "Smooth output, no bursts" | Leaky bucket |

> **FAANG Tip:** When in doubt, say **token bucket** or **sliding window counter**. Both are defensible and commonly used.

---

## Red Flags to Avoid

| Red flag | Better approach |
|----------|-----------------|
| "We'll use a HashMap in each server" | Shared store (Redis); in-memory doesn't work distributed |
| "Fixed window is fine" (no caveat) | Mention boundary spike; or pick sliding/token bucket |
| "We'll INCR then EXPIRE" | Use Lua script for atomic INCR+EXPIRE |
| "If Redis fails, we retry" | Decide: fail open vs fail closed |
| No Retry-After on 429 | Always include Retry-After |

---

## One-Liner Answers for Follow-ups

| Question | One-liner |
|----------|-----------|
| "Which algorithm?" | "Token bucket for burst allowance, or sliding window counter for accurate O(1) limits." |
| "Why Redis?" | "Sub-ms latency, INCR/sorted sets, Lua for atomicity; shared across all API nodes." |
| "What if Redis is down?" | "Fail open for availability or fail closed for security—product-dependent." |
| "How to avoid race conditions?" | "Lua scripts—all ops in one atomic script." |
| "Boundary spike?" | "Fixed window can allow 2× limit at window boundary; sliding window or token bucket avoids it." |

---

## Real-World Usage

| Company / Product | Approach |
|-------------------|----------|
| **Twitter API** | Token bucket per endpoint tier |
| **Stripe API** | Token bucket; X-RateLimit-* headers |
| **GitHub API** | Token bucket; 5000/hr for authenticated |
| **AWS API Gateway** | Token bucket or fixed window; configurable |
| **Kong / Nginx** | Plugins support fixed window, sliding window, Redis |

---

## Interview Flow Cheat Sheet

```
1. Clarify: identity (user/IP/key), per-endpoint?, scale
2. List 5 algorithms, recommend token bucket or sliding window counter
3. Draw: Client → Gateway → Rate Limiter → Redis
4. Redis: Lua for atomicity; key = ratelimit:{id}:{endpoint}:{window}
5. Fail open/closed when Redis down
6. 429 + Retry-After + X-RateLimit-* headers
7. Monitoring: 429 rate, Redis latency
```

---

## Mermaid: Request Flow

```mermaid
flowchart LR
    R[Request] --> E[Extract Identity]
    E --> L[Lookup Rule]
    L --> C[Redis: Check/Increment]
    C --> A{Within Limit?}
    A -->|Yes| P[Pass 200]
    A -->|No| D[429 Retry-After]
```

---

## Related Topics to Mention

| Topic | Connection |
|-------|------------|
| API Gateway | Rate limiter often lives in gateway (Kong, AWS API GW) |
| Throttling | Similar: limit rate; throttling may queue, rate limiting rejects |
| Circuit breaker | When Redis is down; avoid cascading failure |
| DDoS | Rate limiting is one layer; also CDN, IP reputation |

---

## Memorize These

| Item | Value |
|------|-------|
| Response code when limited | 429 Too Many Requests |
| Retry header | Retry-After |
| Shared store | Redis |
| Atomicity | Lua scripts |
| Latency budget | <5ms overhead |
| Fail modes | Open (allow) / Closed (reject) |
| Best algorithms | Token bucket, Sliding window counter |
