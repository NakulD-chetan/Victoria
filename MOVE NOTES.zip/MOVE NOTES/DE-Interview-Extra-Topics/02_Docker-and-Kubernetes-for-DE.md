# 02 — Docker & Kubernetes for Data Engineering

> **One-line:** Docker **packages** your pipeline code + dependencies into portable containers; Kubernetes **orchestrates** those containers at scale with auto-healing, scaling, and scheduling.

---

## 1. Why Docker Matters for DE

| Problem Without Docker | Docker Solution |
|----------------------|-----------------|
| "Works on my machine" — different Python/Java versions | Container bundles **exact** runtime |
| Installing Spark/Airflow dependencies is painful | Pre-built image with everything included |
| Dev environment ≠ production | **Same image** runs everywhere |
| Testing pipeline changes is risky | Spin up **isolated** container, test, destroy |

---

## 2. Docker Core Concepts

| Concept | What It Is | DE Example |
|---------|-----------|------------|
| **Image** | Blueprint/template (read-only layers) | `python:3.11-slim` + your ETL script |
| **Container** | Running instance of an image | Your Spark job executing |
| **Dockerfile** | Recipe to build an image | Install deps → copy code → set entrypoint |
| **Registry** | Image storage (DockerHub, ECR, GCR) | Push/pull pipeline images |
| **Volume** | Persistent storage mounted into container | Store output data that survives container restart |
| **Network** | Container-to-container communication | Spark worker ↔ driver communication |

### Sample Dockerfile for a DE Pipeline

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY pipeline/ ./pipeline/
COPY config/ ./config/

ENTRYPOINT ["python", "pipeline/main.py"]
```

### Docker Compose — Multi-Container Setup

```yaml
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: warehouse
  
  airflow:
    image: apache/airflow:2.8
    depends_on:
      - postgres
  
  spark-master:
    image: bitnami/spark:3.5
    ports:
      - "8080:8080"
```

**Interview tip:** "Docker Compose is great for **local dev** — spin up Postgres + Airflow + Spark with one `docker compose up`."

---

## 3. Kubernetes (K8s) Core Concepts

| Concept | What It Is | DE Example |
|---------|-----------|------------|
| **Pod** | Smallest deployable unit (1+ containers) | Single Spark executor pod |
| **Node** | Physical/virtual machine running pods | EC2 instance in EKS cluster |
| **Deployment** | Manages pod replicas + rollouts | Airflow webserver with 2 replicas |
| **Service** | Stable network endpoint for pods | Load-balanced access to Airflow UI |
| **Namespace** | Logical isolation within cluster | `dev` vs `prod` pipelines |
| **ConfigMap** | External config (non-secret) | Pipeline parameters, file paths |
| **Secret** | Encrypted sensitive data | DB passwords, API keys |
| **Job** | Run-to-completion workload | One-time backfill ETL job |
| **CronJob** | Scheduled Job | Nightly data pipeline |
| **PVC (PersistentVolumeClaim)** | Persistent storage request | Store checkpoint data for Spark Streaming |

### K8s Architecture (Simplified)

```
┌─────────────────── K8s Cluster ───────────────────┐
│                                                    │
│  ┌── Control Plane ──┐                             │
│  │  API Server       │                             │
│  │  Scheduler        │                             │
│  │  etcd (state)     │                             │
│  └───────────────────┘                             │
│                                                    │
│  ┌── Node 1 ──────┐    ┌── Node 2 ──────┐         │
│  │ Pod: Airflow    │    │ Pod: Spark     │         │
│  │ Pod: Scheduler  │    │  Executor 1    │         │
│  └────────────────┘    │ Pod: Spark     │         │
│                         │  Executor 2    │         │
│                         └────────────────┘         │
└────────────────────────────────────────────────────┘
```

---

## 4. K8s for Specific DE Tools

| Tool | K8s Integration |
|------|----------------|
| **Airflow** | KubernetesExecutor — each task = separate pod → **resource isolation** |
| **Spark** | Spark on K8s — driver + executor pods → replaces YARN |
| **Kafka** | Strimzi operator — manages Kafka brokers as K8s resources |
| **Flink** | Flink K8s operator — manages JobManager + TaskManager pods |
| **Debezium** | Kafka Connect on K8s with Debezium connector pods |
| **dbt** | dbt jobs in CronJob pods or triggered by Airflow KubernetesPodOperator |

### Airflow KubernetesExecutor — Why It's Asked

```
Airflow Scheduler
    │
    ├── Task A → launches Pod A (Python image, 2GB RAM)
    ├── Task B → launches Pod B (Spark image, 8GB RAM)
    └── Task C → launches Pod C (dbt image, 1GB RAM)
    
Each task gets its own isolated pod with specific resources.
Pod dies after task completes → clean, no resource leak.
```

**Interview line:** "KubernetesExecutor gives **per-task resource isolation** — a Spark task gets 8GB while a simple Python task gets 1GB, and both clean up after themselves."

---

## 5. Docker vs Kubernetes — When to Use

| Scenario | Use |
|----------|-----|
| **Local development** | Docker / Docker Compose |
| **Small team, few pipelines** | Docker Compose on a VM |
| **Production at scale** | Kubernetes (EKS / GKE / AKS) |
| **Auto-scaling pipelines** | Kubernetes HPA (Horizontal Pod Autoscaler) |
| **Multi-tenant data platform** | Kubernetes namespaces + RBAC |

---

## 6. Key Docker Commands (Interview Quick Reference)

| Command | Purpose |
|---------|---------|
| `docker build -t my-pipeline .` | Build image from Dockerfile |
| `docker run my-pipeline` | Run container from image |
| `docker ps` | List running containers |
| `docker logs <container>` | View container logs |
| `docker exec -it <container> bash` | Shell into running container |
| `docker compose up -d` | Start all services in background |
| `docker push registry/image:tag` | Push image to registry |

---

## 7. Key kubectl Commands (Interview Quick Reference)

| Command | Purpose |
|---------|---------|
| `kubectl get pods` | List all pods |
| `kubectl describe pod <name>` | Detailed pod info + events |
| `kubectl logs <pod>` | View pod logs |
| `kubectl apply -f job.yaml` | Create/update resources from YAML |
| `kubectl get jobs` | List batch jobs |
| `kubectl top pods` | Resource usage |

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "Why Docker for data pipelines?" | Reproducibility, isolation, consistent dev-to-prod |
| "Docker vs VM?" | Docker: lightweight (shares OS kernel), fast startup. VM: full OS, heavier |
| "What is KubernetesExecutor in Airflow?" | Each task runs in its own pod — resource isolation, auto-cleanup |
| "How does Spark run on K8s?" | Driver pod → requests executor pods → K8s schedules them on nodes |
| "How do you handle secrets in K8s?" | K8s Secrets, HashiCorp Vault, AWS Secrets Manager mounted as env vars |
| "What is a sidecar container?" | Helper container in same pod — e.g., log forwarder next to your ETL container |
| "How do you debug a failing K8s pod?" | `kubectl describe pod` → events, `kubectl logs` → app logs, check resource limits |

---

## Key Takeaways

- **Docker** = package your pipeline as a portable, reproducible unit. Essential for modern DE.
- **Kubernetes** = orchestrate containers at scale with auto-healing, scheduling, and resource management.
- **KubernetesExecutor** in Airflow and **Spark on K8s** are the most asked DE-specific K8s topics.
- Know `docker build/run/compose` and `kubectl get/describe/logs` commands for interviews.
- K8s replaces YARN for modern Spark deployments — understand the trade-offs.

---
