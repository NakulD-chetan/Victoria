# Scalability — Design Template

> **Permanent Recall:** Six reusable patterns: horizontal scaling (LB + stateless), DB read scaling (primary + replicas), write scaling (sharding), caching layer, CDN, async processing (queues). Apply these in sequence when scaling any system. Each has a clear "when to use" trigger.

---

## 1. Horizontal Scaling (LB + Stateless Servers)

### Architecture Diagram

```
                    ┌────────────────────────────────────┐
                    │        Load Balancer (LB)            │
                    │  Health checks, round-robin/least conn │
                    └────────────────┬───────────────────┘
                                     │
        ┌────────────────────────────┼────────────────────────────┐
        │                            │                            │
        ▼                            ▼                            ▼
┌───────────────┐          ┌───────────────┐          ┌───────────────┐
│  App Server 1  │          │  App Server 2  │          │  App Server N  │
│  (stateless)   │          │  (stateless)   │          │  (stateless)   │
│  No session   │          │  No session   │          │  No session   │
└───────┬───────┘          └───────┬───────┘          └───────┬───────┘
        │                          │                          │
        └──────────────────────────┴──────────────────────────┘
                                     │
                        Shared: Redis, DB, Kafka
```

### When to Use

| Trigger | Action |
|---------|--------|
| Single server CPU/RAM saturated | Add more app servers behind LB |
| Need zero-downtime deployments | Stateless allows rolling restarts |
| Traffic spikes (Black Friday) | Auto-scale instances based on RPS/CPU |
| Any service that can be stateless | Session in Redis/JWT; scale freely |

### Implementation Notes

- **Stateless:** Store session in Redis or encode in JWT. No sticky sessions.
- **LB algorithm:** Round-robin for equal cost; least-connections for variable request duration.
- **Health checks:** LB removes unhealthy instances; graceful shutdown drains connections.
- **Capacity:** ~1K–5K RPS per server (simple API); scale when total RPS exceeds capacity.

---

## 2. Database Read Scaling (Primary + Read Replicas)

### Architecture Diagram

```
                    ┌──────────────────┐
                    │   App Servers     │
                    └────────┬─────────┘
                             │
           ┌─────────────────┼─────────────────┐
           │                 │                 │
           ▼                 ▼                 ▼
    ┌──────────┐     ┌──────────┐     ┌──────────┐
    │ Replica 1 │     │ Replica 2 │     │ Replica N │
    │ (reads)   │     │ (reads)   │     │ (reads)   │
    └────┬─────┘     └────┬─────┘     └────┬─────┘
         │                │                │
         └────────────────┴────────────────┘
                          │ async replication
                    ┌─────▼─────┐
                    │  Primary   │
                    │  (writes)  │
                    └───────────┘
```

### When to Use

| Trigger | Action |
|---------|--------|
| Read-heavy workload (10:1 or higher read:write) | Add read replicas |
| DB CPU saturated on reads | Route reads to replicas |
| Single DB can't serve read QPS | Replicas share read load |
| Geographically distributed users | Read replicas in each region |

### Implementation Notes

- **Replication lag:** 100ms–1s typical; eventual consistency. Don't read-after-write from replica.
- **Read-after-write:** Route that request to primary, or accept staleness for feed/timeline.
- **Connection routing:** App config: `read_conn` → replicas, `write_conn` → primary.
- **Capacity:** Each replica ~same as primary; 500K read QPS → ~100 replicas (5K each).

---

## 3. Write Scaling (Sharding)

### Architecture Diagram

```
                    ┌──────────────────┐
                    │   App Servers     │
                    └────────┬─────────┘
                             │
        Shard key = user_id % N (or hash)
                             │
     ┌──────────────────────┼──────────────────────┐
     │                      │                      │
     ▼                      ▼                      ▼
┌─────────┐           ┌─────────┐           ┌─────────┐
│ Shard 0 │           │ Shard 1 │           │ Shard N │
│ user 0,3,6..       │ user 1,4,7..       │ user 2,5,8..
└─────────┘           └─────────┘           └─────────┘
```

### When to Use

| Trigger | Action |
|---------|--------|
| Primary DB write saturation | Shard by partition key |
| Data volume exceeds single DB (e.g., >1 TB) | Partition data across shards |
| Write QPS > single primary capacity | Distribute writes |
| Not before: Exhaust replicas + cache first | Sharding adds complexity |

### Implementation Notes

- **Shard key choice:** Pick key that minimizes cross-shard queries (e.g., `user_id` for user data).
- **Cross-shard queries:** Avoid or denormalize; scatter-gather expensive.
- **Rebalancing:** Add shards → rehash → migrate; use consistent hashing to minimize reshuffling.
- **Hot shards:** If one key (e.g., celebrity) dominates, split key further or use composite key.

---

## 4. Caching Layer

### Architecture Diagram

```
    Client ──► LB ──► App ──► Redis (cache)
                   │      │
                   │      └── HIT ──► return
                   │
                   └── MISS ──► DB ──► populate cache ──► return
```

### When to Use

| Trigger | Action |
|---------|--------|
| DB overloaded by repeated reads | Add cache (Redis) in front of DB |
| Same data read many times | Cache-aside: check cache first |
| Read:write >> 10:1 | Cache absorbs read load |
| Expensive computation repeated | Cache result (e.g., feed merge) |

### Implementation Notes

- **Cache-aside:** App checks cache → miss → DB → populate cache. App owns logic.
- **TTL:** Set expiry to prevent stale data indefinitely; invalidate on write for critical data.
- **Eviction:** LRU default; size cache for working set (e.g., 80% traffic from 20% data).
- **Capacity:** Redis ~100K ops/sec per node; 90% hit rate can cut DB load 10×.

---

## 5. CDN (Content Delivery Network)

### Architecture Diagram

```
    Users (global)
         │
         │  Request: GET /video.mp4
         ▼
    ┌─────────┐  Edge miss   ┌─────────┐
    │  Edge 1 │ ──────────► │ Origin  │
    │ (NYC)   │ ◄────────── │ (S3)    │
    └────┬────┘   content   └─────────┘
         │
         │  Edge hit → serve from edge (1–5ms)
         ▼
    User (NYC) gets fast response
```

### When to Use

| Trigger | Action |
|---------|--------|
| Static assets (images, video, JS, CSS) | Serve from CDN |
| Global users; origin in single region | CDN edges reduce latency |
| Origin overloaded by asset requests | Offload to CDN |
| Large file delivery (video streaming) | CDN for bandwidth and latency |

### Implementation Notes

- **Cache at edge:** Origin uploads to S3; CDN (CloudFront, Cloudflare) caches at PoPs.
- **Invalidation:** Purge by path or full flush when content changes.
- **Static only:** Don't CDN dynamic API responses (unless edge compute).
- **Cost:** Origin egress reduced; CDN egress usually cheaper; pay per GB delivered.

---

## 6. Async Processing (Message Queues)

### Architecture Diagram

```
    Sync path (fast)                    Async path (heavy work)
    ───────────────                    ─────────────────────

    Client ──► API ──► DB (minimal) ──► 202 Accepted
                   │
                   │  Publish event
                   ▼
              ┌─────────┐
              │  Kafka  │  or SQS, RabbitMQ
              │  Queue  │
              └────┬────┘
                   │
         ┌─────────┼─────────┐
         ▼         ▼         ▼
    Worker 1   Worker 2   Worker N
    (process)  (process)  (process)
```

### When to Use

| Trigger | Action |
|---------|--------|
| Request does heavy work (email, image resize) | Offload to queue; return 202 |
| One component slow; blocks others | Decouple via queue; backpressure |
| Batch processing (analytics, reports) | Queue + workers; scale workers |
| Event-driven flows (notify, fan-out) | Publish to topic; subscribers consume |

### Implementation Notes

- **Sync vs async:** Sync = user waits; async = enqueue, process later, notify when done.
- **Ordering:** Kafka partitions preserve order per key; SQS FIFO for strict order.
- **Retries:** Dead-letter queue for failed messages; idempotent consumers.
- **Throughput:** Kafka ~100K msg/sec per partition; scale partitions for parallelism.

---

## Pattern Selection Decision Tree

```mermaid
flowchart TD
    A[Need to scale?] --> B{What's bottleneck?}
    B -->|App servers| C[Horizontal scaling: LB + stateless]
    B -->|DB reads| D{Cache help?}
    D -->|Yes| E[Caching layer first]
    D -->|No / still overloaded| F[Read replicas]
    B -->|DB writes| G[Sharding]
    B -->|Static assets / media| H[CDN]
    B -->|Heavy sync work| I[Async: Message queue]
```

---

## Quick Reference Table

| Pattern | When | Key Component | Trade-off |
|---------|------|---------------|-----------|
| **Horizontal scaling** | App tier bottleneck | LB + stateless servers | Requires stateless design |
| **Read replicas** | Read-heavy DB | Primary + replicas | Replication lag |
| **Sharding** | Write-heavy / data volume | Partition by key | Cross-shard complexity |
| **Caching** | Repeated reads | Redis / Memcached | Staleness, invalidation |
| **CDN** | Static assets, global users | Edge PoPs | Invalidation on update |
| **Async queue** | Heavy work, decoupling | Kafka / SQS | Eventually consistent |

> **FAANG Tip:** State the bottleneck first, then name the pattern. "Our reads are the bottleneck, so we add read replicas and a cache layer." Shows systematic thinking.

---

## 30-SECOND REVISION BOX

```
1. HORIZONTAL: LB + stateless servers; scale app tier
2. READ REPLICAS: Primary writes; replicas reads; replication lag
3. SHARDING: Partition by key; cross-shard = expensive
4. CACHE: Redis cache-aside; TTL + invalidation
5. CDN: Static assets at edge; reduce origin load
6. ASYNC: Queue + workers; 202 for heavy work
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
