# Design YouTube/Netflix — Concept

> **Permanent Recall:** A video streaming platform at billion-user scale has **two fundamentally different systems**: the **upload pipeline** (write path, slow, compute-heavy) and the **streaming pipeline** (read path, fast, CDN-heavy). Transcoding is the most expensive operation; adaptive bitrate (HLS/DASH) is mandatory for quality UX.

---

## Problem Statement

Design a **video streaming platform** (YouTube/Netflix-style) where:

- **Content creators** upload videos; the system processes and stores them
- **Viewers** stream videos with minimal buffering, across devices and network conditions
- Users can **search**, **discover**, **comment**, **like**, and subscribe to **channels**
- Scale: **2B+ users**, **500 hours of video uploaded per minute globally**

---

## Functional Requirements

| Feature | Description |
|---------|-------------|
| **Upload video** | Creators upload raw video; support large files (hours of content); resumable uploads |
| **Stream video** | Adaptive bitrate streaming (HLS/DASH); multiple resolutions (240p–4K); minimal startup latency |
| **Search** | Full-text search on title, description, tags; autocomplete; trending |
| **Recommendations** | Personalized "watch next," home feed, related videos |
| **Comments** | Nested comments; like/unlike; sort by relevance/time |
| **Likes / dislikes** | Thumbs up/down; view counts; engagement metrics |
| **Channels / subscriptions** | Creator channels; subscribe; notification on new uploads |

---

## Non-Functional Requirements

| NFR | Target |
|-----|--------|
| **Latency** | Video playback start < 200ms; no perceptible buffering |
| **Scale** | 2B+ MAU; 500 hours uploaded/min; 1B+ video views/day |
| **Consistency (metadata)** | Eventual consistency acceptable (views, likes, comments) |
| **Consistency (payments)** | Strong consistency (subscriptions, ad revenue, premium billing) |
| **Availability** | 99.9%+ for streaming; upload can tolerate brief outages with retry |

> **FAANG Tip:** Always distinguish metadata consistency (eventual OK) from payment consistency (strong required) — it drives DB and transaction design.

---

## Capacity Estimation

### Upload Throughput

- **500 hours/min** = 500 × 60 = **30,000 hours/day** of video uploaded
- Assumption: avg 30-min video → ~60,000 videos/day
- Assumption: avg 1080p, 5 Mbps bitrate → 30 min × 5 Mbps × 60 sec × 8 = ~11.25 GB per 30-min video
- **Storage per day (raw):** 30,000 hours × ~10 GB/hour (1080p) ≈ **300 TB/day** raw uploads

### Storage (Processed Video)

- **1 hour of 4K video** ≈ **20 GB** (compressed)
- **Multiple resolutions** (240p, 360p, 480p, 720p, 1080p, 4K) → **5× multiplier** on storage
- Per 1 hour upload: 20 GB × 5 ≈ **100 GB** (all resolutions)
- **Daily storage:** 30,000 hours × 100 GB ≈ **3 PB/day** for processed video

### Video Views

- **1B video views/day** → ~11.5K views/sec average
- Peak: 3× average → ~35K views/sec
- Each view = stream chunks from CDN (not origin)

### Bandwidth (Streaming)

- Assumption: avg 2 Mbps playback, avg view 5 min
- **Egress per view:** 2 Mbps × 5 min × 60 sec / 8 ≈ 75 MB
- **1B views/day:** 1B × 75 MB = **75 PB/day** egress
- **CDN handles 90%+** → origin sees ~7.5 PB/day; CDN absorbs rest

---

## Key Numbers to Memorize

| Metric | Value |
|--------|-------|
| MAU | 2B+ |
| Upload rate | 500 hours/min |
| Views/day | 1B+ |
| 1 hr 4K size | ~20 GB |
| Resolution multiplier | 5× (multiple qualities) |
| Storage/day (processed) | ~3 PB |
| Playback start target | < 200ms |
| CDN cache hit target | 90%+ |

---

## Consistency Requirements

| Data Type | Consistency | Reason |
|-----------|-------------|--------|
| Video metadata (title, description) | Eventual | No financial impact |
| Views, likes, comments | Eventual | Counts can drift briefly |
| Subscriptions | Eventually consistent read | Acceptable for feed |
| Ad revenue, premium billing | **Strong** | Money must be exact |
| Video availability | Strong | User must see video or clear error |

---

## Out of Scope (Clarify in Interview)

- **Live streaming** — different architecture (real-time transcoding, HLS low-latency)
- **Video calls / conferencing** — real-time, peer-to-peer
- **Exact recommendation algorithm** — high-level (collaborative + content-based)
- **DRM / licensing** — separate domain
- **Ads insertion** — can be mentioned but not deep-dive unless asked

---

## Assumptions (State in Interview)

- On-demand (VOD) video; live streaming is out of scope or separate
- Videos are long-form (minutes to hours); short-form (Shorts/TikTok) may need different treatment
- Transcoding produces multiple resolutions for adaptive bitrate
- CDN is global; users worldwide
- Metadata (title, tags, description) is relatively small; video blobs dominate storage

---

## Constraints

- **Compute:** Transcoding is CPU/GPU intensive — need distributed workers
- **Storage:** 3 PB/day is massive — object storage + lifecycle policies
- **Bandwidth:** 75 PB/day egress — CDN mandatory; origin cannot serve users directly
- **Latency:** Sub-200ms startup — CDN edge, chunk-based delivery

---

## Success Criteria

- Video upload completes (user sees "processing"); playback available within minutes
- Playback starts in < 200ms from user click
- Adaptive bitrate switches seamlessly based on network
- 99.9% availability for streaming
- Search returns results in < 100ms

---

## Summary

YouTube/Netflix design centers on **two pipelines**: (1) **Upload** — raw video → object store → transcoding (multi-resolution) → processed store → CDN push → metadata DB; (2) **Streaming** — client → CDN edge → origin on miss → adaptive bitrate selection. Capacity is dominated by storage (3 PB/day) and egress (75 PB/day); CDN absorbs most reads.
