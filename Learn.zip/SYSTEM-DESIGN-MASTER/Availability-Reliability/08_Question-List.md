# Availability and Reliability — Question List

> **Permanent Recall:** 10 MUST-DO questions cover availability definition, nines, SLA/SLO/SLI, redundancy types, failover, SPOF, RPO/RTO, chaos engineering, and HA design. Full list includes 25+ questions spanning HA design, failover, disaster recovery, SLA calculation, with difficulty and company tags.

---

## 10 MUST-DO Availability Questions

| # | Question | Concepts Tested | Difficulty |
|---|----------|-----------------|------------|
| 1 | What is availability vs reliability vs durability? | Definitions, differences | Easy |
| 2 | Explain the "nines" table. What's 99.9% downtime per year? | Nines, downtime calculation | Easy |
| 3 | What are SLA, SLO, and SLI? How do they relate? | SLI→SLO→SLA | Medium |
| 4 | Design a highly available web service. | Multi-AZ, LB, redundancy | Medium |
| 5 | Compare active-active, active-passive, N+1, and 2N. | Redundancy types | Medium |
| 6 | Explain cold, warm, and hot failover. When to use each? | Failover strategies | Medium |
| 7 | How do you identify and eliminate single points of failure? | SPOF, redundancy | Medium |
| 8 | What are RPO and RTO? How do they affect DR design? | Disaster recovery | Medium |
| 9 | How does Netflix Chaos Monkey work? Why chaos engineering? | Chaos engineering | Medium |
| 10 | Design a payment system with 99.99% availability. | HA at scale, critical path | Hard |

---

## Complete Question List (25+)

### Fundamentals

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 1 | What is availability? How is it measured? | Easy | Definition, formula |
| 2 | Availability vs reliability vs durability? | Easy | Table, examples |
| 3 | Explain the nines: 99%, 99.9%, 99.99%, 99.999% | Easy | Downtime per year |
| 4 | What are SLA, SLO, and SLI? | Medium | Definitions, relationship |
| 5 | How do you calculate composite availability (series vs parallel)? | Medium | Formulas, example |

### Redundancy & Failover

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 6 | Active-active vs active-passive? | Medium | Use cases, trade-offs |
| 7 | What is N+1 redundancy? 2N? | Easy | Definitions |
| 8 | Cold vs warm vs hot failover? | Medium | Table, when to use |
| 9 | How do you achieve zero-downtime deployment? | Medium | Rolling, blue-green, canary |
| 10 | What is circuit breaker? How does it prevent cascading failure? | Medium | Pattern, benefits |

### SPOF & Architecture

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 11 | How do you identify SPOFs? | Medium | Trace path, checklist |
| 12 | Design a highly available API. | Medium | Multi-AZ, LB, replicas |
| 13 | The load balancer is a SPOF. How do you fix it? | Medium | Active-passive, cloud LB |
| 14 | Design for 99.99% availability. What do you need? | Hard | Multi-region, hot standby |
| 15 | How does multi-AZ differ from multi-region? | Medium | Scope, use cases |

### Disaster Recovery

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 16 | What are RPO and RTO? | Easy | Definitions |
| 17 | How does RPO affect your backup strategy? | Medium | Backup frequency |
| 18 | Design a disaster recovery plan. | Medium | RPO/RTO, runbook |
| 19 | What happens during a region outage? | Hard | Failover, DNS, data |
| 20 | Async vs sync replication for DR? | Medium | Trade-offs |

### Chaos & Testing

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 21 | What is chaos engineering? | Easy | Definition |
| 22 | How does Chaos Monkey work? | Medium | Random termination |
| 23 | How do you test failover? | Medium | Chaos, game days |
| 24 | What is a "game day"? | Easy | DR drill |
| 25 | How do you simulate AZ failure? | Medium | Chaos Kong, tools |

### Design Integration

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 26 | Design a payment system with 99.99% availability | Hard | Multi-region, sync |
| 27 | Design URL shortener with HA | Medium | Stateless, multi-AZ |
| 28 | Design chat with HA | Medium | Sticky, session store |
| 29 | How does availability trade off with consistency? | Hard | CAP, sync writes |
| 30 | Cost of each nine level? | Medium | Infra multiplier |

---

## Concepts Tested by Question Type

| Concept | Easy | Medium | Hard |
|---------|------|--------|------|
| **Definitions** | 1, 2, 3, 7, 16, 21, 24 | 4, 5 | |
| **Redundancy** | | 6, 8, 9, 10, 15 | |
| **SPOF** | | 11, 12, 13 | 14 |
| **DR** | | 17, 18, 20 | 19 |
| **Chaos** | | 22, 23, 25 | |
| **Design** | | 27, 28, 30 | 26, 29 |

---

## Suggested Practice Order

**Week 1: Fundamentals**
- Questions 1, 2, 3, 4, 5 (definitions, nines, SLA/SLO/SLI, formulas)

**Week 2: Redundancy & Failover**
- Questions 6, 7, 8, 9, 10 (redundancy types, failover, circuit breaker)

**Week 3: SPOF & Architecture**
- Questions 11, 12, 13, 14, 15 (SPOF, HA design, multi-AZ vs multi-region)

**Week 4: Disaster Recovery**
- Questions 16, 17, 18, 19, 20 (RPO/RTO, DR plan, replication)

**Week 5: Chaos & Design**
- Questions 21, 22, 23, 25, 26, 27, 28 (chaos, design integration)

---

## Company Tags (Typical Focus)

| Company | Likely Focus |
|---------|---------------|
| **Netflix** | Chaos engineering, resilience |
| **Amazon** | Multi-AZ, S3 durability, SLA |
| **Google** | SRE, SLO, error budget |
| **Meta** | Scale, multi-region |
| **Stripe** | Payment HA, 99.99% |

---

## Expected Answer Depth (Interview)

| Level | What to cover |
|-------|---------------|
| **Brief** | 1–2 sentences; e.g., "Availability is uptime percentage." |
| **Standard** | 3–5 sentences; include comparison or trade-off. |
| **Deep** | Full explanation; diagram; alternatives; edge cases. |

Use **Brief** for warm-up; **Standard** for main answer; **Deep** for follow-ups.

---

## Quick Memory Card

```
MUST-DO:        1–10 cover definitions, nines, SLA, redundancy, failover, SPOF, RPO/RTO, chaos
FUNDAMENTALS:   1–5
REDUNDANCY:     6–10
SPOF/ARCH:      11–15
DR:             16–20
CHAOS:          21–25
DESIGN:         26–30
ORDER:          Fundamentals → Redundancy → SPOF → DR → Chaos → Design
```

---

**Next:** [[01_Concept]] (cycle back to start)
