# Scalability — Mental Model

> **Permanent Recall:** Think of scaling like a highway — add lanes (horizontal) or make lanes wider (vertical). The bottleneck is the narrowest point; throughput = slowest component. Amdahl's Law limits parallel speedup. Design servers as disposable cattle, not pets. Use the scaling decision tree: quick fix? → scale up. Need resilience? → scale out. Read-heavy? → replicas. Write-heavy? → sharding.

---

## The Highway Analogy

**Horizontal scaling = adding lanes**

```
Before:  |===|  ← One lane, traffic backs up
After:   |===|===|===|===|  ← Four lanes, 4x throughput (ideally)
```

**Vertical scaling = wider lanes**

```
Before:  |===|  ← Narrow lane
After:  |======|  ← Wider lane, same road, more capacity per lane
```

**Bottleneck = the bridge**

```
Lanes:  |===|===|===|===|  →  [BRIDGE - 1 lane]  →  |===|===|
                              ↑
                    Throughput limited here
```

> **FAANG Tip:** "The system throughput is limited by its slowest component — like traffic at a one-lane bridge." This framing shows you think in terms of bottlenecks.

---

## How to Think About Bottlenecks

**The slowest component determines throughput.**

```
Request flow:
Client → LB → App Server → Cache → DB
              ↑              ↑      ↑
           Can add         Fast   Often
           more            (ms)   bottleneck
```

**Questions to ask:**
1. Where does the request spend the most time?
2. Which component has the lowest capacity (RPS, connections)?
3. Which component is hardest to replicate or scale?

---

## Amdahl's Law for Scaling

**Not all work parallelizes.** Some fraction `P` is parallelizable; `1-P` is serial.

```
Speedup = 1 / ((1 - P) + P/N)
  P = fraction that can run in parallel
  N = number of processors
```

| P (parallel %) | N=4 | N=10 | N=100 | Limit |
|----------------|-----|------|-------|-------|
| 95% | 3.5x | 6.9x | 16.8x | 20x max |
| 50% | 1.8x | 1.8x | 2.0x | 2x max |
| 10% | 1.1x | 1.1x | 1.1x | 1.1x max |

**Takeaway:** If 10% of work is serial, adding 100 cores gives ~1.1x, not 100x. Optimize the serial portion first.

---

## scaling Decision Tree (When to Scale Up vs Out)

```mermaid
flowchart TD
    A[Bottleneck identified?] --> B{Quick fix needed?}
    B -->|Yes, low traffic| C[Scale Up - add CPU/RAM]
    B -->|No| D{Need resilience/HA?}
    D -->|Yes| E[Scale Out - add servers]
    D -->|No| F{Read-heavy or Write-heavy?}
    F -->|Read-heavy| G[Read replicas + Cache]
    F -->|Write-heavy| H[Sharding + Async]
    
    E --> I[Stateless app servers]
    I --> J[Load Balancer]
    
    G --> K[Primary + Replicas]
    H --> L[Partition by key]
    
    style C fill:#ffe066
    style E fill:#69db7c
    style G fill:#74c0fc
    style H fill:#b197fc
```

**ASCII Fallback:**

```
                    [Bottleneck?]
                           |
              +------------+------------+
              |                         |
        Quick fix?                 Need HA?
              |                         |
         Yes → Scale Up            Yes → Scale Out
         (add CPU/RAM)             (add servers)
                                       |
                              Read or Write heavy?
                                       |
                          +------------+------------+
                          |                         |
                    Read-heavy                 Write-heavy
                          |                         |
                   Replicas + Cache           Sharding + Async
```

---

## Stateless Design Mental Model

**Servers as disposable cattle, not pets.**

| Pets | Cattle |
|------|--------|
| Named, unique, irreplaceable | Identical, interchangeable |
| State lives on server | State external (Redis, DB) |
| Failure = manual recovery | Failure = terminate, new one spins up |
| Hard to scale | Easy to scale |

```
PET:   Server-007 has user sessions in RAM → crash = lost sessions
CATTLE: Server-042 dies → LB stops routing; new instance gets traffic; sessions in Redis
```

**Design principle:** Any request can hit any server. No server-specific state.

---

## Read vs Write Scaling Mental Model

**Read scaling: replication**

```
         [Write] → Primary DB
                       |
              Replication (async)
                       |
              +--------+--------+
              |        |        |
           Replica  Replica  Replica  → Reads distributed
```

- Reads scale by adding replicas.
- Writes still hit primary (single write path).
- Replication lag = eventual consistency.

**Write scaling: partitioning**

```
User 1,4,7  →  Shard A
User 2,5,8  →  Shard B
User 3,6,9  →  Shard C
```

- Writes distributed across shards.
- Each shard handles a subset of data.
- Cross-shard queries are expensive; design to avoid them.

---

## Capacity Mental Model

**Order-of-magnitude thinking:**

```
1 server     →  1K RPS
10 servers   →  10K RPS  (linear, if stateless)
100 servers  →  ~80K RPS (diminishing: LB, DB become bottleneck)
```

**When you 10x traffic:**
- App tier: add ~10x servers (if stateless)
- DB: may need replicas or sharding
- Cache: likely need more memory or nodes
- Network: check bandwidth

---

## Quick Memory Card

```
HIGHWAY:     Lanes = horizontal; wider = vertical; bridge = bottleneck
BOTTLENECK:  Slowest component limits throughput
AMDahl:      Serial portion limits speedup; optimize serial first
SCALE UP:    Quick fix, low traffic
SCALE OUT:   Resilience, high traffic
CATTLE:      Stateless, disposable, any server any request
READ:        Replicas + cache
WRITE:       Sharding + partition by key
```

---

**Next: [[03_Design-Template]]**
