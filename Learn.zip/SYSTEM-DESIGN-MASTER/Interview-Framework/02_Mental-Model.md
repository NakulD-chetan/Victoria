# Interview Framework — Mental Model

> **Permanent Recall:** The system design interview is a **conversation**, not a test. YOU lead. The interviewer is your "new team member"—explain your design to them as you would onboard a colleague. Use the "funnel" model: start broad (requirements), narrow to architecture, then deep-dive into specifics. When faced with ambiguity: make reasonable assumptions, state them clearly, and ask for confirmation.

---

## Conversation, Not Test

### The Wrong Mental Model
- "They're grading me on every word"
- "I need to prove I know everything"
- "I should wait for them to tell me what to do"
- "One wrong answer = failure"

### The Right Mental Model
- "We're collaborating on a design problem"
- "I'm the one with the whiteboard; I drive the discussion"
- "They're observing how I think and communicate"
- "Mistakes are okay if I recover and adapt"

---

## The Interviewer as "New Team Member"

Imagine the interviewer just joined your team. You're walking them through a design doc. You would:

1. **Clarify the problem** before showing the solution
2. **Explain your reasoning** at each step
3. **Invite questions** ("Does this make sense? Any concerns?")
4. **Adapt** when they raise valid points
5. **Acknowledge gaps** ("I'm not 100% sure here, but my intuition is...")

This mindset reduces anxiety and improves communication.

---

## The Funnel Mental Model

```
                    BROAD (Requirements)
                         │
                         │  What are we building?
                         │  Who uses it? At what scale?
                         │  What matters most?
                         │
                         ▼
                    ┌─────────┐
                    │  SCOPE  │
                    └────┬────┘
                         │
                         ▼
                    NARROW (Architecture)
                         │
                         │  What components?
                         │  How does data flow?
                         │  APIs? Data model?
                         │
                         ▼
                    ┌─────────┐
                    │ DESIGN  │
                    └────┬────┘
                         │
                         ▼
                    DEEP (Specifics)
                         │
                         │  How does component X work?
                         │  What are the trade-offs?
                         │  What if it fails? 10x traffic?
                         │
                         ▼
                    ┌─────────┐
                    │ DETAIL  │
                    └─────────┘
```

**Rule:** Never go narrow before broad. Never go deep before narrow.

> **FAANG Tip:** Candidates who start with "Here's my architecture..." before clarifying requirements lose points immediately. The funnel is non-negotiable.

---

## You Lead the Discussion

| You Do | Interviewer Does |
|--------|------------------|
| Propose the structure (requirements first) | Observes, may nod or redirect |
| Ask clarifying questions | Provides or withholds info |
| Draw and explain diagrams | Probes with "What if?" questions |
| Pick what to deep-dive | May steer toward their interests |
| Wrap up with bottlenecks/monitoring | May add final questions |

You are the **driver**. They are the **navigator** who occasionally asks "What about this road?"

---

## Handling Ambiguity

### The Reality
Interview questions are **intentionally vague**. "Design Twitter" could mean feed, DMs, search, ads, or all of it. Ambiguity tests how you handle real-world messiness.

### The Strategy

1. **Make reasonable assumptions**
   - Don't freeze. Pick sensible defaults.

2. **State them explicitly**
   - "I'm assuming we're focusing on the feed and tweet creation, not DMs or ads. Does that work?"
   - "I'll assume 500M DAU and a 100:1 read:write ratio unless you tell me otherwise."

3. **Ask for confirmation**
   - "Should we prioritize latency or consistency for this use case?"
   - "Is international expansion in scope, or single-region for now?"

4. **Adjust if corrected**
   - "Got it—if DM is in scope, we'd add a message queue and WebSocket layer."

### Anti-Patterns
- **Asking 20 clarifying questions** before saying anything → Looks indecisive
- **Making assumptions silently** → Interviewer doesn't know your scope
- **Refusing to assume** → "I need more info" on everything → No progress

---

## The 2–3 Assumption Rule

For most questions, make **2–3 key assumptions** upfront, state them, and move on. More than that feels scattered; fewer means you're not scoping.

**Example (Design Twitter):**
- "I'll assume we're designing the feed and tweet creation, not DMs or ads."
- "I'll assume 500M DAU, 100:1 read:write, and we care about <200ms feed latency."
- "I'll assume single-region to start; we can discuss multi-region later."

---

## Mermaid: Interview Flow

```mermaid
flowchart TD
    A[Interviewer: Design X] --> B[You: Clarify requirements]
    B --> C{Assumptions OK?}
    C -->|Yes| D[You: High-level design]
    C -->|No| B
    D --> E[You: Draw components, API, data]
    E --> F[You: Pick 1–2 components to deep-dive]
    F --> G[You: Trade-offs, what-ifs]
    G --> H[You: Wrap-up: bottlenecks, monitoring]
    H --> I[Interviewer: Final probes]
```

---

## Summary

| Principle | Action |
|-----------|--------|
| **Conversation** | Talk through your thinking; invite input |
| **You lead** | Structure the interview; drive the whiteboard |
| **Funnel** | Broad → Narrow → Deep; never skip a level |
| **Ambiguity** | Assume 2–3 things, state them, confirm, adapt |
| **Team member** | Explain as if onboarding a colleague |
