# Subqueries and CTE — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is a Subquery?
**A:** A query nested inside another query. Can appear in SELECT, FROM, WHERE, HAVING. Returns a result that the outer query uses.

### Q: What is a Correlated Subquery?
**A:** A subquery that references columns from the outer query. Re-executed for each row of the outer query. Think of it as a nested loop — for each outer row, run the inner query.

### Q: EXISTS vs IN — when to use which?
**A:** EXISTS for correlated checks (short-circuits at first match, NULL-safe). IN for small value lists. For anti-joins: ALWAYS use `NOT EXISTS` instead of `NOT IN` (NOT IN breaks with NULLs in subquery).

### Q: What is a CTE?
**A:** Common Table Expression — a named temporary result set defined with `WITH` clause. Improves readability, can be referenced multiple times in the same query, supports recursion.

### Q: CTE vs Subquery — which is better?
**A:** Same performance usually (optimizer inlines CTE). CTE wins on readability, reusability within query, and recursive capability. Subquery is fine for simple one-time nesting.

### Q: CTE vs Temp Table?
**A:** CTE = query-scoped, not materialized (usually), no disk I/O. Temp table = session-scoped, physically stored in tempdb, good for large intermediate results accessed multiple times. Use temp table when CTE would be re-evaluated expensively.

### Q: CTE vs View?
**A:** CTE is temporary (exists only for one query). View is permanent (stored definition, reusable across queries). View doesn't store data; it's a saved query.

### Q: What is a Recursive CTE?
**A:** CTE that references itself. Has anchor (base case) + recursive member joined with UNION ALL. Used for hierarchical data — org charts, category trees, path traversal.

### Q: What is a Derived Table?
**A:** Subquery in the FROM clause — acts as an inline temporary table. Must have an alias. Useful to pre-filter or pre-aggregate before joining.

### Q: What is a Scalar Subquery?
**A:** Subquery that returns exactly one value (one row, one column). Can be used in SELECT list, WHERE with `=`, etc. Errors if it returns more than one row.

### Q: ANY vs ALL?
**A:** `> ANY(subquery)` = greater than at least one value (minimum). `> ALL(subquery)` = greater than every value (maximum). `= ANY` is same as `IN`.

### Q: Can a CTE be used in INSERT/UPDATE/DELETE?
**A:** Yes. `WITH cte AS (...) INSERT INTO ... SELECT * FROM cte;` Works in most modern DBs.

### Q: What happens if NOT IN subquery returns NULL?
**A:** The entire NOT IN evaluates to UNKNOWN for every row → empty result set. This is a classic trap. Always use NOT EXISTS instead.

---

## Strong answers

- "For **anti-join**, I prefer `NOT EXISTS` to avoid NULL pitfalls of `NOT IN`."
- "I use CTEs to **name each step** of a complex transformation — it reads like a pipeline."
- "Correlated subquery is conceptually a **nested loop** — I check if optimizer rewrites it as a join."

---

## Follow-up traps

- **"Is CTE always materialized?"** → No. Most engines inline it. PostgreSQL ≤11 materialized by default; 12+ inlines. SQL Server always inlines non-recursive CTEs.
- **"Can CTE reference another CTE?"** → Yes. Define in order: `WITH a AS (...), b AS (SELECT ... FROM a) SELECT ...`
- **"Subquery in SELECT vs JOIN?"** → Scalar subquery in SELECT = correlated, runs per row. JOIN is usually more efficient for multiple columns.

---

*Next: [[05_Common-Mistakes]]*
