/**
 * importer.js — Import markdown/text files, folders, or ZIP archives
 * into the notes tree. Works entirely in the browser.
 *
 * All three entry points return the same shape:
 *   { notebooksCreated, notesCreated, rootNotebookId, errors }
 */

import JSZip from 'jszip';

/* Extensions we recognise as note content. Everything else is skipped
 * (images/binaries are ignored to keep things simple — we could base64-
 * encode them as attachments later if needed). */
const TEXT_EXTS = new Set([
  'md', 'markdown', 'mdx',
  'txt', 'text',
  'json', 'yaml', 'yml', 'toml',
  'html', 'htm',
  'csv', 'tsv',
  'log',
]);

const MAX_FILE_BYTES = 5 * 1024 * 1024; // 5 MB per file safety cap
const IGNORED_DIRS = new Set(['node_modules', '.git', '.DS_Store', '__MACOSX', '.idea', '.vscode', 'dist', 'build']);

function extOf(name) {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

function baseName(path) {
  const last = path.replace(/\\/g, '/').split('/').pop() || path;
  const i = last.lastIndexOf('.');
  return i > 0 ? last.slice(0, i) : last;
}

function stripExt(name) {
  const i = name.lastIndexOf('.');
  return i > 0 ? name.slice(0, i) : name;
}

function isTextExt(ext) { return TEXT_EXTS.has(ext); }

function isIgnoredPath(relPath) {
  return relPath
    .split('/')
    .some((seg) => IGNORED_DIRS.has(seg));
}

function readAsText(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(fr.error || new Error('read failed'));
    fr.onload = () => resolve(String(fr.result ?? ''));
    fr.readAsText(file);
  });
}

/**
 * Ensure a chain of folders exists along `segments` starting at `parentId`.
 * Returns the id of the deepest folder. Uses a cache so we don't create
 * duplicates inside the same import session.
 */
function ensureFolderPath({ segments, parentId, cache, storeApi }) {
  let curParent = parentId;
  const pathKey = [];
  for (const seg of segments) {
    if (!seg) continue;
    pathKey.push(seg);
    const key = `${curParent ?? 'root'}::${pathKey.join('/')}`;
    let id = cache.get(key);
    if (!id) {
      id = storeApi.createNotebook(seg, curParent);
      cache.set(key, id);
    }
    curParent = id;
  }
  return curParent;
}

/**
 * Given a list of { path, content } entries, create the notebook tree
 * and notes. `path` uses forward-slash separators, relative to the import
 * root. `content` is the file's text.
 *
 * Options:
 *   storeApi        — { createNotebook, createNote }
 *   rootParentId    — notebook id to import under (null = top level)
 *   rootFolderName  — optional string. When given, an umbrella notebook
 *                     is created at `rootParentId` and everything lives
 *                     inside it. (Used for folder / zip imports.)
 */
function materialise(entries, { storeApi, rootParentId = null, rootFolderName = null }) {
  const errors = [];
  const cache = new Map();
  let notebooksCreated = 0;
  let notesCreated = 0;

  let importRootId = rootParentId;
  if (rootFolderName) {
    importRootId = storeApi.createNotebook(rootFolderName, rootParentId);
    notebooksCreated += 1;
    cache.set(`${rootParentId ?? 'root'}::${rootFolderName}`, importRootId);
  }

  for (const entry of entries) {
    try {
      const parts = entry.path.replace(/\\/g, '/').split('/').filter(Boolean);
      if (!parts.length) continue;
      const fileSeg = parts[parts.length - 1];
      const dirSegs = parts.slice(0, -1);

      const beforeFolderCount = cache.size;
      const parentId = ensureFolderPath({
        segments: dirSegs,
        parentId: importRootId,
        cache,
        storeApi,
      });
      notebooksCreated += cache.size - beforeFolderCount;

      const title = stripExt(fileSeg);
      storeApi.createNote(parentId, { title, body: entry.content });
      notesCreated += 1;
    } catch (e) {
      errors.push({ path: entry.path, message: e?.message || String(e) });
    }
  }

  return {
    notebooksCreated,
    notesCreated,
    rootNotebookId: importRootId,
    errors,
  };
}

/* ── Public API ─────────────────────────────────────────────────────── */

/**
 * Import a list of plain files picked via <input type="file" multiple>.
 * All imported notes go under `rootParentId` directly (no umbrella folder).
 */
export async function importFiles(fileList, { storeApi, rootParentId = null } = {}) {
  const entries = [];
  const errors = [];
  for (const f of fileList) {
    const ext = extOf(f.name);
    if (!isTextExt(ext)) {
      errors.push({ path: f.name, message: `Skipped: unsupported type (.${ext || 'unknown'})` });
      continue;
    }
    if (f.size > MAX_FILE_BYTES) {
      errors.push({ path: f.name, message: `Skipped: file exceeds ${MAX_FILE_BYTES / 1024 / 1024} MB limit` });
      continue;
    }
    try {
      const content = await readAsText(f);
      entries.push({ path: f.name, content });
    } catch (e) {
      errors.push({ path: f.name, message: e?.message || 'read failed' });
    }
  }
  const result = materialise(entries, { storeApi, rootParentId, rootFolderName: null });
  result.errors = [...errors, ...result.errors];
  return result;
}

/**
 * Import a folder picked via <input type="file" webkitdirectory>.
 * Each File has a `webkitRelativePath` we use to rebuild the tree.
 */
export async function importFolder(fileList, { storeApi, rootParentId = null } = {}) {
  const errors = [];
  const entries = [];
  let rootName = 'Imported Folder';
  for (const f of fileList) {
    const rel = f.webkitRelativePath || f.name;
    const topDir = rel.split('/')[0];
    if (topDir && topDir !== f.name) rootName = topDir;
    break;
  }

  for (const f of fileList) {
    const rel = (f.webkitRelativePath || f.name).replace(/\\/g, '/');
    if (isIgnoredPath(rel)) continue;
    const ext = extOf(f.name);
    if (!isTextExt(ext)) {
      errors.push({ path: rel, message: `Skipped: unsupported type (.${ext || 'unknown'})` });
      continue;
    }
    if (f.size > MAX_FILE_BYTES) {
      errors.push({ path: rel, message: `Skipped: file exceeds ${MAX_FILE_BYTES / 1024 / 1024} MB limit` });
      continue;
    }
    try {
      const content = await readAsText(f);
      /* Strip the top-level folder segment so materialise() doesn't
       * nest everything twice (we add it back via rootFolderName). */
      const segs = rel.split('/');
      const trimmed = segs.length > 1 ? segs.slice(1).join('/') : segs[0];
      entries.push({ path: trimmed, content });
    } catch (e) {
      errors.push({ path: rel, message: e?.message || 'read failed' });
    }
  }

  const result = materialise(entries, {
    storeApi,
    rootParentId,
    rootFolderName: rootName,
  });
  result.errors = [...errors, ...result.errors];
  return result;
}

/**
 * Import a .zip archive. Zips become an umbrella notebook named after
 * the zip file (minus .zip), with the archive structure recreated inside.
 */
export async function importZip(file, { storeApi, rootParentId = null } = {}) {
  const errors = [];
  const entries = [];
  const zipName = baseName(file.name) || 'Imported Zip';

  let zip;
  try {
    zip = await JSZip.loadAsync(file);
  } catch (e) {
    return {
      notebooksCreated: 0,
      notesCreated: 0,
      rootNotebookId: null,
      errors: [{ path: file.name, message: `Invalid zip: ${e?.message || e}` }],
    };
  }

  /* Detect a single top-level wrapper dir (e.g. `my-notes/...`) and peel
   * it off so the imported structure mirrors what users see in the zip
   * viewer. If there are multiple top-level dirs/files we keep them. */
  const topSegments = new Set();
  zip.forEach((relPath) => {
    const seg = relPath.replace(/\\/g, '/').split('/')[0];
    if (seg) topSegments.add(seg);
  });
  const singleRoot = topSegments.size === 1 ? [...topSegments][0] : null;

  const fileEntries = [];
  zip.forEach((relPath, entry) => {
    if (entry.dir) return;
    fileEntries.push({ relPath, entry });
  });

  for (const { relPath, entry } of fileEntries) {
    const normalized = relPath.replace(/\\/g, '/');
    if (isIgnoredPath(normalized)) continue;
    const ext = extOf(normalized);
    if (!isTextExt(ext)) {
      errors.push({ path: normalized, message: `Skipped: unsupported type (.${ext || 'unknown'})` });
      continue;
    }
    try {
      const content = await entry.async('string');
      if (content.length > MAX_FILE_BYTES) {
        errors.push({ path: normalized, message: `Skipped: exceeds ${MAX_FILE_BYTES / 1024 / 1024} MB` });
        continue;
      }
      let trimmed = normalized;
      if (singleRoot) {
        const segs = normalized.split('/');
        if (segs[0] === singleRoot) trimmed = segs.slice(1).join('/');
      }
      if (!trimmed) continue;
      entries.push({ path: trimmed, content });
    } catch (e) {
      errors.push({ path: normalized, message: e?.message || 'extract failed' });
    }
  }

  const rootFolderName = singleRoot || zipName;

  const result = materialise(entries, {
    storeApi,
    rootParentId,
    rootFolderName,
  });
  result.errors = [...errors, ...result.errors];
  return result;
}
