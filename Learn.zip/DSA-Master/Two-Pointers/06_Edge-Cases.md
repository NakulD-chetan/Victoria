# Two Pointers — Edge Cases

> **The difference between "Almost Hired" and "Hired" at FAANG is edge case handling.**

---

## Edge Case 1: Empty Input

```
arr = [], target = 5
```

- Two-pointer logic never executes
- Return empty result / -1 / false immediately

```python
if not arr or len(arr) < 2:
    return []
```

---

## Edge Case 2: Single Element

```
arr = [5], target = 10
```

- Can't form a pair with one element
- Linked list: single node has no cycle, is its own middle

---

## Edge Case 3: Two Elements

```
arr = [1, 9], target = 10  →  Valid pair
arr = [1, 9], target = 5   →  No pair
```

- Minimum input for pair-based two pointer
- Left and right start adjacent — one comparison, done

---

## Edge Case 4: All Duplicates

```
arr = [3, 3, 3, 3], target = 6
```

- 3Sum: must skip duplicates to avoid duplicate triplets
- Two Sum: multiple valid pairs, return first or all?
- **Critical:** Duplicate skipping logic is the #1 bug source

```python
# Skip duplicates in sorted two-pointer
while left < right and arr[left] == arr[left + 1]:
    left += 1
```

---

## Edge Case 5: Already Sorted vs Unsorted

- **Two-pointer on sorted array:** assumes sorted input
- If input isn't sorted, must sort first: O(n log n) overhead
- **Ask interviewer:** "Can I assume the array is sorted?"

---

## Edge Case 6: Negative Values

```
arr = [-4, -1, 0, 1, 2, 3], target = 0
```

- Two pointers work fine with negatives on sorted arrays
- 3Sum specifically designed for arrays with negatives
- Negative + positive = possible zero sum

---

## Edge Case 7: No Valid Answer Exists

```
arr = [1, 2, 3, 4], target = 100  →  No pair sums to 100
```

- Pointers converge without finding answer
- Return appropriate default: `[]`, `-1`, `false`

---

## Edge Case 8: Overflow with Large Values

```
arr = [INT_MAX/2, INT_MAX/2 + 1], target = INT_MAX
```

- `arr[left] + arr[right]` may overflow in C++
- **Fix (C++):** Use `long long` or check `target - arr[left] == arr[right]`
- **Rust:** Checked arithmetic with `.checked_add()`
- **Python:** No overflow (arbitrary precision)

---

## Edge Case 9: Linked List — No Cycle

```
1 → 2 → 3 → null
```

- Fast pointer reaches null → no cycle
- Must check `fast != null AND fast.next != null`

---

## Edge Case 10: Linked List — Cycle at Head

```
1 → 2 → 3 → (back to 1)
```

- Cycle starts at the very first node
- Floyd's algorithm still works: fast and slow meet, then reset one to head

---

## Edge Case 11: Palindrome — Empty and Single Char

```
s = ""   →  Palindrome (vacuously true)
s = "a"  →  Palindrome (single char)
s = "ab" →  Not palindrome
```

---

## Edge Case 12: Container with Water — All Same Height

```
heights = [5, 5, 5, 5, 5]
```

- Any pair works, widest gives max area
- Area = min(5,5) * (n-1) = 5*(n-1)

---

## Edge Case Checklist

| # | Case | Check | Impact |
|---|------|-------|--------|
| 1 | Empty array | `len < 2` | Return default |
| 2 | Single element | `len == 1` | Can't form pair |
| 3 | Two elements | Minimum valid | One comparison |
| 4 | All duplicates | Skip logic | Duplicate results |
| 5 | Unsorted input | Sort first | O(n log n) cost |
| 6 | Negatives | Works fine | Sum can be zero |
| 7 | No solution | Pointers converge | Return empty |
| 8 | Large values | Overflow | Use long long / checked |
| 9 | No cycle | Fast hits null | Return false |
| 10 | Cycle at head | Floyd's works | Reset to head |
| 11 | Empty string | Vacuous palindrome | Return true |
| 12 | All same height | Widest pair | Max area |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Two Pointers Edge Cases
ALWAYS CHECK:       Empty, single element, all duplicates, no solution
DUPLICATES:         Skip logic is #1 bug source in 3Sum
OVERFLOW:           C++ long long, Rust checked_add, Python safe
LINKED LIST:        Check fast AND fast.next before advancing
SORTED ASSUMPTION:  Always clarify with interviewer
INTERVIEW LINE:     "Let me handle edge cases: empty input,
                     single element, duplicates, and overflow."
```

---

## 30-SECOND REVISION BOX

```
EMPTY/SINGLE: return default early
DUPLICATES: while(arr[l]==arr[l+1]) skip
OVERFLOW: target - arr[l] == arr[r] instead of sum
CYCLE: check fast AND fast.next != null
SORTED: ask interviewer, sort if needed O(n log n)
```
