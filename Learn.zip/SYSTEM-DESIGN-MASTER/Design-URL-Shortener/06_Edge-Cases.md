# Design URL Shortener — Edge Cases

> **Permanent Recall:** Edge cases: hash collision (retry with salt), custom alias conflict (409), expired URL (404), hot key (single URL gets massive traffic—replicate cache, use local cache), DB failover during write (idempotency, retry), cache invalidation on update (delete key), malicious URLs (blocklist, redirect warning), concurrent key gen (atomic pop from KGS, DB unique constraint).

---

## 1. Hash Collision

**Scenario:** Two different long URLs hash to same short code.

| Approach | Handling |
|----------|----------|
| **Detect** | DB unique constraint on `short_url`; insert fails |
| **Retry** | Append random salt to URL, rehash, retry insert |
| **Alternative** | Use more chars (8 instead of 7) to reduce probability |
| **Best** | Use KGS or counter—no collision by design |

---

## 2. Custom Alias Conflicts

**Scenario:** User wants `short.io/mysite` but it's already taken.

| Handling |
|----------|
| Return **409 Conflict** with message "Alias already taken" |
| Suggest similar available alias (optional) |
| For hash-generated: user doesn't choose, so N/A |
| **Reserved aliases:** Blocklist (api, admin, login) → 400 Bad Request |

---

## 3. Expired URL Redirect

**Scenario:** User clicks short URL after `expires_at`.

| Handling |
|----------|
| Lookup returns row but `expires_at < now` |
| Return **404 Not Found** or redirect to "Link expired" landing page |
| **Cache:** Set TTL in Redis ≤ min(expires_at - now, 24h) |
| If cached past expiry: lazy invalidation on next hit (recheck DB) or shorter cache TTL |

> **FAANG Tip:** Don't serve stale redirect for expired URLs. Always validate expiry on DB read.

---

## 4. Hot Key (Extremely High Traffic on Single URL)

**Scenario:** Viral link gets 1M QPS to one short code.

| Problem | Solution |
|---------|----------|
| Single Redis key overloaded | Redis is single-threaded per key; can handle ~100K ops/sec per key—usually OK |
| If beyond Redis capacity | Replicate Redis (read replicas); or add **local in-memory cache** in API servers (e.g., 1-min TTL) for top N URLs |
| DB hot row | Cache should absorb; if not, consider caching at LB or CDN for top URLs |

```
    Top 10K URLs  →  Local cache in each API server (LRU, 1 min)
    Rest         →  Redis  →  DB
```

---

## 5. Database Failover During Writes

**Scenario:** Primary DB fails mid-insert; client retries.

| Handling |
|----------|
| **Idempotency:** Client sends `Idempotency-Key`; server deduplicates |
| Retry returns same response if key seen |
| **At-most-once vs at-least-once:** Prefer at-least-once with dedup |
| **Failover:** Promote replica; replay WAL; client retries; duplicate insert → unique constraint catches, return original |

---

## 6. Cache Invalidation on URL Update

**Scenario:** User updates long URL for same short code (if allowed).

| Handling |
|----------|
| On update: `DELETE` Redis key for `short_url` |
| Next redirect: cache miss → DB returns new `long_url` → repopulate cache |
| If no update feature: no invalidation needed |
| **Custom alias reuse:** Same—delete cache entry on change |

---

## 7. Malicious URLs

**Scenario:** Short URL points to phishing site, malware, or blocked domain.

| Handling |
|----------|
| **Blocklist:** Block known bad domains at shorten time; reject with 400 |
| **Redirect warning:** Interstitial page "You are leaving short.io. Continue?" (optional) |
| **User reports:** Flag and review; disable URL |
| **Crawlers:** Periodically check destination; auto-disable if domain blacklisted |

---

## 8. Concurrent Key Generation Race Conditions

**Scenario:** Two requests get same key from KGS or hash to same value.

| Approach | Handling |
|----------|----------|
| **KGS** | Atomic pop from pool (Redis LPOP, DB with locking); each key used once |
| **Hash** | DB `INSERT` with unique constraint; one wins, other gets constraint violation → retry with salt |
| **Counter** | Single counter service or DB sequence; atomic increment |
| **Custom alias** | Two users claim same alias: first wins; second gets 409 |

---

## Summary Table

| Edge Case | Detection | Resolution |
|-----------|-----------|------------|
| Hash collision | Unique constraint violation | Retry with salt or switch to KGS |
| Custom alias conflict | DB lookup before insert | 409 Conflict |
| Expired URL | Check `expires_at` on lookup | 404 or expired page |
| Hot key | Monitor per-key QPS | Local cache, Redis replicas |
| DB failover | Replication, health check | Idempotency, retry |
| Cache invalidation | Update/delete event | Delete Redis key |
| Malicious URL | Blocklist, reports | Reject or disable |
| Race on key | Unique constraint, atomic pop | Retry or 409 |

---

## 30-SECOND REVISION BOX

```
COLLISION: Retry with salt; KGS avoids
ALIAS: 409 if taken; blocklist reserved
EXPIRED: 404; check expires_at
HOT KEY: Local cache, Redis replica
FAILOVER: Idempotency, retry
INVALIDATE: Delete Redis on update
MALICIOUS: Blocklist, interstitial
RACE: Atomic pop, unique constraint
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
