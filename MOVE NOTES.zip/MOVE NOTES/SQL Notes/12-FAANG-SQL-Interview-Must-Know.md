# FAANG SQL Interview — Must Know Problems & Patterns

> **Yeh file interview ke TOP SQL problems aur patterns cover karti hai.**
> Har problem ke saath solution + explanation hai — practice karo aur interview crack karo!
> Topics: LeetCode style problems, common patterns, traps, SQL vs NoSQL.

---

## Top 25 SQL Interview Problems (with Solutions)

---

### 1. Second Highest Salary

> **Difficulty:** Easy | **Asked at:** Amazon, Google, Microsoft

```sql
-- Method 1: Subquery
SELECT MAX(salary) AS second_highest
FROM employees
WHERE salary < (SELECT MAX(salary) FROM employees);

-- Method 2: LIMIT OFFSET
SELECT DISTINCT salary
FROM employees
ORDER BY salary DESC
LIMIT 1 OFFSET 1;

-- Method 3: DENSE_RANK (most flexible — works for Nth)
SELECT salary FROM (
    SELECT salary, DENSE_RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employees
) t
WHERE rnk = 2;
```

---

### 2. Nth Highest Salary (Generic)

> **Difficulty:** Medium | **Asked at:** FAANG, all companies

```sql
-- Replace N with any number
WITH ranked AS (
    SELECT DISTINCT salary,
           DENSE_RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT salary FROM ranked WHERE rnk = N;
```

---

### 3. Duplicate Emails / Find Duplicates

> **Difficulty:** Easy | **Asked at:** Facebook, Amazon

```sql
SELECT email, COUNT(*) AS cnt
FROM users
GROUP BY email
HAVING COUNT(*) > 1;
```

---

### 4. Delete Duplicate Rows (Keep One)

> **Difficulty:** Medium | **Asked at:** Amazon, Microsoft

```sql
-- Keep the row with the SMALLEST id
DELETE FROM users
WHERE id NOT IN (
    SELECT MIN(id)
    FROM users
    GROUP BY email
);

-- OR using CTE + ROW_NUMBER (better approach)
WITH cte AS (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY email ORDER BY id) AS rn
    FROM users
)
DELETE FROM users WHERE id IN (SELECT id FROM cte WHERE rn > 1);
```

---

### 5. Employees Earning More Than Their Manager

> **Difficulty:** Easy | **Asked at:** FAANG classic

```sql
SELECT e.name AS employee
FROM employees e
JOIN employees m ON e.manager_id = m.id
WHERE e.salary > m.salary;
```

---

### 6. Department Highest Salary

> **Difficulty:** Medium | **Asked at:** Google, Amazon

```sql
-- Top 1 earner per department
WITH ranked AS (
    SELECT name, department, salary,
           RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT name, department, salary
FROM ranked
WHERE rnk = 1;
```

---

### 7. Top N Earners Per Department

> **Difficulty:** Medium-Hard | **Asked at:** FAANG

```sql
-- Top 3 per department
WITH ranked AS (
    SELECT name, department, salary,
           DENSE_RANK() OVER (PARTITION BY department ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT name, department, salary
FROM ranked
WHERE rnk <= 3;
```

---

### 8. Consecutive Days / Streak Problems

> **Difficulty:** Hard | **Asked at:** Google, Meta

```sql
-- Find users who logged in for 3+ consecutive days
WITH numbered AS (
    SELECT user_id, login_date,
           ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY login_date) AS rn
    FROM logins
),
grouped AS (
    SELECT user_id, login_date,
           DATE_SUB(login_date, INTERVAL rn DAY) AS grp
    FROM numbered
)
SELECT user_id, COUNT(*) AS streak_length, MIN(login_date), MAX(login_date)
FROM grouped
GROUP BY user_id, grp
HAVING COUNT(*) >= 3;
```

> **Pattern:** `login_date - ROW_NUMBER()` = same value for consecutive days. This is the **islands and gaps** technique!

---

### 9. Cumulative Sum / Running Total

> **Difficulty:** Easy-Medium | **Asked at:** Amazon, Flipkart

```sql
SELECT
    sale_date,
    amount,
    SUM(amount) OVER (ORDER BY sale_date) AS running_total
FROM sales;
```

---

### 10. Year-over-Year / Month-over-Month Growth

> **Difficulty:** Medium | **Asked at:** Google, Meta

```sql
WITH monthly AS (
    SELECT
        DATE_FORMAT(order_date, '%Y-%m') AS month,
        SUM(amount) AS revenue
    FROM orders
    GROUP BY DATE_FORMAT(order_date, '%Y-%m')
)
SELECT
    month,
    revenue,
    LAG(revenue) OVER (ORDER BY month) AS prev_month,
    ROUND((revenue - LAG(revenue) OVER (ORDER BY month)) * 100.0
          / NULLIF(LAG(revenue) OVER (ORDER BY month), 0), 2) AS growth_pct
FROM monthly;
```

---

### 11. Pivot Data (Rows to Columns)

> **Difficulty:** Medium | **Asked at:** Amazon, Microsoft

```sql
SELECT
    student_name,
    SUM(CASE WHEN subject = 'Math' THEN marks ELSE 0 END) AS Math,
    SUM(CASE WHEN subject = 'Science' THEN marks ELSE 0 END) AS Science,
    SUM(CASE WHEN subject = 'English' THEN marks ELSE 0 END) AS English
FROM scores
GROUP BY student_name;
```

---

### 12. Find Customers Who Never Ordered

> **Difficulty:** Easy | **Asked at:** Amazon classic

```sql
-- Method 1: LEFT JOIN + IS NULL
SELECT c.name
FROM customers c
LEFT JOIN orders o ON c.id = o.customer_id
WHERE o.id IS NULL;

-- Method 2: NOT EXISTS
SELECT name FROM customers c
WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.id);

-- Method 3: NOT IN
SELECT name FROM customers
WHERE id NOT IN (SELECT customer_id FROM orders WHERE customer_id IS NOT NULL);
```

---

### 13. Department with No Employees

```sql
SELECT d.dept_name
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
WHERE e.emp_id IS NULL;
```

---

### 14. Moving Average (Last N Rows)

> **Difficulty:** Medium | **Asked at:** Google

```sql
SELECT
    trade_date, price,
    AVG(price) OVER (
        ORDER BY trade_date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS moving_avg_7day
FROM stock_prices;
```

---

### 15. Find Median

> **Difficulty:** Hard | **Asked at:** Google, Meta

```sql
WITH ordered AS (
    SELECT salary,
           ROW_NUMBER() OVER (ORDER BY salary) AS rn,
           COUNT(*) OVER () AS total
    FROM employees
)
SELECT AVG(salary) AS median
FROM ordered
WHERE rn IN (FLOOR((total + 1) / 2.0), CEIL((total + 1) / 2.0));
```

---

### 16. Managers With At Least 5 Reports

```sql
SELECT m.name AS manager, COUNT(e.id) AS direct_reports
FROM employees e
JOIN employees m ON e.manager_id = m.id
GROUP BY m.id, m.name
HAVING COUNT(e.id) >= 5;
```

---

### 17. Exchange Seats (Swap Alternate Rows)

> **Difficulty:** Medium | **Asked at:** LeetCode famous

```sql
SELECT
    CASE
        WHEN id % 2 = 1 AND id = (SELECT MAX(id) FROM seat) THEN id
        WHEN id % 2 = 1 THEN id + 1
        ELSE id - 1
    END AS id,
    student
FROM seat
ORDER BY id;
```

---

### 18. Tree Node Types (Root, Inner, Leaf)

> **Difficulty:** Medium | **Asked at:** Meta

```sql
SELECT id,
    CASE
        WHEN parent_id IS NULL THEN 'Root'
        WHEN id IN (SELECT parent_id FROM tree) THEN 'Inner'
        ELSE 'Leaf'
    END AS node_type
FROM tree;
```

---

### 19. Consecutive Numbers (3+ times in a row)

> **Difficulty:** Medium | **Asked at:** LeetCode classic

```sql
-- Using LAG/LEAD
WITH temp AS (
    SELECT num,
           LAG(num) OVER (ORDER BY id) AS prev_num,
           LEAD(num) OVER (ORDER BY id) AS next_num
    FROM logs
)
SELECT DISTINCT num AS consecutive_num
FROM temp
WHERE num = prev_num AND num = next_num;
```

---

### 20. Rank Scores

```sql
SELECT score,
       DENSE_RANK() OVER (ORDER BY score DESC) AS rank
FROM scores;
```

---

### 21. Active Users (Logged in on multiple days)

```sql
SELECT user_id
FROM logins
GROUP BY user_id
HAVING COUNT(DISTINCT login_date) >= 5;
```

---

### 22. Difference Between Consecutive Rows

```sql
SELECT
    id, amount,
    amount - LAG(amount) OVER (ORDER BY id) AS diff_from_prev
FROM transactions;
```

---

### 23. Self Join — Find Pairs

```sql
-- Find pairs of employees in the same department
SELECT a.name, b.name, a.department
FROM employees a
JOIN employees b ON a.department = b.department AND a.id < b.id;
```

---

### 24. UNION to Combine Results

```sql
-- All unique cities from both employees and customers
SELECT city FROM employees
UNION
SELECT city FROM customers;

-- Keep duplicates
SELECT city FROM employees
UNION ALL
SELECT city FROM customers;
```

---

### 25. Recursive CTE — Org Chart

```sql
WITH RECURSIVE org AS (
    SELECT id, name, manager_id, 0 AS level
    FROM employees WHERE manager_id IS NULL

    UNION ALL

    SELECT e.id, e.name, e.manager_id, o.level + 1
    FROM employees e
    JOIN org o ON e.manager_id = o.id
)
SELECT * FROM org ORDER BY level, name;
```

---

## SQL Query Patterns — Cheatsheet

| Pattern | Technique | Use Case |
|---------|-----------|----------|
| **Top N per Group** | ROW_NUMBER + PARTITION BY | Top 3 earners per dept |
| **Running Total** | SUM() OVER (ORDER BY) | Cumulative sales |
| **Previous/Next Row** | LAG / LEAD | MoM growth, consecutive check |
| **Ranking** | RANK / DENSE_RANK | Leaderboards, Nth highest |
| **Find Missing** | LEFT JOIN + IS NULL | Customers who never ordered |
| **Duplicates** | GROUP BY + HAVING COUNT > 1 | Find duplicate emails |
| **Delete Duplicates** | ROW_NUMBER + DELETE where rn > 1 | Keep first occurrence |
| **Pivot** | CASE WHEN + Aggregate | Rows to columns |
| **Consecutive/Streak** | ROW_NUMBER gap technique | Login streaks |
| **Hierarchy** | Recursive CTE | Org chart, tree structure |
| **Exists Check** | EXISTS / NOT EXISTS | Does record exist? |
| **Median** | ROW_NUMBER + middle rows | Statistical median |

---

## Common Interview Traps

### Trap 1: NOT IN with NULLs

```sql
-- ❌ Returns EMPTY if subquery has NULL!
SELECT * FROM t1 WHERE id NOT IN (SELECT id FROM t2);  -- If t2 has NULL id!

-- ✅ Safe: Use NOT EXISTS
SELECT * FROM t1 WHERE NOT EXISTS (SELECT 1 FROM t2 WHERE t2.id = t1.id);
```

### Trap 2: COUNT(*) vs COUNT(column)

```sql
COUNT(*)      -- Sab rows (including NULL)
COUNT(column) -- Non-NULL values only
```

### Trap 3: GROUP BY mein SELECT columns

```sql
-- ❌ Error: name is not in GROUP BY
SELECT name, department, COUNT(*) FROM emp GROUP BY department;

-- ✅ Correct
SELECT department, COUNT(*) FROM emp GROUP BY department;
```

### Trap 4: WHERE vs HAVING

```sql
-- ❌ Wrong: WHERE mein aggregate nahi chalega
WHERE COUNT(*) > 5

-- ✅ Correct: HAVING use karo
HAVING COUNT(*) > 5
```

### Trap 5: JOIN without ON = CROSS JOIN

```sql
-- Galti se ON bhool gaye → Cartesian product!
SELECT * FROM employees, departments;  -- ❌ M×N rows!
```

### Trap 6: BETWEEN is INCLUSIVE

```sql
BETWEEN 10 AND 20  -- Includes 10 AND 20!
```

---

## SQL vs NoSQL — Interview Question

| Feature | SQL (Relational) | NoSQL |
|---------|-----------------|-------|
| **Structure** | Fixed schema (tables) | Flexible schema (documents, key-value) |
| **Scaling** | Vertical (bigger server) | Horizontal (more servers) |
| **ACID** | ✅ Strong ACID | Eventual consistency (BASE) |
| **Joins** | ✅ Powerful | Limited or no joins |
| **Query Language** | SQL (standard) | Database-specific |
| **Best For** | Complex queries, transactions | High volume, flexible data |
| **Examples** | MySQL, PostgreSQL, Oracle | MongoDB, Redis, Cassandra |
| **Use Case** | Banking, ERP, e-commerce | Social media, IoT, real-time |

> **Interview Answer:** "Use SQL when you need complex queries, transactions, and data integrity. Use NoSQL when you need horizontal scaling, flexible schema, and high write throughput."

---

## Query Optimization Checklist

```
Before Interview, verify your query:

□ Do I really need SELECT *? → Use specific columns
□ Is there an index on WHERE/JOIN columns? → Suggest creating one
□ Am I using functions on indexed columns? → Rewrite without
□ Am I doing LIKE '%text'? → Avoid leading wildcard
□ Can I replace NOT IN with NOT EXISTS? → Safer with NULLs
□ Am I joining too many tables? → Consider denormalization
□ Is my subquery correlated? → Can it be a JOIN instead?
□ Am I using DISTINCT unnecessarily? → Fix the query logic
□ Is my ORDER BY on an indexed column? → Index speeds sorting
□ Can I use CTE for readability? → Always prefer readable SQL
```

---

## Problem-Solving Strategy for SQL Interviews

```
Step 1: Understand the Problem
  → Kya output chahiye? Kaunse tables involved hain?

Step 2: Identify the Pattern
  → Ranking? Filtering? Grouping? Joining? Window function?

Step 3: Break Down the Query
  → FROM → WHERE → GROUP BY → HAVING → SELECT → ORDER BY

Step 4: Write Step by Step
  → Pehle simple query likho, phir complexity add karo

Step 5: Handle Edge Cases
  → NULLs? Duplicates? Empty results? Ties?

Step 6: Optimize
  → Index suggestions? Better approach? CTE for readability?
```

---

## Practice Categories (LeetCode SQL)

| Category | # Problems | Key Topics |
|----------|-----------|------------|
| **SELECT** | 15+ | Basic queries, WHERE, LIKE |
| **Joins** | 20+ | All join types, self join |
| **Aggregate** | 15+ | GROUP BY, HAVING, COUNT |
| **Subquery** | 10+ | IN, EXISTS, correlated |
| **Window Functions** | 15+ | RANK, LAG, LEAD, running sum |
| **Advanced** | 10+ | Recursive CTE, pivot, median |

> **Recommended Practice:** Start with Easy (50 problems) → Medium (30 problems) → Hard (10 problems). Focus on patterns, not memorizing solutions.

---

## Quick Memory Card — Interview Dos and Don'ts

| DO | DON'T |
|----|-------|
| Use CTE for readability | Use too many nested subqueries |
| Use EXISTS over NOT IN | Forget NULL handling |
| Use specific columns in SELECT | Use SELECT * in production |
| Test with edge cases | Assume data is clean |
| Explain your approach first | Jump to writing directly |
| Mention index optimization | Ignore query performance |
| Use window functions | Use only GROUP BY for everything |
| Consider ACID properties | Forget about transactions |

---

*Notes Source: FAANG SQL Interview patterns + LeetCode SQL + Interview preparation material*
