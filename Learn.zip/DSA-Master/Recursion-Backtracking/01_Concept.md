# Recursion-Backtracking — Concept

> **Permanent Recall:** Recursion = break problem into smaller subproblems; Backtracking = try choices, undo if they fail. Backtracking is DFS on a decision tree with pruning. The holy trinity: Subsets (2^n), Permutations (n!), Combinations (C(n,k)). Time = branching_factor^depth. FAANG tests this in ~15% of rounds — N-Queens, Sudoku, generate-all problems.

---

## Core Idea (2 Lines)

**Recursion:** A function calls itself on a smaller instance of the same problem until a base case stops it.

**Backtracking:** Build a solution step-by-step; when a choice leads to a dead end, undo it and try the next option. Intelligent brute force.

---

## Recursion Fundamentals

### Base Case vs Recursive Case

| Component | Purpose | Example (factorial) |
|-----------|---------|---------------------|
| **Base case** | Stops recursion; prevents infinite loop | `n == 0` → return 1 |
| **Recursive case** | Reduces problem; calls self | `n * factorial(n-1)` |

```
factorial(3)
  → 3 * factorial(2)
       → 2 * factorial(1)
            → 1 * factorial(0)
                 → 1  (base case)
            ← 1
       ← 2
  ← 6
```

### Call Stack = Decision History

- Each recursive call = one frame on the stack
- Returning from a call = "popping" that decision
- **Backtracking insight:** The "undo" in backtracking IS the return — when you return, you're implicitly undoing the last choice

```
Stack during backtrack:
  [chose A] → [chose B] → [chose C] → dead end!
  [chose A] → [chose B] ← (C undone, try D)
  [chose A] → [chose B] → [chose D] → solution!
```

---

## Backtracking = DFS on Decision Tree + Pruning

```
                    Root (empty state)
                   /        |        \
              Choice 1   Choice 2   Choice 3
               /   \       |          ...
         C1.1   C1.2    (pruned)
          |      |
       Leaf   Leaf
```

- **Node** = partial solution (state)
- **Edge** = a choice/decision
- **Leaf** = complete solution or dead end
- **Backtracking** = DFS traversal, skip (prune) branches that can't lead to valid solutions

---

## The Holy Trinity

| Type | Question | Decision | Tree Shape | Count |
|------|----------|----------|------------|-------|
| **Subsets** | "All subsets of {1,2,3}" | Include or exclude each element | Binary (2 branches) | 2^n |
| **Permutations** | "All orderings of {1,2,3}" | Which remaining element goes in position i? | k-ary (n, n-1, n-2...) | n! |
| **Combinations** | "All subsets of size k" | Include/exclude + prune by size | Binary + prune | C(n,k) |

### Subsets — Include/Exclude

```
                    {}
              /            \
          {1}                {}
        /     \            /     \
    {1,2}    {1}       {2}       {}
     /  \    /  \      /  \      /  \
  {1,2,3} ...  ...  ...  ...  {3}   {}
```

### Permutations — Choose from Remaining

```
                        []
                  /      |      \
               [1]     [2]     [3]
              /   \   /   \   /   \
         [1,2] [1,3] ...  ...  [3,2]
            |     |
        [1,2,3] [1,3,2]
```

### Combinations — Subsets with Size k

Same tree as subsets, but prune when:
- Already picked k items → stop
- Remaining items < (k - picked) → prune

---

## Time Complexity of Backtracking

**Formula:** O(branching_factor ^ depth) × work per node

| Problem Type | Branching | Depth | Typical Time |
|--------------|-----------|-------|--------------|
| Subsets | 2 | n | O(2^n) |
| Permutations | n, n-1, n-2... | n | O(n!) |
| Combinations C(n,k) | 2 | n | O(2^n) with pruning → O(C(n,k)) |
| N-Queens | n (columns) | n | O(n!) with pruning |
| Word Search | 4 (directions) | word length | O(4^L × m×n) |

**Key:** Pruning reduces the actual nodes visited. Worst case = full tree.

---

## When NOT to Use Backtracking

| Scenario | Why Not | Use Instead |
|----------|---------|-------------|
| Need optimal value, overlapping subproblems | Redundant work | Dynamic Programming |
| Greedy choice is provably correct | Overkill | Greedy |
| Problem has mathematical formula | Unnecessary | Direct formula |
| n is very large (>20) | Exponential blowup | DP, or different approach |
| "Find one" with early exit possible | BFS/DFS might suffice | BFS/DFS |
| Counting only, no enumeration | Often DP with recurrence | DP |

---

## Golden Rules

1. **"Generate all..." or "Find all..."** → Backtracking candidate
2. **Choose → Explore → Unchoose** — never forget unchoose
3. **Draw the decision tree first** — code follows naturally
4. **Prune early** — check validity before recursing
5. **Subsets:** process left-to-right, use index to avoid duplicates
6. **Permutations:** track `used[]` or use swap-based
7. **Duplicates in input:** sort first, skip when `nums[i]==nums[i-1]` and prev not used
8. **Base case** — must exist and be reachable

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Recursion + Backtracking
RECURSION:          Break into subproblems; base case stops
BACKTRACKING:       Try choice → recurse → undo; DFS + prune
HOLY TRINITY:       Subsets (2^n), Permutations (n!), Combinations C(n,k)
TREE:               Node=state, Edge=choice, Leaf=solution/dead-end
TIME:               branching_factor ^ depth (pruning reduces)
WHEN NOT:           DP overlap, greedy works, n huge, formula exists
INTERVIEW LINE:     "I'll model this as a decision tree. At each step I choose
                     from available options, recurse, then undo to try others."
```
