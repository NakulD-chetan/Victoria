# Tree — Tricks and Recognition

> See the problem → instantly know what to do. Pattern library.

---

## Instant Recognition Patterns

### Signal: "Level by level" or "row by row"
→ **BFS with level tracking**
```python
q = deque([root])
while q:
    for _ in range(len(q)):   # process one full level
        node = q.popleft()
        ...
```

### Signal: "Path from root to leaf"
→ **Top-down DFS**, carry running value/sum/path
```python
def dfs(node, current_state):
    if not node: return
    current_state += node.data   # update state as you go down
    if is_leaf(node): check(current_state)
    dfs(node.left,  current_state)
    dfs(node.right, current_state)
```

### Signal: "Max/min over all paths" or "longest path"
→ **Bottom-up**, compute at every node and track global max
```python
global_max = [0]
def helper(node):
    if not node: return 0
    left = helper(node.left)
    right = helper(node.right)
    global_max[0] = max(global_max[0], left + right)  # update at every node
    return 1 + max(left, right)
```

### Signal: "Kth smallest/largest in BST"
→ **In-order traversal** (gives sorted order), stop at kth element
```python
def kth_smallest(root, k):
    stack, node = [], root
    count = 0
    while node or stack:
        while node:
            stack.append(node)
            node = node.left
        node = stack.pop()
        count += 1
        if count == k: return node.data
        node = node.right
```

### Signal: "Check if BST"
→ Pass **min/max bounds** top-down
```python
def is_bst(node, lo=float('-inf'), hi=float('inf')):
    if not node: return True
    if not (lo < node.data < hi): return False
    return is_bst(node.left, lo, node.data) and is_bst(node.right, node.data, hi)
```

### Signal: "Serialize / store tree"
→ **Pre-order DFS** with null markers
- First value in pre-order = root → easy to reconstruct

### Signal: "Right side view" / "Left side view"
→ **BFS**, take last (or first) element of each level

### Signal: "Zigzag / spiral level order"
→ **BFS** with a flag that alternates direction each level

### Signal: "Balanced tree check"
→ **Bottom-up**, return (is_balanced, height) pair at every node
- If ANY node returns unbalanced, propagate False upward

### Signal: "Count nodes in complete binary tree"
→ **Binary search on height** — O(log²n) not O(n)
```
Compare left_height vs right_height:
- If equal: left subtree is perfect → count = 2^left_h + count(right)
- If not equal: right subtree is perfect → count = count(left) + 2^right_h
```

### Signal: "Connect nodes at same level"
→ **BFS level-order** or **right-pointer** trick (Morris traversal style)

---

## Key Tricks to Know

### Trick 1: Use return value as "message from subtree"

Instead of global variables (which cause bugs in recursion), return a tuple:
```python
def check_balanced(node):
    if node is None: return (True, -1)   # (is_balanced, height)
    lb, lh = check_balanced(node.left)
    rb, rh = check_balanced(node.right)
    balanced = lb and rb and abs(lh - rh) <= 1
    height = 1 + max(lh, rh)
    return (balanced, height)
```

### Trick 2: In-order of BST = Sorted Array

Use this for:
- Finding Kth smallest/largest
- Finding closest value in BST
- Checking if BST is valid (inorder should be strictly increasing)

### Trick 3: Pre-order First = Root, Post-order Last = Root

When given traversals to reconstruct a tree:
- **Pre-order[0]** = root
- **Post-order[-1]** = root
- In-order splits into left/right subtrees around root

### Trick 4: Heap Index Formulas (0-indexed)

```
Parent of i     = (i - 1) // 2
Left child of i = 2 * i + 1
Right child of i= 2 * i + 2
```

For heap of n elements:
- Last non-leaf node = (n // 2) - 1 (use for build-heap)
- All nodes from (n//2) to n-1 are leaf nodes

### Trick 5: Build Heap in O(n) — Heapify from Bottom

```python
def build_heap(arr):
    n = len(arr)
    for i in range(n // 2 - 1, -1, -1):   # start from last non-leaf
        heapify_down(arr, i, n)
```

### Trick 6: BST Delete — Always Replace with Inorder Successor

When deleting a node with 2 children:
1. Find **inorder successor** = leftmost node in right subtree (smallest in right)
2. Copy its value to current node
3. Delete the inorder successor (which has at most 1 child)

OR use **inorder predecessor** = rightmost node in left subtree (largest in left)

### Trick 7: AVL Rotation Decision Tree

```
After insert, go up to first unbalanced node.
Check: where is the newly inserted node?

Unbalanced node's BF = +2 (left heavy):
    Left child's BF = +1 → LL → Right Rotation
    Left child's BF = -1 → LR → Left Rotation on child, Right Rotation on node

Unbalanced node's BF = -2 (right heavy):
    Right child's BF = -1 → RR → Left Rotation
    Right child's BF = +1 → RL → Right Rotation on child, Left Rotation on node
```

### Trick 8: Morris Traversal (In-order without Stack/Recursion)

For O(1) space in-order traversal using threaded binary trees — advanced.

---

## Problem Category → Data Structure to Use

| Category | Use This |
|----------|---------|
| Sorted insert, delete, search | BST or AVL |
| Get min/max repeatedly | Min/Max Heap |
| Priority queue, scheduling | Heap |
| Top-K elements | Heap of size K |
| Level-order, shortest path | BFS Queue |
| Path problems, tree shape | DFS Recursion |
| Balanced BST | AVL Tree |
| Database indexing | B-Tree / B+Tree |

---

## The "3 Lines" Summary for Each Tree Type

**Binary Tree:** Non-linear, max 2 children, no ordering. Use recursion at every node.

**BST:** Same as BT but left < node < right. Gives sorted order (in-order). O(log n) average for search/insert/delete.

**AVL Tree:** BST + balance factor kept ∈ {-1, 0, 1}. Rotations fix imbalance. Guarantees O(log n) always.

**Heap:** Complete Binary Tree + parent always ≥ (or ≤) children. Use array storage. Insert/delete O(log n). Get-min/max O(1).
