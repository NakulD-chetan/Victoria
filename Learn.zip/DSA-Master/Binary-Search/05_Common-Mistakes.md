# Binary Search — Common Mistakes

> **Every mistake here has been made in real FAANG interviews. Learn WHY they happen so you never repeat them.**

---

## Mistake 1: Infinite Loop — lo = mid Instead of lo = mid + 1

### The Mistake
```python
# WRONG: When we need to search right, lo must move PAST mid
while lo < hi:
    mid = lo + (hi - lo) // 2
    if condition(mid):
        hi = mid
    else:
        lo = mid  # BUG! If lo=3, hi=4, mid=3, lo stays 3 → infinite loop
```

### Why It Happens
- When condition(mid) is false, we know mid is NOT the answer
- So we must exclude mid from the search space
- `lo = mid` keeps mid in the space — can cause infinite loop when lo and hi are adjacent

### The Fix
```python
# CORRECT: Always exclude mid when we know it's wrong
else:
    lo = mid + 1
```

### Golden Rule
> **When discarding the left half: lo = mid + 1. When discarding the right half: hi = mid (or hi = mid - 1). Never assign lo = mid or hi = mid when mid is excluded.**

---

## Mistake 2: Infinite Loop — Maximize Case Without Ceiling

### The Mistake
```python
# WRONG: Finding MAXIMUM X such that condition(X) is true
while lo < hi:
    mid = lo + (hi - lo) // 2  # Floor division
    if condition(mid):
        lo = mid  # We want to try larger
    else:
        hi = mid - 1

# When lo=4, hi=5, mid=4. If condition(4) true, lo=4. Still lo < hi? Yes.
# Next: mid = 4 again. Infinite loop!
```

### Why It Happens
- For "find maximum", we use lo = mid when condition holds
- With floor division, mid can equal lo when hi = lo + 1
- lo becomes mid, but hi doesn't change — stuck

### The Fix
```python
# CORRECT: Use CEILING for mid when lo = mid
mid = lo + (hi - lo + 1) // 2
```

### Golden Rule
> **When you have `lo = mid` (not mid+1), use ceiling for mid. Otherwise infinite loop when lo and hi are adjacent.**

---

## Mistake 3: Integer Overflow in mid Calculation

### The Mistake
```python
# WRONG: When lo and hi are large (e.g., 10^9)
mid = (lo + hi) // 2  # lo + hi can exceed 2^31 in C++/Java
```

```cpp
// C++: int overflow
int lo = 2000000000, hi = 2000000000;
int mid = (lo + hi) / 2;  // Overflow! UB.
```

### Why It Happens
- lo + hi can exceed INT_MAX when indices or values are large
- Common in binary search on answer (range 1 to 10^9)

### The Fix
```python
# CORRECT: Always use this form
mid = lo + (hi - lo) // 2
```

```cpp
// C++
int mid = lo + (hi - lo) / 2;
```

### Golden Rule
> **Never use (lo + hi) / 2. Always use lo + (hi - lo) / 2.**

---

## Mistake 4: Wrong Boundary — lo <= hi vs lo < hi

### The Mistake
```python
# WRONG for bisect_left: lo <= hi
while lo <= hi:
    mid = lo + (hi - lo) // 2
    if arr[mid] < target:
        lo = mid + 1
    else:
        hi = mid - 1  # This can skip the answer!
```

### Why It Happens
- For bisect_left: when arr[mid] >= target, mid might be the answer
- Using hi = mid - 1 could skip it
- Different loop conditions for different variants

### The Fix

| Variant | Loop Condition | When to Use |
|---------|----------------|-------------|
| Exact match | `lo <= hi` | Need to check when lo == hi |
| bisect_left / bisect_right | `lo < hi` | hi = mid or lo = mid + 1, exit when lo == hi |
| BS on answer (min) | `lo < hi` | hi = mid, lo = mid + 1 |

### Golden Rule
> **Exact match: lo <= hi, return -1 if not found. Bounds/BS on answer: lo < hi, lo is the answer at exit.**

---

## Mistake 5: Wrong Comparison in bisect_left vs bisect_right

### The Mistake
```python
# bisect_left: first index where arr[i] >= target
# WRONG: using <= in the condition
if arr[mid] <= target:  # This is bisect_right logic!
    lo = mid + 1
else:
    hi = mid
```

### The Fix
```python
# bisect_left: we want first >= target
if arr[mid] < target:
    lo = mid + 1
else:
    hi = mid

# bisect_right: we want first > target
if arr[mid] <= target:
    lo = mid + 1
else:
    hi = mid
```

### Memory Aid
```
bisect_left:  first arr[i] >= target  →  if arr[mid] < target, go right
bisect_right: first arr[i] > target   →  if arr[mid] <= target, go right
```

---

## Mistake 6: Not Handling Duplicates Correctly

### The Mistake
```python
# Problem: Find first occurrence of target
# WRONG: Return immediately on match
if arr[mid] == target:
    return mid  # Could be middle occurrence, not first!
```

### The Fix
```python
# For first occurrence: use bisect_left
# When we find match, search left for earlier one
if arr[mid] >= target:
    hi = mid
else:
    lo = mid + 1
# After loop, lo is first index >= target
return lo if lo < len(arr) and arr[lo] == target else -1
```

### Golden Rule
> **First occurrence = bisect_left then verify. Last occurrence = bisect_right - 1 then verify.**

---

## Mistake 7: Off-by-One in Result

### The Mistake
```python
# BS on answer: find minimum capacity
# WRONG: Returning hi when answer is lo
while lo < hi:
    mid = lo + (hi - lo) // 2
    if works(mid):
        hi = mid
    else:
        lo = mid + 1
return hi  # Actually lo is correct at exit (lo == hi)
```

### Why It Happens
- At exit, lo == hi. Both point to the answer.
- But if loop exits early or logic is wrong, lo and hi can differ
- Convention: for "find minimum", lo converges to answer

### The Fix
```python
return lo  # At exit lo == hi, both are the answer
```

### Golden Rule
> **At exit of `lo < hi` loop, lo == hi. Use either — but be consistent. Usually return lo.**

---

## Mistake 8: Wrong Search Space for BS on Answer

### The Mistake
```python
# "Minimum capacity to ship in D days"
# WRONG: lo = 0
lo, hi = 0, sum(weights)
# Capacity 0 never works. Wastes iterations. Or worse, condition(0) errors.
```

### The Fix
```python
# CORRECT: lo = max(weights) — can't ship a single package larger than capacity
lo, hi = max(weights), sum(weights)
```

### Golden Rule
> **For BS on answer, set lo and hi to the tightest valid range. lo = smallest possible answer, hi = largest.**

---

## Mistake 9: Not Validating Final Answer

### The Mistake
```python
# BS on answer: maybe no valid answer exists
while lo < hi:
    # ...
return lo  # What if condition(lo) is false? No valid answer!
```

### The Fix
```python
# CORRECT: Verify before returning
ans = lo
return ans if condition(ans) else -1
```

### Golden Rule
> **When the problem allows "no answer", verify condition(lo) at the end.**

---

## Mistake 10: Confusing < and <= in Condition

### The Mistake
```python
# "Minimum days to complete" — can we do it in d days?
# WRONG: days_needed < D  (should be <=)
def works(days):
    return days_needed <= D  # We have EXACTLY D days
```

### Why It Happens
- "Complete in D days" usually means ≤ D
- "Complete in under D days" means < D
- Off-by-one in interpretation changes the answer

### Golden Rule
> **Read the problem: "in D days" = ≤ D. "within D days" = ≤ D. "strictly less than" = < D.**

---

## Mistake Summary Table

| # | Mistake | Root Cause | Fix |
|---|---------|------------|-----|
| 1 | lo = mid (infinite loop) | Didn't exclude mid | lo = mid + 1 |
| 2 | Maximize without ceiling | mid = lo when adjacent | mid = lo + (hi - lo + 1) // 2 |
| 3 | (lo + hi) / 2 overflow | Large indices | lo + (hi - lo) / 2 |
| 4 | Wrong loop condition | Variant-specific | Exact: <= ; Bounds: < |
| 5 | Wrong comparison | bisect_left vs right | < vs <= |
| 6 | Duplicates | Return on first match | Use bisect_left |
| 7 | Off-by-one result | lo vs hi at exit | Usually return lo |
| 8 | Wrong search space | Loose bounds | Tighten lo, hi |
| 9 | No validation | No answer case | Check condition(lo) |
| 10 | < vs <= in condition | Misread problem | Clarify with interviewer |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Binary Search Mistakes
TOP 3 KILLERS:     1) lo=mid infinite loop  2) Overflow in mid  3) Wrong < vs <=
MID CALC:          lo + (hi - lo) / 2  ALWAYS
MAXIMIZE:          Use ceiling: mid = lo + (hi - lo + 1) / 2
DISCARD LEFT:      lo = mid + 1
DISCARD RIGHT:     hi = mid (or hi = mid - 1)
BISECT_LEFT:       arr[mid] < target → lo=mid+1
BISECT_RIGHT:      arr[mid] <= target → lo=mid+1
VALIDATE:          Check condition(lo) when "no answer" possible
INTERVIEW LINE:    "I'll use lo + (hi - lo) / 2 to avoid overflow,
                    and ensure one boundary moves past mid each step."
```
