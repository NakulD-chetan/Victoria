# Microservices Architecture — Common Mistakes

> **Permanent Recall:** Top 12 microservices mistakes: (1) too many services too early, (2) shared databases, (3) synchronous chains, (4) no API gateway, (5) ignoring distributed transactions, (6) chatty inter-service calls, (7) no service discovery, (8) no monitoring/tracing, (9) distributed monolith, (10) ignoring data consistency, (11) wrong service boundaries, (12) no circuit breakers. Each has a clear fix.

---

## Mistake 1: Too Many Microservices Too Early

**Problem:** 50 services for a 3-person team; operational nightmare.

| Wrong | Right |
|-------|-------|
| Extract everything to microservices | Start monolith; extract when team/scale justify |
| Service per table/entity | Service per bounded context / domain |

**Fix:** Modular monolith first; extract when deploy independence is needed.

---

## Mistake 2: Shared Databases

**Problem:** Multiple services touching same DB; coupling, schema conflict, no independent deploy.

| Wrong | Right |
|-------|-------|
| All services read/write shared DB | Database per service |
| Shared DB "for transactions" | Saga + eventual consistency |

**Fix:** Each service owns its DB; share via APIs or events.

---

## Mistake 3: Synchronous Chains

**Problem:** A → B → C → D; one slow/failing service blocks entire chain.

```
Service A → Service B → Service C → Service D
   (latency adds up; one failure = cascade)
```

| Wrong | Right |
|-------|-------|
| Long sync call chains | Async where possible; aggregate at BFF |
| No timeouts | Set timeouts; circuit breaker |

**Fix:** Prefer async; limit sync chain length; use BFF to aggregate.

---

## Mistake 4: No API Gateway

**Problem:** Clients call each service directly; duplicated auth, rate limiting, routing logic.

| Wrong | Right |
|-------|-------|
| Clients hit services directly | API Gateway at edge |
| Auth in every service | Centralize auth at gateway |

**Fix:** Single entry point; gateway handles auth, rate limit, routing.

---

## Mistake 5: Ignoring Distributed Transactions

**Problem:** Order created, payment failed—inconsistent state; no plan.

| Wrong | Right |
|-------|-------|
| Assume local transactions work | Design for Saga or compensating actions |
| No idempotency | Idempotency keys for retries |

**Fix:** Saga pattern; compensating actions; idempotent operations.

---

## Mistake 6: Chatty Inter-Service Calls

**Problem:** 20 round-trips to render one page; latency explodes.

| Wrong | Right |
|-------|-------|
| Many small calls per request | BFF aggregates; batch APIs |
| N+1 style calls | Single aggregation endpoint |

**Fix:** BFF or aggregator; batch/combine calls; cache where appropriate.

---

## Mistake 7: No Service Discovery

**Problem:** Hardcoded IPs; manual config when instances change; no dynamic scaling.

| Wrong | Right |
|-------|-------|
| Static IPs in config | Service discovery (Consul, Eureka, K8s) |
| Manual updates on scale | Auto-registration |

**Fix:** Use service discovery or K8s DNS; instances register on start.

---

## Mistake 8: No Monitoring / Tracing

**Problem:** "Something is slow"—can't find which service or call.

| Wrong | Right |
|-------|-------|
| No distributed tracing | Trace IDs across services (Jaeger, Zipkin) |
| No metrics per service | Metrics + dashboards per service |

**Fix:** Distributed tracing (trace ID in headers); centralized logging; metrics.

---

## Mistake 9: Distributed Monolith

**Problem:** Services deploy together; tight coupling. **Fix:** Loose coupling; versioned APIs; own your model; contract testing.

---

## Mistake 10: Ignoring Data Consistency

**Problem:** Eventual consistency not designed; no duplicate handling. **Fix:** Idempotent consumers; dedup by key; reconciliation jobs.

---

## Mistake 11: Wrong Service Boundaries

**Problem:** Split by layer or table; chatty calls. **Fix:** Domain-driven design; one service per bounded context; high cohesion.

---

## Mistake 12: No Circuit Breakers

**Problem:** Cascading failure; keep calling failing service. **Fix:** Circuit breaker; fail fast; fallback (cached, default).

---

## Mistake Summary Table

| # | Mistake | Severity | One-Line Fix |
|---|---------|----------|--------------|
| 1 | Too many services early | High | Start monolith |
| 2 | Shared databases | Critical | DB per service |
| 3 | Synchronous chains | High | Async; BFF; timeouts |
| 4 | No API gateway | High | Add gateway |
| 5 | Ignoring dist. transactions | Critical | Saga; idempotency |
| 6 | Chatty calls | Medium | BFF; batch |
| 7 | No service discovery | High | Consul, K8s |
| 8 | No monitoring/tracing | High | Tracing, metrics |
| 9 | Distributed monolith | High | True loose coupling |
| 10 | Ignoring data consistency | High | Idempotency; reconciliation |
| 11 | Wrong boundaries | High | DDD; domain-based |
| 12 | No circuit breakers | High | Circuit breaker; fallback |

---

## Quick Memory Card

```
TOO EARLY:     Start monolith
SHARED DB:     DB per service
SYNC CHAINS:   Async; BFF; timeout
GATEWAY:       Always at edge
TRANSACTIONS:  Saga; idempotency
CHATTY:        BFF; batch
DISCOVERY:     Consul, K8s
MONITORING:    Tracing; metrics
DIST MONOLITH: Loose coupling
CONSISTENCY:   Idempotent; reconcile
BOUNDARIES:    DDD
CIRCUIT:       Breaker; fallback
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
