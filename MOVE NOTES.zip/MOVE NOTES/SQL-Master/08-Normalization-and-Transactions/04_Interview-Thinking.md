# Normalization and Transactions — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is Normalization?
**A:** Process of organizing tables to minimize redundancy and dependency. Split tables so each fact is stored once. Normal forms: 1NF → 2NF → 3NF → BCNF → 4NF → 5NF.

### Q: What is 1NF?
**A:** First Normal Form — each column has atomic (single) values, no repeating groups, each row is unique. Violation: column with comma-separated values like "Math, Science".

### Q: What is 2NF?
**A:** Second Normal Form — 1NF + no partial dependency. Every non-key column depends on the WHOLE primary key, not just part of it. Only relevant with composite PK.

### Q: What is 3NF?
**A:** Third Normal Form — 2NF + no transitive dependency. Non-key columns depend ONLY on PK, not on other non-key columns. Example violation: emp table with dept_id → dept_name (dept_name depends on dept_id, not emp_id).

### Q: What is BCNF?
**A:** Boyce-Codd Normal Form — stricter 3NF. Every determinant must be a candidate key. Handles rare cases where 3NF allows non-CK determinants.

### Q: What is 4NF?
**A:** Eliminates multi-valued dependencies. If two independent one-to-many relationships exist, split them into separate tables. Example: employee skills and hobbies are independent → separate tables.

### Q: What are Anomalies?
**A:** Problems from poor normalization: Insert anomaly (can't add data without unrelated info), Update anomaly (one fact change requires many row updates), Delete anomaly (deleting row loses unrelated data).

### Q: When to Denormalize?
**A:** Read-heavy analytics, dashboards, data warehouses. When join cost hurts performance. Methods: materialized views, summary tables, star schema. Trade-off: faster reads but harder writes and potential inconsistency.

### Q: What is Star Schema?
**A:** Data warehouse design: central fact table (measures) surrounded by denormalized dimension tables (descriptors). Few joins, fast queries.

### Q: Star Schema vs Snowflake Schema?
**A:** Star: dimensions are denormalized (flat), fewer joins, faster queries. Snowflake: dimensions are normalized (have sub-tables), more joins, less storage. Star preferred for BI/dashboards.

### Q: What is ACID?
**A:** Transaction guarantees: Atomicity (all or nothing), Consistency (valid state → valid state), Isolation (concurrent tx don't interfere), Durability (committed data survives crash).

### Q: What is Atomicity?
**A:** All operations in a transaction succeed together, or all fail together. No partial execution. Bank transfer: both debit and credit, or neither.

### Q: What is Consistency?
**A:** DB moves from one valid state to another. All constraints, triggers, cascades must be satisfied after transaction.

### Q: What is Isolation?
**A:** Concurrent transactions behave as if they're running alone. Level of isolation configurable (Read Uncommitted → Serializable).

### Q: What is Durability?
**A:** Once a transaction is committed, its changes are permanent — survives power failure, crash. Ensured by WAL (Write-Ahead Logging).

### Q: What are Isolation Levels?
**A:** From weakest to strongest: Read Uncommitted (dirty reads OK), Read Committed (no dirty reads), Repeatable Read (same row = same value), Serializable (complete isolation, slowest).

### Q: What is a Dirty Read?
**A:** Reading data that another transaction has modified but NOT committed. If that tx rolls back, you've read invalid data.

### Q: What is a Non-Repeatable Read?
**A:** Reading the same row twice in one transaction and getting different values because another tx modified and committed between reads.

### Q: What is a Phantom Read?
**A:** Running same query twice in one transaction and getting different ROW SET because another tx inserted/deleted rows between reads.

### Q: What is a Deadlock?
**A:** Two transactions each holding a lock and waiting for the other's lock. Neither can proceed. DB detects and kills one (victim). App should catch error and retry.

### Q: How to prevent Deadlocks?
**A:** 1) Consistent lock ordering. 2) Keep transactions short. 3) Use lock timeouts. 4) Access tables in same order across all transactions.

### Q: What is Optimistic vs Pessimistic Locking?
**A:** Pessimistic: lock row before reading (SELECT FOR UPDATE) — high contention. Optimistic: no lock, check version at write time, retry on conflict — low contention, better performance.

### Q: What is MVCC?
**A:** Multi-Version Concurrency Control — each tx sees a snapshot, no read-write blocking. Writers create new versions, readers see old versions. Used by PostgreSQL, MySQL InnoDB.

### Q: What is WAL?
**A:** Write-Ahead Logging — changes written to log file BEFORE data file. On crash, replay log to recover. Ensures durability.

### Q: What is a SAVEPOINT?
**A:** Marker within a transaction to partially rollback to. `SAVEPOINT sp1; ... ROLLBACK TO sp1;` — undoes work after sp1 without rolling back entire tx.

### Q: What is Autocommit?
**A:** Mode where each SQL statement is automatically committed. Default in many DBs. Use explicit BEGIN/COMMIT for multi-statement atomic transactions.

### Q: What is Two-Phase Locking (2PL)?
**A:** Growing phase: acquire locks, no releases. Shrinking phase: release locks, no new acquisitions. Guarantees serializability.

### Q: Is 3NF always the best?
**A:** No. For OLTP — yes (minimize redundancy). For OLAP/data warehouses — denormalize for read speed (star schema). Context matters.

---

## Follow-up traps

- "Is 3NF always best?" → No — OLAP / warehouses **denormalize** for read speed.
- "Difference between Repeatable Read and Serializable?" → Serializable also prevents **phantom reads** (new rows appearing).
- "What is the default isolation level?" → Depends on DB: PostgreSQL/Oracle = Read Committed, MySQL InnoDB = Repeatable Read.

---

*Next: [[05_Common-Mistakes]]*
