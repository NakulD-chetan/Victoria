import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useLeakyBucketStore } from '../../stores/leaky-bucket-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4', stroke: '#1c1917', textPrimary: '#1c1917', textSecondary: '#78716c',
    clientFill: '#d0bfff', serverFill: '#b2f2bb', bucketStroke: '#1c1917', bucketRim: '#1c1917',
    waterFill: 'rgba(166,216,249,0.35)', waterStroke: 'rgba(25,113,194,0.3)',
    arrowStroke: '#78716c', pipeStroke: '#1c1917',
    statusOk: '#2f9e44', statusFull: '#e03131', statusNormal: '#78716c',
    queueItem: '#ffd43b', queueStroke: '#e8590c', emptySlot: '#d6d3d1',
    leakDrop: 'rgba(25,113,194,0.6)',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)', stroke: 'rgba(255,255,255,0.6)', textPrimary: '#e7e5e4', textSecondary: '#a8a29e',
    clientFill: '#3b2e6e', serverFill: '#1e5631', bucketStroke: 'rgba(255,255,255,0.55)', bucketRim: 'rgba(255,255,255,0.45)',
    waterFill: 'rgba(100,180,255,0.15)', waterStroke: 'rgba(100,180,255,0.25)',
    arrowStroke: '#a8a29e', pipeStroke: 'rgba(255,255,255,0.45)',
    statusOk: '#51cf66', statusFull: '#ff6b6b', statusNormal: '#a8a29e',
    queueItem: '#ffd43b', queueStroke: '#e8590c', emptySlot: 'rgba(255,255,255,0.15)',
    leakDrop: 'rgba(100,180,255,0.6)',
  },
};
function getPal() { return (document.documentElement.getAttribute('data-theme') === 'light') ? PALETTE.light : PALETTE.dark; }

const LeakyBucketCanvas = forwardRef(function LeakyBucketCanvas({ bucketRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');
  const capacity = useLeakyBucketStore((s) => s.capacity);
  const leakRate = useLeakyBucketStore((s) => s.leakRate);

  const addAnim = useCallback((type, dur = 700, delay = 0) => {
    animsRef.current.push({ type, t0: performance.now(), dur, delay });
  }, []);
  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache(); lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);
    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function L() {
      const W = wRef.current, H = hRef.current, cx = W / 2;
      return {
        client: { x: 30, y: H / 2 - 40, w: 110, h: 70 },
        bucket: { x: cx - 80, y: 60, w: 160, h: 240, cx },
        bucketBot: { lx: cx - 60, rx: cx + 60, y: 300 },
        server: { x: W - 140, y: H / 2 - 40, w: 110, h: 70 },
        pipeIn: { x: cx, y: 14, h: 46 },
        pipeOut: { x: cx, y: 300, h: 50 },
        arrowIn: { sx: 140, ex: cx - 80, y: H / 2 },
        arrowOut: { sx: cx + 80, ex: W - 140, y: H / 2 },
        W, H,
      };
    }

    function drawBox(key, x, y, w, h, opts) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.6, bowing: 1.2, strokeWidth: 2.2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawBucket(key, l, pal) {
      const bw = l.bucket.w + 20, bh = l.bucket.h + 10;
      const img = cacheShape(key, bw, bh, (rc) => {
        const topL = 10, topR = l.bucket.w + 10;
        const botL = 10 + (l.bucket.w - (l.bucketBot.rx - l.bucketBot.lx)) / 2;
        const botR = botL + (l.bucketBot.rx - l.bucketBot.lx);
        const h2 = l.bucket.h + 5;
        rc.polygon([[topL, 5], [topR, 5], [botR, h2], [botL, h2]], { seed: 1, roughness: 1.8, bowing: 1, stroke: pal.bucketStroke, strokeWidth: 2.8 });
        rc.line(topL - 12, 5, topR + 12, 5, { seed: 77, roughness: 1.5, strokeWidth: 4, stroke: pal.bucketRim });
      });
      ctx.drawImage(img, l.bucket.x - 10, l.bucket.y - 5, bw, bh);
    }

    function drawPipe(key, x, yStart, h, pal) {
      const pw = 30, ph = h + 10;
      const img = cacheShape(key, pw, ph, (rc) => {
        rc.line(8, 0, 8, ph, { seed: 30, roughness: 1.2, strokeWidth: 2, stroke: pal.pipeStroke });
        rc.line(22, 0, 22, ph, { seed: 31, roughness: 1.2, strokeWidth: 2, stroke: pal.pipeStroke });
      });
      ctx.drawImage(img, x - 15, yStart, pw, ph);
    }

    function drawArrowLine(key, x1, y1, x2, pal) {
      const pad = 20, w = Math.abs(x2 - x1) + pad * 2, h = 30;
      const img = cacheShape(key, w, h, (rc) => {
        rc.line(pad, h / 2, w - pad, h / 2, { seed: 50, roughness: 1.5, strokeWidth: 1.8, stroke: pal.arrowStroke });
        const tipX = w - pad;
        rc.line(tipX - 12, h / 2 - 7, tipX, h / 2, { seed: 51, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
        rc.line(tipX - 12, h / 2 + 7, tipX, h / 2, { seed: 52, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
      });
      ctx.drawImage(img, Math.min(x1, x2) - pad, y1 - 15, w, h);
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';
      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) { clearShapeCache(); clearCache(); lastThemeRef.current = curTheme; }
      const pal = getPal();
      const l = L();
      const bucket = bucketRef.current;

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.5, 1.5);

      bucket.leak(now);

      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h, { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke });
      drawBox('server', l.server.x, l.server.y, l.server.w, l.server.h, { fill: pal.serverFill, fillStyle: 'hachure', hachureGap: 6, seed: 4, stroke: pal.stroke });
      drawPipe('pipe-in', l.pipeIn.x, l.pipeIn.y, l.pipeIn.h, pal);
      drawPipe('pipe-out', l.pipeOut.x, l.pipeOut.y, l.pipeOut.h, pal);
      drawBucket('bucket', l, pal);
      drawArrowLine('arr-in', l.arrowIn.sx, l.arrowIn.y, l.arrowIn.ex, pal);
      drawArrowLine('arr-out', l.arrowOut.sx, l.arrowOut.y, l.arrowOut.ex, pal);

      const fillPct = bucket.queueSize / bucket.capacity;
      const bTop = l.bucket.y + 3, bBot = l.bucketBot.y;
      const bTopL = l.bucket.x, bTopR = l.bucket.x + l.bucket.w;
      const bBotL = l.bucketBot.lx, bBotR = l.bucketBot.rx;
      const waterTop = bBot - (bBot - bTop) * fillPct;
      const frac = (waterTop - bTop) / (bBot - bTop);
      const wlL = bTopL + (bBotL - bTopL) * frac;
      const wlR = bTopR + (bBotR - bTopR) * frac;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(bTopL, bTop); ctx.lineTo(bTopR, bTop); ctx.lineTo(bBotR, bBot); ctx.lineTo(bBotL, bBot);
      ctx.closePath(); ctx.clip();
      ctx.fillStyle = pal.waterFill;
      ctx.fillRect(bBotL - 20, waterTop, bBotR - bBotL + 40, bBot - waterTop + 5);
      ctx.strokeStyle = pal.waterStroke; ctx.lineWidth = 2;
      ctx.beginPath();
      for (let wx = wlL - 5; wx <= wlR + 5; wx += 1) {
        const wy = waterTop + Math.sin((wx + now * 0.002) * 0.08) * 3;
        wx === wlL - 5 ? ctx.moveTo(wx, wy) : ctx.lineTo(wx, wy);
      }
      ctx.stroke();
      ctx.restore();

      const cols = Math.min(4, bucket.capacity), rows = Math.ceil(bucket.capacity / cols);
      const areaW = (bBotR - bBotL) * 0.85, areaH = l.bucket.h * 0.65;
      const startY = bBot - 18;
      const gapX = areaW / (cols + 1), gapY = areaH / (rows + 0.5);
      for (let i = 0; i < bucket.capacity; i++) {
        const row = Math.floor(i / cols), col = i % cols;
        const rowCount = Math.min(cols, bucket.capacity - row * cols);
        const rowW = rowCount * gapX;
        const px = l.bucket.cx - rowW / 2 + gapX / 2 + col * gapX;
        const py = startY - row * gapY;
        const filled = i < bucket.queueSize;
        const key = `slot-${i}-${filled}`;
        const img = cacheShape(key, 26, 26, (rc) => {
          if (filled) {
            rc.circle(13, 13, 22, { seed: 200 + i, roughness: 1, fill: pal.queueItem, fillStyle: 'solid', stroke: pal.queueStroke, strokeWidth: 2 });
          } else {
            rc.circle(13, 13, 22, { seed: 200 + i, roughness: 1, stroke: pal.emptySlot, strokeWidth: 1.2 });
          }
        });
        ctx.drawImage(img, px - 13, py - 13, 26, 26);
      }

      if (bucket.queueSize > 0) {
        const leakPhase = (now % 600) / 600;
        const dropY = l.pipeOut.y + leakPhase * l.pipeOut.h;
        ctx.beginPath(); ctx.arc(l.pipeOut.x, dropY, 5, 0, Math.PI * 2);
        ctx.fillStyle = pal.leakDrop; ctx.fill();
      }

      ctx.fillStyle = pal.textPrimary; ctx.font = `600 15px ${FONT_HAND}`; ctx.textAlign = 'center';
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);
      ctx.fillText('Server', l.server.x + l.server.w / 2, l.server.y + l.server.h / 2);
      ctx.font = `800 34px ${FONT_MONO}`; ctx.fillStyle = pal.textPrimary;
      ctx.fillText(String(bucket.queueSize), l.bucket.cx, l.bucket.y + 50);
      ctx.font = `14px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText(`/ ${bucket.capacity} queue`, l.bucket.cx, l.bucket.y + 74);
      ctx.font = `13px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText('request in', (l.arrowIn.sx + l.arrowIn.ex) / 2, l.arrowIn.y - 18);
      ctx.fillText('processed out', (l.arrowOut.sx + l.arrowOut.ex) / 2, l.arrowOut.y - 18);

      ctx.textAlign = 'center'; ctx.font = `12px ${FONT_HAND}`;
      ctx.fillText('Queue (FIFO)', l.bucket.cx, l.bucket.y - 12);
      ctx.fillStyle = pal.statusOk; ctx.font = `11px ${FONT_MONO}`;
      ctx.fillText(`leak: ${bucket.leakRate}/s`, l.bucket.cx, l.pipeOut.y + l.pipeOut.h + 14);

      ctx.textAlign = 'left'; ctx.font = `12px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText(`capacity = ${bucket.capacity}`, l.bucket.x + l.bucket.w + 14, l.bucket.y + 30);
      ctx.fillText(`leak_rate = ${bucket.leakRate}/s`, l.bucket.x + l.bucket.w + 14, l.bucket.y + 50);

      ctx.textAlign = 'center'; ctx.font = `700 14px ${FONT_HAND}`;
      if (bucket.queueSize >= bucket.capacity) { ctx.fillStyle = pal.statusFull; ctx.fillText('Queue Full \u2014 Rejecting!', l.bucket.cx, l.bucketBot.y + 36); }
      else if (bucket.queueSize === 0) { ctx.fillStyle = pal.statusNormal; ctx.fillText('Queue Empty \u2014 Idle', l.bucket.cx, l.bucketBot.y + 36); }
      else { ctx.fillStyle = pal.statusOk; ctx.fillText('Accepting & draining...', l.bucket.cx, l.bucketBot.y + 36); }

      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const elapsed = now - a.t0 - (a.delay || 0);
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);
        if (a.type === 'req-accept') {
          if (t < 0.5) {
            const p = t / 0.5;
            const px = l.arrowIn.sx + (l.arrowIn.ex - l.arrowIn.sx) * easeOut(p);
            ctx.beginPath(); ctx.arc(px, l.arrowIn.y, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(25,113,194,0.7)'; ctx.fill();
          } else if (t < 0.7) {
            const p = (t - 0.5) / 0.2;
            const dy = l.bucket.y + l.bucket.h * (1 - (bucket.queueSize / bucket.capacity) * 0.8) - l.arrowIn.y;
            const py = l.arrowIn.y + dy * easeOut(p);
            ctx.beginPath(); ctx.arc(l.bucket.cx, py, 6, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(255,212,59,0.8)'; ctx.fill();
          } else {
            const alpha = 1 - (t - 0.7) / 0.3;
            ctx.font = `800 28px ${FONT_HAND}`; ctx.fillStyle = `rgba(47,158,68,${alpha})`; ctx.textAlign = 'center';
            ctx.fillText('\u2713', l.bucket.cx, l.bucket.y - 26);
          }
        }
        if (a.type === 'req-reject') {
          if (t < 0.4) {
            const p = t / 0.4;
            const px = l.arrowIn.sx + (l.arrowIn.ex - l.arrowIn.sx) * easeOut(p);
            ctx.beginPath(); ctx.arc(px, l.arrowIn.y, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(224,49,49,0.7)'; ctx.fill();
          } else if (t < 0.6) {
            const bT = (t - 0.4) / 0.2;
            const px = l.arrowIn.ex - bT * 30;
            ctx.beginPath(); ctx.arc(px, l.arrowIn.y, 8 * (1 - bT * 0.3), 0, Math.PI * 2);
            ctx.fillStyle = `rgba(224,49,49,${1 - bT * 0.5})`; ctx.fill();
          }
          if (t > 0.25 && t < 0.85) {
            ctx.font = `800 32px ${FONT_HAND}`; ctx.fillStyle = pal.statusFull; ctx.textAlign = 'center';
            ctx.globalAlpha = Math.max(t < 0.55 ? 1 : 1 - (t - 0.55) / 0.3, 0);
            ctx.fillText('\u2717', l.bucket.cx, l.bucket.y - 26); ctx.globalAlpha = 1;
          }
        }
        if (a.type === 'leak-out') {
          const p = easeOut(t);
          const px = l.arrowOut.sx + (l.arrowOut.ex - l.arrowOut.sx) * p;
          ctx.beginPath(); ctx.arc(px, l.arrowOut.y, 6, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(47,158,68,${1 - t * 0.5})`; ctx.fill();
        }
        if (t >= 1) anims.splice(i, 1);
      }
      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, [bucketRef, addAnim]);

  useEffect(() => { clearShapeCache(); clearCache(); lastThemeRef.current = ''; }, [capacity, leakRate]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 420 }} />
    </div>
  );
});

export default LeakyBucketCanvas;
