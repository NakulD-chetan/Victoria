# Design Distributed Cache — Edge Cases

> **Permanent Recall:** Key edge cases: **hot key** (one key gets 90% traffic), **node failure + rehashing** (consistent hashing minimizes), **cache stampede** (thundering herd on miss), **memory fragmentation**, **large values** (big keys), **network partition** (split-brain). Each needs a mitigation strategy.

---

## 1. Hot Key

**Scenario:** One key (e.g., `trending:list`) gets 90% of GET traffic. All requests land on one node.

**Impact:** That node becomes bottleneck; latency spikes; possible failure.

**Mitigation:**

| Approach | How |
|----------|-----|
| **Replication** | Multiple replicas for hot shard; round-robin reads |
| **Local cache** | Application-level cache (e.g., in-process) for hottest keys |
| **Key sharding** | Split: `trending:0`, `trending:1`, ...; client picks randomly or by some rule |
| **Read-through with lock** | Prevent stampede (see below) |

---

## 2. Node Failure and Rehashing

**Scenario:** Node fails. Keys it owned must be served by elsewhere.

**Impact:** Without consistent hashing: massive rehash, all nodes busy. With consistent hashing: only next node on ring gets the keys.

**Mitigation:**

- **Consistent hashing:** Only K/N keys move (K = keys on failed node)
- **Replica promotion:** Replica already has the data; quick failover
- **Client retry:** Retry on connection failure; topology update from cluster

---

## 3. Cache Stampede (Thundering Herd)

**Scenario:** Popular key expires. Thousands of requests miss simultaneously; all hit DB.

**Impact:** DB overload; latency spike; potential cascade failure.

**Mitigation:**

| Approach | How |
|----------|-----|
| **Lock/mutex** | First miss acquires lock; others wait or get stale; one DB query |
| **Probabilistic early expiry** | Return stale if TTL > X with prob; spread reloads |
| **Background refresh** | Refresh before expiry; avoid synchronous reload |

```
Stampede:  TTL expires → 1000 GETs miss → 1000 DB queries
With lock: TTL expires → 1000 GETs miss → 1 acquires lock, 999 wait → 1 DB query → all get fresh
```

---

## 4. Memory Fragmentation

**Scenario:** Many small allocations/deallocations; memory fragmented; "we have 10GB free" but no contiguous block for 1MB allocation.

**Impact:** OOM even with "free" memory; allocation failure.

**Mitigation:**

- **Slab allocator** (Memcached-style): Pre-allocate size classes; reduce fragmentation
- **jemalloc** (Redis): Better than glibc malloc for allocation patterns
- **Avoid variable huge values:** Large values fragment more

---

## 5. Large Values (Big Keys)

**Scenario:** One key holds 100MB (e.g., huge list or JSON blob).

**Impact:** Slow serialization/deserialization; network transfer; blocks node; memory spike.

**Mitigation:**

- **Limit value size:** Reject or warn above threshold (e.g., 512KB)
- **Chunking:** Split into sub-keys (`key:0`, `key:1`, ...)
- **Compression:** For compressible values
- **Different storage:** Large blobs in object store; cache only metadata/pointer

> **FAANG Tip:** "Big key" is a known Redis anti-pattern. Mention it to show production awareness.

---

## 6. Network Partition (Split-Brain)

**Scenario:** Network divides cluster into two groups. Each may think the other is dead.

**Impact:** Two primaries for same shard; divergent writes; data inconsistency.

**Mitigation:**

- **Quorum:** Require majority for primary election; partition can't form two primaries
- **Fence/epoch:** Reject requests from old primary after failover
- **Last-writer-wins:** Accept conflict; document the trade-off
- **CP vs AP:** Choose consistency (refuse writes in minority) or availability (accept writes, resolve later)

---

## 7. Cold Start

**Scenario:** Cluster starts empty. All requests miss; all hit DB.

**Impact:** DB overload; slow startup.

**Mitigation:**

- **Warm-up:** Preload hot keys from DB before traffic
- **Lazy load:** Accept initial miss penalty; cache warms over time
- **Rate limit DB:** Protect DB during cold start

---

## 8. TTL Expiry Storm

**Scenario:** Millions of keys with same TTL expire at once (e.g., all set with 1h TTL at midnight).

**Impact:** CPU spike; delayed eviction; potential latency spike.

**Mitigation:**

- **Jitter:** Add random offset to TTL (e.g., 1h + rand(0, 5min))
- **Lazy + periodic:** Redis-style; spread work over time
