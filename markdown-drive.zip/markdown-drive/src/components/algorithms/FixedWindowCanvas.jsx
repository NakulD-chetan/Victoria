import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useFixedWindowStore } from '../../stores/fixed-window-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    clientFill: '#d0bfff',
    serverFill: '#b2f2bb',
    windowStroke: '#1c1917',
    windowBg: '#f5f5f4',
    windowFill: 'rgba(25,113,194,0.4)',
    windowFillStroke: 'rgba(25,113,194,0.6)',
    arrowStroke: '#78716c',
    statusFull: '#2f9e44',
    statusEmpty: '#e03131',
    statusNormal: '#78716c',
    reqDot: 'rgba(25,113,194,0.8)',
    denyDot: 'rgba(224,49,49,0.8)',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)',
    stroke: 'rgba(255,255,255,0.6)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    clientFill: '#3b2e6e',
    serverFill: '#1e5631',
    windowStroke: 'rgba(255,255,255,0.55)',
    windowBg: 'rgba(255,255,255,0.05)',
    windowFill: 'rgba(100,180,255,0.25)',
    windowFillStroke: 'rgba(100,180,255,0.4)',
    arrowStroke: '#a8a29e',
    statusFull: '#51cf66',
    statusEmpty: '#ff6b6b',
    statusNormal: '#a8a29e',
    reqDot: 'rgba(100,180,255,0.8)',
    denyDot: 'rgba(255,107,107,0.8)',
  },
};

function getThemePalette() {
  const t = document.documentElement.getAttribute('data-theme');
  return t === 'light' ? PALETTE.light : PALETTE.dark;
}

const FixedWindowCanvas = forwardRef(function FixedWindowCanvas({ counterRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');

  const windowSize = useFixedWindowStore((s) => s.windowSize);
  const limit = useFixedWindowStore((s) => s.limit);

  const addAnim = useCallback((type, dur = 700, delay = 0) => {
    animsRef.current.push({ type, t0: performance.now(), dur, delay });
  }, []);

  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache();
      lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function L() {
      const W = wRef.current, H = hRef.current;
      const clientW = 110, clientH = 70;
      const serverW = 110, serverH = 70;
      const windowW = Math.min(320, W - 280);
      const windowH = 100;
      return {
        client: { x: 30, y: H / 2 - clientH / 2, w: clientW, h: clientH },
        server: { x: W - 30 - serverW, y: H / 2 - serverH / 2, w: serverW, h: serverH },
        window: {
          x: (W - windowW) / 2,
          y: H / 2 - windowH / 2 - 20,
          w: windowW,
          h: windowH,
          cx: W / 2,
        },
        arrowReqStart: { x: 30 + clientW, y: H / 2 },
        arrowReqEnd: { x: (W - windowW) / 2 - 10, y: H / 2 },
        arrowResStart: { x: (W + windowW) / 2 + 10, y: H / 2 },
        arrowResEnd: { x: W - 30 - serverW - 10, y: H / 2 },
        W, H,
      };
    }

    function drawBox(key, x, y, w, h, opts) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.6, bowing: 1.2, strokeWidth: 2.2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawArrowLine(key, x1, y1, x2, pal) {
      const pad = 20, w = Math.abs(x2 - x1) + pad * 2, h = 30;
      const img = cacheShape(key, w, h, (rc) => {
        rc.line(pad, h / 2, w - pad, h / 2, { seed: 50, roughness: 1.5, strokeWidth: 1.8, stroke: pal.arrowStroke });
        const tipX = w - pad, tipY = h / 2;
        rc.line(tipX - 12, tipY - 7, tipX, tipY, { seed: 51, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
        rc.line(tipX - 12, tipY + 7, tipX, tipY, { seed: 52, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
      });
      ctx.drawImage(img, Math.min(x1, x2) - pad, y1 - 15, w, h);
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';
      const l = L();
      const counter = counterRef.current;

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) {
        clearShapeCache(); clearCache();
        lastThemeRef.current = curTheme;
      }
      const pal = getThemePalette();

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h, { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke });
      drawBox('server', l.server.x, l.server.y, l.server.w, l.server.h, { fill: pal.serverFill, fillStyle: 'hachure', hachureGap: 6, seed: 4, stroke: pal.stroke });
      drawArrowLine('arr-req', l.arrowReqStart.x, l.arrowReqStart.y, l.arrowReqEnd.x, pal);
      drawArrowLine('arr-res', l.arrowResStart.x, l.arrowResStart.y, l.arrowResEnd.x, pal);

      const win = l.window;
      const fillPct = limit > 0 ? counter.count / limit : 0;

      const windowKey = `win-${win.w}-${win.h}`;
      const winImg = cacheShape(windowKey, win.w + 8, win.h + 8, (rc) => {
        rc.rectangle(4, 4, win.w, win.h, { roughness: 1.4, bowing: 1, strokeWidth: 2.2, stroke: pal.windowStroke, fill: pal.windowBg, fillStyle: 'solid' });
      });
      ctx.drawImage(winImg, win.x - 4, win.y - 4, win.w + 8, win.h + 8);

      const anims = animsRef.current;
      let windowResetProgress = 1;
      for (const a of anims) {
        if (a.type === 'window-reset') {
          const elapsed = now - a.t0 - (a.delay || 0);
          if (elapsed >= 0) {
            const t = Math.min(elapsed / a.dur, 1);
            windowResetProgress = 1 - easeOut(t);
          }
        }
      }

      const displayFillPct = fillPct * windowResetProgress;
      const fillW = win.w * 0.9 * displayFillPct;
      const fillX = win.x + win.w * 0.05;
      const fillY = win.y + win.h * 0.2;
      const fillH = win.h * 0.6;
      ctx.fillStyle = pal.windowFill;
      ctx.fillRect(fillX, fillY, Math.max(0, fillW), fillH);
      ctx.strokeStyle = pal.windowFillStroke;
      ctx.lineWidth = 2;
      ctx.strokeRect(fillX, fillY, Math.max(0, fillW), fillH);

      const dotCols = Math.min(limit, 8);
      const dotRows = Math.ceil(limit / dotCols);
      const dotAreaW = win.w * 0.75;
      const dotAreaH = fillH * 0.8;
      const dotStartX = win.cx - dotAreaW / 2 + dotAreaW / (dotCols + 1) / 2;
      const dotStartY = win.y + win.h * 0.5;
      const dotGapX = dotAreaW / (dotCols + 1);
      const dotGapY = dotAreaH / (dotRows + 0.5);
      for (let i = 0; i < Math.min(counter.count, limit); i++) {
        const row = Math.floor(i / dotCols);
        const col = i % dotCols;
        const px = dotStartX + col * dotGapX;
        const py = dotStartY - row * dotGapY;
        ctx.beginPath();
        ctx.arc(px, py, 6, 0, Math.PI * 2);
        ctx.fillStyle = pal.reqDot;
        ctx.fill();
        ctx.strokeStyle = pal.windowFillStroke;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      ctx.fillStyle = pal.textPrimary;
      ctx.font = `600 15px ${FONT_HAND}`;
      ctx.textAlign = 'center';
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);
      ctx.fillText('Server', l.server.x + l.server.w / 2, l.server.y + l.server.h / 2);

      ctx.font = `800 28px ${FONT_MONO}`;
      ctx.fillStyle = pal.textPrimary;
      ctx.fillText(`${counter.count}/${limit}`, win.cx, win.y + win.h / 2);
      ctx.font = `12px ${FONT_HAND}`;
      ctx.fillStyle = pal.textSecondary;
      ctx.fillText(`Window #${counter.currentWindow}`, win.cx, win.y + win.h - 8);
      ctx.fillText(`${windowSize}s window`, win.cx, win.y - 8);

      ctx.font = `13px ${FONT_HAND}`;
      ctx.fillStyle = pal.textSecondary;
      ctx.fillText('request', (l.arrowReqStart.x + l.arrowReqEnd.x) / 2, l.arrowReqStart.y - 18);
      ctx.fillText('response', (l.arrowResStart.x + l.arrowResEnd.x) / 2, l.arrowResStart.y - 18);

      ctx.textAlign = 'center';
      ctx.font = `700 14px ${FONT_HAND}`;
      if (counter.count >= limit) {
        ctx.fillStyle = pal.statusEmpty;
        ctx.fillText('Window Full \u2014 Denying!', win.cx, win.y + win.h + 24);
      } else if (counter.count === 0) {
        ctx.fillStyle = pal.statusNormal;
        ctx.fillText('Accepting requests...', win.cx, win.y + win.h + 24);
      } else {
        ctx.fillStyle = pal.statusFull;
        ctx.fillText(`${limit - counter.count} slots left`, win.cx, win.y + win.h + 24);
      }

      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const delay = a.delay || 0;
        const elapsed = now - a.t0 - delay;
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);

        if (a.type === 'req-allow') {
          const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
          if (t < 0.5) {
            const p = t / 0.5;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = pal.reqDot;
            ctx.fill();
          } else {
            const p = (t - 0.5) / 0.5;
            const sx2 = l.arrowResStart.x, ex2 = l.arrowResEnd.x;
            const px = sx2 + (ex2 - sx2) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, l.arrowResStart.y, 7, 0, Math.PI * 2);
            ctx.fillStyle = pal.statusFull;
            ctx.fill();
          }
          if (t > 0.3 && t < 0.7) {
            ctx.font = `800 28px ${FONT_HAND}`;
            ctx.fillStyle = pal.statusFull;
            ctx.textAlign = 'center';
            ctx.globalAlpha = Math.min(1 - Math.abs(t - 0.5) / 0.2, 1);
            ctx.fillText('\u2713', win.cx, win.y - 16);
            ctx.globalAlpha = 1;
          }
        }

        if (a.type === 'req-deny') {
          const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
          if (t < 0.4) {
            const p = t / 0.4;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = pal.denyDot;
            ctx.fill();
          } else if (t < 0.6) {
            const bT = (t - 0.4) / 0.2;
            const px = ex - bT * 30;
            ctx.beginPath();
            ctx.arc(px, sy, 8 * (1 - bT * 0.3), 0, Math.PI * 2);
            ctx.fillStyle = `rgba(224,49,49,${1 - bT * 0.5})`;
            ctx.fill();
          }
          if (t > 0.25 && t < 0.85) {
            ctx.font = `800 32px ${FONT_HAND}`;
            ctx.fillStyle = pal.statusEmpty;
            ctx.textAlign = 'center';
            ctx.globalAlpha = Math.max(t < 0.55 ? 1 : 1 - (t - 0.55) / 0.3, 0);
            ctx.fillText('\u2717', win.cx, win.y - 16);
            ctx.globalAlpha = 1;
          }
        }

        if (t >= 1) anims.splice(i, 1);
      }

      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [counterRef, addAnim, windowSize, limit]);

  useEffect(() => {
    clearShapeCache();
    clearCache();
    lastThemeRef.current = '';
  }, [windowSize, limit]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 420 }} />
    </div>
  );
});

export default FixedWindowCanvas;
