import { usePlaygroundStore } from '../../stores/playground-store';
import PropertyEditor from './PropertyEditor';

export default function ConfigPanel() {
  const components = usePlaygroundStore((s) => s.components);
  const selectedCompId = usePlaygroundStore((s) => s.selectedCompId);
  const stats = usePlaygroundStore((s) => s.stats);
  const requests = usePlaygroundStore((s) => s.requests);

  const selectedComp = components.find((c) => c.id === selectedCompId);

  const elapsed = stats.startTime ? (Date.now() - stats.startTime) / 1000 : 0;
  const throughput = elapsed > 1 ? (stats.done / elapsed).toFixed(1) + '/s' : '--';
  const avgLat = stats.done > 0 ? Math.round(stats.totalLat / stats.done) + 'ms' : '--';
  const activeReqs = requests.filter((r) => r.state !== 'done').length;

  if (!selectedComp && !stats.sent) return null;

  return (
    <div className="dc-config-panel">
      {selectedComp && (
        <div className="dc-config-panel__section">
          <PropertyEditor comp={selectedComp} />
        </div>
      )}

      {stats.sent > 0 && (
        <div className="dc-config-panel__section dc-config-panel__stats">
          <div className="dc-config-panel__stats-title">Live Stats</div>
          <div className="dc-live-stats">
            {[
              ['Sent', stats.sent],
              ['Completed', stats.done],
              ['Failed', stats.failed],
              ['Rejected', stats.rejected],
              ['In-Flight', activeReqs],
              ['Avg Latency', avgLat],
              ['Throughput', throughput],
            ].map(([label, val]) => (
              <div key={label} className="dc-live-stats__row">
                <span>{label}</span>
                <span className="dc-live-stats__val">{val}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
