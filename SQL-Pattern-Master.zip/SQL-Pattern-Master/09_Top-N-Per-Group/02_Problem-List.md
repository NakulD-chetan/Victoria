# Top-N per Group — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers ROW_NUMBER top-N, DENSE_RANK top-N, top-1 (latest/max), and advanced multi-criteria ranking. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Second Highest Salary | LC 176 | Medium | Top-2, single group | Foundation — Nth value |
| 2 | Nth Highest Salary | LC 177 | Medium | Top-N parameterized | Generalized Nth value |
| 3 | Department Highest Salary | LC 184 | Medium | Top-1 per group | MAX per partition |
| 4 | Department Top Three Salaries | LC 185 | Hard | Top-3 DENSE_RANK | Most-asked SQL interview problem |
| 5 | Game Play Analysis I | LC 511 | Easy | Top-1 (first date) | MIN per group = first event |
| 6 | Latest Order Per Customer | Common | Easy | Top-1 (most recent) | ROW_NUMBER = 1, ORDER DESC |
| 7 | Top 3 Products Per Category | DataLemur | Medium | Top-N per partition | Classic product ranking |
| 8 | Most Recent Transaction | StrataScratch | Medium | Top-1 with tiebreak | ROW_NUMBER with secondary sort |
| 9 | Highest Salary Per Department | HackerRank | Easy | Top-1 per group | Basic PARTITION BY + RANK |
| 10 | Market Analysis II | LC 1159 | Medium | 2nd item per seller | ROW_NUMBER = 2 per group |

---

## Complete 20-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Game Play Analysis I | LC 511 | MIN per group | First login per player |
| 2 | Highest Salary Per Department | HackerRank | MAX per group | Top-1 salary per dept |
| 3 | Latest Order Per Customer | Common | ROW_NUMBER = 1 | Most recent order, ORDER DESC |
| 4 | Second Highest Salary | LC 176 | Top-2, handle NULL | DENSE_RANK or LIMIT OFFSET |
| 5 | First Login Date | DataLemur | MIN per group | MIN(date) per user |
| 6 | Most Expensive Product Per Category | Common | MAX per group | Top-1 price per category |

### Medium (Problems 7-15) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 7 | Department Highest Salary | LC 184 | Top-1 + join | MAX per dept, join for full row |
| 8 | Nth Highest Salary | LC 177 | Parameterized rank | DENSE_RANK = N, handle NULLs |
| 9 | Top 3 Products Per Category | DataLemur | Top-3 per partition | DENSE_RANK <= 3 per category |
| 10 | Market Analysis II | LC 1159 | 2nd item per seller | ROW_NUMBER = 2, handle missing |
| 11 | Most Recent Transaction Per User | StrataScratch | Top-1 with tiebreak | ROW_NUMBER ORDER BY date DESC, id DESC |
| 12 | Product Price at Given Date | LC 1164 | Top-1 before date | Latest price change before cutoff |
| 13 | Best Seller Per Region | Common | Top-1 + SUM | Aggregate first, then rank |
| 14 | Top N Students Per Course | Common | Top-N flexible | Parameterized N per partition |
| 15 | Last Login Per User | DataLemur | DISTINCT ON / RN=1 | PostgreSQL DISTINCT ON shortcut |

### Hard (Problems 16-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 16 | Department Top Three Salaries | LC 185 | DENSE_RANK <= 3 | The classic hard problem |
| 17 | Median Employee Salary | LC 569 | Middle rank | ROW_NUMBER for median position |
| 18 | Tournament Winners | LC 1194 | Aggregate + rank | SUM scores, then top-1 per group |
| 19 | Top 3 Wineries Per Country | StrataScratch | Multi-criteria rank | Rank by score, tiebreak by name |
| 20 | Top Percentile Per Group | Advanced | PERCENT_RANK | Top 10% per department |

---

## Problem-by-Problem Strategy Notes

### Problem 4: Department Top Three Salaries (LC 185)

```
Pattern:     DENSE_RANK + PARTITION BY + filter
Approach:    CTE: DENSE_RANK() OVER (PARTITION BY deptId ORDER BY salary DESC)
             Outer: WHERE drnk <= 3
Key Insight: DENSE_RANK because "top 3 salaries" = top 3 distinct values
One-liner:   Dense rank per dept by salary desc; filter top 3 in outer query.
```

### Problem 2: Nth Highest Salary (LC 177)

```
Pattern:     Parameterized rank
Approach:    CTE: DENSE_RANK() OVER (ORDER BY salary DESC) AS drnk
             Outer: WHERE drnk = N
             Return NULL if no Nth row exists: wrap in IFNULL or handle in function
Key Insight: Must return NULL (not empty) if fewer than N distinct salaries
One-liner:   Dense rank descending; pick rank = N; return NULL if not found.
```

### Problem 10: Market Analysis II (LC 1159)

```
Pattern:     Nth item per group
Approach:    ROW_NUMBER() OVER (PARTITION BY seller_id ORDER BY sale_date) AS rn
             Filter WHERE rn = 2
             LEFT JOIN from users to handle sellers with no 2nd item
Key Insight: Some sellers may not have a 2nd sale — need LEFT JOIN
One-liner:   Row number per seller by date; pick rn=2; left join for missing.
```

### Problem 17: Median Employee Salary (LC 569)

```
Pattern:     Middle position via ROW_NUMBER
Approach:    ROW_NUMBER and COUNT per dept partition
             Median rows: WHERE rn IN (FLOOR((cnt+1)/2), CEIL((cnt+1)/2))
Key Insight: Even count = average of two middle rows; odd = exact middle
One-liner:   ROW_NUMBER and COUNT per dept; filter to middle position(s).
```

---

## Pattern Distribution

```
TOP-1 PER GROUP (latest/max/first):      8 problems  (1-3, 5-7, 12, 15)
TOP-N PER GROUP (N > 1):                 6 problems  (4, 8-9, 14, 16, 19)
NTH VALUE (specific rank):              3 problems  (4, 8, 10)
AGGREGATE THEN RANK:                    2 problems  (13, 18)
PERCENTILE / MEDIAN:                    2 problems  (17, 20)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 511, HackerRank highest salary (top-1)
- Day 2: LC 176, LC 177 (2nd highest, Nth highest)
- Day 3: LC 184 (dept highest — top-1 per group)

### Week 2: Core Top-N (Days 4-6)
- Day 4: LC 185 (dept top 3 — the key problem)
- Day 5: LC 1159, DataLemur top 3 products (Nth and top-N)
- Day 6: LC 1164, tiebreak problems

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 569 (median), LC 1194 (tournament)
- Day 8: Percentile, multi-criteria ranking
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| All window functions | Pattern 01 (Window Functions) — broader coverage |
| Running total not ranking | Pattern 07 (Running Total) — SUM OVER |
| Dedup keeping latest | Pattern 12 (Deduplication) — ROW_NUMBER = 1 special case |
| Correlated approach | Pattern 05 (Subquery/EXISTS) — COUNT DISTINCT < N |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (6 Easy, 9 Medium, 5 Hard)
MUST-DO:            LC 176, 177, 184, 185, 511, 1159 + DataLemur/StrataScratch
TOP 3 MOST ASKED:   LC 185 (Top 3 Salaries), LC 184 (Highest), LC 177 (Nth)
PATTERN SPLIT:      Top-1 (8), Top-N (6), Nth value (3), Agg+Rank (2), Percentile (2)
STUDY ORDER:        Top-1 → Nth value → Top-N → Aggregate+Rank → Percentile
KEY INSIGHT:        CTE + ROW_NUMBER/DENSE_RANK + WHERE rn <= N = universal template
INTERVIEW LINE:     "I use ROW_NUMBER for exactly N rows per group,
                     DENSE_RANK for top N distinct values per group,
                     wrapped in a CTE with PARTITION BY and filtered in outer query."
```

---

## 30-SECOND REVISION BOX

```
TEMPLATE:      WITH r AS (ROW_NUMBER() OVER (PARTITION BY g ORDER BY v DESC) AS rn)
               SELECT * FROM r WHERE rn <= N
ROW_NUMBER:    Exactly N rows per group (arbitrary tiebreak)
DENSE_RANK:    Top N distinct values (ties included, may get > N rows)
RANK:          Like DENSE_RANK but with gaps (rarely used for top-N)
TOP-1:         ROW_NUMBER = 1 — most recent, highest, first, latest
NTH:           ROW_NUMBER = N or DENSE_RANK = N — specific position
NULL HANDLING: Return NULL if Nth doesn't exist — IFNULL / COALESCE
TIEBREAK:      Add secondary ORDER BY column for deterministic results
RULE:          Window functions can't go in WHERE — always wrap in CTE
```
