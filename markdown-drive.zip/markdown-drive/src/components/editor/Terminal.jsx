import { useRef, useEffect, useCallback, useImperativeHandle, forwardRef, memo } from 'react';
import { Terminal as XTerm } from '@xterm/xterm';
import { FitAddon } from '@xterm/addon-fit';
import '@xterm/xterm/css/xterm.css';

const THEME_DARK = {
  background: '#0d0d0d',
  foreground: '#cdd6f4',
  cursor: '#f5e0dc',
  cursorAccent: '#0d0d0d',
  selectionBackground: '#45475a',
  selectionForeground: '#cdd6f4',
  black: '#45475a',
  red: '#f38ba8',
  green: '#a6e3a1',
  yellow: '#f9e2af',
  blue: '#89b4fa',
  magenta: '#cba6f7',
  cyan: '#94e2d5',
  white: '#bac2de',
  brightBlack: '#585b70',
  brightRed: '#f38ba8',
  brightGreen: '#a6e3a1',
  brightYellow: '#f9e2af',
  brightBlue: '#89b4fa',
  brightMagenta: '#cba6f7',
  brightCyan: '#94e2d5',
  brightWhite: '#a6adc8',
};

const THEME_LIGHT = {
  background: '#f9fafb',
  foreground: '#4c4f69',
  cursor: '#dc8a78',
  cursorAccent: '#f9fafb',
  selectionBackground: '#acb0be',
  selectionForeground: '#4c4f69',
  black: '#5c5f77',
  red: '#d20f39',
  green: '#40a02b',
  yellow: '#df8e1d',
  blue: '#1e66f5',
  magenta: '#8839ef',
  cyan: '#179299',
  white: '#acb0be',
  brightBlack: '#6c6f85',
  brightRed: '#d20f39',
  brightGreen: '#40a02b',
  brightYellow: '#df8e1d',
  brightBlue: '#1e66f5',
  brightMagenta: '#8839ef',
  brightCyan: '#179299',
  brightWhite: '#bcc0cc',
};

const TerminalComponent = memo(forwardRef(function TerminalComponent({ theme = 'dark', onExecDone }, ref) {
  const containerRef = useRef(null);
  const termRef = useRef(null);
  const fitRef = useRef(null);
  const runningRef = useRef(false);
  const abortRef = useRef(null);
  const onExecDoneRef = useRef(onExecDone);

  useEffect(() => { onExecDoneRef.current = onExecDone; }, [onExecDone]);

  useEffect(() => {
    const term = new XTerm({
      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace",
      fontSize: 13,
      lineHeight: 1.4,
      cursorBlink: true,
      cursorStyle: 'bar',
      theme: theme === 'dark' ? THEME_DARK : THEME_LIGHT,
      allowProposedApi: true,
      scrollback: 5000,
      convertEol: false,
      disableStdin: true,
    });

    const fit = new FitAddon();
    term.loadAddon(fit);

    termRef.current = term;
    fitRef.current = fit;

    if (containerRef.current) {
      term.open(containerRef.current);
      fit.fit();
    }

    term.write('\x1b[38;5;245m$ Ready — write your code and hit Run\x1b[0m\r\n');

    const resizeObserver = new ResizeObserver(() => {
      try { fit.fit(); } catch { /* ignore */ }
    });
    if (containerRef.current) resizeObserver.observe(containerRef.current);

    return () => {
      resizeObserver.disconnect();
      term.dispose();
    };
  }, []);

  useEffect(() => {
    if (termRef.current) {
      termRef.current.options.theme = theme === 'dark' ? THEME_DARK : THEME_LIGHT;
    }
  }, [theme]);

  const executeViaRest = useCallback(async (code, language, stdin) => {
    const term = termRef.current;
    if (!term) return;

    const controller = new AbortController();
    abortRef.current = controller;

    term.write(`\x1b[38;5;245mExecuting ${language}...\x1b[0m\r\n`);

    const startTime = Date.now();

    try {
      const isSql = ['sqlite', 'mysql', 'oracle', 'sql'].includes(language);
      const url = isSql ? '/api/sql/execute' : '/api/execute';
      
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code: code, language, stdin: stdin || '' }),
        signal: controller.signal,
      });

      const result = await res.json();
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(2);

      if (!res.ok) {
        term.write(`\x1b[31m${result.error || 'Execution failed'}\x1b[0m\r\n`);
        term.write(`\r\n\x1b[31m--- Error ---\x1b[0m\r\n`);
        runningRef.current = false;
        if (onExecDoneRef.current) {
          onExecDoneRef.current({ exitCode: 1, time: elapsed });
        }
        return;
      }

      if (result.compile_output) {
        const text = result.compile_output.replace(/\n/g, '\r\n');
        term.write(`\x1b[33m${text}\x1b[0m`);
        if (!text.endsWith('\r\n')) term.write('\r\n');
      }

      if (result.stdout) {
        const text = result.stdout.replace(/\n/g, '\r\n');
        term.write(text);
        if (!text.endsWith('\r\n')) term.write('\r\n');
      }

      if (result.stderr) {
        const text = result.stderr.replace(/\n/g, '\r\n');
        term.write(`\x1b[31m${text}\x1b[0m`);
        if (!text.endsWith('\r\n')) term.write('\r\n');
      }

      const statusId = result.status?.id ?? result.status;
      const exitCode = statusId === 3 ? 0 : (typeof statusId === 'number' ? statusId : 1);

      if (exitCode === 0) {
        term.write(`\r\n\x1b[32m--- Exited with code 0 ---\x1b[0m\r\n`);
      } else {
        const desc = result.status?.description || `code ${exitCode}`;
        term.write(`\r\n\x1b[31m--- ${desc} ---\x1b[0m\r\n`);
      }

      runningRef.current = false;
      if (onExecDoneRef.current) {
        onExecDoneRef.current({
          exitCode,
          time: result.time || elapsed,
          memory: result.memory || null,
          engine: result.engine || null,
        });
      }
    } catch (err) {
      runningRef.current = false;
      if (err.name === 'AbortError') {
        term.write(`\r\n\x1b[33m--- Execution cancelled ---\x1b[0m\r\n`);
        if (onExecDoneRef.current) {
          onExecDoneRef.current({ exitCode: -1, time: null });
        }
      } else {
        term.write(`\x1b[31mNetwork error: ${err.message}\x1b[0m\r\n`);
        term.write(`\r\n\x1b[31m--- Error ---\x1b[0m\r\n`);
        if (onExecDoneRef.current) {
          onExecDoneRef.current({ exitCode: -1, time: null, error: err.message });
        }
      }
    }
  }, []);

  useImperativeHandle(ref, () => ({
    runCode: (code, language, stdin) => {
      const term = termRef.current;
      if (!term) return;

      if (abortRef.current) {
        abortRef.current.abort();
        abortRef.current = null;
      }

      term.clear();
      term.write('\x1b[2J\x1b[H');

      runningRef.current = true;
      executeViaRest(code, language, stdin);
    },
    clear: () => {
      if (termRef.current) {
        termRef.current.clear();
        termRef.current.write('\x1b[2J\x1b[H\x1b[38;5;245m$ Ready\x1b[0m\r\n');
      }
    },
    kill: () => {
      if (abortRef.current) {
        abortRef.current.abort();
        abortRef.current = null;
      }
      runningRef.current = false;
      if (onExecDoneRef.current) {
        onExecDoneRef.current({ exitCode: -1, time: null });
      }
    },
    isRunning: () => runningRef.current,
  }), [executeViaRest]);

  return (
    <div className="ce-xterm" ref={containerRef} />
  );
}));

export default TerminalComponent;
