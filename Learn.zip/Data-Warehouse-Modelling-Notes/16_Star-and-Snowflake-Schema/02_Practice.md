# Star and Snowflake Schema — Practice

> "Analysts vote with their joins—star schemas win most elections."

---

## Quick Recall

**Q: Define a star schema.**  
A: Facts surrounded by denormalized dimensions; typically one join hop from fact to any attribute.

**Q: Define a snowflake schema.**  
A: Normalized dimensions split into sub-tables (e.g., category split from product) creating multi-hop joins.

**Q: Primary advantage of star for retail BI?**  
A: Simpler SQL, predictable performance, intuitive modeling for self-service users.

**Q: When might snowflake still appear in a warehouse?**  
A: Staging/master data layers, very large shared hierarchies, or strict data stewardship boundaries.

**Q: Galaxy / constellation schema?**  
A: Multiple facts sharing conformed dimensions—common in e-commerce (sales + returns + clicks).

---

## Interview Questions

**1. Compare star vs snowflake for a national retailer dashboard.**  
Say: Prefer star for store sales, inventory, and labor facts with wide `dim_store` and `dim_product`. Snowflake only where normalization saves measurable storage and duplicate maintenance is automated.

**2. How does snowflake affect query optimizers on cloud warehouses?**  
Say: Modern columnar engines handle joins well, but extra hops still complicate models and row access policies—measure representative queries.

**3. Explain constellation with an e-commerce example.**  
Say: `fact_order_line`, `fact_cart_event`, and `fact_page_view` all use `dim_customer` and `dim_product` where applicable for funnel and revenue in one semantic model.

**4. Is a snowflake always 3NF?**  
Say: Not necessarily full 3NF—partial snowflaking is common; degree of normalization is a design choice.

**5. Security angle?**  
Say: More dimension tables mean more row-level security definitions—star reduces policy surface area.

**6. Fact table in star only—can dimensions snowflake?**  
Say: Yes; star refers to the fact-centric join pattern; dimensions may still be lightly snowflaked behind views.

**7. Migration from snowflake to star?**  
Say: Build denormalized `dim_product_current` via ETL, keep normalized sources for MDM, point BI to the wide dimension.

---

## Scenario-Based Exercises

**Scenario 1 — Logical star for online orders**  
Facts: `fact_order_line`. Dimensions: `dim_date`, `dim_customer`, `dim_product`, `dim_promotion`, `dim_fulfillment_center`, `dim_payment_type`.  
**Solution:** All dimensions single-table; promotion role optional; shipment uses accumulating snapshot separately.

**Scenario 2 — Partial snowflake**  
`dim_product` references `dim_brand` when brand is shared with `dim_supplier_product`.  
**Solution:** Physical snowflake on brand; expose `vw_dim_product_star` joining brand for analysts.

**Scenario 3 — SQL pattern: star join**

```sql
SELECT
    d.calendar_month,
    s.region,
    p.category_name,
    SUM(f.net_sales) AS net_sales,
    SUM(f.quantity) AS units
FROM dw.fact_order_line f
JOIN dw.dim_date d ON f.order_date_key = d.date_key
JOIN dw.dim_store s ON f.store_key = s.store_key
JOIN dw.dim_product p ON f.product_key = p.product_key
WHERE d.calendar_year = 2026
GROUP BY 1, 2, 3;
```

**Scenario 4 — When snowflake is justified**  
Global retailer with 30 languages of product description stored per locale in `dim_product_locale` keyed by `product_key` and `language_key`.  
**Solution:** Snowflake locale off product to avoid 30 columns in the main dimension while keeping sales facts narrow.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| "Snowflake is more professional" | Academic bias | Choose based on usability and SLAs |
| Mixing staging 3NF with mart star | Confusing layers | Name layers: raw, conformed, mart |
| Too many facts without conformation | Broken drill-across | Conform keys before more facts |
| Views hiding 6-way joins | Surprise latency | Document physical vs logical model |

---

## One-Liner Answers

- Star schema minimizes joins between facts and descriptive context.
- Snowflake normalizes dimensions, trading simplicity for storage or governance benefits.
- Constellation designs link multiple facts through shared conformed dimensions.
- Default to star for retail marts unless measurement proves snowflake value.
- Use views to present stars even when MDM remains normalized underneath.
- Performance tuning starts with grain, keys, and pruning—schema style is secondary but real.
