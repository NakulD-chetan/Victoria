# Python History and Basics

> *"Beautiful is better than ugly"* — Zen of Python (Tim Peters)

This file covers Python's origin, philosophy, execution model, and your first program. Read it carefully — Python is everywhere today (data science, web, automation, interviews); keep your foundation strong.

---

## 1. Python's history

### Guido van Rossum and 1991

- **Guido van Rossum** designed Python — from the Netherlands; later the community's **BDFL** (Benevolent Dictator For Life)
- **1991** — first release; the goal was a readable language
- Inspiration: **ABC language** (teaching language) + experience from the **Amoeba OS** distributed systems project
- The name comes from the **Monty Python** comedy group — a bit of fun even for serious folks

### Python 2 vs Python 3

| Aspect | Python 2 | Python 3 |
|--------|----------|----------|
| print | `print "hi"` statement style | `print("hi")` function |
| Strings | bytes/unicode confusion | clear `str` (Unicode) model |
| Integer division | `3/2` → `1` | `3/2` → `1.5` (true division) |
| Status | EOL 2020 — meaning officially ended | Active, use this |

**Watch Out!** Always write **new projects in Python 3**. In interviews you should be clear on Py2 vs Py3 differences.

### Versions (high level)

| Milestone | Note |
|-----------|------|
| 3.0 | Breaking changes from Py2 |
| 3.5+ | async/await matured |
| 3.10+ | `match`/`case` structural pattern matching |
| 3.11+ | Performance improvements (faster interpreter) |

**Interview Tip:** "Why Python 3?" — Unicode by default, cleaner model, modern features, community support.

---

## 2. Interpreted vs compiled — Python's model

### Simple picture

- **C/C++:** Source → **Compiler** → machine code → the OS runs it
- **Python (CPython):** Source → **Interpreter** compiles to bytecode (`.pyc` cache) → **PVM** (Python Virtual Machine) runs it

Meaning: people usually call Python an **interpreted language**, but under the hood there is **bytecode** too — a hybrid picture is accurate.

| Term | Meaning |
|------|---------|
| Source (.py) | Your readable code |
| Bytecode | Intermediate representation — portable |
| PVM | Runs the bytecode |

**Watch Out!** "Python is slow" — often because of I/O or the algorithm; **PyPy**, **C extensions**, **vectorized NumPy** can give you speed.

---

## 3. Zen of Python

Run this in the REPL:

```python
import this
```

Some famous lines:

```text
Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Readability counts.
There should be one-- and preferably only one --obvious way to do it.
```

**Interview Tip:** Don't quote Zen by rote — explain the **meaning**: readability, explicit APIs, simple design.

---

## 4. Dynamic typing

- When you create a variable you **don't have to write the type**
- The object's **type** is decided at **runtime**
- The same name can point to a different type at a different time (rebinding)

```python
x = 10        # int object
x = "hello"   # now x refers to a string object
```

| Static (C++) | Dynamic (Python) |
|--------------|------------------|
| `int x = 5;` | `x = 5` |
| Compile-time type checks (many) | Errors possible at runtime |

**Watch Out!** Dynamic ≠ weak — Python has **strong typing**: `3 + "a"` raises an error; it won't do weird implicit mixing.

---

## 5. REPL (Read-Eval-Print Loop)

> **Definition:** A REPL (Read-Eval-Print Loop) is an interactive session that reads a line or snippet, evaluates it, prints the result, and repeats.

**Why we need it:** It gives instant feedback for learning, quick experiments, and checking behavior without writing and running a full script each time.

**Syntax:**
```python
>>> <statement_or_expression>
```

- In the terminal type `python` or `python3` → interactive shell
- Try line by line — best for learning
- Exit: `exit()` or `Ctrl+Z` (Windows) / `Ctrl+D` (Unix)

```python
>>> 2 + 2
4
>>> name = "Python"
>>> name.lower()
'python'
```

---

## 6. First program — script vs REPL

### Script file (`hello.py`)

```python
def main():
    print("Hello, Python!")

if __name__ == "__main__":
    main()
```

Run: `python hello.py`

### Simple first program (teacher style)

```python
print("Hello, Python!")
```

**Interview Tip:** `if __name__ == "__main__":` — stops auto-run when the module is imported; details in [[13-Python-Modules-Packages]].

---

## 7. Installation and `python -V`

```bash
python --version
# Python 3.12.x
```

- **pip** — package installer (packages in [[13-Python-Modules-Packages]])
- **venv** — isolated environments

---

## 8. PEP 8 and readable code (intro)

> **Definition:** PEP 8 is the community style guide for Python: conventions for layout, naming, imports, and line length so code looks and reads consistently.

**Why we need it:** Shared rules reduce pointless debates, make teamwork smoother, and align everyday style with Python’s emphasis on readability (“Pythonic” code).

**Syntax:**
```python
def <snake_case_name>(<parameters>):
    """<docstring>."""
    <body_indented_with_four_spaces>
```

**PEP 8** — the Python community's style guide. In oral exams they sometimes ask "What is Pythonic code?"

| Guideline | Example |
|-----------|---------|
| Indent | 4 spaces (don't mix tabs) |
| Names | `snake_case` for functions/vars, `PascalCase` for classes |
| Imports | stdlib → third party → local; one-per-line style varies by team |
| Line length | Often 88 (`black`) or classic 79 — team decides |

```python
def total_price(qty: int, unit: float) -> float:
    return qty * unit
```

**Interview Tip:** "Readability counts" — Zen and PEP 8 point the same way.

---

## 9. `python -m` — running a module

```bash
python -m venv .venv
python -m http.server 8000
python -m pytest
```

Runs with package context — `sys.path` behavior stays clear.

**Watch Out!** Use `python`/`pip` **after** activating the virtual environment when the project should be isolated.

---

## 10. Oral-exam style rapid Q&A

| Question | Short answer |
|----------|----------------|
| Is Python compiled? | Bytecode + PVM — hybrid; people often say "interpreted" |
| Strong vs weak typing? | Strong — little weird implicit mixing |
| Why did Py2 end? | Unicode model, maintenance, community moved |
| What's the benefit of the REPL? | Quick experiments, teaching |

---

## Quick Memory Card

```
+------------------------------------------+
| PYTHON HISTORY                            |
| - Guido van Rossum, 1991                 |
| - ABC language inspiration               |
| - Use Python 3 (Py2 EOL)                 |
+------------------------------------------+
| EXECUTION                                 |
| - CPython: source → bytecode → PVM       |
| - Called "interpreted" (hybrid)        |
+------------------------------------------+
| ZEN / STYLE                               |
| - Readable, explicit, simple             |
| - import this                            |
+------------------------------------------+
| DYNAMIC TYPING                            |
| - No type declaration on variable        |
| - Strong typing (no crazy coercion)      |
+------------------------------------------+
| REPL                                      |
| - python → try snippets                  |
+------------------------------------------+
```

---

*Next: [[02-Python-Variables-DataTypes-IO]]*
