# Microservices Architecture — Question List

> **Permanent Recall:** 10 MUST-DO questions cover monolith vs microservices, API gateway, service mesh, Saga, service boundaries, and migration. Full list includes 25+ questions with difficulty and company tags. Practice explaining tradeoffs, not just definitions.

---

## 10 MUST-DO Microservices Questions

| # | Question | Concepts Tested | Difficulty |
|---|----------|-----------------|------------|
| 1 | Monolith vs Microservices—when to use each? | Tradeoffs, team, scale | Medium |
| 2 | What is an API Gateway? What does it do? | Routing, auth, rate limit | Easy |
| 3 | Design an e-commerce system with microservices. How do you split? | Service boundaries, DDD | Medium |
| 4 | How do microservices communicate? Sync vs async? | REST, gRPC, message queue | Medium |
| 5 | What is a service mesh? Why use it? | Sidecar, Istio, mTLS | Medium |
| 6 | How do you handle distributed transactions? Explain Saga. | Saga, 2PC | Hard |
| 7 | What is the Strangler Fig pattern? When do you use it? | Migration from monolith | Medium |
| 8 | Database per service—why? What are the challenges? | Data ownership, consistency | Medium |
| 9 | What is a circuit breaker? Why is it important? | Resilience, cascading failure | Easy |
| 10 | How do you migrate a monolith to microservices? | Strangler Fig, incremental | Medium |

---

## Complete Question List (25+)

### Monolith vs Microservices

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 1 | Monolith vs Microservices—pros and cons? | Medium | Google, Meta |
| 2 | When would you choose monolith over microservices? | Medium | Amazon |
| 3 | What is a modular monolith? | Easy | — |
| 4 | Microservices add operational complexity. How do you justify them? | Hard | Netflix |

### API Gateway & Service Mesh

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 5 | What is an API Gateway? Responsibilities? | Easy | All |
| 6 | API Gateway vs Service Mesh—difference? | Medium | Netflix, Uber |
| 7 | When do you need a service mesh? | Medium | Google |
| 8 | Explain the sidecar pattern. | Easy | — |
| 9 | Istio vs Linkerd—when to use which? | Hard | — |

### Service Discovery & Communication

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 10 | Client-side vs server-side service discovery? | Medium | Netflix |
| 11 | How does Kubernetes service discovery work? | Medium | — |
| 12 | REST vs gRPC for inter-service communication? | Medium | Google |
| 13 | When to use sync vs async between services? | Medium | Amazon |
| 14 | What is a BFF? When do you need it? | Medium | — |

### Distributed Transactions & Saga

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 15 | How do you handle transactions across multiple services? | Hard | Amazon, Stripe |
| 16 | Explain the Saga pattern. Choreography vs orchestration? | Hard | — |
| 17 | Saga vs 2PC—when to use each? | Hard | — |
| 18 | How do you handle partial failure in a Saga? | Hard | — |

### Patterns & Migration

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 19 | Explain Strangler Fig migration. | Medium | Amazon |
| 20 | Database per service—challenges? | Medium | — |
| 21 | What is the circuit breaker pattern? | Easy | Netflix |
| 22 | How do you ensure data consistency across services? | Hard | — |
| 23 | Explain the Outbox pattern. | Medium | — |

### Design Integration

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 24 | Design Uber with microservices. | Hard | Uber |
| 25 | Design Netflix with microservices. | Hard | Netflix |
| 26 | Design an e-commerce checkout flow across services. | Hard | Amazon |
| 27 | How do you handle service versioning? | Medium | — |
| 28 | Design for cascading failure prevention. | Medium | — |

---

## Concepts Tested by Question Type

| Concept | Easy | Medium | Hard |
|---------|------|--------|------|
| **Monolith vs Micro** | | 1, 2, 3 | 4 |
| **API Gateway** | 5 | 6 | |
| **Service Mesh** | 8 | 7, 9 | |
| **Discovery** | | 10, 11 | |
| **Communication** | | 12, 13, 14 | |
| **Saga/Transactions** | | | 15, 16, 17, 18 |
| **Migration** | | 19, 21 | |
| **DB per service** | | 20 | |
| **Design** | | | 24, 25, 26 |

---

## Suggested Practice Order

**Week 1: Fundamentals**
- Questions 1, 2, 5, 8, 21 (monolith vs micro, gateway, sidecar, circuit breaker)

**Week 2: Communication & Discovery**
- Questions 10, 11, 12, 13, 14 (discovery, REST/gRPC, sync/async, BFF)

**Week 3: Service Mesh & Patterns**
- Questions 6, 7, 9, 19, 20 (mesh, Strangler Fig, DB per service)

**Week 4: Saga & Transactions**
- Questions 15, 16, 17, 18, 22 (Saga, 2PC, partial failure, consistency)

**Week 5: Design**
- Questions 3, 24, 25, 26, 28 (e-commerce, Uber, Netflix, cascading failure)

---

## Expected Answer Depth

| Level | What to cover |
|-------|---------------|
| **Brief** | 1–2 sentences; e.g., "API Gateway routes, authenticates, rate limits." |
| **Standard** | 3–5 sentences; tradeoffs; e.g., "Monolith simpler; microservices for scale and teams." |
| **Deep** | Full explanation; diagram; alternatives; edge cases. |

---

## Quick Memory Card

```
MUST-DO:        1–10: monolith vs micro, gateway, mesh, Saga, migration
MONOLITH/MICRO: 1–4
GATEWAY/MESH:    5–9
DISCOVERY/COMM: 10–14
SAGA:           15–18
PATTERNS:       19–23
DESIGN:         24–28
```

---

**Prev: [[07_Tricks-and-Recognition]] | Next: [[01_Concept]] (cycle back)**
