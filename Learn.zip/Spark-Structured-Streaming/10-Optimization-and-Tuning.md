# Optimization & Tuning (Structured Streaming)

Structured Streaming inherits **Catalyst** and **Tungsten** optimizations **within** each micro-batch. Streaming-specific tuning targets **trigger cadence**, **shuffle parallelism**, **state footprint**, and **source/sink** integration. This note collects **theory-level** levers—not a substitute for profiling your workload.

---

## 1. Catalyst in Streaming

Per micro-batch, many **batch** rules still apply:

- **Predicate pushdown** to columnar sources (Parquet, Kafka with selective reads where supported).
- **Column pruning** and **expression simplification**.

**Caveat:** Stateful operators add **incremental** physical nodes—generic batch rules may not apply across triggers; global optimization is **per epoch**, not one giant DAG for all history.

---

## 2. Shuffle Partitions & Parallelism

| Knob (typical) | Effect |
| -------------- | ------ |
| `spark.sql.shuffle.partitions` | Number of tasks for shuffle-heavy stages—too **low** → long tasks; too **high** → scheduler overhead. |
| Input partition count (Kafka) | Linked to topic partitions—cannot parallelize reads beyond partition count without repartitioning downstream. |

**Guideline:** Align shuffle partitions with **sustained throughput** and **cluster cores**, revisiting after measuring **batch duration**.

---

## 3. Trigger Tuning

| Shorter trigger | Longer trigger |
| ---------------- | -------------- |
| Lower latency | Higher per-batch throughput (amortized overhead) |
| More scheduling overhead | Possibly larger state merge bursts |

Balance against **P95 batch duration**—triggers faster than completion time **build lag**.

---

## 4. Watermark & State Size

Increasing **watermark delay**:

- **Increases** lateness tolerance and **state** retention.
- **Decreases** droppable late volume—**accuracy** vs **memory**.

Decreasing delay does the opposite—**test** on representative skew and disorder.

---

## 5. Serialization & Memory

Same family of concerns as batch:

- **Kryo** registration for custom types in **mapGroupsWithState** paths.
- Avoid **giant** objects in state; prefer **primitive** aggregates or **compact** sketches.

---

## 6. Observability

Use **StreamingQuery** progress metrics and Spark UI **per micro-batch**:

- **Input rate**, **batch duration**, **state operators** duration.
- **Shuffle spill** indicators—sign of memory pressure in stateful stages.

Structured Streaming **UI** tab (version-dependent) simplifies inspecting **watermarks**, **lag**, and **state store** metrics where exposed.

---

## 7. foreachBatch Patterns (Conceptual)

`foreachBatch` enables **micro-batch transactions** to sinks without losing DataFrame API:

- Use **`batchId`** for **idempotent** commits.
- Coalesce **small** outputs judiciously—**avoid** giant single tasks unless intended.

---

## 8. Key Takeaways

1. **Batch tuning** applies **inside** each epoch; **streaming tuning** adds **trigger + watermark + state**.
2. **Right-size** shuffle partitions against **measured** batch times and **cluster** capacity.
3. Treat **watermark** as the **primary** memory dial for event-time stateful pipelines.
4. **Measure** end-to-end **lag** (processing time − event time) as the **health** metric for SLA adherence.

---
