# Design WhatsApp — Common Mistakes

> **Permanent Recall:** Top 10 mistakes: HTTP polling instead of WebSocket, not handling offline users, ignoring message ordering, no delivery receipts, not discussing E2E encryption, synchronous group message delivery, storing all messages in single DB, ignoring presence service, not discussing media separately, no push notifications for offline. Avoid these to pass FAANG chat system design.

---

## Mistake 1: Using HTTP Polling Instead of WebSocket

**What happens:** Client polls every few seconds; latency is high; server load is massive for little gain.

| Wrong | Right |
|-------|-------|
| "We'll poll every 2 seconds" | WebSocket for real-time; long polling as fallback only |
| Short polling (1–5s interval) | Persistent bidirectional connection |

> **FAANG Tip:** WebSocket is the default for chat. Long polling is acceptable as fallback when WebSocket is blocked (corporate firewalls).

---

## Mistake 2: Not Handling Offline Users

**What happens:** Message sent when recipient offline is lost; user never receives it.

**Fix:**
- Always store message in DB
- Send push notification (FCM/APNs)
- On reconnect: push backlog or client fetches since last `sequence_id`

---

## Mistake 3: Ignoring Message Ordering

**What happens:** Messages appear out of order; conversation is confusing.

**Fix:**
- Assign `sequence_id` per conversation
- Client displays in order; buffer out-of-order messages
- For groups: consistent ordering (e.g., single partition per group)

---

## Mistake 4: No Delivery Receipts

**What happens:** User doesn't know if message was delivered or read; poor UX.

**Fix:**
- **Sent:** Server acknowledges receipt
- **Delivered:** Recipient's device acknowledges (or server when pushed)
- **Read:** Recipient opens chat; send read receipt

---

## Mistake 5: Not Discussing E2E Encryption

**What happens:** Interviewer expects you to address privacy; you ignore it.

**Fix:** Mention "end-to-end encryption with Signal protocol. Client encrypts; server stores ciphertext and routes. Key exchange out-of-band or server-assisted." Don't need to deep-dive unless asked.

---

## Mistake 6: Synchronous Group Message Delivery

**What happens:** One message to 256 members = 256 synchronous DB writes or API calls; blocks sender; doesn't scale.

**Fix:**
- Write message **once** to DB
- Fan-out to message queue (Kafka topics or per-user queues)
- Each consumer delivers asynchronously when member is online

---

## Mistake 7: Storing All Messages in Single DB

**What happens:** One DB partition can't handle 100B messages/day; hot partitions; no scalability.

**Fix:**
- Shard by `conversation_id` (or composite key)
- Use Cassandra, DynamoDB, or similar for write scalability
- Partition per conversation for locality

---

## Mistake 8: Ignoring Presence Service

**What happens:** No way to show "online" or "last seen"; core WhatsApp feature missing.

**Fix:**
- Heartbeat every 30–60s from client
- Redis: `SET user:X:online 1 EX 90` (TTL)
- On disconnect: set `last_seen` timestamp

---

## Mistake 9: Not Discussing Media Separately

**What happens:** Treating 10MB video like 100-byte text; blocks message pipeline.

**Fix:**
- Separate upload flow: `POST /media/upload` → S3 → URL
- Message contains URL, not raw bytes
- CDN for delivery; lazy load on client

---

## Mistake 10: No Push Notifications for Offline

**What happens:** User closes app; message stored but user never knows; no notification.

**Fix:**
- After storing message: call Notification Service
- FCM (Android), APNs (iOS) for push
- Payload: conversation_id, sender, snippet (or generic "New message")

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| HTTP polling | High latency, waste | WebSocket |
| No offline handling | Lost messages | Store + push + deliver on reconnect |
| No message ordering | Confusing UX | sequence_id per conversation |
| No receipts | Poor UX | Sent → delivered → read |
| No E2E mention | Privacy gap | Signal protocol |
| Sync group delivery | Doesn't scale | Fan-out via queue |
| Single DB | Bottleneck | Shard by conversation_id |
| No presence | Missing feature | Heartbeat + TTL |
| Media in pipeline | Blocks, slow | Separate upload, URL in message |
| No push | Offline users miss messages | FCM/APNs |

---

## Interviewer Signals

When interviewer says "What about when the user is offline?" → Mistake 2.
When they ask "How do you scale group chat?" → Mistake 6.
When they mention "privacy" → Mistake 5.
When they ask "How do you know if someone is online?" → Mistake 8.

---

## 30-SECOND REVISION BOX

```
1. WebSocket, not HTTP polling
2. Offline: store + push + reconnect deliver
3. sequence_id for ordering
4. Sent → delivered → read receipts
5. E2E: Signal protocol
6. Group: fan-out, write once
7. Shard messages by conversation
8. Presence: heartbeat + TTL
9. Media: separate upload, URL
10. Push when offline
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
