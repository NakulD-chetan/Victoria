# Security and Authentication — Edge Cases

> **Permanent Recall:** Critical edge cases: token theft (short TTL, rotation, revoke), refresh token rotation race condition (concurrent requests), JWT size limit (cookie/header limits), session fixation (regenerate ID on login), CORS preflight issues (OPTIONS, credentials), OAuth redirect URI manipulation (strict validation), token revocation in stateless auth (blacklist, short TTL), time-based attacks (constant-time compare). Know these for "what if" questions in FAANG interviews.

---

## Edge Case 1: Token Theft

**Cause:** Access or refresh token stolen (XSS, MITM, malware, logged).

**Symptom:** Attacker uses token to impersonate user; may persist if refresh not rotated.

**Mitigation:**

| Approach | How | Trade-off |
|----------|-----|-----------|
| **Short TTL** | Access token 15 min | Limits window; more refresh calls |
| **Refresh rotation** | New refresh on use; detect reuse | Revoke family on reuse |
| **Blacklist** | Store revoked token IDs in Redis | Extra lookup; partial statelessness |
| **Binding** | Token bound to IP/fingerprint | Can break on legit network changes |

> **FAANG Tip:** Combine short TTL + refresh rotation + optional blacklist for high-security.

---

## Edge Case 2: Refresh Token Rotation Race Condition

**Cause:** Two concurrent requests use same refresh token; both get new refresh; one invalidates the other.

**Symptom:** One request fails with "invalid refresh"; user logged out unexpectedly.

**Mitigation:**
- **Grace period:** Allow same refresh within N seconds; return cached tokens
- **Single-flight:** Only one refresh in progress per token; others wait
- **Family revocation:** If reuse after rotation, revoke entire family (theft detection)
- **Idempotency:** Same refresh in short window returns same new tokens

---

## Edge Case 3: JWT Size Limit

**Cause:** JWT in cookie or header; cookies ~4KB; some proxies limit header size.

**Symptom:** Request rejected; cookie truncated; auth fails.

**Mitigation:**
- **Minimal claims:** Only `sub`, `exp`, `iat` in access token
- **Reference token:** Store data server-side; put opaque reference in JWT
- **Separate storage:** Use HTTP-only cookie for token; don't stuff in URL
- **Compression:** Not recommended (CRIME attack); prefer smaller payload

---

## Edge Case 4: Session Fixation

**Cause:** Attacker gets user to use attacker-controlled session ID; after login, attacker has valid session.

**Symptom:** Attacker gains access after victim logs in.

**Mitigation:**
- **Regenerate on login:** Issue new session ID after successful auth
- **Regenerate on privilege change:** New ID when role/permission changes
- **Don't accept external session ID:** Never use session ID from query/body

---

## Edge Case 5: CORS Preflight Issues

**Cause:** Custom headers or methods trigger preflight (OPTIONS); misconfigured server rejects or doesn't include credentials.

**Symptom:** Preflight fails; actual request never sent; CORS error in console.

**Mitigation:**
- Handle `OPTIONS` with `Access-Control-Allow-Methods`, `Allow-Headers`
- `Access-Control-Allow-Origin` must match request `Origin` (no `*` for credentials)
- `Access-Control-Allow-Credentials: true` when sending cookies
- Cache preflight with `Access-Control-Max-Age` to reduce OPTIONS requests

---

## Edge Case 6: OAuth Redirect URI Manipulation

**Cause:** Attacker uses similar redirect URI or open redirect to steal authorization code.

**Symptom:** Code sent to attacker's domain; token theft.

**Mitigation:**
- **Exact match:** Redirect URI must match registered URI character-for-character
- **No wildcards** in redirect URI
- **HTTPS only** for production redirect URIs
- Validate redirect against allowlist before redirecting

---

## Edge Case 7: Token Revocation in Stateless Auth

**Cause:** JWT is self-contained; server doesn't store it; revoking before expiry is hard.

**Symptom:** User logs out or is banned; token still valid until `exp`.

**Mitigation:**
- **Blacklist:** Store revoked token IDs (jti) in Redis; check on each request
- **Short TTL:** 15 min access token; revocation effective in minutes
- **Version/epoch:** Include `version` in token; bump version to invalidate all
- **Hybrid:** Stateless for access; stateful for refresh (revoke refresh)

---

## Edge Case 8: Time-Based Attacks

**Cause:** String compare or hash verify leaks info via timing (early exit on first diff).

**Symptom:** Attacker can guess secrets character-by-character by measuring response time.

**Mitigation:**
- **Constant-time compare:** `hmac.compare(a, b)` or XOR then compare; don't short-circuit
- **bcrypt/Argon2:** Built-in constant-time compare
- **Avoid:** `==` or `.equals()` for secrets; use dedicated secure compare

---

## Edge Cases Summary Table

| Edge Case | Cause | Mitigation |
|-----------|-------|------------|
| Token theft | XSS, MITM, leak | Short TTL, rotation, blacklist |
| Rotation race | Concurrent refresh | Grace period, single-flight |
| JWT size | Cookie/header limit | Minimal claims, reference token |
| Session fixation | Attacker-controlled ID | Regenerate on login |
| CORS preflight | OPTIONS, credentials | Proper headers, no * with creds |
| OAuth redirect | URI manipulation | Exact match, allowlist |
| JWT revocation | Stateless | Blacklist, short TTL, version |
| Time-based | Timing leakage | Constant-time compare |

---

## 30-SECOND REVISION BOX

```
THEFT: Short TTL, rotation, revoke family
RACE: Grace period, single-flight, idempotency
JWT SIZE: Minimal claims, reference token
FIXATION: Regenerate session on login
CORS: OPTIONS, exact Origin, credentials
OAUTH REDIRECT: Exact URI match
REVOCATION: Blacklist jti, short TTL
TIMING: Constant-time compare for secrets
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
