# Linked List — Common Mistakes

> **Permanent Recall:** Top 5: (1) Losing reference to next before rewiring, (2) Not using dummy head, (3) Null pointer dereference, (4) Off-by-one in nth from end, (5) Not handling head deletion. Avoid these = avoid rejection.

---

## Mistake 1: Losing the Next Pointer During Reversal

### The Trap

```python
# WRONG: overwrite curr.next before saving it
curr.next = prev       # Lost reference to rest of list!
prev = curr
curr = curr.next       # curr.next is now prev, NOT the original next!

# RIGHT: save next FIRST
next_node = curr.next  # Save reference
curr.next = prev       # Now safe to overwrite
prev = curr
curr = next_node       # Use saved reference
```

### Why It Happens

- Pointer rewiring is destructive — once you change `curr.next`, the old value is gone
- Always save what you need BEFORE modifying

---

## Mistake 2: Not Using Dummy Head

### The Trap

```python
# WRONG: special case for head removal
def remove_elements(head, val):
    while head and head.val == val:  # Handle head separately
        head = head.next
    curr = head
    while curr and curr.next:
        if curr.next.val == val:
            curr.next = curr.next.next
        else:
            curr = curr.next
    return head

# RIGHT: dummy head makes it uniform
def remove_elements(head, val):
    dummy = ListNode(0, head)
    curr = dummy
    while curr.next:
        if curr.next.val == val:
            curr.next = curr.next.next
        else:
            curr = curr.next
    return dummy.next
```

### When to Use Dummy

- Deleting nodes (including potentially the head)
- Building a new list (merge, partition)
- Any operation where the head might change

---

## Mistake 3: Null Pointer Dereference

### The Trap

```python
# WRONG: accessing .next on null
while fast.next and fast.next.next:  # Fast might be null!
    fast = fast.next.next

# RIGHT: check fast FIRST
while fast and fast.next:
    slow = slow.next
    fast = fast.next.next
```

```cpp
// WRONG in C++: dereferencing nullptr
while (fast->next && fast->next->next)  // crash if fast is nullptr

// RIGHT: check pointer before dereferencing
while (fast && fast->next)
```

### The Rule

**Always check a pointer is non-null BEFORE accessing its members.** Order matters in `&&`.

---

## Mistake 4: Off-by-One in "Nth From End"

### The Trap

```python
# WRONG: gap of n (should be n+1 to land on node BEFORE target)
fast = head
for _ in range(n):
    fast = fast.next
slow = head
while fast:           # slow ends AT the target — can't delete it!
    slow = slow.next
    fast = fast.next

# RIGHT: use dummy head, move fast n+1 steps
dummy = ListNode(0, head)
fast = dummy
for _ in range(n + 1):
    fast = fast.next
slow = dummy
while fast:
    slow = slow.next
    fast = fast.next
slow.next = slow.next.next  # slow is BEFORE target
```

### Why Dummy Helps

- We need to reach the node **before** the target to delete it
- Dummy provides consistent gap calculation

---

## Mistake 5: Not Handling Head Deletion

### The Trap

```python
# WRONG: only handles deletion of non-head nodes
def delete_node(head, val):
    curr = head
    while curr.next:
        if curr.next.val == val:
            curr.next = curr.next.next
            return head
        curr = curr.next
    return head  # Never checks if head.val == val!

# RIGHT: check head first, OR use dummy
def delete_node(head, val):
    if head and head.val == val:
        return head.next
    curr = head
    while curr and curr.next:
        if curr.next.val == val:
            curr.next = curr.next.next
            return head
        curr = curr.next
    return head
```

---

## Mistake 6: Infinite Loop in Cycle Problems

### The Trap

```python
# WRONG: modifying list while detecting cycle → infinite loop
def has_cycle(head):
    curr = head
    while curr:
        if curr.val == "visited":  # Modifying node values!
            return True
        curr.val = "visited"
        curr = curr.next
    return False

# RIGHT: use fast/slow pointers (no modification)
def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True
    return False
```

### Why It Matters

- Modifying node values is destructive and not always allowed
- Fast/slow is the standard O(1) space approach

---

## Mistake 7: Forgetting to Terminate the List

### The Trap

```python
# WRONG: after reversing second half, old connections remain
# Reorder list: 1→2→3→4→5
# After finding middle and reversing:
# First half: 1→2→3  (but 3.next still points to 4!)
# Second half: 5→4→3  (creates cycle!)

# RIGHT: explicitly break the connection
slow.next = None  # Cut first half from second half
```

### The Rule

When splitting a list, **always set the last node's next to null.** Otherwise you create unintended cycles.

---

## Mistake 8: Wrong Merge Logic (Forgetting Remaining Nodes)

### The Trap

```python
# WRONG: only merge while BOTH have nodes, forget the rest
while l1 and l2:
    # merge logic...
# What about remaining nodes in l1 or l2?

# RIGHT: attach remaining
while l1 and l2:
    # merge logic...
curr.next = l1 or l2  # Attach whichever is left
```

---

## Mistake 9: Recursive Solutions Hitting Stack Overflow

```python
# For n = 100,000 nodes, recursive reverse hits Python stack limit (1000)
# Use iterative approach for large lists

# If you must recurse:
import sys
sys.setrecursionlimit(200000)  # Not recommended in interviews
```

### The Rule

- Mention recursion uses O(n) stack space
- Default to iterative for linked list problems
- Recursive only if specifically asked or list is small

---

## Summary Table

| Mistake | Fix |
|---------|-----|
| Lose next pointer | Save `next_node = curr.next` BEFORE rewiring |
| No dummy head | Add `dummy = ListNode(0, head)`, return `dummy.next` |
| Null dereference | Check pointer non-null BEFORE `.next` access |
| Off-by-one (nth end) | Use dummy, move fast n+1 steps |
| Head not deleted | Use dummy or explicit head check |
| Infinite loop (cycle) | Use fast/slow, don't modify nodes |
| List not terminated | Set `last.next = None` when splitting |
| Merge: forget remainder | `curr.next = l1 or l2` after loop |
| Stack overflow | Prefer iterative over recursive |

---

## FINAL MEMORY COMPRESSION BLOCK

```
1. SAVE next BEFORE rewiring: next_node = curr.next
2. DUMMY HEAD for deletions, merges, partitions
3. NULL CHECK before .next: if node and node.next
4. NTH END: dummy + n+1 gap → land BEFORE target
5. HEAD DELETION: dummy handles, or explicit check
6. CYCLE: fast/slow, don't modify nodes
7. TERMINATE: set .next = None when splitting
8. MERGE: attach leftover with curr.next = l1 or l2
9. RECURSIVE: O(n) stack — prefer iterative
```
