# Queue — Mental Model

> **How FAANG engineers think about queue problems.** Internalize these models for instant pattern recognition.

---

## "People Standing in Line" Mental Model

```
    CASHIER
       ↑
   [A][B][C][D]  ← People waiting
   ↑        ↑
 FRONT    REAR (new people join here)

- A arrived first → A gets served first
- B, C, D wait their turn
- No cutting — strict FIFO
```

**Apply to code:**

- Enqueue = person joins at back
- Dequeue = person at front gets served
- Peek = who's next? (front person)

---

## BFS = Queue-Powered Level-by-Level Exploration

```
Think: "Ripple effect" or "Water drop in pond"

        START (0)
       /   |   \
    (1)   (1)   (1)    ← Level 1: all at distance 1
    / \     \     \
  (2) (2)   (2)  (2)   ← Level 2: all at distance 2

Queue ensures: we finish ALL level-i nodes before ANY level-(i+1) node
```

ASCII fallback

```
Step 0: Queue = [S]           Visited = {S}
        [S]

Step 1: Process S, add neighbors
        [A][B][C]             Visited = {S,A,B,C}

Step 2: Process A, add its neighbors (not visited)
        [B][C][D]             Visited = {S,A,B,C,D}

Step 3: Process B, C, D...
        Level by level expands like a wave
```



### Why Queue (Not Stack)?


| Use Queue (BFS)            | Use Stack (DFS)               |
| -------------------------- | ----------------------------- |
| Level order                | Depth order                   |
| Shortest path (unweighted) | Path exists / cycle detection |
| "Closest" / "nearest"      | "Reachability"                |
| Tree: level-by-level       | Tree: pre/in/post order       |


---

## Monotonic Deque: Maintaining Order Invariant

**Mental model:** "Survival of the fittest" — only elements that can still be max/min stay.

```
Sliding Window Max (k=3):
Array: [1, 3, -1, -3, 5, 3, 6, 7]

At index 2, window [1,3,-1]:
  - 1: can 3 ever be beaten by 1? NO. 1 is useless for future windows.
  - Deque: [3, -1] (indices 1, 2) — 3 is max

At index 4, window [-1,-3,5]:
  - 5 > -1, -3 → they can NEVER be max in any window containing 5
  - Pop them. Deque: [5]
  - Front = 5 = max
```

### Invariant Visualization

```
MONOTONIC DECREASING (for MAX):
  Front ──────────────────────→ Back
  [  big  |  medium  |  small  ]
  New element arrives: kick out everyone smaller (they're obsolete)

MONOTONIC INCREASING (for MIN):
  Front ──────────────────────→ Back
  [ small |  medium  |  big   ]
  New element arrives: kick out everyone larger
```

---

```mermaid
flowchart TD
    A["Level order / BFS / Shortest path unweighted"] --> B[QUEUE BFS]
    C["Sliding window + max or min in O(n)"] --> D[MONOTONIC DEQUE]
    E["Implement queue using stacks / stack using queues"] --> F[Two stacks / Two queues]
    G["Task scheduler / Round robin / Process in order"] --> H[QUEUE]
    style B fill:#51cf66,color:#fff
    style D fill:#51cf66,color:#fff
    style F fill:#339af0,color:#fff
    style H fill:#51cf66,color:#fff
```



ASCII fallback

```
┌─────────────────────────────────────────────────────────────┐
│  "Level order" / "BFS" / "Shortest path (unweighted)"       │
│  → QUEUE (BFS)                                              │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  "Sliding window" + "max" or "min" in O(n)                   │
│  → MONOTONIC DEQUE                                          │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  "Implement queue using stacks" / "Implement stack using   │
│   queues"                                                   │
│  → Two stacks / Two queues (amortized O(1))                │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  "Task scheduler" / "Round robin" / "Process in order"       │
│  → QUEUE                                                    │
└─────────────────────────────────────────────────────────────┘
```



---

## BFS Level Tracking — Two Patterns

### Pattern A: Queue Size (Explicit Level)

```
while queue:
    level_size = len(queue)   # snapshot!
    for _ in range(level_size):
        node = queue.popleft()
        # process node
        for child in children:
            queue.append(child)
    # end of level
```

### Pattern B: Sentinel / Null Marker

```
queue = [root, None]
while queue:
    node = queue.popleft()
    if node is None:
        # level end; add new sentinel if more nodes
        if queue:
            queue.append(None)
        continue
    # process node
    for child in children:
        queue.append(child)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
QUEUE MODEL:     People in line — first in, first out
BFS MODEL:       Ripple/wave — level by level; queue = frontier
MONOTONIC:       "Kick out obsolete" — keep only potential max/min
TRIGGERS:        Level order → BFS | Window max/min → Monotonic deque
LEVEL TRACK:     level_size = len(q) before loop, or sentinel
```

