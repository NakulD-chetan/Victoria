# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. TYPES OF FACTS (VERY IMPORTANT)
==================================================

Key idea:
- Not all numbers can be summed
- You must know:
  → Can I add this?
  → Along which dimension?

Types:
1. Additive
2. Semi-Additive
3. Non-Additive


----------------------------------------
Important Quote Meaning
----------------------------------------
"Summation is a privilege, not a right"

Meaning:
- You cannot blindly use SUM()
- Some measures give wrong results if summed



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Additivity means:
- Whether a measure can be summed across a dimension

Important:
- Always say:
  "Additive along WHICH dimension?"


----------------------------------------
Example:
----------------------------------------

Measure = Sales

Can we sum:
- Across time? → YES
- Across stores? → YES

→ Additive


Measure = Inventory

Can we sum:
- Across time? → NO
- Across products? → YES

→ Semi-additive



==================================================
3. ADDITIVE FACTS
==================================================

Definition:
- Can be summed across ALL dimensions


----------------------------------------
Examples
----------------------------------------

- sale_amount
- quantity
- discount_amount


----------------------------------------
Why works?
----------------------------------------
- These are flow values (transactions)


----------------------------------------
SQL Example
----------------------------------------

SELECT
  month,
  SUM(sale_amount),
  SUM(quantity)
FROM fact_sales
GROUP BY month;


----------------------------------------
Important Note
----------------------------------------
- Must ensure:
  → same currency
  → same unit



==================================================
4. NON-ADDITIVE FACTS
==================================================

Definition:
- Cannot be summed across ANY dimension


----------------------------------------
Examples
----------------------------------------

1. Unit Price
2. Percentage
3. Temperature
4. Ratio metrics


----------------------------------------
Why SUM fails?
----------------------------------------
- No logical meaning

Example:
Price1 = 10  
Price2 = 20  

SUM = 30 ❌ (meaningless)


----------------------------------------
Correct Approach
----------------------------------------

Weighted average:

SUM(amount) / SUM(quantity)


----------------------------------------
SQL Example
----------------------------------------

SELECT
  SUM(sale_amount) / SUM(quantity) AS avg_price
FROM fact_sales;


----------------------------------------
Important Warning
----------------------------------------
Never sum percentages



==================================================
5. SEMI-ADDITIVE FACTS
==================================================

Definition:
- Can be summed across SOME dimensions
- Cannot be summed across others (usually time)


----------------------------------------
Examples
----------------------------------------

- inventory (stock level)
- account balance
- headcount


----------------------------------------
Why?
----------------------------------------
These are "state" or "snapshot" values


----------------------------------------
Example
----------------------------------------

Day 1: 100 units  
Day 2: 120 units  

SUM = 220 ❌ (wrong)

Correct:
- average
- max
- last value


----------------------------------------
SQL Example
----------------------------------------

SELECT
  AVG(on_hand_units)
FROM inventory_table;


----------------------------------------
Important Insight
----------------------------------------
Semi-additive = additive across space, not time



==================================================
6. DIMENSION-WISE ADDITIVITY
==================================================

Measure: sale_amount

- Time → additive
- Store → additive
- Product → additive


Measure: unit_price

- Time → non-additive
- Store → non-additive


Measure: inventory

- Time → semi-additive
- Store → additive (within same time)



==================================================
7. FLOW vs LEVEL DATA
==================================================

----------------------------------------
Flow Data
----------------------------------------
- Happens over time
- Example:
  → sales
  → transactions

→ Additive


----------------------------------------
Level Data
----------------------------------------
- Snapshot at a point
- Example:
  → inventory
  → balance

→ Semi-additive



==================================================
8. COMMON INTERVIEW QUESTIONS
==================================================

----------------------------------------
Q: Is discount percentage additive?
----------------------------------------
Answer:
- No
- Compute from total discount / total sales


----------------------------------------
Q: Can we sum inventory?
----------------------------------------
Answer:
- Not across time


----------------------------------------
Q: Conversion rate?
----------------------------------------
Answer:
- Non-additive
- Compute using totals



==================================================
9. COMMON MISTAKES
==================================================

----------------------------------------
1. Averaging averages
----------------------------------------
Problem:
- Wrong results

Fix:
- Use weighted average


----------------------------------------
2. Summing inventory across time
----------------------------------------
Problem:
- Double counting

Fix:
- Use average or last value


----------------------------------------
3. Summing distinct counts
----------------------------------------
Problem:
- Duplicate counting

Fix:
- Use distinct logic


----------------------------------------
4. Storing percentages
----------------------------------------
Problem:
- Cannot aggregate

Fix:
- Store base values


----------------------------------------
5. No naming clarity
----------------------------------------
Problem:
- Users misuse data

Fix:
- Use naming like:
  → _amount
  → _ratio
  → _balance



==================================================
10. CORRECT AGGREGATION EXAMPLES
==================================================

----------------------------------------
Conversion Rate
----------------------------------------

Wrong:
AVG(conversion_rate)

Correct:
SUM(success) / SUM(total)


----------------------------------------
Average Price
----------------------------------------

Wrong:
AVG(price)

Correct:
SUM(amount) / SUM(quantity)



==================================================
11. FINAL TAKEAWAY
==================================================

Before using any measure, ask:

1. Can I sum it?
2. Along which dimension?


----------------------------------------
Golden Rule
----------------------------------------

Additive:
- SUM works

Semi-additive:
- SUM works only for some dimensions

Non-additive:
- Recalculate


----------------------------------------
Big Insight
----------------------------------------

Wrong aggregation = wrong business decision



==================================================
12. QUICK MEMORY SUMMARY
==================================================

Additive:
- sales, quantity

Semi-additive:
- inventory, balance

Non-additive:
- price, percentage, ratio

Rule:
- Always check dimension before aggregation

Goal:
- Ensure correct analytics