# Spark Architecture

Apache Spark is a **distributed computing engine** built to process massive amounts of data in parallel across a cluster of machines.

Think of it like a **construction project**: you have a project manager (Driver), workers (Executors), and an HR department (Cluster Manager) that assigns workers.

---

## The Three Main Components

### 1. Driver Program (The Brain)

The Driver is the **master process** that controls everything. It runs on one machine and does the following:

- Converts your Python/Scala code into a **logical plan**, then an **optimized plan**, then a **physical plan**
- Builds the **DAG** (Directed Acyclic Graph) — the blueprint of the entire job
- Splits work into **stages** and **tasks**
- Sends tasks to executors and tracks their progress
- Handles **task failures and retries**
- Maintains the **SparkSession** (entry point to Spark)

**Simple analogy**: The Driver is like a GPS navigation system. It plans the entire route (DAG), breaks it into turns (stages/tasks), and tells each car (executor) where to go. But the Driver itself doesn't drive — it only plans and coordinates.

### 2. Executors (The Workers)

Executors are **worker processes** that run on cluster nodes. They do the actual heavy lifting:

- Execute the tasks assigned by the Driver
- Perform CPU-intensive work — transformations, joins, shuffles, aggregations
- Store data in memory when you use `cache()` or `persist()`
- Return results back to the Driver

**Each executor has:**

| Resource    | Description                            |
|-------------|----------------------------------------|
| Own Memory  | Separate heap for storage & execution  |
| Own Cores   | Each core runs one task at a time      |
| Own JVM     | Isolated process — crash doesn't kill others |

**Simple analogy**: Executors are like kitchen chefs. Each chef has their own counter (memory), their own stove burners (cores), and works independently. Multiple chefs = food gets prepared faster (parallelism).

### 3. Cluster Manager (The Resource Allocator)

The Cluster Manager decides **who gets what resources**. It:

- Allocates executors, memory, and CPU to the Spark application
- Starts the Driver process
- Launches Executor containers/pods
- Monitors health and restarts failed containers

**Supported Cluster Managers:**

| Manager      | When Used                                  |
|-------------|---------------------------------------------|
| Standalone  | Simple, built into Spark itself             |
| YARN        | Hadoop ecosystems (most common in on-prem)  |
| Kubernetes  | Modern cloud-native deployments             |
| Mesos       | Less common, being phased out               |

---

## How a Spark Application Runs (End-to-End)

Here is exactly what happens when you submit a Spark job:

```
Step 1:  You submit a Spark job (spark-submit or Notebook)
Step 2:  Request goes to the Cluster Manager
Step 3:  Cluster Manager starts the Driver container/pod
Step 4:  Driver requests resources:
           "I need 5 executors, 4 cores each, 10 GB memory each"
Step 5:  Cluster Manager launches Executor pods/containers
Step 6:  Driver divides the job into Stages → Tasks
Step 7:  Tasks are sent to Executors for execution
Step 8:  Executors process data and send results back
Step 9:  Driver assembles the final output
Step 10: On completion, Executors shut down
```

**Visual Flow:**

```
  [Your Code]
       |
       v
  [Cluster Manager]  ──allocates──>  [Driver]
                                        |
                              plans & schedules
                                        |
                     ┌──────────────────┼──────────────────┐
                     v                  v                  v
               [Executor 1]      [Executor 2]      [Executor 3]
               Core1  Core2      Core1  Core2      Core1  Core2
               Task1  Task2      Task3  Task4      Task5  Task6
```

---

## Key Takeaway

> Spark follows a **Driver–Executor** architecture.
> The **Driver** plans and coordinates the job, **Executors** do the actual computation, and the **Cluster Manager** allocates resources.
> This architecture enables **distributed, in-memory, parallel processing** at massive scale.
