# Interview Framework — Question List

> **Permanent Recall:** The MASTER list of system design questions. Use this for comprehensive preparation. Questions are organized by Difficulty, Category, and Company frequency. Study order depends on your timeline: 1 week (essentials), 2 weeks (+ common), 1 month (+ full list), 3 months (+ expert, company-specific).

---

## By Difficulty

### Easy
| # | Question | Category |
|---|----------|----------|
| 1 | Design a URL Shortener (bit.ly) | Infrastructure |
| 2 | Design a Pastebin | Infrastructure |
| 3 | Design a Rate Limiter | Infrastructure |
| 4 | Design a Simple Key-Value Store | Infrastructure |
| 5 | Design a Web Crawler (basic) | Search |
| 6 | Design a Hash Table | Data Structures |
| 7 | Design a TinyURL | Infrastructure |
| 8 | Design a Counter Service | Infrastructure |
| 9 | Design an API Gateway (basic) | Infrastructure |
| 10 | Design a Log Aggregation System (basic) | Observability |

### Medium
| # | Question | Category |
|---|----------|----------|
| 11 | Design Twitter / X (Feed) | Social |
| 12 | Design Instagram | Social |
| 13 | Design Facebook News Feed | Social |
| 14 | Design WhatsApp | Chat |
| 15 | Design a Chat System (Slack, iMessage) | Chat |
| 16 | Design YouTube | Media |
| 17 | Design Netflix | Media |
| 18 | Design a Notification System | Notification |
| 19 | Design a Distributed Cache | Infrastructure |
| 20 | Design a Search Autocomplete (Typeahead) | Search |
| 21 | Design a URL Shortener at Scale | Infrastructure |
| 22 | Design a Rate Limiter (Distributed) | Infrastructure |
| 23 | Design a News Feed System | Social |
| 24 | Design a Session Store | Infrastructure |
| 25 | Design a Photo Storage System | Media |
| 26 | Design a Download Manager | Media |
| 27 | Design Dropbox | Storage |
| 28 | Design Google Drive | Storage |
| 29 | Design a Recommendation System (basic) | ML/Recommendation |
| 30 | Design a Metrics/Monitoring System | Observability |

### Hard
| # | Question | Category |
|---|----------|----------|
| 31 | Design Uber / Ride-sharing | Geospatial |
| 32 | Design Google Maps | Geospatial |
| 33 | Design a Distributed Message Queue | Infrastructure |
| 34 | Design Google Search | Search |
| 35 | Design a Distributed File System (GFS) | Storage |
| 36 | Design a Distributed Database | Infrastructure |
| 37 | Design Google Docs | Collaborative |
| 38 | Design Figma (Collaborative Design) | Collaborative |
| 39 | Design Spotify | Media |
| 40 | Design a Video Conferencing System (Zoom) | Real-time |
| 41 | Design Twitter at Scale (full) | Social |
| 42 | Design a Payment System | E-commerce |
| 43 | Design an E-commerce Platform (Amazon) | E-commerce |
| 44 | Design a Hotel Booking System | E-commerce |
| 45 | Design a Distributed Lock Service | Infrastructure |
| 46 | Design a Distributed ID Generator (Snowflake) | Infrastructure |
| 47 | Design a Real-time Analytics Dashboard | Real-time |
| 48 | Design a Job Scheduler (Distributed) | Infrastructure |
| 49 | Design a Reservation System | E-commerce |
| 50 | Design a Content Delivery Network (CDN) | Infrastructure |

### Expert
| # | Question | Category |
|---|----------|----------|
| 51 | Design Google (Search at Scale) | Search |
| 52 | Design Facebook (Full System) | Social |
| 53 | Design a Distributed Transaction System | Infrastructure |
| 54 | Design a Consensus Algorithm (Raft/Paxos) | Distributed Systems |
| 55 | Design a Multi-Region Database | Infrastructure |
| 56 | Design a Global Rate Limiter | Infrastructure |
| 57 | Design a Distributed Tracing System | Observability |
| 58 | Design a Real-time Leaderboard | Real-time |
| 59 | Design a Graph Database (Social Graph) | Data |
| 60 | Design a Recommendation System at Scale | ML/Recommendation |
| 61 | Design a Fraud Detection System | E-commerce |
| 62 | Design a Distributed Logging System | Observability |
| 63 | Design a Multi-Tenant SaaS Platform | Infrastructure |
| 64 | Design a Blockchain (Simplified) | Distributed Systems |
| 65 | Design a Real-time Collaboration Platform (like Miro) | Collaborative |

---

## By Category

| Category | Questions |
|----------|-----------|
| **Social** | Twitter, Instagram, Facebook News Feed, News Feed System |
| **Chat** | WhatsApp, Slack, iMessage, Chat System |
| **Media** | YouTube, Netflix, Spotify, Photo Storage, Video Conferencing |
| **Infrastructure** | URL Shortener, Rate Limiter, Cache, API Gateway, Distributed Lock, Snowflake, CDN |
| **E-commerce** | Amazon, Payment System, Hotel Booking, Reservation, Fraud Detection |
| **Search** | Google Search, Autocomplete, Web Crawler |
| **Real-time** | Video Conferencing, Real-time Analytics, Leaderboard |
| **Collaborative** | Google Docs, Figma, Miro |
| **Geospatial** | Uber, Google Maps |
| **Storage** | Dropbox, Google Drive, GFS |
| **Observability** | Log Aggregation, Metrics, Tracing, Logging |
| **ML/Recommendation** | Recommendation System |

---

## By Company Frequency (Reported)

*Note: Based on commonly reported patterns; actual frequency varies by team and year.*

### Google
- Design Google Search
- Design YouTube
- Design Google Docs
- Design GFS (Distributed File System)
- Design a Distributed Cache
- Design a Rate Limiter
- Design a URL Shortener
- Design Google Maps
- Design a Recommendation System

### Amazon
- Design an E-commerce Platform
- Design a Distributed Cache
- Design a Notification System
- Design a URL Shortener
- Design a Rate Limiter
- Design a Payment System
- Design a Delivery Tracking System
- Design a Recommendation System

### Meta (Facebook)
- Design Facebook News Feed
- Design WhatsApp
- Design Instagram
- Design a Chat System
- Design a Notification System
- Design a Search Autocomplete
- Design a Graph Database (Social Graph)

### Microsoft
- Design a Chat System (Teams)
- Design a Distributed Cache
- Design a Rate Limiter
- Design a URL Shortener
- Design Azure-like services
- Design a Video Conferencing System
- Design a Collaborative Platform

### Apple
- Design iMessage
- Design a Chat System
- Design a Photo Storage System (iCloud)
- Design a Notification System
- Design a Music Streaming Service

### Netflix
- Design Netflix (obvious)
- Design a Video Streaming Platform
- Design a Recommendation System
- Design a CDN
- Design a Distributed Cache

### Uber
- Design Uber / Ride-sharing
- Design a Real-time Location System
- Design a Dispatch System
- Design a Rate Limiter (for drivers)
- Design a Notification System

### Meta (Instagram)
- Design Instagram
- Design a Photo/Video Feed
- Design a Notification System
- Design a Search System (hashtags, users)

---

## Study Order by Timeline

### 1 Week (Essentials — 10 questions)
1. Design a URL Shortener
2. Design Twitter (Feed)
3. Design a Rate Limiter
4. Design a Chat System (WhatsApp/Slack)
5. Design a Distributed Cache
6. Design a Notification System
7. Design YouTube/Netflix (pick one)
8. Design Uber
9. Design Google Search (simplified)
10. Design a Recommendation System (basic)

### 2 Weeks (+ Common — 20 questions)
Add to 1-week list:
11. Design Instagram
12. Design Facebook News Feed
13. Design Dropbox / Google Drive
14. Design a Search Autocomplete
15. Design Google Docs
16. Design a Payment System
17. Design an E-commerce Platform (simplified)
18. Design a Metrics/Monitoring System
19. Design a Session Store
20. Design a News Feed System

### 1 Month (+ Full Coverage — 35 questions)
Add to 2-week list:
21. Design Spotify
22. Design a Video Conferencing System
23. Design a Distributed Message Queue
24. Design a Distributed Lock Service
25. Design a Distributed ID Generator (Snowflake)
26. Design Figma / Collaborative Design
27. Design a Job Scheduler (Distributed)
28. Design a Hotel Booking System
29. Design a Content Delivery Network
30. Design a Web Crawler
31. Design a Log Aggregation System
32. Design a Real-time Analytics Dashboard
33. Design a Pastebin
34. Design a Download Manager
35. Design a Multi-Tenant SaaS Platform (basic)

### 3 Months (+ Expert, Company-Specific — 50+ questions)
Add to 1-month list:
36. Design Google (full search at scale)
37. Design Facebook (full system)
38. Design a Distributed Transaction System
39. Design a Consensus Algorithm (Raft/Paxos)
40. Design a Multi-Region Database
41. Design a Global Rate Limiter
42. Design a Distributed Tracing System
43. Design a Real-time Leaderboard
44. Design a Graph Database (Social Graph)
45. Design a Recommendation System at Scale
46. Design a Fraud Detection System
47. Design a Distributed Logging System
48. Design a Blockchain (Simplified)
49. Design a Real-time Collaboration Platform (Miro)
50. Design GFS (Distributed File System)

---

## Quick Reference: Top 15 Most Asked

| Rank | Question |
|------|----------|
| 1 | Design a URL Shortener |
| 2 | Design Twitter / Feed |
| 3 | Design a Rate Limiter |
| 4 | Design a Chat System |
| 5 | Design a Distributed Cache |
| 6 | Design a Notification System |
| 7 | Design YouTube / Netflix |
| 8 | Design Uber |
| 9 | Design Instagram |
| 10 | Design Google Search |
| 11 | Design a Recommendation System |
| 12 | Design Dropbox / Google Drive |
| 13 | Design Google Docs |
| 14 | Design an E-commerce Platform |
| 15 | Design a Search Autocomplete |

---

## Category-to-Component Map (Quick Study)

| Category | Key Components to Know |
|----------|------------------------|
| **Social** | Fan-out (push/pull), timeline cache, sharding by user_id |
| **Chat** | WebSocket, message queue, presence (Redis), read receipts |
| **Media** | CDN, object storage, transcoding, adaptive bitrate |
| **Infrastructure** | LB, cache, DB, queues, sharding, replication |
| **E-commerce** | ACID DB, cache, idempotency, payment gateway |
| **Search** | Inverted index, sharding, ranking, spell correction |
| **Real-time** | WebSocket, pub/sub, ordering guarantees |
| **Collaborative** | OT or CRDT, version vector, conflict resolution |
| **Geospatial** | Geohash, spatial index, real-time location |
| **Storage** | Object storage, chunking, dedup, sync |
