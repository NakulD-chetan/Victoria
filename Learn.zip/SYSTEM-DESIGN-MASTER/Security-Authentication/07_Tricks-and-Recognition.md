# Security and Authentication — Tricks and Recognition

> **Permanent Recall:** Auth selection shortcuts: internal API → API key, user-facing third-party → OAuth, microservices → JWT, enterprise SSO → SAML/OIDC. Use the security checklist for any system design. Be aware of OWASP Top 10. Use these triggers to choose and design auth fast in interviews.

---

## Auth Selection Shortcuts

| Scenario | Use | Why |
|----------|-----|-----|
| **Internal API** | API key | Simple, revocable, machine identity |
| **User-facing, third-party app** | OAuth 2.0 | Delegated consent, no password sharing |
| **Our mobile/web app** | JWT or Session | JWT stateless; Session for instant revoke |
| **Microservices** | JWT | Stateless, service-to-service |
| **Enterprise SSO** | SAML / OIDC | Federate with customer IdP |
| **Simple partner integration** | API key | Low complexity |
| **High-security, instant logout** | Session | Delete session = done |

> **FAANG Tip:** "Internal → API key. Third-party → OAuth. Microservices → JWT. Enterprise SSO → SAML/OIDC."

---

## Security Checklist for Any System Design

When designing any system, ask:

| Check | Question |
|-------|----------|
| **Authentication** | Who accesses? How do we verify identity? |
| **Authorization** | What can each actor do? RBAC/ABAC? |
| **Encryption** | HTTPS? Encryption at rest? |
| **Passwords** | bcrypt/Argon2? No plain text? |
| **Tokens** | Expiry? Refresh rotation? |
| **Input** | Validate? Parameterized SQL? Output encode? |
| **CSRF** | Token or SameSite? |
| **CORS** | Specific origins? No * with credentials? |
| **Rate limit** | Login? API? |
| **Secrets** | Env/vault? No hardcode? |
| **Sessions** | HttpOnly, Secure, timeout? |
| **Logging** | No secrets in logs? |

---

## OWASP Top 10 Awareness

| # | Risk | What to Do |
|---|------|------------|
| A01 | **Broken Access Control** | Enforce authz on every endpoint; RBAC/ABAC |
| A02 | **Cryptographic Failures** | HTTPS; strong algorithms; protect keys |
| A03 | **Injection** | Parameterized queries; input validation; ORM |
| A04 | **Insecure Design** | Security in design; threat modeling |
| A05 | **Security Misconfiguration** | Secure defaults; no debug in prod |
| A06 | **Vulnerable Components** | Update deps; SBOM; vulnerability scanning |
| A07 | **Auth Failures** | Strong auth; MFA; rate limit; no default creds |
| A08 | **Software/Data Integrity** | Signed updates; verify integrity |
| A09 | **Logging/Monitoring** | Log auth failures; alert; no PII in logs |
| A10 | **SSRF** | Validate URLs; block internal IPs; allowlist |

---

## Quick Auth Pattern Recognition

When interviewer says:

| Phrase | Think |
|--------|-------|
| "Internal service calls" | API key or JWT |
| "Third-party developers" | OAuth 2.0 |
| "Login with Google" | OAuth (authorization code or PKCE) |
| "Microservices" | JWT for service-to-service |
| "Enterprise customer, their AD" | SAML or OIDC federation |
| "Instant logout" | Session-based |
| "Stateless, scale out" | JWT |
| "Machine-to-machine" | Client credentials or API key |

---

## Protocol Quick Reference

| Need | Protocol |
|------|----------|
| User identity + OAuth | OpenID Connect (OIDC) |
| Delegated API access | OAuth 2.0 |
| Enterprise SSO (XML) | SAML 2.0 |
| Simple API auth | API key, JWT |
| Password storage | bcrypt, Argon2 |

---

## Interview One-Liners

| Topic | One-liner |
|-------|-----------|
| **Auth vs Authz** | "Auth = who you are; Authz = what you can do" |
| **OAuth** | "Delegated auth—user never gives app their password" |
| **JWT** | "Self-contained, signed token; stateless validation" |
| **Session vs JWT** | "Session = instant revoke; JWT = stateless scale" |
| **Passwords** | "bcrypt/Argon2, never plain text" |
| **401 vs 403** | "401 not authenticated; 403 forbidden" |
| **CSRF** | "Token or SameSite cookie; validate Origin" |
| **SQL injection** | "Parameterized queries only" |
| **XSS** | "Output encode, CSP, HttpOnly cookies" |

---

## Anti-Patterns (When NOT to Use)

| Don't | Why |
|-------|-----|
| JWT for everything | Session better when instant revoke needed |
| OAuth for internal only | API key simpler |
| Plain text passwords | Always hash |
| CORS * with credentials | Security hole |
| GET for state changes | CSRF risk, crawlers |
| Long-lived access tokens | Theft window |
| No rate limit on login | Brute-force |
| Secrets in code | Leak via repo |

---

## Recognition: Interview Triggers

| Trigger | Response |
|---------|----------|
| "Design login" | Auth flow, JWT/session, bcrypt, rate limit |
| "Third-party integration" | OAuth 2.0, authorization code |
| "Microservices auth" | JWT, API gateway validates |
| "Enterprise SSO" | SAML/OIDC, federate IdP |
| "How prevent X?" | OWASP category; specific controls |
| "Token stolen?" | Short TTL, rotation, blacklist, revoke |

---

## 30-SECOND REVISION BOX

```
INTERNAL → API key | THIRD-PARTY → OAuth | MICROSERVICES → JWT
SSO → SAML/OIDC
CHECKLIST: Auth, authz, HTTPS, bcrypt, tokens, input, CSRF, CORS, rate limit
OWASP: Broken access, injection, auth failures, XSS, etc.
ONE-LINERS: Auth vs Authz, OAuth, JWT, 401/403, CSRF, SQLi, XSS
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
