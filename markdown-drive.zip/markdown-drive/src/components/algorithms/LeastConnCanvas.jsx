import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useLeastConnStore } from '../../stores/least-conn-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const SERVER_COLORS = ['#a5d8ff', '#d0bfff', '#b2f2bb', '#ffd8a8', '#ffc9c9'];
const SERVER_COLORS_DARK = ['#1c4a6e', '#3b2e6e', '#1e5631', '#5c3d1a', '#5c2020'];

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4', stroke: '#1c1917', textPrimary: '#1c1917', textSecondary: '#78716c',
    lbFill: '#fff3bf', clientFill: '#d0bfff', arrowStroke: '#78716c',
    connActive: '#1971c2', connDone: '#2f9e44', highlight: 'rgba(25,113,194,0.15)',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)', stroke: 'rgba(255,255,255,0.6)', textPrimary: '#e7e5e4', textSecondary: '#a8a29e',
    lbFill: '#4a3d10', clientFill: '#3b2e6e', arrowStroke: '#a8a29e',
    connActive: '#74c0fc', connDone: '#51cf66', highlight: 'rgba(100,180,255,0.15)',
  },
};

function getPal() {
  return (document.documentElement.getAttribute('data-theme') === 'light') ? PALETTE.light : PALETTE.dark;
}

const LeastConnCanvas = forwardRef(function LeastConnCanvas({ lbRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');

  const serverCount = useLeastConnStore((s) => s.serverCount);

  const addAnim = useCallback((type, extra = {}) => {
    animsRef.current.push({ type, t0: performance.now(), dur: extra.dur || 800, ...extra });
  }, []);

  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache(); lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function layout() {
      const W = wRef.current, H = hRef.current;
      const sCount = lbRef.current.serverCount;
      const clientW = 110, clientH = 70;
      const lbW = 130, lbH = 80;
      const svrW = 100, svrH = 60;
      const svrGap = Math.min(70, (H - 60) / sCount);
      const svrStartY = (H - sCount * svrGap) / 2 + svrGap / 2 - svrH / 2;
      const servers = [];
      for (let i = 0; i < sCount; i++) {
        servers.push({ x: W - svrW - 30, y: svrStartY + i * svrGap, w: svrW, h: svrH });
      }
      return {
        client: { x: 30, y: H / 2 - clientH / 2, w: clientW, h: clientH },
        lb: { x: W / 2 - lbW / 2, y: H / 2 - lbH / 2, w: lbW, h: lbH },
        servers,
        W, H,
      };
    }

    function drawBox(key, x, y, w, h, opts, pal) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.4, bowing: 1, strokeWidth: 2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawArrow(key, x1, y1, x2, y2, pal) {
      const dx = x2 - x1, dy = y2 - y1;
      const len = Math.sqrt(dx * dx + dy * dy);
      const pad = 6;
      const img = cacheShape(key, len + pad * 2, 24, (rc) => {
        rc.line(pad, 12, len + pad - 8, 12, { seed: 50, roughness: 1.2, strokeWidth: 1.5, stroke: pal.arrowStroke });
        const tipX = len + pad - 8;
        rc.line(tipX - 10, 5, tipX, 12, { seed: 51, roughness: 0.8, strokeWidth: 1.5, stroke: pal.arrowStroke });
        rc.line(tipX - 10, 19, tipX, 12, { seed: 52, roughness: 0.8, strokeWidth: 1.5, stroke: pal.arrowStroke });
      });
      ctx.save();
      ctx.translate(x1, y1);
      ctx.rotate(Math.atan2(dy, dx));
      ctx.drawImage(img, -pad, -12, len + pad * 2, 24);
      ctx.restore();
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) { clearShapeCache(); clearCache(); lastThemeRef.current = curTheme; }
      const pal = getPal();
      const isDark = curTheme !== 'light';
      const svrFills = isDark ? SERVER_COLORS_DARK : SERVER_COLORS;

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      const l = layout();
      const lb = lbRef.current;

      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h,
        { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke }, pal);
      ctx.fillStyle = pal.textPrimary; ctx.font = `600 14px ${FONT_HAND}`; ctx.textAlign = 'center';
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);

      drawBox('lb', l.lb.x, l.lb.y, l.lb.w, l.lb.h,
        { fill: pal.lbFill, fillStyle: 'hachure', hachureGap: 5, seed: 7, stroke: pal.stroke }, pal);
      ctx.fillStyle = pal.textPrimary; ctx.font = `700 13px ${FONT_HAND}`; ctx.textAlign = 'center';
      ctx.fillText('Load Balancer', l.lb.x + l.lb.w / 2, l.lb.y + l.lb.h / 2 - 8);
      ctx.font = `11px ${FONT_MONO}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText('Least Connections', l.lb.x + l.lb.w / 2, l.lb.y + l.lb.h / 2 + 10);

      drawArrow('arr-c-lb', l.client.x + l.client.w, l.client.y + l.client.h / 2, l.lb.x, l.lb.y + l.lb.h / 2, pal);

      for (let i = 0; i < l.servers.length; i++) {
        const s = l.servers[i];
        const conns = lb.connections[i] || 0;
        const isMin = conns === Math.min(...lb.connections.slice(0, lb.serverCount));

        if (isMin && conns >= 0) {
          ctx.fillStyle = pal.highlight;
          ctx.beginPath();
          ctx.roundRect(s.x - 6, s.y - 6, s.w + 12, s.h + 12, 8);
          ctx.fill();
        }

        drawBox(`svr-${i}`, s.x, s.y, s.w, s.h,
          { fill: svrFills[i % svrFills.length], fillStyle: 'hachure', hachureGap: 5, seed: 10 + i, stroke: pal.stroke }, pal);

        ctx.fillStyle = pal.textPrimary; ctx.font = `600 13px ${FONT_HAND}`; ctx.textAlign = 'center';
        ctx.fillText(`Server ${i + 1}`, s.x + s.w / 2, s.y + s.h / 2 - 8);

        ctx.font = `800 16px ${FONT_MONO}`;
        ctx.fillStyle = conns > 0 ? pal.connActive : pal.textSecondary;
        ctx.fillText(String(conns), s.x + s.w / 2, s.y + s.h / 2 + 12);

        drawArrow(`arr-lb-s${i}`, l.lb.x + l.lb.w, l.lb.y + l.lb.h / 2, s.x, s.y + s.h / 2, pal);
      }

      ctx.font = `12px ${FONT_HAND}`; ctx.textAlign = 'center'; ctx.fillStyle = pal.textSecondary;
      ctx.fillText('requests', (l.client.x + l.client.w + l.lb.x) / 2, l.client.y - 14);

      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const elapsed = now - a.t0 - (a.delay || 0);
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);

        if (a.type === 'route') {
          const si = a.serverIdx;
          const s = l.servers[si];
          if (!s) { anims.splice(i, 1); continue; }
          if (t < 0.4) {
            const p = t / 0.4;
            const px = l.client.x + l.client.w + (l.lb.x - l.client.x - l.client.w) * easeOut(p);
            const py = l.client.y + l.client.h / 2;
            ctx.beginPath(); ctx.arc(px, py, 7, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(25,113,194,0.7)'; ctx.fill();
          } else if (t < 0.8) {
            const p = (t - 0.4) / 0.4;
            const sx = l.lb.x + l.lb.w;
            const sy = l.lb.y + l.lb.h / 2;
            const ex = s.x;
            const ey = s.y + s.h / 2;
            const px = sx + (ex - sx) * easeOut(p);
            const py = sy + (ey - sy) * easeOut(p);
            ctx.beginPath(); ctx.arc(px, py, 6, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(25,113,194,0.7)'; ctx.fill();
          } else {
            const alpha = 1 - (t - 0.8) / 0.2;
            ctx.font = `800 20px ${FONT_HAND}`;
            ctx.fillStyle = `rgba(47,158,68,${alpha})`;
            ctx.textAlign = 'center';
            ctx.fillText('\u2713', s.x + s.w / 2, s.y - 14);
          }
        }

        if (a.type === 'complete') {
          const si = a.serverIdx;
          const s = l.servers[si];
          if (!s) { anims.splice(i, 1); continue; }
          const alpha = 1 - t;
          ctx.font = `700 12px ${FONT_HAND}`;
          ctx.fillStyle = `rgba(47,158,68,${alpha})`;
          ctx.textAlign = 'center';
          ctx.fillText('done', s.x + s.w / 2, s.y + s.h + 14);
        }

        if (t >= 1) anims.splice(i, 1);
      }

      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, [lbRef, addAnim]);

  useEffect(() => { clearShapeCache(); clearCache(); lastThemeRef.current = ''; }, [serverCount]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 380 }} />
    </div>
  );
});

export default LeastConnCanvas;
