# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. WHAT ARE DATA WAREHOUSE INTERNALS
==================================================

Key idea:
- Inside a data warehouse, not all tables are same
- Some tables are:
  → Temporary (for processing)
  → Final (for business use)

Analogy:
- Back room (staging) → raw goods
- Store floor (curated) → clean products for customers

Meaning:
- Data is first collected and checked
- Then cleaned and made ready for business use



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Warehouse has 2 main parts:

1. STAGING LAYER
- Raw data
- Used for checking and validation

2. USER ACCESS (CURATED LAYER)
- Clean, trusted data
- Used by BI and business users

Flow:
Data → Staging → Cleaning → Curated → BI

Important:
- Problems should be fixed BEFORE data reaches business layer



==================================================
3. TWO MAIN LAYERS
==================================================

----------------------------------------
STAGING LAYER
----------------------------------------
Who uses:
- Data engineers

Purpose:
- Store raw data
- Validate data
- Track issues

Key features:
- Raw format
- No heavy transformation


----------------------------------------
USER ACCESS LAYER
----------------------------------------
Who uses:
- Analysts
- BI tools

Purpose:
- Provide clean data
- Stable structure

Key features:
- Fact tables
- Dimension tables


----------------------------------------
Important Line
----------------------------------------
Staging = "prove data is correct"  
Curated = "promise data is correct"



==================================================
4. ETL FLOW WITH STAGING
==================================================

Steps:

1. Extract
- Get data from sources

2. Stage
- Store raw data

3. Transform
- Clean and validate

4. Load
- Move to curated tables


Flow:
SOURCE → STAGING → TRANSFORM → CURATED → BI


----------------------------------------
Warning
----------------------------------------
If no staging:
- Cannot debug issues
- Cannot compare raw vs processed



==================================================
5. RETAIL EXAMPLE (VERY IMPORTANT)
==================================================

Different systems send different data:

----------------------------------------
Web system
----------------------------------------
- JSON data
- Complex structure

Solution:
- Break JSON into tables


----------------------------------------
Partner stores
----------------------------------------
- Files
- Delayed data

Solution:
- Add batch_id, file info


----------------------------------------
ERP system
----------------------------------------
- Different IDs

Solution:
- Map to common keys



----------------------------------------
SQL Example Explained
----------------------------------------

CREATE TABLE stg.partner_pos_sales (
  ingest_batch_id      STRING,
  ingest_ts_utc        TIMESTAMP,
  source_file_name     STRING,
  partner_store_code   STRING,
  partner_sku          STRING,
  sale_qty             DECIMAL(18,4),
  sale_amount_local    DECIMAL(18,4),
  currency_code        STRING,
  sale_ts_local        STRING
);

Explanation:
- Raw data stored as-is
- Metadata added (batch_id, timestamp)
- Some fields kept as STRING (not parsed yet)



==================================================
6. ONE-TO-ONE STAGING PRINCIPLE
==================================================

Key idea:
- Staging should match source exactly

----------------------------------------
Rules
----------------------------------------

1. 1:1 column mapping
- Same columns as source

2. Add metadata
- batch_id
- ingest time

3. No joins
- Do not combine data yet


----------------------------------------
Why?
----------------------------------------
- Easier debugging
- Trace data back to source


----------------------------------------
Warning
----------------------------------------
Early joins = hard debugging



==================================================
7. CURATED LAYER (BUSINESS LAYER)
==================================================

This is where real modeling happens

----------------------------------------
Main Tables
----------------------------------------

1. Dimension Tables (dim)
- Example:
  dim_product
  dim_store

2. Fact Tables (fact)
- Example:
  fact_sales


----------------------------------------
SQL Example Explained
----------------------------------------

dim_product:
- Stores product details
- Includes history (SCD)

fact_sales:
- Stores transaction data
- Linked to dimensions


----------------------------------------
Important Concept
----------------------------------------
Surrogate Keys:
- Artificial keys
- Used instead of natural keys
- Helps track history



==================================================
8. PERSISTENT vs NON-PERSISTENT STAGING
==================================================

----------------------------------------
Non-Persistent Staging
----------------------------------------
- Data overwritten every load

Pros:
- Low storage

Cons:
- Hard to debug


----------------------------------------
Persistent Staging
----------------------------------------
- Keeps history of data

Pros:
- Easy replay
- Audit-friendly

Cons:
- More storage needed


----------------------------------------
Decision Logic
----------------------------------------

Use Persistent if:
- Need audit
- Data comes late

Use Non-Persistent if:
- Cost sensitive



==================================================
9. DATA QUALITY CHECKS
==================================================

Before moving to curated layer, checks are applied:

----------------------------------------
Types of checks
----------------------------------------

1. Schema Check
- Columns exist

2. Referential Check
- Keys exist

3. Distribution Check
- Sudden spike in data

4. Business Rules
- Example: net <= gross


----------------------------------------
SQL Example Explained
----------------------------------------

SELECT
  ingest_batch_id,
  COUNT(*) AS row_cnt,
  COUNT(DISTINCT partner_store_code) AS store_cnt,
  SUM(CASE WHEN sale_qty < 0 THEN 1 ELSE 0 END) AS negative_qty_rows
FROM stg.partner_pos_sales
GROUP BY 1;

Explanation:
- Checks:
  - total rows
  - unique stores
  - invalid values



==================================================
10. NAMING & PARTITIONING
==================================================

Best practices:

----------------------------------------
Naming
----------------------------------------
- Use prefix: stg_
- Use schema: staging


----------------------------------------
Partitioning
----------------------------------------
- Partition by ingest_date


----------------------------------------
Separate tables
----------------------------------------
- raw data
- cleaned staging
- curated data


----------------------------------------
Example
----------------------------------------
staging.raw_sales  
staging.cleaned_sales  
dw.fact_sales  



==================================================
11. USER ACCESS LAYER DESIGN
==================================================

----------------------------------------
Patterns
----------------------------------------

1. Star Schema
- Fact + dimensions

2. Views
- Simplify queries

3. Certified datasets
- Trusted data


----------------------------------------
SQL Example
----------------------------------------

CREATE VIEW dw_presentation.vw_store_sales_daily AS
SELECT
  d.calendar_date,
  s.store_name,
  SUM(f.net_sales_usd) AS net_sales_usd
FROM dw.fact_sales f
JOIN dw.dim_date d ON f.order_date_sk = d.date_sk
JOIN dw.dim_store s ON f.store_sk = s.store_sk
GROUP BY 1, 2;

Explanation:
- View simplifies complex joins



==================================================
12. PERFORMANCE STRATEGY
==================================================

----------------------------------------
Staging Layer
----------------------------------------
- Focus on fast data load
- Minimal indexing


----------------------------------------
Curated Layer
----------------------------------------
- Optimized for queries
- Use partitioning


----------------------------------------
Warning
----------------------------------------
Too many indexes in staging = slow loads



==================================================
13. SECURITY
==================================================

----------------------------------------
Staging
----------------------------------------
- Only engineers access
- Raw sensitive data


----------------------------------------
Curated
----------------------------------------
- Controlled access
- Mask sensitive data



==================================================
14. COMMON MISTAKES
==================================================

----------------------------------------
1. BI accessing staging
----------------------------------------
Problem:
- Raw data exposure

Fix:
- Restrict access


----------------------------------------
2. No validation
----------------------------------------
Problem:
- Bad data in reports

Fix:
- Add checks


----------------------------------------
3. Joining too early
----------------------------------------
Problem:
- Hard debugging

Fix:
- Keep staging raw


----------------------------------------
4. Unlimited staging storage
----------------------------------------
Problem:
- Cost + compliance risk

Fix:
- Set retention


----------------------------------------
5. No metadata
----------------------------------------
Problem:
- Cannot trace issues

Fix:
- Add batch_id, lineage



==================================================
15. FINAL TAKEAWAY
==================================================

Data Warehouse Internals = Pipeline of Trust

Steps:

1. Staging:
- Capture raw data
- Validate it

2. Curated:
- Clean data
- Build business models

3. BI:
- Use trusted data


----------------------------------------
Key Principles
----------------------------------------

- Keep staging raw
- Validate before publish
- Use conformed dimensions
- Track lineage
- Choose staging type carefully


----------------------------------------
Goal
----------------------------------------
Convert messy data → reliable insights