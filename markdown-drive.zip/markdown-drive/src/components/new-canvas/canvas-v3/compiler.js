import {
  FONT_FAMILY,
  convertToExcalidrawElements,
} from '@excalidraw/excalidraw';
import {
  LESSON_FRAME_HEIGHT,
  LESSON_FRAME_WIDTH,
  currentLessonFrame,
  nextLessonFrame,
  normalizeTeachingDocumentV3,
} from './document';
import { validateTeachingDocumentV3 } from './validator';

const COLORS = {
  ink: '#1f1f1f',
  board: '#ffc9c9',
  boardSoft: '#fff1f1',
  callout: '#ffe8a3',
  blue: '#dbeafe',
  green: '#dcfce7',
  accent: '#6965db',
  danger: '#e8590c',
};

let idCounter = 0;
function id(prefix) {
  idCounter += 1;
  return `${prefix}_${Date.now().toString(36)}_${idCounter.toString(36)}`;
}

function customData({
  role,
  topic,
  frameId,
  beat,
  semanticId,
  extra,
}) {
  return {
    schemaVersion: 3,
    agentOwned: true,
    semanticRole: role,
    topic,
    lessonFrameId: frameId,
    revealBeat: beat,
    semanticId,
    ...(extra || {}),
  };
}

function baseShape({
  id: elementId,
  type,
  x,
  y,
  width,
  height,
  frameId,
  groupIds = [],
  backgroundColor = 'transparent',
  strokeColor = COLORS.ink,
  strokeWidth = 2,
  roughness = 1,
  roundness = { type: 3 },
  role,
  topic,
  lessonFrameId,
  beat,
  semanticId,
  extra,
}) {
  return {
    id: elementId,
    type,
    x,
    y,
    width,
    height,
    frameId,
    groupIds,
    backgroundColor,
    strokeColor,
    strokeWidth,
    fillStyle: 'solid',
    strokeStyle: 'solid',
    roughness,
    opacity: 100,
    roundness,
    customData: customData({
      role,
      topic,
      frameId: lessonFrameId,
      beat,
      semanticId,
      extra,
    }),
  };
}

function text({
  id: elementId,
  value,
  x,
  y,
  width,
  fontSize,
  frameId,
  groupIds = [],
  role,
  topic,
  lessonFrameId,
  beat,
  semanticId,
  color = COLORS.ink,
  textAlign = 'left',
  extra,
}) {
  return {
    id: elementId,
    type: 'text',
    text: value,
    x,
    y,
    width,
    height: fontSize * 1.4,
    frameId,
    groupIds,
    fontSize,
    fontFamily: FONT_FAMILY.Excalifont,
    textAlign,
    verticalAlign: 'top',
    strokeColor: color,
    backgroundColor: 'transparent',
    customData: customData({
      role,
      topic,
      frameId: lessonFrameId,
      beat,
      semanticId,
      extra,
    }),
  };
}

function labeledBox({
  id: elementId,
  label,
  x,
  y,
  width,
  height,
  frameId,
  groupIds = [],
  backgroundColor,
  role,
  topic,
  lessonFrameId,
  beat,
  semanticId,
  fontSize = 22,
  extra,
}) {
  return {
    ...baseShape({
      id: elementId,
      type: 'rectangle',
      x,
      y,
      width,
      height,
      frameId,
      groupIds,
      backgroundColor,
      role,
      topic,
      lessonFrameId,
      beat,
      semanticId,
      extra,
    }),
    label: {
      text: label,
      fontSize,
      fontFamily: FONT_FAMILY.Excalifont,
      textAlign: 'center',
      verticalAlign: 'middle',
    },
  };
}

function inferArrayFocus(request) {
  const source = [
    request?.focus,
    request?.operation,
    request?.title,
    request?.definition,
    request?.callout,
  ].filter(Boolean).join(' ').toLowerCase();
  if (/delete|remove|erase/.test(source)) return 'deletion';
  if (/insert|append|push/.test(source)) return 'insertion';
  if (/memory|contiguous|address/.test(source)) return 'memory';
  if (/code|implement|c\+\+|python|java/.test(source)) return 'code';
  return 'overview';
}

function arrayDefinition(request, focus) {
  if (request?.definition) return request.definition;
  if (focus === 'deletion') {
    return 'Deleting an array element closes the gap by shifting every later value one position to the left.';
  }
  if (focus === 'insertion') {
    return 'Inserting inside an array may require shifting later values to keep the elements contiguous.';
  }
  return 'An array is a data structure that stores multiple values of the same type in contiguous (continuous) memory locations.';
}

function arrayCallout(focus) {
  if (focus === 'deletion') return 'The first cell is removed, then later values shift left.';
  if (focus === 'insertion') return 'Make space at the chosen index, then place the new value.';
  if (focus === 'memory') return 'Adjacent boxes represent adjacent memory locations.';
  return 'Think of it like a row of numbered boxes.';
}

function buildArrayStoryboard(frame, request, elementIds) {
  const title = request.title || 'Array';
  return {
    id: id('storyboard'),
    topic: 'array',
    learningGoal: `Understand ${title.toLowerCase()} through one concrete visual.`,
    slides: [{
      id: frame.id,
      frameElementId: frame.frameElementId,
      title,
      beats: [
        { id: id('beat'), action: 'introduce', targets: elementIds.introduction, durationMs: 700 },
        { id: id('beat'), action: 'draw', targets: elementIds.array, durationMs: 850 },
        { id: id('beat'), action: 'label', targets: elementIds.indices, durationMs: 600 },
        { id: id('beat'), action: 'draw', targets: elementIds.callout, durationMs: 650 },
        { id: id('beat'), action: 'connect', targets: elementIds.connector, durationMs: 700 },
        { id: id('beat'), action: 'summarize', targets: elementIds.summary, durationMs: 700 },
      ],
    }],
  };
}

function buildArraySlide(frame, request) {
  const topic = 'array';
  const focus = inferArrayFocus(request);
  const values = Array.isArray(request.values) && request.values.length
    ? request.values.slice(0, 8).map(String)
    : ['12', '7', '19', '4', '23'];
  const originX = frame.bounds.x;
  const originY = frame.bounds.y;
  const frameElementId = frame.frameElementId;
  const groupId = id('array-group');
  const boardId = id('board');
  const badgeId = id('step-badge');
  const definitionId = id('definition');
  const metaphorId = id('metaphor');
  const arrayOuterId = id('array-outer');
  const calloutId = id('array-callout');
  const summaryId = id('summary');

  const cellWidth = 92;
  const cellHeight = 78;
  const cellGap = 16;
  const arrayWidth = values.length * cellWidth + (values.length - 1) * cellGap + 56;
  const arrayX = originX + 150;
  const arrayY = originY + 320;

  const skeletons = [];
  const childIds = [];
  const add = (element) => {
    skeletons.push(element);
    childIds.push(element.id);
    return element;
  };

  add(baseShape({
    id: boardId,
    type: 'rectangle',
    x: originX + 18,
    y: originY + 18,
    width: LESSON_FRAME_WIDTH - 36,
    height: LESSON_FRAME_HEIGHT - 36,
    frameId: frameElementId,
    backgroundColor: COLORS.board,
    strokeWidth: 2,
    roughness: 1,
    role: 'lesson-background',
    topic,
    lessonFrameId: frame.id,
    beat: 0,
    semanticId: 'lesson.board',
  }));

  add({
    ...baseShape({
      id: badgeId,
      type: 'ellipse',
      x: originX + 70,
      y: originY + 72,
      width: 64,
      height: 64,
      frameId: frameElementId,
      backgroundColor: COLORS.boardSoft,
      role: 'step-badge',
      topic,
      lessonFrameId: frame.id,
      beat: 0,
      semanticId: 'lesson.step',
      roundness: null,
    }),
    label: {
      text: String(frame.order + 1),
      fontSize: 24,
      fontFamily: FONT_FAMILY.Excalifont,
      textAlign: 'center',
      verticalAlign: 'middle',
    },
  });

  add(text({
    id: definitionId,
    value: arrayDefinition(request, focus),
    x: originX + 175,
    y: originY + 72,
    width: 920,
    fontSize: 30,
    frameId: frameElementId,
    role: 'definition',
    topic,
    lessonFrameId: frame.id,
    beat: 0,
    semanticId: 'array.definition',
  }));

  add(text({
    id: metaphorId,
    value: arrayCallout(focus),
    x: originX + 175,
    y: originY + 184,
    width: 720,
    fontSize: 24,
    frameId: frameElementId,
    role: 'analogy',
    topic,
    lessonFrameId: frame.id,
    beat: 0,
    semanticId: 'array.analogy',
    color: '#5f3dc4',
  }));

  add(baseShape({
    id: arrayOuterId,
    type: 'rectangle',
    x: arrayX - 28,
    y: arrayY - 26,
    width: arrayWidth,
    height: 134,
    frameId: frameElementId,
    groupIds: [groupId],
    backgroundColor: COLORS.boardSoft,
    strokeWidth: 2,
    role: 'array-container',
    topic,
    lessonFrameId: frame.id,
    beat: 1,
    semanticId: 'array.container',
  }));

  const cellIds = [];
  const indexIds = [];
  values.forEach((value, index) => {
    const cellId = id(`array-cell-${index}`);
    const indexId = id(`array-index-${index}`);
    const cellX = arrayX + index * (cellWidth + cellGap);
    cellIds.push(cellId);
    indexIds.push(indexId);
    add(labeledBox({
      id: cellId,
      label: value,
      x: cellX,
      y: arrayY,
      width: cellWidth,
      height: cellHeight,
      frameId: frameElementId,
      groupIds: [groupId],
      backgroundColor: focus === 'deletion' && index === 0 ? '#ffd8a8' : COLORS.boardSoft,
      role: 'array-cell',
      topic,
      lessonFrameId: frame.id,
      beat: 1,
      semanticId: `array.cell.${index}`,
      fontSize: 28,
      extra: { index, value },
    }));
    add(text({
      id: indexId,
      value: `index ${index}`,
      x: cellX + 5,
      y: arrayY + cellHeight + 16,
      width: cellWidth - 10,
      fontSize: 17,
      frameId: frameElementId,
      groupIds: [groupId],
      role: 'array-index',
      topic,
      lessonFrameId: frame.id,
      beat: 2,
      semanticId: `array.index.${index}`,
      textAlign: 'center',
      color: '#5c5f66',
    }));
  });

  const calloutX = originX + 875;
  const calloutY = originY + 328;
  add(labeledBox({
    id: calloutId,
    label: focus === 'deletion'
      ? 'Delete this cell'
      : focus === 'insertion'
        ? 'Insert at this index'
        : 'Contiguous memory',
    x: calloutX,
    y: calloutY,
    width: 250,
    height: 94,
    frameId: frameElementId,
    backgroundColor: focus === 'deletion' ? '#ffd8a8' : COLORS.callout,
    role: 'callout',
    topic,
    lessonFrameId: frame.id,
    beat: 3,
    semanticId: 'array.callout',
    fontSize: 22,
  }));

  const targetIndex = focus === 'deletion' ? 0 : Math.min(values.length - 1, 4);
  const targetCellId = cellIds[targetIndex];
  const arrowId = id('array-connector');
  add({
    id: arrowId,
    type: 'arrow',
    x: calloutX,
    y: calloutY + 47,
    width: 220,
    height: 30,
    frameId: frameElementId,
    strokeColor: COLORS.ink,
    strokeWidth: 2,
    roughness: 1,
    elbowed: true,
    start: { id: calloutId },
    end: { id: targetCellId },
    endArrowhead: 'arrow',
    customData: customData({
      role: 'connector',
      topic,
      frameId: frame.id,
      beat: 4,
      semanticId: 'array.callout.connector',
      extra: {
        sourceSemanticId: 'array.callout',
        targetSemanticId: `array.cell.${targetIndex}`,
      },
    }),
  });

  add(text({
    id: summaryId,
    value: focus === 'deletion'
      ? 'Deletion is not just removing a box: the remaining values must stay contiguous.'
      : 'The index identifies the box; contiguous storage makes direct access predictable.',
    x: originX + 175,
    y: originY + 555,
    width: 890,
    fontSize: 24,
    frameId: frameElementId,
    role: 'summary',
    topic,
    lessonFrameId: frame.id,
    beat: 5,
    semanticId: 'array.summary',
    color: '#2b8a3e',
  }));

  const portal = request.includeCodeEditor
    ? {
        id: id('code-portal'),
        type: 'code',
        frameId: frame.id,
        frameElementId,
        semanticId: 'array.code',
        revealBeat: 5,
        x: originX + 690,
        y: originY + 500,
        width: 480,
        height: 190,
        language: request.codeLanguage || 'cpp',
        title: request.codeTitle || 'Array code',
        content: request.code || '',
        typingState: request.liveTyping ? 'queued' : 'idle',
        editable: true,
        executionMode: 'remote',
      }
    : null;

  if (portal) {
    const portalPlaceholderId = id('code-placeholder');
    add(baseShape({
      id: portalPlaceholderId,
      type: 'rectangle',
      x: portal.x,
      y: portal.y,
      width: portal.width,
      height: portal.height,
      frameId: frameElementId,
      backgroundColor: '#1f1f1f',
      strokeColor: '#495057',
      roughness: 0,
      role: 'code-editor-placeholder',
      topic,
      lessonFrameId: frame.id,
      beat: 5,
      semanticId: portal.semanticId,
    }));
  }

  skeletons.push({
    id: frameElementId,
    type: 'frame',
    name: frame.title,
    x: originX,
    y: originY,
    width: LESSON_FRAME_WIDTH,
    height: LESSON_FRAME_HEIGHT,
    children: childIds,
    customData: customData({
      role: 'lesson-frame',
      topic,
      frameId: frame.id,
      beat: 0,
      semanticId: `lesson.frame.${frame.order}`,
    }),
  });

  const storyboard = buildArrayStoryboard(frame, request, {
    introduction: [badgeId, definitionId, metaphorId],
    array: [arrayOuterId, ...cellIds],
    indices: indexIds,
    callout: [calloutId],
    connector: [arrowId],
    summary: [summaryId],
  });

  const semanticNodes = [
    {
      id: 'array.definition',
      elementIds: [definitionId],
      kind: 'definition',
      role: 'definition',
      topic,
      lessonFrameId: frame.id,
    },
    {
      id: 'array.container',
      elementIds: [arrayOuterId, ...cellIds, ...indexIds],
      kind: 'data-structure',
      role: 'primary-visual',
      topic,
      lessonFrameId: frame.id,
    },
    ...cellIds.map((elementId, index) => ({
      id: `array.cell.${index}`,
      elementIds: [elementId],
      kind: 'array-cell',
      role: 'value',
      topic,
      lessonFrameId: frame.id,
      data: { index, value: values[index] },
    })),
    {
      id: 'array.callout',
      elementIds: [calloutId],
      kind: 'callout',
      role: 'annotation',
      topic,
      lessonFrameId: frame.id,
    },
  ];
  const semanticEdges = [{
    id: id('semantic-edge'),
    from: 'array.callout',
    to: `array.cell.${targetIndex}`,
    relation: 'points-to',
    elementIds: [arrowId],
  }];

  return {
    skeletons,
    storyboard,
    semanticNodes,
    semanticEdges,
    portals: portal ? [portal] : [],
  };
}

function buildGenericSlide(frame, request) {
  const topic = request.topic || request.structureType || 'concept';
  const originX = frame.bounds.x;
  const originY = frame.bounds.y;
  const boardId = id('board');
  const definitionId = id('definition');
  const visualId = id('visual');
  const calloutId = id('callout');
  const frameId = frame.frameElementId;
  const childIds = [boardId, definitionId, visualId, calloutId];
  const skeletons = [
    baseShape({
      id: boardId,
      type: 'rectangle',
      x: originX + 18,
      y: originY + 18,
      width: LESSON_FRAME_WIDTH - 36,
      height: LESSON_FRAME_HEIGHT - 36,
      frameId,
      backgroundColor: COLORS.board,
      role: 'lesson-background',
      topic,
      lessonFrameId: frame.id,
      beat: 0,
      semanticId: 'lesson.board',
    }),
    text({
      id: definitionId,
      value: request.definition || `Let us build a visual model of ${frame.title}.`,
      x: originX + 110,
      y: originY + 90,
      width: 980,
      fontSize: 32,
      frameId,
      role: 'definition',
      topic,
      lessonFrameId: frame.id,
      beat: 0,
      semanticId: `${topic}.definition`,
    }),
    labeledBox({
      id: visualId,
      label: frame.title,
      x: originX + 260,
      y: originY + 290,
      width: 420,
      height: 160,
      frameId,
      backgroundColor: COLORS.boardSoft,
      role: 'primary-visual',
      topic,
      lessonFrameId: frame.id,
      beat: 1,
      semanticId: `${topic}.visual`,
      fontSize: 30,
    }),
    labeledBox({
      id: calloutId,
      label: request.callout || 'Ask the next question to continue on a new lesson frame.',
      x: originX + 760,
      y: originY + 320,
      width: 340,
      height: 110,
      frameId,
      backgroundColor: COLORS.callout,
      role: 'callout',
      topic,
      lessonFrameId: frame.id,
      beat: 2,
      semanticId: `${topic}.callout`,
      fontSize: 22,
    }),
    {
      id: frameId,
      type: 'frame',
      name: frame.title,
      x: originX,
      y: originY,
      width: LESSON_FRAME_WIDTH,
      height: LESSON_FRAME_HEIGHT,
      children: childIds,
      customData: customData({
        role: 'lesson-frame',
        topic,
        frameId: frame.id,
        beat: 0,
        semanticId: `lesson.frame.${frame.order}`,
      }),
    },
  ];
  return {
    skeletons,
    storyboard: {
      id: id('storyboard'),
      topic,
      learningGoal: `Understand ${frame.title}.`,
      slides: [{
        id: frame.id,
        frameElementId: frameId,
        title: frame.title,
        beats: [
          { id: id('beat'), action: 'introduce', targets: [definitionId], durationMs: 700 },
          { id: id('beat'), action: 'draw', targets: [visualId], durationMs: 850 },
          { id: id('beat'), action: 'connect', targets: [calloutId], durationMs: 700 },
        ],
      }],
    },
    semanticNodes: [
      { id: `${topic}.definition`, elementIds: [definitionId], kind: 'definition', lessonFrameId: frame.id },
      { id: `${topic}.visual`, elementIds: [visualId], kind: 'visual', lessonFrameId: frame.id },
    ],
    semanticEdges: [],
    portals: [],
  };
}

function removeFrameContent(document, frame) {
  const frameElementId = frame?.frameElementId;
  if (!frameElementId) return document.elements;
  return document.elements.filter((element) => (
    element.id !== frameElementId && element.frameId !== frameElementId
  ));
}

export function compileTeachingDocumentV3({
  document: rawDocument,
  request,
  runId = null,
}) {
  const document = normalizeTeachingDocumentV3(rawDocument);
  const topic = request?.topic || request?.structureType || 'concept';
  const useCurrent = request?.pageMode === 'current' && currentLessonFrame(document);
  const frame = useCurrent
    ? {
        ...currentLessonFrame(document),
        title: request.title || currentLessonFrame(document).title,
        topic,
        updatedAt: Date.now(),
      }
    : nextLessonFrame(document, {
        topic,
        title: request?.title || topic.replace(/-/g, ' '),
      });

  const built = request?.structureType === 'array' || topic === 'array'
    ? buildArraySlide(frame, request || {})
    : buildGenericSlide(frame, request || {});
  const materialized = convertToExcalidrawElements(built.skeletons, {
    regenerateIds: false,
  });
  const retained = useCurrent ? removeFrameContent(document, frame) : document.elements;
  const frames = useCurrent
    ? document.lessonDeck.frames.map((candidate) => (candidate.id === frame.id ? frame : candidate))
    : document.lessonDeck.frames.concat([frame]);
  const oldFrameNodeIds = new Set(
    document.semanticGraph.nodes
      .filter((node) => node.lessonFrameId === frame.id)
      .map((node) => node.id),
  );
  const nextDocument = normalizeTeachingDocumentV3({
    ...document,
    elements: retained.concat(materialized),
    lessonDeck: {
      frames,
      currentFrameId: frame.id,
    },
    semanticGraph: {
      nodes: document.semanticGraph.nodes
        .filter((node) => !oldFrameNodeIds.has(node.id))
        .concat(built.semanticNodes),
      edges: document.semanticGraph.edges
        .filter((edge) => !oldFrameNodeIds.has(edge.from) && !oldFrameNodeIds.has(edge.to))
        .concat(built.semanticEdges),
    },
    portals: document.portals
      .filter((portal) => portal.frameId !== frame.id)
      .concat(built.portals),
    playback: {
      status: 'playing',
      storyboardId: built.storyboard.id,
      storyboard: built.storyboard,
      currentBeat: -1,
      totalBeats: built.storyboard.slides[0].beats.length,
      activeFrameId: frame.id,
      reducedMotion: false,
    },
    agentRuns: runId
      ? document.agentRuns.concat([{ runId, frameId: frame.id, storyboardId: built.storyboard.id, createdAt: Date.now() }]).slice(-40)
      : document.agentRuns,
    updatedAt: Date.now(),
  });

  frame.semanticNodeIds = built.semanticNodes.map((node) => node.id);
  const validation = validateTeachingDocumentV3(nextDocument);
  if (!validation.valid) {
    throw new Error(validation.errors[0]?.type || 'V3 teaching scene validation failed');
  }

  return {
    document: nextDocument,
    frame,
    storyboard: built.storyboard,
    validation,
  };
}

export function compileCodeLessonV3({
  document: rawDocument,
  operation,
  runId = null,
}) {
  const request = {
    topic: operation?.topic || 'coding',
    structureType: operation?.topic === 'array' ? 'array' : 'concept',
    title: operation?.title || 'Code Practice',
    definition: operation?.definition || 'Use the editor to inspect, change, and run the code.',
    values: operation?.values || ['0', '1', '2', '3', '4'],
    includeCodeEditor: true,
    codeLanguage: operation?.language || 'cpp',
    codeTitle: operation?.title || 'Code Editor',
    code: operation?.code || '',
    liveTyping: operation?.liveTyping !== false,
    pageMode: operation?.pageMode || 'next',
  };
  return compileTeachingDocumentV3({
    document: rawDocument,
    request,
    runId,
  });
}

