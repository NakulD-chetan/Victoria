# How Reddit Works - System Design

> Source: https://newsletter.systemdesign.one/p/reddit-architecture

## One-Line Summary
Reddit handles 100M+ daily users by pre-computing ranked post lists with job queues, caching post IDs with their rank, and partitioning vote queues by subreddit to avoid lock contention at scale.

## Key Requirements

### Functional
- Submit posts to subreddits
- Upvote/downvote posts and comments
- Display ranked feed (front page + per-subreddit)
- Nested comment threads
- User accounts and karma tracking

### Non-Functional
- Handle 100M+ daily active users
- Low latency feed display
- Consistent vote counting
- Scale horizontally
- Handle viral posts with millions of votes

## High-Level Architecture

```
Client
  |
Load Balancer
  |
App Servers (multiple)
  |
  +---+---+---+
  |   |   |   |
Job  Cache  DB   DB
Queue (Redis) (Postgres) Replicas
(partitioned   (sharded)
 by subreddit)
      |
  Processors
  (async workers)
      |
  Cassandra
  (durable list storage)
```

## Core Components Deep Dive

### 1. Post Submission (Async via Job Queue)
- Submitting a post is EXPENSIVE: updates posts, subreddits, accounts tables + spam checks + rate limiting
- Solution: **job queue** for async processing
  1. New post → message added to job queue
  2. Processor pulls job from queue asynchronously
  3. Processor handles the post and updates databases
- User gets immediate acknowledgment; processing happens in background

### 2. Ranked Lists (Feed/Front Page)
- Each subreddit and front page = **ordered list of posts** ranked by a "hot" algorithm
- Hot ranking function: `hot(upvotes, downvotes, post_age)`
- Direct DB query is expensive: `SELECT * FROM posts ORDER BY hot(...)`

**Solution: Pre-compute and cache**
- Pre-compute each list using job queue
- Store list of **post IDs + rank** in cache (Redis)
- Cache = denormalized index of posts
- Popular lists also stored in **Cassandra** for durability
- Fast lookup by post primary key

### 3. Voting (The Hard Part)
Voting is expensive because it must:
- Invalidate cached lists
- Update posts, comments, accounts tables
- Recalculate rankings

**Solution: Async voting via job queue**
1. Vote → message added to job queue
2. Processor pulls job async
3. Invalidates cache + updates DB
4. Cache updated via atomic **read-mutate-write** operation

**Problem: Lock contention at scale**
- Multiple processors voting on same popular post → all wait for same lock
- Uses **Zookeeper** for distributed locking
- But with many processors, lock wait time skyrockets

**Solution: Partition the queue by subreddit**
- Votes go into different queues based on `subreddit_id % N`
- Each processor handles a different queue
- Fewer processors compete for the same lock
- Scales horizontally without adding lock contention

```
Before: Single queue → all processors compete for locks on popular posts
After:  Queue_0 (subreddit_id % 3 == 0) → Processor A
        Queue_1 (subreddit_id % 3 == 1) → Processor B
        Queue_2 (subreddit_id % 3 == 2) → Processor C
```

### 4. Database Evolution
- Started: single Postgres on one machine
- Then: separate app server and DB server
- Then: vertical scaling (bigger DB hardware)
- Then: **sharded Postgres** (partitioned by subreddit)
- Read replicas for scaling reads
- Cassandra for durable pre-computed lists

### 5. Caching Strategy
- Redis stores pre-computed ranked lists
- Cache-aside pattern: compute → store in cache → serve from cache
- Invalidation triggered by new posts and votes
- Atomic read-mutate-write to prevent race conditions on cache updates

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Async job queues (not sync) | Post submission and voting are expensive; decouple from request |
| Pre-computed ranked lists | Avoid expensive ORDER BY queries on every page load |
| Cache post IDs + rank | Fast feed serving without DB queries |
| Partition vote queue by subreddit | Reduce lock contention on popular posts |
| Zookeeper for locking | High availability distributed lock |
| Cassandra for list durability | Cache can fail; Cassandra is durable backup |

## Data Model

```
Posts (Postgres, sharded):
  post_id, subreddit_id, user_id, title, content,
  upvotes, downvotes, created_at, hot_score

Comments (Postgres):
  comment_id, post_id, parent_comment_id (nullable),
  user_id, content, upvotes, downvotes, created_at

Subreddits:
  subreddit_id, name, description, subscriber_count

Users:
  user_id, username, karma, created_at

Cached Lists (Redis):
  subreddit:{id}:hot → [(post_id, rank), ...]
  front_page:hot → [(post_id, rank), ...]

Durable Lists (Cassandra):
  Partition key: list_type + list_id
  Clustering key: rank
  Fields: post_id, score
```

## Scaling Strategies

1. **Job queues** for all write-heavy operations (posts, votes)
2. **Partition vote queues by subreddit** to reduce lock contention
3. **Pre-compute and cache** ranked lists (avoid expensive DB queries)
4. **Database sharding** by subreddit
5. **Read replicas** for scaling read queries
6. **Cassandra** as durable backup for cached lists
7. **Zookeeper** for distributed lock coordination

## Interview Tips

- Start with Reddit's evolution: single machine → sharded multi-service architecture
- Explain WHY voting is the hardest problem (lock contention, cache invalidation)
- Draw the **partitioned queue** solution with modulo hashing
- Mention **pre-computed lists** with cache + Cassandra durability
- Know the hot ranking algorithm concept (upvotes, downvotes, time)
- Discuss the tradeoff: eventual consistency on votes vs instant UI feedback
- Compare with Twitter's fan-out approach (pull vs push model)

## Quick Revision (5 bullet points)

1. **Post submission + voting are async** via job queues to avoid blocking user requests on expensive multi-table updates
2. **Ranked feeds are pre-computed** and stored in Redis (post IDs + rank); Cassandra as durable backup
3. **Vote queue partitioned by subreddit** (`subreddit_id % N`) to eliminate lock contention on popular posts
4. **Zookeeper** provides distributed locks for vote processors; atomic read-mutate-write prevents cache race conditions
5. **Database evolved**: single Postgres → vertical scaling → sharded by subreddit → read replicas; Cassandra for list durability
