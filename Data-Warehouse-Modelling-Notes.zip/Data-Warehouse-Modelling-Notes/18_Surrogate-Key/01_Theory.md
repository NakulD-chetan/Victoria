# Surrogate Key

> "The surrogate does not tell you what the thing is—it tells you which row in the warehouse story you mean."

**Real-world analogy:** A surrogate key is like the internal sequence number printed on a retail return ticket: customers care about the receipt barcode, but the service desk system assigns a new opaque ticket id for every visit so merges, splits, and rebrands never collide in the database.

---

## Core Idea (2 Lines)

A **surrogate key** is a warehouse-generated identifier with no business meaning, used as the primary key of dimension rows and referenced by foreign keys on facts to keep joins stable across source changes. It complements—not replaces—natural keys preserved as attributes for integration and audit.

---

## Natural / Business Key: Definition and Examples

A **natural** or **business** key is an identifier understood by business systems and people.

| Domain | Example natural keys | Retail notes |
|--------|----------------------|--------------|
| Store | Banner store number `4821` | May change format during mergers |
| Product | UPC, EAN, style-color-size | Reused across seasons sometimes |
| Pharmacy Rx | Prescription number + store id | Strict privacy; still a business identifier |
| Smart codes | `DEPT-14-AISLE-3-SKU-778` | Human-readable composite |

```sql
-- Natural key appears as a column, not necessarily the PK
CREATE TABLE dim_product (
    product_key    BIGINT      NOT NULL PRIMARY KEY, -- surrogate
    product_id     VARCHAR(20) NOT NULL,             -- natural / business
    product_desc   VARCHAR(120) NOT NULL
);
```

**Interview Tip:** Clarify composite natural keys (e.g., `chain_id` + `legacy_sku`) versus single-column marketing codes.

**Watch Out!** “Smart” codes embed hierarchy segments that change when merchandising reorganizes, breaking assumptions in downstream SQL.

---

## Stability Problems with Natural Keys

| Issue | Retail manifestation | Impact on analytics |
|-------|------------------------|---------------------|
| Source rekeys | ERP replaces store ids after acquisition | Historical facts appear under “new” store unless remapped |
| Reuse | Loyalty card numbers recycled after dormancy policy | Wrong customer profile joins |
| Format drift | Leading zeros dropped in flat files | Duplicate false matches |
| Ambiguity | Private label UPC shared across packs | Colliding product rows |

ASCII stability view:

```
  SOURCE CHANGE (same real-world store)
        |
        v
 business_key:  '4821'  --->  'AZ-104821'
        |
        +-- surrogate store_key:  unchanged 910017
```

**Watch Out!** Fixing natural keys in the dimension without SCD strategy rewrites history (Type 1 risk).

---

## Mergers and Multi-Source Scenarios

When two retail banners combine:

| Challenge | Surrogate approach |
|-----------|-------------------|
| Duplicate stores | Master data creates one `store_key`; source ids map in bridge |
| Overlapping SKUs | `product_id` namespace prefix + conformed `product_key` |
| Different calendars | Still one `dim_date`; map source dates |

Staging example keys:

| SourceSystem | SourceStoreId | Conformed store_key |
|--------------|-----------------|---------------------|
| LegacyPOS | 4821 | 910017 |
| NewERP | AZ-104821 | 910017 |

**Interview Tip:** Surrogates decouple the warehouse from any single source’s numbering scheme.

---

## Surrogate Key: Definition and Placement

| Placement | Usage |
|-----------|-------|
| Dimension PK | `dim_customer.customer_key` |
| Fact FK | `fact_store_sales.customer_key` |
| Not usually on pure measure columns | Measures are numeric facts |

```sql
CREATE TABLE dim_customer (
    customer_key   BIGINT NOT NULL PRIMARY KEY,
    loyalty_card_id VARCHAR(32) NOT NULL,
    email_hash      VARBINARY(32) NULL
);

CREATE TABLE fact_store_sales (
    sale_line_key BIGINT NOT NULL PRIMARY KEY,
    customer_key   BIGINT NULL REFERENCES dim_customer(customer_key),
    net_sales_amount DECIMAL(12,2) NOT NULL
);
```

**Watch Out!** Nullable `customer_key` on facts complicates “distinct customers” metrics unless modeled with an unknown member row.

---

## Advantages of Surrogate Keys

| Advantage | Explanation |
|-----------|-------------|
| Stability | Survives business key changes with SCD support |
| Size | Integer joins are compact vs long composite strings |
| Join performance | Narrow keys help hash joins and column pruning |
| Integration | One key for many source natural ids |
| SCD Type 2 | Each version gets its own surrogate; facts point to correct version |

Retail illustration: a shopper changes loyalty cards; `loyalty_card_id` updates (Type 1) or versions (Type 2) while analytics often still keys off `customer_key` if master data links cards.

**Interview Tip:** Lead with stability and SCD when asked “why surrogate?”

---

## Disadvantages and Risks

| Disadvantage | Mitigation |
|--------------|------------|
| Extra ETL | Generate keys in controlled steps; audit row counts |
| No business meaning | Always retain natural keys as attributes |
| Collision risk (bad generator) | Use DB identity/sequence with overflow guards |
| Debugging harder | Publish key maps and data lineage views |

**Watch Out!** Using UUID strings as PK/FK everywhere can bloat fact tables at billions of rows compared to bigint.

---

## Generation Patterns

| Pattern | Description | Retail usage |
|---------|-------------|--------------|
| Identity / auto-increment | DB assigns next integer | Common for `dim_*` |
| Sequence | Explicit `NEXTVAL` | MPP warehouses, Oracle-style |
| Hash of business key | Deterministic surrogate | Cross-region idempotent loads |
| UUID | Globally unique 128-bit | Occasionally for distributed staging |

```sql
-- SQL Server style identity surrogate
CREATE TABLE dim_store (
    store_key INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    store_id  VARCHAR(10) NOT NULL
);

-- Hash surrogate sketch (policy-dependent)
-- product_key = HASHBYTES('SHA2_256', CONCAT(source_system, '|', source_sku))
```

**Interview Tip:** Hash keys can help idempotent merges but complicate Type 2 if collisions or algorithm changes occur—many shops prefer sequences for dimensions.

**Watch Out!** Recomputing hash surrogates with a changed algorithm invalidates all historical facts.

---

## When to Use Surrogate vs Natural

| Favor surrogate | Natural key acceptable as PK |
|-----------------|------------------------------|
| Type 2 customer or product | Tiny static reference tables (e.g., 5-row tender type) |
| Multi-source integration | Import-only codes never change |
| Large fact joins | Some bridge tables with stable composite |

Decision table:

| Scenario | Recommendation |
|----------|------------------|
| `dim_product` with rebrands | Surrogate PK |
| `dim_payment_tender` rarely changes | Surrogate still typical; small natural PK possible |
| Factless fact at exact event grain | Composite of dimension keys sometimes |

---

## Connection to SCD Type 2

SCD Type 2 issues a **new surrogate row** when tracked attributes change:

| customer_key | loyalty_card_id | effective_date | end_date | current_flag |
|--------------|-----------------|----------------|----------|--------------|
| 501 | CARD-AAA | 2020-01-01 | 2023-06-30 | N |
| 712 | CARD-BBB | 2023-07-01 | NULL | Y |

Facts on 2022-05-01 must store `customer_key = 501`, not the shopper’s person id alone.

**Watch Out!** Storing only `loyalty_card_id` on the fact loses the ability to join to the correct historical attribute row.

---

## Retail Example: Pharmacy Counter

Even when regulations require storing prescription numbers, the analytic dimension uses surrogates:

```sql
CREATE TABLE dim_prescription (
    prescription_key BIGINT NOT NULL PRIMARY KEY,
    rx_number          VARCHAR(20) NOT NULL,
    store_key          INT NOT NULL,
    written_date_key   INT NOT NULL
);
```

Facts reference `prescription_key` while operational joins use `rx_number` + `store_key` in controlled environments.

**Interview Tip:** Surrogates support anonymized keys exposed to broader analytics sandboxes.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Surrogate without stored natural key | Cannot reconcile to source | Keep business keys as columns |
| Recycling deleted surrogate | Silent wrong joins | Never reuse keys |
| UUID on trillion-row facts without need | Storage and join bloat | Prefer bigint surrogate |
| Natural PK on Type 2 rows | Cannot distinguish versions | Surrogate per version |
| Different surrogates for same conformed entity across marts | Non-additive enterprise reports | Master conformed key hub |

---

## Key Takeaway

> Use meaningless surrogate keys as the join backbone for retail dimensions and facts, preserve natural keys for traceability, and align surrogate generation with SCD Type 2 so every sale row references the product and customer exactly as the business was on that day.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) Surrogate = opaque warehouse key; not shown to shoppers.      |
| 2) Natural key stays as an attribute for integration.           |
| 3) Stability beats human-readable PKs in SCD worlds.           |
| 4) Prefer bigint/identity for large facts over wide UUIDs.    |
| 5) Mergers: map many source ids to one conformed surrogate.    |
| 6) SCD2: new surrogate row; fact stores that version’s key.      |
| 7) Never recycle surrogates; treat collisions as incidents.      |
+------------------------------------------------------------------+
```
