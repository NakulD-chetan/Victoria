import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { SkeletonCard, SkeletonTagCloud } from '../shared/Skeleton';

const API_BASE = '/api';
const DIFF_COLORS = {
  Easy: 'var(--accent)',
  Medium: 'var(--accent-warm)',
  Hard: 'var(--danger)',
};

export default function AlgorithmCatalog() {
  const [algorithms, setAlgorithms] = useState([]);
  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [selectedTag, setSelectedTag] = useState(null);
  const [tagsExpanded, setTagsExpanded] = useState(false);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const debounceRef = useRef(null);
  const abortRef = useRef(null);
  const cacheRef = useRef(new Map());
  const limit = 24;

  const buildCacheKey = (pg, cat, tag, q) => `${pg}|${cat}|${tag}|${q}`;

  const fetchAlgorithms = useCallback(async (pg, cat, tag, q) => {
    const key = buildCacheKey(pg, cat, tag, q);
    const cached = cacheRef.current.get(key);
    if (cached) {
      setAlgorithms(cached.data);
      setTotal(cached.total);
      setLoading(false);
      return;
    }

    if (abortRef.current) abortRef.current.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    const params = new URLSearchParams({ page: pg, limit });
    if (cat && cat !== 'All') params.set('category', cat);
    if (tag) params.set('tag', tag);
    if (q) params.set('q', q);

    try {
      const res = await fetch(`${API_BASE}/algorithms?${params}`, { signal: controller.signal });
      if (res.ok) {
        const json = await res.json();
        const data = json.data || [];
        const t = json.total || data.length;
        setAlgorithms(data);
        setTotal(t);
        cacheRef.current.set(key, { data, total: t });
        if (cacheRef.current.size > 50) {
          const first = cacheRef.current.keys().next().value;
          cacheRef.current.delete(first);
        }
      } else {
        setAlgorithms([]);
        setTotal(0);
      }
    } catch (e) {
      if (e.name !== 'AbortError') { setAlgorithms([]); setTotal(0); }
    }
    setLoading(false);
  }, []);

  const fetchMeta = useCallback(async () => {
    const [catRes, tagRes] = await Promise.all([
      fetch(`${API_BASE}/algorithms/categories`),
      fetch(`${API_BASE}/algorithms/tags`),
    ]);
    if (catRes.ok) {
      const cats = await catRes.json();
      setCategories(cats.map(c => ({ name: c.name, count: c.count })));
    }
    if (tagRes.ok) {
      setTags(await tagRes.json());
    }
  }, []);

  useEffect(() => { fetchMeta(); }, [fetchMeta]);

  useEffect(() => {
    fetchAlgorithms(page, category, selectedTag, search);
  }, [page, category, selectedTag, fetchAlgorithms]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(1);
      fetchAlgorithms(1, category, selectedTag, search);
    }, 400);
    return () => clearTimeout(debounceRef.current);
  }, [search]);

  const navigate = (href) => {
    window.history.pushState(null, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  const visibleTags = tagsExpanded ? tags : tags.slice(0, 10);
  const totalPages = Math.ceil(total / limit);
  const allCategories = useMemo(() => [{ name: 'All', count: total }, ...categories], [categories, total]);

  const activeFilters = (category !== 'All' ? 1 : 0) + (selectedTag ? 1 : 0) + (search ? 1 : 0);

  return (
    <div className="dc-catalog dc-catalog--wide">
      <div className="dc-catalog__header">
        <h1 className="dc-catalog__title">Algorithm Visualizations</h1>
        <p className="dc-catalog__desc">Interactive step-by-step visualizations of classic algorithms.</p>
      </div>

      <div className="dc-catalog__search-row">
        <div className="dc-search-wrap">
          <svg className="dc-search-wrap__icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            type="text"
            placeholder="Search algorithms..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="dc-search-input"
          />
          {search && (
            <button className="dc-search-wrap__clear" onClick={() => setSearch('')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>
        <span className="dc-catalog__count">{total} algorithms</span>
      </div>

      {loading && tags.length === 0 ? (
        <SkeletonTagCloud />
      ) : (
        <div className="dc-tag-cloud">
          <div className="dc-tag-cloud__wrap">
            {allCategories.map((cat) => (
              <button
                key={cat.name}
                className={`dc-tag-pill dc-tag-pill--cat ${category === cat.name ? 'dc-tag-pill--active' : ''}`}
                onClick={() => { setCategory(category === cat.name ? 'All' : cat.name); setSelectedTag(null); setPage(1); }}
              >
                {cat.name}
                <span className="dc-tag-pill__count">{cat.count}</span>
              </button>
            ))}
          </div>
          <div className="dc-tag-cloud__wrap">
            {visibleTags.map((tag) => (
              <button
                key={tag.name}
                className={`dc-tag-pill ${selectedTag === tag.name ? 'dc-tag-pill--active' : ''}`}
                onClick={() => { setSelectedTag(selectedTag === tag.name ? null : tag.name); setPage(1); }}
              >
                {tag.name}
                <span className="dc-tag-pill__count">{tag.count}</span>
              </button>
            ))}
            {tags.length > 10 && (
              <button className="dc-tag-cloud__toggle" onClick={() => setTagsExpanded(!tagsExpanded)}>
                {tagsExpanded ? 'Collapse' : `+${tags.length - 10} more`}
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: tagsExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
                  <polyline points="6 9 12 15 18 9" />
                </svg>
              </button>
            )}
          </div>
          {activeFilters > 0 && (
            <button className="dc-tag-cloud__clear" onClick={() => { setCategory('All'); setSelectedTag(null); setSearch(''); setPage(1); }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
              </svg>
              Clear all filters
            </button>
          )}
        </div>
      )}

      <div className="dc-card-grid">
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
        ) : (
          algorithms.map((algo) => (
            <button key={algo.slug} className="dc-algo-card" onClick={() => navigate(`/algorithms/${algo.slug}`)}>
              <div className="dc-algo-card__top">
                <span className="dc-algo-card__icon">{algo.icon}</span>
                <div>
                  <div className="dc-algo-card__title">{algo.title}</div>
                  <div className="dc-algo-card__cat">{algo.category}</div>
                </div>
                <span className="dc-badge" style={{ background: DIFF_COLORS[algo.difficulty], color: '#fff' }}>{algo.difficulty}</span>
              </div>
              <p className="dc-algo-card__desc">{algo.short_description || algo.shortDescription}</p>
              <div className="dc-algo-card__tags">
                {(algo.tags || []).slice(0, 3).map((t) => (
                  <span key={t} className="dc-algo-tag">{t}</span>
                ))}
              </div>
            </button>
          ))
        )}
      </div>

      {!loading && algorithms.length === 0 && <div className="dc-empty">No algorithms match your search.</div>}

      {totalPages > 1 && (
        <div className="dc-pagination">
          <button
            className="dc-pagination__btn"
            disabled={page <= 1}
            onClick={() => setPage(p => p - 1)}
          >
            Previous
          </button>
          <span className="dc-pagination__info">Page {page} of {totalPages}</span>
          <button
            className="dc-pagination__btn"
            disabled={page >= totalPages}
            onClick={() => setPage(p => p + 1)}
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
