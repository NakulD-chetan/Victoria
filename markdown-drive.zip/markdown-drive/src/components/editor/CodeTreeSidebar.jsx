import { memo, useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useFileStore } from './useFileStore';
import { useVaultStore } from '../../stores/vault-store';
import VaultManagerModal from '../VaultManagerModal';

function fileMatchesQuery(file, query) {
  if (!query?.trim()) return true;
  const q = query.trim().toLowerCase();
  return (file.name || '').toLowerCase().includes(q)
    || (file.content || '').toLowerCase().includes(q);
}

function folderMatchesQuery(folder, allFolders, allFiles, query) {
  if (!query?.trim()) return true;
  const q = query.trim().toLowerCase();
  if ((folder.name || '').toLowerCase().includes(q)) return true;
  const hasFile = allFiles.some(
    (f) => (f.folderId || null) === folder.id && fileMatchesQuery(f, q)
  );
  if (hasFile) return true;
  const children = allFolders.filter((d) => d.parentId === folder.id);
  return children.some((child) => folderMatchesQuery(child, allFolders, allFiles, q));
}

function sortFilesList(list, sortMode) {
  const sorted = [...list];
  sorted.sort((a, b) => {
    if (sortMode === 'name') {
      return (a.name || '').localeCompare(b.name || '');
    }
    return (a.name || '').localeCompare(b.name || '');
  });
  return sorted;
}

function clampContextMenuPosition(anchor, menuEl) {
  const margin = 8;
  if (!anchor || !menuEl) return null;
  const rect = menuEl.getBoundingClientRect();
  const width = rect.width || 180;
  const height = rect.height || 120;
  return {
    left: Math.min(Math.max(anchor.x, margin), window.innerWidth - width - margin),
    top: Math.min(Math.max(anchor.y, margin), window.innerHeight - height - margin),
  };
}

function TreeFile({ file, isActive, onOpen, onDelete, onDuplicate, onStartRename }) {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const closeOnEscape = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const closeOnScrollOrResize = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('resize', closeOnScrollOrResize);
    window.addEventListener('scroll', closeOnScrollOrResize, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('resize', closeOnScrollOrResize);
      window.removeEventListener('scroll', closeOnScrollOrResize, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  return (
    <div
      className={`ft-node ft-node--file ${isActive ? 'ft-node--active' : ''}`}
      style={{ paddingLeft: 14 }}
      onClick={() => onOpen(file.id)}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setMenuAnchor({ x: e.clientX, y: e.clientY });
        setMenuPos(null);
      }}
    >
      <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
      </svg>
      <span className="ft-node__label">{file.name || 'Untitled'}</span>

      {menuAnchor && (
        <div
          ref={menuRef}
          className="ft-ctx"
          style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={() => { onOpen(file.id); setMenuAnchor(null); }}>Open</button>
          <button onClick={() => { onStartRename(file.id, file.name); setMenuAnchor(null); }}>Rename</button>
          <button onClick={() => { onDuplicate(file.id); setMenuAnchor(null); }}>Duplicate</button>
          <button className="ft-ctx--danger" onClick={() => { onDelete(file.id); setMenuAnchor(null); }}>Delete</button>
        </div>
      )}
    </div>
  );
}

function TreeRenameRow({ initialValue, depth, kind, onSubmit, onCancel }) {
  const [val, setVal] = useState(initialValue || '');
  const inputRef = useRef(null);
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, []);
  return (
    <div
      className="ft-node ft-node--creating"
      style={{ paddingLeft: depth > 0 ? 14 : 10 }}
      onClick={(e) => e.stopPropagation()}
    >
      {kind === 'folder' ? (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
        </svg>
      ) : (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
        </svg>
      )}
      <input
        ref={inputRef}
        className="ft-node__edit"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={() => onSubmit(val)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') onSubmit(val);
          if (e.key === 'Escape') onCancel();
        }}
        placeholder={kind === 'folder' ? 'Folder name...' : 'filename.ext'}
      />
    </div>
  );
}

function TreeFolder({
  folder, depth, files, allFolders, activeFileId,
  deleteFile, duplicateFile, renameFile, startRenameFile,
  deleteFolder, renameFolder, createFolder, createFile, openFileInTab,
  searchQuery, sortMode, renamingId, beginRename, cancelRename,
  creatingIn, setCreatingIn, foldCommand,
}) {
  const [collapsed, setCollapsed] = useState(false);

  /* Parent-driven expand/collapse all. `foldCommand` is a { action, nonce }
   * object — bumping the nonce re-triggers the effect even if the action
   * is repeated. */
  useEffect(() => {
    if (!foldCommand) return;
    if (foldCommand.action === 'collapse') setCollapsed(true);
    else if (foldCommand.action === 'expand') setCollapsed(false);
  }, [foldCommand]);
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const menuRef = useRef(null);

  const childFolders = allFolders.filter((d) =>
    d.parentId === folder.id
    && folderMatchesQuery(d, allFolders, files, searchQuery)
  );
  const childFiles = sortFilesList(
    files.filter((f) => (f.folderId || null) === folder.id && fileMatchesQuery(f, searchQuery)),
    sortMode
  );

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const closeOnEscape = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const closeOnScrollOrResize = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', closeOnEscape);
    window.addEventListener('resize', closeOnScrollOrResize);
    window.addEventListener('scroll', closeOnScrollOrResize, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', closeOnEscape);
      window.removeEventListener('resize', closeOnScrollOrResize);
      window.removeEventListener('scroll', closeOnScrollOrResize, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  const isRenamingThis = renamingId === folder.id;
  const isCreatingHere = creatingIn?.folderId === folder.id;

  return (
    <>
      {isRenamingThis ? (
        <TreeRenameRow
          initialValue={folder.name}
          depth={depth}
          kind="folder"
          onSubmit={(v) => { const t = (v || '').trim(); if (t) renameFolder(folder.id, t); cancelRename(); }}
          onCancel={cancelRename}
        />
      ) : (
        <div
          className={`ft-node ft-node--folder ${depth > 0 ? 'ft-node--guided' : ''}`}
          style={{ paddingLeft: 6 }}
          onClick={() => setCollapsed(!collapsed)}
          onContextMenu={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setMenuAnchor({ x: e.clientX, y: e.clientY });
            setMenuPos(null);
          }}
        >
          <svg className="ft-node__arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3"
            style={{ transform: collapsed ? 'rotate(-90deg)' : 'rotate(0)' }}>
            <polyline points="8 10 12 14 16 10" />
          </svg>
          <span className="ft-node__label">{folder.name}</span>

          {menuAnchor && (
            <div
              ref={menuRef}
              className="ft-ctx"
              style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={() => {
                setCreatingIn({ kind: 'file', folderId: folder.id });
                setCollapsed(false);
                setMenuAnchor(null);
              }}>New file here</button>
              <button onClick={() => {
                setCreatingIn({ kind: 'folder', folderId: folder.id });
                setCollapsed(false);
                setMenuAnchor(null);
              }}>New sub-folder</button>
              <button onClick={() => { beginRename(folder.id); setMenuAnchor(null); }}>Rename</button>
              <button className="ft-ctx--danger" onClick={() => { deleteFolder(folder.id); setMenuAnchor(null); }}>Delete folder</button>
            </div>
          )}
        </div>
      )}

      <div className={`ft-children ${collapsed ? 'ft-children--collapsed' : 'ft-children--expanded'}`}>
        <div className="ft-children__inner">
          {isCreatingHere && (
            <TreeRenameRow
              initialValue=""
              depth={depth + 1}
              kind={creatingIn.kind}
              onSubmit={(v) => {
                const t = (v || '').trim();
                if (t) {
                  if (creatingIn.kind === 'folder') {
                    createFolder(t, folder.id);
                  } else {
                    const id = createFile(t, folder.id);
                    if (id) openFileInTab(id);
                  }
                }
                setCreatingIn(null);
              }}
              onCancel={() => setCreatingIn(null)}
            />
          )}

          {childFolders.map((child) => (
            <TreeFolder
              key={child.id}
              folder={child}
              depth={depth + 1}
              files={files}
              allFolders={allFolders}
              activeFileId={activeFileId}
              deleteFile={deleteFile}
              duplicateFile={duplicateFile}
              renameFile={renameFile}
              startRenameFile={startRenameFile}
              deleteFolder={deleteFolder}
              renameFolder={renameFolder}
              createFolder={createFolder}
              createFile={createFile}
              openFileInTab={openFileInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              renamingId={renamingId}
              beginRename={beginRename}
              cancelRename={cancelRename}
              creatingIn={creatingIn}
              setCreatingIn={setCreatingIn}
              foldCommand={foldCommand}
            />
          ))}
          {childFiles.map((file) => (
            renamingId === file.id ? (
              <TreeRenameRow
                key={file.id}
                initialValue={file.name}
                depth={depth + 1}
                kind="file"
                onSubmit={(v) => { const t = (v || '').trim(); if (t) renameFile(file.id, t); cancelRename(); }}
                onCancel={cancelRename}
              />
            ) : (
              <TreeFile
                key={file.id}
                file={file}
                isActive={file.id === activeFileId}
                onOpen={openFileInTab}
                onDelete={deleteFile}
                onDuplicate={duplicateFile}
                onStartRename={startRenameFile}
              />
            )
          ))}
        </div>
      </div>
    </>
  );
}

const CodeTreeSidebar = memo(function CodeTreeSidebar({ onNewFile, onThemeToggle }) {
  const filesMap = useFileStore((s) => s.files);
  const foldersMap = useFileStore((s) => s.folders);
  const activeFile = useFileStore((s) => s.activeFile);
  const setActiveFile = useFileStore((s) => s.setActiveFile);
  const createFile = useFileStore((s) => s.createFile);
  const deleteFile = useFileStore((s) => s.deleteFile);
  const renameFile = useFileStore((s) => s.renameFile);
  const duplicateFile = useFileStore((s) => s.duplicateFile);
  const createFolder = useFileStore((s) => s.createFolder);
  const deleteFolder = useFileStore((s) => s.deleteFolder);
  const renameFolder = useFileStore((s) => s.renameFolder);

  const [collapsed, setCollapsed] = useState(false);
  const [creatingIn, setCreatingIn] = useState(null); // { kind: 'file'|'folder', folderId: string|null }
  const [renamingId, setRenamingId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState('name');
  const [allExpanded, setAllExpanded] = useState(true);
  const [foldCommand, setFoldCommand] = useState(null);
  const [foldAnimating, setFoldAnimating] = useState(false);
  const [vaultModalOpen, setVaultModalOpen] = useState(false);
  const activeVault = useVaultStore((s) => s.getActiveVault());
  const vaultTriggerRef = useRef(null);
  const searchRef = useRef(null);

  const filesArr = useMemo(() => Object.values(filesMap), [filesMap]);
  const foldersArr = useMemo(() => Object.values(foldersMap), [foldersMap]);

  const rootFolders = useMemo(() => (
    foldersArr
      .filter((d) => (d.parentId || null) === null && folderMatchesQuery(d, foldersArr, filesArr, searchQuery))
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
  ), [foldersArr, filesArr, searchQuery]);

  const rootFiles = useMemo(() => sortFilesList(
    filesArr.filter((f) => (f.folderId || null) === null && fileMatchesQuery(f, searchQuery)),
    sortMode,
  ), [filesArr, searchQuery, sortMode]);

  const hasResults = rootFolders.length > 0 || rootFiles.length > 0;
  const hasAny = filesArr.length > 0 || foldersArr.length > 0;

  useEffect(() => {
    const onFocusSearch = (e) => {
      // Skip if target is inside Monaco editor
      const target = e.target;
      if (target?.closest?.('.monaco-editor')) return;
      
      const key = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && key === 'f') {
        e.preventDefault();
        searchRef.current?.focus();
        searchRef.current?.select();
      }
    };
    window.addEventListener('keydown', onFocusSearch, true);
    return () => window.removeEventListener('keydown', onFocusSearch, true);
  }, []);

  const openFileInTab = useCallback((id) => {
    setActiveFile(id);
  }, [setActiveFile]);

  const startRenameFile = useCallback((id) => {
    setRenamingId(id);
  }, []);

  const beginRename = useCallback((id) => setRenamingId(id), []);
  const cancelRename = useCallback(() => setRenamingId(null), []);

  const handleToggleSort = useCallback(() => {
    setSortMode((prev) => (prev === 'name' ? 'recent' : 'name'));
  }, []);

  const handleToggleFoldAll = useCallback(() => {
    setAllExpanded((prev) => {
      const next = !prev;
      setFoldCommand({ action: next ? 'expand' : 'collapse', nonce: Date.now() });
      return next;
    });
    setFoldAnimating(true);
    setTimeout(() => setFoldAnimating(false), 360);
  }, []);

  const handleNewFileTopLevel = useCallback(() => {
    if (onNewFile) {
      onNewFile();
      return;
    }
    setCreatingIn({ kind: 'file', folderId: null });
  }, [onNewFile]);

  const handleNewFolderTopLevel = useCallback(() => {
    setCreatingIn({ kind: 'folder', folderId: null });
  }, []);

  const rootCreatingHere = creatingIn && (creatingIn.folderId === null || creatingIn.folderId === undefined);

  return (
    <div className={`ft-sidebar${collapsed ? ' ft-sidebar--collapsed' : ''}`}>
      {collapsed ? (
        <button
          type="button"
          className="ft-sidebar__toggle"
          onClick={() => setCollapsed(false)}
          title="Expand sidebar"
          aria-label="Expand sidebar"
          aria-expanded={false}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
        </button>
      ) : (
      <div className="ft-pane">
        <div className="ft-actions">
          <button className="ft-actions__btn" onClick={handleNewFileTopLevel} title="New file">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
              <polyline points="14 2 14 8 20 8" />
              <line x1="12" y1="18" x2="12" y2="12" />
              <line x1="9" y1="15" x2="15" y2="15" />
            </svg>
          </button>
          <button className="ft-actions__btn" onClick={handleNewFolderTopLevel} title="New folder">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
              <line x1="12" y1="11" x2="12" y2="17" />
              <line x1="9" y1="14" x2="15" y2="14" />
            </svg>
          </button>
          <button className="ft-actions__btn" title={`Sort: ${sortMode === 'name' ? 'Name' : 'Recent'}`} onClick={handleToggleSort}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" y1="6" x2="20" y2="6" /><line x1="4" y1="12" x2="14" y2="12" /><line x1="4" y1="18" x2="10" y2="18" /></svg>
          </button>
          <button
            className={`ft-actions__btn ft-fold-all${foldAnimating ? ' ft-fold-all--animating' : ''}`}
            title={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-label={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-pressed={!allExpanded}
            onClick={handleToggleFoldAll}
          >
            <span className="ft-fold-all__icon" key={allExpanded ? 'expanded' : 'collapsed'}>
              {allExpanded ? (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="17 11 12 6 7 11" />
                  <polyline points="17 18 12 13 7 18" />
                </svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="7 13 12 18 17 13" />
                  <polyline points="7 6 12 11 17 6" />
                </svg>
              )}
            </span>
          </button>
          <button className="ft-actions__btn" title="Collapse sidebar" onClick={() => setCollapsed(true)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><line x1="9" y1="3" x2="9" y2="21" /></svg>
          </button>
        </div>

        <div className="ft-search">
          <svg className="ft-search__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            ref={searchRef}
            className="ft-search__input"
            placeholder="Search files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="ft-search__clear" onClick={() => setSearchQuery('')} title="Clear search">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>

        <div className="ft-tree">
          {!hasAny && !creatingIn && (
            <div className="ft-tree__empty-state">
              <div className="ft-tree__empty-title">No files available</div>
              <div className="ft-tree__empty-copy">Create a new file to get started.</div>
              <button className="ft-tree__empty-btn" onClick={handleNewFileTopLevel}>Create new file</button>
            </div>
          )}

          {rootCreatingHere && (
            <TreeRenameRow
              initialValue=""
              depth={0}
              kind={creatingIn.kind}
              onSubmit={(v) => {
                const t = (v || '').trim();
                if (t) {
                  if (creatingIn.kind === 'folder') {
                    createFolder(t, null);
                  } else {
                    const id = createFile(t, null);
                    if (id) openFileInTab(id);
                  }
                }
                setCreatingIn(null);
              }}
              onCancel={() => setCreatingIn(null)}
            />
          )}

          {rootFolders.map((folder) => (
            <TreeFolder
              key={folder.id}
              folder={folder}
              depth={0}
              files={filesArr}
              allFolders={foldersArr}
              activeFileId={activeFile}
              deleteFile={deleteFile}
              duplicateFile={duplicateFile}
              renameFile={renameFile}
              startRenameFile={startRenameFile}
              deleteFolder={deleteFolder}
              renameFolder={renameFolder}
              createFolder={createFolder}
              createFile={createFile}
              openFileInTab={openFileInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              renamingId={renamingId}
              beginRename={beginRename}
              cancelRename={cancelRename}
              creatingIn={creatingIn}
              setCreatingIn={setCreatingIn}
              foldCommand={foldCommand}
            />
          ))}

          {rootFiles.map((file) => (
            renamingId === file.id ? (
              <TreeRenameRow
                key={file.id}
                initialValue={file.name}
                depth={0}
                kind="file"
                onSubmit={(v) => { const t = (v || '').trim(); if (t) renameFile(file.id, t); cancelRename(); }}
                onCancel={cancelRename}
              />
            ) : (
              <TreeFile
                key={file.id}
                file={file}
                isActive={file.id === activeFile}
                onOpen={openFileInTab}
                onDelete={deleteFile}
                onDuplicate={duplicateFile}
                onStartRename={startRenameFile}
              />
            )
          ))}

          {hasAny && !hasResults && (
            <div className="ft-tree__empty">No files found</div>
          )}
        </div>

        <div className="ft-bottom">
          <button
            ref={vaultTriggerRef}
            type="button"
            className="ft-bottom__vault-btn"
            title={`Active vault: ${activeVault?.name || 'MY_DATA'} — click to manage vaults`}
            aria-haspopup="menu"
            aria-expanded={vaultModalOpen}
            onClick={() => setVaultModalOpen((v) => !v)}
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z" /></svg>
            <span className="ft-bottom__vault-btn-name">
              {(activeVault?.name || 'MY_DATA').toUpperCase()}
            </span>
          </button>
          <VaultManagerModal
            open={vaultModalOpen}
            onClose={() => setVaultModalOpen(false)}
            anchorRef={vaultTriggerRef}
          />
        </div>
      </div>
      )}
    </div>
  );
});

export default CodeTreeSidebar;
