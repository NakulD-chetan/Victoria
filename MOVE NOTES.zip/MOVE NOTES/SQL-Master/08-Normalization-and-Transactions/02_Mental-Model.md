# Normalization and Transactions — Mental Model

---

## Normalization = "one fact, one place"

```
UNNORMALIZED:
  orders(order_id, product_name, product_price, customer_name, customer_city)
  → Update product_price? Change in EVERY order row!

NORMALIZED:
  orders(order_id, product_id, customer_id)
  products(product_id, name, price)
  customers(customer_id, name, city)
  → Update price once in products table
```

---

## Normal form staircase

```
1NF: No multi-value cells      "each cell = one value"
  ↓
2NF: No partial dependency     "non-key depends on WHOLE PK"
  ↓
3NF: No transitive dependency  "non-key depends ONLY on PK, not via another non-key"
  ↓
BCNF: Every determinant = CK   "strict version of 3NF"
```

---

## Transaction mental picture

```
BEGIN;
  UPDATE accounts SET balance = balance - 100 WHERE id = 1;  -- debit
  UPDATE accounts SET balance = balance + 100 WHERE id = 2;  -- credit
COMMIT;

If ANYTHING fails → ROLLBACK → as if nothing happened (Atomicity)
```

---

## Isolation = "how much of other tx do I see?"

**Hinglish:** Read Uncommitted = sabka kaccha kaam dikhe. Serializable = ek time pe ek hi kaam hota dikh raha.

---

*Next: [[03_Coding-Template]]*
