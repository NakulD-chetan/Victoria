# Dynamic Programming — Edge Cases

> **Permanent Recall:** Empty input, single element, all same — test these first. Negative values break knapsack. Large tables → memory. Language-specific: Python recursion depth, C++ stack overflow, Rust stack in deep recursion.

---

## Input Edge Cases

### 1. Empty Input

| Problem Type | Expected | Common Bug |
|--------------|----------|------------|
| Count ways | 0 or 1 | Returning uninitialized; index error |
| Max/min value | 0 or -∞/∞ | Wrong default |
| String DP | 0 (LCS), n (edit dist) | dp[0][0] wrong |

```
Always handle: if not nums: return 0  (or appropriate default)
```

---

### 2. Single Element

| Problem Type | Expected | Common Bug |
|--------------|----------|------------|
| House Robber | nums[0] | dp[1] undefined if only dp[0] base |
| Climbing Stairs | 1 | n=1 → 1 way |
| LIS | 1 | Single element = length 1 |
| Coin Change | 0 if amount=0, -1 if amount>0 and no coin | amount=0 → 0 |

---

### 3. All Same Elements

| Problem Type | Edge Case | Expected |
|--------------|-----------|----------|
| LIS | [5,5,5,5] | 1 (strictly increasing fails) |
| LCS | "aaa", "aaa" | 3 |
| Max subarray | All negative | Single max element (not 0) |

---

## Knapsack Edge Cases

| Edge Case | Issue | Fix |
|-----------|-------|-----|
| **Negative weight** | Invalid; w - weight[i] can go negative | Problem redefinition or filter |
| **Negative value** | "Max value" may want negative; 0/1 knapsack usually assumes non-negative | Clarify; may need different formulation |
| **Zero weight** | Can take for free; watch division | Handle w>=0; avoid div by zero |
| **Zero value** | Valid; take or skip | No special handling |
| **Empty items** | No items to choose | return 0 |
| **W = 0** | No capacity | return 0 |

---

## Large DP Tables (Memory)

| Scenario | Risk | Mitigation |
|----------|------|------------|
| n=10^5, W=10^5 | O(n×W) = 10^10 ints ≈ 40GB | Space optimize to O(W); or different approach |
| 2D string DP, m=n=10^4 | 10^8 cells | May need O(min(m,n)) space; diagonal fill |
| Bitmask n=20 | 2^20 × 20 ≈ 20M | Usually fine; watch stack in recursion |

```
Rule: If table size > 10^7, consider space optimization or different algorithm.
```

---

## String DP Edge Cases

| Edge Case | LCS | Edit Distance |
|-----------|-----|---------------|
| Empty s1 | 0 | len(s2) |
| Empty s2 | 0 | len(s1) |
| s1 == s2 | len(s1) | 0 |
| No common chars | 0 | len(s1)+len(s2) |
| One char each, same | 1 | 0 |
| One char each, diff | 0 | 1 |

---

## Language-Specific Edge Cases

### Python

| Edge Case | Issue | Fix |
|-----------|-------|-----|
| **Recursion depth** | Default 1000; n=10^4 → stack overflow | Use bottom-up; or `sys.setrecursionlimit(10**6)` |
| **Large list allocation** | `[0]*(10**7)` can be slow | Preallocate; consider numpy for huge arrays |
| **Float inf** | `float('inf')` in comparisons | Use `math.inf` (3.5+); handle in min/max |

---

### C++

| Edge Case | Issue | Fix |
|-----------|-------|-----|
| **Stack overflow** | Deep recursion (e.g., n=10^5) | Use iterative bottom-up; avoid recursion |
| **Integer overflow** | dp[i] + value > INT_MAX | Use `long long`; check bounds |
| **Vector allocation** | `vector<vector<int>>(1e5, vector<int>(1e5))` — huge | Space optimize; avoid if possible |

---

### Rust

| Edge Case | Issue | Fix |
|-----------|-------|-----|
| **Stack overflow** | Deep recursion; Rust has small default stack | Use iterative; or `RUST_MIN_STACK` env var |
| **usize underflow** | `i - 1` when i=0 in usize | `i.saturating_sub(1)` or `if i > 0 { i-1 }` |
| **Vec allocation** | Large `Vec::new()` then push | `Vec::with_capacity(n)` for known size |

---

## ASCII: Edge Case Checklist

```
BEFORE SUBMITTING:
  [ ] Empty input
  [ ] Single element
  [ ] Two elements
  [ ] All same
  [ ] Min/max in range (negative, zero)
  [ ] Large n (stack? memory?)

KNAPSACK:
  [ ] W=0
  [ ] No items
  [ ] Single item
  [ ] Impossible (coin change: amount unreachable)

STRINGS:
  [ ] Empty string
  [ ] Single char
  [ ] s1 == s2
  [ ] No overlap
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:         Return 0, 1, or len; never uninitialized
SINGLE:        dp[1] or nums[0]; base case
ALL SAME:      LIS=1 (strict); LCS=len
KNAPSACK:      W=0→0; negative weight/value→special
LARGE TABLE:   Space opt; 10^7 cells = ~40MB ints
STRING:        Empty s1, s2; one char
PYTHON:        Recursion limit 1000
CPP:           Stack overflow; int overflow
RUST:          Stack; usize underflow
```

---

## 30-SECOND REVISION BOX

```
□ Empty input handled?
□ Single element base case?
□ All same (LIS strict)?
□ Knapsack: W=0, negative?
□ Large n: bottom-up, space opt?
□ Python: setrecursionlimit or iterative?
□ C++: long long for overflow?
□ Rust: saturating_sub for i-1?
```
