import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const ITEMS = [
  { id: 'A', v: 60, w: 10 },
  { id: 'B', v: 100, w: 20 },
  { id: 'C', v: 120, w: 30 },
];
const CAP = 50;

function generateSteps() {
  const steps = [];
  const ratios = ITEMS.map((it) => ({ ...it, r: it.v / it.w }));
  ratios.sort((a, b) => b.r - a.r);
  steps.push({
    type: 'sort',
    msg: 'Sort by value/weight (desc)',
    array: ratios.map((x) => Math.round(x.r * 10)),
    colors: {},
  });
  let rem = CAP;
  const taken = [];
  for (let i = 0; i < ratios.length; i++) {
    const it = ratios[i];
    steps.push({
      type: 'consider',
      msg: `Item ${it.id} ratio ${it.r.toFixed(2)}`,
      array: ratios.map((x) => Math.round(x.r * 10)),
      colors: Object.fromEntries(taken.map((j) => [j, 'sorted'])),
      idx: i,
    });
    if (rem <= 0) break;
    if (it.w <= rem) {
      taken.push(i);
      rem -= it.w;
      steps.push({
        type: 'take',
        msg: `Take all of ${it.id} (${it.w} kg)`,
        array: ratios.map((x) => Math.round(x.r * 10)),
        colors: Object.fromEntries(taken.map((j) => [j, 'sorted'])),
        idx: i,
      });
    } else {
      const frac = rem / it.w;
      steps.push({
        type: 'frac',
        msg: `Take ${(frac * 100).toFixed(0)}% of ${it.id}`,
        array: ratios.map((x) => Math.round(x.r * 10)),
        colors: Object.fromEntries(taken.map((j) => [j, 'sorted'])),
        idx: i,
      });
      rem = 0;
    }
  }
  steps.push({
    type: 'done',
    msg: 'Knapsack filled greedily',
    array: ratios.map((x) => Math.round(x.r * 10)),
    colors: Object.fromEntries(ratios.map((_, j) => [j, 'sorted'])),
  });
  return steps;
}

export default function FractionalKnapsackVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray(steps[0].array);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Capacity ${CAP}` });
    canvasRef.current?.setState({ array: steps[0].array, colors: steps[0].colors || {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.setArray(step.array);
    const colors = { ...step.colors };
    if (step.idx != null) colors[step.idx] = 'compare';
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
