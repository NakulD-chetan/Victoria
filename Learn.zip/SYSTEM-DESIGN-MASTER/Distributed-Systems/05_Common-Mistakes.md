# Distributed Systems — Common Mistakes

> **Permanent Recall:** Top 10 mistakes: assuming network is reliable, ignoring clock skew, not handling partial failures, using distributed lock without fencing token, single leader without failover, ignoring split brain, not using heartbeats, over-complicating consensus, ignoring CAP implications, not considering message ordering. Avoid these to demonstrate FAANG-level distributed systems expertise.

---

## Mistake 1: Assuming Network Is Reliable

**What's wrong:** Designing as if messages always arrive, never get delayed or reordered.

| Wrong | Right |
|-------|-------|
| "Send and forget" | Timeouts, retries, idempotency |
| "They'll get it eventually" | Assume loss; design for it |
| No partition plan | "What if DC A and B can't talk?" |

**Fix:** Every RPC/request: set timeout, retry with backoff, make idempotent when possible.

---

## Mistake 2: Ignoring Clock Skew

**What's wrong:** Using wall-clock timestamps for ordering, LWW, or locking. Clocks drift.

| Wrong | Right |
|-------|-------|
| LWW with `timestamp = now()` | Lamport, vector clocks, or HLC |
| Lock expiry based on local clock | Use logical time or centralized clock |
| "Same time" comparison | "Happens-before" or concurrent |

> **FAANG Tip:** "For ordering we'd use Lamport timestamps or Hybrid Logical Clocks—wall clock can skew between nodes."

---

## Mistake 3: Not Handling Partial Failures

**What's wrong:** Thinking "node is up or down." Reality: some nodes slow, some messages lost, some timeouts.

**Fix:** Design for "maybe"—request might have succeeded, might not. Use idempotency keys, at-least-once delivery with dedup, timeouts on every call.

---

## Mistake 4: Distributed Lock Without Fencing Token

**What's wrong:** Client A holds lock, gets paused (GC), lock expires, Client B acquires. A resumes and writes. Both think they hold lock → data corruption.

| Wrong | Right |
|-------|-------|
| Lock + release when done | Lock + fencing token |
| Trust "I hold the lock" | Storage rejects lower token |
| RedLock alone for critical data | RedLock + fencing or use ZooKeeper |

---

## Mistake 5: Single Leader Without Failover

**What's wrong:** One leader, no election. When it dies, system stuck.

**Fix:** Use Raft, ZooKeeper, or similar. Leader election with quorum. Heartbeats to detect failure. Automatic failover.

---

## Mistake 6: Ignoring Split Brain

**What's wrong:** Not considering partition causing two leaders. Both accept writes → divergence.

| Wrong | Right |
|-------|-------|
| Even number of nodes (2, 4) | Odd (3, 5) for quorum |
| "We'll detect it" | Quorum prevents it |
| Two leaders possible | Only majority can elect |

---

## Mistake 7: Not Using Heartbeats

**What's wrong:** No failure detection. Dead nodes treated as alive, or vice versa.

**Fix:** Heartbeat protocol: send "alive" periodically; if no heartbeat for 2-3× interval, mark dead. Use for leader election, membership, health checks.

---

## Mistake 8: Over-Complicating Consensus

**What's wrong:** "We'll implement Paxos from scratch" or hand-wave a custom protocol.

**Fix:** Use battle-tested: etcd (Raft), ZooKeeper (Zab), Consul (Raft). Don't reinvent. Say "we'd use etcd for leader election" and move on.

---

## Mistake 9: Ignoring CAP Implications

**What's wrong:** Designing without stating partition behavior. "We want both C and A always."

**Fix:** During partition: CP (reject) or AP (serve stale). For locks, config, leader: CP. For feeds, analytics: AP. State the choice.

---

## Mistake 10: Not Considering Message Ordering

**What's wrong:** Assuming FIFO or total order. Messages can reorder, duplicate.

| Scenario | Fix |
|----------|-----|
| Causality matters | Vector clocks, causal consistency |
| Total order needed | Leader sequence, or consensus log |
| Duplicate delivery | Idempotency keys |
| Reorder | Sequence numbers, Lamport |

---

## Summary: Mistake → Fix

| # | Mistake | Fix |
|---|---------|-----|
| 1 | Network reliable | Timeouts, retries, idempotency |
| 2 | Clock skew | Lamport, vector clocks, HLC |
| 3 | No partial failure handling | Design for "maybe" |
| 4 | Lock without fencing | Fencing token |
| 5 | Single leader, no failover | Raft/ZK, election |
| 6 | Ignore split brain | Quorum, odd N |
| 7 | No heartbeats | Heartbeat + timeout |
| 8 | Custom consensus | Use etcd, ZK, Consul |
| 9 | Ignore CAP | State C or A during partition |
| 10 | Ignore ordering | Sequence, causal, idempotent |

---

## Interview Impact

Making these mistakes signals shallow understanding. Avoiding them—especially mentioning fencing, quorum, and partition behavior—shows real distributed systems experience.

---

## Quick Self-Check Before Answering

- [ ] Did I mention partition behavior?
- [ ] Did I include fencing for locks?
- [ ] Did I specify odd N for quorum?
- [ ] Did I avoid wall clock for ordering?
- [ ] Did I mention timeouts and retries?

---

## 30-SECOND REVISION BOX

```
1. Network: Timeouts, retries
2. Clock: Lamport, HLC
3. Partial: Design for maybe
4. Lock: Fencing token
5. Leader: Failover (Raft)
6. Split brain: Quorum, odd N
7. Heartbeats: Use them
8. Consensus: Use etcd/ZK
9. CAP: Choose C or A
10. Ordering: Sequence, idempotent
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
