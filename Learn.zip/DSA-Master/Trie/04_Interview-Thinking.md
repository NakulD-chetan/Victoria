# Trie — Interview Thinking

> **How to identify trie problems, discuss trade-offs, and communicate your approach in FAANG interviews.**

---

## Problem Identification Checklist

| Signal | Trie? | Action |
|--------|-------|--------|
| "Prefix" / "starts with" | ✅ | Trie for O(L) prefix lookup |
| "Autocomplete" / "suggestions" | ✅ | Trie + DFS/BFS from prefix node |
| "Word break" / "segment string" | ✅ | Trie + DP (check prefixes) |
| "Wildcard" / "dot" matching | ✅ | Trie + DFS (try all at '.') |
| "Longest common prefix" | ✅ | Trie: path until branch |
| "Max XOR" / "bitwise" | ✅ | Bitwise trie (bits as chars) |
| "Exact lookup only" | ❌ | HashMap simpler |
| "Sorted iteration" | ❌ | TreeMap / sorted structure |

---

## Trie vs HashMap: When to Discuss

**Always mention when:** Problem has prefix queries.

```
INTERVIEWER: "Design autocomplete."
YOU: "I'll use a trie. Hash maps give O(L) exact lookup but to find all words
      starting with 'pre' we'd need to scan all keys. A trie lets us go to
      the 'pre' node in O(L) and enumerate descendants. That's O(L + k)
      where k = number of matches."
```

**When HashMap is enough:**
- "Check if word exists" — no prefix needed → `set` or `dict`
- "Count word frequency" — exact key → `Counter` / `unordered_map`

---

## Communication Framework

### Step 1: State the need
> "We need fast prefix lookups. A trie lets us follow a path character by character and share storage for common prefixes."

### Step 2: Describe structure
> "Each node has children (map or array) and an end-of-word flag. The path from root spells the string."

### Step 3: Complexity
> "Insert and search are O(L) per operation. Space is O(total characters) with prefix sharing."

### Step 4: Implementation choice
> "For lowercase English I'll use an array of size 26. For Unicode or sparse data, a hash map per node."

---

## Decision Tree: Trie or Not?

```
                    Need prefix search?
                         |
            +------------+------------+
            | YES                     | NO
            v                         v
    Build trie?              Exact lookup only?
    (many lookups)                 |
            |              +-------+-------+
            |              | YES            | NO
            v              v                v
    Use Trie           HashMap/Set      Depends
                               (simpler)
```

---

## Common Interview Follow-ups

| Follow-up | Response |
|-----------|----------|
| "What if alphabet is huge?" | Use HashMap in each node instead of array; O(L) time, more space per node |
| "How to delete a word?" | Mark end=false; optionally prune nodes with no descendants (recursive) |
| "How to list all words with prefix?" | DFS from prefix node, collect paths where is_end |
| "Space vs HashMap?" | Trie can save space via shared prefixes; HashMap stores each key fully |
| "Thread safety?" | Use locks per node or immutable trie (copy-on-write) |

---

## Red Flags (Don't Use Trie)

- One-time batch lookup → building trie is wasteful
- Need range queries on numeric keys → use segment tree / B-tree
- Very short strings, few keys → HashMap is simpler
- Need to support deletion with heavy pruning → more complex

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY:    Prefix, autocomplete, word break, wildcard, XOR → Trie
DISCUSS:     Trie vs HashMap when prefix matters
COMMUNICATE: Need → Structure → Complexity → Implementation
FOLLOW-UP:   Large alphabet → HashMap children; Delete → prune; List words → DFS
RED FLAGS:   Exact-only, one-time lookup, numeric range → not trie
```

---

## 30-SECOND REVISION BOX

```
PREFIX/AUTOCOMPLETE → Trie
EXACT ONLY → HashMap
SAY: "Trie for O(L) prefix lookup, shared storage"
LARGE ALPHABET → HashMap in node
DELETE → mark false, optionally prune
LIST WORDS → DFS from prefix node
```
