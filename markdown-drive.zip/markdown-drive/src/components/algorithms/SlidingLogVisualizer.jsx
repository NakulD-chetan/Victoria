import { useRef, useEffect, useCallback, useState } from 'react';
import { SlidingWindowLog } from '../../lib/algorithms/sliding-window-log';
import { useSlidingLogStore } from '../../stores/sliding-log-store';
import SlidingLogCanvas from './SlidingLogCanvas';
import CodePanel from './CodePanel';
import EventLog from './EventLog';
import StatsPanel from './StatsPanel';

export default function SlidingLogVisualizer({ config }) {
  const logRef = useRef(new SlidingWindowLog(5, 5));
  const canvasRef = useRef(null);
  const autoIntervalRef = useRef(null);
  const codeStepTimeoutRef = useRef(null);

  const {
    windowSize, limit, autoRate, autoActive,
    allowed, denied, total, currentStep,
    addLog, recordAllow, recordDeny, setStep, reset, startTime,
    setWindowSize, setLimit, setAutoRate, toggleAuto,
  } = useSlidingLogStore();

  const [codeOpen, setCodeOpen] = useState(false);

  useEffect(() => {
    logRef.current.windowSize = windowSize;
    logRef.current.limit = limit;
  }, [windowSize, limit]);

  const highlightSteps = useCallback((isAllowed, result) => {
    if (codeStepTimeoutRef.current) clearTimeout(codeStepTimeoutRef.current);
    const seq = isAllowed ? config.stepsAllow : config.stepsDeny;
    let i = 0;
    function next() {
      if (i >= seq.length) { setTimeout(() => setStep(null), 800); return; }
      setStep(seq[i]);
      i++;
      codeStepTimeoutRef.current = setTimeout(next, 170);
    }
    next();
  }, [config, setStep]);

  const sendRequest = useCallback(() => {
    const now = performance.now();
    const result = logRef.current.tryAllow(now);
    const t = ((now - startTime) / 1000).toFixed(1);
    if (result.allowed) {
      recordAllow();
      addLog({ time: t + 's', type: 'allow', message: `\u2713 ALLOW (${result.count}/${limit} in window)` });
      canvasRef.current?.addAnim('req-allow', 900);
    } else {
      recordDeny();
      addLog({ time: t + 's', type: 'deny', message: `\u2717 DENY (${result.count}/${limit} in window)` });
      canvasRef.current?.addAnim('req-deny', 800);
    }
    highlightSteps(result.allowed, result);
  }, [limit, startTime, recordAllow, recordDeny, addLog, highlightSteps]);

  const handleBurst = useCallback(() => {
    let i = 0;
    const iv = setInterval(() => {
      if (i++ >= 5) { clearInterval(iv); return; }
      sendRequest();
    }, 80);
  }, [sendRequest]);

  const handleReset = useCallback(() => {
    logRef.current.windowSize = windowSize;
    logRef.current.limit = limit;
    logRef.current.reset();
    reset();
    addLog({ time: '0.0s', type: 'refill', message: 'Log reset' });
  }, [windowSize, limit, reset, addLog]);

  useEffect(() => {
    if (autoActive) {
      autoIntervalRef.current = setInterval(sendRequest, 1000 / autoRate);
    } else if (autoIntervalRef.current) {
      clearInterval(autoIntervalRef.current);
      autoIntervalRef.current = null;
    }
    return () => {
      if (autoIntervalRef.current) clearInterval(autoIntervalRef.current);
    };
  }, [autoActive, autoRate, sendRequest]);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); sendRequest(); }
      if (e.key === 'b' || e.key === 'B') handleBurst();
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [sendRequest, handleBurst, handleReset]);

  const cutoff = performance.now() - windowSize * 1000;
  const countInWindow = logRef.current
    ? logRef.current.timestamps.filter((t) => t > cutoff).length
    : 0;

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <StatsPanel
          tokens={countInWindow}
          capacity={limit}
          allowed={allowed}
          denied={denied}
          total={total}
        />
      </div>

      <SlidingLogCanvas ref={canvasRef} logRef={logRef} />

      <div className="dc-control-bar">
        <button className="dc-btn dc-btn--primary" onClick={sendRequest}>Send Request</button>
        <button className="dc-btn dc-btn--secondary" onClick={handleBurst}>Burst x5</button>
        <button className={`dc-btn ${autoActive ? 'dc-btn--success' : 'dc-btn--outline'}`} onClick={toggleAuto}>
          {autoActive ? 'Stop Auto' : 'Auto Send'}
        </button>

        <div className="dc-control-bar__sep" />

        <div className="dc-slider-group">
          <label>Window Size</label>
          <input type="range" min={2} max={15} value={windowSize} onChange={(e) => setWindowSize(+e.target.value)} />
          <span className="dc-slider-val">{windowSize}s</span>
        </div>
        <div className="dc-slider-group">
          <label>Limit</label>
          <input type="range" min={2} max={15} value={limit} onChange={(e) => setLimit(+e.target.value)} />
          <span className="dc-slider-val">{limit}</span>
        </div>
        <div className="dc-slider-group">
          <label>Auto</label>
          <input type="range" min={1} max={25} value={autoRate} onChange={(e) => setAutoRate(+e.target.value)} />
          <span className="dc-slider-val">{autoRate}/s</span>
        </div>

        <div className="dc-control-bar__sep" />
        <button className="dc-btn dc-btn--danger" onClick={handleReset}>Reset</button>
      </div>

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" />
              <polyline points="8 6 2 12 8 18" />
            </svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: codeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          {codeOpen && (
            <div className="dc-visualizer__code-wrap">
              <CodePanel code={config.code} activeStep={currentStep} languages={config.meta.languages} storeFn={useSlidingLogStore} />
            </div>
          )}
        </div>
        <div className="dc-visualizer__log-col">
          <EventLog storeFn={useSlidingLogStore} />
        </div>
      </div>

      <div className="dc-visualizer__shortcuts">
        <kbd>Space</kbd> Send <kbd>B</kbd> Burst <kbd>R</kbd> Reset
      </div>
    </div>
  );
}
