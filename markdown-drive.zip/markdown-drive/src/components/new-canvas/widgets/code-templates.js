/**
 * Starter templates for the new-canvas CodeWidget. Deliberately duplicated
 * from the existing canvas so this folder doesn't depend on anything in
 * components/canvas/**.
 */
export const CODE_TEMPLATES = {
  cpp: `#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
`,
  python: `print("Hello, World!")
`,
  java: `public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
`,
  javascript: `console.log("Hello, World!");
`,
  sqlite: `CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT
);
INSERT INTO users (name) VALUES ('Alice'), ('Bob');
SELECT * FROM users;`,
  mysql: `CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50)
);
INSERT INTO users (name) VALUES ('Alice'), ('Bob');
SELECT * FROM users;`,
  oracle: `CREATE TABLE users (
  id NUMBER PRIMARY KEY,
  name VARCHAR2(50)
);
INSERT INTO users (id, name) VALUES (1, 'Alice');
INSERT INTO users (id, name) VALUES (2, 'Bob');
SELECT * FROM users;`,
};
