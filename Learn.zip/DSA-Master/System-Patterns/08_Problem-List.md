# System-Patterns — Problem List

> **30 mixed problems that combine multiple patterns. MUST-DO for final FAANG preparation. These are the problems where single-topic solutions fail — system-patterns shine.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Patterns Combined | Why Critical |
|---|---------|-------------|-----|-------------------|--------------|
| 1 | Koko Eating Bananas | Medium | 875 | BS on Answer + Greedy | Classic BS on answer; high frequency |
| 2 | Split Array Largest Sum | Hard | 410 | BS on Answer + Greedy | Same pattern; harder constraint |
| 3 | Meeting Rooms II | Medium | 253 | Sweep Line | Intervals → events; very common |
| 4 | Product of Array Except Self | Medium | 238 | Two-Pass | O(1) space two-pass; asked often |
| 5 | Largest Rectangle in Histogram | Hard | 84 | Monotonic Stack + DP | Mono stack masterpiece |
| 6 | Trapping Rain Water | Hard | 42 | Monotonic Stack or Two Pointers | Multiple valid approaches |
| 7 | Word Search II | Hard | 212 | Trie + Backtrack | Trie + DFS combo |
| 8 | Word Ladder | Medium | 127 | BFS | Shortest path; high frequency |
| 9 | Count of Smaller Numbers After Self | Hard | 315 | BIT / Merge Sort | Inversions; BIT or D&C |
| 10 | Random Pick with Weight | Medium | 528 | Binary Search + Prefix Sum | BS on prefix; streaming variant |

---

## Complete 30-Problem Progression

### BS on Answer + Greedy (Problems 1–5)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Koko Eating Bananas | 875 | BS + Greedy check | feasible(k) = sum(ceil(p/k)) ≤ h |
| 2 | Split Array Largest Sum | 410 | BS + Greedy | feasible(mid) = greedy split ≤ k |
| 3 | Capacity To Ship Packages | 1011 | BS + Greedy | feasible(cap) = days to ship ≤ D |
| 4 | Minimum Speed to Arrive on Time | 1870 | BS + Greedy | feasible(speed) = arrival time |
| 5 | Minimize Max Distance to Gas Station | 774 | BS + Greedy | feasible(d) = can add ≤ k stations |

### Sweep Line + Intervals (Problems 6–10)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 6 | Meeting Rooms II | 253 | Sweep Line | Events (start,+1),(end,-1); max concurrent |
| 7 | Merge Intervals | 56 | Sweep / Sort | Sort by start; merge overlapping |
| 8 | Non-overlapping Intervals | 435 | Greedy + Sort | Sort by end; take earliest end |
| 9 | The Skyline Problem | 218 | Sweep + Heap | Events; heap for active heights |
| 10 | Insert Interval | 57 | Sweep | Binary search + merge |

### Monotonic Stack + DP (Problems 11–15)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Largest Rectangle in Histogram | 84 | Mono Stack | Width = i - stack[-1] - 1 |
| 12 | Trapping Rain Water | 42 | Mono Stack or Two Pointers | Water = min(L,R) - height |
| 13 | Daily Temperatures | 739 | Mono Stack | Next greater element |
| 14 | Next Greater Element II | 503 | Mono Stack + Circular | Double array or mod |
| 15 | Sum of Subarray Minimums | 907 | Mono Stack + DP | Count subarrays with min |

### Two-Pass (Problems 16–18)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 16 | Product of Array Except Self | 238 | Two-Pass | Left product, right product, O(1) space |
| 17 | Candy | 135 | Two-Pass | Left-to-right, right-to-left |
| 18 | Trapping Rain Water (alt) | 42 | Two-Pass | Prefix max left, suffix max right |

### Trie + Backtrack (Problems 19–21)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 19 | Word Search II | 212 | Trie + Backtrack | Trie of words; DFS from each cell |
| 20 | Word Squares | 425 | Trie + Backtrack | Build trie; backtrack with prefix |
| 21 | Design Search Autocomplete | 642 | Trie + Heap | Trie + top K per prefix |

### BIT / Segment Tree (Problems 22–24)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 22 | Count of Smaller Numbers After Self | 315 | BIT or Merge Sort | Inversions; compress values |
| 23 | Range Sum Query - Mutable | 307 | BIT / Segment Tree | Point update, range sum |
| 24 | Count Inversions | — | BIT / Merge Sort | Classic inversion count |

### BFS + DP / State (Problems 25–27)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 25 | Word Ladder | 127 | BFS | Shortest path; neighbor = 1 char diff |
| 26 | Word Ladder II | 126 | BFS + DFS | All shortest paths |
| 27 | Shortest Path in Binary Matrix | 1091 | BFS | 8-direction neighbors |

### Meet in Middle + Other (Problems 28–30)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 28 | Partition to K Equal Sum Subsets | 698 | Backtrack / Meet in Middle | Subset sum; n≤16 |
| 29 | 4Sum II | 454 | Meet in Middle + Hash | Split into 2+2; count pairs |
| 30 | Random Pick Index | 398 | Reservoir Sampling | Stream; equal prob |

---

## Pattern Distribution

```
BS on Answer + Greedy:    5 problems  (1-5)
Sweep Line:               5 problems  (6-10)
Monotonic Stack:          5 problems  (11-15)
Two-Pass:                 3 problems  (16-18)
Trie + Backtrack:         3 problems  (19-21)
BIT / Segment Tree:       3 problems  (22-24)
BFS + State:              3 problems  (25-27)
Meet in Middle / Other:   3 problems  (28-30)
```

---

## 4-Week Study Plan

### Week 1: BS on Answer + Sweep Line
- Day 1-2: LC 875, 410, 1011 (BS + Greedy)
- Day 3-4: LC 253, 56, 435 (Sweep, Merge, Non-overlapping)
- Day 5: LC 218 (Skyline — harder sweep)
- Focus: BS feasibility function; event ordering

### Week 2: Monotonic Stack + Two-Pass
- Day 1-2: LC 84, 42, 739 (Histogram, Rain, Temperatures)
- Day 3-4: LC 503, 907 (Circular, Subarray minimums)
- Day 5: LC 238, 135 (Product, Candy)
- Focus: Stack invariant; left/right passes

### Week 3: Trie + BIT
- Day 1-2: LC 212, 425 (Word Search II, Word Squares)
- Day 3-4: LC 315, 307 (Smaller After Self, Range Sum Mutable)
- Day 5: LC 642 (Autocomplete)
- Focus: Trie structure; BIT update/query

### Week 4: BFS + Meet in Middle + Review
- Day 1-2: LC 127, 126, 1091 (Word Ladder I/II, Binary Matrix)
- Day 3-4: LC 698, 454, 398 (Partition, 4Sum II, Random Pick)
- Day 5: Review MUST-DO; weak areas
- Focus: BFS state; meet in middle split

---

## MUST-DO Quick Reference

| LC# | Problem | Pattern |
|-----|---------|---------|
| 875 | Koko Eating Bananas | BS + Greedy |
| 410 | Split Array Largest Sum | BS + Greedy |
| 253 | Meeting Rooms II | Sweep Line |
| 238 | Product of Array Except Self | Two-Pass |
| 84 | Largest Rectangle in Histogram | Mono Stack |
| 42 | Trapping Rain Water | Mono Stack / Two Pointers |
| 212 | Word Search II | Trie + Backtrack |
| 127 | Word Ladder | BFS |
| 315 | Count Smaller After Self | BIT / Merge Sort |
| 528 | Random Pick with Weight | BS + Prefix Sum |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL:        30 problems (mix of Medium/Hard)
MUST-DO:      LC 875, 410, 253, 238, 84, 42, 212, 127, 315, 528
TOP 5:        LC 875 (Koko), LC 253 (Meeting Rooms), LC 84 (Histogram),
              LC 238 (Product), LC 127 (Word Ladder)
PATTERNS:     BS+Greedy, Sweep, Mono Stack, Two-Pass, Trie+Backtrack, BIT, BFS
ORDER:        BS→Sweep→Mono→Two-Pass→Trie→BIT→BFS→Meet-in-Middle
```

---

## 30-SECOND REVISION BOX

```
BS+Greedy:    875, 410, 1011 — feasible(mid) check
Sweep:        253, 56, 218 — events, sort, max concurrent
Mono Stack:   84, 42, 739 — next greater, histogram
Two-Pass:     238, 135 — left, right, combine
Trie:         212, 425 — prefix + backtrack
BIT:          315, 307 — inversions, range sum
BFS:          127, 1091 — shortest path
MUST-DO:      875, 410, 253, 238, 84, 42, 212, 127, 315, 528
```
