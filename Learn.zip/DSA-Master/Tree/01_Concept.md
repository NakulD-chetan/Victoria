# Tree — Concept

> **Permanent Recall:** Tree = Non-linear data structure with nodes connected by edges, forming a hierarchy. One root, no cycles. Used everywhere: file systems, databases (B-Tree), compilers (parse tree), heaps. Binary Tree → BST → AVL → Heap — each adds a constraint. FAANG tests trees in ~30% of rounds.

---

## What is a Tree?

A **Tree** is a **non-linear data structure** where elements (nodes) are connected in a hierarchical parent-child relationship.

**Real-world examples from lecture:**
- **Folder structure** — your computer's file system
- **Organization structure** — company hierarchy (CEO → Manager → Employee)
- **Parse tree** — how compilers understand code
- **DBMS Indexing** — B-Tree, B+-Tree for fast database lookup
- **Heap** — priority queues, scheduling

```
         10          ← Root
        /  \
      20    12       ← Level 1
     / \   / | \
   35   7 56 60 70   ← Level 2
             |
            90       ← Leaf Node
```

---

## Basic Terminology (From Lecture)

| Term | Definition | Example (above tree) |
|------|-----------|----------------------|
| **Node** | Every element in the tree | 10, 20, 12, 35... are nodes |
| **Edge** | Link connecting two nodes | Line between 10 and 20 |
| **Root** | Node with NO parent | 10 (top node) |
| **Leaf Node** | Node with NO children | 35, 7, 56, 90, 70 |
| **Parent** | Immediate upper node | 10 is parent of 20 and 12 |
| **Child** | Immediate lower node | 20 and 12 are children of 10 |
| **Siblings** | Children of the same parent | 56, 60, 70 are siblings (all children of 12) |
| **Height of node** | Longest path from node to a leaf | Height of root = height of tree |
| **Depth of node** | Distance from root to that node | Root depth = 0 |
| **Degree of node** | Number of children a node has | Degree of 12 = 3 (has 56, 60, 70) |

> **Simple trick:** "Immediately above any node = parent. Immediately below = child."

---

## Binary Tree

A **Binary Tree** is a tree where every node has **at most 2 children** (left and right).

```
      A
     / \
    B   C
   / \   \
  D   E   H
 / \   \
F   G   I
```

### Types of Binary Trees

#### 1. Full Binary Tree
Every node has **either 0 or 2 children** (no node has exactly 1 child).

```
    A
   / \
  B   C
 / \
D   E
```

#### 2. Complete Binary Tree (CBT)
- All levels are **fully filled except the last**
- Last level nodes are filled **left to right** (no gaps)

> **Formula:** A complete binary tree of height h:
> - (i) Full up to level (h-1) — second last level is completely full
> - (ii) Nodes at last level are added from **left to right** sequentially

```
      1
     / \
    2   3
   / \ /
  4  5 6    ← filled left to right, no gap at position 7
```

#### 3. Perfect Binary Tree
All leaf nodes are at the **same level**. Every internal node has exactly 2 children.
- Number of nodes = 2^(h+1) - 1

#### 4. Skewed Binary Tree
All nodes go in one direction:
- **Left-skewed:** Every node has only a left child
- **Right-skewed:** Every node has only a right child (like a linked list!)

---

## Binary Search Tree (BST)

A **BST** is a Binary Tree with an ordering rule:

> **For every node X:**
> - All values in **left subtree < X**
> - All values in **right subtree > X**

```
        50
       /  \
      30   70
     / \   / \
   20  40 60  80
```

**Key property:** Inorder traversal of a BST gives a **sorted sequence** (20, 30, 40, 50, 60, 70, 80).

### BST Operations

| Operation | Average Case | Worst Case (Skewed) |
|-----------|-------------|---------------------|
| Search | O(log n) | O(n) |
| Insert | O(log n) | O(n) |
| Delete | O(log n) | O(n) |

---

## AVL Tree (Self-Balancing BST)

An **AVL Tree** is a BST that **automatically keeps itself balanced** to avoid the O(n) worst case.

### Balance Factor
```
Balance Factor (BF) of a node = Height(Left Subtree) - Height(Right Subtree)
```

**AVL Rule:** Every node must have BF ∈ {-1, 0, +1}

> **From lecture:**
> - Every **leaf node** BF = 0 (no children, so height difference = 0)
> - A **Full Binary Tree** has all BF = 0
> - For AVL checking, only **tree structure** matters
> - For BST checking, you need the **data values** too

### AVL Rotations
When inserting a node causes BF to become ±2, perform rotations:

| Case | Situation | Fix |
|------|-----------|-----|
| **LL** (Left-Left) | New node added to left of left child | Right Rotation |
| **RR** (Right-Right) | New node added to right of right child | Left Rotation |
| **LR** (Left-Right) | New node added to right of left child | Left Rotation → Right Rotation |
| **RL** (Right-Left) | New node added to left of right child | Right Rotation → Left Rotation |

> **Key rule from lecture:** "Stop at the first node (going from inserted node upward) that becomes unbalanced (BF = ±2)." — This is the node you rotate.

**Example — LL Case (Inserting 10 → 20 → 30 causes imbalance at 10):**
```
Before:         After Right Rotation:
   10 (BF=-2)       20 (BF=0)
     \              /  \
     20 (BF=-1)   10    30
       \
       30 (BF=0)  ← newly inserted
```

---

## Heap

A **Heap** is a **Complete Binary Tree (CBT)** that satisfies the **Heap Property**:

| Type | Property |
|------|---------|
| **Max Heap** | Parent ≥ both children (root = maximum element) |
| **Min Heap** | Parent ≤ both children (root = minimum element) |

```
Max Heap:       Min Heap:
    60               10
   /  \             /  \
  40   50          20   30
 / \  /           / \
10 30 20         40  50
```

### Why CBT? → Array Implementation!

Because it's a CBT, we can store a heap in an **array** with zero wasted space:

```
Index:  0   1   2   3   4   5   6
Array: [60, 40, 50, 10, 30, 20, -]

For node at index i:
  Left child  = 2*i + 1
  Right child = 2*i + 2
  Parent      = (i - 1) / 2
```

### Heap Insert (Heapify Up)
1. Add new element at the **end** (maintains CBT property)
2. Compare with parent; if violates heap property → **swap**
3. Repeat until heap property restored

### Heap Delete (Extract Root / Heapify Down)
1. Replace root with **last element** (maintains CBT property)
2. Remove last element
3. Compare root with children; swap with **larger child** (Max Heap) or smaller child (Min Heap)
4. Repeat until heap property restored

---

## Quick Comparison Table

| Feature | Binary Tree | BST | AVL Tree | Heap |
|---------|------------|-----|----------|------|
| **Structure** | At most 2 children | At most 2 children | Balanced BST | CBT |
| **Ordering** | None | Left < Root < Right | Left < Root < Right | Parent ≥/≤ Children |
| **Search** | O(n) | O(log n) avg | O(log n) guaranteed | O(n) |
| **Insert** | O(1) | O(log n) avg | O(log n) guaranteed | O(log n) |
| **Get Min/Max** | O(n) | O(log n) | O(log n) | O(1) |
| **Use case** | General hierarchy | Sorted data | When balance needed | Priority Queue |
