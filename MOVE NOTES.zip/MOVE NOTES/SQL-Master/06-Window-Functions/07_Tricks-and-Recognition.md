# Window Functions — Tricks and Recognition

| Problem | Window |
|---------|--------|
| Top N per category | `ROW_NUMBER` + filter |
| 7-day moving average | `AVG` + frame `ROWS 6 PRECEDING` |
| YoY compare | `LAG` 12 months or join |
| Dedup keep latest | `ROW_NUMBER` order by time desc, `rn=1` |

---

*Next: [[08_Problem-List]]*
