# Quick Revision — Sab Kuch Ek Jagah

> **Interview se 1 ghanta pehle yeh padho — pura System Design revise ho jaayega!**
> Har topic ka 5-line summary + key formula + interview mein kya bolna hai

---

## System Design Basics

**Ek line mein:** Large-scale systems ko design karte waqt requirements, scalability, trade-offs — sab consider karo.

**Key points:**
- Requirements first — functional + non-functional
- Scale = QPS, Storage, Users
- Trade-offs = har choice ka cost hai
- Building blocks: LB, Cache, DB, Queue
- No perfect design — good enough + iterate

**Formula/Rule:** Requirements → Estimation → Design → Deep Dive

**Interview mein bolo:** "Let me start with requirements. Scale kya hai? Read/Write ratio? Latency?"

---

## Scalability

**Ek line mein:** Load badhne ke saath system handle kar sake — Vertical (bigger) ya Horizontal (more).

**Key points:**
- Vertical = bigger machine (limit hai)
- Horizontal = more machines (unlimited)
- Stateless = easy horizontal scaling
- Bottleneck dhoondo — wahi scale karo
- Read scale = Replicas, Write scale = Sharding

**Formula/Rule:** Stateless > Stateful for scaling

**Interview mein bolo:** "Read-heavy hai toh replicas. Write-heavy toh sharding. Stateless design for app servers."

---

## Load Balancing

**Ek line mein:** Traffic ko multiple servers pe distribute karo — no single overload.

**Key points:**
- Round Robin = simple, equal distribution
- Least Connections = busy servers se less traffic
- Consistent Hashing = same key → same server (cache)
- L4 = transport layer, L7 = application layer
- Health checks = dead servers ko remove

**Formula/Rule:** N servers = N× capacity (if stateless)

**Interview mein bolo:** "Load balancer for stateless app servers. Round Robin for simple, Least Connections for variable load."

---

## Caching

**Ek line mein:** Frequently accessed data ko fast storage mein rakho — DB load kam, latency kam.

**Key points:**
- Cache-Aside = app manages cache, DB on miss
- Write-Through = write to cache + DB together
- LRU = evict least recently used
- 80% traffic 20% data pe — cache hot data
- CDN = static, Cache = dynamic/user-specific

**Formula/Rule:** Cache Hit Ratio = Hits / (Hits + Misses). Target > 80%

**Interview mein bolo:** "Read-heavy hai toh Redis cache. Cache-Aside pattern. TTL for invalidation. Thundering herd? Stale cache or lock."

---

## CDN

**Ek line mein:** Static content ko user ke paas (edge) pe serve karo — latency kam, origin load kam.

**Key points:**
- Push CDN = you upload content first
- Pull CDN = CDN fetches on first request
- Edge = user ke paas servers
- Static = images, CSS, JS, videos
- Invalidation = purge when content changes

**Formula/Rule:** CDN for static, Cache for dynamic

**Interview mein bolo:** "Static assets (images, videos) CDN pe. Origin se sirf cache miss. Push for known content, Pull for dynamic."

---

## CAP Theorem

**Ek line mein:** Partition mein C ya A choose karo — dono nahi mil sakte.

**Key points:**
- C = Consistency, A = Availability, P = Partition tolerance
- P forced hai (network fails) — so C vs A
- CP = Banking (consistency zaroori)
- AP = Social feed (availability zaroori)
- PACELC = extended CAP

**Formula/Rule:** Partition = C ya A. No partition = dono mil sakte.

**Interview mein bolo:** "CAP mein P always. So C vs A. Banking = CP. Feed = AP. Eventual consistency for feed."

---

## Availability/Reliability

**Ek line mein:** System uptime — 99.9% = 8.76 hrs downtime/year.

**Key points:**
- 99.9% = 3 nines, 99.99% = 4 nines
- SLA = promise, SLO = target, SLI = metric
- Redundancy = multiple instances
- Series = A1×A2 (weakest link)
- Parallel = 1-(1-A1)(1-A2) (redundancy helps)

**Formula/Rule:** 99.9% = 8.76 hrs/year downtime. 99.99% = 52.6 min/year

**Interview mein bolo:** "99.9% target. Multiple replicas. No SPOF. Health checks. Failover."

---

## Database Fundamentals

**Ek line mein:** SQL = ACID + schema, NoSQL = flexible + scale.

**Key points:**
- SQL = transactions, joins, schema
- NoSQL = document, key-value, wide-column
- ACID = Atomicity, Consistency, Isolation, Durability
- BASE = Basically Available, Soft state, Eventual
- Index = B-Tree (range), Hash (exact)

**Formula/Rule:** Need ACID/joins → SQL. Need scale/flex → NoSQL

**Interview mein bolo:** "Transactions zaroori? SQL. High scale, flexible schema? NoSQL. Read-heavy? Replicas."

---

## Database Scaling

**Ek line mein:** Reads = Replicas, Writes = Sharding.

**Key points:**
- Replication = read replicas, master-slave
- Sharding = partition by key (user_id, etc.)
- Consistent Hashing = minimal rebalance on add/remove
- Connection pooling = reuse connections
- Replication lag = ~100ms-1s

**Formula/Rule:** Shards = Total_data / Shard_capacity

**Interview mein bolo:** "Read-heavy = replicas. Write-heavy = sharding. Consistent hashing for even distribution."

---

## Architecture Patterns

**Ek line mein:** Monolith start, Microservices when scale/complexity.

**Key points:**
- Monolith = single deploy, simple start
- Microservices = independent deploy, scale per service
- API Gateway = single entry, routing
- Service Discovery = find services dynamically
- Start monolith, split when needed

**Formula/Rule:** Team < 10, MVP = Monolith. Multiple teams, different scale = Microservices

**Interview mein bolo:** "Start with monolith. When scale/complexity badhe, split. API Gateway for routing."

---

## Message Queues

**Ek line mein:** Async communication — decouple, buffer, reliability.

**Key points:**
- Producer → Queue → Consumer
- Kafka = log-based, high throughput, retention
- RabbitMQ = queue-based, task queue
- Kafka = event streaming, RabbitMQ = job queue
- At-least-once, at-most-once, exactly-once

**Formula/Rule:** Async when you can, sync when you must

**Interview mein bolo:** "Async processing = Kafka/RabbitMQ. Decouple services. Retry for failed messages. Idempotency for critical."

---

## Resilience Patterns

**Ek line mein:** Failure handle karo — retry, circuit breaker, rate limit.

**Key points:**
- Retry = exponential backoff
- Circuit Breaker = fail fast when downstream down
- Rate Limiting = token bucket, sliding window
- Bulkhead = isolate failures
- Idempotency = retry safe

**Formula/Rule:** Design for failure, not for success

**Interview mein bolo:** "Circuit breaker for downstream. Retry with backoff. Rate limit for abuse. Idempotency for payments."

---

## Distributed Systems

**Ek line mein:** Multiple nodes, consensus, failure handling.

**Key points:**
- Consensus = Raft, Paxos (agree on value)
- Leader election = one leader, others follow
- Distributed lock = Redis, ZooKeeper
- Heartbeat = liveness check
- Split brain = two leaders = bad

**Formula/Rule:** Consensus = majority agree. 2f+1 nodes for f failures

**Interview mein bolo:** "Consensus for leader. Distributed lock for critical section. Heartbeat for failure detection."

---

## Back of Envelope

**Ek line mein:** Quick numbers — QPS, Storage, Bandwidth — feasibility check.

**Key points:**
- QPS = DAU × req_per_user / 86400
- Peak = Avg × 2-5
- Storage = Users × data × days
- Bandwidth = QPS × size
- Power of 2: 2^10=1K, 2^20=1M, 2^30=1G

**Formula/Rule:** 86400 = seconds/day. Latency: L1=0.5ns, RAM=100ns, SSD=100μs, Network=0.5ms

**Interview mein bolo:** "Let me estimate. 100M DAU, 10 req/user = 100M×10/86400 ≈ 12K QPS. Storage = 100M×1KB = 100GB."

---

## Interview Framework

**Ek line mein:** 4 steps — Requirements → Estimation → Design → Deep Dive.

**Key points:**
- Step 1: Requirements (5-10 min) — functional + non-functional
- Step 2: Estimation (5 min) — QPS, Storage
- Step 3: High-level (15-20 min) — API, Data, Components
- Step 4: Deep dive (15-20 min) — bottlenecks, failures
- Think aloud, check-ins, trade-offs

**Formula/Rule:** Requirements first → Always estimate → Trade-offs always

**Interview mein bolo:** "Let me clarify requirements first. Scale? Read/Write? Then I'll estimate and design."

---

## URL Shortener

**Ek line mein:** Long URL → short code → redirect. Hash + DB + Cache.

**Key points:**
- Hash = base62 encode (counter or UUID)
- Collision = retry with new hash
- Read-heavy = cache critical (Redis)
- 302 redirect = temporary, SEO
- Analytics = async, separate service

**Formula/Rule:** 6 chars base62 = 62^6 ≈ 56B combinations

**Interview mein bolo:** "Base62 hash from counter. Redis cache for redirect. DB for persistence. Analytics async queue."

---

## Instagram / Twitter

**Ek line mein:** Feed = Fan-out (Push vs Pull). Media = S3 + CDN. Graph = follow relationship.

**Key points:**
- Fan-out = Push (pre-compute) vs Pull (on-demand)
- Push = write heavy, Pull = read heavy
- Fan-out on read = celebrity problem
- Hybrid = Push for normal, Pull for celebrity
- Media = upload → process → S3 → CDN

**Formula/Rule:** 200 followers = Push. 10M followers = Pull (fan-out on read)

**Interview mein bolo:** "Hybrid fan-out. Push for <500 followers. Pull for celebrities. Media on CDN. Feed ranking = engagement + recency."

---

## WhatsApp / Chat

**Ek line mein:** WebSocket for real-time. Message queue for delivery. Presence = heartbeat.

**Key points:**
- WebSocket = real-time bidirectional
- Message queue = offline delivery, ordering
- Read receipt = client ack
- Group chat = fan-out to members
- Presence = online/offline via heartbeat

**Formula/Rule:** 1B users, 50 msg/user/day = 600K msg/sec

**Interview mein bolo:** "WebSocket for real-time. Message queue for persistence. At-least-once delivery. Idempotency for duplicates."

---

## YouTube / Netflix

**Ek line mein:** Upload → Transcode → Store → CDN. Adaptive bitrate streaming.

**Key points:**
- Upload = chunked, multipart
- Transcode = multiple resolutions (720p, 1080p)
- Store = S3/Object storage
- CDN = edge delivery
- Adaptive = HLS/DASH, quality based on bandwidth

**Formula/Rule:** 5 min video = 50MB. 10B views/day = 500 PB/day (CDN handles)

**Interview mein bolo:** "Chunked upload. Async transcoding. Multiple formats. CDN for delivery. Adaptive bitrate."

---

## Uber

**Ek line mein:** Geospatial index for nearby. Real-time matching. Surge pricing.

**Key points:**
- Geohash/Quad-tree = nearby drivers
- Real-time = WebSocket, location updates
- Matching = driver accept, dispatch
- Surge = demand/supply based pricing
- ETA = traffic + distance

**Formula/Rule:** Geohash = encode lat/long into string, prefix match = nearby

**Interview mein bolo:** "Geospatial index for nearby drivers. WebSocket for real-time. Matching service. Surge pricing algorithm."

---

## Notification System

**Ek line mein:** Push (server-initiated) vs Pull (client polls). Fan-out to devices.

**Key points:**
- Push = FCM, APNS — server sends to device
- Pull = client polls — simpler, more latency
- Fan-out = one notification → many devices
- Queue = for async processing
- Rate limit = don't spam

**Formula/Rule:** Push for real-time. Pull for simple. Queue for high volume.

**Interview mein bolo:** "Push via FCM/APNS. Queue for async. Fan-out to user's devices. Rate limit per user."

---

## Payment System

**Ek line mein:** Idempotency critical. Retry safe. Gateway integration.

**Key points:**
- Idempotency key = same request = same result
- Retry = network can fail
- Idempotency = retry safe
- Gateway = Stripe, PayPal — don't store card
- Two-phase = authorize + capture

**Formula/Rule:** Same idempotency key = same response. Never duplicate charge.

**Interview mein bolo:** "Idempotency key for every payment. Retry safe. Gateway for PCI. Auth + capture for delayed charge."

---

## Distributed Cache

**Ek line mein:** Consistent hashing for sharding. Replication for availability.

**Key points:**
- Sharding = data across nodes
- Consistent hashing = minimal rebalance
- Replication = each key on N nodes
- Eviction = LRU per shard
- Cluster = Redis Cluster, Memcached

**Formula/Rule:** N nodes, add 1 = 1/N keys move (consistent hashing)

**Interview mein bolo:** "Consistent hashing for sharding. Replication for HA. LRU eviction. Cache stampede? Lock or probabilistic."

---

## Search Engine

**Ek line mein:** Inverted index. Crawl → Index → Rank → Serve.

**Key points:**
- Inverted index = word → doc IDs
- Crawler = fetch pages
- Indexer = build index
- Ranking = TF-IDF, PageRank, ML
- Distributed = shard by term

**Formula/Rule:** Inverted index = term → [doc1, doc2, ...]. Query = intersect lists

**Interview mein bolo:** "Inverted index for full-text. Shard by term. Ranking = relevance + authority. Elasticsearch for scale."

---

## Master Cheat Sheet — All Formulas

| What | Formula |
|------|---------|
| **Average QPS** | DAU × req_per_user / 86400 |
| **Peak QPS** | Avg QPS × 2 to 5 |
| **Storage** | Users × data_per_user × days × replication |
| **Bandwidth** | QPS × response_size |
| **Servers** | Peak QPS / QPS_per_server × 1.3 |
| **Availability (series)** | A1 × A2 × A3 |
| **Availability (parallel)** | 1 - (1-A1)(1-A2) |
| **Shards** | Total_data / Shard_capacity |
| **Cache hit ratio** | Hits / (Hits + Misses) |
| **Power of 2** | 2^10=1K, 2^20=1M, 2^30=1G, 2^40=1T |

---

## Latency Numbers Card

| Operation | Latency |
|-----------|---------|
| L1 cache | 0.5 ns |
| L2 cache | 7 ns |
| RAM | 100 ns |
| SSD | 100 μs |
| HDD | 10 ms |
| Same DC network | 0.5 ms |
| Cross-country | 50 ms |
| Round-world | 150 ms |

---

## Component Selection Guide

| Need | Use |
|------|-----|
| Scale reads | Replicas, Cache |
| Scale writes | Sharding |
| Reduce latency | Cache, CDN |
| Decouple | Message Queue |
| Static content | CDN |
| User-specific data | Cache |
| Async processing | Queue |
| Strong consistency | SQL |
| Eventual OK | NoSQL, Replicas |
| Real-time | WebSocket |
| Search | Elasticsearch, Inverted index |
| Geospatial | Geohash, Quad-tree |

---

## The 10 Most Important Things to Remember

1. **Requirements first** — 5 min minimum, clarify karo
2. **Always estimate** — QPS, Storage — numbers bolo
3. **Trade-offs always** — "We chose X because Y, trade-off is Z"
4. **Think aloud** — Interviewer ko dikhao thought process
5. **Simple first** — Monolith → Microservices when needed
6. **Design for failure** — "What if DB fails?"
7. **Reads = Replicas, Writes = Shards** — scaling mantra
8. **Cache for read-heavy** — 80% traffic 20% data
9. **CDN for static** — Images, videos edge pe
10. **No perfect design** — Good enough + iterate

---

## Quick Decision Tree

```
Need scale?
├── Read-heavy → Replicas + Cache
├── Write-heavy → Sharding
└── Both → Replicas + Sharding

Need consistency?
├── Strong → SQL, single DB
└── Eventual OK → NoSQL, Replicas

Need async?
├── Yes → Queue (Kafka/RabbitMQ)
└── No → Sync call

Static or dynamic?
├── Static → CDN
└── Dynamic → Cache (Redis)
```

---

## Pre-Interview 1-Hour Checklist

- [ ] 4-step framework yaad hai
- [ ] QPS, Storage formulas
- [ ] Latency numbers (RAM, SSD, Network)
- [ ] Power of 2 (2^10 to 2^40)
- [ ] CAP, ACID, BASE
- [ ] SQL vs NoSQL when
- [ ] Cache vs CDN when
- [ ] 2-3 designs (URL, Twitter, Chat)
- [ ] Trade-offs always bolo
- [ ] "What if fails?" always ask

---

*Yeh file interview se 1 ghanta pehle padho — sab kuch ek jagah! All the best!*

---

## Topic Index — Jump Reference

| # | Topic | Page Section |
|---|-------|--------------|
| 1 | System Design Basics | Top |
| 2 | Scalability | Top |
| 3 | Load Balancing | Top |
| 4 | Caching | Top |
| 5 | CDN | Top |
| 6 | CAP Theorem | Top |
| 7 | Availability | Top |
| 8 | Database Fundamentals | Top |
| 9 | Database Scaling | Top |
| 10 | Architecture Patterns | Top |
| 11 | Message Queues | Top |
| 12 | Resilience Patterns | Top |
| 13 | Distributed Systems | Top |
| 14 | Back of Envelope | Top |
| 15 | Interview Framework | Top |
| 16-22 | Real System Designs | Middle |
| — | Master Cheat Sheet | Bottom |
| — | Latency Card | Bottom |
| — | 10 Most Important | Bottom |

---

## One-Liner Per Design (Ultra Quick)

| Design | One-Liner |
|--------|-----------|
| URL Shortener | Hash + Cache + Redirect |
| Twitter/Instagram | Fan-out + CDN + Feed ranking |
| WhatsApp | WebSocket + Queue + Presence |
| YouTube | Upload + Transcode + CDN |
| Uber | Geohash + Real-time + Matching |
| Notification | Push + Queue + Fan-out |
| Payment | Idempotency + Gateway + Retry |
| Cache | Consistent hash + Sharding |
| Search | Inverted index + Rank |

---

## Last-Minute Reminders (5 Min Before Interview)

1. Breathe — calm raho
2. Requirements first — always
3. Numbers — QPS, Storage
4. Trade-offs — "We chose X because..."
5. Think aloud — don't go silent
6. Simple first — then add
7. Failure — "What if X fails?"
8. Check-in — "Does this make sense?"
