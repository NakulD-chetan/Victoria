# 11 — Real-Time OLAP Engines (ClickHouse, Druid, Pinot)

> **One-line:** Real-time OLAP engines are purpose-built for **sub-second analytical queries** on **billions of rows** with **real-time data ingestion** — the engines behind dashboards at Uber, Netflix, LinkedIn, and Cloudflare.

---

## 1. Why Traditional DW Is Not Enough

| Scenario | Traditional DW (Snowflake/BigQuery) | Real-Time OLAP |
|----------|-------------------------------------|----------------|
| **Latency** | Seconds to minutes | Sub-second (p99 < 200ms) |
| **Concurrency** | Hundreds of queries | Thousands of queries |
| **Data freshness** | Minutes to hours | Seconds |
| **Use case** | Business reports, analytics | User-facing dashboards, monitoring |
| **Cost at scale** | Expensive per-query compute | Efficient for repetitive query patterns |

**Interview line:** "When you need **sub-second queries** at **high concurrency** with **real-time data** — like a user-facing analytics dashboard — you need a dedicated OLAP engine, not a general-purpose DW."

---

## 2. The Big Three — ClickHouse vs Druid vs Pinot

| Feature | ClickHouse | Apache Druid | Apache Pinot |
|---------|-----------|-------------|-------------|
| **Created by** | Yandex (2016) | Metamarkets (2011) | LinkedIn (2013) |
| **Used by** | Cloudflare, Uber, eBay | Netflix, Airbnb, Walmart | LinkedIn, Uber, Stripe |
| **Query language** | SQL (native) | SQL (via Druid SQL) | SQL (multi-stage) |
| **Storage** | Columnar, MergeTree engine | Columnar segments | Columnar segments |
| **Ingestion** | Batch + real-time | Batch + real-time (Kafka) | Batch + real-time (Kafka) |
| **Strength** | Raw speed, SQL compatibility | Time-series, real-time | User-facing analytics |
| **Architecture** | Single binary, simpler ops | Multi-component (complex) | Multi-component |
| **Joins** | Supports joins well | Limited joins | Limited joins |
| **Best for** | Log analytics, observability | Event analytics, time-series | User-facing dashboards |

---

## 3. ClickHouse Deep Dive

### Architecture

```
┌─────────────────────────────────────┐
│          ClickHouse Cluster         │
│                                     │
│  ┌──────────┐  ┌──────────┐        │
│  │ Shard 1  │  │ Shard 2  │  ...   │
│  │ Replica A│  │ Replica A│        │
│  │ Replica B│  │ Replica B│        │
│  └──────────┘  └──────────┘        │
│                                     │
│  ZooKeeper / ClickHouse Keeper      │
│  (coordination, replication)        │
└─────────────────────────────────────┘
```

### Key Concepts

| Concept | Detail |
|---------|--------|
| **MergeTree Engine** | Core table engine — columnar, sorted, merged in background |
| **ORDER BY** | Data physically sorted by these columns — critical for query performance |
| **Partitioning** | Logical division (usually by date) — enables partition pruning |
| **Primary key** | Sparse index on ORDER BY columns — not unique like traditional DBs |
| **Materialized Views** | Pre-compute aggregations on insert — instant queries on aggregates |
| **Distributed table** | Federated view across shards for distributed queries |

### ClickHouse Example

```sql
CREATE TABLE events (
    event_date Date,
    user_id UInt64,
    event_type String,
    value Float64
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(event_date)
ORDER BY (event_date, user_id, event_type);

-- Query: Count events by type in last 24 hours
SELECT event_type, count() as cnt
FROM events
WHERE event_date >= today() - 1
GROUP BY event_type
ORDER BY cnt DESC;
-- Runs in milliseconds on billions of rows
```

---

## 4. Apache Druid Deep Dive

### Architecture

```
┌─────────────────────────────────────────────┐
│              Druid Cluster                   │
│                                              │
│  ┌──────────────┐  ┌──────────────┐         │
│  │ Broker       │  │ Router       │         │
│  │ (query)      │  │ (API gateway)│         │
│  └──────┬───────┘  └──────────────┘         │
│         │                                    │
│  ┌──────┴───────┐  ┌──────────────┐         │
│  │ Historical   │  │ MiddleManager│         │
│  │ (serve old   │  │ (real-time   │         │
│  │  segments)   │  │  ingestion)  │         │
│  └──────────────┘  └──────────────┘         │
│                                              │
│  ┌──────────────┐  ┌──────────────┐         │
│  │ Coordinator  │  │ Overlord     │         │
│  │ (manage data)│  │ (manage      │         │
│  │              │  │  ingestion)  │         │
│  └──────────────┘  └──────────────┘         │
│                                              │
│  Deep Storage: S3 / HDFS                     │
│  Metadata: MySQL / PostgreSQL                │
│  Coordination: ZooKeeper                     │
└──────────────────────────────────────────────┘
```

### Key Concepts

| Concept | Detail |
|---------|--------|
| **Segments** | Immutable columnar data chunks (time-partitioned) |
| **Roll-up** | Pre-aggregate at ingestion time — reduces storage dramatically |
| **Real-time ingestion** | Kafka → MiddleManager → segment creation |
| **Time-based partitioning** | All data partitioned by time — optimized for time-range queries |
| **Bitmap indexes** | Fast filtering on low-cardinality dimensions |

### Druid Roll-up Example

```
Raw events (1B rows/day):
  timestamp | user_id | page  | clicks | duration
  10:00:01  | user1   | home  | 1      | 30
  10:00:02  | user1   | home  | 1      | 45
  10:00:03  | user2   | home  | 1      | 20

After roll-up (minutely granularity):
  timestamp | page  | clicks_sum | duration_sum | count
  10:00     | home  | 3          | 95           | 3

1B rows → 50M rows (with minute granularity)
```

---

## 5. Apache Pinot Deep Dive

### Key Differentiators

| Feature | Detail |
|---------|--------|
| **Upsert support** | Update existing records (unlike pure append-only OLAP) |
| **Star-tree index** | Pre-computed aggregation tree for ultra-fast queries |
| **Multi-stage query** | Full SQL with joins (newer feature) |
| **Real-time + offline** | Separate real-time (mutable) and offline (immutable) tables |
| **Tenant isolation** | Multi-tenant query isolation for SaaS platforms |

### Pinot Table Types

| Type | Ingestion | Use Case |
|------|-----------|----------|
| **REALTIME** | Kafka → Pinot directly | Live dashboards, monitoring |
| **OFFLINE** | Batch ingestion from files | Historical analytics |
| **HYBRID** | Both real-time + offline merged | Complete picture (recent + historical) |

---

## 6. When to Use Which

| Scenario | Best Choice | Why |
|----------|-------------|-----|
| **Log/observability analytics** | ClickHouse | SQL native, fast on raw logs, supports joins |
| **Time-series event analytics** | Druid | Roll-up, time-partitioning, mature ecosystem |
| **User-facing product analytics** | Pinot | Star-tree index, upsert, multi-tenant |
| **Simple dashboarding** | ClickHouse | Easiest to deploy and operate |
| **Kafka-native real-time** | Druid or Pinot | Native Kafka integration |
| **Need complex joins** | ClickHouse | Best join support among the three |

---

## 7. OLAP vs OLTP vs Data Warehouse

| Dimension | OLTP (Postgres) | Data Warehouse (Snowflake) | Real-Time OLAP (ClickHouse) |
|-----------|-----------------|---------------------------|----------------------------|
| **Workload** | Transactions | Batch analytics | Real-time analytics |
| **Latency** | Low (per txn) | Seconds-minutes | Sub-second |
| **Concurrency** | High (txn) | Medium | Very high (queries) |
| **Data freshness** | Real-time | Minutes-hours | Seconds |
| **Storage** | Row-oriented | Columnar | Columnar |
| **Best for** | App backend | BI reports | Live dashboards |

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "When would you use ClickHouse over Snowflake?" | Sub-second queries at high concurrency with real-time data — user-facing dashboards |
| "What is Druid roll-up?" | Pre-aggregate at ingestion — reduces storage, speeds queries, trades raw data granularity |
| "ClickHouse vs Druid vs Pinot?" | ClickHouse: SQL+joins. Druid: time-series. Pinot: user-facing+upsert |
| "How do these ingest real-time data?" | Kafka integration — consume from topics, build columnar segments |
| "What is a star-tree index?" | Pinot's pre-computed aggregation tree — answers GROUP BY queries without scanning |
| "Why not just use Snowflake for everything?" | Cost at high concurrency, latency for user-facing, real-time freshness needs |

---

## Key Takeaways

- **Real-time OLAP engines** fill the gap between OLTP and traditional DW — **sub-second queries on real-time data**.
- **ClickHouse**: fastest for SQL, best joins, simplest operations — great for logs and observability.
- **Druid**: best for time-series with roll-up — used at Netflix, Airbnb.
- **Pinot**: best for user-facing analytics with upserts — used at LinkedIn, Uber.
- All three are **columnar**, ingest from **Kafka**, and handle **billions of rows**.
- Use traditional DW (Snowflake/BigQuery) for **analyst BI**. Use OLAP engines for **user-facing, real-time, high-concurrency** dashboards.
- In interviews, emphasize **when** to use these vs standard DW — it's a **trade-off** discussion.

---
