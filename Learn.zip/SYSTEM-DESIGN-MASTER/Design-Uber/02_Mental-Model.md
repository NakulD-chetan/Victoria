# Design Uber — Mental Model

> **Permanent Recall:** Core challenge: **real-time geospatial matching** (find nearest available driver). Two key problems: **1)** Efficient location storage and querying (geospatial indexing), **2)** Real-time location updates at massive scale (3.75M/s). Decomposition: Location Service, Matching Service, Trip Service, Pricing Service, Payment Service. Think "dispatch center" analogy.

---

## Core Challenge

**Real-time geospatial matching:** Given a rider at (lat, lng), find the K nearest available drivers in <1 second, while ingesting millions of location updates per second.

```
    RIDER (pickup)                    SYSTEM                     DRIVERS (scattered)
       |                                 |                              |
       |---- request ride -------------->|                              |
       |                                 |---- query: nearest K -------->|
       |                                 |      (geospatial index)      |
       |                                 |<--- driver IDs, distances ---|
       |                                 |---- send request to K ------>|
       |                                 |<--- first accept ------------|
       |<--- matched -------------------|                              |
```

---

## Two Key Problems

### Problem 1: Geospatial Indexing

**Naïve approach (wrong):** `SELECT * FROM drivers WHERE lat BETWEEN ? AND ? AND lng BETWEEN ?` — full table scan; doesn't scale.

**Right approach:**
- Encode (lat, lng) into a structure that supports **spatial locality** — nearby points share a prefix or fall in same cell
- Query: "Give me all drivers in this region" → O(log n) or O(1) lookup
- Options: **Geohash**, **QuadTree**, **S2 cells** — each encodes location for efficient range/nearest queries

### Problem 2: Real-Time Updates at Scale

**Challenge:** 15M active drivers × 0.25 Hz = 3.75M writes/second.

- Can't write every update to disk — too slow
- **Solution:** In-memory geospatial store (e.g., Redis GEO, custom QuadTree in memory)
- Batch or stream updates; eventual persistence for analytics
- Partition by geographic region to shard load

---

## The "Dispatch Center" Analogy

Think of the system as a **dispatch center**:

| Component | Dispatch Analogy | System Equivalent |
|-----------|------------------|-------------------|
| **Radio grid** | Dispatchers see drivers on a map by zone | Geospatial index by region |
| **Status board** | Who's available, who's on a trip | Driver state (AVAILABLE, BUSY, OFFLINE) |
| **Call queue** | Rider requests queue up | Matching queue; first-available or nearest-first |
| **Live tracking** | "Driver 5 min away" updates | WebSocket push of driver location |
| **Pricing board** | "Peak rates in downtown" | Surge pricing per geohash/region |

---

## Decomposition into Services

| Service | Responsibility |
|---------|-----------------|
| **Location Service** | Ingest driver GPS (every 4s); maintain in-memory geospatial index; answer "drivers in region X" |
| **Matching Service** | Receive rider request; query Location Service for nearby drivers; send request to top K; first-accept-wins |
| **Trip Service** | Trip lifecycle (REQUESTED → MATCHED → DRIVER_EN_ROUTE → IN_PROGRESS → COMPLETED); persist trip data |
| **Pricing Service** | Surge multiplier per region; ETA calculation; base fare + surge + distance |
| **Payment Service** | Process payment after trip; support cards, wallet, etc. |

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│ Location Service│  │ Matching Service │  │  Trip Service   │
│ (driver GPS,    │  │ (find nearest K, │  │ (lifecycle,     │
│  geospatial     │  │  first-accept)   │  │  state machine) │
│  index)         │  │                 │  │                 │
└────────┬────────┘  └────────┬────────┘  └────────┬────────┘
         │                     │                     │
         └─────────────────────┼─────────────────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              v                v                v
     ┌────────────────┐ ┌────────────────┐ ┌────────────────┐
     │ Pricing Service│ │ Payment Service│ │  Real-time     │
     │ (surge, ETA)   │ │ (post-trip)    │ │  (WebSocket)   │
     └────────────────┘ └────────────────┘ └────────────────┘
```

---

## Why Geospatial Indexing Matters

| Approach | Query Time | Write Throughput | Use Case |
|----------|------------|------------------|----------|
| **SQL with lat/lng** | O(n) scan | Low | Small datasets only |
| **Geohash + hash map** | O(1) region lookup | High | Good for Uber-like |
| **QuadTree** | O(log n) | High | Variable density |
| **S2 cells** | O(1) | High | Google's approach; hierarchical |
| **Redis GEO** | O(log n) | High | Prototype; GEOADD, GEORADIUS |

> **FAANG Tip:** Saying "we'll use a database with lat/lng columns" is a red flag. Geospatial indexing is THE differentiator for Uber. Mention Geohash or QuadTree or S2.

---

## Matching Algorithm (High Level)

1. Rider sends request with pickup (lat, lng) and dropoff
2. Convert pickup to geohash/cell
3. Query Location Service: "drivers in this cell and adjacent cells, status=AVAILABLE"
4. Sort by distance (or ETA); take top K (e.g., 5)
5. Send ride request to these K drivers (push notification or in-app)
6. **First-accept-wins:** First driver to accept gets the ride
7. Others' requests expire after timeout (e.g., 15–30s)

---

## 30-SECOND REVISION BOX

```
CORE: Real-time geospatial matching — find nearest available driver
PROBLEM 1: Geospatial indexing (Geohash, QuadTree, S2) — not SQL lat/lng
PROBLEM 2: 3.75M location updates/s — in-memory store, partition by region
ANALOGY: Dispatch center — zones, status board, live tracking
SERVICES: Location, Matching, Trip, Pricing, Payment
MATCHING: Nearest K, first-accept-wins
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
