import { create } from 'zustand';
import { getAuthHeaders } from '../components/AuthGate';
import { destroyWidgetStorageForCanvas, renameWidgetStorageCanvas } from '../components/canvas/widget-storage.js';

const CLOUD_DEBOUNCE = 3000;
const LOCAL_KEY_LEGACY_BASE = 'inkdrop-canvas-data';
const META_KEY_BASE = 'inkdrop-canvas-meta';
const META_VERSION = 2;
let _saveTimer = null;

function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

/* Active vault id read from the window global that vault-store sets.
 * The default vault keeps using the legacy keys and flat cloud prefix so
 * existing data is preserved byte-for-byte on upgrade. */
function currentVaultId() {
  if (typeof window !== 'undefined' && window.__activeVaultId) return window.__activeVaultId;
  return 'default';
}
function legacyKey(vaultId) {
  const id = vaultId || currentVaultId();
  return id === 'default' ? LOCAL_KEY_LEGACY_BASE : `${LOCAL_KEY_LEGACY_BASE}:${id}`;
}
function metaKey(vaultId) {
  const id = vaultId || currentVaultId();
  return id === 'default' ? META_KEY_BASE : `${META_KEY_BASE}:${id}`;
}
function vaultQuery() {
  const id = currentVaultId();
  return id === 'default' ? '' : `&vault=${encodeURIComponent(id)}`;
}
function vaultQueryFirst() {
  const id = currentVaultId();
  return id === 'default' ? '' : `?vault=${encodeURIComponent(id)}`;
}

// ── Legacy flat-storage helpers (still used for actual scene bytes) ─────────
function loadLegacy() {
  try { return JSON.parse(localStorage.getItem(legacyKey())) || {}; } catch { return {}; }
}
function saveLegacyFor(canvasName, elements, files) {
  try {
    const all = loadLegacy();
    all[canvasName] = { elements, files, updatedAt: new Date().toISOString() };
    localStorage.setItem(legacyKey(), JSON.stringify(all));
  } catch {}
}
function deleteLegacy(name) {
  try {
    const all = loadLegacy();
    delete all[name];
    localStorage.setItem(legacyKey(), JSON.stringify(all));
  } catch {}
}
function renameLegacy(oldName, newName) {
  try {
    const all = loadLegacy();
    if (all[oldName]) { all[newName] = all[oldName]; delete all[oldName]; }
    localStorage.setItem(legacyKey(), JSON.stringify(all));
  } catch {}
}

// ── Meta (folders + id→name mapping + open tabs) ────────────────────────────
function loadMeta(vaultId) {
  try {
    const raw = localStorage.getItem(metaKey(vaultId));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === META_VERSION) return parsed;
    }
  } catch {}
  return null;
}
function saveMeta(state, vaultId) {
  try {
    localStorage.setItem(metaKey(vaultId), JSON.stringify({
      version: META_VERSION,
      folders: state.folders,
      canvases: state.canvases,
      openTabs: state.openTabs,
      activeCanvasId: state.activeCanvasId,
    }));
  } catch {}
}

function uniqueCanvasName(canvases, name, folderId) {
  const exists = (n) => Object.values(canvases).some(
    (c) => c.name === n && (c.folderId || null) === (folderId || null)
  );
  if (!exists(name)) return name;
  for (let i = 2; i < 1000; i += 1) {
    const cand = `${name} (${i})`;
    if (!exists(cand)) return cand;
  }
  return `${name}_${Date.now()}`;
}

function uniqueFolderName(folders, name, parentId) {
  const exists = (n) => Object.values(folders).some(
    (f) => f.name === n && (f.parentId || null) === (parentId || null)
  );
  if (!exists(name)) return name;
  for (let i = 2; i < 1000; i += 1) {
    const cand = `${name} (${i})`;
    if (!exists(cand)) return cand;
  }
  return `${name}_${Date.now()}`;
}

// Build initial state from meta + legacy flat store, or migrate if meta is missing.
function buildInitialState() {
  const meta = loadMeta();
  const legacy = loadLegacy();
  const legacyNames = Object.keys(legacy);

  if (meta) {
    // Reconcile any legacy canvases that aren't yet tracked in meta
    const canvases = { ...(meta.canvases || {}) };
    const byName = new Map();
    for (const c of Object.values(canvases)) byName.set(c.name, c.id);

    for (const name of legacyNames) {
      if (!byName.has(name)) {
        const id = uid('cv');
        canvases[id] = {
          id,
          name,
          folderId: null,
          updatedAt: legacy[name]?.updatedAt || '',
        };
      }
    }
    return {
      folders: meta.folders || {},
      canvases,
      openTabs: (meta.openTabs || []).filter((t) => canvases[t]),
      activeCanvasId: canvases[meta.activeCanvasId] ? meta.activeCanvasId : null,
    };
  }

  // First-run migration: every legacy name becomes a root-level canvas row.
  const canvases = {};
  for (const name of legacyNames) {
    const id = uid('cv');
    canvases[id] = {
      id,
      name,
      folderId: null,
      updatedAt: legacy[name]?.updatedAt || '',
    };
  }

  // Seed a default if none exist.
  if (Object.keys(canvases).length === 0) {
    const id = uid('cv');
    const name = 'Untitled Canvas';
    canvases[id] = { id, name, folderId: null, updatedAt: '' };
    saveLegacyFor(name, [], {});
  }

  const firstId = Object.keys(canvases)[0] || null;
  return {
    folders: {},
    canvases,
    openTabs: firstId ? [firstId] : [],
    activeCanvasId: firstId,
  };
}

const initial = buildInitialState();

export const useCanvasStore = create((set, get) => ({
  // ── Hierarchy & tabs ─────────────────────────────────────────────────────
  folders: initial.folders,
  canvases: initial.canvases,
  openTabs: initial.openTabs,
  activeCanvasId: initial.activeCanvasId,

  // ── Active scene (for the currently-open canvas) ─────────────────────────
  elements: [],
  files: {},
  cloudStatus: 'idle',

  // ── Sidebar ──────────────────────────────────────────────────────────────
  sidebarOpen: true,
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),

  // ── Scene updates for active canvas ──────────────────────────────────────
  setScene: (elements, files) => {
    const s = get();
    const active = s.canvases[s.activeCanvasId];
    if (!active) {
      set({ elements: elements || [], files: files || {} });
      return;
    }
    set({ elements: elements || [], files: files || {} });
    saveLegacyFor(active.name, elements || [], files || {});

    const updatedAt = new Date().toISOString();
    const canvases = {
      ...s.canvases,
      [active.id]: { ...active, updatedAt },
    };
    set({ canvases });
    saveMeta({ ...s, canvases });

    get()._debounceSave();
  },

  // ── Canvas CRUD (id-based) ───────────────────────────────────────────────
  createCanvas: (rawName, folderId = null) => {
    const s = get();
    const baseName = (rawName && rawName.trim()) || `Canvas ${Date.now().toString(36)}`;
    const name = uniqueCanvasName(s.canvases, baseName, folderId);
    const id = uid('cv');
    const canvas = { id, name, folderId: folderId || null, updatedAt: new Date().toISOString() };
    const canvases = { ...s.canvases, [id]: canvas };
    const openTabs = s.openTabs.includes(id) ? s.openTabs : [...s.openTabs, id];

    saveLegacyFor(name, [], {});
    set({
      canvases,
      openTabs,
      activeCanvasId: id,
      elements: [],
      files: {},
      cloudStatus: 'idle',
    });
    saveMeta({ ...s, canvases, openTabs, activeCanvasId: id });
    get()._saveToCloud();
    return id;
  },

  deleteCanvas: (id) => {
    const s = get();
    const target = s.canvases[id];
    if (!target) return;

    deleteLegacy(target.name);
    destroyWidgetStorageForCanvas(target.name);
    fetch(`/api/canvas/delete?name=${encodeURIComponent(target.name)}${vaultQuery()}`, {
      method: 'DELETE', headers: getAuthHeaders(),
    }).catch(() => {});

    const canvases = { ...s.canvases };
    delete canvases[id];
    const openTabs = s.openTabs.filter((t) => t !== id);

    let activeCanvasId = s.activeCanvasId;
    let elements = s.elements;
    let files = s.files;

    if (activeCanvasId === id) {
      const nextId = openTabs[openTabs.length - 1] || Object.keys(canvases)[0] || null;
      activeCanvasId = nextId;
      if (nextId) {
        // Preload next canvas synchronously from legacy storage.
        const legacy = loadLegacy();
        const next = canvases[nextId];
        elements = legacy[next.name]?.elements || [];
        files = legacy[next.name]?.files || {};
      } else {
        elements = [];
        files = {};
      }
    }

    set({ canvases, openTabs, activeCanvasId, elements, files });
    saveMeta({ ...s, canvases, openTabs, activeCanvasId });

    // Auto-seed if we deleted the last one
    if (Object.keys(canvases).length === 0) {
      get().createCanvas('Untitled Canvas');
    }
  },

  renameCanvas: (id, newName) => {
    const s = get();
    const target = s.canvases[id];
    if (!target) return;
    const trimmed = (newName || '').trim();
    if (!trimmed || trimmed === target.name) return;

    const without = Object.fromEntries(Object.entries(s.canvases).filter(([k]) => k !== id));
    const finalName = uniqueCanvasName(without, trimmed, target.folderId);

    renameLegacy(target.name, finalName);
    renameWidgetStorageCanvas(target.name, finalName);

    const canvases = {
      ...s.canvases,
      [id]: { ...target, name: finalName, updatedAt: new Date().toISOString() },
    };
    set({ canvases });
    saveMeta({ ...s, canvases });
    get()._debounceSave();
  },

  duplicateCanvas: (id) => {
    const s = get();
    const src = s.canvases[id];
    if (!src) return null;
    const legacy = loadLegacy();
    const srcData = legacy[src.name] || { elements: [], files: {} };

    const baseName = src.name;
    const finalName = uniqueCanvasName(s.canvases, baseName, src.folderId);
    const newId = uid('cv');
    const copy = {
      id: newId,
      name: finalName,
      folderId: src.folderId,
      updatedAt: new Date().toISOString(),
    };
    saveLegacyFor(finalName, srcData.elements || [], srcData.files || {});

    const canvases = { ...s.canvases, [newId]: copy };
    const openTabs = [...s.openTabs, newId];
    set({ canvases, openTabs });
    saveMeta({ ...s, canvases, openTabs });
    return newId;
  },

  moveCanvas: (id, folderId) => {
    const s = get();
    const target = s.canvases[id];
    if (!target) return;
    const canvases = {
      ...s.canvases,
      [id]: { ...target, folderId: folderId || null },
    };
    set({ canvases });
    saveMeta({ ...s, canvases });
  },

  /* Reparent a folder. Cycle-safe: rejects moving into self or any descendant. */
  moveFolder: (folderId, parentId) => {
    if (!folderId || folderId === parentId) return;
    const s = get();
    const current = s.folders[folderId];
    if (!current) return;
    const newParent = parentId || null;
    if ((current.parentId || null) === newParent) return;

    if (newParent) {
      const descendants = new Set([folderId]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const f of Object.values(s.folders)) {
          if (!descendants.has(f.id) && f.parentId && descendants.has(f.parentId)) {
            descendants.add(f.id);
            changed = true;
          }
        }
      }
      if (descendants.has(newParent)) return;
    }

    const folders = { ...s.folders, [folderId]: { ...current, parentId: newParent } };
    set({ folders });
    saveMeta({ ...s, folders });
  },

  // ── Folder CRUD ──────────────────────────────────────────────────────────
  createFolder: (name, parentId = null) => {
    const s = get();
    const trimmed = (name || '').trim() || 'New Folder';
    const finalName = uniqueFolderName(s.folders, trimmed, parentId);
    const id = uid('fd');
    const folder = { id, name: finalName, parentId: parentId || null };
    const folders = { ...s.folders, [id]: folder };
    set({ folders });
    saveMeta({ ...s, folders });
    return id;
  },

  renameFolder: (id, newName) => {
    const s = get();
    const current = s.folders[id];
    if (!current) return;
    const trimmed = (newName || '').trim();
    if (!trimmed || trimmed === current.name) return;
    const siblings = Object.fromEntries(Object.entries(s.folders).filter(([k]) => k !== id));
    const finalName = uniqueFolderName(siblings, trimmed, current.parentId);
    const folders = { ...s.folders, [id]: { ...current, name: finalName } };
    set({ folders });
    saveMeta({ ...s, folders });
  },

  deleteFolder: (id) => {
    const s = get();
    if (!s.folders[id]) return;

    const toRemoveFolders = new Set([id]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const f of Object.values(s.folders)) {
        if (!toRemoveFolders.has(f.id) && f.parentId && toRemoveFolders.has(f.parentId)) {
          toRemoveFolders.add(f.id);
          changed = true;
        }
      }
    }

    const folders = {};
    for (const f of Object.values(s.folders)) {
      if (!toRemoveFolders.has(f.id)) folders[f.id] = f;
    }

    const canvases = {};
    const removedCanvasIds = new Set();
    for (const c of Object.values(s.canvases)) {
      if (c.folderId && toRemoveFolders.has(c.folderId)) {
        removedCanvasIds.add(c.id);
        deleteLegacy(c.name);
        destroyWidgetStorageForCanvas(c.name);
        fetch(`/api/canvas/delete?name=${encodeURIComponent(c.name)}${vaultQuery()}`, {
          method: 'DELETE', headers: getAuthHeaders(),
        }).catch(() => {});
      } else {
        canvases[c.id] = c;
      }
    }

    let openTabs = s.openTabs.filter((t) => !removedCanvasIds.has(t));
    let activeCanvasId = s.activeCanvasId;
    let elements = s.elements;
    let files = s.files;
    if (activeCanvasId && removedCanvasIds.has(activeCanvasId)) {
      const nextId = openTabs[openTabs.length - 1] || Object.keys(canvases)[0] || null;
      activeCanvasId = nextId;
      if (nextId) {
        const legacy = loadLegacy();
        const next = canvases[nextId];
        elements = legacy[next.name]?.elements || [];
        files = legacy[next.name]?.files || {};
      } else {
        elements = [];
        files = {};
      }
    }

    set({ folders, canvases, openTabs, activeCanvasId, elements, files });
    saveMeta({ ...s, folders, canvases, openTabs, activeCanvasId });

    if (Object.keys(canvases).length === 0) {
      get().createCanvas('Untitled Canvas');
    }
  },

  // ── Tab management ───────────────────────────────────────────────────────
  openCanvasInTab: (id) => {
    const s = get();
    if (!s.canvases[id]) return;
    const openTabs = s.openTabs.includes(id) ? s.openTabs : [...s.openTabs, id];
    set({ openTabs, activeCanvasId: id });
    saveMeta({ ...s, openTabs, activeCanvasId: id });
    get()._loadActive(id);
  },

  setActiveCanvas: (id) => {
    const s = get();
    if (!s.canvases[id] || s.activeCanvasId === id) {
      if (s.canvases[id] && !s.openTabs.includes(id)) {
        const openTabs = [...s.openTabs, id];
        set({ openTabs });
        saveMeta({ ...s, openTabs });
      }
      return;
    }
    const openTabs = s.openTabs.includes(id) ? s.openTabs : [...s.openTabs, id];
    set({ activeCanvasId: id, openTabs });
    saveMeta({ ...s, activeCanvasId: id, openTabs });
    get()._loadActive(id);
  },

  closeTab: (id) => {
    const s = get();
    if (!s.openTabs.includes(id)) return;
    const openTabs = s.openTabs.filter((t) => t !== id);
    let activeCanvasId = s.activeCanvasId;
    let elements = s.elements;
    let files = s.files;
    if (activeCanvasId === id) {
      const idx = s.openTabs.indexOf(id);
      const nextId = openTabs[Math.min(idx, openTabs.length - 1)] || openTabs[0] || null;
      activeCanvasId = nextId;
      if (nextId) {
        const legacy = loadLegacy();
        const next = s.canvases[nextId];
        elements = legacy[next.name]?.elements || [];
        files = legacy[next.name]?.files || {};
      } else {
        elements = [];
        files = {};
      }
    }
    set({ openTabs, activeCanvasId, elements, files });
    saveMeta({ ...s, openTabs, activeCanvasId });
  },

  _loadActive: async (id) => {
    const s = get();
    const c = s.canvases[id];
    if (!c) return;
    const legacy = loadLegacy();
    if (legacy[c.name]) {
      set({
        elements: legacy[c.name].elements || [],
        files: legacy[c.name].files || {},
        cloudStatus: 'saved',
      });
      return;
    }
    try {
      const res = await fetch(`/api/canvas/sync?name=${encodeURIComponent(c.name)}${vaultQuery()}`, { headers: getAuthHeaders() });
      if (!res.ok) return;
      const data = await res.json();
      if (data.exists && data.data) {
        const elems = data.data.elements || [];
        const f = data.data.files || {};
        set({ elements: elems, files: f, cloudStatus: 'saved' });
        saveLegacyFor(c.name, elems, f);
      }
    } catch (e) {
      console.error('[Canvas] load error:', e);
    }
  },

  // ── Cloud sync ───────────────────────────────────────────────────────────
  _debounceSave: () => {
    if (_saveTimer) clearTimeout(_saveTimer);
    set({ cloudStatus: 'pending' });
    _saveTimer = setTimeout(() => get()._saveToCloud(), CLOUD_DEBOUNCE);
  },

  _saveToCloud: async () => {
    const s = get();
    const active = s.canvases[s.activeCanvasId];
    if (!active) { set({ cloudStatus: 'idle' }); return; }
    saveLegacyFor(active.name, s.elements, s.files);
    set({ cloudStatus: 'syncing' });
    try {
      const res = await fetch(`/api/canvas/sync${vaultQueryFirst()}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ name: active.name, elements: s.elements, files: s.files }),
      });
      if (res.ok) set({ cloudStatus: 'saved' });
      else set({ cloudStatus: 'error' });
    } catch {
      set({ cloudStatus: 'error' });
    }
  },

  // Loads cloud list and merges any remote canvases not yet in local meta.
  refreshCanvasList: async () => {
    try {
      const res = await fetch(`/api/canvas/list${vaultQueryFirst()}`, { headers: getAuthHeaders() });
      if (!res.ok) return;
      const cloud = await res.json();
      const s = get();
      const byName = new Map();
      for (const c of Object.values(s.canvases)) byName.set(c.name, c.id);

      const canvases = { ...s.canvases };
      let changed = false;
      for (const c of cloud) {
        if (!byName.has(c.name)) {
          const id = uid('cv');
          canvases[id] = { id, name: c.name, folderId: null, updatedAt: c.updatedAt || '' };
          changed = true;
        }
      }
      if (changed) {
        set({ canvases });
        saveMeta({ ...s, canvases });
      }
    } catch {}
  },

  // Legacy entrypoint (kept for first paint of App.jsx)
  loadFromCloud: async () => {
    const s = get();
    if (s.activeCanvasId) {
      await get()._loadActive(s.activeCanvasId);
    }
    await get().refreshCanvasList();
  },

  /* Hot-swap all canvas state to the new vault's snapshot. Kills any
   * pending cloud save so the OLD vault's scene bytes don't leak into
   * the NEW vault's storage prefix. */
  reloadForVault: async (newVaultId) => {
    if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
    const meta = loadMeta(newVaultId);
    const canvases = meta?.canvases || {};
    const folders = meta?.folders || {};
    const openTabs = Array.isArray(meta?.openTabs) ? meta.openTabs.filter((id) => canvases[id]) : [];
    let activeCanvasId = meta?.activeCanvasId && canvases[meta.activeCanvasId]
      ? meta.activeCanvasId
      : (openTabs[0] || Object.keys(canvases)[0] || null);

    /* Seed the scene bytes from legacy local storage if present. */
    let elements = [];
    let files = {};
    if (activeCanvasId) {
      const active = canvases[activeCanvasId];
      if (active) {
        /* loadLegacy reads from currentVaultId(); by this point
         * window.__activeVaultId has already been updated to newVaultId. */
        const legacy = loadLegacy();
        if (legacy[active.name]) {
          elements = legacy[active.name].elements || [];
          files = legacy[active.name].files || {};
        }
      }
    }
    set({
      canvases,
      folders,
      openTabs,
      activeCanvasId,
      elements,
      files,
      cloudStatus: 'idle',
    });
    /* Pull fresh list + active scene from cloud in background. */
    try { await get().refreshCanvasList(); } catch {}
    if (activeCanvasId) {
      try { await get()._loadActive(activeCanvasId); } catch {}
    }
  },
}));

if (typeof window !== 'undefined') {
  import('./vault-store.js').then(({ onVaultChange }) => {
    onVaultChange((nextId) => useCanvasStore.getState().reloadForVault(nextId));
  }).catch(() => {});
}
