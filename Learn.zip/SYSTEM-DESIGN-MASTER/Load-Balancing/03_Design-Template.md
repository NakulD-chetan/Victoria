# Load Balancing — Design Template (Deep Understanding)

> **Permanent Recall:** Reusable LB patterns: (1) single LB for small systems; (2) multi-tier DNS→L4→L7 for scale; (3) LB + auto-scaling for variable load; (4) service mesh with sidecar LB for microservices. Know one config example each for Nginx, HAProxy, and AWS ALB/NLB to discuss in interviews.

---

## Why Design Patterns Matter

Instead of designing load balancing from scratch every time, use **proven patterns**. Each pattern fits a specific scale and complexity level. Think of them as blueprints.

---

## Pattern 1: Single LB (Simple)

### What It Is

One load balancer in front of N identical backend servers.

```
                    ┌─────────────────────────────────┐
                    │         Load Balancer            │
                    │     (Nginx / HAProxy / ALB)      │
                    └────────────────┬────────────────┘
                                     │
              ┌──────────────────────┼──────────────────────┐
              │                      │                      │
              ▼                      ▼                      ▼
        ┌──────────┐           ┌──────────┐           ┌──────────┐
        │ Server 1 │           │ Server 2 │           │ Server 3 │
        └──────────┘           └──────────┘           └──────────┘
```

### When to Use

- MVP, internal tools, small apps (<1000 requests/sec)
- Single team, single service
- Quick to set up, easy to understand

### How It Works Internally

```
1. DNS resolves your domain → LB's public IP
2. Client connects to LB
3. LB picks a server (e.g., round robin)
4. LB forwards request to that server
5. Server responds → LB forwards back to client
```

### Real-World Example

You build a simple blog API. It gets 500 requests/second. One server handles 200 req/s. You need 3 servers.

```
Nginx config:
  upstream blog_api {
      server 10.0.1.1:8080;
      server 10.0.1.2:8080;
      server 10.0.1.3:8080;
  }
  
  server {
      listen 80;
      location / {
          proxy_pass http://blog_api;
      }
  }
```

### Limitations

| Problem | What Happens |
|---------|-------------|
| LB itself is SPOF | LB dies → entire service down |
| Can't route by path | All requests go to same server pool |
| No geographic routing | Users far away get high latency |
| Manual scaling | You add/remove servers manually |

---

## Pattern 2: Multi-Tier LB (DNS → L4 → L7)

### What It Is

Three layers of load balancing, each doing a different job.

```
    Clients (worldwide)
       │
       ▼
┌──────────────┐
│  DNS / GSLB  │  Layer 1: "Which REGION should handle this user?"
│  (Route53,   │  Returns IP of nearest L4 LB
│  Cloudflare) │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  L4 LB       │  Layer 2: "Distribute TCP connections efficiently"
│  (NLB / LVS) │  Handles millions of connections, SSL pass-through
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  L7 LB       │  Layer 3: "Route by HTTP path/headers"
│  (ALB/Nginx) │  /api/users → Service A, /api/orders → Service B
└──────┬───────┘
       │
       ├─────────────┬─────────────┐
       ▼             ▼             ▼
   /api/users    /api/orders    /static
   User Service  Order Service  CDN/Static
   [S1, S2, S3]  [S4, S5]      [S6, S7]
```

### Why Three Layers?

| Layer | What It Does | Why Not Just Skip It? |
|-------|-------------|----------------------|
| **DNS/GSLB** | Routes to nearest region | Without it, US users hit India servers (300ms latency) |
| **L4 LB** | Raw TCP distribution, handles millions of connections | L7 alone can't handle extreme connection counts; L4 is faster for raw packets |
| **L7 LB** | Smart routing by path, SSL termination | Without it, you can't send /users to user-service and /orders to order-service |

### How It Works Step-by-Step

```
User in India types api.example.com:

1. DNS/GSLB checks user's location → India
   Returns IP of India region's L4 LB: 52.66.10.1

2. User connects to 52.66.10.1 (L4 LB in Mumbai)
   L4 LB distributes TCP connection to one of several L7 LBs
   Picked: L7-LB-2 (10.0.0.2)

3. L7-LB-2 receives HTTP request:
   GET /api/users/123
   L7 reads path → /api/users/* → route to "user-service" pool
   Picks Server 2 from user-service pool

4. Server 2 processes request → response flows back
   Server 2 → L7 LB → L4 LB → User's browser
```

### When to Use

- High-scale web apps (>100K requests/sec)
- Multiple backend services (microservices)
- Global user base (multi-region)
- Companies like Netflix, Google, Amazon use this pattern

---

## Pattern 3: LB with Auto-Scaling Group

### What It Is

The LB is connected to an **auto-scaling group** (ASG). Servers are added automatically when load increases, removed when load decreases. The LB automatically detects new/removed servers.

```
                    ┌─────────────────────────────────┐
                    │         Load Balancer (ALB)       │
                    │    Knows about all servers in ASG │
                    └────────────────┬────────────────┘
                                     │
                    ┌────────────────┼────────────────┐
                    │                │                │
                    ▼                ▼                ▼
              ┌──────────┐    ┌──────────┐    ┌──────────┐
              │Instance 1│    │Instance 2│    │Instance N│
              └──────────┘    └──────────┘    └──────────┘
                     ▲                                ▲
                     │     Auto-Scaling Group          │
                     └──── Scale based on:  ──────────┘
                           - CPU > 70% → add instance
                           - CPU < 30% → remove instance
                           - Request count > threshold
```

### How It Works Step-by-Step

```
Normal day (3 servers handling 300 req/s):
  LB → [S1, S2, S3] (each handles ~100 req/s)

Traffic spike (600 req/s):
  1. CloudWatch alarm: CPU > 70% on all servers
  2. ASG launches 3 new instances (S4, S5, S6)
  3. New instances start, pass health check
  4. LB automatically registers them as targets
  5. LB → [S1, S2, S3, S4, S5, S6] (each handles ~100 req/s)

Traffic drops (150 req/s):
  1. CloudWatch alarm: CPU < 30% on all servers
  2. ASG terminates 3 instances (S4, S5, S6)
  3. LB enables connection draining (finishes in-flight requests)
  4. LB deregisters terminated instances
  5. LB → [S1, S2, S3] (each handles ~50 req/s)
```

### Why This Pattern is Powerful

| Without ASG | With ASG |
|-------------|----------|
| You manually add servers when traffic spikes | Servers auto-scale based on metrics |
| You pay for peak capacity 24/7 | You pay only for what you use |
| Forgot to scale? → outage | Scales automatically → no outage |
| Forgot to scale down? → wasting money | Scales down → saves money |

### AWS-Specific Setup

```
Components:
1. ALB (Application Load Balancer) - routes HTTP traffic
2. Target Group - "api-servers" (linked to ASG)
3. Auto Scaling Group - min: 2, max: 10, desired: 3
4. Launch Template - defines what each new instance looks like
5. Scaling Policy - "Add 1 instance when CPU > 70% for 5 minutes"

Flow:
  ALB → Target Group ("api-servers") → ASG instances
  
  ASG scales out → new instance registers with Target Group → ALB routes to it
  ASG scales in  → instance deregisters → ALB stops routing → instance terminated
```

---

## Pattern 4: LB for Microservices (Service Mesh)

### What It Is

In a microservices architecture, each service can call other services. Instead of one central LB, each service has a **sidecar proxy** (usually Envoy) that handles load balancing for outgoing requests.

### The Problem Service Mesh Solves

```
WITHOUT service mesh:
  Service A needs to call Service B
  Service A must know: all Service B IPs, health status, retry logic, circuit breaking...
  Multiply by 100 services calling each other = NIGHTMARE

WITH service mesh:
  Service A just calls "service-b:8080"
  Sidecar proxy handles: discovery, load balancing, retries, timeouts, encryption
  Service A code is simple; all networking complexity is in the sidecar
```

### Architecture

```
┌─────────────────────────────────────────────────────┐
│  KUBERNETES CLUSTER                                 │
│                                                     │
│  ┌─── Pod A ──────────┐  ┌─── Pod B ──────────┐    │
│  │                    │  │                    │    │
│  │  ┌──────────────┐  │  │  ┌──────────────┐  │    │
│  │  │  Service A   │  │  │  │  Service B   │  │    │
│  │  │  (your code) │  │  │  │  (your code) │  │    │
│  │  └──────┬───────┘  │  │  └──────────────┘  │    │
│  │         │          │  │         ▲           │    │
│  │  ┌──────▼───────┐  │  │  ┌──────┴───────┐  │    │
│  │  │  Sidecar     │──┼──┼──│  Sidecar     │  │    │
│  │  │  (Envoy)     │  │  │  │  (Envoy)     │  │    │
│  │  │  - LB        │  │  │  │  - LB        │  │    │
│  │  │  - Retry     │  │  │  │  - Retry     │  │    │
│  │  │  - Timeout   │  │  │  │  - Timeout   │  │    │
│  │  │  - mTLS      │  │  │  │  - mTLS      │  │    │
│  │  └──────────────┘  │  │  └──────────────┘  │    │
│  └────────────────────┘  └────────────────────┘    │
│                                                     │
│  ┌──────────────────────────────────────────┐       │
│  │  Control Plane (Istio / Linkerd)         │       │
│  │  - Service discovery                     │       │
│  │  - Configuration                         │       │
│  │  - Certificate management                │       │
│  └──────────────────────────────────────────┘       │
└─────────────────────────────────────────────────────┘
```

### How the Sidecar LB Works

```
Service A wants to call Service B:

1. Service A sends request to localhost:8080 (sidecar intercepts it)
2. Sidecar looks up "Service B" in service registry
3. Finds Service B has 3 instances: [10.0.1.1, 10.0.1.2, 10.0.1.3]
4. Sidecar picks one using least connections algorithm
5. Sidecar forwards request to 10.0.1.2:8080
6. If 10.0.1.2 fails, sidecar automatically retries on 10.0.1.3
7. Response comes back through sidecar → Service A
```

### When to Use Service Mesh

| Use Service Mesh When | Don't Use When |
|-----------------------|----------------|
| 10+ microservices calling each other | Monolith or few services |
| Need mTLS between services | Simple internal network is sufficient |
| Need per-service retry/timeout policies | Basic retry logic in code is enough |
| Need observability (tracing, metrics) per service call | External monitoring is sufficient |
| Kubernetes environment | Traditional VMs (overhead not worth it) |

---

## Configuration Examples — Deep Explanation

### Nginx Configuration (Explained Line by Line)

```nginx
# UPSTREAM BLOCK: Defines a group of backend servers
# "backend" is just a name you choose — it's referenced below
upstream backend {
    # Algorithm: "least_conn" sends to server with fewest connections
    # Other options: (remove this line for default round robin), ip_hash
    least_conn;
    
    # Server list with weights
    # weight=2 means Server 1 gets 2x traffic vs Server 2
    server 10.0.1.1:8080 weight=2;
    server 10.0.1.2:8080 weight=1;
    
    # "backup" means this server is ONLY used when all others are down
    # Like a spare tire — only used in emergencies
    server 10.0.1.3:8080 backup;
    
    # Health check: Nginx OSS does passive checks by default
    # Nginx Plus (paid) supports active health checks
    # max_fails=3: mark as down after 3 consecutive failures
    # fail_timeout=30s: try again after 30 seconds
    server 10.0.1.1:8080 max_fails=3 fail_timeout=30s;
}

# SERVER BLOCK: Defines how Nginx listens and routes
server {
    # Listen on port 80 (HTTP)
    listen 80;
    
    # For HTTPS, you'd add:
    # listen 443 ssl;
    # ssl_certificate /path/to/cert.pem;
    # ssl_certificate_key /path/to/key.pem;
    
    # LOCATION BLOCK: Match URL paths
    location / {
        # Forward ALL requests to the "backend" upstream group
        proxy_pass http://backend;
        
        # Pass the original Host header (important for virtual hosts)
        proxy_set_header Host $host;
        
        # Tell backend the real client IP (otherwise it sees Nginx's IP)
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        
        # Tell backend the original protocol (HTTP or HTTPS)
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # Route different paths to different backends
    location /api/users {
        proxy_pass http://user_service;  # separate upstream
    }
    
    location /api/orders {
        proxy_pass http://order_service;  # separate upstream
    }
}
```

### HAProxy Configuration (Explained Line by Line)

```haproxy
# GLOBAL: Process-wide settings
global
    # Max connections HAProxy can handle simultaneously
    maxconn 50000
    
    # Run as background daemon
    daemon

# DEFAULTS: Default settings for all frontends/backends
defaults
    # Mode: "http" = L7 (understands HTTP), "tcp" = L4 (raw TCP)
    mode http
    
    # Timeouts (CRITICAL — wrong values cause hanging connections)
    timeout connect 5s    # Max time to establish connection to backend
    timeout client 30s    # Max time client can be idle
    timeout server 30s    # Max time server can take to respond

# FRONTEND: Where HAProxy LISTENS for incoming traffic
# Think of it as the "entrance door"
frontend http_in
    # Listen on port 80, all network interfaces
    bind *:80
    
    # For HTTPS:
    # bind *:443 ssl crt /path/to/cert.pem
    
    # URL-based routing (L7 feature)
    # If path starts with /api → send to api_servers backend
    acl is_api path_beg /api
    use_backend api_servers if is_api
    
    # Everything else → default backend
    default_backend web_servers

# BACKEND: Group of servers that handle requests
# Think of it as the "kitchen" in a restaurant
backend api_servers
    # Algorithm: roundrobin, leastconn, source (IP hash)
    balance roundrobin
    
    # Active health check: Send GET /health every 5 seconds
    option httpchk GET /health
    # Expect HTTP 200 response — anything else = unhealthy
    http-check expect status 200
    
    # Server list
    # "check" enables health checking for this server
    # "inter 5s" = check every 5 seconds
    # "fall 3" = mark unhealthy after 3 failures
    # "rise 2" = mark healthy after 2 successes
    server s1 10.0.1.1:8080 check inter 5s fall 3 rise 2
    server s2 10.0.1.2:8080 check inter 5s fall 3 rise 2
    server s3 10.0.1.3:8080 check inter 5s fall 3 rise 2

backend web_servers
    balance roundrobin
    server web1 10.0.2.1:3000 check
    server web2 10.0.2.2:3000 check
```

### AWS ALB Configuration (Explained)

```
AWS ALB Setup (via console or Terraform):

1. CREATE ALB
   - Name: my-app-lb
   - Scheme: internet-facing (public) or internal
   - Listeners: HTTPS:443 (with ACM certificate)
   - Subnets: at least 2 AZs (for HA)

2. CREATE TARGET GROUPS
   Target Group 1: "api-servers"
     - Protocol: HTTP, Port: 8080
     - Health check: GET /health, interval 30s, threshold 3
     - Targets: EC2 instances running API
   
   Target Group 2: "web-servers"
     - Protocol: HTTP, Port: 3000
     - Health check: GET /, interval 30s, threshold 3
     - Targets: EC2 instances running web frontend

3. CREATE LISTENER RULES (L7 path-based routing)
   HTTPS:443 Listener:
   ┌────────────────────────────────────────┐
   │  Rule 1: IF path = /api/*             │
   │          THEN forward to "api-servers" │
   │                                        │
   │  Rule 2: IF path = /static/*          │
   │          THEN forward to "static-s3"  │
   │                                        │
   │  Default: forward to "web-servers"     │
   └────────────────────────────────────────┘
```

```
HOW THE REQUEST FLOWS THROUGH ALB:

User: GET https://myapp.com/api/users

1. DNS → ALB's public IP
2. ALB accepts HTTPS connection, terminates SSL
3. ALB reads HTTP path: /api/users
4. Matches Rule 1: /api/* → forward to "api-servers" target group
5. ALB picks healthy target from api-servers using round robin
6. ALB forwards HTTP request to selected EC2 instance
7. EC2 responds → ALB forwards to user
```

### AWS NLB Configuration (Explained)

```
AWS NLB Setup:

1. CREATE NLB
   - Name: my-tcp-lb
   - Scheme: internet-facing
   - Listener: TCP:443
   - Static IP: YES (NLB gives you static IP — ALB doesn't!)

2. CREATE TARGET GROUP
   - Protocol: TCP, Port: 443
   - Health check: TCP (just checks if port is open)
   - Targets: EC2 instances

WHY NLB INSTEAD OF ALB?
  - Need static IP? → NLB (ALB's IP changes)
  - Need extreme performance (millions of connections)? → NLB
  - Non-HTTP protocol (database, custom TCP)? → NLB
  - Need lowest possible latency? → NLB
  - Need to see client's real IP without X-Forwarded-For? → NLB (preserves source IP)
```

### ALB vs NLB — Complete Comparison

| Aspect | ALB (Application LB) | NLB (Network LB) |
|--------|----------------------|-------------------|
| **Layer** | L7 (HTTP/HTTPS) | L4 (TCP/UDP/TLS) |
| **Routing** | Path, host, header, query string | Port-based only |
| **SSL** | Terminates SSL | Pass-through or terminates |
| **IP** | Dynamic IP (use DNS name) | Static IP per AZ |
| **Performance** | Good (millions req/s) | Extreme (millions connections/s) |
| **Latency** | ~ms (HTTP parsing) | ~μs (no HTTP parsing) |
| **Use case** | HTTP APIs, web apps, microservices | TCP/UDP apps, gaming, IoT, DB proxy |
| **Client IP** | Via X-Forwarded-For header | Preserved natively |
| **WebSocket** | Supported | Supported |
| **Cost** | Higher (per rule, per connection) | Lower (per connection) |

---

## Architecture Summary Table

| Pattern | Components | Scale | Complexity | When to Use |
|---------|------------|-------|------------|-------------|
| **Single LB** | 1 LB, N backends | Small | Low | MVP, internal tools, <1K req/s |
| **Multi-tier** | DNS → L4 → L7 | Very Large | High | Production, microservices, global |
| **LB + ASG** | LB + auto-scaling backends | Medium-Large | Medium | Cloud-native, variable traffic |
| **Service Mesh** | Ingress + sidecar per service | Large | Very High | 10+ microservices, K8s |

### How to Choose

```
Building a side project / MVP?
  → Single LB (Nginx or ALB)

Building a cloud app with variable traffic?
  → LB + ASG (ALB + Auto Scaling Group)

Building for global users with multiple services?
  → Multi-tier (GSLB → NLB → ALB)

Building 10+ microservices on Kubernetes?
  → Service Mesh (Istio/Envoy) + Ingress LB
```

---

## Quick Memory Card

```
SINGLE:       One LB, N backends — MVP, simple
MULTI-TIER:   DNS → L4 → L7 — production, global, multiple services
ASG:          LB + auto-scaling — cloud-native, pay-for-what-you-use
MESH:         Sidecar proxy per service — microservices, K8s
NGINX:        upstream block + proxy_pass; weight, backup, max_fails
HAPROXY:      frontend (listen) + backend (servers); balance, httpchk
ALB:          L7, path routing, SSL termination, dynamic IP
NLB:          L4, static IP, extreme performance, preserves source IP
```

---

**Next:** [[04_Interview-Thinking]]
