# EASY: Internals - TLS Handshake and Cryptography

> **Quick Recall:** TLS is the security layer used by HTTPS. It makes sure the client is talking to the real server, creates shared secret keys, and then encrypts all HTTP data. TLS 1.2 usually needs 2 round trips for handshake. TLS 1.3 usually needs 1 round trip. After handshake, data is protected using fast symmetric encryption like `AES-256-GCM` or `ChaCha20-Poly1305`.

---

## Why TLS Matters in API Design

When you call:

```js
fetch("https://api.example.com/users/123")
```

the browser or client is not directly sending HTTP first.

It usually does this:

1. TCP handshake
2. TLS handshake
3. Encrypted HTTP request and response

So for a **new connection**, TLS adds extra latency.

Example:

- If network RTT is `100 ms`
- TLS 1.2 may add around `200 ms`
- TLS 1.3 may add around `100 ms`

This is why the following things matter a lot in backend and API design:

- `connection pooling`: reuse existing secure connections
- `HTTP/2`: many requests can share one TLS connection
- `TLS 1.3`: fewer round trips than TLS 1.2
- `0-RTT resumption`: very fast reconnect in some cases
- `gRPC`: often uses long-lived HTTP/2 connections, so TLS cost is paid less often

Simple idea:

`TCP -> TLS -> HTTP`

HTTP travels **inside** the encrypted TLS tunnel.

---

## TLS 1.2 Handshake in Easy Language

TLS 1.2 usually takes **2 round trips**.

### Step-by-step

1. **ClientHello**
   The client starts the conversation and says:
   - I want to use TLS 1.2
   - Here is my random value
   - Here are the cipher suites I support
   - Here are extra extensions like `SNI` and `ALPN`

2. **ServerHello**
   The server replies:
   - OK, we will use TLS 1.2
   - Here is my random value
   - I choose this cipher suite

3. **Certificate**
   The server sends its certificate chain so the client can verify the server identity.

4. **ServerKeyExchange**
   If using `ECDHE`, the server sends key exchange parameters and its public key.
   This message is signed using the server's private key so the client knows it is genuine.

5. **ServerHelloDone**
   The server says it is done with its first set of messages.

6. **ClientKeyExchange**
   The client sends its own ECDHE public key.
   Now both client and server can calculate the same shared secret.

7. **ChangeCipherSpec**
   The client says: from now on, I will start using encryption.

8. **Finished**
   The client sends an encrypted proof that it computed the handshake correctly.

9. **ChangeCipherSpec**
   The server also switches to encrypted communication.

10. **Finished**
    The server sends its own encrypted proof.

After this, handshake is complete and normal HTTP data can be sent securely.

### Main point

TLS 1.2 is slower because the client waits for the server's key exchange details before sending its own.

---

## TLS 1.3 Handshake in Easy Language

TLS 1.3 is faster and cleaner. It usually takes **1 round trip**.

### What changed?

In TLS 1.3, the client does something smart:

- it sends its key share immediately in `ClientHello`
- it does not wait for the server first

This removes one round trip in most cases.

### Step-by-step

1. **ClientHello**
   The client sends:
   - TLS 1.3 support
   - random value
   - cipher suites
   - supported groups like `x25519`
   - its ECDHE public key
   - `ALPN` values like `h2` or `http/1.1`

2. **ServerHello + other handshake messages**
   The server sends:
   - chosen cipher suite
   - its ECDHE public key
   - encrypted extensions
   - certificate
   - proof that it owns the certificate
   - finished message

3. **Client Finished**
   The client sends its finished message.

At this point, the client can already send encrypted HTTP data.

### Why TLS 1.3 is faster

- TLS 1.2: client waits, then sends key exchange
- TLS 1.3: client sends key share immediately

If the server does not like the client's chosen group, it can send `HelloRetryRequest`, but that is less common.

### Important security improvement

TLS 1.3 requires **forward secrecy**.

That means even if the server's long-term private key is leaked in the future, old session traffic still cannot be decrypted.

---

## 0-RTT Resumption

TLS 1.3 can sometimes reconnect with **0 extra round trips**.

After a successful earlier connection, the server gives the client a **session ticket**.
That ticket helps create a `PSK` (Pre-Shared Key).

On the next connection:

- client sends `ClientHello`
- includes the PSK info
- may also send application data immediately

So the first request can travel in the first packet itself.

### Why this is useful

It reduces latency a lot for repeated connections.

### Why this is dangerous

0-RTT data has two important risks:

- it is **not forward-secret** in the same way as a fresh handshake
- it is **replayable**, meaning an attacker might resend it

So 0-RTT is usually safe only for:

- `GET`
- other idempotent operations

It is usually unsafe for:

- `POST`
- money transfer
- order placement
- any action that should happen only once

Servers should also use anti-replay protection.

---

## Certificate Chain Verification

The certificate tells the client: "this server really is `api.example.com`."

But the client should not blindly trust it.
It verifies a chain like this:

- server certificate
- intermediate CA certificate
- root CA certificate

### Chain structure

1. **Leaf / server certificate**
   - belongs to the actual server
   - contains the domain name
   - contains the server public key

2. **Intermediate CA certificate**
   - signed by the root CA
   - used to sign server certificates

3. **Root CA certificate**
   - already trusted by the operating system or browser
   - stored in the machine trust store

### What the client checks

1. The chain is complete and correctly linked.
2. Each certificate signature is valid.
3. The root CA is trusted by the OS/browser.
4. The certificate is within its valid date range.
5. The certificate is not revoked.
6. The domain name matches the certificate.

Example:

- request is for `api.example.com`
- certificate should match `api.example.com` or maybe `*.example.com`

### If verification fails

The connection should be rejected.

Common errors:

- browser warning
- `CERTIFICATE_VERIFY_FAILED`
- `SSLHandshakeException`
- `ERR_CERT_AUTHORITY_INVALID`

---

## ECDHE Key Exchange in Easy Language

`ECDHE` stands for:

**Elliptic Curve Diffie-Hellman Ephemeral**

Its job is to let client and server agree on the same secret key over a public network.

### Basic idea

Both sides create:

- a private key
- a public key

They exchange only the **public** keys.
Then each side uses:

- its own private key
- the other side's public key

to calculate the same shared secret.

An attacker can see both public keys but still should not be able to calculate the secret.

### Why "ephemeral" matters

`Ephemeral` means the key pair is temporary and created fresh for each connection.

This gives **forward secrecy**:

- if server long-term key is stolen later
- past TLS sessions are still safe

That is one of the biggest security wins of modern TLS.

### Key derivation

The shared secret is not used directly.
It goes through a key derivation function like `HKDF` to produce:

- client write key
- server write key
- IVs / nonces

These are then used for actual encryption.

### Performance note

Modern ECDHE is fast enough that network round trips are often a bigger cost than the crypto itself.

---

## Symmetric Encryption After Handshake

Once the handshake is done, TLS switches to **symmetric encryption**.

This is used because symmetric encryption is much faster than public-key crypto.

Common ciphers:

- `AES-256-GCM`
- `ChaCha20-Poly1305`

### AES-256-GCM gives three things

1. **Confidentiality**
   Attackers cannot read the plaintext.

2. **Integrity**
   Attackers cannot change the message silently.

3. **Authentication**
   The auth tag proves the encrypted record was not tampered with.

### Inputs and outputs

Inputs:

- symmetric key
- IV or nonce
- plaintext
- AAD (additional authenticated data)

Outputs:

- ciphertext
- authentication tag

### Why it is fast

Modern CPUs often have hardware acceleration like `AES-NI`.
So TLS encryption overhead is usually small on modern systems.

### ChaCha20-Poly1305

This is a great alternative on devices where AES hardware acceleration is weak or missing, such as many phones and ARM systems.

---

## TLS Record Protocol

TLS does not send one giant encrypted stream with no structure.
It breaks data into **records**.

Each TLS record contains:

- a small header
- encrypted payload
- authentication tag

### Record header has things like

- content type
- version
- length

Content type examples:

- `20` = ChangeCipherSpec
- `21` = Alert
- `22` = Handshake
- `23` = Application Data

### Why records matter

- they frame the encrypted data
- they limit chunk size
- receiver can decrypt record by record
- large responses can start being processed before the full response arrives

### Overhead

Each record adds some extra bytes for header and auth tag.
For small payloads, overhead is more noticeable.
For large payloads, overhead is tiny.

---

## mTLS - Mutual TLS

Normal TLS is usually **one-way authentication**:

- client verifies server

`mTLS` is **two-way authentication**:

- client verifies server
- server also verifies client

### Where it is used

Mostly in:

- microservices
- internal service-to-service calls
- zero-trust networks

### How it works

During handshake, the server asks the client for a certificate.

Then the client sends:

- its certificate
- proof that it owns the private key

The server checks:

- client certificate signed by trusted internal CA
- certificate not expired or revoked
- identity matches expected client service

### Example

If `order-service` calls `payment-service`, mTLS helps `payment-service` verify that the caller is really `order-service`.

### Service mesh

Tools like `Istio` and `Linkerd` often automate this.

They use sidecars such as `Envoy` to handle:

- certificate provisioning
- rotation
- verification
- encryption

So the application itself may still speak plain HTTP locally while the sidecars handle mTLS on the network.

---

## Session Resumption

A full TLS handshake costs time.
If the same client reconnects, TLS can often avoid doing all the expensive work again.

### TLS 1.2

The server can send a **session ticket**.
Later, the client sends it back.
The server restores session state and skips much of the full handshake.

### TLS 1.3

The server can send a ticket that enables `PSK`-based resumption.
This can support:

- fast 1-RTT resumed handshakes
- sometimes 0-RTT early data

### Why it matters

Resumption reduces:

- latency
- CPU cost

This is one reason connection reuse and keep-alive are so important in high-performance systems.

### Connection pooling + resumption

If the client keeps a pool of live TLS connections:

- no new TCP handshake
- no new TLS handshake
- request can be sent immediately

This is much faster than opening a brand-new secure connection every time.

---

## Easy Interview Summary

- TLS is the security layer under HTTPS.
- It authenticates the server, creates shared keys, and encrypts HTTP traffic.
- TLS 1.2 usually needs `2 RTT` for handshake.
- TLS 1.3 usually needs `1 RTT` because key share is sent early.
- Certificate chain is `leaf -> intermediate -> root`.
- `ECDHE` creates a shared secret and gives forward secrecy.
- Actual data encryption uses fast symmetric ciphers like `AES-256-GCM` or `ChaCha20-Poly1305`.
- TLS sends encrypted data in records.
- `mTLS` means both client and server authenticate each other.
- Session resumption avoids repeating full handshakes.
- `0-RTT` is fast but risky for non-idempotent requests.

---

## 30-Second Revision Box

```text
TLS protects HTTPS traffic.
TLS 1.2 handshake: usually 2 RTT.
TLS 1.3 handshake: usually 1 RTT.
0-RTT: fastest reconnect, but replay risk exists.
Certificate chain: server cert -> intermediate -> trusted root.
ECDHE: shared secret + forward secrecy.
Bulk encryption: AES-256-GCM or ChaCha20-Poly1305.
TLS record: header + encrypted payload + auth tag.
mTLS: both sides prove identity.
Resumption: faster reconnect using ticket or PSK.
```

---

**Prev: [[09_Internals-HTTP-Protocol-Deep-Dive]] | Next: [[11_Internals-REST-HTTP-Caching-Mechanics]]**
