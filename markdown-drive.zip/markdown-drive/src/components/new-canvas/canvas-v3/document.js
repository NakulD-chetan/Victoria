export const TEACHING_DOCUMENT_VERSION = 3;
export const LESSON_FRAME_WIDTH = 1280;
export const LESSON_FRAME_HEIGHT = 720;
export const LESSON_FRAME_GAP = 240;

function createId(prefix = 'v3') {
  const random = Math.random().toString(36).slice(2, 9);
  return `${prefix}_${Date.now().toString(36)}_${random}`;
}

export function createEmptyTeachingDocumentV3() {
  return {
    version: TEACHING_DOCUMENT_VERSION,
    elements: [],
    files: {},
    appState: {
      scrollX: 0,
      scrollY: 0,
      zoom: { value: 1 },
      viewBackgroundColor: '#f7f5ef',
    },
    lessonDeck: {
      frames: [],
      currentFrameId: null,
    },
    semanticGraph: {
      nodes: [],
      edges: [],
    },
    portals: [],
    playback: {
      status: 'idle',
      storyboardId: null,
      currentBeat: -1,
      totalBeats: 0,
      activeFrameId: null,
      reducedMotion: false,
    },
    agentRuns: [],
    updatedAt: Date.now(),
  };
}

function normalizeFrame(frame, index) {
  const x = Number(frame?.bounds?.x);
  const y = Number(frame?.bounds?.y);
  return {
    id: frame?.id || createId('lesson-frame'),
    frameElementId: frame?.frameElementId || null,
    topic: frame?.topic || 'general',
    title: frame?.title || `Lesson ${index + 1}`,
    order: Number.isFinite(frame?.order) ? frame.order : index,
    previousFrameId: frame?.previousFrameId || null,
    bounds: {
      x: Number.isFinite(x) ? x : index * (LESSON_FRAME_WIDTH + LESSON_FRAME_GAP),
      y: Number.isFinite(y) ? y : 0,
      width: LESSON_FRAME_WIDTH,
      height: LESSON_FRAME_HEIGHT,
    },
    semanticNodeIds: Array.isArray(frame?.semanticNodeIds) ? frame.semanticNodeIds : [],
    createdAt: Number(frame?.createdAt) || Date.now(),
    updatedAt: Number(frame?.updatedAt) || Date.now(),
  };
}

export function normalizeTeachingDocumentV3(raw) {
  const empty = createEmptyTeachingDocumentV3();
  if (!raw || typeof raw !== 'object') return empty;

  const frames = (Array.isArray(raw.lessonDeck?.frames) ? raw.lessonDeck.frames : [])
    .map(normalizeFrame)
    .sort((a, b) => a.order - b.order);
  const currentFrameId = frames.some((frame) => frame.id === raw.lessonDeck?.currentFrameId)
    ? raw.lessonDeck.currentFrameId
    : frames.at(-1)?.id || null;

  return {
    ...empty,
    ...raw,
    version: TEACHING_DOCUMENT_VERSION,
    elements: Array.isArray(raw.elements) ? raw.elements : [],
    files: raw.files && typeof raw.files === 'object' ? raw.files : {},
    appState: {
      ...empty.appState,
      ...(raw.appState || {}),
      zoom: {
        value: Math.max(0.1, Number(raw.appState?.zoom?.value) || 1),
      },
    },
    lessonDeck: {
      frames,
      currentFrameId,
    },
    semanticGraph: {
      nodes: Array.isArray(raw.semanticGraph?.nodes) ? raw.semanticGraph.nodes : [],
      edges: Array.isArray(raw.semanticGraph?.edges) ? raw.semanticGraph.edges : [],
    },
    portals: Array.isArray(raw.portals) ? raw.portals : [],
    playback: {
      ...empty.playback,
      ...(raw.playback || {}),
    },
    agentRuns: Array.isArray(raw.agentRuns) ? raw.agentRuns : [],
    updatedAt: Number(raw.updatedAt) || Date.now(),
  };
}

export function nextLessonFrame(document, { topic, title }) {
  const frames = document.lessonDeck.frames || [];
  const previous = frames.at(-1) || null;
  const order = previous ? previous.order + 1 : 0;
  const id = createId('lesson-frame');
  return {
    id,
    frameElementId: createId('frame'),
    topic: topic || 'general',
    title: title || `Lesson ${order + 1}`,
    order,
    previousFrameId: previous?.id || null,
    bounds: {
      x: previous
        ? previous.bounds.x + LESSON_FRAME_WIDTH + LESSON_FRAME_GAP
        : 0,
      y: previous?.bounds.y || 0,
      width: LESSON_FRAME_WIDTH,
      height: LESSON_FRAME_HEIGHT,
    },
    semanticNodeIds: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

export function currentLessonFrame(document) {
  const id = document.lessonDeck?.currentFrameId;
  return document.lessonDeck?.frames?.find((frame) => frame.id === id)
    || document.lessonDeck?.frames?.at(-1)
    || null;
}

export function persistableAppState(appState) {
  return {
    scrollX: Number(appState?.scrollX) || 0,
    scrollY: Number(appState?.scrollY) || 0,
    zoom: {
      value: Math.max(0.1, Number(appState?.zoom?.value) || 1),
    },
    viewBackgroundColor: appState?.viewBackgroundColor || '#f7f5ef',
    theme: appState?.theme || 'light',
  };
}

