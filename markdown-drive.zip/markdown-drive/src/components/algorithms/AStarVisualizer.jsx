import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: a-star */
const ROWS = 5;
const COLS = 5;
const WALL = new Set(['1,2', '2,2', '3,1', '3,3']);
const START = '0,0';
const GOAL = '4,4';
const DIRS = [[1, 0], [-1, 0], [0, 1], [0, -1]];

function manhattan(a, b) {
  const [ar, ac] = a.split(',').map(Number);
  const [br, bc] = b.split(',').map(Number);
  return Math.abs(ar - br) + Math.abs(ac - bc);
}

function buildGraph() {
  const nodes = [];
  for (let r = 0; r < ROWS; r += 1) {
    for (let c = 0; c < COLS; c += 1) {
      const id = `${r},${c}`;
      if (WALL.has(id)) continue;
      nodes.push({ id, x: 48 + c * 52, y: 48 + r * 52, label: id });
    }
  }
  const edges = [];
  nodes.forEach((n) => {
    const [r, c] = n.id.split(',').map(Number);
    DIRS.forEach(([dr, dc]) => {
      const nr = r + dr;
      const nc = c + dc;
      const nid = `${nr},${nc}`;
      if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return;
      if (WALL.has(nid)) return;
      edges.push({ from: n.id, to: nid, weight: 1, directed: false });
    });
  });
  return { nodes, edges };
}

const GRAPH = buildGraph();

function generateSteps() {
  const open = new Map();
  const gScore = {};
  const fScore = {};
  const came = {};
  const closed = new Set();
  const steps = [];
  gScore[START] = 0;
  fScore[START] = manhattan(START, GOAL);
  open.set(START, fScore[START]);
  steps.push({
    type: 'init',
    nodeColors: { [START]: 'source', [GOAL]: 'found' },
    edgeColors: {},
    nodeLabels: { [START]: `f=${fScore[START]} g=0 h=${manhattan(START, GOAL)}` },
  });
  while (open.size) {
    let current = null;
    let bestF = Infinity;
    open.forEach((f, id) => {
      if (f < bestF) {
        bestF = f;
        current = id;
      }
    });
    if (current == null) break;
    open.delete(current);
    closed.add(current);
    steps.push({
      type: 'expand',
      nodeColors: { [current]: 'current', [GOAL]: 'found' },
      edgeColors: {},
      nodeLabels: {
        [current]: `f=${fScore[current]} g=${gScore[current]} h=${manhattan(current, GOAL)}`,
      },
    });
    if (current === GOAL) {
      const path = [];
      let x = GOAL;
      while (x) {
        path.unshift(x);
        x = came[x];
      }
      steps.push({ type: 'path', nodeColors: Object.fromEntries(path.map((id) => [id, 'visited'])), edgeColors: {}, path });
      break;
    }
    const [r, c] = current.split(',').map(Number);
    DIRS.forEach(([dr, dc]) => {
      const nr = r + dr;
      const nc = c + dc;
      if (nr < 0 || nr >= ROWS || nc < 0 || nc >= COLS) return;
      const nid = `${nr},${nc}`;
      if (WALL.has(nid)) return;
      if (closed.has(nid)) return;
      const tg = (gScore[current] || 0) + 1;
      if (gScore[nid] == null || tg < gScore[nid]) {
        came[nid] = current;
        gScore[nid] = tg;
        fScore[nid] = tg + manhattan(nid, GOAL);
        open.set(nid, fScore[nid]);
        steps.push({
          type: 'relax',
          nodeColors: { [current]: 'processing', [nid]: 'processing', [GOAL]: 'found' },
          edgeColors: { [`${current}-${nid}`]: 'highlight', [`${nid}-${current}`]: 'highlight' },
          nodeLabels: { [nid]: `f=${fScore[nid]} g=${gScore[nid]} h=${manhattan(nid, GOAL)}` },
        });
      }
    });
  }
  steps.push({ type: 'done', nodeColors: {}, edgeColors: {} });
  return steps;
}

export default function AStarVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'A* on grid (Manhattan h)' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { [START]: 'source', [GOAL]: 'found' },
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'relax') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: [],
      stack: [],
      distances: {},
      visited: step.path || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
