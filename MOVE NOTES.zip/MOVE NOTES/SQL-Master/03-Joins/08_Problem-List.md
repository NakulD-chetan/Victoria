# Joins — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Joins = most-asked SQL topic at FAANG.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Combine Two Tables | Easy | 175 | LEFT JOIN | Purest optional-join problem — foundation |
| 2 | Employees Earning More Than Their Managers | Easy | 181 | Self-join | Classic same-table comparison |
| 3 | Customers Who Never Order | Easy | 183 | Anti-join (LEFT) | Most-asked anti-join pattern |
| 4 | Rising Temperature | Easy | 197 | Self-join + date | Date arithmetic in join |
| 5 | Employee Bonus | Easy | 577 | LEFT JOIN + NULL | Optional join + NULL filter |
| 6 | Students and Examinations | Easy | 1280 | CROSS JOIN + LEFT JOIN | Generate all combos then count |
| 7 | Managers with at Least 5 Direct Reports | Medium | 570 | Self-join + HAVING | Count children per parent |
| 8 | Confirmation Rate | Medium | 1934 | LEFT JOIN + conditional agg | Join + AVG(CASE) |
| 9 | Product Sales Analysis III | Medium | 1070 | JOIN + first-year logic | Multi-table + filter on aggregate |
| 10 | Restaurant Growth | Medium | 1321 | Self-join / window | Moving average via join |

---

## Complete 30-Problem Progression

### Easy (Problems 1-10) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Combine Two Tables | 175 | LEFT JOIN | Person + Address, optional |
| 2 | Employees Earning More Than Managers | 181 | Self-join | e.salary > m.salary |
| 3 | Customers Who Never Order | 183 | Anti-join | LEFT JOIN … IS NULL |
| 4 | Rising Temperature | 197 | Self-join + DATEDIFF | Compare consecutive dates |
| 5 | Employee Bonus | 577 | LEFT JOIN + NULL | bonus IS NULL OR < 1000 |
| 6 | Customer Visited No Transaction | 1581 | LEFT JOIN + COUNT | Anti-pattern with aggregation |
| 7 | Replace Employee ID With Unique Identifier | 1378 | LEFT JOIN | Simple optional lookup |
| 8 | Students and Examinations | 1280 | CROSS + LEFT JOIN | Generate grid, fill counts |
| 9 | Managers with ≥ 5 Direct Reports | 570 | Self-join + GROUP | Count where managerId = id |
| 10 | Average Time of Process per Machine | 1661 | Self-join | Start vs end event pairing |

### Medium (Problems 11-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Confirmation Rate | 1934 | LEFT JOIN + cond agg | AVG(CASE WHEN) after join |
| 12 | Product Sales Analysis I | 1068 | INNER JOIN | Pick correct columns |
| 13 | Product Sales Analysis III | 1070 | JOIN + MIN year | First year of sale per product |
| 14 | Monthly Transactions I | 1193 | JOIN + GROUP + CASE | Multi-agg with conditions |
| 15 | Percentage of Users Attended a Contest | 1633 | CROSS concept + COUNT | Ratio from join |
| 16 | Investments in 2016 | 585 | Self-join for matching | HAVING COUNT logic |
| 17 | Friend Requests II: Who Has Most Friends | 602 | UNION + GROUP | Symmetric relationship |
| 18 | Restaurant Growth | 1321 | Self-join / window | 7-day moving sum with dates |
| 19 | Exchange Seats | 626 | Self-join or CASE | Swap adjacent rows |
| 20 | Market Analysis I | 1158 | LEFT JOIN + COUNT | Buyer activity in year |
| 21 | Trips and Users | 262 | Multi-join + WHERE | Cancel rate with role filter |
| 22 | Last Person to Fit in the Bus | 1204 | Self-join running sum | Cumulative weight ≤ 1000 |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Consecutive Numbers | 180 | Self-join 3× | Same value three rows in a row |
| 24 | Department Top Three Salaries | 185 | JOIN + dense rank | Top N per group with join |
| 25 | Human Traffic of Stadium | 601 | Self-join 3× consecutive | 3 consecutive rows ≥ 100 |
| 26 | Second Highest Salary | 176 | Self-join / OFFSET | Handle NULL if none |
| 27 | Nth Highest Salary | 177 | Function + OFFSET | Generalized Nth |
| 28 | Rank Scores | 178 | Dense rank via self-join | Ranking without window (classic) |
| 29 | Department Highest Salary | 184 | JOIN + subquery | Max salary per dept |
| 30 | Tree Node | 608-tree | Self-join | Root / Inner / Leaf classification |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Combine Two Tables (LC 175)
```
Type: LEFT JOIN
Key: Person LEFT JOIN Address ON personId — some people have no address
One-liner: LEFT preserves all people; NULL for missing address.
```

### Problem 3: Customers Who Never Order (LC 183)
```
Type: Anti-join
Approach 1: LEFT JOIN orders WHERE orders.id IS NULL
Approach 2: NOT IN (SELECT customerId FROM Orders)
One-liner: "Find missing" = anti-join pattern. Foundation for all exclusion problems.
```

### Problem 4: Rising Temperature (LC 197)
```
Type: Self-join + date
Key: JOIN Weather w2 ON DATEDIFF(w1.recordDate, w2.recordDate) = 1
     WHERE w1.temperature > w2.temperature
One-liner: Compare each day to its previous day via self-join on date diff.
```

### Problem 8: Students and Examinations (LC 1280)
```
Type: CROSS JOIN + LEFT JOIN
Key: CROSS JOIN to get all (student, subject) combos, LEFT JOIN exams to count
One-liner: Generate complete grid first, then fill — pattern for "include zeros."
```

### Problem 23: Consecutive Numbers (LC 180)
```
Type: Triple self-join
Key: l1.num = l2.num = l3.num AND l2.id = l1.id+1 AND l3.id = l2.id+1
One-liner: Three consecutive same values — self-join 3x or LAG approach.
```

### Problem 24: Department Top Three Salaries (LC 185)
```
Type: JOIN + ranking
Key: Count distinct higher salaries < 3 (or DENSE_RANK window)
One-liner: "Top N per group" — either subquery-count or window rank.
```

---

## Pattern Distribution

```
LEFT JOIN (optional):     8 problems  (1, 5, 7, 8, 11, 16, 20, 30)
ANTI-JOIN (missing):      4 problems  (3, 6, 20, 21)
SELF-JOIN:               10 problems  (2, 4, 9, 10, 16, 18, 22-25)
CROSS JOIN:               2 problems  (8, 15)
MULTI-TABLE JOIN:         4 problems  (12, 13, 14, 21)
JOIN + SUBQUERY:          2 problems  (24, 29)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-3 (LEFT JOIN, self-join, anti-join)
- Day 2: Problems 4-6 (date self-join, NULL filter, anti+count)
- Day 3: Problems 7-10 (CROSS JOIN, manager count, event pairing)

### Week 2: Core (Days 4-7)
- Day 4: Problems 11-13 (conditional agg after join, product analysis)
- Day 5: Problems 14-17 (multi-agg, symmetric relations)
- Day 6: Problems 18-20 (moving avg, swap, market analysis)
- Day 7: Problems 21-22 (Trips cancel rate, running sum)

### Week 3: Hard (Days 8-10)
- Day 8: Problems 23-25 (consecutive, top-N, stadium)
- Day 9: Problems 26-28 (Nth highest, ranking via join)
- Day 10: Problems 29-30 (dept max, tree node classification)

---

## Cross-Reference: Joins vs Windows

| Problem | Primary Pattern | Why |
|---------|----------------|------|
| Restaurant Growth (LC 1321) | Join OR window | Moving avg — window cleaner but join is classic |
| Rank Scores (LC 178) | Self-join OR window | DENSE_RANK easier but self-join tests fundamentals |
| Dept Top 3 (LC 185) | Join + subquery OR window | Window is modern; correlated count is old-school |
| Consecutive Numbers (LC 180) | Self-join OR LAG | LAG simpler; self-join tests join depth |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (10 Easy, 12 Medium, 8 Hard)
MUST-DO:            LC 175, 181, 183, 197, 577, 1280, 570, 1934, 1070, 1321
TOP 3 MOST ASKED:   LC 183 (Never Order), LC 181 (Manager Salary), LC 197 (Rising Temp)
PATTERN SPLIT:      LEFT (8), Anti (4), Self (10), Cross (2), Multi (4), Sub+Join (2)
STUDY ORDER:        LEFT JOIN → Anti-Join → Self-Join → CROSS → Multi-table
INTERVIEW LINE:     "I choose LEFT for optional relations, self-join for
                     row comparison, and always check NULL key behavior."
```

---

## 30-SECOND REVISION BOX

```
ANTI-JOIN:      LC 183 — LEFT JOIN … WHERE IS NULL (or NOT EXISTS)
SELF-JOIN:      LC 181, 197 — same table aliased twice
CROSS + LEFT:   LC 1280 — generate all combos, then count matches
CONSECUTIVE:    LC 180 — triple self-join or LAG
TOP-N PER GRP:  LC 185 — DENSE_RANK window or correlated count
```
