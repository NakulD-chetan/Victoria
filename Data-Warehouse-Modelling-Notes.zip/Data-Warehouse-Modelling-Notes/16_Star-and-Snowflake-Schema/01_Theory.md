# Star and Snowflake Schema

> "The star is the analyst’s map; the snowflake is the modeler’s compromise when hierarchies refuse to stay flat."

**Real-world analogy:** A star schema is like a store manager’s one-page daily dashboard: sales, inventory, and labor each connect to the same recognizable boxes for store, product, and date. A snowflake schema is like the back-room filing system where category binders sit on separate shelves linked by cross-references—tidier storage, more steps to pull a complete story.

---

## Core Idea (2 Lines)

A **star schema** centers a fact table on foreign keys to denormalized dimension tables so typical retail queries need few joins and predictable performance. A **snowflake schema** normalizes one or more dimensions into parent tables, reducing redundancy at the cost of extra joins and more intricate ETL and query patterns.

---

## Star Schema: Definition and Structure

In a star, each dimension is generally **one wide table** at a single grain, and the fact holds **only keys and numeric measures**.

| Element | Role | Retail example |
|---------|------|----------------|
| Fact | Events / transactions at chosen grain | `fact_store_sales` at line-item grain |
| Dimensions | Descriptive context | `dim_store`, `dim_product`, `dim_date` |
| Keys | Integer surrogates for fast joins | `store_key`, `product_key`, `sale_date_key` |

ASCII star:

```
                        dim_date
                           |
                           |
dim_promotion ---- fact_store_sales ---- dim_store
                           |
                           |
                      dim_product
```

Characteristics:

| Characteristic | Implication |
|----------------|-------------|
| Denormalized dimensions | Repeated higher-level attributes (e.g., category on every SKU) |
| Single-hop joins | Fact to each dimension in one join |
| BI-friendly | Simple parent-child hierarchies in metadata |

**Interview Tip:** Star is the default recommendation in Kimball-style warehouses for query performance and self-service clarity.

**Watch Out!** Confusing “star schema” with “only five tables”—large warehouses have many facts sharing conformed dimensions (constellation / galaxy).

---

## Snowflake Schema: Definition and Structure

Snowflaking **splits a dimension** into normalized tables, usually along a hierarchy (region → district → store) or shared lookup (brand table reused by many SKUs).

ASCII snowflake:

```
dim_region
     |
     v
dim_district
     |
     v
 dim_store ---- fact_store_sales ---- dim_date
                        |
                        |
                   dim_product
                        |
                        v
                 dim_brand (shared)
```

| Element | Change vs star |
|---------|----------------|
| `dim_store` | Holds `district_key` instead of repeating district/region columns |
| Extra joins | Fact → store → district → region for some queries |
| Storage | Less repeated text for region names |

**Watch Out!** Accidental many-to-many paths without enforcing cardinality produce inflated aggregations.

---

## Pros and Cons

| Aspect | Star | Snowflake |
|--------|------|-----------|
| Query simplicity | High | Lower |
| Typical join count | Lower | Higher |
| Redundancy | Higher in dimensions | Lower in dimensions |
| ETL complexity | Straightforward wide loads | Split staging and key lookups |
| Hierarchy updates | May touch many SKU rows | May touch fewer parent rows |
| Columnstore scan | Wide but single table | Narrow tables; more joins |

**Interview Tip:** Mention that modern columnstores mitigate some star width costs, but snowflake join fan-out still matters on huge facts.

---

## Comparison Table

| Criterion | Star | Snowflake |
|-----------|------|-----------|
| Design | Fact + denormalized dimensions | Fact + normalized dimension branches |
| Joins | Fewer, shorter paths | More hops along chains |
| Speed | Often faster for ad hoc retail BI | Depends; can be slower |
| Redundancy | More repeated attributes | Less repetition |
| Normalization | Intentionally denormalized | More normalized branches |

---

## When to Use Each

| Use star when | Use snowflake when |
|---------------|---------------------|
| Business users query directly | Shared hierarchy masters change often |
| Performance is primary | Storage / update anomalies dominate |
| Dimensions are moderately wide | Very large text attributes repeat massively |
| Team maturity favors simplicity | Strong governance on hierarchy tables |

Retail hybrid pattern: keep `dim_product` wide for daily merchandising dashboards, snowflake only `dim_geography` if regions are complex shared entities.

**Watch Out!** Snowflaking for theoretical purity alone often disappoints store operations teams who live in wide, flat extracts.

---

## Galaxy Schema (Constellation)

Multiple facts share conformed dimensions:

```
 fact_store_sales --------\
                           +---- dim_store ---- dim_date
 fact_inventory_snapshot --/

 fact_ecom_sales ----------/
```

This is not a different “join shape” per fact row; it is an enterprise pattern for integrated retail analytics across channels.

**Interview Tip:** Galaxy = conformed dimensions + multiple facts; still star-like at each fact’s local neighborhood.

---

## SQL Join Examples: Star

```sql
SELECT
    s.store_name,
    p.category,
    d.calendar_date,
    SUM(f.net_sales_amount) AS net_sales
FROM fact_store_sales AS f
JOIN dim_store   AS s ON f.store_key   = s.store_key
JOIN dim_product AS p ON f.product_key = p.product_key
JOIN dim_date    AS d ON f.sale_date_key = d.date_key
WHERE d.calendar_date >= '2025-10-01'
GROUP BY
    s.store_name,
    p.category,
    d.calendar_date;
```

---

## SQL Join Examples: Snowflake

```sql
SELECT
    r.region_name,
    SUM(f.net_sales_amount) AS net_sales
FROM fact_store_sales AS f
JOIN dim_store     AS s ON f.store_key = s.store_key
JOIN dim_district  AS di ON s.district_key = di.district_key
JOIN dim_region    AS r ON di.region_key = r.region_key
JOIN dim_date      AS d ON f.sale_date_key = d.date_key
WHERE d.fiscal_year = 2025
GROUP BY
    r.region_name
ORDER BY
    net_sales DESC;
```

**Watch Out!** Forgetting to join through the correct hierarchy chain can attach the wrong region if `district_key` is nullable or stale.

---

## One-Line Interview Answer

> “A star schema keeps dimensions wide and facts narrow for fast retail analytics; a snowflake normalizes heavy hierarchies to reduce redundancy, trading joins for maintenance benefits.”

---

## Physical Design Notes (Retail Scale)

| Topic | Guidance |
|-------|----------|
| Partitioning | Partition large facts by `sale_date_key` month |
| Distribution | Co-locate fact and largest dimension keys if MPP |
| Indexes | Cluster on date + store for common slicers |
| Aggregates | Precompute district-week for executive KPIs |

```sql
-- Optional rolling weekly aggregate (star neighborhood)
CREATE TABLE agg_store_week_sales (
    store_key      INT NOT NULL,
    retail_year    SMALLINT NOT NULL,
    retail_week    TINYINT NOT NULL,
    net_sales      DECIMAL(14,2) NOT NULL,
    PRIMARY KEY (store_key, retail_year, retail_week)
);
```

**Interview Tip:** Aggregate tables are adjuncts to the star—they do not change the logical star model.

---

## Decision Flow (ASCII)

```
                Need shared hierarchy master?
                        |
           NO ----------+-------- YES
           |                        |
      Prefer STAR              Still wide enough?
      (default)                       |
                         NO ----------+-------- YES
                         |                      |
                   SNOWFLAKE branch      STAR + outrigger
                   on heavy parts        (light satellite)
```

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Snowflaking dimensions users always filter together | Extra joins every query | Collapse hot attributes back to star |
| Calling any multi-table model a snowflake | Confuses hub-and-spoke staging with dimensional snowflake | Reserve term for normalized **dimensions** around facts |
| Ignoring conformed keys in galaxy | Incomparable channel metrics | Align `dim_store`, `dim_product`, `dim_date` |
| Deep snowflake without surrogate keys | Join explosions | Surrogate keys at each normalized level |
| Star with dozens of unused outriggers | Complexity without benefit | Prune unused tables from published layer |

---

## Key Takeaway

> Default to a star for retail facts and conformed dimensions; introduce snowflake branches only where normalization delivers clear hierarchy integrity or storage wins that justify extra joins and modeling care.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) Star = fact hub + wide single-table dimensions.             |
| 2) Snowflake = normalized dimension chains off the star.       |
| 3) Star: fewer joins, simpler BI; more repeated attributes.    |
| 4) Snowflake: less redundancy; more join paths to manage.      |
| 5) Galaxy = many facts sharing conformed dimensions.           |
| 6) Hybrid retail models are common and pragmatic.              |
| 7) Interview: star for speed/simplicity; flake for hierarchy.  |
+------------------------------------------------------------------+
```
