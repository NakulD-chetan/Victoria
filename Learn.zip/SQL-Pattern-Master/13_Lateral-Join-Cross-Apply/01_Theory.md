# LATERAL JOIN / CROSS APPLY

A **LATERAL JOIN** allows a subquery in the `FROM` clause to use columns from the table before it, meaning the subquery is executed **once for each row of the left table**.

**DSA Analogy**: Calling a function per element — like `array.map(fn)` where `fn` receives each element and returns a computed result. The function can use the current element's value to determine its output.

---

## Core Idea (2 Lines)

A regular subquery in FROM is independent — it runs once and produces a fixed result. A **LATERAL** subquery sees the current row from the outer table and can use its columns, producing a different result for each outer row. This makes it a correlated subquery that behaves like a join.  
  
Corelatd Query inside form phase ,lateral join can reutnr multipl vaues

---

## Syntax

```sql
-- PostgreSQL: LATERAL keyword
SELECT o.*, t.*
FROM orders o
CROSS JOIN LATERAL (
    SELECT product_id, amount
    FROM order_items oi
    WHERE oi.order_id = o.id         -- references outer table!
    ORDER BY amount DESC
    LIMIT 3
) t;

-- SQL Server: CROSS APPLY / OUTER APPLY
SELECT o.*, t.*
FROM orders o
CROSS APPLY (
    SELECT TOP 3 product_id, amount
    FROM order_items oi
    WHERE oi.order_id = o.id
    ORDER BY amount DESC
) t;
```

### CROSS JOIN LATERAL vs LEFT JOIN LATERAL

both will do same 

Run a subquery for each row of the left table”  
but  
Behavior

> Only keeps rows where the subquery returns something.


| Type                            | Behavior                                               | SQL Server Equivalent |
| ------------------------------- | ------------------------------------------------------ | --------------------- |
| `CROSS JOIN LATERAL`            | Only keeps outer rows where subquery returns rows      | `CROSS APPLY`         |
| `LEFT JOIN LATERAL ... ON TRUE` | Keeps ALL outer rows; NULL if subquery returns nothing | `OUTER APPLY`         |


```sql
-- LEFT JOIN LATERAL: keep customers even if they have no orders
SELECT c.name, recent.*
FROM customers c
LEFT JOIN LATERAL (
    SELECT order_date, amount
    FROM orders o
    WHERE o.customer_id = c.id
    ORDER BY order_date DESC
    LIMIT 1
) recent ON TRUE;           -- ON TRUE is required syntax for LEFT JOIN LATERAL
```

---

## Why LATERAL Exists (The Problem It Solves)

**Without LATERAL — this is INVALID:**

```sql
-- ERROR: subquery in FROM can't reference outer table
SELECT *
FROM orders o,
     (SELECT * FROM items WHERE items.order_id = o.id LIMIT 3) t;
     --                                            ^ INVALID reference
```

**With LATERAL — this works:**

```sql
SELECT *
FROM orders o
CROSS JOIN LATERAL (
    SELECT * FROM items WHERE items.order_id = o.id LIMIT 3
) t;
```

---

## The 4 Key Use Cases

### Use Case 1: Top-N Per Group (Best Alternative)

```sql
-- Top 3 orders per customer (cleaner than ROW_NUMBER)
SELECT c.name, top_orders.*
FROM customers c
CROSS JOIN LATERAL (
    SELECT order_date, amount
    FROM orders o
    WHERE o.customer_id = c.id
    ORDER BY amount DESC
    LIMIT 3
) top_orders;
```

**LATERAL vs ROW_NUMBER for Top-N:**


| Feature     | LATERAL / APPLY                       | ROW_NUMBER + CTE            |
| ----------- | ------------------------------------- | --------------------------- |
| Readability | More intuitive                        | More verbose                |
| Performance | Index on join col → very fast         | Full table scan + sort      |
| Flexibility | LIMIT can be dynamic per row          | N is fixed in WHERE rn <= N |
| Portability | PostgreSQL, MySQL 8.0.14+, SQL Server | All databases               |


### Use Case 2: Unnest / Expand Arrays or JSON

```sql
-- PostgreSQL: expand JSON array into rows
SELECT o.id, item.*
FROM orders o
CROSS JOIN LATERAL jsonb_array_elements(o.items) AS item;

-- PostgreSQL: unnest array column
SELECT u.name, skill
FROM users u
CROSS JOIN LATERAL unnest(u.skills) AS skill;
```

### Use Case 3: Dependent Subquery with LIMIT

```sql
-- Most recent login per user (faster than ROW_NUMBER if indexed)
SELECT u.name, last_login.*
FROM users u
LEFT JOIN LATERAL (
    SELECT login_date, ip_address
    FROM logins l
    WHERE l.user_id = u.id
    ORDER BY login_date DESC
    LIMIT 1
) last_login ON TRUE;
```

### Use Case 4: Table-Valued Functions

```sql
-- Call a function for each row
SELECT e.name, salary_band.*
FROM employees e
CROSS JOIN LATERAL get_salary_band(e.salary) AS salary_band;

-- Generate series per row
SELECT p.name, month.m
FROM projects p
CROSS JOIN LATERAL generate_series(p.start_date, p.end_date, '1 month') AS month(m);
```

---

## How LATERAL Executes (Mental Model)

```
Without LATERAL:                    With LATERAL:
  Subquery runs ONCE               Subquery runs ONCE PER ROW
  Result is fixed                  Result depends on current row

  ┌──────────┐  ┌──────────┐       ┌──────────┐
  │ Outer    │  │ Subquery │       │ Outer    │  For row 1: run subquery(row1)
  │ Table    │  │ (fixed)  │       │ Table    │  For row 2: run subquery(row2)
  │          │  │          │       │          │  For row 3: run subquery(row3)
  └──────────┘  └──────────┘       └──────────┘
       CROSS JOIN                       CROSS JOIN LATERAL
```

**Performance**: Sounds like O(N × subquery), but with proper indexes, the database can use an index lookup for each outer row → effectively O(N × log M) instead of O(N × M).

---

## LATERAL vs Correlated Subquery

```sql
-- Correlated subquery (scalar — one value only):
SELECT c.name,
       (SELECT MAX(amount) FROM orders WHERE customer_id = c.id) AS max_order
FROM customers c;

-- LATERAL (can return multiple rows AND columns):
SELECT c.name, top.*
FROM customers c
CROSS JOIN LATERAL (
    SELECT order_date, amount
    FROM orders WHERE customer_id = c.id
    ORDER BY amount DESC
    LIMIT 3
) top;
```


| Feature       | Correlated Subquery | LATERAL JOIN                     |
| ------------- | ------------------- | -------------------------------- |
| Returns       | Single scalar value | Multiple rows and columns        |
| Used in       | SELECT, WHERE       | FROM (as a table)                |
| LIMIT support | Not useful (scalar) | Yes — LIMIT per row              |
| Joins further | No                  | Yes — can join with other tables |


---

## Database Support


| Database        | LATERAL                                    | APPLY                         |
| --------------- | ------------------------------------------ | ----------------------------- |
| PostgreSQL 9.3+ | `CROSS JOIN LATERAL` / `LEFT JOIN LATERAL` | Not supported                 |
| MySQL 8.0.14+   | `LATERAL` keyword                          | Not supported                 |
| SQL Server      | Not supported                              | `CROSS APPLY` / `OUTER APPLY` |
| Oracle 12c+     | `CROSS APPLY` / `OUTER APPLY`              | Also supports LATERAL         |
| BigQuery        | `CROSS JOIN UNNEST(...)`                   | Similar functionality         |


---

## Common Mistakes


| Mistake                                       | Why It Breaks                            | Fix                                         |
| --------------------------------------------- | ---------------------------------------- | ------------------------------------------- |
| Using LATERAL without `ON TRUE` for LEFT JOIN | Syntax error in PostgreSQL               | Add `ON TRUE` after LEFT JOIN LATERAL       |
| Forgetting LATERAL keyword                    | Subquery can't see outer columns         | Add LATERAL after CROSS JOIN or LEFT JOIN   |
| No index on correlated column                 | O(N × M) — very slow                     | Index the column used in WHERE              |
| CROSS APPLY dropping rows                     | Rows with no subquery match are excluded | Use OUTER APPLY / LEFT JOIN LATERAL         |
| Using when regular JOIN suffices              | Unnecessary complexity                   | Use regular JOIN for non-correlated queries |


---

## Key Takeaway

> LATERAL JOIN is a correlated subquery that sits in the FROM clause and can return multiple rows and columns. Use it for Top-N per group (with LIMIT), unnesting arrays/JSON, and calling table-valued functions per row. It's more readable than ROW_NUMBER for Top-N and more powerful than scalar correlated subqueries. Use LEFT JOIN LATERAL (OUTER APPLY) to keep outer rows with no matches.

