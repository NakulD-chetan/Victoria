# Distributed Systems — Question List

> **Permanent Recall:** Master the 10 MUST-DO distributed systems questions for FAANG interviews. The full list covers consensus, leader election, distributed locking, coordination, heartbeats, split brain, gossip, clock sync, and DHTs. Use this as a checklist—each question tests specific concepts from the Distributed-Systems notes.

---

## 10 MUST-DO Distributed Systems Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | What are the Eight Fallacies of Distributed Computing? | Easy | Fallacies, design assumptions |
| 2 | Explain Raft leader election. How does it prevent split brain? | Medium | Raft, quorum, split brain |
| 3 | Design a distributed lock. What is a fencing token and why is it needed? | Medium | Lock, fencing, ZooKeeper |
| 4 | What happens during a network partition in a Raft cluster? | Easy | Partition, quorum |
| 5 | Compare Paxos and Raft. When would you use each? | Medium | Consensus, practicality |
| 6 | How does ZooKeeper support leader election and distributed locks? | Medium | ZooKeeper, coordination |
| 7 | Explain gossip protocol. When is it appropriate vs consensus? | Medium | Gossip, consensus trade-off |
| 8 | What is the split brain problem? How do you prevent it? | Easy | Split brain, quorum |
| 9 | Design a heartbeat-based failure detection system | Medium | Heartbeat, timeout |
| 10 | How do Lamport timestamps and vector clocks differ? When to use each? | Medium | Clock sync, ordering |

---

## Complete Question List (25+)

### Consensus & Leader Election

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 11 | How does Raft achieve consensus? Explain log replication | Medium | General |
| 12 | Design a system with exactly one active job scheduler instance | Medium | FAANG |
| 13 | What is the FLP impossibility result? Practical implications? | Hard | General |
| 14 | Compare Raft, Paxos, and Zab | Medium | General |
| 15 | How does the bully algorithm work for leader election? | Easy | General |
| 16 | Why use odd number of nodes (3, 5) in a cluster? | Easy | General |

### Distributed Locking & Coordination

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 17 | How does Redis RedLock work? What are its limitations? | Medium | General |
| 18 | Design a distributed mutex for a critical section across microservices | Medium | FAANG |
| 19 | What use cases does ZooKeeper solve? | Easy | General |
| 20 | How would you implement service discovery in a distributed system? | Medium | General |
| 21 | Design a configuration management system for 1000+ nodes | Hard | FAANG |

### Clock, Ordering & Time

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 22 | Why can't we rely on wall clocks in distributed systems? | Easy | General |
| 23 | Explain Lamport timestamps with an example | Medium | General |
| 24 | When would you use vector clocks vs Lamport? | Medium | General |
| 25 | How does NTP work? What accuracy can we expect? | Easy | General |

### Failure Detection, Gossip & DHT

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 26 | Design a heartbeat mechanism. What parameters matter? | Medium | General |
| 27 | What is the split brain problem during leader election? | Easy | General |
| 28 | How does a gossip protocol disseminate information? Convergence time? | Medium | General |
| 29 | What is a Distributed Hash Table (DHT)? Examples? | Medium | General |
| 30 | How does Cassandra use gossip for cluster membership? | Medium | General |

### Edge Cases & Advanced

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 31 | What happens when a client holds a lock but is slow (GC pause)? | Medium | FAANG |
| 32 | How do you handle cascading timeouts in a distributed system? | Medium | General |
| 33 | Design for Byzantine failures vs crash failures | Hard | General |
| 34 | What are the CAP implications of your distributed lock design? | Medium | General |

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, definitions |
| **Medium** | Design choice, trade-offs, implementation |
| **Hard** | Deep dive, protocol details, edge cases |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **Consensus (Raft, Paxos)** | 2, 5, 11, 14 |
| **Leader election** | 2, 12, 15, 16 |
| **Distributed lock** | 3, 17, 18, 31 |
| **ZooKeeper** | 6, 19, 20 |
| **Split brain** | 2, 8, 27 |
| **Partition** | 4 |
| **Gossip** | 7, 28, 30 |
| **Clock / ordering** | 10, 22, 23, 24, 25 |
| **Heartbeat** | 9, 26 |
| **DHT** | 29 |
| **Edge cases** | 31, 32, 33 |
| **CAP** | 34 |

---

## Question Categories for Targeted Practice

| Category | Focus | Example Questions |
|----------|-------|-------------------|
| **Definitions** | Fallacies, concepts | 1, 8, 19, 22 |
| **Design** | End-to-end design | 3, 9, 12, 18, 21 |
| **Mechanisms** | How it works | 2, 7, 11, 17, 26 |
| **Compare** | Trade-offs | 5, 10, 14, 23 |
| **Edge cases** | Failures, partitions | 4, 31, 32, 33 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can explain Raft leader election and log replication
- [ ] Can explain fencing tokens for distributed locks
- [ ] Can explain split brain and quorum prevention
- [ ] Can compare Paxos vs Raft
- [ ] Can explain ZooKeeper use cases
- [ ] Can explain gossip vs consensus
- [ ] Can explain Lamport vs vector clocks
- [ ] Can design heartbeat failure detection
- [ ] Can handle partition and lock edge cases

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: Fallacies, Raft, Lock+fencing, Partition,
            Paxos vs Raft, ZK, Gossip, Split brain,
            Heartbeat, Lamport vs vector
FULL LIST: 34+ questions across consensus, lock, ZK,
           clock, gossip, edge cases
```

---

**Prev: [[07_Tricks-and-Recognition]]**
