import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: topological-sort */
const GRAPH = {
  nodes: [
    { id: 'A', x: 100, y: 120, label: 'A' },
    { id: 'B', x: 260, y: 80, label: 'B' },
    { id: 'C', x: 260, y: 180, label: 'C' },
    { id: 'D', x: 420, y: 80, label: 'D' },
    { id: 'E', x: 420, y: 180, label: 'E' },
    { id: 'F', x: 560, y: 130, label: 'F' },
  ],
  edges: [
    { from: 'A', to: 'B', directed: true },
    { from: 'A', to: 'C', directed: true },
    { from: 'B', to: 'D', directed: true },
    { from: 'C', to: 'D', directed: true },
    { from: 'C', to: 'E', directed: true },
    { from: 'D', to: 'F', directed: true },
    { from: 'E', to: 'F', directed: true },
  ],
};

function generateSteps() {
  const ids = GRAPH.nodes.map((n) => n.id);
  const indeg = Object.fromEntries(ids.map((id) => [id, 0]));
  const adj = Object.fromEntries(ids.map((id) => [id, []]));
  GRAPH.edges.forEach((e) => {
    indeg[e.to] += 1;
    adj[e.from].push(e.to);
  });
  const q = ids.filter((id) => indeg[id] === 0);
  const order = [];
  const steps = [];
  steps.push({ type: 'init', nodeColors: Object.fromEntries(q.map((id) => [id, 'processing'])), edgeColors: {}, queue: [...q] });
  while (q.length) {
    const u = q.shift();
    order.push(u);
    steps.push({
      type: 'remove',
      nodeColors: { [u]: 'current' },
      edgeColors: {},
      queue: [...q],
      order: [...order],
    });
    steps.push({ type: 'take', nodeColors: { [u]: 'visited' }, edgeColors: {}, queue: [...q], order: [...order] });
    for (const v of adj[u]) {
      indeg[v] -= 1;
      steps.push({
        type: 'dec',
        nodeColors: { [u]: 'visited', [v]: 'processing' },
        edgeColors: { [`${u}-${v}`]: 'highlight' },
        queue: [...q],
        order: [...order],
      });
      if (indeg[v] === 0) {
        q.push(v);
        steps.push({ type: 'free', nodeColors: { [v]: 'processing' }, edgeColors: {}, queue: [...q], order: [...order] });
      }
    }
  }
  steps.push({ type: 'done', nodeColors: Object.fromEntries(ids.map((id) => [id, 'visited'])), edgeColors: {}, queue: [], order });
  return steps;
}

export default function TopologicalSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: "Kahn's topological sort" });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.type}${step.order ? ` → ${step.order.join('')}` : ''}` });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: {},
      queue: step.queue || [],
      stack: step.order || [],
      distances: {},
      visited: step.order || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
