# 10. Performance Tuning & Monitoring

> **Permanent Recall Note:** Kafka is **fast** when **batching**, **compression**, **page cache**, and **parallelism** align. Tuning without **metrics** is blind — **UnderReplicatedPartitions**, **ISR**, **request handler idle**, **bytes in/out**, and **consumer lag** tell the story. JVM tuning matters at **broker** scale. Cross-train with Spark’s **shuffle** tuning — different layer, same **measure-first** mindset — [../spark/11_Performance_Tuning_OOM_Spill.md](../spark/11_Performance_Tuning_OOM_Spill.md).

### The 10-Second Summary
- **Producer:** `batch.size`, `linger.ms`, `compression.type`, `acks` — throughput vs latency.
- **Consumer:** `fetch.min.bytes`, `max.partition.fetch.bytes`, `max.poll.interval.ms`.
- **Broker:** `num.network.threads`, `num.io.threads`, `log.segment.bytes`, `replica.fetch.max.bytes`.
- **OS:** **page cache**, **disk** (sequential), **network** — **GC** logs on brokers.

---

# 10.1 Producer Tuning

| Config | Direction |
|--------|-----------|
| `linger.ms` ↑ | More batching |
| `batch.size` ↑ | Larger batches (bytes) |
| `compression.type=lz4/zstd` | Less network |
| `acks=1` vs `all` | Latency vs durability |

💡 **Key Insight:** **Micro-batch** producers to **same partition** → **higher** throughput — **key** design matters.

---

# 10.2 Consumer Tuning

| Config | Notes |
|--------|-------|
| `fetch.min.bytes` / `fetch.max.wait.ms` | Read **more** per empty poll — **efficiency** |
| `max.partition.fetch.bytes` | Large messages — **must** align with broker **max.message.bytes** |
| `max.poll.interval.ms` | **Long** processing — increase **carefully** |

---

# 10.3 Broker Tuning

```properties
num.network.threads=8
num.io.threads=16
socket.send.buffer.bytes=102400
socket.receive.buffer.bytes=102400
log.segment.bytes=1073741824
```

- **Threads** vs **CPU cores** — profile, don't guess.

---

# 10.4 OS-Level Tuning

- **vm.swappiness** low — avoid **RAM** swap thrash.
- **ulimit** open files — **many partitions** = many file descriptors.
- **XFS** common for Kafka disks; **RAID** vs **JBOD** trade-offs.

---

# 10.5 JVM Tuning for Kafka

- **G1GC** common; **heap** not huge — **page cache** does heavy lifting.
- **Direct memory** / **network buffers** — watch **GC pauses** correlating with **consumer lag**.

⚠️ **Warning:** Huge broker heap **fights** OS page cache — **counterproductive**.

---

# 10.6 Key Metrics

| Metric | Meaning |
|--------|---------|
| **UnderReplicatedPartitions** | Replication **not** caught up |
| **ISRShrinks / ISRExpands** | Stability signal |
| **RequestHandlerAvgIdlePercent** | **Low** = CPU bound |
| **BytesInPerSec / BytesOutPerSec** | Traffic |
| **ConsumerLag** (per partition) | Processing health |

---

# 10.7 Monitoring Tools

| Tool | Role |
|------|------|
| **JMX** | Broker metrics |
| **Prometheus + Grafana** | Dashboards |
| **Confluent Control Center** | Vendor UI |
| **Burrow** | Consumer lag **API** |

🎯 **Interview Tip:** **Lag** growth rate **alert** > static threshold only.

---

# 10.8 Capacity Planning

```
Required throughput ≈ (messages/sec × message size) × replication factor fanout
Disk ≈ retention × write rate × RF (rough)
Network ≈ replication + consumer fan-out
```

🏗️ **Real-World:** **Growth** + **burst** factor — **headroom** for **rebalancing** and **failures**.

---

# 10.9 Example — Producer props for throughput

```properties
linger.ms=20
batch.size=65536
compression.type=lz4
acks=1
```

### Spark note

Spark **Kafka write** batching is **different** — shuffle + Spark **tuning** separate — [../spark/11_Performance_Tuning_OOM_Spill.md](../spark/11_Performance_Tuning_OOM_Spill.md).

---

# 10.10 Lag Monitoring — Burrow & Lag Exporter

```
Burrow: consumer group status (OK / STALLING / STOP)
Kafka Lag Exporter: Prometheus metrics per group/topic/partition
```

- **STALLING** in Burrow ⇒ partitions not advancing — tie to **rebalance** or **slow** processing.
- Export **max** lag histogram — **p99** matters for **SLA** stories.

🎯 **Interview Tip:** **Consumer group** lag **per partition** — **one** hot partition can dominate **user** impact.

---

# 10.11 Interview Questions & Answers

**Q: Broker slow — pehla metric?**  
**A:** **RequestHandlerAvgIdlePercent**, **disk** wait, **network** — **narrow** bottleneck.

**Q: Producer lag vs consumer lag?**  
**A:** **Producer** usually **batch/queue**; **consumer lag** = **processing** or **fetch** — **different** dashboards.

**Q: Why not max heap 64G on broker?**  
**A:** **Long GC**, **cache eviction** — Kafka **relies** on **OS cache**.

**Q: Spark + Kafka pipeline tuning order?**  
**A:** **Kafka** healthy (ISR, lag) → **consumer** app → **Spark** stages — **upstream first**.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 10 — QUICK RECALL                                 │
├─────────────────────────────────────────────────────────────┤
│  🧠 Batch + compression + parallelism = throughput         │
│  🧠 Broker threads + segment size = I/O pattern            │
│  🧠 Page cache > giant JVM heap                            │
│  🧠 URP, ISR, lag = triage dashboard                       │
│  ⚠️  max.poll.interval vs processing time                  │
│  🎯 Measure before random config changes                   │
└─────────────────────────────────────────────────────────────┘
```
