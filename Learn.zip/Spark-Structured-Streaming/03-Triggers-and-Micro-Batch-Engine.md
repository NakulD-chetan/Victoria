# Triggers & Micro-Batch Engine

A **trigger** decides **when** Structured Streaming runs the next **incremental computation**. The default **micro-batch** engine executes one Spark job per trigger interval. This note defines triggers, processing-time semantics, and how they interact with latency and throughput.

---

## 1. Definition: Trigger

A **trigger** is the scheduling policy for streaming execution. It answers:

> “How often should Spark pull new data, run the query plan, and push results to the sink?”

Without an explicit trigger, Spark typically uses a **default processing-time interval** (documented per version—common default is a short fixed interval for micro-batches).

---

## 2. Common Trigger Strategies (Conceptual)

| Strategy | Behavior |
| -------- | -------- |
| **Fixed interval** | Run at most every *T* wall-clock time units (processing time). |
| **Once** | Process all **currently available** data and **stop** (batch-like catch-up). |
| **Continuous** (where available / experimental) | Lower-latency path; different execution characteristics than classic micro-batch. |

**Processing time** means wall-clock time in the engine when the trigger fires—not necessarily the **event time** embedded in records.

---

## 3. Micro-Batch Timeline

```
Wall-clock:  0s      1s      2s      3s      4s
Trigger:     |-------|-------|-------|-------|
Micro-batch:    MB₀      MB₁      MB₂      MB₃

Each MBᵢ:
  - consumes newly available input since MBᵢ₋₁
  - updates state and emits per output mode
```

**Latency** ≈ *trigger interval* + *execution time* + *sink commit time* (simplified).

---

## 4. Processing Time vs Event Time

| Clock | What it measures | Typical use |
| ----- | ---------------- | ----------- |
| **Processing time** | When Spark **handles** a record. | Triggers, throughput-oriented pipelines. |
| **Event time** | When the **business event** occurred (field in data). | Windows, sessionization, late-data policies. |

Triggers are almost always tied to **processing time**. Correct windowed analytics still use **event time** *inside* the query via timestamps and **watermarks**.

---

## 5. Backpressure (Conceptual)

If a micro-batch takes **longer** than the trigger period, the next batch may **queue** or Spark may **adjust** effective scheduling (behavior depends on source and version). Operators should monitor:

- **Batch duration** vs trigger interval.
- **Input rate** vs **processing rate**.

Persistent imbalance leads to **growing delays** and larger **state** retention windows.

---

## 6. “Once” and Available-Now Data

**Trigger.Once** (and related APIs in different Spark versions) treats streaming as **bounded**: consume what is available **now**, write outputs, then stop. Useful for **hourly catch-up** jobs that reuse the same streaming logic as continuous mode.

---

## 7. Key Takeaways

1. **Trigger** = schedule of micro-batch runs in the default engine.
2. **Processing time** drives triggers; **event time** drives window correctness.
3. **Throughput vs latency**: shorter triggers reduce latency but increase scheduling overhead; longer triggers batch more data per job.
4. Watch **batch duration** versus trigger interval to avoid **lag** and **memory pressure**.

---
