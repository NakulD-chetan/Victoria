# Joins in Spark

Joins are one of the most common and most **expensive** operations in Spark. Understanding how they work internally helps you write faster pipelines.

---

## 1. Join Types


| Join Type  | What It Returns                                     |
| ---------- | --------------------------------------------------- |
| Inner      | Only rows that match in BOTH tables                 |
| Left       | All left rows + matching right (NULL if no match)   |
| Right      | All right rows + matching left (NULL if no match)   |
| Full Outer | All rows from both sides (NULLs for non-matches)    |
| Left Anti  | Left rows that have NO match in right               |
| Left Semi  | Left rows that have a match (right columns dropped) |
| Cross      | Cartesian product — every row × every row           |
| Self       | Joining a table with itself                         |


```python
# Examples
df1.join(df2, "customer_id", "inner")
df1.join(df2, "customer_id", "left")
df1.join(df2, "customer_id", "left_anti")
df1.crossJoin(df2)
```

---

## 2. Why Joins Cause Shuffle

When joining `df1 JOIN df2 ON key`, Spark must bring **all rows with the same key** into the **same partition**. This requires moving data across the network = **shuffle**.

**What makes shuffle expensive:**

- Network I/O — massive data movement between executors
- Serialization and Deserialization
- Sorting cost (for Sort-Merge Join)
- Disk spill (when data doesn't fit in memory)

---

## 3. Join Strategies in Spark

### Strategy 1: Sort-Merge Join (Default for Large-Large Joins)

Used when **both tables are large**.

**Steps:**

1. **Shuffle Write**: Both DataFrames shuffled by join key
2. **Shuffle Read**: Data pulled to new partitions
3. **Sort**: Both sides sorted by key
4. **Merge**: Walk through both sorted lists, matching keys

```
df1 (large) ──shuffle + sort──┐
                                ├── Merge Join ──> Result
df2 (large) ──shuffle + sort──┘
```

**Cost**: 2 shuffles + 2 sorts = most expensive

### Strategy 2: Broadcast Hash Join (Best for Small-Large Joins)

Used when **one table is small** enough to fit in memory.

**Default threshold**: `spark.sql.autoBroadcastJoinThreshold = 10 MB`

**Steps:**

1. Driver collects the small DataFrame
2. Broadcasts it to ALL executors
3. Each executor builds a **hash map** from the small data
4. Large DataFrame is scanned locally — each row looks up the hash map

```
df_small ──broadcast to all executors──┐
                                         ├── Hash Lookup ──> Result
df_large ──stays local (no shuffle)────┘
```

**Cost**: No shuffle, no sort = **fastest join**

```python
from pyspark.sql.functions import broadcast
result = df_large.join(broadcast(df_small), "customer_id")
```

> **Note**: The practical upper limit for broadcast is around **2 GB** due to Java's byte array size limit. The PDF mentioned 10 GB which is incorrect. You can increase the threshold up to ~2 GB but not beyond that.

In Java, arrays are indexed by `int` **(32-bit signed integer)**.

👉 Max value of `int`:

```
2^31 - 1 ≈ 2.1 billion
```

So:

> 👉 A single array **cannot exceed ~2 GB**

---

# 📦 How This Affects Spark Broadcast

When Spark broadcasts a DataFrame:

1.   
It **serializes** the data  

2.   
Converts it into **binary (byte array)**  

3.   
Sends it to executors  


```
df_small → serialize → byte[] → broadcast
```

---

## 🚨 Problem

If serialized data becomes:

```
> 2 GB
```

👉 Java **cannot create that byte array**

### Strategy 3: Shuffle Hash Join

Used when one table is relatively smaller (but too big to broadcast) and the other is large.

**Steps:**

1. Shuffle both DataFrames by join key
2. Build a hash map from the smaller side
3. Probe with the larger side

**Cost**: 1 shuffle, no sort (faster than Sort-Merge, but needs more memory)

---

## 4. How Shuffle Works During a Join (Deep Dive)

### Shuffle Write Phase

Each executor:

1. Reads its own partition
2. For each row, computes `hash(join_key) % num_shuffle_partitions`
3. Writes rows to local disk, grouped by target partition

```
Executor 1 has: customer_id = 1, 2
  hash(1) % 3 = 1 → writes to partition_1.data
  hash(2) % 3 = 2 → writes to partition_2.data

Executor 2 has: customer_id = 3
  hash(3) % 3 = 0 → writes to partition_0.data
```

**Shuffle files are stored on executor local disk** (`spark.local.dir`), NOT in memory, NOT in HDFS, NOT in S3.

### Shuffle Read Phase

Next-stage executors:

1. Read shuffle files from ALL executors over the network
2. Deserialize the data
3. Sort and merge for the join operation

---

## 5. AQE (Adaptive Query Execution) — Smart Join Optimization

AQE is Spark's **runtime optimizer** (Spark 3.0+). It changes the plan **while the job is running** based on actual data size.

### A) Auto Broadcast Join

If a table turns out to be small after filtering (even if estimated as large), AQE converts Sort-Merge Join → Broadcast Join at runtime.

### B) Auto Switch Join Strategy

AQE can switch between:

- Sort-Merge → Broadcast
- Sort-Merge → Shuffle Hash
- Based on actual partition sizes

### C) Skew Join Handling

If one key has 90% of the data, AQE:

- Detects the skewed partition
- Splits it into multiple sub-partitions
- Distributes the work evenly

### D) Auto Coalesce Shuffle Partitions

Default = 200 partitions, but maybe your data only needs 5. AQE merges tiny partitions automatically:

```
spark.sql.adaptive.shuffle.targetPostShuffleInputSize = 64MB
```

**Enable AQE:**

```python
spark.conf.set("spark.sql.adaptive.enabled", "true")
```

---

## 6. How to Reduce Shuffle in Joins

### A) Broadcast Small DataFrames

```python
result = df_large.join(broadcast(df_small), "customer_id")
```

No shuffle, no sort — fastest option when one table is small.

### B) Repartition by Join Key Before Joining

```python
df1 = df1.repartition(col("customer_id"))
df2 = df2.repartition(col("customer_id"))
result = df1.join(df2, "customer_id")
```

Pre-arranges data so shuffle during join is more efficient.

### C) Bucketing (Best for Repeated Joins)

If you join the same tables repeatedly:

```sql
-- Both tables bucketed on same key, same number of buckets
CREATE TABLE t1 ... CLUSTERED BY (cust_id) INTO 32 BUCKETS;
CREATE TABLE t2 ... CLUSTERED BY (cust_id) INTO 32 BUCKETS;
```

Then joins between `t1` and `t2` on `cust_id` require **no shuffle**.

### D) Salting (Fix Heavy Skew)

When one key dominates the data:

```python
df_large = df_large.withColumn("salted_key",
    concat(col("key"), lit("_"), (rand() * 10).cast("int")))

df_small_exploded = df_small.crossJoin(
    spark.range(10).withColumnRenamed("id", "salt")
).withColumn("salted_key",
    concat(col("key"), lit("_"), col("salt")))

result = df_large.join(df_small_exploded, "salted_key")
```

### E) Enable AQE

```python
spark.conf.set("spark.sql.adaptive.enabled", "true")
```

Automatically handles skew, partition merging, and join strategy switching.

### F) Cache Strategic DataFrames

If joining the same DataFrame multiple times:

```python
df_cached = df_expensive.cache()
result1 = df_cached.join(df_a, "id")
result2 = df_cached.join(df_b, "id")
```

---

## Key Takeaway

> Joins are expensive because they require **shuffle** (data movement across the cluster).
> Use **broadcast join** when one table is small (< 2 GB). For repeated large-table joins, use **bucketing**. For skewed keys, use **salting**.
> Enable **AQE** for automatic runtime optimization.

