import assert from 'node:assert/strict';

import {
  createBoundArrow,
  resolveSceneBindings,
  worldPointsForLinear,
} from '../src/components/new-canvas/engine/binding-engine.js';
import {
  repairSceneOverlaps,
  validateScene,
} from '../src/components/new-canvas/engine/scene-validator.js';
import { compileTeachingScene } from '../src/components/new-canvas/agent/teaching-composer.js';
import {
  CANVAS_DOCUMENT_VERSION,
  normalizeElementV2,
} from '../src/components/new-canvas/state/types.js';
import { migrateLegacyDocument } from '../src/components/new-canvas/state/persist.js';

function box(id, x, y, w = 120, h = 80) {
  return { id, type: 'rect', x, y, w, h, z: 1, isDeleted: false };
}

{
  const from = box('from', 0, 0);
  const to = box('to', 420, 190);
  const obstacle = box('obstacle', 180, 40, 100, 210);
  const arrow = createBoundArrow({
    id: 'arrow',
    from,
    to,
    elements: [from, to, obstacle],
    style: { stroke: '#111827', strokeWidth: 2 },
  });
  assert.equal(arrow.startBinding.elementId, from.id);
  assert.equal(arrow.endBinding.elementId, to.id);
  assert.ok(worldPointsForLinear(arrow).length >= 3, 'router should bend around the obstacle');

  const movedTo = { ...to, x: 560, y: 260 };
  const resolved = resolveSceneBindings([from, movedTo, obstacle, arrow]);
  const movedArrow = resolved.find((element) => element.id === arrow.id);
  const points = worldPointsForLinear(movedArrow);
  assert.ok(points.at(-1).x > 500, 'bound arrow should follow a moved target');
  assert.equal(validateScene(resolved).valid, true);
}

{
  const source = {
    id: 'note',
    type: 'callout',
    x: 0,
    y: 0,
    w: 160,
    h: 80,
    z: 1,
    isDeleted: false,
  };
  const target = {
    id: 'array',
    type: 'widget',
    x: 260,
    y: 120,
    w: 420,
    h: 160,
    z: 1,
    isDeleted: false,
    customData: {
      ports: {
        'cell:0': { fixedPoint: [0.2, 0.75], side: 'top', mode: 'inside', gap: 0 },
      },
    },
  };
  const arrow = createBoundArrow({
    id: 'port-arrow',
    from: source,
    to: target,
    toPort: 'cell:0',
    elements: [source, target],
    style: { stroke: '#111827', strokeWidth: 2 },
  });
  assert.equal(arrow.endBinding.portId, 'cell:0');
  const endPoint = worldPointsForLinear(arrow).at(-1);
  assert.equal(Math.round(endPoint.x), Math.round(target.x + target.w * 0.2));
}

{
  const overlapping = [
    box('first', 0, 0, 220, 120),
    box('second', 90, 40, 220, 120),
    box('third', 150, 70, 200, 120),
  ];
  assert.equal(validateScene(overlapping).valid, false);
  const repaired = repairSceneOverlaps(overlapping, { iterations: 80, gap: 28 });
  assert.equal(validateScene(repaired).valid, true, 'repair pass must remove hard overlaps');
}

{
  const scene = {
    viewport: { zoom: 1, panX: 0, panY: 0 },
    elements: [
      {
        id: 'old-array',
        type: 'widget',
        widgetType: 'array',
        x: 20,
        y: 20,
        w: 300,
        h: 120,
        z: 1,
        isDeleted: false,
        widgetData: {
          title: 'Array',
          values: ['bad'],
          agentMeta: {
            clusterKey: 'lesson:array',
            semanticRole: 'primary-visual',
            sourceRunId: 'old-run',
          },
          agentSpawnId: 'old-spawn',
        },
      },
      {
        id: 'old-text',
        type: 'text',
        text: 'Deletes the array and deallocates memory.',
        x: 30,
        y: 180,
        w: 260,
        h: 60,
        z: 2,
        isDeleted: false,
        customData: {
          owner: 'agent',
          clusterKey: 'lesson:array',
          semanticRole: 'definition',
        },
      },
    ],
  };
  const compiled = compileTeachingScene({
    scene,
    stageElement: { clientWidth: 1400, clientHeight: 900 },
    request: {
      topic: 'array',
      structureType: 'array',
      title: 'Array',
      values: ['12', '7', '19', '4', '23'],
      focus: 'overview',
    },
    replaceExistingTopic: true,
  });
  const arrayWidgets = compiled.elements.filter((element) => element.type === 'widget' && element.widgetType === 'array' && !element.isDeleted);
  assert.equal(compiled.validation.valid, true, 'compiled teaching scene should validate');
  assert.equal(arrayWidgets.length, 1, 'old agent-owned array lesson should be replaced in place');
  assert.ok(compiled.elements.some((element) => element.type === 'arrow' && element.endBinding?.portId), 'array lesson should bind arrows to semantic ports');
  assert.ok(!compiled.elements.some((element) => element.text === 'Deletes the array and deallocates memory.'), 'stale lesson text should be removed');
}

{
  const invalid = normalizeElementV2({
    id: 'invalid-arrow',
    type: 'arrow',
    x: 0,
    y: 0,
    x2: 100,
    y2: 100,
    startBinding: { elementId: 'missing' },
  });
  const validation = validateScene([invalid]);
  assert.equal(validation.valid, false);
  assert.ok(validation.errors.some((error) => error.type === 'invalid-binding'));
}

{
  const normalized = normalizeElementV2({
    id: 'legacy',
    type: 'rect',
    x: 12,
    y: 18,
    w: 140,
    h: 90,
  });
  assert.equal(normalized.width, 140);
  assert.equal(normalized.height, 90);
  assert.equal(normalized.customData.schemaVersion, CANVAS_DOCUMENT_VERSION);
  assert.ok(Number.isInteger(normalized.seed) && normalized.seed > 0);
}

{
  const legacy = {
    activeId: 'scene-1',
    scenes: {
      'scene-1': {
        id: 'scene-1',
        name: 'Legacy lesson',
        folderId: 'folder-1',
        viewport: { zoom: 0.8, panX: 12, panY: -9 },
        elements: [{
          id: 'legacy-widget',
          type: 'widget',
          widgetType: 'array',
          x: 40,
          y: 70,
          w: 320,
          h: 140,
          widgetData: { title: 'Array', values: ['1', '2', '3'] },
        }],
      },
    },
    folders: {
      'folder-1': { id: 'folder-1', name: 'DSA', parentId: null },
    },
    openTabs: ['scene-1'],
  };
  const migrated = migrateLegacyDocument(legacy);
  const scene = migrated.scenes['scene-1'];
  assert.equal(migrated.documentVersion, CANVAS_DOCUMENT_VERSION);
  assert.equal(scene.folderId, 'folder-1');
  assert.deepEqual(scene.viewport, legacy.scenes['scene-1'].viewport);
  assert.deepEqual(scene.elements[0].widgetData, legacy.scenes['scene-1'].elements[0].widgetData);
  assert.deepEqual(migrated.openTabs, ['scene-1']);
  assert.equal(migrated.folders['folder-1'].name, 'DSA');
}

console.log('Canvas V2 geometry tests passed.');
