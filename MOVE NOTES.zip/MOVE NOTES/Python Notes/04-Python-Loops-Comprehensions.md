# Python Loops and Comprehensions

> *"else clause runs if loop completed without break"* — Python loop surprise (important)

`for`, `while`, `range()`, loop-`else`, comprehensions, and generator expressions — this is where Python starts to feel **Pythonic**. A natural follow-up after [[03-Python-Operators-Control-Flow]].

---

## 1. `for` loop — iteration protocol

> **Definition:** A `for` loop executes a block once per item yielded by an iterable, using Python’s iterator protocol (`iter` / `__next__` / `StopIteration`) under the hood.

**Why we need it:** You describe *what to visit* (the iterable), not *how to index*, which reduces off-by-one bugs and reads closer to the problem domain.

**Syntax:**
```python
for <item> in <iterable>:
    <block>
```

Python's `for` does **not** depend on a C-style index — it runs over an **iterable**.

```python
for ch in "Python":    # Goes through each character one by one: P, y, t, h, o, n
    print(ch)

for x in [1, 2, 3]:   # Goes through each item in the list: 1, 2, 3
    print(x * 2)       # Prints 2, 4, 6
```

**Under the hood:** `iter()` → iterator → `__next__()` until `StopIteration`.

---

## 2. `range()` — lazy sequence

> **Definition:** `range` is an immutable, memory-efficient sequence of integers that produces values on demand instead of storing them all in a list.

**Why we need it:** Counted loops and numeric strides stay cheap for large spans; the `start`, `stop`, `step` shape matches how people reason about numeric intervals.

**Syntax:**
```python
range(<stop>)
range(<start>, <stop>[, <step>])
```

```python
range(5)           # Generates numbers: 0, 1, 2, 3, 4 (starts from 0, stops BEFORE 5)
range(2, 10)       # Generates: 2, 3, 4, 5, 6, 7, 8, 9 (starts at 2, stops before 10)
range(0, 20, 3)    # Generates: 0, 3, 6, 9, 12, 15, 18 (jumps by 3 each time)
range(5, 0, -1)    # Generates: 5, 4, 3, 2, 1 (counts backwards)
```

| Call | What it does |
|------|---------|
| `range(stop)` | Numbers from 0 up to (not including) stop |
| `range(start, stop)` | Numbers from start up to (not including) stop |
| `range(start, stop, step)` | Numbers with custom jump size (step can be negative to go backwards) |

```python
for i in range(5):       # Loops 5 times with i = 0, 1, 2, 3, 4
    print(i, end=" ")    # Prints: 0 1 2 3 4
```

**Watch Out!** A `range` object is **not a list** — memory efficient; use `list(range(5))` to materialize.

---

## 3. `while` loop

> **Definition:** A `while` loop repeats its body as long as the header condition evaluates to true, re-checking before each iteration.

**Why we need it:** Some work is driven by a state or external condition rather than a fixed iterable, so “keep going until …” is the natural control structure.

**Syntax:**
```python
while <condition>:
    <block>
```

```python
n = 3
while n > 0:    # Keeps running AS LONG AS n is greater than 0
    print(n)    # Prints 3, then 2, then 1
    n -= 1      # Subtract 1 each time (so the loop eventually stops)
```

Keep the condition clear to avoid infinite loops — `break`/`continue` in the next section.

---

## 4. `break`, `continue`, `pass`

> **Definition:** `break` exits the innermost loop immediately; `continue` skips the rest of the current iteration and jumps to the next test; `pass` is a no-op that satisfies the need for a statement where a block is required.

**Why we need it:** Fine-grained loop control without `goto`; `pass` lets you stub legal syntax while you design structure.

**Syntax:**
```python
for <item> in <iterable>:   # or while <cond>:
    break       # leave the loop
    continue    # next iteration
    pass        # placeholder body
```

| Stmt | What it does |
|------|--------|
| `break` | Immediately EXIT the loop — stops everything |
| `continue` | SKIP the rest of this round, jump to next iteration |
| `pass` | Do nothing — just a placeholder when you need a line but have nothing to do |

```python
for i in range(10):
    if i == 3:
        continue    # Skips 3, jumps to next number
    if i == 7:
        break       # Stops loop completely at 7
    print(i)        # Prints: 0 1 2 4 5 6
```

---

## 5. `else` with loops — tricky but useful

> **Definition:** A loop may have an `else` clause that runs only if the loop finished normally—meaning it did **not** exit early via `break`.

**Why we need it:** You can express “exhausted the search without finding …” without an extra flag variable, which is a common pattern in Pythonic code.

**Syntax:**
```python
for <item> in <iterable>:
    ...
    if <found>: break
else:
    <not_found_or_completed_without_break>
```

`else` runs when the loop was **not** interrupted by `break`.

```python
for n in range(2, 10):
    for x in range(2, n):
        if n % x == 0:
            break
    else:
        # no break → prime for this n
        print(n, "prime")
```

**Interview Tip:** This pattern is used in **search loops** — `break` when found, otherwise the else block means "not found".

---

## 6. List comprehension

> **Definition:** A list comprehension is a compact expression that builds a new list by mapping over an iterable and optionally filtering with an `if` clause.

**Why we need it:** For straightforward transforms it is often clearer and faster than an explicit loop plus `append`, when the goal really is “make a list.”

**Syntax:**
```python
[<expr> for <var> in <iterable> [if <condition>]]
```

```python
squares = [x * x for x in range(10)]          # Build list of squares: [0, 1, 4, 9, 16, ...]
evens = [x for x in range(20) if x % 2 == 0]  # Build list of even numbers only: [0, 2, 4, 6, ...]
# Pattern: [WHAT_TO_PUT for ITEM in COLLECTION if CONDITION]
```

### Nested (watch readability)

```python
matrix = [[i * j for j in range(3)] for i in range(3)]
```

| Style | When |
|-------|------|
| Comprehension | Simple transform + filter |
| Plain loop | Side effects, complex logic |

**Watch Out!** Avoid **side effects** inside comprehensions (append file, print) — not readable.

---

## 7. Dict and set comprehension

> **Definition:** Dict comprehensions build `{key: value}` mappings; set comprehensions build sets of unique elements—same idea as list comprehensions but for those collection types.

**Why we need it:** One consistent pattern covers lists, sets, and dicts so you can construct the right shape without boilerplate loops.

**Syntax:**
```python
{<key_expr>: <value_expr> for <var> in <iterable> [if <condition>]}
{<expr> for <var> in <iterable> [if <condition>]}
```

```python
word = "hello"
counts = {c: word.count(c) for c in set(word)}  # Dict: each letter → its count
# Result: {'h': 1, 'e': 1, 'l': 2, 'o': 1}

unique_lengths = {len(s) for s in ["aa", "bbb", "cc"]}
# Set comprehension: gets unique lengths → {2, 3}
```

---

## 8. Generator expression — lazy

> **Definition:** A generator expression is a comprehension in parentheses that returns a lazy iterator producing items one at a time instead of building a full list.

**Why we need it:** Large or streaming data stays memory-bounded; consumers like `sum()`, pipelines, or manual `next()` pull values on demand.

**Syntax:**
```python
(<expr> for <var> in <iterable> [if <condition>])
```

In parentheses — memory friendly:

```python
sum(x * x for x in range(1_000_000))  # Calculates sum WITHOUT creating a huge list in memory
```

```python
gen = (x * x for x in range(5))  # Creates a generator — computes values one at a time
next(gen)  # 0 → gives first value
next(gen)  # 1 → gives next value
next(gen)  # 4 → and so on...
```

**Interview Tip:** For large data pipelines — think **generator** first; use a list only when you really need one.

---

## 9. `enumerate` and `zip` — loop helpers

> **Definition:** `enumerate` pairs each item with an incrementing index; `zip` aligns several iterables in lockstep, yielding tuples until the shortest input is exhausted.

**Why we need it:** You avoid manual `range(len(...))` indexing and fragile parallel index variables when walking related sequences together.

**Syntax:**
```python
for <i>, <value> in enumerate(<iterable>[, <start>]):
    ...

for <a>, <b>, ... in zip(<iter1>, <iter2>, ...):
    ...
```

```python
for i, v in enumerate(["a", "b", "c"]):  # Gives both INDEX and VALUE
    print(i, v)   # 0 a, 1 b, 2 c → no need to track index manually

for a, b in zip([1, 2], ["x", "y"]):  # Pairs up items from two lists
    print(a, b)   # 1 x, 2 y → walks through both lists at the same time
```

**Quick summary:**
- **enumerate** = gives you (position number, value) for each item — no need for `range(len(...))`
- **zip** = combines two lists into pairs — walks through them together side by side

---

## 10. `zip` strict mode (3.10+)

```python
list(zip([1, 2], [10, 20, 30], strict=True))  # ValueError — length mismatch
```

**Interview Tip:** Use `strict=True` in data pipelines to avoid silent truncation.

---

## 11. `reversed`, `sorted` — loop friends

```python
for i in reversed(range(5)):              # Goes backwards: 4, 3, 2, 1, 0
    print(i)

for x in sorted([3, 1, 2]):              # Goes in order: 1, 2, 3 (ascending)
    print(x)

for x in sorted([3, 1, 2], reverse=True):  # Goes in reverse order: 3, 2, 1 (descending)
    print(x)
```

**Quick summary:**
- **reversed** = goes through items in backwards order
- **sorted** = returns a NEW sorted list — original list stays the same
- `reverse=True` = sort from highest to lowest

---

## 12. Anti-pattern — comprehension side effects

```python
# BAD style
[print(x) for x in range(3)]

# GOOD
for x in range(3):
    print(x)
```

**Watch Out!** The goal of a comprehension is to **build a value** — do side effects in normal loops.

---

## Quick Memory Card

```
+------------------------------------------+
| FOR                                       |
| - runs over an iterable                  |
| - range(start, stop, step)               |
+------------------------------------------+
| BREAK / CONTINUE                          |
| - break exit, continue next iter         |
+------------------------------------------+
| LOOP ELSE                                 |
| - runs if NO break in loop               |
+------------------------------------------+
| COMPREHENSIONS                            |
| - [expr for x in it if cond]             |
| - {k:v for ...}, {expr for ...}          |
+------------------------------------------+
| GEN EXPR                                  |
| - (expr for x in it) lazy                |
+------------------------------------------+
| HELPERS                                   |
| - enumerate, zip                         |
+------------------------------------------+
```

---

*Next: [[05-Python-Functions-Scope]]*
