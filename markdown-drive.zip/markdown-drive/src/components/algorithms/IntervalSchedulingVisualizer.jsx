import { useCallback, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const IVS = [
  { id: '1', s: 1, e: 3 },
  { id: '2', s: 2, e: 4 },
  { id: '3', s: 3, e: 5 },
  { id: '4', s: 0, e: 6 },
  { id: '5', s: 5, e: 7 },
  { id: '6', s: 8, e: 9 },
  { id: '7', s: 5, e: 9 },
  { id: '8', s: 6, e: 10 },
];

const TMAX = 10;

function generateSteps() {
  const sorted = [...IVS].sort((a, b) => a.e - b.e);
  const steps = [];
  steps.push({ type: 'sort', msg: 'Sort intervals by end time', selected: [] });
  const picked = [];
  let last = -Infinity;
  for (const it of sorted) {
    steps.push({ type: 'look', msg: `Interval ${it.id} [${it.s},${it.e}]`, current: it.id, selected: [...picked], last });
    if (it.s >= last) {
      picked.push(it.id);
      last = it.e;
      steps.push({ type: 'take', msg: `Take ${it.id}`, current: it.id, selected: [...picked], last });
    } else {
      steps.push({ type: 'drop', msg: `Reject ${it.id} (overlap)`, current: it.id, selected: [...picked], last });
    }
  }
  steps.push({ type: 'done', msg: `Maximum subset size ${picked.length}`, selected: [...picked], last });
  return steps;
}

const TimelineCanvas = forwardRef(function TimelineCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ order: IVS.map((x) => x.id), selected: [], highlight: null });
  const addAnim = useCallback(() => {}, []);
  const setState = useCallback((p) => Object.assign(stateRef.current, p), []);
  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 320;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);
    const byId = Object.fromEntries(IVS.map((x) => [x.id, x]));
    let raf;
    function draw() {
      const { order, selected, highlight } = stateRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#e7e5e4' : 'rgba(255,255,255,0.06)';
      for (let gx = 20; gx < W; gx += 20) for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.2, 1.2);
      const pad = 36;
      const axisY = H - 44;
      const axisW = W - pad * 2;
      ctx.strokeStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#1c1917' : '#e7e5e4';
      ctx.beginPath();
      ctx.moveTo(pad, axisY);
      ctx.lineTo(W - pad, axisY);
      ctx.stroke();
      for (let t = 0; t <= TMAX; t++) {
        const x = pad + (t / TMAX) * axisW;
        ctx.fillStyle = ctx.strokeStyle;
        ctx.font = '9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(String(t), x, axisY + 16);
      }
      let row = 0;
      order.forEach((id) => {
        const a = byId[id];
        if (!a) return;
        const x0 = pad + (a.s / TMAX) * axisW;
        const x1 = pad + (a.e / TMAX) * axisW;
        const y = 40 + row * 24;
        row += 1;
        const sel = selected.includes(id);
        const hi = highlight === id;
        ctx.fillStyle = hi ? '#ffec99' : sel ? '#b2f2bb' : '#d0bfff';
        if (document.documentElement.getAttribute('data-theme') !== 'light') ctx.fillStyle = hi ? '#805b10' : sel ? '#1e5631' : '#3b2e6e';
        ctx.fillRect(x0, y, Math.max(3, x1 - x0), 16);
        ctx.strokeStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#44403c' : 'rgba(255,255,255,0.4)';
        ctx.strokeRect(x0, y, Math.max(3, x1 - x0), 16);
        ctx.fillStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#111' : '#eee';
        ctx.font = '600 10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(id, (x0 + x1) / 2, y + 11);
      });
      raf = requestAnimationFrame(draw);
    }
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function paint(step) {
  return {
    order: [...IVS].sort((a, b) => a.e - b.e).map((x) => x.id),
    selected: step.selected || [],
    highlight: step.current || null,
  };
}

export default function IntervalSchedulingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Interval scheduling (earliest finishing)' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={TimelineCanvas} onInit={onInit} onStep={onStep} />;
}
