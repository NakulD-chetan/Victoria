# 07 — Protocol Buffers (Protobuf) & Thrift

> Protobuf (Google) and Thrift (Facebook) are **binary serialization** formats that use **numbered field IDs** and **compiled code generation** — smaller and faster than JSON or Avro, widely used in **gRPC**, **microservices**, and **high-performance** data pipelines.

---

## 1. What Is Protobuf and Why It Matters for Data Engineering

Protobuf (Protocol Buffers) is Google's language-neutral, platform-neutral binary serialization format. It defines schemas in `.proto` files that are compiled into generated code for any language.

| Property | Detail |
|----------|--------|
| **Created by** | Google (open-sourced 2008) |
| **Schema** | `.proto` files, compiled with `protoc` compiler |
| **Encoding** | Binary, uses field numbers (not names) |
| **Code generation** | Required — schema compiles to language-specific classes |
| **Size** | Smallest among common formats (20–30% smaller than Avro) |
| **Speed** | Fastest serialization/deserialization (compiled, no runtime schema parsing) |
| **Used by** | Google, Uber, Netflix, Confluent (Kafka Schema Registry supports Protobuf) |

### Why Data Engineers Need to Know Protobuf

| Reason | Detail |
|--------|--------|
| **gRPC** | Google's RPC framework uses Protobuf — increasingly used for data platform APIs and inter-service communication |
| **Kafka** | Confluent Schema Registry supports Protobuf alongside Avro — growing adoption |
| **Performance** | At billions of messages/day, the 20–30% size reduction over Avro is significant |
| **Microservices** | Many upstream data sources produce Protobuf — DE pipelines must consume it |

---

## 2. Protobuf Schema Definition (.proto file)

```protobuf
syntax = "proto3";

package com.company.events;

message Customer {
  int64 id = 1;               // field number 1
  string name = 2;             // field number 2
  string email = 3;            // field number 3
  int32 age = 4;               // field number 4

  Address address = 5;         // nested message
  repeated string tags = 6;    // repeated = list/array

  enum Status {
    UNKNOWN = 0;
    ACTIVE = 1;
    INACTIVE = 2;
  }
  Status status = 7;
}

message Address {
  string city = 1;
  string state = 2;
  string zip = 3;
}
```

### Key Schema Concepts

| Concept | Detail |
|---------|--------|
| **Field numbers** | Each field has a unique number — this number is used in binary encoding, not the field name |
| **Never reuse numbers** | Deleted field numbers must NEVER be reused — mark them as `reserved` |
| **`repeated`** | List/array of values |
| **`oneof`** | Union — exactly one of the fields in the group is set |
| **`map`** | Key-value pairs: `map<string, int32>` |
| **Nested messages** | Messages can contain other messages (like nested structs) |
| **`optional`** | In proto3, all fields are optional by default — missing fields get zero-value |

### Proto3 Zero Values

In proto3, if a field is not set, it gets the **zero value** for its type — not null. This is a critical difference from Avro/JSON.

| Type | Zero Value |
|------|-----------|
| int32/int64 | `0` |
| string | `""` (empty string) |
| bool | `false` |
| bytes | empty bytes |
| enum | first value (index 0) |
| message | `null` / not present |

**Implication:** You cannot distinguish "field was set to 0" from "field was not set" in proto3 without using wrapper types or `optional` keyword.

---

## 3. Wire Format — How Protobuf Encoding Works

This is why Protobuf is so compact. Each field is encoded as a tag + value pair, where the tag contains the field number and wire type.

```
Each field: [tag] [value]
  tag = (field_number << 3) | wire_type

Wire types:
  0 = Varint     (int32, int64, bool, enum)
  1 = 64-bit     (fixed64, double)
  2 = Length-delimited  (string, bytes, nested messages, repeated)
  5 = 32-bit     (fixed32, float)
```

### Encoding Example

```
Field: id = 150 (field number 1, type int64)

  Tag:   0x08  (field 1, wire type 0 → varint)
  Value: 0x96 0x01  (varint encoding of 150)
  Total: 3 bytes

Same field in JSON: "id": 150 → 9 bytes (including quotes, colon, space)
Protobuf is 3x smaller for this single field.
```

### Varint Encoding — The Key to Compactness

Protobuf uses variable-length integer encoding (varint). Small numbers use fewer bytes.

```
Value 1:     → 1 byte    (0x01)
Value 127:   → 1 byte    (0x7F)
Value 128:   → 2 bytes   (0x80 0x01)
Value 16383: → 2 bytes
Value 16384: → 3 bytes

Most real-world integers are small → most values use 1–2 bytes instead of fixed 4 or 8.
```

**How to explain it:** "Protobuf uses field numbers in the binary encoding, not field names. Combined with varint encoding for integers, this makes Protobuf the most compact serialization format — no string field names, no delimiters, and small numbers use fewer bytes."

---

## 4. Schema Evolution in Protobuf

| Change | Safe? | Rule |
|--------|-------|------|
| **Add new field** | Yes | Old readers ignore unknown field numbers |
| **Remove field** | Yes (but reserve the number) | Mark as `reserved` — never reuse |
| **Rename field** | Yes | Binary uses field NUMBER, not name — rename is free |
| **Change field number** | NO — breaks everything | Field number IS the identity in binary |
| **Change type (compatible)** | Some | int32 → int64 OK. string → int32 NOT OK |
| **Change required ↔ optional** | Careful | Proto3: all optional by default |

### Reserved Fields — Protecting Against Reuse

```protobuf
message Customer {
  reserved 4, 8;                       // reserved field numbers — can never be reused
  reserved "old_phone", "legacy_id";   // reserved names — prevents accidental reuse

  int64 id = 1;
  string name = 2;
  // Field 4 was "age" — removed, but number 4 is reserved forever
}
```

**Deep concept — Protobuf vs Avro Evolution:**
In Avro, schema evolution is based on field **names** + defaults. In Protobuf, evolution is based on field **numbers**. This means Protobuf allows free renames (the binary doesn't care about names) but forbids number changes. Avro allows type-compatible promotions with defaults but makes renames harder (need aliases).

---

## 5. Protobuf vs Avro vs JSON — Complete Comparison

| Feature | Protobuf | Avro | JSON |
|---------|----------|------|------|
| **Format** | Binary | Binary | Text |
| **Schema** | `.proto` file (compiled to code) | JSON schema (embedded in file header) | None (or external JSON Schema) |
| **Schema in payload** | No (only field numbers + values) | Yes (in file header) | Field names in every record |
| **Code generation** | Required (`protoc` compiler) | Optional | None |
| **Size** | Smallest | Small | Largest |
| **Serialization speed** | Fastest (compiled code) | Fast | Slowest (text parsing) |
| **Schema evolution** | Field numbers | Field names + defaults | No enforcement |
| **Self-describing** | No (need `.proto` to decode) | Yes (schema embedded) | Yes (field names present) |
| **Dynamic reading** | Hard (need compiled schema or reflection) | Easy (schema in file) | Easy (parse as map) |
| **Best for** | gRPC, high-performance services, Kafka | Kafka, CDC, data exchange, Hadoop | APIs, configs, human debugging |

### Size Comparison (Same Record)

```
Record: {id: 12345, name: "Alice", email: "alice@test.com", age: 30}

JSON:      ~65 bytes  (field names + text values + delimiters + quotes)
Avro:      ~30 bytes  (binary values, no field names, schema separate)
Protobuf:  ~25 bytes  (field numbers + varint, no names, no delimiters)
```

---

## 6. gRPC — Protobuf's RPC Framework

gRPC is Google's RPC framework that uses Protobuf for serialization and HTTP/2 for transport.

| Feature | Detail |
|---------|--------|
| **Transport** | HTTP/2 (multiplexed connections, header compression) |
| **Serialization** | Protobuf (compact binary) |
| **Streaming** | Supports unary, server-streaming, client-streaming, bidirectional streaming |
| **Code generation** | Service stubs generated from `.proto` file — type-safe client/server |
| **DE relevance** | Data platform APIs, metadata services, catalog services |

```protobuf
// Define a service in .proto
service CustomerService {
  rpc GetCustomer(GetCustomerRequest) returns (Customer);
  rpc ListCustomers(ListRequest) returns (stream Customer);  // server-streaming
}

message GetCustomerRequest {
  int64 id = 1;
}
```

**How to explain it:** "gRPC uses Protobuf for serialization and HTTP/2 for transport. It's replacing REST+JSON for internal service-to-service communication because it's faster (binary), type-safe (compiled stubs), and supports streaming natively."

---

## 7. Apache Thrift — Brief Overview

Thrift is Facebook's equivalent of Protobuf — a binary serialization format with an IDL (Interface Definition Language) and built-in RPC framework.

| Feature | Detail |
|---------|--------|
| **Created by** | Facebook (2007), now Apache project |
| **Similar to** | Protobuf (binary serialization with numbered fields) |
| **RPC** | Built-in (unlike Protobuf which uses separate gRPC) |
| **Used by** | Hive (Thrift Server), HBase, Cassandra (internal protocol) |
| **2026 status** | Declining — mainly seen in legacy Hadoop components |

```thrift
struct Customer {
  1: required i64 id,
  2: required string name,
  3: optional string email,
  4: optional i32 age
}

service CustomerService {
  Customer getCustomer(1: i64 id),
  list<Customer> searchCustomers(1: string query)
}
```

### Protobuf vs Thrift

| Dimension | Protobuf | Thrift |
|-----------|----------|--------|
| **Creator** | Google | Facebook |
| **RPC** | gRPC (separate project) | Built-in |
| **Adoption (2026)** | Much wider, growing | Declining (legacy) |
| **Protocols** | Binary only | Binary, compact, JSON, etc. |
| **Performance** | Slightly faster | Comparable |
| **DE relevance** | gRPC APIs, Kafka, modern services | Hive Thrift Server, HBase, legacy |

**How to explain it:** "In 2026, Protobuf + gRPC has largely replaced Thrift for new projects. Thrift is mainly encountered in legacy Hadoop components like the Hive Thrift Server and HBase."

---

## 8. Protobuf with Kafka (Schema Registry)

Confluent Schema Registry supports Protobuf alongside Avro and JSON Schema. The wire format is the same.

```
Kafka message wire format (same for Avro and Protobuf):
  [0x00] [4-byte schema ID] [binary payload]

Flow:
  Producer → registers .proto schema in registry → gets schema ID
  Producer → sends (magic byte + schema ID + protobuf binary) to Kafka
  Consumer → reads schema ID from message → fetches .proto from registry
  Consumer → deserializes with compiled Protobuf code
```

**When to use Protobuf vs Avro in Kafka:**
- Use **Avro** when consumers need to read messages dynamically without pre-compiled code (data exploration, ad-hoc consumers)
- Use **Protobuf** when maximum performance matters and all consumers have compiled schema code (production services)

---

## 9. Interview Questions & How to Answer

**Q: "What is Protobuf?"**
> Protocol Buffers is Google's binary serialization format. Schemas are defined in `.proto` files and compiled into language-specific code. It uses field numbers (not names) in the binary encoding, making it the most compact serialization format — 25–30% smaller than Avro and 3x smaller than JSON.

**Q: "Protobuf vs Avro?"**
> Protobuf is faster and smaller but requires code generation and is not self-describing — you need the `.proto` file to decode. Avro is slightly larger but embeds the schema in the file, making it self-describing and easier for dynamic/ad-hoc reading. Use Protobuf for high-performance services. Use Avro for data exchange and Kafka where self-describing payloads matter.

**Q: "Why is Protobuf smaller than JSON?"**
> Three reasons: (1) no field names in the payload — just 1-byte field number tags, (2) binary encoding — integers use varint (small numbers = fewer bytes), (3) no delimiters or quotes — no commas, colons, braces, or quotation marks.

**Q: "How does Protobuf schema evolution work?"**
> Field numbers are the identity. Add new fields — old readers ignore unknown numbers. Remove fields — mark the number as `reserved` and never reuse it. Rename fields freely — binary uses numbers, not names. Never change a field's number — that breaks everything.

**Q: "What is gRPC?"**
> gRPC is Google's RPC framework using Protobuf for serialization and HTTP/2 for transport. It provides type-safe generated client/server stubs, supports streaming, and is replacing REST+JSON for internal service-to-service communication in data platforms.

**Q: "Can Kafka use Protobuf?"**
> Yes. Confluent Schema Registry supports Protobuf schemas alongside Avro. The wire format is the same — magic byte + 4-byte schema ID + binary payload. Use Protobuf when all consumers have compiled code and performance is critical. Use Avro when dynamic deserialization is needed.

---

## Key Takeaways

1. **Protobuf** = binary serialization with **numbered field IDs**. Smallest size, fastest serialization.
2. **Field numbers are sacred** — never change them, never reuse them. They are the binary identity.
3. **25–30% smaller** than Avro, **3x smaller** than JSON — varint encoding + no field names + no delimiters.
4. **Code generation required** — `.proto` compiled with `protoc` → type-safe, fast, but not self-describing.
5. **Renames are free** — binary doesn't use names. This is the opposite of Avro where renames need aliases.
6. **gRPC** = Protobuf + HTTP/2. Standard for inter-service communication, replacing REST+JSON.
7. **Thrift** is Protobuf's older cousin from Facebook — declining, mainly in legacy Hadoop (Hive Thrift Server).
8. **Kafka supports Protobuf** via Schema Registry — same wire format as Avro (magic byte + schema ID + payload).

---
