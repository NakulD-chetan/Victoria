# Gaps and Islands

Gaps and Islands identifies consecutive groups (islands) and missing sequences (gaps) in ordered data. An "island" is a streak of consecutive rows that belong together. A "gap" is a hole between two islands.

**DSA Analogy**: Interval merge problem — given a list of intervals, merge overlapping ones into continuous ranges. Also like finding consecutive subsequences in an array.

---

## Core Idea (2 Lines)

Assign a **group identifier** to consecutive rows using the difference between ROW_NUMBER and the actual value (or DENSE_RANK). Rows in the same consecutive streak share the same group ID. Then GROUP BY that ID to find island boundaries.

---

## The Core Technique: ROW_NUMBER Difference

The magic formula: if values are consecutive, `value - ROW_NUMBER()` is constant within each streak.

```
value:       1, 2, 3,    7, 8, 9, 10,    15, 16
row_number:  1, 2, 3,    4, 5, 6,  7,     8,  9
difference:  0, 0, 0,    3, 3, 3,  3,     7,  7
                         ↑                  ↑
                    new island          new island

Group by difference → 3 islands: [1-3], [7-10], [15-16]
```

**Why does this work?**

```
If values are consecutive:   val[i+1] = val[i] + 1
Row numbers are always:      rn[i+1]  = rn[i]  + 1
So:  (val - rn) stays constant within a streak.

When there's a gap, val jumps but rn only increments by 1,
so (val - rn) changes → new group.
```

---

## Pattern 1: Find Islands (Consecutive Ranges)

```sql
WITH numbered AS (
    SELECT val,
           val - ROW_NUMBER() OVER (ORDER BY val) AS grp
    FROM sequence_table
)
SELECT MIN(val) AS island_start,
       MAX(val) AS island_end,
       COUNT(*) AS island_length
FROM numbered
GROUP BY grp
ORDER BY island_start;
```

**Example with login dates:**

```sql
-- Find consecutive login streaks per user
WITH numbered AS (
    SELECT user_id, login_date,
           login_date - ROW_NUMBER() OVER (
               PARTITION BY user_id ORDER BY login_date
           ) * INTERVAL '1 day' AS grp
    FROM logins
)
SELECT user_id,
       MIN(login_date) AS streak_start,
       MAX(login_date) AS streak_end,
       COUNT(*) AS streak_days
FROM numbered
GROUP BY user_id, grp
ORDER BY user_id, streak_start;
```

```
user_id | login_date    user_id | streak_start | streak_end | streak_days
────────┼───────────    ────────┼──────────────┼────────────┼────────────
1       | 2024-01-01    1       | 2024-01-01   | 2024-01-03 | 3
1       | 2024-01-02    1       | 2024-01-05   | 2024-01-07 | 3
1       | 2024-01-03    1       | 2024-01-10   | 2024-01-10 | 1
1       | 2024-01-05
1       | 2024-01-06
1       | 2024-01-07
1       | 2024-01-10
```

---

## Pattern 2: Find Gaps (Missing Values)

```sql
WITH islands AS (
    SELECT val,
           LEAD(val) OVER (ORDER BY val) AS next_val
    FROM sequence_table
)
SELECT val + 1 AS gap_start,
       next_val - 1 AS gap_end
FROM islands
WHERE next_val - val > 1;
```

**Using LAG/LEAD for date gaps:**

```sql
-- Find gaps in daily data (missing dates)
SELECT login_date AS last_active,
       LEAD(login_date) OVER (ORDER BY login_date) AS next_active,
       LEAD(login_date) OVER (ORDER BY login_date) - login_date - 1 AS gap_days
FROM logins
WHERE LEAD(login_date) OVER (ORDER BY login_date) - login_date > 1;
```

---

## Pattern 3: Islands with Categories (Status Changes)

When consecutive rows share the same status/category:

```sql
-- Find periods where status remained the same
WITH status_groups AS (
    SELECT event_date, status,
           ROW_NUMBER() OVER (ORDER BY event_date) -
           ROW_NUMBER() OVER (PARTITION BY status ORDER BY event_date) AS grp
    FROM server_logs
)
SELECT status,
       MIN(event_date) AS period_start,
       MAX(event_date) AS period_end,
       COUNT(*) AS duration_days
FROM status_groups
GROUP BY status, grp
ORDER BY period_start;
```

**How the double ROW_NUMBER trick works:**

```
date  | status | rn_global | rn_per_status | diff (grp)
──────┼────────┼───────────┼───────────────┼───────
Jan 1 | UP     |     1     |      1        |   0
Jan 2 | UP     |     2     |      2        |   0     ← same group
Jan 3 | DOWN   |     3     |      1        |   2
Jan 4 | DOWN   |     4     |      2        |   2     ← same group
Jan 5 | UP     |     5     |      3        |   2     ← different group from first UP
Jan 6 | UP     |     6     |      4        |   2       (same diff=2, but status differs)

Group by (status, grp): UP(0)=[Jan1-2], DOWN(2)=[Jan3-4], UP(2)=[Jan5-6]
```

---

## Pattern 4: Session Detection (Activity Windows)

```sql
-- Group events into sessions (gap > 30 min = new session)
WITH flagged AS (
    SELECT user_id, event_time,
           CASE WHEN event_time - LAG(event_time) OVER (
               PARTITION BY user_id ORDER BY event_time
           ) > INTERVAL '30 minutes' THEN 1 ELSE 0 END AS new_session
    FROM events
),
sessions AS (
    SELECT user_id, event_time,
           SUM(new_session) OVER (
               PARTITION BY user_id ORDER BY event_time
           ) AS session_id
    FROM flagged
)
SELECT user_id, session_id,
       MIN(event_time) AS session_start,
       MAX(event_time) AS session_end,
       COUNT(*) AS events_in_session
FROM sessions
GROUP BY user_id, session_id;
```

**How it works:**

```
Step 1: Flag rows where gap from previous > threshold → 1 (new session), else 0
Step 2: Running SUM of flags → session ID (increments at each new session)
Step 3: GROUP BY session ID → session boundaries
```

---

## Pattern 5: Longest Streak

```sql
-- Find the user with the longest consecutive login streak
WITH numbered AS (
    SELECT user_id, login_date,
           login_date - ROW_NUMBER() OVER (
               PARTITION BY user_id ORDER BY login_date
           ) * INTERVAL '1 day' AS grp
    FROM logins
),
streaks AS (
    SELECT user_id, COUNT(*) AS streak_length
    FROM numbered
    GROUP BY user_id, grp
)
SELECT user_id, MAX(streak_length) AS longest_streak
FROM streaks
GROUP BY user_id
ORDER BY longest_streak DESC;
```

---

## Three Approaches Compared

| Approach | Technique | Best For |
|----------|-----------|----------|
| ROW_NUMBER difference | `val - ROW_NUMBER() OVER (ORDER BY val)` | Numeric/date sequences |
| Double ROW_NUMBER | `rn_global - rn_per_category` | Status/category changes |
| LAG + running SUM | Flag new groups, SUM flags for group ID | Custom gap thresholds (sessions) |

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Duplicate values in sequence | ROW_NUMBER skips, creating false gaps | DISTINCT first, or use DENSE_RANK |
| Date arithmetic issues | Dates don't subtract like integers in all DBs | Cast to integer or use DATEDIFF |
| Missing PARTITION BY | Streaks cross user boundaries | Add PARTITION BY user_id |
| Off-by-one in gap calculation | Gap starts at val+1, ends at next_val-1 | Verify boundary arithmetic |
| Not handling single-row islands | Islands of length 1 are valid | COUNT(*) = 1 is fine |

---

## Key Takeaway

> Gaps and Islands is the hardest pure-SQL pattern but follows one principle: **consecutive values produce a constant difference with ROW_NUMBER**. Use `val - ROW_NUMBER()` for numeric/date islands, double ROW_NUMBER for category-based islands, and `LAG + SUM flag` for custom-threshold sessions. GROUP BY the computed group ID to find island boundaries.
