# Design Google Docs — Tricks and Recognition

> **Permanent Recall:** OT = transform operations against concurrent ops (Google's approach). CRDT = data structure that auto-merges (Figma, Yjs). WebSocket for real-time sync. Snapshot + operation log for storage. This is the **hardest common design question** — shows senior-level thinking.

---

## Key Insights (Tricks)

| # | Insight | Why It Matters |
|---|---------|----------------|
| 1 | **OT = transform ops against concurrent ops** | Google Docs; server transforms so all clients converge |
| 2 | **CRDT = auto-merge data structure** | Figma, Yjs; no server needed; P2P, offline-friendly |
| 3 | **WebSocket for real-time sync** | Low latency, bidirectional; no polling |
| 4 | **Snapshot + operation log** | Fast load (snapshot); history (replay log); checkpoint to bound |
| 5 | **Hardest common design question** | Conflict resolution is nontrivial; senior/staff level |
| 6 | **Never last write wins** | Loses edits; instant red flag |
| 7 | **Presence separate from content** | Cursors are metadata; throttle; don't block ops |

---

## Recognition: What Problem Is This?

```
If they say: "Design Google Docs" / "Real-time collaborative editing"
They mean:  Multiple users edit same document; changes sync in real-time
They test:  Conflict resolution (OT/CRDT), WebSocket, consistency, scale

Core signal: "Collaborative" + "real-time" + "editing" = conflict resolution
```

---

## One-Liner Answers

| Question | One-Liner |
|----------|-----------|
| How handle concurrent edits? | OT or CRDT; transform/merge operations so they converge |
| What's OT? | Transform operations against each other so order doesn't matter; server applies and broadcasts |
| What's CRDT? | Data structure with merge rules; commutative; no server needed |
| Real-time sync? | WebSocket; ops flow client ↔ server; <100ms |
| Storage? | Snapshot (current state) + operation log (history); periodic checkpoint |
| Version history? | Replay operation log from snapshot |
| Offline? | Queue ops; sync on reconnect; server transforms (OT) or local merge (CRDT) |
| Cursor presence? | Separate channel; throttle to ~100–200ms; broadcast to session |

---

## Pattern Recognition

```
Google Docs / collaborative editor ≈ Conflict resolution (OT/CRDT)
                                    + Real-time (WebSocket)
                                    + Document storage (snapshot + log)
                                    + Presence (cursors)
                                    + Version history (replay)

Not:  Simple CRUD document storage
Not:  Chat (that's message ordering, not concurrent edit merge)
Not:  File sync (Dropbox-style; different conflict model)
```

---

## Mermaid: System Recognition

```mermaid
flowchart TD
    A[Collaborative Doc] --> B[Conflict Resolution]
    A --> C[Real-Time]
    A --> D[Storage]
    B --> E[OT or CRDT]
    C --> F[WebSocket]
    D --> G[Snapshot + Log]
    A --> H[Auxiliary]
    H --> I[Presence]
    H --> J[Version History]
    H --> K[Offline]
```

---

## Interview Shortcuts

1. **First sentence:** "The core challenge is conflict resolution — when two users type at the same position, we need OT or CRDT so we don't lose edits. I'll assume OT like Google Docs."
2. **OT:** "We transform concurrent operations so applying them in any order yields the same document. The server is the authority."
3. **Architecture:** "Client with local buffer → WebSocket → Collaboration Service that runs OT → Document Storage with snapshot and operation log."
4. **Storage:** "Snapshot for fast load; append-only operation log for history; periodic checkpoint to bound the log."
5. **Scale:** "Each document session can be on its own Collaboration Service instance; shard storage by doc_id."

---

## When to Mention Each Trick

| Context | Trick to Emphasize |
|---------|-------------------|
| "How do you design it?" | Conflict resolution first; OT or CRDT |
| "What if two people type at once?" | OT transforms; CRDT merges; never last write wins |
| "Real-time how?" | WebSocket; ops in <100ms |
| "How do you store it?" | Snapshot + operation log |
| "Version history?" | Replay log from snapshot |
| "Offline?" | Queue ops; sync; server transforms (OT) |
| "1000 concurrent editors?" | Throttle, batch; scale by doc; maybe CRDT for P2P |

---

## Combined Test Recognition

Collaborative doc = **Conflict resolution (OT/CRDT)** + **Real-time (WebSocket)** + **Persistence (snapshot + log)**. Interviewers want to see you understand the problem and the two main solutions, not implement them from scratch.

---

## Quick Wins to Mention

- **Block-level model:** Simpler than char-level; paragraphs as units
- **Throttle presence:** Don't send cursor on every mousemove
- **Batch ops:** Group keystrokes for 50–100ms before sending
- **Permission check:** Before accepting op, verify user has edit access
- **Sequence numbers:** Order ops; handle reordering from network

---

## Differentiation from Other Designs

| vs Chat | vs File Sync (Dropbox) | vs Shared Whiteboard (Miro) |
|---------|------------------------|------------------------------|
| Chat: message ordering; no concurrent edit of same content | File sync: whole-file merge; different conflict model | Whiteboard: similar (OT/CRDT); different primitives (shapes vs text) |
| Collaborative doc: character/block-level merge | Doc: operation-level merge | Same family of problems |

---

## Recap: 7 Tricks

1. **OT** — Transform ops; Google's approach
2. **CRDT** — Auto-merge; Figma, Yjs
3. **WebSocket** — Real-time sync
4. **Snapshot + log** — Storage and history
5. **Hardest common question** — Senior/staff signal
6. **Never last write wins** — Core rule
7. **Presence separate** — Throttle cursor updates

---

## Final Recognition

When you hear "Design Google Docs" or "real-time collaborative editing," think: **conflict resolution** (OT or CRDT), **WebSocket**, **snapshot + operation log**, **presence**, **version history**. The conflict resolution is the differentiator — nail that first.

---

## Memory Hook

"**OTC** — OT or CRDT for conflict. **WSL** — WebSocket, Snapshot, Log." Repeat when starting the design.
