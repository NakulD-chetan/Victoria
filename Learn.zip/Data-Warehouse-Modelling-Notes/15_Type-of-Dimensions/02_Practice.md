# Types of Dimensions — Practice

> "Dimensions tell the story around the numbers—name each role clearly."

---

## Quick Recall

**Q: What is a conformed dimension?**  
A: Identical or subset-compatible dimension used across multiple facts so metrics drill across processes consistently.

**Q: What is a role-playing dimension?**  
A: One physical dimension, multiple foreign keys on a fact with different semantic roles (e.g., order vs ship date).

**Q: What is a junk dimension?**  
A: Combined low-cardinality flags and codes (payment type + channel + device) to reduce fact width and sparse keys.

**Q: What is a degenerate dimension?**  
A: Operational identifier stored on the fact without a separate table (e.g., `order_number`).

**Q: Why not put every flag in junk?**  
A: If a flag is high-cardinality or slowly changing with business rules, it deserves its own dimension or SCD treatment.

---

## Interview Questions

**1. Give a retail conformed dimension example.**  
Say: `dim_store` shared by `fact_sales`, `fact_inventory_daily`, and `fact_labor_hours` so same-store analysis aligns on store attributes.

**2. Implement role-playing for ship vs delivery dates.**  
Say: Two integer keys on `fact_shipment_line` referencing `dim_date`; in the semantic layer, label joins as Ship Date and Delivery Date pointing to the same table.

**3. Design a junk dimension for checkout.**  
Say: Attributes like `payment_method`, `checkout_device`, `loyalty_scan_flag`, `gift_wrap_flag`—cardinality product stays small; build maintenance ETL to append unseen combinations.

**4. When is degenerate preferred over `dim_order`?**  
Say: When order header attributes are few and slowly changing and you want fast order-number grouping without another join—large header attributes may still warrant `dim_order`.

**5. Junk vs factless fact?**  
Say: Junk collapses orthogonal flags onto one key; factless facts represent occurrences or relationships, not just descriptive bundles.

**6. Conformed subset example.**  
Say: Corporate `dim_product` with 200 attributes; store inventory mart uses a subset view with identical keys for shared SKUs.

**7. Risk of overusing junk dimensions?**  
Say: Exploding combinations and stale rows if rare combos are not refreshed—monitor cardinality and usage.

---

## Scenario-Based Exercises

**Scenario 1 — Conformed customer**  
Web and store sales share customer.  
**Solution:** Single `dim_customer` with `customer_key`; web facts include `guest_session` bridge if identity resolution is partial—document unmatched members.

**Scenario 2 — Junk dimension maintenance**

```sql
INSERT INTO dw.dim_checkout_junk (
    payment_method, checkout_device, loyalty_scan_flag, gift_wrap_flag
)
SELECT DISTINCT
    s.payment_method,
    s.checkout_device,
    s.loyalty_scan_flag,
    s.gift_wrap_flag
FROM stg.order_line s
LEFT JOIN dw.dim_checkout_junk j
    ON j.payment_method = s.payment_method
   AND j.checkout_device = s.checkout_device
   AND j.loyalty_scan_flag = s.loyalty_scan_flag
   AND j.gift_wrap_flag = s.gift_wrap_flag
WHERE j.checkout_junk_key IS NULL;
```

**Scenario 3 — Degenerate keys on `fact_order_line`**  
Columns: `order_id`, `order_line_id`, measures for revenue and cost.  
**Solution:** Keep `order_id` degenerate for operational drill; `dim_date` for `order_date_key`; line type in `dim_line_type` if cardinality grows.

**Scenario 4 — Role-playing store**  
Ship-from vs sold-in store for buy-online-pick-up-in-store orders.  
**Solution:** `fulfilling_store_key` and `selling_store_key` both to `dim_store`; attributes clarify omnichannel reporting.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Duplicate customer tables per mart | Breaks conformation | One hub dimension or strict subsets |
| Same date dimension, unclear roles | Users pick wrong join | Semantic layer labels + modeling docs |
| Junk for high-cardinality payment tokens | Key explosion | Hash or tokenize; separate secure dim |
| Degenerate for 50 order attributes | Unmaintainable wide facts | Promote to `dim_order` |

---

## One-Liner Answers

- Conformed dimensions are the glue for integrated retail metrics across facts.
- Role-playing reuses one dimension table with multiple foreign keys and aliases.
- Junk dimensions bundle many low-cardinality flags into one surrogate key.
- Degenerate dimensions keep stable transaction IDs on the fact table itself.
- Choose junk when combinations are manageable and flags are mostly static.
- Conformation is about compatible keys and attributes, not identical column counts.
