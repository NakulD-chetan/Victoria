# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. WHAT IS SCD (SLOWLY CHANGING DIMENSION)
==================================================

Key idea:
- Dimension data changes over time
- We must decide:
  → keep history OR
  → overwrite data


----------------------------------------
Meaning
----------------------------------------

Slowly:
- Changes are not frequent (like product category)

Changing:
- Attributes change over time

Dimension:
- Context table (customer, product, store)


----------------------------------------
Important Insight
----------------------------------------

Fact data changes frequently  
Dimension changes slowly



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

SCD defines:
- How to handle changes in dimension

Important:
- Different attributes → different rules


----------------------------------------
Example
----------------------------------------

Customer:
- name change → maybe overwrite  
- address change → keep history  



==================================================
3. WHY SCD IS NEEDED
==================================================

----------------------------------------
Problem
----------------------------------------

Customer moved city:

Old:
City = Mumbai  

New:
City = Pune  


----------------------------------------
Question
----------------------------------------

Old sales:
- Should they show Mumbai OR Pune?


----------------------------------------
Answer depends on SCD type



==================================================
4. SCD TYPE 0 (NO CHANGE)
==================================================

Definition:
- Never update value


----------------------------------------
Example
----------------------------------------

signup_date


----------------------------------------
Meaning
----------------------------------------
- Once set → never change


----------------------------------------
Use case
----------------------------------------
- Legal or audit fields



==================================================
5. SCD TYPE 1 (OVERWRITE)
==================================================

Definition:
- Replace old value with new value


----------------------------------------
Example
----------------------------------------

Customer name correction


----------------------------------------
Result
----------------------------------------
- Old value lost


----------------------------------------
Pros
----------------------------------------
- Simple


----------------------------------------
Cons
----------------------------------------
- No history



==================================================
6. SCD TYPE 2 (VERY IMPORTANT)
==================================================

Definition:
- Create new row for every change
- Keep old data


----------------------------------------
Example
----------------------------------------

Customer moves city


----------------------------------------
Before
----------------------------------------

customer_key = 1  
city = Mumbai  


----------------------------------------
After
----------------------------------------

Row 1:
customer_key = 1  
city = Mumbai  
end_date = 2023  

Row 2:
customer_key = 2  
city = Pune  
current_flag = Y  


----------------------------------------
Important Columns
----------------------------------------

- effective_date  
- end_date  
- current_flag  


----------------------------------------
Key Insight
----------------------------------------

Each change = new surrogate key



==================================================
7. SCD TYPE 2 (TIMELINE)
==================================================

TIME →

Old record (Mumbai) → closed  
New record (Pune) → active  


----------------------------------------
Important Rule
----------------------------------------
No overlap in dates



==================================================
8. SCD TYPE 3
==================================================

Definition:
- Store limited history in same row


----------------------------------------
Example
----------------------------------------

current_city = Pune  
previous_city = Mumbai  


----------------------------------------
Limitation
----------------------------------------
- Only one history value



==================================================
9. HYBRID TYPES (ADVANCED)
==================================================

Types:
- Type 4
- Type 5
- Type 6
- Type 7


----------------------------------------
Meaning
----------------------------------------
- Combination of approaches


----------------------------------------
Important Note
----------------------------------------
Not standardized



==================================================
10. SCD AND SURROGATE KEY
==================================================

Very important connection:

----------------------------------------
Type 2
----------------------------------------

- Each version → new surrogate key


----------------------------------------
Fact table stores:
----------------------------------------

- correct version key


----------------------------------------
Meaning
----------------------------------------

Fact joins correct history



==================================================
11. POINT-IN-TIME JOIN (IMPORTANT)
==================================================

Goal:
- Get correct dimension data at time of fact


----------------------------------------
Correct way
----------------------------------------

Fact stores surrogate key


----------------------------------------
Wrong way
----------------------------------------

Join using business key + date range


----------------------------------------
Why wrong?
----------------------------------------

- Slow
- Complex



==================================================
12. ETL PROCESS FOR SCD TYPE 2
==================================================

Steps:

1. Detect change  
2. Close old record  
3. Insert new record  
4. Update current_flag  


----------------------------------------
Important Rule
----------------------------------------
Only update changed records



==================================================
13. REAL EXAMPLES
==================================================

----------------------------------------
Customer
----------------------------------------
- Address change → Type 2


----------------------------------------
Product
----------------------------------------
- Category change → Type 2


----------------------------------------
Store
----------------------------------------
- Format change → Type 2



==================================================
14. COMMON MISTAKES
==================================================

----------------------------------------
1. Using Type 1 everywhere
----------------------------------------
Problem:
- Lose history

Fix:
- Use Type 2 where needed


----------------------------------------
2. Missing current_flag
----------------------------------------
Problem:
- Hard to filter

Fix:
- Add flag


----------------------------------------
3. Overlapping dates
----------------------------------------
Problem:
- Duplicate joins

Fix:
- Validate ranges


----------------------------------------
4. Using business key in fact
----------------------------------------
Problem:
- Wrong history

Fix:
- Use surrogate key


----------------------------------------
5. Tracking too many columns
----------------------------------------
Problem:
- Large dimension

Fix:
- Track only important fields



==================================================
15. FINAL TAKEAWAY
==================================================

SCD controls:
- how history is stored


----------------------------------------
Golden Rule
----------------------------------------

Choose SCD type based on business need


----------------------------------------
Key Insight
----------------------------------------

Type 2 = most important


----------------------------------------
Goal
----------------------------------------

Ensure:
- correct historical reporting
- accurate analysis



==================================================
16. QUICK MEMORY SUMMARY
==================================================

Type 0:
- no change

Type 1:
- overwrite

Type 2:
- full history (new row)

Type 3:
- limited history

Rule:
- facts must store surrogate key

Goal:
- correct point-in-time analysis