import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  for (let i = 0; i < n - 1; i++) {
    let minIdx = i;
    steps.push({ type: 'start-scan', i, minIdx, array: [...a] });
    for (let j = i + 1; j < n; j++) {
      steps.push({ type: 'compare', i, j, minIdx, array: [...a] });
      if (a[j] < a[minIdx]) { minIdx = j; steps.push({ type: 'new-min', i, minIdx, array: [...a] }); }
    }
    if (minIdx !== i) {
      [a[i], a[minIdx]] = [a[minIdx], a[i]];
      steps.push({ type: 'swap', i, j: minIdx, array: [...a] });
    }
    steps.push({ type: 'placed', i, array: [...a] });
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 20) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function SelectionSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    for (let k = 0; k < step.i; k++) colors[k] = 'sorted';
    if (step.type === 'compare') {
      colors[step.j] = 'compare'; colors[step.minIdx] = 'pivot';
      store.incComparisons();
    } else if (step.type === 'new-min') {
      colors[step.minIdx] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `New min at [${step.minIdx}]` });
    } else if (step.type === 'swap') {
      colors[step.i] = 'swap'; colors[step.j] = 'swap';
      store.incSwaps();
      canvasRef.current?.addAnim('swap', { i: step.i, j: step.j }, 300);
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Swap [${step.i}] ↔ [${step.j}]` });
    } else if (step.type === 'placed') {
      colors[step.i] = 'sorted';
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
