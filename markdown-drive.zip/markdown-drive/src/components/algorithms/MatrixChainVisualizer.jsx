import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(dims) {
  const n = dims.length - 1;
  const dp = Array.from({ length: n }, () => Array(n).fill(null));
  const steps = [];
  const labels = Array.from({ length: n }, (_, i) => `${i + 1}`);

  const snap = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: dp.map((row) => row.map((v) => v)),
      rowLabels: labels,
      colLabels: labels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('Matrix chain DP: fill diagonals by chain length', {}, null, []);

  for (let len = 1; len <= n; len += 1) {
    for (let i = 0; i <= n - len; i += 1) {
      const j = i + len - 1;
      if (i === j) {
        dp[i][j] = 0;
        snap(`Length-1 chain (${i + 1},${j + 1}): cost 0`, { [`${i}-${j}`]: 'optimal' }, [i, j], []);
        continue;
      }
      let best = Infinity;
      for (let k = i; k < j; k += 1) {
        const cost = dp[i][k] + dp[k + 1][j] + dims[i] * dims[k + 1] * dims[j + 1];
        const colors = {
          [`${i}-${j}`]: 'current',
          [`${i}-${k}`]: 'filled',
          [`${k + 1}-${j}`]: 'filling',
        };
        const arrows = [
          { from: [i, k], to: [i, j] },
          { from: [k + 1, j], to: [i, j] },
        ];
        snap(`Split at k=${k}: mult ${dims[i]}×${dims[k + 1]}×${dims[j + 1]}`, colors, [i, j], arrows);
        best = Math.min(best, cost);
      }
      dp[i][j] = best;
      snap(`m[${i + 1},${j + 1}] = ${best}`, { [`${i}-${j}`]: 'optimal' }, [i, j], []);
    }
  }

  snap(`Optimal parenthesization cost = ${dp[0][n - 1]}`, { [`0-${n - 1}`]: 'optimal' }, [0, n - 1], []);
  return steps;
}

export default function MatrixChainVisualizer({ config }) {
  const dims = [2, 3, 4, 5];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(dims);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Dims [${dims.join(' × ')}]` });
    canvasRef.current?.setState({
      table: [[null]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      items: [`dims: ${dims.join(', ')}`],
      caption: 'Matrix chain multiplication',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[null]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      items: [`dims: ${dims.join(', ')}`],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
