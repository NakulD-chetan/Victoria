# Aggregates and GROUP BY — Common Mistakes

| Mistake | Fix |
|---------|-----|
| `SELECT` non-aggregated column not in `GROUP BY` | Add to `GROUP BY` or wrap in `ANY_VALUE`/aggregate |
| Filtering aggregate in `WHERE` | `HAVING` |
| `SUM` after one-to-many join without care | Pre-aggregate or `SUM(DISTINCT …)` rarely correct — fix grain |
| Using `AVG` on rate | Often need **weighted** avg — `SUM(num)/SUM(den)` |

---

*Next: [[06_Edge-Cases]]*
