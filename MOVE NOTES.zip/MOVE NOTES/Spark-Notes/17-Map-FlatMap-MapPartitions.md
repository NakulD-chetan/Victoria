# map(), flatMap(), and mapPartitions()

These are three transformation functions that process data differently. Understanding when to use each one is important for writing efficient Spark code.

---

## 1. map() — One Input → One Output

`map()` applies a function to **each element** and returns exactly **one output per input**.

### How It Works
```
Input:  [1, 2, 3]
Function: x → x * 2
Output: [2, 4, 6]
```

### Example
```python
# RDD
rdd = sc.parallelize([1, 2, 3, 4])
result = rdd.map(lambda x: x * 2)
# Output: [2, 4, 6, 8]

# DataFrame (equivalent using withColumn)
df = df.withColumn("doubled", col("value") * 2)
```

### When to Use
- Simple row-by-row transformations
- Each row produces exactly one output row
- Math operations, type conversions, adding columns

---

## 2. flatMap() — One Input → Zero or Many Outputs

`flatMap()` is like `map()`, but each input can produce **zero, one, or multiple** outputs. The results are **flattened** into a single list.

### How It Works
```
Input:  ["hello world", "spark"]
Function: line → line.split(" ")
Output: ["hello", "world", "spark"]   (flattened!)
```

### Example
```python
# RDD
rdd = sc.parallelize(["hello world", "apache spark"])
result = rdd.flatMap(lambda line: line.split(" "))
# Output: ["hello", "world", "apache", "spark"]

# Compare with map():
result_map = rdd.map(lambda line: line.split(" "))
# Output: [["hello", "world"], ["apache", "spark"]]  (nested lists!)
```

### When to Use
- Splitting rows into multiple rows (exploding)
- Text processing (splitting lines into words)
- One-to-many transformations
- Filtering within the function (return empty list to skip rows)

### map vs flatMap Visual

```
map():
  "hello world" → ["hello", "world"]     (keeps as list)
  "spark"       → ["spark"]              (keeps as list)
  Result: [["hello", "world"], ["spark"]]  ← nested

flatMap():
  "hello world" → "hello", "world"       (flattened)
  "spark"       → "spark"                (flattened)
  Result: ["hello", "world", "spark"]     ← flat
```

---

## 3. mapPartitions() — Process Entire Partition at Once

`mapPartitions()` applies a function **once per partition** instead of once per row. You receive an **iterator** of all rows in the partition and return an iterator of results.

### How It Works
```
Partition 0: [row1, row2, row3]  → function(iterator) → [result1, result2, result3]
Partition 1: [row4, row5, row6]  → function(iterator) → [result4, result5, result6]
```

### Key Difference from map()
- `map()`: function called N times (once per row)
- `mapPartitions()`: function called P times (once per partition)

### Example: Database Connection
```python
# BAD: Opens DB connection for EVERY ROW
def enrich_row(row):
    conn = connect_to_db()        # Expensive! Called per row
    result = conn.query(row.id)
    conn.close()
    return result

rdd.map(enrich_row)  # If 1 million rows → 1 million DB connections!

# GOOD: Opens DB connection ONCE PER PARTITION
def enrich_partition(iterator):
    conn = connect_to_db()        # Called once per partition
    results = []
    for row in iterator:
        result = conn.query(row.id)
        results.append(result)
    conn.close()
    return iter(results)

rdd.mapPartitions(enrich_partition)  # If 200 partitions → only 200 connections
```

### When to Use
- **Expensive setup operations** — DB connections, API clients, model loading
- **Bulk processing** — batch API calls instead of one-by-one
- **Performance-critical code** — fewer function calls = less overhead
- Loading ML models (load once per partition, predict on all rows)

### Caveat
The entire partition's data must fit in memory since `mapPartitions` processes all rows at once. For very large partitions, this could cause OOM. In that case, process the iterator lazily:

```python
def process_partition(iterator):
    conn = connect_to_db()
    for row in iterator:       # Process one at a time (lazy)
        yield transform(row)   # Use yield, not append to list
    conn.close()
```

---

## Quick Comparison

| Feature          | map()                | flatMap()              | mapPartitions()           |
|------------------|----------------------|------------------------|---------------------------|
| Input → Output   | 1 → 1                | 1 → 0 or many          | All rows → All results    |
| Function called  | Once per row         | Once per row           | Once per partition        |
| Result shape     | Same count as input  | Can be more or fewer   | Depends on function       |
| Overhead         | Higher (per-row call)| Higher (per-row call)  | Lower (per-partition)     |
| Use case         | Simple transforms    | Exploding / splitting  | Expensive setup (DB, API) |

---

## Key Takeaway

> `map()` = one-to-one, simple row transformations.
> `flatMap()` = one-to-many, splits/explodes rows.
> `mapPartitions()` = process entire partition at once, fewer function calls, ideal for expensive setup like DB connections or model loading.
