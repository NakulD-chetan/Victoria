import { memo, useState, useCallback, useRef, useEffect } from 'react';

export const COLORS = [
  '#6965db', '#10a37f', '#f59e0b', '#ef4444', '#3b82f6',
  '#ec4899', '#8b5cf6', '#14b8a6', '#f97316', '#06b6d4',
];

function TreeLevel({ folder, color, expandedSubs, toggleSub, onFolderClick, onFileClick }) {
  const children = folder.children || [];
  const files = folder.files || [];

  if (children.length > 0) {
    return (
      <div className="subtree">
        <div className="subtree__trunk" style={{ background: color }} />
        {children.length > 1 && <div className="subtree__rail" />}
        <div className="subtree__grid">
          {children.map((child, ci) => {
            const cPath = child.path || child.name;
            const isOpen = expandedSubs.has(cPath);
            const hasChildren = child.children?.length > 0;
            const hasFiles = child.files?.length > 0;
            const total = (child.fileCount || 0) + (child.children?.length || 0);
            return (
              <div key={cPath} data-branch={cPath} className={`subtree__branch ${isOpen ? 'subtree__branch--expanded' : ''}`}>
                <div className="subtree__stem" style={{ background: color }} />
                <button
                  className={`snode ${isOpen ? 'snode--open' : ''}`}
                  style={{ '--scolor': color }}
                  onClick={() => {
                    if (hasChildren || hasFiles) toggleSub(cPath);
                    else onFolderClick?.(cPath);
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" style={{ flexShrink: 0 }}>
                    <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
                  </svg>
                  <span className="snode__name">{child.name}</span>
                  {total > 0 && <span className="snode__badge">{total}</span>}
                  {(hasChildren || hasFiles) && (
                    <svg className="snode__chevron" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  )}
                </button>

                {isOpen && hasChildren && (
                  <TreeLevel
                    folder={child}
                    color={color}
                    expandedSubs={expandedSubs}
                    toggleSub={toggleSub}
                    onFolderClick={onFolderClick}
                    onFileClick={onFileClick}
                  />
                )}

                {isOpen && !hasChildren && hasFiles && (
                  <div className="subtree__filelist">
                    {child.files.map((file, fi) => (
                      <button
                        key={file.name}
                        className="fnode"
                        style={{ '--d': `${fi * 0.025}s`, '--color': color }}
                        onClick={(e) => onFileClick?.(cPath, file.name, e)}
                      >
                        <span className="fnode__dot" />
                        <span className="fnode__name">{file.title || file.name}</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {files.length > 0 && (
          <div className="subtree__filelist subtree__filelist--root">
            {files.map((file, fi) => (
              <button
                key={file.name}
                className="fnode"
                style={{ '--d': `${fi * 0.025}s`, '--color': color }}
                onClick={(e) => onFileClick?.(folder.path || folder.name, file.name, e)}
              >
                <span className="fnode__dot" />
                <span className="fnode__name">{file.title || file.name}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (files.length > 0) {
    return (
      <div className="subtree__filelist">
        {files.map((file, fi) => (
          <button
            key={file.name}
            className="fnode"
            style={{ '--d': `${fi * 0.025}s`, '--color': color }}
            onClick={(e) => onFileClick?.(folder.path || folder.name, file.name, e)}
          >
            <span className="fnode__dot" />
            <span className="fnode__name">{file.title || file.name}</span>
          </button>
        ))}
      </div>
    );
  }

  return null;
}

const WelcomeScreen = memo(function WelcomeScreen({
  folders = [], onFolderClick, onFileClick,
  user, onTreeStateChange,
}) {
  const [expandedFolder, setExpandedFolder] = useState(null);
  const [expandedSubs, setExpandedSubs] = useState(new Set());
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [dragging, setDragging] = useState(false);
  const lastPt = useRef({ x: 0, y: 0 });
  const canvasRef = useRef(null);
  const treeRef = useRef(null);
  const zoomRef = useRef(1);
  const zoomTargetRef = useRef(null);
  const [diving, setDiving] = useState(false);

  useEffect(() => { zoomRef.current = zoom; }, [zoom]);

  useEffect(() => {
    onTreeStateChange?.(expandedFolder);
  }, [expandedFolder, onTreeStateChange]);

  const toggleSub = useCallback((path) => {
    setExpandedSubs(prev => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
        zoomTargetRef.current = next.size === 1 ? [...next][0] : expandedFolder;
      } else {
        const parentPath = path.includes('/') ? path.substring(0, path.lastIndexOf('/')) : '';
        for (const existing of prev) {
          const ep = existing.includes('/') ? existing.substring(0, existing.lastIndexOf('/')) : '';
          if (ep === parentPath && existing !== path) next.delete(existing);
        }
        next.add(path);
        zoomTargetRef.current = path;
      }
      return next;
    });
  }, [expandedFolder]);

  const fitToScreen = useCallback(() => {
    const tree = treeRef.current;
    const container = canvasRef.current;
    if (!tree || !container) return;

    const rect = tree.getBoundingClientRect();
    const cur = zoomRef.current || 1;
    const naturalW = rect.width / cur;
    const naturalH = rect.height / cur;
    const containerW = container.clientWidth;
    const containerH = container.clientHeight;

    if (naturalW < 50 || naturalH < 50 || containerW < 50 || containerH < 50) return;

    const pad = 80;
    const fit = Math.min(
      (containerW - pad) / naturalW,
      (containerH - pad) / naturalH,
      1.6
    );

    const newZ = Math.max(0.25, fit);
    setZoom(newZ);
    zoomRef.current = newZ;
    setPan({ x: 0, y: 0 });
  }, []);

  const zoomToBranch = useCallback((targetPath) => {
    const tree = treeRef.current;
    const container = canvasRef.current;
    if (!tree || !container || !targetPath) { fitToScreen(); return; }

    let targetEl = null;
    const allBranches = tree.querySelectorAll('[data-branch]');
    for (const el of allBranches) {
      if (el.dataset.branch === targetPath) { targetEl = el; break; }
    }
    if (!targetEl) { fitToScreen(); return; }

    const cur = zoomRef.current || 1;
    const treeRect = tree.getBoundingClientRect();
    const targetRect = targetEl.getBoundingClientRect();
    const containerW = container.clientWidth;
    const containerH = container.clientHeight;

    if (targetRect.width < 2 || targetRect.height < 2) { fitToScreen(); return; }

    const targetW = targetRect.width / cur;
    const targetH = targetRect.height / cur;

    const screenDx = (targetRect.left + targetRect.width / 2) - (treeRect.left + treeRect.width / 2);
    const screenDy = (targetRect.top + targetRect.height / 2) - (treeRect.top + treeRect.height / 2);
    const ndx = screenDx / cur;
    const ndy = screenDy / cur;

    const padX = 60;
    const padY = 40;
    const availW = containerW - padX;
    const availH = containerH - padY;
    const zW = availW / Math.max(targetW, 80);
    const zH = availH / Math.max(targetH, 50);
    const fitZ = Math.min(zW, zH);
    const z = Math.max(0.3, Math.min(fitZ, 2.8));

    setZoom(z);
    zoomRef.current = z;
    setPan({ x: -ndx * z, y: -ndy * z });
  }, [fitToScreen]);

  useEffect(() => {
    let cancelled = false;
    const target = zoomTargetRef.current;

    const doZoom = () => {
      if (cancelled) return;
      if (target) zoomToBranch(target);
      else fitToScreen();
    };

    const t1 = setTimeout(() => {
      if (cancelled) return;
      requestAnimationFrame(() => {
        if (cancelled) return;
        requestAnimationFrame(() => doZoom());
      });
    }, 100);

    const t2 = setTimeout(() => {
      if (cancelled) return;
      requestAnimationFrame(() => {
        if (cancelled) return;
        requestAnimationFrame(() => doZoom());
      });
    }, 600);

    return () => { cancelled = true; clearTimeout(t1); clearTimeout(t2); };
  }, [expandedFolder, expandedSubs, folders.length, fitToScreen, zoomToBranch]);

  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(() => {
        const target = zoomTargetRef.current;
        if (target) zoomToBranch(target);
        else fitToScreen();
      });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, [fitToScreen, zoomToBranch]);

  const handleWheel = useCallback((e) => {
    e.preventDefault();
    setZoom(z => Math.min(2, Math.max(0.2, z - e.deltaY * 0.001)));
  }, []);

  useEffect(() => {
    const el = canvasRef.current;
    if (!el) return;
    el.addEventListener('wheel', handleWheel, { passive: false });
    return () => el.removeEventListener('wheel', handleWheel);
  }, [handleWheel]);

  const onPointerDown = useCallback((e) => {
    if (e.target.closest('button')) return;
    setDragging(true);
    lastPt.current = { x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  }, []);

  const onPointerMove = useCallback((e) => {
    if (!dragging) return;
    const dx = e.clientX - lastPt.current.x;
    const dy = e.clientY - lastPt.current.y;
    lastPt.current = { x: e.clientX, y: e.clientY };
    setPan(p => ({ x: p.x + dx, y: p.y + dy }));
  }, [dragging]);

  const onPointerUp = useCallback(() => setDragging(false), []);

  const handleFileClick = useCallback((folderPath, fileName, e) => {
    if (diving) return;
    setDiving(true);

    const btn = e?.currentTarget;
    const sourceRect = btn ? btn.getBoundingClientRect() : null;
    const label = btn?.querySelector('.fnode__name')?.textContent || fileName;
    const color = btn ? getComputedStyle(btn).getPropertyValue('--color').trim() : null;

    onFileClick?.(folderPath, fileName, sourceRect, label, color);
    setTimeout(() => setDiving(false), 500);
  }, [onFileClick, diving]);

  const expanded = expandedFolder
    ? folders.find(f => (f.path || f.name) === expandedFolder)
    : null;

  return (
    <div
      className="welcome"
      ref={canvasRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
      style={{ cursor: dragging ? 'grabbing' : 'grab' }}
    >
      <div className="zoom-ctrl">
        <button onClick={() => setZoom(z => Math.min(2, z + 0.15))} title="Zoom in">+</button>
        <span className="zoom-ctrl__level">{Math.round(zoom * 100)}%</span>
        <button onClick={() => setZoom(z => Math.max(0.2, z - 0.15))} title="Zoom out">−</button>
        <button onClick={fitToScreen} title="Fit to screen" className="zoom-ctrl__reset">⊡</button>
      </div>

      <div
        className={`tree ${diving ? 'tree--diving' : ''}`}
        ref={treeRef}
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}
      >
        <div className="tree__root">
          <div className="tree__logo">
            <svg width="60" height="60" viewBox="0 0 100 100" fill="none">
              <defs>
                <linearGradient id="wg" x1="0.15" y1="0.1" x2="0.85" y2="0.9">
                  <stop offset="0%" stopColor="#6366F1" />
                  <stop offset="100%" stopColor="#10B981" />
                </linearGradient>
                {user?.photoURL && (
                  <clipPath id="dropClip">
                    <path d="M50 18 C50 18 72 42 72 56 C72 66 62 75 50 75 C38 75 28 66 28 56 C28 42 50 18 50 18Z" />
                  </clipPath>
                )}
              </defs>
              <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#wg)" />
              {user?.photoURL ? (
                <image href={user.photoURL} x="22" y="18" width="56" height="62" clipPath="url(#dropClip)" preserveAspectRatio="xMidYMid slice" />
              ) : (
                <>
                  <rect x="35" y="49" width="30" height="2.5" rx="1.25" fill="white" opacity="0.92" />
                  <rect x="35" y="59" width="22" height="2.5" rx="1.25" fill="white" opacity="0.65" />
                </>
              )}
            </svg>
          </div>
          <span className="tree__root-label">{user?.name ? `${user.name.split(' ')[0]}'s InkDrop` : 'INKDROP'}</span>
        </div>

        {folders.length > 0 && <div className="tree__trunk" />}
        {folders.length > 0 && <div className="tree__rail" />}

        <div className="tree__grid">
          {folders.map((f, i) => {
            const color = COLORS[i % COLORS.length];
            const fPath = f.path || f.name;
            const isOpen = expandedFolder === fPath;
            const totalItems = f.fileCount + (f.children?.length || 0);
            return (
              <div key={fPath} data-branch={fPath} className={`tree__branch ${isOpen ? 'tree__branch--expanded' : ''}`} style={{ '--color': color, '--i': i }}>
                <div className="tree__stem" />

                <button
                  className={`tnode ${isOpen ? 'tnode--open' : ''}`}
                  onClick={() => {
                    const next = expandedFolder === fPath ? null : fPath;
                    setExpandedFolder(next);
                    setExpandedSubs(new Set());
                    zoomTargetRef.current = next;
                  }}
                >
                  <span className="tnode__dot" />
                  <span className="tnode__name">{f.name}</span>
                  <span className="tnode__badge">{totalItems}</span>
                  <svg className="tnode__chevron" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="6 9 12 15 18 9" />
                  </svg>
                </button>

                {isOpen && expanded && (
                  <TreeLevel
                    folder={expanded}
                    color={color}
                    expandedSubs={expandedSubs}
                    toggleSub={toggleSub}
                    onFolderClick={onFolderClick}
                    onFileClick={handleFileClick}
                  />
                )}
              </div>
            );
          })}
        </div>

        {!folders.length && (
          <p className="tree__empty">Drop your markdown, start reading</p>
        )}

        <div className="tree__features">
          <button
            className="tree__feature-card tree__feature-card--canvas"
            onClick={(e) => {
              e.stopPropagation();
              window.history.pushState(null, '', '/new-canvas');
              window.dispatchEvent(new PopStateEvent('popstate'));
            }}
          >
            <div className="tree__feature-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="3" y="3" width="18" height="18" rx="3" />
                <path d="M8 9l-2 3 2 3" />
                <path d="M16 9l2 3-2 3" />
                <path d="M13.5 7l-3 10" />
              </svg>
            </div>
            <div className="tree__feature-info">
              <span className="tree__feature-title">Canvas Studio</span>
              <span className="tree__feature-desc">Sketch, code, inspect data, and build with LocalAgent</span>
            </div>
            <svg className="tree__feature-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>

          <button
            className="tree__feature-card tree__feature-card--algo"
            onClick={(e) => {
              e.stopPropagation();
              window.history.pushState(null, '', '/algorithms');
              window.dispatchEvent(new PopStateEvent('popstate'));
            }}
          >
            <div className="tree__feature-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
              </svg>
            </div>
            <div className="tree__feature-info">
              <span className="tree__feature-title">Algorithms</span>
              <span className="tree__feature-desc">Visualize & learn algorithms step by step</span>
            </div>
            <svg className="tree__feature-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>

          <button
            className="tree__feature-card tree__feature-card--problems"
            onClick={(e) => {
              e.stopPropagation();
              window.history.pushState(null, '', '/systemdesign');
              window.dispatchEvent(new PopStateEvent('popstate'));
            }}
          >
            <div className="tree__feature-icon">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <rect x="2" y="3" width="20" height="14" rx="2" ry="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
              </svg>
            </div>
            <div className="tree__feature-info">
              <span className="tree__feature-title">System Design</span>
              <span className="tree__feature-desc">Build & test system architectures interactively</span>
            </div>
            <svg className="tree__feature-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="9 18 15 12 9 6" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
});

export default WelcomeScreen;
