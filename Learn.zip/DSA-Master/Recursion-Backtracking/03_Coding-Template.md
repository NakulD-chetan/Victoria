# Recursion-Backtracking — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.**

---

## Template 1: Subsets (Power Set)

**Decision:** Include or exclude each element. Index-based to avoid duplicates.

### Python
```python
def subsets(nums):
    result = []
    path = []
    
    def backtrack(start):
        result.append(path[:])  # base: every path is a subset
        for i in range(start, len(nums)):
            path.append(nums[i])   # CHOOSE
            backtrack(i + 1)      # EXPLORE (only elements after i)
            path.pop()            # UNCHOOSE
    
    backtrack(0)
    return result
```

### C++
```cpp
vector<vector<int>> subsets(vector<int>& nums) {
    vector<vector<int>> result;
    vector<int> path;
    
    function<void(int)> backtrack = [&](int start) {
        result.push_back(path);
        for (int i = start; i < nums.size(); i++) {
            path.push_back(nums[i]);
            backtrack(i + 1);
            path.pop_back();
        }
    };
    backtrack(0);
    return result;
}
```

### Rust
```rust
fn subsets(nums: &[i32]) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    fn backtrack(nums: &[i32], start: usize, path: &mut Vec<i32>, result: &mut Vec<Vec<i32>>) {
        result.push(path.clone());
        for i in start..nums.len() {
            path.push(nums[i]);
            backtrack(nums, i + 1, path, result);
            path.pop();
        }
    }
    backtrack(nums, 0, &mut path, &mut result);
    result
}
```
**Rust note:** `path.push`/`path.pop` — Vec matches backtracking. `path.clone()` when adding to result. Use indices to avoid borrow issues.

---

## Template 2: Subsets with Duplicates

**Key:** Sort first. Skip when `nums[i] == nums[i-1]` and we're at same level (i > start).

### Python
```python
def subsetsWithDup(nums):
    result = []
    path = []
    nums.sort()
    
    def backtrack(start):
        result.append(path[:])
        for i in range(start, len(nums)):
            if i > start and nums[i] == nums[i-1]:
                continue  # skip duplicate
            path.append(nums[i])
            backtrack(i + 1)
            path.pop()
    
    backtrack(0)
    return result
```

### C++
```cpp
vector<vector<int>> subsetsWithDup(vector<int>& nums) {
    vector<vector<int>> result;
    vector<int> path;
    sort(nums.begin(), nums.end());
    
    function<void(int)> backtrack = [&](int start) {
        result.push_back(path);
        for (int i = start; i < nums.size(); i++) {
            if (i > start && nums[i] == nums[i-1]) continue;
            path.push_back(nums[i]);
            backtrack(i + 1);
            path.pop_back();
        }
    };
    backtrack(0);
    return result;
}
```

### Rust
```rust
fn subsets_with_dup(nums: &mut [i32]) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    nums.sort();
    fn backtrack(nums: &[i32], start: usize, path: &mut Vec<i32>, result: &mut Vec<Vec<i32>>) {
        result.push(path.clone());
        for i in start..nums.len() {
            if i > start && nums[i] == nums[i - 1] { continue; }
            path.push(nums[i]);
            backtrack(nums, i + 1, path, result);
            path.pop();
        }
    }
    backtrack(nums, 0, &mut path, &mut result);
    result
}
```
**Rust note:** Sort first; skip when `i > start && nums[i] == nums[i-1]`.

---

## Template 3: Permutations

**Decision:** Which remaining element goes in current position? Track `used[]`.

### Python
```python
def permute(nums):
    result = []
    path = []
    used = [False] * len(nums)
    
    def backtrack():
        if len(path) == len(nums):
            result.append(path[:])
            return
        for i in range(len(nums)):
            if used[i]:
                continue
            used[i] = True
            path.append(nums[i])
            backtrack()
            path.pop()
            used[i] = False
    
    backtrack()
    return result
```

### C++
```cpp
vector<vector<int>> permute(vector<int>& nums) {
    vector<vector<int>> result;
    vector<int> path;
    vector<bool> used(nums.size(), false);
    
    function<void()> backtrack = [&]() {
        if (path.size() == nums.size()) {
            result.push_back(path);
            return;
        }
        for (int i = 0; i < nums.size(); i++) {
            if (used[i]) continue;
            used[i] = true;
            path.push_back(nums[i]);
            backtrack();
            path.pop_back();
            used[i] = false;
        }
    };
    backtrack();
    return result;
}
```

### Rust
```rust
fn permute(nums: &[i32]) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    let mut used = vec![false; nums.len()];
    fn backtrack(nums: &[i32], path: &mut Vec<i32>, used: &mut [bool], result: &mut Vec<Vec<i32>>) {
        if path.len() == nums.len() {
            result.push(path.clone());
            return;
        }
        for i in 0..nums.len() {
            if used[i] { continue; }
            used[i] = true;
            path.push(nums[i]);
            backtrack(nums, path, used, result);
            path.pop();
            used[i] = false;
        }
    }
    backtrack(nums, &mut path, &mut used, &mut result);
    result
}
```
**Rust note:** `used` array; mutable refs in recursive calls. Clone path when adding.

---

## Template 4: Permutations with Duplicates

**Key:** Sort. Skip when `nums[i] == nums[i-1]` and `used[i-1] == false`.

### Python
```python
def permuteUnique(nums):
    result = []
    path = []
    used = [False] * len(nums)
    nums.sort()
    
    def backtrack():
        if len(path) == len(nums):
            result.append(path[:])
            return
        for i in range(len(nums)):
            if used[i]:
                continue
            if i > 0 and nums[i] == nums[i-1] and not used[i-1]:
                continue  # skip duplicate
            used[i] = True
            path.append(nums[i])
            backtrack()
            path.pop()
            used[i] = False
    
    backtrack()
    return result
```

### C++
```cpp
vector<vector<int>> permuteUnique(vector<int>& nums) {
    vector<vector<int>> result;
    vector<int> path;
    vector<bool> used(nums.size(), false);
    sort(nums.begin(), nums.end());
    
    function<void()> backtrack = [&]() {
        if (path.size() == nums.size()) {
            result.push_back(path);
            return;
        }
        for (int i = 0; i < nums.size(); i++) {
            if (used[i]) continue;
            if (i > 0 && nums[i] == nums[i-1] && !used[i-1]) continue;
            used[i] = true;
            path.push_back(nums[i]);
            backtrack();
            path.pop_back();
            used[i] = false;
        }
    };
    backtrack();
    return result;
}
```

### Rust
```rust
fn permute_unique(nums: &mut [i32]) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    let mut used = vec![false; nums.len()];
    nums.sort();
    fn backtrack(nums: &[i32], path: &mut Vec<i32>, used: &mut [bool], result: &mut Vec<Vec<i32>>) {
        if path.len() == nums.len() {
            result.push(path.clone());
            return;
        }
        for i in 0..nums.len() {
            if used[i] { continue; }
            if i > 0 && nums[i] == nums[i - 1] && !used[i - 1] { continue; }
            used[i] = true;
            path.push(nums[i]);
            backtrack(nums, path, used, result);
            path.pop();
            used[i] = false;
        }
    }
    backtrack(nums, &mut path, &mut used, &mut result);
    result
}
```
**Rust note:** Sort + skip when `nums[i] == nums[i-1] && !used[i-1]`.

---

## Template 5: Combinations C(n, k)

**Decision:** Include/exclude. Prune when `len(path) == k` or not enough remaining.

### Python
```python
def combine(n, k):
    result = []
    path = []
    
    def backtrack(start):
        if len(path) == k:
            result.append(path[:])
            return
        for i in range(start, n + 1):
            if n - i + 1 < k - len(path):  # prune: not enough left
                break
            path.append(i)
            backtrack(i + 1)
            path.pop()
    
    backtrack(1)
    return result
```

### C++
```cpp
vector<vector<int>> combine(int n, int k) {
    vector<vector<int>> result;
    vector<int> path;
    
    function<void(int)> backtrack = [&](int start) {
        if (path.size() == k) {
            result.push_back(path);
            return;
        }
        for (int i = start; i <= n; i++) {
            if (n - i + 1 < k - (int)path.size()) break;
            path.push_back(i);
            backtrack(i + 1);
            path.pop_back();
        }
    };
    backtrack(1);
    return result;
}
```

### Rust
```rust
fn combine(n: i32, k: i32) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    fn backtrack(n: i32, k: i32, start: i32, path: &mut Vec<i32>, result: &mut Vec<Vec<i32>>) {
        if path.len() == k as usize {
            result.push(path.clone());
            return;
        }
        for i in start..=n {
            if (n - i + 1) < (k - path.len() as i32) { break; }
            path.push(i);
            backtrack(n, k, i + 1, path, result);
            path.pop();
        }
    }
    backtrack(n, k, 1, &mut path, &mut result);
    result
}
```

---

## Template 6: Combination Sum (Unlimited Use)

**Key:** When include, stay at same index (can reuse). When exclude, advance index.

### Python
```python
def combinationSum(candidates, target):
    result = []
    path = []
    candidates.sort()
    
    def backtrack(start, remain):
        if remain == 0:
            result.append(path[:])
            return
        for i in range(start, len(candidates)):
            if candidates[i] > remain:
                break  # prune: sorted, rest are bigger
            path.append(candidates[i])
            backtrack(i, remain - candidates[i])  # same i = reuse
            path.pop()
    
    backtrack(0, target)
    return result
```

### C++
```cpp
vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
    vector<vector<int>> result;
    vector<int> path;
    sort(candidates.begin(), candidates.end());
    
    function<void(int, int)> backtrack = [&](int start, int remain) {
        if (remain == 0) {
            result.push_back(path);
            return;
        }
        for (int i = start; i < candidates.size(); i++) {
            if (candidates[i] > remain) break;
            path.push_back(candidates[i]);
            backtrack(i, remain - candidates[i]);
            path.pop_back();
        }
    };
    backtrack(0, target);
    return result;
}
```

### Rust
```rust
fn combination_sum(candidates: &mut [i32], target: i32) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    candidates.sort();
    fn backtrack(cand: &[i32], start: usize, remain: i32, path: &mut Vec<i32>, result: &mut Vec<Vec<i32>>) {
        if remain == 0 {
            result.push(path.clone());
            return;
        }
        for i in start..cand.len() {
            if cand[i] > remain { break; }
            path.push(cand[i]);
            backtrack(cand, i, remain - cand[i], path, result);
            path.pop();
        }
    }
    backtrack(candidates, 0, target, &mut path, &mut result);
    result
}
```
**Rust note:** `backtrack(i, remain)` — same index = reuse. Advance only on exclude.

---

## Template 7: Combination Sum (Unique Elements, Use Once)

**Key:** Standard include/exclude. Advance index. Skip duplicates.

### Python
```python
def combinationSum2(candidates, target):
    result = []
    path = []
    candidates.sort()
    
    def backtrack(start, remain):
        if remain == 0:
            result.append(path[:])
            return
        for i in range(start, len(candidates)):
            if candidates[i] > remain:
                break
            if i > start and candidates[i] == candidates[i-1]:
                continue  # skip duplicate
            path.append(candidates[i])
            backtrack(i + 1, remain - candidates[i])
            path.pop()
    
    backtrack(0, target)
    return result
```

### C++
```cpp
vector<vector<int>> combinationSum2(vector<int>& candidates, int target) {
    vector<vector<int>> result;
    vector<int> path;
    sort(candidates.begin(), candidates.end());
    
    function<void(int, int)> backtrack = [&](int start, int remain) {
        if (remain == 0) {
            result.push_back(path);
            return;
        }
        for (int i = start; i < candidates.size(); i++) {
            if (candidates[i] > remain) break;
            if (i > start && candidates[i] == candidates[i-1]) continue;
            path.push_back(candidates[i]);
            backtrack(i + 1, remain - candidates[i]);
            path.pop_back();
        }
    };
    backtrack(0, target);
    return result;
}
```

### Rust
```rust
fn combination_sum2(candidates: &mut [i32], target: i32) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let mut path = vec![];
    candidates.sort();
    fn backtrack(cand: &[i32], start: usize, remain: i32, path: &mut Vec<i32>, result: &mut Vec<Vec<i32>>) {
        if remain == 0 {
            result.push(path.clone());
            return;
        }
        for i in start..cand.len() {
            if cand[i] > remain { break; }
            if i > start && cand[i] == cand[i - 1] { continue; }
            path.push(cand[i]);
            backtrack(cand, i + 1, remain - cand[i], path, result);
            path.pop();
        }
    }
    backtrack(candidates, 0, target, &mut path, &mut result);
    result
}
```
**Rust note:** `backtrack(i+1, remain)` — advance index. Skip duplicate.

---

## Template 8: N-Queens Framework

**Decision:** Which column for queen in row `r`? Track columns + diagonals.

### Python
```python
def solveNQueens(n):
    result = []
    board = [['.'] * n for _ in range(n)]
    cols = set()
    diag1 = set()  # r - c
    diag2 = set()  # r + c
    
    def backtrack(r):
        if r == n:
            result.append([''.join(row) for row in board])
            return
        for c in range(n):
            if c in cols or (r - c) in diag1 or (r + c) in diag2:
                continue
            cols.add(c)
            diag1.add(r - c)
            diag2.add(r + c)
            board[r][c] = 'Q'
            backtrack(r + 1)
            board[r][c] = '.'
            diag2.remove(r + c)
            diag1.remove(r - c)
            cols.remove(c)
    
    backtrack(0)
    return result
```

### C++
```cpp
vector<vector<string>> solveNQueens(int n) {
    vector<vector<string>> result;
    vector<string> board(n, string(n, '.'));
    unordered_set<int> cols, diag1, diag2;
    
    function<void(int)> backtrack = [&](int r) {
        if (r == n) {
            result.push_back(board);
            return;
        }
        for (int c = 0; c < n; c++) {
            if (cols.count(c) || diag1.count(r-c) || diag2.count(r+c))
                continue;
            cols.insert(c);
            diag1.insert(r - c);
            diag2.insert(r + c);
            board[r][c] = 'Q';
            backtrack(r + 1);
            board[r][c] = '.';
            diag2.erase(r + c);
            diag1.erase(r - c);
            cols.erase(c);
        }
    };
    backtrack(0);
    return result;
}
```

### Rust
```rust
fn solve_n_queens(n: i32) -> Vec<Vec<String>> {
    let mut result = vec![];
    let mut board = vec![vec!['.'; n as usize]; n as usize];
    let mut cols = std::collections::HashSet::new();
    let mut diag1 = std::collections::HashSet::new();
    let mut diag2 = std::collections::HashSet::new();
    fn backtrack(r: i32, n: i32, board: &mut Vec<Vec<char>>, cols: &mut std::collections::HashSet<i32>,
                 diag1: &mut std::collections::HashSet<i32>, diag2: &mut std::collections::HashSet<i32>,
                 result: &mut Vec<Vec<String>>) {
        if r == n {
            result.push(board.iter().map(|row| row.iter().collect()).collect());
            return;
        }
        for c in 0..n {
            if cols.contains(&c) || diag1.contains(&(r - c)) || diag2.contains(&(r + c)) { continue; }
            cols.insert(c);
            diag1.insert(r - c);
            diag2.insert(r + c);
            board[r as usize][c as usize] = 'Q';
            backtrack(r + 1, n, board, cols, diag1, diag2, result);
            board[r as usize][c as usize] = '.';
            cols.remove(&c);
            diag1.remove(&(r - c));
            diag2.remove(&(r + c));
        }
    }
    backtrack(0, n, &mut board, &mut cols, &mut diag1, &mut diag2, &mut result);
    result
}
```
**Rust note:** `cols`, `diag1`(r-c), `diag2`(r+c). Mutable refs passed through recursion.

---

## Template 9: Sudoku Solver Framework

**Decision:** For empty cell, try digits 1-9. Check row, col, box.

### Python
```python
def solveSudoku(board):
    def valid(r, c, d):
        for i in range(9):
            if board[r][i] == d or board[i][c] == d:
                return False
        br, bc = 3 * (r // 3), 3 * (c // 3)
        for i in range(br, br + 3):
            for j in range(bc, bc + 3):
                if board[i][j] == d:
                    return False
        return True
    
    def backtrack():
        for r in range(9):
            for c in range(9):
                if board[r][c] != '.':
                    continue
                for d in '123456789':
                    if valid(r, c, d):
                        board[r][c] = d
                        if backtrack():
                            return True
                        board[r][c] = '.'
                return False
        return True
    
    backtrack()
```

### C++
```cpp
void solveSudoku(vector<vector<char>>& board) {
    function<bool(int, int, char)> valid = [&](int r, int c, char d) {
        for (int i = 0; i < 9; i++)
            if (board[r][i] == d || board[i][c] == d) return false;
        int br = 3 * (r / 3), bc = 3 * (c / 3);
        for (int i = br; i < br + 3; i++)
            for (int j = bc; j < bc + 3; j++)
                if (board[i][j] == d) return false;
        return true;
    };
    function<bool()> backtrack = [&]() {
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (board[r][c] != '.') continue;
                for (char d = '1'; d <= '9'; d++) {
                    if (!valid(r, c, d)) continue;
                    board[r][c] = d;
                    if (backtrack()) return true;
                    board[r][c] = '.';
                }
                return false;
            }
        }
        return true;
    };
    backtrack();
}
```

### Rust
```rust
fn solve_sudoku(board: &mut Vec<Vec<char>>) {
    fn valid(board: &[Vec<char>], r: usize, c: usize, d: char) -> bool {
        for i in 0..9 {
            if board[r][i] == d || board[i][c] == d { return false; }
        }
        let (br, bc) = (3 * (r / 3), 3 * (c / 3));
        for i in br..br + 3 {
            for j in bc..bc + 3 {
                if board[i][j] == d { return false; }
            }
        }
        true
    }
    fn backtrack(board: &mut Vec<Vec<char>>) -> bool {
        for r in 0..9 {
            for c in 0..9 {
                if board[r][c] != '.' { continue; }
                for d in '1'..='9' {
                    if !valid(board, r, c, d) { continue; }
                    board[r][c] = d;
                    if backtrack(board) { return true; }
                    board[r][c] = '.';
                }
                return false;
            }
        }
        true
    }
    backtrack(board);
}
```
**Rust note:** `valid` checks row, col, box. Find empty; try digits; backtrack.

---

## Template 10: Word Search (Grid Backtracking)

**Decision:** From current cell, try 4 directions. Mark visited, unmark on backtrack.

### Python
```python
def exist(board, word):
    R, C = len(board), len(board[0])
    
    def backtrack(r, c, idx):
        if idx == len(word):
            return True
        if r < 0 or r >= R or c < 0 or c >= C or board[r][c] != word[idx]:
            return False
        board[r][c] = '#'  # mark visited
        for dr, dc in [(0,1), (1,0), (0,-1), (-1,0)]:
            if backtrack(r + dr, c + dc, idx + 1):
                return True
        board[r][c] = word[idx]  # unchoose
        return False
    
    for r in range(R):
        for c in range(C):
            if backtrack(r, c, 0):
                return True
    return False
```

### C++
```cpp
bool exist(vector<vector<char>>& board, string word) {
    int R = board.size(), C = board[0].size();
    
    function<bool(int, int, int)> backtrack = [&](int r, int c, int idx) {
        if (idx == word.size()) return true;
        if (r < 0 || r >= R || c < 0 || c >= C || board[r][c] != word[idx])
            return false;
        board[r][c] = '#';
        int dr[] = {0, 1, 0, -1}, dc[] = {1, 0, -1, 0};
        for (int i = 0; i < 4; i++) {
            if (backtrack(r + dr[i], c + dc[i], idx + 1))
                return true;
        }
        board[r][c] = word[idx];
        return false;
    };
    for (int r = 0; r < R; r++)
        for (int c = 0; c < C; c++)
            if (backtrack(r, c, 0)) return true;
    return false;
}
```

### Rust
```rust
fn exist(board: &mut Vec<Vec<char>>, word: &str) -> bool {
    let word: Vec<char> = word.chars().collect();
    let (r, c) = (board.len(), board[0].len());
    fn backtrack(board: &mut [Vec<char>], word: &[char], r: usize, c: usize, idx: usize) -> bool {
        if idx == word.len() { return true; }
        if r >= board.len() || c >= board[0].len() || board[r][c] != word[idx] { return false; }
        let ch = board[r][c];
        board[r][c] = '#';
        let found = (r > 0 && backtrack(board, word, r - 1, c, idx + 1))
            || (r + 1 < board.len() && backtrack(board, word, r + 1, c, idx + 1))
            || (c > 0 && backtrack(board, word, r, c - 1, idx + 1))
            || (c + 1 < board[0].len() && backtrack(board, word, r, c + 1, idx + 1));
        board[r][c] = ch;
        found
    }
    for r in 0..board.len() {
        for c in 0..board[0].len() {
            if backtrack(board, &word, r, c, 0) { return true; }
        }
    }
    false
}
```
**Rust note:** Mark cell with `#`; restore on backtrack. Use indices to avoid borrow checker.

---

## Template Summary Table

| Template | Key Variation | Index/State |
|----------|---------------|-------------|
| Subsets | Include/exclude, start index | `backtrack(start)` |
| Subsets w/ dup | Sort + skip `i>start && nums[i]==nums[i-1]` | same |
| Permutations | used[], pick any unused | `backtrack()` |
| Permutations w/ dup | Sort + skip if `nums[i]==nums[i-1] && !used[i-1]` | same |
| Combinations | Subsets + `len(path)==k` | same |
| Combo Sum (unlimited) | `backtrack(i, remain)` — same i | advance only on exclude |
| Combo Sum (unique) | `backtrack(i+1, remain)` + skip dup | advance always |
| N-Queens | cols, diag1 (r-c), diag2 (r+c) | row by row |
| Sudoku | valid(row,col,box) | find next empty |
| Word Search | 4 dirs, mark/unmark cell | (r,c), idx |

---

## FINAL MEMORY COMPRESSION BLOCK

```
SUBSETS:        path[:], start→i+1, include/exclude
SUBSETS DUP:    sort, skip i>start && nums[i]==nums[i-1]
PERMUTE:        used[], pick any unused
PERMUTE DUP:    sort, skip nums[i]==nums[i-1] && !used[i-1]
COMBINE:        len(path)==k, prune by remaining count
COMBO SUM ∞:    backtrack(i, remain) — reuse
COMBO SUM 1:    backtrack(i+1, remain), skip dup
N-QUEENS:       cols, diag1(r-c), diag2(r+c)
SUDOKU:         valid row/col/box, find empty
WORD SEARCH:    4 dirs, mark cell, unmark on return
```

---

## 30-SECOND REVISION BOX

| Pattern | Key Idea |
|---------|----------|
| Subsets | path.clone(); start→i+1; include/exclude |
| Subsets dup | Sort; skip `i>start && nums[i]==nums[i-1]` |
| Permute | used[]; pick any unused |
| Permute dup | Sort; skip `nums[i]==nums[i-1] && !used[i-1]` |
| Combine | len(path)==k; prune by remaining |
| Combo sum ∞ | backtrack(i, remain) — reuse |
| Combo sum 1 | backtrack(i+1, remain); skip dup |
| N-Queens | cols, diag1(r-c), diag2(r+c) |
| Sudoku | valid row/col/box; find empty |
| Word search | 4 dirs; mark/unmark cell |

---

## Language Comparison

| Construct | Python | C++ | Rust |
|-----------|--------|-----|------|
| Path | `list` (append/pop) | `vector` (push_back/pop_back) | `Vec` (push/pop) |
| Save result | `path[:]` copy | `result.push_back(path)` | `path.clone()` |
| Recursion | Nested def / closure | `function<void(int)>` lambda | Nested fn or impl |
| Mutable state | Closure captures | Lambda `[&]` capture | `&mut` refs in params |
| Avoid borrow | — | — | Use indices instead of refs |
