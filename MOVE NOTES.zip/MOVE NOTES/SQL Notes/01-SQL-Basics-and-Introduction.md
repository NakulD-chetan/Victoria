# SQL — Basics & Introduction

> **SQL = Structured Query Language**
> Relational Database se baat karne ki **language** hai yeh.
> Data store karna, nikalna, update karna, delete karna — sab SQL se hota hai.

---

## What is SQL?

> **Definition (Interview):** SQL is a standard language for storing, manipulating, and retrieving data in relational databases.

- SQL pronounced as **"S-Q-L"** ya **"Sequel"** — dono chalte hain
- SQL **declarative** language hai — tum batao **KYA chahiye**, SQL decide karega **KAISE** nikale
- Almost har relational database SQL use karta hai: MySQL, PostgreSQL, Oracle, SQL Server, SQLite

```
Tum: "Mujhe sab students chahiye jinke marks 90 se zyada hain"
SQL: SELECT * FROM students WHERE marks > 90;
     ↑ Tum sirf yeh likho, database optimize karega kaise dhundhna hai
```

---

## DBMS vs RDBMS

> **Interview mein bahut puchha jaata hai yeh difference!**

| Feature | DBMS | RDBMS |
|---------|------|-------|
| **Full Form** | Database Management System | Relational DBMS |
| **Data Storage** | Files mein store karta hai | Tables (rows + columns) mein store karta hai |
| **Relationships** | Tables ke beech relationship nahi hoti | Tables ke beech **Foreign Key** se relationship |
| **Normalization** | Support nahi karta | Normalization support karta hai |
| **ACID Properties** | Generally nahi hoti | **ACID guaranteed** |
| **Examples** | File System, XML, dBase | MySQL, PostgreSQL, Oracle, SQL Server |
| **Data Redundancy** | Zyada hoti hai | Kam hoti hai (normalization se) |
| **Users** | Single user | Multiple users concurrently |

> **Yaad Rakho:** RDBMS mein "R" = **Relational** → Tables ke beech **relationships** hoti hain (Foreign Keys se)

---

## What is a Table?

SQL mein data **Table** (ya **Relation**) mein store hota hai:

```
Table: students
+----+---------+------+-------+--------+
| id | name    | age  | marks | city   |
+----+---------+------+-------+--------+
| 1  | Rahul   | 21   | 85    | Mumbai |    ← Row (Record/Tuple)
| 2  | Priya   | 22   | 92    | Delhi  |
| 3  | Amit    | 20   | 78    | Pune   |
| 4  | Sneha   | 21   | 95    | Mumbai |
| 5  | Karan   | 23   | 60    | Delhi  |
+----+---------+------+-------+--------+
  ↑      ↑       ↑      ↑       ↑
  Columns (Fields/Attributes)
```

| Term | Matlab | Example |
|------|--------|---------|
| **Table / Relation** | Data ka collection | `students` |
| **Row / Record / Tuple** | Ek entry | `(1, Rahul, 21, 85, Mumbai)` |
| **Column / Field / Attribute** | Property | `name`, `age`, `marks` |
| **Schema** | Table ka structure (columns + data types) | `students(id INT, name VARCHAR, ...)` |
| **Database** | Tables ka collection | `school_db` |

---

## SQL Sub-Languages (5 Types)

> **VERY IMPORTANT for interviews!** SQL ko 5 parts mein divide karte hain based on kaam:

```
SQL Sub-Languages
├── 1. DDL (Data Definition Language)    → Table/Structure banao
├── 2. DML (Data Manipulation Language)  → Data add/update/delete karo
├── 3. DQL (Data Query Language)         → Data nikalo (SELECT)
├── 4. DCL (Data Control Language)       → Permissions do/chino
└── 5. TCL (Transaction Control Language)→ Transactions manage karo
```

### 1) DDL — Data Definition Language

> **Definition:** DDL commands define the structure of the database (tables, schemas, indexes).

| Command | Kya Karta Hai | Example |
|---------|---------------|---------|
| **CREATE** | Naya table/database banao | `CREATE TABLE students (...)` |
| **ALTER** | Table ka structure change karo | `ALTER TABLE students ADD email VARCHAR(100)` |
| **DROP** | Table/database pura delete karo | `DROP TABLE students` |
| **TRUNCATE** | Table ka sara data hatao (structure rahe) | `TRUNCATE TABLE students` |
| **RENAME** | Table/column ka naam badlo | `RENAME TABLE students TO learners` |

> **Key Point:** DDL commands are **auto-committed** — ROLLBACK nahi kar sakte!

---

### 2) DML — Data Manipulation Language

> **Definition:** DML commands manipulate the data inside tables (add, modify, remove rows).

| Command | Kya Karta Hai | Example |
|---------|---------------|---------|
| **INSERT** | Naya row add karo | `INSERT INTO students VALUES (...)` |
| **UPDATE** | Existing data change karo | `UPDATE students SET marks = 90 WHERE id = 1` |
| **DELETE** | Specific rows hatao | `DELETE FROM students WHERE id = 5` |

> **Key Point:** DML changes can be **ROLLED BACK** (agar transaction mein ho)

---

### 3) DQL — Data Query Language

> **Definition:** DQL is used to retrieve/fetch data from the database.

| Command | Kya Karta Hai | Example |
|---------|---------------|---------|
| **SELECT** | Data query karo / nikalo | `SELECT name, marks FROM students` |

> **Note:** Kuch log SELECT ko DML mein count karte hain, kuch alag DQL kehte hain — dono sahi hai.

---

### 4) DCL — Data Control Language

> **Definition:** DCL commands control access/permissions on database objects.

| Command | Kya Karta Hai | Example |
|---------|---------------|---------|
| **GRANT** | Permission do | `GRANT SELECT ON students TO user1` |
| **REVOKE** | Permission wapas lo | `REVOKE SELECT ON students FROM user1` |

---

### 5) TCL — Transaction Control Language

> **Definition:** TCL commands manage transactions — group of SQL operations that should execute as one unit.

| Command | Kya Karta Hai | Example |
|---------|---------------|---------|
| **COMMIT** | Changes save karo permanently | `COMMIT;` |
| **ROLLBACK** | Changes undo karo | `ROLLBACK;` |
| **SAVEPOINT** | Ek checkpoint banao | `SAVEPOINT sp1;` |

---

## SQL Data Types

> Interview mein puchh sakte hain — "Which data type would you use for...?"

### Numeric Types:

| Type | Range/Size | Kab Use Karo |
|------|-----------|-------------|
| **INT / INTEGER** | -2B to +2B (4 bytes) | IDs, age, counts |
| **BIGINT** | Very large numbers (8 bytes) | Large IDs, timestamps |
| **SMALLINT** | -32K to +32K (2 bytes) | Small numbers |
| **DECIMAL(p,s)** / NUMERIC | Exact precision | Money, marks → `DECIMAL(10,2)` |
| **FLOAT / DOUBLE** | Approximate decimal | Scientific calculations |
| **BOOLEAN** | TRUE / FALSE | Flags (is_active, is_deleted) |

### String Types:

| Type | Size | Kab Use Karo |
|------|------|-------------|
| **CHAR(n)** | Fixed length (padded) | Gender ('M'/'F'), Country Code |
| **VARCHAR(n)** | Variable length (up to n) | Names, emails, addresses |
| **TEXT** | Very large strings | Descriptions, articles, comments |

> **Interview Tip:** `CHAR(10)` mein agar "Rahul" daalo toh 5 spaces padding lagegi → `"Rahul     "`.
> `VARCHAR(10)` mein sirf `"Rahul"` store hoga — space waste nahi hoga.

### Date/Time Types:

| Type | Format | Example |
|------|--------|---------|
| **DATE** | YYYY-MM-DD | `'2024-03-15'` |
| **TIME** | HH:MM:SS | `'14:30:00'` |
| **DATETIME / TIMESTAMP** | YYYY-MM-DD HH:MM:SS | `'2024-03-15 14:30:00'` |

---

## SQL Constraints

> **Definition:** Constraints are rules enforced on columns to ensure data integrity.

> **Interview Favorite:** "What are SQL constraints? Name all of them."

```
Constraints
├── NOT NULL       → NULL value nahi le sakta
├── UNIQUE         → Duplicate values nahi ho sakte
├── PRIMARY KEY    → NOT NULL + UNIQUE (row ko identify karta hai)
├── FOREIGN KEY    → Doosre table ko reference karta hai
├── CHECK          → Custom condition check karta hai
├── DEFAULT        → Default value set karta hai
└── AUTO_INCREMENT → Automatically badhe (1, 2, 3, ...)
```

### Example — Sab constraints ek table mein:

```sql
CREATE TABLE employees (
    emp_id      INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    email       VARCHAR(100) UNIQUE,
    age         INT CHECK (age >= 18 AND age <= 65),
    department  VARCHAR(50) DEFAULT 'General',
    manager_id  INT,
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
);
```

### Constraint Breakdown:

| Constraint | Kya Karta Hai | Rule |
|-----------|---------------|------|
| **NOT NULL** | NULL values not allowed | `name VARCHAR(100) NOT NULL` |
| **UNIQUE** | No duplicate values in that column | `email VARCHAR(100) UNIQUE` |
| **PRIMARY KEY** | Unique + Not Null — row identifier | `emp_id INT PRIMARY KEY` |
| **FOREIGN KEY** | Points to PK of another table | `FOREIGN KEY (dept_id) REFERENCES departments(id)` |
| **CHECK** | Custom validation | `CHECK (age >= 18)` |
| **DEFAULT** | Agar value na do toh yeh use hoga | `DEFAULT 'General'` |
| **AUTO_INCREMENT** | Auto-increment (MySQL), SERIAL (PostgreSQL) | `emp_id INT AUTO_INCREMENT` |

> **Important:** PRIMARY KEY = NOT NULL + UNIQUE. Lekin UNIQUE column NULL le sakta hai!

---

## Keys in SQL (VERY Important for Interviews!)

> **Definition:** Keys are used to uniquely identify records and establish relationships between tables.

### Sample Tables:

```
Table: students                          Table: enrollments
+----+---------+--------+-----------+    +-----+-----+-----------+
| id | name    | email  | phone     |    | e_id| s_id| course    |
+----+---------+--------+-----------+    +-----+-----+-----------+
| 1  | Rahul   | r@g.co | 9876543210|    | 101 | 1   | SQL       |
| 2  | Priya   | p@g.co | 9876543211|    | 102 | 2   | Python    |
| 3  | Amit    | a@g.co | 9876543212|    | 103 | 1   | Python    |
+----+---------+--------+-----------+    +-----+-----+-----------+
```

### 1) Primary Key (PK)

> **Definition:** A column (or set of columns) that **uniquely identifies** each row in a table.

- **NOT NULL + UNIQUE** — dono conditions mandatory
- Har table mein **sirf ek Primary Key** ho sakti hai
- Example: `id` column in students table

```sql
CREATE TABLE students (
    id INT PRIMARY KEY,
    name VARCHAR(100)
);
```

---

### 2) Foreign Key (FK)

> **Definition:** A column that **references the Primary Key** of another table, creating a link between them.

- Yeh **relationship establish** karta hai tables ke beech
- Foreign Key mein **NULL** aa sakta hai
- Foreign Key mein **duplicate** values aa sakte hain

```sql
CREATE TABLE enrollments (
    e_id INT PRIMARY KEY,
    s_id INT,
    course VARCHAR(50),
    FOREIGN KEY (s_id) REFERENCES students(id)
);
```

```
students.id (PK)  ←──────  enrollments.s_id (FK)
     1             ─────→       101 → s_id = 1
     2             ─────→       102 → s_id = 2
     3                          103 → s_id = 1
```

---

### 3) Candidate Key

> **Definition:** Any column (or set of columns) that **can be** a Primary Key — uniquely identifies each row.

Students table mein:
- `id` → unique → Candidate Key ✅
- `email` → unique → Candidate Key ✅
- `phone` → unique → Candidate Key ✅
- `name` → NOT unique (duplicates possible) → ❌

> **Primary Key is chosen FROM Candidate Keys.** Baaki candidate keys = **Alternate Keys**.

---

### 4) Composite Key

> **Definition:** A Primary Key made of **2 or more columns** together.

```sql
CREATE TABLE enrollments (
    student_id INT,
    course_id  INT,
    semester   VARCHAR(20),
    PRIMARY KEY (student_id, course_id)
);
```

> Yahan na `student_id` alone unique hai, na `course_id` alone — but **dono together unique** hain.

---

### 5) Super Key

> **Definition:** Any set of columns that **can uniquely identify** a row (includes extra columns too).

Students table ke Super Keys:
- `{id}` → ✅ (minimal — yeh candidate key bhi hai)
- `{id, name}` → ✅ (id alone enough tha, name extra hai)
- `{id, name, email}` → ✅ (zyada extra columns)
- `{email}` → ✅ (minimal — candidate key)

> **Super Key ⊇ Candidate Key ⊇ Primary Key**
> Every Candidate Key is a Super Key, but not every Super Key is a Candidate Key.

---

## Keys Hierarchy (Interview Answer):

```
Super Key (broadest — any unique combination)
    │
    ├── Candidate Key (minimal super key — no extra columns)
    │       │
    │       ├── Primary Key (ONE chosen candidate key)
    │       │
    │       └── Alternate Key (remaining candidate keys)
    │
    └── Non-minimal Super Keys (extra columns added)

Foreign Key → References Primary Key of another table (separate concept)
```

---

## Quick Memory Card

| Term | One Line Definition | Interview Hint |
|------|-------------------|----------------|
| SQL | Language to talk to relational databases | Declarative, not procedural |
| RDBMS | Data stored in related tables | Tables + Relationships + ACID |
| DDL | Define structure (CREATE, ALTER, DROP) | Auto-committed |
| DML | Manipulate data (INSERT, UPDATE, DELETE) | Can be rolled back |
| DQL | Query data (SELECT) | Most used command |
| DCL | Control access (GRANT, REVOKE) | Security related |
| TCL | Manage transactions (COMMIT, ROLLBACK) | ACID related |
| Primary Key | Unique row identifier | NOT NULL + UNIQUE, one per table |
| Foreign Key | Links to another table's PK | Can be NULL, can have duplicates |
| Candidate Key | Could be Primary Key | All unique columns |
| Composite Key | Multi-column Primary Key | When single column can't be unique |
| NOT NULL | No empty values | Default allows NULL |
| UNIQUE | No duplicates | Can have ONE null (in most RDBMS) |
| CHECK | Custom validation rule | `CHECK (age >= 18)` |
| CHAR vs VARCHAR | Fixed vs Variable length | CHAR pads with spaces |

---

*Notes Source: SQL fundamentals + Interview preparation material*
