# Availability and Reliability — Interview Thinking

---

## When to Bring Up Availability


| Trigger                                      | What to say                                                                                 |
| -------------------------------------------- | ------------------------------------------------------------------------------------------- |
| "How do you ensure the system is always up?" | "We design for HA: multiple instances, multi-AZ, no SPOFs. Target 99.9% uptime."            |
| "What happens when X fails?"                 | "We have redundancy: N+1 for that component, automatic failover to standby."                |
| "What's your SLA?"                           | "We target 99.9% (SLO). SLA is contractual; we measure with SLIs like success rate."        |
| "Design for scale"                           | "Scale implies HA—we need redundancy and failover so adding capacity doesn't create SPOFs." |
| "How do you handle disasters?"               | "DR plan with RPO/RTO. Async replication to DR region, runbook for failover."               |


> **FAANG Tip:** Availability is a natural follow-up to scalability. Don't wait—weave it in: "We scale horizontally and ensure HA through redundancy."

---

## Calculating Availability Numbers

**Series:** `A_total = A_1 × A_2 × A_3` (all must work)

**Parallel:** `A_total = 1 − (1−A)^n` (any works)

**Model answer:** *"For components in series, we multiply. For parallel redundancy, we use 1 minus the product of failure rates. So three 99% components in parallel give 99.9999%."*

---

## Discussing Trade-Offs


| Trade-Off                       | How to Present                                                                                                                                                                  |
| ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Availability vs Consistency** | "Strong consistency can require synchronous writes, which add latency and failure points. We often accept eventual consistency for non-critical paths to improve availability." |
| **Availability vs Cost**        | "Each nine adds cost: 99.99% needs multi-region, hot standby. We match target to business impact."                                                                              |
| **Availability vs Complexity**  | "More redundancy = more components to monitor and fail over. We start with N+1 and multi-AZ, add multi-region if needed."                                                       |


---

## Presenting Failover Strategies

**Shallow:** "We use warm standby—replica is always syncing, promotes on primary failure."

**Deep:** "Cold for non-critical: spin up on failure. Warm for most services: standby ready, async sync. Hot for payment: sync replica, instant switch. Trade-off is cost vs recovery time."


| Strategy | When to Use      | Interview Answer                                        |
| -------- | ---------------- | ------------------------------------------------------- |
| Cold     | DR, non-critical | "Backup region; restore from backup on disaster."       |
| Warm     | Most production  | "Standby replicas, async sync, promote in seconds."     |
| Hot      | Payment, auth    | "Sync replication, automated failover in milliseconds." |


---

## When Interviewers Probe Disaster Recovery

**What they want:** RPO, RTO, backup strategy, runbook awareness.

**Model answer:** *"We define RPO—max acceptable data loss—and RTO—max downtime. For RPO 1 hour, we do hourly backups and async replication. For RTO 4 hours, we have a runbook: promote DR replica, update DNS, verify. We practice with chaos drills."*

---

## Model Answers for Availability Questions

### Q: "What availability do you target?"

*"99.9% for customer-facing, 99.99% for payment and auth. Internal tools 99%. We set SLO slightly above SLA to have headroom."*

### Q: "How do you achieve high availability?"

*"Eliminate SPOFs: multi-AZ for app and DB, N+1 instances, DB replication with failover. Health checks remove unhealthy instances. For critical path, we use active-active across regions."*

### Q: "What's the difference between SLA, SLO, and SLI?"

*"SLI is the measured metric—e.g., success rate. SLO is our internal target. SLA is the contractual commitment with penalties. We measure SLI, aim for SLO, promise SLA."*

### Q: "How do you test failover?"

*"Chaos engineering: we run Chaos Monkey to kill instances, and game days for AZ failure. We also have automated failover tests in staging."*

### Q: "What's your disaster recovery strategy?"

*"RPO of 1 hour, RTO of 4 hours. Async replication to DR region. Runbook: promote replica, update DNS/GSLB, verify. We test quarterly."*

---

## Red Flags to Avoid

- **Don't say:** "We don't need high availability" (for any production system)
- **Don't say:** "Cloud is always available" (still need multi-AZ, design)
- **Don't say:** "99.999% for everything" (over-promising, expensive)
- **Don't say:** "We've never had an outage" (implies no testing)

---

## Quick Memory Card

```
WHEN:          Scale, SLA, failure, disaster
TRADE-OFFS:    Avail vs consistency, cost, complexity
FAILOVER:      Cold/warm/hot — match to criticality
DR:            RPO, RTO, backup, runbook, chaos
MODEL:         99.9% customer, 99.99% payment
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**