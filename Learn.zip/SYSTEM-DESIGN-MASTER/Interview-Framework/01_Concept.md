# Interview Framework — Concept

> **Permanent Recall:** The system design interview is a 40–45 minute structured conversation with four phases: Requirements (5 min), High-Level Design (10 min), Deep Dive (20 min), Wrap-up (5 min). Interviewers evaluate structured thinking, trade-off awareness, communication, and the ability to evolve a design—not memorized architectures. You lead; they observe and probe.

---

## What Interviewers Are Really Evaluating

| Dimension | What They Look For |
|-----------|--------------------|
| **Problem Clarification** | Do you ask the right questions before jumping to solutions? |
| **Structured Thinking** | Can you break problems into components and reason about them? |
| **Trade-off Awareness** | Do you understand pros/cons and justify choices? |
| **Communication** | Can you explain complex ideas clearly and collaborate? |
| **Technical Depth** | Do you know how components work at a practical level? |
| **Scalability Thinking** | Can you reason about scale, bottlenecks, and evolution? |

---

## The 4 Phases — Time Allocation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SYSTEM DESIGN INTERVIEW TIMELINE (45 min)                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  Phase 1        Phase 2            Phase 3                Phase 4            │
│  Requirements   High-Level         Deep Dive              Wrap-up            │
│  ──────────    Design             ──────────              ────────           │
│  ~5 min         ~10 min            ~20 min                ~5 min             │
│                                                                              │
│  ████           ██████████         ████████████████████████████████████      │
│  Clarify        Draw boxes,        Pick 1–2 critical     Bottlenecks,       │
│  scope          APIs, data        components; go        monitoring,         │
│  & constraints  flow              deep; trade-offs      future work        │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Phase 1: Requirements (5 min)

### Goals
- Clarify **functional** requirements (what the system must do)
- Clarify **non-functional** requirements (latency, availability, scale)
- Define **constraints** and **scope**
- Explicitly state what is **out of scope**

### What to Do
- Ask about **DAU**, **read:write ratio**, **data size**, **geography**
- Understand **use cases** and **priorities**
- Make reasonable assumptions and **state them** for confirmation
- Avoid diving into solution—this phase is about alignment

### What Interviewers Evaluate
- Do you ask clarifying questions?
- Do you identify constraints before designing?
- Can you scope appropriately?

> **FAANG Tip:** Skipping requirements and diving straight into architecture is the #1 reason candidates get a No Hire. Interviewers intentionally leave ambiguity—they want to see you handle it.

---

## Phase 2: High-Level Design (10 min)

### Goals
- Draw **main components** (clients, servers, LB, cache, DB, queues, CDN)
- Show **data flow** (request path, write path, read path)
- Design **API** for core operations
- Sketch **data model** (key tables/collections)

### What to Do
- Start with a box diagram: Client → LB → App Servers → DB
- Add cache, message queues, CDN as needed
- Define 3–5 key REST/gRPC endpoints
- Show database schema at a high level

### What Interviewers Evaluate
- Can you decompose a system into components?
- Do you choose appropriate building blocks?
- Is your design coherent and complete at a high level?

---

## Phase 3: Deep Dive (20 min)

### Goals
- **Go deep** on 1–2 critical components (e.g., feed generation, consistency model, sharding)
- Discuss **trade-offs** explicitly (CAP, latency vs consistency, cost vs complexity)
- Handle **what-if** questions (10x traffic, component failure, data growth)
- Show you understand *how* things work, not just *that* they exist

### What to Do
- Pick components based on interviewer hints or system type
- Explain algorithms, data structures, replication, partitioning
- Use diagrams (ASCII or mermaid) when helpful
- Say "Let me discuss the trade-offs here..."

### What Interviewers Evaluate
- Do you have genuine technical depth?
- Can you reason about failures and edge cases?
- Do you justify design choices with trade-offs?

> **FAANG Tip:** The deep dive is where Strong Hire vs Hire is decided. Candidates who stay shallow get a marginal Hire; those who articulate trade-offs and handle curveballs get Strong Hire.

---

## Phase 4: Wrap-up (5 min)

### Goals
- Identify **bottlenecks** and how you’d address them
- Discuss **monitoring** and **observability**
- Mention **security** (auth, encryption, DDoS)
- Suggest **future improvements** (scale, features, tech debt)

### What to Do
- "If we scale 10x, the bottleneck would be X; we’d address it by Y"
- "We’d monitor latency p99, error rate, cache hit ratio, queue depth"
- "For security: auth tokens, HTTPS, rate limiting, input validation"
- "Future: add CDN for static assets, consider event sourcing"

### What Interviewers Evaluate
- Do you think about production?
- Do you consider operational concerns?
- Can you extend the design for the future?

---

## Scoring Rubric — Hire vs No Hire

| Signal | Hire / Strong Hire | No Hire |
|--------|--------------------|---------|
| **Requirements** | Asks questions, clarifies scope, states assumptions | Jumps to solution, ignores constraints |
| **Architecture** | Reasonable components, coherent flow, justified choices | Wrong components, incoherent, no justification |
| **Deep Dive** | Explains trade-offs, handles what-ifs, shows depth | Stays superficial, can’t justify, doesn’t handle failure |
| **Communication** | Leads conversation, explains clearly, collaborates | Silent, unclear, doesn’t engage |
| **Time Management** | Covers all phases, leaves room for wrap-up | Runs out of time, skips phases |
| **Recovery** | Recovers from mistakes, adapts to feedback | Defensive, rigid, gives up when stuck |

---

## Rough Calibration

| Outcome | Typical Profile |
|---------|-----------------|
| **Strong Hire** | Excellent requirements, coherent design, deep trade-off discussion, handles curveballs, mentions monitoring/security |
| **Hire** | Good requirements, sensible design, some depth, acceptable communication |
| **Lean Hire** | Adequate design, some gaps in depth or communication, recoverable mistakes |
| **No Hire** | Skips requirements, wrong components, no trade-offs, poor communication, or gives up |

---

## Summary Checklist

- [ ] Phase 1: Functional, non-functional, constraints, out of scope
- [ ] Phase 2: Components, data flow, API, data model
- [ ] Phase 3: Deep dive on 1–2 components, trade-offs, what-ifs
- [ ] Phase 4: Bottlenecks, monitoring, security, future
- [ ] Throughout: Lead the conversation, state assumptions, justify choices
