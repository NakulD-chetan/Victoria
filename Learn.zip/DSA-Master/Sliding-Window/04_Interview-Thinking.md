# Sliding Window — Interview Thinking

> **How to think, communicate, and reason about sliding window problems in a FAANG interview. This is not about code — it's about HOW the interviewer expects you to approach the problem.**

---

## The FAANG Interview Flow (Step by Step)

### Phase 1: Understand (2-3 minutes)

**What the interviewer expects you to do:**
- Read the problem carefully
- Ask clarifying questions
- Identify constraints

**What to say:**

> "Let me make sure I understand the problem. We have an array of [type], and we need to find [goal]. Can I confirm: are the values always non-negative? Can the array be empty? Is k always valid (≤ n)?"

**Why this matters:** FAANG interviewers score you on **clarification before coding**. Jumping straight to code is a red flag.

### Phase 2: Identify the Pattern (1-2 minutes)

**What to say when you recognize sliding window:**

> "I notice we're looking for a [longest/shortest/maximum] [contiguous subarray/substring] with [constraint]. This is a classic sliding window pattern."

**How to justify:**

> "The brute force would check all O(n²) subarrays, but since we're looking at contiguous elements and can maintain a running [sum/count/frequency], we can slide a window in O(n) time."

**Do NOT say:** "I've seen this problem before" — interviewers want to see reasoning, not memorization.

### Phase 3: Explain Approach Before Coding (2-3 minutes)

**Structure your explanation:**

1. **State the approach:**
   > "I'll use two pointers, left and right, defining a window."

2. **Explain the window state:**
   > "I'll maintain a [running sum / hash map of frequencies / count of distinct elements]."

3. **Explain expansion:**
   > "I'll expand right on every iteration, adding the new element to my state."

4. **Explain contraction:**
   > "When the window becomes invalid — meaning [specific condition] — I'll shrink from the left until valid again."

5. **Explain answer tracking:**
   > "I'll track the [maximum window size / minimum window size / best sum] throughout."

6. **State complexity:**
   > "This runs in O(n) time because each element enters and leaves the window at most once. Space is O(1) [or O(k)]."

### Phase 4: Code (15-20 minutes)

**What the interviewer watches for:**
- Clean variable names (`left`, `right`, not `i`, `j`)
- Clear structure (initialize → expand → shrink → update)
- Edge case handling
- Running commentary while coding

**What to say while coding:**

> "First I'll initialize my window state... Now the right pointer iterates through the array... Here I'm adding the new element... And this while loop handles shrinking when [condition]... After shrinking, the window is valid so I update my answer..."

### Phase 5: Test (3-5 minutes)

Walk through your code with an example:

> "Let me trace through: arr = [2, 1, 5, 1, 3, 2], k = 3. Initial window: [2,1,5], sum = 8. Slide: remove 2, add 1 → sum = 7. Slide: remove 1, add 3 → sum = 9. Continue..."

---

## How to Justify Pointer Movement

### The Core Argument

**Why does left only move forward?**

> "We never need to move left backward because we've already considered all windows ending before the current right. Moving left backward would revisit already-explored territory."

**Why is this O(n) despite nested loops?**

> "Although there's a while loop inside the for loop, the left pointer moves at most n times *total* across all iterations. So the inner loop's total work across the entire algorithm is O(n), giving us O(n) overall."

### For Fixed Window

> "Since the window size is fixed at k, both pointers move in lockstep. Each step, one element enters and one leaves — constant work per step, n steps total."

### For Variable Window

> "Right pointer: n advances total. Left pointer: at most n advances total. Each element is added once and removed once. Total work: O(2n) = O(n)."

---

## How to Communicate Your Approach

### The 30-Second Elevator Pitch

Memorize this structure:

> "This is a sliding window problem because [reason]. I'll maintain [state] in a window defined by left and right pointers. I expand by [action], shrink when [condition], and track [answer]. Time: O(n), Space: O([space])."

### Example Pitches

**Maximum sum subarray of size k:**
> "This is a fixed-size sliding window. I'll maintain a running sum. I expand by adding the rightmost element, and when the window exceeds size k, I remove the leftmost element. I track the maximum sum seen."

**Longest substring without repeating characters:**
> "This is a variable sliding window. I'll maintain a hash set of characters in the current window. I expand by adding the right character. If it's a duplicate, I shrink from the left until it's no longer a duplicate. I track the maximum valid window length."

**Minimum window substring:**
> "This is a variable sliding window with frequency matching. I'll maintain two frequency maps — one for the target string, one for the current window. I expand right until all target characters are present, then shrink left to minimize the window while it's still valid."

---

## Optimization Explanation Strategy

### Step 1: Start with Brute Force

**Always mention brute force first.** This shows you understand the problem.

> "The brute force approach would enumerate all subarrays (O(n²)) and check each one. For each starting index, we'd iterate through all ending indices, maintaining the [sum/count/etc]. This gives us O(n²) time."

### Step 2: Identify the Redundancy

> "The key observation is that consecutive windows overlap. When we shift the window by one position, we're recomputing n-1 elements that we already know about. We're doing redundant work."

### Step 3: Introduce the Optimization

> "Instead of recomputing from scratch, we can maintain a running state. When an element enters the window, we add it. When an element leaves, we remove it. This way, each element is processed at most twice — once when entering, once when leaving."

### Step 4: Prove Correctness

> "This is correct because we examine every possible valid window. The right pointer ensures we consider every ending position. The left pointer ensures we find the optimal starting position for each end."

---

## Common Follow-Up Questions (and How to Answer)

### "Can you do better than O(n)?"

> "No — we need to examine every element at least once to be sure we haven't missed the optimal window. O(n) is optimal for this problem."

### "What if the array has negative numbers?"

> "Good question. With negative numbers, expanding the window might decrease the sum and shrinking might increase it. The monotonicity property that sliding window relies on would break. We'd need a different approach — perhaps prefix sums with binary search, or a deque-based solution."

### "Can you do this in-place / O(1) space?"

> "If the window state is just a running sum or a few variables, yes — O(1) space. If we need a frequency map, the space is O(alphabet size) which is O(26) = O(1) for lowercase English letters, or O(k) for k distinct elements."

### "What about the edge case where..."

Always respond with: "Great catch. Let me handle that." Then trace through the edge case with your code.

---

## Red Flags Interviewers Watch For

| Red Flag | What It Signals | Better Approach |
|----------|----------------|-----------------|
| Immediately writing code | Doesn't think before coding | "Let me understand the problem first" |
| Using i, j as variable names | Unclear code | Use `left`, `right`, `window_sum` |
| Not mentioning brute force | Can't compare approaches | Always start with brute force |
| Saying "I've seen this before" | Memorization, not understanding | "This reminds me of sliding window because..." |
| Not testing edge cases | Incomplete thinking | "Let me check: empty input, single element, all same values" |
| Can't explain O(n) complexity | Doesn't understand amortized analysis | "Left moves at most n times total" |

---

## The Golden Communication Framework

```mermaid
flowchart TD
    S1["1. CLARIFY — Can I confirm...?"] --> S2["2. OBSERVE — I notice this is contiguous..."]
    S2 --> S3["3. PATTERN — This suggests sliding window"]
    S3 --> S4["4. BRUTE FORCE — Brute force would be O n²..."]
    S4 --> S5["5. OPTIMIZE — But we can reuse computation..."]
    S5 --> S6["6. APPROACH — I will use left/right pointers..."]
    S6 --> S7["7. COMPLEXITY — O n time, O 1 space"]
    S7 --> S8["8. CODE — Write clean, commented code"]
    S8 --> S9["9. TEST — Trace through example + edges"]
    S9 --> S10["10. IMPROVE — If needed, we could also..."]

    style S1 fill:#ff922b,color:#fff
    style S3 fill:#339af0,color:#fff
    style S5 fill:#51cf66,color:#fff
    style S8 fill:#cc5de8,color:#fff
    style S9 fill:#fcc419,color:#000
```

<details><summary>ASCII fallback</summary>

```
┌─────────────────────────────────────────────────────────┐
│  STEP 1: CLARIFY      "Can I confirm...?"              │
│  STEP 2: OBSERVE      "I notice this is contiguous..." │
│  STEP 3: PATTERN      "This suggests sliding window"   │
│  STEP 4: BRUTE FORCE  "Brute force would be O(n²)..."  │
│  STEP 5: OPTIMIZE     "But we can reuse computation..." │
│  STEP 6: APPROACH     "I'll use left/right pointers..." │
│  STEP 7: COMPLEXITY   "O(n) time, O(1) space"          │
│  STEP 8: CODE         Write clean, commented code       │
│  STEP 9: TEST         Trace through example + edges     │
│  STEP 10: IMPROVE     "If needed, we could also..."    │
└─────────────────────────────────────────────────────────┘
```
</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Sliding Window Interview
CLARIFY FIRST:      Ask about constraints, negatives, empty input
IDENTIFY PATTERN:   "Contiguous + optimize → sliding window"
JUSTIFY:            "Each element enters/exits once → O(n)"
COMMUNICATE:        Approach → State → Expand → Shrink → Track → Complexity
BRUTE FORCE:        Always mention O(n²) brute force first
CODE STYLE:         Descriptive names, clear structure, running commentary
TEST:               Walk through example, check edges
INTERVIEW LINE:     "The brute force is O(n²) because we recompute overlapping
                     windows. Sliding window reuses computation by maintaining
                     a running state, giving us O(n)."
```

---

## 30-SECOND REVISION BOX

```
FLOW: Clarify → Observe contiguous → Pattern → Brute O(n²) → Optimize O(n)
SAY:  "contiguous subarray + optimize → sliding window"
JUSTIFY: "each element enters/exits once → O(n)"
CODE:  Descriptive names (left/right not i/j), running commentary
TEST:  Trace example + edges (empty, single, all same)
```
