# Indexes and Optimization — Concept

> **Permanent recall:** An **index** is a separate data structure (B-tree, hash) that speeds up lookups at the cost of extra writes. **Clustered** = data sorted on disk; **non-clustered** = pointer structure. `EXPLAIN` reveals what the optimizer actually does.

---

## Why indexes exist

Without index → **full table scan** (O(n)). With index → **B-tree lookup** (O(log n)).

---

## Index types

| Type | What | Details |
|------|------|---------|
| **Clustered** | Data rows physically sorted by index key | Exactly **1** per table (usually PK). Leaf nodes = actual data rows |
| **Non-clustered** | Separate B-tree with pointers to rows | **Multiple** allowed. Leaf nodes = pointers (row locators) |
| **Composite** | Index on (col1, col2, …) | **Leftmost prefix** rule applies |
| **Covering** | Index contains all queried columns | No table lookup needed (index-only scan) |
| **Unique** | Enforces uniqueness — also used for constraints | Auto-created for PK and UNIQUE constraints |
| **Partial / Filtered** | Index on subset of rows | Postgres: `CREATE INDEX ... WHERE active = TRUE` |
| **Hash** | O(1) exact match — no range support | Used in memory-optimized tables, some engines |
| **Full-text** | For text search (words, phrases) | `FULLTEXT INDEX` in MySQL; `tsvector` in Postgres |
| **Bitmap** | Bit array for low-cardinality columns | Oracle; good for data warehouses |
| **GIN / GiST** | For JSON, arrays, full-text, geometric | PostgreSQL-specific |

---

## Clustered vs Non-Clustered (detailed)

| Feature | Clustered | Non-Clustered |
|---------|-----------|---------------|
| **Number per table** | 1 only | Multiple allowed |
| **Data storage** | Data rows ARE the leaf nodes | Separate structure, pointers to data |
| **Speed for range scans** | Fastest (data physically sorted) | Needs lookup to actual row |
| **Insert cost** | Higher (must maintain physical order) | Lower (just update separate structure) |
| **Default** | Usually created on PK | Must be created explicitly |

---

## When to index

- Columns in **WHERE**, **JOIN ON**, **ORDER BY**, **GROUP BY**
- High **selectivity** (many distinct values → good candidate)
- **Don't** index everything — writes (INSERT/UPDATE/DELETE) slow down; space cost
- **Don't** index low-cardinality columns (boolean, gender) — optimizer may ignore

---

## EXPLAIN / query plan

- Shows **access type** (seq scan, index scan, index-only scan, nested loop, hash join, merge join)
- Look for: **full table scan** on large table → missing index
- Look for: **filesort**, **temporary table** → possible improvement
- `EXPLAIN ANALYZE` (Postgres) shows actual execution time

---

## Optimization habits

1. **SELECT only needed columns** (helps covering index)
2. **Avoid functions on indexed column in WHERE** (`WHERE YEAR(date) = …` → can't use date index; rewrite as range)
3. **Use LIMIT** where possible
4. **Analyze** periodically for up-to-date statistics
5. **Use EXISTS instead of COUNT** for existence checks
6. **Avoid SELECT *** in production

---

## View — Definition

A **View** is a **virtual table** based on a stored SQL query. It does NOT store data — every time you query the view, the underlying query re-executes.

```sql
CREATE VIEW active_users AS
SELECT id, name, email FROM users WHERE active = TRUE;

SELECT * FROM active_users;  -- runs the underlying query
```

### View — Pros and Cons

| Pros | Cons |
|------|------|
| Simplifies complex queries (abstraction) | No performance gain (re-executes every time) |
| Security — expose subset of columns/rows | Cannot index a view directly (most DBs) |
| Consistent interface (schema changes hidden) | Can be slow if underlying query is complex |
| Reusable across multiple queries | Updating through view has restrictions |

### Updatable View

A view is updatable if it:
- References one base table (no joins, no aggregates)
- Includes PK of base table
- Has no DISTINCT, GROUP BY, HAVING, UNION
- Rules vary by DB engine

---

## Materialized View — Definition

A **Materialized View** (MV) is a view that **stores the result physically** on disk. It's a precomputed snapshot that must be **refreshed** to stay current.

```sql
-- Create (Postgres)
CREATE MATERIALIZED VIEW mv_daily_revenue AS
SELECT DATE(order_ts) AS d, SUM(amount) AS rev
FROM orders GROUP BY 1;

-- Refresh (manually or scheduled)
REFRESH MATERIALIZED VIEW mv_daily_revenue;
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_daily_revenue;  -- no lock
```

### Materialized View — Pros and Cons

| Pros | Cons |
|------|------|
| **Fast reads** — data precomputed, no re-execution | **Stale data** — snapshot, not real-time |
| Can be **indexed** for even faster queries | **Storage cost** — stores duplicate data |
| Great for **dashboards, reports, analytics** | **Refresh cost** — takes time, can block |
| Reduces load on base tables | Not available in all DBs (MySQL lacks native MV) |
| Can include complex joins/aggregations | CONCURRENT refresh needs unique index |

### View vs Materialized View

| Feature | View | Materialized View |
|---------|------|-------------------|
| **Stores data** | No (virtual) | Yes (physical snapshot) |
| **Fresh data** | Always current | Stale until refreshed |
| **Query speed** | Same as underlying query | Fast (precomputed) |
| **Storage** | None | Uses disk space |
| **Indexable** | No (usually) | Yes |
| **Use case** | Abstraction, security | Performance, reporting |

---

## Stored Procedure — Definition

A **Stored Procedure** is a precompiled collection of SQL statements stored in the database. Executed with `CALL` or `EXEC`.

```sql
CREATE PROCEDURE raise_salary(IN emp INT, IN amount DECIMAL)
BEGIN
    UPDATE employees SET salary = salary + amount WHERE emp_id = emp;
END;

CALL raise_salary(101, 5000);
```

### Stored Procedure — Pros and Cons

| Pros | Cons |
|------|------|
| **Performance** — precompiled, cached execution plan | **Portability** — syntax varies across DBs |
| **Security** — grant EXECUTE without table access | **Debugging** — harder to debug than app code |
| **Reusability** — call from multiple applications | **Version control** — harder to manage in git |
| **Network** — reduces round-trips (multiple statements in one call) | **Business logic in DB** — tight coupling |
| Can use variables, loops, IF/ELSE, transactions | **Testing** — harder to unit test |

---

## Function (UDF) — Definition

A **User-Defined Function** returns a value and can be used in SQL expressions (SELECT, WHERE).

### Stored Procedure vs Function

| Feature | Stored Procedure | Function |
|---------|-----------------|----------|
| **Returns** | 0 or more result sets (via OUT params) | Must return a single value (scalar) or table |
| **Called with** | `CALL` / `EXEC` | Used in SQL expressions (`SELECT fn()`) |
| **DML allowed** | Yes (INSERT, UPDATE, DELETE) | Depends on DB (often restricted) |
| **Transaction control** | Can COMMIT/ROLLBACK | Usually cannot |
| **Use in WHERE/SELECT** | No | Yes |

---

## Trigger — Definition

A **Trigger** is a special procedure that automatically executes (fires) when a specific DML event (INSERT, UPDATE, DELETE) occurs on a table.

```sql
CREATE TRIGGER log_update
AFTER UPDATE ON employees
FOR EACH ROW
INSERT INTO audit_log VALUES (OLD.emp_id, OLD.salary, NEW.salary, NOW());
```

### Trigger Types

| Type | When it fires |
|------|--------------|
| **BEFORE** | Before the DML operation (can modify NEW values) |
| **AFTER** | After the DML operation (for logging, cascading) |
| **INSTEAD OF** | Replaces the operation (used with views) |

### Trigger — Pros and Cons

| Pros | Cons |
|------|------|
| Automatic — no application code needed | Hidden logic — hard to debug |
| Enforce complex business rules | Performance — fires on every affected row |
| Audit logging | Cascading triggers — can cause loops |
| Referential actions beyond FK | Harder to maintain and test |

---

## Cursor — Definition

A **Cursor** is a database object that allows row-by-row processing of a result set (instead of set-based operations).

### Cursor — Why avoid?

| Issue | Why |
|-------|-----|
| **Slow** | Row-by-row = O(n) with overhead per row; set-based SQL is optimized |
| **Resource-heavy** | Holds memory and locks for duration |
| **Anti-pattern** | Almost always replaceable with set-based SQL (JOINs, CTEs, window functions) |

**Use only when:** Complex row-by-row logic that truly cannot be expressed in set-based SQL (rare).

---

## Table Partitioning

Splitting a large table into smaller physical pieces while appearing as one logical table.

| Type | How it splits |
|------|--------------|
| **Range** | By value ranges (dates, IDs) — most common |
| **List** | By specific values (country, status) |
| **Hash** | By hash function (even distribution) |
| **Composite** | Combination (range + hash) |

**Pros:** Faster queries on partition key, easier data management (drop old partitions), parallel scans.
**Cons:** Cross-partition queries can be slower, adds complexity.

---

## OLTP vs OLAP

| Feature | OLTP | OLAP |
|---------|------|------|
| **Full name** | Online Transaction Processing | Online Analytical Processing |
| **Purpose** | Day-to-day transactions | Reporting, analytics, BI |
| **Operations** | INSERT, UPDATE, DELETE (frequent) | SELECT (complex aggregations) |
| **Schema** | Normalized (3NF) | Denormalized (star/snowflake) |
| **Data** | Current, operational | Historical, aggregated |
| **Queries** | Simple, short, frequent | Complex, long-running, few |
| **Example** | Banking app, e-commerce | Data warehouse, dashboards |

---

## Query Optimization Checklist

1. Check EXPLAIN output
2. Add indexes on WHERE/JOIN/ORDER BY columns
3. Avoid `SELECT *`
4. Avoid functions on indexed columns in WHERE
5. Use covering indexes for frequent queries
6. Pre-aggregate with materialized views for dashboards
7. Use `EXISTS` instead of `COUNT` for existence
8. Limit result set with LIMIT/TOP
9. Use connection pooling
10. Keep statistics updated (ANALYZE)

---

*Next: [[02_Mental-Model]]*
