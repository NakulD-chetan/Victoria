# Internals: gRPC and HTTP/2 Streaming — Low-Level Deep Dive

> **Permanent Recall:** gRPC is an RPC framework built on HTTP/2. One Channel = one HTTP/2 connection (or pool). Stubs are generated from .proto files. Every gRPC call maps to HTTP/2: :method POST, :path /package.Service/Method, content-type application/grpc. gRPC message frame: [1 byte compressed flag][4 bytes length][protobuf bytes]. Four RPC types: Unary (1:1), Server streaming (1:N), Client streaming (N:1), Bidirectional (N:N). Status sent as HTTP/2 trailers (grpc-status, grpc-message). gRPC wins on latency, throughput, and streaming; REST sufficient for simple CRUD and browser-first APIs.

---

## 1. gRPC Architecture — Channel, Stub, Server, Service, Method

```
gRPC ARCHITECTURE — FULL STACK:

┌─────────────────────────────────────────────────────────────────────────────────┐
│                           CLIENT SIDE                                            │
│                                                                                 │
│  ┌─────────────┐    ┌─────────────────────────────────────────────────────┐    │
│  │ Application │    │  Generated Stub (from .proto)                       │    │
│  │   Code      │───►│  UserServiceStub.GetUser(req) → User                │    │
│  │             │    │  UserServiceStub.ListUsers(req) → Stream<User>      │    │
│  └─────────────┘    └──────────────────────┬──────────────────────────────┘    │
│                                            │                                    │
│                                            ▼                                    │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  Channel (ManagedChannel)                                                │   │
│  │  • Represents connection to gRPC server(s)                              │   │
│  │  • One Channel = one HTTP/2 connection (or connection pool)             │   │
│  │  • Handles: connection lifecycle, load balancing, keepalive            │   │
│  │  • Created once, reused for all RPCs to same target                     │   │
│  └──────────────────────────────────────┬──────────────────────────────────┘   │
│                                         │                                       │
└─────────────────────────────────────────┼───────────────────────────────────────┘
                                          │
                    ┌─────────────────────┼─────────────────────┐
                    │   HTTP/2 Connection  │  (TLS optional)     │
                    │   Multiplexed Streams│                     │
                    └─────────────────────┼─────────────────────┘
                                          │
┌─────────────────────────────────────────┼───────────────────────────────────────┐
│                           SERVER SIDE   │                                       │
│                                         ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  gRPC Server                                                             │   │
│  │  • Listens on port (e.g., 50051)                                         │   │
│  │  • Accepts HTTP/2 connections                                           │   │
│  │  • Routes requests to registered Services                                │   │
│  └──────────────────────────────────────┬──────────────────────────────────┘   │
│                                         │                                       │
│                                         ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  Service (UserService)                                                   │   │
│  │  • Implements service interface from .proto                             │   │
│  │  • Contains one or more Methods                                         │   │
│  │  • GetUser(req) → User                                                  │   │
│  │  • ListUsers(req) → Stream<User>                                        │   │
│  └──────────────────────────────────────┬──────────────────────────────────┘   │
│                                         │                                       │
│                                         ▼                                       │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │  Application Handler (your business logic)                              │   │
│  │  • GetUser: fetch from DB, return User                                  │   │
│  │  • ListUsers: stream rows from DB as they're read                       │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

MAPPING: .proto → Code Generation → Runtime

  user.proto:
    service UserService {
      rpc GetUser(GetUserRequest) returns (User);           // Unary
      rpc ListUsers(ListRequest) returns (stream User);     // Server streaming
    }

  Generated (e.g., Java):
    UserServiceGrpc.UserServiceBlockingStub stub =
      UserServiceGrpc.newBlockingStub(channel);
    User user = stub.getUser(request);  // Blocks until response

  Generated (e.g., Go):
    client := pb.NewUserServiceClient(conn)
    stream, err := client.ListUsers(ctx, &pb.ListRequest{})
    for { user, err := stream.Recv(); ... }
```

### How a gRPC Call Maps to HTTP/2

```
SINGLE gRPC UNARY CALL → HTTP/2 REQUEST/RESPONSE:

  Application:  stub.GetUser(GetUserRequest{id: 123})

  HTTP/2 Request (one stream, e.g., stream ID 1):
    HEADERS frame:
      :method = POST
      :path = /user.UserService/GetUser
      :scheme = https
      :authority = api.example.com
      content-type = application/grpc
      te = trailers                    ← Required! Server sends status in trailers
      grpc-timeout = 10S               ← Deadline (optional)
      [custom metadata as headers]

    DATA frame:
      [gRPC message frame: 1 byte flag + 4 bytes length + protobuf bytes]

    END_STREAM flag on DATA frame (request body complete)

  HTTP/2 Response (same stream 1):
    HEADERS frame:
      :status = 200
      content-type = application/grpc
      [custom metadata]

    DATA frame:
      [gRPC message frame: User protobuf serialized]

    HEADERS frame (trailers, END_STREAM=1):
      grpc-status = 0                  ← 0 = OK
      grpc-message = ""                ← Empty for success
```

### One Channel = One HTTP/2 Connection (or Pool)

```
CHANNEL TO CONNECTION MAPPING:

  Channel (logical):
    channel = ManagedChannelBuilder.forTarget("api.example.com:50051").build()

  Under the hood:
    ┌──────────────────────────────────────────────────────────────┐
    │  Subchannel (physical connection)                            │
    │  • One TCP connection                                        │
    │  • One HTTP/2 connection (multiplexed)                       │
    │  • All RPCs over this channel share this connection          │
    │                                                              │
    │  With connection pooling (e.g., multiple backends):          │
    │  Subchannel 1 → backend-1:50051                              │
    │  Subchannel 2 → backend-2:50051                              │
    │  Subchannel 3 → backend-3:50051                              │
    │  Load balancer picks subchannel per RPC                      │
    └──────────────────────────────────────────────────────────────┘

  Key insight: Channel is REUSED. Never create a new channel per RPC.
  Creating channel = TCP handshake + TLS + HTTP/2 preface = expensive!
```

---

## 2. gRPC over HTTP/2 Wire Format — Byte-Level Encoding

```
gRPC WIRE FORMAT — EXACT BYTES ON THE WIRE:

HTTP/2 HEADERS FOR gRPC REQUEST:
┌────────────────────────────────────────────────────────────────────────────┐
│ Pseudo-headers (required):                                                  │
│   :method       = POST                                                      │
│   :path         = /package.ServiceName/MethodName                           │
│   :scheme       = https (or http)                                           │
│   :authority    = host:port                                                 │
│                                                                             │
│ gRPC-specific headers:                                                      │
│   content-type  = application/grpc                                         │
│   te            = trailers              ← MUST be present (case-sensitive)  │
│   grpc-encoding = gzip (optional)       ← Compression: identity, gzip, etc. │
│   grpc-timeout  = 10S (optional)       ← Deadline in format: 1H2M3S4N      │
│   grpc-accept-encoding = gzip (optional) ← Client accepts these encodings   │
│                                                                             │
│ Custom metadata: grpc- prefixed or custom (e.g., x-custom-auth)             │
└────────────────────────────────────────────────────────────────────────────┘

gRPC MESSAGE FRAME (inside HTTP/2 DATA frame payload):
┌────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  Byte 0:        Compressed-flag (1 byte)                                   │
│                 0 = uncompressed (identity)                                 │
│                 1 = compressed (e.g., gzip)                                 │
│                                                                             │
│  Bytes 1-4:     Message length (4 bytes, big-endian)                       │
│                 Length of the following message in bytes                    │
│                 Max: 2^32 - 1 (4 GB)                                       │
│                 In practice: often 4 MB default limit                       │
│                                                                             │
│  Bytes 5+:      Message (protobuf serialized bytes)                         │
│                 Length = value from bytes 1-4                               │
│                                                                             │
│  Total frame size = 5 + message_length bytes                                │
│                                                                             │
└────────────────────────────────────────────────────────────────────────────┘

BYTE-LEVEL EXAMPLE: GetUserRequest{user_id: 123}

  Protobuf encoding of user_id=123:
    Field 1, wire type 0 (varint): 123
    → 0x08 0x7B  (2 bytes)
      (0x08 = field 1, wire 0; 0x7B = 123 in varint)

  gRPC frame:
    [0x00] [0x00 0x00 0x00 0x02] [0x08 0x7B]
      │           │                  │
      │           │                  └── Protobuf message (2 bytes)
      │           └── Length = 2 (big-endian 32-bit)
      └── Compressed = 0 (uncompressed)

  This 7-byte gRPC frame is placed in HTTP/2 DATA frame payload.
  HTTP/2 DATA frame: 9-byte header + 7-byte payload = 16 bytes on wire.
```

### HTTP/2 Frame Encapsulation

```
FULL STACK: Application → Wire

  Application object:  GetUserRequest{user_id: 123}

  Step 1: Protobuf serialize
    → 0x08 0x7B (2 bytes)

  Step 2: gRPC frame wrap
    → [0x00][0x00 0x00 0x00 0x02][0x08 0x7B] (7 bytes)

  Step 3: HTTP/2 DATA frame
    ┌─────────────────────────────────────────────────┐
    │ Length: 7 (24 bits)                             │
    │ Type: 0x00 (DATA)                               │
    │ Flags: 0x01 (END_STREAM if last message)        │
    │ Stream ID: 1                                    │
    │ Payload: [0x00 0x00 0x00 0x00 0x02 0x08 0x7B]  │
    └─────────────────────────────────────────────────┘

  Step 4: TLS record (if HTTPS)
    → Encrypted with AES-GCM

  Step 5: TCP segment
    → IP packet → NIC → wire
```

---

## 3. Four RPC Types Deep Dive — HTTP/2 Frame Sequences

```
FOUR gRPC RPC TYPES:

  Unary:           1 request  → 1 response
  Server stream:   1 request  → N responses
  Client stream:   N requests → 1 response
  Bidirectional:   N requests ↔ N responses (full duplex)
```

### Unary RPC — 1 Request, 1 Response

```
UNARY: GetUser(request) → User

Client                                                    Server
  │                                                          │
  │  HEADERS (stream 1)                                      │
  │  :method=POST, :path=/user.UserService/GetUser           │
  │  content-type=application/grpc, te=trailers              │
  │  END_HEADERS                                             │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │  DATA (stream 1)                                         │
  │  [gRPC frame: GetUserRequest]                            │
  │  END_STREAM                                              │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │                                    Server processes      │
  │                                                          │
  │  HEADERS (stream 1)                                      │
  │  :status=200, content-type=application/grpc              │
  │  END_HEADERS                                             │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  DATA (stream 1)                                         │
  │  [gRPC frame: User]                                      │
  │  END_STREAM                                              │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  HEADERS (stream 1) TRAILERS                             │
  │  grpc-status=0, grpc-message=                             │
  │  END_STREAM, END_HEADERS                                  │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  Stream 1 closed. RPC complete.                           │
```

### Server Streaming — 1 Request, N Responses

```
SERVER STREAMING: ListUsers(request) → stream User

Client                                                    Server
  │                                                          │
  │  HEADERS (stream 3)                                      │
  │  :method=POST, :path=/user.UserService/ListUsers         │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │  DATA (stream 3) [ListRequest] END_STREAM                 │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │  HEADERS (stream 3) :status=200                           │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  DATA (stream 3) [User 1]     ← No END_STREAM             │
  │  ◄───────────────────────────────────────────────────    │
  │  DATA (stream 3) [User 2]     ← No END_STREAM             │
  │  ◄───────────────────────────────────────────────────    │
  │  DATA (stream 3) [User 3]     ← No END_STREAM             │
  │  ◄───────────────────────────────────────────────────    │
  │  ...                                                      │
  │                                                          │
  │  HEADERS (stream 3) TRAILERS                              │
  │  grpc-status=0                                            │
  │  END_STREAM, END_HEADERS   ← Stream ends with trailers   │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  Client receives users one-by-one as they're produced.    │
```

### Client Streaming — N Requests, 1 Response

```
CLIENT STREAMING: UploadLogs(stream LogEntry) → UploadResult

Client                                                    Server
  │                                                          │
  │  HEADERS (stream 5)                                      │
  │  :method=POST, :path=/logs.LogService/UploadLogs         │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │  DATA (stream 5) [LogEntry 1]  ← No END_STREAM            │
  │  ───────────────────────────────────────────────────►   │
  │  DATA (stream 5) [LogEntry 2]  ← No END_STREAM            │
  │  ───────────────────────────────────────────────────►   │
  │  DATA (stream 5) [LogEntry 3]  ← No END_STREAM            │
  │  ───────────────────────────────────────────────────►   │
  │  DATA (stream 5) [] END_STREAM  ← Empty DATA + END_STREAM │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │                                    Server processes all  │
  │                                                          │
  │  HEADERS (stream 5) :status=200                           │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  DATA (stream 5) [UploadResult] END_STREAM                │
  │  ◄───────────────────────────────────────────────────    │
  │                                                          │
  │  HEADERS (stream 5) TRAILERS grpc-status=0                │
  │  ◄───────────────────────────────────────────────────    │
```

### Bidirectional Streaming — N Requests, N Responses

```
BIDIRECTIONAL: Chat(stream Message) → stream Message

Client                                                    Server
  │                                                          │
  │  HEADERS (stream 7)                                      │
  │  :method=POST, :path=/chat.ChatService/Chat               │
  │  ───────────────────────────────────────────────────►   │
  │                                                          │
  │  DATA [Message "Hi"]        ─────────────────────────►   │
  │                                                          │
  │  DATA [Message "How are you?"] ──────────────────────►   │  (can interleave!)
  │                                                          │
  │  DATA [Message "Hello!"]    ◄─────────────────────────   │
  │                                                          │
  │  DATA [Message "I'm good"]  ◄─────────────────────────   │
  │                                                          │
  │  ... Full duplex: both sides send/receive concurrently    │
  │                                                          │
  │  Client sends END_STREAM when done sending               │
  │  Server sends END_STREAM when done sending               │
  │  Trailers (grpc-status) sent with final HEADERS          │
```

### END_STREAM Flag Usage

```
END_STREAM SEMANTICS:

  Request direction (client → server):
    END_STREAM on last DATA frame = "I'm done sending request body"
    For unary: END_STREAM on the one DATA frame
    For client/bidi stream: END_STREAM when client calls CloseSend()

  Response direction (server → client):
    END_STREAM on last frame = "Response is complete"
    Can be on: final DATA frame OR on HEADERS (trailers) frame
    For unary: END_STREAM on DATA (single response) or on trailers
    For server stream: END_STREAM on trailers (after last DATA)

  Trailers ALWAYS have END_STREAM:
    grpc-status and grpc-message are in HEADERS frame with END_STREAM=1
    This closes the stream from server's perspective
```

---

## 4. gRPC Status and Trailers — Why Trailers, Not Headers

```
WHY TRAILERS, NOT HEADERS:

  HTTP/1.1: Headers sent first, then body. Status known upfront.
  gRPC:     Response body = stream of DATA frames. Status unknown until end.

  Problem: Server streaming sends N DATA frames. When does it end?
  Solution: Trailers come AFTER the last DATA frame. They carry the status.

  ┌──────────────────────────────────────────────────────────────┐
  │  HEADERS (response start)                                     │
  │    :status = 200        ← HTTP says "OK" (always 200 for gRPC)│
  │    content-type = application/grpc                           │
  │                                                              │
  │  DATA [message 1]                                             │
  │  DATA [message 2]                                             │
  │  ...                                                          │
  │  DATA [message N]                                             │
  │                                                              │
  │  HEADERS (trailers, END_STREAM)                                │
  │    grpc-status = 0      ← ACTUAL RPC status (0 = OK)         │
  │    grpc-message = ""    ← Human-readable error message        │
  │                                                              │
  │  If status != 0: trailers may be sent WITHOUT any DATA       │
  │  (immediate error response)                                   │
  └──────────────────────────────────────────────────────────────┘

  This is why "te: trailers" is REQUIRED in request:
    Tells server: "I understand and will read trailers"
    Without it: server might not send trailers (legacy behavior)
```

### gRPC Status Codes

```
grpc-status CODES (numeric):

  0   OK                  Success
  1   CANCELLED           Operation cancelled (e.g., client cancelled, deadline)
  2   UNKNOWN             Unknown error (catch-all)
  3   INVALID_ARGUMENT    Invalid argument (e.g., malformed request)
  4   DEADLINE_EXCEEDED   Deadline expired before operation completed
  5   NOT_FOUND           Resource not found
  6   ALREADY_EXISTS      Resource already exists
  7   PERMISSION_DENIED   Caller lacks permission
  8   RESOURCE_EXHAUSTED  Quota exhausted (rate limit, disk full)
  9   FAILED_PRECONDITION  Operation rejected (e.g., wrong state)
  10  ABORTED             Concurrency conflict, retry may help
  11  OUT_OF_RANGE        Out of valid range
  12  UNIMPLEMENTED       Method not implemented
  13  INTERNAL            Internal server error
  14  UNAVAILABLE        Service unavailable (transient, retry)
  15  DATA_LOSS           Unrecoverable data loss/corruption
  16  UNAUTHENTICATED     Request does not have valid auth credentials

grpc-message: Human-readable string (e.g., "user_id must be positive")
```

### Error Response Format

```
ERROR RESPONSE (no DATA, just trailers):

  Client sends request
  Server encounters error before/during processing

  Server responds:
    HEADERS :status=200  content-type=application/grpc
    (No DATA frames — no response body)
    HEADERS (trailers) grpc-status=3 grpc-message="user_id must be positive"
    END_STREAM

  Client parses trailers, sees grpc-status=3 (INVALID_ARGUMENT)
  Client surfaces error to application
```

---

## 5. Protobuf Serialization in gRPC — Full Pipeline

```
SERIALIZATION PIPELINE: Application → Wire

┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 1: Application Object                                                      │
│                                                                                 │
│  GetUserRequest{ user_id: 123 }                                                  │
│  (in-memory struct/object)                                                       │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 2: Protobuf Serialize                                                     │
│                                                                                 │
│  .proto: message GetUserRequest { int64 user_id = 1; }                          │
│                                                                                 │
│  Wire encoding (varint for int64):                                              │
│    Field 1, wire type 0 (varint): 123                                           │
│    Tag: (1 << 3) | 0 = 0x08                                                     │
│    Value: 123 = 0x7B (varint encoded)                                           │
│    Output: 0x08 0x7B (2 bytes)                                                   │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 3: gRPC Frame Wrap                                                        │
│                                                                                 │
│  [0x00][0x00 0x00 0x00 0x02][0x08 0x7B]                                         │
│   │     └── length=2 (big-endian) ──┘  └── protobuf bytes                       │
│   └── compressed=0                                                              │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 4: HTTP/2 DATA Frame                                                      │
│                                                                                 │
│  9-byte header + 7-byte payload                                                 │
│  Stream ID assigned, END_STREAM if last message                                │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 5: TLS (if HTTPS)                                                         │
│                                                                                 │
│  TLS Record: Application Data (type 23)                                         │
│  Encrypted with AES-GCM or ChaCha20-Poly1305                                    │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 6: TCP Segment                                                            │
│                                                                                 │
│  TCP payload = TLS record(s)                                                    │
│  May be split/coalesced across segments                                         │
└────────────────────────────────────────┬────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│  STEP 7: IP Packet → NIC → Wire                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

REVERSE (receive): Wire → TCP → TLS decrypt → HTTP/2 parse → gRPC frame parse
                   → Protobuf deserialize → Application object
```

### .proto Service Definition → Generated Code

```
.proto FILE:

  syntax = "proto3";
  package user;
  service UserService {
    rpc GetUser(GetUserRequest) returns (User);
    rpc ListUsers(ListRequest) returns (stream User);
  }
  message GetUserRequest { int64 user_id = 1; }
  message User { int64 id = 1; string name = 2; }
  message ListRequest { int32 limit = 1; }

GENERATED CODE (conceptual):

  // Client stub interface
  interface UserServiceStub {
    User GetUser(GetUserRequest req);
    Stream<User> ListUsers(ListRequest req);
  }

  // Server interface (implement this)
  interface UserService {
    User GetUser(GetUserRequest req);
    Stream<User> ListUsers(ListRequest req, StreamObserver<User> observer);
  }

  // Code generator produces:
  // - Serialization/deserialization for each message type
  // - Stub that translates method calls → HTTP/2 requests
  // - Server dispatcher that routes :path to correct method
```

---

## 6. Connection Management — Channels, Keepalive, Backoff

```
gRPC CONNECTION LIFECYCLE:

  Channel creation:
    channel = ManagedChannelBuilder
      .forTarget("dns:///api.example.com:50051")
      .keepAliveTime(30, TimeUnit.SECONDS)
      .keepAliveTimeout(5, TimeUnit.SECONDS)
      .build();

  Under the hood:
    1. DNS resolution (or use provided address)
    2. TCP connect
    3. TLS handshake (if secure)
    4. HTTP/2 connection preface (magic + SETTINGS)
    5. Connection ready for RPCs
```

### Subchannel and Connection Pooling

```
SUBCHANNEL CONCEPT:

  Channel (logical)
    └── Subchannel(s) (physical connections)

  Single backend:
    Channel → 1 Subchannel → 1 TCP/HTTP2 connection

  Multiple backends (load balanced):
    Channel → Subchannel 1 → backend-1:50051
            → Subchannel 2 → backend-2:50051
            → Subchannel 3 → backend-3:50051

  Each subchannel = independent TCP + HTTP/2 connection
  Load balancer selects subchannel per RPC (round_robin, pick_first, etc.)
```

### Keepalive — PING Frames

```
KEEPALIVE — DETECTING DEAD CONNECTIONS:

  HTTP/2 PING frame (type 0x6):
    Payload: 8 bytes (opaque data)
    Used to: verify connection is alive, measure RTT

  gRPC keepalive behavior:
    Client sends PING periodically (e.g., every 30s)
    Server must respond with PING ACK
    If no response within keepalive_timeout (e.g., 5s): connection is dead

  ┌──────────────────────────────────────────────────────────────┐
  │  Client                    Server                            │
  │     │                         │                              │
  │     │  PING (opaque 8 bytes)   │                              │
  │     │  ─────────────────────►  │                              │
  │     │                         │  (if server doesn't respond  │
  │     │  ... 5 seconds ...      │   within timeout)             │
  │     │                         │                              │
  │     │  Connection marked DEAD │                              │
  │     │  New connection created │                              │
  │     │  (or backoff + retry)   │                              │
  └──────────────────────────────────────────────────────────────┘

  Idle timeout:
    If no RPC for N seconds, server may close connection
    Client keepalive PING prevents idle timeout (keeps connection warm)
```

### Connection Backoff — Exponential with Jitter

```
CONNECTION BACKOFF (when connect fails):

  Attempt 1: connect immediately
  Attempt 2: wait base_delay (e.g., 1s) + jitter
  Attempt 3: wait 2 * base_delay + jitter
  Attempt 4: wait 4 * base_delay + jitter
  ...
  Max delay: cap (e.g., 120s)

  Jitter: random(0, 1) * delay
    Prevents thundering herd when many clients reconnect

  ┌──────────────────────────────────────────────────────────────┐
  │  Exponential backoff with jitter:                            │
  │                                                              │
  │  delay = min(max_delay, base * 2^attempt) * (0.5 + 0.5*rand) │
  │                                                              │
  │  Attempt 1: 0s (immediate)                                   │
  │  Attempt 2: ~1s ± 0.5s                                       │
  │  Attempt 3: ~2s ± 1s                                         │
  │  Attempt 4: ~4s ± 2s                                         │
  │  ...                                                         │
  │  Attempt 10: ~120s (capped)                                  │
  └──────────────────────────────────────────────────────────────┘
```

### Detecting Dead Connections

```
HOW gRPC DETECTS DEAD CONNECTIONS:

  1. Keepalive timeout: PING sent, no PING ACK within timeout
  2. TCP RST: connection reset by peer
  3. TLS alert: connection closed abnormally
  4. GOAWAY frame: server gracefully shutting down
  5. RPC deadline exceeded: may indicate stalled connection

  On detection:
    Subchannel marked TRANSIENT_FAILURE
    Pending RPCs failed with UNAVAILABLE
    Next RPC triggers reconnect (with backoff)
```

---

## 7. Load Balancing in gRPC — L4 vs L7, xDS

```
gRPC LOAD BALANCING OPTIONS:

  1. Client-side (built-in)
  2. Proxy load balancer (L4 or L7)
  3. Look-aside (xDS: Envoy, Istio)
```

### Client-Side Load Balancing

```
CLIENT-SIDE: pick_first vs round_robin

  pick_first (default):
    Resolve "api.example.com" → [ip1, ip2, ip3]
    Connect to FIRST successful address
    All RPCs go to that one connection
    If connection fails: try next address

  round_robin:
    Resolve → create subchannel per address
    Each RPC: pick next subchannel in round-robin order
    RPCs distributed across all backends

  ┌──────────────────────────────────────────────────────────────┐
  │  pick_first:                                                  │
  │  Client ──► [backend-1]  (all traffic to one)                │
  │                                                              │
  │  round_robin:                                                 │
  │  Client ──► [backend-1] [backend-2] [backend-3]               │
  │             RPC1→1, RPC2→2, RPC3→3, RPC4→1, ...              │
  └──────────────────────────────────────────────────────────────┘
```

### L4 vs L7 — The HTTP/2 Problem

```
L4 LOAD BALANCER PROBLEM WITH HTTP/2:

  L4 (TCP): Load balancer sees only TCP connections
    Client connects to LB
    LB forwards TCP connection to ONE backend
    All bytes on that connection go to that backend

  HTTP/2: ONE connection, MULTIPLE streams (multiplexed)
    Client opens 1 connection to LB
    LB forwards to backend-1
    ALL gRPC streams (RPCs) go to backend-1!
    backend-2 and backend-3 get NOTHING

  ┌──────────────────────────────────────────────────────────────┐
  │  L4 LB:                                                      │
  │                                                              │
  │  Client ──► [L4 LB] ──► backend-1  (connection 1)           │
  │                    ──► backend-2  (connection 2, if new conn) │
  │                                                              │
  │  Same client, same connection = all RPCs to one backend      │
  │  LB cannot distribute streams within one connection          │
  └──────────────────────────────────────────────────────────────┘

  L7 LOAD BALANCER (HTTP/2 aware):
    Terminates HTTP/2, sees streams
    Can route each RPC (stream) to different backend
    Opens new connection to backend per stream (or pools)
    More expensive: must parse HTTP/2
```

### Look-Aside Load Balancing — xDS

```
xDS (e.g., Envoy, Istio) — LOOK-ASIDE:

  Client does NOT connect directly to backends
  Client connects to local Envoy sidecar
  Envoy has full view of cluster (from xDS control plane)

  ┌──────────────────────────────────────────────────────────────┐
  │  xDS flow:                                                    │
  │                                                              │
  │  Control plane (e.g., Istio Pilot)                           │
  │    ├── LDS (Listener Discovery): which ports to listen       │
  │    ├── RDS (Route Discovery): route rules                    │
  │    ├── CDS (Cluster Discovery): backend clusters              │
  │    └── EDS (Endpoint Discovery): backend instances           │
  │                                                              │
  │  Envoy sidecar:                                              │
  │    Receives xDS config                                       │
  │    Knows: backend-1, backend-2, backend-3 (health, load)     │
  │    Routes each gRPC stream to best backend                   │
  │                                                              │
  │  App → localhost:15001 (Envoy) → backend (chosen by Envoy)    │
  └──────────────────────────────────────────────────────────────┘

  Benefits:
    Client stays simple (connect to localhost)
    Envoy handles: LB, retries, timeouts, mTLS, observability
    Dynamic: backends change, xDS pushes updates
```

---

## 8. Interceptors and Middleware — Call Chain

```
INTERCEPTOR CHAIN:

  Client:  App → Interceptor1 → Interceptor2 → ... → Stub → Channel → Wire
  Server:  Wire → Server → Interceptor1 → Interceptor2 → ... → Handler

  Each interceptor can:
    - Inspect/modify request/response
    - Add metadata (headers)
    - Short-circuit (e.g., return cached response)
    - Call next interceptor (or handler)
```

### Client Interceptors

```
CLIENT INTERCEPTOR EXAMPLE (pseudo-code):

  interceptor(req, next) {
    // Before call
    req.metadata["x-request-id"] = generateUUID()
    req.metadata["x-deadline"] = deadline.toString()
    start = now()

    // Call next (stub or next interceptor)
    resp, err = next(req)

    // After call
    log("RPC took", now() - start, "status", err)
    metrics.record("grpc_latency", now() - start)
    return resp, err
  }

  Common uses:
    - Logging
    - Auth: inject Bearer token into metadata
    - Metrics: latency, error rate
    - Retry: wrap next, retry on UNAVAILABLE
    - Timeout: enforce deadline, cancel on exceed
```

### Server Interceptors

```
SERVER INTERCEPTOR EXAMPLE:

  interceptor(req, handler) {
    // Before handler
    if !validateAuth(req.metadata["authorization"]) {
      return error(UNAUTHENTICATED)
    }
    req.context = addTraceID(req.context, req.metadata["x-request-id"])

    // Call handler
    resp, err = handler(req)

    // After handler
    log("handler completed", err)
    return resp, err
  }

  Common uses:
    - Auth: validate JWT, mTLS identity
    - Logging
    - Rate limiting
    - Tracing: extract trace ID, span
```

### Deadline Propagation

```
DEADLINE PROPAGATION ACROSS SERVICES:

  Client A (user-facing): deadline = 500ms
    └── calls Service B: passes deadline in metadata
        └── calls Service C: passes same deadline

  gRPC metadata: "grpc-timeout" header
    Format: 1H2M3S4N (hours, minutes, seconds, nanoseconds)
    Example: "499865432u" (microseconds)

  Each service:
    Receives deadline from incoming metadata
    Sets context.WithDeadline(ctx, deadline)
    Passes deadline to outgoing RPCs
    If local processing + downstream RPC exceeds deadline: CANCELLED

  ┌──────────────────────────────────────────────────────────────┐
  │  Client: deadline 500ms                                       │
  │    │                                                          │
  │    ▼                                                          │
  │  Service B: receives 500ms, uses 100ms, passes 400ms to C     │
  │    │                                                          │
  │    ▼                                                          │
  │  Service C: receives 400ms, must respond within 400ms         │
  │                                                              │
  │  If C takes 500ms: C's RPC fails with DEADLINE_EXCEEDED       │
  │  B propagates error to Client                                │
  │  Client gets DEADLINE_EXCEEDED                                │
  └──────────────────────────────────────────────────────────────┘
```

---

## 9. gRPC vs REST Performance — Concrete Comparison

```
COMPARISON DIMENSIONS:

  1. Serialization time
  2. Message size (wire)
  3. Connection overhead
  4. Latency
  5. Throughput
  6. When to use which
```

### Serialization Time

```
SERIALIZATION (approximate, single core):

  JSON (REST):
    Serialize:   ~1-5 µs per KB
    Deserialize: ~2-10 µs per KB
    (varies by library: simdjson faster, standard slower)

  Protobuf (gRPC):
    Serialize:   ~0.2-1 µs per KB
    Deserialize: ~0.3-1.5 µs per KB
    (binary, no parsing of strings/numbers)

  Typical 1KB message:
    JSON:  ~5-10 µs round-trip (serialize + deserialize)
    Proto: ~1-2 µs round-trip
    gRPC wins: 3-5x faster serialization
```

### Message Size

```
MESSAGE SIZE (same logical data):

  JSON: {"user_id": 123, "name": "Alice", "active": true}
    ~45 bytes (with whitespace) or ~40 bytes (minified)

  Protobuf: user_id=123, name="Alice", active=true
    ~15-20 bytes (binary, varint for numbers, length-prefixed strings)

  Compression (gzip):
    JSON: compresses well (text)
    Protobuf: compresses well (repetitive structure)
    Both benefit; protobuf often 2-3x smaller before compression

  At scale (1M requests):
    JSON 1KB avg: 1 GB
    Proto 400B avg: 400 MB
    Savings: 600 MB bandwidth
```

### Connection Overhead

```
CONNECTION OVERHEAD:

  REST (HTTP/1.1):
    New connection: TCP (1 RTT) + TLS (1-2 RTT) = 2-3 RTT
    Per request: 1 RTT (if keep-alive)
    Without keep-alive: 2-3 RTT per request!

  REST (HTTP/2):
    New connection: same 2-3 RTT
    Per request: 1 RTT (multiplexed)
    Connection reuse: critical

  gRPC (HTTP/2):
    Same as REST/HTTP/2
    But: gRPC encourages long-lived channels
    Channel created once at startup
    All RPCs reuse: 1 RTT per RPC after first
    First RPC: 2-3 RTT (connection) + 1 RTT (request) = 3-4 RTT
```

### Latency and Throughput

```
LATENCY (same datacenter, 1ms RTT):

  REST/JSON, new connection each time:
    TCP + TLS + HTTP: 3 RTT = 3ms
    Request/response: 1 RTT = 1ms
    Serialization: 10 µs
    Total: ~4ms

  REST/JSON, connection reuse:
    Request/response: 1 RTT = 1ms
    Serialization: 10 µs
    Total: ~1ms

  gRPC, connection reuse:
    Request/response: 1 RTT = 1ms
    Serialization: 2 µs
    Total: ~1ms (slightly better due to faster serialization)

  At 100ms RTT (cross-continent):
    REST new conn: 300ms + 100ms = 400ms
    gRPC new conn: same
    Both reused: ~100ms
    gRPC advantage: marginal for single RPC, significant for many
```

### When gRPC Wins vs When REST Is Sufficient

```
gRPC WINS WHEN:

  ✓ Microservice-to-microservice (same org, control both ends)
  ✓ High throughput (millions RPCs/sec)
  ✓ Streaming (server push, client stream, bidirectional)
  ✓ Strong typing and code generation desired
  ✓ Polyglot (many languages, .proto is contract)
  ✓ Low latency critical (every µs counts)

REST SUFFICIENT WHEN:

  ✓ Public API (browsers, third-party clients)
  ✓ Simple CRUD, low request rate
  ✓ Human-readable payloads (JSON) important
  ✓ Caching at HTTP layer (CDN, reverse proxy)
  ✓ No streaming need
  ✓ Ecosystem: curl, Postman, browser DevTools
```

### Summary Table

```
┌─────────────────────┬──────────────────────┬──────────────────────┐
│                     │ REST (JSON/HTTP)     │ gRPC (Proto/HTTP2)  │
├─────────────────────┼──────────────────────┼──────────────────────┤
│ Serialization       │ ~5 µs/KB             │ ~1 µs/KB             │
│ Message size        │ Larger (text)        │ Smaller (binary)     │
│ Connection          │ HTTP/2 or HTTP/1.1  │ HTTP/2               │
│ Streaming           │ Chunked, SSE         │ Native 4 types       │
│ Browser support     │ Full                 │ Limited (grpc-web)   │
│ Code gen            │ OpenAPI → clients    │ .proto → both        │
│ Load balancing      │ L4/L7 both work      │ L7 or client-side    │
└─────────────────────┴──────────────────────┴──────────────────────┘
```

---

## 30-SECOND REVISION BOX

```
gRPC: RPC over HTTP/2. Channel=connection/pool, Stub=generated from .proto
WIRE: :method POST, :path /pkg.Service/Method, content-type application/grpc
FRAME: [1B compressed][4B length][protobuf] inside HTTP/2 DATA
FOUR TYPES: Unary (1:1), Server stream (1:N), Client stream (N:1), Bidi (N:N)
TRAILERS: grpc-status, grpc-message after DATA (status unknown until end)
PIPELINE: Object → protobuf → gRPC frame → HTTP/2 DATA → TLS → TCP
CONNECTION: keepalive PING, backoff with jitter, subchannel per backend
LB: pick_first/round_robin client-side; L4 bad (1 conn=1 backend); xDS for Envoy
INTERCEPTORS: wrap call chain for auth, logging, metrics, deadline propagation
gRPC WINS: microservices, streaming, throughput, latency; REST: public API, CRUD
```

---

**Prev: [[12_Internals-GraphQL-Execution-Engine]] | Next: [[14_Internals-Rate-Limiting-Algorithms]]**
