# Design a Real-Time Streaming Pipeline - Interview Answer Format

## One-Line Answer

A real-time streaming pipeline continuously ingests events through Kafka/MSK or Kinesis, processes them with low latency, stores raw events for replay, and serves dashboards, alerts, or downstream systems within seconds or minutes.

---

## Step 1: Clarify Requirements (1-2 min)

### What to ask

- What does "real-time" mean here: sub-second, seconds, or minutes?
- What is the expected event throughput and peak traffic?
- What correctness level is needed: at-most-once, at-least-once, or exactly-once?
- Do we need ordering per user, order, or session?
- What are the downstream consumers: dashboards, alerts, ML, or search?
- How long should the raw stream be replayable?

### Good interview line

> "Before I design it, I want to clarify the latency target, expected throughput, ordering requirements, delivery guarantees, and who will consume the stream."

---

## Step 2: High-Level Design (2-3 min)

### Say this clearly

```text
Producers -> Kafka/Kinesis -> Stream Processing -> Raw S3 + Real-Time Outputs
```

### Short explanation you can speak

1. Applications or services produce events
2. A durable stream like Kafka/MSK or Kinesis buffers the events
3. A processing layer validates, enriches, and aggregates them
4. Raw events are archived to S3 for replay and audit
5. Real-time outputs go to dashboards, alerts, search, or other consumers

### Architecture

```text
Applications / Services
         |
  Kafka (MSK) / Kinesis
         |
 Stream Processing Layer
(Spark Structured Streaming / Flink / Lambda)
     |               |
  Raw S3         Real-Time Outputs
     |               |
Curated Lake     Redshift / OpenSearch / Alerts
     |
Replay / Audit
```

### Good interview line

> "My high-level design is producers writing to a durable stream, then a processing layer for validation and aggregation, with raw archival to S3 and separate serving outputs for real-time use cases."

---

## Step 3: Deep Dive (This Is Where You Win)

### A. Streaming Backbone

#### Why Kafka/MSK or Kinesis?

- They decouple producers from consumers
- They handle spikes better than direct point-to-point delivery
- They support replay and multi-consumer architectures

#### Why partition by business key?

- Partition by `user_id`, `order_id`, or similar key
- This keeps related events together
- It helps preserve ordering where needed

### Good interview line

> "I would use Kafka or Kinesis as the durable buffer, and partition by a business key so related events stay together and consumers can scale horizontally."

---

### B. Stream Processing

#### What processing usually does

- validate schema
- parse payloads
- enrich with reference data
- aggregate in windows
- write bad events to DLQ or quarantine

#### Late-arriving and out-of-order data

- Use event time, not only processing time
- Use watermarks to allow small lateness windows
- Accept that mobile or distributed systems often send late events

#### Delivery semantics

- **At-most-once**: fastest, but can lose data
- **At-least-once**: common, but duplicates are possible
- **Exactly-once**: best correctness, but more complex

### Good interview line

> "Most real systems use at-least-once delivery, so I would design consumers to be idempotent and handle duplicates explicitly."

---

### C. Reliability and Replay

#### Why archive raw events to S3?

- Replay becomes easier
- Audit and debugging become easier
- Long-term retention is cheaper than relying only on stream retention

#### Monitoring to mention

- consumer lag
- throughput
- processing latency
- failed events
- watermark delay
- end-to-end freshness

### Good interview line

> "I would always archive raw events to S3 because stream retention is not enough for long-term replay, audit, and offline recomputation."

---

## Step 4: Scaling

### Main scaling points

#### Horizontal scaling

- Increase partitions or shards
- Add more consumers or stream processing workers

#### Efficient event design

- Keep messages compact
- Manage schema versions carefully
- Avoid heavy per-event synchronous joins

#### Serving scalability

- Pre-aggregate high-volume metrics
- Separate hot real-time consumers from slow offline ones

### Good interview line

> "To scale, I would increase partitions for parallelism, keep events compact, and separate real-time processing from heavier offline workloads."

---

## Step 5: Trade-Offs

### Example trade-offs

#### Kafka/MSK vs Kinesis

- Kafka/MSK gives a strong ecosystem and flexibility
- Kinesis is more AWS-managed and operationally simpler

#### At-least-once vs exactly-once

- At-least-once is simpler and common
- Exactly-once improves correctness but adds cost and complexity

#### Real-time vs batch

- Real-time gives freshness
- But it is more operationally complex than batch

### Good interview line

> "If the business does not require strict exactly-once semantics, I would choose at-least-once with idempotent consumers because it is simpler and usually good enough."

---

## Strong 2-Minute Answer Script

> "First, I would clarify what real-time means here, the expected throughput, ordering requirements, and the consumers of the output. My design would have producers writing events into Kafka, MSK, or Kinesis as the durable streaming backbone. A stream processing layer would validate, enrich, deduplicate, and aggregate the events. I would send malformed events to a DLQ or quarantine path.
>
> I would also archive raw events to S3 because replay, audit, and offline reprocessing are critical. For serving, I would write real-time aggregates to systems like Redshift, OpenSearch, or an alerting layer depending on the use case.
>
> In the deep dive, I would focus on partitioning, delivery guarantees, and late data. Partitioning by a business key helps preserve ordering and scale consumers. In most cases I would choose at-least-once delivery and make downstream consumers idempotent. For late or out-of-order events, I would use event-time processing and watermarks. For scaling, I would increase partitions, add consumers, and pre-aggregate high-volume metrics before sending them to dashboards. The main trade-off is that streaming gives much better freshness than batch, but it is more complex operationally."

---

## Common Failure Cases

### Consumer falls behind

- Add more consumers or partitions
- Reduce expensive per-event logic
- Replay from raw S3 if needed

### Duplicate events

- Deduplicate using event ID
- Keep downstream writes idempotent

### Out-of-order events

- Use event time and watermark logic
- Allow bounded lateness

### Poison message

- Send bad event to DLQ or quarantine
- Do not block the entire stream

---

## Interview Tips

- Clarify what "real-time" means
- Always mention **ordering**, **duplicates**, and **late data**
- Mention **consumer lag** as a key metric
- Do not forget **raw archival to S3**
- Explain delivery guarantees in simple business terms

---

## Quick Revision (5 points)

1. Clarify latency, throughput, ordering, and delivery semantics first
2. Explain the flow as `Producers -> Kafka/Kinesis -> Processing -> S3 + Serving`
3. Deep dive on partitioning, delivery guarantees, and replay
4. Mention lag monitoring, DLQ handling, and late data
5. Close with trade-offs like freshness vs operational complexity
