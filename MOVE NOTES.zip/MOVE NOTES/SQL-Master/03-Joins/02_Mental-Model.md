# Joins — Mental Model

---

## Venn picture

```
INNER     = overlap only
LEFT      = full left circle + overlap fill from right
FULL      = both circles, gaps filled with NULLs
```

---

## “Driving table” intuition

- **LEFT JOIN:** left table is **preserved** — good when it’s the **fact** you must list (e.g., all orders even if customer missing — data quality issue then shows NULL).

---

## Fan-out (duplicate rows)

One `order` → many `order_items` → joining multiplies rows. Aggregates **after** join need care (double counting) — see Aggregates folder.

---

*Next: [[03_Coding-Template]]*
