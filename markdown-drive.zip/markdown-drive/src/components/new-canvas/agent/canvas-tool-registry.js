export const CANVAS_TOOLS = [
  {
    name: "compose_teaching_scene",
    description: "Compose a complete editable data-structure lesson. The canvas engine handles layout, routing, binding, and overlap repair.",
    parameters: {
      type: "object",
      properties: {
        topic: { type: "string" },
        structure_type: { type: "string", enum: ["array", "tree", "linked-list", "stack", "queue", "hash-map"] },
        title: { type: "string" },
        definition: { type: "string" },
        values: { type: "array", items: { type: "string" } },
        focus: { type: "string", enum: ["overview", "access", "memory", "insertion", "deletion"] },
        include_code_editor: { type: "boolean" },
        code_language: { type: "string", enum: ["cpp", "python", "java", "javascript"] },
        code_title: { type: "string" },
        code: { type: "string" },
        operation: { type: "string" },
        callout: { type: "string" }
      },
      required: ["topic", "structure_type", "title", "definition", "values"]
    }
  },
  {
    name: "teach_concept",
    description: "Write a clear, educational explanation of a concept. Spawns a note widget on the canvas.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", description: "A short, catchy title for the note" },
        text: { type: "string", description: "The educational content to explain the concept" }
      },
      required: ["title", "text"]
    }
  },
  {
    name: "draw_flowchart",
    description: "Draw a highly visual flowchart, architectural diagram, or memory layout using Mermaid.js syntax. Spawns a flowchart widget on the canvas.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string", description: "Title of the flowchart" },
        mermaid_code: { type: "string", description: "Valid Mermaid.js graph code (e.g., 'graph TD; A-->B;')" }
      },
      required: ["title", "mermaid_code"]
    }
  },
  {
    name: "show_data_structure",
    description: "Display a visual representation of a data structure. Spawns the corresponding widget on the canvas.",
    parameters: {
      type: "object",
      properties: {
        type: { type: "string", enum: ["array", "tree", "linked-list", "stack", "queue", "hash-map"] },
        title: { type: "string" },
        values: { 
          type: "array", 
          items: { type: "string" },
          description: "An array of elements to initialize the data structure. E.g. for an array: ['10', '20', '30']" 
        }
      },
      required: ["type", "title", "values"]
    }
  },
  {
    name: "write_code_example",
    description: "Show a practical code example to demonstrate a concept. Spawns a code widget on the canvas.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        language: { type: "string", enum: ["cpp", "python", "java", "javascript"] },
        code: { type: "string" },
        live_typing: { type: "boolean" }
      },
      required: ["title", "language", "code"]
    }
  },
  {
    name: "spawn_calculator",
    description: "Provide a functional calculator widget to the user when they ask to do math or calculations.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" }
      },
      required: ["title"]
    }
  },
  {
    name: "spawn_file_converter",
    description: "Provide an interface for the user to upload and convert files (e.g., PDF to PPT).",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        conversion_type: { type: "string", description: "E.g., 'PDF to PPT', 'Image to Text'" }
      },
      required: ["title", "conversion_type"]
    }
  },
  {
    name: "show_progress",
    description: "Show a live progress tracker with steps, useful when processing a long task like file conversion.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        steps: { 
          type: "array", 
          items: { type: "string" },
          description: "List of steps, e.g., ['Uploading', 'Converting', 'Done']"
        },
        currentStepIndex: { type: "number", description: "The index (0-based) of the current active step" }
      },
      required: ["title", "steps", "currentStepIndex"]
    }
  },
  {
    name: "open_sql_workspace",
    description: "Open a SQL practice workspace for SQLite, MySQL, or Oracle style queries.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        dialect: { type: "string", enum: ["sqlite", "mysql", "oracle"] },
        starter_query: { type: "string", description: "Starter SQL query or schema setup." }
      },
      required: ["title", "dialect", "starter_query"]
    }
  },
  {
    name: "show_json_viewer",
    description: "Open a JSON viewer widget with starter JSON content.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        source: { type: "string", description: "JSON text to preload in the viewer." }
      },
      required: ["title", "source"]
    }
  },
  {
    name: "show_csv_loader",
    description: "Open a CSV loader widget with optional starter CSV content.",
    parameters: {
      type: "object",
      properties: {
        title: { type: "string" },
        source: { type: "string", description: "CSV text to preload." },
        delimiter: { type: "string", enum: ["auto", ",", "\\t", ";", "|"] }
      },
      required: ["title", "source", "delimiter"]
    }
  }
];
