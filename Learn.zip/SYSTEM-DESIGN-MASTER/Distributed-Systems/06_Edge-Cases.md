# Distributed Systems — Edge Cases

> **Permanent Recall:** Edge cases to handle: network partition scenarios, split brain during leader election, distributed lock expiry with slow client, clock skew causing data corruption, message reordering, Byzantine failures, cascading timeouts, gossip protocol convergence delay. Each has detection and mitigation strategies—design for these in FAANG system design discussions.

---

## Edge Case 1: Network Partition Scenarios

**What happens:** Nodes split into isolated groups. Each may believe it has quorum or is the leader.

```
    Partition
  ┌──────────┐     X     ┌──────────┐
  │ A, B     │           │ C        │
  │ (majority)│          │ (minority)│
  └──────────┘           └──────────┘
  Can elect leader       Cannot form quorum
  Can commit             Must block
```

**Mitigation:** Odd N (3, 5). Only majority can form quorum. Minority blocks until partition heals. Document: "Minority unavailable—acceptable for CP."

---

## Edge Case 2: Split Brain During Leader Election

**What happens:** Brief moment where two nodes both think they are leader (e.g., message delay, bug).

| Cause | Mitigation |
|-------|------------|
| Even split (2-2) | Odd N avoids 50-50 |
| Stale leader doesn't know | Term numbers; higher term wins |
| Election timeout too short | Randomize (150-300ms) to reduce split votes |
| Bug in implementation | Use etcd/ZK, don't roll your own |

---

## Edge Case 3: Distributed Lock Expiry with Slow Client

**What happens:** Client A holds lock. GC pause 10s. Lock TTL 5s. Lock expires. Client B acquires. A resumes, writes. Data corruption.

```
  Client A          Lock          Client B
  ┌──────┐        ┌─────┐        ┌──────┐
  │ Hold │───────►│ TTL │        │      │
  │ GC   │  ...   │ 5s  │        │      │
  │ 10s  │        │expires       │Acquire│
  │      │        │     │◄───────│      │
  │resume│───────►│     │        │      │
  │write │  !!!   │     │        │write │
  └──────┘        └─────┘        └──────┘
  Both wrote → corruption
```

**Mitigation:** Fencing tokens. Monotonic counter from CP store. Storage rejects ops with lower token. A's token < B's → A rejected.

---

## Edge Case 4: Clock Skew Causing Data Corruption

**What happens:** Node A clock +5 min, Node B -5 min. LWW: A's write (future ts) overwrites B's correct write. Wrong winner.

**Mitigation:** Use NTP (reduce skew), Hybrid Logical Clocks, or logical clocks. Avoid wall-clock for LWW in critical paths. Prefer vector clocks for conflict detection.

---

## Edge Case 5: Message Reordering

**What happens:** Sent: 1, 2, 3. Received: 2, 1, 3. Application assumes order → wrong state.

**Mitigation:** Sequence numbers. Causal delivery (vector clocks). Or leader-based total order (single writer). Idempotency for duplicates.

---

## Edge Case 6: Byzantine Failures

**What happens:** Malicious or buggy node sends contradicting messages. Can break consensus (if >f of 3f+1 nodes).

**Mitigation:** Byzantine fault-tolerant consensus (PBFT) if needed. Otherwise assume crash-only (non-Byzantine). Most systems assume crash-only.

---

## Edge Case 7: Cascading Timeouts

**What happens:** One node slow → callers time out → retries → more load → more timeouts → cascade failure.

```
  Slow node
      │
      ▼
  Callers timeout ──► Retry ──► More load
      │                              │
      ◄──────────────────────────────┘
  Cascade
```

**Mitigation:** Circuit breaker (stop retrying after N failures). Exponential backoff. Bulkheads (limit concurrent). Degrade gracefully.

---

## Edge Case 8: Gossip Protocol Convergence Delay

**What happens:** New config propagates slowly. Some nodes have old config for O(log N) rounds. Inconsistent view.

**Mitigation:** Accept eventually consistent. For critical config: use ZooKeeper/etcd (strong consistency). Or version config; clients handle stale until propagated.

---

## Edge Case Summary Table

| Edge Case | Cause | Mitigation |
|-----------|-------|------------|
| Network partition | Split network | Odd N, quorum, minority blocks |
| Split brain | Dual leaders | Quorum, term numbers |
| Lock + slow client | GC, network | Fencing tokens |
| Clock skew | NTP drift | HLC, logical clocks |
| Message reorder | Network | Sequence, causal order |
| Byzantine | Malicious node | PBFT or assume crash-only |
| Cascading timeout | Retry storm | Circuit breaker, backoff |
| Gossip delay | O(log N) rounds | Accept or use strong consistency |

---

## Design Checklist for Edge Cases

- [ ] Partition: Odd N, quorum behavior
- [ ] Split brain: Term-based election
- [ ] Lock: Fencing token for critical resources
- [ ] Clock: HLC or logical for ordering
- [ ] Reorder: Sequence numbers, idempotency
- [ ] Cascading: Circuit breaker, backoff
- [ ] Gossip: Convergence delay acceptable?

---

## 30-SECOND REVISION BOX

```
PARTITION: Odd N, minority blocks
SPLIT BRAIN: Quorum, terms
LOCK SLOW: Fencing token
CLOCK SKEW: HLC, logical
REORDER: Sequence, causal
BYZANTINE: PBFT or crash-only
CASCADE: Circuit breaker
GOSSIP: O(log N) delay
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
