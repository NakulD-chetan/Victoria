# Design WhatsApp / Chat System — Real-time Messaging

> **Chat system design = WebSocket + Message Queue + Delivery Guarantee**
> WhatsApp 100 Billion messages/day handle karta hai — samjho kaise!

---

## 1. Requirements Clarification

### Functional Requirements

| Feature | Description | Complexity |
|---------|-------------|------------|
| **1-to-1 Chat** | Two users message each other | Core flow |
| **Group Chat** | Multiple users in one conversation | Fan-out to N members |
| **Online Status** | User online/offline/last seen | Presence service |
| **Read Receipts** | Single tick (sent), Double tick (delivered), Blue (read) | State tracking |
| **Media Sharing** | Photos, videos, documents | Upload → Blob → Link in message |
| **End-to-End Encryption** | Only sender & receiver can read | Signal protocol |
| **Message History** | Scroll up, load older messages | Pagination |
| **Typing Indicator** | "User is typing..." | Real-time ephemeral |

### Non-Functional Requirements

| NFR | Target | Why |
|-----|--------|-----|
| **Low Latency** | < 100ms message delivery | Chat feels instant |
| **Reliable Delivery** | No message loss | At-least-once guarantee |
| **Offline Support** | Messages when user comes online | Store and forward |
| **Ordering** | Messages in correct order | Per-conversation sequence |
| **Scale** | 1B+ users, 100B messages/day | Massive throughput |
| **Availability** | 99.99% | Chat = critical communication |

### Scope (Interview Clarification)

```
┌─────────────────────────────────────────────────────────────┐
│  IN SCOPE                         │  OUT OF SCOPE           │
├───────────────────────────────────┼─────────────────────────┤
│  1:1, Group chat                  │  Voice/Video calls      │
│  Text + Media                     │  Status/Stories         │
│  Delivery status                  │  Payments               │
│  Presence (online/offline)        │  Bot integrations       │
│  Basic E2E (concept)              │  Full Signal protocol   │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Back of the Envelope Estimation

### Assumptions

- **1 Billion DAU**
- **100 Billion messages/day** = ~1.15M messages/sec
- **Avg message size**: 100 bytes (text), 50KB (with media link)
- **Avg 50 messages/user/day**
- **Group size**: Avg 10 members, max 256
- **Peak**: 3x average

### Calculations

| Metric | Calculation | Result |
|--------|-------------|--------|
| **Messages/sec** | 100B / 86400 | ~1.15M msg/sec |
| **Peak QPS** | 1.15M × 3 | ~3.5M msg/sec |
| **Storage/day** | 100B × 500 bytes (avg) | ~50 TB/day |
| **Storage (5 yr)** | 50 TB × 365 × 5 | ~90 PB (!!) |
| **Connections** | 1B concurrent? No — ~10% online | ~100M WebSocket connections |

**Matlab**: Write-heavy, connection-heavy. Message queue + sharding critical.

### Real-World Analogy: Post Office

Chat system = Digital post office. Message = letter. Server = post office. WebSocket = registered post (instant delivery when recipient available). Offline = letter post office mein store, jab aayega tab dega. Read receipt = acknowledgment slip. Group chat = circular letter — ek copy, sabko forward.

---

## 3. High Level Design

### 3.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                           WHATSAPP-STYLE CHAT SYSTEM                                  │
└─────────────────────────────────────────────────────────────────────────────────────┘

    ┌──────────┐                    ┌─────────────────────────────────────────────────┐
    │  Mobile  │                    │              Load Balancer / API Gateway          │
    │  / Web   │◄──────────────────►│  (Sticky sessions for WebSocket)                  │
    │  Client  │   WebSocket        │                                                     │
    └────┬─────┘   (persistent)     │  ┌─────────────┐  ┌─────────────┐  ┌───────────┐  │
         │                          │  │ Chat        │  │ Presence    │  │ Media     │  │
         │                          │  │ Service     │  │ Service     │  │ Service   │  │
         │                          │  └──────┬──────┘  └──────┬──────┘  └─────┬─────┘  │
         │                          └─────────┼────────────────┼───────────────┼───────┘
         │                                    │                │               │
         │                          ┌─────────▼────────────────▼───────────────▼───────┐
         │                          │              Message Queue (Kafka)                 │
         │                          │         Topics: messages, presence, media         │
         │                          └─────────┬────────────────┬───────────────┬───────┘
         │                                    │                │               │
         │                          ┌─────────▼────┐  ┌────────▼────┐  ┌──────▼──────┐
         │                          │  Cassandra   │  │    Redis     │  │  S3 / Blob  │
         │                          │  (Messages)  │  │  (Presence, │  │  (Media     │
         │                          │              │  │   Sessions) │  │   files)    │
         │                          └──────────────┘  └─────────────┘  └─────────────┘
         │
         └──────────────────────────►  Push Notification (FCM/APNs) — when offline
```

### 3.2 Message Flow — Send & Receive

```
SENDER                              SERVER                           RECIPIENT
   │                                    │                                  │
   │  WebSocket: send(msg)               │                                  │
   │───────────────────────────────────►│                                  │
   │                                    │  Validate, Save to DB            │
   │                                    │  Publish to Kafka                │
   │                                    │                                  │
   │  ACK (msg_id, status=sent)         │                                  │
   │◄───────────────────────────────────│                                  │
   │                                    │                                  │
   │                                    │  Recipient ONLINE?               │
   │                                    │       │                          │
   │                                    │  YES  ├──► WebSocket push ──────►│
   │                                    │       │                          │
   │                                    │  NO   └──► Push notification ───►│
   │                                    │              (when app opens)    │
   │                                    │                                  │
   │                                    │  Recipient receives ──► Deliver ACK
   │                                    │  Recipient reads ──────► Read ACK
```

### 3.3 Connection Model

```
┌─────────────────────────────────────────────────────────────────┐
│  WebSocket vs HTTP Long Polling                                   │
├─────────────────────────────────────────────────────────────────┤
│  WebSocket:                                                      │
│  • Persistent connection, bidirectional                          │
│  • Server push instantly                                         │
│  • Low latency, efficient                                        │
│  • Used by: WhatsApp Web, Slack, Discord                         │
├─────────────────────────────────────────────────────────────────┤
│  Long Polling:                                                   │
│  • Client polls, server holds until message                       │
│  • Fallback when WebSocket blocked (corporate firewall)          │
│  • More overhead                                                 │
└─────────────────────────────────────────────────────────────────┘
```

**WhatsApp uses WebSocket (or custom protocol) for real-time.**

---

## 4. API Design

### REST APIs (HTTP — for initial load, media, etc.)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/messages` | Send message (fallback if WS fails) |
| `GET` | `/api/v1/conversations/{id}/messages` | Get message history (paginated) |
| `POST` | `/api/v1/media/upload` | Upload media, get URL |
| `GET` | `/api/v1/users/{id}/presence` | Get user online status |
| `POST` | `/api/v1/conversations` | Create group |
| `GET` | `/api/v1/conversations` | List conversations |

### WebSocket Messages (Real-time)

| Direction | Message Type | Payload |
|-----------|--------------|---------|
| Client→Server | `send_message` | `{ conv_id, content, type }` |
| Server→Client | `new_message` | `{ msg_id, sender, content, timestamp }` |
| Server→Client | `delivery_ack` | `{ msg_id, status: "delivered" }` |
| Server→Client | `read_ack` | `{ msg_id, status: "read" }` |
| Client→Server | `typing` | `{ conv_id, is_typing }` |
| Server→Client | `presence` | `{ user_id, status: "online" }` |

### Message Payload Structure

```json
{
  "msg_id": "uuid",
  "conv_id": "conv_123",
  "sender_id": "user_456",
  "content": "Hello!",
  "type": "text",
  "media_url": null,
  "timestamp": "2024-01-15T10:30:00Z",
  "status": "sent"
}
```

---

## 5. Data Model / Database Schema

### Users (MySQL)

```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY,
    phone VARCHAR(20) UNIQUE,
    name VARCHAR(100),
    avatar_url VARCHAR(500),
    created_at TIMESTAMP
);
```

### Conversations

```sql
-- 1:1 conversation
CREATE TABLE conversations (
    id BIGINT PRIMARY KEY,
    type ENUM('direct', 'group'),
    created_at TIMESTAMP
);

-- Group members
CREATE TABLE conversation_members (
    conv_id BIGINT,
    user_id BIGINT,
    role ENUM('admin', 'member'),
    joined_at TIMESTAMP,
    PRIMARY KEY (conv_id, user_id)
);
```

### Messages (Cassandra — write-heavy!)

```
messages table:
  Partition Key: conv_id
  Clustering Key: (created_at, msg_id)
  Columns: msg_id, sender_id, content, type, media_url, status, created_at
```

**Why Cassandra?** Write-heavy, append-only, partition by conversation.

### Message Status (Per recipient — for groups)

```
message_status table:
  Partition Key: msg_id
  Columns: user_id, status (sent/delivered/read), updated_at
```

### Presence (Redis)

```
Key: presence:user:{user_id}
Value: { status: "online", last_seen: timestamp }
TTL: 60 seconds (heartbeat refresh)
```

### Media (S3 + Metadata in DB)

```
media table:
  id, msg_id, url (S3), type, size, created_at
```

---

## 6. Deep Dive — Key Components

### 6.1 Delivery Guarantees — Tick Marks

```
┌─────────────────────────────────────────────────────────────────┐
│  MESSAGE LIFECYCLE                                               │
├─────────────────────────────────────────────────────────────────┤
│  1. SENT (1 tick)     : Server received, saved to DB              │
│  2. DELIVERED (2 tick): Recipient device received                │
│  3. READ (blue tick)  : Recipient opened and read                │
└─────────────────────────────────────────────────────────────────┘
```

**Implementation**:
- **Sent**: Server saves → ACK to sender
- **Delivered**: Recipient receives via WebSocket → Client sends `delivery_ack` → Server updates
- **Read**: Recipient opens chat → Client sends `read_ack` → Server updates → Notify sender

### 6.2 Offline Messages — Store and Forward

```
User A sends to User B (offline)
        │
        ▼
Server saves message to DB
        │
        ├──► Push notification to B's device (wake app if possible)
        │
        └──► When B comes online:
             B connects WebSocket
             B requests: "Give me messages since last_seen"
             Server fetches from DB, delivers
```

### 6.3 Group Chat — Fan-out

```
User sends message to group (100 members)
        │
        ▼
Server saves 1 copy to DB (conv_id, msg)
        │
        ▼
Fan-out: For each online member in group
        ├──► Push via WebSocket
        └──► For offline: Store, push notification
```

**Optimization**: Don't fan-out to 256 members synchronously. Use message queue:
```
Kafka topic: group_messages
Consumer: Group delivery workers (sharded by conv_id)
Each worker delivers to its subset of members
```

### 6.4 Presence Service — Online/Offline/Last Seen

```
┌─────────────────────────────────────────────────────────────┐
│  User connects WebSocket                                     │
│  → Set Redis: presence:user:123 = "online", TTL=60s        │
│  → Client sends heartbeat every 30s → Refresh TTL           │
│                                                              │
│  User disconnects                                            │
│  → TTL expires (no heartbeat) → "offline"                    │
│  → Or: Explicit disconnect → Set "last_seen" = now          │
└─────────────────────────────────────────────────────────────┘
```

**Privacy**: "Last seen" can be hidden (user setting). Server still tracks, but doesn't expose.

### 6.5 Media Sharing

```
User sends photo
        │
        ▼
Client uploads to pre-signed S3 URL (direct upload)
        │
        ▼
Client sends message: { type: "image", media_url: "s3://..." }
        │
        ▼
Server saves message with media_url (no file through server!)
        │
        ▼
Recipient fetches image from CDN (S3 + CloudFront)
```

**Server never touches the file** — saves bandwidth, scales.

### 6.6 End-to-End Encryption (Concept)

```
┌─────────────────────────────────────────────────────────────────┐
│  E2E: Server cannot read message content                         │
├─────────────────────────────────────────────────────────────────┤
│  1. Client A encrypts with B's public key                         │
│  2. Sends ciphertext to server                                   │
│  3. Server stores ciphertext (cannot decrypt)                     │
│  4. Server forwards to B                                          │
│  5. B decrypts with private key                                  │
│                                                                   │
│  Signal Protocol: Double Ratchet, forward secrecy                 │
│  (Full implementation = separate deep dive)                      │
└─────────────────────────────────────────────────────────────────┘
```

**For interview**: Acknowledge E2E, say "encrypted client-side, server stores ciphertext."

**Signal Protocol (simplified):**
- Each device has key pair (public/private)
- Session established via X3DH (key agreement)
- Double Ratchet: New key per message, forward secrecy
- Server only sees: encrypted blob, metadata (sender, recipient, timestamp)

### 6.7 Message Ordering

- **Per conversation**: Use timestamp + msg_id. Clustering key in Cassandra.
- **Conflict**: Two messages same millisecond? Use msg_id (UUID) as tiebreaker.
- **Out-of-order delivery**: Client sorts by (timestamp, msg_id) before display.

### 6.8 Message Deduplication

**Duplicate delivery prevent:**
- Client sends msg_id with every message
- Server: if msg_id seen in last 24h → skip (idempotent)
- Client: dedupe by msg_id before displaying

### 6.9 Typing Indicator

- Ephemeral, no persistence
- Client sends `typing: true` when user types
- Server broadcasts to other participants via WebSocket
- Auto-expire: if no message in 5 sec, send `typing: false` (or client timeout)

### 6.10 Push Notifications

```
User offline, message arrives
        │
        ▼
Server: Recipient not in WebSocket map
        │
        ▼
Queue push notification (FCM/APNs)
        │
        ▼
Device receives: "John: Hey!" (no content if E2E)
        │
        ▼
User taps → App opens → Fetches messages from server
```

---

## 7. Bottlenecks and Solutions

| Bottleneck | Problem | Solution |
|------------|---------|----------|
| **WebSocket scale** | 100M connections | Connection sharding, sticky LB, regional servers |
| **Message throughput** | 3.5M msg/sec | Kafka partitioning, consumer groups |
| **Hot conversation** | Celebrity group chat | Shard by conv_id, multiple consumers |
| **Presence load** | 100M heartbeats/30s | Redis, short TTL, batch updates |
| **Media storage** | 50 TB/day | S3 + lifecycle (archive old), compression |
| **Message history** | 1B messages/conv | Pagination, cursor-based, archive old |
| **Read receipt storm** | 256 members read | Batch ACKs, debounce |

### Sharding Strategy

| Data | Shard Key | Why |
|------|-----------|-----|
| Messages | conv_id | Conversation-scoped queries |
| Users | user_id | Even distribution |
| WebSocket | user_id → server mapping | Sticky routing |
| Presence | user_id | Per-user state |

---

## 8. Scaling Improvements

```
Phase 1: Single server, WebSocket + DB
    │
    ▼
Phase 2: Message queue (Kafka) for async delivery
    │
    ▼
Phase 3: Cassandra for messages, Redis for presence
    │
    ▼
Phase 4: WebSocket servers sharded by user_id
    │
    ▼
Phase 5: Regional deployment (user → nearest region)
    │
    ▼
Phase 6: Media on CDN, S3 lifecycle policies
    │
    ▼
Phase 7: Read replica for history, write to primary
```

### WebSocket Server Scaling

```
user_id % N = server_id
Load balancer: Sticky session by user_id
When user connects → Route to server X
All messages for user → Go to server X (via Kafka consumer)
```

**Connection mapping (Redis):**
```
Key: ws:user:{user_id}
Value: server_id (e.g., "ws-server-42")
TTL: 0 (no expiry while connected)
On connect: SET ws:user:123 "ws-server-42"
On disconnect: DEL ws:user:123
```

**Message routing:**
```
New message for user 123
  → Lookup: ws:user:123 = "ws-server-42"
  → Publish to Kafka partition 42 (or topic per server)
  → ws-server-42 consumes, pushes to connected client
```

### Kafka Partitioning for Chat

```
Option A: Partition by (sender_id, recipient_id) — ordering per conversation
Option B: Partition by recipient_id — all messages for user to one consumer
Option C: Partition by conv_id — group messages together

Best: Partition by recipient_id for 1:1, conv_id for groups
```

### Multi-Region

```
User in India → Asia region WebSocket
User in US → US region WebSocket
Messages: Replicate globally (Cassandra multi-DC)
Presence: Regional Redis, sync if needed
```

---

## 9. Trade-offs Discussed

| Decision | Option A | Option B | Choice | Why |
|----------|----------|----------|--------|-----|
| **Connection** | WebSocket | Long polling | WebSocket | Lower latency, efficient |
| **Message DB** | MySQL | Cassandra | Cassandra | Write-heavy, append-only |
| **Delivery** | At-most-once | At-least-once | At-least-once | No message loss |
| **Ordering** | Strong | Best-effort | Per-conversation | Good enough for chat |
| **Media** | Through server | Direct to S3 | Direct S3 | Server bandwidth save |
| **Presence** | Real-time | Lazy | Real-time | UX critical |
| **E2E** | No | Yes | Yes (concept) | Privacy expectation |

---

## 10. Interview Questions

1. **Duplicate delivery** — Same message 2 baar deliver? (Idempotent: msg_id check, dedupe)
2. **Message edit/delete** — Kaise handle? (Soft delete, edit = new message + ref)
3. **Large group** — 10K members group? (Fan-out via queue, rate limit)
4. **Sync across devices** — Phone + Web both open? (Both get WebSocket, same user_id)
5. **Search messages** — Full-text search? (Elasticsearch, separate index)
6. **Reconnection** — WebSocket disconnect, reconnect? (Fetch since last_msg_id)
7. **Ordering across regions** — Multi-DC? (Vector clocks or centralized timestamp)
8. **Message edit** — Edit allowed? (New message + ref to original, or append-only no edit)
9. **Voice messages** — Same as media? (Yes, upload audio file, link in message)
10. **Web + Mobile both open** — Same user, 2 devices? (Both get WebSocket, both receive)

---

## 11. 1 Minute Recall Block

```
┌─────────────────────────────────────────────────────────────────┐
│  WHATSAPP / CHAT — 60 SECOND RECALL                               │
├─────────────────────────────────────────────────────────────────┤
│  1. CONNECTION: WebSocket persistent, sticky by user_id          │
│  2. FLOW: Send → Server → Save → Kafka → Deliver to recipient   │
│  3. OFFLINE: Store in DB, push notification, fetch on connect   │
│  4. TICKS: Sent (server), Delivered (device), Read (opened)     │
│  5. GROUP: 1 write, fan-out via Kafka to N members               │
│  6. DB: Cassandra (messages), Redis (presence)                  │
│  7. MEDIA: Direct S3 upload, link in message                    │
└─────────────────────────────────────────────────────────────────┘
```

### 5 Bullet Memory Hooks

1. **WebSocket + Sticky** — user_id → server mapping, all messages that server pe
2. **Kafka for fan-out** — 1 write, async deliver to N (group/offline)
3. **Cassandra for messages** — Write-heavy, partition by conv_id
4. **Store and forward** — Offline = save + push, fetch on connect
5. **Media = S3 link** — Server never stores file, client uploads direct

---

## Appendix: Message Flow Sequence (Detailed)

```
SENDER                SERVER                 KAFKA                 RECIPIENT
   |                      |                      |                       |
   |-- send_message ----->|                      |                       |
   |                      |-- validate           |                       |
   |                      |-- save to Cassandra  |                       |
   |                      |-- produce(msg) ----->|                       |
   |<-- ack (sent) -------|                      |                       |
   |                      |                      |-- consume ---------->|
   |                      |                      |   (recipient server)   |
   |                      |                      |                       |-- push WS
   |                      |                      |<-- delivery_ack ------|
   |                      |<-- produce(ack) -----|                       |
   |<-- delivery_status --|                      |                       |
   |                      |                      |                       |-- user reads
   |                      |                      |<-- read_ack ----------|
   |                      |<-- produce(read) -----|                      |
   |<-- read_status ------|                      |                       |
```

### Conversation List (Inbox) Design

```
Key: conv_list:user:{user_id}
Value: Sorted Set (conv_id, score=last_message_timestamp)
  → ZADD conv_list:user:123 {latest_ts} conv_456
  → ZREVRANGE conv_list:user:123 0 49  (top 50 conversations)

On new message: Update last_message_ts for all participants
```

### Message Retention & Archive

- **Active**: Last 30 days in hot storage (Cassandra)
- **Archive**: Older messages → Cold storage (S3) or compressed
- **Legal hold**: Some orgs need 7-year retention — separate compliance pipeline

### Interview Tips — Chat System

1. **WebSocket + Sticky** — user_id → server mapping, Kafka for routing
2. **Delivery states** — Sent (server), Delivered (device), Read (opened)
3. **Offline = store + push** — Fetch on connect, idempotent by msg_id
4. **Group = 1 write, N fan-out** — Kafka consumers, not sync loop
5. **Cassandra for messages** — Write-heavy, partition by conv_id
6. **Media = direct S3** — Pre-signed URL, server never touches file

---

*End of WhatsApp/Chat Design — 100B messages/day handle karne ka system ab tum design kar sakte ho!*
