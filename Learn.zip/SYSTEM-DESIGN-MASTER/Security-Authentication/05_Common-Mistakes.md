# Security and Authentication — Common Mistakes

> **Permanent Recall:** The top 12 security mistakes: storing passwords in plain text, not using HTTPS, JWT without expiry, no refresh token rotation, CORS wildcard, no CSRF protection, SQL injection vulnerable, XSS vulnerable, no rate limiting on login, insecure session management, hardcoded secrets, no input validation. Avoid these to pass FAANG security discussions and ship production-ready systems.

---

## Mistake 1: Storing Passwords in Plain Text

**What happens:** Database breach exposes all passwords; attackers reuse them elsewhere.

| Wrong | Right |
|-------|-------|
| `password = "user_input"` | Hash with bcrypt/Argon2 |
| Store as-is in DB | Store only hash + salt |
| MD5/SHA for passwords | bcrypt (slow, salted) |

> **FAANG Tip:** bcrypt cost factor 10–12; Argon2 for new systems.

---

## Mistake 2: Not Using HTTPS

**What happens:** Credentials, tokens, and data sent in plain text; man-in-the-middle attacks.

**Fix:** Enforce HTTPS for all traffic. Redirect HTTP → HTTPS. Use HSTS header. Valid TLS cert.

---

## Mistake 3: JWT Without Expiry

**What happens:** Stolen token valid forever; no way to force re-auth.

**Fix:** Always set `exp` (expiration). Short TTL for access tokens (15 min–1 hr). Use refresh tokens for long sessions.

---

## Mistake 4: No Refresh Token Rotation

**What happens:** Stolen refresh token used indefinitely; no detection of theft.

**Fix:** Rotate on every use—new refresh issued, old one invalidated. If old refresh is used after rotation, revoke entire token family (possible theft).

---

## Mistake 5: CORS Wildcard

**What happens:** `Access-Control-Allow-Origin: *` with credentials allows any site to make authenticated requests from user's browser.

**Fix:** Use specific origins. Never `*` when cookies or auth headers are sent. Validate `Origin` header.

---

## Mistake 6: No CSRF Protection

**What happens:** Attacker tricks user's browser into submitting request to your site; action performed as logged-in user.

**Fix:** CSRF token in forms; `SameSite=Strict` or `Lax` on cookies; validate Origin/Referer for state-changing requests.

---

## Mistake 7: SQL Injection Vulnerable

**What happens:** Input like `' OR '1'='1` bypasses login or leaks data.

| Wrong | Right |
|-------|-------|
| `"SELECT * FROM users WHERE id='" + id + "'"` | Parameterized: `?` or `$1` |
| String concatenation | Prepared statements, ORM |

---

## Mistake 8: XSS Vulnerable

**What happens:** Inject `<script>` or event handlers; steal cookies, phish users.

**Fix:** Output encoding (escape HTML); Content-Security-Policy; HttpOnly cookies; sanitize user input.

---

## Mistake 9: No Rate Limiting on Login

**What happens:** Brute-force and credential stuffing attacks succeed.

**Fix:** Limit attempts per IP and per account (e.g., 5/15 min). Lock or CAPTCHA after threshold. Log failures.

---

## Mistake 10: Insecure Session Management

**What happens:** Predictable session IDs; no secure flags; sessions never expire.

**Fix:**
- Cryptographically random session IDs
- `HttpOnly`, `Secure`, `SameSite` on cookies
- Session timeout; regenerate ID on login
- Store server-side; validate on each request

---

## Mistake 11: Hardcoded Secrets

**What happens:** API keys, DB passwords in code; leaked via repo, logs, or reverse engineering.

**Fix:** Environment variables, secrets manager (Vault, AWS Secrets); never commit secrets; rotate regularly.

---

## Mistake 12: No Input Validation

**What happens:** Malformed data, overflow, injection, unexpected types cause errors or vulnerabilities.

**Fix:** Validate type, length, format. Whitelist allowed values. Reject invalid input early. Sanitize for output.

> **FAANG Tip:** Validate at the edge; never trust client input. Use allowlists over blocklists.

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| Plain text passwords | Credential theft | bcrypt/Argon2 |
| No HTTPS | MITM, eavesdropping | TLS everywhere |
| JWT no expiry | Eternal token | exp, short TTL |
| No refresh rotation | Stolen refresh abuse | Rotate, detect reuse |
| CORS wildcard | Cross-site auth abuse | Specific origins |
| No CSRF | Forged requests | Token, SameSite |
| SQL injection | Data breach, auth bypass | Parameterized queries |
| XSS | Cookie theft, phishing | Encode, CSP, HttpOnly |
| No login rate limit | Brute-force | Limit, lock, CAPTCHA |
| Insecure sessions | Session hijack | Random ID, flags, timeout |
| Hardcoded secrets | Leak | Env, vault, rotate |
| No input validation | Injection, crashes | Validate, sanitize |

---

## 30-SECOND REVISION BOX

```
1. bcrypt, never plain text
2. HTTPS always
3. JWT with exp
4. Refresh token rotation
5. No CORS * with credentials
6. CSRF protection
7. Parameterized SQL
8. XSS: encode, CSP
9. Rate limit login
10. Secure session (HttpOnly, Secure, timeout)
11. No hardcoded secrets
12. Input validation
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
