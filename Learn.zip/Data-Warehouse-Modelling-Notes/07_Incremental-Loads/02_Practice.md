# Incremental Loads — Practice

> "Incremental loading is a contract with time: know your watermark, honor your grain."

---

## Quick Recall

**Q:** What is an incremental load?  
**A:** Processing only new or changed data since the last successful batch instead of reloading the entire table.

**Q:** What is a high-watermark column for retail orders?  
**A:** Typically `updated_at` or `order_modified_at`, sometimes paired with `order_id` for tie-breaking.

**Q:** What is CDC?  
**A:** Change data capture streams inserts, updates, and deletes from source logs into the pipeline.

**Q:** What risk exists with naive `WHERE order_date > last_run`?  
**A:** Late-arriving rows or backdated corrections can be missed if you only filter on business date.

**Q:** What is merge (upsert) semantics?  
**A:** Insert new keys, update changed rows, optionally delete when source indicates removal.

---

## Interview Questions

**1. How do you design incremental loads for a high-volume `orders` table?**  
**Model answer:** I choose a reliable change indicator—preferably CDC or an `updated_at` maintained by the application—capture a batch window with overlap for safety, merge into the fact on natural or surrogate keys, and reconcile row counts and amounts to staging totals each run. I never rely on "max id" alone if ids are not strictly monotonic across shards.

**2. How do you handle late-arriving facts in e-commerce?**  
**Model answer:** I use technical ingestion windows, overlap previous batches, or maintain a late-arriving bucket that reprocesses a sliding window of days. Business `order_date` alone is insufficient without understanding source behavior. I document how dashboards behave when a November order lands in December processing.

**3. Compare truncate-and-reload vs incremental for a small dimension.**  
**Model answer:** Small dimensions like `dim_payment_method` can be full refresh for simplicity. Large facts like `fact_sales_line` should be incremental to control cost and load time. The cutoff depends on row counts, change rate, and compliance needs for history.

**4. What is idempotency in incremental pipelines?**  
**Model answer:** Replaying the same batch window should not double-insert rows; merges and deterministic keys make retries safe during operational incidents. Idempotency is non-negotiable for marketplace payout pipelines.

**5. How do you validate an incremental load?**  
**Model answer:** Hash sums on amounts, distinct key counts, null rate checks, and reconcile to source control totals for the window. I also compare yesterday's published total to today's restated total when late arrivals are expected.

**6. Explain delete handling from source.**  
**Model answer:** Soft-delete flags in the warehouse, tombstone events from CDC, or explicit delete facts—never pretend deletes did not happen if finance requires integrity. For retail catalogs, deletes may be rare; for customer accounts, they are sensitive legally.

**7. What is a hybrid approach for dimensions?**  
**Model answer:** Incremental SCD processing: detect changes on natural key, apply Type 1 or Type 2 rules only for changed attributes. This reduces full-table scans while preserving history where required.

**8. How do you coordinate incremental loads with downstream BI caches?**  
**Model answer:** Publish load completion events, version datasets, or use semantic layer refresh hooks so dashboards do not show half-updated windows during long merges.

---

## Scenario-Based Exercises

**Scenario 1 — OMS backfills yesterday's orders today**  
**Solution:** Incremental filter on `updated_at >= watermark - overlap` while still partitioning facts by `order_date` for query pruning. Communicate to analysts that "order date" and "processing date" differ.

**Scenario 2 — Partial batch failure mid-window**  
**Solution:** Persist batch metadata in a control table; on retry, use the same window boundaries and merge semantics so duplicates do not occur. Mark batches as failed with diagnostic payloads.

**Scenario 3 — Full initial load then incremental**  
**Solution:** One-time historical backfill with chunked ranges; switch to CDC or watermark-driven merges afterward. Chunk by month for ten years of orders to avoid long locks on source.

```sql
MERGE INTO dw.fact_sales AS t
USING staging.orders_delta AS s
ON t.order_id = s.order_id
WHEN MATCHED AND s.row_hash <> t.row_hash THEN
  UPDATE SET amount = s.amount, updated_at = s.updated_at
WHEN NOT MATCHED THEN
  INSERT (order_id, customer_key, order_date, amount, updated_at)
  VALUES (s.order_id, s.customer_key, s.order_date, s.amount, s.updated_at);
```

**Scenario 4 — Retroactive price updates and duplicate retries**  
**Solution:** Treat retroactive seller price changes as dimension change or pricing adjustment facts depending on whether historical price at sale time must be preserved; align with seller contract language. For duplicate detection after network retries, use natural keys in merge plus ingestion metadata such as `source_batch_id`, and alert when merge insert rates spike unexpectedly.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Watermark = business date only | Misses corrections | Add technical timestamps or overlap |
| Ignoring deletes | Warehouse diverges from OMS | Plan CDC or soft deletes explicitly |
| No overlap window | One-second gaps lose rows | Use modest overlap plus merge keys |
| Double-count on retries | Operational reality | Idempotent merge and batch logging |
| Assuming monotonic IDs | Sharded systems break this | Prefer CDC or `updated_at` |
| Full reload "to be safe" nightly | Does not scale | Incremental with reconciliation gates |

---

## One-Liner Answers

- Incremental loads process only new or changed rows to save time and money at retail scale.
- Prefer CDC or `updated_at` over business date alone when corrections exist.
- Merge semantics make retries safe without duplicating facts.
- Late-arriving data needs overlap windows or reprocessing rules.
- Control tables record watermarks, batch boundaries, and validation outcomes.
- Dimensions can still be incrementally processed for SCD changes while facts stream in.
