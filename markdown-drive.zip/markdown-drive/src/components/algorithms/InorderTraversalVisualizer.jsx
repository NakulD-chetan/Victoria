import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function sampleTree() {
  const nodes = [
    { id: 0, value: 50, left: 1, right: 2 },
    { id: 1, value: 30, left: 3, right: 4 },
    { id: 2, value: 70, left: 5, right: 6 },
    { id: 3, value: 20, left: 7, right: 8 },
    { id: 4, value: 40, left: 9, right: null },
    { id: 5, value: 60, left: null, right: 10 },
    { id: 6, value: 80, left: 11, right: 12 },
    { id: 7, value: 15, left: null, right: null },
    { id: 8, value: 25, left: null, right: null },
    { id: 9, value: 35, left: null, right: null },
    { id: 10, value: 65, left: null, right: null },
    { id: 11, value: 75, left: null, right: null },
    { id: 12, value: 90, left: null, right: null },
  ];
  const edges = [];
  nodes.forEach((n) => {
    if (n.left != null) edges.push([n.id, n.left]);
    if (n.right != null) edges.push([n.id, n.right]);
  });
  return { nodes, edges };
}

function buildNodeColors(currentId, stack, visited, resultIds) {
  const nodeColors = {};
  stack.forEach((id) => { nodeColors[id] = 'visited'; });
  visited.forEach((id) => { nodeColors[id] = 'visited'; });
  resultIds.forEach((id) => { nodeColors[id] = 'result'; });
  if (currentId != null) nodeColors[currentId] = 'current';
  return nodeColors;
}

function generateSteps(tree) {
  const { nodes } = tree;
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const steps = [];
  let cur = 0;
  const stack = [];
  const result = [];
  const visited = new Set();

  steps.push({
    caption: 'Start at root, push all left spine',
    stack: [], queue: [], result: [], nodeColors: buildNodeColors(cur, stack, visited, []),
  });

  while (cur != null || stack.length) {
    while (cur != null) {
      steps.push({
        caption: `Push left: stack ← ${byId[cur].value}`,
        stack: stack.map((id) => byId[id].value),
        queue: [],
        result: [...result],
        nodeColors: buildNodeColors(cur, stack, visited, []),
        visitAnim: cur,
      });
      stack.push(cur);
      cur = byId[cur].left;
    }
    cur = stack.pop();
    result.push(byId[cur].value);
    visited.add(cur);
    steps.push({
      caption: `Pop & visit ${byId[cur].value} → inorder output`,
      stack: stack.map((id) => byId[id].value),
      queue: [],
      result: [...result],
      nodeColors: buildNodeColors(null, stack, visited, [cur]),
      visitAnim: cur,
    });
    cur = byId[cur].right;
    if (cur != null) {
      steps.push({
        caption: `Move right to subtree rooted at ${byId[cur].value}`,
        stack: stack.map((id) => byId[id].value),
        queue: [],
        result: [...result],
        nodeColors: buildNodeColors(cur, stack, visited, []),
      });
    }
  }
  steps.push({
    caption: 'Inorder complete',
    stack: [],
    queue: [],
    result: [...result],
    nodeColors: buildNodeColors(null, [], visited, [...visited]),
  });
  return steps;
}

export default function InorderTraversalVisualizer({ config }) {
  const treeRef = { current: sampleTree() };

  const onInit = useCallback((canvasRef) => {
    treeRef.current = sampleTree();
    const steps = generateSteps(treeRef.current);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Iterative inorder with explicit stack' });
    canvasRef.current?.setState({
      ...treeRef.current,
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Ready',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || step.type || 'step' });
    if (step.visitAnim != null) canvasRef.current?.addAnim('visit', { nodeId: step.visitAnim }, 320);
    canvasRef.current?.setState({
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
