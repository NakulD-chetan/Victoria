# Joins — Concept

> **Permanent recall:** A **JOIN** combines rows from two+ tables by a **predicate** (usually key equality). **INNER** = intersection; **LEFT** = preserve left + optional right; **FULL** = union of both sides with NULLs.

---

## Join types (core)

| Join | Keeps | Use when |
|------|--------|---------|
| **INNER** | Only **matching** pairs on predicate | Both sides must have data |
| **LEFT (OUTER)** | **All** left rows + matched right (else NULL) | Left entity must appear even if no match |
| **RIGHT (OUTER)** | Mirror of LEFT (prefer LEFT for consistency) | Rarely used — rewrite as LEFT |
| **FULL OUTER** | All rows from **both** sides, NULLs for non-matches | Need complete picture from both tables |
| **CROSS** | Cartesian product — every left × every right | Generate combinations, test data |
| **SELF** | Same table twice (aliases required) | Employee-manager, compare rows in same table |

---

## NATURAL JOIN

Automatically joins on **all columns with same name** in both tables. Dangerous — if column names change, join changes silently.

```sql
SELECT * FROM employees NATURAL JOIN departments;
-- auto-joins on matching column names (e.g., dept_id)
```

> **Interview tip:** "I avoid NATURAL JOIN in production — it's fragile. Explicit ON is safer."

---

## USING Clause

Shortcut when join column has **same name** in both tables:

```sql
SELECT * FROM employees JOIN departments USING (dept_id);
-- equivalent to: ON employees.dept_id = departments.dept_id
-- but dept_id appears only ONCE in result
```

---

## ON vs WHERE (with INNER)

For **INNER JOIN**, `ON` vs `WHERE` often interchangeable — style: put **join keys** in `ON`, **filters** in `WHERE`.

For **OUTER** joins, **`ON` vs `WHERE` changes results** — predicates in WHERE can turn outer join into inner if placed wrong.

```sql
-- Preserves all employees, only matches active departments:
LEFT JOIN departments d ON e.dept_id = d.dept_id AND d.active = TRUE

-- This REMOVES employees without active department (acts like INNER):
LEFT JOIN departments d ON e.dept_id = d.dept_id
WHERE d.active = TRUE
```

---

## Join Algorithms (how DB executes joins)

| Algorithm | How it works | Best when |
|-----------|-------------|-----------|
| **Nested Loop** | For each row in outer table, scan inner table | Small tables or indexed inner table |
| **Hash Join** | Build hash table on smaller table, probe with larger | Large unsorted tables, equi-join |
| **Merge Join (Sort-Merge)** | Sort both tables on join key, merge | Both tables already sorted or indexed |

> DB optimizer picks automatically based on table size, indexes, statistics. EXPLAIN shows which.

---

## NULL in join keys

- `NULL = NULL` is **UNKNOWN**, not TRUE → rows with NULL FK **won't match** in equi-join unless handled (`IS NULL` logic or `COALESCE` strategy).

---

## Anti-Join (find non-matching rows)

Three ways to find "rows in A without match in B":

```sql
-- 1. LEFT JOIN + IS NULL (most common)
SELECT a.* FROM A a LEFT JOIN B b ON a.id = b.a_id WHERE b.a_id IS NULL;

-- 2. NOT EXISTS (NULL-safe, often preferred)
SELECT * FROM A a WHERE NOT EXISTS (SELECT 1 FROM B b WHERE b.a_id = a.id);

-- 3. NOT IN (watch for NULLs!)
SELECT * FROM A WHERE id NOT IN (SELECT a_id FROM B WHERE a_id IS NOT NULL);
```

---

## Semi-Join (EXISTS — just check existence)

Returns rows from A where a match EXISTS in B — does NOT add columns from B:

```sql
SELECT * FROM customers c
WHERE EXISTS (SELECT 1 FROM orders o WHERE o.customer_id = c.id);
```

---

## Cross Join use cases

- Generate all date × product combinations (for reporting missing data)
- Create test data / permutations
- Pair every row with every other row

---

*Next: [[02_Mental-Model]]*
