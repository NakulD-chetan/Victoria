# Grammar Essentials — Articles, Prepositions, Modals & More

> *"Grammar rules yaad karo, lekin conversation mein naturally use karo — ratta mat lagao"*

Yeh chapter mein important grammar topics cover karenge jo daily speaking mein baar-baar aate hain: Articles, Prepositions, Modals, Subject-Verb Agreement, aur common confusions.

---

## 1. Articles — A / An / The

### Basic Rule

| Article | Kab Use Karo | Example |
|---------|-------------|---------|
| **a** | Consonant sound se start hone wale singular noun ke pehle | a book, a car, a university *(yoo sound)* |
| **an** | Vowel sound se start hone wale singular noun ke pehle | an apple, an egg, an hour *(silent h)* |
| **the** | Specific / particular cheez ke baare mein | the sun, the book on the table |

### Trick: Sound dekho, spelling nahi!

| Word | Article | Kyun |
|------|---------|------|
| **university** | **a** university | "yoo" sound — consonant sound |
| **hour** | **an** hour | "au" sound — vowel sound (h silent) |
| **honest** | **an** honest man | "o" sound — h silent |
| **European** | **a** European | "yoo" sound — consonant sound |
| **MBA** | **an** MBA | "em" sound — vowel sound |

### Kab Article USE Nahi Karte

| Situation | Example |
|-----------|---------|
| Uncountable nouns (general) | I like **music**. (NOT: the music) |
| Plural nouns (general sense) | **Dogs** are loyal. (NOT: The dogs) |
| Proper nouns (generally) | **India** is beautiful. (NOT: The India) |
| Meals (general) | I had **lunch**. (NOT: a lunch) |
| Languages | I speak **English**. |
| Sports | I play **cricket**. |

### Kab "THE" Zaroor Lagao

| Situation | Example |
|-----------|---------|
| Unique cheezein | the sun, the moon, the earth, the sky |
| Superlatives | the best, the tallest, the most beautiful |
| Ordinals | the first, the second, the last |
| Specific / already discussed | I bought **a** pen. **The** pen is blue. |
| Countries (with Republic/Kingdom/States) | the USA, the UK, the UAE |
| Rivers, oceans, mountain ranges | the Ganges, the Pacific, the Himalayas |
| Newspapers | the Times of India |

[COMMON MISTAKE] "I am **engineer**" → "I am **an** engineer." Profession ke pehle a/an lagta hai.

---

## 2. Prepositions — In / On / At / By / For / With

### Time Ke Liye

| Preposition | Kab | Examples |
|-------------|-----|---------|
| **at** | Specific time | at 5 PM, at noon, at midnight, at night |
| **on** | Days / Dates | on Monday, on 15th March, on my birthday |
| **in** | Months / Years / Seasons / Parts of day | in January, in 2026, in summer, in the morning |

[TIP] Yaad karne ka trick: **at** = point, **on** = surface/day, **in** = enclosed/large period.

### Place Ke Liye

| Preposition | Kab | Examples |
|-------------|-----|---------|
| **at** | Specific point / location | at the door, at the bus stop, at home |
| **on** | Surface pe | on the table, on the wall, on the floor |
| **in** | Enclosed space / andar | in the room, in the car, in India, in the box |

### Common Preposition Phrases

| Phrase | Meaning | Example |
|--------|---------|---------|
| **look at** | dekhna | Look at this picture. |
| **listen to** | sunna | Listen to the teacher. |
| **wait for** | intezaar karna | Wait for me. |
| **depend on** | nirbhar hona | It depends on the weather. |
| **think about** | sochna | Think about your future. |
| **agree with** | sehmat hona | I agree with you. |
| **belong to** | kisi ka hona | This book belongs to me. |
| **apologize for** | maafi maangna | I apologize for being late. |

[COMMON MISTAKE] "I am **married with** him" → "I am **married to** him."

---

## 3. Modals — Can, Could, Will, Would, Should, Must, May, Might

| Modal | Meaning | Example |
|-------|---------|---------|
| **can** | Ability (sakta hai) | I **can** speak English. |
| **could** | Past ability / polite request | I **could** swim when I was 10. / **Could** you help me? |
| **will** | Future / promise | I **will** call you tomorrow. |
| **would** | Polite / hypothetical | **Would** you like some tea? / I **would** go if I had time. |
| **shall** | Suggestion / offer (formal) | **Shall** we go? / **Shall** I open the door? |
| **should** | Advice (chahiye) | You **should** study harder. |
| **must** | Strong obligation / zaroor | You **must** wear a helmet. |
| **may** | Permission / possibility | **May** I come in? / It **may** rain today. |
| **might** | Weak possibility | He **might** come later. *(shayad)* |
| **need** | Zaroorat | You **need** to practice more. |

### Modal Rules

- Modal ke baad **V1** (base form) aata hai — NEVER V2 or V-ing
  - **Right:** He can **speak**. 
  - **Wrong:** He can **speaks**. / He can **speaking**.
- Modals ke saath do/does/did **nahi** lagate
  - **Right:** She can't come.
  - **Wrong:** She doesn't can come.

---

## 4. Subject-Verb Agreement

> **Rule:** Subject singular hai toh verb singular, subject plural hai toh verb plural.

| Subject | Verb | Example |
|---------|------|---------|
| I | am / have / go | I **am** a student. |
| He / She / It | is / has / goes | She **is** a teacher. He **goes** daily. |
| You / We / They | are / have / go | They **are** happy. We **have** a plan. |

### Tricky Cases

| Rule | Example |
|------|---------|
| "Everyone / Everybody / Each" = singular | Everyone **is** here. (NOT: are) |
| "Neither...nor" — verb agrees with nearest subject | Neither he nor they **are** coming. |
| "A lot of" — depends on noun | A lot of water **is** wasted. / A lot of people **are** here. |
| Uncountable nouns = singular | Information **is** important. (NOT: are) |
| "News" = singular | The news **is** shocking. (NOT: are) |
| "Mathematics / Physics" = singular | Mathematics **is** my favorite subject. |

---

## 5. Common Confusions — Quick Reference

| Confusion | Rule | Example |
|-----------|------|---------|
| **much vs many** | much = uncountable, many = countable | much water, many bottles |
| **few vs little** | few = countable, little = uncountable | few friends, little time |
| **a few vs few** | a few = kuch (positive), few = bahut kam (negative) | I have **a few** friends. (achha) / I have **few** friends. (sad) |
| **since vs for** | since = point in time, for = duration | since 2020, for 5 years |
| **in vs after** | in = future mein kitne baad, after = past mein kitne baad | I'll come **in** 10 minutes. / He came **after** 10 minutes. |
| **its vs it's** | its = uska (possessive), it's = it is | The dog wagged **its** tail. / **It's** raining. |
| **there / their / they're** | there = wahan, their = unka, they're = they are | **They're** going to **their** house. It's **there**. |
| **than vs then** | than = comparison, then = time/sequence | He is taller **than** me. / First eat, **then** sleep. |
| **affect vs effect** | affect = verb, effect = noun | The rain **affected** the match. / The **effect** was visible. |
| **lose vs loose** | lose = kho dena, loose = dheela | Don't **lose** hope. / The shirt is **loose**. |

---

## 6. Question Formation — Quick Rules

| Type | Structure | Example |
|------|-----------|---------|
| **Yes/No** | Do/Does/Did + subject + V1? | **Do** you like coffee? |
| **Wh-question** | Wh-word + do/does/did + subject + V1? | **Where** do you live? |
| **With "be"** | Am/Is/Are + subject? | **Are** you coming? |
| **With modals** | Modal + subject + V1? | **Can** you help me? |

### Common Wh-Words

| Word | Puchta hai | Example |
|------|-----------|---------|
| **What** | Kya | What is your name? |
| **Where** | Kahan | Where do you live? |
| **When** | Kab | When is the meeting? |
| **Who** | Kaun | Who is your teacher? |
| **Why** | Kyun | Why are you late? |
| **How** | Kaise | How are you? |
| **Which** | Kaun sa | Which one do you want? |
| **Whose** | Kiska | Whose pen is this? |

---

*Agle chapter mein: Vocabulary Building — naye words kaise seekhein aur kaise yaad rakhein*
