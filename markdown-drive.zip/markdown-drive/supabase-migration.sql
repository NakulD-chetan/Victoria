-- ============================================================
-- InkDrop Algorithm Platform - Database Schema Migration
-- Run this in Supabase Dashboard > SQL Editor
-- ============================================================

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  color VARCHAR(20),
  algo_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Algorithms table
CREATE TABLE IF NOT EXISTS algorithms (
  id SERIAL PRIMARY KEY,
  slug VARCHAR(150) UNIQUE NOT NULL,
  title VARCHAR(255) NOT NULL,
  category_id INT REFERENCES categories(id),
  category VARCHAR(100) NOT NULL,
  difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  short_description TEXT,
  icon VARCHAR(10),
  color VARCHAR(20),
  languages TEXT[] DEFAULT '{}',
  tags TEXT[] DEFAULT '{}',
  default_params JSONB DEFAULT '{}',
  visualizer_key VARCHAR(100),
  sort_order INT DEFAULT 0,
  published BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Algorithm introduction content (EN/HI)
CREATE TABLE IF NOT EXISTS algorithm_content (
  id SERIAL PRIMARY KEY,
  algorithm_id INT NOT NULL REFERENCES algorithms(id) ON DELETE CASCADE,
  lang VARCHAR(5) NOT NULL CHECK (lang IN ('en', 'hi')),
  intro_markdown TEXT NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(algorithm_id, lang)
);

-- Algorithm code (per language)
CREATE TABLE IF NOT EXISTS algorithm_code (
  id SERIAL PRIMARY KEY,
  algorithm_id INT NOT NULL REFERENCES algorithms(id) ON DELETE CASCADE,
  language VARCHAR(20) NOT NULL,
  code_lines JSONB NOT NULL DEFAULT '[]',
  step_info JSONB NOT NULL DEFAULT '{}',
  steps_allow JSONB DEFAULT '[]',
  steps_deny JSONB DEFAULT '[]',
  UNIQUE(algorithm_id, language)
);

-- Tags table
CREATE TABLE IF NOT EXISTS tags (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  usage_count INT DEFAULT 0
);

-- Algorithm-Tags junction
CREATE TABLE IF NOT EXISTS algorithm_tags (
  algorithm_id INT NOT NULL REFERENCES algorithms(id) ON DELETE CASCADE,
  tag_id INT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (algorithm_id, tag_id)
);

-- Problems table
CREATE TABLE IF NOT EXISTS problems (
  id SERIAL PRIMARY KEY,
  slug VARCHAR(150) UNIQUE NOT NULL,
  number INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  icon VARCHAR(10),
  difficulty VARCHAR(20) NOT NULL CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  description TEXT,
  requirements JSONB DEFAULT '{}',
  hints JSONB DEFAULT '[]',
  test_cases JSONB DEFAULT '[]',
  constraints JSONB DEFAULT '[]',
  published BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for fast queries
CREATE INDEX IF NOT EXISTS idx_algorithms_category ON algorithms(category);
CREATE INDEX IF NOT EXISTS idx_algorithms_difficulty ON algorithms(difficulty);
CREATE INDEX IF NOT EXISTS idx_algorithms_published ON algorithms(published);
CREATE INDEX IF NOT EXISTS idx_algorithms_slug ON algorithms(slug);
CREATE INDEX IF NOT EXISTS idx_algorithm_content_algo ON algorithm_content(algorithm_id);
CREATE INDEX IF NOT EXISTS idx_algorithm_code_algo ON algorithm_code(algorithm_id);
CREATE INDEX IF NOT EXISTS idx_problems_difficulty ON problems(difficulty);
CREATE INDEX IF NOT EXISTS idx_problems_slug ON problems(slug);

-- Full-text search index on algorithms
ALTER TABLE algorithms ADD COLUMN IF NOT EXISTS fts tsvector
  GENERATED ALWAYS AS (
    to_tsvector('english', coalesce(title, '') || ' ' || coalesce(short_description, '') || ' ' || coalesce(category, ''))
  ) STORED;
CREATE INDEX IF NOT EXISTS idx_algorithms_fts ON algorithms USING GIN(fts);

-- Full-text search index on problems
ALTER TABLE problems ADD COLUMN IF NOT EXISTS fts tsvector
  GENERATED ALWAYS AS (
    to_tsvector('english', coalesce(title, '') || ' ' || coalesce(description, ''))
  ) STORED;
CREATE INDEX IF NOT EXISTS idx_problems_fts ON problems USING GIN(fts);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_algorithms_updated
  BEFORE UPDATE ON algorithms
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE OR REPLACE TRIGGER trg_problems_updated
  BEFORE UPDATE ON problems
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- RLS policies (allow read for anon, write for authenticated)
ALTER TABLE algorithms ENABLE ROW LEVEL SECURITY;
ALTER TABLE algorithm_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE algorithm_code ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE algorithm_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE problems ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "public_read_algorithms" ON algorithms FOR SELECT USING (true);
CREATE POLICY "public_read_algorithm_content" ON algorithm_content FOR SELECT USING (true);
CREATE POLICY "public_read_algorithm_code" ON algorithm_code FOR SELECT USING (true);
CREATE POLICY "public_read_categories" ON categories FOR SELECT USING (true);
CREATE POLICY "public_read_tags" ON tags FOR SELECT USING (true);
CREATE POLICY "public_read_algorithm_tags" ON algorithm_tags FOR SELECT USING (true);
CREATE POLICY "public_read_problems" ON problems FOR SELECT USING (true);

-- Service role write access (for seed script and admin)
CREATE POLICY "service_write_algorithms" ON algorithms FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_algorithm_content" ON algorithm_content FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_algorithm_code" ON algorithm_code FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_categories" ON categories FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_tags" ON tags FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_algorithm_tags" ON algorithm_tags FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "service_write_problems" ON problems FOR ALL USING (true) WITH CHECK (true);
