# System Design Fundamentals — Edge Cases

> **Permanent Recall:** Universal edge cases for ALL system designs: network partitions, server crashes, DB failures, cache stampede, hot spots, clock skew, data corruption, cascading failures, split brain, thundering herd, race conditions, regional outages. Plan for each; categorize by type. Use this checklist in every design.

---

## Universal Edge Cases — Categorized Table

| Category | Edge Case | What Happens | Mitigation |
|----------|-----------|--------------|------------|
| **Network** | Network partition | Parts of system can't communicate | Timeouts, circuit breakers; design for partial availability |
| **Network** | Regional outage | Entire region down (DC, AZ) | Multi-region; failover; replicate data |
| **Node** | Server crash | Process dies mid-request | Stateless; retry; idempotency |
| **Node** | DB primary failure | Writes fail; reads may be stale | Failover to replica; replication lag awareness |
| **Cache** | Cache stampede | Cache expires; many requests hit DB at once | Lock (mutex), probabilistic early expiration |
| **Cache** | Thundering herd | Many clients request same cold key | Same as stampede; single-flighter pattern |
| **Data** | Hot spots | One key (e.g., celebrity) gets most traffic | Split key; add replication for hot shards |
| **Data** | Clock skew | Servers have different time; ordering wrong | Use logical clocks (Lamport) or server-generated timestamps |
| **Data** | Data corruption | Bad write; partial failure; bit flip | Checksums, idempotency, audit logs |
| **Cascade** | Cascading failure | One failure causes overload downstream | Circuit breakers, bulkheads, backpressure |
| **Consensus** | Split brain | Two primaries after partition; inconsistent writes | Quorum, leader election; avoid if possible |
| **Concurrency** | Race condition | Two requests overwrite each other | Locks, optimistic concurrency (version), idempotency |
| **Concurrency** | Duplicate delivery | At-least-once delivers same message twice | Idempotent consumers; deduplication by ID |

---

## Network Partitions

**What:** Network splits; some nodes can't reach others.

**Impact:** Inconsistent state; possible split brain in DB; messages lost or delayed.

**Mitigation:**
- **Timeouts:** Don't wait forever; fail fast.
- **Circuit breakers:** Stop calling failing service.
- **Design for partial availability:** Degrade gracefully (e.g., serve cached data).
- **Quorum writes:** Avoid split brain by requiring majority (e.g., 3 nodes, 2 must ack).

---

## Server Crashes

**What:** Process dies; in-flight requests lost; state in memory gone.

**Impact:** User sees error; possible duplicate if retried.

**Mitigation:**
- **Stateless servers:** No in-memory state; any server can retry.
- **Idempotency:** Client sends `idempotency_key`; server deduplicates.
- **Retries with backoff:** Client retries; exponential backoff to avoid stampede.
- **Health checks:** LB removes dead instances.

---

## DB Failures

**What:** Primary down; replica lagged; disk full; connection exhausted.

**Impact:** Writes fail; reads may return stale or nothing.

**Mitigation:**
- **Failover:** Promote replica to primary; DNS or service discovery update.
- **Connection pooling:** Avoid exhaustion.
- **Read replicas:** Serve reads during primary failover (stale OK for some use cases).
- **Circuit breaker:** Stop sending traffic to failing DB.

---

## Cache Stampede

**What:** Popular key expires; hundreds of requests miss cache and hit DB simultaneously.

**Impact:** DB overload; timeout; possible outage.

**Mitigation:**
- **Lock (mutex):** First request acquires lock; others wait; one DB call.
- **Probabilistic early expiration:** Before TTL, some requests refresh (e.g., 1/10 chance).
- **Background refresh:** Never expire; refresh in background when stale.
- **Stale-while-revalidate:** Serve stale, refresh async.

---

## Hot Spots

**What:** One key (e.g., celebrity `user_id`) gets 80% of traffic.

**Impact:** Single shard/partition overloaded; others underutilized.

**Mitigation:**
- **Split hot key:** e.g., `user_123_post_1`, `user_123_post_2` — distribute across shards.
- **Replication:** Replicate hot data to multiple nodes.
- **Local cache:** Client-side or edge cache for hottest content.
- **Rate limit:** Throttle requests to hot key if abuse.

---

## Clock Skew

**What:** Server A says 10:00:00, Server B says 10:00:05. Ordering by time is wrong.

**Impact:** Wrong order of events; "happened before" incorrect.

**Mitigation:**
- **Server timestamps only:** Don't trust client time.
- **Logical clocks:** Lamport timestamps or vector clocks for ordering.
- **Sequencers:** Central service assigns monotonic IDs (Snowflake).
- **Avoid time for critical ordering:** Use `sequence_id` from single source.

---

## Data Corruption

**What:** Bad write, partial failure, bit flip on disk.

**Impact:** Wrong data served; integrity violated.

**Mitigation:**
- **Checksums:** Verify on read; detect corruption.
- **Idempotent writes:** Same request = same outcome; safe to retry.
- **Audit logs:** Reconstruct what happened.
- **Replication:** Compare replicas; detect divergence.

---

## Cascading Failures

**What:** Service A slow → B waits → B's connections pile up → B slow → C fails. Chain reaction.

**Impact:** Small fault becomes system-wide outage.

**Mitigation:**
- **Circuit breaker:** Stop calling failing service; fail fast.
- **Bulkheads:** Isolate resources (e.g., connection pool per dependency).
- **Timeouts:** Don't wait forever.
- **Backpressure:** Propagate "I'm overloaded" upstream; slow down clients.

---

## Split Brain

**What:** Network partition; two nodes believe they're primary; both accept writes.

**Impact:** Divergent data; merge conflict; data loss possible.

**Mitigation:**
- **Quorum:** Writes need majority; partition prevents quorum → no write.
- **Single leader:** Leader election; only one primary.
- **Avoid if possible:** Prefer single-primary + replicas; multi-primary is hard.
- **Conflict resolution:** If multi-write, use CRDTs or last-write-wins with caution.

---

## Thundering Herd

**What:** Many clients (or servers) do the same thing at once — e.g., all request a resource when it becomes available.

**Impact:** Overload; same as cache stampede.

**Mitigation:**
- **Single-flighter:** Only one request does the work; others wait.
- **Randomization:** Stagger retries or requests.
- **Backoff:** Exponential backoff on retry.
- **Batching:** Consolidate many small requests into one.

---

## Race Conditions

**What:** Two requests read same state, both modify, both write; one overwrites the other.

**Impact:** Lost update; inconsistent state.

**Mitigation:**
- **Optimistic locking:** Version field; `UPDATE SET ... WHERE version = X`; retry if conflict.
- **Pessimistic locking:** Lock row/key before update.
- **Single writer:** Route updates for same key to same partition/thread.
- **Idempotency:** Ensure same input = same output.

---

## Regional Outages

**What:** Entire region (AZ, DC, cloud region) unavailable.

**Impact:** Total outage if single region; latency spike if users far from remaining region.

**Mitigation:**
- **Multi-region:** Deploy in 2+ regions.
- **Failover:** DNS or global LB switches traffic.
- **Data replication:** Async or sync replication to other region(s).
- **Design for degradation:** Read-only mode if write region down.

---

## Edge Case Checklist (Use in Every Design)

| Edge Case | Did I consider it? | Mitigation in design? |
|-----------|-------------------|------------------------|
| Network partition | ☐ | |
| Server crash | ☐ | |
| DB failure | ☐ | |
| Cache stampede | ☐ | |
| Hot spot | ☐ | |
| Clock skew | ☐ | |
| Cascading failure | ☐ | |
| Split brain (if multi-write) | ☐ | |
| Thundering herd | ☐ | |
| Race condition | ☐ | |
| Regional outage | ☐ | |
| Duplicate delivery | ☐ | |

> **FAANG Tip:** "Let me address a few edge cases: If the DB fails, we failover to a replica. If we get a cache stampede, we use a mutex so only one request repopulates. For clock skew, we use server-generated sequence IDs for ordering."

---

## 30-SECOND REVISION BOX

```
NETWORK: Partition, region outage → timeouts, multi-region
NODE: Server/DB crash → stateless, failover, idempotency
CACHE: Stampede, thundering herd → lock, probabilistic refresh
DATA: Hot spot, clock skew, corruption → split key, logical clocks, checksums
CASCADE: Cascading failure → circuit breaker, timeouts
CONSENSUS: Split brain → quorum, single leader
CONCURRENCY: Race, duplicate → optimistic lock, idempotency
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
