import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function lowbit(i) {
  return i & -i;
}

function buildFenwickGraph(arr) {
  const n = arr.length;
  const nodes = [];
  const edges = [];
  for (let i = 1; i <= n; i += 1) {
    nodes.push({ id: i, value: arr[i - 1], label: `${arr[i - 1]}` });
    const p = i + lowbit(i);
    if (p <= n) edges.push([i, p]);
  }
  return { nodes, edges };
}

function generateSteps(base) {
  const steps = [];
  const n = base.length;
  let bit = Array(n + 1).fill(0);

  const snap = (caption, arr, colors, stackNote) => {
    const g = buildFenwickGraph(arr.slice(1));
    steps.push({
      caption,
      nodes: g.nodes,
      edges: g.edges,
      nodeColors: colors,
      stack: stackNote ? [stackNote] : [],
      queue: [],
      result: arr.slice(1),
    });
  };

  snap('Initial BIT array (1-based indices)', bit, {}, 'init');

  for (let i = 1; i <= n; i += 1) {
    let j = i;
    snap(`Point update: add ${base[i - 1]} at index ${i}`, [...bit], { [i]: 'current' }, `add@${i}`);
    while (j <= n) {
      bit[j] += base[i - 1];
      const cols = { [j]: 'visited' };
      snap(`Propagate to index ${j}, new partial sum ${bit[j]}`, [...bit], cols, `i=${j}`);
      j += lowbit(j);
    }
  }

  snap('Prefix sum query: accumulate while i>0', [...bit], { [5]: 'current' }, 'query=5');
  let i = 5;
  let acc = 0;
  const order = [];
  while (i > 0) {
    acc += bit[i];
    order.push(i);
    snap(`Include BIT[${i}] → running sum ${acc}`, [...bit], Object.fromEntries(order.map((x) => [x, 'visited'])), `sum=${acc}`);
    i -= lowbit(i);
  }

  snap('Fenwick operations complete', [...bit], {}, 'done');
  return steps;
}

export default function FenwickTreeVisualizer({ config }) {
  const base = [2, 1, 4, 3, 5, 6, 2, 1];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(base);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Fenwick tree point update + prefix query' });
    canvasRef.current?.setState({
      nodes: [],
      edges: [],
      edgeLabels: [],
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Binary Indexed Tree',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      edgeLabels: step.edgeLabels || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
