# SQL Foundation — Problem List

> **20 problems in progressive difficulty. 8 MUST-DO problems highlighted. Focus: DDL/DML basics, schema understanding, simple SELECT.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Recyclable and Low Fat Products | Easy | 1757 | Basic SELECT + WHERE | Purest SELECT filter — foundation |
| 2 | Find Customer Referee | Easy | 584 | NULL handling | Tests NULL != value trap |
| 3 | Big Countries | Easy | 595 | OR conditions | Simple multi-condition filter |
| 4 | Article Views I | Easy | 1148 | Self-equality, DISTINCT | Author viewed own article |
| 5 | Invalid Tweets | Easy | 1683 | String function + WHERE | LENGTH/CHAR_LENGTH usage |
| 6 | Customers Who Never Order | Easy | 183 | LEFT JOIN / NOT IN | First anti-join pattern |
| 7 | Delete Duplicate Emails | Easy | 196 | DELETE + self-reference | DML: delete with subquery/join |
| 8 | Fix Names in a Table | Easy | 1667 | String manipulation | CONCAT, UPPER, LOWER, SUBSTRING |

---

## Complete 20-Problem Progression

### Easy — Pure SELECT & Filtering (Problems 1-10)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Recyclable and Low Fat Products | 1757 | WHERE + AND | Filter on two columns |
| 2 | Find Customer Referee | 584 | NULL in WHERE | `!= 2` misses NULL → use `IS NULL OR` |
| 3 | Big Countries | 595 | OR condition | area >= 3M OR population >= 25M |
| 4 | Article Views I | 1148 | DISTINCT | author_id = viewer_id |
| 5 | Invalid Tweets | 1683 | String length | CHAR_LENGTH(content) > 15 |
| 6 | Customers Who Never Order | 183 | Anti-join | LEFT JOIN … IS NULL or NOT IN |
| 7 | Calculate Special Bonus | 1873 | CASE WHEN + MOD | Conditional column logic |
| 8 | Swap Salary | 627 | UPDATE + CASE | DML: in-place swap m↔f |
| 9 | Delete Duplicate Emails | 196 | DELETE + self-join | Keep min(id) per email |
| 10 | Fix Names in a Table | 1667 | String functions | UPPER + LOWER + SUBSTRING |

### Easy-Medium — Schema Awareness (Problems 11-20)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Combine Two Tables | 175 | LEFT JOIN basics | Optional FK relationship |
| 12 | Employees Earning More Than Their Managers | 181 | Self-join | Compare rows in same table |
| 13 | Duplicate Emails | 182 | GROUP BY + HAVING | Find duplicates |
| 14 | Rearrange Products Table | 1795 | UNION / UNPIVOT | Reshape wide → long |
| 15 | Patients With a Condition | 1527 | LIKE pattern | Match prefix in space-separated string |
| 16 | Employee Bonus | 577 | LEFT JOIN + NULL filter | Bonus IS NULL OR < 1000 |
| 17 | Customer Who Visited but Did Not Make Any Transaction | 1581 | LEFT JOIN + COUNT | Anti-join with aggregation |
| 18 | Rising Temperature | 197 | Self-join on date | DATE arithmetic, DATEDIFF |
| 19 | Primary Department for Each Employee | 1789 | CASE + subquery | Handle single vs multiple depts |
| 20 | Group Sold Products By The Date | 1484 | GROUP_CONCAT / STRING_AGG | Aggregate strings |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Find Customer Referee (LC 584)
```
Type: NULL handling
Key: WHERE referee_id != 2 misses NULL rows
Fix: WHERE referee_id != 2 OR referee_id IS NULL
One-liner: NULL != anything is UNKNOWN, not TRUE — explicitly include IS NULL.
```

### Problem 6: Customers Who Never Order (LC 183)
```
Type: Anti-join
Approach 1: LEFT JOIN orders ON … WHERE orders.id IS NULL
Approach 2: WHERE id NOT IN (SELECT customer_id FROM orders)
One-liner: First taste of "find missing" pattern — foundation for harder anti-joins.
```

### Problem 9: Delete Duplicate Emails (LC 196)
```
Type: DML (DELETE)
Key: DELETE p1 FROM Person p1, Person p2 WHERE p1.email = p2.email AND p1.id > p2.id
One-liner: Self-join to find duplicates, keep smallest id.
```

### Problem 12: Employees Earning More Than Managers (LC 181)
```
Type: Self-join
Key: JOIN Employee m ON e.managerId = m.id WHERE e.salary > m.salary
One-liner: Self-join = same table twice with different aliases.
```

---

## Pattern Distribution

```
BASIC SELECT + WHERE:   5 problems  (1, 3, 4, 5, 7)
NULL HANDLING:          3 problems  (2, 6, 16)
STRING FUNCTIONS:       3 problems  (5, 10, 15)
SELF-JOIN:              2 problems  (12, 18)
DML (UPDATE/DELETE):    2 problems  (8, 9)
GROUP BY INTRO:         3 problems  (13, 17, 20)
JOIN INTRO:             2 problems  (11, 16)
```

---

## Weekly Study Plan

### Day 1-2: Pure SELECT
- Problems 1-5 (WHERE, NULL, DISTINCT, string)

### Day 3-4: Anti-Join & DML
- Problems 6-10 (LEFT JOIN intro, UPDATE, DELETE, strings)

### Day 5-6: Schema + Joins
- Problems 11-15 (LEFT JOIN, self-join, GROUP BY intro)

### Day 7: Wrap-up
- Problems 16-20 (mixed patterns)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (all Easy / Easy-Medium)
MUST-DO:            LC 1757, 584, 595, 1148, 1683, 183, 196, 1667
TOP 3 MOST ASKED:   LC 584 (NULL trap), LC 183 (anti-join), LC 196 (delete dup)
PATTERN SPLIT:      SELECT/WHERE (5), NULL (3), String (3), Self-Join (2),
                    DML (2), GROUP BY intro (3), JOIN intro (2)
STUDY ORDER:        WHERE → NULL → Anti-Join → DML → Self-Join
INTERVIEW LINE:     "I handle NULLs explicitly with IS NULL/IS NOT NULL,
                     and I know DELETE with self-join for dedup."
```

---

## 30-SECOND REVISION BOX

```
NULL TRAP:      LC 584 — != misses NULL, always add IS NULL check
ANTI-JOIN:      LC 183 — LEFT JOIN … WHERE id IS NULL
DELETE DEDUP:   LC 196 — self-join, keep MIN(id)
SELF-JOIN:      LC 181 — employee vs manager salary
STRING:         LC 1667 — CONCAT(UPPER(LEFT()), LOWER(SUBSTRING()))
```
