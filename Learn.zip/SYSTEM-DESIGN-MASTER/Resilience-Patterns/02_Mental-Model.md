# Resilience Patterns — Mental Model

> **Permanent Recall:** Circuit breaker = electrical fuse (trip when overloaded). Rate limiting = water dam with gates (control flow). Bulkhead = ship compartments (isolate flooding). Core mindset: **assume everything will fail**. Apply **defense in depth**—multiple layers of protection. Use decision flowchart to pick the right pattern for your scenario.

---

## Electrical Fuse Analogy — Circuit Breaker

```
         ELECTRICAL FUSE = CIRCUIT BREAKER
        
    Normal load:  [===fuse===]  →  current flows
    Overload:     [===POP!===]  →  fuse blows, stops flow
    Replace:      new fuse      →  try again (Half-Open)
    
    Don't keep pushing current (requests) through a blown circuit (failing service).
    Fail fast, protect the grid (your system).
```

**Mapping:**
| Electrical | System Design |
|------------|---------------|
| Fuse | Circuit breaker |
| Overload | Too many failures |
| Fuse blows | Circuit opens |
| Replace fuse | Half-Open test |
| Protect wiring | Protect your service |

> **FAANG Tip:** "Circuit breaker is like a fuse—when the downstream service is overloaded, we stop sending requests instead of making it worse."

---

## Water Dam with Gates — Rate Limiting

```
         RATE LIMITER = WATER DAM
        
    [Reservoir]  →  [Gate: N gal/sec]  →  [Downstream]
         ↑                  │
    Incoming requests       Controlled release
    (unbounded)             (fixed rate)
    
    Too much water? Queue or spill (reject).
    Burst? Open gate wider temporarily (token bucket).
```

**Mapping:**
| Dam | Rate Limiter |
|-----|---------------|
| Reservoir | Request queue / token bucket |
| Gate | Limit per second |
| Spillway | 429 Too Many Requests |
| Controlled release | Smooth throughput |

---

## Ship Compartments — Bulkhead

```
         BULKHEAD = SHIP COMPARTMENTS
        
    [Compartment A]  |  [Compartment B]  |  [Compartment C]
    Payment API      |  Search API       |  Recommendation API
         │           |        │          |        │
    Hole (failure)?  |  Others stay dry  |  Isolated damage
    Flood contained  |  (isolated)       |
```

**Key insight:** One compartment floods; others stay afloat. One dependency fails; others keep serving.

---

## Core Resilience Mindset

**Assume everything will fail.**

```
MINDSET SHIFT:
  Wrong:  "Our DB has 99.99% uptime, we're fine."
  Right:  "When the DB fails (it will), what happens?"
  
  Wrong:  "Retries will fix transient errors."
  Right:  "Retries can cause retry storms. Add backoff, idempotency, circuit breaker."
```

---

## Defense in Depth

Multiple layers of protection—don't rely on one pattern.

```
DEFENSE IN DEPTH STACK:

  Client
    │
    ▼  [1. Rate Limit]     ← Throttle abusive clients
    │
    ▼  [2. Timeout]        ← Don't wait forever
    │
    ▼  [3. Circuit Breaker]← Fail fast if dependency down
    │
    ▼  [4. Retry + Backoff]← Transient errors only
    │
    ▼  [5. Bulkhead]       ← Isolate thread pools
    │
    ▼  [6. Graceful Degradation] ← Fallback when all else fails
    │
  Dependency
```

> **FAANG Tip:** "Resilience isn't one pattern—it's layering rate limit, timeout, circuit breaker, retry, bulkhead, and degradation."

---

## When to Apply Which Pattern

| Scenario | Primary Pattern | Why |
|----------|-----------------|-----|
| API abuse, DDoS risk | Rate limiting | Control incoming load |
| Dependency frequently fails | Circuit breaker | Fail fast, avoid cascade |
| Multiple downstream services | Bulkhead | Isolate per service |
| Transient network glitches | Retry + backoff | Temporary failures |
| Slow/unresponsive dependency | Timeout | Don't block forever |
| Payment, order creation | Idempotency | Safe retries |
| High load, need to survive | Graceful degradation | Reduced but working |
| Validate resilience | Chaos engineering | Prove it works |
| Producer > consumer speed | Backpressure | Prevent overflow |

---

## Decision Flowchart

```mermaid
flowchart TD
    A[Protecting from external overload?] -->|Yes| B[Rate Limiting]
    A -->|No| C[Internal dependency failure?]
    C -->|Yes| D[Circuit Breaker]
    C -->|No| E[Multiple downstream services?]
    E -->|Yes| F[Bulkhead]
    E -->|No| G[Transient errors expected?]
    G -->|Yes| H[Retry + Backoff]
    G -->|No| I[Writes / payments?]
    I -->|Yes| J[Idempotency]
    I -->|No| K[Need fallback when down?]
    K -->|Yes| L[Graceful Degradation]
    K -->|No| M[Producer too fast?]
    M -->|Yes| N[Backpressure]
    M -->|No| O[Apply defense in depth]
```

```
QUICK DECISION:
  External abuse?     → Rate limit
  Dependency down?   → Circuit breaker
  Many dependencies? → Bulkhead
  Glitches?          → Retry + backoff
  Writes?            → Idempotency
  Survive overload?  → Graceful degradation + backpressure
```

---

## 30-SECOND REVISION BOX

```
FUSE = circuit breaker (trip, don't hammer)
DAM = rate limit (control flow)
BULKHEAD = ship compartments (isolate)
MINDSET = assume failure
DEFENSE IN DEPTH = layer multiple patterns
DECISION: abuse→rate limit; dep failure→circuit; many deps→bulkhead
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
