/*
 * MemberRow — one row in the People tab.
 * Owners can change role / remove; everyone else sees a read-only chip.
 */

function initialsFor(name, email) {
  const src = (name || email || '?').trim();
  if (!src) return '?';
  const parts = src.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return src.slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export default function MemberRow({ member, canManage, onRoleChange, onRemove }) {
  const p = member.profile || {};
  const name = p.display_name || p.email || '(unknown)';
  const email = p.email || '';
  const avatar = p.avatar_url;
  const isOwnerRow = member.role === 'owner';

  return (
    <div className="sd-member">
      <span className="sd-avatar">
        {avatar
          ? <img src={avatar} alt="" referrerPolicy="no-referrer" />
          : <span className="sd-avatar__initials">{initialsFor(name, email)}</span>}
      </span>
      <div className="sd-member__id">
        <span className="sd-member__name">{name}</span>
        <span className="sd-member__email">{email}</span>
      </div>
      {canManage && !isOwnerRow ? (
        <select
          className="sd-role-select"
          value={member.role}
          onChange={(e) => onRoleChange(e.target.value)}
        >
          <option value="viewer">Viewer</option>
          <option value="editor">Editor</option>
        </select>
      ) : (
        <span className="sd-role-pill">{member.role}</span>
      )}
      {canManage && !isOwnerRow && (
        <button className="sd-link-btn sd-link-btn--danger" onClick={onRemove} title="Remove member">
          Remove
        </button>
      )}
    </div>
  );
}
