# Trie — Common Mistakes (Python + C++ + Rust)

> **Every mistake here has been made in real FAANG interviews. Organized by pattern AND by language.**

---

## Pattern Mistakes (All Languages)

### Mistake 1: Not Marking End-of-Word

```
WRONG:  Only create path, no is_end flag
        "car" and "card" both return true for search("car")

RIGHT:  node.is_end = true at end of insert
        search() must check node.is_end at final node
```

**Impact:** "car" would match "card"; "app" would match "apple".

---

### Mistake 2: Checking is_end in startsWith

```
WRONG:  def startsWith(prefix):
            ...
            return node.is_end   # Only true if prefix is exact word!

RIGHT:  return True   # Prefix exists if we reached the node
```

**startsWith("app")** should be true even if "app" isn't a full word (e.g., "apple" exists).

---

### Mistake 3: Off-by-One in Wildcard DFS

```
WRONG:  if i == len(word): return True   # Forgot to check is_end for exact match
RIGHT:  if i == len(word): return node.is_end
```

---

### Mistake 4: Not Handling Empty String

```
WRONG:  insert("")  → no loop, root.is_end never set
        search("")  → returns false (root.is_end is false)

RIGHT:  if not word: root.is_end = True; return
        Or: define empty string as valid/invalid per problem
```

---

### Mistake 5: Word Break — Checking Wrong DP Index

```
WRONG:  if node.is_end: dp[j] = True   # j is 0-indexed end
RIGHT:  if node.is_end: dp[j + 1] = True   # dp[i] = can form s[0:i), so j+1
```

---

## C++ Specific Mistakes

### C++ Mistake 1: Memory Leaks (No Destructor)

```cpp
// WRONG: Trie nodes never freed
class Trie {
    TrieNode* root;
public:
    Trie() { root = new TrieNode(); }
    // No destructor! Every insert allocates, never freed
};

// FIX: Add destructor, recursive delete
~Trie() {
    function<void(TrieNode*)> del = [&](TrieNode* n) {
        for (auto& [c, child] : n->children) del(child);
        delete n;
    };
    del(root);
}
```

---

### C++ Mistake 2: Using map Instead of unordered_map

```cpp
// SLOW: map is O(log n) per operation
map<char, TrieNode*> children;

// FAST: unordered_map is O(1) average
unordered_map<char, TrieNode*> children;
```

---

### C++ Mistake 3: Array Index Out of Bounds (a-z)

```cpp
// WRONG: No bounds check
int i = c - 'a';   // Fails for uppercase, digits, space
node->children[i] = ...;

// FIX: Validate or normalize
if (c < 'a' || c > 'z') return false;
int i = c - 'a';
```

---

### C++ Mistake 4: Iterator Invalidation in DFS

```cpp
// WRONG: Modifying children while iterating
for (auto it = node->children.begin(); it != node->children.end(); ++it) {
    dfs(it->second);  // If dfs modifies node->children, iterator invalidated
}

// FIX: Iterate over copy of keys or use range-for carefully
for (auto& [c, child] : node->children) {
    dfs(child);  // Don't modify node->children inside dfs
}
```

---

### C++ Mistake 5: Pass-by-Value for Strings

```cpp
// WRONG: Copies string every call
bool search(string word) { ... }

// RIGHT: Pass by const reference
bool search(const string& word) { ... }
```

---

## Rust Specific Mistakes

### Rust Mistake 1: Ownership of Recursive Trie

```rust
// WRONG: Moving node into recursive call
fn search(&self, word: &str) -> bool {
    fn go(node: Box<TrieNode>, ...) -> bool { ... }  // Consumes node!
    go(self.root, ...)  // Can't use self.root again
}

// FIX: Use references
fn search(&self, word: &str) -> bool {
    fn go(node: &TrieNode, ...) -> bool { ... }
    go(self.root.as_ref(), ...)
}
```

---

### Rust Mistake 2: Borrow Checker — Mutating While Iterating

```rust
// WRONG: Can't borrow node mutably for insert while holding ref
let mut node = &mut self.root;
for c in word.chars() {
    node = node.children.entry(c).or_insert_with(...);
    // node is &mut Box<TrieNode>, need to get &mut TrieNode
}

// FIX: Use .as_mut() or entry API correctly
node = node.children.entry(c).or_insert_with(|| Box::new(TrieNode::new()));
// entry() returns Entry, or_insert_with gives &mut Box<TrieNode>
```

---

### Rust Mistake 3: String vs &str in API

```rust
// INCONSISTENT: Some methods take String, others &str
fn insert(&mut self, word: String) { ... }
fn search(&self, word: &str) -> bool { ... }  // &str is more flexible

// BETTER: Use &str for read-only to avoid unnecessary allocation
fn insert(&mut self, word: &str) {
    for c in word.chars() { ... }
}
```

---

### Rust Mistake 4: Forgetting .chars() for Unicode

```rust
// WRONG: s.bytes() for multi-byte chars
for b in word.bytes() { ... }  // " café" breaks (é is 2 bytes)

// RIGHT: Use .chars() for proper character handling
for c in word.chars() { ... }
```

---

### Rust Mistake 5: Box vs Rc for Shared Children

```rust
// Trie: Each child has single parent → Box is correct
children: HashMap<char, Box<TrieNode>>

// WRONG: Rc when no sharing needed (adds ref-count overhead)
children: HashMap<char, Rc<TrieNode>>
```

---

## Python Specific Mistakes

### Python Mistake 1: Using dict Instead of defaultdict

```python
# WRONG: KeyError when accessing missing char
self.children = {}
node = node.children[ch]  # KeyError if ch not in children

# RIGHT: defaultdict auto-creates
from collections import defaultdict
self.children = defaultdict(TrieNode)
node = node.children[ch]  # Auto-creates TrieNode
```

---

### Python Mistake 2: Mutable Default Argument

```python
# WRONG: Shared across instances!
class TrieNode:
    def __init__(self, children={}):  # BUG: mutable default
        self.children = children

# RIGHT:
def __init__(self):
    self.children = defaultdict(TrieNode)
```

---

### Python Mistake 3: Modifying During Iteration

```python
# WRONG: Modifying dict while iterating
for ch in node.children:
    if condition:
        del node.children[ch]  # RuntimeError

# FIX: Iterate over list of keys
for ch in list(node.children.keys()):
    if condition:
        del node.children[ch]
```

---

### Python Mistake 4: Not Using .get() for Optional Child

```python
# VERBOSE:
if ch in node.children:
    node = node.children[ch]
else:
    return False

# CLEANER (same logic):
node = node.children.get(ch)
if node is None:
    return False
```

---

### Python Mistake 5: Assuming ASCII for Index

```python
# WRONG: ord(c) - ord('a') for Unicode
i = ord(c) - ord('a')  # Fails for 'é', '中'

# RIGHT: Use dict/HashMap for Unicode, or validate
if not c.isascii() or not c.islower():
    return False
```

---

## Mistake Summary Table

| # | Mistake | Language | Impact |
|---|---------|----------|--------|
| 1 | No is_end | All | "car" matches "card" |
| 2 | startsWith checks is_end | All | Wrong for prefixes |
| 3 | Memory leak | C++ | Resource leak |
| 4 | map vs unordered_map | C++ | TLE |
| 5 | Ownership in recursion | Rust | Compile error |
| 6 | Borrow conflict | Rust | Compile error |
| 7 | dict vs defaultdict | Python | KeyError |
| 8 | Mutable default | Python | Shared state bug |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN:    is_end required | startsWith ignores is_end | empty string
C++:        Destructor for nodes | unordered_map | const string& | bounds check
RUST:       &TrieNode not Box in recursion | .chars() | &str over String
PYTHON:    defaultdict(TrieNode) | no mutable default | list(d.keys()) for safe del
INTERVIEW:  "I'll mark end-of-word and ensure startsWith doesn't require it."
```

---

## 30-SECOND REVISION BOX

```
ALL:     is_end at insert | startsWith returns true (no is_end check)
C++:     ~Trie() delete | unordered_map | const string&
RUST:    &node in DFS | .chars() | entry().or_insert_with()
PYTHON:  defaultdict(TrieNode) | list(.keys()) before del
```
