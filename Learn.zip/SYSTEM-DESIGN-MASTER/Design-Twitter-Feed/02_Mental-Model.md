# Design Twitter/X Feed — Mental Model

> **Permanent Recall:** The core challenge is the **fan-out problem**: when a user with 10M followers posts, how do you deliver that tweet to 10M timelines? The KEY design decision: **fan-out on write** vs **fan-out on read** vs **hybrid**. Hybrid wins: push for normal users, pull on-demand for celebrities. Think "newspaper delivery" (write) vs "newsstand" (read).

---

## The Fan-Out Problem

```
    USER A (10M followers) posts 1 tweet
    →
    How do 10M users see it in their home timeline?
```

Two extremes:

| Approach | When tweet posted | When user loads feed |
|----------|-------------------|----------------------|
| **Fan-out on write** | Push tweet to 10M timeline caches | Read from cache (fast) |
| **Fan-out on read** | Store tweet once | Query 10M users' followees, merge (slow) |

---

## Fan-Out on Write (Push Model)

```
    POST:  Tweet → Fan-out Service → Write to 10M timeline caches
    READ:  User → Read own timeline from cache (O(1))
```

**Pros:** Blazingly fast reads; timeline pre-computed.
**Cons:** Celebrity with 10M followers → 10M writes on one post. Write storm, latency spike, storage explosion.

---

## Fan-Out on Read (Pull Model)

```
    POST:  Tweet → Store once in DB
    READ:  User → Query all followees → Merge recent tweets → Return
```

**Pros:** Writes scale (1 write per tweet). No fan-out storm.
**Cons:** Slow reads. User with 500 followees → 500 queries + merge. Doesn't scale at 2.8M read QPS.

---

## Hybrid Approach (The Winning Answer)

| User type | Strategy | Rationale |
|-----------|----------|-----------|
| **Normal users** (<10K followers) | Fan-out on write | Push to followers' caches; cheap, fast |
| **Celebrities** (>10K or 100K followers) | Fan-out on read | Pull on demand when user loads feed; avoid write storm |
| **Mid-tier** | Configurable threshold | Tune based on cost/performance |

> **FAANG Tip:** "We use a hybrid. Push for 99% of users. For the top 0.1% with millions of followers, we pull on read—they're <1% of users but cause >50% of fan-out cost."

---

## "Newspaper Delivery" Analogy

| Model | Analogy |
|-------|---------|
| **Fan-out on write** | Newspaper delivered to every doorstep when printed |
| **Fan-out on read** | Everyone goes to the newsstand to pick up a copy |

Hybrid: Deliver to homes for most; for celebrity "editions," newsstand pickup (pull).

---

## Decomposing the System

```
    ┌─────────────────┐
    │  Tweet Storage  │  ← Where tweets live (DB, sharded by user_id)
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ Fan-out Service │  ← Decides push vs pull; pushes to Redis
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │Timeline Service │  ← Serves feed; merges cache + celebrity pull
    └────────┬────────┘
             │
    ┌────────▼────────┐
    │ Timeline Cache  │  ← Redis sorted sets per user (user_id → tweet_ids)
    └─────────────────┘

    Media:  S3 + CDN
    Search: Elasticsearch
    Trending: Stream processing (Kafka + Flink/Spark)
```

---

## Key Mental Models

| Component | Mental model |
|-----------|--------------|
| **Tweet storage** | Append-only; shard by `user_id`; tweets are immutable (edit = new) |
| **Fan-out service** | Async worker; reads followers, writes to Redis; skips if celebrity |
| **Timeline cache** | Redis sorted set: `timeline:{user_id}` → `(tweet_id, timestamp)` |
| **Celebrity feed** | On read: fetch from celebrity's recent tweets, merge with cached timeline |
| **Media** | Upload → S3 → CDN URL in tweet; never serve from origin |

---

## 30-SECOND REVISION BOX

```
FAN-OUT: Core problem — 10M followers, 1 tweet = 10M deliveries?
PUSH: Fast read, slow/write storm for celebrities
PULL: Fast write, slow read for many followees
HYBRID: Push for normals, pull for celebrities (<1% users, >50% cost)
ANALOGY: Write = newspaper to door; Read = newsstand
DECOMPOSE: Tweet storage → Fan-out → Timeline → Cache; Media S3; Search ES
```

---

**Next: [[03_Design-Template]]**
