# Top-N per Group

Select the top N rows within each group — like "top 3 highest-paid employees per department" or "most recent order per customer." This combines window functions with filtering.

**DSA Analogy**: Priority queue per bucket — you have K buckets, and within each bucket you maintain a min-heap/max-heap of size N, keeping only the top N elements.

---

## Core Idea (2 Lines)

Use `ROW_NUMBER()` (or `RANK` / `DENSE_RANK`) partitioned by the group column and ordered by the ranking column. Then filter in an outer query where the row number <= N. This is the most-asked SQL interview pattern.

---

## The Standard Template

```sql
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY group_col
               ORDER BY rank_col DESC
           ) AS rn
    FROM table_name
)
SELECT *
FROM ranked
WHERE rn <= N;
```

**Step by step:**

```
Step 1:  PARTITION BY dept → separate groups per department
Step 2:  ORDER BY salary DESC → rank within each group
Step 3:  ROW_NUMBER() → assign 1, 2, 3... per group
Step 4:  Filter rn <= 3 → keep top 3 per group

  Engineering:                    Sales:
  rn=1  Alice  120000  ✓         rn=1  Frank   95000  ✓
  rn=2  Bob    100000  ✓         rn=2  Grace   90000  ✓
  rn=3  Charlie 95000  ✓         rn=3  Helen   85000  ✓
  rn=4  Diana   80000  ✗         rn=4  Ivan    75000  ✗
```

---

## ROW_NUMBER vs RANK vs DENSE_RANK for Top-N

| Function | Ties Handling | Example (salaries: 120k, 100k, 100k, 80k) | Use When |
|----------|-------------|------|----------|
| `ROW_NUMBER` | Always unique (arbitrary tiebreak) | 1, 2, 3, 4 | "Give me exactly N rows per group" |
| `RANK` | Ties share rank, gaps after | 1, 2, 2, 4 | "Top N, but include all ties (may get >N rows)" |
| `DENSE_RANK` | Ties share rank, no gaps | 1, 2, 2, 3 | "Top N distinct values, include all with those values" |

**Interview insight**: The problem statement dictates which to use:
- "Top 3 employees" → ROW_NUMBER (exactly 3)
- "Top 3 salaries" → DENSE_RANK (all employees at those salary levels)

---

## Example: Department Top 3 Salaries (LC 185)

```sql
WITH ranked AS (
    SELECT d.name AS department,
           e.name AS employee,
           e.salary,
           DENSE_RANK() OVER (
               PARTITION BY e.departmentId
               ORDER BY e.salary DESC
           ) AS drnk
    FROM employee e
    JOIN department d ON e.departmentId = d.id
)
SELECT department, employee, salary
FROM ranked
WHERE drnk <= 3;
```

Why DENSE_RANK? Because "top 3 salaries" means top 3 distinct salary values — if two people earn the same, both should be included.

---

## Alternative Approaches (Without Window Functions)

### Approach 1: Correlated Subquery

```sql
-- Top 3 salaries per department (older SQL style)
SELECT e.name, e.dept, e.salary
FROM employees e
WHERE (
    SELECT COUNT(DISTINCT e2.salary)
    FROM employees e2
    WHERE e2.dept = e.dept AND e2.salary > e.salary
) < 3;
```

"Count how many distinct salaries are higher than mine in my dept. If < 3, I'm in the top 3."

### Approach 2: LATERAL JOIN (PostgreSQL)

```sql
SELECT d.dept, e.*
FROM departments d
CROSS JOIN LATERAL (
    SELECT name, salary
    FROM employees
    WHERE dept = d.dept
    ORDER BY salary DESC
    LIMIT 3
) e;
```

### Comparison

| Approach | Portability | Performance | Readability |
|----------|-------------|-------------|-------------|
| ROW_NUMBER + CTE | All databases | Best (single scan) | Best |
| Correlated subquery | All databases | O(N × M) — slowest | Medium |
| LATERAL JOIN | PostgreSQL, MySQL 8+ | Good | Good |

---

## Top-1 Per Group (Most Recent / Latest)

Special case of Top-N where N=1 — very common for "latest record per user."

```sql
-- Most recent order per customer
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY customer_id
               ORDER BY order_date DESC
           ) AS rn
    FROM orders
)
SELECT * FROM ranked WHERE rn = 1;
```

**PostgreSQL shortcut: DISTINCT ON**

```sql
SELECT DISTINCT ON (customer_id) *
FROM orders
ORDER BY customer_id, order_date DESC;
```

---

## Top-N with Additional Conditions

```sql
-- Top 2 most expensive orders per customer, but only completed orders
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY customer_id
               ORDER BY amount DESC
           ) AS rn
    FROM orders
    WHERE status = 'completed'        -- filter BEFORE ranking
)
SELECT * FROM ranked WHERE rn <= 2;
```

**Filter placement matters:**
- `WHERE` before CTE → filter rows before ranking
- `WHERE` after CTE → filter rows after ranking (affects which rows get which rank)

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Using window function in WHERE | Window functions execute after WHERE | Wrap in CTE/subquery, filter in outer query |
| ROW_NUMBER for "top N distinct values" | Arbitrary tiebreak — might miss tied values | Use DENSE_RANK for distinct value ranking |
| DENSE_RANK for "exactly N rows" | Ties may return more than N rows | Use ROW_NUMBER for exact count |
| Not handling ties deterministically | ROW_NUMBER assigns arbitrary order to ties | Add secondary ORDER BY column |
| Missing PARTITION BY | Ranks across entire table, not per group | Add PARTITION BY group_column |

---

## Key Takeaway

> Top-N per Group is the most commonly asked SQL interview pattern. The template is always: ROW_NUMBER/RANK/DENSE_RANK in a CTE with PARTITION BY group and ORDER BY rank column, then filter rn <= N in the outer query. Use ROW_NUMBER for "exactly N rows," DENSE_RANK for "top N distinct values."
