# Design Distributed Cache — Common Mistakes

> **Permanent Recall:** Top mistakes: using **modulo hashing** instead of consistent hashing, single node with no HA, no eviction policy, ignoring cache coherence, conflating persistence with pure cache, and ignoring the **hot key problem**. Each is interview poison.

---

## 1. Modulo Hashing Instead of Consistent Hashing

**Mistake:** `node = hash(key) % N`

**Problem:** When N changes (node added/removed), almost all keys must move. With 10 nodes and 1 failure, ~90% of keys rehash. Cascading load, potential outage.

**Correct:** Consistent hashing with virtual nodes. Only K/N keys move (K = keys on failed node).

---

## 2. Single Node — No High Availability

**Mistake:** Design stops at one cache node.

**Problem:** Node failure = total cache loss; all traffic hits DB; thundering herd.

**Correct:** Primary-replica replication. Replica promoted on failure. Clients get updated topology.

---

## 3. No Eviction Policy

**Mistake:** "We'll just add more memory" or "We'll figure it out later."

**Problem:** Memory is finite. Without eviction, OOM crash.

**Correct:** LRU (hash map + doubly-linked list, O(1)), LFU, or TTL-based. State policy explicitly.

---

## 4. Ignoring Cache Coherence / Invalidation

**Mistake:** Cache never invalidated when source data changes.

**Problem:** Stale data served indefinitely.

**Correct:** TTL, write-through (update cache on DB write), cache-aside invalidation (delete on write), or pub/sub invalidation. State the strategy.

---

## 5. Persistence vs Pure Cache Confusion

**Mistake:** Assuming cache must always persist, or never mentioning it.

**Problem:** Cache and durable store have different trade-offs. Persistence adds complexity (RDB, AOF, fsync).

**Correct:** Clarify use case. Pure cache = no persistence, recompute from DB. Cache-as-datastore = RDB/AOF.

---

## 6. Hot Key Problem Ignored

**Mistake:** One key (e.g., celebrity profile) gets 90% of traffic; one node overloaded.

**Problem:** Consistent hashing sends all requests for that key to one node; bottleneck.

**Correct:** Replication (multiple replicas for hot shard), local cache in front, or key sharding (e.g., `user:123:0`, `user:123:1`).

---

## 7. No Virtual Nodes in Consistent Hashing

**Mistake:** One point per node on the ring.

**Problem:** Uneven distribution; some nodes get many more keys than others.

**Correct:** 100–200 virtual nodes per physical node. Smoother distribution.

---

## 8. Sync Replication by Default

**Mistake:** "We replicate synchronously for consistency."

**Problem:** Every write waits for replica ack; latency doubles or more.

**Correct:** Async replication for cache (eventual consistency acceptable). Sync only if strong consistency required (rare for cache).

---

## 9. Wrong Data Structure for Sorted Sets

**Mistake:** "We use a sorted array" or "balanced BST."

**Problem:** Array: O(n) insert. BST: fine but skip list is Redis's choice; good for range queries, simpler.

**Correct:** Skip list + hash map. O(log n) insert, O(log n + k) range query.

---

## 10. No Capacity Estimation

**Mistake:** Vague "we scale" without numbers.

**Problem:** Interviewer wants to see back-of-envelope thinking.

**Correct:** "100K ops/s per node × 100 nodes = 10M ops/s. 64GB × 100 = 6.4TB. Billions of keys."
