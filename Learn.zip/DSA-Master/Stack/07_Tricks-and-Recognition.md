# Stack — Tricks and Recognition

> **Permanent Recall:** Stack problems hide behind many phrasings. Key recognition: "next greater/smaller" → monotonic stack; "valid parentheses" → stack; "largest rectangle in histogram" → stack. This file maps problem phrases to patterns and helps choose stack vs queue vs deque.

---

## Primary Recognition Patterns

### 1. "Next Greater / Next Smaller Element" → Monotonic Stack

| Phrase | Stack Type | Scan Direction |
|--------|------------|----------------|
| Next greater element (right) | Monotonic decreasing | Left → Right |
| Next smaller element (right) | Monotonic increasing | Left → Right |
| Previous greater element (left) | Monotonic decreasing | Right → Left (or Left→Right with different logic) |
| Previous smaller element (left) | Monotonic increasing | Left → Right (standard) |

**LeetCode examples:** 496, 503, 739, 1019

---

### 2. "Valid Parentheses / Balanced Brackets" → Stack

| Phrase | Pattern |
|--------|---------|
| Valid parentheses | Push `( [ {`, pop on `) ] }` if matching |
| Valid brackets | Same |
| Generate parentheses | Often backtracking; validating uses stack |
| Longest valid parentheses | Stack for indices + matching |

**LeetCode examples:** 20, 32, 22

---

### 3. "Largest Rectangle in Histogram" → Monotonic Stack

| Phrase | Pattern |
|--------|---------|
| Largest rectangle in histogram | Find left/right boundaries (prev/next smaller) |
| Max area under histogram | Same |
| Largest rectangle in binary matrix | Row-by-row histogram + stack |

**LeetCode examples:** 84, 85

---

### 4. Hidden Stack Problems

| Problem | Why Stack |
|---------|-----------|
| **Daily Temperatures** (739) | "Days until warmer" = next greater element |
| **Remove K Digits** (402) | Maintain smallest digits — monotonic increasing stack |
| **Trapping Rain Water** (42) | Can use stack to find boundaries (or two pointers) |
| **Asteroid Collision** (735) | Simulate collisions — stack for remaining asteroids |
| **Decode String** (394) | Nested structure — stack for depth |
| **Basic Calculator** (224) | Expression + parentheses — stack |
| **Simplify Path** (71) | Path segments — stack for ".." |
| **Score of Parentheses** (856) | Nested score — stack |
| **Remove Duplicate Letters** (316) | Lexicographically smallest — monotonic stack |
| **132 Pattern** (456) | Find i<j<k with ai<ak<aj — stack for "3" |

---

## Stack vs Queue vs Deque Decision

```
                    ┌─────────────────────────────────────┐
                    │  Need LIFO (last in, first out)?    │
                    │  Process most recent first?         │
                    └─────────────────┬───────────────────┘
                                      │ YES
                                      ▼
                    ┌─────────────────────────────────────┐
                    │  Need "next greater/smaller"?       │
                    │  Monotonic order?                   │
                    └─────────────────┬───────────────────┘
                          │ YES                │ NO
                          ▼                    ▼
                    MONOTONIC STACK      SIMPLE STACK
                    (NGE, NSE,          (parentheses,
                     histogram)          expression)
                    
                    ┌─────────────────────────────────────┐
                    │  Need FIFO (first in, first out)?   │
                    │  Process oldest first?              │
                    └─────────────────┬───────────────────┘
                                      │ YES
                                      ▼
                                    QUEUE
                    
                    ┌─────────────────────────────────────┐
                    │  Need both ends? Sliding window     │
                    │  min/max in range?                  │
                    └─────────────────┬───────────────────┘
                                      │ YES
                                      ▼
                                    DEQUE
                    (monotonic deque for sliding window max/min)
```

---

## Decision Table

| Signal | Use |
|--------|-----|
| Next greater/smaller | Monotonic stack |
| Valid/match parentheses | Stack |
| Expression, calculator | Stack (operator + operand) |
| Histogram, rectangle | Monotonic stack |
| Nested structure (decode, score) | Stack |
| Remove k digits, smallest subsequence | Monotonic stack (greedy) |
| BFS, level order | Queue |
| Sliding window max/min | Deque (monotonic) |
| Palindrome check | Deque or two pointers |

---

## Monotonic Stack Variants

| Variant | When to Use |
|---------|-------------|
| **Strict decreasing** | Next greater (strictly >) |
| **Non-strict decreasing** | Next greater or equal |
| **Strict increasing** | Next smaller (strictly <) |
| **Non-strict increasing** | Next smaller or equal |
| **Store indices** | Always for NGE/NSE/histogram |
| **Store (index, value)** | When both needed; usually index enough |
| **Circular array** | Run loop 2n, use i % n |

---

## "Remove K Digits" / "Smallest Number" Trick

**Pattern:** Greedy + monotonic increasing stack.

- We want the smallest number by removing k digits.
- When we see a digit smaller than the top, the top is "bad" — remove it.
- Stack stays increasing (smallest possible left-to-right).

```
num = "1432219", k = 3
Stack: 1 → 14 → 13 (pop 4) → 12 (pop 3) → 122 → 121 (pop 2) → 1219
Remove 1 more? We have removed 3. Result: "1219"
```

---

## "Largest Rectangle" — One-Pass Trick

Instead of two passes (left boundaries, then right), do **one pass**:

```python
# When we pop, we know:
# - arr[popped] is the height
# - Right boundary = current i (next smaller to right)
# - Left boundary = new stack top (previous smaller to left)
# Width = i - stack[-1] - 1 (after pop, stack top is left boundary)
```

---

## Circular Array Trick

For "Next Greater Element II" (circular):

- Concatenate array with itself: process `arr + arr` (or loop `i in range(2*n)` with `arr[i % n]`)
- Only write result for `i < n` to avoid overwriting
- Each element gets at most one answer (first occurrence in second half)

---

## FINAL MEMORY COMPRESSION BLOCK

```
NGE/NSE:         Monotonic stack (decreasing/increasing)
PARENTHESES:     Simple stack (push open, pop on close)
HISTOGRAM:       Monotonic stack for boundaries
DAILY TEMPS:     NGE in disguise
REMOVE K DIGITS: Monotonic increasing (greedy)
STACK vs QUEUE:  LIFO vs FIFO
STORE:           Indices for NGE/NSE/histogram
CIRCULAR:        Loop 2n, use i % n
```
