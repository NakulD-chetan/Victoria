# Design Distributed Cache — Concept

> **Permanent Recall:** Design an **in-memory distributed cache** like Redis/Memcached. Core operations: GET, SET, DELETE with TTL, eviction policies (LRU/LFU), and support for rich data structures (strings, hashes, lists, sets, sorted sets). Scale: billions of keys, terabytes across cluster; sub-millisecond latency; 100K+ ops/s per node; high availability via replication.

---

## Problem Statement

Design a **distributed in-memory cache** that behaves like **Redis** or **Memcached**:
- Store key-value data in RAM for fast access
- Scale horizontally across hundreds of nodes
- Survive node failures without data loss (replication)
- Evict data when memory is full

---

## Functional Requirements

| Feature | Description |
|---------|-------------|
| **GET** | Retrieve value by key; return `null` if missing or expired |
| **SET** | Store key-value; overwrite if exists |
| **DELETE** | Remove key and value |
| **TTL** | Time-to-live: key expires after duration (e.g., 60s, 24h) |
| **Eviction** | When memory full: LRU (least recently used), LFU (least frequently used), or random |
| **Data structures** | Strings, hashes (field-value maps), lists, sets, sorted sets (score + member) |

---

## Non-Functional Requirements

| NFR | Target |
|-----|--------|
| **Latency** | Sub-millisecond (P99 < 1ms) for cache hits |
| **Throughput** | 100K+ ops/s per node; linear scaling with nodes |
| **Availability** | High availability; survive node failures without data loss |
| **Scalability** | Horizontal: add nodes to increase capacity |
| **Consistency** | Eventual consistency acceptable for cache (primary-replica async replication) |

> **FAANG Tip:** Sub-millisecond means avoiding network hops where possible; in-memory hash table lookup is O(1). The bottleneck is usually network and serialization.

---

## Capacity Estimation

### Scale

| Metric | Value |
|--------|-------|
| **Total keys** | Billions |
| **Data size** | Terabytes across cluster |
| **Per-node memory** | 64–256 GB typical |
| **Ops per node** | 100K–500K ops/s |

### Key Size Assumptions

- **Average key:** 20–50 bytes
- **Average value:** 100–500 bytes (strings); larger for hashes/lists
- **1M keys × 500 bytes ≈ 500 MB** per node (rough)

---

## Data Structures (Redis-Style)

| Type | Use Case | Implementation |
|------|----------|----------------|
| **String** | Simple KV; counters | Hash table |
| **Hash** | Object (user:123 → {name, email}) | Hash of hashes |
| **List** | Queue; timeline; recent items | Doubly-linked list or ziplist |
| **Set** | Unique members; tags | Hash table (value=1) or intset |
| **Sorted Set** | Leaderboard; range queries by score | Skip list + hash map |

---

## Out of Scope (Clarify in Interview)

- **Persistence** — Can add RDB/AOF; clarify if pure cache or cache-as-datastore
- **Pub/sub** — Separate feature; can extend
- **Transactions** — Multi-key atomicity (MULTI/EXEC)
- **Strong consistency** — Cache typically eventual; primary-replica async

---

## Assumptions (State in Interview)

- Data can be recomputed from source of truth (DB) if evicted
- Eventual consistency acceptable for replicas
- Network within datacenter (low latency, reliable)
- Single-region initially; multi-region is extension

---

## Success Criteria

- GET/SET/DELETE in sub-millisecond
- Keys distributed evenly across nodes (consistent hashing)
- Node failure causes minimal rehashing (only affected keys move)
- Eviction when full (LRU/LFU); no OOM
- Support for TTL and rich data structures
