# C++ STL Complete Reference — FAANG Interview Cheatsheet

> **The go-to reference for competitive programming & DSA interviews**

---

## 1. vector

| Operation | Syntax | Complexity |
|-----------|--------|------------|
| Create | `vector<int> v;` | O(1) |
| Create with size | `vector<int> v(n);` | O(n) |
| Create with init | `vector<int> v(n, 0);` | O(n) |
| push_back | `v.push_back(x);` | O(1) amortized |
| pop_back | `v.pop_back();` | O(1) |
| size | `v.size()` | O(1) |
| empty | `v.empty()` | O(1) |
| reserve | `v.reserve(1000);` | O(n) |
| resize | `v.resize(n, val);` | O(n) |
| clear | `v.clear();` | O(n) |

```cpp
#include <vector>
vector<int> v = {3, 1, 4, 1, 5};
v.push_back(9); v.pop_back();
cout << v.size() << " " << v.empty();  // 5 0

// 2D vector init
vector<vector<int>> grid(n, vector<int>(m, 0));
vector<vector<int>> adj(n);  // adjacency list

// Iteration
for (int x : v) cout << x;
for (auto it = v.begin(); it != v.end(); ++it) cout << *it;

// Sort with lambda (descending)
sort(v.begin(), v.end(), [](int a, int b) { return a > b; });

// Sort pairs by second element
vector<pair<int,int>> vp = {{1,3}, {2,1}, {3,2}};
sort(vp.begin(), vp.end(), [](auto& a, auto& b) { return a.second < b.second; });
```

---

## 2. string

| Operation | Syntax |
|-----------|--------|
| substr | `s.substr(pos, len)` — from pos, length len |
| find | `s.find("ab")` — returns index or `string::npos` |
| append | `s += "xyz";` or `s.append("xyz");` |
| stoi/stol | `int n = stoi("42");` `long l = stol("1234567890");` |
| to_string | `string s = to_string(42);` |
| char ops | `isdigit(c)`, `isalpha(c)`, `tolower(c)` |

```cpp
#include <string>
string s = "hello world";
string sub = s.substr(0, 5);     // "hello"
size_t pos = s.find("world");    // 6
s += "!";                        // "hello world!"
int n = stoi("42");              // 42
string num = to_string(123);     // "123"

// char to int: c - '0'
// int to char: n + '0'
char c = '5'; int d = c - '0';   // d = 5
```

---

## 3. unordered_map / map

| Operation | unordered_map | map |
|-----------|---------------|-----|
| insert | `m[key] = val;` or `m.insert({k,v});` | same |
| access | `m[key]` (creates if missing!) | same |
| count | `m.count(key)` → 0 or 1 | same |
| find | `m.find(key)` → iterator or `m.end()` | same |
| erase | `m.erase(key);` | same |
| iteration | `for (auto& [k,v] : m)` | same |

```cpp
#include <unordered_map>
#include <map>
unordered_map<int, int> freq;
freq[5]++;  // count frequency
if (freq.count(5)) { /* exists */ }
auto it = freq.find(5);
if (it != freq.end()) cout << it->second;
freq.erase(5);

// Iteration
for (auto& [key, val] : freq) cout << key << " " << val;
for (auto& p : freq) cout << p.first << " " << p.second;

// Custom hash for pair
struct HashPair {
    size_t operator()(const pair<int,int>& p) const {
        return hash<long long>()((long long)p.first << 32 | p.second);
    }
};
unordered_map<pair<int,int>, int, HashPair> mp;
```

**Performance:** `unordered_map` O(1) avg vs `map` O(log n) — use unordered for counting/lookup; map when you need sorted keys.

---

## 4. unordered_set / set

| Operation | Syntax |
|-----------|--------|
| insert | `s.insert(x);` |
| count | `s.count(x)` → 0 or 1 |
| erase | `s.erase(x);` |
| find | `s.find(x)` → iterator or `s.end()` |

```cpp
#include <unordered_set>
#include <set>
unordered_set<int> seen;
seen.insert(5);
if (seen.count(5)) { /* in set */ }
seen.erase(5);

// Iteration
for (int x : seen) cout << x;

// set: sorted, O(log n) insert/erase
set<int> s;
s.insert(3); s.insert(1);
// s = {1, 3}
```

---

## 5. priority_queue

| Type | Declaration |
|------|-------------|
| Max-heap (default) | `priority_queue<int> pq;` |
| Min-heap | `priority_queue<int, vector<int>, greater<int>> pq;` |
| Custom comparator | `priority_queue<T, vector<T>, decltype(cmp)> pq(cmp);` |
| With pairs | `priority_queue<pair<int,int>> pq;` (sorts by first, then second) |

```cpp
#include <queue>
priority_queue<int> maxHeap;
maxHeap.push(3); maxHeap.push(1); maxHeap.push(4);
cout << maxHeap.top();  // 4
maxHeap.pop();

// Min-heap
priority_queue<int, vector<int>, greater<int>> minHeap;

// Min-heap of pairs (by first element)
priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
pq.push({dist, node});

// Custom comparator (max by second)
auto cmp = [](pair<int,int> a, pair<int,int> b) { return a.second < b.second; };
priority_queue<pair<int,int>, vector<pair<int,int>>, decltype(cmp)> pq(cmp);
```

---

## 6. stack / queue / deque

```cpp
#include <stack>
#include <queue>
#include <deque>

stack<int> st;
st.push(1); st.push(2);
cout << st.top();   // 2
st.pop();

queue<int> q;
q.push(1); q.push(2);
cout << q.front();  // 1
cout << q.back();   // 2
q.pop();

deque<int> dq;
dq.push_back(1); dq.push_front(0);
dq.pop_back(); dq.pop_front();
cout << dq.front() << " " << dq.back();
```

---

## 7. pair / tuple

```cpp
#include <utility>
#include <tuple>

pair<int, string> p = {1, "hello"};
pair<int, string> p2 = make_pair(2, "world");
cout << p.first << " " << p.second;

// C++17 structured bindings
auto [a, b] = p;

// tie (unpack)
int x; string s;
tie(x, s) = p;

// tuple
tuple<int, int, int> t = {1, 2, 3};
auto [a, b, c] = t;
cout << get<0>(t) << get<1>(t);
```

---

## 8. algorithm

| Function | Usage | Complexity |
|----------|-------|------------|
| sort | `sort(beg, end)` or `sort(beg, end, cmp)` | O(n log n) |
| reverse | `reverse(beg, end)` | O(n) |
| lower_bound | first elem >= val | O(log n) |
| upper_bound | first elem > val | O(log n) |
| binary_search | returns bool | O(log n) |
| accumulate | `accumulate(beg, end, init)` | O(n) |
| max_element | `*max_element(beg, end)` | O(n) |
| min_element | `*min_element(beg, end)` | O(n) |
| next_permutation | `next_permutation(beg, end)` | O(n) |
| unique | `unique(beg, end)` — remove consecutive dupes | O(n) |

```cpp
#include <algorithm>
#include <numeric>
vector<int> v = {3, 1, 4, 1, 5};
sort(v.begin(), v.end());
reverse(v.begin(), v.end());

// Binary search on sorted vector
auto it = lower_bound(v.begin(), v.end(), 3);  // first >= 3
int idx = it - v.begin();
bool found = binary_search(v.begin(), v.end(), 4);

// Sum
int sum = accumulate(v.begin(), v.end(), 0);
int sum2 = accumulate(v.begin(), v.end(), 0LL);  // long long!

// Max/min
int mx = *max_element(v.begin(), v.end());
int mn = *min_element(v.begin(), v.end());

// Next permutation (sort first!)
sort(v.begin(), v.end());
do { /* use v */ } while (next_permutation(v.begin(), v.end()));

// Remove consecutive duplicates
sort(v.begin(), v.end());
v.erase(unique(v.begin(), v.end()), v.end());
```

---

## 9. auto keyword

```cpp
// Type deduction
auto x = 42;           // int
auto s = "hello";      // const char*
auto v = vector<int>{1,2,3};

// Range-based for
for (auto x : v) { }       // copy
for (auto& x : v) { }      // reference (modify)
for (const auto& x : v) { } // const reference (read-only, no copy)

// Iterators
for (auto it = v.begin(); it != v.end(); ++it)
    cout << *it;
```

---

## 10. Lambda

```cpp
// [capture](params) { body }
// Capture: [] none, [=] by value, [&] by ref, [x, &y] mixed

auto add = [](int a, int b) { return a + b; };

// Sort descending
sort(v.begin(), v.end(), [](int a, int b) { return a > b; });

// Sort by abs
sort(v.begin(), v.end(), [](int a, int b) { return abs(a) < abs(b); });

// Capture external variable
int threshold = 5;
auto cmp = [threshold](int a, int b) { return a < b; };
```

---

## 11. Important Gotchas

| Gotcha | Fix |
|--------|-----|
| **size_t vs int** | `v.size()` returns `size_t` (unsigned). `for (int i = 0; i < v.size() - 1; i++)` can overflow if v is empty! Use `(int)v.size()` or `i + 1 < v.size()` |
| **Iterator invalidation** | Don't modify vector/map while iterating. Use `v.erase(it)` — it invalidates it, use `it = v.erase(it)` for loops |
| **unordered_map []** | `m[key]` creates default value if missing. Use `m.count(key)` or `m.find(key)` when you don't want insertion |
| **map vs unordered_map** | unordered_map faster for random access; map for sorted iteration |
| **priority_queue top** | No iterator! Can't access elements except top. Use vector+sort if you need random access |

---

## 12. STL Complexity Cheatsheet

| Container | Insert | Erase | Access | Find |
|-----------|--------|-------|--------|------|
| vector | O(1) end, O(n) mid | O(1) end, O(n) mid | O(1) | O(n) |
| deque | O(1) ends | O(1) ends | O(1) | O(n) |
| list | O(1) | O(1) | O(n) | O(n) |
| set/map | O(log n) | O(log n) | — | O(log n) |
| unordered_set/map | O(1) avg | O(1) avg | — | O(1) avg |
| priority_queue | O(log n) | O(log n) | top only O(1) | — |
| stack/queue | O(1) | O(1) | top/front O(1) | — |

| Algorithm | Complexity |
|-----------|------------|
| sort | O(n log n) |
| lower_bound, upper_bound, binary_search | O(log n) |
| next_permutation | O(n) |
| accumulate, find, count | O(n) |
| reverse, rotate | O(n) |

---

## 30-SECOND REVISION BOX

```
VECTOR: push_back, pop_back, size, sort(v.begin(), v.end(), [](a,b){return a>b;})
STRING: substr(pos,len), find(), stoi(), to_string()
MAP: m[key]++, m.count(k), for(auto& [k,v]:m)
SET: s.insert(x), s.count(x)
PQ: max default, min: greater<int>, pq.push/pop/top
STACK/Q: push, pop, top/front, back
PAIR: make_pair, auto [a,b]=p
ALGO: sort, reverse, lower_bound, upper_bound, binary_search, accumulate, max_element
LAMBDA: [](a,b){return a<b;}
GOTCHAS: size_t overflow, m[key] creates, unordered=O(1) map=O(log n)
```
