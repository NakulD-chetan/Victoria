# Back-of-Envelope Estimation — Edge Cases

> **Permanent Recall:** Edge cases in estimation: **peak traffic** (10× average), **viral spikes**, **geographic distribution**, **time zone effects**, **replication + backups** for storage, **compression ratios**, **cold vs hot data**. Adjust your numbers when these matter—especially for FAANG-scale systems.

---

## Peak Traffic Estimation

**Rule:** Peak ≈ **10× average** for systems with bursty traffic (social, news, events).

| Scenario | Peak Factor | Example |
|----------|-------------|---------|
| Uniform (enterprise) | 2–3× | Internal tools |
| Consumer, daily cycle | 3–5× | E-commerce |
| Viral / events | 5–10× | Social, breaking news |
| Flash sale | 10–50× | Black Friday, product launch |

```
    Average QPS = Total / 86400
    Peak QPS    = Average × Peak_Factor
    Capacity    = Design for Peak, not Average
```

> **FAANG Tip:** If the problem mentions "viral" or "peak hours," use 5–10×. Always say "I'm using N× peak factor because..."

---

## Viral Content Spikes

| Event | Typical Spike |
|-------|---------------|
| Celebrity tweet | 10–100× normal for that user |
| Breaking news | 5–20× site-wide |
| Product launch | 10–50× for that product |

**Implications:** Can't scale servers for viral peak cost-effectively. Need **auto-scaling**, **queue-based** processing, or **degraded experience** (e.g., delayed fan-out).

---

## Geographic Distribution

| Distribution | Impact |
|--------------|--------|
| US-only | Single region, lower latency |
| Global | Multi-region, 150ms cross-continent |
| India-heavy | ~1.3B population, different peak hours |

**Traffic by region:** If 50% US, 30% EU, 20% APAC → peak may not align; consider **regional peaks** for capacity.

---

## Time Zone Effects on Traffic

```
    GLOBAL TRAFFIC (simplified)

    EST    PST    GMT    IST
    9am    6am    2pm    7:30pm   ← Overlapping peak
```

- **Single timezone:** Clear peak (e.g., 8–10 PM local).
- **Global:** Peaks flatten; average closer to peak. Use 2–3× instead of 10× for fully global systems.

---

## Storage with Replication and Backups

| Factor | Typical Value | When to Use |
|--------|---------------|-------------|
| Replication | 3× | Standard durability |
| Backups | 1–2× | Snapshot + incremental |
| Cross-region DR | 2× | Multi-region copy |
| **Total** | **6–10× raw** | Full durability + DR |

**Formula:** `Total = Raw × Replication × (1 + Backup_overhead)`

---

## Compression Ratios

| Data Type | Ratio | Example |
|-----------|-------|---------|
| Text (tweets, logs) | 2–5× | 1KB → 200–500 bytes |
| JSON | 2–3× | Structured, repetitive |
| Video | 10–100× | Codec dependent |
| Already compressed | 1× | Don't double-count |

**Use:** For cold/long-term storage, divide by compression ratio. For active data, often uncompressed for speed.

---

## Cold vs Hot Data

| Tier | Access Pattern | Cost | Example |
|------|----------------|------|---------|
| Hot | Frequent, low latency | High (SSD, RAM) | Recent tweets, active sessions |
| Warm | Occasional | Medium | 30-day feed |
| Cold | Rare, archive | Low (HDD, S3 Glacier) | 5-year-old logs |

**Estimation impact:** Total storage ≠ active storage. Design for hot tier size + cold tier size separately.

---

## Combined Edge Case Example

**Problem:** Estimate storage for 1B tweets/day, 5 years, global, with DR.

| Factor | Calculation |
|--------|-------------|
| Raw | 1B × 365 × 5 × 300 bytes = 548 TB |
| Replication | 3× = 1.6 PB |
| Backup | +50% = 2.4 PB |
| Compression (cold) | 2× for archive = 1.2 PB active, 0.6 PB cold |
| **Ballpark** | **~2 PB total** |

---

## Multi-Tenant and Isolation

When estimating for **SaaS** or **multi-tenant** systems:

| Factor | Impact |
|--------|--------|
| Tenant count | Storage × tenants if isolated |
| Shared vs isolated | Shared = lower total; isolated = per-tenant overhead |
| Bursty tenants | Peak = sum of tenant peaks (worst) or pooled (best) |

---

## Idempotency and Retries

| Scenario | Impact on QPS |
|----------|---------------|
| Client retries | Effective QPS may be 1.2–1.5× raw |
| Duplicate requests | Same |
| **Fix** | Design for 20–50% overhead on writes |

---

## 30-SECOND REVISION BOX

```
PEAK: 10× average for viral; 2–3× for global
VIRAL: 10–100× spike; need auto-scale, queues
GEO: Multi-region = 150ms RTT, regional peaks
TIMEZONE: Global flattens peak
REPLICATION: 3× + backup = 6–10× raw
COMPRESSION: 2–5× text, 10–100× video
COLD/HOT: Tier by access pattern
```

---

**Next: [[07_Tricks-and-Recognition]]**
