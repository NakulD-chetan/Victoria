# How To Prepare for Amazon DE2 - Interview Playbook

## One-Line Goal

Amazon DE2 interviews test whether you can design reliable data systems, write strong SQL and Python, explain trade-offs clearly, and communicate with structure.

---

## What Amazon Usually Tests

### 1. SQL

- joins
- window functions
- aggregations
- deduplication
- date logic
- SCD logic

### 2. Python

- parsing files and events
- ETL-style transformations
- error handling
- edge cases
- clean readable functions

### 3. Data Modeling

- fact vs dimension
- star schema
- SCD Type 1 vs Type 2
- surrogate keys
- partitioning strategy

### 4. System Design

- batch pipelines
- streaming pipelines
- CDC pipelines
- data lakes
- warehouses
- orchestration and backfills

### 5. Behavioral

- Ownership
- Dive Deep
- Deliver Results
- Earn Trust
- Bias for Action

---

## The Answer Format You Should Use in System Design

Use this exact flow in most design rounds.

### Step 1: Clarify requirements

Ask:

- Is this batch or real-time?
- What is the expected data volume?
- What is the latency or SLA requirement?
- Who are the consumers?
- What correctness level is needed?
- How long should data be retained?

### Step 2: Give the high-level design

Say the end-to-end flow first:

```text
Sources -> Ingestion -> Raw Storage -> Processing -> Curated Storage -> Serving -> Monitoring
```

### Step 3: Deep dive into 2-3 areas

Good deep-dive choices:

- storage format and partitioning
- processing engine
- schema evolution
- reliability and retries
- data quality
- security and governance

### Step 4: Explain scaling

Talk about:

- horizontal scaling
- partitioning
- batching/windowing
- storage vs compute separation

### Step 5: Close with trade-offs

Examples:

- batch vs streaming
- S3 vs warehouse storage
- Kafka/MSK vs Kinesis
- Lambda vs Spark
- Parquet vs JSON/CSV

---

## Strong Opening You Can Reuse

> "Let me first clarify the scale, latency, consumers, and correctness requirements. Then I will propose a simple high-level design, deep dive into the main storage and processing choices, and finally cover reliability, scaling, and trade-offs."

---

## What You Must Know for Amazon DE2

### Core AWS Services

| Service | Why it matters |
|--------|-----------------|
| S3 | cheap durable raw and curated storage |
| Glue | catalog, crawlers, ETL jobs |
| EMR / Spark | large-scale processing |
| Lambda | lightweight event-driven compute |
| Kinesis / MSK | streaming ingestion |
| Redshift | BI warehouse serving layer |
| IAM / KMS | security and encryption |
| CloudWatch | logs, alerts, metrics |
| Step Functions / Airflow | workflow orchestration |

### Core Concepts

- partitioning
- Parquet and columnar storage
- schema evolution
- idempotency
- CDC
- watermarking
- late data
- backfills
- upserts and merges
- compaction

---

## What a Good DE2 Answer Sounds Like

Bad answer:

```text
I will use S3, Glue, and Redshift.
```

Better answer:

```text
I would land immutable raw data in S3 first because it gives replay and auditability.
Then Spark or Glue jobs would transform it into curated Parquet datasets.
For BI, I would load serving tables into Redshift.
To make it reliable, I would use idempotent writes, retries, validation checks,
and CloudWatch alerts for failures and freshness issues.
```

---

## Common Mistakes to Avoid

1. Starting with tools before clarifying requirements
2. Ignoring scale and SLA assumptions
3. Explaining only the happy path
4. Forgetting retries, duplicates, and backfills
5. Forgetting data quality validation
6. Saying "real-time" when batch is enough
7. Ignoring cost
8. Over-designing with too many services

---

## What to Mention in Almost Every System Design Answer

### Reliability

- retries
- idempotency
- duplicate handling
- replay and recovery

### Data correctness

- schema checks
- row count checks
- null checks
- late-arriving data handling

### Cost

- Parquet instead of raw JSON for analytics
- partition pruning
- S3 for cheap long-term storage
- lifecycle policies

### Security

- IAM roles
- encryption at rest
- encryption in transit
- PII access control

### Operability

- logs
- metrics
- alerts
- freshness monitoring

---

## 2-Week Preparation Plan

### Week 1

1. Review the answer framework
2. Study batch pipeline design
3. Study streaming pipeline design
4. Study CDC pipeline design
5. Study data lake design
6. Study Redshift warehouse design
7. Revise all architectures from memory

### Week 2

1. Study orchestration, quality, and backfills
2. Practice SQL
3. Practice Python
4. Run a batch design mock
5. Run a streaming design mock
6. Prepare Leadership Principle stories
7. Do one full mock interview with timer

---

## Final Advice

If you are unsure, keep the design simple and speak clearly.

Strong candidates usually do these things well:

- clarify first
- explain a clean flow
- go deep on 2-3 areas
- discuss failure handling
- mention trade-offs

That scores better than giving a very complex architecture with many buzzwords.

---

## Quick Revision (5 points)

1. Amazon DE2 tests SQL, Python, modeling, system design, and communication together
2. A strong design answer starts with clarification, not tool names
3. Speak in this order: requirements -> design -> deep dive -> scaling -> trade-offs
4. Always mention reliability, data quality, security, and cost
5. Simple, correct, well-explained answers usually beat over-engineered ones
