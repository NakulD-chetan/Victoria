# SQL Foundation — Edge Cases

---

## NULL in foreign keys

- Optional relation: child `dept_id` **NULL** → “no department” (if FK allows NULL).
- FK still must not point to a **non-existent** non-null parent id.

---

## Composite keys

- Joins must match **all** key columns.
- Surrogate PK (`INT` id) vs natural key (email) — interviews often ask **why surrogate** (stable, narrow, avoids change).

---

## Self-referencing FK

Example: `employees.manager_id` → `employees.emp_id`.  
Deletes/updates need care (cycle, cascade rules).

---

## Dialect differences

- `AUTO_INCREMENT` / `IDENTITY` / `SERIAL` for auto PK.
- `BOOLEAN` vs `TINYINT(1)`.

Say: “I’d confirm syntax for the specific DB.”

---

*Next: [[07_Tricks-and-Recognition]]*
