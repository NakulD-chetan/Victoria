# CAP Theorem and Consistency — Mental Model

> **Permanent Recall:** Think of CAP like a bank ATM network—during a phone-line outage, the branch must choose: refuse service (CP) or allow withdrawals with possible overdraft risk (AP). Use the key question "Can your system tolerate stale reads?" to drive the decision. Eventual consistency is like DNA replication—eventually all cells have the same DNA. Strong consistency is worth the cost when wrong data causes real harm (money, safety).

---

## Bank ATM Network Analogy

```
         BANK ATM NETWORK (CAP Analogy)

    Branch A                    Branch B
    ┌─────────┐                 ┌─────────┐
    │  ATMs   │                 │  ATMs   │
    │ Balance │   ???           │ Balance │
    │ $1000   │◄───X───►        │ $1000   │
    └─────────┘  Network        └─────────┘
                   DOWN

CP (Consistency): "We don't know if B updated. Refuse withdrawals."
AP (Availability): "Allow withdrawal; risk overdraft if B also paid out."
```

**Mapping:**

| Bank | Distributed System |
|------|---------------------|
| Branch A, B | Data center / region |
| Shared ledger | Replicated data |
| Phone line down | Network partition |
| Refuse service | CP — block until connected |
| Allow with risk | AP — serve, possible inconsistency |

> **FAANG Tip:** This analogy helps non-technical interviewers and stakeholders grasp CAP. "During an outage, we either stop serving or serve with stale data."

---

## How to Think About Consistency Requirements

**Key question:** *What happens if a user sees stale data?*

| Impact | Consistency needed |
|--------|---------------------|
| **Money lost, safety issue** | Strong |
| **Wrong medical dose** | Strong |
| **Duplicate order, double charge** | Strong |
| **Stale social feed** | Eventual OK |
| **Like count off by 1** | Eventual OK |
| **Old profile photo** | Eventual OK |

---

## Decision Framework: "Can Your System Tolerate Stale Reads?"

```
                    Can users tolerate stale reads?
                                │
                    ┌───────────┴───────────┐
                    │ No                    │ Yes
                    ▼                       ▼
            Strong consistency        Eventual consistency
            (CP or quorum reads)       (AP, read-from-one)
```

---

## Mental Model for Eventual Consistency

**Think of DNA replication:** Every cell copies DNA. Replication takes time. Eventually, all cells have the same DNA. No cell "blocks" until others catch up.

```
EVENTUAL = "Given enough time and no new writes, replicas converge"

    Replica 1:  [A] ────────────► [A] (same)
    Replica 2:  [ ] ──► [A] ────► [A] (same)
    Replica 3:  [ ] ────► [A] ──► [A] (same)
                     time
```

**Implication:** Reads might return old value briefly. For many use cases (likes, views, non-critical counters), this is acceptable.

---

## When Strong Consistency Is Worth the Cost

| Scenario | Why Strong |
|----------|------------|
| **Bank balance** | Wrong amount = real money lost |
| **Inventory** | Oversell = broken promises, refunds |
| **Leader election** | Two leaders = split brain |
| **Distributed lock** | Two holders = data corruption |
| **Medical / safety** | Wrong data = harm |

> **FAANG Tip:** "Strong consistency when the cost of being wrong exceeds the cost of higher latency or lower availability."

---

## Decision Tree: Consistency Selection

```mermaid
flowchart TD
    A[Does wrong/stale data cause harm?] --> B{Yes}
    A --> C{No}
    B --> D[Strong Consistency - CP or Quorum]
    C --> E[Can users tolerate brief staleness?]
    E --> F{Yes}
    E --> G{No}
    F --> H[Eventual - AP]
    G --> I[Read-your-writes or Causal]
    D --> J[HBase, ZooKeeper, Quorum reads]
    H --> K[Cassandra, DynamoDB default]
    I --> L[Session stickiness, Causal DB]
```

---

## ASCII Fallback: Decision Tree

```
                    Does stale data cause harm?
                         │Yes           │No
                         ▼              ▼
                  Strong (CP)     Tolerate brief staleness?
                                    │Yes      │No
                                    ▼         ▼
                              Eventual    Read-your-writes
                              (AP)        or Causal
```

---

## Quick Recall: Mental Models

| Concept | Mental Model |
|---------|--------------|
| **CAP during partition** | ATM network—refuse or risk |
| **Eventual consistency** | DNA replication—converge over time |
| **Strong consistency** | Single source of truth—everyone waits |
| **Quorum** | Majority must agree—overlap ensures freshness |
| **Conflict resolution** | "Who wins?"—LWW, merge, or ask user |

---

## 30-SECOND REVISION BOX

```
ATM = CAP (refuse vs risk during outage)
STALE DATA HARM? → Strong. No harm? → Eventual.
EVENTUAL = DNA replication, converge over time
STRONG WHEN: money, safety, inventory, locks
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
