# System-Patterns — Common Mistakes

> **Permanent Recall:** Poor time management, jumping to code too fast, not testing, and overcomplicating kill FAANG interviews. Language-specific pitfalls: C++ TLE from wrong container, Rust borrow checker under pressure, Python TLE from O(n²) hidden in builtins.

---

## General Interview Mistakes

| Mistake | Impact | Fix |
|---------|--------|-----|
| **Poor time management** | No time to test; incomplete solution | Allocate: 4 clarify, 5 brute, 12 optimize, 22 code, 7 test |
| **Jumping to code too fast** | Wrong approach; major rewrite | Always state brute force, then optimize, then code |
| **Not testing** | Bugs in edge cases; no chance to fix | Always trace 1–2 examples + empty/single |
| **Overcomplicating** | Wasted time; harder to debug | Start simple; add complexity only if needed |
| **Ignoring constraints** | Wrong algorithm (e.g., O(n²) when n=10^6) | Check n first; map to complexity |
| **Not clarifying** | Wrong assumptions; invalid solution | Ask: empty? duplicates? negatives? |
| **Silent coding** | Interviewer loses context | Think aloud; explain key decisions |
| **Giving up too early** | No partial credit | Brute force + ask for hint |

---

## Time Management Pitfalls

| Pitfall | Symptom | Recovery |
|---------|---------|----------|
| **Over-clarifying** | 8 min in, no approach | Cap at 3–4 questions; move on |
| **Over-optimizing** | 25 min in, no code | Start coding at 20 min even if not perfect |
| **Perfectionism** | Rewriting working code | "Good enough" > perfect |
| **No buffer** | No time for follow-up | Finish main by 40 min |
| **Stuck too long** | 15 min on one step | Ask for hint after 5 min stuck |

---

## Code Quality Mistakes

| Mistake | Example | Fix |
|---------|---------|-----|
| **Monolithic function** | 80-line function | Extract helpers: `feasible()`, `merge()` |
| **Magic numbers** | `if i < 7` | Use named constants or explain |
| **Unclear variable names** | `x`, `y`, `tmp` | Use `left`, `right`, `prefix_sum` |
| **No base case** | Recursion without `if n<=1` | Always handle empty/single |
| **Off-by-one** | `i < n` vs `i <= n` | Test with n=1, n=2 |
| **Wrong loop bound** | `for i in range(n)` when 1-indexed | Double-check indices |

---

## Pattern-Specific Mistakes

| Pattern | Common Mistake | Fix |
|---------|----------------|-----|
| **BS on Answer** | `lo = mid` instead of `hi = mid` (or vice versa) | Remember: "first true" → hi=mid; "last true" → lo=mid+1 |
| **BS on Answer** | Wrong search space (lo, hi) | Ensure answer is in [lo, hi]; check boundaries |
| **Monotonic Stack** | Wrong comparison (strict vs non-strict) | Next greater: `<`; next greater or equal: `<=` |
| **Sweep Line** | Wrong event order (end before start) | Sort by time; if tie, end before start: `(t, -1)` before `(t, 1)` |
| **Two-Pass** | Using extra O(n) space when O(1) possible | Product except self: use output array for one direction |
| **BIT** | 0-indexed vs 1-indexed confusion | BIT is 1-indexed internally; convert at API boundary |
| **Meet in Middle** | Duplicate counting | Careful with "empty" half; avoid double-counting |

---

## Language-Specific Pitfalls

### Python

| Mistake | Cause | Fix |
|---------|-------|-----|
| **TLE from `in` on list** | `x in list` is O(n) | Use `set` for O(1) lookup |
| **TLE from `list.insert(0, x)`** | Shifting is O(n) | Use `deque` for O(1) appendleft |
| **TLE from `str += char`** | String concat is O(n) | Use `list.append` then `''.join()` |
| **TLE from repeated `sorted()`** | O(n log n) each call | Sort once; reuse |
| **TLE from `max(arr)` in loop** | O(n) per iteration | Precompute or use heap |
| **Recursion limit** | Default ~1000 | Use iterative or `sys.setrecursionlimit` |
| **Mutable default** | `def f(x=[])` | Use `def f(x=None): x = x or []` |

### C++

| Mistake | Cause | Fix |
|---------|-------|-----|
| **TLE from `endl`** | Flushes buffer every time | Use `'\n'` |
| **TLE from wrong container** | `list` for random access | Use `vector` for array-like |
| **TLE from `unordered_map` hash collision** | Worst case O(n) per op | Use `map` if keys have bad hash |
| **TLE from `cin`/`cout`** | Slower than scanf/printf | Use `ios_base::sync_with_stdio(false)` |
| **Integer overflow** | `int` for 10^9 * 10^9 | Use `long long` |
| **Wrong `lower_bound`** | Returns first >= ; need first > | Use `upper_bound` or adjust |
| **Vector resize** | `resize` vs `reserve` | `reserve` for capacity; `resize` for size |

### Rust

| Mistake | Cause | Fix |
|---------|-------|-----|
| **Borrow checker fight** | `&mut` and `&` conflict | Clone if needed; use `RefCell` for interior mutability |
| **Ownership in loop** | Moving into loop | Use `iter()` or indices; avoid `into_iter()` when need to reuse |
| **Fighting borrow checker under pressure** | Complex nested refs | Simplify; use `clone()` to unblock |
| **`Vec::with_capacity`** | Avoid reallocation | Pre-allocate when size known |
| **`unwrap()` in interview** | Panic on None/Err | Use `unwrap_or()` or `?` with Result |
| **Wrong integer type** | `usize` vs `i32` | Match problem constraints; cast explicitly |
| **`sort` vs `sort_by`** | Need custom compare | Use `sort_by_key` or `sort_by` |

---

## Testing Mistakes

| Mistake | Fix |
|---------|-----|
| **Not testing** | Always trace at least one example |
| **Only happy path** | Test empty, single, two elements |
| **Not testing boundaries** | Test lo, hi, first, last |
| **Assuming input valid** | Consider duplicates, negatives |
| **Not fixing found bugs** | Fix before saying "done" |

---

## FINAL MEMORY COMPRESSION BLOCK

```
GENERAL:      Time mgmt, don't jump to code, always test, don't overcomplicate
TIME:         Cap clarify 4 min; start code by 20 min
CODE:         Modular, clear names, base cases, off-by-one
PATTERN:      BS: hi=mid vs lo=mid+1; Sweep: end before start on tie
PYTHON:       in on list O(n)→set; str+= O(n)→list+join; mutable default
CPP:          endl→'\n'; vector not list; long long for big nums
RUST:         Borrow checker→clone to unblock; pre-allocate Vec
```

---

## 30-SECOND REVISION BOX

```
□ 45 min split: 4+5+12+22+7
□ Brute first, then optimize, then code
□ Always trace example + empty/single
□ Python: set for lookup, list+join for string
□ C++: '\n' not endl, vector, long long
□ Rust: clone to unblock borrow checker
□ BS: first true → hi=mid; last true → lo=mid+1
```
