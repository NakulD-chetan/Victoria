# Design Distributed Cache — Tricks and Recognition

> **Permanent Recall:** Consistent hashing with virtual nodes is **the** distribution answer. LRU = O(1) via hash map + doubly-linked list. Redis is the real-world answer — explain how it works internally. This problem tests **data structures + distributed systems** combined.

---

## Recognition — When This Is the Question

| Phrase | Implication |
|--------|-------------|
| "Design Redis" | Full cache: data structures, eviction, persistence, cluster |
| "Design Memcached" | Simpler: key-value only, no persistence, no rich types |
| "Distributed cache" | Partitioning + replication; consistent hashing |
| "In-memory key-value store" | Same family; emphasize latency, eviction |
| "Cache layer for X" | Cache-aside or write-through; invalidation strategy |

---

## Must-Know Tricks

### 1. Consistent Hashing = Distribution Answer

When asked "how do you distribute keys across nodes?", the answer is **consistent hashing**. Not modulo. Explain:
- Ring (hash space)
- Key → clockwise to first node
- Virtual nodes for balance
- Only K/N keys move on failure

---

### 2. LRU in O(1) — Hash Map + Doubly-Linked List

When asked "how do you implement LRU eviction?", answer:

```
HashMap: key → (value, pointer to list node)
List: head = MRU, tail = LRU

GET: lookup, move node to head
SET: if exists update+move; else add to head; if over cap, evict tail
EVICT: remove tail, delete from map
```

All O(1).

---

### 3. Sorted Set = Skip List + Hash Map

When asked "how does Redis implement sorted sets?":

- **Skip list:** Ordered by score; levels for O(log n) search
- **Hash map:** member → score (for O(1) lookup by member)
- **ZADD, ZRANGE, ZRANGEBYSCORE** — know the complexity

---

### 4. Redis as Reference

"Redis does it this way" is a strong signal. Be able to explain:
- RDB vs AOF
- Single-threaded (mostly) for simplicity
- RESP protocol
- Cluster: hash slots (16384), gossip

---

### 5. Evolution Narrative

Start simple → add distribution → add replication → eviction detail → persistence. Shows incremental thinking.

---

### 6. Hot Key — Proactive Mention

If designing at scale, say: "We should consider hot keys. Mitigations: replication for hot shard, local cache, or key sharding."

---

### 7. Cache Stampede — Proactive Mention

"If a popular key expires, we need to avoid thundering herd. Probabilistic early expiry or a lock so only one request hits DB."

---

### 8. Virtual Nodes — Always Include

"Without virtual nodes, one node might get 80% of keys. With 100–200 virtual nodes per physical node, distribution is even."

---

## Formula Cheat Sheet

| Concept | Formula / Structure |
|---------|---------------------|
| Key location | `ring[hash(key)]` → clockwise to node |
| Keys moved on failure | ~K/N (K = keys on failed node) |
| LRU | HashMap + doubly-linked list |
| Sorted set | Skip list + HashMap |
| Eviction | Remove tail (LRU) or lowest freq (LFU) |

---

## What Interviewers Probe

| Probe | What they want |
|-------|----------------|
| "How does hashing work?" | Consistent hashing, not modulo |
| "What if a node fails?" | Replication, failover, minimal rehash |
| "How do you evict?" | LRU/LFU, O(1) implementation |
| "How do sorted sets work?" | Skip list; range queries |
| "What about persistence?" | RDB vs AOF; when to use |

---

## One-Liner Summary

**Distributed cache = partitioned hash table + consistent hashing + replication + O(1) LRU eviction.** Add persistence (RDB/AOF) and data structures (skip list for sorted sets) as needed.
