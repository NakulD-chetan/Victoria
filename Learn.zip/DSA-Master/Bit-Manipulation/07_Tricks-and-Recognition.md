# Bit Manipulation — Tricks & Recognition

> **FAANG Focus:** Pattern → technique mapping for fast recognition.

---

## 1. Problem Phrase → Technique

| Phrase / Constraint | Technique |
|--------------------|-----------|
| "Single number" / "unique" / "others appear twice" | **XOR all** |
| "Power of 2" / "power of 4" | **n & (n-1) == 0** (+ extra for 4) |
| "All subsets" / "subsets of array" | **Bitmask iteration** |
| n ≤ 20 / "visited" / "assign" | **Bitmask DP** |
| "Maximum XOR" of two numbers | **Trie** or greedy bit-by-bit |
| "XOR of subarray" | **Prefix XOR** |
| "Count 1s" / "Hamming weight" | **Popcount** / Brian Kernighan |
| "Hamming distance" | **XOR + popcount** |
| "Swap without temp" | **XOR swap** |
| "Gray code" | **i ^ (i >> 1)** |

---

## 2. Key Tricks Cheat Sheet

### XOR Tricks

```
Single among pairs:     xor_all = 0; for x: xor_all ^= x
Two singles:            split by xor_all & (-xor_all)
Swap:                   a^=b; b^=a; a^=b;
XOR range [l,r]:        prefix[r+1] ^ prefix[l]
XOR 1..n:               n%4→0:n, 1:1, 2:n+1, 3:0
```

### AND/OR Tricks

```
Power of 2:             n > 0 && (n & (n-1)) == 0
Remove LSB:             n & (n-1)
Isolate LSB:            n & (-n)
Set bit i:              n | (1 << i)
Clear bit i:            n & ~(1 << i)
Mod 2^k:                n & ((1<<k)-1)
```

### Bitmask Tricks

```
All subsets:            for mask in 0..(1<<n)
Submask of m:           for sub = m; sub; sub = (sub-1) & m
Size k subsets:        filter popcount(mask)==k or Gosper's
Full set:               (1<<n) - 1
```

---

## 3. Constraint → Approach Table

| Constraint | Approach |
|------------|----------|
| n ≤ 20 | Bitmask DP (2^20 states) |
| n ≤ 25 | Bitmask DP (tight, 2^25) |
| n ≤ 16 | Brute-force subsets often OK |
| O(1) space | XOR, math (no extra arrays) |
| O(n) time | Single pass XOR, prefix |
| "Exactly one" | XOR cancellation |

---

## 4. Recognition Flowchart

```mermaid
flowchart TD
    A["Problem"] --> B["Unique / Pairs?"]
    A --> C["Subsets / Choose?"]
    A --> D["n ≤ 20 / Visited?"]
    B --> E["XOR all elems"]
    C --> F["Bitmask iterate"]
    D --> G["Bitmask DP dp[mask]"]
    style E fill:#90EE90
    style F fill:#87CEEB
    style G fill:#DDA0DD
```

<details>
<summary>ASCII fallback</summary>

```
                    Problem
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
   "Unique"        "Subsets"      "n ≤ 20"
   "Pairs"         "Choose"       "Visited"
        │              │              │
        ▼              ▼              ▼
      XOR          Bitmask        Bitmask DP
    all elems      iterate        dp[mask]
```

</details>

---

## 5. Power of 2 vs Power of 4

| Check | Formula |
|-------|---------|
| Power of 2 | `n > 0 && (n & (n-1)) == 0` |
| Power of 4 | Above + `(n & 0x55555555) != 0` (odd bit positions) |

```
Power of 4: 1, 4, 16, 64... (bits at positions 0, 2, 4...)
0x55555555 = 0101 0101 0101... (mask for odd positions)
```

---

## 6. Single Number Variants

| Variant | Technique |
|---------|-----------|
| Others 2x | XOR all |
| Others 3x | Bit count mod 3 (ones, twos) |
| Two unique | XOR + split by diff bit |
| Missing in [0..n] | XOR indices and values |

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  "Single number" → XOR all                      │
│  "Power of 2" → n & (n-1) == 0                  │
│  "Subsets" → bitmask 0..(1<<n)                  │
│  n ≤ 20 → Bitmask DP                            │
│  "Max XOR" → Trie / greedy bits                 │
│  "XOR range" → prefix XOR                       │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] Single → XOR; Power of 2 → n&(n-1)==0
- [ ] Subsets → bitmask; n≤20 → bitmask DP
- [ ] Max XOR → Trie; XOR range → prefix
- [ ] Remove LSB: n&(n-1); Isolate LSB: n&(-n)
