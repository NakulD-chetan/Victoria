# How Stock Exchange Works - In Depth (Easy Language)

> Companion to: [07-How-Stock-Exchange-Works.md](07-How-Stock-Exchange-Works.md)

---

## What Problem Does a Stock Exchange Solve?

### The Farmer's Market Analogy

Imagine a farmer's market without a central exchange:

```
WITHOUT exchange:
  Buyer A: "I want to buy 10 apples for $1 each" → wanders around asking sellers
  Seller B: "I want to sell 20 apples for $1.20 each" → wanders around asking buyers
  
  Problem: How do they find each other? Who decides the fair price?
  No one knows who's buying or selling or at what price!

WITH exchange:
  All buyers and sellers go to ONE place (the exchange)
  Everyone posts their offers on a public board (order book)
  When a buyer's price matches a seller's price → TRADE HAPPENS automatically
```

A stock exchange is this central meeting point, but for stocks, bonds, and other financial instruments. And it happens in **microseconds**.

---

## Key Trading Terms (No Jargon)

| Term | Simple Meaning | Example |
|------|---------------|---------|
| **Order Book** | A list of all "I want to buy" and "I want to sell" requests for a stock | See detailed section below |
| **Market Order** | "Buy/sell RIGHT NOW at whatever the current price is" | "Buy 10 shares of Apple NOW" |
| **Limit Order** | "Buy/sell ONLY if the price reaches my target" | "Buy Apple only if price drops to $150" |
| **BID** | Highest price someone is willing to PAY (buyer) | "I'll pay up to $150" |
| **ASK** | Lowest price someone is willing to ACCEPT (seller) | "I'll sell for at least $151" |
| **Spread** | Gap between highest BID and lowest ASK | $151 - $150 = $1 spread |
| **FIFO** | First In, First Out -- whoever placed order first gets matched first | Fair queuing |

---

## The Order Book - The Heart of the Exchange

### How It's Structured

Think of two lists facing each other:

```
═══════════════ APPLE (AAPL) ORDER BOOK ═══════════════

BUY SIDE (sorted: highest price first)    SELL SIDE (sorted: lowest price first)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
$150.00: [Alice: 100 shares] → [Bob: 50]  $151.00: [Eve: 200 shares] → [Frank: 80]
$149.50: [Charlie: 200 shares]             $151.50: [Grace: 150 shares]
$149.00: [David: 75 shares]               $152.00: [Henry: 300 shares]
$148.00: [Emily: 500 shares]              $155.00: [Ivy: 100 shares]

         ↑ BID = $150.00                            ↑ ASK = $151.00
                    ← SPREAD = $1.00 →
```

**The BUY side**: People wanting to BUY shares. Sorted by price (highest first, because buyers offering more money get priority).

**The SELL side**: People wanting to SELL shares. Sorted by price (lowest first, because sellers offering the cheapest price get priority).

**A trade happens when**: buy_price >= sell_price

### What Happens When a New Order Arrives

**Scenario 1: Market order to BUY 100 shares**
```
"Buy 100 shares of AAPL at market price (whatever it costs)"

Look at SELL side: cheapest seller is Eve at $151.00 with 200 shares
→ Match 100 shares at $151.00
→ Eve has 100 shares left
→ Trade complete!

After:
SELL SIDE: $151.00: [Eve: 100 shares left] → [Frank: 80]
```

**Scenario 2: Limit order to BUY at $149.00**
```
"Buy 100 shares of AAPL but ONLY at $149.00 or less"

Look at SELL side: cheapest seller is Eve at $151.00
→ $151.00 > $149.00 → NO MATCH! Too expensive!
→ Order sits in BUY side, waiting for a seller to lower their price

BUY SIDE: $150.00: [Alice: 100] → [Bob: 50]
          $149.50: [Charlie: 200]
          $149.00: [David: 75] → [NEW: 100]  ← added to queue!
```

---

## The Data Structure Magic - O(1) Everything

### Why Speed Matters

A stock exchange processes **millions of messages per second**. If each operation took even 1 millisecond, the system would be too slow. Everything must be **microseconds**.

### The Secret: Doubly-Linked List + Hash Map

**At each price level**, there's a queue (doubly-linked list):

```
Price $150.00:
  [Alice: 100] ←→ [Bob: 50] ←→ [Charlie: 75]
      ↑                               ↑
     HEAD                            TAIL

New order → INSERT at TAIL: O(1) time (just point TAIL to new node)
```

**For cancellations**, there's a hash map (index):

```
Index (Hash Map):
  order_id_001 → pointer to [Alice: 100] node
  order_id_002 → pointer to [Bob: 50] node
  order_id_003 → pointer to [Charlie: 75] node

Cancel order_id_002 (Bob's order):
  1. Look up in hash map: O(1)
  2. Get pointer to Bob's node
  3. Remove node from linked list: O(1) (just repoint neighbors)
  4. Done! No searching needed!
```

**Result:**
- Insert new order: **O(1)**
- Cancel order: **O(1)**
- Find best bid/ask: **O(1)** (just look at head of BUY/SELL lists)
- Everything in memory (no disk I/O!)

---

## The Three-Tier Architecture

```
Tier 1: BROKER (User-Facing)
  ┌─────────────────────────────────┐
  │ Robinhood / Zerodha App         │
  │ - User places order via REST    │
  │ - Real-time prices via WebSocket│
  │ - Connects to exchange via FIX  │
  └──────────────┬──────────────────┘
                 │ FIX Protocol
                 
Tier 2: GATEWAY (Validation + Sequencing)
  ┌──────────────▼──────────────────┐
  │ Risk Manager                     │
  │ - Does user have enough money?  │
  │ - Is this suspicious activity?  │
  │                                 │
  │ Wallet Service                  │
  │ - User's funds and stock count  │
  │                                 │
  │ Order Manager                   │
  │ - Assigns SEQUENCE NUMBERS      │
  │ - Guarantees ordering fairness  │
  │ - Routes to matching engine     │
  └──────────────┬──────────────────┘
                 │ Topic Queues
                 
Tier 3: MATCHING ENGINE (The Brain)
  ┌──────────────▼──────────────────┐
  │ Order Book (in-memory)          │
  │ Matching Logic                  │
  │ Market Data Publisher           │
  └─────────────────────────────────┘
```

---

## FIX Protocol - How Brokers Talk to the Exchange

### Why Not Just Use HTTP?

HTTP was designed for web pages. Financial trading needs:
- **Guaranteed delivery** (your order MUST reach the exchange)
- **Sequence numbers** (to detect missing or duplicate messages)
- **Checksums** (to verify data wasn't corrupted)
- **Low latency** (microseconds matter)

### FIX (Financial Information Exchange) Protocol

```
A FIX message looks like:
  8=FIX.4.4|35=D|49=BROKER_A|56=EXCHANGE|
  11=ORDER_001|55=AAPL|54=1|38=100|40=2|44=150.00|

Translated:
  Protocol: FIX 4.4
  Type: New Order (35=D)
  From: BROKER_A
  To: EXCHANGE
  Order ID: ORDER_001
  Symbol: AAPL
  Side: BUY (54=1)
  Quantity: 100
  Order Type: Limit (40=2)
  Price: $150.00
```

Every message has a **sequence number**. If the exchange receives message #5 but #4 never arrived, it knows something was lost and requests retransmission.

---

## Sequence Numbers - Guaranteeing Fairness

### The Problem Without Sequence Numbers

```
Trader A submits order at 10:00:00.001
Trader B submits order at 10:00:00.002

If network routes them differently:
  Exchange receives B first, then A
  B gets matched before A → UNFAIR!
  A submitted first but got served second
```

### The Solution

The Order Manager assigns **globally increasing sequence numbers**:

```
Order arrives from Trader A → Sequence #1001
Order arrives from Trader B → Sequence #1002
Order arrives from Trader C → Sequence #1003

Matching engine processes in order: 1001, 1002, 1003
Even if they arrive out of order, they're REORDERED by sequence number
→ Fairness guaranteed!
```

**Separate queues per message type** prevent different operations from blocking each other:

```
New Order Queue:    [#1001] [#1002] [#1003] → Matching Engine
Cancel Queue:       [#501]  [#502]  → Matching Engine  
Trade Result Queue: [#201]  [#202]  → Market Data Publisher
```

---

## Event Sourcing - Replay Everything

### Traditional Approach

```
Store current state in a database:
  AAPL order book: { bids: [...], asks: [...] }
  
  Problem: If system crashes, how do you rebuild?
  The database might be corrupted or outdated.
```

### Event Sourcing Approach

```
Store EVERY event that ever happened:
  Event #1: OrderPlaced(AAPL, BUY, $150, 100 shares)
  Event #2: OrderPlaced(AAPL, SELL, $151, 200 shares)
  Event #3: OrderCancelled(#1)
  Event #4: OrderPlaced(AAPL, BUY, $150.50, 150 shares)
  Event #5: TradeExecuted(AAPL, $151, 100 shares)

To rebuild state after crash:
  1. Start with empty order book
  2. Replay events #1, #2, #3, #4, #5 in order
  3. Order book is perfectly reconstructed!
```

**Benefits:**
- **Complete audit trail**: regulators can see exactly what happened
- **Deterministic recovery**: replay events → get exact same state
- **Debugging**: "What happened at 2:35 PM?" → replay events from that time
- **Testing**: replay production events on a test system

---

## Message Distribution - What Happens on a Typical Day

```
All messages on a stock exchange in one day:
  ┌─────────────────────────────────────┐
  │ New Orders:      50% of messages    │
  │ Cancellations:   40% of messages    │ ← Most orders are CANCELLED!
  │ Executions:       2% of messages    │ ← Very few actually trade
  │ Other:            8%                │
  └─────────────────────────────────────┘
```

**Surprising fact**: Only ~2% of orders result in actual trades! Most orders are placed and then cancelled. This is because algorithmic traders constantly adjust their prices based on market conditions.

This is why **O(1) cancellation** is so important -- 40% of all messages are cancellations!

---

## Determinism - The Non-Negotiable Rule

### What Is Determinism?

**Same input → same output, ALWAYS.**

```
If you replay these 3 events:
  1. BUY 100 AAPL at $150
  2. SELL 50 AAPL at $149
  3. CANCEL order #1

The result MUST always be the same, no matter:
  - What time you replay them
  - What machine you replay them on
  - How many times you replay them
```

**Why is this critical?**
- Regulators require it (prove what happened)
- Disaster recovery depends on it (replay = rebuild state)
- Fairness requires it (same order → same result)

**No randomness, no timestamps from system clock, no external data** during matching. Everything is based on the event sequence.

---

## Scaling a Stock Exchange

### Why This Is Different from Web Services

Web services scale **horizontally** (add more servers). Stock exchanges scale **vertically** (make one server faster).

```
Web service (e.g., Twitter):
  10 servers → 100 servers → 1000 servers
  Each server handles a subset of users
  Horizontal scaling!

Stock exchange matching engine:
  One REALLY fast server per stock
  Single-threaded (for determinism!)
  In-memory (for speed!)
  Vertical scaling: faster CPU, more RAM
```

### The One Trick for Horizontal Scaling

**Shard by stock symbol:**

```
Matching Engine 1: AAPL, GOOGL, MSFT
Matching Engine 2: TSLA, AMZN, META
Matching Engine 3: NVDA, JPM, BAC

Each stock's order book runs on its own matching engine
They don't need to communicate with each other
This IS horizontal scaling (for the exchange as a whole)
```

---

## Revision Flashcards

**Q: What data structures does the order book use?**
A: Doubly-linked list per price level (for FIFO queuing, O(1) insert at tail) + hash map index mapping order_id to node pointer (for O(1) cancellation).

**Q: When does a trade happen?**
A: When buy_price >= sell_price. The matching engine checks the best bid and best ask; if they cross, a trade executes.

**Q: Why are 40% of messages cancellations?**
A: Algorithmic traders constantly adjust orders based on market conditions. They cancel old orders and place new ones many times per second.

**Q: What is event sourcing and why does a stock exchange use it?**
A: Every action is stored as an immutable event. To recover from a crash, replay all events from the beginning. Gives a complete audit trail and deterministic recovery.

**Q: Why is the matching engine single-threaded?**
A: Determinism. Multi-threading introduces race conditions and non-deterministic behavior. Same input must ALWAYS produce same output, and single-threading guarantees this.

**Q: What is the FIX protocol?**
A: Financial Information Exchange protocol. Industry standard for broker-to-exchange communication with built-in sequence numbers, checksums, and guaranteed delivery.
