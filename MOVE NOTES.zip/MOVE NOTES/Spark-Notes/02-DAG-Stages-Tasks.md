# DAG, Stages, and Tasks

This is how Spark converts your code into actual parallel execution. Understanding this flow is critical.

---

## 1. DAG (Directed Acyclic Graph) — The Blueprint

When you write transformations like `filter()`, `map()`, `groupBy()`, Spark does NOT execute them immediately. Instead, it builds a **DAG** — a logical blueprint of the entire data flow.

**What does DAG mean?**


| Word     | Meaning                                      |
| -------- | -------------------------------------------- |
| Directed | Data flows in one direction (step by step)   |
| Acyclic  | No loops — prevents infinite processing      |
| Graph    | Nodes = data states, Edges = transformations |


**Important**: The DAG is just a **logical plan** — it describes *what* needs to be done. No data is processed until you trigger an **Action**.

### Actions that trigger execution:

- `count()`
- `show()`
- `collect()`
- `write()`
- `take()`
- `foreach()`

**One Action = One Job**

---

## 2. DAG → Stages — Breaking the Plan

When an Action is called, the **DAG Scheduler** converts the DAG into **Stages**.

### How are stages created?

Stages are created at **shuffle boundaries**. Every time Spark encounters a **wide transformation** (one that requires data to move between partitions), it creates a new stage.

**Wide transformations that create stage boundaries:**

- `groupBy()`
- `join()`
- `reduceByKey()`
- `distinct()`
- `repartition()`
- `orderBy()` / `sortBy()`

**Narrow transformations** (no data movement) are pipelined within the same stage:

- `filter()`
- `map()`
- `select()`
- `withColumn()`

### The Golden Rule

### Stage 1 (Read Stage):

- Reads data from source:
  - HDFS / S3 / local / DB
- Splits data into **partitions**
- Assigns partitions to executors
- Applies **narrow transformations** (if possible)

```
Number of Stages = 1 (initial read stage) + Number of Wide Transformations
```

### Example

```python
df = spark.read.csv("data.csv")          # Read
df_filtered = df.filter(...).map(...)     # Narrow ops (pipelined with read)
df_final = df_filtered.groupBy(...).count()  # Wide op (shuffle)
df_final.show()                           # Action triggers execution!
```

**How many stages?**

- Wide transformations: 1 (`groupBy`)
- Total stages = 1 (read) + 1 (wide) = **2 stages**

```
Stage 0: Read + filter + map  (all narrow, pipelined together — no shuffle)
Stage 1: groupBy + count      (shuffle happens before this stage)
```

> **PDF Correction**: The original PDF showed this as 3 stages (separating read and filter/map into different stages). That's incorrect. Narrow transformations are **always pipelined** into the same stage as their preceding operation. The correct answer is **2 stages**, which matches the golden rule: 1 + 1 = 2.

---

## 3. Stages → Tasks — The Parallel Workers

Each Stage is divided into **Tasks**. Tasks are the smallest unit of work.

### Key Rule

```
1 Task = 1 Partition of data + the computation for that partition
```

Each task runs on **one executor core**.

**Example**: If a stage has 200 partitions → Spark creates **200 tasks**. If you have 20 cores across your cluster, 20 tasks run in parallel, then the next batch of 20, and so on.

---

## Complete Flow (End-to-End)

```
Your Code (transformations)
       |
       v
   [DAG Built]          ← Lazy — nothing executed yet
       |
   Action Called (e.g., show())
       |
       v
   [Job Created]         ← One action = one job
       |
       v
   [DAG Scheduler]       ← Breaks DAG into Stages at shuffle boundaries
       |
       v
   [Stages Created]      ← 1 read stage + 1 per wide transformation
       |
       v
   [Task Scheduler]      ← Creates 1 task per partition per stage
       |
       v
   [Executors Run Tasks]  ← Each core runs one task in parallel
       |
       v
   [Results to Driver]
```

---

## Fault Tolerance

If an executor crashes or a task fails:

- Spark uses **DAG lineage** to figure out which partitions were lost
- It **recomputes only the lost partitions** — not the entire job
- This is possible because the DAG records every transformation step

---

## Key Takeaway

> Code → DAG (lazy) → Action triggers Job → DAG Scheduler breaks into Stages (at shuffle boundaries) → Each stage creates Tasks (1 per partition) → Tasks run in parallel on Executor cores.
>
> This is what makes Spark scalable, efficient, and fault-tolerant.

