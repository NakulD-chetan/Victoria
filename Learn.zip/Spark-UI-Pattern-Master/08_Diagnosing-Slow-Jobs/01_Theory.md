# Diagnosing Slow Jobs — Skew, Spill, GC, OOM

Yeh capstone pattern hai. Ab tak tum tabs padhna seekh chuke ho — yeh pattern un sab insights ko **debugging workflow** mein assemble karta hai. Real interviews aur production firefighting yahin ka hai.

**DSA Analogy**: Root-cause analysis on a system. Like binary searching across stages → tasks → executors → operators until you find the actual bottleneck.

---

## Core Idea (2 Lines)

Slow Spark jobs ke 4 main villains hote hain: **Data Skew, Shuffle Spill, Garbage Collection, OOM**. Inhe systematically identify karne ke liye Jobs → Stages → Tasks → Executors → SQL ka funnel use karo.

---

## The Universal Debug Workflow

```
SLOW JOB
   |
   v
Step 1. Jobs tab        -> WHICH job is slow?
   |
   v
Step 2. Stages tab      -> WHICH stage in the slow job?
   |
   +--> Click stage; look at Summary Metrics
            |
            v
        Step 3a. Task duration: Max >> Median?
                    +-- yes -> SKEW (Section 1)
                    +-- no  -> next check
        Step 3b. Spill (Memory) or Spill (Disk) > 0?
                    +-- yes -> SPILL (Section 2)
                    +-- no  -> next check
        Step 3c. GC time > 10% of task time?
                    +-- yes -> GC issue (Section 3)
                    +-- no  -> next check
        Step 3d. Shuffle Read or Write huge?
                    +-- yes -> Plan optimization needed (Section 4)
   |
   v
Step 4. Cross-check with Executors / Storage / SQL tabs
```

---

## Section 1 — Data Skew

### Symptom Signatures

```
Stages tab → Summary Metrics:
  Min     25th    Median    75th    Max
  0.1s    0.3s    0.5s      0.8s    25.0s     <-- Max >> Median
                                    ^^^^^^
                                    DATA SKEW
```

```
Event Timeline (inside the stage):
  Executor 1: ##############################  <-- one task, 25s
  Executor 2: ##                              <-- 1s, then idle
  Executor 3: #                               <-- idle
```

### Root Cause

One partition has wildly more rows than others — usually because:
- Hot key (e.g. country = "US" has 80% of rows)
- Null values bucketed together
- Bad join key distribution

### Detection Recipe

```
1. Open the slow stage.
2. Read Summary Metrics row "Duration":
        Max / Median ≥ 10  -> skew
3. Click "Tasks" tab → sort by Duration descending.
4. Note Shuffle Read of the slow task vs median:
        SR_max / SR_median ≥ 10 -> confirms partition skew.
```

### Fixes (in order of preference)

| Fix                                     | When To Use                                          | Example                                                 |
|-----------------------------------------|------------------------------------------------------|---------------------------------------------------------|
| Enable AQE skew handling                | Spark 3.0+, dynamic skew                              | `spark.sql.adaptive.skewJoin.enabled=true`              |
| Salting (key + random suffix)           | Group by hot key; you control logic                  | `df.withColumn("k_salt", concat(col("k"), lit("_"), (rand()*10).cast("int")))` |
| Broadcast the small side                | Hot key on one side, small df on other               | `df.join(broadcast(small_df), "k")`                     |
| Increase shuffle partitions             | Skew across many keys (not one hot key)              | `spark.sql.shuffle.partitions = 1000`                   |
| Pre-aggregate before shuffle             | Aggregations                                          | `df.groupBy("k", "extra").count().groupBy("k").sum()`   |
| Filter out null/sentinel keys            | Nulls clustered                                       | `df.filter(col("k").isNotNull())`                        |

### Worked Example — Salting

```python
# Before: skewed groupBy on "country" where US has 80% of rows
df.groupBy("country").sum("amount")
# After:
salted = df.withColumn("salt", (rand()*10).cast("int")) \
           .withColumn("country_salt", concat(col("country"), lit("_"), col("salt")))
partial = salted.groupBy("country_salt", "country").sum("amount").alias("partial_sum")
final = partial.groupBy("country").sum("partial_sum")
```

---

## Section 2 — Shuffle Spill

### Symptom

```
Stages → Summary Metrics:
  Spill (Memory): 8.0 GB     <-- not 0
  Spill (Disk):    2.4 GB     <-- compressed disk
```

```
Executors tab:
  Disk Used: 2.4 GB
```

### Root Cause

Spark's **execution memory** wasn't enough to hold the data being shuffled/aggregated/sorted. So Spark spilled extra rows to local disk and read them back later → **massive slowdown**.

### Detection

```
spill_ratio = Spill_Disk / Shuffle_Read
  spill_ratio = 0       -> healthy
  spill_ratio > 0       -> memory tight
  spill_ratio > 0.5     -> severe; rewrite the stage
```

### Fixes

| Fix                                        | When                                      |
|--------------------------------------------|-------------------------------------------|
| Increase `spark.executor.memory`           | Always first try                          |
| Increase `spark.memory.fraction`           | If cache hogging memory; default 0.6      |
| Decrease `spark.memory.storageFraction`    | Same; default 0.5 of fraction             |
| Reduce data per task (more partitions)     | `df.repartition(N*2)` before shuffle      |
| Avoid wide transformations when possible   | Replace `groupBy + agg` with map-side ops |
| Enable AQE coalesce                        | If too many tiny post-shuffle partitions  |

---

## Section 3 — High GC Time

### Symptom

```
Executors:
  Executor 0: GC Time = 120 s out of 300 s task time -> 40% GC ratio
```

### Root Cause

JVM heap is full or fragmented; GC pauses dominate. Common causes:
- Cache holding too much
- Too many small Java objects (UDFs creating lots of intermediate objects)
- Heap too small relative to data volume
- CMS GC instead of G1 (under heavy pressure)

### Fixes

| Fix                                          | Effect                                                 |
|----------------------------------------------|--------------------------------------------------------|
| Reduce or unpersist cache                    | Frees memory for execution                              |
| `--conf spark.executor.extraJavaOptions="-XX:+UseG1GC"` | Better large-heap behavior                       |
| `spark.memory.storageFraction` lower         | Gives execution more memory                            |
| Use `MEMORY_ONLY_SER` for caching            | Smaller footprint                                       |
| Replace Python UDF with native function      | Cuts boxing/unboxing                                    |
| Use Arrow-based Pandas UDFs                  | Vectorized, fewer objects                               |
| Increase heap                                 | `spark.executor.memory = larger`                        |

---

## Section 4 — OOM (Executor Killed)

### Symptom

```
Executors tab:
  Executor 1: Status = Dead
  Failed Tasks: 5

Logs:
  java.lang.OutOfMemoryError: Java heap space
  ExecutorLostFailure (executor 1 exited caused by ...)
```

### Causes & Fixes

| Cause                                         | Fix                                                                    |
|-----------------------------------------------|-------------------------------------------------------------------------|
| Task tries to load too-big single partition    | `df.repartition(N×2)` before action                                     |
| Cache too aggressive                           | `df.persist(MEMORY_AND_DISK)` or smaller cache                          |
| Broadcasted variable too big                   | Lower `spark.sql.autoBroadcastJoinThreshold`                            |
| Large `collect()` to driver                    | Replace with `write()` or `toLocalIterator()`                           |
| Memory overhead too low                        | `spark.executor.memoryOverhead` higher (default 10% of executor memory)|
| Container OOM (YARN/k8s killed)                | Both `spark.executor.memory` and `memoryOverhead` higher                |

---

## Section 5 — Plan / Strategy Issues

### Symptom

Even after fixing skew/spill/GC, things still feel slow. The plan itself is suboptimal.

### Common Plan Problems

| Symptom in SQL Tab                          | Issue                                                |
|----------------------------------------------|------------------------------------------------------|
| `SortMergeJoin` on a tiny table              | Should be Broadcast                                   |
| `PushedFilters: []` on a filter you wrote    | No predicate pushdown                                 |
| Multiple back-to-back `Exchange`             | Catalyst couldn't combine them                        |
| `Project` reading all columns                 | Column pruning not effective                          |
| `Sort` for a small dataset                    | Could be in-memory sort                               |
| `Cartesian` / `BroadcastNestedLoopJoin`       | Missing equi-join condition                           |

### Fixes

```python
# Force broadcast
df.join(broadcast(small_df), "k")

# Force more shuffle partitions
spark.conf.set("spark.sql.shuffle.partitions", "1000")

# Enable adaptive query execution
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
```

---

## The "What Should I Do First" Decision Tree

```
SLOW JOB
   |
   +-- Look at Stages tab
            |
            +-- Max/Median > 10 ?    -> SKEW (salt / AQE / broadcast)
            |
            +-- Spill > 0 ?           -> SPILL (more memory / smaller partitions)
            |
            +-- GC > 10 % ?           -> GC (less cache / G1GC)
            |
            +-- Big Shuffle ?
            |       |
            |       +-- Tiny dim table SMJ ?  -> BROADCAST
            |       +-- Wrong partitions ?     -> ↑ shuffle.partitions
            |       +-- Repeated shuffle ?    -> Plan rewrite
            |
            +-- Failed Tasks > 0 ?    -> OOM (memory / overhead)
```

---

## Field Heuristics (Production-Tested)

```
1. "Max task time > 10x median" -> always skew until proven otherwise.
2. "Spill > 0" + "GC > 10%"      -> double-trouble; raise memory first.
3. "200 tasks but data 50MB"     -> reduce shuffle.partitions to 8-16.
4. "Driver OOM on small cluster"  -> stop using collect / toPandas.
5. "Job took 2x longer after upgrade" -> AQE got enabled by default.
6. "show() suddenly slow"        -> sparse data; tune limit.initialNumPartitions.
7. "Cache works locally but not in prod" -> bigger data; switch to MEMORY_AND_DISK.
8. "Pipeline OOM only at end"    -> final write trying to collect partitions; coalesce(N).
```

---

## Interview Cheat Sheet (Use These Verbatim)

> **"How would you debug a slow Spark job?"**
>
> *"I start at the Jobs tab to find the slow job, then drill into its Stages tab. In the Summary Metrics for tasks, I check the Min/Median/Max duration — if Max is more than 10× Median, it's data skew, and I'd fix with salting or AQE skew join. If I see non-zero Spill (Memory/Disk), execution memory is too small — I increase `spark.executor.memory` or repartition before the shuffle. I check Executors tab for GC ratio; if over 10%, the heap is pressured by cache or UDFs. Finally, I open the SQL tab to verify the plan — making sure the right join strategy is chosen and predicate pushdown happened."*

> **"Why did `df.show()` create 3 jobs?"**
> See Pattern 03 verbatim answer.

> **"What does 'skipped' mean in Jobs tab?"**
>
> *"Skipped means a stage's output was already produced by a prior job in the same application — either as shuffle output on local disk or via a cached DataFrame. Spark reuses that output for free. In the UI, `7 / 23 (16 skipped)` means 7 tasks ran new work and 16 were reused."*

---

## Common Mistakes

| Mistake                                              | Why                                                       | Fix                                                                  |
|------------------------------------------------------|-----------------------------------------------------------|----------------------------------------------------------------------|
| Throwing more memory at every problem                | Often the issue is plan / partitioning                    | Always check Skew + Plan first                                       |
| Tuning shuffle.partitions blindly                    | Wrong number causes spill or excess parallelism           | Aim for ~128 MB per partition                                         |
| Over-using `cache()` "just in case"                  | Cache misuse causes GC and eviction                       | Cache only DataFrames used in 2+ actions                              |
| Confusing GC time with task time                     | High GC eats into task time                                | Sum task time across stages and divide                                |
| Treating one slow task as bad luck                   | Often it's the *signal* of skew                            | Always check Max vs Median                                            |
| Leaving AQE off in 3.x                               | Misses free coalesce + skew handling                       | Enable AQE unless you have a specific reason                          |

---

## Worked Example — End-to-End Diagnosis

**Scenario**: Pipeline takes 60 minutes; expected 5 minutes.

```
1. Jobs tab:
   - Job 7: 50 minutes (write at line:42).  -> our culprit.

2. Stages tab (inside Job 7):
   - Stage 11: 48 min, Tasks 198/200, Spill 12 GB, GC 600s.
   - Summary: Min 5s, Median 8s, Max 1800s.

3. Diagnosis:
   - Max/Median = 225 → severe skew.
   - Spill 12 GB → memory tight.
   - GC 600s → cache pressure.

4. Cross-check:
   - SQL tab: SortMergeJoin on a 50MB dim_country table.
   - Storage tab: 6 cached dfs, 80% fraction (eviction happening).

5. Fixes (in priority):
   - broadcast(dim_country) -> kills SMJ, no shuffle for that side
   - .config("spark.sql.adaptive.skewJoin.enabled", "true") -> handles remaining skew
   - Unpersist 4 unused caches -> frees memory
   - Increase spark.executor.memory from 4g to 8g -> handles spill
   - Re-run: 4 minutes. Done.
```

---

## Cross-References

| Topic                                       | Pattern |
|---------------------------------------------|---------|
| Reading Summary Metrics                     | 04      |
| Identifying broadcast vs SMJ                | 06      |
| Checking executor health                    | 07      |
| Configs that affect plan                    | 06, 07  |

---

## Key Takeaway

> The 4 main villains: **Skew, Spill, GC, OOM**.
> The order of investigation: **Jobs → Stages → Task Summary → Executors → SQL**.
> Most slow jobs are *not* about machine size — they're about partitioning, plan choice, and caching discipline.
> Master this pattern and you become the person on the team who debugs the prod incidents in 10 minutes.
