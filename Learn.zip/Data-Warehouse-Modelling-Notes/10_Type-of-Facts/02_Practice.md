# Types of Facts (Additive, Semi-Additive, Non-Additive) — Practice

> "Additivity is not a property of SQL; it is a property of the metric and the grain."

---

## Quick Recall

**Q:** What is an additive fact in retail?  
**A:** A measure that can be summed across all dimensions—example: `net_sales_amount` across time, store, and product.

**Q:** What is a semi-additive fact?  
**A:** Summable across some dimensions but not others—classic: `inventory_on_hand` across products, not across time without taking an endpoint snapshot.

**Q:** What is a non-additive fact?  
**A:** A measure that should not be naively summed—example: `average_selling_price` at mixed grains.

**Q:** What are common additive retail facts?  
**A:** `units_sold`, `gross_sales`, `discount_amount`, `tax_amount`.

**Q:** How do you safely report inventory over a month?  
**A:** Use daily snapshots and `MAX` or `AVG` by policy on time, or end-of-month snapshot fact designed for semi-additive logic.

---

## Interview Questions

**1. Define additive, semi-additive, and non-additive with retail examples.**  
**Model answer:** Additive: sum `net_sales` by week and region. Semi-additive: sum `on_hand_units` across SKUs for a chosen `snapshot_date`, but never sum across multiple snapshot dates in one row without taking last day. Non-additive: `conversion_rate` is a ratio; sum numerators and denominators separately, then divide. I always tie the definition to grain.

**2. Why is margin sometimes tricky?**  
**Model answer:** Dollar margin can be additive at consistent line grain if defined as `net_sales - cost`. Margin percent is non-additive; compute from aggregated components. Mixed currencies make margin even trickier without a single reporting currency.

**3. How do you model semi-additive inventory for stores and DCs?**  
**Model answer:** A periodic snapshot fact at `store_sku_date` grain with `on_hand_units`, documented that totals across time use `last_day_of_month` logic via window functions or a monthly closing snapshot table. DC and store should not be mixed without a location dimension roll-up rule.

**4. What mistake do BI tools encourage with ratios?**  
**Model answer:** Averaging of averages—users drag average basket size to a higher level. Fix with base measures `total_sales` and `order_count`, ratio at query time. I add semantic layer protections where possible.

**5. Are distinct counts additive?**  
**Model answer:** No. Distinct customers across weeks double-counts shoppers who appear in multiple weeks; use careful approximation or push to tools that handle count distinct rollups correctly. For executive views, define "unique customers in period" at the period grain explicitly.

**6. How do you document additivity for self-service users?**  
**Model answer:** Metric catalog entries list additive dimensions, semi-additive rules, and safe aggregation functions (SUM versus AVG versus none). Include example SQL snippets for semi-additive inventory to reduce misuse.

**7. Gift card liability example**  
**Model answer:** Ending liability is semi-additive across time; changes in liability may be additive flows (issuance, redemption) modeled as separate additive facts. Finance distinguishes stock versus flow measures.

**8. How do you explain semi-additivity to a store manager?**  
**Model answer:** "You can add inventory across aisles at closing tonight, but you cannot add tonight's count to yesterday's count and call it meaningful inventory—you need a rule like end-of-week snapshot."

---

## Scenario-Based Exercises

**Scenario 1 — Executive wants sum of daily average basket**  
**Solution:** Explain non-additivity; instead provide `SUM(net_sales) / COUNT(DISTINCT order_id)` over the requested period.

```sql
SELECT SUM(net_sales_amount) / NULLIF(COUNT(DISTINCT order_id), 0) AS avg_basket
FROM dw.fact_sales
WHERE order_date BETWEEN DATE '2025-11-01' AND DATE '2025-11-30';
```

**Scenario 2 — Inventory accuracy audit**  
**Solution:** Snapshot at `location_sku_day`; monthly reporting uses end-of-month selection per location.

```sql
SELECT location_id,
       SUM(on_hand_units) AS eom_on_hand
FROM dw.fact_inventory_snapshot
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY location_id, DATE_TRUNC('month', snapshot_date)
  ORDER BY snapshot_date DESC
) = 1
GROUP BY location_id;
```

**Scenario 3 — Web sessions and orders**  
**Solution:** Model additive `fact_orders`; keep session counts separate; do not sum session counts into revenue totals. If a blended funnel KPI is needed, define it as a ratio with explicit components.

**Scenario 4 — Customers across stores and marketplace GMV**  
**Solution:** Sales remain additive across stores; distinct customer counts need explicit scope because "customers who purchased" differs from "customer-store pairs." For marketplaces, GMV and platform revenue are different additive measures at their respective grains; take rate is a ratio derived after aggregation, not summed from line-level rates without weights.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Summing inventory across days | Classic semi-additive error | State snapshot semantics explicitly |
| Averaging percentages | Looks intuitive | Recompute from sums |
| Treating distinct count like SUM | BI tools hide the issue | Define period-level distinct logic |
| Mixing grains in one fact | Breaks all rules | Split facts or document allocation |
| Using LAST_VALUE without ordering | Wrong snapshot | Specify ordering keys and ties |
| Confusing flow and stock measures | Inventory errors | Separate issuance facts from snapshot balances |

---

## One-Liner Answers

- Additive facts can be summed across all relevant dimensions, like sales dollars and units.
- Semi-additive facts sum across some dimensions only, like inventory across SKUs at one date.
- Non-additive facts require formulas after aggregation, like ratios and distinct counts.
- Always define the grain before deciding which aggregations are valid.
- Snapshot facts carry semi-additive inventory; flow facts carry additive receipts and shipments.
- Margin dollars may be additive at line grain; margin percent is not additive across lines.
- Document safe aggregations in the metric catalog to protect self-service retail users.
