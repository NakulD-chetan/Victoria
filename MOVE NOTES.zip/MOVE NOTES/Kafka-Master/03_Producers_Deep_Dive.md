# 3. Producers — Deep Dive

> **Permanent Recall Note:** The **producer** batches records, picks **partition** (key/partitioner), compresses, and waits for **acks** according to durability/latency trade-offs. Production pipelines need explicit **retries**, **idempotence** for EOS foundations, and **buffer** tuning — otherwise you get duplicates, timeouts, or OOM. Spark batch writes to Kafka use similar ideas via DataFrame writer options — mentally map to [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

### The 10-Second Summary
- **Batching:** `linger.ms` + `batch.size` trade latency vs throughput.
- **Compression:** `lz4`, `snappy`, `gzip`, `zstd` — CPU vs bytes on wire.
- **Acks:** `0` fire-and-forget, `1` leader, `all` ISR-safe (with min.insync.replicas).
- **Idempotent producer:** PID + sequence — dedupe on broker; pairs with transactions for EOS.

---

# 3.1 Producer Architecture (Mental Model)

```
┌─────────────────────────────────────────────────────────────┐
│  Serializer → Partitioner → RecordAccumulator (per partition) │
│       │                         │                            │
│       │                    batches (linger/size)             │
│       ▼                         ▼                            │
│  Sender thread ─────► Network client ─────► Broker leader   │
└─────────────────────────────────────────────────────────────┘
```

💡 **Key Insight:** **Accumulator** is **memory-bound** — tune `buffer.memory` vs batch pressure.

---

# 3.2 Batching — linger.ms & batch.size

| Config | Effect |
|--------|--------|
| `linger.ms` | Wait to fill batch — **higher** = better packing, **more latency** |
| `batch.size` | Upper bound per batch in **bytes** — not a minimum |

🔄 **Trade-off:** Low-latency services → small linger; bulk ingestion → higher linger + bigger batch.

---

# 3.3 Compression — Producer Side

```properties
compression.type=lz4   # or snappy, gzip, zstd, none
```

🏗️ **Real-World:** **lz4/snappy** common for balanced CPU; **zstd** when network is tight and CPU available.

---

# 3.4 Acknowledgments — acks

| acks | Semantics | Risk |
|------|-----------|------|
| **0** | No wait | **Loss** on failure |
| **1** | Leader persisted (old mental model: leader ack) | Loss if leader dies before replication |
| **all** | Wait per ISR policy | **Safest** with `min.insync.replicas` |

📏 **Golden Rule:** `acks=all` + `min.insync.replicas>=2` for **durability** stories in interviews.

---

# 3.5 Retries & Idempotent Producer

```properties
retries=2147483647               # effectively unlimited in modern clients with idempotence
enable.idempotence=true        # sets safe defaults (acks=all, retries, max.in.flight<=5 in 3.x)
```

- **Without idempotence:** retries can **duplicate** on the log.
- **Idempotent:** broker tracks **Producer ID + sequence** per partition.

⚠️ **Warning:** Idempotence covers **producer session** — **not** end-to-end EOS without transactions + consumer side.

---

# 3.6 Key Serialization

```java
props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
    "org.apache.kafka.common.serialization.StringSerializer");
props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
    "io.confluent.kafka.serializers.KafkaAvroSerializer");
```

💡 **Key Insight:** **Schema Registry** + Avro/Protobuf for values — keys often string/bytes.

---

# 3.7 Partitioner Logic

- Default: **murmur2** hash of key → partition.
- Custom `Partitioner` for **priority** topics or **geographic** routing.

---

# 3.8 Producer Callbacks & Error Handling

```java
producer.send(record, (metadata, exception) -> {
    if (exception != null) {
        // classify: retriable vs fatal
    } else {
        // success: topic/partition/offset
    }
});
```

🎯 **Interview Tip:** **Retriable** (`NetworkException`, some timeouts) vs **fatal** (serialization, message too large).

---

# 3.9 Exactly-Once Producer (Idempotent + Transactional)

```java
props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, "my-tx-id");
KafkaProducer<String, String> p = new KafkaProducer<>(props);
p.initTransactions();
p.beginTransaction();
try {
    p.send(record1);
    p.sendOffsetsToTransaction(...); // with consumer, EOS read-process-write
    p.commitTransaction();
} catch (Exception e) {
    p.abortTransaction();
}
```

- **Transactional ID** → fencing of zombie producers via epoch bump.

---

# 3.10 max.in.flight.requests.per.connection

- **Higher** → more pipelining, **more reorder risk** on retry without idempotence.
- Idempotent producer caps sensibly — **ordering** preserved for single partition in typical settings.

🔥 **Pro Tip:** For strict ordering + retries, **idempotence** + conservative in-flight — read Confluent docs for your exact client version.

---

# 3.11 Buffer Memory Management

```properties
buffer.memory=33554432    # 32MB default ballpark — tune per JVM
```

- **BufferExhaustedException** → slow network or broker; tune batch/linger or scale brokers.

---

# 3.12 CLI — Producer perf sanity

```bash
kafka-producer-perf-test.sh \
  --topic test --num-records 1000000 --record-size 1000 --throughput -1 \
  --producer-props bootstrap.servers=localhost:9092 acks=all linger.ms=10 batch.size=65536
```

---

# 3.13 Interview Questions & Answers

**Q: linger.ms badhaoge to kya hoga?**  
**A:** Throughput often **up**, p99 latency **up** — batching zyada fill hota hai.

**Q: acks=all phir bhi message lost?**  
**A:** Possible if **ISR=1** and min.insync misconfigured — or producer **timeout** before commit.

**Q: Idempotent duplicate kab possible?**  
**A:** Broker-level duplicates **deduped** for same PID+seq; **application** retries with **new** producer session need dedupe keys downstream.

**Q: Spark to Kafka write mein kya dhyaan?**  
**A:** `checkpointLocation`, delivery guarantees mode, often **at-least-once** + idempotent sink — align with Spark streaming semantics in [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 3 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 linger + batch.size = throughput vs latency             │
│  🧠 acks=all + min.insync = durability story                  │
│  🧠 enable.idempotence = dedupe broker-side                 │
│  🧠 Transactions = EOS read-process-write pattern           │
│  ⚠️  buffer.memory exhaustion = backpressure signal          │
│  🎯 Classify retriable vs fatal errors in callbacks         │
└─────────────────────────────────────────────────────────────┘
```
