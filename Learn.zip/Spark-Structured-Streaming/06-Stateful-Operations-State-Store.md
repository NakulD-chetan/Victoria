# Stateful Operations & State Store

Stateful streaming operators **remember** information across micro-batches: aggregations keyed by group, session buffers, join state, etc. Spark persists this **state** durably via **checkpointing** (see note 07). This note focuses on **what** state is and **how** it behaves.

---

## 1. Stateless vs Stateful

| Class | Examples | Needs cross-batch memory? |
| ----- | -------- | ------------------------- |
| **Stateless** | `filter`, `select`, `map`-like ops | No—each row processed from current batch + optional broadcast side inputs. |
| **Stateful** | `groupBy` aggregations, windowed agg, `dropDuplicates` with watermark, stream joins | Yes—**keyed state** updated every trigger. |

---

## 2. What Is Stored in State?

Conceptually, **key-value** structures:

| Operator | State content (simplified) |
| -------- | -------------------------- |
| **Running aggregation** | Per-key partial aggregates (counts, sums, min/max sketches). |
| **Window aggregation** | Per-window buckets still receiving data before watermark closure. |
| **Session windows** | Active sessions keyed by session id or grouping keys. |
| **Stream–stream join** | Rows in a buffer keyed such that they can **match** future rows from the other side within time bounds. |

State grows with **number of active keys** and **retention** dictated by watermarks and join intervals.

---

## 3. State Backend (Execution View)

Executors hold **state partitions** aligned with **task partitioning** (often shuffle partitions). On each micro-batch:

1. **Read** delta input.
2. **Join** delta with **existing state** for affected keys.
3. **Write back** updated state.
4. **Spill** to disk if memory pressure exceeds thresholds.

The **authoritative** durable copy is **checkpointed** to reliable storage so restart can **replay** from consistent offsets + state snapshot.

---

## 4. State and Shuffle

Wide operators introduce **shuffle**; state is keyed consistently so that all updates for a logical key land on the **same** partition (similar intuition to batch `groupBy`).

**Implication:** `spark.sql.shuffle.partitions` (and streaming analogs) affects **parallelism** and **task granularity** of stateful work.

---

## 5. mapGroupsWithState / flatMapGroupsWithState (Conceptual)

Beyond declarative `groupBy`, Spark offers **custom stateful** handlers:

- You define **schema of state** per key group.
- Each trigger, Spark invokes your logic with **previous state** + **new rows** for that group.
- Enables **custom sessions**, complex transitions, and integrations not expressible in pure SQL.

Correctness still depends on **checkpoint** + **idempotent** effects if touching external systems.

---

## 6. Memory Pressure and Spill

When keyed state exceeds executor memory:

- Data **spills** to disk (performance hit).
- Extreme skew can create **hot partitions**—one key dominates.

Mitigations include **salting** keys (advanced), **repartitioning** upstream, increasing resources, or tightening **watermarks** / join bounds to **expire** state sooner.

---

## 7. Key Takeaways

1. **Stateful** operators are why streaming is more than “batch on small chunks”—they **accumulate** information over time.
2. State is **partitioned** and **checkpointed**; executors are caches of live working sets.
3. **Watermarking** and **join time bounds** are primary levers to **cap** state size.
4. Custom **group state** APIs trade flexibility for **implementation responsibility** (timers, eviction, external side effects).

---
