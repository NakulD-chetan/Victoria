# Python FAANG Interview Must-Know

> *"Know your data structures' complexity — list vs set vs dict"* — Interview reality

This file covers patterns and tools that show up often in FAANG-style Python interviews: **LeetCode-style mindset**, **time complexity of common ops**, **`collections`**, **`heapq`**, **`bisect`**, and **gotchas**. Theory base: [[06-Python-Strings-Collections]] through [[16-Python-Advanced-Topics]].

---

## 1. Top 15 Python-Friendly Problem Patterns (names + idea)

> **Definition:** Coding patterns are reusable solution shapes (two pointers, heaps, graphs, DP) that map common interview problems to known algorithms and data structures.

**Why we need it:** Recognizing the pattern cuts search time in interviews and production; Python’s stdlib (`deque`, `heapq`, `Counter`) lines up with those patterns.

**Syntax:**
```text
Problem shape → pattern name → typical structure (e.g. BFS: deque + visited set)
```

| # | Pattern | Python angle |
|---|---------|--------------|
| 1 | Two pointers | List sorted — `l`, `r` |
| 2 | Sliding window | `deque` / index window |
| 3 | Binary search on answer | `bisect`, custom `check(mid)` |
| 4 | BFS/DFS graph | `deque`, `set` visited, adjacency `dict` |
| 5 | Topological sort | Kahn / DFS, `defaultdict(list)` |
| 6 | Union-Find | List/dict parent, path compression |
| 7 | Heap / top-K | `heapq` min-heap, negate for max |
| 8 | Trie | Nested `dict` nodes |
| 9 | DP tabulation | List of lists, sometimes `@lru_cache` top-down |
| 10 | Greedy + sorting | `sort` with `key=` |
| 11 | Prefix sum | `itertools.accumulate` or manual |
| 12 | Hash map frequency | `Counter`, `defaultdict(int)` |
| 13 | Stack for parentheses | `list` as stack |
| 14 | Monotonic stack/queue | `deque` pattern |
| 15 | Intervals merge/sweep | sort by start, linear scan |

**Interview Tip:** First state **brute force complexity**, then optimize — communication counts.

---

## 2. Time complexity — Python operations (typical CPython)

> **Definition:** Time complexity describes how operation cost grows with input size (e.g. O(1), O(n), O(n log n)) for typical CPython implementations of built-in types.

**Why we need it:** Choosing `list` vs `set`, where you insert, and nested loops determines whether a solution passes constraints; interviewers expect you to state and justify complexity.

**Syntax:**
```text
O(1)   constant
O(n)   linear
O(n log n)  typical optimal sort / divide-and-conquer
```

| Operation | Average | Worst notes |
|-----------|---------|-------------|
| `x in list` | O(n) | linear scan |
| `x in set` / `x in dict` | O(1)* | hash collisions rare |
| `list.append` | O(1) amortized | |
| `list.insert(0, x)` | O(n) | shifting |
| `del list[0]` | O(n) | use `deque` for left pops |
| `dict[key]` get/set | O(1)* | |
| `sort()` (Timsort) | O(n log n) | |

\* Average case for hashing; adversarial inputs can have worse theoretical worst case — usually OK in interviews.

**Watch Out!** `list` membership inside a loop = hidden O(n²).

---

## 3. `collections` module — must know

> **Definition:** The `collections` module adds specialized containers: `Counter` for frequencies, `defaultdict` for missing-key defaults, `deque` for fast two-ended queues, and `OrderedDict` for order-aware dict operations.

**Why we need it:** Interview and production code repeatedly needs counts, adjacency lists, and O(1) pops from both ends; these types are faster and clearer than manual `dict` + existence checks.

**Syntax:**
```python
from collections import Counter, defaultdict, deque, OrderedDict

c = Counter(<iterable>)
d = defaultdict(<factory>)   # e.g. list, int
q = deque()
od = OrderedDict()
```

### `Counter`

```python
from collections import Counter
c = Counter("abracadabra")   # Counts each letter → {'a':5, 'b':2, 'r':2, 'c':1, 'd':1}
c.most_common(3)              # Top 3 most frequent → [('a',5), ('b',2), ('r',2)]
c["a"] += 1                   # Manually increase count of 'a' by 1
c["z"]                        # 0 → missing keys return 0 (no KeyError!)
```

### `defaultdict`

```python
from collections import defaultdict

g = defaultdict(list)   # If key missing, auto-creates empty list []
g[1].append(2)          # No KeyError! Auto-creates g[1]=[], then appends 2

cnt = defaultdict(int)  # If key missing, auto-creates 0
for x in items:
    cnt[x] += 1         # No need to check "if x in cnt" — auto-starts from 0
```

### `deque`

```python
from collections import deque
q = deque()           # Double-ended queue — fast add/remove from BOTH ends
q.append(1)           # Add to RIGHT end → deque([1])
q.appendleft(0)       # Add to LEFT end → deque([0, 1])
q.pop()               # Remove from RIGHT end → returns 1
q.popleft()           # Remove from LEFT end → returns 0 (FAST — O(1)!)
# Regular list: pop(0) is O(n) slow. deque: popleft() is O(1) fast!
```

### `OrderedDict`

```python
from collections import OrderedDict
# 3.7+ dict ordered anyway — still useful for LRU-style move_to_end patterns
```

**Interview Tip:** **LRU Cache** design — `OrderedDict` + capacity or `functools.lru_cache` discussion.

---

## 4. `heapq` — min-heap (list-backed)

> **Definition:** `heapq` implements a binary min-heap as a list where `heap[0]` is always the smallest element; push/pop maintain the heap invariant in O(log n).

**Why we need it:** Top-K, merging sorted streams, and scheduling problems need repeated min/max without full sorts; Python’s heap is the standard interview tool for those.

**Syntax:**
```python
import heapq

h = []
heapq.heappush(h, <item>)
heapq.heappop(h)
heapq.heapify(<list>)
heapq.nlargest(k, <iterable>)
heapq.nsmallest(k, <iterable>)
```

```python
import heapq

h = []
heapq.heappush(h, 3)     # Adds 3 to heap → [3]
heapq.heappush(h, 1)     # Adds 1 to heap → [1, 3] (smallest stays at top)
heapq.heappop(h)          # Removes and returns SMALLEST → 1

nums = [4, 1, 7, 3]
heapq.nlargest(2, nums)   # [7, 4] → top 2 BIGGEST numbers
heapq.nsmallest(2, nums)  # [1, 3] → top 2 SMALLEST numbers

# For MAX heap (biggest first), negate values:
heapq.heappush(h, -5)     # Push -5 (actually storing 5 as max)
-heapq.heappop(h)         # Pop and negate back → 5
```

**Quick summary:**
- **heappush** = add item, keeps smallest at top
- **heappop** = remove and return the smallest item
- **nlargest/nsmallest** = get top K biggest/smallest items
- Python only has MIN heap — for MAX heap, negate values

**Watch Out!** `heap[0]` is smallest — the full list is **not** sorted.

---

## 5. `bisect` — binary search on sorted list

> **Definition:** The `bisect` module binary-searches a sorted sequence to find insertion positions (`bisect_left` / `bisect_right`) or insert while preserving order (`insort`).

**Why we need it:** Sorted-array problems, “how many values ≤ x,” and maintaining a sorted list for queries need O(log n) lookup instead of linear scans.

**Syntax:**
```python
import bisect

i = bisect.bisect_left(<sorted_list>, <x>)
j = bisect.bisect_right(<sorted_list>, <x>)
bisect.insort(<sorted_list>, <x>)
```

```python
import bisect

a = [1, 3, 3, 5, 7]
bisect.bisect_left(a, 3)    # 1 → position where 3 would go (BEFORE existing 3s)
bisect.bisect_right(a, 3)   # 3 → position where 3 would go (AFTER existing 3s)
bisect.insort(a, 4)         # Inserts 4 into sorted position → [1, 3, 3, 4, 5, 7]
```

**Quick summary:**
- **bisect_left** = find where to insert (before duplicates) — binary search O(log n)
- **bisect_right** = find where to insert (after duplicates) — binary search O(log n)
- **insort** = insert while keeping list sorted (find is fast, but shifting is O(n))

**Interview Tip:** Sorted container + frequent inserts → discuss **BST** / **balanced tree** libs — not in Python stdlib, but good to know.

---

## 6. Common coding patterns — snippets

> **Definition:** These snippets are small, repeatable code shapes for frequencies, graphs, and BFS that you can drop into problems and adapt.

**Why we need it:** Under time pressure, you avoid reinventing boilerplate and focus on the problem-specific logic; interviewers recognize idiomatic Python.

**Syntax:**
```python
from collections import Counter, defaultdict, deque

freq = Counter(<iterable>)
g = defaultdict(list)
q, seen = deque([start]), {start}
```

### Frequency + bucket

```python
from collections import Counter
freq = Counter(nums)
```

### Graph adjacency

```python
from collections import defaultdict
g = defaultdict(list)
for u, v in edges:
    g[u].append(v)
```

### BFS skeleton

```python
from collections import deque

def bfs(start):
    q = deque([start])
    seen = {start}
    while q:
        u = q.popleft()
        for v in g[u]:
            if v not in seen:
                seen.add(v)
                q.append(v)
```

---

## 7. Gotchas — interview traps

> **Definition:** Gotchas are Python behaviors (mutable defaults, `is` vs `==`, shallow copies, small-int caching) that look right in quick code but fail in subtle ways.

**Why we need it:** Interviews explicitly test whether you understand object identity, argument binding, and copying—bugs here are common in real code too.

**Syntax:**
```python
def f(x, acc=None):
    if acc is None:
        acc = []
    ...

# equality vs identity
a == b
a is b
x is None

import copy
copy.deepcopy(<obj>)
```

### Mutable default argument

```python
def bad(x, acc=[]):  # DON'T
    acc.append(x)
    return acc
```

Fix: `acc=None` + new list inside.

### `is` vs `==`

```python
a = 1000; b = 1000
a is b  # maybe False — different objects
a == b  # True

x = None
x is None  # preferred check
```

### Shallow vs deep copy

```python
import copy
a = [[1]]
b = list(a)
b[0].append(2)   # a also changes
c = copy.deepcopy(a)
```

### Integer caching

Small ints `-5..256` are often reused — `is` may accidentally work — **don't rely on it**.

**Interview Tip:** Read [[notes]] for memory model — `id`, interning, refcount.

---

## 8. `enumerate`, `zip`, unpacking — fast clean code

> **Definition:** `enumerate` yields index-value pairs, `zip` pairs iterables element-wise, and unpacking assigns multiple names from iterables or function returns in one step.

**Why we need it:** Loops and data pairing stay readable without manual index counters; `divmod` and tuple unpacking reduce noise in numeric and interview code.

**Syntax:**
```python
for i, v in enumerate(<iterable>):
    ...

for a, b in zip(<iter1>, <iter2>):
    ...

x, y = <pair>
q, r = divmod(a, b)
```

```python
for i, v in enumerate(arr):    # Gives (index, value) — no need for manual counter
    print(i, v)

pairs = list(zip(keys, vals))  # Pairs up two lists → [(k1,v1), (k2,v2), ...]
a, b = divmod(7, 3)            # Returns (quotient, remainder) → a=2, b=1
```

---

## 9. When to use what — FAANG cheat

> **Definition:** This cheat sheet maps common needs (frequency, graph storage, top-K, membership) to the right Python built-in or `collections` type.

**Why we need it:** Picking the wrong structure (e.g. `list` for membership in a hot loop) fails complexity requirements; the table is a quick sanity check before coding.

**Syntax:**
```text
Need X → use Y (know big-O for get/insert/membership)
```

| What you need | What to use | Why |
|------|-----|-----|
| Count how often items appear | `Counter` | Built for frequency counting |
| Store graph edges | `defaultdict(list)` | Auto-creates empty list for new nodes |
| Fast add/remove from both ends | `deque` | O(1) on both sides (list is O(n) on left) |
| Find top K biggest/smallest | `heapq` | Efficient heap operations |
| Binary search on sorted list | `bisect` | O(log n) search |
| Remove duplicates / fast "is X in here?" | `set` | O(1) membership check |
| Fast key-value lookup | `dict` | O(1) get/set by key |

---

## 10. `deque` + sliding window template

> **Definition:** A monotonic deque sliding-window template keeps indices in `deque` order so the window’s max (or min) is always at one end in amortized O(n) over the array.

**Why we need it:** Naive “max of each window” is O(n·k); the deque pattern is the standard interview optimization for hard window problems.

**Syntax:**
```python
from collections import deque

dq = deque()  # store indices, maintain monotonic order on values
for i, x in enumerate(nums):
    while dq and <shrink_condition>:
        dq.pop()
    dq.append(i)
    if <window_ready>:
        <record nums[dq[0]]>
```

```python
from collections import deque

def window_max(nums, k):
    dq = deque()
    out = []
    for i, x in enumerate(nums):
        while dq and nums[dq[-1]] <= x:
            dq.pop()
        dq.append(i)
        if dq[0] == i - k:
            dq.popleft()
        if i >= k - 1:
            out.append(nums[dq[0]])
    return out
```

**Interview Tip:** Monotonic deque — pattern for hard problems; do a dry run.

---

## 11. Kahn topo sort skeleton — `defaultdict` + `deque`

> **Definition:** Kahn’s algorithm repeatedly removes nodes with zero in-degree and relaxes edges; a valid ordering exists iff all nodes are processed (DAG); cycle otherwise.

**Why we need it:** Course schedule, build order, and dependency problems reduce to topological sort; this skeleton is the queue-based form interviewers expect.

**Syntax:**
```python
from collections import defaultdict, deque

g = defaultdict(list)
indeg = {v: 0 for v in nodes}
# build g, indeg from edges
q = deque([u for u in nodes if indeg[u] == 0])
order = []
while q:
    u = q.popleft()
    order.append(u)
    for v in g[u]:
        indeg[v] -= 1
        if indeg[v] == 0:
            q.append(v)
# cycle if len(order) != len(nodes)
```

```python
from collections import defaultdict, deque

def topo_sort(edges):
    nodes = set()
    for u, v in edges:
        nodes.add(u)
        nodes.add(v)
    g = defaultdict(list)
    indeg = {x: 0 for x in nodes}
    for u, v in edges:
        g[u].append(v)
        indeg[v] += 1
    q = deque([u for u in nodes if indeg[u] == 0])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in g[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    if len(order) != len(nodes):
        raise ValueError("cycle")
    return order
```

**Watch Out!** `len(order) != len(nodes)` — verify cycle / disconnected handling.

---

## Quick Memory Card

```
+------------------------------------------+
| FAANG PATTERNS                            |
| - 2ptr, window, heap, graph, DP, trie    |
+------------------------------------------+
| COMPLEXITY                                |
| - list in: O(n)  set/dict in: O(1)*     |
| - sort: O(n log n)                       |
+------------------------------------------+
| COLLECTIONS                               |
| - Counter, defaultdict, deque            |
+------------------------------------------+
| HEAPQ                                     |
| - min-heap, nlargest/nsmallest           |
+------------------------------------------+
| BISECT                                    |
| - sorted list search/insert            |
+------------------------------------------+
| GOTCHAS                                   |
| - mutable default, is vs ==              |
| - shallow copy, None is check            |
+------------------------------------------+
```

---

*Next: [[notes]] (Memory Model) | Index: [[00-Index]]*
