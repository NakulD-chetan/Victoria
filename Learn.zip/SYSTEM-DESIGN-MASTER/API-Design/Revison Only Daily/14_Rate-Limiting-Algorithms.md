# Rate Limiting Algorithms — FAANG Revision Notes

---

## Why Rate Limiting? (Say This First in Interview)

> "Rate limiting protects APIs from abuse, ensures fair usage, prevents resource exhaustion, and defends against DDoS. It controls how many requests a client can make in a given time window."

---

## The 5 Algorithms — Know Cold

### 1. Token Bucket (Most Asked)

**How it works:** Bucket holds tokens. Each request costs 1 token. Tokens refill at a fixed rate. If empty → reject.

```
Bucket: capacity=10, refill_rate=2/sec

Request arrives → consume 1 token → ALLOW
Bucket empty   → DENY (429 Too Many Requests)
Tokens refill lazily on next request:
  new_tokens = elapsed_time × refill_rate
  tokens = min(tokens + new_tokens, capacity)
```

**Key properties:**
- Allows bursts (up to capacity)
- Memory: O(1) — just 4 fields (tokens, capacity, rate, last_refill_time)
- Lock-free via CAS (Compare-And-Swap) or simple mutex
- Used by: AWS API Gateway, Stripe

**FAANG follow-up:** "How do you make it thread-safe?"
- CAS loop: read old value → compute new → atomic swap if unchanged, else retry
- Simpler: mutex lock around refill + consume

---

### 2. Leaky Bucket

**How it works:** Requests enter a FIFO queue. Queue drains at a fixed rate. If queue full → reject.

```
Bursty input → [Queue (FIFO)] → Smooth output at fixed drain_rate
Queue full → DENY
```

**Key properties:**
- Smooths bursts (unlike token bucket which allows them)
- Memory: O(n) for queue-based, O(1) for timestamp variant
- Used by: NGINX (`limit_req` module), Shopify

**Token Bucket vs Leaky Bucket (Classic Interview Question):**

| Aspect | Token Bucket | Leaky Bucket |
|--------|-------------|--------------|
| Bursts | ALLOWS bursts | SMOOTHS bursts |
| Output | Variable/bursty | Fixed/smooth |
| Memory | O(1) | O(n) queue / O(1) timestamp |
| Best for | "Allow short bursts then steady rate" | "Strict constant rate (e.g., SMS)" |

---

### 3. Fixed Window Counter

**How it works:** Divide time into fixed windows (e.g., 1-min blocks). Count requests per window. Reset at window boundary.

```
Window 1 (0:00-0:59): count=10 → ALLOW up to limit
Window 2 (1:00-1:59): count=0  → Fresh start
```

**Key properties:**
- Simplest to implement
- Memory: O(1) — one counter per window
- Redis: `INCR key` + `EXPIRE key 60`

**Critical flaw (ALWAYS mention this):**
> Boundary burst problem: 10 requests at 0:59 + 10 requests at 1:00 = 20 requests in 1 second, even though limit is 10/min. Effective rate can be 2x the limit!

---

### 4. Sliding Window Log

**How it works:** Store timestamp of every request. On new request, count timestamps within the last window. If count >= limit → reject.

```
Now = 1:00:45, Window = 60s
Look at timestamps in [0:59:45 ... 1:00:45]
Count = 7 → ALLOW (under limit of 10)
```

**Key properties:**
- Most accurate — no boundary problem
- Memory: O(n) — stores every timestamp (expensive at scale!)
- Redis: Sorted Set (`ZADD`, `ZREMRANGEBYSCORE`, `ZCARD`)

**FAANG trade-off:** "Accurate but expensive. At 1000 req/min per user, that's 1000 entries per key."

---

### 5. Sliding Window Counter (Best Trade-off — Mention This)

**How it works:** Combines fixed window simplicity with sliding window accuracy using a weighted formula.

```
estimated_count = current_window_count + previous_window_count × overlap_fraction

overlap_fraction = time_remaining_in_current_window / window_size

Example: 25 sec into current window
  overlap = (60-25)/60 = 0.583
  count = 5 + 8 × 0.583 ≈ 9.67 → under 10 → ALLOW
```

**Key properties:**
- Memory: O(1) — just two counters
- Good accuracy (slight over-estimation = conservative, which is fine)
- Best balance of accuracy vs memory

---

## Algorithm Comparison — One Table to Rule Them All

| Algorithm | Memory | Accuracy | Burst Handling | Complexity | Use When |
|-----------|--------|----------|----------------|------------|----------|
| Token Bucket | O(1) | Good | Allows bursts | Low | General APIs, need burst tolerance |
| Leaky Bucket | O(n)/O(1) | Good | Smooths bursts | Low | Strict rate (messaging, SMS) |
| Fixed Window | O(1) | Poor (2x at boundary) | No control | Very Low | Simple, non-critical |
| Sliding Log | O(n) | Exact | Perfect | Medium | When accuracy is critical |
| Sliding Counter | O(1) | Very Good | Good | Low | Production — best trade-off |

---

## Distributed Rate Limiting (Always Asked as Follow-up)

### The Problem
Multiple API servers → each has its own counter → user hits different servers → limit is effectively N × limit.

### The Solution: Redis + Lua

```
All API Servers → single Redis instance → source of truth
```

**Why Lua?** Without atomicity:
```
Server A: reads count=99, allows, writes 100
Server B: reads count=99 (before A writes), allows, writes 100
Result: 101 requests allowed — OVER LIMIT!
```
Lua script runs atomically inside Redis — no interleaving possible.

**Redis Cluster gotcha:** Use hash tags `{user:123}` so all keys for a user land on the same slot/node. Lua scripts touching keys on different nodes will error.

**Latency cost:** ~1-3 ms per request (Redis round-trip + Lua execution).

### Local vs Global Rate Limiting

| Approach | Accuracy | Latency | When to Use |
|----------|----------|---------|-------------|
| Local only | Poor (N×limit) | Zero | Internal services, non-critical |
| Redis + Lua | Exact | 1-3 ms | Production APIs, billing-sensitive |
| Local + periodic sync | Approximate | Low | Slightly over-limit OK (e.g., 105 vs 100) |

---

## Rate Limiting Layers (Know All 5)

| Layer | Key Used | Example |
|-------|----------|---------|
| Per-IP | Client IP / X-Forwarded-For | DDoS protection |
| Per-User | user_id from JWT/session | Fair usage |
| Per-API-Key | API key header | Tiered pricing (free vs paid) |
| Per-Endpoint | method + path | Protect expensive endpoints |
| Global | Single counter | Entire system protection |

Combined key example: `ratelimit:ip:1.2.3.4:path:/api/orders`

---

## Response Headers (Must Know for API Design Questions)

```
HTTP/1.1 429 Too Many Requests

X-RateLimit-Limit: 100          ← max requests per window
X-RateLimit-Remaining: 0        ← requests left
X-RateLimit-Reset: 1710345660   ← Unix timestamp when window resets
Retry-After: 45                 ← seconds to wait before retrying
```

---

## FAANG Interview Quick-Fire Answers

**Q: "Design a rate limiter"**
→ Start with Token Bucket (most versatile), mention sliding window counter as alternative.

**Q: "How to handle distributed rate limiting?"**
→ Redis + Lua for atomic ops. All servers talk to one Redis. Lua prevents race conditions.

**Q: "Token bucket vs leaky bucket?"**
→ Token bucket allows bursts up to capacity. Leaky bucket enforces strict constant rate. Pick based on whether bursts are OK.

**Q: "What's wrong with fixed window?"**
→ Boundary burst: 2x the limit can pass at window edges. Fix with sliding window.

**Q: "How to rate limit at scale?"**
→ Redis cluster with hash tags, connection pooling, consider local counters with periodic sync for lower latency.

**Q: "What HTTP status code for rate limiting?"**
→ 429 Too Many Requests. Include Retry-After header.

**Q: "Where should rate limiting live?"**
→ API Gateway layer (Kong, NGINX, AWS API Gateway). Can also add application-level for fine-grained control.

---

## 30-Second Recall Box

```
TOKEN BUCKET   → tokens refill at fixed rate, allows bursts, O(1), CAS for thread-safety
LEAKY BUCKET   → FIFO queue, fixed drain, smooths traffic, strict rate
FIXED WINDOW   → counter per time block, simple but 2x boundary burst problem
SLIDING LOG    → store every timestamp, exact but O(n) memory, Redis sorted set
SLIDING COUNTER→ weighted formula (current + prev × overlap), O(1), best trade-off
DISTRIBUTED    → Redis + Lua = atomic, no race conditions, ~1-3ms overhead
LAYERS         → per-IP, per-user, per-API-key, per-endpoint, global
HEADERS        → X-RateLimit-Limit, Remaining, Reset, Retry-After
STATUS CODE    → 429 Too Many Requests
```

---
