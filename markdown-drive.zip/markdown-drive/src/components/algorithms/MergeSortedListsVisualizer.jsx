import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const MergeListsCanvas = forwardRef(function MergeListsCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ a: [], b: [], i: 0, j: 0, res: [], phase: '' });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function row(vals, sel, y, label) {
      ctx.fillStyle = '#57534e';
      ctx.font = '600 10px -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(label, 18, y - 14);
      vals.forEach((v, idx) => {
        const x = 80 + idx * 54;
        ctx.fillStyle = sel === idx ? '#ffd43b' : '#e0e7ff';
        ctx.strokeStyle = '#1c1917';
        ctx.beginPath();
        ctx.roundRect(x, y, 44, 30, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1c1917';
        ctx.font = 'bold 12px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(String(v), x + 22, y + 19);
      });
    }
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 300;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { a, b, i, j, res, phase } = stateRef.current;
      row(a, i, 60, 'List A');
      row(b, j, 130, 'List B');
      ctx.fillStyle = '#57534e';
      ctx.font = '600 10px -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('Result', 18, 210);
      res.forEach((v, idx) => {
        const x = 80 + idx * 54;
        ctx.fillStyle = '#b2f2bb';
        ctx.strokeStyle = '#14532d';
        ctx.beginPath();
        ctx.roundRect(x, 224, 44, 30, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#14532d';
        ctx.font = 'bold 12px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(String(v), x + 22, 243);
      });
      if (phase) {
        ctx.fillStyle = '#44403c';
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(phase, W / 2, 20);
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function generateSteps(a, b) {
  const steps = [];
  let i = 0;
  let j = 0;
  const res = [];
  steps.push({ type: 'init', a: [...a], b: [...b], i, j, res: [...res], phase: 'Compare heads' });
  while (i < a.length && j < b.length) {
    steps.push({ type: 'compare', a: [...a], b: [...b], i, j, res: [...res], phase: `min(${a[i]}, ${b[j]})` });
    if (a[i] <= b[j]) {
      res.push(a[i]);
      i++;
    } else {
      res.push(b[j]);
      j++;
    }
    steps.push({ type: 'append', a: [...a], b: [...b], i, j, res: [...res], phase: 'Append smaller' });
  }
  while (i < a.length) {
    res.push(a[i]);
    i++;
    steps.push({ type: 'drain-a', a: [...a], b: [...b], i, j, res: [...res], phase: 'Drain A' });
  }
  while (j < b.length) {
    res.push(b[j]);
    j++;
    steps.push({ type: 'drain-b', a: [...a], b: [...b], i, j, res: [...res], phase: 'Drain B' });
  }
  steps.push({ type: 'done', a: [...a], b: [...b], i, j, res: [...res], phase: '✓ Merged' });
  return steps;
}

export default function MergeSortedListsVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const a = [1, 4, 7, 10];
    const b = [2, 3, 8, 11];
    const steps = generateSteps(a, b);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Merge two sorted lists' });
    canvasRef.current?.setState({ ...steps[0] });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.phase || step.type });
    canvasRef.current?.setState({ ...step });
  }, []);

  return <AlgoVisualizer config={config} canvas={MergeListsCanvas} onInit={onInit} onStep={onStep} />;
}
