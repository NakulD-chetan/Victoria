import { worldFromClient } from '../coords';

/**
 * Explicit pan tool. Space-drag and middle-click pan are handled in the
 * engine's global pointer handler so they work during any tool.
 */
export const panTool = {
  id: 'pan',
  cursor: 'grab',

  onPointerDown(ctx, ev) {
    if (ev.button !== 0) return false;
    ctx.canvasEl.setPointerCapture?.(ev.pointerId);
    const vp = ctx.getVp();
    const w = worldFromClient(ev.clientX, ev.clientY, ctx.canvasEl, vp);
    ctx._pan = { sx: ev.clientX, sy: ev.clientY, sWorldX: w.x, sWorldY: w.y, startPanX: vp.panX, startPanY: vp.panY, zoom: vp.zoom };
    ctx.canvasEl.style.cursor = 'grabbing';
    return true;
  },

  onPointerMove(ctx, ev) {
    if (!ctx._pan) return;
    const p = ctx._pan;
    const dx = (ev.clientX - p.sx) / p.zoom;
    const dy = (ev.clientY - p.sy) / p.zoom;
    ctx.setViewport({ zoom: p.zoom, panX: p.startPanX + dx, panY: p.startPanY + dy });
    ctx.markDirty(2);
  },

  onPointerUp(ctx) {
    if (!ctx._pan) return;
    ctx._pan = null;
    ctx.canvasEl.style.cursor = 'grab';
  },

  onCancel(ctx) { ctx._pan = null; },
};
