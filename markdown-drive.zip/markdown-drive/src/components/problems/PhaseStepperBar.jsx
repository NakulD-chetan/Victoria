import { useProblemSessionStore } from '../../stores/problem-session-store';

const PHASE_LABELS = [
  { key: 'requirements', label: 'Requirements', icon: '\u2611' },
  { key: 'api', label: 'API Design', icon: '\u{1F4DD}' },
  { key: 'architecture', label: 'Architecture', icon: '\u{1F3D7}' },
  { key: 'deepDive', label: 'Deep Dive', icon: '\u{1F9E0}' },
];

export default function PhaseStepperBar() {
  const currentPhase = useProblemSessionStore((s) => s.currentPhase);
  const phases = useProblemSessionStore((s) => s.phases);
  const setPhase = useProblemSessionStore((s) => s.setPhase);

  return (
    <div className="dc-phase-stepper">
      {PHASE_LABELS.map((phase, idx) => {
        const state = phases[phase.key];
        const isCurrent = idx === currentPhase;
        const isCompleted = state?.completed;
        const isAccessible = idx <= currentPhase || isCompleted;

        let cls = 'dc-phase-stepper__step';
        if (isCurrent) cls += ' dc-phase-stepper__step--active';
        if (isCompleted) cls += ' dc-phase-stepper__step--completed';
        if (!isAccessible) cls += ' dc-phase-stepper__step--locked';

        return (
          <div key={phase.key} className="dc-phase-stepper__item">
            {idx > 0 && (
              <div className={`dc-phase-stepper__connector ${idx <= currentPhase ? 'dc-phase-stepper__connector--active' : ''}`} />
            )}
            <button
              className={cls}
              onClick={() => isAccessible && setPhase(idx)}
              disabled={!isAccessible}
              title={phase.label}
            >
              <span className="dc-phase-stepper__icon">
                {isCompleted ? '\u2713' : phase.icon}
              </span>
              <span className="dc-phase-stepper__label">{phase.label}</span>
              {state?.score > 0 && (
                <span className="dc-phase-stepper__score">{state.score}%</span>
              )}
            </button>
          </div>
        );
      })}
    </div>
  );
}
