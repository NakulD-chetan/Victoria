import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateLinear(m, inserts) {
  const table = Array(m).fill(null);
  const steps = [];
  inserts.forEach((key) => {
    let i = key % m;
    steps.push({ type: 'hash', mode: 'linear', key, i, table: [...table], probe: [i] });
    let guard = 0;
    while (table[i] != null && guard < m) {
      steps.push({ type: 'collision', mode: 'linear', key, i, table: [...table], probe: [i] });
      i = (i + 1) % m;
      guard++;
      steps.push({ type: 'probe', mode: 'linear', key, i, table: [...table], probe: [i] });
    }
    table[i] = key;
    steps.push({ type: 'insert', mode: 'linear', key, i, table: [...table], probe: [] });
  });
  steps.push({ type: 'done', mode: 'linear', table: [...table] });
  return steps;
}

function generateQuadratic(m, inserts) {
  const table = Array(m).fill(null);
  const steps = [];
  inserts.forEach((key) => {
    const i0 = key % m;
    steps.push({ type: 'hash', mode: 'quad', key, i: i0, table: [...table], probe: [i0] });
    let t = 0;
    let i = i0;
    let guard = 0;
    while (table[i] != null && guard < m) {
      steps.push({ type: 'collision', mode: 'quad', key, i, table: [...table], probe: [i] });
      t += 1;
      i = (i0 + t * t) % m;
      guard++;
      steps.push({ type: 'probe', mode: 'quad', key, i, table: [...table], probe: [i] });
    }
    table[i] = key;
    steps.push({ type: 'insert', mode: 'quad', key, i, table: [...table], probe: [] });
  });
  steps.push({ type: 'done', mode: 'quad', table: [...table] });
  return steps;
}

export default function OpenAddressingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const m = 7;
    const inserts = [10, 17, 24, 31];
    const useQuad = Math.random() > 0.5;
    const steps = useQuad ? generateQuadratic(m, inserts) : generateLinear(m, inserts);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({
      time: '0s',
      type: 'info',
      message: `${useQuad ? 'Quadratic' : 'Linear'} probing, table size ${m}`,
    });
    canvasRef.current?.setState({
      cells: steps[0].table.map((v) => (v == null ? '·' : String(v))),
      colors: {},
      title: 'Open addressing',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    (step.probe || []).forEach((idx) => {
      colors[idx] = 'compare';
    });
    if (step.type === 'insert') colors[step.i] = 'sorted';
    if (step.type === 'hash') colors[step.i] = 'pivot';
    if (step.type === 'collision') colors[step.i] = 'swap';
    if (step.type === 'probe') colors[step.i] = 'active';
    const label = step.mode === 'quad' ? 'Quadratic' : 'Linear';
    if (step.type === 'done') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Open addressing demo complete' });
    } else {
      store.addLog({
        time: `${store.stepIndex + 1}`,
        type: 'info',
        message: `${label} ${step.type}${step.key != null ? ` key=${step.key}` : ''}${step.i != null ? ` idx=${step.i}` : ''}`,
      });
    }
    canvasRef.current?.setState({
      cells: step.table.map((v) => (v == null ? '·' : String(v))),
      colors,
      title: `${label} probing`,
      pointers: step.i != null ? { i: step.i } : {},
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
