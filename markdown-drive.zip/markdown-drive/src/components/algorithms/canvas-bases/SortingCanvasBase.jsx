import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9', dotGrid: '#e7e5e4', stroke: '#1c1917',
    barDefault: '#a5d8ff', barCompare: '#ffd43b', barSwap: '#ff6b6b',
    barSorted: '#b2f2bb', barPivot: '#d0bfff', barActive: '#74c0fc',
    barMerge: '#ffa94d', textPrimary: '#1c1917', textSecondary: '#78716c',
    barBucket: '#c5f6fa',
  },
  dark: {
    bg: 'transparent', dotGrid: 'rgba(255,255,255,0.05)', stroke: 'rgba(255,255,255,0.6)',
    barDefault: '#1c4a6e', barCompare: '#805b10', barSwap: '#7c1d1d',
    barSorted: '#1e5631', barPivot: '#3b2e6e', barActive: '#1864ab',
    barMerge: '#7c4a0e', textPrimary: '#e7e5e4', textSecondary: '#a8a29e',
    barBucket: '#0b4d59',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

const SortingCanvasBase = forwardRef(function SortingCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ array: [], colors: {}, pointers: {}, labels: {}, buckets: null, treeView: null });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 500) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((newState) => {
    Object.assign(stateRef.current, newState);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width, H = 340;
    canvas.width = W * DPR; canvas.height = H * DPR;
    canvas.style.width = W + 'px'; canvas.style.height = H + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function render() {
      const now = performance.now();
      const p = getPalette();
      const { array, colors, pointers, labels, buckets, treeView } = stateRef.current;
      ctx.clearRect(0, 0, W, H);

      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.2, 1.2);

      if (!array || array.length === 0) {
        rafRef.current = requestAnimationFrame(render);
        return;
      }

      if (treeView) {
        drawTreeView(ctx, W, H, p, treeView, colors, animsRef.current, now);
      } else if (buckets) {
        drawBucketView(ctx, W, H, p, array, buckets, colors, labels);
      } else {
        drawBarView(ctx, W, H, p, array, colors, pointers, labels, animsRef.current, now);
      }

      for (let i = animsRef.current.length - 1; i >= 0; i--) {
        if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
      }

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current); };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function drawBarView(ctx, W, H, p, array, colors, pointers, labels, anims, now) {
  const n = array.length;
  const maxVal = Math.max(...array, 1);
  const pad = 40;
  const barAreaW = W - pad * 2;
  const gap = Math.max(2, Math.min(6, barAreaW / n * 0.15));
  const barW = Math.max(4, (barAreaW - gap * (n - 1)) / n);
  const barAreaH = H - 80;

  const animOffsets = {};
  for (const a of anims) {
    const t = Math.min((now - a.t0) / a.dur, 1);
    const e = easeOut(t);
    if (a.type === 'swap') {
      const { i, j } = a.data;
      const dist = (j - i) * (barW + gap);
      animOffsets[i] = (animOffsets[i] || 0) + dist * e;
      animOffsets[j] = (animOffsets[j] || 0) - dist * e;
    }
    if (a.type === 'shift') {
      const { idx, from, to } = a.data;
      const dist = (to - from) * (barW + gap);
      animOffsets[idx] = (animOffsets[idx] || 0) + dist * (1 - e) * -1;
    }
  }

  for (let i = 0; i < n; i++) {
    const val = array[i];
    const barH = (val / maxVal) * barAreaH;
    let x = pad + i * (barW + gap) + (animOffsets[i] || 0);
    const y = H - 30 - barH;
    const color = colors[i] || 'default';
    const fillColor = p['bar' + color.charAt(0).toUpperCase() + color.slice(1)] || p.barDefault;

    ctx.fillStyle = fillColor;
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, [3, 3, 0, 0]);
    ctx.fill();
    ctx.stroke();

    if (barW > 14) {
      ctx.fillStyle = p.textPrimary;
      ctx.font = `600 ${Math.min(11, barW * 0.5)}px -apple-system, sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(val, x + barW / 2, y - 4);
    }

    ctx.fillStyle = p.textSecondary;
    ctx.font = '500 9px -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(i, x + barW / 2, H - 16);
  }

  if (pointers) {
    const arrowColors = { lo: '#2f9e44', hi: '#e03131', mid: '#1971c2', pivot: '#7c3aed', i: '#f08c00', j: '#1098ad', min: '#c2255c', k: '#5c940d' };
    for (const [name, idx] of Object.entries(pointers)) {
      if (idx < 0 || idx >= n) continue;
      const x = pad + idx * (barW + gap) + barW / 2;
      ctx.fillStyle = arrowColors[name] || '#6366f1';
      ctx.beginPath();
      ctx.moveTo(x, H - 8); ctx.lineTo(x - 5, H); ctx.lineTo(x + 5, H);
      ctx.fill();
      ctx.font = 'bold 10px -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(name, x, H - 1);
    }
  }
}

function drawBucketView(ctx, W, H, p, array, buckets, colors, labels) {
  const n = Object.keys(buckets).length;
  if (n === 0) return;
  const pad = 30;
  const bucketW = Math.min(80, (W - pad * 2) / n - 8);
  const startX = (W - n * (bucketW + 8)) / 2;

  Object.entries(buckets).forEach(([key, items], bi) => {
    const bx = startX + bi * (bucketW + 8);
    const by = 50;
    const bh = H - 80;

    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(bx, by, bucketW, bh);

    ctx.fillStyle = p.textPrimary;
    ctx.font = 'bold 11px -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(key, bx + bucketW / 2, by - 6);

    items.forEach((val, vi) => {
      const vy = by + bh - (vi + 1) * 22;
      if (vy < by) return;
      ctx.fillStyle = p.barBucket;
      ctx.fillRect(bx + 3, vy, bucketW - 6, 18);
      ctx.strokeStyle = p.stroke;
      ctx.strokeRect(bx + 3, vy, bucketW - 6, 18);
      ctx.fillStyle = p.textPrimary;
      ctx.font = '500 10px -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(val, bx + bucketW / 2, vy + 13);
    });
  });
}

function drawTreeView(ctx, W, H, p, treeView, colors, anims, now) {
  const { nodes, edges } = treeView;
  if (!nodes || nodes.length === 0) return;

  const levels = {};
  let maxLevel = 0;
  nodes.forEach(n => { maxLevel = Math.max(maxLevel, n.level || 0); if (!levels[n.level || 0]) levels[n.level || 0] = []; levels[n.level || 0].push(n); });

  const nodeR = 18;
  const positions = {};
  for (let lv = 0; lv <= maxLevel; lv++) {
    const lvNodes = levels[lv] || [];
    const y = 40 + lv * 60;
    const total = lvNodes.length;
    lvNodes.forEach((n, i) => {
      const x = W / 2 + (i - (total - 1) / 2) * (W / (total + 1));
      positions[n.id] = { x, y };
    });
  }

  if (edges) {
    edges.forEach(([from, to]) => {
      const pf = positions[from], pt = positions[to];
      if (!pf || !pt) return;
      ctx.beginPath();
      ctx.moveTo(pf.x, pf.y + nodeR);
      ctx.lineTo(pt.x, pt.y - nodeR);
      ctx.strokeStyle = p.stroke;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    });
  }

  nodes.forEach(n => {
    const pos = positions[n.id];
    if (!pos) return;
    const color = colors[n.id] || 'default';
    const fill = p['bar' + color.charAt(0).toUpperCase() + color.slice(1)] || p.barDefault;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, nodeR, 0, Math.PI * 2);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = p.textPrimary;
    ctx.font = 'bold 12px -apple-system, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(n.value, pos.x, pos.y);
  });
}

export default SortingCanvasBase;
