# Design Distributed Cache — Question List

> **Permanent Recall:** Core question: "Design a distributed cache (Redis/Memcached)." Variations: Redis from scratch, pub/sub, write-through, multi-region, TTL. Related: Memcached, CDN, cache coherence. 15+ questions for practice.

---

## Direct / Core Questions

1. **Design a distributed cache like Redis or Memcached.**
2. **Design Redis from scratch.** (Full: data structures, persistence, cluster)
3. **Design an in-memory key-value store that scales to billions of keys.**
4. **How would you build a distributed LRU cache?**
5. **Design a caching layer for a read-heavy application.**

---

## Variation Questions

6. **Add pub/sub to your distributed cache.** (Publish/subscribe; channel-based; no persistence of messages)
7. **Design a write-through cache.** (Every write goes to cache + DB; strong consistency)
8. **Design a write-behind cache.** (Write to cache first; async flush to DB)
9. **How would you handle cache in a multi-region setup?** (Replication, conflict resolution, latency)
10. **Design a cache with TTL support.** (Lazy expiry, background scan, timer heap)
11. **Design a cache that supports range queries.** (Sorted sets; skip list)
12. **How would you implement a distributed session store?** (TTL, replication, failover)
13. **Design a cache with strong consistency.** (Sync replication, quorum, consensus)
14. **Add transactional support (MULTI/EXEC) to your cache.**
15. **Design a cache that supports geospatial queries.** (GeoHash; Redis GEORADIUS-style)

---

## Related / Adjacent Questions

16. **What's the difference between Redis and Memcached?** (Data structures, persistence, single vs multi-threaded)
17. **Design a CDN cache.** (Edge locations, cache invalidation, consistency)
18. **How does cache invalidation work?** (TTL, write-through, invalidation on write, pub/sub)
19. **Design a rate limiter using a distributed cache.** (Sliding window, token bucket in Redis)
20. **How would you implement a leaderboard?** (Sorted set; ZADD, ZREVRANGE)
21. **Design a rate-limited API with caching.** (Cache responses; rate limit per key)

---

## Deep-Dive / Follow-Up Questions

22. **Explain consistent hashing. Why not modulo?**
23. **How do you implement O(1) LRU eviction?**
24. **How does Redis implement sorted sets internally?**
25. **What happens when a cache node fails?**
26. **How do you handle the hot key problem?**
27. **What is cache stampede and how do you prevent it?**
28. **RDB vs AOF — when would you use each?**
29. **How does Redis Cluster partition data?** (Hash slots, gossip)
30. **Explain the CAP trade-offs in a distributed cache.**

---

## Quick Reference

| Question Type | Key Concepts |
|---------------|--------------|
| Core cache | Consistent hashing, replication, eviction |
| Redis from scratch | Data structures (skip list), RDB/AOF, RESP |
| Pub/sub | Channel routing; no persistence |
| Write-through | Sync cache+DB; strong consistency |
| Multi-region | Cross-DC replication; conflict resolution |
| TTL | Lazy + periodic; jitter |
| Hot key | Replication, local cache, sharding |
| CDN | Edge, invalidation, geo-routing |
