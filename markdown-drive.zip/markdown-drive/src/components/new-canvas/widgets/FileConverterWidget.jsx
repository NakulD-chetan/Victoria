import { memo, useState } from 'react';
import { useNewCanvasStore } from '../state/store';

function FileConverterWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [status, setStatus] = useState('idle'); // idle, uploading, processing, done
  const [progress, setProgress] = useState(0);

  const title = data.title || 'File Converter';
  const conversionType = data.conversionType || 'PDF to PPT';

  const simulateConversion = () => {
    setStatus('uploading');
    let p = 0;
    const interval = setInterval(() => {
      p += 15;
      if (p >= 50 && status === 'uploading') setStatus('processing');
      if (p >= 100) {
        p = 100;
        setStatus('done');
        clearInterval(interval);
      }
      setProgress(p);
    }, 400);
  };

  const onDelete = () => {
    commitElements((els) => els.map((e) => (e.id === element.id ? { ...e, isDeleted: true } : e)));
  };

  return (
    <div
      className="nc-widget"
      style={{
        background: data.chromeBg || '#1e1b4b', // indigo dark
        borderColor: element.style?.stroke || '#4338ca',
        borderWidth: element.style?.strokeWidth ?? 1,
        borderStyle: 'solid',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div className="nc-widget-header" data-nc-drag-handle="1">
        <div className="nc-widget-header__label">{title} ({conversionType})</div>
        <div className="nc-widget-header__actions">
          <button type="button" className="nc-widget-header__btn" onClick={onDelete}>×</button>
        </div>
      </div>
      <div className="nc-widget-body" style={{ padding: '24px', flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        {status === 'idle' && (
          <div 
            onClick={simulateConversion}
            style={{
              border: '2px dashed #6366f1',
              borderRadius: '8px',
              padding: '32px',
              textAlign: 'center',
              cursor: 'pointer',
              background: '#312e81'
            }}
          >
            <div style={{ fontSize: '24px', marginBottom: '8px' }}>📄 ➡️ 📊</div>
            <div>Click to select a file</div>
            <div style={{ fontSize: '12px', color: '#a5b4fc', marginTop: '4px' }}>Supports PDF up to 10MB</div>
          </div>
        )}

        {(status === 'uploading' || status === 'processing') && (
          <div style={{ width: '100%', textAlign: 'center' }}>
            <div style={{ marginBottom: '12px', fontSize: '14px', color: '#c7d2fe' }}>
              {status === 'uploading' ? 'Uploading...' : 'Converting to PPT...'}
            </div>
            <div style={{ background: '#312e81', height: '8px', borderRadius: '4px', overflow: 'hidden' }}>
              <div style={{ background: '#818cf8', height: '100%', width: `${progress}%`, transition: 'width 0.3s' }} />
            </div>
          </div>
        )}

        {status === 'done' && (
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '32px', marginBottom: '12px' }}>✅</div>
            <div style={{ marginBottom: '16px', color: '#a5b4fc' }}>Conversion Complete!</div>
            <button
              onClick={() => setStatus('idle')}
              style={{
                background: '#6366f1',
                color: 'white',
                border: 'none',
                padding: '8px 16px',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Download PPT
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default memo(FileConverterWidgetImpl);
