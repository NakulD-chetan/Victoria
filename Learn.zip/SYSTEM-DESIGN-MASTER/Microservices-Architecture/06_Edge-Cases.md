# Microservices Architecture — Edge Cases

> **Permanent Recall:** Edge cases to anticipate: cascading failures, service discovery failures, network latency between services, distributed tracing complexity, data consistency across services, service versioning conflicts, and deployment ordering dependencies. Each has specific mitigations—design for failure.

---

## Edge Case 1: Cascading Failures Across Services

**Scenario:** Service A depends on B; B is slow or down. A keeps calling; A's threads pile up; A becomes unresponsive; clients of A fail.

```
    A (overloaded) ←── clients
     │
     ▼
    B (slow/down)  →  A waits → A's connections exhaust → A fails
```

| Mitigation | How |
|------------|-----|
| **Circuit breaker** | Stop calling B after N failures; fail fast |
| **Timeouts** | Don't wait forever; return error or fallback |
| **Bulkhead** | Isolate thread pool per downstream |
| **Graceful degradation** | Return partial data; cache; default |

> **FAANG Tip:** "We use circuit breakers and timeouts on every outbound call. If B is down, we fail fast and return a cached or degraded response."

---

## Edge Case 2: Service Discovery Failures

**Scenario:** Discovery service (Consul, Eureka) is down or unreachable. New instances can't register; clients can't resolve.

| Mitigation | How |
|------------|-----|
| **Caching** | Cache instance list; survive short discovery outage |
| **Fallback to config** | Static list or last-known-good |
| **K8s DNS** | Built-in; less single point than external registry |
| **Multi-region** | Run discovery in multiple regions |

---

## Edge Case 3: Network Latency Between Services

**Scenario:** Services in different AZs/regions; cross-region calls add 50–100ms each. Chain of 5 services = 250–500ms.

| Mitigation | How |
|------------|-----|
| **Colocate** | Keep critical path in same region |
| **Async** | Don't wait; fire event; process async |
| **Cache** | Cache cross-service data when stale OK |
| **BFF aggregation** | Parallel calls where possible |
| **Reduce chain length** | Flatten; avoid A→B→C→D |

---

## Edge Case 4: Distributed Tracing Complexity

**Scenario:** Request spans 10 services; traces are incomplete or mis-correlated; sampling drops critical path.

| Mitigation | How |
|------------|-----|
| **Trace ID propagation** | Pass trace ID in headers; every service logs it |
| **Consistent sampling** | Sample by trace ID; all or nothing |
| **Structured logging** | trace_id, span_id in every log line |
| **Tooling** | Jaeger, Zipkin, OpenTelemetry |

---

## Edge Case 5: Data Consistency Across Services

**Scenario:** Order created; payment event delayed; inventory reduced; payment fails—now what?

| Mitigation | How |
|------------|-----|
| **Saga compensating** | Reverse steps in order; make each step reversible |
| **Idempotency** | Same event processed twice = same result |
| **Reconciliation job** | Periodic job finds inconsistencies; fixes |
| **Outbox pattern** | Write to DB + outbox; poll outbox to publish; no lost events |

---

## Edge Case 6: Service Versioning Conflicts

**Scenario:** Service A v1 calls Service B; B upgrades to v2 with breaking change. A breaks.

| Mitigation | How |
|------------|-----|
| **Backward compatibility** | Add fields; don't remove; deprecate gradually |
| **Versioned APIs** | /v1/orders, /v2/orders |
| **Contract testing** | Verify consumer expectations before deploy |
| **Feature flags** | Roll out new behavior gradually |
| **Coexist** | Run v1 and v2; migrate consumers; retire v1 |

---

## Edge Case 7: Deployment Ordering Dependencies

**Scenario:** New Order Service requires new schema in Payment Service. Deploy order matters; wrong order = outage.

| Mitigation | How |
|------------|-----|
| **Backward compatible changes** | New schema supports old and new; deploy independently |
| **Expand-contract** | Add new field; deploy; migrate; remove old |
| **No ordering** | Design so no deploy dependency |
| **Orchestrated release** | If unavoidable; automate; document |

---

## Edge Case Summary Table

| Edge Case | Symptom | Mitigation |
|-----------|---------|------------|
| Cascading failure | One failure brings down many | Circuit breaker, timeout, bulkhead |
| Discovery failure | Can't find instances | Cache, fallback config, K8s DNS |
| Network latency | Slow cross-service calls | Colocate, async, cache, flatten |
| Tracing complexity | Can't debug across services | Trace ID, sampling, tooling |
| Data consistency | Inconsistent state after failure | Saga, idempotency, reconciliation |
| Versioning conflict | Breaking change breaks caller | Backward compat, versioned API |
| Deploy ordering | Wrong order causes outage | Expand-contract, no dependency |

---

## Quick Memory Card

```
CASCADE:       Circuit breaker, timeout, bulkhead
DISCOVERY:     Cache, fallback, K8s DNS
LATENCY:       Colocate, async, cache
TRACING:       Trace ID, sampling, OTLP
CONSISTENCY:   Saga, idempotency, reconcile
VERSIONING:    Backward compat, /v1/, contract test
DEPLOY ORDER:  Expand-contract, no dependency
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
