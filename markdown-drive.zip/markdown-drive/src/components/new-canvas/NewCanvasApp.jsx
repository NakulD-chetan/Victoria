import { useEffect, useRef, useState, useCallback, memo } from 'react';
import AppNavbar from '../shared/AppNavbar';
import NewCanvasTreeSidebar from './NewCanvasTreeSidebar';
import NewCanvasStage from './NewCanvasStage';
import CanvasV3Stage from './CanvasV3Stage';
import NewCanvasDock from './NewCanvasDock';
import LocalAgentBar from './LocalAgentBar';
import Toolbar from './Toolbar';
import WidgetPropertiesPanel from './WidgetPropertiesPanel';
import { useNewCanvasStore } from './state/store';
import { flushWrite } from './state/persist';
import './new-canvas.css';
import { isCanvasV3Enabled } from './canvas-v3/feature-flags';

/**
 * Top-level shell for the new canvas. Uses the same obsidian-theme (obs-app,
 * cv-app, obs-tabbar, cv-main, cv-sync-pill) class hierarchy as CanvasApp so
 * the two routes are visually identical at the shell level.
 */
const NewCanvasApp = memo(function NewCanvasApp({ path, theme, onThemeToggle }) {
  const stageRef = useRef(null);
  const useV3 = isCanvasV3Enabled();
  const shellTheme = 'light';

  const scenes   = useNewCanvasStore((s) => s.scenes);
  const folders  = useNewCanvasStore((s) => s.folders);
  const openTabs = useNewCanvasStore((s) => s.openTabs);
  const activeId = useNewCanvasStore((s) => s.activeId);

  const setActiveScene = useNewCanvasStore((s) => s.setActiveScene);
  const closeTab       = useNewCanvasStore((s) => s.closeTab);
  const createScene    = useNewCanvasStore((s) => s.createScene);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const moreMenuRef = useRef(null);

  const activeScene = scenes[activeId];
  const canvasName = activeScene ? activeScene.name : 'Untitled Canvas';

  useEffect(() => {
    const onHide = () => flushWrite();
    window.addEventListener('pagehide', onHide);
    window.addEventListener('beforeunload', onHide);
    return () => {
      window.removeEventListener('pagehide', onHide);
      window.removeEventListener('beforeunload', onHide);
    };
  }, []);

  useEffect(() => {
    if (!moreMenuOpen) return;
    const onDoc = (e) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(e.target)) setMoreMenuOpen(false);
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [moreMenuOpen]);

  const getCanvasPath = useCallback((id) => {
    const c = scenes[id];
    if (!c) return '';
    const parts = [c.name];
    let folderId = c.folderId;
    while (folderId && folders[folderId]) {
      parts.unshift(folders[folderId].name);
      folderId = folders[folderId].parentId;
    }
    return `/${parts.join('/')}`;
  }, [scenes, folders]);

  const handleNewCanvas = useCallback(() => {
    const id = createScene('Untitled Canvas');
    if (id) setActiveScene(id);
  }, [createScene, setActiveScene]);

  const handleExportPNG = useCallback(async () => {
    const stage = stageRef.current;
    if (!stage || !stage.exportPNG) return;
    try {
      const blob = await stage.exportPNG();
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${canvasName || 'canvas'}.png`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('[new-canvas] export failed:', err);
    }
  }, [canvasName]);

  return (
    <div className="obs-app cv-app nc-app" data-theme={shellTheme}>
      <AppNavbar currentPath={path} theme={shellTheme} onThemeToggle={onThemeToggle} />

      <div className="obs-app__body">
        <NewCanvasTreeSidebar onNewCanvas={handleNewCanvas} onThemeToggle={onThemeToggle} />

        <div className="obs-main">
          <div className="obs-tabbar">
            <div className="obs-tabbar__left">
              <div className="obs-tabs">
                {openTabs.map((tabId) => {
                  const c = scenes[tabId];
                  if (!c) return null;
                  const isActive = tabId === activeId;
                  return (
                    <div
                      key={tabId}
                      className={`obs-tab ${isActive ? 'obs-tab--active' : ''}`}
                      onClick={() => setActiveScene(tabId)}
                      title={getCanvasPath(tabId)}
                    >
                      <span className="obs-tab__title">{c.name}</span>
                      <button
                        className="obs-tab__close"
                        onClick={(e) => { e.stopPropagation(); closeTab(tabId); }}
                      >
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <line x1="18" y1="6" x2="6" y2="18" />
                          <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                      </button>
                    </div>
                  );
                })}
              </div>

              <button className="obs-tabbar__new-btn" onClick={handleNewCanvas} title="New canvas">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </button>
            </div>

            <div className="obs-tabbar__right">
              <span className="cv-sync-pill cv-sync-pill--saved" title="Stored in localStorage (no cloud sync)">
                ✓ Local
              </span>

              <button
                type="button"
                className="obs-tabbar__icon-btn"
                onClick={handleExportPNG}
                title="Export as PNG (download)"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="7 10 12 15 17 10" />
                  <line x1="12" y1="15" x2="12" y2="3" />
                </svg>
              </button>

              <button
                type="button"
                className={`obs-tabbar__icon-btn ${moreMenuOpen ? 'obs-tabbar__icon-btn--active' : ''}`}
                title="More options"
                onClick={() => setMoreMenuOpen((v) => !v)}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="5" r="1.5" />
                  <circle cx="12" cy="12" r="1.5" />
                  <circle cx="12" cy="19" r="1.5" />
                </svg>
              </button>
              {moreMenuOpen && (
                <div className="obs-more-menu" ref={moreMenuRef}>
                  <button onClick={() => { handleNewCanvas(); setMoreMenuOpen(false); }}>New canvas</button>
                  <button onClick={() => { handleExportPNG(); setMoreMenuOpen(false); }}>Export PNG</button>
                  {activeId && (
                    <button onClick={() => { closeTab(activeId); setMoreMenuOpen(false); }}>Close tab</button>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="cv-main">
            {activeId ? (
              <div className="nc-stage-wrap">
                {useV3 ? (
                  <CanvasV3Stage ref={stageRef} key={activeId} theme={shellTheme} />
                ) : (
                  <NewCanvasStage ref={stageRef} key={activeId} theme={shellTheme} />
                )}
                {!useV3 ? <Toolbar /> : null}
                {!useV3 ? <NewCanvasDock /> : null}
                <LocalAgentBar />
                {!useV3 ? <WidgetPropertiesPanel /> : null}
              </div>
            ) : (
              <div className="cv-empty">
                <div className="cv-empty__title">No canvas open</div>
                <div className="cv-empty__copy">Pick a canvas from the sidebar or create a new one.</div>
                <button className="cv-empty__btn" onClick={handleNewCanvas}>Create new canvas</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
});

export default NewCanvasApp;
