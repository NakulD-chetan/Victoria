import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { useNewCanvasStore } from '../state/store';
import { createWidgetElement } from './widget-registry';
import { runCanvasAgentTurn } from '../agent/canvas-intents';

const DEFAULT_SURFACE = '#12141b';
const DEFAULT_ACCENT = '#7c83ff';

function makeId(prefix) {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

function createWelcomeMessage() {
  return {
    id: makeId('agent-msg'),
    role: 'assistant',
    text: 'Tell me what you want to do on this canvas. For example: "I want to do coding practice."',
  };
}

function practicePlan(prompt) {
  const focus = /graph|tree|dp|dynamic|array|string|system design/i.exec(prompt)?.[0] || 'DSA fundamentals';
  return [
    `Goal: ${prompt}`,
    `Track: ${focus}`,
    'Warm-up: solve one easy problem in 15 minutes.',
    'Main round: solve one medium problem with explanation notes.',
    'Review: write mistakes, edge cases, and next revision topic.',
  ].join('\n');
}

function buildMockRun(prompt, workspaceReady) {
  const wantsPractice = /coding|code|practice|dsa|problem|interview|leetcode/i.test(prompt);
  const wantsSystemDesign = /system design|hld|lld|architecture/i.test(prompt);

  if (wantsPractice) {
    return {
      shouldCreateWorkspace: !workspaceReady,
      planItems: [
        { id: 'goal', label: 'Understand your practice goal', state: 'done' },
        { id: 'track', label: 'Choose a practice track and difficulty', state: 'done' },
        { id: 'setup', label: workspaceReady ? 'Reuse existing canvas practice setup' : 'Create a fresh practice workspace on canvas', state: 'done' },
        { id: 'next', label: 'Suggest the next focused step', state: 'done' },
      ],
      finalText: workspaceReady
        ? 'Your practice workspace is already on the canvas. Next, tell me a topic like arrays, DP, graphs, or C++ STL and I will guide the session.'
        : 'I created a coding practice workspace on the canvas for you: a planning note and a code editor. Next, tell me your topic or difficulty and we can turn this into a focused practice round.',
    };
  }

  if (wantsSystemDesign) {
    return {
      shouldCreateWorkspace: false,
      planItems: [
        { id: 'goal', label: 'Understand the design objective', state: 'done' },
        { id: 'scope', label: 'Break it into APIs, data, and scaling concerns', state: 'done' },
        { id: 'prep', label: 'Prepare a canvas-first design flow', state: 'done' },
      ],
      finalText: 'I can guide a system design session next. Ask for something like "design URL shortener" or "design chat app", and I will structure the canvas workflow.',
    };
  }

  return {
    shouldCreateWorkspace: false,
    planItems: [
      { id: 'goal', label: 'Understand what you want to accomplish', state: 'done' },
      { id: 'prep', label: 'Prepare the next canvas workflow', state: 'done' },
    ],
    finalText: 'I can help you turn that into a canvas workflow. Try asking for coding practice, interview prep, or a system design session.',
  };
}

function AgentWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const frameStroke = element.style?.stroke || 'rgba(255,255,255,0.12)';
  const frameW = element.style?.strokeWidth ?? 1;

  const messages = Array.isArray(data.messages) && data.messages.length
    ? data.messages
    : [createWelcomeMessage()];
  const suggestions = data.suggestions || [
    'I want to do coding practice',
    'Help me revise graphs',
    'Start a system design session',
  ];

  const [composer, setComposer] = useState(data.composer || '');
  const timersRef = useRef([]);

  useEffect(() => {
    setComposer(data.composer || '');
  }, [data.composer]);

  useEffect(() => () => {
    timersRef.current.forEach((id) => window.clearTimeout(id));
    timersRef.current = [];
  }, []);

  const updateData = useCallback((updater) => {
    commitElements((els) => els.map((e) => {
      if (e.id !== element.id) return e;
      const current = e.widgetData || {};
      const patch = typeof updater === 'function' ? updater(current) : updater;
      return { ...e, widgetData: { ...current, ...patch } };
    }));
  }, [commitElements, element.id]);

  const onDelete = useCallback(() => {
    timersRef.current.forEach((id) => window.clearTimeout(id));
    timersRef.current = [];
    commitElements((els) => els.map((e) => (e.id === element.id ? { ...e, isDeleted: true } : e)));
  }, [commitElements, element.id]);

  const spawnPracticeWorkspace = useCallback((prompt) => {
    commitElements((els) => {
      const host = els.find((e) => e.id === element.id);
      const hostData = host?.widgetData || {};
      if (!host || hostData.workspaceReady) return els;

      const note = createWidgetElement('note', element.x + element.w + 48, element.y + 10, 320, 230);
      note.widgetData = {
        ...note.widgetData,
        color: '#bbf7d0',
        textColor: '#0f172a',
        text: practicePlan(prompt),
      };
      note.style = { ...note.style, stroke: '#4ade80' };

      const code = createWidgetElement('code', element.x + element.w + 48, element.y + 258, 540, 330);
      code.style = { ...code.style, stroke: '#32363f', strokeWidth: 1 };

      return els
        .map((e) => (e.id === element.id
          ? {
              ...e,
              widgetData: {
                ...hostData,
                workspaceReady: true,
                linkedWidgetIds: [note.id, code.id],
              },
            }
          : e))
        .concat([note, code]);
    });
  }, [commitElements, element.id, element.w, element.x, element.y]);

  const runPrompt = useCallback(async (prompt) => {
    const trimmed = prompt.trim();
    if (!trimmed) return;

    timersRef.current.forEach((id) => window.clearTimeout(id));
    timersRef.current = [];

    const userMessage = { id: makeId('agent-msg'), role: 'user', text: trimmed };
    const thinkingMessage = {
      id: makeId('agent-msg'),
      role: 'assistant',
      text: 'Working through the request...',
      pending: true,
    };

    updateData((current) => ({
      composer: '',
      status: 'running',
      planItems: [
        { id: 'goal', label: 'Reading your request', state: 'active' },
        { id: 'plan', label: 'Preparing a plan', state: 'todo' },
        { id: 'setup', label: 'Getting the canvas ready', state: 'todo' },
      ],
      messages: [...(current.messages?.length ? current.messages : [createWelcomeMessage()]), userMessage, thinkingMessage],
    }));
    setComposer('');

    // Simulate short UI transitions
    updateData({
      planItems: [
        { id: 'goal', label: 'Reading your request', state: 'done' },
        { id: 'plan', label: 'Preparing a plan', state: 'active' },
        { id: 'setup', label: 'Getting the canvas ready', state: 'todo' },
      ],
    });

    try {
      const currentState = useNewCanvasStore.getState();
      const stageElement = document.querySelector('.nc-stage'); // Will find the closest one
      
      const prevMsgs = data.messages || [createWelcomeMessage()];
      const contextMsgs = [...prevMsgs, userMessage].map(m => ({ role: m.role, text: m.text }));

      const result = await runCanvasAgentTurn(contextMsgs, {
        store: useNewCanvasStore,
        stageElement,
      });

      const planItems = [];
      if (result.toolCalls && result.toolCalls.length > 0) {
        planItems.push({ id: 'tool-head', label: 'Executing Agent Plan', state: 'done' });
        result.toolCalls.forEach((call, idx) => {
          planItems.push({ id: 'tc-'+idx, label: `Ran ${call.name}`, state: 'done' });
        });
      }

      updateData((current) => ({
        status: 'done',
        planItems: [
          { id: 'goal', label: 'Reading your request', state: 'done' },
          { id: 'plan', label: 'Preparing a plan', state: 'done' },
          { id: 'setup', label: 'Getting the canvas ready', state: 'done' },
          ...planItems
        ],
        messages: (current.messages || []).map((msg) => (
          msg.id === thinkingMessage.id
            ? { ...msg, text: result.text || 'Done!', pending: false }
            : msg
        )),
      }));

    } catch (err) {
      updateData((current) => ({
        status: 'done',
        messages: (current.messages || []).map((msg) => (
          msg.id === thinkingMessage.id
            ? { ...msg, text: 'Error: ' + err.message, pending: false }
            : msg
        )),
      }));
    }
  }, [data.messages, updateData]);

  const onSubmit = useCallback(() => {
    runPrompt(composer);
  }, [composer, runPrompt]);

  const status = data.status || 'idle';
  const planItems = data.planItems || [];
  const accent = data.accentColor || DEFAULT_ACCENT;
  const chromeBg = data.chromeBg || DEFAULT_SURFACE;

  return (
    <div
      className="nc-agent"
      style={{
        background: chromeBg,
        borderColor: frameStroke,
        borderWidth: frameW,
        borderStyle: 'solid',
        ['--nc-agent-accent']: accent,
      }}
    >
      <div className="nc-widget-header nc-agent__header" data-nc-drag-handle="1">
        <div className="nc-agent__header-main">
          <span className="nc-widget-header__label">Local Agent</span>
          <span className={`nc-agent__status nc-agent__status--${status}`}>{status === 'running' ? 'Planning' : status === 'done' ? 'Ready' : 'Idle'}</span>
        </div>
        <div className="nc-widget-header__actions">
          <button type="button" className="nc-widget-header__btn" onClick={onDelete} aria-label="Delete agent">×</button>
        </div>
      </div>

      <div className="nc-agent__body">
        <div className="nc-agent__messages">
          {messages.map((msg) => (
            <div key={msg.id} className={`nc-agent__message nc-agent__message--${msg.role}`}>
              <div className="nc-agent__avatar">{msg.role === 'assistant' ? 'AI' : 'You'}</div>
              <div className="nc-agent__bubble">
                <div className="nc-agent__bubble-role">{msg.role === 'assistant' ? 'Local Agent' : 'You'}</div>
                <p>{msg.text}</p>
                {msg.pending ? <span className="nc-agent__typing">Thinking through the next step…</span> : null}
              </div>
            </div>
          ))}
        </div>

        {planItems.length ? (
          <div className="nc-agent__plan">
            <div className="nc-agent__plan-title">Agentic flow</div>
            <div className="nc-agent__plan-list">
              {planItems.map((item) => (
                <div key={item.id} className={`nc-agent__plan-item nc-agent__plan-item--${item.state || 'todo'}`}>
                  <span className="nc-agent__plan-dot" aria-hidden />
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <div className="nc-agent__suggestions">
          {suggestions.map((suggestion) => (
            <button
              key={suggestion}
              type="button"
              className="nc-agent__chip"
              onClick={() => runPrompt(suggestion)}
            >
              {suggestion}
            </button>
          ))}
        </div>

        <div className="nc-agent__composer">
          <textarea
            className="nc-agent__input"
            value={composer}
            onChange={(e) => {
              setComposer(e.target.value);
              updateData({ composer: e.target.value });
            }}
            placeholder="Ask the local agent what you want to do on canvas…"
            onKeyDown={(e) => {
              if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                e.preventDefault();
                onSubmit();
              }
            }}
          />
          <button
            type="button"
            className="nc-agent__send"
            onClick={onSubmit}
            disabled={!composer.trim() || status === 'running'}
          >
            {status === 'running' ? 'Working…' : 'Ask Agent'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default memo(AgentWidgetImpl);
