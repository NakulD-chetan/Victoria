# Caching and CDN — Common Mistakes

> **Permanent Recall:** The top caching mistakes: caching everything (memory blow-up), ignoring invalidation (stale forever), no TTL (danger), cache stampede (thundering herd), single cache node (SPOF), caching mutable data without invalidation, oversized values, not monitoring hit ratio, cold cache after restart, caching sensitive data, inconsistent cache across regions, and CDN cache poisoning. Avoid these to pass FAANG system design and ship production-ready systems.

---

## Mistake 1: Caching Everything

**What happens:** Cache every key → memory fills up → evictions → low hit ratio → no benefit.

| Wrong | Right |
|-------|-------|
| Cache all products | Cache top N by traffic, or LRU with size limit |
| No size limit | Set `maxmemory` and eviction policy |
| Cache errors | Don't cache 404/500; fail through |

> **FAANG Tip:** Cache the working set (hot data), not the entire dataset.

---

## Mistake 2: Ignoring Cache Invalidation

**What happens:** Write to DB, forget to invalidate cache → users see stale data indefinitely.

```
WRONG:
  POST /user/123 → DB update → return
  (cache still has old value)

RIGHT:
  POST /user/123 → DB update → cache.delete("user:123") → return
```

> **FAANG Tip:** "Write path must touch cache" — either invalidate or update. Make it part of the write flow.

---

## Mistake 3: No TTL

**What happens:** Cached forever → data never refreshes → stale data even with invalidation bugs.

| Risk | Mitigation |
|------|------------|
| Invalidation missed | TTL expires eventually |
| Bug in write path | TTL as safety net |
| Orphaned keys | TTL cleans up |

**Rule:** Every cached entry should have a TTL. Default 5–60 min depending on data.

---

## Mistake 4: Cache Stampede (Thundering Herd)

**What happens:** Key expires → 1000 requests miss → 1000 parallel DB queries → DB overload.

```
STAMPEDE:
  t=0:   Key expires
  t=1:   Request 1, 2, ... 1000 all miss
  t=2:   1000 × DB query → DB dies
```

**Fix:**
- **Locking:** First request acquires lock, loads, others wait.
- **Probabilistic early expiry:** Expire 1–5 min early randomly to spread load.
- **Background refresh:** Before TTL, async refresh; serve stale until done.

---

## Mistake 5: Single Cache Node (SPOF)

**What happens:** One Redis node → node fails → all cache traffic hits DB → DB overload → outage.

**Fix:**
- Redis Cluster (sharding) or replica set
- Multiple Memcached nodes with consistent hashing
- Circuit breaker when cache is down

---

## Mistake 6: Caching Mutable Data Without Invalidation

**What happens:** User profile cached. User updates name. Cache still shows old name.

**Fix:** Tie cache key to entity + version, or invalidate on every write.

---

## Mistake 7: Oversized Cache Values

**What happens:** Store 1 MB JSON per key → few keys fill memory → evictions → low hit ratio. Also: serialization/network cost.

**Fix:**
- Compress large values
- Split into smaller keys (pagination)
- Store only needed fields

---

## Mistake 8: Not Monitoring Hit Ratio

**What happens:** Cache deployed but hit ratio 10% → no benefit, wasted memory.

**Fix:**
- Metric: `hits / (hits + misses)`
- Target: 80%+ for read-heavy
- Alert if hit ratio drops

---

## Mistake 9: Cold Cache After Restart

**What happens:** Deploy or cache restart → empty cache → all requests miss → DB overload.

**Fix:**
- Cache warming (preload hot keys)
- Gradual rollout (canary)
- Accept temporary latency spike; size DB for worst case

---

## Mistake 10: Caching Sensitive Data

**What happens:** Cache PII, tokens, passwords → cache compromised → data breach.

**Fix:**
- Don't cache secrets, raw PII
- If needed: encrypt at rest, short TTL, audit access

---

## Mistake 11: Inconsistent Cache Across Regions

**What happens:** Multi-region deployment, separate caches → User in Region A sees different data than Region B after write.

**Fix:**
- Cross-region invalidation (pub/sub, event bus)
- Or: single global cache (higher latency)
- Or: accept eventual consistency with TTL

---

## Mistake 12: CDN Cache Poisoning

**What happens:** Attacker requests `example.com/?user=attacker` with malicious `User-Agent` or headers → CDN caches response → other users get poisoned response.

**Fix:**
- Cache key must include only safe attributes (e.g., path, normalized query)
- Don't cache based on `User-Agent`, `Cookie` for public content
- Use `Vary` carefully; restrict cache key to needed dimensions

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| Cache everything | OOM, evictions | Cache working set, size limit |
| No invalidation | Stale forever | Invalidate/update on write |
| No TTL | Stale, no safety net | Always set TTL |
| Stampede | DB overload | Lock, early expiry, background refresh |
| Single node | SPOF | Cluster, replicas |
| Mutable without invalidation | Stale | Invalidate on write |
| Oversized values | Memory, latency | Compress, split, trim |
| No hit ratio monitor | Unknown ROI | Track hits/misses, alert |
| Cold cache | DB spike on restart | Warming, gradual roll |
| Sensitive data | Security risk | Don't cache, or encrypt |
| Multi-region inconsistent | Wrong data | Cross-region invalidation |
| CDN poisoning | Security, wrong content | Safe cache key |

---

## 30-SECOND REVISION BOX

```
1. Don't cache everything — working set only
2. Invalidate on write — always
3. TTL mandatory — safety net
4. Stampede — lock or early expiry
5. No single node — cluster
6. Mutable → invalidate
7. Small values — compress/split
8. Monitor hit ratio
9. Warm cache on restart
10. No sensitive data
11. Multi-region invalidation
12. CDN safe cache key
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
