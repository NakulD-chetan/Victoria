# Slowly Changing Dimension — Practice

> "History is expensive—only pay for the attributes that deserve it."

---

## Quick Recall

**Q: SCD Type 0?**  
A: Never update—keep original values as loaded (true insert-only semantics for selected columns).

**Q: SCD Type 1?**  
A: Overwrite attribute values in place; history is lost but current reporting is simple.

**Q: SCD Type 2?**  
A: Add a new row with new surrogate when attributes change; preserve `effective_start`, `effective_end`, `current_flag`.

**Q: SCD Type 3?**  
A: Add prior-value columns (e.g., `category_current`, `category_previous`)—limited history, quick comparisons.

**Q: Retail example for Type 2?**  
A: `dim_product` when `category_name` or `brand_name` changes and finance needs point-in-time reporting.

---

## Interview Questions

**1. Choose Type 1 vs Type 2 for store `square_footage` correction.**  
Say: If the correction fixes a data entry error and leadership agrees history should move, Type 1; if the store physically resized and sales per square foot history matters, Type 2.

**2. How do you implement Type 2 in ETL?**  
Say: Compare incoming natural key row hash to current row; on change, expire old row (`effective_end`, `current_flag='N'`), insert new row with new surrogate, then map subsequent facts to the new key via date logic.

**3. Type 3 when still useful?**  
Say: When only one prior value matters for simple YoY category migration reporting without full history tables—less common today but valid for narrow requirements.

**4. Type 0 example**  
Say: Original `product_launch_channel` frozen for analytics even if CRM updates—prevents retroactive channel credit shifts.

**5. Hybrid approaches**  
Say: Type 1 current view plus Type 2 history table, or mini-dimension for volatile attributes to limit row explosion on `dim_customer`.

**6. Impact on aggregate tables**  
Say: Rebuild or partition-aware incremental loads must key on surrogate and effectivity, not only calendar month.

**7. Rapid change on customer address**  
Say: Mini-dimension for geographic bands or Type 1 on street with Type 2 on segment attributes—depends on marketing use cases and privacy constraints.

**8. E-commerce marketplace: seller display name changes weekly.**  
Say: Type 1 on cosmetic text if reporting does not rely on historical seller branding; Type 2 if commission disputes require point-in-time seller identity—often split stable `seller_id` as natural key from volatile display attributes with clear policy.

---

## Scenario-Based Exercises

**Scenario 1 — Type 2 timeline**  
Customer segment changes from "Occasional" to "Loyal" on March 10.  
**Solution:** Close prior `customer_key` row at March 9 end-of-day; open new row March 10; orders before March 10 join old key; orders after join new key using transaction timestamp.

**Scenario 2 — Type 1 quick fix SQL**

```sql
UPDATE dw.dim_store
SET region_name = 'Northeast'
WHERE store_number = 4521
  AND region_name = 'Northwest'; -- data correction agreed by owners
```

**Scenario 3 — Type 3 columns**  
Track previous category for a SKU after merchandising reclass.  
**Solution:** `category_current`, `category_previous`, `category_change_date` on `dim_product`—document that only one hop of history is retained.

**Scenario 4 — Type 0 policy**  
Loyalty enrollment source system backfills enrollment dates; marketing wants original cohort month locked.  
**Solution:** Type 0 on `enrollment_cohort_month` once set; corrections flow through governance, not nightly overwrite.

**Scenario 5 — Type 2 close and insert sketch**

```sql
UPDATE dw.dim_product
SET effective_end_date = DATE '2026-03-09',
    current_flag = 'N'
WHERE sku = 'ABC123' AND current_flag = 'Y';

INSERT INTO dw.dim_product (
    sku, product_name, category_name, effective_start_date, effective_end_date, current_flag
)
SELECT
    'ABC123', 'Cordless Kettle', 'Electronics', DATE '2026-03-10', DATE '9999-12-31', 'Y';
```

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Type 2 everything | Row explosion, slow joins | Mini-dimensions or Type 1 for volatile noise |
| Forgetting fact key resolution | Wrong historical context | Date-aware joins to SCD2 |
| Calling overwrite "Type 2" | Terminology error | Name behaviors, not intentions |
| Type 3 for full audit | Insufficient depth | Use Type 2 or audit tables |
| Same-day multiple changes | Unclear which version applies | Timestamp keys or intraday versioning rules |

---

## One-Liner Answers

- SCD Type 1 overwrites; Type 2 versions; Type 3 keeps limited prior columns; Type 0 freezes.
- Pick SCD type from how much history the business will pay to store and query.
- Type 2 requires effectivity dates and careful fact-to-dimension resolution by transaction time.
- Mini-dimensions isolate rapidly changing attributes from wide core dimensions.
- Always document which attributes are Type 1 vs Type 2 in the data dictionary.
- Aggregate design must respect changing keys, not only calendar partitions.
