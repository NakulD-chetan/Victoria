# Subqueries and CTE — Mental Model

---

## Nested loops picture (correlated)

For each **outer** row, run **inner** check — think O(n·m) unless index helps.

**EXISTS** often maps to semi-join — “is there **any** witness row?”

---

## CTE as pipeline

```
WITH filtered AS (...),
     ranked AS (...)
SELECT * FROM ranked WHERE ...
```

Each step **names** intent — easier to debug than one giant nested SELECT.

---

*Next: [[03_Coding-Template]]*
