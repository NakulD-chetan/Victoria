# Interview Framework — Tricks and Recognition

> **Permanent Recall:** Given a problem statement, use the "10-second classification" to instantly categorize it. Each category maps to **component patterns** (read-heavy social → fan-out + caching, real-time → WebSocket + queues, etc.). The "always mention" checklist: caching, monitoring, security, failure handling.

---

## The 10-Second Classification System

When the interviewer says "Design X," within 10 seconds you should know:

1. **System type** (one of the categories below)
2. **Primary challenge** (scale? latency? consistency? real-time?)
3. **Key components** (from the pattern table)

---

## Quick Recognition by Problem Type

| Problem Statement | Category | Primary Challenge | Instant Components |
|-------------------|----------|-------------------|---------------------|
| Twitter, Instagram, Facebook feed | **Read-heavy social** | Feed generation at scale | Fan-out (push/pull), caching, timeline merge |
| WhatsApp, Slack, iMessage | **Real-time chat** | Low latency, ordering | WebSocket, message queue, presence |
| YouTube, Netflix, Spotify | **Media/streaming** | Bandwidth, global delivery | CDN, object storage, transcoding |
| Google Docs, Figma, Notion | **Collaborative editing** | Conflict resolution | OT or CRDT, WebSocket, version history |
| Uber, Lyft, Google Maps | **Geospatial** | Location queries, matching | Geohash, spatial index, real-time updates |
| Amazon, eBay | **E-commerce** | Inventory, checkout, search | Transaction DB, cache, search index |
| Google Search, Elasticsearch | **Search** | Full-text, ranking | Inverted index, sharding, relevance |
| URL shortener, pastebin | **Simple CRUD + redirect** | Scale, key generation | KGS, cache, DB |
| Rate limiter, API gateway | **Infrastructure** | Sliding window, distributed | Redis, token bucket, sliding window |
| Notification system | **Multi-channel push** | Fan-out, delivery | Queue, worker pools, device tokens |
| Design a cache | **Distributed systems** | Consistency, eviction | Sharding, LRU, invalidation |

---

## Component Patterns by System Type

### Read-Heavy Social (Twitter, Instagram, Facebook Feed)
```
Pattern: Fan-out + Caching + Timeline merge

- Push (write-time): Pre-compute timelines → store in cache/DB → read is O(1)
- Pull (read-time): Merge from followed users' recent tweets → O(follows)
- Hybrid: Push for normal users, pull for celebrities (millions of followers)
- Always: Cache timelines, shard by user_id, message queue for async fan-out
```

### Real-Time (Chat, Notifications, Gaming)
```
Pattern: WebSocket + Message Queue + Presence

- WebSocket/long-polling for client connections
- Message queue (Kafka/SQS) for async delivery, ordering
- Presence: heartbeat, Redis for online status
- Always: Stateless app servers, horizontal scaling of connections
```

### Media (YouTube, Netflix, Spotify)
```
Pattern: CDN + Object Storage + Transcoding

- Object storage (S3) for origin
- CDN for global delivery (CloudFront, Cloudflare)
- Transcoding pipeline for multiple formats/qualities
- Always: Adaptive bitrate, range requests, pre-warming
```

### Collaborative (Google Docs, Figma)
```
Pattern: OT or CRDT + WebSocket + Version History

- Operational Transform (OT) or CRDT for conflict resolution
- WebSocket for real-time broadcast
- Version history for undo/redo, audit
- Always: Central doc server or P2P; eventual consistency
```

### Geospatial (Uber, Lyft, Maps)
```
Pattern: Geohash + Spatial Index + Real-time

- Geohash for location encoding (e.g., "dr5r")
- Spatial index (PostGIS, S2) for range queries
- Real-time location updates via WebSocket or polling
- Always: Shard by region; cache hot areas
```

### E-commerce (Amazon, eBay)
```
Pattern: Transaction DB + Cache + Search

- ACID DB for inventory, orders, payments
- Cache for product catalog, hot items
- Search index for product discovery
- Always: Idempotency, idempotent payment retries, eventual consistency for inventory
```

### Search (Google, Elasticsearch)
```
Pattern: Inverted Index + Sharding + Ranking

- Inverted index: term → doc IDs
- Shard by term hash or doc ID
- Ranking: TF-IDF, BM25, ML models
- Always: Replicas, caching hot queries, spell correction
```

### Simple CRUD + Redirect (URL Shortener, Pastebin)
```
Pattern: Key Generation + Cache + DB

- KGS or hash+base62 for keys
- Cache for hot URLs (cache-aside)
- DB for persistence
- Always: 302 vs 301 choice, collision handling
```

---

## The "Always Mention" Checklist

Regardless of system type, **always** cover these in your design:

| Item | What to Say |
|------|-------------|
| **Caching** | "We'd cache [hot data] in Redis. Cache-aside pattern. TTL of [X]. Invalidation on [write path]." |
| **Monitoring** | "We'd monitor latency p99, error rate, [cache hit ratio / queue depth]. Alerts on [thresholds]." |
| **Security** | "Auth tokens, HTTPS, rate limiting, input validation. Consider encryption at rest, DDoS protection." |
| **Failure handling** | "If [component] fails: [redundancy / failover / circuit breaker / graceful degradation]." |
| **Scalability** | "We'd scale horizontally—add more app servers. DB: read replicas, sharding by [key] when needed." |

---

## Mermaid: Recognition Flow

```mermaid
flowchart TD
    A[Problem: Design X] --> B{10-sec classification}
    B --> C[Read-heavy social?]
    B --> D[Real-time?]
    B --> E[Media?]
    B --> F[Collaborative?]
    B --> G[Geospatial?]
    B --> H[Other?]
    
    C --> I[Fan-out + cache + timeline]
    D --> J[WebSocket + queue + presence]
    E --> K[CDN + object storage]
    F --> L[OT/CRDT + WebSocket]
    G --> M[Geohash + spatial index]
    H --> N[CRUD + cache + DB base]
    
    I --> O[Always: caching, monitoring, security, failure]
    J --> O
    K --> O
    L --> O
    M --> O
    N --> O
```

---

## Recognition Triggers — Keywords

| Keyword | Likely Category |
|---------|-----------------|
| Feed, timeline, followers | Read-heavy social |
| Chat, messaging, DM | Real-time chat |
| Video, streaming, upload | Media |
| Collaborative, edit together | Collaborative (OT/CRDT) |
| Location, nearby, drivers | Geospatial |
| Search, find, query | Search |
| Shorten, redirect | Simple CRUD |
| Rate limit, throttle | Infrastructure |
| Notify, push, alert | Notification system |

---

## Quick Component Selection

| Need | Component |
|------|-----------|
| Fast reads, hot data | **Redis** (cache) |
| Persistent, transactional | **PostgreSQL** (relational) |
| Flexible schema, scale out | **MongoDB** (document) |
| Wide-column, high write | **Cassandra** |
| Async, decoupling | **Kafka** / **SQS** |
| Real-time to client | **WebSocket** |
| Static assets, global | **CDN** |
| Blobs, media | **Object storage (S3)** |
| Full-text search | **Elasticsearch** |
| Location queries | **PostGIS** / **S2** |

---

## Trade-off Quick Reference

| Trade-off | Choose A When | Choose B When |
|-----------|---------------|---------------|
| **Push vs Pull** (feed) | Reads >> writes; low latency critical | Writes expensive; acceptable read latency |
| **Strong vs Eventual consistency** | Money, inventory, correctness | Social feed, analytics |
| **SQL vs NoSQL** | ACID, joins, complex queries | Scale out, flexible schema |
| **Cache-aside vs Write-through** | Read-heavy, stale OK | Write-heavy, need consistency |
| **Sync vs Async** | Need immediate confirmation | Can eventually deliver |
| **Single vs Multi-region** | Latency OK; simplicity | Global users; low latency |

---

## Summary: Pre-Draw Mental Templates

Before the interview, have these **mental templates** ready:

1. **Basic web app:** Client → LB → App → Cache → DB
2. **Read-heavy:** + Fan-out service, timeline cache, message queue
3. **Real-time:** + WebSocket server, message queue, presence service
4. **Media:** + CDN, object storage, transcoding pipeline
5. **Geospatial:** + Geohash, spatial index, real-time location stream

Start with the template that matches your 10-second classification. Customize from there.
