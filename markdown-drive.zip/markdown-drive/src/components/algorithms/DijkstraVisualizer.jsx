import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: dijkstra */
const GRAPH = {
  nodes: [
    { id: 'S', x: 80, y: 200, label: 'S' },
    { id: 'A', x: 200, y: 120, label: 'A' },
    { id: 'B', x: 200, y: 280, label: 'B' },
    { id: 'C', x: 340, y: 120, label: 'C' },
    { id: 'D', x: 340, y: 280, label: 'D' },
    { id: 'T', x: 480, y: 200, label: 'T' },
  ],
  edges: [
    { from: 'S', to: 'A', weight: 4, directed: true },
    { from: 'S', to: 'B', weight: 8, directed: true },
    { from: 'A', to: 'C', weight: 3, directed: true },
    { from: 'A', to: 'D', weight: 6, directed: true },
    { from: 'B', to: 'D', weight: 2, directed: true },
    { from: 'C', to: 'T', weight: 5, directed: true },
    { from: 'D', to: 'T', weight: 4, directed: true },
    { from: 'C', to: 'D', weight: 1, directed: true },
  ],
};

function generateSteps() {
  const nids = ['S', 'A', 'B', 'C', 'D', 'T'];
  const dist = Object.fromEntries(nids.map((id) => [id, Infinity]));
  dist.S = 0;
  const steps = [];
  const adj = {};
  GRAPH.edges.forEach((e) => {
    if (!adj[e.from]) adj[e.from] = [];
    adj[e.from].push({ to: e.to, w: e.weight });
  });
  const done = new Set();
  steps.push({ type: 'init', nodeColors: { S: 'source' }, edgeColors: {}, distances: { ...dist } });
  while (done.size < nids.length) {
    let u = null;
    let best = Infinity;
    nids.forEach((id) => {
      if (!done.has(id) && dist[id] < best) {
        best = dist[id];
        u = id;
      }
    });
    if (u == null || best === Infinity) break;
    done.add(u);
    steps.push({ type: 'extract', nodeColors: { [u]: 'current' }, edgeColors: {}, distances: { ...dist } });
    for (const { to, w } of adj[u] || []) {
      const nd = dist[u] + w;
      steps.push({
        type: 'relax',
        nodeColors: { [u]: 'processing', [to]: 'processing' },
        edgeColors: { [`${u}-${to}`]: 'highlight' },
        distances: { ...dist },
        relaxTo: to,
        newD: nd,
      });
      if (nd < dist[to]) {
        dist[to] = nd;
        steps.push({
          type: 'update',
          nodeColors: { [u]: 'processing', [to]: 'visited' },
          edgeColors: { [`${u}-${to}`]: 'tree' },
          distances: { ...dist },
        });
      }
    }
    steps.push({ type: 'settle', nodeColors: { [u]: 'visited' }, edgeColors: {}, distances: { ...dist } });
  }
  steps.push({ type: 'done', nodeColors: Object.fromEntries(nids.map((id) => [id, 'visited'])), edgeColors: {}, distances: { ...dist } });
  return steps;
}

export default function DijkstraVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Dijkstra from S' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { S: 'source' },
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: { S: 0, A: '∞', B: '∞', C: '∞', D: '∞', T: '∞' },
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'relax') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: [],
      stack: [],
      distances: step.distances || {},
      visited: step.visited || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
