# executeTake & Show Jobs — Why `df.show()` Creates Multiple Jobs

Yeh wahi pattern hai jiske liye 99% engineers ek baar Spark UI dekhke confused hote hain: *"Maine `df.show()` ek baar call kiya, but UI mein 3 jobs aaye — kyu?"*. Yeh notes Spark ke source code se exact trace lekar wahi answer karta hai.

**DSA Analogy**: Exponential search on a sorted array. Tum nahi jaante kahan target hai, isliye `1, 4, 16, 64, ...` partitions check karte ho jab tak `n` rows mil nahi jaate. Each "expansion" = ek separate Spark job.

---

## Core Idea (2 Lines)

`df.show(n)` is **NOT** a single shot. Internally yeh `executeTake(n+1)` loop chala hai jo **incrementally** partitions scan karta hai. Har iteration ek alag `runJob()` submit karti hai → Jobs tab mein ek alag row.

---

## The Call Chain (Source-Level)

```
df.show(20)
    |
    v
Dataset.showString(20, ...)
    |
    v
Dataset.getRows  ->  head(21)         // 20 rows + 1 sentinel for truncation
    |
    v
Dataset.collectFromPlan(...)
    |
    v
CollectLimitExec.executeCollect()     // file: limit.scala
    |
    v
child.executeTake(limit)              // file: SparkPlan.scala  <-- THE LOOP
    |
    v
sparkContext.runJob(...)              // submits one Spark job per loop iteration
```

> Repo: `github.com/apache/spark`
> Files: `sql/core/src/main/scala/org/apache/spark/sql/execution/{limit,SparkPlan,basicPhysicalOperators}.scala`

---

## The Actual Loop (Annotated)

From `SparkPlan.executeTake` (Scala, simplified):

```scala
private def executeTake(n: Int, takeFromEnd: Boolean): Array[InternalRow] = {
  if (n == 0) return new Array[InternalRow](0)

  val limitScaleUpFactor   = math.max(conf.limitScaleUpFactor, 2)        // default 4
  val childRDD             = getByteArrayRdd(n, takeFromEnd)
  val totalParts           = childRDD.partitions.length

  val buf       = new ArrayBuffer[InternalRow]
  var partsScanned = 0

  while (buf.length < n && partsScanned < totalParts) {
    var numPartsToTry = conf.limitInitialNumPartitions                   // default 1
    if (partsScanned > 0) {
      // we already tried but didn't get enough rows -> grow window
      numPartsToTry = (partsScanned * limitScaleUpFactor).toInt
    }
    val left  = n - buf.length
    val parts = (partsScanned until math.min(partsScanned + numPartsToTry, totalParts))

    val res = sc.runJob(childRDD, ..., parts)        // <-- one runJob = one UI job
    buf ++= res
    partsScanned += parts.length
  }
  buf.toArray
}
```

The PySpark mirror in `pyspark/rdd.py` is even more explicit:

```python
p = range(partsScanned, min(partsScanned + numPartsToTry, totalParts))
res = self.context.runJob(self, takeUpToNumLeft, p)   # <-- ONE job per iter
items += res
partsScanned += numPartsToTry
```

### Line-by-Line Meaning

| Line                                   | What It Does                                                         | Effect on UI                                  |
|----------------------------------------|----------------------------------------------------------------------|-----------------------------------------------|
| `limitScaleUpFactor = max(conf.limitScaleUpFactor, 2)` | Reads `spark.sql.limit.scaleUpFactor` (default 4)                    | Controls how aggressively window grows         |
| `numPartsToTry = conf.limitInitialNumPartitions`        | Reads `spark.sql.limit.initialNumPartitions` (default 1)             | Iteration 1 scans 1 partition                  |
| `while (buf.length < n && partsScanned < totalParts)`   | Loop until `n` rows collected OR all partitions scanned              | **Each iteration = one Spark job**             |
| `numPartsToTry = partsScanned * limitScaleUpFactor`     | Multiplies window after each "not enough" iteration                  | 1 → 4 → 16 → 64 → ...                          |
| `sc.runJob(childRDD, ..., parts)`                       | Submits the job to DAGScheduler                                       | **This is the line that creates the UI row**   |

> **Doc string above the loop** (in source): "executeTake runs Spark jobs that take all the elements from requested number of partitions, starting from the 0th partition and increasing their number by `spark.sql.limit.scaleUpFactor` property."
> So this is **documented behavior**, not a bug.

---

## Worked Example — Reproducing 3 `showString` Jobs

Reference setup (`spark.sql.shuffle.partitions = 8`):

```python
df_final.show()
# Internally: head(21) -> executeTake(21, takeFromEnd=false)
```

`df_final` ka post-shuffle output 8 partitions hai, but only 2 actual rows (`Group1`, `Group2`). 6 partitions empty hain. Loop kaise unfold hota hai:

| Iter | partsScanned (start) | numPartsToTry            | Partitions Read | Rows Found | Buffer | Job in UI       |
|------|----------------------|--------------------------|-----------------|------------|--------|-----------------|
| 1    | 0                    | 1 (initial)              | partition 0     | 0 (empty)  | 0 < 21 | **Job 1**       |
| 2    | 1                    | 1 × 4 = 4                | partitions 1–4  | 1          | 1 < 21 | **Job 2**       |
| 3    | 5                    | 5 × 4 = 20 (capped at 8) | partitions 5–7  | 1          | 2      | **Job 3**       |

After iter 3, `partsScanned (8) >= totalParts (8)` → loop exits.
Total partitions scanned: `1 + 4 + 3 = 8` ✓ (matches `shuffle.partitions = 8`).

> This is **exactly** the 3 `showString` rows you see in the Jobs tab.

---

## Generalized Job-Count Formula for `show()` / `take()`

Given:
- `P` = number of input partitions to executeTake
- `R(p)` = rows in partition `p` (in scan order)
- `n` = `show(k)` → `k+1`, or `take(k)` → `k`
- `init` = `spark.sql.limit.initialNumPartitions` (default 1)
- `f`    = `spark.sql.limit.scaleUpFactor`        (default 4)

The number of jobs is the number of iterations until *either*:
1. cumulative rows ≥ n, OR
2. all partitions consumed.

Iteration partition counts: `init, init·f, init·f², init·f³, …` (capped at remaining `P`).

```
Examples (init=1, f=4):
  n=21, partitions full of rows  -> 1 job (iter 1 fills buffer)
  n=21, all partitions empty     -> log₄(P) + 1 jobs (loop until exhausted)
  n=21, P=8, ~uniform sparse rows -> usually 2-3 jobs

Override:
  conf("spark.sql.limit.initialNumPartitions", str(P))  -> always 1 job
```

> The JIRA `SPARK-40211` was opened specifically because the initial count was hard-coded to `1` and could not be tuned. That ticket added `spark.sql.limit.initialNumPartitions`. Before that, the line was literally `var numPartsToTry = 1L`.

---

## Why You Only See *One* Set of Stages Re-running

In iter 2 and iter 3, the upstream pipeline (cache, joins, partial aggregations) is **already materialized** from iter 1. Spark reuses shuffle output and skips those stages.

That's why iter 2 and iter 3 show:
- Very few **active** tasks (4, 3)
- Many **skipped** tasks (22, 22)
- Very fast duration (25 ms, 33 ms)

Skipped stages are not re-executed — they just supply pre-computed shuffle bytes. Pattern 05 covers this in detail.

---

## How `count()` and `collect()` Differ

| Action      | Path                              | Why 1 Job (not many)?                              |
|-------------|-----------------------------------|----------------------------------------------------|
| `count()`   | `RDD.count` → `sc.runJob(this)`   | Whole RDD, all partitions, single submission       |
| `collect()` | `executeCollect` → `runJob(all)`  | All partitions submitted in one runJob             |
| `show(n)`   | `executeTake(n+1)` (loop)         | Incremental — wants only enough partitions for n   |
| `take(n)`   | `executeTake(n)` (loop)           | Same as show                                       |

**Key insight**: `show / take` are *frugal* — they don't want to scan the whole dataset if a few partitions can answer. The price for that frugality is multiple jobs.

---

## Configs That Control This Behavior

| Config                                  | Default | Effect                                                                   |
|-----------------------------------------|---------|--------------------------------------------------------------------------|
| `spark.sql.limit.initialNumPartitions`  | 1       | Partitions scanned in iter 1. Set to `P` → always 1 job.                |
| `spark.sql.limit.scaleUpFactor`         | 4       | Multiplier per iteration. Higher = fewer iterations, more wasted scans.  |

```python
spark = (SparkSession.builder
    .config("spark.sql.limit.initialNumPartitions", "8")  # match shuffle.partitions
    .config("spark.sql.limit.scaleUpFactor", "4")
    .getOrCreate())

df_final.show()   # now 1 job instead of 3
```

> **Trade-off**: Bigger `initialNumPartitions` = fewer jobs, but each job does more work upfront. For a `show()` on a huge dataset where rows are dense in the first partition, the default of 1 is actually optimal.

---

## Why This Design?

Spark optimizes for the **common case**: most `show()` and `take(n)` calls finish after iter 1 because the first partition usually has enough rows. The loop is a **safety net** for the unusual case where partitions are sparse.

```
Common case:   df.show() on a 200-partition df with billions of rows
               -> 1 job, scans 1 partition, gets 21 rows. Done in ms.

Pathological:  df.show() on a 200-partition df after a heavy filter that
               leaves rows only in partitions 199, 200
               -> Multiple jobs, eventually scans all 200. Still safe.
```

---

## Common Mistakes

| Mistake                                                              | Why It Breaks Mental Model                              | Fix                                                                       |
|----------------------------------------------------------------------|---------------------------------------------------------|---------------------------------------------------------------------------|
| "I called show once so 1 job"                                         | executeTake is iterative                                | Read source — 1 to log₄(P)+1 jobs                                         |
| Setting `limit(n).collect()` to "save jobs" then seeing many          | `CollectLimitExec` also uses executeTake                | Same loop — same job behavior                                             |
| Trying to optimize show by `.coalesce(1)` first                       | Defeats the purpose; turns to single task               | Just set `limit.initialNumPartitions`                                     |
| Confusing showString jobs with stages                                 | Each iter is a *job*, with its own stages               | Read "Description" column — 3 rows of `showString` = 3 jobs               |
| Believing AQE causes multiple show jobs                               | AQE adds *bookkeeping* jobs; executeTake adds *real*    | Toggle AQE; show jobs persist, AQE jobs disappear                         |
| Using `df.tail(n)` for last n rows                                    | `tail` runs executeTake from the *end* — same multi-job | Same behavior, different direction                                        |

---

## Interview Answer (Use This Verbatim)

> *"Internally `df.show()` calls `head(n+1)` which goes through `CollectLimitExec.executeCollect` → `SparkPlan.executeTake`. `executeTake` is a while-loop that submits one `runJob` per iteration. Iteration 1 scans `spark.sql.limit.initialNumPartitions` (default 1) partitions; if not enough rows are collected, it multiplies by `spark.sql.limit.scaleUpFactor` (default 4) and retries. So with 8 partitions and sparse data, you can see up to 3 jobs (`1, 4, 8` partitions cumulatively). To collapse them into one job, set `spark.sql.limit.initialNumPartitions` to the partition count."*

---

## Real-World Use Cases

```
1. Notebook performance: "Why does df.show() take longer than df.count()?"
   - count is 1 job; show may be 3+ jobs each with stage rebuild overhead.

2. Filtering noise: After a heavy filter, show() may scan many partitions.
   - Set initialNumPartitions = P, or repartition before show.

3. Streaming sinks: foreachBatch + show inside batch -> per-trigger multi-jobs.
   - Use take(n) or replace with logging.

4. Notebook latency tuning:
   - For dashboards that always show top 5 from sparse data, tune the configs once.
```

---

## When To NOT Touch These Configs

| Situation                                | Default Is Fine? |
|------------------------------------------|------------------|
| Small interactive `df.show()` on big data| Yes              |
| Dense rows in first partition            | Yes              |
| Production code (no `show()` at all)     | Irrelevant       |
| Sparse data after heavy filter           | **Tune them**    |
| You see 5+ showString rows in UI         | **Tune them**    |

---

## Cross-References

| Topic                                       | Pattern |
|---------------------------------------------|---------|
| Why upstream stages get *skipped* in iter 2 | 05      |
| Why count is exactly 1 job                  | 02      |
| What stages look like inside each iter      | 04      |
| Where to see the executeTake plan in UI     | 06 (SQL tab) |

---

## Key Takeaway

> `df.show()` is an **exponential search over partitions** disguised as a single API call.
> Iteration 1 scans 1 partition; if not enough rows, it scans 4× more; then 16×; until either `n` rows are found or all partitions are exhausted.
> Each iteration = one row in the Jobs tab.
> The two configs `spark.sql.limit.initialNumPartitions` and `spark.sql.limit.scaleUpFactor` are the *only* knobs.
> Once you internalize this, the "3 showString jobs" mystery dissolves forever.
