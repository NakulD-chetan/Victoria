# Quick Revision — Design Problem Summaries

> **Permanent Recall:** One-page summary per design problem. For each: problem in one line, key insight, core architecture (5–7 components), #1 thing to get right, common trap.

---

## 1. URL Shortener

| Item | Content |
|------|---------|
| **Problem** | Shorten long URL → redirect; high redirect QPS |
| **Key insight** | Read-heavy 100:1; KGS or hash avoids collision; 302 for analytics |
| **Core components** | Client → LB → API → Redis (cache) + KGS → DB |
| **#1 thing** | Unique key gen at scale (KGS pre-generates; no collision) |
| **Common trap** | Hash collision; hot key (viral URL) |

---

## 2. Twitter Feed

| Item | Content |
|------|---------|
| **Problem** | Post tweet; view timeline from followed users; 100:1 read:write |
| **Key insight** | Fan-out: Push for normal, Pull for celebrities (10M+ followers) |
| **Core components** | Client → LB → API → Fan-out service + Cache → DB; Message Queue (async) |
| **#1 thing** | Celebrity problem: never push; pull + cache celebrity recent tweets |
| **Common trap** | Pushing to 100M followers = system meltdown |

---

## 3. Instagram

| Item | Content |
|------|---------|
| **Problem** | Photo/video feed, likes, stories (24h TTL) |
| **Key insight** | Feed = fan-out (like Twitter); viral photo = hot key for likes |
| **Core components** | Client → LB → API → Fan-out + Cache → DB; CDN (media); Object Storage |
| **#1 thing** | Viral like count: eventual consistency; batch sync to DB |
| **Common trap** | Celebrity fan-out; resumable uploads for large media |

---

## 4. WhatsApp

| Item | Content |
|------|---------|
| **Problem** | Real-time chat; 1:1 and groups (256); multi-device |
| **Key insight** | WebSocket for delivery; queue for offline; server-assigned sequence_id for order |
| **Core components** | Client → WebSocket/LB → API → Message Queue → DB; Presence (Redis) |
| **#1 thing** | Message ordering: sequence_id, not client timestamp (clock skew) |
| **Common trap** | Multi-device fan-out; offline storage; block mid-conversation |

---

## 5. YouTube / Netflix

| Item | Content |
|------|---------|
| **Problem** | Video upload, transcoding, streaming at scale |
| **Key insight** | CDN + immutable chunks; pre-push viral content; adaptive bitrate |
| **Core components** | Client → CDN ← Object Storage ← Transcoding pipeline ← Upload API; DB (metadata) |
| **#1 thing** | Viral video: pre-push to CDN; chunks immutable |
| **Common trap** | Transcoding failure; resumable upload; CDN invalidation on delete |

---

## 6. Uber

| Item | Content |
|------|---------|
| **Problem** | Match rider to nearby drivers; real-time location |
| **Key insight** | Geohash for location; query 3×3 cells (boundary); spatial index |
| **Core components** | Client → LB → Matching Service + Location Service → Redis (Geo) + DB |
| **#1 thing** | Geohash boundary: query rider cell + 8 neighbors |
| **Common trap** | No drivers; driver cancels; GPS in tunnel; concurrent match to same driver |

---

## 7. Notification System

| Item | Content |
|------|---------|
| **Problem** | Push, email, SMS to users; fan-out from events |
| **Key insight** | Queue per channel; partition by user_id; batch to APNS/FCM; priority queues |
| **Core components** | Event → API → Queue (partitioned) → Workers → APNS/FCM/SendGrid |
| **#1 thing** | Mass blast: partition queue; batch to provider; rate limit |
| **Common trap** | Device token 410 (uninstalled); provider outage; duplicate events |

---

## 8. Rate Limiter

| Item | Content |
|------|---------|
| **Problem** | Limit requests per user/IP per window; distributed |
| **Key insight** | Redis + Lua for atomicity; token bucket or sliding window counter |
| **Core components** | Request → Gateway → Rate Limiter (Redis) → Backend |
| **#1 thing** | Lua script: atomic INCR + EXPIRE; 429 + Retry-After |
| **Common trap** | Fixed window boundary spike; Redis down = fail open/closed |

---

## 9. Distributed Cache

| Item | Content |
|------|---------|
| **Problem** | In-memory key-value at scale; partition, replicate, evict |
| **Key insight** | Consistent hashing + virtual nodes; LRU = HashMap + doubly-linked list |
| **Core components** | Client → Hash ring → Shards (Redis nodes); Replication |
| **#1 thing** | Consistent hashing: only K/N keys move on failure |
| **Common trap** | Hot key; cache stampede; split-brain |

---

## 10. Google Docs

| Item | Content |
|------|---------|
| **Problem** | Real-time collaborative editing; conflict resolution |
| **Key insight** | OT (Operational Transform) or CRDT; server assigns sequence; WebSocket broadcast |
| **Core components** | Client → WebSocket → Collaboration Service → DB (snapshot + op log) |
| **#1 thing** | Op ordering: server sequence; transform against prior ops |
| **Common trap** | 100 users same paragraph; offline reconnect; version explosion |

---

## Quick Recognition Table

| Problem | Pattern | Key Tech |
|---------|---------|----------|
| URL Shortener | KGS + cache | Redis, KGS |
| Twitter | Fan-out push/pull | Cache, queue |
| Instagram | Fan-out + media | CDN, S3 |
| WhatsApp | Real-time + queue | WebSocket, Kafka |
| YouTube | CDN + transcoding | CDN, S3, workers |
| Uber | Geospatial | Geohash, Redis Geo |
| Notifications | Fan-out + channels | Queue, APNS/FCM |
| Rate Limiter | Sliding/token | Redis, Lua |
| Distributed Cache | Consistent hash | Redis cluster |
| Google Docs | OT/CRDT | WebSocket, version |

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
