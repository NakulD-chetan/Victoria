# 18. How Uber Finds Nearby Drivers

## One-Line Summary
Uber finds nearby drivers at 1M requests/second using the H3 hexagonal geospatial library (created at Uber), Cassandra for write-optimized location storage, Redis for read caching, and map matching to transform noisy GPS into road segments.

## Key Requirements
- **Scale**: 1 million requests per second for finding nearby drivers
- **Functional**: Driver location updates (every few seconds), find nearby drivers, ETA calculation
- **Geospatial**: Hierarchical indexing; cell ID as sharding key
- **Data quality**: Noisy GPS → map matching to actual road segments

## High-Level Architecture
```
[Client] → [API] → [Find Nearby Service]
                        ↓
              [H3 Cell Resolution] → [Redis Cache] → [Cassandra]
                        ↓                    ↓
              [Map Matching] ← [Redis Buffer]   [Map-Matched Cassandra]
```

- **H3 library** (Uber) for hexagonal hierarchical geospatial indexing
- **Cassandra** for raw location storage (write-optimized)
- **Redis** cache on top of Cassandra for read operations
- **Redis** buffers data points for map matching
- **Map-matched data** stored in separate Cassandra schema

## Core Components Deep Dive

### H3 Geospatial Library (Uber)
- **Hexagonal grid**: Each neighbor same distance from center — simpler distance measurement than squares
- **Hierarchical**: 16 resolution levels; smallest = ~1 sq meter
- **122 base cells** — 12 pentagons (can't tile sphere with only hexagons)
- **Cell ID as sharding key** — drivers in same cell → same shard
- **kRing function** — find neighboring cells for radius queries
- **Constant-time bitwise ops** for resolution switching

### Map Matching
- **Problem**: Noisy GPS signals (buildings, tunnels, drift)
- **Solution**: Transform GPS points to actual road segments
- **Flow**: Raw GPS → Redis buffer → map matching service → map-matched Cassandra

### Find Nearby Drivers Flow
1. Identify relevant H3 cells for user's location + radius
2. List drivers in those cells (from Redis/Cassandra)
3. Sort by ETA

### Driver Location Updates
- Updates every few seconds
- Write-optimized: Cassandra handles high write throughput
- Read path: Redis cache → Cassandra fallback

## Key Design Decisions
1. **H3 hexagons** — Uber's own library; hierarchical, 16 resolutions
2. **Cassandra for raw location** — Write-optimized; handles high update rate
3. **Redis for reads** — Cache-aside; reduces Cassandra load
4. **Map matching** — Separate pipeline; improves ETA accuracy
5. **Cell ID as shard key** — Colocate drivers in same area

## Scaling Strategies
- **Write scaling**: Cassandra (distributed, write-optimized)
- **Read scaling**: Redis cache; 1M read QPS
- **Geospatial**: H3 kRing for efficient neighbor lookup
- **Map matching**: Async pipeline; Redis buffer decouples ingestion

## Interview Tips
- H3 vs S2: Both hexagonal; H3 is Uber's, 122 base cells, 16 resolutions
- Why hexagons: Equal distance to all 6 neighbors
- Map matching: Critical for urban accuracy; separate write path
- 1M QPS: Redis cache is essential; Cassandra for durability

## Quick Revision
- **Scale**: 1M requests/sec for nearby drivers
- **H3**: Hexagonal, 16 resolutions, 122 base cells, kRing for neighbors, cell ID = shard key
- **Stack**: Cassandra (raw + map-matched), Redis (cache + buffer)
- **Map matching**: GPS → Redis buffer → map matching → map-matched Cassandra
- **Flow**: H3 cells → list drivers in cells → sort by ETA
