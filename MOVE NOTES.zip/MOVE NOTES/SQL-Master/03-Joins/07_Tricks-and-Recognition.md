# Joins — Tricks and Recognition

| Pattern | Technique |
|---------|-----------|
| “All A without B” | `LEFT JOIN B … WHERE B.key IS NULL` (or `NOT EXISTS`) |
| “Pairs in same table” | Self-join with aliases |
| “Bridge table” many-to-many | Two joins through junction table |
| Exploding rows | `COUNT(DISTINCT …)` or subquery to fix grain |

---

*Next: [[08_Problem-List]]*
