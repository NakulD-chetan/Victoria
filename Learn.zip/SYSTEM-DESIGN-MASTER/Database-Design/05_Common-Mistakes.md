# Database Design — Common Mistakes (Deep Understanding)

> **Permanent Recall:** The top DB mistakes: (1) wrong database for workload, (2) no indexes on hot queries, (3) N+1 queries, (4) ignoring read/write ratio, (5) premature sharding, (6) storing blobs in DB, (7) no connection pooling, (8) over-normalization for read-heavy paths, (9) not using transactions when needed, (10) ignoring data growth. Each has a real-world scenario, why people make it, and how to fix it.

---

## Mistake 1: Wrong Database for the Workload

### What Happens

You pick a database based on familiarity ("I know MongoDB") instead of the workload's requirements. Result: poor performance, missing features, or unnecessary complexity.

```
SCENARIO 1: MongoDB for a payment system

Company X chose MongoDB because "it's modern and scalable."
Payment flow: debit Account A, credit Account B.

MongoDB (at the time): no multi-document transactions.
  Step 1: Debit A → succeeds
  Step 2: Credit B → FAILS (network error)
  
  Result: A lost $100, B didn't receive it.
  Money VANISHED. No atomic rollback across documents.
  
  With PostgreSQL:
  BEGIN; UPDATE A; UPDATE B; COMMIT;
  If step 2 fails → ROLLBACK → A restored.
  
  COST: Company lost $47K in phantom debits before switching to PostgreSQL.

SCENARIO 2: PostgreSQL for session cache

Company Y stores user sessions in PostgreSQL.
  Each page load: SELECT * FROM sessions WHERE token = 'abc123'
  At 50K concurrent users: 50K queries/sec to PostgreSQL for simple key-value lookups.
  
  PostgreSQL overhead per query: parse SQL → optimize → execute → return.
  Response time: 2-5ms per session lookup.
  
  With Redis:
  GET session:abc123
  Response time: 0.1ms. No SQL parsing. No optimizer.
  50× faster for this specific pattern.
  
  COST: 50K QPS to PostgreSQL caused connection pool exhaustion.
  Moved to Redis → PostgreSQL freed up for real queries.
```

### Algorithm Decision Table (Memorize This)

| Your Workload | Wrong Database | Right Database | Why |
|---------------|---------------|----------------|-----|
| Financial transactions | MongoDB (no multi-doc ACID) | **PostgreSQL** (ACID, multi-row transactions) | Money can't vanish |
| Session storage | PostgreSQL (overkill) | **Redis** (key-value, TTL, sub-ms) | Simple lookup, no SQL needed |
| Product catalog (varying attributes) | SQL (rigid schema) | **MongoDB** (flexible documents) | Phone has screen_size, book has pages |
| Social graph (friends of friends) | SQL (self-JOINs on billions) | **Neo4j** (native graph traversal) | 6-hop traversals are instant in graph DB |
| Time-series IoT data (1B writes/day) | PostgreSQL (can't handle volume) | **Cassandra** (write-optimized, LSM-tree) | Append-only, no locking |
| Full-text search | SQL LIKE '%term%' (slow) | **Elasticsearch** (inverted index) | Designed for text search and ranking |

> **Interview Answer:** *"I'd never pick a database based on popularity. I'd match it to the workload — ACID → SQL, key-value → Redis, flexible docs → MongoDB, graph → Neo4j. Most systems use multiple databases, each for what it does best."*

---

## Mistake 2: No Indexes on Hot Query Columns

### What Happens

Without indexes, every query does a **full table scan** — reading every single row. At 10M rows, queries take seconds instead of milliseconds.

### Real-World Scenario

```
E-commerce site. orders table: 50 million rows.

QUERY: "Show user 123's recent orders"
  SELECT * FROM orders WHERE user_id = 123 ORDER BY created_at DESC LIMIT 20;

WITHOUT INDEX on (user_id, created_at):
  Database: "I need to find all rows where user_id = 123..."
  Scans row 1:    user_id = 456 → no
  Scans row 2:    user_id = 789 → no
  ...
  Scans row 50M:  user_id = 123 → yes
  
  Time: 3.2 seconds (full table scan)
  Users see: loading spinner for 3 seconds → frustration → leave site
  
  At 1000 concurrent users: 1000 × full scan = database CPU at 100% → crash

WITH INDEX on (user_id, created_at DESC):
  Database: "B-Tree lookup: user_id = 123 → found 47 orders"
  "Already sorted by created_at DESC → take first 20"
  
  Time: 0.5ms (index scan)
  Users see: instant response
  
  That's 6400× faster.
```

### How to Know Which Columns Need Indexes

```
STEP 1: Identify your hot queries (most frequent)
  "Show user's orders"     → WHERE user_id = ? ORDER BY created_at DESC
  "Search products"        → WHERE category = ? AND price BETWEEN ? AND ?
  "Login"                  → WHERE email = ?
  "User's feed"            → WHERE user_id IN (followed_ids) ORDER BY created_at DESC

STEP 2: For each hot query, index the WHERE, JOIN, and ORDER BY columns
  orders: CREATE INDEX idx_orders_user_created ON orders(user_id, created_at DESC);
  products: CREATE INDEX idx_products_cat_price ON products(category_id, price);
  users: CREATE UNIQUE INDEX idx_users_email ON users(email);
  posts: CREATE INDEX idx_posts_user_created ON posts(user_id, created_at DESC);

STEP 3: Verify with EXPLAIN ANALYZE
  EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 123 ...;
  Should show "Index Scan" not "Seq Scan"
```

### Common Indexing Mistakes

| Mistake | What Goes Wrong | Fix |
|---------|----------------|-----|
| **No index at all** | Full table scan on every query | Index WHERE/JOIN/ORDER BY columns |
| **Index in wrong column order** | Composite index (created_at, user_id) doesn't help WHERE user_id = ? | Put equality columns FIRST: (user_id, created_at) |
| **Index every column** | Each index slows writes (must update index on INSERT/UPDATE) | Only index HOT query paths |
| **Missing partial index** | Index includes ALL rows; most are irrelevant | `CREATE INDEX ... WHERE status = 'active'` for active-only queries |
| **Not checking EXPLAIN** | Think index is used, but optimizer chose seq scan | Always verify with EXPLAIN ANALYZE |

---

## Mistake 3: The N+1 Query Problem

### What Happens

You fetch a list of items, then loop through each item making a separate database query. Instead of 1-2 queries, you make N+1 queries. This is the #1 performance killer in web applications.

### Real-World Scenario

```
Blog page: "Show 50 most recent posts with author names"

WRONG (N+1): 51 queries
  posts = db.query("SELECT * FROM posts ORDER BY created_at DESC LIMIT 50")  # 1 query
  
  for post in posts:
      author = db.query("SELECT name FROM users WHERE id = ?", post.user_id)  # 50 queries!
      post.author_name = author.name
  
  Total queries: 1 + 50 = 51
  At 2ms per query: 51 × 2ms = 102ms
  
  Now scale to 200 posts per page: 201 queries = 402ms
  Now add comments (5 per post): 1 + 200 + 1000 = 1201 queries = 2.4 seconds
  Page loads in 2.4 seconds. Unacceptable.

RIGHT (JOIN): 1 query
  results = db.query("""
      SELECT p.*, u.name as author_name 
      FROM posts p 
      JOIN users u ON p.user_id = u.id 
      ORDER BY p.created_at DESC 
      LIMIT 50
  """)
  
  Total queries: 1
  Time: 3ms
  
  34× faster for 50 posts. 400× faster for 200 posts with comments.

RIGHT (Batch): 2 queries
  posts = db.query("SELECT * FROM posts ORDER BY created_at DESC LIMIT 50")
  user_ids = [p.user_id for p in posts]
  users = db.query("SELECT * FROM users WHERE id = ANY(%s)", [user_ids])
  
  Total queries: 2 (regardless of how many posts)
  Time: 4ms
```

### Why People Make This Mistake

```
ORMs hide it! ActiveRecord, Django, SQLAlchemy make N+1 look natural:

  # Django — looks innocent, but generates N+1 queries
  posts = Post.objects.all()[:50]
  for post in posts:
      print(post.author.name)  # Each access triggers a separate query!
  
  # FIX: Eager loading
  posts = Post.objects.select_related('author').all()[:50]
  # Now Django fetches posts and authors in ONE query (JOIN)
```

---

## Mistake 4: Ignoring Read/Write Ratio

### What Happens

You design the database the same way for a read-heavy app (100:1) as a write-heavy app (1:100). Different ratios need completely different strategies.

### Real-World Scenario

```
SCENARIO: Social media feed (100:1 read:write)

WRONG design: Compute feed on every read
  User opens app → query: SELECT posts from followed users ORDER BY time
  → JOIN followers + posts + users on every single read
  → At 100K concurrent readers: 100K complex JOINs/second → DB melts

RIGHT design: Optimize for reads
  1. Pre-compute feed (fan-out on write):
     When User A posts → push post to ALL followers' pre-computed feed lists
     When User B reads feed → read pre-computed list (single read, no JOINs)
  2. Cache in Redis:
     user:123:feed → [post1, post2, ..., post50]
     Read: GET user:123:feed → sub-ms
  3. Read replicas:
     Writes go to primary (infrequent)
     Reads go to 5 replicas (frequent)

SCENARIO: IoT sensor logging (1:100 write:read)

WRONG design: Standard PostgreSQL with 10 indexes
  1 million sensors × 1 write/second = 1M writes/sec
  Each write must update 10 indexes → 10M index operations/sec
  PostgreSQL can't handle this

RIGHT design: Optimize for writes
  1. Use Cassandra (write-optimized, LSM-tree, no locking)
  2. Minimal indexes (only partition key)
  3. Batch inserts (write 1000 readings at once)
  4. Time-based partitioning (new table per day)
```

### Read/Write Optimization Strategies

| Ratio | Strategy |
|-------|---------|
| **Read-heavy (100:1)** | Denormalize for single-read access. Heavy caching (Redis). Read replicas. Pre-compute aggregations. Covering indexes. |
| **Balanced (1:1)** | Standard normalized schema. Moderate caching. Indexes on hot paths only. |
| **Write-heavy (1:100)** | Fewer indexes (each index costs per write). Batch inserts. Consider Cassandra/ClickHouse. Time-based partitioning. Async processing. |

---

## Mistake 5: Premature Sharding

### What Happens

You shard the database before it's necessary, adding enormous complexity for no benefit. Sharding is like surgery — don't do it unless you really need it.

### Real-World Scenario

```
Startup with 100K users decides to shard "for future scale."

Before sharding:
  1 PostgreSQL instance handles 1K req/sec comfortably
  Queries are simple (user lookups, order history)
  All JOINs work naturally
  One database to backup, monitor, maintain

After sharding (4 shards by user_id):
  "Show all orders with total > $1000" → must query ALL 4 shards
  "Admin dashboard: total revenue" → scatter-gather across 4 shards
  "User 123 messages User 456" → users on different shards!
  Migrations: must run on ALL shards
  Backups: 4× the work
  Monitoring: 4× the dashboards
  New developers: "Which shard has this data?"
  
  MASSIVE complexity. ZERO benefit (single server wasn't even at 50% capacity).
  
  Team spent 3 months building sharding infrastructure.
  Could have spent that time on features.
```

### The Right Scaling Progression

```
STEP 1: Optimize (free, immediate)
  - Add indexes on hot queries → 10-100× faster
  - Fix N+1 queries → 10-50× fewer DB hits
  - Use connection pooling → handle 10× more connections
  
  Can handle: 1K-5K req/sec on one server

STEP 2: Vertical scaling (easy, moderate cost)
  - Bigger instance (more CPU, RAM, faster SSD)
  - Go from 4 cores to 32 cores
  
  Can handle: 5K-20K req/sec

STEP 3: Read replicas + cache (moderate complexity)
  - Read replicas for read scaling
  - Redis cache for hot data
  
  Can handle: 20K-100K req/sec

STEP 4: Sharding (ONLY if writes exceed one server)
  - Shard by user_id or tenant_id
  - Use Vitess, Citus, or app-level routing
  
  Can handle: 100K+ write req/sec

Most applications NEVER need step 4.
```

---

## Mistake 6: Storing Blobs in the Database

### What Happens

You store images, videos, PDFs directly in the database as BYTEA/BLOB columns. The database grows to terabytes, backups take hours, replication is strained.

### Real-World Scenario

```
Photo-sharing app. Users upload 5MB photos.

WRONG: Store photos in PostgreSQL
  INSERT INTO photos (user_id, image_data) VALUES (123, [5MB blob]);
  
  1M photos × 5MB = 5TB in the database!
  
  Problems:
  1. Backup: 5TB database → backup takes 8 hours
  2. Replication: streaming 5TB WAL → replicas can't keep up
  3. Queries: Simple "SELECT * FROM photos" reads 5MB per row → slow
  4. Memory: Buffer pool filled with image blobs → actual data evicted
  5. Cost: PostgreSQL storage is 10× more expensive than S3

RIGHT: Store photos in S3, URL in PostgreSQL
  1. App uploads photo to S3 → gets URL: https://bucket.s3.amazonaws.com/photo123.jpg
  2. App stores URL in PostgreSQL:
     INSERT INTO photos (user_id, image_url) VALUES (123, 'https://...');
  
  1M photos:
  - S3: 5TB (cheap, designed for blobs, CDN-ready)
  - PostgreSQL: ~100MB (just URLs) → fast, small, easy to backup
```

### What Belongs in the Database vs Object Storage

| Store in DB | Store in S3/Object Storage |
|-------------|--------------------------|
| User data (name, email) | Images, videos, PDFs |
| Order details (amount, status) | File uploads |
| JSON configuration | Log files |
| Small text (comments, posts) | Backup archives |
| URLs/paths pointing to files | Any file > 1MB |

---

## Mistake 7: No Connection Pooling

### What Happens

Every request opens a new database connection, queries, and closes it. At high traffic, the database runs out of connections and crashes.

### Real-World Scenario

```
API server. 500 requests/second. Each request queries PostgreSQL.

WITHOUT POOLING:
  Each request: Open TCP connection → TLS handshake → Auth → Query → Close
  Connection overhead: ~5ms per request
  
  500 req/sec × 1 connection each = 500 connections opening/closing per second
  PostgreSQL: each connection = 1 OS process = ~10MB RAM
  500 connections = 5GB RAM just for connection handling
  
  Peak hour: 2000 req/sec
  PostgreSQL max_connections default: 100
  Request 101: "FATAL: too many connections" → error
  Request 102: same error. Site is down.

WITH POOLING (HikariCP / pgBouncer):
  Pool of 20 connections, kept open permanently
  
  Request 1: Borrow connection (instant) → Query (2ms) → Return to pool
  Request 2: Borrow same connection → Query (2ms) → Return to pool
  
  500 req/sec → 20 connections handle everything
  2000 req/sec → requests queue briefly, but 20 connections still sufficient
  PostgreSQL: only 20 processes = 200MB RAM
  
  BONUS: pgBouncer in transaction mode
  App has 500 connections to pgBouncer
  pgBouncer has 20 connections to PostgreSQL
  500:20 multiplexing. PostgreSQL barely notices.
```

### Connection Pool Settings (What to Set and Why)

| Setting | Recommended | Why |
|---------|-------------|-----|
| **Pool size** | (CPU cores × 2) + disk spindles ≈ 10-20 | More connections ≠ more throughput (context switching) |
| **Connection timeout** | 30 seconds | Don't wait forever for a connection |
| **Idle timeout** | 10 minutes | Close unused connections to free DB resources |
| **Max lifetime** | 30 minutes | Recycle connections (DB may have restarted) |
| **Min idle** | 3-5 | Keep some warm connections ready |

---

## Mistake 8: Over-Normalization for Read-Heavy Paths

### What Happens

Every piece of data is in its own table (perfectly normalized), but the main queries require 5+ JOINs. At scale, these JOINs kill performance.

### Real-World Scenario

```
Social media feed. Fully normalized schema:

To show ONE feed item, you need:
  posts (post content)
  → JOIN users (author name)
  → JOIN user_profiles (author avatar)
  → JOIN post_likes (like count)
  → JOIN comments (comment count)
  → JOIN post_media (images/videos)
  
  6 tables × JOIN = EXPENSIVE
  For a feed of 50 posts: 6 JOINs executed 50 times = VERY EXPENSIVE
  At 100K concurrent users loading feeds: DATABASE MELTS

DENORMALIZED for feed (much faster):
  feed_posts table:
  ┌────┬───────────┬─────────────┬────────┬──────────┬────────┬──────────┐
  │ id │ author_name│ author_avatar│ content│ like_count│ comment_count│ media_urls│
  ├────┼───────────┼─────────────┼────────┼──────────┼────────┼──────────┤
  │ 1  │ Alice     │ /alice.jpg  │ Hello! │ 42       │ 7      │ [/img.jpg]│
  └────┴───────────┴─────────────┴────────┴──────────┴────────┴──────────┘
  
  ONE table. ZERO JOINs. One query returns everything for the feed.
  
  Tradeoff: When Alice changes her name:
  - Normalized: UPDATE users SET name = 'Alice2' (one row, instant)
  - Denormalized: UPDATE all Alice's posts SET author_name = 'Alice2' (could be thousands)
  
  But name changes happen once a year. Feed reads happen 1000×/second.
  Optimize for the common case (reads).
```

### The Right Balance

```
KEEP NORMALIZED:
  ✅ Core entities (users, products, orders) — source of truth
  ✅ Data that changes frequently
  ✅ Data accessed through forms (CRUD pages)

DENORMALIZE (or cache):
  ✅ Feed/timeline — pre-join author info into post
  ✅ Counters — store like_count in the post row (not COUNT every time)
  ✅ Display names — embed author_name in comment for fast display
  ✅ Search results — pre-compute search documents
```

> **Interview Answer:** *"We normalize the source-of-truth tables for data integrity. For read-heavy paths like the feed, we denormalize — embed author name and avatar in the post record. One read instead of 6 JOINs. We accept some redundancy because reads are 100× more frequent than writes."*

---

## Mistake 9: Not Using Transactions When Needed

### What Happens

Multi-step operations that MUST succeed or fail together are executed as separate statements. If one fails, data is left in an inconsistent state.

### Real-World Scenario

```
E-commerce checkout. Three steps:
  1. Reduce product stock
  2. Create order
  3. Charge payment

WITHOUT TRANSACTION:
  UPDATE products SET stock = stock - 1 WHERE id = 42;  → SUCCESS (stock: 5 → 4)
  INSERT INTO orders (user_id, product_id) VALUES (123, 42);  → SUCCESS
  INSERT INTO payments (order_id, amount) VALUES (999, 50.00);  → FAILS (payment gateway down)
  
  RESULT:
  - Stock reduced ✅ (but shouldn't be — payment failed)
  - Order created ✅ (but shouldn't be — payment failed)
  - Payment NOT recorded ❌
  - Customer wasn't charged, but stock is reduced and order exists
  - INCONSISTENT STATE. Product appears sold but money wasn't collected.

WITH TRANSACTION:
  BEGIN;
    UPDATE products SET stock = stock - 1 WHERE id = 42;
    INSERT INTO orders (user_id, product_id) VALUES (123, 42);
    INSERT INTO payments (order_id, amount) VALUES (999, 50.00);  → FAILS
  ROLLBACK;  ← Everything undone. Stock back to 5. No order. Clean state.
```

### When to Use Transactions

| Operation | Transaction Needed? | Why |
|-----------|-------------------|-----|
| Bank transfer (debit + credit) | **YES — CRITICAL** | Money can't vanish |
| Order checkout (stock + order + payment) | **YES — CRITICAL** | All three must succeed together |
| User registration (user + profile + welcome email) | **Partially** — transaction for DB, async for email | Email failure shouldn't rollback user creation |
| Incrementing a counter | **Usually no** — use atomic operations | `UPDATE SET count = count + 1` is already atomic |
| Reading a report | **Depends** — use transaction for snapshot consistency | Repeatable Read ensures consistent data within the report |

---

## Mistake 10: Ignoring Data Growth

### What Happens

The database works fine at 100K rows. At 100M rows, queries timeout, disk fills, backups take hours, and migrations fail.

### Real-World Scenario

```
Activity log table. Every user action is logged.

Year 1: 10M rows. Queries fast. All good.
Year 2: 100M rows. "SELECT COUNT(*) FROM activity_log" takes 30 seconds.
Year 3: 500M rows. INSERT starts slowing (10 indexes to update per INSERT).
Year 4: 1B rows. Table is 2TB. Backup takes 12 hours. ALTER TABLE takes 3 days.
         Disk is 90% full. Engineers panic.

Nobody planned for growth. Now it's a crisis.
```

### How to Plan for Growth

```
STRATEGY 1: Time-based Partitioning
  Instead of one huge table, split by month:
  
  activity_log_2024_01  (January data)
  activity_log_2024_02  (February data)
  ...
  activity_log_2024_12  (December data)
  
  PostgreSQL native partitioning:
  CREATE TABLE activity_log (
      id BIGSERIAL,
      user_id BIGINT,
      action TEXT,
      created_at TIMESTAMPTZ
  ) PARTITION BY RANGE (created_at);
  
  CREATE TABLE activity_log_2024_q1 
    PARTITION OF activity_log 
    FOR VALUES FROM ('2024-01-01') TO ('2024-04-01');
  
  Benefits:
  - Drop old partitions instantly (vs DELETE which locks table)
  - Queries on recent data only scan recent partitions
  - Each partition is small → fast indexes, fast queries

STRATEGY 2: Archive Old Data
  Move data older than 90 days to cold storage (S3, cheap DB)
  Keep last 90 days in hot PostgreSQL
  
STRATEGY 3: Use BIGINT for IDs
  INT max: 2,147,483,647 (~2.1 billion)
  BIGINT max: 9,223,372,036,854,775,807 (~9.2 quintillion)
  
  A table with 100K inserts/day hits INT max in ~58 years.
  But with UUIDs or high-volume systems, always use BIGINT.

STRATEGY 4: Monitor table sizes
  SELECT pg_size_pretty(pg_total_relation_size('activity_log'));
  Set alerts at 50GB, 100GB, 500GB thresholds
```

---

## Mistake Summary Table

| # | Mistake | Real Impact | One-Line Fix | Severity |
|---|---------|------------|--------------|----------|
| 1 | Wrong DB for workload | Poor performance, missing features | Match DB to workload (ACID→SQL, cache→Redis) | Critical |
| 2 | No indexes on hot queries | Full table scans, seconds-long queries | Index WHERE/JOIN/ORDER BY columns | Critical |
| 3 | N+1 queries | 100× more DB hits, slow page loads | JOIN or batch fetch | High |
| 4 | Ignoring read/write ratio | Wrong optimization strategy | Read-heavy→cache+denormalize; write-heavy→fewer indexes | High |
| 5 | Premature sharding | Massive complexity, no benefit | Optimize→vertical→replicas→cache→shard (in order) | High |
| 6 | Blobs in database | Huge DB, slow backups | Store in S3, URL in DB | Medium |
| 7 | No connection pooling | Connection exhaustion, crashes | HikariCP/pgBouncer, 10-20 pool connections | Critical |
| 8 | Over-normalization | 5+ JOINs per query, slow reads | Denormalize hot read paths | Medium |
| 9 | No transactions | Inconsistent data (money lost, stock errors) | Wrap multi-step ops in BEGIN/COMMIT | Critical |
| 10 | Ignoring data growth | Timeouts, disk full, migration failures | Partition, archive, BIGINT, monitor sizes | High |

---

## Quick Memory Card

```
WRONG DB:         Match workload. ACID→SQL. Cache→Redis. Graph→Neo4j. Writes→Cassandra.
NO INDEX:         Index WHERE/JOIN/ORDER BY. Composite: equality→range→sort. EXPLAIN to verify.
N+1:              JOIN or batch fetch. Never loop + query. ORMs hide this — use eager loading.
READ/WRITE:       Read-heavy→cache+denormalize. Write-heavy→fewer indexes, batching.
PREMATURE SHARD:  Don't. Optimize→vertical→replicas→cache→shard. Most apps never need sharding.
BLOBS:            S3 for files. DB stores only URLs. 
POOLING:          Always. 10-20 connections in pool. pgBouncer for PostgreSQL at scale.
OVER-NORMALIZE:   Source of truth normalized. Hot read paths denormalized.
TRANSACTIONS:     Multi-step ops that must succeed together → BEGIN/COMMIT/ROLLBACK.
DATA GROWTH:      Partition by time. Archive old data. BIGINT for IDs. Monitor sizes.
```

---

**Next:** [[06_Edge-Cases]]
