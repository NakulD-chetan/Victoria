# Caching and CDN — Tricks and Recognition

> **Permanent Recall:** When to immediately think "add caching": read-heavy workload, repeated queries for same key, expensive computation. Cache sizing: 80/20 rule — 20% of keys get 80% traffic; size for working set. Quick pattern: "Same for most users → CDN", "Personalized but repeated → app cache", "Computed once read many → distributed cache". TTL shortcuts: static = hours, dynamic = minutes, user-specific = minutes with invalidation.

---

## When to Immediately Think "Add Caching"

| Signal | Interpretation | Action |
|--------|----------------|--------|
| **Read-heavy** | 10:1 or 100:1 read:write | Cache reads |
| **Repeated queries** | Same key requested many times | Cache that key |
| **Expensive computation** | ML inference, aggregation, search | Cache result |
| **High DB latency** | DB is bottleneck | Cache to reduce DB load |
| **Global users** | Users far from origin | CDN for static |
| **Same response for many** | Product page, config | CDN or shared cache |

> **FAANG Tip:** "We have 100K reads/sec and 1K writes/sec — caching reads will cut DB load by 90%+."

---

## Recognition: Quick Decision Matrix

| Question | Answer |
|----------|--------|
| **Response same for most users?** | CDN |
| **Personalized but repeated per user?** | App / Distributed cache |
| **Computed once, read many times?** | Distributed cache |
| **Static assets (JS, CSS, images)?** | CDN |
| **Session / auth state?** | Distributed cache (Redis) |
| **Real-time, unique per request?** | Don't cache |

---

## Cache Sizing Heuristics

### 80/20 Rule

```
~80% of requests hit ~20% of keys.

If total keys = 1M, hot set ≈ 200K.
Cache size: 2–3× hot set for headroom → 400K–600K entries.
```

### Memory Sizing

```
Working set = Hot keys × Avg value size
Cache memory = Working set × 2 or 3 (headroom)
```

Example: 100K hot keys × 1 KB avg = 100 MB → allocate 200–300 MB.

---

## TTL Selection Shortcuts

| Data Type | TTL | Reason |
|-----------|-----|--------|
| **Static assets** | 24h–7d | Rarely changes |
| **Product catalog** | 1h–24h | Changes occasionally |
| **User profile** | 5–15 min | Changes on edit; invalidate on write |
| **Session** | Session duration | Invalid on logout |
| **API response (same for all)** | 1–5 min | Balance freshness vs load |
| **Computed (ML, aggregation)** | 5–60 min | Expensive to recompute |
| **Negative result (404)** | 1–5 min | Short to allow retry |

---

## Pattern: "Read-Through" vs "Cache-Aside" Choice

| Prefer | When |
|--------|------|
| **Cache-Aside** | App owns business logic, multiple data sources |
| **Read-Through** | Single source (DB), want cache abstraction |

---

## Pattern: Multi-Region Caching

| Approach | Use When |
|----------|----------|
| **Per-region cache** | Latency critical, accept eventual consistency |
| **Global cache** | Consistency critical, can accept higher latency |
| **Cross-region invalidation** | Need to sync after writes (event bus) |

---

## Recognition: Anti-Patterns (When NOT to Cache)

| Anti-pattern | Why |
|--------------|-----|
| Cache every DB row | Working set is small; cache hot only |
| Cache with no TTL | Stale forever on bugs |
| Cache secrets | Security risk |
| Cache for write-heavy | Writes invalidate; little benefit |
| Cache unique-per-request | No reuse |

---

## Interview One-Liners

| Topic | One-liner |
|-------|-----------|
| **When to cache** | "Read-heavy, repeated, or expensive to compute." |
| **Cache size** | "Working set × 2–3. 80/20: 20% of keys get 80% traffic." |
| **TTL** | "Static = hours, dynamic = minutes, always set one." |
| **CDN vs cache** | "Same for all → CDN. Per-user → app cache." |
| **Consistency** | "Eventual for most; bypass cache for critical reads." |

---

## Recognition: "Design a Cache" Interview Flow

When asked to design a cache system from scratch:

1. **Clarify:** Read/write ratio? Latency targets? Data size?
2. **Strategy:** Cache-Aside (default) or Read-Through?
3. **Storage:** In-memory (Redis/Memcached) for speed.
4. **Sharding:** Consistent hashing for horizontal scale.
5. **Eviction:** LRU + TTL.
6. **Consistency:** TTL + invalidation; write-through if strong.
7. **Failure:** Replicas, circuit breaker, fallback to DB.
8. **Edge cases:** Stampede, penetration, avalanche—mention mitigations.

---

## Quick Reference: Cache Key Design

| Key Pattern | Example | Invalidation |
|-------------|---------|--------------|
| `entity:id` | `user:123` | On user update |
| `entity:id:v2` | `product:456:v2` | Version bump = new cache |
| `query:hash` | `search:abc123` | TTL or query change |
| `list:page` | `products:page:1` | On catalog update |
| `session:id` | `sess:xyz` | On logout, TTL |

---

## 30-SECOND REVISION BOX

```
THINK CACHE: Read-heavy, repeated, expensive
SAME FOR ALL → CDN
PERSONALIZED + REPEATED → App cache
COMPUTED ONCE → Distributed cache
SIZE: 80/20, working set × 2–3
TTL: Static=hours, dynamic=minutes
KEY DESIGN: entity:id, entity:id:v2, query:hash
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
