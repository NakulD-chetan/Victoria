# 01 — Parquet Deep Dive

> Parquet is an **open-source columnar** storage format that organizes data as **Row Groups → Column Chunks → Pages** with a metadata footer containing statistics — enabling engines like Spark to skip irrelevant data and read only the columns you need.

---

## 1. What Is Parquet

Parquet is a **columnar file format** — instead of storing all fields of a row together (like CSV or Avro), it stores all values of a single column together. This design is optimized for analytical queries that typically read a few columns from wide tables.


| Property        | Detail                                                          |
| --------------- | --------------------------------------------------------------- |
| **Type**        | Columnar, binary                                                |
| **Created by**  | Twitter + Cloudera (2013), now Apache project                   |
| **Default in**  | Spark (`df.write.save()` defaults to Parquet)                   |
| **Schema**      | Embedded in footer (self-describing)                            |
| **Compression** | Built-in (Snappy default, also Zstd, Gzip, LZ4)                 |
| **Ecosystem**   | Spark, Hive, Presto, Trino, Athena, BigQuery, Snowflake, DuckDB |


### Why Parquet Dominates Analytics


| Capability             | How It Works                                                                                |
| ---------------------- | ------------------------------------------------------------------------------------------- |
| **Column pruning**     | `SELECT name, age` reads only those 2 column chunks — ignores the other 98 columns entirely |
| **Predicate pushdown** | `WHERE age > 30` checks min/max stats in footer — skips entire row groups that can't match  |
| **Compression**        | Same-type values stored together compress 5–10x better than row formats                     |
| **Vectorized reads**   | Engines read columns as arrays, enabling SIMD/batch CPU operations                          |


**How to explain it:** "Spark decides **what** to read using the Catalyst optimizer. Parquet enables **efficient execution** of that decision through its columnar layout and embedded statistics."

---

## 2. Parquet File Internal Structure

This is the **most asked** Parquet interview question. Know this hierarchy by heart.

```
┌──────────────────────────────────────────────────┐
│                 PARQUET FILE                       │
│                                                    │
│  ┌──────────────── Row Group 1 ──────────────┐    │
│  │                                            │    │
│  │  ┌─ Column Chunk: "name" ──────────────┐  │    │
│  │  │  Page 1 (data page)                  │  │    │
│  │  │  Page 2 (data page)                  │  │    │
│  │  │  [Dictionary Page — if dict encoding]│  │    │
│  │  └─────────────────────────────────────┘  │    │
│  │                                            │    │
│  │  ┌─ Column Chunk: "age" ───────────────┐  │    │
│  │  │  Page 1 (data page)                  │  │    │
│  │  └─────────────────────────────────────┘  │    │
│  │                                            │    │
│  │  ┌─ Column Chunk: "city" ──────────────┐  │    │
│  │  │  Page 1 (data page)                  │  │    │
│  │  └─────────────────────────────────────┘  │    │
│  │                                            │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────────── Row Group 2 ──────────────┐    │
│  │  (same structure as above)                 │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────────── FOOTER ───────────────────┐    │
│  │  Schema (column names, types, nesting)     │    │
│  │  Row group metadata:                       │    │
│  │    - num_rows per row group                │    │
│  │    - column chunk offsets                  │    │
│  │    - column statistics (min, max, null_ct) │    │
│  │  Key-value metadata (user custom)          │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  [4-byte footer length] [Magic: "PAR1"]            │
└────────────────────────────────────────────────────┘
```

### The Four Levels


| Level            | What                                          | Default Size  | Key Concept                                                            |
| ---------------- | --------------------------------------------- | ------------- | ---------------------------------------------------------------------- |
| **File**         | One Parquet file on disk                      | 128 MB – 1 GB | Contains 1+ row groups + footer                                        |
| **Row Group**    | Horizontal slice of the table (batch of rows) | ~128 MB       | Unit of parallel processing — one row group maps to one Spark task     |
| **Column Chunk** | One column's data within a row group          | Varies        | Unit of column pruning — unselected columns are never read             |
| **Page**         | Smallest unit of I/O and encoding             | ~1 MB         | Unit of compression — each page is individually compressed and encoded |


### Why the Footer Is at the End

The reader workflow explains this design:

1. Jump to end of file, read mlengthagic bytes `PAR1` to confirm it's Parquet
2. Read the 4-byte footer , then read the footer
3. From footer, get schema + row group statistics (min, max, null count per column)
4. Use statistics to decide which row groups to read and which to skip
5. Read only the needed column chunks from the selected row groups

Putting the footer at the end means the writer doesn't need to know statistics until all data is written. A single sequential write produces the entire file.

---

## 3. Encoding Types — How Parquet Shrinks Data

Parquet doesn't store raw values. It applies **encoding** first (data representation), then **compression** on top (byte-level reduction).


| Encoding                      | How It Works                                       | Best For                                          | Example                                            |
| ----------------------------- | -------------------------------------------------- | ------------------------------------------------- | -------------------------------------------------- |
| **Dictionary**                | Build a dictionary of unique values, store indices | Low-cardinality columns (status, country, gender) | `["Mumbai","Pune","Delhi"]` → `[0, 1, 2, 0, 0, 1]` |
| **Run-Length Encoding (RLE)** | Store value + count of consecutive repeats         | Sorted data, boolean columns                      | `[A,A,A,B,B]` → `[(A,3),(B,2)]`                    |
| **Bit Packing**               | Use minimum bits needed per value                  | Small integers, dictionary indices                | Values 0–7 → only 3 bits each instead of 32        |
| **Delta Encoding**            | Store differences between consecutive values       | Timestamps, auto-increment IDs                    | `[1000,1001,1002,1003]` → `[1000, +1, +1, +1]`     |
| **Plain**                     | Raw values, no encoding tricks                     | Fallback for high-cardinality data                | Random UUIDs, free-text                            |


### Dictionary + RLE Combo (Most Common in Practice)

```
Original column "status": ["active","active","active","inactive","active","inactive","inactive"]

Step 1 — Dictionary Encoding:
  Dictionary: {0: "active", 1: "inactive"}
  Indices:    [0, 0, 0, 1, 0, 1, 1]

Step 2 — RLE on the indices:
  [(0,3), (1,1), (0,1), (1,2)]

Result: 7 strings → 4 small (value, count) pairs → 80%+ compression
```

**Deep concept — Dictionary Fallback:**
Parquet uses dictionary encoding **by default** for every column. But if a column has too many unique values (high cardinality), the dictionary page exceeds a size threshold and Parquet **falls back to plain encoding**. This is why a column like `user_id` with millions of unique values won't benefit from dictionary encoding, but `country` with ~200 values will.

---

## 4. Predicate Pushdown — How Spark Skips Data

### Without Pushdown

```
Query: SELECT * FROM orders WHERE amount > 10000

Without pushdown:
  Read ALL row groups → load ALL data into memory → filter
  Read: 100 GB → Keep: 1 GB → Wasted I/O: 99 GB
```

### With Pushdown

```
Footer statistics per row group:
  Row Group 1: amount min=5, max=500        → SKIP (max < 10000)
  Row Group 2: amount min=100, max=50000    → READ (might have matches)
  Row Group 3: amount min=20000, max=99000  → READ (definitely has matches)
  Row Group 4: amount min=1, max=200        → SKIP (max < 10000)

Result: Read 2 of 4 row groups → 50% less I/O
```

### Three Levels of Data Skipping


| Level               | What Gets Skipped                                  | Where Stats Live |
| ------------------- | -------------------------------------------------- | ---------------- |
| **Row group level** | Entire row groups where min/max prove no match     | Footer metadata  |
| **Page level**      | Individual pages within a row group (Parquet 2.0+) | Page headers     |
| **Column level**    | Unneeded column chunks (column pruning)            | Schema in footer |


### What Predicates Can vs Cannot Be Pushed Down


| Works                           | Does NOT Work                             |
| ------------------------------- | ----------------------------------------- |
| `=`, `!=`, `<`, `>`, `<=`, `>=` | `LIKE '%pattern%'`                        |
| `IN (list)`                     | User-defined functions (UDFs)             |
| `IS NULL`, `IS NOT NULL`        | Functions on columns: `UPPER(name) = 'X'` |
| `BETWEEN`                       | `OR` across different columns             |
| `AND` combinations              | Complex expressions                       |


**Critical interview point:**

```sql
-- BAD: function on column breaks pushdown
WHERE YEAR(date_col) = 2024

-- GOOD: range filter preserves pushdown
WHERE date_col >= '2024-01-01' AND date_col < '2025-01-01'
```

Applying a function to the filter column means Spark can't compare the function's output against the raw min/max stats. The filter becomes a regular in-memory filter, reading all data.

---

## 5. Row Group Size — Performance Tuning


| Row Group Size          | Effect                                                                           |
| ----------------------- | -------------------------------------------------------------------------------- |
| **Too small (1 MB)**    | Too many row groups → excessive metadata → slow footer reads, high task overhead |
| **Too large (1 GB+)**   | Fewer tasks → less parallelism → memory pressure during reads                    |
| **Sweet spot (128 MB)** | Spark's default — good balance of parallelism and I/O efficiency                 |


```python
spark.conf.set("parquet.block.size", 134217728)  # 128 MB in bytes
```

**Deep concept — Row Group to Task Mapping:**
In Spark, each row group typically maps to one task. If you have 10 row groups, Spark creates ~10 tasks. This is why row group size directly affects parallelism. Too few large row groups = underutilized cluster. Too many tiny row groups = task scheduling overhead dominates actual work.

---

## 6. Small File Problem


| Aspect             | Detail                                                                             |
| ------------------ | ---------------------------------------------------------------------------------- |
| **What**           | Too many small Parquet files (each < 128 MB)                                       |
| **Why it happens** | Too many partitions during write, frequent streaming appends, over-partitioning    |
| **Why it's bad**   | Each file = separate task → driver overhead, slow file listing, metadata explosion |


### Solutions


| Solution            | How                                                    | When to Use                                                          |
| ------------------- | ------------------------------------------------------ | -------------------------------------------------------------------- |
| `coalesce(N)`       | Reduce partitions before write (no shuffle)            | When you have too many partitions and data is already distributed OK |
| `repartition(N)`    | Redistribute data into N partitions (full shuffle)     | When you need exact control over file count and data distribution    |
| `OPTIMIZE` (Delta)  | Compact small files into larger ones post-write        | Periodic maintenance on Delta tables                                 |
| Spark AQE           | `spark.sql.adaptive.coalescePartitions.enabled = true` | Automatic at runtime — Spark merges small partitions                 |
| `maxRecordsPerFile` | `df.write.option("maxRecordsPerFile", 1000000)`        | Cap file size during write                                           |


**Deep concept — coalesce vs repartition:**
`coalesce(N)` reduces partitions by merging them locally — no shuffle, but can create skewed files. `repartition(N)` does a full shuffle to distribute data evenly — more expensive but produces uniform files. For writes, `repartition` is safer; for quick reduction before a narrow write, `coalesce` is faster.

---

## 7. Schema Evolution(structre od fata changes over time but system still can rread old and newdata toggetthr


| Operation         | Supported?      | Detail                                                                |
| ----------------- | --------------- | --------------------------------------------------------------------- |
| **Add column**    | Yes             | Old files return NULL for the new column                              |
| **Remove column** | Yes (read side) | Data still exists in old files; readers simply ignore it              |
| **Rename column** | No              | Parquet matches by **name** — rename = drop old + add new → data loss |
| **Change type**   | Limited         | Compatible promotions only: int → long, float → double                |


```python
df = spark.read.option("mergeSchema", "true").parquet("path/")
```

`mergeSchema` scans all files and unions their schemas. It's slower (reads every file's footer) but handles files written at different times with different schemas.

**Why this matters:** Parquet's schema evolution is **limited** compared to Avro (which has full backward/forward compatibility) and Iceberg (which uses column IDs for safe renames). For production pipelines, use **Delta Lake or Iceberg** on top of Parquet — they manage schema evolution properly.

---

## 8. Spark Parquet Configuration Reference


| Config                                  | Default     | What It Does                                          |
| --------------------------------------- | ----------- | ----------------------------------------------------- |
| `spark.sql.parquet.filterPushdown`      | `true`      | Enable/disable predicate pushdown                     |
| `spark.sql.parquet.mergeSchema`         | `false`     | Merge schemas from all files on read                  |
| `spark.sql.parquet.compression.codec`   | `snappy`    | Compression codec (snappy, gzip, zstd, lz4, none)     |
| `parquet.block.size`                    | `134217728` | Row group size in bytes (128 MB)                      |
| `parquet.page.size`                     | `1048576`   | Page size in bytes (1 MB)                             |
| `parquet.enable.dictionary`             | `true`      | Enable dictionary encoding                            |
| `spark.sql.parquet.writeLegacyFormat`   | `false`     | Write in Parquet format compatible with older readers |
| `spark.sql.parquet.int96AsTimestamp`    | `true`      | Read INT96 as Spark timestamp (Hive compatibility)    |
| `spark.sql.parquet.outputTimestampType` | `INT96`     | Timestamp type in output (INT96 or TIMESTAMP_MICROS)  |


### Parquet Write Modes

Spark write modes control what happens when the output path already exists:


| Mode                          | Behavior                                                                        |
| ----------------------------- | ------------------------------------------------------------------------------- |
| `**errorifexists`** (default) | Throws error if output path already exists — safest                             |
| `**overwrite`**               | Deletes existing data and writes new data — dangerous, can lose data            |
| `**append**`                  | Adds new files alongside existing ones — common for incremental loads           |
| `**ignore**`                  | Silently does nothing if output path exists — like `CREATE TABLE IF NOT EXISTS` |


```python
df.write.mode("overwrite").parquet("output/orders/")
df.write.mode("append").parquet("output/orders/")
```

**Interview tip:** "In production, I prefer `append` for incremental pipelines and `overwrite` only with partitioned writes using `partitionBy()` + `spark.sql.sources.partitionOverwriteMode = dynamic` so only affected partitions are overwritten, not the entire table."

---

## 9. Inspecting Parquet Metadata (Debugging)

```python
# PyArrow — inspect footer, row groups, column statistics
import pyarrow.parquet as pq

meta = pq.read_metadata("orders.parquet")
print(f"Row groups: {meta.num_row_groups}")
print(f"Total rows: {meta.num_rows}")
print(f"Columns: {meta.num_columns}")

for i in range(meta.num_row_groups):
    rg = meta.row_group(i)
    print(f"Row Group {i}: {rg.num_rows} rows")
    for j in range(rg.num_columns):
        col = rg.column(j)
        if col.statistics:
            print(f"  {col.path_in_schema}: min={col.statistics.min}, max={col.statistics.max}")
```

```bash
# CLI tools
parquet-meta file.parquet    # show footer metadata
parquet-head file.parquet    # show first few rows
```

---

## 10. Interview Questions & How to Answer

**Q: "What is the internal structure of Parquet?"**

> File → Row Groups (~~128 MB) → Column Chunks (one per column per row group) → Pages (~~1 MB). The footer at the end contains the schema and per-column min/max/null statistics for each row group.

**Q: "How does predicate pushdown work in Parquet?"**

> When Spark has a filter like `WHERE age > 30`, it reads the Parquet footer first and checks the min/max stats for `age` in each row group. If a row group's max is 25, it's impossible for any row to match, so Spark skips the entire row group. This can eliminate 50–90% of I/O.

**Q: "What encoding does Parquet use?"**

> Dictionary encoding by default — it builds a dictionary of unique values and stores integer indices. For sorted data it adds RLE (run-length encoding). If a column has too many unique values, it falls back to plain encoding. Delta encoding is used for timestamps and sequential IDs.

**Q: "Why is columnar faster for analytics?"**

> Three reasons: (1) column pruning — reads only needed columns, skipping the rest entirely, (2) better compression — same-type values compress much better than mixed-type rows, (3) vectorized execution — engines process columns as arrays, enabling CPU-level batch operations.

**Q: "What's the small file problem and how do you fix it?"**

> Too many small Parquet files (<128 MB) create excessive task scheduling overhead and slow file listing. Fix with `coalesce()` or `repartition()` before writing, Delta Lake's `OPTIMIZE` command for post-write compaction, or Spark AQE's automatic partition coalescing.

**Q: "Does Parquet support schema evolution?"**

> Limited. Adding columns works (old files return null). Removing columns works on the read side. But renaming columns is treated as drop + add (data loss), and type changes only work for compatible promotions like int → long. For full schema evolution, use Delta Lake or Iceberg on top of Parquet.

**Q: "Why shouldn't you apply functions on filter columns?"**

> It breaks predicate pushdown. `WHERE YEAR(date_col) = 2024` forces Spark to read all data and compute `YEAR()` for every row. `WHERE date_col >= '2024-01-01' AND date_col < '2025-01-01'` lets Spark compare raw values against min/max stats and skip data.

---

---

