# DDL Commands — Data Definition Language

> **DDL = Data Definition Language**
> Table ka **structure** banao, modify karo, ya hatao.
> DDL commands **auto-commit** hote hain — ek baar execute kiya toh ROLLBACK nahi ho sakta!

---

## DDL Commands Overview

```
DDL Commands
├── CREATE    → Naya table/database banao
├── ALTER     → Existing table ka structure change karo
├── DROP      → Table/database completely delete karo
├── TRUNCATE  → Table ka sab data hatao, structure rahe
└── RENAME    → Table/column ka naam badlo
```

---

## 1. CREATE — Naya Banao

### Create Database:

```sql
CREATE DATABASE school_db;
USE school_db;
```

### Create Table:

> **Syntax:**
```sql
CREATE TABLE table_name (
    column1 datatype constraint,
    column2 datatype constraint,
    ...
);
```

### Example — Students Table:

```sql
CREATE TABLE students (
    student_id   INT PRIMARY KEY AUTO_INCREMENT,
    first_name   VARCHAR(50) NOT NULL,
    last_name    VARCHAR(50) NOT NULL,
    email        VARCHAR(100) UNIQUE,
    age          INT CHECK (age >= 15 AND age <= 50),
    marks        DECIMAL(5,2) DEFAULT 0.00,
    city         VARCHAR(50) DEFAULT 'Unknown',
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Example — Departments Table (for join examples later):

```sql
CREATE TABLE departments (
    dept_id    INT PRIMARY KEY AUTO_INCREMENT,
    dept_name  VARCHAR(100) NOT NULL UNIQUE,
    location   VARCHAR(100)
);
```

### Example — Employees Table (with Foreign Key):

```sql
CREATE TABLE employees (
    emp_id      INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    salary      DECIMAL(10,2) NOT NULL,
    dept_id     INT,
    manager_id  INT,
    hire_date   DATE,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
);
```

> **Dhyan Do:**
> - `manager_id` **SELF-REFERENCING** Foreign Key hai — same table ko point karta hai!
> - Yeh **Self Join** ke concept se related hai (05-Joins mein detail mein)

---

### CREATE TABLE AS (Copy Table)

> Existing table se naya table banao (data ke saath ya bina data ke):

```sql
-- Structure + Data copy
CREATE TABLE students_backup AS
SELECT * FROM students;

-- Sirf structure copy (no data)
CREATE TABLE students_empty AS
SELECT * FROM students WHERE 1 = 0;
```

> **Interview Tip:** `WHERE 1 = 0` hamesha FALSE hota hai, toh koi row nahi aayegi — sirf structure copy hoga.

---

## 2. ALTER — Table Structure Change Karo

> ALTER command se existing table modify kar sakte ho — columns add/remove/change, constraints add karo, etc.

### a) ADD Column — Naya column add karo:

```sql
ALTER TABLE students ADD phone VARCHAR(15);

-- Multiple columns ek saath:
ALTER TABLE students
    ADD address VARCHAR(200),
    ADD pincode VARCHAR(10);
```

### b) MODIFY / ALTER Column — Data type ya constraint change karo:

```sql
-- MySQL syntax:
ALTER TABLE students MODIFY phone VARCHAR(20) NOT NULL;

-- PostgreSQL syntax:
ALTER TABLE students ALTER COLUMN phone TYPE VARCHAR(20);
ALTER TABLE students ALTER COLUMN phone SET NOT NULL;

-- SQL Server syntax:
ALTER TABLE students ALTER COLUMN phone VARCHAR(20) NOT NULL;
```

> **Dhyan Do:** MODIFY ka syntax har database mein **thoda alag** hota hai!

### c) DROP Column — Column hatao:

```sql
ALTER TABLE students DROP COLUMN pincode;
```

> **Warning:** DROP COLUMN se us column ka **saara data permanently delete** ho jaata hai!

### d) RENAME Column:

```sql
-- MySQL 8+:
ALTER TABLE students RENAME COLUMN phone TO contact_number;

-- PostgreSQL:
ALTER TABLE students RENAME COLUMN phone TO contact_number;

-- SQL Server:
EXEC sp_rename 'students.phone', 'contact_number', 'COLUMN';
```

### e) ADD Constraint:

```sql
ALTER TABLE students ADD CONSTRAINT chk_age CHECK (age >= 15);
ALTER TABLE students ADD CONSTRAINT uq_email UNIQUE (email);
```

### f) DROP Constraint:

```sql
-- MySQL:
ALTER TABLE students DROP CHECK chk_age;

-- PostgreSQL / SQL Server:
ALTER TABLE students DROP CONSTRAINT chk_age;
```

---

## 3. DROP — Complete Delete

> **DROP puri table delete kar deta hai — structure + data + constraints — sab kuch!**

```sql
DROP TABLE students;           -- Table delete
DROP TABLE IF EXISTS students; -- Error nahi aayegi agar table exist nahi karti
DROP DATABASE school_db;       -- Pura database delete
```

> **Warning:** DROP **irreversible** hai — no ROLLBACK possible!
> **Interview mein puchha jaata hai:** "DROP vs TRUNCATE vs DELETE kya difference hai?"

---

## 4. TRUNCATE — Data Hatao, Structure Rakho

> **Table ka sara data delete kardo, but table structure (columns, constraints) as it is rahe.**

```sql
TRUNCATE TABLE students;
```

> **TRUNCATE vs DELETE:**

| Feature | TRUNCATE | DELETE |
|---------|----------|--------|
| **Kya hatata hai** | **ALL rows** | Specific rows (WHERE se) ya all |
| **WHERE clause** | ❌ Nahi use kar sakte | ✅ Kar sakte ho |
| **Speed** | **Bahut fast** (drop + recreate) | Slow (row-by-row delete) |
| **ROLLBACK** | ❌ Nahi ho sakta (DDL — auto-commit) | ✅ Ho sakta hai (DML) |
| **Auto-Increment Reset** | ✅ Reset ho jaata hai | ❌ Reset nahi hota |
| **Triggers Fire** | ❌ Nahi | ✅ Haan |
| **Logging** | Minimal logging | Full logging (har row log hoti hai) |
| **Space Release** | ✅ Space free hota hai | ❌ Nahi hota (until OPTIMIZE) |
| **Command Type** | DDL | DML |

```sql
-- DELETE example — specific rows
DELETE FROM students WHERE city = 'Pune';

-- DELETE example — all rows (slow, but rollback possible)
DELETE FROM students;

-- TRUNCATE — all rows (fast, no rollback)
TRUNCATE TABLE students;
```

> **Interview Answer (DROP vs TRUNCATE vs DELETE):**
> - **DROP** = Table hi hata do (structure + data gone)
> - **TRUNCATE** = Data hatao, structure rakho (fast, no rollback)
> - **DELETE** = Specific data hatao (slow, rollback possible, triggers fire)

---

## 5. RENAME — Naam Badlo

```sql
-- MySQL:
RENAME TABLE students TO learners;

-- PostgreSQL:
ALTER TABLE students RENAME TO learners;

-- SQL Server:
EXEC sp_rename 'students', 'learners';
```

---

## ON DELETE and ON UPDATE (Foreign Key Actions)

> Jab parent table ki row delete/update ho, toh child table mein kya ho?

```sql
CREATE TABLE enrollments (
    enrollment_id INT PRIMARY KEY,
    student_id    INT,
    course_name   VARCHAR(100),
    FOREIGN KEY (student_id) REFERENCES students(student_id)
        ON DELETE CASCADE
        ON UPDATE SET NULL
);
```

| Action | Kya Hota Hai | Example |
|--------|-------------|---------|
| **CASCADE** | Parent delete → child bhi delete | Student delete → uska enrollment bhi delete |
| **SET NULL** | Parent delete → child FK = NULL | Student delete → enrollment.student_id = NULL |
| **SET DEFAULT** | Parent delete → child FK = default value | Rarely used |
| **RESTRICT / NO ACTION** | Delete hone hi nahi dega | Error aayegi if child exists |

> **Interview Tip:** "What happens when you delete a parent row that has child references?"
> Answer depends on ON DELETE action — CASCADE, SET NULL, ya RESTRICT.

---

## Practical Example — Complete Schema Design

```sql
-- Step 1: Database banao
CREATE DATABASE company_db;
USE company_db;

-- Step 2: Departments table
CREATE TABLE departments (
    dept_id    INT PRIMARY KEY AUTO_INCREMENT,
    dept_name  VARCHAR(100) NOT NULL UNIQUE,
    location   VARCHAR(100) DEFAULT 'Head Office'
);

-- Step 3: Employees table (FK → departments)
CREATE TABLE employees (
    emp_id     INT PRIMARY KEY AUTO_INCREMENT,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(100) UNIQUE NOT NULL,
    salary     DECIMAL(10,2) CHECK (salary > 0),
    dept_id    INT,
    manager_id INT,
    hire_date  DATE DEFAULT (CURRENT_DATE),
    is_active  BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id)
        ON DELETE SET NULL,
    FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
        ON DELETE SET NULL
);

-- Step 4: Projects table
CREATE TABLE projects (
    project_id   INT PRIMARY KEY AUTO_INCREMENT,
    project_name VARCHAR(200) NOT NULL,
    budget       DECIMAL(15,2),
    start_date   DATE,
    end_date     DATE,
    CHECK (end_date > start_date)
);

-- Step 5: Employee-Project mapping (Many-to-Many)
CREATE TABLE emp_projects (
    emp_id     INT,
    project_id INT,
    role       VARCHAR(50) DEFAULT 'Member',
    PRIMARY KEY (emp_id, project_id),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);
```

> **Dhyan Do:**
> - `emp_projects` table mein **Composite Primary Key** hai → `(emp_id, project_id)`
> - Yeh **Many-to-Many** relationship hai → ek employee multiple projects mein, ek project mein multiple employees
> - ON DELETE CASCADE → employee delete toh uska assignment bhi delete

---

## SHOW / DESCRIBE Commands (Useful)

```sql
SHOW DATABASES;           -- Sab databases dikha do
SHOW TABLES;              -- Current database ki tables dikha do
DESCRIBE students;        -- Table ka structure dikha do (columns, types, constraints)
DESC students;            -- Short form
SHOW CREATE TABLE students; -- CREATE statement dikha do (exact DDL)
```

---

## Quick Memory Card

| Command | Kya Karta Hai | Rollback? | Structure? | Data? |
|---------|---------------|-----------|-----------|-------|
| **CREATE** | Naya table/DB banao | ❌ | New ✅ | — |
| **ALTER** | Structure modify karo | ❌ | Changed ✅ | Intact |
| **DROP** | Sab kuch delete karo | ❌ | Gone ❌ | Gone ❌ |
| **TRUNCATE** | Data hatao, structure rakho | ❌ | Intact ✅ | Gone ❌ |
| **DELETE** | Rows hatao (DML hai actually) | ✅ | Intact ✅ | Selected rows gone |
| **RENAME** | Naam badlo | ❌ | Renamed ✅ | Intact |

---

*Notes Source: SQL DDL commands + Interview preparation material*
