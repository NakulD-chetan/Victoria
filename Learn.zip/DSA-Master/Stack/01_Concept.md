# Stack — Concept

---

## Core Idea (2 Lines)

**Stack processes the most recent element first. Monotonic stack keeps elements in increasing or decreasing order**

---

## LIFO Intuition

```
PUSH:  A → B → C → D
       ┌───┐
       │ D │  ← TOP (most recent)
       │ C │
       │ B │
       │ A │  ← BOTTOM (oldest)
       └───┘

POP order: D → C → B → A  (reverse of push order)
```

**Key:** Whatever you put in last comes out first. No random access — only top.

---

## Monotonic Stack — The FAANG Favorite

A **monotonic stack** maintains elements in strictly increasing or strictly decreasing order (from bottom to top).

### Why It Matters


| Problem Type                        | Brute Force                    | Monotonic Stack                        |
| ----------------------------------- | ------------------------------ | -------------------------------------- |
| Next Greater Element (each element) | O(n²) — for each i, scan right | O(n) — each element pushed/popped once |
| Next Smaller Element                | Same                           | Same                                   |
| Largest Rectangle in Histogram      | O(n²) or O(n³)                 | O(n)                                   |
| Trapping Rain Water (variant)       | O(n²)                          | O(n)                                   |


---

## Stack for Expression Evaluation

### Infix → Postfix (Shunting Yard)

```
Infix:   3 + 4 * 2 - ( 1 + 5 )
Postfix: 3 4 2 * + 1 5 + -

Operator stack: lower precedence waits; higher pops lower
```


| Operator | Precedence   | Associativity |
| -------- | ------------ | ------------- |
| +, -     | 1            | Left          |
| *, /     | 2            | Left          |
| ^        | 3            | Right         |
| (        | 0 (special)  | —             |
| )        | pops until ( | —             |


### Postfix Evaluation

```
Postfix: 3 4 2 * + 1 5 + -
Stack:   [3] → [3,4] → [3,4,2] → [3,8] → [11] → [11,1] → [11,1,5] → [11,6] → [5]
```

---

## Parentheses Matching

```
Valid:   ( ) [ ] { }  →  push open, pop on close if matching
Invalid: ( ]  →  type mismatch
Invalid: ( ) )  →  pop from empty stack
Invalid: ( ( )  →  stack non-empty at end
```

---

## Next Greater Element Pattern

**Problem:** For each element, find the next element to the right that is greater.

```
Array:  [2, 1, 4, 3, 5]
NGE:    [4, 4, 5, 5, -1]

  idx:  0  1  2  3  4
  arr:  2  1  4  3  5
  NGE:  4  4  5  5 -1
```

**Monotonic decreasing stack:** When `arr[i] > stack.top()`, `arr[i]` is the NGE for `stack.top()`.

---

## When NOT to Use Stack


| Scenario                             | Why Not                          | Use Instead                |
| ------------------------------------ | -------------------------------- | -------------------------- |
| Need FIFO order                      | Stack is LIFO                    | Queue                      |
| Need random access / middle elements | Stack only has top               | Array, Deque               |
| Need to process oldest first         | Stack processes newest first     | Queue                      |
| "Next greater" but need to look LEFT | Monotonic stack scans left→right | Precompute or reverse scan |
| Recursion depth very large           | Stack overflow risk              | Iterative + explicit stack |
| Need sorted order of all elements    | Stack maintains partial order    | Heap, Sorted Set           |


---



