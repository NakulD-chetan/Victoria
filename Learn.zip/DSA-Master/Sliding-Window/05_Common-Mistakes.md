# Sliding Window — Common Mistakes (Python + C++ + Rust)

> **Every mistake here has been made in real FAANG interviews. Organized by pattern AND by language.**

---

## Pattern Mistakes (All Languages)

### Mistake 1: `if` Instead of `while` for Variable Window

```
WRONG:  if len(freq) > k:    → Only shrinks ONCE
RIGHT:  while len(freq) > k:  → Shrinks until valid
```

**Why it happens:** Thinking "one removal fixes it." But removing one element might not restore validity.

**Rule:** Variable window = ALWAYS `while`. Fixed window = `if` is OK.

---

### Mistake 2: Update Answer at Wrong Time

| Goal | Update When |
|------|-------------|
| **Longest** (maximize) | AFTER shrinking — window is now valid |
| **Shortest** (minimize) | DURING shrinking — window is still valid |

**Wrong:** Updating inside shrink loop for longest problems (window is INVALID there).

---

### Mistake 3: Forgetting to Delete Zero-Count Keys

```python
freq[s[left]] -= 1
# MISSING: if freq[s[left]] == 0: del freq[s[left]]
# len(freq) now counts dead keys → distinct count is WRONG
```

---

### Mistake 4: Off-by-One in Window Size

```
WRONG:  window_size = right - left        → Misses 1 element
RIGHT:  window_size = right - left + 1    → Correct
```

---

### Mistake 5: Infinite Loop — Forgetting `left += 1`

```python
while current_sum > target:
    current_sum -= arr[left]
    # MISSING: left += 1  → INFINITE LOOP
```

---

### Mistake 6: Sliding Window with Negative Numbers

Sliding window for sum constraints **assumes monotonicity**: adding increases sum, removing decreases sum. Negatives break this.

**Fix:** For negatives, use prefix sum + hash map instead.

---

### Mistake 7: Wrong Shrink Comparison

```
"at most k distinct" → shrink when > k  (NOT >= k)
"exactly k" → use atMost(k) - atMost(k-1) decomposition
```

---

## C++ Specific Mistakes

### C++ Mistake 1: Signed/Unsigned Comparison Warning

```cpp
// WRONG: Compiler warning, potential bug
for (int right = 0; right < s.size(); right++)  // s.size() is size_t (unsigned)

// FIX: Cast explicitly
for (int right = 0; right < (int)s.size(); right++)
```

**Why:** `size()` returns `size_t` (unsigned). Comparing with `int` (signed) causes implicit conversion issues.

---

### C++ Mistake 2: Iterator Invalidation

```cpp
// WRONG: Erasing while iterating
for (auto it = freq.begin(); it != freq.end(); it++) {
    if (it->second == 0)
        freq.erase(it);    // INVALIDATES iterator!
}

// FIX: Use erase return value
for (auto it = freq.begin(); it != freq.end(); ) {
    if (it->second == 0)
        it = freq.erase(it);   // Returns next valid iterator
    else
        ++it;
}
```

---

### C++ Mistake 3: Pass-by-Value Instead of Reference

```cpp
// WRONG: Copies entire vector
int solve(vector<int> arr) { ... }        // O(n) copy!

// RIGHT: Pass by reference
int solve(vector<int>& arr) { ... }       // O(1) reference
int solve(const vector<int>& arr) { ... } // O(1), can't modify
```

---

### C++ Mistake 4: Wrong Container Choice

| Need | Wrong Choice | Right Choice |
|------|-------------|-------------|
| O(1) lookup by key | `map` (O(log n)) | `unordered_map` (O(1) avg) |
| Ordered iteration | `unordered_map` | `map` |
| O(1) frequency count | `set` | `unordered_map` |
| Key existence check | `m[key]` (creates entry!) | `m.count(key)` or `m.find(key)` |

**Critical:** `m[key]` in C++ **auto-inserts** a default value if key doesn't exist! Use `count()` or `find()` to check without inserting.

---

### C++ Mistake 5: Not Reserving Vector Capacity

```cpp
// SLOW: Multiple reallocations
vector<int> result;
for (...) result.push_back(x);

// FAST: Pre-allocate
vector<int> result;
result.reserve(expected_size);  // One allocation
```

---

## Rust Specific Mistakes

### Rust Mistake 1: Borrow Checker — Mutable + Immutable Simultaneously

```rust
// WRONG: Can't borrow as mutable and immutable at same time
let val = freq[&key];           // Immutable borrow
*freq.get_mut(&key).unwrap() -= 1;  // Mutable borrow → CONFLICT

// FIX: Use entry API or separate the operations
if let Some(count) = freq.get_mut(&key) {
    *count -= 1;
    if *count == 0 { /* ... */ }
}
```

---

### Rust Mistake 2: Ownership Move in Loop

```rust
// WRONG: s is moved into the loop, can't use after
for ch in s.chars() { ... }
println!("{}", s);  // ERROR: s was moved (if s is String, not &str)

// FIX: Borrow the string
for ch in s.chars() { ... }  // .chars() borrows, doesn't move for &str
// Or explicitly: for ch in s.as_str().chars() { ... }
```

**Key insight:** `&str` is borrowed, so `.chars()` is fine. But `String` ownership matters.

---

### Rust Mistake 3: Indexing Strings Directly

```rust
// WRONG: Rust strings are UTF-8, not byte-indexable
let ch = s[0];  // ERROR: String doesn't implement Index<usize>

// FIX: Convert to Vec<char> first (for ASCII problems)
let chars: Vec<char> = s.chars().collect();
let ch = chars[0];  // OK: Vec supports indexing

// Or use .as_bytes() for ASCII-only
let ch = s.as_bytes()[0] as char;  // Only for ASCII!
```

---

### Rust Mistake 4: Forgetting to Dereference

```rust
// WRONG: Comparing reference with value
let count = freq.get(&key);  // Returns Option<&i32>
if count == 0 { ... }         // ERROR: comparing &i32 with i32

// FIX: Dereference
if let Some(&count) = freq.get(&key) {  // Pattern match dereferences
    if count == 0 { ... }
}
// Or: if *count == 0
```

---

### Rust Mistake 5: Using `.clone()` Unnecessarily

```rust
// WRONG: Cloning when not needed (wasteful)
let key = s_chars[left].clone();  // char is Copy, no clone needed!

// RIGHT: char, i32, usize, bool are Copy types — just use them
let key = s_chars[left];  // Copied automatically
```

**Rule:** Types that implement `Copy` (primitives, char, bool) don't need `.clone()`.

---

## Python Specific Mistakes

### Python Mistake 1: Accidental O(n) in Loop

```python
# WRONG: 'in' on list is O(n)
if element in my_list:    # O(n) scan!

# RIGHT: Use set for O(1) lookup
if element in my_set:     # O(1) hash lookup
```

---

### Python Mistake 2: Shallow Copy of List

```python
# WRONG: Both point to same list
path = current_path       # Reference copy!
path.append(x)            # Modifies current_path too!

# RIGHT: Deep copy
path = current_path[:]    # Slice copy
path = list(current_path) # Constructor copy
path = current_path.copy() # Explicit copy
```

---

### Python Mistake 3: Default Mutable Arguments

```python
# WRONG: Default list is shared across calls
def solve(arr, seen=[]):    # seen is created ONCE, shared!
    seen.append(arr[0])

# RIGHT: Use None as default
def solve(arr, seen=None):
    if seen is None:
        seen = []
```

---

### Python Mistake 4: Integer Division Trap

```python
# Python 3: / gives float, // gives int
7 / 2    # → 3.5 (float)
7 // 2   # → 3 (int, floors toward -inf)
-7 // 2  # → -4 (NOT -3! Floors toward negative infinity)

# For truncation toward zero (like C++):
int(-7 / 2)  # → -3
```

---

### Python Mistake 5: Not Using `collections` Module

```python
# SLOW: Manual frequency counting
freq = {}
for ch in s:
    if ch in freq:
        freq[ch] += 1
    else:
        freq[ch] = 1

# FAST: Use Counter
from collections import Counter
freq = Counter(s)  # One line!

# Or defaultdict
from collections import defaultdict
freq = defaultdict(int)
for ch in s:
    freq[ch] += 1  # No key check needed
```

---

## Mistake Summary Table

| # | Mistake | Language | Impact |
|---|---------|---------|--------|
| 1 | if vs while | All | Wrong answer |
| 2 | Update timing | All | Wrong answer |
| 3 | Zero-count keys | All | Wrong distinct count |
| 4 | Window size ±1 | All | Off by one |
| 5 | Signed/unsigned | C++ | Undefined behavior |
| 6 | Iterator invalidation | C++ | Crash/UB |
| 7 | Pass-by-value | C++ | TLE (slow) |
| 8 | Borrow conflict | Rust | Compile error |
| 9 | String indexing | Rust | Compile error |
| 10 | O(n) list `in` | Python | TLE |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN MISTAKES:   if→while, update timing, zero-count cleanup
C++ TRAPS:          signed/unsigned, iterator invalidation, pass-by-value,
                    m[key] auto-inserts, wrong container
RUST TRAPS:         borrow checker, string indexing, dereference,
                    ownership moves, unnecessary clone
PYTHON TRAPS:       O(n) list 'in', shallow copy, mutable defaults,
                    integer division, not using collections
INTERVIEW LINE:     "Let me verify: shrink condition uses while,
                    I delete zero-count keys, and window size
                    is right - left + 1."
```

---

## 30-SECOND REVISION BOX

```
ALL:     while (not if) for variable | delete zero-count | size = R-L+1
C++:     (int)size() | &ref params | .count() not [] | .erase(it) returns next
RUST:    .entry().or_insert() | chars().collect() | *deref | no string[i]
PYTHON:  set not list for 'in' | Counter/defaultdict | [:] for copy
```
