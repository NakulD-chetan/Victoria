# executeTake & Show Jobs — Problem List

> **18 prediction tasks.** Goal: predict the exact number of `showString` jobs *before* running the script. Then verify in the Spark UI Jobs tab.

---

## Reference Helper Function

For all "predict job count" problems below, use this trace:

```
init = spark.sql.limit.initialNumPartitions      (default 1)
f    = spark.sql.limit.scaleUpFactor             (default 4)
n    = show(k) -> k+1   |   take(k) -> k

Iteration partition counts: init, init*f, init*f^2, ...   (each capped at remaining P)
Stop when: cumulative_rows >= n   OR   all P partitions consumed.
Job count = number of iterations.
```

---

## 10 MUST-DO Tasks

| # | Scenario                                                                                              | Predicted Jobs | Concept Tag                  |
|---|-------------------------------------------------------------------------------------------------------|----------------|------------------------------|
| 1 | `df.show(20)` where partition 0 has 100 rows                                                          | 1              | Iter 1 fills buffer          |
| 2 | `df.show(20)` where 8 partitions each have 1 row                                                      | 3              | Sparse loop unfolds          |
| 3 | `df.show(20)` where 200 partitions, only partition 199 has 30 rows                                    | 5              | Worst-case loop expansion    |
| 4 | `df.take(1)` where partition 0 has 1 row                                                              | 1              | Smallest n, easy exit        |
| 5 | `df.take(100)` where 200 partitions, ~1 row each                                                      | 5–6            | Spread evenly                |
| 6 | `df.show()` after `df.repartition(1)`                                                                 | 1              | Single partition, single job |
| 7 | `df.show()` after `df.repartition(8)` with `initialNumPartitions=8`                                   | 1              | Config override              |
| 8 | `df.tail(20)` on 8-partition sparse df                                                                | 3              | Same loop, reverse direction |
| 9 | `df.limit(50).collect()` on 100-partition df                                                          | 1–4            | CollectLimitExec → executeTake |
|10 | `df.show()` with AQE on, post-shuffle (1 shuffle in lineage)                                          | 3 + AQE bookkeeping | Mix of executeTake + AQE |

---

## Complete 18-Task Progression

### Easy (1–6) — Default Configs

| # | Code / Setup                                                              | Pred. Jobs | Reasoning                                                                          |
|---|---------------------------------------------------------------------------|------------|------------------------------------------------------------------------------------|
| 1 | 1 partition, 1000 rows, `df.show(20)`                                      | 1          | Iter 1 reads 1 part, gets 21 rows ≥ 21 → stop                                       |
| 2 | 4 partitions, 100 rows in partition 0, `df.show(20)`                       | 1          | Iter 1 satisfies                                                                    |
| 3 | 8 partitions, 1 row each, `df.show(20)`                                    | 3          | 1, 4, 3 = 8 cumulative; never reaches 20 rows                                       |
| 4 | 200 partitions, 1 row each, `df.show(20)`                                  | 4          | 1 → 4 → 16 → 64 → 200 (capped) but stops earlier when rows ≥ 20                     |
| 5 | 8 partitions, all rows in partition 7, `df.show(20)`                       | 3          | Loop has to scan all 8                                                              |
| 6 | 1 partition, `df.show(0)`                                                  | 0          | n=0 short-circuits before the loop                                                  |

### Medium (7–13) — Tuning the Configs

| # | Setup                                                                              | Pred. Jobs | Reasoning                                                              |
|---|------------------------------------------------------------------------------------|------------|------------------------------------------------------------------------|
| 7 | 8 partitions sparse, `initialNumPartitions=8`                                       | 1          | First iter covers all parts                                            |
| 8 | 8 partitions sparse, `scaleUpFactor=2` (default 4)                                  | 4          | 1 → 2 → 4 → 1 (cap)                                                    |
| 9 | 200 partitions, `initialNumPartitions=200`                                          | 1          | One-shot                                                               |
| 10| `df.show(1000)` on 8 partitions with 100 rows each                                 | 1          | 8 × 100 = 800 < 1000, but iter 1 reads enough rows in part 0           |
| 11| `df.show(1000)` on 8 partitions with 1 row each                                    | 3          | Same as Task 3 — bounded by partitions                                 |
| 12| `df.limit(5).show()`                                                                | 1          | `limit(5)` is a logical plan node; CollectLimitExec uses executeTake(6)|
| 13| `df.head()` (no arg) on 8-part sparse df                                            | 3          | head() = head(1); loop until 1 row found across sparse parts           |

### Hard (14–18) — AQE / Mixed Effects

| # | Setup                                                                                                         | Pred. Jobs | Reasoning                                                                  |
|---|---------------------------------------------------------------------------------------------------------------|------------|----------------------------------------------------------------------------|
| 14| AQE on, `df.show()` after groupBy (1 shuffle)                                                                  | 3 + 1      | 3 executeTake jobs + 1 AQE bookkeeping                                     |
| 15| `df.show(); df.show()` (called twice on same DataFrame, no cache)                                              | 6          | 2 × 3, no reuse without cache                                              |
| 16| `df.cache(); df.count(); df.show()` (cache materialized first)                                                  | 1 + 3      | count = 1, show still iterates but most stages skipped                     |
| 17| `df.show()` followed by `df.show(50)` on cached df                                                              | 3 + 2      | 2nd show may need fewer iters depending on rows                            |
| 18| Streaming `dfStream.writeStream.foreachBatch(lambda b, _: b.show())` per micro-batch                            | per-batch loop | Each batch triggers fresh executeTake — multi-job each batch          |

---

## Strategy Notes

### Task 3 — The Classic "8-Partition Sparse" Case

```
Setup:     P = 8, sparse rows
Trace:     Iter 1: 1 part, ~0 rows
           Iter 2: min(1*4, 7) = 4 parts (parts 1..4)
           Iter 3: min(5*4, 3) = 3 parts (parts 5..7)
           partsScanned = 8 -> exit
Result:    3 jobs.
Memorize:  This is the canonical example used in interviews.
```

### Task 4 — 200 Partitions, 1 Row Each

```
Setup:     P = 200, ~1 row per part, n = 21
Trace:     Iter 1: 1 part   -> 1 row  (need 20 more)
           Iter 2: 4 parts  -> 5 rows
           Iter 3: 16 parts -> 21 rows -> STOP
Result:    3 jobs.
Insight:   With 1 row per part, you need ~21 partitions; iter 3 covers 1+4+16=21.
```

### Task 7 — Force 1 Job

```python
spark = (SparkSession.builder
    .config("spark.sql.limit.initialNumPartitions", "8")  # match P
    .getOrCreate())

df_final.show()       # iter 1 reads all 8 parts -> always 1 job
```

```
Trade-off: First iter does ALL the work. Fine when you'd
           have to scan everything anyway (sparse data).
           Wasteful when first part already has enough rows.
```

### Task 14 — AQE Distortion

```
Without AQE:   3 jobs in UI
With AQE:      4-5 rows in UI
                3 = executeTake iters
                1-2 = AQE planning runJob (Description: "runJob at ThreadPoolExecutor.java:1149")
Tell apart:    AQE jobs show 0/X tasks (all skipped) and stages (all skipped).
               Real executeTake jobs run actual tasks.
```

### Task 15 — Same df, Two `show()`s

```
Without cache:  6 jobs (3 + 3), full upstream re-runs both times.
With cache (after first show):  3 + 1 ≈ 4 jobs total
                                  - 1st show: 3 jobs, materializes cache implicitly via earlier action
                                  - 2nd show: usually 1 job since cached partitions are dense
```

---

## Source-Code Reference Card

```scala
// SparkPlan.scala (master branch, simplified)
private def executeTake(n: Int, takeFromEnd: Boolean): Array[InternalRow] = {
  val limitScaleUpFactor = math.max(conf.limitScaleUpFactor, 2)
  val totalParts = childRDD.partitions.length
  var partsScanned = 0
  while (buf.length < n && partsScanned < totalParts) {
    var numPartsToTry = conf.limitInitialNumPartitions
    if (partsScanned > 0) numPartsToTry = (partsScanned * limitScaleUpFactor).toInt
    val parts = (partsScanned until min(partsScanned + numPartsToTry, totalParts))
    sc.runJob(childRDD, ..., parts)             // <-- one job
    partsScanned += parts.length
  }
}
```

```python
# pyspark/rdd.py (mirror for RDD.take)
p = range(partsScanned, min(partsScanned + numPartsToTry, totalParts))
res = self.context.runJob(self, takeUpToNumLeft, p)   # <-- one job
items += res
partsScanned += numPartsToTry
```

---

## Cheat Decision Tree

```
You see N showString rows in Jobs tab.
   |
   +---> N == 1 ?  -> First partition had enough rows. Default behavior.
   |
   +---> N == 2..3 ?  -> Sparse data needed 1+4 or 1+4+more partitions.
   |
   +---> N == log4(P)+1 ?  -> Worst case; almost no rows.
   |
   +---> N >= 4 with AQE on ?
            +---> Some rows are AQE bookkeeping (Description in TPE thread).
            +---> Real ones are showString at <your-file>:<line>.
```

---

## Cross-Reference

| If You're Studying...                              | Also See                                    |
|----------------------------------------------------|---------------------------------------------|
| Why each show iter has many *skipped* tasks        | Pattern 05 (Skipped Stages & Reuse)         |
| What stages run inside iter 1 vs iter 2            | Pattern 04                                  |
| What `CollectLimitExec` looks like in the SQL tab  | Pattern 06                                  |
| How to interpret Description column                 | Pattern 02                                  |

---

## Study Plan

### Day 1 — Reproduce Default Behavior
- Write the 5-job reference script from `00_Index.md`.
- Confirm 3 showString rows; click each, confirm decreasing task counts.

### Day 2 — Tune Configs
- Add `spark.sql.limit.initialNumPartitions = 8`.
- Confirm jobs collapse to 1.
- Vary `scaleUpFactor` 2 vs 4 — count iterations.

### Day 3 — Tasks 3, 4, 5
- Build dataframes with controlled partition shapes (e.g. `df.repartition(8, col("k"))` then filter).

### Day 4 — AQE Toggle
- Run Task 14 with AQE on then off; compare row counts in UI.

---

## Final Revision Box

```
SHOW(n)                  -> head(n+1) -> executeTake(n+1)
EXECUTE_TAKE             -> while-loop, one runJob per iter
ITER 1 partitions        -> spark.sql.limit.initialNumPartitions  (default 1)
ITER k+1 partitions      -> partsScanned * scaleUpFactor          (default 4)
LOOP STOPS               -> when buf.length >= n OR all P scanned
JOB COUNT (worst case)   -> log4(P) + 1
COLLAPSE TO 1 JOB        -> set initialNumPartitions = P
COUNT vs SHOW            -> count = 1 job; show = 1..K jobs
COLLECT vs TAKE          -> collect = 1 job; take = same loop as show
RULE                     -> "show is exponential search; tune configs only when sparse"
```
