import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(a, b) {
  const n = a.length;
  const m = b.length;
  const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
  const steps = [];
  const colLabels = ['ε', ...b.split('')];
  const rowLabels = ['ε', ...a.split('')];

  const snap = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: dp.map((r) => [...r]),
      rowLabels,
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('LCS length table initialized with zeros', {}, null, []);

  for (let i = 1; i <= n; i += 1) {
    for (let j = 1; j <= m; j += 1) {
      const colors = { [`${i}-${j}`]: 'current', [`${i - 1}-${j}`]: 'filled', [`${i}-${j - 1}`]: 'filled' };
      const arrows = [
        { from: [i - 1, j], to: [i, j] },
        { from: [i, j - 1], to: [i, j] },
      ];
      if (a[i - 1] === b[j - 1]) {
        colors[`${i - 1}-${j - 1}`] = 'filling';
        arrows.push({ from: [i - 1, j - 1], to: [i, j] });
        snap(`Match '${a[i - 1]}' == '${b[j - 1]}' → +1`, colors, [i, j], arrows);
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        snap(`No match: max(left, top)`, colors, [i, j], arrows);
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
      snap(`dp[${i}][${j}] = ${dp[i][j]}`, { [`${i}-${j}`]: 'optimal' }, [i, j], []);
    }
  }

  snap(`LCS length = ${dp[n][m]}`, { [`${n}-${m}`]: 'optimal' }, [n, m], []);
  return steps;
}

export default function LCSVisualizer({ config }) {
  const a = 'AGGTAB';
  const b = 'GXTXAYB';

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(a, b);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `LCS of "${a}" vs "${b}"` });
    canvasRef.current?.setState({
      table: [[0]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      caption: 'Longest common subsequence',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={DPCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
