# SQL Interview Mastery — Coding Templates

> **8 universal templates. Memorize these and you cover 90% of SQL interview questions.**

---

## T1: Top-N per group

```sql
WITH ranked AS (
    SELECT *,
           DENSE_RANK() OVER (PARTITION BY group_col ORDER BY metric DESC) AS rk
    FROM table_name
)
SELECT * FROM ranked WHERE rk <= N;
```

---

## T2: Ratio / rate

```sql
SELECT group_col,
       ROUND(AVG(CASE WHEN condition THEN 1.0 ELSE 0.0 END), 2) AS rate
FROM table_name
GROUP BY group_col;
```

---

## T3: Anti-join (find missing)

```sql
SELECT a.*
FROM table_a a
LEFT JOIN table_b b ON a.id = b.a_id
WHERE b.a_id IS NULL;
```

---

## T4: Running total / cumulative

```sql
SELECT *,
       SUM(amount) OVER (ORDER BY date_col ROWS UNBOUNDED PRECEDING) AS cum_total
FROM table_name;
```

---

## T5: Consecutive detection (LAG)

```sql
WITH lagged AS (
    SELECT *,
           LAG(val, 1) OVER (ORDER BY id) AS prev1,
           LAG(val, 2) OVER (ORDER BY id) AS prev2
    FROM table_name
)
SELECT DISTINCT val FROM lagged
WHERE val = prev1 AND val = prev2;
```

---

## T6: Island / gap grouping

```sql
WITH islands AS (
    SELECT *,
           date_col - INTERVAL '1 day' * ROW_NUMBER() OVER (ORDER BY date_col) AS grp
    FROM table_name
)
SELECT grp, MIN(date_col) AS start_date, MAX(date_col) AS end_date, COUNT(*) AS streak
FROM islands
GROUP BY grp;
```

---

## T7: Weighted average

```sql
SELECT product_id,
       ROUND(SUM(price * units) / SUM(units), 2) AS weighted_avg_price
FROM sales
GROUP BY product_id;
```

---

## T8: Self-comparison (prev row / manager)

```sql
SELECT curr.*, prev.metric AS prev_metric
FROM table_name curr
LEFT JOIN table_name prev
    ON curr.entity_id = prev.entity_id
   AND curr.date_col = prev.date_col + INTERVAL '1 day';
```

---

*Next: [[04_Interview-Thinking]]*
