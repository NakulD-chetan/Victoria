# Monitoring and Observability — Interview Thinking

> **Permanent Recall:** Always mention monitoring in your wrap-up. Bring up observability when discussing reliability, debugging, or SLAs. Know the three pillars (logs, metrics, traces) and RED/USE methods. Present monitoring as a first-class part of your system design, not an afterthought.

---

## When to Bring Up Monitoring

| Interview Phase | Opportunity |
|-----------------|-------------|
| **Requirements** | "We need observability for debugging and SLA tracking" |
| **High-level design** | "Each component will emit metrics and structured logs" |
| **Deep dive** | "For latency issues, we'd use distributed tracing" |
| **Wrap-up** | **Always** — "We'd add monitoring: metrics, logs, traces, alerting" |

> **FAANG Tip:** "If you don't mention monitoring in your wrap-up, the interviewer may assume you forgot it. Always include it."

---

## How to Explain the Three Pillars Concisely

**30-second pitch:**
> "We'd use the three pillars of observability: **Logs** for event records and debugging—structured JSON via ELK. **Metrics** for real-time numbers—Prometheus and Grafana, following RED for services and USE for infra. **Traces** for request flow across services—OpenTelemetry and Jaeger for latency breakdown. Plus the four golden signals: latency, traffic, errors, saturation."

---

## Discussing Alerting Strategy

**Interview phrasing:**
> "We'd alert on **causes** not just symptoms—e.g., DB connection pool exhaustion rather than only high latency. Threshold-based alerts with a 5-minute `for` to avoid noise. PagerDuty for on-call. SLO-based alerting: if error rate exceeds 0.5%, page the on-call."

---

## Presenting Monitoring in Your Design

```
INTEGRATION POINTS:
  
  1. Each service: health endpoints (liveness, readiness)
  2. API layer: RED metrics (rate, errors, duration)
  3. DB/Cache: USE metrics (utilization, saturation)
  4. All components: structured logs with trace_id
  5. Microservices: trace propagation via OpenTelemetry
  6. Dashboard: 4 golden signals + business metrics
  7. Alerts: SLO breach, dependency down, anomaly
```

---

## Wrap-Up Checklist

- [ ] Mention logs (structured, centralized)
- [ ] Mention metrics (Prometheus, Grafana, RED/USE)
- [ ] Mention traces (distributed tracing for microservices)
- [ ] Mention alerting (SLO-based, PagerDuty)
- [ ] Mention dashboards (4 golden signals)
- [ ] Mention health checks (K8s liveness/readiness)

---

## Phrasing Examples for Different Scenarios

**When designing an API:**
> "We'd instrument each endpoint with RED metrics—request count, error count, and latency histogram. Structured logs would include trace_id for correlation. Health endpoints for liveness and readiness."

**When designing a data pipeline:**
> "We'd monitor queue lag, consumer throughput, and processing latency. USE metrics for the workers. Alert if lag exceeds threshold or consumer group falls behind."

**When discussing failures:**
> "We'd use distributed tracing to see the full request path. Circuit breaker metrics would show when we're failing fast. Dashboards would surface the four golden signals."

---

## Red Flags to Avoid

| Don't Say | Instead Say |
|-----------|-------------|
| "We'll add monitoring later" | "Monitoring is part of the initial design" |
| "We'll use whatever the cloud provides" | "Prometheus/Grafana for metrics, ELK for logs, Jaeger for traces" |
| "We'll alert when things break" | "We'll alert on SLO breach and root causes" |
| "Logs are in each server" | "Centralized structured logs with trace_id" |

---

## Common Follow-Up Questions

| Question | Answer Direction |
|----------|------------------|
| "How would you debug a latency spike?" | Traces → find slow span → logs for that service |
| "How do you avoid alert fatigue?" | Alert on causes; use `for` duration; tier alerts |
| "What about log volume at scale?" | Sampling, retention, sharding, drop debug in prod |
| "How do you monitor microservices?" | RED + traces; trace_id in logs for correlation |
| "What's the difference between SLI and SLO?" | SLI = measurable; SLO = target; SLA = contract |
| "How would you reduce monitoring costs?" | Sampling, retention, cardinality limits, tiered storage |

---

## Handling "We Don't Need It" Pushback

If interviewer says "assume we have basic monitoring":

> "We'd still specify what we'd add: trace_id in logs for this microservice design, RED metrics for the new API, and SLO-based alerts for the critical path. Even with existing infra, we'd document the instrumentation points."

---

## Time-Boxed Monitoring Discussion

If you have 2 minutes in wrap-up:
1. **Logs:** Structured, ELK, trace_id (20 sec)
2. **Metrics:** Prometheus, 4 golden signals, RED/USE (40 sec)
3. **Traces:** OpenTelemetry, Jaeger (20 sec)
4. **Alerting:** SLO-based, PagerDuty (20 sec)
5. **Health:** Liveness, readiness (20 sec)

---

## One-Liner for Extremely Tight Time

> "We'd add the three pillars—structured logs in ELK, Prometheus metrics with the four golden signals, and OpenTelemetry tracing—plus SLO-based alerting and health checks."

---

## Prioritization If Asked to Cut Scope

| Keep (Essential) | Can Defer |
|------------------|------------|
| Metrics (golden signals) | Full distributed tracing |
| Structured logs | Advanced dashboards |
| Health checks | Anomaly detection |
| Basic alerts (error rate, latency) | Business metrics |

> **FAANG Tip:** "If forced to cut scope: metrics and health checks first. Traces can come second for microservices."

---

## 30-SECOND REVISION BOX

```
ALWAYS: Mention monitoring in wrap-up
PILLARS: Logs, Metrics, Traces — explain in 30 sec
ALERTING: Causes not symptoms; SLO-based
PRESENT: As first-class design, not afterthought
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
