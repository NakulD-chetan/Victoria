import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const S = 'forgeeksskeegfor';

function generateSteps() {
  const steps = [];
  const n = S.length;
  let bestL = 0;
  let bestR = 0;
  for (let c = 0; c < n; c++) {
    steps.push({ type: 'center', msg: `Odd center at ${c}`, S, c, kind: 'odd', lo: c, hi: c, bestL, bestR });
    let lo = c;
    let hi = c;
    while (lo >= 0 && hi < n && S[lo] === S[hi]) {
      steps.push({ type: 'expand', msg: `Expand odd: [${lo},${hi}]`, S, c, lo, hi, bestL, bestR });
      if (hi - lo > bestR - bestL) {
        bestL = lo;
        bestR = hi;
        steps.push({ type: 'best', msg: `New best length ${hi - lo + 1}`, S, c, lo, hi, bestL, bestR });
      }
      lo -= 1;
      hi += 1;
    }
    steps.push({ type: 'center', msg: `Even center between ${c} and ${c + 1}`, S, c, kind: 'even', lo: c, hi: c + 1, bestL, bestR });
    lo = c;
    hi = c + 1;
    while (lo >= 0 && hi < n && S[lo] === S[hi]) {
      steps.push({ type: 'expand', msg: `Expand even: [${lo},${hi}]`, S, c, lo, hi, bestL, bestR });
      if (hi - lo > bestR - bestL) {
        bestL = lo;
        bestR = hi;
        steps.push({ type: 'best', msg: `New best length ${hi - lo + 1}`, S, c, lo, hi, bestL, bestR });
      }
      lo -= 1;
      hi += 1;
    }
  }
  steps.push({ type: 'done', msg: `Longest palindrome: "${S.slice(bestL, bestR + 1)}"`, S, bestL, bestR });
  return steps;
}

function paint(step) {
  const str = step.S;
  const textColors = {};
  const patternColors = {};
  const matchPositions = [];
  if (step.lo != null && step.hi != null) {
    for (let k = step.lo; k <= step.hi; k++) textColors[k] = 'match';
  }
  if (step.bestL != null && step.bestR != null) {
    for (let k = step.bestL; k <= step.bestR; k++) matchPositions.push(k);
  }
  if (step.c != null) textColors[step.c] = 'current';
  return {
    text: str.split(''),
    pattern: str.split(''),
    textColors,
    patternColors,
    offset: 0,
    table: step.bestL != null ? [step.bestR - step.bestL + 1] : null,
    tableLabel: 'best len',
    matchPositions,
    comparePairs: null,
  };
}

export default function LongestPalSubVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Longest palindromic substring' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'expand') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
