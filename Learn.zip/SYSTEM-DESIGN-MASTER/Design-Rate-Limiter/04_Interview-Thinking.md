# Design Rate Limiter — Interview Thinking

> **Permanent Recall:** Clarify **per-user vs global**, **which algorithm**, then present trade-offs. Focus on **distributed implementation with Redis**, **Lua for atomicity**, **fail-open vs fail-closed**, and **monitoring on 429s**.

---

## Step 1: Clarify Requirements (2–3 min)

| Question | Why it matters |
|----------|----------------|
| Rate limit by what? User ID, IP, API key, or combination? | Determines key format; IP for anonymous, user_id for authenticated |
| Per-endpoint or global? | Different rules per path (e.g., search vs upload) |
| What algorithm? Fixed window, sliding, token bucket? | Trade-off: simplicity vs accuracy vs burst support |
| Single region or multi-region? | Multi-region: global vs per-region limits; sync complexity |
| Scale? Requests/second? | Determines Redis sizing, connection pooling, caching |
| What happens when rate limit store (Redis) fails? | Fail open vs fail closed |

---

## Step 2: Present Algorithms with Trade-offs (3–4 min)

**Suggested flow:**

1. **Fixed window** — simplest; mention boundary spike (100 at :59 + 100 at :01 = 200 in 2 sec)
2. **Sliding window log** — accurate but O(n) memory; not ideal at scale
3. **Sliding window counter** — best practical: O(1) memory, good accuracy
4. **Token bucket** — industry standard; allows bursts; used by Twitter, Stripe
5. **Leaky bucket** — smooth output; less common for APIs

Recommend **token bucket** or **sliding window counter** for production.

---

## Step 3: Distributed Design with Redis (5–6 min)

```
Request → API Gateway → Extract identity → Lookup rule
        → Redis: INCR/sorted set/token bucket (Lua for atomicity)
        → Allow or 429 with Retry-After
```

**Key points:**

- **Why Redis?** In-memory, sub-millisecond, supports INCR, sorted sets, Lua
- **Why Lua?** Atomic read-modify-write; avoid race between INCR and EXPIRE
- **Key format:** `ratelimit:{identity}:{endpoint}:{window}` or similar
- **Response headers:** X-RateLimit-Limit, Remaining, Reset, Retry-After on 429

---

## Step 4: Edge Cases and Faults (2–3 min)

| Scenario | Handling |
|----------|----------|
| Redis down | Fail open (allow) or fail closed (reject)—state preference |
| Clock skew | Use Redis TIME or single server timestamp |
| Rate limit bypass | Changing API key = new identity; need abuse detection |
| Burst at window boundary | Fixed window has spike; sliding/token bucket don't |
| Multi-region | Per-region Redis vs global; eventual consistency |

---

## Step 5: Monitoring and Wrap-up (1–2 min)

- **Metrics:** 429 rate per identity/endpoint, Redis latency, error rate
- **Alerting:** Spike in 429s, Redis unavailability
- **Tuning:** Adjust limits per endpoint based on usage patterns

---

## Whiteboard Checklist

- [ ] Clarified: identity, scope (per-endpoint), algorithm choice
- [ ] Drew: Request flow with rate limiter in path
- [ ] Listed: 5 algorithms with 1–2 sentence trade-offs
- [ ] Redis: INCR+EXPIRE for fixed; sorted set for sliding; Lua for atomicity
- [ ] Fail open vs fail closed
- [ ] Response headers (429, Retry-After)
- [ ] Monitoring on 429s

---

## Sample Dialogue

**Interviewer:** "Design a rate limiter for our API."

**You:** "A few clarifications: Are we limiting per user, per IP, or per API key? And is it one global limit or different limits per endpoint—for example, stricter limits on expensive operations like search or upload?"

**Interviewer:** "Per user, and different per endpoint."

**You:** "I'll assume we need distributed deployment across multiple API servers. I'd use Redis as a shared store, with either a **token bucket** or **sliding window counter**—both give good accuracy and handle bursts. Let me sketch the flow..."

---

## What to Emphasize

| Topic | One-liner |
|-------|-----------|
| Algorithms | "Five main approaches; token bucket and sliding window counter are most practical." |
| Redis | "Redis for distributed state; Lua scripts for atomic operations." |
| Race conditions | "INCR then EXPIRE isn't atomic; use Lua to do both in one call." |
| Failure mode | "If Redis is down, we choose fail open or fail closed based on availability vs security." |
| Headers | "429 with Retry-After; optional X-RateLimit-* headers for client feedback." |
