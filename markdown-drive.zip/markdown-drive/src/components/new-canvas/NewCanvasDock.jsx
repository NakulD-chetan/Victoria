import { memo, useCallback } from 'react';
import { useNewCanvasStore } from './state/store';

/**
 * Bottom-left canvas chrome: undo / redo / zoom — same visual language as the
 * floating toolbar island (nc-island), kept off the tab bar to save space.
 */
function NewCanvasDockImpl() {
  const activeId = useNewCanvasStore((s) => s.activeId);
  const scenes = useNewCanvasStore((s) => s.scenes);
  const undo = useNewCanvasStore((s) => s.undo);
  const redo = useNewCanvasStore((s) => s.redo);
  const setViewport = useNewCanvasStore((s) => s.setViewport);

  const activeScene = activeId ? scenes[activeId] : null;
  const zoom = activeScene?.viewport?.zoom ?? 1;

  const applyZoom = useCallback(
    (factor) => {
      if (!activeId || !scenes[activeId]) return;
      const vp = scenes[activeId].viewport || { zoom: 1, panX: 0, panY: 0 };
      setViewport({ ...vp, zoom: Math.max(0.1, Math.min(8, vp.zoom * factor)) });
    },
    [activeId, scenes, setViewport],
  );

  const resetZoomPan = useCallback(() => {
    setViewport({ zoom: 1, panX: 0, panY: 0 });
  }, [setViewport]);

  if (!activeId) return null;

  return (
    <div className="nc-dock" aria-label="Canvas controls">
      <div className="nc-dock__inner">
        <button type="button" className="nc-dock__icon-btn" onClick={undo} title="Undo (Ctrl+Z)" aria-label="Undo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 7v6h6" />
            <path d="M21 17a8 8 0 0 0-8-8H3" />
          </svg>
        </button>
        <button type="button" className="nc-dock__icon-btn" onClick={redo} title="Redo (Ctrl+Shift+Z)" aria-label="Redo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 7v6h-6" />
            <path d="M3 17a8 8 0 0 1 8-8h10" />
          </svg>
        </button>
        <span className="nc-dock__sep" aria-hidden />
        <div className="nc-dock__zoom" role="group" aria-label="Zoom">
          <button type="button" className="nc-dock__zoom-btn" onClick={() => applyZoom(0.9)} title="Zoom out" aria-label="Zoom out">
            −
          </button>
          <button type="button" className="nc-dock__zoom-pct" onClick={resetZoomPan} title="Reset zoom & pan">
            {Math.round(zoom * 100)}%
          </button>
          <button type="button" className="nc-dock__zoom-btn" onClick={() => applyZoom(1.1)} title="Zoom in" aria-label="Zoom in">
            +
          </button>
        </div>
      </div>
    </div>
  );
}

export default memo(NewCanvasDockImpl);
