-- ─────────────────────────────────────────────────────────────────────────
-- v4 — Multi-user vaults, members, invites, folders, notes, ACL.
-- Run AFTER v1/v2/v3 (algorithms / problems / submissions) are in place.
-- This migration is idempotent: every CREATE uses IF NOT EXISTS where Postgres
-- supports it. RLS policies live in supabase-migration-v4-rls.sql.
-- ─────────────────────────────────────────────────────────────────────────

-- ── EXTENSIONS ───────────────────────────────────────────────────────────
create extension if not exists "pgcrypto";

-- ── PROFILES (mirror of auth.users with display fields) ──────────────────
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  email        text unique not null,
  display_name text,
  avatar_url   text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

-- Keep email + a sane display_name in sync for new users.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, email, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.email, ''),
    coalesce(new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'name', split_part(coalesce(new.email,''), '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ── VAULTS ───────────────────────────────────────────────────────────────
create table if not exists public.vaults (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  owner_id    uuid not null references auth.users(id) on delete cascade,
  settings    jsonb not null default '{}'::jsonb,
  is_archived boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists vaults_owner_idx on public.vaults (owner_id);

-- Auto-add the owner to vault_members so policies stay simple.
create or replace function public.handle_new_vault()
returns trigger language plpgsql security definer as $$
begin
  insert into public.vault_members (vault_id, user_id, role, added_by)
  values (new.id, new.owner_id, 'owner', new.owner_id)
  on conflict do nothing;
  return new;
end;
$$;

-- ── VAULT MEMBERS ────────────────────────────────────────────────────────
create table if not exists public.vault_members (
  vault_id  uuid not null references public.vaults(id) on delete cascade,
  user_id   uuid not null references auth.users(id) on delete cascade,
  role      text not null check (role in ('owner','editor','viewer')),
  added_by  uuid references auth.users(id),
  added_at  timestamptz not null default now(),
  primary key (vault_id, user_id)
);

create index if not exists vault_members_user_idx on public.vault_members (user_id);

drop trigger if exists on_vault_created on public.vaults;
create trigger on_vault_created
  after insert on public.vaults
  for each row execute function public.handle_new_vault();

-- ── VAULT INVITES (email + token-based) ──────────────────────────────────
create table if not exists public.vault_invites (
  id           uuid primary key default gen_random_uuid(),
  vault_id     uuid not null references public.vaults(id) on delete cascade,
  email        text,
  token        text unique not null default encode(gen_random_bytes(24), 'hex'),
  role         text not null check (role in ('editor','viewer')),
  invited_by   uuid not null references auth.users(id),
  status       text not null default 'pending' check (status in ('pending','accepted','revoked','expired')),
  expires_at   timestamptz,
  accepted_at  timestamptz,
  accepted_by  uuid references auth.users(id),
  created_at   timestamptz not null default now()
);

create index if not exists vault_invites_token_idx on public.vault_invites (token);
create index if not exists vault_invites_vault_idx on public.vault_invites (vault_id);

-- ── FOLDERS (tree, scoped to vault) ──────────────────────────────────────
create table if not exists public.folders (
  id          uuid primary key default gen_random_uuid(),
  vault_id    uuid not null references public.vaults(id) on delete cascade,
  parent_id   uuid references public.folders(id) on delete cascade,
  name        text not null,
  position    int  not null default 0,
  created_by  uuid references auth.users(id),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create index if not exists folders_vault_parent_idx on public.folders (vault_id, parent_id);

-- ── NOTES (rows; content as JSONB for TipTap; Yjs binary lives in Storage)
create table if not exists public.notes (
  id              uuid primary key default gen_random_uuid(),
  vault_id        uuid not null references public.vaults(id) on delete cascade,
  folder_id       uuid references public.folders(id) on delete set null,
  title           text not null default 'Untitled',
  content         jsonb,
  yjs_state_key   text,
  position        int  not null default 0,
  created_by      uuid references auth.users(id),
  updated_by      uuid references auth.users(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index if not exists notes_vault_folder_idx on public.notes (vault_id, folder_id);
create index if not exists notes_updated_idx     on public.notes (vault_id, updated_at desc);

-- ── PER-RESOURCE ACL OVERRIDES ───────────────────────────────────────────
-- A user with no vault_members row may still gain access via resource_acl.
-- A vault member's effective role is max(vault_role, acl_role).
create table if not exists public.resource_acl (
  id            uuid primary key default gen_random_uuid(),
  resource_type text not null check (resource_type in ('folder','note')),
  resource_id   uuid not null,
  user_id       uuid not null references auth.users(id) on delete cascade,
  role          text not null check (role in ('editor','viewer')),
  granted_by    uuid references auth.users(id),
  created_at    timestamptz not null default now(),
  unique (resource_type, resource_id, user_id)
);

create index if not exists resource_acl_lookup_idx on public.resource_acl (resource_type, resource_id);
create index if not exists resource_acl_user_idx   on public.resource_acl (user_id);

-- ── AUDIT EVENTS (share/role/delete history) ─────────────────────────────
create table if not exists public.audit_events (
  id        uuid primary key default gen_random_uuid(),
  vault_id  uuid references public.vaults(id) on delete set null,
  actor_id  uuid references auth.users(id),
  action    text not null,
  target    jsonb,
  payload   jsonb,
  created_at timestamptz not null default now()
);

create index if not exists audit_events_vault_idx on public.audit_events (vault_id, created_at desc);

-- ── EFFECTIVE ROLE FUNCTION (used by every RLS policy) ───────────────────
create or replace function public.effective_role(p_vault uuid, p_type text, p_id uuid)
returns text
language sql
stable
security definer
set search_path = public
as $$
  with
    vm as (
      select role from public.vault_members
      where vault_id = p_vault and user_id = auth.uid()
    ),
    acl_self as (
      select role from public.resource_acl
      where resource_type = p_type and resource_id = p_id and user_id = auth.uid()
    )
  select
    case
      when (select role from vm) = 'owner'                            then 'owner'
      when (select role from vm) = 'editor' or (select role from acl_self) = 'editor' then 'editor'
      when (select role from vm) = 'viewer' or (select role from acl_self) = 'viewer' then 'viewer'
      else null
    end;
$$;

grant execute on function public.effective_role(uuid, text, uuid) to anon, authenticated;

-- ── ACCEPT INVITE RPC ────────────────────────────────────────────────────
create or replace function public.accept_invite(p_token text)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  inv public.vault_invites;
begin
  select * into inv from public.vault_invites where token = p_token;
  if not found then
    raise exception 'Invite not found' using errcode = 'P0002';
  end if;
  if inv.status <> 'pending' then
    raise exception 'Invite is %', inv.status using errcode = 'P0001';
  end if;
  if inv.expires_at is not null and inv.expires_at < now() then
    update public.vault_invites set status = 'expired' where id = inv.id;
    raise exception 'Invite expired' using errcode = 'P0001';
  end if;
  if auth.uid() is null then
    raise exception 'Not authenticated' using errcode = '28000';
  end if;

  insert into public.vault_members (vault_id, user_id, role, added_by)
  values (inv.vault_id, auth.uid(), inv.role, inv.invited_by)
  on conflict (vault_id, user_id)
    do update set role = excluded.role, added_by = excluded.added_by;

  update public.vault_invites
     set status = 'accepted', accepted_at = now(), accepted_by = auth.uid()
   where id = inv.id;

  insert into public.audit_events (vault_id, actor_id, action, target)
  values (inv.vault_id, auth.uid(), 'invite.accept', jsonb_build_object('invite_id', inv.id));

  return inv.vault_id;
end;
$$;

grant execute on function public.accept_invite(text) to authenticated;

-- ── REALTIME PUBLICATIONS ────────────────────────────────────────────────
-- Add tables to the realtime publication so postgres_changes pushes flow.
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    alter publication supabase_realtime add table public.folders;
    alter publication supabase_realtime add table public.notes;
    alter publication supabase_realtime add table public.vault_members;
    alter publication supabase_realtime add table public.vault_invites;
    alter publication supabase_realtime add table public.resource_acl;
  end if;
exception when duplicate_object then
  null;
end $$;
