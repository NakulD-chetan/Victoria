# Golden Rules, Common Mistakes & Memory Tricks

> **Yeh file interview ke 1 din pehle zaroor padho — sab important rules ek jagah!**
> 20 Golden Rules + 15 Mistakes + Memory Tricks + Decision Trees

---

## 20 Golden Rules of System Design

| # | Rule | One-Line Explanation |
|---|------|---------------------|
| 1 | **No silver bullet** | Har problem ka alag solution — one-size-fits-all nahi |
| 2 | **Optimize for common case (80/20)** | 80% traffic 20% features pe — wahan optimize karo |
| 3 | **Design for failure** | Sab kuch fail hoga — plan for it |
| 4 | **Keep it simple first** | Simple solution → validate → phir complex |
| 5 | **Measure before optimizing** | Guess mat karo — metrics dekho, phir optimize |
| 6 | **Avoid SPOF** | Single Point of Failure = kabhi mat rakho |
| 7 | **Latency ≠ Throughput** | Low latency ≠ high throughput — dono alag |
| 8 | **Cache is not substitute for good design** | Cache band-aid hai — design sahi hona chahiye |
| 9 | **Async when you can, sync when you must** | Non-blocking prefer karo — jab strongly needed ho sync |
| 10 | **Data is the hardest part** | Schema, migration, consistency — sabse mushkil |
| 11 | **Consistency has a cost** | Strong consistency = performance trade-off |
| 12 | **Names and boundaries matter** | Service boundaries clear honi chahiye |
| 13 | **Document the "why"** | "What" se zyada "why" important — future you will thank |
| 14 | **Design for observability** | Logs, metrics, traces — debug ke liye zaroori |
| 15 | **Know your limits (estimation)** | Scale pehle se pata hona chahiye |
| 16 | **Stateless > Stateful** | Stateless = easy scaling, Stateful = complexity |
| 17 | **Reads = Replicas, Writes = Shards** | Read scale = replicas, Write scale = sharding |
| 18 | **CDN for static, Cache for dynamic** | Static content = CDN, User-specific = Cache |
| 19 | **Queue everything that can wait** | Async = decouple, buffer, reliability |
| 20 | **Start monolith, split when needed** | Premature microservices = overkill |

---

## 15 Common Mistakes (Anti-Patterns)

### Mistake 1: Jumping to Solution

| Aspect | Details |
|--------|---------|
| **What it is** | Requirements puche bina design start karna |
| **Why bad** | Wrong scope, over/under engineering |
| **How to fix** | "Let me clarify requirements first" — 5 min minimum |

### Mistake 2: No Back-of-Envelope

| Aspect | Details |
|--------|---------|
| **What it is** | Numbers bina design karna |
| **Why bad** | Unrealistic design, wrong component choice |
| **How to fix** | Always: QPS, Storage, Bandwidth — estimate karo |

### Mistake 3: Single Point of Failure (SPOF)

| Aspect | Details |
|--------|---------|
| **What it is** | Ek component fail = sab fail |
| **Why bad** | No availability, no redundancy |
| **How to fix** | Multiple instances, replicas, failover |

### Mistake 4: Ignoring Read/Write Ratio

| Aspect | Details |
|--------|---------|
| **What it is** | Read-heavy system mein write optimization |
| **Why bad** | Wrong DB choice, wrong caching strategy |
| **How to fix** | Pehle ratio pata karo — 100:1 read-heavy = cache critical |

### Mistake 5: Over-Engineering

| Aspect | Details |
|--------|---------|
| **What it is** | Kafka, K8s, 50 microservices for 1K QPS |
| **Why bad** | Complexity, maintenance nightmare |
| **How to fix** | "What's the simplest solution?" — start there |

### Mistake 6: No Caching Strategy

| Aspect | Details |
|--------|---------|
| **What it is** | Direct DB for every request |
| **Why bad** | DB overload, high latency |
| **How to fix** | Cache hot data — 80% traffic 20% data |

### Mistake 7: No Failure Handling

| Aspect | Details |
|--------|---------|
| **What it is** | "Everything will work" assumption |
| **Why bad** | Production mein crash, no recovery |
| **How to fix** | "What if DB fails? Cache? Network?" — plan karo |

### Mistake 8: No Trade-off Discussion

| Aspect | Details |
|--------|---------|
| **What it is** | "We'll use cache" — kyun? |
| **Why bad** | Interviewer thinks you don't understand |
| **How to fix** | "Cache for latency, trade-off: stale data" — always |

### Mistake 9: Wrong Consistency Choice

| Aspect | Details |
|--------|---------|
| **What it is** | Strong consistency for everything |
| **Why bad** | Unnecessary latency, availability cost |
| **How to fix** | "Do we need strong consistency?" — analytics = eventual |

### Mistake 10: No API Design

| Aspect | Details |
|--------|---------|
| **What it is** | Vague "client talks to server" |
| **Why bad** | Unclear contract, integration issues |
| **How to fix** | 2-3 endpoints with request/response — define karo |

### Mistake 11: No Data Model

| Aspect | Details |
|--------|---------|
| **What it is** | "Data stored somewhere" |
| **Why bad** | Unclear schema, wrong DB choice |
| **How to fix** | Tables: id, fields, indexes — draw karo |

### Mistake 12: Monologue (No Interaction)

| Aspect | Details |
|--------|---------|
| **What it is** | 45 min solo speech |
| **Why bad** | Interviewer bored, no collaboration signal |
| **How to fix** | "Does this make sense?" "Should I go deeper?" |

### Mistake 13: No Prioritization

| Aspect | Details |
|--------|---------|
| **What it is** | Sab features equal importance |
| **Why bad** | Time waste, no MVP |
| **How to fix** | "MVP is X, we can add Y later" |

### Mistake 14: Cache Invalidation Ignored

| Aspect | Details |
|--------|---------|
| **What it is** | "We'll cache" — but when to invalidate? |
| **Why bad** | Stale data, wrong results |
| **How to fix** | TTL, write-through, or cache-aside — strategy bolo |

### Mistake 15: No Idempotency for Critical Operations

| Aspect | Details |
|--------|---------|
| **What it is** | Retry = duplicate payment/order |
| **Why bad** | Data corruption, user loss |
| **How to fix** | Idempotency keys for payments, writes |

---

## Memory Tricks for Quick Recall

### CAP Theorem

**Memory:** "3 friends, pick 2"

| Letter | Meaning | Pick 2 |
|--------|---------|--------|
| C | Consistency | CP or AP |
| A | Availability | AP or CA |
| P | Partition tolerance | Must have (network fails) |

**Reality:** CP (Banking) vs AP (Social feed) — P always, so C vs A choice.

### ACID

**Memory:** "All or nothing, Consistent, Isolated, Durable"

| Letter | Meaning |
|--------|---------|
| A | Atomicity — all or nothing |
| C | Consistency — valid state |
| I | Isolation — concurrent invisible |
| D | Durability — committed = permanent |

### Vertical vs Horizontal Scaling

**Memory:** "Vertical = taller (bigger machine), Horizontal = wider (more machines)"

| Type | Scaling | When |
|------|---------|------|
| Vertical | Bigger CPU/RAM | Quick fix, limit hai |
| Horizontal | More servers | Long-term, unlimited |

### LRU Cache

**Memory:** "Closet cleanup — jo sabse purana use hua, usko bahar"

- Least Recently Used = jo sabse pehle use hua, evict
- Linked list + Hash map for O(1)

### BASE (NoSQL)

**Memory:** "ACID ka opposite — relaxed"

| Letter | Meaning |
|--------|---------|
| B | Basically Available |
| A | Soft state |
| S | Eventual consistency |
| E | — |

---

## Decision Trees

### Do I Need Caching?

```
┌─────────────────────────────┐
│  Read-heavy? (10:1 or more) │
└──────────────┬──────────────┘
               │
       ┌───────┴───────┐
       │ Yes           │ No
       ↓               ↓
┌──────────────┐  ┌──────────────┐
│ Same data     │  │ Skip cache   │
│ repeated?     │  │ (or minimal) │
└──────┬───────┘  └──────────────┘
       │
       │ Yes
       ↓
┌──────────────┐
│ USE CACHE    │
│ (Redis, etc) │
└──────────────┘
```

### SQL or NoSQL?

```
┌─────────────────────────────┐
│  Need ACID/Transactions?    │
└──────────────┬──────────────┘
       │ Yes → SQL
       │
       │ No
       ↓
┌─────────────────────────────┐
│  Complex queries/joins?     │
└──────────────┬──────────────┘
       │ Yes → SQL
       │
       │ No
       ↓
┌─────────────────────────────┐
│  Schema flexible?           │
│  Write-heavy?               │
│  Horizontal scale needed?   │
└──────────────┬──────────────┘
       │ Yes → NoSQL
       │
       │ No → SQL
```

### Monolith or Microservices?

```
┌─────────────────────────────┐
│  Team size < 10?            │
│  Early stage / MVP?         │
│  Unknown scale?             │
└──────────────┬──────────────┘
       │ Yes → MONOLITH
       │
       │ No
       ↓
┌─────────────────────────────┐
│  Different scaling needs?   │
│  Independent deploy?        │
│  Multiple teams?            │
└──────────────┬──────────────┘
       │ Yes → MICROSERVICES
       │
       │ No → Still Monolith
```

### Which Scaling Pattern?

```
┌─────────────────────────────┐
│  Read-heavy?                 │
└──────────────┬──────────────┘
       │ Yes → Replicas + Cache
       │
       │ Write-heavy?
       ↓
┌─────────────────────────────┐
│  Write-heavy?                │
└──────────────┬──────────────┘
       │ Yes → Sharding
       │
       │ Both?
       ↓
┌─────────────────────────────┐
│  Replicas (read) +           │
│  Sharding (write)            │
└─────────────────────────────┘
```

---

## Quick Comparison Tables

### SQL vs NoSQL

| Aspect | SQL | NoSQL |
|--------|-----|-------|
| **Schema** | Fixed | Flexible |
| **ACID** | Yes | No (BASE) |
| **Scaling** | Vertical mostly | Horizontal |
| **Joins** | Native | Manual/avoid |
| **Use case** | Transactions, reporting | High scale, flexible |
| **Examples** | PostgreSQL, MySQL | MongoDB, Cassandra |

### Redis vs Memcached

| Aspect | Redis | Memcached |
|--------|-------|-----------|
| **Data types** | String, List, Set, Hash | String only |
| **Persistence** | Yes (optional) | No |
| **Replication** | Yes | No |
| **Complexity** | Higher | Simpler |
| **Use case** | Cache + Session + Queue | Simple cache only |

### Kafka vs RabbitMQ

| Aspect | Kafka | RabbitMQ |
|--------|-------|----------|
| **Model** | Log-based, pub/sub | Queue-based |
| **Ordering** | Per partition | Per queue |
| **Retention** | Yes (configurable) | No (consumed = gone) |
| **Throughput** | Very high | High |
| **Use case** | Event streaming, logs | Task queue, RPC |
| **Complexity** | Higher | Lower |

### REST vs gRPC vs GraphQL

| Aspect | REST | gRPC | GraphQL |
|--------|------|------|---------|
| **Format** | JSON/XML | Protobuf | JSON |
| **Protocol** | HTTP | HTTP/2 | HTTP |
| **Client control** | Multiple endpoints | Multiple endpoints | Single endpoint, client queries |
| **Performance** | Good | Best | Good |
| **Use case** | General API | Microservices | Mobile, flexible queries |

### Push vs Pull CDN

| Aspect | Push CDN | Pull CDN |
|--------|----------|----------|
| **Content upload** | You push to CDN | CDN fetches on first request |
| **Use case** | Known content, pre-warm | Dynamic, unknown |
| **Cache control** | You control | Origin headers |
| **Examples** | Static assets | CDN for images, videos |

### Monolith vs Microservices

| Aspect | Monolith | Microservices |
|--------|----------|---------------|
| **Deploy** | One unit | Independent |
| **Scale** | Whole app | Per service |
| **Complexity** | Lower initially | Higher |
| **Team** | Single team | Multiple teams |
| **When** | Start, MVP | Scale, complexity |

---

## Interview Quick Reference

### When to Use What

| Need | Use |
|------|-----|
| **Scale reads** | Replicas, Cache |
| **Scale writes** | Sharding |
| **Reduce latency** | Cache, CDN |
| **Decouple** | Message Queue |
| **Static content** | CDN |
| **User-specific** | Cache |
| **Async processing** | Queue |
| **Strong consistency** | SQL, single DB |
| **Eventual OK** | NoSQL, replicas |

### One-Liner Rules

- **Read-heavy** → Cache + Replicas
- **Write-heavy** → Sharding
- **Static** → CDN
- **Dynamic** → Cache
- **Async OK** → Queue
- **Sync needed** → Direct call
- **Start simple** → Monolith
- **Scale needed** → Microservices

---

## Final Checklist — Interview Se Pehle

- [ ] 20 Golden Rules — at least 1-10 yaad
- [ ] 15 Mistakes — top 5 avoid karna
- [ ] CAP, ACID, BASE — memory tricks
- [ ] Decision trees — SQL vs NoSQL, Cache need
- [ ] Comparison tables — SQL vs NoSQL, Kafka vs RabbitMQ
- [ ] "Trade-off" always bolo
- [ ] "What if it fails?" always ask

**Yaad rakhna:** Rules yaad karne se zyada **apply** karna important hai!

---

## More Memory Tricks

### Sharding vs Replication

**Memory:** "Read = Replicas (copy paste), Write = Shards (split)"

- Replication = same data, multiple copies (reads)
- Sharding = split data across nodes (writes)

### Cache Patterns

**Memory:** "Aside = app controls, Through = cache writes to DB, Behind = cache queues writes"

- Cache-Aside = App checks cache, loads from DB on miss
- Write-Through = Write to cache + DB together
- Write-Behind = Write to cache, async to DB

### Consistency Levels

**Memory:** "Strong = bank, Eventual = feed, Causal = chat order"

- Strong = read = latest write
- Eventual = read = latest eventually
- Causal = cause before effect visible

---

## Anti-Pattern Quick List

1. Jumping to solution
2. No estimation
3. SPOF
4. Ignoring read/write ratio
5. Over-engineering
6. No caching strategy
7. No failure handling
8. No trade-off discussion
9. Wrong consistency
10. No API design
11. No data model
12. Monologue
13. No prioritization
14. Cache invalidation ignored
15. No idempotency
