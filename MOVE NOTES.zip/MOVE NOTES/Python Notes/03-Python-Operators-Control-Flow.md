# Python Operators and Control Flow

> *"Indentation is syntax — braces optional, discipline mandatory"* — Python rule

This note covers operators, branching (`if`/`elif`/`else`), the ternary operator, and Python 3.10+ `match`-`case`. In Python **indentation** defines blocks — that's the biggest visual difference from C++. First make [[02-Python-Variables-DataTypes-IO]] solid.

---

## 1. Arithmetic operators

> **Definition:** Arithmetic operators are symbols that combine numbers with operations such as addition, subtraction, multiplication, division, floor division, remainder, and exponentiation.

**Why we need it:** They are the basic vocabulary for numeric code; Python separates true division (`/`) from floor division (`//`) so intent is explicit in Python 3.

**Syntax:**
```python
<a> + <b>    # -
<a> * <b>
<a> / <b>    # true division → float
<a> // <b>   # floor division
<a> % <b>    # modulo
<a> ** <b>   # power
```

| Operator | Meaning | Example |
|----------|---------|---------|
| `+` | Add | `3 + 4` → `7` |
| `-` | Subtract | `10 - 3` |
| `*` | Multiply | `2 * 5` |
| `/` | True division | `7 / 2` → `3.5` |
| `//` | Floor division | `7 // 2` → `3` |
| `%` | Modulo | `7 % 2` → `1` |
| `**` | Power | `2 ** 10` → `1024` |

```python
a, b = 7, 2
a / b    # 3.5   → True division (gives decimal answer)
a // b   # 3     → Floor division (cuts off decimal, gives whole number)
a % b    # 1     → Modulo (remainder after dividing 7 by 2)
a ** b   # 49    → Power (7 raised to power 2 = 7×7)
```

**Watch Out!** Negative floor division can be tricky: `-7 // 2` → `-4` (floor toward negative infinity).

---

## 2. Comparison operators

> **Definition:** Comparison operators test equality, inequality, or ordering between values and yield `True` or `False`.

**Why we need it:** Branching and sorting need a readable, consistent way to compare values; Python also allows chained comparisons so range checks look like ordinary math.

**Syntax:**
```python
<a> == <b>
<a> != <b>
<a> < <b>    # <=, >, >=
<a1> < <a2> < <a3>   # chained: all parts must hold
```

| Op | Meaning |
|----|---------|
| `==` | Equal value |
| `!=` | Not equal |
| `<`, `>`, `<=`, `>=` | Ordering |

```python
"apple" < "banana"   # True → compares alphabetically (a comes before b)
[1, 2] == [1, 2]     # True → checks if values are the same
[1, 2] is [1, 2]     # False → checks if same object in memory (different objects)
5 != 3               # True → 5 is NOT equal to 3
1 <= 1               # True → 1 is less than or equal to 1
```

**Interview Tip:** `==` vs `is` — [[17-Python-FAANG-Interview-Must-Know]] / [[notes]]; comparison chaining: `1 < x < 10` is Pythonic.

---

## 3. Logical operators

- `and`, `or`, `not` — keywords, not C's `&&` `||`

```python
if age >= 18 and has_id:     # Both conditions must be True
    print("OK")

if is_admin or is_owner:     # At least one must be True
    print("access")

if not is_blocked:           # Flips True→False, False→True
    print("allowed")
```

**Short-circuit:** `and` — if the first is False, the second is not checked. `or` — if the first is True, the second is not checked. Saves time and avoids errors.

---

## 4. Bitwise operators

| Op | Meaning |
|----|---------|
| `&` | AND |
| `\|` | OR |
| `^` | XOR |
| `~` | NOT |
| `<<`, `>>` | Shift |

```python
x = 5 & 3    # 1 → AND: compares each bit, keeps only where both are 1
y = 5 | 3    # 7 → OR: keeps bit if either is 1
z = 5 ^ 3    # 6 → XOR: keeps bit if exactly one is 1
w = ~5       # -6 → NOT: flips all bits
a = 1 << 3   # 8 → Left shift: moves bits left (1 becomes 1000 = 8)
b = 8 >> 2   # 2 → Right shift: moves bits right (1000 becomes 10 = 2)
```

**Watch Out!** Bitwise works on ints; on bool it can be confusing — use explicit `int(bool)` if you need bitwise ops.

---

## 5. Assignment operators

> **Definition:** Assignment binds a name to an object; augmented assignments like `+=` apply an operation to the current value and rebind the name to the result.

**Why we need it:** Shorthand updates reduce repetition and match how people already write math; ordinary `=` makes rebinding explicit.

**Syntax:**
```python
<name> = <expr>
<name> <op>= <expr>   # +=, -=, *=, /=, //=, %=, **=, &=, |=, ^=, <<=, >>=
<name1> = <name2> = <value>   # chained assignment
```

```python
n = 10
n += 5      # Add and assign: n = n + 5 → n is now 15
n -= 3      # Subtract and assign: n = n - 3 → n is now 12
n *= 2      # Multiply and assign: n = n * 2 → n is now 24
n //= 5     # Floor divide and assign: n = n // 5 → n is now 4
a = b = 0   # Chained assignment: both a and b become 0
```

Walrus `:=` — [[16-Python-Advanced-Topics]].

---

## 6. `if` / `elif` / `else`

> **Definition:** `if` / `elif` / `else` chooses which block runs by testing conditions in order; the first true branch wins, otherwise `else` runs if present.

**Why we need it:** Decisions are written the way you say them aloud; indentation defines blocks so structure stays visible without braces.

**Syntax:**
```python
if <condition>:
    <block>
elif <condition>:
    <block>
else:
    <block>
```

```python
score = int(input("Score: "))   # Ask user for score, convert to number
if score >= 90:       # Check first condition
    grade = "A"       # If score is 90+, grade is A
elif score >= 75:     # If not, check this condition
    grade = "B"       # If score is 75-89, grade is B
elif score >= 60:     # If not, check this
    grade = "C"       # If score is 60-74, grade is C
else:                 # If none of the above matched
    grade = "F"       # Everything below 60 is F
print(grade)
```

### Indentation rules

- After a colon `:` the block **must** be indented (usually 4 spaces)
- Don't mix tabs and spaces — PEP 8 uses spaces

**Watch Out!** For an empty block use `pass`:

```python
if debug:
    pass   # I'll fill this in later
```

---

## 7. Ternary (conditional expression)

> **Definition:** The conditional expression (ternary) picks one of two expressions to evaluate based on a boolean condition, all in one line.

**Why we need it:** For simple either/or values it avoids a multi-line `if`/`else` when a single expression is clearer.

**Syntax:**
```python
<value_if_true> if <condition> else <value_if_false>
```

```python
msg = "even" if n % 2 == 0 else "odd"
# Reads as: msg = "even" IF n is divisible by 2, OTHERWISE "odd"
# One-line shortcut for simple if-else
```

Order: **`value_if_true` if `condition` else `value_if_false`**

---

## 8. `match` / `case` (3.10+)

> **Definition:** `match` / `case` is structural pattern matching: the subject value is compared against patterns; the first matching `case` runs its block.

**Why we need it:** Complex branching on shape, types, and nested data is clearer and safer than long `if`/`elif` chains or ad-hoc type checks.

**Syntax:**
```python
match <subject>:
    case <pattern>:
        <block>
    case _:
        <default_block>
```

Structural pattern matching — more powerful than a simple switch:

```python
def http_status(code):
    match code:
        case 200:
            return "OK"
        case 404:
            return "Not Found"
        case _:
            return "Unknown"
```

### Pattern with capture

```python
match point:
    case (0, 0):
        print("origin")
    case (x, 0):
        print(f"x-axis at {x}")
    case _:
        print("other")
```

**Interview Tip:** People use `match` for **type + shape** — FAANG codebases are adopting it gradually.

---

## 9. Operator precedence (quick)

**High → low:** `**` → unary `+ - ~` → `* / // %` → `+ -` → shifts → `&` → `^` → `|` → comparisons → `not` → `and` → `or`

If confused, use **brackets** — Zen says the same (readable).

---

## 10. Membership — `in` / `not in`

> **Definition:** Membership operators test whether a left-hand value appears inside a right-hand container (or, for strings, as a substring), as defined by that type’s rules.

**Why we need it:** One readable syntax covers lists, sets, dict keys, strings, and more; with sets and dict keys you get fast average-time lookups.

**Syntax:**
```python
<item> in <container>
<item> not in <container>
```

```python
3 in [1, 2, 3]         # True → checks if 3 is inside the list
"py" in "python"       # True → checks if "py" is a part of "python"
"k" not in {"a": 1}    # True → checks if "k" is NOT a key in the dict
```

| Container | `in` complexity (typical) |
|-----------|---------------------------|
| list | O(n) |
| set / dict key | O(1) average |
| str | substring search optimized |

**Interview Tip:** For membership on large data — build a `set` and check there.

---

## 11. Chained comparisons — Pythonic

```python
0 < x < 10
a == b == c
```

The middle operand is evaluated **once** — different from the usual C pattern.

**Watch Out!** `a < f() < b` — `f()` is called once — be aware of side effects.

---

## 12. Walrus in `if` (3.8+) — small preview

```python
if (line := input()) != "quit":
    print("you said", line)
```

Full power: [[16-Python-Advanced-Topics]].

---

## Quick Memory Card

```
+------------------------------------------+
| ARITHMETIC                                |
| - / true div, // floor, ** power         |
+------------------------------------------+
| COMPARISON                                |
| - == value, chaining: a < x < b          |
+------------------------------------------+
| LOGICAL                                   |
| - and or not (short-circuit)             |
+------------------------------------------+
| CONTROL FLOW                              |
| - if / elif / else + colon + indent      |
| - pass for empty block                   |
+------------------------------------------+
| TERNARY                                   |
| - x if cond else y                       |
+------------------------------------------+
| MATCH/CASE (3.10+)                        |
| - case _ default                         |
+------------------------------------------+
```

---

*Next: [[04-Python-Loops-Comprehensions]]*
