# Pivot / CASE WHEN

Pivoting transforms rows into columns — turning vertical data into a horizontal crosstab. CASE WHEN inside aggregates is the universal technique that works in every SQL database.

**DSA Analogy**: Array reshaping / transpose — like converting a 1D list of key-value pairs into a 2D matrix where keys become column headers.

---

## Core Idea (2 Lines)

Rows contain repeated category values (like month names or status codes). Pivoting moves each unique value into its own column, with aggregated values filling the cells. `CASE WHEN` inside `SUM/COUNT/MAX` is the manual pivot technique that works everywhere.

---

## The Problem Pivot Solves

```
Before (Rows — Normalized):              After (Columns — Pivoted):

name    | month | revenue                 name    | Jan   | Feb   | Mar
────────┼───────┼─────────                ────────┼───────┼───────┼──────
Alice   | Jan   | 1000                    Alice   | 1000  | 1500  | 1200
Alice   | Feb   | 1500                    Bob     | 800   | 900   | 1100
Alice   | Mar   | 1200
Bob     | Jan   | 800
Bob     | Feb   | 900
Bob     | Mar   | 1100
```

---

## Technique 1: CASE WHEN + Aggregate (Universal)

Works in **every** SQL database. This is the go-to technique.

```sql
SELECT name,
       SUM(CASE WHEN month = 'Jan' THEN revenue END) AS jan,
       SUM(CASE WHEN month = 'Feb' THEN revenue END) AS feb,
       SUM(CASE WHEN month = 'Mar' THEN revenue END) AS mar
FROM sales
GROUP BY name;
```

**How it works step by step:**

```
Step 1: GROUP BY name → bucket all rows per name
Step 2: For each bucket, CASE WHEN evaluates each row:
        - If month = 'Jan' → return revenue, else NULL
        - SUM aggregates → sums the non-NULL values
Step 3: Each CASE WHEN becomes a column

  Alice's bucket: [(Jan,1000), (Feb,1500), (Mar,1200)]
    CASE month='Jan': [1000, NULL, NULL] → SUM = 1000
    CASE month='Feb': [NULL, 1500, NULL] → SUM = 1500
    CASE month='Mar': [NULL, NULL, 1200] → SUM = 1200
```

---

## Technique 2: PIVOT Keyword (SQL Server / Oracle)

```sql
-- SQL Server syntax
SELECT name, [Jan], [Feb], [Mar]
FROM sales
PIVOT (
    SUM(revenue)
    FOR month IN ([Jan], [Feb], [Mar])
) AS pvt;
```

| Feature | CASE WHEN | PIVOT keyword |
|---------|-----------|---------------|
| Portability | All databases | SQL Server, Oracle only |
| Dynamic columns | Manual — must list all | Still must list values |
| Flexibility | Any logic in CASE | Only simple column values |
| Multiple aggregates | Easy — add more CASE columns | Complex |

---

## Common Pivot Patterns

### Pattern 1: Crosstab Report

```sql
-- Monthly revenue per product category
SELECT category,
       SUM(CASE WHEN EXTRACT(MONTH FROM order_date) = 1 THEN amount ELSE 0 END) AS jan,
       SUM(CASE WHEN EXTRACT(MONTH FROM order_date) = 2 THEN amount ELSE 0 END) AS feb,
       SUM(CASE WHEN EXTRACT(MONTH FROM order_date) = 3 THEN amount ELSE 0 END) AS mar
FROM orders o
JOIN products p ON o.product_id = p.id
GROUP BY category;
```

### Pattern 2: Boolean Flags as Columns

```sql
-- Which features does each user have enabled?
SELECT user_id,
       MAX(CASE WHEN feature = 'dark_mode' THEN 1 ELSE 0 END) AS dark_mode,
       MAX(CASE WHEN feature = 'notifications' THEN 1 ELSE 0 END) AS notifications,
       MAX(CASE WHEN feature = 'two_factor' THEN 1 ELSE 0 END) AS two_factor
FROM user_features
GROUP BY user_id;
```

### Pattern 3: Status Counting

```sql
-- Count orders by status per customer
SELECT customer_id,
       COUNT(CASE WHEN status = 'completed' THEN 1 END) AS completed,
       COUNT(CASE WHEN status = 'pending' THEN 1 END) AS pending,
       COUNT(CASE WHEN status = 'cancelled' THEN 1 END) AS cancelled
FROM orders
GROUP BY customer_id;
```

### Pattern 4: Conditional Percentage

```sql
-- Cancellation rate per day
SELECT order_date,
       ROUND(
           100.0 * SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END)
           / COUNT(*),
           2
       ) AS cancel_rate_pct
FROM orders
GROUP BY order_date;
```

### Pattern 5: Unpivot (Columns to Rows)

The reverse operation — convert columns back to rows.

```sql
-- Using UNION ALL (universal)
SELECT name, 'Jan' AS month, jan AS revenue FROM sales_pivot
UNION ALL
SELECT name, 'Feb' AS month, feb AS revenue FROM sales_pivot
UNION ALL
SELECT name, 'Mar' AS month, mar AS revenue FROM sales_pivot;

-- PostgreSQL: UNNEST or VALUES
-- SQL Server: UNPIVOT keyword
```

---

## CASE WHEN Syntax Deep Dive

```sql
-- Simple CASE: compare one expression to values
CASE status
    WHEN 'active'   THEN 'A'
    WHEN 'inactive' THEN 'I'
    ELSE 'U'
END

-- Searched CASE: arbitrary boolean conditions
CASE
    WHEN salary > 100000 THEN 'high'
    WHEN salary > 50000  THEN 'mid'
    ELSE 'low'
END

-- CASE in different positions:
-- In SELECT: computed column
-- In WHERE:  conditional filter
-- In ORDER BY: custom sort order
-- In GROUP BY: custom grouping
-- Inside aggregate: conditional aggregation (pivot)
```

---

## SUM vs COUNT vs MAX in CASE WHEN

| Aggregate | CASE Returns | Use When |
|-----------|-------------|----------|
| `SUM(CASE WHEN x THEN amount END)` | The value to sum | Summing values conditionally |
| `COUNT(CASE WHEN x THEN 1 END)` | 1 or NULL | Counting occurrences |
| `MAX(CASE WHEN x THEN value END)` | The value | Picking one value per group |
| `MIN(CASE WHEN x THEN value END)` | The value | Picking min value conditionally |

**COUNT vs SUM for counting:**

```sql
-- These are equivalent for counting:
COUNT(CASE WHEN status = 'active' THEN 1 END)           -- counts non-NULL
SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END)      -- sums 1s and 0s
-- Both return the count of active rows. COUNT is slightly cleaner.
```

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Forgetting GROUP BY | One row per group needed for pivot | Add GROUP BY on the "row key" column |
| NULL in ELSE (COUNT vs SUM) | COUNT counts non-NULLs; omitting ELSE gives NULL | Use `ELSE 0` with SUM, or omit ELSE with COUNT |
| Hardcoding too many values | Pivot breaks when new values appear | Use dynamic SQL for truly dynamic pivots |
| Missing aggregate function | Raw CASE without SUM/COUNT returns one row value | Wrap CASE in aggregate when pivoting |
| ELSE not handled | Unmatched values become NULL | Add ELSE clause or COALESCE |

---

## Dynamic Pivot (Advanced)

When you don't know the column values in advance, you need dynamic SQL:

```sql
-- PostgreSQL: crosstab() from tablefunc extension
-- SQL Server: dynamic PIVOT with STUFF + FOR XML
-- MySQL: prepared statement with GROUP_CONCAT for column list

-- General approach:
-- 1. Query distinct values for the pivot column
-- 2. Build the SQL string with CASE WHEN for each value
-- 3. Execute dynamically
```

---

## Key Takeaway

> CASE WHEN inside SUM/COUNT is the universal pivot technique — it works in every SQL database and handles any transformation from rows to columns. Remember: GROUP BY defines the rows, each CASE WHEN defines a column, and the aggregate function fills the cells. For the reverse (columns to rows), use UNION ALL.
