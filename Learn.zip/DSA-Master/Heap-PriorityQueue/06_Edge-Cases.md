# Heap — Edge Cases

> **K=1, K=N, K>N. All same elements. Negatives. Empty heap. Streaming. Always mention these in interviews.**

---

## Edge Case 1: K = 1

**Scenario:** Top 1 largest = single max element.

**Behavior:** Min-heap of size 1. Every element > root gets pushed (root evicted). Final root = max.

**Code:** Same template works. `len(heap) < 1` → push first element. Then `x > heap[0]` → replace.

**Mention:** *"K=1 is a special case but our template handles it — we end up with the single maximum."*

---

## Edge Case 2: K = N

**Scenario:** Top N largest = all elements (when array has N elements).

**Behavior:** Heap grows to size N. No eviction (every element gets in). O(n log n) — same as sort.

**Mention:** *"When K equals array size, we keep everything. Heap works but sorting might be simpler. I'll still use heap for consistency."*

---

## Edge Case 3: K > N

**Scenario:** "Top 100" from array of 50 elements.

**Behavior:** Heap caps at N. Return all elements. Don't assume K ≤ N.

**Fix:**
```python
k = min(k, len(nums))  # Cap K
if k == 0:
    return []
```

**Mention:** *"If K exceeds array size, we return all elements. I'll cap K to avoid invalid state."*

---

## Edge Case 4: K = 0

**Scenario:** Top 0 elements.

**Behavior:** Return empty list. Don't process.

**Fix:**
```python
if k <= 0:
    return []
```

---

## Edge Case 5: All Same Elements

**Scenario:** `[5, 5, 5, 5]`, K=2. Top 2 = [5, 5].

**Behavior:** Heap works. Duplicates are fine. We might have multiple 5s in heap. No special handling.

**Mention:** *"Duplicates are handled naturally — we can have multiple of the same value in our top-K."*

---

## Edge Case 6: Negative Numbers with Negation Trick

**Scenario:** Max-heap in Python: we store `-x`. What if x = -5? `-(-5) = 5` — still works.

**Potential bug:** For custom objects, negation might not be defined. Use tuple `(-key, obj)` instead.

**Mention:** *"Negation works for integers. For other types, I'll use (-key, value) tuples."*

---

## Edge Case 7: Empty Heap Operations

**Scenario:** `heappop` or `heap[0]` on empty heap.

**Python:** `IndexError`  
**C++:** Undefined behavior

**Fix:**
```python
if heap:
    x = heapq.heappop(heap)
```

```cpp
if (!pq.empty()) {
    int x = pq.top();
    pq.pop();
}
```

---

## Edge Case 8: Streaming — Elements Arrive One by One

**Scenario:** `add(val)` called repeatedly; `getKthLargest()` at any time.

**Behavior:** Heap maintains state. Each add: O(log K). Each get: O(1) for peek.

**Edge:** First few adds when heap size < K. Don't evict until heap is full.

```python
if len(heap) < k:
    heapq.heappush(heap, val)
else:
    if val > heap[0]:
        heapq.heapreplace(heap, val)
```

---

## Edge Case 9: Two-Heap Median — Single Element

**Scenario:** `addNum(5)` then `findMedian()`.

**Behavior:** One heap has one element. Median = that element.

**Edge:** After first add, `lo` has 1, `hi` has 0. Median = `lo.top()`.

---

## Edge Case 10: Two-Heap Median — Two Elements

**Scenario:** `addNum(3)`, `addNum(5)`, `findMedian()`.

**Behavior:** Median = (3+5)/2 = 4. Both heaps have one element.

**Balance:** Ensure after two adds, we have one in each, or two in one. Sizes differ by at most 1.

---

## Edge Case 11: Merge K — Empty Lists

**Scenario:** `lists = [[], [1], []]` — some lists empty.

**Fix:** Only push if list is non-empty.
```python
for i, lst in enumerate(lists):
    if lst:  # Skip empty
        heapq.heappush(heap, (lst[0], i, 0))
```

---

## Edge Case 12: Merge K — All Empty

**Scenario:** `lists = [[], [], []]`.

**Behavior:** Heap stays empty. Return `[]`.

---

## Edge Case 13: K Closest — Origin Itself

**Scenario:** One point is (0,0). Distance = 0.

**Behavior:** It's always in top-K closest. No issue.

---

## Edge Case 14: Integer Overflow (Distance Squared)

**Scenario:** Points like (100000, 100000). `x² + y²` might overflow in some languages.

**Fix:** Use long/LL or avoid squaring if possible. For LeetCode, usually fine.

---

## Summary Table

| Edge Case | Action |
|-----------|--------|
| K=1 | Template works; root = max |
| K=N | Heap size N; no eviction |
| K>N | Cap K to N; return all |
| K=0 | Return [] immediately |
| All same | No special handling |
| Negatives | Negation works for ints |
| Empty heap | Check before pop/top |
| Streaming | Maintain heap; don't evict until size K |
| Merge K empty | Skip empty lists; return [] if all empty |
| Two-heap single | One element in one heap |

---

## FINAL MEMORY COMPRESSION BLOCK

```
K=1:       Works; root = single best
K=N:       All in heap; O(n log n)
K>N:       Cap k=min(k,n); return all
K=0:       return []
SAME:      Duplicates OK
NEGATIVE:  -x works for ints
EMPTY:     Check before pop/top
STREAM:    Don't evict until size K
MERGE K:   if lst: push
ALL EMPTY: return []
```
