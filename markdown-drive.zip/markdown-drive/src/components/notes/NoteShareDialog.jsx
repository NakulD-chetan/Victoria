import { useState, useCallback, memo } from 'react';
import { getAuthHeaders } from '../AuthGate';

const NoteShareDialog = memo(function NoteShareDialog({ note, onClose }) {
  const [shareUrl, setShareUrl] = useState(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [expiry, setExpiry] = useState('0');
  const [error, setError] = useState(null);

  const handleShare = useCallback(async () => {
    if (!note) return;
    setLoading(true); setError(null);
    try {
      const res = await fetch('/api/notes/share', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({
          noteId: note.id,
          title: note.title || 'Untitled',
          body: note.body || '',
          coverImage: note.coverImage || null,
          tags: note.tags || [],
          expiresInDays: expiry === '0' ? null : parseInt(expiry),
        }),
      });
      const data = await res.json();
      if (data.error) { setError(data.error); return; }
      const fullUrl = `${window.location.origin}/shared/${data.shareId}`;
      setShareUrl(fullUrl);
    } catch (e) { setError(e.message); }
    finally { setLoading(false); }
  }, [note, expiry]);

  const handleCopy = useCallback(() => {
    if (!shareUrl) return;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [shareUrl]);

  return (
    <div className="share-dialog-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="share-dialog">
        <div className="share-dialog__header">
          <span className="share-dialog__title">Share Note</span>
          <button className="share-dialog__close" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        <div className="share-dialog__body">
          <p style={{ margin: '0 0 12px', fontSize: '13px', color: 'var(--text-secondary, #aaa)' }}>
            Create a public link that anyone can use to view this note.
            Code blocks will be executable by viewers.
          </p>

          <div className="share-dialog__option">
            <label>Expires:</label>
            <select value={expiry} onChange={(e) => setExpiry(e.target.value)}>
              <option value="0">Never</option>
              <option value="1">1 day</option>
              <option value="7">7 days</option>
              <option value="30">30 days</option>
            </select>
          </div>

          {error && <p style={{ color: '#ef4444', fontSize: '13px', margin: '8px 0' }}>{error}</p>}

          {!shareUrl ? (
            <button className="share-dialog__btn share-dialog__btn--primary" onClick={handleShare} disabled={loading} style={{ width: '100%', marginTop: 8 }}>
              {loading ? 'Creating link...' : 'Create Share Link'}
            </button>
          ) : (
            <>
              <div className="share-dialog__link-row">
                <input className="share-dialog__link-input" value={shareUrl} readOnly onClick={(e) => e.target.select()} />
                <button className="share-dialog__btn share-dialog__btn--copy" onClick={handleCopy}>
                  {copied ? '✓ Copied' : 'Copy'}
                </button>
              </div>
              <div className="share-dialog__success">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4ade80" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                Share link created! Anyone with this link can view the note.
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
});

export default NoteShareDialog;
