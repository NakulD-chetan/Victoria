# Python Inheritance and Polymorphism

> *"MRO tells you the order Python searches for methods"* — Multiple inheritance key

Single / multiple / multilevel inheritance, `super()`, MRO, diamond situation, duck typing, operator overloading, and `ABC` — all in this file. Clear the base in [[07-Python-OOP-Classes-Objects]] first.

---

## 1. Single inheritance

> **Definition:** **Single inheritance** means a class declares one direct base class in parentheses and inherits its attributes and methods, optionally overriding them in the subclass.

**Why we need it:** Reuse and specialization—define common behavior once on the parent and extend or replace pieces in the child—without duplicating code across similar types.

**Syntax:**
```python
class Base:
    ...

class Child(Base):
    ...
```

```python
class Animal:           # Parent (base) class
    def speak(self):
        return "..."

class Dog(Animal):      # Dog INHERITS from Animal — gets everything Animal has
    def speak(self):    # OVERRIDES parent's speak — Dog has its own version
        return "woof"

d = Dog()
d.speak()  # "woof" → uses Dog's version (override), not Animal's
```

**Quick summary:**
- **Inheritance** = child class gets all methods/attributes from parent class
- **Override** = child provides its own version of a parent method
- **Multilevel:** `class Puppy(Dog):` — chain `Puppy` → `Dog` → `Animal` (Puppy gets everything)

---

## 2. `super()` — cooperative inheritance

> **Definition:** `super()` returns a proxy object that dispatches the next method in the **method resolution order (MRO)**, usually used to call a parent’s implementation from a subclass.

**Why we need it:** Subclasses should compose behavior with their bases (especially in multiple inheritance) without hard-coding the parent class name, so cooperative chains stay correct when the hierarchy changes.

**Syntax:**
```python
super().<method>(...)
super(ClassName, self).<method>(...)  # explicit form (older style)
```

```python
class Base:
    def __init__(self):
        print("Base init")

class Child(Base):
    def __init__(self):
        super().__init__()     # Calls PARENT's __init__ — makes sure parent sets up too
        print("Child init")

# Child() prints: "Base init" then "Child init"
# super() = "go to my parent class and call their version"
```

**Interview Tip:** With multiple inheritance `super()` is **not** only the parent class — it calls the **next** class in the **MRO**. So every class should use a **cooperative** `super()` chain.

---

## 3. MRO (Method Resolution Order)

> **Definition:** The **method resolution order (MRO)** is the linear sequence of classes Python searches when looking up a method or attribute on a class that uses inheritance (including multiple bases).

**Why we need it:** With multiple inheritance, a method could exist on several parents; a single predictable order avoids ambiguity and lets `super()` walk a consistent chain without calling the same base twice in diamond shapes.

**Syntax:**
```python
ClassName.__mro__
help(ClassName)  # shows MRO
```

```python
class A: pass
class B(A): pass
class C(A): pass
class D(B, C): pass

print(D.__mro__)
```

**C3 linearization** — consistent, monotonic order. `help(D)` also shows the linearization.

### Diamond shape (concept)

```text
    A
   / \
  B   C
   \ /
    D
```

Python builds a **linear** order so `A`'s `__init__` is not run twice — `super()` follows one **chain**.

**Watch Out!** If every `__init__` does not call `super()` — partial init / skipped bases — bugs.

---

## 4. Multiple inheritance — practical

> **Definition:** **Multiple inheritance** means a class lists more than one base in parentheses and inherits from all of them; Python merges their MRO so method lookup follows one combined order (left-to-right among bases matters).

**Why we need it:** You can mix in small, focused capabilities (mixins) or combine orthogonal behaviors without duplicating code or inventing one giant superclass.

**Syntax:**
```python
class Child(Base1, Base2, ...):
    ...
```

```python
class Flyer:
    def move(self):
        return "fly"

class Swimmer:
    def move(self):
        return "swim"

class Duck(Flyer, Swimmer):
    pass

Duck().move()  # 'fly' — first base (MRO left-to-right)
```

**Interview Tip:** **Mixins** — small focused parent classes; avoid deep messy graphs.

---

## 5. Duck typing — polymorphism without inheritance

> **Definition:** **Duck typing** means you rely on what an object *can do* (which methods or operations it supports), not on its class name or inheritance tree.

**Why we need it:** Many algorithms only need a protocol (e.g. “iterable” or “has `len`”); duck typing keeps APIs flexible and avoids forcing unrelated types into one artificial hierarchy.

**Syntax:**
```python
def use(obj):
    len(obj)       # works if obj supports len()
    for x in obj:  # works if obj is iterable
        ...
```

> "If it walks like a duck and quacks like a duck..."

```python
def length_of(obj):    # Works with ANY object that has len() — string, list, tuple...
    return len(obj)

length_of("hi")        # 2 → string has length
length_of([1, 2, 3])   # 3 → list has length
# No inheritance needed! If it supports len(), it works — that's duck typing
```

**EAFP** — try it, handle `TypeError` — [[10-Python-Exception-Handling]].

---

## 6. Operator overloading — dunder methods

> **Definition:** **Operator overloading** means defining dunder methods such as `__add__` or `__eq__` so operators like `+` and `==` invoke your custom logic on user-defined types.

**Why we need it:** Domain objects (vectors, matrices, money) read naturally with familiar operator syntax instead of verbose method calls, while staying type-safe and explicit.

**Syntax:**
```python
class ClassName:
    def __add__(self, other):
        ...

    def __eq__(self, other):
        ...
```

```python
class Vector:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)

    def __repr__(self):
        return f"Vector({self.x}, {self.y})"

Vector(1, 2) + Vector(3, 4)
```

| Dunder | Operator | What it lets you do |
|--------|----------|-----|
| `__add__` | `+` | Use `+` between your objects |
| `__mul__` | `*` | Use `*` between your objects |
| `__eq__` | `==` | Compare your objects for equality |
| `__lt__` | `<` | Compare if one object is "less than" another |

More depth: [[09-Python-Encapsulation-Special-Methods]].

---

## 7. Abstract Base Classes — `abc`

> **Definition:** An **abstract base class (ABC)** is a class that declares one or more **abstract methods** you must implement in subclasses; you cannot instantiate the ABC itself until those methods exist on a concrete class.

**Why we need it:** Libraries and frameworks can document required behavior, catch missing methods early, and share checks with `isinstance` against ABCs from `collections.abc` and similar.

**Syntax:**
```python
from abc import ABC, abstractmethod

class Base(ABC):
    @abstractmethod
    def method(self):
        ...
```

```python
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass

class Rect(Shape):
    def __init__(self, w, h):
        self.w, self.h = w, h
    def area(self):
        return self.w * self.h
```

**Watch Out!** Instantiating `Shape()` directly — `TypeError` until all abstract methods are implemented.

**Interview Tip:** `collections.abc` — `Iterable`, `Mapping` — structural typing checks.

---

## 8. `isinstance` / `issubclass`

> **Definition:** **`isinstance(obj, cls)`** is true if `obj` is an instance of `cls` or any subclass; **`issubclass(A, B)`** is true if class `A` derives from `B` (including `A is B`).

**Why we need them:** You validate inputs and branch on types in a way that respects inheritance, unlike comparing `type(x) == T`, which ignores subclasses.

**Syntax:**
```python
isinstance(object, ClassOrTuple)
issubclass(class_, ClassOrTuple)
```

```python
isinstance(d, Dog)       # True → checks "is d a Dog object?"
isinstance(d, Animal)    # True → Dog inherits from Animal, so d is also an Animal
issubclass(Dog, Animal)  # True → checks "is Dog class a child of Animal class?"
```

---

## 9. Composition vs inheritance — design mantra

> **Definition:** **Inheritance** models an **IS-A** relationship (a subtype specializes a general type); **composition** models **HAS-A** by storing another object inside and delegating to it.

**Why we need both concepts:** Inheritance shares interface and implementation but can create rigid hierarchies; composition swaps parts at runtime and avoids deep trees, which is why “favor composition over inheritance” is common advice.

**Syntax:**
```python
# Inheritance
class Child(Parent):
    ...

# Composition
class Owner:
    def __init__(self):
        self.part = Part()
```

| Approach | When to use | Example |
|----------|-----|---------|
| Inheritance | **IS-A** relationship — Dog IS-A Animal | `class Dog(Animal)` |
| Composition | **HAS-A** relationship — Car HAS-A Engine | `self.engine = Engine()` |

**Interview Tip:** "Favor composition over inheritance" — Gang of Four — valid in Python too.

---

## 10. `object` base — root of every class

> **Definition:** **`object`** is the built-in root type in Python 3: every class ultimately inherits from it, so all instances share baseline behavior like `__str__`, `__eq__`, and attribute access.

**Why we need it:** A single root gives a consistent object model, default implementations, and a place from which metaclasses and descriptors build the rest of the language.

**Syntax:**
```python
class C:          # same as class C(object):
    pass
```

In Python 3 every class derives from `object` — you don't have to write it.

---

## Quick Memory Card

```
+------------------------------------------+
| INHERITANCE                               |
| - class Child(Parent)                    |
| - override methods                       |
+------------------------------------------+
| super()                                   |
| - next in MRO chain                      |
+------------------------------------------+
| MRO / DIAMOND                             |
| - C3 linearization                       |
| - cooperative super() chains             |
+------------------------------------------+
| DUCK TYPING                               |
| - protocols / try / hasattr              |
+------------------------------------------+
| DUNDERS                                   |
| - __add__, __eq__, ...                   |
+------------------------------------------+
| ABC                                       |
| - ABC + @abstractmethod                  |
+------------------------------------------+
```

---

*Next: [[09-Python-Encapsulation-Special-Methods]]*
