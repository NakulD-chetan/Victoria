# Internals: REST/HTTP Caching Mechanics

> **Permanent Recall:** HTTP caching reduces latency and bandwidth by storing responses at browser, proxy, or CDN. Cache-Control controls who caches (public/private), how long (max-age), and revalidation (must-revalidate, stale-while-revalidate). ETags enable conditional requests (If-None-Match → 304 Not Modified, saves full body). Content negotiation (Accept, Accept-Encoding, Vary) affects cache keys. Chunked transfer enables streaming. Connection pooling amortizes TCP/TLS handshake cost. CDNs cache at edge; invalidation is purge or TTL. Proxies multiplex and buffer requests to upstream pools.

---

## 1. HTTP Caching Headers Deep Dive

```
CACHE HIERARCHY — WHERE RESPONSES CAN BE STORED:

  ┌─────────────────────────────────────────────────────────────────────┐
  │                         CACHING LAYERS                               │
  │                                                                     │
  │  Browser Cache (private)     Proxy Cache (shared)    CDN Edge        │
  │  ┌─────────────────┐        ┌─────────────────┐    ┌─────────────┐ │
  │  │ Memory + Disk   │        │ Corporate proxy │    │ Cloudflare  │ │
  │  │ ~50-500 MB      │        │ Squid, Varnish │    │ Akamai, etc │ │
  │  │ Per-user        │        │ Shared by users │    │ Per-POP     │ │
  │  └────────┬────────┘        └────────┬────────┘    └──────┬──────┘ │
  │           │                          │                    │        │
  │           └──────────────────────────┴────────────────────┘        │
  │                                    │                               │
  │                                    ▼                               │
  │                           ┌─────────────────┐                      │
  │                           │   Origin API    │                      │
  │                           │   (no cache)    │                      │
  │                           └─────────────────┘                      │
  └─────────────────────────────────────────────────────────────────────┘
```

### Cache-Control — The Master Directive

```
CACHE-CONTROL DIRECTIVES (comma-separated, order doesn't matter):

  Cache-Control: max-age=3600, public, must-revalidate

BYTE-LEVEL ON WIRE:
  43 61 63 68 65 2D 43 6F 6E 74 72 6F 6C 3A 20  = "Cache-Control: "
  6D 61 78 2D 61 67 65 3D 33 36 30 30 2C 20     = "max-age=3600, "
  70 75 62 6C 69 63 2C 20 6D 75 73 74 2D 72 65  = "public, must-re"
  76 61 6C 69 64 61 74 65 0D 0A                 = "validate\r\n"

DIRECTIVE REFERENCE:

  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Directive          │ Effect                                            │
  ├────────────────────┼──────────────────────────────────────────────────┤
  │ max-age=N          │ Response fresh for N seconds from receipt        │
  │                    │ Stored as: expiry_time = now + N                  │
  │ s-maxage=N         │ Same as max-age but for SHARED caches only       │
  │                    │ (CDN, proxy). Overrides max-age for shared.       │
  │ public             │ May be stored by ANY cache (browser, proxy, CDN) │
  │ private            │ May be stored ONLY by browser (user's cache)     │
  │                    │ Proxy/CDN must NOT store (e.g., personalized)     │
  │ no-cache           │ MUST revalidate before use (send If-None-Match)   │
  │                    │ Can store, but must check with origin first       │
  │ no-store           │ MUST NOT store anywhere (sensitive data)          │
  │ must-revalidate    │ After expiry, MUST revalidate (no stale serve)    │
  │                    │ Without: cache MAY serve stale if origin down     │
  │ stale-while-       │ After expiry, may serve stale for N sec while     │
  │   revalidate=N     │ background revalidation (best of both worlds)     │
  │ immutable          │ Response never changes; no revalidation needed   │
  └────────────────────┴──────────────────────────────────────────────────┘
```

### Browser/Proxy Cache Decision Algorithm

```
CACHE LOOKUP ALGORITHM (step-by-step):

  Request: GET /api/v1/users/123
  Cache has entry for this URL

  STEP 1: Is response cacheable?
    - Method is GET or HEAD? ✓
    - Status was 200, 203, 206, 300, 301, 404, 405, 410? ✓
    - No Cache-Control: no-store? ✓
    - No Vary: * (uncacheable)? ✓
    → If any fails: BYPASS cache, fetch from origin

  STEP 2: Compute cache key
    Key = (Request-URI, Vary header values)
    If Vary: Accept-Encoding → key includes Accept-Encoding from request
    If Vary: Authorization → key includes Authorization (often = no hit!)

  STEP 3: Find matching cache entry
    Lookup(key) → entry or miss

  STEP 4: If hit, check freshness
    freshness_lifetime = max-age value (or derived from Expires - Date)
    age = now - (response_time + Age header)
    is_fresh = (age < freshness_lifetime)

  STEP 5: If fresh → SERVE FROM CACHE (no network)
    Return cached response immediately
    No request sent to origin!

  STEP 6: If stale:
    - must-revalidate? → MUST revalidate (conditional request)
    - stale-while-revalidate? → Serve stale, async revalidate in background
    - Otherwise: MAY serve stale if origin unreachable (RFC 7234)
```

### Expires vs Cache-Control

```
EXPIRES HEADER (legacy, HTTP/1.0):

  Expires: Wed, 13 Mar 2025 12:00:00 GMT

  Format: HTTP-date (RFC 7231)
  Absolute timestamp when response becomes stale
  Problem: Client and server clocks can differ!
  If server clock is wrong: cache forever or never cache

  Cache-Control takes precedence when both present:
  Cache-Control: max-age=3600
  Expires: Wed, 13 Mar 2025 12:00:00 GMT
  → max-age wins (relative to receipt time)
```

### Pragma: no-cache (HTTP/1.0 Compatibility)

```
  Pragma: no-cache

  HTTP/1.0 had no Cache-Control. Pragma was the workaround.
  Equivalent to: Cache-Control: no-cache (for requests)
  Browsers send both for compatibility:
    Cache-Control: no-cache
    Pragma: no-cache

  On RESPONSE: Pragma has no defined meaning (ignore for caching)
  On REQUEST: "Don't use cached copy without revalidation"
```

---

## 2. ETags and Conditional Requests

```
ETAG — CONTENT FINGERPRINT FOR VALIDATION:

  Server sends: ETag: "33a64df551425fcc55e4d42a148795d9f25f89d4"

  Strong ETag (default): Exact byte-for-byte match required
  Weak ETag:     ETag: W/"33a64df5"  (semantic equivalence, not byte-identical)
```

### How ETags Are Generated

```
ETAG GENERATION STRATEGIES:

  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Strategy           │ Implementation                                    │
  ├────────────────────┼──────────────────────────────────────────────────┤
  │ Content hash       │ MD5(body) or SHA-256(body)[:16]                    │
  │                    │ Changes when ANY byte changes                      │
  │ Version/timestamp  │ ETag: "v123" or "1699876543"                        │
  │                    │ Increment on update; no body hashing               │
  │ Inode+mtime        │ ETag: hex(inode + mtime) for static files          │
  │                    │ Nginx: etag on; uses inode+mtime+size               │
  └────────────────────┴──────────────────────────────────────────────────┘

  EXAMPLE (Node.js with content hash):
    const crypto = require('crypto');
    const etag = '"' + crypto.createHash('md5').update(body).digest('hex') + '"';
    res.setHeader('ETag', etag);
```

### Conditional Request — Byte-Level Wire Example

```
FIRST REQUEST (no cache):

  Client                                          Server
    │                                                │
    │  GET /api/v1/users/123 HTTP/1.1\r\n            │
    │  Host: api.example.com\r\n                     │
    │  Accept: application/json\r\n                  │
    │  \r\n                                          │
    │  ──────────────────────────────────────────►  │
    │                                                │
    │  HTTP/1.1 200 OK\r\n                           │
    │  Content-Type: application/json\r\n            │
    │  Content-Length: 85\r\n                        │
    │  Cache-Control: max-age=60\r\n                 │
    │  ETag: "abc123"\r\n                            │
    │  \r\n                                          │
    │  {"id":123,"name":"John","email":"john@example.com"}\r\n
    │  ◄──────────────────────────────────────────   │
    │                                                │
  Client stores: body (85 bytes) + ETag "abc123"
  Cache fresh for 60 seconds

SECOND REQUEST (after 61 seconds — stale, conditional):

  Client                                          Server
    │                                                │
    │  GET /api/v1/users/123 HTTP/1.1\r\n            │
    │  Host: api.example.com\r\n                     │
    │  If-None-Match: "abc123"\r\n     ← KEY: "If ETag matches, skip body" │
    │  \r\n                                          │
    │  ──────────────────────────────────────────►  │
    │                                                │
    │  Server compares: current_etag vs "abc123"     │
    │  If SAME → 304 Not Modified (no body!)         │
    │  If DIFF → 200 OK + full body                  │
    │                                                │
    │  HTTP/1.1 304 Not Modified\r\n                 │
    │  Cache-Control: max-age=60\r\n                 │
    │  ETag: "abc123"\r\n                            │
    │  \r\n                                          │
    │  (NO BODY — 0 bytes!)                          │
    │  ◄──────────────────────────────────────────   │
    │                                                │
  Client: uses cached body, updates freshness
  BANDWIDTH SAVED: 85 bytes (for 85-byte response)
  For 100KB JSON: saves ~100KB per revalidation!
```

### If-Modified-Since (Fallback)

```
  If-Nodified-Since: Wed, 13 Mar 2024 12:00:00 GMT

  Sent with Last-Modified from previous response
  Server: if (last_modified <= if_modified_since) → 304
  Less precise than ETag (1-second granularity, clock skew)
  ETag preferred when both available
```

---

## 3. Content Negotiation

```
CONTENT NEGOTIATION — SERVER PICKS REPRESENTATION BASED ON REQUEST:

  Client sends preferences; server picks best match

  ┌─────────────────────┬────────────────────────────────────────────────┐
  │ Header              │ Purpose                                         │
  ├─────────────────────┼────────────────────────────────────────────────┤
  │ Accept              │ Content type: application/json, text/html      │
  │ Accept-Encoding     │ Compression: gzip, br, deflate                  │
  │ Accept-Language     │ Language: en-US, en;q=0.9, fr;q=0.8            │
  │ Accept-Charset      │ Character set: utf-8 (rarely used)              │
  └─────────────────────┴────────────────────────────────────────────────┘
```

### Quality Values (q=)

```
  Accept: application/json, text/plain;q=0.9, */*;q=0.8

  Format: type;q=value  (q = 0.0 to 1.0, default 1.0)
  application/json → q=1.0 (implicit)
  text/plain → q=0.9 (preferred over wildcard)
  */* → q=0.8 (lowest)

  Server picks highest q that it can satisfy
```

### Vary Header — Critical for Caching

```
  Vary: Accept-Encoding, Accept-Language

  MEANING: "This response is valid only for requests with the SAME
            Accept-Encoding and Accept-Language values"

  CACHE KEY EXPANSION:
    Without Vary:  key = URL
    With Vary:     key = (URL, Accept-Encoding, Accept-Language)

  Example:
    Request 1: Accept-Encoding: gzip  → 200 + gzipped body
    Request 2: Accept-Encoding: identity → DIFFERENT response (uncompressed)
    Cache must store BOTH under different keys!

  Vary: * = "Response varies on something we can't cache" → UNCACHEABLE
  Common mistake: Vary: Authorization for user-specific data
    → Every user gets different cache key = low hit rate
```

---

## 4. HTTP Compression

```
COMPRESSION — REDUCE BANDWIDTH AT COST OF CPU:

  Server compresses body before sending
  Client decompresses after receiving
  Content-Encoding indicates algorithm
```

### Wire-Level: gzip, brotli, deflate

```
REQUEST:
  Accept-Encoding: gzip, deflate, br

  br = Brotli (best ratio, slower)
  gzip = most common (good balance)
  deflate = zlib (often misimplemented, avoid)

RESPONSE (compressed):
  Content-Encoding: gzip
  Content-Length: 342    ← Compressed size (was 1024 uncompressed)

  Body: raw gzip stream (RFC 1952)
    - 10-byte gzip header
    - deflate-compressed data
    - 8-byte gzip trailer (CRC32, original size)
```

### Bandwidth Savings for JSON APIs

```
  TYPICAL JSON COMPRESSION RATIOS:

  Uncompressed:  {"id":123,"name":"John Smith","email":"john@example.com",...}
  Repeated keys: "id","name","email" — compress very well

  ┌──────────────────┬─────────────┬─────────────┬──────────────┐
  │ Payload size     │ gzip        │ brotli      │ Typical API  │
  ├──────────────────┼─────────────┼─────────────┼──────────────┤
  │ 1 KB             │ ~400 B      │ ~350 B      │ 60-70% save  │
  │ 10 KB            │ ~2.5 KB     │ ~2 KB       │ 75-80% save  │
  │ 100 KB           │ ~15 KB      │ ~12 KB      │ 85-88% save  │
  └──────────────────┴─────────────┴─────────────┴──────────────┘

  JSON compresses well: repetitive structure, text
  Already-compressed (images, video): don't re-compress
```

### When Compression Happens

```
  SERVER SIDE:
    1. Generate response body (e.g., JSON string)
    2. Compress with zlib/brotli
    3. Set Content-Encoding: gzip
    4. Set Content-Length: compressed_size
    5. Send compressed bytes

  CLIENT SIDE:
    1. Receive bytes
    2. Check Content-Encoding
    3. Decompress (e.g., zlib.inflate)
    4. Parse JSON from decompressed buffer
    5. Return to application

  Transparent to application code (handled by HTTP client lib)
```

---

## 5. Chunked Transfer Encoding

```
CHUNKED — STREAMING WITHOUT KNOWING LENGTH IN ADVANCE:

  When server doesn't know Content-Length upfront:
  - Dynamic generation
  - Streaming from database
  - Server-Sent Events (SSE)
```

### Chunk Format (RFC 7230)

```
  Transfer-Encoding: chunked

  BODY FORMAT:
    <size in hex>\r\n
    <data bytes>\r\n
    <size in hex>\r\n
    <data bytes>\r\n
    ...
    0\r\n
    \r\n

  BYTE-LEVEL EXAMPLE:
    "1A\r\n"                    = 26 (hex) = 26 bytes of data
    "{\"id\":1,\"name\":\"Alice\"}\r\n"   = 26 bytes
    "1A\r\n"                    = next chunk, 26 bytes
    "{\"id\":2,\"name\":\"Bob\"}\r\n"
    "0\r\n"                     = last chunk (size 0)
    "\r\n"                      = end of body

  Each chunk: chunk-size (hex) + CRLF + chunk-data + CRLF
  Final chunk: 0 + CRLF + optional trailers + CRLF
```

### Why It Matters for Large API Responses

```
  WITHOUT CHUNKED (Content-Length):
    Server must buffer ENTIRE response in memory
    1 GB response = 1 GB RAM held until complete
    Client waits for full response before first byte useful

  WITH CHUNKED:
    Server can send chunks as soon as data ready
    Client can start parsing/processing first chunk
    Memory: O(chunk_size) not O(total_size)
    Latency: Time to First Byte (TTFB) = first chunk, not full response

  Connection draining: Server sends 0\r\n\r\n to signal end
  Client knows response complete, can close or reuse connection
```

---

## 6. Connection Pooling

```
CONNECTION POOL — REUSE TCP/TLS CONNECTIONS:

  Without pooling: Every request = new TCP + TLS handshake
  With pooling: Create once, reuse many times
```

### How HTTP Client Libraries Maintain Pools

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │                    CONNECTION POOL INTERNALS                         │
  │                                                                     │
  │  Key: (host, port, scheme)  e.g., ("api.example.com", 443, "https") │
  │                                                                     │
  │  Pool state:                                                        │
  │    - active: connections currently in use (request in flight)       │
  │    - idle:   connections waiting for reuse                          │
  │    - max:    max connections per host (default 6-10)                │
  │                                                                     │
  │  On request:                                                        │
  │    1. Get idle connection from pool (if any)                        │
  │    2. If none and under max: create new connection                  │
  │    3. If at max: queue request until connection free               │
  │    4. Send request on connection                                    │
  │    5. On response: return connection to idle pool                   │
  └─────────────────────────────────────────────────────────────────────┘
```

### Connection Lifecycle

```
  create → use → idle → reuse or close

  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
  │ CREATE   │───►│ USE      │───►│ IDLE     │───►│ REUSE    │
  │ TCP sync │    │ Send req │    │ In pool  │    │ or CLOSE │
  │ TLS hand │    │ Recv rsp │    │ wait     │    │ (timeout)│
  └──────────┘    └──────────┘    └──────────┘    └──────────┘

  Keep-alive timeout: Server sends Connection: keep-alive, Keep-Alive: timeout=5
  Client closes connection after idle timeout (e.g., 5-30 seconds)
  Kernel: close() releases file descriptor, TCP buffer memory
```

### Kernel Resources Per Connection

```
  PER CONNECTION (Linux):
    - 1 file descriptor (ulimit -n)
    - TCP socket buffer: ~2x default (e.g., 2 × 87 KB = 174 KB)
    - TLS session state: ~1-2 KB
    - Epoll/kqueue entry if using async I/O

  1000 connections = 1000 FDs + ~170 MB for buffers
  Connection pooling limits total connections (e.g., 5 per host)
  Prevents FD exhaustion and memory blowup
```

---

## 7. CDN Caching for APIs

```
CDN — CACHE AT EDGE, CLOSE TO USERS:

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   User (Tokyo)          User (London)         User (NYC)            │
  │        │                     │                     │               │
  │        ▼                     ▼                     ▼               │
  │   ┌─────────┐           ┌─────────┐           ┌─────────┐          │
  │   │ Edge JP │           │ Edge UK │           │ Edge US │          │
  │   │ (cache) │           │ (cache) │           │ (cache) │          │
  │   └────┬────┘           └────┬────┘           └────┬────┘          │
  │        │                     │                     │               │
  │        └─────────────────────┼─────────────────────┘               │
  │                              │                                     │
  │                              ▼                                     │
  │                       ┌─────────────┐                              │
  │                       │   Origin    │                              │
  │                       │ api.example │                              │
  │                       └─────────────┘                              │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Cache Keys

```
  CDN cache key = f(URL, selected headers)

  Default: URL only
    GET /api/v1/users/123 → key = "/api/v1/users/123"

  With Vary: URL + Vary header values
    Vary: Accept-Encoding → key includes Accept-Encoding
    Request with gzip vs identity = different cache entries

  Custom (Cloudflare, etc.): Can include query params, cookies, headers
    Cache key = URL + ?api_key=xxx (for per-tenant caching)
```

### Cache Invalidation

```
  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Method             │ How it works                                      │
  ├────────────────────┼──────────────────────────────────────────────────┤
  │ TTL expiry         │ Cache-Control: max-age=3600 → auto-expire         │
  │ Purge              │ API call: PURGE /api/v1/users/123                │
  │                    │ Removes specific URL from all edge caches         │
  │ Purge all         │ Nuclear option: clear entire cache                │
  │ stale-while-       │ Serve stale, revalidate in background            │
  │   revalidate       │ Smooth invalidation (no thundering herd)         │
  └────────────────────┴──────────────────────────────────────────────────┘
```

### Vary Header Impact on CDN Hit Rate

```
  BAD: Vary: User-Agent, Accept-Language, Cookie
    Every combination = separate cache entry
    Hit rate can drop to <1% (too many variants)

  GOOD: Vary: Accept-Encoding
    Only 2-3 variants (gzip, br, identity)
    Hit rate stays high

  For APIs: Avoid Vary on user-specific headers unless necessary
```

---

## 8. HTTP Proxy Internals

```
PROXY TYPES:

  Forward proxy:  Client → Proxy → Internet (e.g., corporate Squid)
  Reverse proxy:  Client → Proxy → Origin (e.g., nginx, Envoy in front of API)
```

### Forward vs Reverse Proxy

```
  FORWARD PROXY (client-initiated):
    Client configures: proxy = proxy.corp.com:3128
    Client sends: GET http://api.example.com/users
    Proxy fetches on behalf of client
    Use: corporate filtering, caching, anonymity

  REVERSE PROXY (server-side):
    Client thinks it talks to api.example.com
    Actually: api.example.com DNS → proxy IP
    Proxy forwards to upstream (e.g., 10.0.1.5:8080)
    Use: load balancing, TLS termination, caching, WAF
```

### How nginx/Envoy Handle API Requests

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │                    REVERSE PROXY REQUEST FLOW                        │
  │                                                                     │
  │  1. Accept connection (listen 443)                                   │
  │  2. TLS termination (if HTTPS)                                      │
  │  3. Parse HTTP request (headers, body)                               │
  │  4. Match location / API route                                      │
  │  5. Check cache (if configured) → cache hit? return                 │
  │  6. Get upstream connection from pool                               │
  │  7. Forward request to upstream (e.g., 10.0.1.5:8080)               │
  │  8. Buffer response (or stream if chunked)                           │
  │  9. Optionally cache response                                       │
  │ 10. Send response to client                                         │
  │ 11. Return upstream connection to pool                               │
  └─────────────────────────────────────────────────────────────────────┘
```

### Connection Multiplexing

```
  HTTP/1.1: One request per connection (at a time)
  Proxy maintains pool of connections to upstream
  Each client connection can use different upstream connection

  HTTP/2: Multiplexing on single connection
  Proxy: 1 HTTP/2 connection to upstream, many streams
  More efficient: fewer connections, less overhead
```

### Request Buffering and Upstream Pools

```
  REQUEST BUFFERING:
    Client may send body slowly (e.g., 1 byte/sec)
    Proxy buffers full request before forwarding to upstream
    Prevents slow client from holding upstream connection
    proxy_request_buffering on (nginx default)

  UPSTREAM CONNECTION POOL:
    keepalive 32;  (nginx)
    Maintains 32 idle connections to upstream
    Reuses for new requests (no TCP/TLS handshake)
    Similar to client-side pooling, but proxy → origin
```

---

## 30-SECOND REVISION BOX

```
CACHE-CONTROL: max-age (freshness), no-store (never cache), no-cache (revalidate),
  public/private (who caches), s-maxage (shared), stale-while-revalidate
ETAG: content fingerprint, If-None-Match → 304 (no body), saves bandwidth
VARY: expands cache key, Vary: * = uncacheable, avoid on user-specific headers
COMPRESSION: gzip/br, Content-Encoding, JSON 70-85% smaller
CHUNKED: size(hex)\r\ndata\r\n, streaming, no Content-Length needed
CONNECTION POOL: reuse TCP+TLS, idle timeout, max per host, kernel FD per conn
CDN: edge cache, key=URL+headers, purge invalidation, Vary hurts hit rate
PROXY: forward (client→net), reverse (client→origin), buffer, upstream pool
```

---

**Prev: [[10_Internals-TLS-Handshake-Cryptography]] | Next: [[12_Internals-GraphQL-Execution-Engine]]**
