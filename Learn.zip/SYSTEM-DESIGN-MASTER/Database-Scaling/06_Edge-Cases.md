# Database Scaling — Edge Cases

> **Permanent Recall:** Critical edge cases: replication lag causing stale reads, hot shard (one shard overloaded), cross-shard transactions (2PC or saga), shard rebalancing (data movement without downtime), split brain in master-master, data inconsistency during failover, schema changes across shards, and backup consistency across shards. Each has a cause, symptom, and mitigation. Know these for "what if" questions in FAANG interviews.

---

## Edge Case 1: Replication Lag Causing Stale Reads

**Cause:** Async replication; replica is seconds behind master.

**Symptom:** User updates profile, refreshes immediately, sees old data.

**Mitigation:**

| Approach | How | Trade-off |
|----------|-----|-----------|
| **Read from master** | Route read-after-write to master | Master load increases |
| **Session stickiness** | Same session → same replica (lag bounded) | Complex routing |
| **Sync replication** | Wait for replica ack | Higher write latency |
| **Version/ETag** | Client sends version; reject if stale | Extra round-trip |

---

## Edge Case 2: Hot Shard

**Cause:** One shard gets disproportionate load (e.g., shard key = country, US shard huge).

**Symptom:** One shard at 100% CPU, others idle. Latency spike for that shard's data.

```
    Shard 0: 10% load    Shard 1: 80% load    Shard 2: 10% load
                         (HOT)
```

**Mitigation:**
- Reshard hot shard (split into sub-shards)
- Choose better shard key (higher cardinality)
- Add read replicas for hot shard only
- Cache hot shard data aggressively

---

## Edge Case 3: Cross-Shard Transactions

**Cause:** Transaction spans multiple shards (e.g., transfer from user A to B on different shards).

**Symptom:** Can't use single DB transaction. Need distributed coordination.

**Mitigation:**

| Approach | How | Consistency |
|----------|-----|--------------|
| **2PC (Two-Phase Commit)** | Coordinator; prepare all, then commit all | Strong, blocking |
| **Saga** | Compensating transactions; rollback via reverse ops | Eventual |
| **Avoid** | Design so transaction is single-shard | Best |

> **FAANG Tip:** "We'd avoid cross-shard transactions when possible. If needed, saga for async or 2PC for strong consistency—know 2PC blocks on failures."

---

## Edge Case 4: Shard Rebalancing

**Cause:** Add/remove shards; need to move data. Can't freeze writes.

**Symptom:** Data movement while serving traffic; risk of inconsistency, long migration.

**Mitigation:**
- Dual-write during migration (old + new shard)
- Background copy, diff, catch-up
- Switch reads incrementally by key range
- Use consistent hashing to minimize moves

---

## Edge Case 5: Split Brain in Master-Master

**Cause:** Network partition between two masters; each thinks it's primary; both accept writes.

**Symptom:** Conflicting writes; data divergence; on merge, which wins?

**Mitigation:**
- Avoid master-master if possible
- Use conflict resolution (last-write-wins, vector clocks)
- Quorum writes (need majority to commit)
- Prefer single-master with async replicas

---

## Edge Case 6: Data Inconsistency During Failover

**Cause:** Master dies; replica promoted; replica had replication lag → last few writes lost.

**Symptom:** Users see data loss (e.g., last 100ms of writes gone).

**Mitigation:**
- Semi-sync replication (at least one replica ack)
- Synchronous replication for critical data
- Accept small window of loss; document RPO
- Replicate to multiple replicas before commit

---

## Edge Case 7: Schema Changes Across Shards

**Cause:** Add column, change type across 100 shards. Can't lock all at once.

**Symptom:** Some shards on new schema, some on old; app must handle both.

**Mitigation:**
- **Expand-contract:** Add nullable column → backfill → make non-null
- **Multi-version app:** App supports old and new schema during migration
- **Online schema change tools:** pt-online-schema-change, gh-ost
- **Blue-green per shard:** Migrate shards one by one

---

## Edge Case 8: Backup Consistency Across Shards

**Cause:** Back up each shard at different times → restore gives inconsistent global state.

**Symptom:** User's order on shard 1, payment on shard 2—timestamps don't match; referential inconsistency.

**Mitigation:**
- Use same logical timestamp (e.g., GTID) for all shards
- Or accept eventual consistency in backup
- Document restore order if shards have dependencies
- Consider logical backup with consistent point-in-time

---

## Edge Cases Summary Table

| Edge Case | Cause | Mitigation |
|-----------|-------|------------|
| Stale reads | Replication lag | Read from master, session stickiness, sync |
| Hot shard | Bad shard key, skew | Reshard, better key, replicas, cache |
| Cross-shard TX | Multi-shard transaction | Avoid, or saga/2PC |
| Rebalancing | Add/remove shards | Dual-write, incremental switch |
| Split brain | Master-master partition | Avoid, conflict resolution, quorum |
| Failover inconsistency | Lag at promote | Semi-sync, sync replication |
| Schema change | Multi-shard deploy | Expand-contract, multi-version app |
| Backup consistency | Different snapshot times | Same logical timestamp, document |

---

## 30-SECOND REVISION BOX

```
STALE READS:    Read from master, sync replica
HOT SHARD:      Reshard, better key, cache
CROSS-SHARD TX: Avoid; saga or 2PC
REBALANCING:    Dual-write, incremental
SPLIT BRAIN:    Avoid master-master
FAILOVER:       Semi-sync, multiple replicas
SCHEMA:         Expand-contract, multi-version
BACKUP:         Consistent timestamp across shards
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
