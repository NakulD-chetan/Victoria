# System Design Fundamentals — Mental Model

> **Permanent Recall:** Think top-down: decompose "Design X" into sub-problems, map requirements to components, and layer your architecture (Presentation → Application → Data → Infrastructure). Use the Restaurant Analogy: kitchen=backend, waiters=API, menu=interface, customers=users. There is no perfect system—every choice is a trade-off. Ask "what question first?" before jumping to solutions.

---

## How to Think About System Design

**Top-down decomposition** is the core mental model: start with the big picture, then drill into specifics. Never jump to "we need Kafka" before understanding *what* needs to be decoupled and *why*.

```
Design Twitter Feed
        │
        ├── Who reads? (Users, followers)
        ├── What's read? (Tweets, timeline)
        ├── How fast? (Real-time vs eventual)
        ├── Scale? (100M DAU, 500M tweets/day)
        └── Constraints? (Ordering, ranking, personalization)
```

> **FAANG Tip:** The first question you ask sets the interview tone. "What's the scale?" or "Read-heavy or write-heavy?" shows you think systematically.

---

## The Restaurant Analogy

Map any system to a restaurant to build intuition:

| Restaurant Component | System Component | Purpose |
|---------------------|------------------|---------|
| **Customers** | Users / Clients | Request service |
| **Menu** | API / Interface | What's available, how to order |
| **Waiters** | API Layer / Gateway | Take orders, deliver responses |
| **Kitchen** | Backend / Application Servers | Process requests, business logic |
| **Recipes** | Business Logic / Algorithms | How to transform inputs |
| **Pantry/Inventory** | Database | Persistent storage |
| **Prep Station** | Cache | Pre-made items for speed |
| **Order Tickets** | Message Queue | Async handoff, decoupling |
| **Multiple Kitchens** | Microservices | Specialized units |
| **Head Chef** | Load Balancer | Distributes work |

---

## Decision-Making Framework: What Question to Ask First

```
                    ┌─────────────────────────┐
                    │  "Design X" Problem      │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │ 1. SCALE: How big?      │  ← Always first
                    │    (Users, QPS, storage) │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │ 2. PATTERN: Read-heavy? │
                    │    Write-heavy? Real-time?│
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │ 3. CONSTRAINTS: Latency?│
                    │    Consistency? Global?  │
                    └────────────┬────────────┘
                                 │
                                 ▼
                    ┌─────────────────────────┐
                    │ 4. COMPONENTS: Now pick │
                    │    DB, cache, queue...   │
                    └─────────────────────────┘
```

---

## Requirement → Component Mapping

| Requirement | Likely Components |
|-------------|-------------------|
| High read throughput | Cache, read replicas, CDN |
| High write throughput | Sharding, async writes, batching |
| Real-time updates | WebSockets, Server-Sent Events, push |
| Search | Elasticsearch, dedicated search index |
| Global users | Multi-region, CDN, edge compute |
| Event ordering | Kafka partitions, single-writer pattern |
| Strong consistency | Primary-replica, distributed locks |
| Eventual consistency | Async replication, CRDTs |

---

## How to Decompose "Design X" Into Sub-Problems

**Example: Design a URL Shortener**

| Sub-Problem | Question | Leads To |
|-------------|----------|----------|
| **Storage** | Where do we store long URL ↔ short URL mapping? | Database choice, schema |
| **Generation** | How do we generate short codes? | Hash, base62, counter |
| **Scale** | How many redirects per second? | Caching, CDN |
| **Uniqueness** | Collision handling? | Retry, longer codes |
| **Analytics** | Click tracking? | Async logging, separate service |

---

## The Layers of a System

```
┌─────────────────────────────────────────────────────────────────┐
│  PRESENTATION LAYER                                              │
│  - Web/Mobile clients, API Gateway, Auth                         │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│  APPLICATION LAYER                                              │
│  - Business logic, microservices, orchestration                  │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│  DATA LAYER                                                     │
│  - Cache, database, search index, object storage                 │
└───────────────────────────────┬─────────────────────────────────┘
                                │
┌───────────────────────────────▼─────────────────────────────────┐
│  INFRASTRUCTURE LAYER                                           │
│  - Load balancers, DNS, networking, compute (VMs/containers)    │
└─────────────────────────────────────────────────────────────────┘
```

> **FAANG Tip:** Draw layers when explaining. It shows you think in abstractions, not just "boxes and arrows."

---

## Trade-Off Thinking: There Is No Perfect System

| Trade-Off | Option A | Option B |
|-----------|----------|----------|
| **Consistency vs Availability** | Strong consistency (slower, can fail) | Eventual consistency (faster, may be stale) |
| **Latency vs Cost** | More replicas, edge caching (low latency, high cost) | Fewer nodes (higher latency, lower cost) |
| **Simplicity vs Scale** | Monolith (easier ops) | Distributed (complex ops, more scale) |
| **Read vs Write optimization** | Denormalized (fast reads, slow writes) | Normalized (slower reads, consistent writes) |

**Always state the trade-off** when making a choice: "I'm choosing X over Y because we value Z, accepting the downside of W."

---

## Mermaid: How to Approach Any System Design Problem

```mermaid
flowchart TD
    A["Start: Design X"] --> B["Clarify Requirements"]
    B --> C["Functional Requirements"]
    B --> D["Non-Functional Requirements"]
    C --> E["Estimate Scale"]
    D --> E
    E --> F["Identify Pattern"]
    F --> G{"Read-heavy?"}
    G -->|Yes| H["Cache, replicas, CDN"]
    G -->|No| I{"Write-heavy?"}
    I -->|Yes| J["Sharding, async, batching"]
    I -->|No| K{"Real-time?"}
    K -->|Yes| L["WebSockets, push, streams"]
    H --> M["High-Level Design"]
    J --> M
    L --> M
    M --> N["Draw Components"]
    N --> O["Deep Dive Critical Path"]
    O --> P["Address Bottlenecks"]
    P --> Q["Discuss Failures & Trade-offs"]
    Q --> R["Done"]
    
    style A fill:#339af0,color:#fff
    style M fill:#51cf66,color:#fff
    style R fill:#51cf66,color:#fff
```

---

## ASCII: System Layers Diagram

```
         ┌──────────────────────────────────────────┐
         │  CLIENTS (Web, Mobile, API consumers)     │
         └────────────────────┬─────────────────────┘
                             │ HTTP/gRPC
         ┌───────────────────▼─────────────────────┐
         │  EDGE (CDN, API Gateway, Auth)           │
         └───────────────────┬─────────────────────┘
                             │
         ┌───────────────────▼─────────────────────┐
         │  APP TIER (Microservices, Workers)       │
         └───────────────────┬─────────────────────┘
                             │
         ┌───────────────────▼─────────────────────┐
         │  DATA TIER (Cache → DB → Queue)          │
         └─────────────────────────────────────────┘
```

---

## Quick Memory Card

```
TOP-DOWN:     Decompose first, components second
RESTAURANT:   Kitchen=backend, Waiters=API, Menu=interface
FIRST Q:      Scale → Pattern → Constraints → Components
LAYERS:       Presentation → Application → Data → Infrastructure
TRADE-OFFS:   No perfect system—always state "X because Y, accepting Z"
```

---

**Next: [[03_Design-Template]]**
