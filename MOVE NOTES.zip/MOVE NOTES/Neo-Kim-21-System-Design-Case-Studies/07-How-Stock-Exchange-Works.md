# How Stock Exchange Works - System Design

> Source: https://newsletter.systemdesign.one/p/stock-exchange-system-design

## One-Line Summary
A stock exchange matches BUY and SELL orders in real-time using an in-memory order book with O(1) insert/cancel operations, connected through brokers and gateways using the FIX protocol and event-sourced architecture.

## Key Requirements

### Functional
- Users place BUY or SELL orders (market or limit orders)
- Users can cancel orders at any time
- Exchange matches buyers and sellers in real-time
- Publish market data (prices, trades) in real-time
- Restrict number of shares a user can trade per day
- Support both market orders and limit orders

### Non-Functional
- Ultra-low latency (microseconds for matching)
- Deterministic (same input always produces same output)
- Fair and transparent (FIFO ordering)
- High throughput (millions of messages/sec)
- Fault tolerant with fast recovery
- Exactly-once guarantee for order processing

## Trading Terms (Simple Language)

| Term | Meaning |
|------|---------|
| **Broker** | App that lets you buy/sell stocks (e.g., Robinhood, Zerodha) |
| **Order Book** | List of all current BUY and SELL orders for a stock |
| **Market Order** | Buy/sell immediately at current price (no price specified) |
| **Limit Order** | Buy/sell only at a specific price or better |
| **Spread** | Gap between highest BUY price and lowest SELL price |
| **BID** | Highest price a buyer is willing to pay |
| **ASK** | Lowest price a seller is willing to accept |

## Message Distribution
- New orders: ~50% of messages
- Cancellations: ~40% of messages
- Executions (actual trades): ~2% of messages
- Rest: noise

## High-Level Architecture

```
Users
  |
Broker (REST + WebSocket)
  |
  | (FIX Protocol)
  |
Gateway
  ├── Risk Manager (funds check, fraud detection)
  ├── Wallet Service (user funds and assets)
  └── Order Manager (sequence numbers, state tracking)
         |
    [Topic Queues] (new order | cancel | trade)
         |
Matching Engine
  ├── Order Book (in-memory BUY/SELL lists)
  └── Matching Logic (price-time priority)
         |
    Market Data Publisher
```

## Core Components Deep Dive

### 1. Broker
- User-facing app (Robinhood, Zerodha, etc.)
- Connects to exchange via **FIX protocol** (Financial Information Exchange)
  - Bidirectional, secure communication over public network
  - Unique sequence numbers per message
  - Checksums for data integrity
- Users connect to broker via REST API + WebSocket (real-time prices)

### 2. Gateway
Entry point for all broker orders. Has 3 sub-components:

**Risk Manager:**
- Checks if user has enough funds/assets
- Blocks unusual trading activity (fraud)
- Determines exchange fees

**Wallet Service:**
- Stores user funds and assets for trading
- Updates balances after trades

**Order Manager:**
- Assigns **globally increasing sequence numbers** to every order
- Guarantees: ordering fairness, fast recovery, exactly-once delivery
- Manages order states: open, cancelled, rejected, filled
- Routes cleared orders to matching engine
- Each message type (new order, cancel, trade) has its OWN topic queue with separate sequence numbers

### 3. Matching Engine
The heart of the exchange. Two sub-components:

**Order Book (In-Memory):**
- Two lists per stock: one for BUY orders, one for SELL orders
- BUY orders sorted: **highest price first** (highest bid)
- SELL orders sorted: **lowest price first** (lowest ask)
- Each price level has a **doubly-linked list** queue (FIFO):
  - Insert new order at tail: **O(1)**
  - Remove filled/cancelled order via pointer: **O(1)**
- **Index map**: order_id → pointer to order object
  - Enables O(1) cancellation (look up by ID, set amount to 0)
- Tracks highest bid and lowest ask for quick matching

**Matching Logic:**
- A trade happens when: `buy_price >= sell_price`
- Must be **deterministic**: same input → same output (always!)
- Verifies sequence numbers before matching
- Publishes trade results as market data

## Key Design Decisions

| Decision | Why |
|----------|-----|
| FIX protocol (not HTTP) | Industry standard for financial trading, built-in integrity |
| Event-sourced architecture | Deterministic replay, fast recovery, audit trail |
| In-memory order book | Ultra-low latency matching (microseconds) |
| Doubly-linked list per price level | O(1) insert and cancel |
| Hash map index (ID → pointer) | O(1) order lookup for cancellation |
| Sequence numbers per message type | Fairness, exactly-once, easy recovery |
| Separate topic queues | Independent processing, reduced contention |

## Data Structures in Order Book

```
Order Book for Stock "AAPL":

BUY Side (sorted by price DESC):
  Price $150: [Order1] → [Order4] → [Order7]  (FIFO queue)
  Price $149: [Order2] → [Order5]
  Price $148: [Order3]

SELL Side (sorted by price ASC):
  Price $151: [Order6] → [Order8]
  Price $152: [Order9]
  Price $155: [Order10]

Spread = $151 (lowest ask) - $150 (highest bid) = $1

Index Map:
  Order1 → pointer to node in $150 BUY queue
  Order6 → pointer to node in $151 SELL queue
  ... (O(1) lookup for any order)
```

## Event-Sourced Architecture

```
Every action is logged as an event:
  [OrderPlaced] → [OrderValidated] → [OrderMatched] → [TradeExecuted]

Benefits:
- Replay events to rebuild state after crash
- Complete audit trail
- Deterministic recovery
- Debug by replaying exact sequence
```

## Scaling Strategies

1. **Vertical scaling** for matching engine (single-threaded, in-memory is already fast)
2. **Shard by stock symbol**: each stock gets its own order book and matching engine
3. **Co-location**: gateway servers physically near matching engine for lowest latency
4. **Separate topic queues** per message type to reduce contention
5. **Event replay** for fast recovery instead of checkpointing
6. **Read replicas** for market data distribution

## Interview Tips

- Start with the **farmer's market analogy** -- makes it easy to explain
- Draw the 3-tier architecture: **Broker → Gateway → Matching Engine**
- Emphasize the **order book data structure** (doubly-linked list + hash map = O(1) everything)
- Mention **sequence numbers** for fairness and exactly-once guarantee
- Know the message distribution: 50% new, 40% cancel, 2% executions
- Discuss **determinism** -- same input must always produce same output
- Event sourcing enables replay and recovery
- For scaling: shard by stock symbol, not by user

## Quick Revision (5 bullet points)

1. **3-tier architecture**: Broker (user-facing) → Gateway (validation + sequencing) → Matching Engine (in-memory order book + matching logic)
2. **Order book** uses doubly-linked list per price level + hash index = **O(1) insert, O(1) cancel, O(1) lookup**
3. **Sequence numbers** on every message guarantee fairness, exactly-once processing, and deterministic replay for recovery
4. **Event-sourced architecture**: every action is an immutable event; replay to rebuild state after crash
5. **FIX protocol** for broker-to-gateway communication; matching rule is simple: trade when `buy_price >= sell_price`
