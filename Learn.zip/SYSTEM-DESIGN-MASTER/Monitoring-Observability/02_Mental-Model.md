# Monitoring and Observability — Mental Model

> **Permanent Recall:** Think of your system as a **car dashboard**: **speedometer = metrics** (real-time numbers), **engine light = alerts** (something wrong), **dashcam = logs** (what happened), **GPS trail = traces** (path taken). Measure what matters to users. **Unknown unknowns** — observability reveals what you didn't know to monitor. **RED for services**, **USE for infrastructure**.

---

## Car Dashboard Analogy

```
                    CAR DASHBOARD = OBSERVABILITY
                    
  ┌─────────────────────────────────────────────────────┐
  │  SPEEDOMETER          ENGINE LIGHT     DASHCAM       │
  │  (Metrics)            (Alerts)         (Logs)        │
  │  60 mph, RPM 2500     Check engine!    Recorded clip │
  │  Real-time numbers    Something wrong  What happened │
  └─────────────────────────────────────────────────────┘
  
  GPS TRAIL (Traces): [Home] → [Store] → [Office] — path taken
```

| Car Component | Observability Equivalent | Purpose |
|---------------|--------------------------|---------|
| **Speedometer** | Metrics | Real-time values (RPS, latency, CPU) |
| **Engine light** | Alerts | Something is wrong; take action |
| **Dashcam** | Logs | Record of events; replay what happened |
| **GPS trail** | Traces | Path of request across services |

> **FAANG Tip:** "Speedometer = metrics. Engine light = alerts. Dashcam = logs. GPS trail = traces. Easy to remember in interviews."

---

## What to Monitor — Measure What Matters to Users

```
WRONG: Monitor everything (noise, cost, alert fatigue)
RIGHT: Monitor what affects user experience

User cares about:
  ✓ Is the service up?
  ✓ Is it fast? (latency)
  ✓ Does it work? (error rate)
  ✓ Can it handle my load? (saturation)

Infrastructure cares about:
  ✓ CPU, memory, disk
  ✓ Connection pool exhaustion
  ✓ Queue depth
```

---

## Unknown Unknowns

**Key insight:** You can't alert on what you don't know exists.

| Known Knowns | Known Unknowns | Unknown Unknowns |
|--------------|----------------|------------------|
| You monitor it | You know the gap | You discover via observability |
| Dashboards, alerts | "We should add that metric" | Logs + traces reveal unexpected behavior |

**Observability** = ability to explore telemetry and answer questions you didn't anticipate. Structured logs + traces let you drill down when something breaks.

```
Incident: "API is slow"
  Without observability: Guess — maybe DB? maybe cache?
  With observability: Trace shows Auth service added 2s latency
                      → Log shows "rate limit exceeded"
                      → Root cause found
```

---

## RED vs USE — When to Use Which

| Method | For | Key Metrics |
|--------|-----|-------------|
| **RED** | Services, APIs, request-driven | Rate, Errors, Duration |
| **USE** | Infrastructure, resources | Utilization, Saturation, Errors |

```
RED (Request-driven):
  Rate     = requests per second
  Errors   = failed requests
  Duration = latency (p50, p95, p99)

USE (Resource-driven):
  Utilization = % of resource busy (CPU, disk)
  Saturation  = degree of queuing (queue depth)
  Errors      = error count
```

---

## Decision Flowchart — Monitoring Strategy

```mermaid
flowchart TD
    A[Start: Design monitoring] --> B{Request-driven service?}
    B -->|Yes| C[Apply RED: Rate, Errors, Duration]
    B -->|No| D{Resource/infrastructure?}
    D -->|Yes| E[Apply USE: Utilization, Saturation, Errors]
    D -->|No| F[Both + custom business metrics]
    C --> G[Add golden signals]
    E --> G
    F --> G
    G --> H[Choose: Logs, Metrics, Traces]
    H --> I[Define SLI/SLO]
    I --> J[Set up alerts on SLO breach]
```

```
QUICK DECISION:
  API / microservice?  → RED + golden signals
  DB / CPU / disk?    → USE
  Both?               → RED for services, USE for infra
  Always include:     → Logs (structured), health checks
```

---

## The "Measure What Matters" Mindset

```
PRIORITY ORDER:
  1. User-facing: latency, availability, error rate
  2. Business: orders/sec, revenue, conversion
  3. Infrastructure: CPU, memory, disk
  4. Debugging: logs, traces (when needed)
```

---

## 30-SECOND REVISION BOX

```
CAR DASHBOARD: speedometer=metrics, engine light=alerts,
               dashcam=logs, GPS trail=traces
MEASURE: what matters to users
UNKNOWN UNKNOWNS: observability discovers them
RED: services (Rate, Errors, Duration)
USE: infrastructure (Utilization, Saturation, Errors)
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
