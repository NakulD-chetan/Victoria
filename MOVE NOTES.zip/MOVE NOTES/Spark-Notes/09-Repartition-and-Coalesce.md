# Repartition and Coalesce

Both change the number of partitions, but they work very differently internally.

---

## repartition() — Full Shuffle Redistribution

### What It Does

`repartition()` can **increase or decrease** the number of partitions by **reshuffling all data** across executors.

### How It Works Internally

**Option 1: By number only** (Round Robin)
```python
df.repartition(8)
```
Spark distributes rows evenly across 8 partitions using **round-robin** — no key-based grouping.

**Option 2: By column** (Hash Partitioning)
```python
df.repartition(8, col("customer_id"))
```
Spark computes `hash(customer_id) % 8` to decide which partition each row goes to. Rows with the same `customer_id` land in the same partition.

### Step-by-Step Example

**Before** (4 partitions, 2 executors):
```
Executor A:
  Partition 0 → [1, 2]
  Partition 1 → [3, 4]

Executor B:
  Partition 2 → [5, 6]
  Partition 3 → [7, 8]
```

**Call**: `df.repartition(2)`

Spark hashes each row:
```
hash(1) % 2 = 1    hash(5) % 2 = 1
hash(2) % 2 = 0    hash(6) % 2 = 0
hash(3) % 2 = 1    hash(7) % 2 = 1
hash(4) % 2 = 0    hash(8) % 2 = 0
```

**Data movement** (SHUFFLE):
```
Executor A sends rows [1,3] to Executor B (new partition 1)
Executor B sends rows [6,8] to Executor A (new partition 0)
```

**After** (2 partitions):
```
Executor A → New Partition 0: [2, 4, 6, 8]
Executor B → New Partition 1: [1, 3, 5, 7]
```

Rows traveled between executors over the network — this is the **shuffle**.

### Key Properties
- **Wide transformation** — always triggers a full shuffle
- Can increase or decrease partitions
- Creates balanced partitions
- Expensive (network + disk I/O)

### When to Use
- Before joins (to align data by join key)
- To fix data skew (redistribute evenly)
- When you need more partitions for parallelism

---

## coalesce() — Lightweight Partition Merge

### What It Does

`coalesce()` can only **decrease** the number of partitions. It merges existing partitions **without shuffling data**.

### How It Works

```python
df.coalesce(2)
```

If you had 8 partitions, Spark combines them locally:
```
Before:
  Executor A: P0, P1, P2, P3
  Executor B: P4, P5, P6, P7

After coalesce(2):
  Executor A: P0' (merged P0+P1+P2+P3)  ← data stays local
  Executor B: P1' (merged P4+P5+P6+P7)  ← data stays local
```

No data moves between executors — just a logical merge.

### Key Properties
- **Narrow transformation** — no shuffle (usually)
- Can only decrease partitions (if you pass a larger number, nothing happens)
- Result may be **uneven** — one partition might be larger than others
- Very fast — no network transfer

### When to Use
- **Before writing output** — to reduce the number of small output files
- **After heavy filtering** — if filtering removed 90% of data, you have many empty partitions
- When you want to reduce partitions cheaply

### Caveat
If you aggressively reduce partitions (e.g., 200 → 1), all data ends up on one executor — that executor becomes a bottleneck.

---

## Comparison Table

| Feature              | repartition()                    | coalesce()                      |
|----------------------|----------------------------------|---------------------------------|
| Direction            | Increase or decrease             | Decrease only                   |
| Shuffle              | Yes (always)                     | No (usually)                    |
| Transformation type  | Wide                             | Narrow                          |
| Partition balance    | Balanced (even distribution)     | May be unbalanced               |
| Speed                | Slow (network shuffle)           | Fast (local merge)              |
| Partitioning scheme  | Hash or Round Robin              | Merge existing partitions       |
| Use case             | Balance data before joins/aggs   | Reduce files before write       |

---

## Common Patterns

### Before Writing (Reduce Files)
```python
df.coalesce(10).write.parquet("output/")
```

### Before Join (Align Data)
```python
df1 = df1.repartition(col("customer_id"))
df2 = df2.repartition(col("customer_id"))
result = df1.join(df2, "customer_id")
```

### After Heavy Filtering
```python
df_filtered = df.filter(col("status") == "active")  # Removes 95% of data
df_filtered = df_filtered.coalesce(20)  # Reduce from 200 empty partitions
```

---

## Key Takeaway

> `repartition()` = full data reshuffle (expensive but balanced). Use when you need to increase partitions or align data by key.
> `coalesce()` = lightweight merge (fast but possibly uneven). Use when reducing partitions before writing output.
