export default function StatsPanel({ tokens, capacity, allowed, denied, total }) {
  const pct = total > 0 ? (allowed / total) * 100 : 0;
  const successText = total > 0 ? pct.toFixed(1) + '%' : '--';
  const barColor = pct > 70 ? 'var(--accent)' : pct > 40 ? 'var(--accent-warm)' : 'var(--danger)';

  return (
    <div className="dc-stats-inline">
      <div className="dc-stat-chip">
        <span className="dc-stat-chip__value" style={{ color: 'var(--accent-secondary)' }}>{Math.floor(tokens)}/{capacity}</span>
        <span className="dc-stat-chip__label">Tokens</span>
      </div>
      <div className="dc-stat-chip">
        <span className="dc-stat-chip__value" style={{ color: 'var(--accent)' }}>{allowed}</span>
        <span className="dc-stat-chip__label">Allowed</span>
      </div>
      <div className="dc-stat-chip">
        <span className="dc-stat-chip__value" style={{ color: 'var(--danger)' }}>{denied}</span>
        <span className="dc-stat-chip__label">Denied</span>
      </div>
      <div className="dc-stat-chip">
        <span className="dc-stat-chip__value" style={{ color: 'var(--accent-warm)' }}>{successText}</span>
        <span className="dc-stat-chip__label">Success</span>
      </div>
      <div className="dc-stats-inline__bar">
        <div className="dc-stats-inline__bar-fill" style={{ width: `${total > 0 ? pct : 0}%`, background: barColor }} />
      </div>
    </div>
  );
}
