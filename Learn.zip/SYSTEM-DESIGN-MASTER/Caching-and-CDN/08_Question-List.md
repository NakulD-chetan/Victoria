# Caching and CDN — Question List

> **Permanent Recall:** Master the 10 MUST-DO caching/CDN questions for FAANG interviews. The full list covers design, implementation, trade-offs, and edge cases. Difficulty ranges from Easy (concepts) to Hard (scaling, multi-region). Use this as a checklist for interview prep—each question tests specific concepts from the Caching-and-CDN notes.

---

## 10 MUST-DO Caching/CDN Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | Design a URL shortener with caching | Medium | Cache-Aside, TTL, CDN for redirects |
| 2 | Design Twitter/X feed with caching | Medium | Multi-layer cache, invalidation on post |
| 3 | How would you implement cache for a read-heavy product catalog? | Easy | Cache-Aside, eviction, hit ratio |
| 4 | Design a distributed cache (like Redis) from scratch | Hard | Sharding, consistent hashing, replication |
| 5 | Handle cache stampede when a celebrity posts | Medium | Thundering herd, locking, early expiry |
| 6 | Design CDN caching for a global e-commerce site | Medium | Push vs pull, TTL, purge, edge locations |
| 7 | How do you keep cache and database consistent? | Medium | Write-through, invalidation, TTL |
| 8 | Design caching for a news feed (mix of static and dynamic) | Medium | CDN + Redis, multi-layer |
| 9 | What happens when cache goes down? How do you handle it? | Easy | Fallback, circuit breaker, HA |
| 10 | Design a system with 100M users, 10K QPS reads—where does cache fit? | Medium | Sizing, distributed cache, hit ratio |

---

## Complete Question List (25+)

### Design Questions

| # | Question | Difficulty | Concepts |
|---|----------|------------|----------|
| 11 | Design a caching layer for a social graph (friends, followers) | Hard | Graph caching, fan-out, invalidation |
| 12 | Design cache for real-time leaderboard | Medium | Redis sorted sets, TTL, updates |
| 13 | Design caching for search results (expensive to compute) | Medium | Cache computed results, TTL, invalidation |
| 14 | Design multi-region caching with consistency | Hard | Cross-region invalidation, eventual consistency |
| 15 | Design cache for session storage (stateless app servers) | Easy | Redis, TTL, logout invalidation |
| 16 | Design CDN for video streaming (VOD vs live) | Medium | CDN, edge caching, live vs static |
| 17 | Design cache for rate limiting | Easy | Redis INCR, TTL, sliding window |
| 18 | Design caching for API gateway (response cache) | Medium | Cache by request fingerprint, TTL, headers |
| 19 | Design cache for autocomplete / typeahead | Medium | Trie/cache combo, prefix caching |
| 20 | Design cache warming strategy for deployment | Medium | Hot keys, startup, gradual traffic |

### Implementation / Trade-off Questions

| # | Question | Difficulty | Concepts |
|---|----------|------------|----------|
| 21 | Redis vs Memcached—when to use which? | Easy | Data structures, persistence, use case |
| 22 | LRU vs LFU—which eviction policy for trending content? | Easy | Eviction, popularity |
| 23 | Cache-Aside vs Write-Through—trade-offs? | Easy | Consistency, latency |
| 24 | How does consistent hashing work for cache sharding? | Medium | Sharding, rehashing |
| 25 | How do you prevent cache penetration (non-existent keys)? | Medium | Negative caching, Bloom filter |
| 26 | How do you prevent cache avalanche? | Easy | TTL jitter |
| 27 | What is cache stampede and how do you fix it? | Medium | Locking, early expiry |
| 28 | How do you handle hot key in distributed cache? | Medium | L1 cache, replication |
| 29 | Push vs Pull CDN—when to use which? | Easy | CDN types |
| 30 | How do you invalidate CDN cache? | Easy | Purge, versioning |

### Scenario / Edge Case Questions

| # | Question | Difficulty | Concepts |
|---|----------|------------|----------|
| 31 | User updates profile—cache shows old data. Debug. | Easy | Invalidation, TTL |
| 32 | After deploy, latency spikes for 5 minutes. Why? | Easy | Cold cache |
| 33 | One Redis node at 100% CPU, others idle. Why? | Medium | Hot key |
| 34 | CDN serves old content after update. How to fix? | Easy | Purge, cache key |
| 35 | Cache hit ratio dropped from 80% to 20%. Investigate. | Medium | Evictions, working set, sizing |
| 36 | Multi-region: user in EU sees different data than US. | Hard | Cross-region consistency |
| 37 | Cache stores 1MB per key—memory fills fast. Fix? | Easy | Value size, compression |
| 38 | Deserialization errors after deploy. Root cause? | Medium | Schema, versioning |

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, single component, straightforward |
| **Medium** | Multiple components, trade-offs, implementation detail |
| **Hard** | Scale, multi-region, distributed systems, edge cases |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **Cache-Aside** | 1, 3, 7, 21, 23 |
| **Write-Through** | 7, 23 |
| **Eviction (LRU, LFU, TTL)** | 3, 22, 25 |
| **Cache Stampede** | 5, 27 |
| **Cache Penetration** | 25 |
| **Cache Avalanche** | 26 |
| **Hot Key** | 8, 28, 33 |
| **CDN** | 6, 16, 29, 30, 34 |
| **Consistent Hashing** | 4, 24 |
| **Multi-region** | 14, 36 |
| **Invalidation** | 2, 7, 11, 31 |
| **Fallback / HA** | 9 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can draw cache architecture for read-heavy system
- [ ] Can explain Cache-Aside, Write-Through, Write-Behind
- [ ] Can explain stampede, penetration, avalanche
- [ ] Can explain Redis vs Memcached
- [ ] Can explain CDN push vs pull
- [ ] Can explain "cache goes down" handling
- [ ] Can size cache (working set, 80/20)
- [ ] Can explain consistent hashing
- [ ] Can discuss multi-region cache consistency

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: Shortener, Feed, Catalog, Redis-like, Stampede,
            CDN e-commerce, Consistency, News feed, Cache down, 100M users
FULL LIST: 30+ questions across design, implementation, scenarios
CONCEPTS: Cache-Aside, eviction, stampede, penetration, CDN, hashing
```

---

**Prev: [[07_Tricks-and-Recognition]]**
