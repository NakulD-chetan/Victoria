# Pronunciation Tips

> *"Grammar galat hai toh log samajh lete hain. Pronunciation galat hai toh sunai hi nahi deta."*

Pronunciation English speaking ka woh part hai jisko zyaadatar log ignore karte hain. Lekin yeh sabse zyada impact karta hai — clear pronunciation = confident speaker. Yeh chapter Hindi speakers ke liye specifically likha hai.

---

## 1. Sounds Jo Hindi Speakers Ke Liye Mushkil Hain

### V vs W

| Letter | Correct Sound | Hindi Speaker Ka Sound | Words |
|--------|-------------|----------------------|-------|
| **V** | Neeche ke honth upar ke daanton pe lagao | W bol dete hain | very, voice, video, vet |
| **W** | Dono honth gol karke bolo | V bol dete hain | water, world, work, well |

**Practice:**
- **V**ery **w**ell done. (V aur W dono alag hain!)
- **V**an vs **W**an — V mein teeth pe lip, W mein lips round
- **V**ine vs **W**ine — sharaab wine hai, bel vine hai

### TH Sound (Voiced & Voiceless)

| Type | Kaise Bolo | Words |
|------|-----------|-------|
| **Voiceless TH** (θ) | Jeebh daanton ke beech rakho, hawa bahar nikalo | **th**ink, **th**ank, **th**ree, **th**ursday, ba**th** |
| **Voiced TH** (ð) | Jeebh daanton ke beech rakho + vibrate karo | **th**is, **th**at, **th**e, **th**ere, bro**th**er |

[COMMON MISTAKE] Hindi mein TH sound nahi hai → "think" ko "tink" ya "sink" bol dete hain. Jeebh daanton ke beech daalo!

### R vs L

| Letter | Kaise Bolo | Example |
|--------|-----------|---------|
| **R** | Jeebh ko peeche curl karo, kahi nahi lagao | **r**ight, **r**ead, **r**un |
| **L** | Jeebh ke tip ko upar taalu pe lagao | **l**ight, **l**ead, **l**unch |

**Confusing Pairs:**
- **r**ight vs **l**ight
- **r**ace vs **l**ace
- **r**ead vs **l**ead
- g**r**ow vs g**l**ow

### Z vs J

| Sound | Hindi Equivalent | Words |
|-------|-----------------|-------|
| **Z** | "ज़" ki tarah (vibrating) | zoo, zero, zone, buzzing |
| **J** | "ज" ki tarah | juice, jump, join, jelly |

---

## 2. Silent Letters — Jo Likhte Hain Lekin Bolte Nahi

| Silent Letter | Words | Pronunciation |
|--------------|-------|---------------|
| **K** (before n) | **k**nife, **k**now, **k**nee, **k**nock, **k**night | naif, noh, nee, nok, nait |
| **W** (before r) | **w**rite, **w**rong, **w**rist, **w**rap | rait, rong, rist, rap |
| **B** (after m) | com**b**, lam**b**, thum**b**, clim**b**, bom**b** | kohm, lam, thum, klaim, bom |
| **G** (before n) | **g**nat, si**g**n, desi**g**n, forei**g**n | nat, sain, dizain, forin |
| **H** | **h**our, **h**onest, **h**onor, g**h**ost | aur, onist, onor, gohst |
| **P** | **p**sychology, **p**neumonia, recei**p**t | saikology, noomonia, riseet |
| **T** | lis**t**en, fas**t**en, cas**t**le, whis**t**le | lisen, faasen, kaasel, wisel |
| **L** | wa**l**k, ta**l**k, ha**l**f, ca**l**m, sa**l**mon | waak, taak, haaf, kaam, samon |

---

## 3. Word Stress — Kaun Sa Part Zor Se Bolna Hai

> English mein har word ka ek syllable **zyada zor** se bola jaata hai. Galat stress = galat word lag sakta hai.

### Basic Rules

| Rule | Example |
|------|---------|
| 2-syllable **nouns** — stress first syllable pe | **TA**ble, **WA**ter, **DOC**tor, **TEA**cher |
| 2-syllable **verbs** — stress second syllable pe | be**GIN**, de**CIDE**, for**GET**, re**PEAT** |
| **-tion / -sion** words — stress tion/sion se pehle wale syllable pe | edu**CA**tion, infor**MA**tion, deci**SION** |
| **-ic** words — stress -ic se pehle wale syllable pe | fan**TAS**tic, dra**MA**tic, rea**LIS**tic |
| **-ity** words — stress -ity se pehle wale syllable pe | uni**VER**sity, elec**TRI**city |

### Same Spelling, Different Stress = Different Meaning

| Word | As Noun (Stress 1st) | As Verb (Stress 2nd) |
|------|----------------------|---------------------|
| **record** | **RE**cord (ek record) | re**CORD** (record karna) |
| **present** | **PRE**sent (tohfa/gift) | pre**SENT** (pesh karna) |
| **project** | **PRO**ject (project) | pro**JECT** (aage rakhna) |
| **object** | **OB**ject (cheez) | ob**JECT** (aitraz karna) |
| **produce** | **PRO**duce (sabziyaan) | pro**DUCE** (banana) |
| **desert** | **DE**sert (registaan) | de**SERT** (chhor dena) |
| **conduct** | **CON**duct (vyavhar) | con**DUCT** (chalana) |

---

## 4. Sentence Stress — Poore Sentence Mein Kya Zor Se Bolein

> English mein **content words** pe stress hota hai, **function words** pe nahi.

| Stress Hota Hai (Content Words) | Stress Nahi Hota (Function Words) |
|-------------------------------|----------------------------------|
| Nouns (book, car, house) | Articles (a, an, the) |
| Main verbs (eat, run, work) | Prepositions (in, on, at) |
| Adjectives (big, fast, good) | Pronouns (he, she, it) |
| Adverbs (quickly, very, well) | Auxiliary verbs (is, am, have) |
| Question words (what, where) | Conjunctions (and, but, or) |

**Example:**
- "I **WENT** to the **STORE** and **BOUGHT** some **BREAD**."
- Stressed: WENT, STORE, BOUGHT, BREAD
- Unstressed: I, to, the, and, some

[TIP] English ek **stress-timed** language hai — stressed syllables ke beech equal time aata hai, chahe beech mein kitne bhi unstressed syllables ho. Hindi **syllable-timed** hai — har syllable barabar time leta hai. Isliye Hindi accent "flat" lagta hai.

---

## 5. Intonation — Awaaz Upar-Neeche Kaise Ho

| Sentence Type | Intonation | Example |
|--------------|-----------|---------|
| **Statements** | Neeche jaati hai (falling) ↘ | I like coffee. ↘ |
| **Yes/No questions** | Upar jaati hai (rising) ↗ | Do you like coffee? ↗ |
| **Wh-questions** | Neeche jaati hai (falling) ↘ | Where do you live? ↘ |
| **Lists** | Rising, rising, falling | I like tea ↗, coffee ↗, and juice ↘. |
| **Surprise** | Sharp rise ↗↗ | Really?! ↗↗ |

---

## 6. Connected Speech — Native Speakers Aise Bolte Hain

> Native speakers words ko alag-alag nahi bolte — jodke bolte hain. Isko samjho toh listening bhi improve hogi.

| Written Form | Spoken Form | Note |
|-------------|-------------|------|
| going to | **gonna** | I'm gonna go. |
| want to | **wanna** | I wanna eat. |
| got to | **gotta** | I gotta leave. |
| kind of | **kinda** | It's kinda cold. |
| sort of | **sorta** | I'm sorta busy. |
| let me | **lemme** | Lemme think. |
| give me | **gimme** | Gimme a second. |
| don't know | **dunno** | I dunno. |
| what are you | **whatcha** | Whatcha doing? |
| would have | **would've** | I would've helped. |

[TIP] Yeh forms samjho listening ke liye, lekin formal speech mein full forms use karo. Casual mein connected speech natural lagta hai.

---

## 7. Commonly Mispronounced Words by Indians

| Word | Wrong Pronunciation | Correct Pronunciation | IPA |
|------|-------------------|---------------------|-----|
| comfortable | com-FOR-table | **KUMF**-ter-bul | /ˈkʌmf.tə.bəl/ |
| vegetable | veg-TABLE | **VEJ**-tuh-bul | /ˈvedʒ.tə.bəl/ |
| Wednesday | wed-NES-day | **WENZ**-day | /ˈwenz.deɪ/ |
| February | feb-ROO-ary | **FEB**-roo-erry | /ˈfeb.ru.er.i/ |
| schedule | SKED-ule | **SHED**-yool (British) / **SKED**-jool (American) | varies |
| pizza | piz-ZA | **PEET**-suh | /ˈpiːt.sə/ |
| suite | SOOT | **sweet** | /swiːt/ |
| receipt | re-SEET | ri-**SEET** (p silent) | /rɪˈsiːt/ |
| entrepreneur | enter-PRE-noor | on-truh-pruh-**NUR** | /ˌɒn.trə.prəˈnɜːr/ |
| colonel | ko-LO-nel | **KUR**-nel | /ˈkɜː.nəl/ |
| genre | JEN-ree | **ZHON**-ruh | /ˈʒɒn.rə/ |
| chaos | CHA-os | **KAY**-os | /ˈkeɪ.ɒs/ |
| subtle | SUB-tle | **SUT**-ul (b silent) | /ˈsʌt.əl/ |
| pronunciation | pro-NOUN-ciation | pro-NUN-ciation | /prəˌnʌn.siˈeɪ.ʃən/ |

[COMMON MISTAKE] "Pronunciation" mein "NOUN" nahi hai — "NUN" hai! Yeh sabse common mistake hai.

---

## 8. Daily Pronunciation Practice Routine (5 min)

| Minute | Activity |
|--------|----------|
| 1 | **Tongue twisters** — "She sells seashells by the seashore." Slowly, phir fast |
| 2 | **V/W practice** — "Very well, William went walking." 5 baar |
| 3 | **TH practice** — "This thing is thick and thin." Jeebh daanton ke beech |
| 4 | **Shadow** — 30 seconds kisi English speaker ko copy karo |
| 5 | **Record** — Ek sentence bolo, suno, improve karo |

### Famous Tongue Twisters:

| Tongue Twister | Focus Sound |
|---------------|-------------|
| She sells seashells by the seashore. | SH vs S |
| Red lorry, yellow lorry. | R vs L |
| Peter Piper picked a peck of pickled peppers. | P sound |
| How much wood would a woodchuck chuck? | W + CH |
| The thirty-three thieves thought they thrilled the throne. | TH sound |
| Fuzzy Wuzzy was a bear. Fuzzy Wuzzy had no hair. | Z + W |

---

*Agle chapter mein: Common Mistakes Hindi Speakers Make — galtiyan aur unke fix*
