import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(N) {
  const dp = Array(N + 1).fill(null);
  dp[0] = 1;
  const steps = [];
  const colLabels = Array.from({ length: N + 1 }, (_, i) => i);

  const snap = (caption, arr, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [arr],
      rowLabels: ['C'],
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('Catalan recurrence: C[0]=1', [...dp], { '0-0': 'filled' }, [0, 0], []);

  for (let n = 1; n <= N; n += 1) {
    let sum = 0;
    const arrows = [];
    for (let i = 0; i < n; i += 1) {
      const prod = dp[i] * dp[n - 1 - i];
      sum += prod;
      const colors = {
        [`0-${n}`]: 'current',
        [`0-${i}`]: 'filled',
        [`0-${n - 1 - i}`]: 'filling',
      };
      arrows.push({ from: [0, i], to: [0, n] });
      arrows.push({ from: [0, n - 1 - i], to: [0, n] });
      snap(`Add term C[${i}]·C[${n - 1 - i}] = ${dp[i]}·${dp[n - 1 - i]}`, [...dp], colors, [0, n], arrows);
    }
    dp[n] = sum;
    snap(`C[${n}] = ${sum}`, { [`0-${n}`]: 'optimal' }, [0, n], []);
  }

  snap('Catalan numbers ready', [...dp], Object.fromEntries([...Array(N + 1)].map((_, i) => [`0-${i}`, 'optimal'])), null, []);
  return steps;
}

export default function CatalanNumberVisualizer({ config }) {
  const N = 6;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(N);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Catalan convolution DP' });
    canvasRef.current?.setState({ table: [[null]], rowLabels: [], colLabels: [], cellColors: {}, arrows: [], highlight: null, caption: 'Catalan numbers' });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[null]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
