import { COMPONENT_TYPES, CONNECTION_RULES } from '../../lib/problems/component-types';
import { usePlaygroundStore } from '../../stores/playground-store';

function Slider({ label, dataKey, value, min, max, unit, compId }) {
  const updateConfig = usePlaygroundStore((s) => s.updateComponentConfig);
  return (
    <div className="dc-prop-slider">
      <span className="dc-prop-slider__label">{label}</span>
      <input type="range" min={min} max={max} value={value} onChange={(e) => updateConfig(compId, dataKey, +e.target.value)} className="dc-prop-slider__input" />
      <span className="dc-prop-slider__val">{value}{unit}</span>
    </div>
  );
}

function Select({ label, dataKey, value, options, compId }) {
  const updateConfig = usePlaygroundStore((s) => s.updateComponentConfig);
  return (
    <div className="dc-prop-slider">
      <span className="dc-prop-slider__label">{label}</span>
      <select value={value} onChange={(e) => updateConfig(compId, dataKey, e.target.value)} className="dc-prop-select__input">
        {options.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
      </select>
    </div>
  );
}

function Group({ label }) {
  return <div className="dc-prop-group">{label}</div>;
}

export default function PropertyEditor({ comp }) {
  const t = COMPONENT_TYPES[comp.type];
  const c = comp.config;
  const allowed = CONNECTION_RULES[comp.type] || [];
  const allowedNames = allowed.map((k) => `${COMPONENT_TYPES[k]?.icon}${COMPONENT_TYPES[k]?.name}`).join(', ');

  return (
    <div>
      <div className="dc-prop-header" style={{ color: t.color }}>{t.icon} {t.name}</div>
      <div className="dc-section-label" style={{ fontSize: 8 }}>Connects to</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 8, color: 'var(--text-secondary)', marginBottom: 4, lineHeight: 1.4 }}>
        {allowedNames || <em>Endpoint — no outgoing</em>}
      </div>

      {comp.type === 'client' && (<>
        <Group label="Traffic" />
        <Slider label="Req/sec" dataKey="rps" value={c.rps} min={1} max={100} unit="" compId={comp.id} />
        <Slider label="Concurrency" dataKey="concurrent" value={c.concurrent} min={1} max={50} unit="" compId={comp.id} />
        <Group label="Reliability" />
        <Slider label="Timeout" dataKey="timeout" value={c.timeout} min={100} max={10000} unit="ms" compId={comp.id} />
        <Slider label="Retries" dataKey="retries" value={c.retries} min={0} max={5} unit="" compId={comp.id} />
      </>)}

      {comp.type === 'cdn' && (<>
        <Group label="Cache" />
        <Slider label="Hit Rate" dataKey="hitRate" value={c.hitRate} min={50} max={99} unit="%" compId={comp.id} />
        <Slider label="TTL" dataKey="ttl" value={c.ttl} min={10} max={3600} unit="s" compId={comp.id} />
        <Group label="Latency" />
        <Slider label="Edge" dataKey="edgeLat" value={c.edgeLat} min={1} max={50} unit="ms" compId={comp.id} />
        <Slider label="Origin" dataKey="originLat" value={c.originLat} min={50} max={500} unit="ms" compId={comp.id} />
        <Group label="Scale" />
        <Slider label="Regions" dataKey="regions" value={c.regions} min={1} max={10} unit="" compId={comp.id} />
      </>)}

      {comp.type === 'apigateway' && (<>
        <Group label="Auth" />
        <Slider label="Auth Latency" dataKey="authLat" value={c.authLat} min={1} max={100} unit="ms" compId={comp.id} />
        <Group label="Rate Limiting" />
        <Slider label="Limit" dataKey="rateLimit" value={c.rateLimit} min={10} max={2000} unit="/s" compId={comp.id} />
        <Group label="Circuit Breaker" />
        <Select label="Enabled" dataKey="circuitBreaker" value={c.circuitBreaker} options={[['on','On'],['off','Off']]} compId={comp.id} />
        <Slider label="Fail Threshold" dataKey="cbThreshold" value={c.cbThreshold} min={2} max={20} unit="" compId={comp.id} />
        <Slider label="Timeout" dataKey="timeout" value={c.timeout} min={100} max={10000} unit="ms" compId={comp.id} />
      </>)}

      {comp.type === 'ratelimiter' && (<>
        <Group label="Algorithm" />
        <Select label="Type" dataKey="algorithm" value={c.algorithm} options={[['token_bucket','Token Bucket'],['sliding_window','Sliding Window'],['fixed_window','Fixed Window']]} compId={comp.id} />
        <Group label="Limits" />
        <Slider label="Max Req/s" dataKey="maxRps" value={c.maxRps} min={1} max={1000} unit="" compId={comp.id} />
        <Slider label="Burst Size" dataKey="burstSize" value={c.burstSize} min={1} max={200} unit="" compId={comp.id} />
        <Slider label="Penalty" dataKey="penaltyMs" value={c.penaltyMs} min={0} max={5000} unit="ms" compId={comp.id} />
      </>)}

      {comp.type === 'loadbalancer' && (<>
        <Group label="Routing" />
        <Select label="Algorithm" dataKey="algorithm" value={c.algorithm} options={[['rr','Round Robin'],['random','Random'],['least_conn','Least Conn'],['ip_hash','IP Hash']]} compId={comp.id} />
        <Group label="Limits" />
        <Slider label="Max Conn" dataKey="maxConn" value={c.maxConn} min={10} max={2000} unit="" compId={comp.id} />
        <Group label="Health" />
        <Select label="Health Check" dataKey="healthCheck" value={c.healthCheck} options={[['on','On'],['off','Off']]} compId={comp.id} />
        <Select label="Sticky" dataKey="sticky" value={c.sticky} options={[['off','Off'],['on','On']]} compId={comp.id} />
      </>)}

      {comp.type === 'server' && (<>
        <Group label="Performance" />
        <Slider label="Latency" dataKey="latency" value={c.latency} min={5} max={500} unit="ms" compId={comp.id} />
        <Slider label="Max Concurrent" dataKey="maxConcurrent" value={c.maxConcurrent} min={1} max={200} unit="" compId={comp.id} />
        <Slider label="Instances" dataKey="instances" value={c.instances} min={1} max={10} unit="" compId={comp.id} />
        <Group label="Reliability" />
        <Slider label="Failure Rate" dataKey="failRate" value={c.failRate} min={0} max={50} unit="%" compId={comp.id} />
      </>)}

      {comp.type === 'service' && (<>
        <Group label="Performance" />
        <Slider label="Latency" dataKey="latency" value={c.latency} min={5} max={500} unit="ms" compId={comp.id} />
        <Slider label="Max Concurrent" dataKey="maxConcurrent" value={c.maxConcurrent} min={1} max={100} unit="" compId={comp.id} />
        <Group label="Reliability" />
        <Slider label="Failure Rate" dataKey="failRate" value={c.failRate} min={0} max={50} unit="%" compId={comp.id} />
        <Slider label="Retries" dataKey="retries" value={c.retries} min={0} max={5} unit="" compId={comp.id} />
        <Group label="Circuit Breaker" />
        <Select label="Enabled" dataKey="circuitBreaker" value={c.circuitBreaker} options={[['on','On'],['off','Off']]} compId={comp.id} />
        <Slider label="Fail Threshold" dataKey="cbThreshold" value={c.cbThreshold} min={2} max={20} unit="" compId={comp.id} />
        <Slider label="Recovery" dataKey="cbRecoveryMs" value={c.cbRecoveryMs} min={1000} max={30000} unit="ms" compId={comp.id} />
      </>)}

      {comp.type === 'cache' && (<>
        <Group label="Cache Behavior" />
        <Slider label="Hit Rate" dataKey="hitRate" value={c.hitRate} min={0} max={100} unit="%" compId={comp.id} />
        <Slider label="Miss Latency" dataKey="missLat" value={c.missLat} min={5} max={500} unit="ms" compId={comp.id} />
        <Slider label="TTL" dataKey="ttl" value={c.ttl} min={1} max={600} unit="s" compId={comp.id} />
        <Slider label="Max Entries" dataKey="maxSize" value={c.maxSize} min={100} max={100000} unit="" compId={comp.id} />
        <Group label="Policy" />
        <Select label="Eviction" dataKey="eviction" value={c.eviction} options={[['lru','LRU'],['lfu','LFU'],['fifo','FIFO'],['random','Random']]} compId={comp.id} />
        <Select label="Write Policy" dataKey="writePolicy" value={c.writePolicy} options={[['write_through','Write-Through'],['write_back','Write-Back'],['write_around','Write-Around']]} compId={comp.id} />
      </>)}

      {comp.type === 'database' && (<>
        <Group label="Engine" />
        <Select label="Type" dataKey="dbType" value={c.dbType} options={[['sql','SQL (PostgreSQL)'],['nosql','NoSQL (MongoDB)'],['graph','Graph (Neo4j)']]} compId={comp.id} />
        <Select label="Sharding" dataKey="sharding" value={c.sharding} options={[['none','None'],['hash','Hash-Based'],['range','Range-Based']]} compId={comp.id} />
        <Group label="Performance" />
        <Slider label="Query Time" dataKey="queryTime" value={c.queryTime} min={5} max={500} unit="ms" compId={comp.id} />
        <Slider label="Pool Size" dataKey="poolSize" value={c.poolSize} min={5} max={200} unit="" compId={comp.id} />
        <Slider label="Repl. Lag" dataKey="replLag" value={c.replLag} min={0} max={500} unit="ms" compId={comp.id} />
      </>)}

      {comp.type === 'queue' && (<>
        <Group label="Processing" />
        <Slider label="Process Time" dataKey="processTime" value={c.processTime} min={10} max={5000} unit="ms" compId={comp.id} />
        <Slider label="Consumers" dataKey="consumers" value={c.consumers} min={1} max={20} unit="" compId={comp.id} />
        <Slider label="Batch Size" dataKey="batchSize" value={c.batchSize} min={1} max={100} unit="" compId={comp.id} />
        <Group label="Capacity" />
        <Slider label="Queue Size" dataKey="capacity" value={c.capacity} min={10} max={10000} unit="" compId={comp.id} />
        <Group label="Delivery" />
        <Select label="Guarantee" dataKey="delivery" value={c.delivery} options={[['at_most_once','At-Most-Once'],['at_least_once','At-Least-Once'],['exactly_once','Exactly-Once']]} compId={comp.id} />
        <Select label="Dead Letter Q" dataKey="dlq" value={c.dlq} options={[['on','On'],['off','Off']]} compId={comp.id} />
      </>)}
    </div>
  );
}
