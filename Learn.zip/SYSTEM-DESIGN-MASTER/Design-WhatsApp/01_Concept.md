# Design WhatsApp — Concept

> **Permanent Recall:** WhatsApp is a real-time messaging system. Core flows: **1:1 chat**, **group chat** (up to 256), **sent/delivered/read receipts**, **online/offline status**, **media sharing**, **end-to-end encryption**. Key challenges: real-time delivery (<100ms), message ordering, at-least-once delivery, 2B+ users, 100B messages/day. Must consider: connection management at scale, offline handling, presence, push notifications.

---

## Problem Statement

Design a messaging system like **WhatsApp** that:
- Enables real-time 1:1 and group messaging
- Delivers messages with sent, delivered, and read receipts
- Shows online/offline status for contacts
- Supports media (images, video, documents)
- Provides end-to-end encryption for privacy

---

## Functional Requirements

| Requirement | Description |
|-------------|-------------|
| **1:1 Messaging** | Send text and media to a single recipient; real-time delivery when online |
| **Group Chat** | Create groups with up to 256 members; send messages to all; see who is in the group |
| **Sent/Delivered/Read Receipts** | Sender sees checkmarks: sent (1 tick), delivered (2 ticks), read (blue) |
| **Online/Offline Status** | Show when a contact was last seen; green dot when online |
| **Media Sharing** | Images, videos, documents, voice notes; upload and download |
| **End-to-End Encryption** | Only sender and recipient can read messages; server cannot decrypt |

---

## Non-Functional Requirements

| Requirement | Target | Rationale |
|-------------|--------|-----------|
| **Real-time delivery** | <100ms p99 when recipient online | User perceives instant delivery |
| **Message ordering** | Per-conversation FIFO | Messages must appear in correct order |
| **Delivery guarantee** | At-least-once | No message loss; idempotency handles duplicates |
| **Scale: Users** | 2B+ DAU | Global messaging platform |
| **Scale: Messages** | 100B messages/day | ~1.15M messages/second peak |
| **High availability** | 99.99% uptime | Messaging is mission-critical |

> **FAANG Tip:** Always state scale numbers. "Millions of users" is vague; "2B DAU, 100B messages/day" shows you understand production scale.

---

## Capacity Estimation

**Assumptions:**
- 2B daily active users
- 50 messages per user per day on average
- Peak traffic 3× average (business hours, timezones)
- Average text message ~100 bytes; media messages 10× larger

**QPS:**

| Operation | Daily | QPS (avg) | QPS (peak, 3×) |
|-----------|-------|-----------|----------------|
| **Messages** | 100B | ~1.15M/s | ~3.5M/s |
| **Media uploads** | ~5B (assume 5% media) | ~58K/s | ~175K/s |

**Storage (messages):**
- 100B messages/day × 100 bytes ≈ 10 TB/day text
- With media (images, video): 50–100 TB/day depending on compression
- 5 years retention: petabytes scale

**Connection Management:**
- 2B users; assume 50% connected during peak → 1B concurrent WebSocket connections
- Need connection managers (load balancers, connection pools) at massive scale
- Each server ~50K connections → 20,000+ connection servers

**Bandwidth:**
- 100B messages × 100B ≈ 10 TB/day text; with headers/metadata ~20 TB/day
- Media uploads: 5B × 1MB avg ≈ 5 PB/day; CDN egress for downloads

---

## Key Constraints

| Constraint | Implication |
|------------|-------------|
| **Real-time** | WebSocket mandatory; no polling |
| **Ordering** | Per-conversation sequence; single partition or logical ordering |
| **Offline** | Store always; push + deliver on reconnect |
| **Scale** | Shard by conversation; connection servers; queue fan-out |

---

## Traffic Patterns

| Pattern | Characteristic |
|---------|----------------|
| **1:1 messages** | Bursty; rapid back-and-forth when both online |
| **Group messages** | Fan-out: 1 message → up to 255 deliveries |
| **Presence** | Heartbeat every 30–60s per connected user |
| **Media** | Async upload; URL passed in message; download on demand |

```mermaid
flowchart LR
    A[User sends message] --> B[Chat Service]
    B --> C{Recipient online?}
    C -->|Yes| D[Push via WebSocket]
    C -->|No| E[Store + Push notification]
    D --> F[Delivered receipt]
    E --> F
```

---

## 30-SECOND REVISION BOX

**Out of Scope (for base design):** Voice/video calling, stories, message backup UI, bots. Can be added as extensions.

**Success metrics:** Message delivery latency p99, delivery rate (%), read receipt accuracy, presence freshness, media upload success rate.

**Key dependencies:** FCM/APNs for push, S3/CDN for media, Redis for presence, Kafka for message fan-out.

**Design scope:** Focus on messaging core first; media and E2E are layered on top.

**Comparison:** Similar to Telegram, Signal; differs in E2E default, group size limits, media handling.

**Interview tip:** Lead with scale numbers (2B users, 100B msg/day) to show production thinking.

---

```
PROBLEM: Real-time messaging (1:1, group), receipts, presence, media, E2E
FUNCTIONAL: Messaging, receipts, status, media, encryption
NFRs: <100ms delivery, message order, at-least-once, 2B users, 100B msg/day
QPS: ~1.15M msg/s avg, ~3.5M peak
STORAGE: 10TB/day text, 50–100TB with media; PB-scale retention
CONNECTIONS: 1B concurrent WebSockets at peak
KEY DEPS: FCM/APNs, S3/CDN, Redis, Kafka
```

---

**Next: [[02_Mental-Model]]**

