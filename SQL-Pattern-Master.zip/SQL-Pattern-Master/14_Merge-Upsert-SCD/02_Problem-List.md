# Merge / Upsert / SCD — Problem List

> **15 problems in progressive difficulty. 8 MUST-DO highlighted. Covers MERGE statement, upsert patterns, SCD Type 1/2/3, and ETL load patterns. Sources: LeetCode, HackerRank, DataLemur, StrataScratch, Real-world scenarios.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Delete Duplicate Emails | LC 196 | Easy | Upsert precursor | Understand modify-in-place |
| 2 | Swap Salary | LC 627 | Easy | Conditional UPDATE | Foundation for MERGE UPDATE |
| 3 | Basic Upsert | Common | Medium | INSERT ON CONFLICT | Core upsert pattern |
| 4 | Sync Two Tables | Common | Medium | Full MERGE | INSERT + UPDATE + DELETE |
| 5 | SCD Type 1 Load | Common | Medium | Overwrite update | Simple dimension load |
| 6 | SCD Type 2 Load | Common | Hard | Historical tracking | Close old + insert new row |
| 7 | Incremental ETL Load | Common | Medium | MERGE from staging | Production ETL pattern |
| 8 | Product Price at Given Date | LC 1164 | Medium | SCD Type 2 query | Query point-in-time from history |

---

## Complete 15-Problem Progression

### Easy (Problems 1-4) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Delete Duplicate Emails | LC 196 | DELETE | Modify table in-place |
| 2 | Swap Salary | LC 627 | UPDATE CASE | Conditional update |
| 3 | Update Column Based on Condition | Common | UPDATE WHERE | Basic row modification |
| 4 | Insert If Not Exists | Common | INSERT ... WHERE NOT EXISTS | Manual upsert logic |

### Medium (Problems 5-11) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 5 | Basic Upsert | Common | ON CONFLICT DO UPDATE | PostgreSQL upsert |
| 6 | Sync Employees Table | Common | Full MERGE | All three WHEN clauses |
| 7 | SCD Type 1 Load | Common | MERGE + overwrite | Dimension update without history |
| 8 | Incremental ETL Load | Common | MERGE from staging | Dedup staging → merge to target |
| 9 | Product Price at Given Date | LC 1164 | SCD query | Latest price before date |
| 10 | Track Config Changes | Common | INSERT + history | Append to history table |
| 11 | Conditional Upsert | Common | MERGE + filter | Update only if value changed |

### Hard (Problems 12-15) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 12 | SCD Type 2 Load | Common | Close + insert | Full historical dimension load |
| 13 | Point-in-Time Query on SCD2 | Common | WHERE date BETWEEN | Query history at specific date |
| 14 | Multi-Source MERGE | Advanced | Union sources + MERGE | Multiple staging → single target |
| 15 | Idempotent Pipeline | Advanced | MERGE + checksum | Rerunnable load (exactly-once) |

---

## Problem-by-Problem Strategy Notes

### Problem 5: Basic Upsert

```
Pattern:     INSERT ON CONFLICT DO UPDATE
Approach:    INSERT INTO table (id, name, value) VALUES (...)
             ON CONFLICT (id) DO UPDATE SET name = EXCLUDED.name, value = EXCLUDED.value
Key Insight: EXCLUDED refers to the row that would have been inserted
One-liner:   Insert new row; if conflict on PK, update existing with new values.
```

### Problem 6: Sync Employees Table (Full MERGE)

```
Pattern:     Full MERGE with all three clauses
Approach:    MERGE INTO target USING source ON id match
             MATCHED → UPDATE
             NOT MATCHED → INSERT
             NOT MATCHED BY SOURCE → DELETE
Key Insight: Three-way sync: update existing, insert new, delete stale
One-liner:   Full MERGE: update matches, insert new, delete removed from source.
```

### Problem 9: Product Price at Given Date (LC 1164)

```
Pattern:     Query SCD Type 2 history
Approach:    ROW_NUMBER() OVER (PARTITION BY product_id ORDER BY change_date DESC)
             WHERE change_date <= target_date AND rn = 1
             UNION ALL: products with no changes → default price
Key Insight: Latest change_date before target = point-in-time value
One-liner:   Rank changes desc before date; rn=1 = current price at that time.
```

### Problem 12: SCD Type 2 Load

```
Pattern:     Close current + insert new + insert brand-new
Approach:    1) Identify changed rows: staging JOIN dim WHERE values differ
             2) UPDATE dim SET end_date = today-1, is_current = FALSE for changed
             3) INSERT new current rows with effective_date = today
             4) INSERT entirely new entities
Key Insight: Must close BEFORE inserting — otherwise two current rows
One-liner:   Close changed currents, insert updated rows, insert new entities.
```

---

## Pattern Distribution

```
BASIC UPSERT (INSERT ON CONFLICT):     4 problems  (3-5, 11)
FULL MERGE (3-way sync):               3 problems  (6, 8, 14)
SCD TYPE 1 (overwrite):                2 problems  (7, 10)
SCD TYPE 2 (historical):               4 problems  (9, 12-13, 15)
CONDITIONAL UPDATE:                    2 problems  (1, 2)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 196, LC 627 (delete, swap — understand DML)
- Day 2: Insert-if-not-exists, basic upsert
- Day 3: Full MERGE (sync two tables)

### Week 2: SCD Patterns (Days 4-6)
- Day 4: SCD Type 1 load (overwrite dimension)
- Day 5: SCD Type 2 load (historical tracking)
- Day 6: LC 1164 (query point-in-time from SCD2)

### Week 3: Advanced + Review (Days 7-8)
- Day 7: Multi-source merge, idempotent pipeline
- Day 8: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Dedup before merge | Pattern 12 (Deduplication) — ROW_NUMBER in staging |
| Query SCD history | Pattern 01 (Window Functions) — ROW_NUMBER for latest |
| Compare snapshots | Pattern 10 (Set Operations) — EXCEPT for diffs |
| Recursive hierarchy in dimensions | Pattern 02 (Recursive CTE) — org charts in dims |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     15 (4 Easy, 7 Medium, 4 Hard)
MUST-DO:            LC 196, 627, 1164 + upsert, full MERGE, SCD2 load
TOP 3 MOST ASKED:   Basic upsert, SCD Type 2 design, LC 1164 (price history)
PATTERN SPLIT:      Upsert (4), Full MERGE (3), SCD1 (2), SCD2 (4), Conditional (2)
STUDY ORDER:        UPDATE/DELETE → Upsert → Full MERGE → SCD1 → SCD2
KEY INSIGHT:        MERGE = atomic INSERT + UPDATE + DELETE; SCD2 = full history
INTERVIEW LINE:     "I use MERGE for atomic sync, SCD Type 2 for historical
                     dimensions with effective/end dates and is_current flags."
```

---

## 30-SECOND REVISION BOX

```
MERGE:         MERGE INTO target USING source ON join
               WHEN MATCHED → UPDATE
               WHEN NOT MATCHED → INSERT
               WHEN NOT MATCHED BY SOURCE → DELETE
UPSERT PG:     INSERT ... ON CONFLICT (col) DO UPDATE SET col = EXCLUDED.col
UPSERT MySQL:  INSERT ... ON DUPLICATE KEY UPDATE col = VALUES(col)
SCD TYPE 1:    Overwrite — no history, simple UPDATE
SCD TYPE 2:    New row per change — close old (end_date), insert new (is_current)
SCD TYPE 3:    Add previous_value column — only one level of history
QUERY SCD2:    WHERE effective_date <= target_date AND end_date >= target_date
EXCLUDED:      PostgreSQL keyword — refers to the conflicting INSERT row
RULE:          Always close old SCD2 row BEFORE inserting new one
```
