# Window Functions — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Window functions = FAANG's #1 SQL topic.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Rank Scores | Medium | 178 | DENSE_RANK | Purest ranking problem — foundation |
| 2 | Department Highest Salary | Medium | 184 | MAX window or subquery | Top-1 per partition |
| 3 | Department Top Three Salaries | Hard | 185 | DENSE_RANK + PARTITION | Top-N per group — THE FAANG classic |
| 4 | Consecutive Numbers | Medium | 180 | LAG/LEAD | Detect N consecutive same values |
| 5 | Rising Temperature | Easy | 197 | LAG on date | Day-over-day comparison |
| 6 | Nth Highest Salary | Medium | 177 | DENSE_RANK or OFFSET | Generalized ranking |
| 7 | Game Play Analysis IV | Medium | 550 | ROW_NUMBER + date | Retention — first day + next day |
| 8 | Restaurant Growth | Medium | 1321 | SUM OVER (ROWS frame) | 7-day rolling sum |
| 9 | Last Person to Fit in the Bus | Medium | 1204 | SUM OVER (ORDER BY) | Running cumulative |
| 10 | Human Traffic of Stadium | Hard | 601 | ROW_NUMBER island trick | 3+ consecutive ids ≥ threshold |

---

## Complete 30-Problem Progression

### Easy-Medium — Ranking Basics (Problems 1-10)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Rank Scores | 178 | DENSE_RANK | Ranking without gaps |
| 2 | Second Highest Salary | 176 | DENSE_RANK or OFFSET | Nth value extraction |
| 3 | Nth Highest Salary | 177 | DENSE_RANK function | Parameterized Nth |
| 4 | Department Highest Salary | 184 | RANK + PARTITION BY | Top-1 per dept |
| 5 | Department Top Three Salaries | 185 | DENSE_RANK ≤ 3 | Top-N per group |
| 6 | Rising Temperature | 197 | LAG | Previous row comparison |
| 7 | Consecutive Numbers | 180 | LAG/LEAD 2 deep | Three same in a row |
| 8 | Find the Start & End of Continuous Ranges | 1285 | ROW_NUMBER diff | Island detection |
| 9 | Exchange Seats | 626 | ROW_NUMBER + CASE | Swap adjacent rows |
| 10 | Employees Earning > Average | 1549 | AVG OVER () | Compare row to global avg |

### Medium — Running Aggregates & Offsets (Problems 11-22)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Restaurant Growth | 1321 | SUM OVER ROWS 6 PREC | 7-day moving average |
| 12 | Last Person to Fit in Bus | 1204 | SUM OVER ORDER BY | Running total ≤ limit |
| 13 | Game Play Analysis IV | 550 | MIN + date add | First login + next day retention |
| 14 | Product Price at Given Date | 1164 | LAST_VALUE / ROW_NUMBER | Latest change before cutoff |
| 15 | Movie Rating | 1341 | ROW_NUMBER per partition | Top-1 per category via UNION |
| 16 | Median Employee Salary | 569 | ROW_NUMBER + COUNT | Middle row(s) per group |
| 17 | Find Cumulative Salary | 579 | SUM OVER ROWS 2 PREC | 3-month rolling excl. latest |
| 18 | Average Salary: Depts vs Company | 615 | AVG OVER () per month | Partition-level vs global avg |
| 19 | Count Salary Categories | 1907 | NTILE or CASE + window | Bucket + count |
| 20 | Immediate Food Delivery II | 1174 | ROW_NUMBER for first | First order per user |
| 21 | Monthly Transactions I | 1193 | Window alt approach | Rolling transaction stats |
| 22 | Sales Person | 607 | NOT EXISTS + window | Filter after window |

### Hard — Islands, Gaps & Advanced (Problems 23-30)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Human Traffic of Stadium | 601 | Island + consecutive | 3+ consecutive rows ≥ 100 |
| 24 | Report Contiguous Dates | 1225 | ROW_NUMBER diff | Date islands — group consecutive |
| 25 | Trips and Users | 262 | Window + ratio | Cancel rate per day |
| 26 | Tournament Winners | 1194 | SUM + RANK partition | Score → rank → winner per group |
| 27 | Active Businesses | 1126 | AVG window + filter | Events above their own avg |
| 28 | Biggest Window Between Visits | 1709 | LEAD on dates | Gap between consecutive visits |
| 29 | Find the Quiet Students in All Exams | 1412 | MIN/MAX RANK | Students never top/bottom |
| 30 | Longest Winning Streak | 2173 | Island + COUNT | Consecutive wins per player |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Rank Scores (LC 178)
```
Type: DENSE_RANK
Key: DENSE_RANK() OVER (ORDER BY score DESC) AS rank
Trap: Don't use RANK (gaps after ties) or ROW_NUMBER (no ties)
One-liner: DENSE_RANK = no gaps — interviews always want "1, 2, 2, 3" not "1, 2, 2, 4".
```

### Problem 5: Department Top Three Salaries (LC 185)
```
Type: DENSE_RANK + PARTITION BY
Key: WITH cte AS (SELECT *, DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS rk)
     SELECT * FROM cte WHERE rk <= 3
One-liner: Top-N per group = DENSE_RANK in CTE + filter in outer WHERE.
```

### Problem 7: Consecutive Numbers (LC 180)
```
Type: LAG / LEAD
Key: LAG(num, 1) = num AND LAG(num, 2) = num
Alt: Self-join on id, id+1, id+2 where all nums equal
One-liner: Check previous 1 and 2 rows have same value.
```

### Problem 11: Restaurant Growth (LC 1321)
```
Type: Running aggregate with frame
Key: SUM(amount) OVER (ORDER BY visited_on ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
Trap: Need exactly 7-day window — filter rows with ROW_NUMBER >= 7
One-liner: Frame clause ROWS 6 PRECEDING = 7-day rolling window.
```

### Problem 23: Human Traffic of Stadium (LC 601)
```
Type: Island detection
Key: id - ROW_NUMBER() gives constant for consecutive ids → group → HAVING COUNT ≥ 3
One-liner: Island trick — subtract ROW_NUMBER from id to find groups of consecutive.
```

### Problem 30: Longest Winning Streak (LC 2173)
```
Type: Island + consecutive count
Key: Use ROW_NUMBER diff trick to group consecutive wins, then MAX(count) per player
One-liner: Streak = island of same result; ROW_NUMBER diff identifies each streak.
```

---

## Pattern Distribution

```
RANKING (ROW_NUMBER/RANK/DENSE_RANK):  10 problems  (1-5, 9, 15-16, 20, 29)
LAG/LEAD (offset):                      6 problems  (6-7, 14, 22, 28, 29)
RUNNING AGGREGATE (SUM/AVG OVER):       6 problems  (11-13, 17-18, 25)
ISLAND / GAP DETECTION:                 5 problems  (8, 23-24, 26, 30)
FRAME CLAUSE:                           3 problems  (11, 17, 21)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-3 (DENSE_RANK, Nth salary)
- Day 2: Problems 4-6 (Top-N per group, LAG)
- Day 3: Problems 7-10 (consecutive, island intro, exchange seats)

### Week 2: Core (Days 4-7)
- Day 4: Problems 11-13 (rolling sum, cumulative)
- Day 5: Problems 14-16 (last value, median, movie)
- Day 6: Problems 17-19 (3-month rolling, dept vs company)
- Day 7: Problems 20-22 (first-order, sales filter)

### Week 3: Hard (Days 8-10)
- Day 8: Problems 23-25 (human traffic, contiguous dates)
- Day 9: Problems 26-28 (tournament, active business, visit gap)
- Day 10: Problems 29-30 (quiet students, winning streak)

---

## Cross-Reference: Window vs GROUP BY vs Join

| Problem | Window | GROUP BY alt | Join alt |
|---------|--------|-------------|----------|
| Rank Scores (178) | DENSE_RANK | COUNT DISTINCT > | Self-join |
| Top 3 Dept (185) | DENSE_RANK CTE | Correlated count | N/A |
| Consecutive (180) | LAG | N/A | Self-join 3× |
| Restaurant Growth (1321) | SUM OVER frame | N/A | Self-join on date range |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (3 Easy, 19 Medium, 8 Hard)
MUST-DO:            LC 178, 184, 185, 180, 197, 177, 550, 1321, 1204, 601
TOP 3 MOST ASKED:   LC 185 (Top 3 Dept), LC 178 (Rank), LC 180 (Consecutive)
PATTERN SPLIT:      Ranking (10), LAG/LEAD (6), Running Agg (6),
                    Island/Gap (5), Frame (3)
STUDY ORDER:        DENSE_RANK → ROW_NUMBER → LAG/LEAD → Running SUM → Island
INTERVIEW LINE:     "I use DENSE_RANK for Top-N per group, LAG for
                     row comparison, and ROW_NUMBER diff for island detection."
```

---

## 30-SECOND REVISION BOX

```
RANKING:        LC 178 — DENSE_RANK() OVER (ORDER BY score DESC)
TOP-N:          LC 185 — DENSE_RANK PARTITION BY dept, WHERE rk <= 3
LAG:            LC 197/180 — LAG(col, 1) OVER (ORDER BY ...) for prev row
RUNNING SUM:    LC 1321 — SUM() OVER (ORDER BY date ROWS 6 PRECEDING)
ISLAND:         LC 601 — id - ROW_NUMBER() = constant for consecutive
RETENTION:      LC 550 — first login + check login on day+1
```
