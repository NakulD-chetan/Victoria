# Prefix Sum — Common Mistakes

> **Why each mistake happens and how to avoid it.** FAANG interviewers notice these instantly.

---

## Mistake 1: Off-by-One in Prefix Array Indexing

### The Error
```python
# WRONG: prefix has same length as arr
prefix = [0] * len(arr)
prefix[i] = prefix[i-1] + arr[i]  # prefix[-1] when i=0!
```

### Correct
```python
prefix = [0] * (len(arr) + 1)  # n+1 elements
prefix[i + 1] = prefix[i] + arr[i]
```

### Why It Happens
- **Confusion:** "prefix[i] = sum up to index i" vs "prefix[i] = sum of arr[0..i-1]"
- **Convention:** prefix[i] = sum of elements **before** index i. So prefix[0]=0 (nothing before), prefix[1]=arr[0], prefix[n]=sum of all.
- **Result:** prefix has length n+1. Index n exists.

### Memory Hook
**prefix[i] = sum of arr[0..i-1]** → prefix[0] is "before first element" → need n+1 slots.

---

## Mistake 2: Forgetting prefix[0] = 0

### The Error
```python
prefix = [arr[0]]  # WRONG
for i in range(1, n):
    prefix.append(prefix[-1] + arr[i])
# Now sum(arr[0..j]) = prefix[j] - ???  No prefix[0]=0!
```

### Correct
```python
prefix = [0]
for i in range(n):
    prefix.append(prefix[-1] + arr[i])
```

### Why It Happens
- **Subarray starting at 0:** sum(arr[0..j]) = prefix[j+1] - prefix[0]. If prefix[0] ≠ 0, formula breaks.
- **Hash map for "sum=K":** When the entire prefix up to some point equals K, we need prefix[i]=0 for some i (the "empty" prefix before start).

### Memory Hook
**prefix[0] = 0** = "sum of nothing" = the starting checkpoint.

---

## Mistake 3: Not Initializing Hash Map with {0: 1}

### The Error
```python
prefix_count = {}  # WRONG
# When first element gives prefix=K, we need count(0)=1
# count += prefix_count.get(prefix - k, 0)  # prefix-K=0, but 0 not in map!
```

### Correct
```python
prefix_count = {0: 1}  # Empty prefix counts as one
```

### Why It Happens
- **Subarray starting at index 0:** sum(arr[0..j]) = prefix[j+1] - prefix[0]. prefix[0]=0.
- **When prefix[j+1] = K:** We need to count prefix[i]=0. The "i" before index 0 is the empty prefix → must be in map with count 1.

### Example
```
arr = [3], K = 3
prefix = [0, 3]
Subarray [0..0] has sum 3. We need prefix[i]=0, i.e. prefix[0].
Without {0:1}, we get count 0. Wrong!
```

### Memory Hook
**{0: 1}** = "one way to have prefix 0" = the empty subarray before we start.

---

## Mistake 4: 2D Prefix Inclusion-Exclusion Errors

### The Error
```python
# WRONG: Wrong indices or wrong signs
region = prefix[r2][c2] - prefix[r1][c2] - prefix[r2][c1] + prefix[r1][c1]
# Off-by-one: prefix is (r+1)x(c+1), so use r2+1, c2+1 for "up to r2,c2"
```

### Correct
```python
region = (
    prefix[r2 + 1][c2 + 1]  # whole rectangle to (r2, c2)
    - prefix[r1][c2 + 1]   # strip above
    - prefix[r2 + 1][c1]   # strip to the left
    + prefix[r1][c1]       # corner (double-subtracted)
)
```

### Why It Happens
- **1-based vs 0-based:** prefix[i][j] = sum of all matrix[r][c] where r < i, c < j. So prefix[r2+1][c2+1] includes row r2 and col c2.
- **Signs:** Subtract top and left strips. The top-left corner was subtracted twice → add it back.

### Memory Hook
**Draw the 2x2 grid:** A|B, C|D. Sum(D) = (A+B+C+D) - (A+B) - (A+C) + A.

---

## Mistake 5: Wrong Range Formula (Exclusive vs Inclusive)

### The Error
```python
# "Sum of arr[i..j] inclusive"
return prefix[j] - prefix[i]   # WRONG: excludes arr[j]
return prefix[j+1] - prefix[i+1]  # WRONG: excludes arr[i]
```

### Correct
```python
# arr[i..j] inclusive: indices i, i+1, ..., j
return prefix[j + 1] - prefix[i]
```

### Why It Happens
- prefix[j+1] = arr[0]+...+arr[j] (includes arr[j])
- prefix[i] = arr[0]+...+arr[i-1] (excludes arr[i])
- Difference = arr[i]+...+arr[j] ✓

### Memory Hook
**prefix[j+1] - prefix[i]** = "from start to j" minus "from start to i-1" = i to j inclusive.

---

## Mistake 6: Integer Overflow (Large Sums)

### The Error
```cpp
vector<int> prefix(n + 1);  // WRONG if sums can exceed INT_MAX
```

### Correct
```cpp
vector<long long> prefix(n + 1);
// Or: check constraints; if n*max(arr[i]) > INT_MAX, use long long
```

### Why It Happens
- Prefix sum accumulates. n=10⁵, arr[i]=10⁹ → sum can be 10¹⁴.
- int max ≈ 2×10⁹. Overflow causes wrong results.

---

## Quick Reference: Mistake Checklist

| Mistake | Fix |
|---------|-----|
| prefix length = n | Use n+1 |
| prefix[0] = arr[0] | prefix[0] = 0 |
| map = {} | map = {0: 1} |
| 2D wrong indices | Use r2+1, c2+1 for "up to (r2,c2)" |
| 2D wrong signs | whole - left - top + corner |
| sum(i..j) = prefix[j]-prefix[i] | prefix[j+1]-prefix[i] |
| int for prefix | long long if overflow possible |

---

## FINAL MEMORY COMPRESSION BLOCK

```
OFF-BY-ONE:    prefix length n+1, prefix[i+1]=prefix[i]+arr[i]
PREFIX[0]:     Always 0 — "sum of nothing"
MAP INIT:      {0: 1} — empty prefix for subarrays starting at 0
2D:            prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1]
RANGE:         sum(i..j) = prefix[j+1] - prefix[i]
OVERFLOW:      Use long long for prefix when n*max_val large
```
