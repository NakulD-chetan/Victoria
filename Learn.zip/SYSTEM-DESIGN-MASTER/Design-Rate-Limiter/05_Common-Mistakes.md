# Design Rate Limiter — Common Mistakes

> **Permanent Recall:** Avoid: in-memory only (breaks with multiple servers), fixed window without mentioning boundary spike, Redis ops without atomicity (Lua), skipping fail-open vs fail-closed, and ignoring monitoring.

---

## 1. Not Discussing Distributed Challenges

**Mistake:** Describing a single-server, in-memory rate limiter.

**Why it's wrong:** At scale you have multiple API servers behind a load balancer. Each has its own memory. User A hits server 1, user A hits server 2—neither sees the other's count. Limits are effectively multiplied by server count.

**Fix:** State upfront that you need a **shared store** (Redis) so all nodes see the same counters.

---

## 2. In-Memory Only

**Mistake:** "We'll keep a HashMap of identity → count in each server."

**Why it's wrong:** With 10 servers, a "100/min" limit becomes 1000/min—each server allows 100 independently.

**Fix:** Explicitly say the counter must be in a **distributed store** (Redis, Memcached, or similar).

---

## 3. Fixed Window Boundary Spike — Not Mentioning It

**Mistake:** Proposing fixed window and not acknowledging the boundary problem.

**Why it matters:** 100 requests at 10:00:59 and 100 at 10:01:01 = 200 in 2 seconds. Interviewers expect you to know this.

**Fix:** Mention it: "Fixed window is simple but has a boundary spike; if that's acceptable we can use it; otherwise sliding window or token bucket."

---

## 4. Race Conditions in Redis — Non-Atomic Ops

**Mistake:** "We'll INCR the key, then EXPIRE it."

```python
count = redis.incr(key)
if count == 1:
    redis.expire(key, 60)  # Another request can INCR before this runs!
```

**Why it's wrong:** Between INCR and EXPIRE, another request can INCR. Or a read-modify-write (GET, check, INCR) is not atomic—two requests can both see count=99 and both allow.

**Fix:** Use a **Lua script** so INCR, conditional EXPIRE, and comparison happen atomically.

---

## 5. Ignoring Fail-Open vs Fail-Closed

**Mistake:** Not addressing "What if Redis is down?"

**Why it matters:** You must choose: allow all traffic (fail open) or reject all (fail closed). Both have trade-offs.

**Fix:** State: "If Redis is unavailable, we'd fail open for availability or fail closed for security, depending on the product."

---

## 6. Ignoring Monitoring

**Mistake:** Building the rate limiter but not mentioning observability.

**Why it matters:** You need to know: Who is hitting limits? Are limits too strict? Is Redis healthy?

**Fix:** Mention: "We'd track 429 rate per identity and endpoint, Redis latency, and alert on anomalies."

---

## 7. Wrong Headers or No Retry-After

**Mistake:** Returning 429 without `Retry-After` or standard headers.

**Why it matters:** Clients need to know when to retry. `Retry-After` is standard (RFC 7231).

**Fix:** Always return `Retry-After` (seconds or HTTP-date) on 429. Optional: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`.

---

## 8. Over-Complicating the Initial Design

**Mistake:** Jumping to sliding window log, multiple regions, ML-based limits in the first 5 minutes.

**Why it's wrong:** Start with core: identity, algorithm, Redis, atomicity. Add complexity when asked.

**Fix:** Begin with fixed window or token bucket + Redis. Introduce sliding window and edge cases as follow-ups.

---

## 9. Not Clarifying "Identity"

**Mistake:** Assuming "rate limit" means one thing—e.g., only by IP.

**Why it matters:** Different products need different dimensions: IP (anonymous), user_id (logged-in), API key (partners).

**Fix:** Ask: "Are we limiting by IP, user ID, API key, or a combination?"

---

## 10. Sliding Window Log at Scale — Memory

**Mistake:** Choosing sliding window log for high-traffic APIs without considering memory.

**Why it's wrong:** O(requests) per identity. 1M requests/min per user = 1M entries; Redis memory explodes.

**Fix:** Prefer **sliding window counter** (O(1)) or **token bucket** for production scale.

---

## Quick Reference

| Mistake | Fix |
|---------|-----|
| In-memory only | Use Redis (or similar) as shared store |
| Fixed window, no caveat | Mention boundary spike; consider sliding/token bucket |
| Non-atomic Redis ops | Lua script for INCR + EXPIRE + check |
| No failure mode | Discuss fail open vs fail closed |
| No monitoring | 429 metrics, Redis latency, alerts |
| No Retry-After | Return Retry-After on 429 |
| Unclear identity | Clarify: IP, user_id, API key |
