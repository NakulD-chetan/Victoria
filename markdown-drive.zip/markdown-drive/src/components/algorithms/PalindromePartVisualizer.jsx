import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function minCutSteps(s) {
  const n = s.length;
  const pal = Array.from({ length: n }, () => Array(n).fill(false));
  const steps = [];
  const labels = s.split('');

  const snapPal = (caption, colors) => {
    steps.push({
      caption,
      table: pal.map((row) => row.map((v) => (v ? '✓' : ''))),
      rowLabels: labels,
      colLabels: labels,
      cellColors: colors || {},
      arrows: [],
      highlight: null,
    });
  };

  for (let i = n - 1; i >= 0; i -= 1) {
    pal[i][i] = true;
    snapPal(`Singleton palindrome '${s[i]}'`, { [`${i}-${i}`]: 'filled' });
    for (let j = i + 1; j < n; j += 1) {
      const colors = { [`${i}-${j}`]: 'current', [`${i + 1}-${j - 1}`]: 'filling' };
      if (s[i] === s[j] && (j - i === 1 || pal[i + 1][j - 1])) {
        pal[i][j] = true;
        snapPal(`s[${i}..${j}] is palindrome`, { [`${i}-${j}`]: 'optimal', ...Object.fromEntries(
          Array.from({ length: j - i + 1 }, (_, k) => [`${i + k}-${i + k}`, 'filled']),
        ) });
      } else {
        snapPal(`s[${i}..${j}] not palindrome`, colors);
      }
    }
  }

  const dp = Array(n).fill(0);
  const colLabels = Array.from({ length: n }, (_, i) => i);

  const snapDp = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [dp],
      rowLabels: ['cuts'],
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snapDp('Min cuts dp[i] for prefix s[0..i]', {}, null, []);

  for (let i = 0; i < n; i += 1) {
    let best = i;
    for (let j = 0; j <= i; j += 1) {
      if (pal[j][i]) {
        const colors = { [`0-${i}`]: 'current', [`0-${j - 1}`]: j > 0 ? 'filling' : 'filled' };
        snapDp(`Whole palindrome s[${j}..${i}]`, colors, [0, i], j ? [{ from: [0, j - 1], to: [0, i] }] : []);
        best = Math.min(best, j === 0 ? 0 : dp[j - 1] + 1);
      }
    }
    dp[i] = best;
    snapDp(`dp[${i}] = ${dp[i]}`, { [`0-${i}`]: 'optimal' }, [0, i], []);
  }

  snapDp(`Minimum palindrome cuts = ${dp[n - 1]}`, { [`0-${n - 1}`]: 'optimal' }, [0, n - 1], []);
  return steps;
}

export default function PalindromePartVisualizer({ config }) {
  const s = 'abacaba';

  const onInit = useCallback((canvasRef) => {
    const steps = minCutSteps(s);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Palindrome partitioning on "${s}"` });
    canvasRef.current?.setState({ table: [[0]], rowLabels: [], colLabels: [], cellColors: {}, arrows: [], highlight: null, caption: 'Palindrome cuts' });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
