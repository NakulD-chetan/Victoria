# Graph — Coding Template

> **Permanent Recall:** Adjacency list = default. BFS = deque/queue. DFS = stack or recursion. Dijkstra = min-heap. Topo = Kahn's or DFS. Cycle: directed = 3-color, undirected = parent/Union-Find. Multi-source BFS = enqueue all sources at start.

---

## 1. Adjacency List Representation

### Python
```python
from collections import defaultdict

# Unweighted
adj = defaultdict(list)
adj[u].append(v)

# Weighted
adj = defaultdict(list)
adj[u].append((v, weight))

# Or with list of lists (n nodes)
adj = [[] for _ in range(n)]
adj[u].append(v)  # or (v, w) for weighted
```

### C++
```cpp
// Unweighted: vector<vector<int>>
vector<vector<int>> adj(n);
adj[u].push_back(v);

// Weighted: vector<vector<pair<int,int>>>
vector<vector<pair<int,int>>> adj(n);
adj[u].push_back({v, weight});
```

### Rust
```rust
// Unweighted: Vec<Vec<usize>>
let mut adj: Vec<Vec<usize>> = vec![vec![]; n];
adj[u].push(v);

// Weighted: Vec<Vec<(usize, i32)>>
let mut adj: Vec<Vec<(usize, i32)>> = vec![vec![]; n];
adj[u].push((v, weight));
```

---

## 2. BFS Traversal (with visited, level tracking)

### Python
```python
from collections import deque

def bfs(adj, start, n):
    visited = [False] * n
    dist = [-1] * n  # level/distance
    q = deque([start])
    visited[start] = True
    dist[start] = 0

    while q:
        u = q.popleft()
        for v in adj[u]:
            if not visited[v]:
                visited[v] = True
                dist[v] = dist[u] + 1
                q.append(v)
    return dist
```

### C++
```cpp
vector<int> bfs(vector<vector<int>>& adj, int start, int n) {
    vector<bool> visited(n, false);
    vector<int> dist(n, -1);
    queue<int> q;
    q.push(start);
    visited[start] = true;
    dist[start] = 0;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : adj[u]) {
            if (!visited[v]) {
                visited[v] = true;
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
    return dist;
}
```

### Rust
```rust
use std::collections::VecDeque;

fn bfs(adj: &[Vec<usize>], start: usize, n: usize) -> Vec<i32> {
    let mut visited = vec![false; n];
    let mut dist = vec![-1; n];
    let mut q = VecDeque::new();
    q.push_back(start);
    visited[start] = true;
    dist[start] = 0;

    while let Some(u) = q.pop_front() {
        for &v in &adj[u] {
            if !visited[v] {
                visited[v] = true;
                dist[v] = dist[u] + 1;
                q.push_back(v);
            }
        }
    }
    dist
}
```

---

## 3. DFS Traversal (Recursive + Iterative)

### Python
```python
# Recursive
def dfs_rec(adj, u, visited):
    visited[u] = True
    for v in adj[u]:
        if not visited[v]:
            dfs_rec(adj, v, visited)

# Iterative (stack)
def dfs_iter(adj, start, n):
    visited = [False] * n
    stack = [start]
    while stack:
        u = stack.pop()
        if visited[u]:
            continue
        visited[u] = True
        for v in adj[u]:
            if not visited[v]:
                stack.append(v)
```

### C++
```cpp
// Recursive
void dfs_rec(vector<vector<int>>& adj, int u, vector<bool>& visited) {
    visited[u] = true;
    for (int v : adj[u]) {
        if (!visited[v]) dfs_rec(adj, v, visited);
    }
}

// Iterative
void dfs_iter(vector<vector<int>>& adj, int start, int n) {
    vector<bool> visited(n, false);
    stack<int> st;
    st.push(start);
    while (!st.empty()) {
        int u = st.top();
        st.pop();
        if (visited[u]) continue;
        visited[u] = true;
        for (int v : adj[u]) {
            if (!visited[v]) st.push(v);
        }
    }
}
```

### Rust
```rust
// Recursive
fn dfs_rec(adj: &[Vec<usize>], u: usize, visited: &mut [bool]) {
    visited[u] = true;
    for &v in &adj[u] {
        if !visited[v] {
            dfs_rec(adj, v, visited);
        }
    }
}

// Iterative
fn dfs_iter(adj: &[Vec<usize>], start: usize, n: usize) {
    let mut visited = vec![false; n];
    let mut stack = vec![start];
    while let Some(u) = stack.pop() {
        if visited[u] { continue; }
        visited[u] = true;
        for &v in adj[u].iter().rev() {
            if !visited[v] {
                stack.push(v);
            }
        }
    }
}
```

---

## 4. Topological Sort (Kahn's BFS + DFS with colors)

### Python
```python
from collections import deque

# Kahn's (BFS) - in-degree based
def topo_kahn(adj, n):
    indeg = [0] * n
    for u in range(n):
        for v in adj[u]:
            indeg[v] += 1
    q = deque([u for u in range(n) if indeg[u] == 0])
    order = []
    while q:
        u = q.popleft()
        order.append(u)
        for v in adj[u]:
            indeg[v] -= 1
            if indeg[v] == 0:
                q.append(v)
    return order if len(order) == n else []  # [] if cycle

# DFS (postorder reverse)
def topo_dfs(adj, n):
    WHITE, GRAY, BLACK = 0, 1, 2
    color = [WHITE] * n
    order = []

    def dfs(u):
        color[u] = GRAY
        for v in adj[u]:
            if color[v] == GRAY:
                return False  # cycle
            if color[v] == WHITE and not dfs(v):
                return False
        color[u] = BLACK
        order.append(u)
        return True

    for u in range(n):
        if color[u] == WHITE and not dfs(u):
            return []
    return order[::-1]
```

### C++
```cpp
// Kahn's (BFS)
vector<int> topo_kahn(vector<vector<int>>& adj, int n) {
    vector<int> indeg(n, 0);
    for (int u = 0; u < n; u++)
        for (int v : adj[u]) indeg[v]++;
    queue<int> q;
    for (int u = 0; u < n; u++)
        if (indeg[u] == 0) q.push(u);
    vector<int> order;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        order.push_back(u);
        for (int v : adj[u]) {
            indeg[v]--;
            if (indeg[v] == 0) q.push(v);
        }
    }
    return order.size() == (size_t)n ? order : vector<int>();
}

// DFS (postorder reverse)
vector<int> topo_dfs(vector<vector<int>>& adj, int n) {
    enum { WHITE, GRAY, BLACK };
    vector<int> color(n, WHITE);
    vector<int> order;
    bool cycle = false;

    function<bool(int)> dfs = [&](int u) {
        color[u] = GRAY;
        for (int v : adj[u]) {
            if (color[v] == GRAY) return cycle = true, false;
            if (color[v] == WHITE && !dfs(v)) return false;
        }
        color[u] = BLACK;
        order.push_back(u);
        return true;
    };
    for (int u = 0; u < n; u++)
        if (color[u] == WHITE && !dfs(u)) return {};
    reverse(order.begin(), order.end());
    return order;
}
```

### Rust
```rust
use std::collections::VecDeque;

// Kahn's (BFS)
fn topo_kahn(adj: &[Vec<usize>], n: usize) -> Vec<usize> {
    let mut indeg = vec![0; n];
    for u in 0..n {
        for &v in &adj[u] {
            indeg[v] += 1;
        }
    }
    let mut q: VecDeque<usize> = (0..n).filter(|&u| indeg[u] == 0).collect();
    let mut order = Vec::new();
    while let Some(u) = q.pop_front() {
        order.push(u);
        for &v in &adj[u] {
            indeg[v] -= 1;
            if indeg[v] == 0 {
                q.push_back(v);
            }
        }
    }
    if order.len() == n { order } else { vec![] }
}

// DFS (postorder reverse)
fn topo_dfs(adj: &[Vec<usize>], n: usize) -> Vec<usize> {
    const WHITE: u8 = 0;
    const GRAY: u8 = 1;
    const BLACK: u8 = 2;
    let mut color = vec![WHITE; n];
    let mut order = Vec::new();
    let mut cycle = false;

    fn dfs(u: usize, adj: &[Vec<usize>], color: &mut [u8], order: &mut Vec<usize>, cycle: &mut bool) -> bool {
        color[u] = GRAY;
        for &v in &adj[u] {
            if color[v] == GRAY {
                *cycle = true;
                return false;
            }
            if color[v] == WHITE && !dfs(v, adj, color, order, cycle) {
                return false;
            }
        }
        color[u] = BLACK;
        order.push(u);
        true
    }
    for u in 0..n {
        if color[u] == WHITE && !dfs(u, adj, &mut color, &mut order, &mut cycle) {
            return vec![];
        }
    }
    order.reverse();
    order
}
```

---

## 5. Dijkstra's Algorithm (min-heap)

### Python
```python
import heapq

def dijkstra(adj, start, n):
    # adj[u] = [(v, weight), ...]
    dist = [float('inf')] * n
    dist[start] = 0
    pq = [(0, start)]

    while pq:
        d, u = heapq.heappop(pq)
        if d > dist[u]:
            continue
        for v, w in adj[u]:
            if dist[u] + w < dist[v]:
                dist[v] = dist[u] + w
                heapq.heappush(pq, (dist[v], v))
    return dist
```

### C++
```cpp
vector<int> dijkstra(vector<vector<pair<int,int>>>& adj, int start, int n) {
    vector<int> dist(n, INT_MAX);
    dist[start] = 0;
    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
    pq.push({0, start});

    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (d > dist[u]) continue;
        for (auto [v, w] : adj[u]) {
            if (dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}
```

### Rust
```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

fn dijkstra(adj: &[Vec<(usize, i32)>], start: usize, n: usize) -> Vec<i64> {
    let mut dist = vec![i64::MAX; n];
    dist[start] = 0;
    let mut pq: BinaryHeap<Reverse<(i64, usize)>> = BinaryHeap::new();
    pq.push(Reverse((0, start)));

    while let Some(Reverse((d, u))) = pq.pop() {
        if d > dist[u] { continue; }
        for &(v, w) in &adj[u] {
            let new_d = dist[u] + w as i64;
            if new_d < dist[v] {
                dist[v] = new_d;
                pq.push(Reverse((dist[v], v)));
            }
        }
    }
    dist
}
```

---

## 6. Cycle Detection

### Directed: DFS with 3 colors

| Python | C++ | Rust |
|--------|-----|------|
| WHITE=unvisited, GRAY=in stack, BLACK=done | Same | Same |
| Back edge to GRAY = cycle | Same | Same |

### Python
```python
def has_cycle_directed(adj, n):
    WHITE, GRAY, BLACK = 0, 1, 2
    color = [WHITE] * n

    def dfs(u):
        color[u] = GRAY
        for v in adj[u]:
            if color[v] == GRAY:
                return True  # cycle
            if color[v] == WHITE and dfs(v):
                return True
        color[u] = BLACK
        return False

    return any(color[u] == WHITE and dfs(u) for u in range(n))
```

### C++
```cpp
bool has_cycle_directed(vector<vector<int>>& adj, int n) {
    enum { WHITE, GRAY, BLACK };
    vector<int> color(n, WHITE);
    function<bool(int)> dfs = [&](int u) {
        color[u] = GRAY;
        for (int v : adj[u]) {
            if (color[v] == GRAY) return true;
            if (color[v] == WHITE && dfs(v)) return true;
        }
        color[u] = BLACK;
        return false;
    };
    for (int u = 0; u < n; u++)
        if (color[u] == WHITE && dfs(u)) return true;
    return false;
}
```

### Undirected: Union-Find

### Python
```python
class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])
        return self.parent[x]
    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        if px == py: return False  # cycle
        self.parent[px] = py
        return True

def has_cycle_undirected(edges, n):
    uf = UnionFind(n)
    for u, v in edges:
        if not uf.union(u, v):
            return True
    return False
```

### C++
```cpp
struct UnionFind {
    vector<int> parent;
    UnionFind(int n) : parent(n) { iota(parent.begin(), parent.end(), 0); }
    int find(int x) {
        if (parent[x] != x) parent[x] = find(parent[x]);
        return parent[x];
    }
    bool unite(int x, int y) {
        int px = find(x), py = find(y);
        if (px == py) return false;
        parent[px] = py;
        return true;
    }
};
```

### Rust
```rust
struct UnionFind {
    parent: Vec<usize>,
}
impl UnionFind {
    fn new(n: usize) -> Self {
        UnionFind { parent: (0..n).collect() }
    }
    fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);
        }
        self.parent[x]
    }
    fn union(&mut self, x: usize, y: usize) -> bool {
        let px = self.find(x);
        let py = self.find(y);
        if px == py { return false; }
        self.parent[px] = py;
        true
    }
}
```

---

## 7. Connected Components

### Python
```python
def count_components(adj, n):
    visited = [False] * n
    count = 0

    def dfs(u):
        visited[u] = True
        for v in adj[u]:
            if not visited[v]:
                dfs(v)

    for u in range(n):
        if not visited[u]:
            count += 1
            dfs(u)
    return count
```

### C++
```cpp
int count_components(vector<vector<int>>& adj, int n) {
    vector<bool> visited(n, false);
    int count = 0;
    function<void(int)> dfs = [&](int u) {
        visited[u] = true;
        for (int v : adj[u])
            if (!visited[v]) dfs(v);
    };
    for (int u = 0; u < n; u++)
        if (!visited[u]) { count++; dfs(u); }
    return count;
}
```

### Rust
```rust
fn count_components(adj: &[Vec<usize>], n: usize) -> usize {
    let mut visited = vec![false; n];
    let mut count = 0;

    fn dfs(u: usize, adj: &[Vec<usize>], visited: &mut [bool]) {
        visited[u] = true;
        for &v in &adj[u] {
            if !visited[v] {
                dfs(v, adj, visited);
            }
        }
    }
    for u in 0..n {
        if !visited[u] {
            count += 1;
            dfs(u, adj, &mut visited);
        }
    }
    count
}
```

---

## 8. Multi-Source BFS (Rotten Oranges)

### Python
```python
from collections import deque

def rotten_oranges(grid):
    rows, cols = len(grid), len(grid[0])
    q = deque()
    fresh = 0
    for r in range(rows):
        for c in range(cols):
            if grid[r][c] == 2:
                q.append((r, c, 0))
            elif grid[r][c] == 1:
                fresh += 1
    dirs = [(0,1),(1,0),(0,-1),(-1,0)]
    minutes = 0
    while q:
        r, c, m = q.popleft()
        minutes = m
        for dr, dc in dirs:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and grid[nr][nc] == 1:
                grid[nr][nc] = 2
                fresh -= 1
                q.append((nr, nc, m + 1))
    return minutes if fresh == 0 else -1
```

### C++
```cpp
int rotten_oranges(vector<vector<int>>& grid) {
    int rows = grid.size(), cols = grid[0].size();
    queue<tuple<int,int,int>> q;
    int fresh = 0;
    for (int r = 0; r < rows; r++)
        for (int c = 0; c < cols; c++) {
            if (grid[r][c] == 2) q.push({r, c, 0});
            else if (grid[r][c] == 1) fresh++;
        }
    vector<pair<int,int>> dirs = {{0,1},{1,0},{0,-1},{-1,0}};
    int minutes = 0;
    while (!q.empty()) {
        auto [r, c, m] = q.front();
        q.pop();
        minutes = m;
        for (auto [dr, dc] : dirs) {
            int nr = r + dr, nc = c + dc;
            if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr][nc] == 1) {
                grid[nr][nc] = 2;
                fresh--;
                q.push({nr, nc, m + 1});
            }
        }
    }
    return fresh == 0 ? minutes : -1;
}
```

### Rust
```rust
use std::collections::VecDeque;

fn rotten_oranges(grid: &mut [Vec<i32>]) -> i32 {
    let (rows, cols) = (grid.len(), grid[0].len());
    let mut q = VecDeque::new();
    let mut fresh = 0;
    for r in 0..rows {
        for c in 0..cols {
            match grid[r][c] {
                2 => q.push_back((r, c, 0)),
                1 => fresh += 1,
                _ => {}
            }
        }
    }
    let dirs: [(i32, i32); 4] = [(0, 1), (1, 0), (0, -1), (-1, 0)];
    let mut minutes = 0;
    while let Some((r, c, m)) = q.pop_front() {
        minutes = m;
        for (dr, dc) in dirs {
            let nr = r as i32 + dr;
            let nc = c as i32 + dc;
            if nr >= 0 && nr < rows as i32 && nc >= 0 && nc < cols as i32 {
                let (nr, nc) = (nr as usize, nc as usize);
                if grid[nr][nc] == 1 {
                    grid[nr][nc] = 2;
                    fresh -= 1;
                    q.push_back((nr, nc, m + 1));
                }
            }
        }
    }
    if fresh == 0 { minutes } else { -1 }
}
```

---

## 9. Bipartite Check

### Python
```python
from collections import deque

def is_bipartite(adj, n):
    color = [-1] * n  # -1 = uncolored, 0/1 = colors
    for start in range(n):
        if color[start] != -1:
            continue
        q = deque([start])
        color[start] = 0
        while q:
            u = q.popleft()
            for v in adj[u]:
                if color[v] == -1:
                    color[v] = 1 - color[u]
                    q.append(v)
                elif color[v] == color[u]:
                    return False
    return True
```

### C++
```cpp
bool is_bipartite(vector<vector<int>>& adj, int n) {
    vector<int> color(n, -1);
    for (int start = 0; start < n; start++) {
        if (color[start] != -1) continue;
        queue<int> q;
        q.push(start);
        color[start] = 0;
        while (!q.empty()) {
            int u = q.front();
            q.pop();
            for (int v : adj[u]) {
                if (color[v] == -1) {
                    color[v] = 1 - color[u];
                    q.push(v);
                } else if (color[v] == color[u])
                    return false;
            }
        }
    }
    return true;
}
```

### Rust
```rust
use std::collections::VecDeque;

fn is_bipartite(adj: &[Vec<usize>], n: usize) -> bool {
    let mut color = vec![-1i32; n];
    for start in 0..n {
        if color[start] != -1 { continue; }
        let mut q = VecDeque::new();
        q.push_back(start);
        color[start] = 0;
        while let Some(u) = q.pop_front() {
            for &v in &adj[u] {
                if color[v] == -1 {
                    color[v] = 1 - color[u];
                    q.push_back(v);
                } else if color[v] == color[u] {
                    return false;
                }
            }
        }
    }
    true
}
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Coding Templates
WHEN TO USE:       Any graph problem — pick template by problem type
CORE IDEA:         Adj list default; BFS=queue; DFS=stack/rec; Dijkstra=min-heap
TIME:              BFS/DFS O(V+E); Dijkstra O((V+E) log V); Topo O(V+E)
SPACE:             O(V) for visited/dist; O(V) for recursion stack
INTERVIEW SENTENCE: "I'll use adjacency list. For shortest path I'll use BFS/Dijkstra.
                     Here's my template..."
```

---

## 30-SECOND REVISION BOX

```
adj list → defaultdict(list) / vector<vector<int>> / Vec<Vec<usize>>
BFS → deque/queue/VecDeque, visited, dist
DFS → stack or recursion, visited
Topo → Kahn (indeg) or DFS (postorder reverse)
Dijkstra → heapq / priority_queue<greater> / BinaryHeap<Reverse>
Cycle dir → 3-color DFS; undir → Union-Find
Multi-BFS → enqueue all sources at start
Bipartite → BFS with color 0/1, conflict = false
```
