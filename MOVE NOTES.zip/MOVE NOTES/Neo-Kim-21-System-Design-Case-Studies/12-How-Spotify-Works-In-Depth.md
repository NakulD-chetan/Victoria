# How Spotify Works - In Depth (Easy Language)

> Companion to: [12-How-Spotify-Works.md](12-How-Spotify-Works.md)

---

## Spotify vs YouTube - Why Audio Is Simpler

Before diving in, understanding how Spotify is SIMPLER than YouTube helps:

| Aspect | Spotify (Audio) | YouTube (Video) |
|--------|----------------|----------------|
| **File size** | ~3 MB per song | 100s MB to GBs per video |
| **Upload** | Artists via label/distributor | Anyone, self-service |
| **Total storage** | ~90 TB (30M songs) | Exabytes (billions of videos) |
| **Transcoding** | 3 bitrates (simple) | 6+ resolutions × segments (complex) |
| **CDN load** | Moderate | Massive |

The same PATTERNS apply (S3, CDN, ABR), but at much smaller scale.

---

## Where the Songs Live - S3 (Blob Storage)

### The Math

```
30 million songs × 3 MB average = 90 TB
Each song stored in 3 bitrates: 64, 128, 320 kbps
  → 90 TB × 3 = 270 TB
With replication (2-3 copies): 540 - 810 TB

Compare to metadata:
  30M songs × 100 bytes metadata = 3 GB
  500K users × 1 KB metadata = 0.5 GB

Audio storage = 99.99% of total storage
Metadata = 0.01%
```

**Key insight**: Audio dominates everything. Metadata is tiny. Optimize for audio delivery, not metadata.

### File Organization in S3

```
s3://spotify-audio/
  ├── artist_001/
  │   ├── album_001/
  │   │   ├── song_001_64kbps.ogg
  │   │   ├── song_001_128kbps.ogg
  │   │   └── song_001_320kbps.ogg
  │   └── album_002/
  │       ├── song_002_64kbps.ogg
  │       └── ...
  └── artist_002/
      └── ...
```

---

## How Streaming Works - The Complete Flow

### Step by Step

```
1. You tap "Play" on a song
   → App sends: GET /songs/song_123

2. API server receives request:
   → Validates your JWT token (are you logged in? premium?)
   → Queries SQL DB for song metadata:
     { title: "Blinding Lights", artist: "The Weeknd",
       duration: 200s, file_urls: {64: "...", 128: "...", 320: "..."} }
   → Generates a SIGNED URL:
     "https://cdn.spotify.com/song_123_128kbps.ogg?token=xyz&expires=3600"

3. App receives signed URL + metadata

4. App starts streaming audio:
   → HTTP range request: "Give me bytes 0 to 100,000"
   → CDN returns first chunk → playback starts! (~200ms)
   → HTTP range request: "Give me bytes 100,001 to 200,000"
   → ... continues chunk by chunk

5. App reports play event:
   → POST /songs/song_123/play (for analytics, royalties, recommendations)
```

### Signed URLs - Security Without Complexity

```
Why signed URLs?
  → You can't just give the direct S3 URL (anyone could download all songs for free!)
  → Signed URL is temporary: works for 1-3 hours, then expires
  → Tied to your account (can't share with others)
  → One-time use or limited uses

What a signed URL looks like:
  https://cdn.spotify.com/song_123_128kbps.ogg
    ?X-Amz-Signature=abc123...
    &X-Amz-Expires=3600
    &X-Amz-Credential=spotify_account/...

After 1 hour: URL stops working → must request a new one
```

### HTTP Range Requests - Stream, Don't Download

```
Without range requests:
  Download entire 3MB file → then play
  → 3 second wait on 8 Mbps connection

With range requests:
  "Give me bytes 0-50,000" → plays first 0.5 seconds immediately
  "Give me bytes 50,001-100,000" → plays next 0.5 seconds
  
  → Playback starts in ~200ms
  → Never downloads more than needed (skip to next song? Stop downloading!)
```

---

## Adaptive Bitrate - Adjusting to Your Connection

### Three Quality Levels

```
64 kbps:  Low quality (saves data on mobile networks)
          ~0.5 MB per minute
128 kbps: Standard quality (most users)
          ~1 MB per minute
320 kbps: High quality (premium users, good headphones)
          ~2.5 MB per minute
```

### How It Adapts

```
You're on WiFi: 
  → App measures: download speed = 5 Mbps → plays 320 kbps (best quality)

You walk outside, switch to 4G:
  → App measures: download speed = 2 Mbps → still plays 320 kbps (enough bandwidth)

You enter a tunnel, signal weakens:
  → App measures: download speed = 100 Kbps → switches to 64 kbps
  → Music keeps playing! (slightly lower quality, but no interruption)

Back to good signal:
  → App switches back to 320 kbps
```

---

## The Stateless API Layer

### What Does "Stateless" Mean?

```
STATEFUL server (bad for scaling):
  Server A remembers: "User_42 is playing song_123 at 1:32"
  If Server A crashes, that information is LOST
  User_42 MUST reconnect to Server A specifically

STATELESS server (good for scaling):
  No server remembers anything about any user
  Each request carries ALL needed info (JWT token, song_id, etc.)
  If Server A crashes, Server B or C can handle the next request
  → Any server can handle any request!
```

### How Stateless Helps Scaling

```
Monday: 100K users → 5 API servers
Friday evening: 500K users → 25 API servers (auto-scale!)
3 AM Sunday: 20K users → 2 API servers (scale down, save money)

Load balancer just round-robins requests to any available server.
No sticky sessions needed. No session state to worry about.
```

### Resilience Patterns in the API Layer

**Circuit Breaker:**
```
API server → SQL database
Database overloaded (90% of queries timing out)

Without circuit breaker:
  → Every request waits 30 seconds, then times out
  → Users see a loading spinner forever

With circuit breaker:
  → After 10 failures in a row, circuit OPENS
  → Requests immediately return cached/default data
  → Every 30 seconds, try ONE real request
  → If it succeeds, circuit CLOSES (back to normal)
```

**Connection Pooling:**
```
Without pooling:
  Each request: open DB connection → query → close connection
  Opening a connection takes ~50ms (TCP handshake + auth)
  1000 requests/sec = 1000 × 50ms = 50 seconds of just connecting!

With pooling:
  Pre-open 50 database connections at startup
  Each request: borrow a connection → query → return to pool
  No connection overhead → queries complete in ~5ms
```

**Fallback Responses:**
```
Primary: Personalized "Discover Weekly" playlist (requires ML service)
ML service is down!

Fallback: "Top 50 Global" playlist (pre-cached, always available)
→ User still gets music, even if personalization is broken
```

---

## Client-Side Caching - Why Spotify Plays Songs Instantly

### Recently Played Cache

```
You played "Blinding Lights" 10 minutes ago.
You play it again.

Without client cache:
  → API call → signed URL → CDN download → play (~2 seconds)

With client cache:
  → Song already on your device's local storage
  → Play IMMEDIATELY (0 seconds, no network needed!)
```

### Offline Downloads (Premium)

```
Premium users:
  → Can download songs/playlists for offline playback
  → Songs stored in encrypted format on device
  → Works on airplane mode!
  → Encrypted so you can't copy files to another device
```

### Cache Eviction

```
Your phone has 2GB allocated for Spotify cache.
Cache is full. New song needs space.

Eviction strategy: LRU (Least Recently Used)
  → "Which song haven't I played in the longest time?"
  → Remove that song to make space for the new one
```

---

## Spotify vs YouTube Architecture Comparison

```
                    SPOTIFY                    YOUTUBE
Upload:       Simple (artist → S3)     Complex (pre-signed URL → S3 → transcode)
Transcoding:  3 bitrates (simple)      6+ resolutions × segments (complex)
Streaming:    Range requests            Segment-based (HLS/DASH manifest)
CDN:          Moderate load             Massive load (video = 100x audio size)
Search:       SQL + simple index        Elasticsearch + complex ranking
Progress:     Play/skip events          Continuous position tracking
Database:     SQL (metadata is tiny)    SQL + DynamoDB + Elasticsearch
Complexity:   Medium                    Very High
```

---

## Revision Flashcards

**Q: Why is audio storage the dominant cost, not metadata?**
A: 30M songs × 3 MB = 90 TB for audio. Metadata is only ~3 GB. Audio is 30,000x larger. Optimizing audio delivery/storage has the biggest impact.

**Q: What are signed URLs and why does Spotify use them?**
A: Temporary URLs that expire after a few hours. They allow secure access to S3-stored audio without exposing permanent URLs. If shared or stolen, they stop working after expiry.

**Q: What are HTTP range requests?**
A: Requests for specific byte ranges of a file ("give me bytes 0-50000"). Enables streaming without downloading the whole file. Also allows seeking to any position in the song.

**Q: What does "stateless API" mean for scaling?**
A: No server stores user session data. Any server can handle any request. This allows horizontal scaling (add/remove servers freely) and easy failover (if one server dies, others take over).

**Q: How does the circuit breaker pattern help?**
A: When a dependency (DB, ML service) is failing, stop sending requests to it (circuit opens). Return cached/default data instead. Periodically test if it's recovered. Prevents cascading failures.
