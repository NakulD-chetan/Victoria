# Window Functions — Common Mistakes

| Mistake | Note |
|---------|------|
| Using `WHERE` on window alias | Push to outer query |
| Wrong `ORDER BY` in OVER | Changes ranking / frame peers |
| Confusing default frame | Running sum not what you think — specify `ROWS` |
| `RANK` when need unique ids | Use `ROW_NUMBER` |

---

*Next: [[06_Edge-Cases]]*
