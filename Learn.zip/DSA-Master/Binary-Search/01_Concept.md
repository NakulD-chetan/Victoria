# Binary Search — Concept

## Binary Search is not just an algorithm — it's a **decision-making strategy**.

Instead of checking elements one by one, you:

- **Divide the search space in half**
- **Eliminate the impossible half**
- Repeat until the answer is found

Think of it like a phone book:

- Open the middle
- Decide direction (left or right)
- Ignore the rest

👉 Each step cuts the problem size by **50%**

```
Sorted Array: [2, 5, 8, 12, 16, 23, 38, 45]
Target: 23

Step 1: mid = 12  → 12 < 23  → discard left half [2,5,8]
Step 2: mid = 38  → 38 > 23  → discard right half [38,45]
Step 3: mid = 23  → found!

Search space: 8 → 4 → 2 → 1  (log₂(8) = 3 steps)
```

---

## Three Variants


| Variant                        | Purpose                 | Returns                              | Use Case                            |
| ------------------------------ | ----------------------- | ------------------------------------ | ----------------------------------- |
| **Exact match**                | Find target             | Index or -1                          | "Is X in array?"                    |
| **Lower bound (bisect_left)**  | First position ≥ target | Smallest index where arr[i] ≥ target | Insert position, count elements < X |
| **Upper bound (bisect_right)** | First position > target | Smallest index where arr[i] > target | Count elements ≤ X                  |


```
Array: [1, 2, 2, 2, 3, 4]
Target: 2

Exact match:     index 1, 2, or 3 (any occurrence)
bisect_left:     index 1 (first 2)
bisect_right:    index 4 (first element > 2)

Count of 2s = bisect_right(2) - bisect_left(2) = 4 - 1 = 3
```

---

## Binary Search on Answer (Parametric Search)

**The FAANG differentiator.** The array might not be sorted — but the **answer space** is monotonic(something moves in only one direction.

### The Key Insight

- Problem asks: "Find minimum X such that condition(X) is true"
- Or: "Find maximum X such that condition(X) is true"
- **Monotonicity:** If condition(5) is true, then condition(6), condition(7)... are true (or vice versa)

```
"Minimum capacity to ship packages in D days"
→ Can we ship with capacity X? (yes/no)
→ If capacity 10 works, capacity 11, 12, 13... all work
→ Binary search on X (the answer)!

  [F F F F T T T T T T]
   lo      mid      hi
   If works(mid): hi = mid (try smaller)
   Else:          lo = mid + 1 (need larger)
```

### Why It Catches Candidates Off Guard

- Problem doesn't say "sorted array"
- No obvious binary search structure
- Requires recognizing: "The answer has a boundary — everything below fails, everything above works"

---

## Why Brute Force O(n) Fails


| Approach              | What It Does                    | Time         | Problem                         |
| --------------------- | ------------------------------- | ------------ | ------------------------------- |
| Linear search         | Check each element sequentially | O(n)         | Wastes the sorted property      |
| Brute force on answer | Try every possible answer value | O(n × check) | Answer space can be huge (10^9) |
| Binary search         | Halve search space each step    | O(log n)     | Optimal — exploits structure    |


**The math:** n elements → log₂(n) steps. n = 10^6 → 20 comparisons vs 1,000,000.

---

## O(log n) Reasoning

```
Search space size: n
After 1 step:      n/2
After 2 steps:     n/4
After k steps:     n/2^k

When n/2^k = 1  →  k = log₂(n)

Each step: O(1) comparison
Total: O(log n)
```

---

## When NOT to Use Binary Search


| Scenario                               | Why Not                            | Use Instead                   |
| -------------------------------------- | ---------------------------------- | ----------------------------- |
| Array is unsorted                      | No monotonicity to exploit         | Sort first, or use hash map   |
| Need all occurrences                   | Binary search finds one            | Lower + upper bound for range |
| Answer space not monotonic             | Can't halve meaningfully           | DP, greedy, or brute force    |
| Need exact match in unsorted           | No structure                       | Linear search O(n)            |
| Problem asks for "pairs" or "triplets" | Different structure                | Two pointers, hash map        |
| Condition is not binary (yes/no)       | Can't decide which half to discard | Different approach            |


---

## Golden Rules

1. **Sorted array + find element → binary search**
2. **"Minimum X such that..." or "Maximum X such that..." → binary search on answer**
3. **Search space must be monotonic — one clear boundary**
4. **Always use `lo + (hi - lo) // 2` to avoid overflow**
5. **Decide: `lo = mid + 1` vs `hi = mid` — never both `mid` (infinite loop risk)**
6. **Lower bound = first ≥ ; Upper bound = first >**

---



