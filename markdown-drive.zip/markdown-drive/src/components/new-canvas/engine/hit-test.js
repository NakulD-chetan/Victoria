import { aabbOf, handlePositions } from './renderer';
import { worldPointsForLinear } from './binding-engine';

/**
 * Hit testing against world-space points.
 *
 * We do a cheap AABB reject first, then a shape-accurate second pass. Strokes
 * are tested against each segment with a small slop proportional to the
 * stroke width.
 */

export function elementContainsPoint(el, px, py) {
  if (el.isDeleted) return false;
  const [bx, by, bw, bh] = aabbOf(el);
  // AABB reject with a small slop for stroked shapes
  const slop = Math.max(2, (el.style?.strokeWidth || 2));
  if (px < bx - slop || px > bx + bw + slop) return false;
  if (py < by - slop || py > by + bh + slop) return false;

  switch (el.type) {
    case 'rect':
    case 'ellipse':
    case 'text':
    case 'callout':
    case 'widget':
      return true;
    case 'line':
    case 'arrow': {
      const points = worldPointsForLinear(el);
      for (let index = 1; index < points.length; index += 1) {
        if (pointNearSegment(
          px,
          py,
          points[index - 1].x,
          points[index - 1].y,
          points[index].x,
          points[index].y,
          slop + 3,
        )) return true;
      }
      return false;
    }
    case 'pen':
    case 'highlighter': {
      const pts = el.points;
      if (!pts || pts.length < 2) return false;
      const tol = Math.max(4, el.style.strokeWidth);
      for (let i = 1; i < pts.length; i++) {
        if (pointNearSegment(px, py, pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1], tol)) {
          return true;
        }
      }
      return false;
    }
    default:
      return false;
  }
}

export function elementIntersectsRect(el, rx, ry, rw, rh) {
  if (el.isDeleted) return false;
  const [bx, by, bw, bh] = aabbOf(el);
  if (bx > rx + rw || rx > bx + bw) return false;
  if (by > ry + rh || ry > by + bh) return false;
  return true;
}

export function topmostAt(elements, x, y) {
  for (let i = elements.length - 1; i >= 0; i--) {
    if (elementContainsPoint(elements[i], x, y)) return elements[i];
  }
  return null;
}

/** Returns handle role ('nw', 'e', …) if (px,py) hits a resize handle. */
export function hitResizeHandle(el, px, py, zoom) {
  const [bx, by, bw, bh] = aabbOf(el);
  const tol = 8 / zoom;
  for (const h of handlePositions(bx, by, bw, bh)) {
    if (Math.abs(h.x - px) <= tol && Math.abs(h.y - py) <= tol) return h.role;
  }
  return null;
}

function pointNearSegment(px, py, ax, ay, bx, by, tol) {
  const dx = bx - ax, dy = by - ay;
  const len2 = dx * dx + dy * dy;
  let t = 0;
  if (len2 > 0) t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / len2));
  const qx = ax + t * dx;
  const qy = ay + t * dy;
  const d2 = (px - qx) * (px - qx) + (py - qy) * (py - qy);
  return d2 <= tol * tol;
}

/**
 * Resize an element's AABB given a handle role and the current world mouse
 * point. Returns a patch { x, y, w, h, x2, y2 } appropriate for the element.
 */
export function resizeFromHandle(el, role, mx, my) {
  if (el.type === 'line' || el.type === 'arrow') {
    // treat NW/SE as the two endpoints
    if (role === 'nw' || role === 'n' || role === 'w') return { x: mx, y: my };
    return { x2: mx, y2: my };
  }
  let { x, y, w, h } = el;
  const right = x + w, bottom = y + h;
  if (role.includes('w')) { w = right - mx; x = mx; }
  if (role.includes('e')) { w = mx - x; }
  if (role.includes('n')) { h = bottom - my; y = my; }
  if (role.includes('s')) { h = my - y; }
  // prevent flip; clamp to a 4px world min
  if (w < 4) { w = 4; }
  if (h < 4) { h = 4; }
  return { x, y, w, h };
}

/** Translate a stroke's points by (dx, dy). */
export function translateElement(el, dx, dy) {
  if (el.type === 'pen' || el.type === 'highlighter') {
    return {
      ...el,
      x: el.x + dx, y: el.y + dy,
      points: el.points.map((p) => [p[0] + dx, p[1] + dy, p[2] ?? 0.5]),
    };
  }
  if (el.type === 'line' || el.type === 'arrow') {
    if (el.startBinding || el.endBinding) return el;
    return { ...el, x: el.x + dx, y: el.y + dy, x2: el.x2 + dx, y2: el.y2 + dy };
  }
  return { ...el, x: el.x + dx, y: el.y + dy };
}
