# Two Pointers — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Every problem builds pattern recognition for FAANG interviews.**

---

## 10 MUST-DO Problems (Start Here)


| #   | Problem                             | Difficulty | LC# | Concept Tag                  | Why Important                             |
| --- | ----------------------------------- | ---------- | --- | ---------------------------- | ----------------------------------------- |
| 1   | Two Sum II - Input Array Is Sorted  | Easy       | 167 | Opposite-direction, pair sum | Purest two-pointer problem — foundation   |
| 2   | 3Sum                                | Medium     | 15  | Three pointers, 3Sum pattern | Most-asked two-pointer at FAANG           |
| 3   | Container With Most Water           | Medium     | 11  | Opposite-direction, area     | Non-obvious two-pointer (width vs height) |
| 4   | Linked List Cycle                   | Easy       | 141 | Fast/slow                    | Classic cycle detection                   |
| 5   | Linked List Cycle II                | Medium     | 142 | Fast/slow, cycle start       | Tests cycle math (find start node)        |
| 6   | Valid Palindrome                    | Easy       | 125 | Opposite-direction, string   | Clean opposite-direction on string        |
| 7   | Sort Colors                         | Medium     | 75  | Dutch National Flag          | The partition template                    |
| 8   | Remove Duplicates from Sorted Array | Easy       | 26  | Read/write pointers          | In-place dedup foundation                 |
| 9   | Trapping Rain Water                 | Hard       | 42  | Two pointers / two passes    | Tests two-pointer from both ends          |
| 10  | 4Sum                                | Medium     | 18  | Four pointers, k-Sum         | Generalizes 3Sum pattern                  |


---

## Complete 30-Problem Progression

### Easy (Problems 1-8) — Build Foundation


| #   | Problem                             | LC# | Concept            | Key Skill                          |
| --- | ----------------------------------- | --- | ------------------ | ---------------------------------- |
| 1   | Two Sum II - Input Array Is Sorted  | 167 | Opposite-direction | Pair sum, move based on comparison |
| 2   | Valid Palindrome                    | 125 | Opposite-direction | Skip non-alnum, case-insensitive   |
| 3   | Remove Duplicates from Sorted Array | 26  | Read/write         | In-place dedup                     |
| 4   | Remove Element                      | 27  | Read/write         | In-place remove by value           |
| 5   | Merge Sorted Array                  | 88  | Two arrays         | Merge from end                     |
| 6   | Linked List Cycle                   | 141 | Fast/slow          | Cycle detection                    |
| 7   | Middle of the Linked List           | 876 | Fast/slow          | Fast at end → slow at middle       |
| 8   | Squares of a Sorted Array           | 977 | Opposite-direction | Largest abs at ends                |


### Medium (Problems 9-22) — Core FAANG Level


| #   | Problem                                | LC#     | Concept            | Key Skill                           |
| --- | -------------------------------------- | ------- | ------------------ | ----------------------------------- |
| 9   | 3Sum                                   | 15      | Three pointers     | Fix i, two-pointer, skip duplicates |
| 10  | Container With Most Water              | 11      | Opposite-direction | Move pointer at smaller height      |
| 11  | 3Sum Closest                           | 16      | Three pointers     | Track closest, not exact            |
| 12  | 4Sum                                   | 18      | Four pointers      | Reduce to 3Sum                      |
| 13  | Sort Colors                            | 75      | Dutch Flag         | Three regions, mid logic            |
| 14  | Linked List Cycle II                   | 142     | Fast/slow          | Find cycle start                    |
| 15  | Partition List                         | 86      | Partition          | Two dummy heads, concatenate        |
| 16  | Remove Nth Node From End of List       | 19      | Fast/slow          | Fast n steps ahead                  |
| 17  | Intersection of Two Sorted Arrays      | 349/350 | Two arrays         | One ptr per array                   |
| 18  | Move Zeroes                            | 283     | Partition          | Write pointer for non-zero          |
| 19  | Backspace String Compare               | 844     | Opposite-direction | Simulate backspace from end         |
| 20  | Remove Duplicates from Sorted Array II | 80      | Read/write         | Allow at most 2 dup, in-place       |
| 21  | Boats to Save People                   | 881     | Opposite-direction | Greedy pair heaviest + lightest     |
| 22  | Two Sum - Less Than Target             | 259     | Opposite-direction | Count pairs, not find one           |


### Hard (Problems 23-30) — Interview Differentiators


| #   | Problem                   | LC# | Concept                   | Key Skill                          |
| --- | ------------------------- | --- | ------------------------- | ---------------------------------- |
| 23  | Trapping Rain Water       | 42  | Two pointers / two passes | Max left, max right, min - height  |
| 24  | 3Sum Smaller              | 259 | Three pointers            | Count triplets, not enumerate      |
| 25  | Find the Duplicate Number | 287 | Fast/slow                 | Cycle in array (index as next)     |
| 26  | Palindrome Linked List    | 234 | Fast/slow + reverse       | Find middle, reverse half, compare |
| 27  | Palindrome Pairs          | 336 | Hash + two ptr            | Different pattern                  |
| 28  | First Missing Positive    | 41  | Index as hash + swap      | In-place, cycle sort               |
| 29  | Sort List                 | 148 | Merge sort + two ptr      | O(1) space merge sort              |
| 30  | Reverse Nodes in k-Group  | 25  | Multiple passes           | K-reverse with ptrs                |


---

## Problem-by-Problem Strategy Notes

### Problem 1: Two Sum II (LC 167)

```
Type: Opposite-direction
State: left=0, right=n-1
Key: sum > target → right--; sum < target → left++
Template: Template 1 (Opposite Pair)
One-liner: Converge from ends, move based on sum vs target.
```

### Problem 2: 3Sum (LC 15)

```
Type: Three pointers
State: Fix i, left=i+1, right=n-1
Key: Skip duplicate i; when match, skip duplicate left
Template: Template 3 (3Sum)
One-liner: For each i, two-pointer on [i+1..n]; skip dups.
```

### Problem 3: Container With Most Water (LC 11)

```
Type: Opposite-direction
State: left=0, right=n-1
Key: area = min(h[L],h[R]) * (R-L); move pointer at smaller height
Template: Opposite (custom)
One-liner: Move the shorter line inward — it can't form a better container.
```

### Problem 4: Linked List Cycle (LC 141)

```
Type: Fast/slow
State: slow=head, fast=head.next
Key: fast=2×slow; meet ⇒ cycle
Template: Template 2 (Fast/Slow)
One-liner: Fast and slow; if they meet, cycle exists.
```

### Problem 5: Linked List Cycle II (LC 142)

```
Type: Fast/slow + reset
State: After meet, reset slow=head; move both 1×
Key: They meet at cycle start
Template: Fast/Slow + phase 2
One-liner: After meet, reset slow to head; both step 1; meet at start.
```

### Problem 9: Sort Colors (LC 75)

```
Type: Dutch National Flag
State: low=0, mid=0, high=n-1
Key: 0→swap L,M; 1→M++; 2→swap M,H (no M++)
Template: Template 4 (Dutch Flag)
One-liner: Three regions; swap 2 with high, don't advance mid.
```

### Problem 23: Trapping Rain Water (LC 42)

```
Type: Two pointers from both ends
State: left=0, right=n-1; maxLeft, maxRight
Key: Water at i = min(maxLeft, maxRight) - height[i]
     Move pointer at smaller max (greedy)
Template: Custom two-pointer
One-liner: Track max from left and right; add water at min(maxL,maxR)-h.
```

---

## Pattern Distribution

```
OPPOSITE-DIRECTION:   12 problems  (1-3, 6, 8-12, 17, 19, 21-22)
FAST/SLOW:            6 problems  (4, 6-7, 14-16, 29)
PARTITION/READ-WRITE: 6 problems  (5, 13, 15, 18, 26, 28)
THREE+ POINTERS:      4 problems  (9, 11-12, 24)
TWO ARRAYS:           2 problems  (5, 17)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)

- Day 1: Problems 1-3 (Opposite-direction: Two Sum II, Palindrome, Remove Dup)
- Day 2: Problems 4-6 (Fast/slow: Cycle, Middle; Remove Element)
- Day 3: Problems 7-8 (Merge Sorted, Squares of Sorted)

### Week 2: Core (Days 4-7)

- Day 4: Problems 9-10 (3Sum, Container With Water)
- Day 5: Problems 11-13 (3Sum Closest, 4Sum, Sort Colors)
- Day 6: Problems 14-16 (Cycle II, Partition List, Remove Nth)
- Day 7: Problems 17-19 (Intersection, Move Zeros, Backspace Compare)

### Week 3: Advanced (Days 8-10)

- Day 8: Problems 20-22 (Product, Boats, Two Sum Less Than)
- Day 9: Problems 23-26 (Trapping Rain, 3Sum Smaller, Min Window, Concat)
- Day 10: Problems 27-30 (Palindrome Pairs, First Missing, Sort List, Reverse k-Group)

---

## Cross-Reference: Two Pointers vs Sliding Window

Some problems are often categorized under both. Clarification:


| Problem                   | Primary Pattern | Why                                    |
| ------------------------- | --------------- | -------------------------------------- |
| Trapping Rain Water       | Two Pointers    | Two ptrs from ends, or two-pass        |
| Container With Most Water | Two Pointers    | Opposite-direction converge            |
| Find Duplicate Number     | Two Pointers    | Fast/slow on array (index as next)     |
| Palindrome Linked List    | Two Pointers    | Fast/slow to find middle, then compare |


---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy, 14 Medium, 8 Hard)
MUST-DO:            LC 167, 15, 11, 141, 142, 125, 75, 26, 42, 18
TOP 3 MOST ASKED:   LC 15 (3Sum), LC 167 (Two Sum II), LC 11 (Container)
PATTERN SPLIT:      Opposite (12), Fast/Slow (6), Partition (6),
                    Three+ (4), Two Arrays (2)
STUDY ORDER:        Opposite → Fast/Slow → Partition → 3Sum/4Sum
INTERVIEW LINE:     "I've practiced opposite-direction, fast/slow,
                     Dutch flag, and 3Sum. I can identify the pattern
                     from sorted array, cycle, or in-place constraints."
```

