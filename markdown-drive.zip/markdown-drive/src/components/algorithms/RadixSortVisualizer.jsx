import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [];
  const max = Math.max(...a);
  for (let exp = 1; Math.floor(max / exp) > 0; exp *= 10) {
    const bkts = Array.from({ length: 10 }, () => []);
    for (let i = 0; i < a.length; i++) {
      const digit = Math.floor(a[i] / exp) % 10;
      bkts[digit].push(a[i]);
      steps.push({ type: 'distribute', idx: i, digit, exp, array: [...a], buckets: Object.fromEntries(bkts.map((b, k) => [k, [...b]])) });
    }
    let idx = 0;
    for (let d = 0; d < 10; d++) for (const v of bkts[d]) { a[idx++] = v; }
    steps.push({ type: 'collect', exp, array: [...a] });
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 16) { return Array.from({ length: n }, () => Math.floor(Math.random() * 200) + 1); }

export default function RadixSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements (radix sort)` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'distribute') {
      colors[step.idx] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `[${step.idx}]=${step.array[step.idx]} → bucket ${step.digit} (exp=${step.exp})` });
    } else if (step.type === 'collect') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: `Collected from buckets (digit exp=${step.exp})` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
