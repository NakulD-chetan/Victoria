# Primary Key and Foreign Key in Data Warehouse — Practice

> "Keys are contracts—break them and every dashboard argues with itself."

---

## Quick Recall

**Q: Typical PK on a dimension table?**  
A: Surrogate `dimension_key` unique and stable; natural business keys stored as attributes.

**Q: Typical FK on a fact table?**  
A: Surrogate keys referencing dimensions, plus optional degenerate business IDs.

**Q: Why not use source system PK alone on facts?**  
A: Source keys churn, merge, or reuse; warehouses need stability and integration across systems.

**Q: Should fact tables always declare a primary key?**  
A: Yes at the declared grain—often composite surrogate or single fact key—to enforce uniqueness in loading.

**Q: Referential integrity in the warehouse—enforced?**  
A: Often enforced logically in ETL; physical FKs optional depending on platform and load patterns.

---

## Interview Questions

**1. Difference between OLTP and DW thinking on keys.**  
Say: OLTP optimizes concurrent writes and tight constraints; DW optimizes analytic joins, surrogate stability, and late-arriving data while still enforcing grain uniqueness.

**2. Fact table PK at order-line grain.**  
Say: `fact_order_line_key` surrogate or composite (`order_id`, `line_id`) plus surrogate dimensions—prefer surrogate fact key for slowly changing contexts and deletes.

**3. Foreign key to date dimension—nullable?**  
Say: Policy-dependent; many teams use not-null with an unknown member row to avoid join loss.

**4. Role-playing FKs duplicate references?**  
Say: Multiple FK columns to the same `dim_date` are valid—each is a separate foreign key logically, same parent table physically.

**5. Handling orphaned facts in retail ETL.**  
Say: Route rows to quarantine with reason codes; do not insert `-1` keys silently without audit; reconcile with MDM for new stores or SKUs.

**6. Surrogate vs natural keys in joins.**  
Say: Join facts to dimensions on surrogate integers for performance; expose natural keys in dimensions for operational lookups.

**7. Platform note: clustered keys.**  
Say: On some engines, declare PK/clustering aligned to common filters (e.g., `order_date_key`) while keeping grain uniqueness.

**8. Composite natural key on a bridge table?**  
Say: For `bridge_order_coupon`, uniqueness is often `(order_id, coupon_code, applied_sequence)`; still add a surrogate `bridge_key` if facts reference the bridge row or if SCD applies to related dimensions.

---

## Scenario-Based Exercises

**Scenario 1 — Uniqueness constraint**  
Enforce one row per `(order_id, line_id)` per day partition in a hub fact.  
**Solution:** Use surrogate `fact_order_line_key` and a unique constraint on business grain columns if duplicates must be rejected, or merge logic in ETL.

**Scenario 2 — FK enforcement choice**  
Nightly batch loads with full dimension scd2 history.  
**Solution:** Stage load into temp tables, validate FK resolution, then insert facts with deferred constraints or post-load checks if physical FKs slow loads.

**Scenario 3 — SQL: detect orphan keys**

```sql
SELECT COUNT(*) AS orphan_lines
FROM dw.fact_order_line f
LEFT JOIN dw.dim_product p ON f.product_key = p.product_key
WHERE p.product_key IS NULL;
```

**Scenario 4 — Degenerate still part of PK?**  
`order_id` on fact without `dim_order`.  
**Solution:** Fact PK remains at line grain; degenerate `order_id` is not a FK but helps operational grouping; dimensional FKs still required for analytic context.

**Scenario 5 — Surrogate FK mismatch after SCD2**  
Facts loaded with `product_key` that was later expired.  
**Solution:** Keep immutable fact keys as loaded; do not restate history unless a governed correction project replays facts; for new loads, resolve `product_key` using transaction-time logic against `effective_start` and `effective_end`.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Reusing order_id as PK across systems | Collisions after M&A | Surrogate + crosswalk |
| No PK because "it's big data" | Silent duplicates | Enforce grain keys in pipeline |
| Physical FK on facts with truncate-reload | Load failures | Use soft RI or post-checks |
| Nullable dims everywhere | Wrong totals | Unknown members + policy |
| Same `store_key` reused after rebuild | Assumes stable meaning | Recycle policy + MDM ownership |

---

## One-Liner Answers

- Primary keys enforce the grain you promised for each table.
- Foreign keys connect facts to conformed dimension versions.
- Surrogate keys insulate the warehouse from operational key volatility.
- Referential integrity can be logical in ETL if physical FKs hurt loads.
- Always detect and handle orphan keys before publishing facts.
- Degenerate identifiers complement but do not replace dimensional keys.
- Document unknown and not-applicable dimension members with explicit keys.
