# CAP Theorem and Consistency — Question List

> **Permanent Recall:** Master the 10 MUST-DO CAP/consistency questions for FAANG interviews. The full list covers CAP analysis, consistency model selection, consensus protocols, conflict resolution, and edge cases. Use this as a checklist—each question tests specific concepts from the CAP-Theorem-Consistency notes.

---

## 10 MUST-DO CAP/Consistency Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | Explain CAP theorem. Why can you only pick 2? | Easy | CAP, partition, C vs A |
| 2 | Design a bank transfer system. What consistency? | Medium | Strong consistency, CP |
| 3 | Design Twitter feed. CP or AP? Why? | Medium | AP, eventual consistency |
| 4 | How does quorum ensure strong consistency? R+W>N | Medium | Quorum, overlap |
| 5 | What is PACELC? When does it apply? | Easy | PACELC, latency vs consistency |
| 6 | Compare Cassandra and HBase in terms of CAP | Medium | CP vs AP, use cases |
| 7 | How do you resolve conflicts in a multi-master system? | Medium | LWW, vector clocks, merge |
| 8 | Design a distributed lock. What consistency? | Medium | Linearizability, CP |
| 9 | What happens during a network partition in a CP system? | Easy | Partition behavior |
| 10 | Explain eventual consistency. When is it acceptable? | Easy | Eventual, use cases |

---

## Complete Question List (25+)

### CAP Analysis

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 11 | Is MongoDB CP or AP? Explain. | Easy | General |
| 12 | Is DynamoDB CP or AP? Can you get strong consistency? | Easy | Amazon |
| 13 | Why is partition tolerance unavoidable? | Easy | General |
| 14 | Design a system that handles partitions. CP vs AP choice. | Medium | FAANG |
| 15 | What's the difference between CA and CP during normal operation? | Easy | General |

### Consistency Model Selection

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 16 | Design an inventory system. Consistency? | Medium | E-commerce |
| 17 | Design a payment system. Consistency? | Medium | FinTech |
| 18 | Design a real-time collaborative document editor | Hard | Google, Figma |
| 19 | When would you use causal consistency? | Medium | General |
| 20 | Read-your-writes vs monotonic reads—difference and use cases | Medium | General |

### Consensus Protocols

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 21 | How does Raft achieve consensus? | Medium | General |
| 22 | What is split brain? How to prevent it? | Medium | General |
| 23 | Compare Paxos and Raft | Medium | General |
| 24 | How does ZooKeeper use Zab? | Hard | General |
| 25 | Design a leader election system | Medium | FAANG |

### Conflict Resolution & Edge Cases

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 26 | How does LWW work? What are the pitfalls? | Medium | General |
| 27 | What are CRDTs? When to use? | Hard | General |
| 28 | Handle clock skew in distributed systems | Medium | General |
| 29 | What happens when a partition heals and data diverged? | Medium | General |
| 30 | Design for read-your-writes after failover | Medium | FAANG |

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, definitions |
| **Medium** | Design choice, trade-offs, implementation |
| **Hard** | Deep dive, protocol details, edge cases |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **CAP** | 1, 9, 11, 12, 13, 14 |
| **PACELC** | 5 |
| **Strong consistency** | 2, 4, 8, 16, 17 |
| **Eventual consistency** | 3, 10 |
| **Causal** | 18, 19 |
| **Quorum** | 4 |
| **CP vs AP systems** | 6, 11, 12 |
| **Conflict resolution** | 7, 26, 27 |
| **Consensus** | 21, 22, 23, 24, 25 |
| **Edge cases** | 28, 29, 30 |

---

## Question Categories for Targeted Practice

| Category | Focus | Example Questions |
|----------|-------|-------------------|
| **Definitions** | CAP, PACELC, models | 1, 5, 10, 13 |
| **Design** | Choose consistency | 2, 3, 6, 8, 14, 16, 17 |
| **Mechanisms** | How it works | 4, 21, 22, 26 |
| **Trade-offs** | When to use what | 7, 19, 20 |
| **Edge cases** | Failures, conflicts | 9, 28, 29, 30 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can explain CAP in partition-centric terms
- [ ] Can justify CP vs AP for a given system
- [ ] Can explain PACELC
- [ ] Can explain quorum (R+W>N)
- [ ] Can compare consistency models
- [ ] Can discuss conflict resolution (LWW, merge)
- [ ] Can explain Raft at high level
- [ ] Can handle partition and failover edge cases

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: CAP explain, Bank, Twitter, Quorum, PACELC,
            Cassandra vs HBase, Conflicts, Lock, Partition, Eventual
FULL LIST: 30+ questions across CAP, consistency, consensus, conflicts
```

---

**Prev: [[07_Tricks-and-Recognition]]**
