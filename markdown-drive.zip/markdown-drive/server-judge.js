import {
  runSimulationTest,
  runStructuralCheck,
  runChaosTest,
} from './src/lib/problems/simulation.js';
import {
  COMPONENT_TYPES,
  CONNECTION_RULES,
} from './src/lib/problems/component-types.js';

const VALID_TYPES = Object.keys(COMPONENT_TYPES);
const MAX_COMPONENTS = 20;
const MAX_CONNECTIONS = 40;

const CONFIG_CLAMPS = {
  client:       { rps: [1, 200], concurrent: [1, 50], timeout: [100, 30000], retries: [0, 10] },
  cdn:          { hitRate: [0, 100], edgeLat: [1, 500], originLat: [10, 2000], regions: [1, 20], ttl: [1, 86400] },
  apigateway:   { authLat: [1, 500], rateLimit: [1, 10000], cbThreshold: [1, 100], timeout: [100, 30000] },
  ratelimiter:  { maxRps: [1, 10000], burstSize: [1, 1000], penaltyMs: [0, 10000] },
  loadbalancer: { maxConn: [1, 10000] },
  server:       { latency: [1, 2000], failRate: [0, 100], maxConcurrent: [1, 500], instances: [1, 50] },
  service:      { latency: [1, 2000], failRate: [0, 100], maxConcurrent: [1, 500], cbThreshold: [1, 100], cbRecoveryMs: [100, 60000], retries: [0, 10] },
  cache:        { hitRate: [0, 100], missLat: [1, 2000], ttl: [1, 86400], maxSize: [1, 100000] },
  database:     { queryTime: [1, 5000], poolSize: [1, 500], replLag: [0, 5000] },
  queue:        { processTime: [1, 10000], capacity: [1, 100000], consumers: [1, 100], batchSize: [1, 1000] },
};

function clamp(val, min, max) {
  if (typeof val !== 'number' || isNaN(val)) return min;
  return Math.max(min, Math.min(max, val));
}

function sanitizeComponent(comp) {
  if (!comp || typeof comp !== 'object') return null;
  if (!VALID_TYPES.includes(comp.type)) return null;

  const config = { ...(comp.config || {}) };
  const rules = CONFIG_CLAMPS[comp.type];
  if (rules) {
    for (const [key, [min, max]] of Object.entries(rules)) {
      if (key in config) config[key] = clamp(config[key], min, max);
    }
  }

  return {
    id: String(comp.id || ''),
    type: comp.type,
    x: typeof comp.x === 'number' ? comp.x : 0,
    y: typeof comp.y === 'number' ? comp.y : 0,
    config,
    _s: {},
  };
}

function sanitizeConnection(conn, validIds) {
  if (!conn || typeof conn !== 'object') return null;
  const from = String(conn.from || '');
  const to = String(conn.to || '');
  if (!validIds.has(from) || !validIds.has(to)) return null;
  if (from === to) return null;
  return { id: String(conn.id || ''), from, to };
}

function validateConnections(connections, components) {
  const compMap = new Map(components.map(c => [c.id, c]));
  return connections.filter(conn => {
    const fromComp = compMap.get(conn.from);
    const toComp = compMap.get(conn.to);
    if (!fromComp || !toComp) return false;
    const allowed = CONNECTION_RULES[fromComp.type] || [];
    return allowed.includes(toComp.type);
  });
}

export function sanitizeInput(rawComponents, rawConnections) {
  if (!Array.isArray(rawComponents) || !Array.isArray(rawConnections)) {
    return { error: 'components and connections must be arrays' };
  }
  if (rawComponents.length > MAX_COMPONENTS) {
    return { error: `Maximum ${MAX_COMPONENTS} components allowed` };
  }
  if (rawConnections.length > MAX_CONNECTIONS) {
    return { error: `Maximum ${MAX_CONNECTIONS} connections allowed` };
  }

  const components = rawComponents.map(sanitizeComponent).filter(Boolean);
  if (components.length === 0) {
    return { error: 'No valid components provided' };
  }

  const validIds = new Set(components.map(c => c.id));
  let connections = rawConnections.map(c => sanitizeConnection(c, validIds)).filter(Boolean);
  connections = validateConnections(connections, components);

  return { components, connections };
}

function evaluateSimTest(tc, simStats) {
  const rpsVal = tc.rps || 10;
  let passed;
  let failReason = null;

  if (simStats.done === 0) {
    passed = false;
    failReason = 'No requests completed successfully';
  } else if (rpsVal <= 10) {
    passed = simStats.failRate < 10 && simStats.rejectRate < 15;
    if (!passed) failReason = `failRate=${simStats.failRate.toFixed(1)}% (need <10%), rejectRate=${simStats.rejectRate.toFixed(1)}% (need <15%)`;
  } else if (rpsVal <= 50) {
    passed = simStats.rejectRate < 25 && simStats.avgLat < 500;
    if (!passed) failReason = `rejectRate=${simStats.rejectRate.toFixed(1)}% (need <25%), avgLat=${simStats.avgLat}ms (need <500ms)`;
  } else if (rpsVal <= 100) {
    passed = simStats.rejectRate < 35;
    if (!passed) failReason = `rejectRate=${simStats.rejectRate.toFixed(1)}% (need <35%)`;
  } else {
    passed = simStats.rejectRate < 60;
    if (!passed) failReason = `rejectRate=${simStats.rejectRate.toFixed(1)}% (need <60%)`;
  }

  return { passed, failReason };
}

export function judgeRun(problem, components, connections) {
  const results = [];

  problem.testCases.forEach((tc) => {
    if (tc.type !== 'simulation') {
      let passed = false;
      try { passed = runStructuralCheck(tc.name, components, connections); } catch { /* */ }
      results.push({
        name: tc.name,
        type: tc.type,
        passed,
        failReason: passed ? null : 'Required component or connection missing',
      });
    }
  });

  const simGroups = {};
  problem.testCases.forEach((tc) => {
    if (tc.type === 'simulation') {
      const key = String(tc.rps || 'default');
      if (!simGroups[key]) simGroups[key] = [];
      simGroups[key].push(tc);
    }
  });

  for (const [key, tcs] of Object.entries(simGroups)) {
    const rps = key === 'default' ? undefined : Number(key);
    let simStats;
    try {
      simStats = runSimulationTest(5000, rps, components, connections);
    } catch {
      simStats = { sent: 0, done: 0, failed: 0, rejected: 0, avgLat: Infinity, throughput: 0, failRate: 100, rejectRate: 100 };
    }

    for (const tc of tcs) {
      const { passed, failReason } = evaluateSimTest(tc, simStats);
      results.push({
        name: tc.name,
        type: tc.type,
        passed,
        rps: tc.rps,
        stats: {
          sent: simStats.sent,
          done: simStats.done,
          failed: simStats.failed,
          rejected: simStats.rejected,
          avgLat: simStats.avgLat === Infinity ? null : simStats.avgLat,
          throughput: Math.round(simStats.throughput),
          failRate: Math.round(simStats.failRate * 10) / 10,
          rejectRate: Math.round(simStats.rejectRate * 10) / 10,
        },
        failReason,
      });
    }
  }

  return results;
}

export function judgeChaos(problem, components, connections) {
  const scenarios = problem.chaosScenarios || problem.chaos_scenarios || [];
  if (!scenarios.length) return [];

  return scenarios.map((scenario) => {
    let result;
    try {
      result = runChaosTest(3000, scenario, components, connections);
    } catch {
      result = { survived: false, sent: 0, done: 0, failed: 0, rejected: 0, failRate: 100 };
    }
    return {
      label: scenario.label,
      type: scenario.type,
      survived: result.survived,
      stats: {
        sent: result.sent,
        done: result.done,
        failed: result.failed,
        rejected: result.rejected,
        failRate: Math.round(result.failRate * 10) / 10,
      },
    };
  });
}

export function scoreDeepDive(problem, userAnswers) {
  const questions = problem.deepDiveQuestions || problem.deep_dive_questions || [];
  if (!questions.length) return { score: 0, results: [] };

  const answers = userAnswers || {};
  let earned = 0;
  const results = [];

  questions.forEach((q, idx) => {
    const userAns = answers[idx] || answers[String(idx)] || [];
    const correct = q.correct || [];
    const allCorrect = correct.every(c => userAns.includes(c));
    const noExtra = userAns.every(a => correct.includes(a));

    let qScore = 0;
    if (allCorrect && noExtra) qScore = 1;
    else if (userAns.length > 0 && userAns.some(a => correct.includes(a))) qScore = 0.5;
    earned += qScore;

    results.push({
      question: q.question,
      userAnswer: userAns,
      correct: q.correct,
      explanation: q.explanation,
      score: qScore,
    });
  });

  return {
    score: Math.round((earned / questions.length) * 100),
    results,
  };
}

export function computeFullScore(testResults, chaosResults, deepDiveResult, hintsUsed) {
  const structural = testResults.filter(t => t.type !== 'simulation');
  const simulation = testResults.filter(t => t.type === 'simulation');

  const structPassed = structural.filter(t => t.passed).length;
  const simPassed = simulation.filter(t => t.passed).length;

  const structPct = structural.length > 0 ? Math.round((structPassed / structural.length) * 100) : 0;
  const simPct = simulation.length > 0 ? Math.round((simPassed / simulation.length) * 100) : 0;

  let chaosPct = 100;
  if (chaosResults.length > 0) {
    const survived = chaosResults.filter(r => r.survived).length;
    chaosPct = Math.round((survived / chaosResults.length) * 100);
  }

  const archScore = Math.round(structPct * 0.4 + simPct * 0.4 + chaosPct * 0.2);

  const archWeight = 70;
  const deepDiveWeight = 30;
  const hintPenalty = (hintsUsed || 0) * 5;

  const raw = (archScore / 100) * archWeight + (deepDiveResult.score / 100) * deepDiveWeight;
  const totalScore = Math.max(0, Math.round(raw - hintPenalty));

  const allTestsPassed = testResults.every(t => t.passed);

  let verdict;
  if (allTestsPassed && chaosPct >= 50 && totalScore >= 90) verdict = 'Strong Hire';
  else if (allTestsPassed && totalScore >= 70) verdict = 'Hire';
  else if (totalScore >= 50) verdict = 'Lean Hire';
  else verdict = 'Needs Practice';

  const accepted = allTestsPassed && chaosPct >= 50;

  return {
    archScore,
    deepDiveScore: deepDiveResult.score,
    totalScore,
    verdict,
    accepted,
    breakdown: { structPct, simPct, chaosPct, hintPenalty },
  };
}
