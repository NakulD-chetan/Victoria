# Queue — Common Mistakes

> **Avoid these pitfalls in interviews. Each mistake has cost candidates at FAANG.**

---

## 1. BFS: Not Tracking Visited Nodes → Infinite Loop

### Mistake

```python
# WRONG — no visited set
def bfs_wrong(start, graph):
    queue = deque([start])
    while queue:
        node = queue.popleft()
        for neighbor in graph[node]:
            queue.append(neighbor)  # Re-adds already processed nodes!
```

**Problem:** In a graph with cycles, the same node gets re-added infinitely. Queue never empties.

### Fix

```python
def bfs_correct(start, graph):
    queue = deque([start])
    visited = {start}
    while queue:
        node = queue.popleft()
        for neighbor in graph[node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
```

### When Visited Isn't Needed

- **Tree:** No cycles — no need for visited (but doesn't hurt)
- **DAG with explicit "no revisit":** Sometimes implicit
- **Grid with modification:** Modifying cell can replace visited (e.g., mark as wall)

---

## 2. Wrong Level Tracking in Level-Order BFS

### Mistake

```python
# WRONG — level_size changes during loop!
while queue:
    for i in range(len(queue)):  # BAD: len(queue) changes as we pop!
        node = queue.popleft()
        # ...
        queue.append(child)
```

**Problem:** `len(queue)` is re-evaluated each iteration. As we pop and append, the loop runs wrong number of times.

### Fix

```python
while queue:
    level_size = len(queue)  # Snapshot BEFORE the loop
    for _ in range(level_size):
        node = queue.popleft()
        # ...
        queue.append(child)
```

---

## 3. Deque Direction Confusion

### Mistake: Pop from Wrong End

```
Sliding window MAX — monotonic DECREASING
  - New element: pop from BACK (smaller elements)
  - Out of window: pop from FRONT (old index)

WRONG: Pop from front for "maintain order" → breaks invariant
WRONG: Pop from back for "out of window" → wrong elements removed
```

### Correct Mapping

| Operation | End | Why |
|-----------|-----|-----|
| Remove out-of-window | **Front** | Oldest (leftmost) index |
| Maintain monotonic (kick smaller) | **Back** | New element goes at back |
| Get max/min | **Front** | Front = extremum |

### Visual

```
Deque:  [front] ... [back]
        ↑              ↑
     max (for decr)   where we add new
     min (for incr)

Out of window: front index too small → popleft
New element kicks smaller: back has smaller → pop from back
```

---

## 4. Not Using Deque Efficiently

### Mistake: Using List as Queue in Python

```python
# WRONG — list.pop(0) is O(n)!
queue = []
queue.append(x)      # O(1)
y = queue.pop(0)     # O(n) — shifts all elements!
```

**Impact:** BFS becomes O(V²) instead of O(V+E).

### Fix

```python
from collections import deque
queue = deque()
queue.append(x)       # O(1)
y = queue.popleft()   # O(1)
```

### C++ Note

- `std::queue` — good for BFS (uses deque internally)
- `std::deque` — when you need both ends (sliding window)

---

## 5. Circular Queue: Off-by-One Errors

### Mistake: Confusing Empty vs Full

```python
# WRONG — both empty and full can have front == rear
# Need to track size or use (rear+1) % k == front for full
```

### Correct Approach

- **Option A:** Track `size` — empty when size==0, full when size==k
- **Option B:** Use (rear+1) % k == front for full, but then you waste one slot

---

## 6. Monotonic Deque: Wrong Comparison for Min vs Max

### Mistake

```python
# For SLIDING WINDOW MAX — need DECREASING
while dq and arr[dq[-1]] < arr[i]:  # Correct: kick smaller
    dq.pop()

# WRONG for max:
while dq and arr[dq[-1]] > arr[i]:  # This is for MIN!
    dq.pop()
```

| Goal | Deque Order | Pop Condition (from back) |
|------|-------------|---------------------------|
| Max | Decreasing | `arr[back] < arr[i]` |
| Min | Increasing | `arr[back] > arr[i]` |

---

## 7. Forgetting to Add Start to Visited

### Mistake

```python
queue = deque([start])
visited = set()  # WRONG: start not in visited!
while queue:
    node = queue.popleft()
    visited.add(node)  # Too late — we might have already re-added start
```

### Fix

```python
visited = {start}
queue = deque([start])
```

---

## 8. Queue vs Stack for "Implement X using Y"

### Queue Using Stacks

- **Push:** Always to `in_stack`
- **Pop/Peek:** Move from `in_stack` to `out_stack` when `out_stack` empty
- **Order:** Reversing twice = same order (FIFO)

### Stack Using Queues

- **Pop:** Rotate n-1 elements to back, then pop front
- **Alternative:** Push O(n) — push new, then rotate all previous to back

---

## Quick Checklist Before Submitting

- [ ] Visited set for BFS on graph?
- [ ] `level_size = len(queue)` before level loop?
- [ ] Using `deque` and `popleft()` in Python?
- [ ] Deque: front = out-of-window, back = monotonic maintain?
- [ ] Max → decreasing, Min → increasing?
- [ ] Start node in visited before BFS loop?

---

## FINAL MEMORY COMPRESSION BLOCK

```
BFS:        visited set ALWAYS (except tree); add start before loop
LEVEL:      level_size = len(q) BEFORE for-loop
DEQUE:      front=out-of-window, back=monotonic; max=decr, min=incr
PYTHON:     deque, popleft() — never list.pop(0)
CIRCULAR:   track size for empty/full
```
