# 03 — ORC Deep Dive

> ORC (Optimized Row Columnar) is a **columnar** format designed for **Hive** with **built-in three-level indexes**, **bloom filters**, and **native ACID** support — offering the best compression ratios and the tightest integration with the Hadoop/Hive ecosystem.

---

Delta Lake solves these by adding:A transactional layer + table management system over Parquet.

- **ACID transactions** (like a database)
- **Schema enforcement and evolution**
- **Time travel** (query old versions of data)
- **Efficient updates and deletes**
- **Streaming + batch unification**

## 1. What Is ORC and Why It Exists Alongside Parquet

ORC and Parquet are both columnar formats, but they came from different ecosystems and optimize for different priorities.


| Dimension             | ORC                                           | Parquet                                |
| --------------------- | --------------------------------------------- | -------------------------------------- |
| **Origin**            | Hortonworks (Hive-focused)                    | Twitter + Cloudera (cross-engine)      |
| **Primary engine**    | Hive, Presto                                  | Spark, Presto, Trino, Athena, BigQuery |
| **ACID support**      | Native in Hive 3.x                            | No (requires Delta Lake / Iceberg)     |
| **Compression**       | Typically 10–30% better than Parquet          | Excellent, but slightly larger         |
| **Indexing**          | Three levels (file → stripe → 10K row groups) | Two levels (file footer → row group)   |
| **Bloom filters**     | Native support                                | Limited support                        |
| **Ecosystem breadth** | Narrower (Hive-centric)                       | Much wider (industry standard)         |


**How to explain it:** "ORC is technically superior in compression and indexing depth, but Parquet won the ecosystem battle — it's supported everywhere. ORC is the best choice when Hive is your primary query engine."

---

## 2. ORC File Internal Structure

```
┌──────────────────────────────────────────────────┐
│                  ORC FILE                         │
│                                                    │
│  ┌──────────── Stripe 1 (64 MB default) ──────┐  │
│  │                                              │  │
│  │  ┌─ Index Data ────────────────────────┐    │  │
│  │  │  Min/max per column per 10K rows     │    │  │
│  │  │  Row positions for skip              │    │  │
│  │  │  Bloom filters (if enabled)          │    │  │
│  │  └─────────────────────────────────────┘    │  │
│  │                                              │  │
│  │  ┌─ Row Data ──────────────────────────┐    │  │
│  │  │  Column 1: encoded + compressed      │    │  │
│  │  │  Column 2: encoded + compressed      │    │  │
│  │  │  Column 3: encoded + compressed      │    │  │
│  │  └─────────────────────────────────────┘    │  │
│  │                                              │  │
│  │  ┌─ Stripe Footer ────────────────────┐    │  │
│  │  │  Column encoding info               │    │  │
│  │  │  Stream positions and sizes          │    │  │
│  │  └─────────────────────────────────────┘    │  │
│  │                                              │  │
│  └──────────────────────────────────────────────┘  │
│                                                    │
│  ┌──────────── Stripe 2 ─────────────────────┐    │
│  │  (same structure)                          │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────── FILE FOOTER ──────────────────┐    │
│  │  Schema (column names, types)              │    │
│  │  Stripe metadata (offset, length, rows)    │    │
│  │  Column statistics (min, max, sum, count)  │    │
│  │  Row count                                 │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────── POSTSCRIPT ───────────────────┐    │
│  │  Footer length, compression type, version  │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
└────────────────────────────────────────────────────┘
```

### ORC Read Flow

1. Read **Postscript** (last bytes) — learn footer size and compression type
2. Read **File Footer** — get schema, stripe metadata, file-level statistics
3. Check file-level statistics — can we skip the entire file?
4. For each stripe, check stripe-level statistics — skip irrelevant stripes
5. Within selected stripes, check row-group index — skip irrelevant 10K-row groups
6. Read only required column streams from surviving row groups

### ORC vs Parquet Structure Mapping


| ORC Term          | Parquet Equivalent    | Size                      | Key Difference                                   |
| ----------------- | --------------------- | ------------------------- | ------------------------------------------------ |
| **Stripe**        | Row Group             | 64 MB default (vs 128 MB) | ORC has smaller default → more granular skipping |
| **Index Data**    | Footer statistics     | Per 10K rows              | ORC indexes at finer granularity than Parquet    |
| **Row Data**      | Column Chunks + Pages | Compressed columns        | Similar concept                                  |
| **Stripe Footer** | Column metadata       | Encoding + offsets        | Similar concept                                  |
| **File Footer**   | File Footer           | Schema + stats            | Similar, but ORC also has sum and has Postscript |


---

## 3. Three-Level Indexing — ORC's Biggest Advantage

This is ORC's key differentiator over Parquet. ORC can skip data at **three levels** of granularity.

```
Level 1: FILE-LEVEL statistics (in File Footer)
  → "Column 'amount' across entire file: min=1, max=99999"
  → If filter is amount > 100000 → skip the ENTIRE FILE

Level 2: STRIPE-LEVEL statistics (in File Footer per stripe)
  → "Column 'amount' in Stripe 3: min=5000, max=8000"
  → Skip specific stripes that can't match the filter

Level 3: ROW-GROUP INDEX (in Index Data, every 10,000 rows)
  → "Rows 20001-30000 of Stripe 3: amount min=6000, max=7500"
  → Skip within a stripe at 10K-row granularity
```

**Parquet comparison:** Parquet indexes at **two levels** — file footer (row group level) and page level (Parquet 2.0+). ORC's 10K-row index within stripes provides finer-grained skipping, especially for large stripes.

---

## 4. Bloom Filters

Bloom filters solve a specific problem that min/max statistics cannot: **equality lookups on high-cardinality columns**.


| Aspect              | Detail                                                                               |
| ------------------- | ------------------------------------------------------------------------------------ |
| **What**            | Probabilistic data structure that answers "is value X **possibly** in this stripe?"  |
| **False positives** | May say "yes" when value isn't there (reads extra data — minor cost)                 |
| **False negatives** | **Never** says "no" when value IS there (never misses data — correctness guaranteed) |
| **Use case**        | Equality filters on high-cardinality columns: `WHERE user_id = 'U12345'`             |


### Why Min/Max Alone Isn't Enough

```
Query: WHERE user_id = 'U12345'

Without bloom filter:
  Stripe has user_id min='U00001', max='U99999'
  Min/max check: 'U12345' is within range → MUST READ the stripe
  But U12345 might not actually be in this stripe → wasted I/O

With bloom filter:
  Check bloom filter: "Is U12345 in this stripe?" → "NO" → SKIP entirely
  Saves reading 64 MB per skipped stripe
```

```sql
-- Enable bloom filter on a column in Hive
CREATE TABLE orders (
    order_id STRING,
    amount DECIMAL(10,2)
) STORED AS ORC
TBLPROPERTIES (
    "orc.bloom.filter.columns" = "order_id",
    "orc.bloom.filter.fpp" = "0.01"   -- false positive probability 1%
);
```

**Deep concept — FPP trade-off:** Lower FPP (false positive probability) means more accurate filtering but larger bloom filter data stored per stripe. 0.01 (1%) is a good default — it means 1 in 100 stripes might be read unnecessarily, but the bloom filter itself stays small.

---

## 5. ORC Encoding Types


| Encoding               | How It Works                               | Used For                                      |
| ---------------------- | ------------------------------------------ | --------------------------------------------- |
| **Dictionary**         | Unique values dictionary + integer indices | Low-cardinality strings (status, country)     |
| **Run-Length (RLEv2)** | Value + repeat count, optimized version 2  | Sorted integers, booleans, repetition lengths |
| **Direct**             | Raw values with no encoding                | High-cardinality when dictionary is too large |
| **Delta**              | Differences between consecutive values     | Timestamps, auto-increment IDs                |
| **Patched Base**       | Base value + patches for outliers          | Mostly-similar integers with a few outliers   |


**Patched Base is unique to ORC** — it handles the common case where most values in a column are close together but a few outliers exist. Instead of storing all values as full integers, it stores a base + small differences for most values and full patches for outliers. This gives better compression than plain delta encoding for real-world data.

---

## 6. ORC ACID Transactions (Hive 3.x)

ORC is the **only** open file format with **native** ACID support built into the format itself, without needing a separate table format layer like Delta Lake.

### How ACID Works

```
Base file: orders_000000 (original data — full ORC file)
    │
    ├── delta_0000001      (INSERT batch 1 — new rows)
    ├── delta_0000002      (INSERT batch 2 — new rows)
    ├── delete_delta_0000003  (DELETE batch — marks rows as deleted)
    │
    └── Compaction (periodic background merge):
         Minor compaction: merge deltas → fewer delta files
         Major compaction: merge base + all deltas → new clean base file
```


| Operation      | How It Works                                                               |
| -------------- | -------------------------------------------------------------------------- |
| **INSERT**     | New delta file with inserted rows                                          |
| **UPDATE**     | Delete old row (delete_delta) + insert new row (delta) — copy-on-write     |
| **DELETE**     | delete_delta file that marks specific rows as deleted                      |
| **Read**       | Base + all deltas + all delete_deltas merged at query time                 |
| **Compaction** | Background process merges everything into fewer files for read performance |


**Deep concept — Minor vs Major Compaction:**
Minor compaction merges delta files together into fewer delta files — fast, but doesn't touch the base. Major compaction merges the base file + all deltas into a new base file — slower, but produces the most efficient read layout. In practice, you run minor compaction frequently and major compaction periodically.

---

## 7. ORC in Spark

```python
# Read ORC
df = spark.read.format("orc").load("data/orders_orc/")

# Write as ORC with compression
df.write.format("orc") \
    .option("compression", "zlib") \
    .save("output/orders/")

# Enable bloom filter columns via Spark config
spark.conf.set("orc.bloom.filter.columns", "order_id,customer_id")
```

### ORC Spark Configuration


| Config                               | Default    | Purpose                                           |
| ------------------------------------ | ---------- | ------------------------------------------------- |
| `spark.sql.orc.compression.codec`    | `snappy`   | Compression codec: snappy, zlib, lzo, zstd, none  |
| `spark.sql.orc.filterPushdown`       | `true`     | Enable/disable predicate pushdown                 |
| `spark.sql.orc.mergeSchema`          | `false`    | Merge schemas across ORC files                    |
| `spark.sql.hive.convertMetastoreOrc` | `true`     | Use Spark's ORC reader instead of Hive's (faster) |
| `orc.bloom.filter.columns`           | none       | Comma-separated column names for bloom filters    |
| `orc.bloom.filter.fpp`               | `0.05`     | False positive probability for bloom filters      |
| `orc.stripe.size`                    | `67108864` | Stripe size in bytes (64 MB)                      |
| `orc.compress.size`                  | `262144`   | Compression chunk size (256 KB)                   |


### ORC Compression Options


| Codec      | Ratio                          | Speed       | When to Use                   |
| ---------- | ------------------------------ | ----------- | ----------------------------- |
| **Zlib**   | High (default for ORC in Hive) | Slower      | Storage-optimized workloads   |
| **Snappy** | Medium (default in Spark)      | Fast        | Query-heavy workloads         |
| **Zstd**   | High                           | Fast-Medium | Modern default (best balance) |
| **LZO**    | Medium                         | Fast        | Legacy Hadoop clusters        |
| **None**   | 1x                             | Fastest     | When CPU is the bottleneck    |


### ORC Write Modes

Same as Parquet — `errorifexists` (default), `overwrite`, `append`, `ignore`.

```python
df.write.format("orc") \
    .mode("overwrite") \
    .option("compression", "zstd") \
    .partitionBy("date") \
    .save("output/orders/")
```

---

## 8. When to Choose ORC vs Parquet


| Choose ORC When                      | Choose Parquet When                 |
| ------------------------------------ | ----------------------------------- |
| Hive is your primary query engine    | Spark is your primary engine        |
| Need native ACID without Delta Lake  | Using Delta Lake or Iceberg         |
| Maximum compression is the priority  | Broader ecosystem support needed    |
| Need bloom filters for point lookups | Standard analytics workload         |
| Existing Hadoop/Hive infrastructure  | New cloud-native project            |
| Presto/Trino on Hive tables          | BigQuery, Snowflake, Athena, DuckDB |


---

## 9. Interview Questions & How to Answer

**Q: "ORC vs Parquet — when would you choose each?"**

> ORC has better compression (10–30% smaller), three-level indexing (file → stripe → 10K rows vs Parquet's two levels), native bloom filters, and built-in ACID in Hive. Parquet has a much wider ecosystem — it's the default in Spark, supported by every cloud analytics engine. Choose ORC for Hive-heavy shops. Choose Parquet for everything else.

**Q: "What is a stripe in ORC?"**

> A stripe is ORC's equivalent of a Parquet row group — a horizontal slice of data, 64 MB by default. Each stripe has three sections: Index Data (per-column min/max/bloom filters every 10K rows), Row Data (actual column values, encoded and compressed), and Stripe Footer (encoding and offset metadata).

**Q: "How does ORC indexing work?"**

> ORC indexes at three levels. Level 1: file-level statistics in the file footer — can skip the entire file. Level 2: stripe-level statistics — skip individual stripes. Level 3: row-group index every 10K rows within a stripe — skip sub-stripe sections. This gives finer-grained data skipping than Parquet.

**Q: "What are bloom filters and why does ORC use them?"**

> Bloom filters are probabilistic data structures that quickly check if a value exists in a stripe. Min/max stats can't help for equality filters on high-cardinality columns — if user_id ranges from U00001 to U99999, min/max says every stripe might contain U12345. A bloom filter can definitively say "NO, this stripe does not contain U12345" and skip it. False positives are possible (small cost), but false negatives never happen (correctness guaranteed).

**Q: "How does ORC ACID work?"**

> ORC ACID uses base files + delta files + delete_delta files. Inserts create delta files. Updates are delete + insert (copy-on-write). Deletes create delete_delta files. Reads merge all layers at query time. Compaction (minor and major) periodically consolidates files for performance.

---

## Key Takeaways

1. **ORC** = columnar format optimized for **Hive** with **three-level indexing** and **native ACID**.
2. **Structure:** Stripes (64 MB) → Index Data + Row Data + Stripe Footer. File Footer + Postscript at end.
3. **Three-level index** (file → stripe → 10K row groups) provides finer-grained data skipping than Parquet's two levels.
4. **Bloom filters** enable efficient equality lookups on high-cardinality columns where min/max stats fail.
5. **ACID** via base + delta + delete_delta files with minor/major compaction — unique among raw file formats.
6. **10–30% better compression** than Parquet, but **narrower ecosystem** support.
7. **Patched Base encoding** is unique to ORC — handles outliers in mostly-uniform integer columns.
8. **Use ORC** for Hive-centric environments. **Use Parquet** for Spark, cloud, and modern stack.

---

