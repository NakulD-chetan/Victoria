import { useEffect, useRef } from 'react';
import { useAlgorithmStore } from '../../stores/algorithm-store';

function syntaxHL(text, lang) {
  let s = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  if (!s.trim()) return '&nbsp;';
  if (lang === 'python') {
    s = s.replace(/(#.*)$/, '<span class="dc-kw-comment">$1</span>');
    s = s.replace(/\b(import|class|def|if|elif|else|return|self|True|False|None|min|max|for|in|with)\b/g, '<span class="dc-kw">$1</span>');
  } else if (lang === 'java') {
    s = s.replace(/(\/\/.*)$/, '<span class="dc-kw-comment">$1</span>');
    s = s.replace(/\b(import|public|private|class|void|boolean|double|int|if|else|return|true|false|new|this|final|try|finally)\b/g, '<span class="dc-kw">$1</span>');
  } else {
    s = s.replace(/(\/\/.*)$/, '<span class="dc-kw-comment">$1</span>');
    s = s.replace(/(#include\s+&lt;\w+&gt;)/g, '<span class="dc-kw-comment">$1</span>');
    s = s.replace(/\b(class|public|void|bool|double|int|auto|if|else|return|true|false|using|namespace|const|for|std)\b/g, '<span class="dc-kw">$1</span>');
  }
  return s;
}

export default function CodePanel({ code, activeStep, languages, storeFn }) {
  const useStore = storeFn || useAlgorithmStore;
  const currentLang = useStore((s) => s.currentLang);
  const setLang = useStore((s) => s.setLang);
  const codeBlockRef = useRef(null);
  const lines = code[currentLang] || [];

  useEffect(() => {
    if (!activeStep || !codeBlockRef.current) return;
    const el = codeBlockRef.current.querySelector('.dc-code-line--active, .dc-code-line--green, .dc-code-line--red');
    if (el) {
      const container = codeBlockRef.current;
      const elTop = el.offsetTop;
      const elBottom = elTop + el.offsetHeight;
      const viewTop = container.scrollTop;
      const viewBottom = viewTop + container.clientHeight;
      if (elTop < viewTop) container.scrollTop = elTop;
      else if (elBottom > viewBottom) container.scrollTop = elBottom - container.clientHeight;
    }
  }, [activeStep]);

  return (
    <div className="dc-code-panel">
      <div className="dc-code-panel__header">
        <span className="dc-section-label">Live Code</span>
        <div className="dc-lang-tabs">
          {languages.map((lang) => (
            <button
              key={lang}
              onClick={() => setLang(lang)}
              className={`dc-lang-tab ${currentLang === lang ? 'dc-lang-tab--active' : ''}`}
            >
              {lang === 'cpp' ? 'C++' : lang.charAt(0).toUpperCase() + lang.slice(1)}
            </button>
          ))}
        </div>
      </div>
      <div ref={codeBlockRef} className="dc-code-block">
        {lines.map((line, i) => {
          const isActive = activeStep && line.step === activeStep;
          const cls = isActive
            ? line.step === 'route' || line.step === 'allow' ? 'dc-code-line--green'
            : line.step === 'deny' ? 'dc-code-line--red'
            : 'dc-code-line--active'
            : '';
          return (
            <div key={i} className={`dc-code-line ${cls}`}>
              <span className="dc-code-line__num">{i + 1}</span>
              <span className="dc-code-line__text" dangerouslySetInnerHTML={{ __html: syntaxHL(line.text, currentLang) }} />
            </div>
          );
        })}
      </div>
    </div>
  );
}
