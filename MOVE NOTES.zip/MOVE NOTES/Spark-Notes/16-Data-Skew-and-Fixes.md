# Data Skew and How to Fix It

Data skew is the **#1 real-world Spark performance problem**. If you've ever seen a job stuck at "199/200 tasks complete," that's data skew.

---

## What Is Data Skew?

Data skew occurs when one or a few keys hold a **disproportionately large** amount of data.

During wide transformations like `groupBy` or `join`, Spark shuffles data by key. If one key has millions of rows while others have hundreds, **one partition gets overloaded**.

### Visual

```
Balanced (no skew):
  Partition 0: ████████  (1000 rows)
  Partition 1: ████████  (1000 rows)
  Partition 2: ████████  (1000 rows)

Skewed:
  Partition 0: ████████████████████████████████████████  (100,000 rows)
  Partition 1: ██  (500 rows)
  Partition 2: ██  (500 rows)
```

### What Happens
- The task processing the skewed partition runs **10–100x longer** than others
- You see "199/200 tasks complete" — one task is stuck
- The overloaded executor may run out of memory (OOM)
- The entire job waits for that one slow task
- SLA breaches, wasted cluster time

---

## How to Detect Skew

1. **Spark UI → Stage Details**: Look for tasks with much higher "Duration" or "Shuffle Read Size" than others
2. **Spark UI → Task Metrics**: One task processes significantly more data
3. **Symptoms**: Job stuck at N-1/N tasks completed for a long time

---

## How to Fix Data Skew

### Fix 1: Broadcast Join (Simplest — When One Table Is Small)

If one table is small enough (< 2 GB practically):

```python
from pyspark.sql.functions import broadcast
result = df_large.join(broadcast(df_small), "customer_id")
```

**Why it works**: No shuffle happens at all — the small table goes to every executor. So there's no partition-based distribution that can be skewed.

**Best for**: Small-large table joins.

### Fix 2: Salting (Best for Heavy Skew)

For extreme skew where one key dominates:

**The idea**: Break the hot key into multiple keys by adding a random "salt."

```python
import random
from pyspark.sql.functions import concat, lit, rand, col

num_salts = 10

# Add random salt to the large (skewed) DataFrame
df_large_salted = df_large.withColumn(
    "salted_key",
    concat(col("key"), lit("_"), (rand() * num_salts).cast("int"))
)

# Explode the small DataFrame to match all possible salts
from pyspark.sql.functions import explode, array
df_small_exploded = df_small.crossJoin(
    spark.range(num_salts).withColumnRenamed("id", "salt")
).withColumn(
    "salted_key",
    concat(col("key"), lit("_"), col("salt"))
)

# Join on salted key — now the hot key is split across 10 partitions
result = df_large_salted.join(df_small_exploded, "salted_key")

# Drop the salt columns
result = result.drop("salted_key", "salt")
```

**Why it works**: A key with 1 million rows gets split into 10 partitions of 100K rows each. No single partition is overloaded.

**Best for**: Heavy skew on specific keys in large-large joins.

### Fix 3: Repartition (Moderate Skew Only)

```python
df = df.repartition(200, col("key"))
```

**Why it helps**: Spreads data across more partitions.

**Limitation**: The skewed key still goes to ONE partition (because `hash(key)` always gives the same result). So this doesn't fully solve heavy skew — it just gives Spark more partitions to work with.

**Best for**: Moderate, not extreme, skew.

### Fix 4: Enable AQE Skew Handling (Spark 3.x)

```python
spark.conf.set("spark.sql.adaptive.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionFactor", "5")
spark.conf.set("spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes", "256mb")
```

**What AQE does**:
- Detects skewed partitions at runtime (not based on estimates)
- Splits the skewed partition into smaller sub-partitions
- Processes each sub-partition separately
- Automatically rebalances the workload

**Best for**: Most cases — should always be enabled as a baseline.

### Fix 5: Bucketing (For Repeated Joins)

If you repeatedly join two large tables on the same column:

```sql
CREATE TABLE t1 ... CLUSTERED BY (customer_id) INTO 32 BUCKETS;
CREATE TABLE t2 ... CLUSTERED BY (customer_id) INTO 32 BUCKETS;
```

**Why it works**: Data is pre-organized by key at write time. Join doesn't need a full shuffle, so skew impact is reduced.

**Best for**: Stable tables that are joined frequently.

---

## Decision Tree: Which Fix to Use

```
Is one table small enough to broadcast?
  YES → Broadcast Join (simplest, fastest)
  NO  ↓

Is AQE enabled?
  NO  → Enable it first (spark.sql.adaptive.enabled = true)
  YES ↓

Does AQE fix the problem?
  YES → Done!
  NO  ↓

Is the skew on one or few specific keys?
  YES → Salting (split the hot key with random suffix)
  NO  ↓

Do you join these tables repeatedly?
  YES → Bucketing (pre-organize data)
  NO  → Repartition + increase shuffle partitions
```

---

## Key Takeaway

> Data skew = uneven data distribution where one key dominates. It causes one task to run much longer than others.
> **Broadcast join** eliminates shuffle entirely (for small tables).
> **Salting** splits heavy keys into sub-keys (for extreme skew).
> **AQE** auto-detects and splits skewed partitions (always enable it).
> **Bucketing** pre-organizes data for repeated joins.
