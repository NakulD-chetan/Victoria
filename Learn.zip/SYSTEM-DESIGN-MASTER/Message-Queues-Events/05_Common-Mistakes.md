# Message Queues and Events — Common Mistakes

> **Permanent Recall:** The most common messaging failures are not "Kafka is slow." They are design mistakes: using sync where async fits better, ignoring duplicates, skipping DLQ, misunderstanding ordering, choosing the wrong broker, and forgetting backlog, retries, and schema evolution.

---

## Mistake 1: Using Messaging Without Real Need

This is the opposite of underusing async. Sometimes people add Kafka just to sound advanced.

### Bad thinking

- using messaging for a simple request-response call
- adding eventual consistency where the business needs immediate confirmation
- creating extra complexity without real scaling benefit

### Better thinking

- use messaging only when async, decoupling, buffering, or fan-out truly help

---

## Mistake 2: Staying Synchronous When Async Would Help

```text
Service A -> Service B -> Service C -> Service D

One slow service slows everything.
```

Problem:

- high latency
- cascading failures
- tight coupling

Fix:

- identify work that does not need to complete before user response
- push it through a queue or event bus

---

## Mistake 3: Assuming Exactly-Once Everywhere

This is one of the most common interview mistakes.

Reality:

- retries create duplicates
- broker failover can cause redelivery
- exactly-once usually exists only in a limited scope

Better default:

- use at-least-once
- make consumers idempotent

---

## Mistake 4: Ignoring Idempotency

If a payment event is processed twice, the business impact can be severe.

### Common causes of duplicates

- consumer crashes after processing but before ack/commit
- producer retries
- consumer group rebalances

### Fixes

- store `message_id`
- use `UPSERT` by business key
- make state transitions safe to repeat

---

## Mistake 5: No DLQ

Without a DLQ, poison messages keep coming back forever.

```text
Message -> fail -> retry -> fail -> retry -> fail -> stuck system
```

With DLQ:

```text
Message -> retry a few times -> DLQ -> inspect -> fix -> replay
```

Always define:

- max retry count
- backoff strategy
- DLQ destination
- replay procedure

---

## Mistake 6: Forgetting Ordering Scope

People often say "Kafka preserves order" without saying **where**.

Correct answer:

- Kafka preserves order **within a partition**
- per-key ordering requires consistent partition key
- global ordering usually hurts throughput badly

If order matters for an entity, partition by that entity ID.

---

## Mistake 7: Choosing the Wrong Broker

| Need | Better Choice |
|---|---|
| Replay, stream history, multiple consumer groups | Kafka |
| Flexible exchange routing, worker queues | RabbitMQ |
| Simple managed queue in AWS | SQS |
| AWS fan-out | SNS + SQS |

Bad choices:

- Kafka for a tiny simple work queue
- RabbitMQ when replay is core
- SQS standard when strict FIFO is required

---

## Mistake 8: Ignoring Backpressure

Problem:

- producers write faster than consumers can process
- backlog keeps growing
- latency becomes huge
- storage fills up

You must explain:

- what happens when consumer falls behind
- whether producer slows down, buffers, or gets throttled
- how backlog is monitored

---

## Mistake 9: Not Monitoring Lag or Queue Depth

If you do not monitor backlog, you only discover issues after the business complains.

### Metrics that matter

- Kafka consumer lag
- queue depth
- message age
- retry rate
- DLQ depth
- processing latency

Strong design answers always mention monitoring.

---

## Mistake 10: Tight Coupling Through Event Schema

Events are contracts.

Bad schema practices:

- breaking field changes without compatibility plan
- consumers depending on every field
- renaming or removing fields carelessly

Better practices:

- version schemas
- evolve with additive changes
- use schema registry where appropriate
- keep consumers tolerant to unknown or optional fields

---

## Mistake 11: Infinite Retries for Permanent Failures

Not every failure is transient.

Transient:

- network timeout
- dependency temporarily unavailable

Permanent:

- bad payload
- incompatible schema
- logic bug

Retries help only the first category.  
Permanent failures need DLQ or manual handling.

---

## Mistake 12: Forgetting Replay and Reprocessing Cost

Replay sounds nice, but it can be expensive.

Questions to think about:

- how much data is retained?
- how long does replay take?
- can consumers handle old schema versions?
- will replay overload downstream dependencies?

This matters especially in Kafka-based designs.

---

## Mistake 13: Treating Eventual Consistency Like a Small Detail

If you move work async, the user may not see final state immediately.

You should explain:

- what the user sees first
- when the final state is visible
- whether you use polling, webhook, push notification, or status endpoint

Interviewers like this because it shows product awareness, not just infra awareness.

---

## Fast Self-Check

Before finalizing a messaging design, ask:

- Does this really need async?
- Queue or pub/sub?
- Right broker?
- Delivery guarantee clear?
- Idempotency covered?
- Ordering scope defined?
- Retry and DLQ present?
- Monitoring present?
- Event schema evolution addressed?

---

## 30-SECOND REVISION BOX

```text
DON'T OVERUSE MQ: use it only when async/decoupling helps
DON'T ASSUME EXACTLY-ONCE: prefer at-least-once + idempotency
DON'T SKIP DLQ: retries must be bounded
DON'T HAND-WAVE ORDERING: define per partition or per key
DON'T PICK WRONG TOOL: Kafka vs RabbitMQ vs SQS matters
DON'T IGNORE BACKLOG: backpressure and lag must be monitored
DON'T BREAK SCHEMAS: events are contracts
DON'T HIDE EVENTUAL CONSISTENCY: explain user-visible behavior
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
