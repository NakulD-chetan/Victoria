# Merge / Upsert / SCD

MERGE (also called UPSERT) combines INSERT, UPDATE, and DELETE into a single atomic statement. It compares a source dataset against a target table and takes different actions based on whether a row matches. Slowly Changing Dimensions (SCD) extend this for tracking historical changes.

**DSA Analogy**: HashMap put-if-absent — like `map.merge(key, value, remappingFunction)` in Java, where existing entries are updated and missing entries are inserted in one operation.

---

## Core Idea (2 Lines)

**MERGE** compares source rows to target rows on a join condition. Matched rows are UPDATED, unmatched source rows are INSERTED, and optionally unmatched target rows are DELETED. **SCD** patterns use this to track how dimension data (like customer address) changes over time.

---

## MERGE Syntax

### Standard SQL (SQL Server, Oracle, PostgreSQL 15+)

```sql
MERGE INTO target_table t
USING source_table s
ON t.id = s.id
WHEN MATCHED THEN
    UPDATE SET t.name = s.name, t.salary = s.salary, t.updated_at = NOW()
WHEN NOT MATCHED THEN
    INSERT (id, name, salary, created_at)
    VALUES (s.id, s.name, s.salary, NOW())
WHEN NOT MATCHED BY SOURCE THEN
    DELETE;                              -- optional: remove stale target rows
```

### PostgreSQL: INSERT ... ON CONFLICT (Upsert)

```sql
INSERT INTO employees (id, name, salary)
VALUES (1, 'Alice', 120000)
ON CONFLICT (id) DO UPDATE
SET name = EXCLUDED.name,
    salary = EXCLUDED.salary,
    updated_at = NOW();
```

### MySQL: INSERT ... ON DUPLICATE KEY UPDATE

```sql
INSERT INTO employees (id, name, salary)
VALUES (1, 'Alice', 120000)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    salary = VALUES(salary),
    updated_at = NOW();
```

---

## How MERGE Executes

```
  Source Table              Target Table
  ┌────┬───────┬────────┐   ┌────┬───────┬────────┐
  │ id │ name  │ salary │   │ id │ name  │ salary │
  ├────┼───────┼────────┤   ├────┼───────┼────────┤
  │ 1  │ Alice │ 130000 │   │ 1  │ Alice │ 120000 │  ← MATCHED → UPDATE
  │ 2  │ Bob   │ 100000 │   │ 2  │ Bob   │ 100000 │  ← MATCHED (no change)
  │ 4  │ Diana │  90000 │   │ 3  │ Carol │  95000 │  ← NOT MATCHED BY SOURCE → DELETE?
  └────┴───────┴────────┘   └────┴───────┴────────┘
                             ↑
  id=4 in source, not in target → NOT MATCHED → INSERT
  id=3 in target, not in source → NOT MATCHED BY SOURCE → DELETE (optional)

  After MERGE:
  ┌────┬───────┬────────┐
  │ 1  │ Alice │ 130000 │  ← updated
  │ 2  │ Bob   │ 100000 │  ← unchanged
  │ 4  │ Diana │  90000 │  ← inserted
  └────┴───────┴────────┘     (id=3 deleted if using NOT MATCHED BY SOURCE)
```

---

## Slowly Changing Dimensions (SCD)

In data warehousing, dimension tables (customers, products, employees) change over time. SCD defines how to handle those changes.

### SCD Type 1: Overwrite (No History)

Simply update the old value. No history preserved.

```sql
MERGE INTO dim_customer t
USING staging_customer s ON t.customer_id = s.customer_id
WHEN MATCHED THEN
    UPDATE SET t.address = s.address,
               t.city = s.city,
               t.updated_at = NOW()
WHEN NOT MATCHED THEN
    INSERT (customer_id, name, address, city, created_at)
    VALUES (s.customer_id, s.name, s.address, s.city, NOW());
```

**Use when**: History doesn't matter (typo corrections, non-critical fields).

### SCD Type 2: Add New Row (Full History)

Keep the old row, insert a new row with updated values. Track with `effective_date`, `end_date`, and `is_current` flag.

```sql
-- Step 1: Close the current record
UPDATE dim_customer
SET end_date = CURRENT_DATE - 1,
    is_current = FALSE
WHERE customer_id IN (
    SELECT s.customer_id FROM staging_customer s
    JOIN dim_customer d ON s.customer_id = d.customer_id
    WHERE d.is_current = TRUE
      AND (s.address != d.address OR s.city != d.city)
);

-- Step 2: Insert new current record
INSERT INTO dim_customer (customer_id, name, address, city,
                          effective_date, end_date, is_current)
SELECT s.customer_id, s.name, s.address, s.city,
       CURRENT_DATE, '9999-12-31', TRUE
FROM staging_customer s
WHERE EXISTS (
    SELECT 1 FROM dim_customer d
    WHERE d.customer_id = s.customer_id
      AND d.is_current = FALSE
      AND d.end_date = CURRENT_DATE - 1
);

-- Step 3: Insert brand new customers
INSERT INTO dim_customer (customer_id, name, address, city,
                          effective_date, end_date, is_current)
SELECT s.customer_id, s.name, s.address, s.city,
       CURRENT_DATE, '9999-12-31', TRUE
FROM staging_customer s
WHERE NOT EXISTS (
    SELECT 1 FROM dim_customer d WHERE d.customer_id = s.customer_id
);
```

**SCD Type 2 table structure:**

```
dim_customer:
surrogate_key | customer_id | name  | address    | effective_date | end_date   | is_current
──────────────┼─────────────┼───────┼────────────┼────────────────┼────────────┼───────────
1001          | C001        | Alice | 123 Main   | 2023-01-01     | 2024-05-31 | FALSE
1002          | C001        | Alice | 456 Oak    | 2024-06-01     | 9999-12-31 | TRUE
1003          | C002        | Bob   | 789 Pine   | 2023-03-15     | 9999-12-31 | TRUE
```

**Use when**: Need full audit trail (financial data, compliance, analytics).

### SCD Type 3: Add New Column (Limited History)

Add a `previous_value` column — keeps only the last change.

```sql
UPDATE dim_customer
SET previous_address = address,
    address = s.new_address,
    address_change_date = CURRENT_DATE
FROM staging_customer s
WHERE dim_customer.customer_id = s.customer_id
  AND dim_customer.address != s.new_address;
```

**Use when**: Only need "before and after" — not full history.

---

## SCD Comparison

| SCD Type | History | Storage | Complexity | Best For |
|----------|---------|---------|------------|----------|
| Type 1 | None (overwrite) | Minimal | Simple | Non-critical fields, corrections |
| Type 2 | Full (new row per change) | High | Complex | Audit trails, compliance, analytics |
| Type 3 | Partial (previous + current) | Medium | Medium | "What was it before?" queries |

---

## Upsert Patterns Across Databases

| Database | Syntax | Notes |
|----------|--------|-------|
| PostgreSQL | `INSERT ... ON CONFLICT DO UPDATE` | Needs unique constraint |
| MySQL | `INSERT ... ON DUPLICATE KEY UPDATE` | Needs unique/primary key |
| SQL Server | `MERGE INTO ... USING ... ON ...` | Full MERGE support |
| Oracle | `MERGE INTO ... USING ... ON ...` | Full MERGE support |
| SQLite | `INSERT OR REPLACE` / `ON CONFLICT` | Simpler version |
| BigQuery | `MERGE` statement | Full support |

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| MERGE without unique join condition | Nondeterministic: row matched by multiple source rows | Ensure 1:1 or M:1 source-to-target match |
| ON CONFLICT without unique constraint | PostgreSQL can't detect conflicts | Create UNIQUE index on conflict columns |
| SCD Type 2 without closing old row | Two current rows for same entity | Always UPDATE end_date/is_current before INSERT |
| Not handling unchanged rows | Unnecessary UPDATEs hurt performance | Add AND condition to check if values actually changed |
| MERGE race condition | Concurrent MERGE can cause duplicates | Use row-level locks or serializable isolation |

---

## Key Takeaway

> MERGE/Upsert combines INSERT + UPDATE + DELETE into one atomic operation. Use it for ETL loads, sync operations, and SCD implementations. SCD Type 1 overwrites (no history), Type 2 adds rows (full history), Type 3 adds columns (partial history). In most production pipelines, SCD Type 2 is the standard for tracking dimension changes over time.
