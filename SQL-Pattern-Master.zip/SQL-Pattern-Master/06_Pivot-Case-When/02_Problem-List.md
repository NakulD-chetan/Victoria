# Pivot / CASE WHEN — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers conditional aggregation, crosstab reports, status counting, percentage calculation, and unpivoting. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Reformat Department Table | LC 1179 | Easy | Basic pivot | Purest CASE WHEN pivot |
| 2 | Capital Gain/Loss | LC 1393 | Medium | Conditional SUM | SUM with sign based on condition |
| 3 | Trips and Users | LC 262 | Hard | Conditional rate | Cancellation rate via CASE/COUNT |
| 4 | Monthly Transactions I | LC 1193 | Medium | Multi-metric pivot | Multiple aggregates per group |
| 5 | Immediate Food Delivery II | LC 1174 | Medium | Percentage CASE | Conditional percentage calculation |
| 6 | Product Sales Analysis III | LC 1070 | Medium | CASE + filter | First-year sales pivot |
| 7 | Tree Node | LC 608 | Medium | CASE classification | CASE for row classification |
| 8 | Triangle Judgement | LC 610 | Easy | CASE boolean | CASE for yes/no classification |
| 9 | Students Report By Geography | LC 1270 | Hard | Multi-column pivot | Pivot multiple groups into columns |
| 10 | Rearrange Products Table | LC 1795 | Easy | Unpivot | Columns to rows (reverse) |

---

## Complete 20-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Reformat Department Table | LC 1179 | Basic pivot | SUM(CASE WHEN month=x THEN revenue END) |
| 2 | Triangle Judgement | LC 610 | CASE boolean | CASE WHEN for yes/no classification |
| 3 | Rearrange Products Table | LC 1795 | Unpivot | UNION ALL to convert columns to rows |
| 4 | Calculate Special Bonus | LC 1873 | CASE in SELECT | Conditional column value |
| 5 | Swap Salary | LC 627 | Simple CASE | Swap m/f using CASE |
| 6 | Recyclable and Low Fat Products | LC 1757 | CASE filter | CASE in WHERE equivalent |

### Medium (Problems 7-15) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 7 | Capital Gain/Loss | LC 1393 | Conditional SUM | Buy=-amount, Sell=+amount, SUM per stock |
| 8 | Monthly Transactions I | LC 1193 | Multi-agg pivot | COUNT + SUM with CASE per status |
| 9 | Immediate Food Delivery II | LC 1174 | Percentage | SUM(CASE)/COUNT for rate |
| 10 | Tree Node | LC 608 | Classification | CASE with NULL check + EXISTS |
| 11 | Product Sales Analysis III | LC 1070 | CASE + window | First year identification |
| 12 | Game Play Analysis IV | LC 550 | Retention rate | CASE for day-after-install login |
| 13 | Apples and Oranges | LC 1445 | Conditional SUM | SUM CASE per fruit type |
| 14 | Number of Calls Between Two Persons | LC 1699 | CASE for normalization | Normalize bidirectional pairs |
| 15 | Friendly Movies Streamed Last Month | LC 1495 | CASE + filter | Multi-condition classification |

### Hard (Problems 16-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 16 | Trips and Users | LC 262 | Conditional rate | ROUND(SUM(CASE)/COUNT, 2) per day |
| 17 | Students Report By Geography | LC 1270 | Multi-group pivot | Separate rows per continent into columns |
| 18 | Hopper Company Queries III | LC 1651 | Rolling CASE + avg | Monthly average with CASE conditions |
| 19 | Dynamic Pivot Report | StrataScratch | Dynamic columns | Pivot with unknown number of values |
| 20 | Revenue by Quarter Comparison | DataLemur | YoY CASE pivot | Year-over-year comparison via CASE |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Reformat Department Table (LC 1179)

```
Pattern:     Basic CASE WHEN pivot
Approach:    SUM(CASE WHEN month='Jan' THEN revenue END) AS Jan_Revenue
             GROUP BY id
Key Insight: Each month becomes a column via its own CASE WHEN
One-liner:   One CASE WHEN per month inside SUM, grouped by department id.
```

### Problem 3: Trips and Users (LC 262)

```
Pattern:     Conditional rate via CASE
Approach:    ROUND(SUM(CASE WHEN status LIKE 'cancelled%' THEN 1.0 ELSE 0 END)
             / COUNT(*), 2) AS cancellation_rate
             GROUP BY request_at
Key Insight: Rate = conditional numerator / total denominator
One-liner:   SUM cancelled CASE / total COUNT per day, rounded to 2 decimals.
```

### Problem 7: Capital Gain/Loss (LC 1393)

```
Pattern:     Conditional SUM with sign
Approach:    SUM(CASE WHEN operation='Buy' THEN -price ELSE price END)
             GROUP BY stock_name
Key Insight: Buy is negative, Sell is positive — net sum is gain/loss
One-liner:   Buy=-price, Sell=+price, SUM per stock = capital gain/loss.
```

### Problem 17: Students Report By Geography (LC 1270)

```
Pattern:     Multi-column pivot with ROW_NUMBER
Approach:    ROW_NUMBER per continent, then pivot continent into columns
             using MAX(CASE WHEN continent='America' THEN name END)
             GROUP BY row_number
Key Insight: Need ROW_NUMBER to align rows across pivoted columns
One-liner:   Row-number per continent; pivot using MAX CASE per continent.
```

---

## Pattern Distribution

```
BASIC PIVOT (CASE WHEN + AGG):          7 problems  (1, 4, 5, 6, 13-14, 20)
CONDITIONAL RATE/PERCENTAGE:            5 problems  (3, 9, 12, 16, 18)
CLASSIFICATION (CASE for labels):       4 problems  (2, 8, 10, 15)
UNPIVOT (columns to rows):             2 problems  (3, 11)
MULTI-GROUP PIVOT:                      2 problems  (17, 19)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 1179, LC 610 (basic pivot, classification)
- Day 2: LC 1795, LC 627 (unpivot, swap)
- Day 3: LC 1393, LC 1193 (conditional sum, multi-agg)

### Week 2: Core Patterns (Days 4-6)
- Day 4: LC 1174, LC 550 (percentage, retention rate)
- Day 5: LC 608, LC 1070 (tree classification, first year)
- Day 6: LC 1445, LC 1699 (apples/oranges, normalization)

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 262 (trips — the classic hard CASE problem)
- Day 8: LC 1270, DataLemur YoY (multi-group, dynamic)
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Aggregate without pivot | Pattern 04 (Aggregation + HAVING) — basic GROUP BY |
| Pivot with running total | Pattern 07 (Running Total) — SUM OVER for cumulative |
| Dynamic number of columns | Dynamic SQL / application layer — SQL pivot is static |
| Conditional filtering | Pattern 05 (Subquery/EXISTS) — sometimes cleaner |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (6 Easy, 9 Medium, 5 Hard)
MUST-DO:            LC 1179, 1393, 262, 1193, 1174, 1070, 608, 610, 1270, 1795
TOP 3 MOST ASKED:   LC 262 (Trips), LC 1179 (Reformat), LC 608 (Tree Node)
PATTERN SPLIT:      Basic pivot (7), Rate/Pct (5), Classification (4),
                    Unpivot (2), Multi-group (2)
STUDY ORDER:        Basic CASE → Conditional SUM → Rates → Unpivot → Dynamic
KEY INSIGHT:        GROUP BY = row keys; CASE WHEN = column headers; AGG = cell values
INTERVIEW LINE:     "I use SUM(CASE WHEN) for row-to-column pivoting and
                     UNION ALL for the reverse unpivot operation."
```

---

## 30-SECOND REVISION BOX

```
PIVOT:         SUM(CASE WHEN col='X' THEN val END) AS x — rows to columns
UNPIVOT:       UNION ALL per column — columns to rows
RATE:          SUM(CASE WHEN x THEN 1.0 ELSE 0 END) / COUNT(*)
COUNT vs SUM:  COUNT(CASE ... THEN 1 END) = SUM(CASE ... THEN 1 ELSE 0 END)
CLASSIFICATION: CASE WHEN condition THEN label ... END AS category
MULTI-AGG:     Multiple CASE WHEN in same SELECT, same GROUP BY
GROUP BY:      Defines the row identity; each CASE defines a column
ELSE:          Omitting ELSE gives NULL — fine for SUM/COUNT, careful for display
PORTABILITY:   CASE WHEN works everywhere; PIVOT keyword = SQL Server/Oracle only
```
