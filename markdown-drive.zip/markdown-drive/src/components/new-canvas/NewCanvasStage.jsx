import { useEffect, useRef, useCallback, forwardRef, useImperativeHandle } from 'react';
import { createEngine } from './engine';
import { useNewCanvasStore } from './state/store';
import { worldFromClient } from './engine/coords';
import { createWidgetElement } from './widgets/widget-registry';
import WidgetLayer from './widgets/WidgetLayer';
import HUD from './debug/HUD';
import { compileTeachingScene } from './agent/teaching-composer';

/**
 * The stage owns:
 *   - two stacked canvases (static + interactive) — the renderer's outputs
 *   - the widget DOM overlay, which sits above them
 *   - drag-and-drop for adding widgets
 *
 * React's job is to mount/unmount the DOM and the engine; everything else
 * (drawing, panning, zooming, hit-testing) happens in the engine.
 */

const NewCanvasStage = forwardRef(function NewCanvasStage({ theme }, ref) {
  const hostRef = useRef(null);
  const staticRef = useRef(null);
  const interactiveRef = useRef(null);
  const inkRef = useRef(null);
  const engineRef = useRef(null);
  const fixtureLoadedRef = useRef(false);
  const tool = useNewCanvasStore((s) => s.tool);

  useEffect(() => {
    if (!hostRef.current || !staticRef.current || !interactiveRef.current) return;
    const engine = createEngine({
      staticEl: staticRef.current,
      interactiveEl: interactiveRef.current,
      inkEl: inkRef.current,
      hostEl: hostRef.current,
      store: useNewCanvasStore,
      getTheme: () => document.documentElement.getAttribute('data-theme') || theme,
    });
    engineRef.current = engine;
    return () => engine.destroy();
  }, [theme]);

  useEffect(() => {
    if (!import.meta.env.DEV || fixtureLoadedRef.current || !hostRef.current) return undefined;
    const fixture = new URLSearchParams(window.location.search).get('nc-fixture');
    if (fixture !== 'array') return undefined;
    const frame = window.requestAnimationFrame(() => {
      if (fixtureLoadedRef.current) return;
      fixtureLoadedRef.current = true;
      const store = useNewCanvasStore.getState();
      const scene = store.scenes[store.activeId];
      if (!scene) return;
      const compiled = compileTeachingScene({
        scene,
        stageElement: hostRef.current,
        request: {
          topic: 'array',
          structureType: 'array',
          title: 'Array',
          definition: 'An array stores elements of the same type in contiguous memory locations.',
          values: ['12', '7', '19', '4', '23'],
          focus: 'overview',
          callout: 'Index gives direct access through contiguous storage.',
        },
        replaceExistingTopic: true,
      });
      store.commitElements(compiled.elements);
      store.patchActiveSceneMeta?.({ lessonDeck: compiled.lessonDeck });
      store.setViewport(compiled.viewport);
      store.setTool('select');
      store.clearSelection();
    });

    return () => window.cancelAnimationFrame(frame);
  }, []);

  useImperativeHandle(ref, () => ({
    /** Composite the static canvas + any DOM widgets into a single PNG blob. */
    async exportPNG() {
      const host = hostRef.current;
      const staticEl = staticRef.current;
      if (!host || !staticEl) return null;
      const rect = host.getBoundingClientRect();

      const out = document.createElement('canvas');
      const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
      out.width = Math.floor(rect.width * dpr);
      out.height = Math.floor(rect.height * dpr);
      const ctx = out.getContext('2d');
      // background
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--obs-surface') || '#ffffff';
      ctx.fillRect(0, 0, out.width, out.height);
      ctx.drawImage(staticEl, 0, 0, out.width, out.height);
      const inkEl = inkRef.current;
      if (inkEl) ctx.drawImage(inkEl, 0, 0, out.width, out.height);
      return await new Promise((resolve) => out.toBlob((b) => resolve(b), 'image/png'));
    },
    getEngine: () => engineRef.current,
  }));

  const onDragOver = useCallback((ev) => {
    const types = ev.dataTransfer?.types;
    if (!types) return;
    if (types.includes('application/x-nc-widget') || types.includes('application/x-widget-id')) {
      ev.preventDefault();
      ev.dataTransfer.dropEffect = 'copy';
    }
  }, []);

  const onDrop = useCallback((ev) => {
    let widgetType = ev.dataTransfer.getData('application/x-nc-widget');
    if (!widgetType) {
      // support old drag identifier for compatibility ("widget-compiler" -> "code")
      const legacy = ev.dataTransfer.getData('application/x-widget-id');
      if (legacy === 'widget-compiler') widgetType = 'code';
      else if (legacy === 'widget-note') widgetType = 'note';
      else if (legacy === 'widget-array') widgetType = 'array';
    }
    if (!widgetType) return;
    ev.preventDefault();
    const store = useNewCanvasStore.getState();
    const scene = store.scenes[store.activeId];
    const vp = scene?.viewport || { zoom: 1, panX: 0, panY: 0 };
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, interactiveRef.current, vp);
    const el = createWidgetElement(widgetType, x, y);
    store.commitElements((els) => els.concat([el]));
  }, []);

  const cursorMap = {
    select: 'default',
    pen: 'crosshair',
    highlighter: 'crosshair',
    eraser: 'crosshair',
    rect: 'crosshair',
    ellipse: 'crosshair',
    line: 'crosshair',
    arrow: 'crosshair',
    text: 'text',
    pan: 'grab',
    laser: 'crosshair',
  };
  const cursor = tool.startsWith('widget-') ? 'crosshair' : (cursorMap[tool] || 'default');

  return (
    <div
      ref={hostRef}
      className="nc-stage"
      data-nc-tool={tool}
      onDragOver={onDragOver}
      onDrop={onDrop}
      style={{ cursor }}
    >
      <canvas ref={staticRef}      className="nc-canvas nc-canvas--static" />
      <canvas ref={interactiveRef} className="nc-canvas nc-canvas--interactive" />
      <WidgetLayer />
      <canvas ref={inkRef}         className="nc-canvas nc-canvas--ink" />
      <HUD getEngine={() => engineRef.current} />
    </div>
  );
});

export default NewCanvasStage;
