# Union-Find — Tricks and Recognition

> **Permanent Recall:** "Connected components" → UF. "Merge groups" → UF. "Cycle in undirected" → UF. "Dynamic connectivity" → UF. Need path/distance → BFS/DFS. Keywords trigger the right DS.

---

## Keyword → Union-Find Mapping

| Keyword / Phrase | Why UF |
|------------------|--------|
| **Connected components** | Count or group components |
| **Number of provinces** | Component count |
| **Friend circles** | Each circle = component |
| **Accounts merge** | Emails in same account = same component |
| **Redundant connection** | Cycle = edge connecting same component |
| **Graph valid tree?** | n-1 edges + no cycle |
| **Regions / clusters** | Merge adjacent same-type |
| **Dynamic connectivity** | Add edges, query connectivity |
| **Group by** | Merge items that share attribute |
| **Lexicographically smallest** | Process in sorted order with UF |

---

## UF vs BFS/DFS Decision

```mermaid
flowchart TD
    A["Are nodes connected?"] --> B{Multiple queries<br/>or dynamic edges?}
    B -->|Yes| UF["Union-Find"]
    B -->|No| D{Need path/distance?}
    D -->|YES| BFSDFS1["BFS/DFS"]
    D -->|NO| BFSDFS2["BFS/DFS (simpler)"]
    style UF fill:#90EE90
    style BFSDFS1 fill:#87CEEB
    style BFSDFS2 fill:#87CEEB
```

<details>
<summary>ASCII fallback</summary>

```
                    "Are nodes connected?"
                           |
              +------------+------------+
              |                         |
        Multiple queries          Single query
        or dynamic edges               |
              |                         |
         Union-Find              Need path/distance?
              |                         |
              |                    +----+----+
              |                    |         |
              |                   YES       NO
              |                    |         |
              |               BFS/DFS    BFS/DFS
              |                    |    (simpler)
              |                    |         |
              +--------------------+---------+
```

</details>

---

## Recognition Patterns

### Pattern 1: Component Count

```
"Count number of connected components"
"Number of islands" (when merging adjacent)
"Number of provinces"

→ Union-Find, return count after all unions
```

### Pattern 2: Cycle Detection (Undirected)

```
"Find redundant connection"
"Is graph a valid tree?" (n-1 edges + no cycle)
"Detect cycle in undirected graph"

→ For each edge: if find(u)==find(v) → cycle
                else union(u,v)
```

### Pattern 3: Group Merging

```
"Merge accounts with common email"
"Group similar items"
"Cluster by shared attribute"

→ Map items to IDs, union those that share attribute
```

### Pattern 4: 2D Grid → 1D Index

```
"Number of islands" (adjacent 1s)
"Regions in grid"

→ idx = r * cols + c
   Union (r,c) with (r-1,c), (r+1,c), (r,c-1), (r,c+1)
```

### Pattern 5: Process in Order

```
"Lexicographically smallest redundant edge"
"Earliest edge that creates cycle"

→ Sort edges, process in order; first cycle = answer
```

---

## Trick: Track Component Size

```python
# Add size[] array for "largest component" problems
def __init__(self, n):
    self.parent = list(range(n))
    self.rank = [0] * n
    self.size = [1] * n  # size of component

def union(self, x, y):
    rx, ry = self.find(x), self.find(y)
    if rx == ry: return
    if self.rank[rx] < self.rank[ry]:
        rx, ry = ry, rx
    self.parent[ry] = rx
    self.size[rx] += self.size[ry]
    if self.rank[rx] == self.rank[ry]:
        self.rank[rx] += 1
```

---

## Trick: Virtual Nodes (Boundary)

```
"Escape grid" — connect boundary cells to virtual "outside" node

  Add node n = rows*cols (virtual exit)
  Union boundary cells with n
  If find(start) == find(n) → can escape
```

---

## Trick: Reverse Time (Offline Queries)

```
"Remove edges in order, answer connectivity after each removal"

→ Process removals in reverse = add edges
  Build UF from final state, add edges backward
  Answer queries in reverse order
```

---

## Problem Type Recognition

```mermaid
flowchart TD
    A["PROBLEM STATEMENT"] --> B["Contains component / province /<br/>island / merge / group?"]
    B -->|YES| C["Union-Find candidate"]
    C --> D["Cycle in undirected?"]
    D --> E["UF (find before union)"]
    C --> F["Need path/distance?"]
    F -->|NO| G["Use BFS/DFS"]
    C --> H["Dynamic edges?"]
    H --> I["Strong UF signal"]
    style C fill:#90EE90
    style E fill:#C8E6C9
    style I fill:#FFE4B5
```

<details>
<summary>ASCII fallback</summary>

```
PROBLEM STATEMENT
       |
       v
Contains "component" / "province" / "island" / "merge" / "group"?
       |
      YES --> Union-Find candidate
       |
       v
Cycle in undirected? --> UF (find before union)
       |
       v
Need path/distance? --> NO, use BFS/DFS
       |
       v
Dynamic edges? --> Strong UF signal
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
KEYWORDS:     components, provinces, merge, groups, redundant, cycle
CYCLE:        find(u)==find(v) before union
MERGE:        Map to IDs, union by shared attribute
GRID:         idx = r*cols+c, union 4 neighbors
SIZE:         size[] array, add on union
VIRTUAL:      Boundary node for "escape" problems
REVERSE:      Removal → process as addition in reverse
VS BFS/DFS:   Path/distance → BFS/DFS
```

---

## 30-SECOND REVISION BOX

```
□ "Components" / "merge" / "groups" → UF
□ Cycle undirected → find before union
□ Grid → r*cols+c, union neighbors
□ Size tracking → size[rx] += size[ry]
□ Path needed? → BFS/DFS not UF
```
