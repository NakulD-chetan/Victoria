import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useSlidingCounterStore } from '../../stores/sliding-counter-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    textFormula: '#1971c2',
    clientFill: '#d0bfff',
    serverFill: '#b2f2bb',
    prevWindowFill: 'rgba(166,216,249,0.25)',
    currWindowFill: 'rgba(166,216,249,0.55)',
    overlayFill: 'rgba(255,212,59,0.2)',
    overlayStroke: 'rgba(230,180,34,0.5)',
    arrowStroke: '#78716c',
    statusFull: '#2f9e44',
    statusEmpty: '#e03131',
    statusNormal: '#78716c',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)',
    stroke: 'rgba(255,255,255,0.6)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    textFormula: '#74c0fc',
    clientFill: '#3b2e6e',
    serverFill: '#1e5631',
    prevWindowFill: 'rgba(100,180,255,0.12)',
    currWindowFill: 'rgba(100,180,255,0.35)',
    overlayFill: 'rgba(255,212,59,0.15)',
    overlayStroke: 'rgba(230,180,34,0.4)',
    arrowStroke: '#a8a29e',
    statusFull: '#51cf66',
    statusEmpty: '#ff6b6b',
    statusNormal: '#a8a29e',
  },
};

function getThemePalette() {
  const t = document.documentElement.getAttribute('data-theme');
  return t === 'light' ? PALETTE.light : PALETTE.dark;
}

const SlidingCounterCanvas = forwardRef(function SlidingCounterCanvas({ counterRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');

  const windowSize = useSlidingCounterStore((s) => s.windowSize);
  const limit = useSlidingCounterStore((s) => s.limit);

  const addAnim = useCallback((type, dur = 700, delay = 0) => {
    animsRef.current.push({ type, t0: performance.now(), dur, delay });
  }, []);

  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache();
      lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function L() {
      const W = wRef.current, H = hRef.current;
      const clientX = 30;
      const serverX = W - 150;
      const windowsCenter = W / 2;
      const barH = 100;
      const barY = H / 2 - barH / 2 - 20;
      const barW = 180;
      const prevBarX = windowsCenter - barW - 8;
      const currBarX = windowsCenter + 8;
      return {
        client: { x: clientX, y: H / 2 - 40, w: 110, h: 80 },
        server: { x: serverX, y: H / 2 - 40, w: 110, h: 80 },
        prevBar: { x: prevBarX, y: barY, w: barW, h: barH },
        currBar: { x: currBarX, y: barY, w: barW, h: barH },
        arrowClientToWindows: { sx: clientX + 110, ex: prevBarX - 10, y: H / 2 },
        arrowWindowsToServer: { sx: currBarX + barW + 10, ex: serverX, y: H / 2 },
        formulaY: barY - 28,
        weightedY: barY + barH / 2,
        W, H,
      };
    }

    function drawBox(key, x, y, w, h, opts) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.6, bowing: 1.2, strokeWidth: 2.2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawArrowLine(key, x1, y1, x2, pal) {
      const pad = 20, w = Math.abs(x2 - x1) + pad * 2, h = 30;
      const img = cacheShape(key, w, h, (rc) => {
        rc.line(pad, h / 2, w - pad, h / 2, { seed: 50, roughness: 1.5, strokeWidth: 1.8, stroke: pal.arrowStroke });
        const tipX = w - pad, tipY = h / 2;
        rc.line(tipX - 12, tipY - 7, tipX, tipY, { seed: 51, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
        rc.line(tipX - 12, tipY + 7, tipX, tipY, { seed: 52, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
      });
      ctx.drawImage(img, Math.min(x1, x2) - pad, y1 - 15, w, h);
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';
      const l = L();
      const counter = counterRef.current;

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) {
        clearShapeCache(); clearCache();
        lastThemeRef.current = curTheme;
      }
      const pal = getThemePalette();

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      const nowSec = now / 1000;
      let windowId = Math.floor(nowSec / counter.windowSize);
      let displayPrev = counter.prevCount;
      let displayCurr = counter.currCount;
      let displayWindow = counter.currentWindow;
      while (windowId > displayWindow) {
        displayPrev = displayCurr;
        displayCurr = 0;
        displayWindow++;
      }
      const windowStart = windowId * counter.windowSize;
      const elapsed = nowSec - windowStart;
      const fraction = Math.min(elapsed / counter.windowSize, 1);
      const weightedCount = displayPrev * (1 - fraction) + displayCurr;

      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h, { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke });
      drawBox('server', l.server.x, l.server.y, l.server.w, l.server.h, { fill: pal.serverFill, fillStyle: 'hachure', hachureGap: 6, seed: 4, stroke: pal.stroke });
      drawArrowLine('arr-req', l.arrowClientToWindows.sx, l.arrowClientToWindows.y, l.arrowClientToWindows.ex, pal);
      drawArrowLine('arr-res', l.arrowWindowsToServer.sx, l.arrowWindowsToServer.y, l.arrowWindowsToServer.ex, pal);

      const prevBar = l.prevBar, currBar = l.currBar;

      ctx.globalAlpha = 0.7;
      ctx.fillStyle = pal.prevWindowFill;
      ctx.fillRect(prevBar.x, prevBar.y, prevBar.w, prevBar.h);
      ctx.strokeStyle = pal.stroke;
      ctx.lineWidth = 2;
      ctx.strokeRect(prevBar.x, prevBar.y, prevBar.w, prevBar.h);
      ctx.globalAlpha = 1;

      ctx.fillStyle = pal.currWindowFill;
      ctx.fillRect(currBar.x, currBar.y, currBar.w, currBar.h);
      ctx.strokeStyle = pal.stroke;
      ctx.lineWidth = 2;
      ctx.strokeRect(currBar.x, currBar.y, currBar.w, currBar.h);

      const overlayLeft = prevBar.x + prevBar.w * (1 - fraction);
      const overlayW = currBar.w + (prevBar.w - prevBar.w * (1 - fraction));
      ctx.fillStyle = pal.overlayFill;
      ctx.fillRect(overlayLeft, prevBar.y, overlayW, prevBar.h);
      ctx.strokeStyle = pal.overlayStroke;
      ctx.lineWidth = 1.5;
      ctx.strokeRect(overlayLeft, prevBar.y, overlayW, prevBar.h);

      ctx.fillStyle = pal.textPrimary;
      ctx.font = `600 15px ${FONT_HAND}`;
      ctx.textAlign = 'center';
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);
      ctx.fillText('Server', l.server.x + l.server.w / 2, l.server.y + l.server.h / 2);

      ctx.font = `11px ${FONT_HAND}`;
      ctx.fillStyle = pal.textSecondary;
      ctx.fillText('Prev', prevBar.x + prevBar.w / 2, prevBar.y - 8);
      ctx.fillText('Curr', currBar.x + currBar.w / 2, currBar.y - 8);

      ctx.font = `800 28px ${FONT_MONO}`;
      ctx.fillStyle = pal.textPrimary;
      ctx.fillText(String(displayPrev), prevBar.x + prevBar.w / 2, prevBar.y + prevBar.h / 2);
      ctx.fillText(String(displayCurr), currBar.x + currBar.w / 2, currBar.y + currBar.h / 2);

      const formulaStr = `weighted = prev×(1-t)+curr = ${displayPrev.toFixed(1)}×(1-${fraction.toFixed(2)})+${displayCurr} = ${weightedCount.toFixed(2)}`;
      ctx.font = `12px ${FONT_MONO}`;
      ctx.fillStyle = pal.textFormula;
      ctx.textAlign = 'center';
      ctx.fillText(formulaStr, (prevBar.x + currBar.x + currBar.w) / 2, l.formulaY);

      ctx.font = `800 32px ${FONT_MONO}`;
      ctx.fillStyle = pal.textPrimary;
      ctx.fillText(`weighted: ${weightedCount.toFixed(2)}`, (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y + prevBar.h + 22);
      ctx.font = `13px ${FONT_HAND}`;
      ctx.fillStyle = pal.textSecondary;
      ctx.fillText(`limit = ${limit}`, (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y + prevBar.h + 42);

      ctx.textAlign = 'center';
      ctx.font = `700 14px ${FONT_HAND}`;
      if (weightedCount >= limit) {
        ctx.fillStyle = pal.statusEmpty;
        ctx.fillText('Over limit \u2014 Denying!', (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y + prevBar.h + 62);
      } else {
        ctx.fillStyle = pal.statusFull;
        ctx.fillText('Under limit \u2014 Accepting', (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y + prevBar.h + 62);
      }

      ctx.font = `13px ${FONT_HAND}`;
      ctx.fillStyle = pal.textSecondary;
      ctx.fillText('request', (l.arrowClientToWindows.sx + l.arrowClientToWindows.ex) / 2, l.arrowClientToWindows.y - 18);
      ctx.fillText('response', (l.arrowWindowsToServer.sx + l.arrowWindowsToServer.ex) / 2, l.arrowWindowsToServer.y - 18);

      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const delay = a.delay || 0;
        const elapsed = now - a.t0 - delay;
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);
        if (a.type === 'req-allow') {
          const sx = l.arrowClientToWindows.sx, sy = l.arrowClientToWindows.y, ex = l.arrowClientToWindows.ex;
          if (t < 0.45) {
            const p = t / 0.45;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(25,113,194,0.7)';
            ctx.fill();
          } else if (t < 0.7) {
            const p = (t - 0.45) / 0.25;
            const sx2 = l.arrowWindowsToServer.sx, ex2 = l.arrowWindowsToServer.ex;
            const px = sx2 + (ex2 - sx2) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, l.arrowWindowsToServer.y, 7, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(47,158,68,0.8)';
            ctx.fill();
          }
          if (t > 0.35 && t < 0.85) {
            ctx.font = `800 28px ${FONT_HAND}`;
            ctx.fillStyle = pal.statusFull;
            ctx.textAlign = 'center';
            ctx.globalAlpha = Math.min(1 - Math.abs(t - 0.6) / 0.25, 1);
            ctx.fillText('\u2713', (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y - 20);
            ctx.globalAlpha = 1;
          }
        }
        if (a.type === 'req-deny') {
          const sx = l.arrowClientToWindows.sx, sy = l.arrowClientToWindows.y, ex = l.arrowClientToWindows.ex;
          if (t < 0.4) {
            const p = t / 0.4;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath();
            ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(224,49,49,0.7)';
            ctx.fill();
          } else if (t < 0.6) {
            const bT = (t - 0.4) / 0.2;
            const px = ex - bT * 30;
            ctx.beginPath();
            ctx.arc(px, sy, 8 * (1 - bT * 0.3), 0, Math.PI * 2);
            ctx.fillStyle = `rgba(224,49,49,${1 - bT * 0.5})`;
            ctx.fill();
          }
          if (t > 0.25 && t < 0.85) {
            ctx.font = `800 32px ${FONT_HAND}`;
            ctx.fillStyle = pal.statusEmpty;
            ctx.textAlign = 'center';
            ctx.globalAlpha = Math.max(t < 0.55 ? 1 : 1 - (t - 0.55) / 0.3, 0);
            ctx.fillText('\u2717', (prevBar.x + currBar.x + currBar.w) / 2, prevBar.y - 20);
            ctx.globalAlpha = 1;
          }
        }
        if (t >= 1) anims.splice(i, 1);
      }
      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, [counterRef, addAnim, limit]);

  useEffect(() => { clearShapeCache(); clearCache(); lastThemeRef.current = ''; }, [windowSize, limit]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 420 }} />
    </div>
  );
});

export default SlidingCounterCanvas;
