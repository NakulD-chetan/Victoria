# Streaming Joins

Joins combine **two** relations. In streaming, one or both sides may be **unbounded**. Spark supports **stream–static** and **stream–stream** joins with **time bounds** and **watermarks** to keep **state** finite.

---

## 1. Stream–Static Join

**Definition:** One side is streaming; the other is a **bounded** table (or batch DataFrame refreshed each trigger when applicable).

| Aspect | Behavior |
| ------ | -------- |
| **State for stream side** | Tracks incoming stream rows as usual. |
| **Static side** | Broadcast or shuffle depending on size; typically **lookup** each batch. |
| **Late static updates** | If the dimension **changes**, historical correctness may require **overwrite** strategies—Spark does not magically version your warehouse. |

**Use cases:** Enriching events with **customer**, **product**, or **geo** dimensions.

---

## 2. Stream–Stream Join

**Definition:** Both inputs are **unbounded**. Without constraints, join state would grow **forever** (every past row might match a future row).

**Solution:** Restrict matches using **event-time constraints**:

- **Watermark** on **both** streams (typically).
- **Join interval** expressed with time predicates (e.g., events within ±10 minutes).

Spark retains rows in **state buffers** only as long as needed to satisfy the interval **plus** watermark lateness policies.

```
Stream A  ──┐
            ├──► Join (time-bounded) ──► Output
Stream B  ──┘
```

---

## 3. Join Types (Supported Combinations)

Exact support matrix evolves by Spark version; conceptually:

| Join type | Stream–static | Stream–stream |
| --------- | ------------- | ------------- |
| Inner | Common | Supported with time + watermark constraints |
| Left outer | Common | Supported with care—**null** matches depend on time bounds |
| Other outer variations | Case-by-case | Same theme—state and watermark interplay |

Always consult **release notes** for your Spark minor version—streaming join capabilities expanded over 2.x → 3.x.

---

## 4. State Explosion Risks

| Risk | Mitigation |
| ---- | ---------- |
| **Cartesian** without time predicate | Avoid—unbounded matches |
| **Wide join interval** | Increases retained rows—**tighten** business window |
| **Skewed keys** | Hot keys enlarge partition state—consider salting or broadcast static fragments |

---

## 5. Output Mode Interaction

Stream–stream joins often target **Append** sinks when each match is emitted **once** as pairs become **final** under watermark rules. **Update** may apply when matches **evolve**—sink must upsert.

---

## 6. Key Takeaways

1. **Stream–static** enriches streaming events—mind **staleness** of dimension data.
2. **Stream–stream** requires **watermarks** + **time predicates**—otherwise state is unbounded.
3. Join **interval** is a **business** and **capacity** parameter—negotiate with SLAs.
4. Validate **join type + output mode + sink** together on a staging cluster.

---
