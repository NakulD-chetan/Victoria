# Quick Revision — The Universal Template

> **Permanent Recall:** One fill-in-the-blank framework for ANY system design. Use as mental checklist. Never skip Step 1 (Requirements) or Step 5 (Wrap-up). One page.

---

## THE MASTER TEMPLATE

```
STEP 1: Requirements (~5 min)
├── Functional: [3–5 core features]
├── Non-functional: [latency, availability, consistency, scale]
├── Constraints: [read:write, data size, DAU]
└── Out of scope: [explicitly exclude]

STEP 2: Estimation (~2 min)
├── DAU: ___
├── QPS: ___
├── Peak QPS: ___
├── Storage/day: ___
└── Storage/5yr: ___

STEP 3: High-Level Design (~8 min)
├── [Draw: Client → LB → App → Cache → DB → Queues → CDN]
├── API: [3–5 key endpoints]
└── Data model: [key tables]

STEP 4: Deep Dive (~20 min)
├── Component 1: [most critical]
├── Component 2: [second critical]
└── Trade-offs: [list]

STEP 5: Wrap-up (~5 min)
├── Bottlenecks: [identified + fix]
├── Monitoring: [metrics]
└── Future: [improvements]
```

---

## Step 1 — Requirements Checklist

| Category | Ask |
|----------|-----|
| **Functional** | What are 3–5 core features? |
| **Non-functional** | Latency? Availability? Consistency? Scale? |
| **Constraints** | Read:write? Data size? Retention? Geography? |
| **Out of scope** | What are we NOT building? |

---

## Step 2 — Estimation Formulas

| Metric | Formula |
|--------|---------|
| **QPS** | DAU × actions_per_day ÷ 86400 |
| **Peak QPS** | 2–3× average |
| **Storage/day** | Records × bytes_per_record × writes |
| **Storage/5yr** | Storage/day × 365 × 5 |
| **Bandwidth** | QPS × request_size × 8 (bits) |

---

## Step 3 — Component Picker

| System Type | Draw These Components |
|-------------|------------------------|
| **Basic web** | Client → LB → App → Cache → DB |
| **Read-heavy social** | + Fan-out, timeline cache, message queue |
| **Real-time chat** | + WebSocket, message queue, presence |
| **Media/streaming** | + CDN, object storage, transcoding |
| **Geospatial** | + Geohash, spatial index |
| **Search** | + Elasticsearch, inverted index |
| **Simple redirect** | + KGS or hash, cache |

---

## Universal Component Diagram (ASCII)

```
                    ┌─────────────┐
                    │   Clients   │
                    └──────┬──────┘
                           │
                    ┌──────▼──────┐
                    │ Load Balancer│
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│  App Server 1 │  │  App Server 2 │  │  App Server N │
└───────┬───────┘  └───────┬───────┘  └───────┬───────┘
        └──────────────────┼──────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│    Cache      │  │ Message Queue │  │   Database    │
└───────────────┘  └───────────────┘  └───────────────┘
                           │
                    ┌──────▼──────┐
                    │    CDN     │  (optional)
                    └────────────┘
```

---

## Component Selection Table

| Need | Component |
|------|-----------|
| Multi-server | Load Balancer |
| Fast reads | Cache (Redis) |
| Persistent data | Database |
| Async, decoupling | Message Queue |
| Static, global | CDN |
| Blobs, media | Object Storage (S3) |
| Full-text search | Elasticsearch |
| Real-time to client | WebSocket |
| Rate limit | API Gateway / Redis |

---

## Time Allocation

| Step | Target | Key Output |
|------|--------|------------|
| 1. Requirements | 5 min | Scope, constraints, assumptions |
| 2. Estimation | 2 min | DAU, QPS, storage |
| 3. High-Level | 8 min | Components, API, data model |
| 4. Deep Dive | 20 min | 1–2 components, trade-offs |
| 5. Wrap-up | 5 min | Bottlenecks, monitoring, future |

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
