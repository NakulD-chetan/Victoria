import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useSlidingLogStore } from '../../stores/sliding-log-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    clientFill: '#d0bfff',
    serverFill: '#b2f2bb',
    arrowStroke: '#78716c',
    dotActive: '#1971c2',
    dotExpired: 'rgba(120,113,108,0.35)',
    windowFill: 'rgba(25,113,194,0.12)',
    windowStroke: 'rgba(25,113,194,0.35)',
    statusFull: '#2f9e44',
    statusEmpty: '#e03131',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)',
    stroke: 'rgba(255,255,255,0.6)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    clientFill: '#3b2e6e',
    serverFill: '#1e5631',
    arrowStroke: '#a8a29e',
    dotActive: '#74c0fc',
    dotExpired: 'rgba(168,162,158,0.25)',
    windowFill: 'rgba(100,180,255,0.1)',
    windowStroke: 'rgba(100,180,255,0.3)',
    statusFull: '#51cf66',
    statusEmpty: '#ff6b6b',
  },
};

function getThemePalette() {
  const t = document.documentElement.getAttribute('data-theme');
  return t === 'light' ? PALETTE.light : PALETTE.dark;
}

const SlidingLogCanvas = forwardRef(function SlidingLogCanvas({ logRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');

  const windowSize = useSlidingLogStore((s) => s.windowSize);
  const limit = useSlidingLogStore((s) => s.limit);
  const startTime = useSlidingLogStore((s) => s.startTime);

  const addAnim = useCallback((type, dur = 700, delay = 0) => {
    animsRef.current.push({ type, t0: performance.now(), dur, delay });
  }, []);

  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    const TIMELINE_H = 90;
    const TIMELINE_VIEW_SEC = 12;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache();
      lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function layout() {
      const W = wRef.current, H = hRef.current;
      const clientW = 100, clientH = 60;
      const serverW = 100, serverH = 60;
      const timelineW = Math.max(200, W - clientW - serverW - 120);
      const clientX = 25;
      const timelineX = clientX + clientW + 35;
      const serverX = timelineX + timelineW + 35;
      const centerY = H / 2;
      const timelineY = centerY - TIMELINE_H / 2;

      return {
        client: { x: clientX, y: centerY - clientH / 2, w: clientW, h: clientH },
        timeline: { x: timelineX, y: timelineY, w: timelineW, h: TIMELINE_H },
        server: { x: serverX, y: centerY - serverH / 2, w: serverW, h: serverH },
        arrowReqStart: { x: clientX + clientW, y: centerY },
        arrowReqEnd: { x: timelineX, y: centerY },
        arrowResStart: { x: timelineX + timelineW, y: centerY },
        arrowResEnd: { x: serverX, y: centerY },
        W, H,
      };
    }

    function drawBox(key, x, y, w, h, opts, pal) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.6, bowing: 1.2, strokeWidth: 2.2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawArrowLine(key, x1, y1, x2, pal) {
      const pad = 20, w = Math.abs(x2 - x1) + pad * 2, h = 30;
      const img = cacheShape(key, w, h, (rc) => {
        rc.line(pad, h / 2, w - pad, h / 2, { seed: 50, roughness: 1.5, strokeWidth: 1.8, stroke: pal.arrowStroke });
        const tipX = w - pad, tipY = h / 2;
        rc.line(tipX - 12, tipY - 7, tipX, tipY, { seed: 51, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
        rc.line(tipX - 12, tipY + 7, tipX, tipY, { seed: 52, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
      });
      ctx.drawImage(img, Math.min(x1, x2) - pad, y1 - 15, w, h);
    }

    function timeToX(tSec, nowSec, l) {
      const viewStart = nowSec - TIMELINE_VIEW_SEC;
      if (tSec < viewStart || tSec > nowSec + 1) return null;
      const frac = (tSec - viewStart) / (TIMELINE_VIEW_SEC + 1);
      return l.timeline.x + frac * l.timeline.w;
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) {
        clearShapeCache(); clearCache();
        lastThemeRef.current = curTheme;
      }
      const pal = getThemePalette();
      const l = layout();
      const log = logRef.current;
      if (!log) { animId = requestAnimationFrame(render); return; }

      const nowSec = (now - startTime) / 1000;
      const cutoffSec = nowSec - windowSize;
      const viewStart = nowSec - TIMELINE_VIEW_SEC;

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h,
        { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke }, pal);
      drawBox('server', l.server.x, l.server.y, l.server.w, l.server.h,
        { fill: pal.serverFill, fillStyle: 'hachure', hachureGap: 6, seed: 4, stroke: pal.stroke }, pal);

      ctx.fillStyle = pal.textPrimary; ctx.font = `600 15px ${FONT_HAND}`; ctx.textAlign = 'center';
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);
      ctx.fillText('Server', l.server.x + l.server.w / 2, l.server.y + l.server.h / 2);

      drawArrowLine('arr-req', l.arrowReqStart.x, l.arrowReqStart.y, l.arrowReqEnd.x, pal);
      drawArrowLine('arr-res', l.arrowResStart.x, l.arrowResStart.y, l.arrowResEnd.x, pal);

      ctx.font = `12px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary; ctx.textAlign = 'center';
      ctx.fillText('request', (l.arrowReqStart.x + l.arrowReqEnd.x) / 2, l.client.y - 8);
      ctx.fillText('response', (l.arrowResStart.x + l.arrowResEnd.x) / 2, l.server.y - 8);

      const tl = l.timeline;
      ctx.strokeStyle = pal.stroke; ctx.lineWidth = 2; ctx.strokeRect(tl.x, tl.y, tl.w, tl.h);

      const windowStartFrac = Math.max(0, (cutoffSec - viewStart) / (TIMELINE_VIEW_SEC + 1));
      const windowEndFrac = 1;
      const winX = tl.x + windowStartFrac * tl.w;
      const winW = (windowEndFrac - windowStartFrac) * tl.w;

      ctx.fillStyle = pal.windowFill;
      ctx.fillRect(winX, tl.y + 2, winW, tl.h - 4);
      ctx.strokeStyle = pal.windowStroke; ctx.lineWidth = 1.5;
      ctx.strokeRect(winX, tl.y + 2, winW, tl.h - 4);

      const countInWindow = log.timestamps.filter((t) => (t - startTime) / 1000 > cutoffSec).length;

      for (let i = 0; i < log.timestamps.length; i++) {
        const t = log.timestamps[i];
        const tSec = (t - startTime) / 1000;
        const x = timeToX(tSec, nowSec, l);
        if (x === null) continue;
        const inWindow = tSec > cutoffSec;
        ctx.beginPath();
        ctx.arc(x, tl.y + tl.h / 2, 5, 0, Math.PI * 2);
        ctx.fillStyle = inWindow ? pal.dotActive : pal.dotExpired;
        ctx.fill();
        if (inWindow) {
          ctx.strokeStyle = pal.dotActive; ctx.lineWidth = 1.5; ctx.stroke();
        }
      }

      const tickStep = Math.max(1, Math.floor(TIMELINE_VIEW_SEC / 6));
      for (let s = Math.ceil(viewStart); s <= nowSec + 1; s += tickStep) {
        const frac = (s - viewStart) / (TIMELINE_VIEW_SEC + 1);
        if (frac < 0 || frac > 1) continue;
        const tx = tl.x + frac * tl.w;
        ctx.beginPath();
        ctx.moveTo(tx, tl.y + tl.h);
        ctx.lineTo(tx, tl.y + tl.h + 6);
        ctx.strokeStyle = pal.textSecondary; ctx.lineWidth = 1; ctx.stroke();
        ctx.font = `10px ${FONT_MONO}`; ctx.fillStyle = pal.textSecondary; ctx.textAlign = 'center';
        ctx.fillText(s.toFixed(0) + 's', tx, tl.y + tl.h + 14);
      }

      ctx.font = `700 14px ${FONT_MONO}`; ctx.fillStyle = pal.textPrimary; ctx.textAlign = 'center';
      ctx.fillText(`${countInWindow} / ${limit}`, tl.x + tl.w / 2, tl.y - 12);
      ctx.font = `11px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText('in window', tl.x + tl.w / 2, tl.y - 2);

      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const delay = a.delay || 0;
        const elapsed = now - a.t0 - delay;
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);

        if (a.type === 'req-allow') {
          if (t < 0.5) {
            const p = t / 0.5;
            const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath(); ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(25,113,194,0.8)'; ctx.fill();
          } else {
            const p = (t - 0.5) / 0.5;
            const dotX = tl.x + tl.w * 0.95;
            ctx.beginPath(); ctx.arc(dotX, tl.y + tl.h / 2, 6 + p * 2, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(25,113,194,${1 - p * 0.3})`; ctx.fill();
            if (t > 0.3 && t < 0.9) {
              ctx.font = `800 24px ${FONT_HAND}`; ctx.fillStyle = pal.statusFull;
              ctx.globalAlpha = Math.min(1 - Math.abs(t - 0.6) / 0.3, 1);
              ctx.fillText('\u2713', tl.x + tl.w / 2, tl.y + tl.h / 2 - 20);
              ctx.globalAlpha = 1;
            }
          }
        }

        if (a.type === 'req-deny') {
          if (t < 0.5) {
            const p = t / 0.5;
            const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
            const px = sx + (ex - sx) * easeOut(p);
            ctx.beginPath(); ctx.arc(px, sy, 8, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(224,49,49,0.8)'; ctx.fill();
          } else {
            const flashAlpha = (1 - t) * 0.4;
            ctx.fillStyle = `rgba(224,49,49,${flashAlpha})`;
            ctx.fillRect(tl.x, tl.y, tl.w, tl.h);
            if (t > 0.2 && t < 0.85) {
              ctx.font = `800 28px ${FONT_HAND}`; ctx.fillStyle = pal.statusEmpty;
              ctx.globalAlpha = Math.max(t < 0.55 ? 1 : 1 - (t - 0.55) / 0.3, 0);
              ctx.fillText('\u2717', tl.x + tl.w / 2, tl.y + tl.h / 2);
              ctx.globalAlpha = 1;
            }
          }
        }

        if (t >= 1) anims.splice(i, 1);
      }

      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, [logRef, addAnim, windowSize, limit, startTime]);

  useEffect(() => { clearShapeCache(); clearCache(); lastThemeRef.current = ''; }, [windowSize, limit]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 420 }} />
    </div>
  );
});

export default SlidingLogCanvas;
