import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const steps = [];
  const stack = [];
  steps.push({ type: 'init', array: [...arr], stack: [] });
  arr.forEach((v, i) => {
    steps.push({ type: 'visit', array: [...arr], stack: [...stack], idx: i });
    while (stack.length && arr[stack.at(-1)] < v) {
      stack.pop();
      steps.push({ type: 'pop', array: [...arr], stack: [...stack], idx: i });
    }
    stack.push(i);
    steps.push({ type: 'push', array: [...arr], stack: [...stack], idx: i });
  });
  steps.push({ type: 'done', array: [...arr], stack: [], idx: -1 });
  return steps;
}

export default function MonotonicStackVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = [6, 4, 3, 2, 5, 8, 1];
    const steps = generateSteps(arr);
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Decreasing stack: pop while top < current' });
    canvasRef.current?.setState({
      array: arr,
      colors: {},
      buckets: { Stack: [] },
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.idx >= 0) colors[step.idx] = 'compare';
    (step.stack || []).forEach((si) => {
      colors[si] = 'active';
    });
    if (step.type === 'done') for (let i = 0; i < step.array.length; i++) colors[i] = 'sorted';
    const stackVals = (step.stack || []).map((i) => step.array[i]);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.type} | stack indices [${(step.stack || []).join(', ')}]` });
    store.setArray(step.array);
    canvasRef.current?.setState({
      array: step.array,
      colors,
      buckets: { Stack: stackVals },
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
