import { uid } from '../../state/types';
import { worldFromClient } from '../coords';
import { createWidgetElement } from '../../widgets/widget-registry';

function snapStyle(opts) {
  return {
    stroke: opts.stroke,
    fill: opts.fill || 'transparent',
    strokeWidth: opts.strokeWidth,
    opacity: opts.opacity ?? 1,
    dash: opts.dash || 'solid',
  };
}

/**
 * Drag-to-place for DOM widgets — same interaction as rect/ellipse.
 * Toolbar selects `widget-{type}`; pointerdown → drag rubber band → pointerup commits.
 */
export function makeWidgetPlaceTool(widgetType) {
  const toolId = `widget-${widgetType}`;
  return {
    id: toolId,
    cursor: 'crosshair',

    onPointerDown(ctx, ev) {
      if (ev.button !== 0) return false;
      const { canvasEl, getVp, store } = ctx;
      canvasEl.setPointerCapture?.(ev.pointerId);
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      const style = snapStyle(store.getState().toolOptions);
      ctx.setDraft({
        id: uid('place'),
        type: 'widget',
        widgetType,
        widgetData: {},
        x,
        y,
        w: 0,
        h: 0,
        z: 0,
        isDeleted: false,
        style,
        _start: { x, y },
        createdAt: Date.now(),
      });
      ctx.markDirty(1);
      return true;
    },

    onPointerMove(ctx, ev) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== 'widget' || draft.widgetType !== widgetType) return;
      const { canvasEl, getVp } = ctx;
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      const sx = draft._start.x;
      const sy = draft._start.y;
      let dx = x - sx;
      let dy = y - sy;
      if (ev.shiftKey) {
        const m = Math.max(Math.abs(dx), Math.abs(dy));
        dx = Math.sign(dx || 1) * m;
        dy = Math.sign(dy || 1) * m;
      }
      draft.x = dx < 0 ? sx + dx : sx;
      draft.y = dy < 0 ? sy + dy : sy;
      draft.w = Math.abs(dx);
      draft.h = Math.abs(dy);
      ctx.markDirty(1);
    },

    onPointerUp(ctx) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== 'widget' || draft.widgetType !== widgetType) return;
      ctx.setDraft(null);
      if (draft.w < 2 && draft.h < 2) {
        ctx.markDirty(1);
        return;
      }
      const el = createWidgetElement(widgetType, draft.x, draft.y, draft.w, draft.h, {
        style: draft.style,
      });
      ctx.commit((els) => els.concat([el]));
      ctx.markDirty(2);
    },

    onCancel(ctx) {
      ctx.setDraft(null);
      ctx.markDirty(1);
    },
  };
}

export const widgetTools = Object.fromEntries([
  'code',
  'sql-pad',
  'note',
  'array',
  'json',
  'csv',
  'linked-list',
  'stack',
  'queue',
  'tree',
  'hash-map',
].map((widgetType) => [`widget-${widgetType}`, makeWidgetPlaceTool(widgetType)]));
