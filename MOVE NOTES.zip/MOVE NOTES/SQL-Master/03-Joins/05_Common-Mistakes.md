# Joins — Common Mistakes

| Mistake | Reality |
|---------|---------|
| Forgetting table alias | Ambiguous column errors |
| INNER when business needed LEFT | Silent row loss |
| Filter on outer table in `WHERE` instead of `ON` | Accidentally **nulls out** outer side (LEFT→INNER effect) |
| Joining on wrong key | Cartesian explosion or wrong matches |
| Assuming `NULL` keys match | They don’t in equi-join |

---

*Next: [[06_Edge-Cases]]*
