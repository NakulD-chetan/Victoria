# Spark UI Pattern Master — Index

> **8 deep-dive patterns to read the Spark UI like an X-ray.**
> Agar tum job dekhke nahi bata sakte ki *kitne jobs banenge*, *kyu banenge*, *kaunsa stage skip hoga*, *kyu ek task 25s aur baaki 0.5s leta hai* — yeh notes wahi gap fix karenge.
> Companion long-form note: `Spark-Notes/24-Spark-UI-Monitoring-Guide.md` (single-file overview).
> Yeh folder usko **pattern-by-pattern**, **theory + problem list** style mein todta hai — bilkul jaise `SQL-Pattern-Master` aur `PySpark-Pattern-Master` ne kiya.

---

## Sample Setup (Used Across Notes)

```python
spark = (SparkSession.builder
    .appName("Spark UI Deep Dive")
    .master("local[*]")
    .config("spark.sql.shuffle.partitions", "8")
    .config("spark.sql.adaptive.enabled", "false")
    .getOrCreate())

df_filtered.cache()
df_filtered.count()      # Job 0  -> count
df_final.show()          # Jobs 1, 2, 3  -> 3 showString jobs
df_final.collect()       # Job 4  -> collect
```

**Total: 5 jobs. Yeh 5 jobs hi humare har pattern ka reference example hain.**

---

## Table of Contents

| #  | Pattern                                          | What You Learn                                                  | Theory                                                          | Problems                                                              |
|----|--------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------|-----------------------------------------------------------------------|
| 01 | Spark UI Tabs Map                                | The 6 tabs, what each one answers, where to click first         | [Theory](01_Spark-UI-Tabs-Map/01_Theory.md)                     | [Problems](01_Spark-UI-Tabs-Map/02_Problem-List.md)                   |
| 02 | Jobs Tab & Actions                               | Action → Job rule, why count is 1 job, why show is many         | [Theory](02_Jobs-Tab-and-Actions/01_Theory.md)                  | [Problems](02_Jobs-Tab-and-Actions/02_Problem-List.md)                |
| 03 | executeTake & Show Jobs (Deep)                   | Source-code trace of why `df.show()` creates 1–N jobs           | [Theory](03_executeTake-and-Show-Jobs/01_Theory.md)             | [Problems](03_executeTake-and-Show-Jobs/02_Problem-List.md)           |
| 04 | Stages, Tasks & Shuffle Boundaries               | How DAG splits into stages, why task count = N partitions       | [Theory](04_Stages-Tasks-and-Shuffle-Boundaries/01_Theory.md)   | [Problems](04_Stages-Tasks-and-Shuffle-Boundaries/02_Problem-List.md) |
| 05 | Skipped Stages & Shuffle Output Reuse            | Why "skipped" stages appear, cache reuse, re-action behavior    | [Theory](05_Skipped-Stages-and-Reuse/01_Theory.md)              | [Problems](05_Skipped-Stages-and-Reuse/02_Problem-List.md)            |
| 06 | SQL Tab & Physical Plans                         | Reading Exchange, WholeStageCodegen, joins, scans               | [Theory](06_SQL-Tab-and-Physical-Plans/01_Theory.md)            | [Problems](06_SQL-Tab-and-Physical-Plans/02_Problem-List.md)          |
| 07 | Executors, Storage & Environment Tabs            | Memory health, cache fraction, GC ratio, config verification    | [Theory](07_Executors-Storage-and-Environment/01_Theory.md)     | [Problems](07_Executors-Storage-and-Environment/02_Problem-List.md)   |
| 08 | Diagnosing Slow Jobs (Skew, Spill, GC)           | The end-to-end debugging workflow + interview answers           | [Theory](08_Diagnosing-Slow-Jobs/01_Theory.md)                  | [Problems](08_Diagnosing-Slow-Jobs/02_Problem-List.md)                |

---

## Code → UI Mental Map

```text
Code                          UI Effect                                    Pattern
---------------------------   -------------------------------------------  ------
df.count()                    1 job, N stages (N = #shuffles + 1)          02, 04
df.show() / df.head(n)        1 to log4(P)+1 jobs (executeTake loop)       03
df.collect()                  1 job, all partitions scanned                02
df.cache() + action           1 job, materialize cache (Storage tab fills) 05, 07
groupBy / join                +1 stage at every shuffle boundary           04, 06
.filter() / .select()         No new stage (pipelined into previous)       04
shuffle.partitions = N        Post-shuffle stage runs N tasks              04
broadcast(small_df).join(big) BroadcastHashJoin in SQL tab, no Exchange    06
adaptive.enabled = true       Extra "AQE" jobs may appear                  03, 06
spark.sql.limit.initialNumPartitions = K  show scans K partitions in iter1 03
```

---

## Recommended Study Order

### Beginner (Build the Map)
```
01  Spark UI Tabs Map
02  Jobs Tab & Actions
04  Stages, Tasks & Shuffle Boundaries
```

### Intermediate (The Real "Why" Layer)
```
03  executeTake & Show Jobs   ← THE most asked "explain show()" interview topic
05  Skipped Stages & Reuse
06  SQL Tab & Physical Plans
```

### Advanced (Production Debugging)
```
07  Executors, Storage & Environment
08  Diagnosing Slow Jobs
```

---

## Pattern Dependency Graph

```text
                       +-----------------------------+
                       | 01 Spark UI Tabs Map        |
                       | (6 tabs, what each answers) |
                       +--------------+--------------+
                                      |
                       +--------------+--------------+
                       | 02 Jobs Tab & Actions       |
                       | (action -> job mapping)     |
                       +-------+-----------+---------+
                               |           |
                               v           v
        +--------------------------+  +--------------------------------+
        | 03 executeTake & Show    |  | 04 Stages, Tasks & Shuffle     |
        | (why show = 3 jobs)      |  | (DAG split, task count rules)  |
        +-----------+--------------+  +---------+----------------------+
                    |                           |
                    +-----------+---------------+
                                v
                    +-------------------------------+
                    | 05 Skipped Stages & Reuse     |
                    | (cache + shuffle reuse)       |
                    +---------------+---------------+
                                    |
                                    v
                    +-------------------------------+
                    | 06 SQL Tab & Physical Plans   |
                    +---------------+---------------+
                                    |
                                    v
                    +-------------------------------+
                    | 07 Executors / Storage / Env  |
                    +---------------+---------------+
                                    |
                                    v
                    +-------------------------------+
                    | 08 Diagnosing Slow Jobs       |
                    +-------------------------------+
```

---

## How To Use This Folder

1. Open the **Spark UI** (`http://localhost:4040`) of a real running script — even a tiny one.
2. Read the Theory for one pattern, then click the same tab in your UI.
3. Solve the Problem List by **looking at the UI**, not at notes.
4. Re-run the sample setup with **AQE on**, then **AQE off**, and compare.
5. Patterns 03, 04, 05 are the "big 3" — most interviews target these.

---

## Reading Order for Your Specific Example (5-jobs scenario)

If you came here from the *"3 showString jobs + 1 count + 1 collect"* discussion:

```
Pattern 02 → see why count = 1 job, collect = 1 job
Pattern 03 → see why show = 3 jobs (executeTake loop)
Pattern 04 → see why count has 3 stages (16 + 6 + 1 tasks)
Pattern 05 → see why jobs 2 & 3 had 22 skipped tasks
Pattern 06 → see Exchange operators in the SQL tab
Pattern 08 → see how to spot skew, spill, GC issues
```

---

## Key Configs Referenced (Cheat-sheet)

| Config                                     | Default | What It Does                                                         |
|--------------------------------------------|---------|----------------------------------------------------------------------|
| `spark.sql.shuffle.partitions`             | 200     | Number of post-shuffle partitions (= task count of post-shuffle stage) |
| `spark.sql.limit.initialNumPartitions`     | 1       | First-iter partition count in `executeTake` (controls show() jobs)   |
| `spark.sql.limit.scaleUpFactor`            | 4       | Multiplier per `executeTake` iteration                               |
| `spark.sql.adaptive.enabled`               | true*   | AQE — adds re-optimization jobs per shuffle boundary                 |
| `spark.default.parallelism`                | #cores  | Default partition count for RDD ops, `parallelize`, `createDataFrame`|
| `spark.eventLog.enabled`                   | false   | Required for History Server to capture finished apps                 |
| `spark.ui.retainedJobs` / `retainedStages` | 1000    | UI memory pressure if low                                            |

*Default flipped to `true` since Spark 3.2.

---

## Key Takeaway

> Spark UI ka kaam ek hi hai — *"code lines ko execution events mein translate karke dikhana"*.
> Agar tum **action → job → stage → task** ka chain bina UI dekhe predict kar sako, tumhe interview mein koi nahi rok sakta. Yeh 8 patterns wahi prediction skill banate hain.
