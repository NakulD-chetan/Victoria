# SQL Foundation — Coding Templates

> Minimal, portable patterns (ANSI-style). Adjust dialect (`AUTO_INCREMENT` vs `SERIAL`, etc.).

---

## 1) Create table with PK + FK

```sql
CREATE TABLE departments (
    dept_id   INT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL
);

CREATE TABLE employees (
    emp_id    INT PRIMARY KEY,
    name      VARCHAR(100) NOT NULL,
    dept_id   INT,
    CONSTRAINT fk_emp_dept
        FOREIGN KEY (dept_id) REFERENCES departments (dept_id)
);
```

---

## 2) Insert / bulk insert

```sql
INSERT INTO departments (dept_id, dept_name)
VALUES (1, 'IT');

INSERT INTO employees (emp_id, name, dept_id)
VALUES
    (101, 'A', 1),
    (102, 'B', 1);
```

---

## 3) Update + delete (safe habits)

```sql
-- Always preview with SELECT + WHERE first in real systems
UPDATE employees
SET dept_id = 2
WHERE emp_id = 101;

DELETE FROM employees
WHERE emp_id = 102;
```

---

## 4) ALTER (common interview)

```sql
ALTER TABLE employees ADD COLUMN email VARCHAR(255);
ALTER TABLE employees ALTER COLUMN name TYPE VARCHAR(200);  -- Postgres-style
-- SQL Server: ALTER COLUMN ... ; MySQL: MODIFY ...
```

---

## 5) DROP vs TRUNCATE vs DELETE (concept template)

| Op | Scope | Typical use |
|----|--------|-------------|
| `DELETE` | Rows (can `WHERE`) | Remove some/all rows, logged heavier |
| `TRUNCATE` | Whole table data | Fast reset; usually DDL-like; FK restrictions |
| `DROP` | Table object | Remove table itself |

---

*Next: [[04_Interview-Thinking]]*
