/*
 * EditorSkeleton — page-level placeholder shown while a vault is loading.
 * Roughly mimics a note (title bar + paragraphs) so the transition reads
 * as "loading content" rather than "empty editor".
 */
export default function EditorSkeleton() {
  const paras = ['92%', '88%', '82%', '70%', '95%', '76%', '60%'];
  return (
    <div className="sk-editor" aria-hidden>
      <div className="sk-editor__title sk-bar sk-bar--xl" />
      <div className="sk-editor__meta">
        <div className="sk-bar sk-bar--sm" style={{ width: '14%' }} />
        <div className="sk-bar sk-bar--sm" style={{ width: '20%' }} />
      </div>
      <div className="sk-editor__body">
        {paras.map((w, i) => (
          <div className="sk-bar" key={i} style={{ width: w }} />
        ))}
      </div>
    </div>
  );
}
