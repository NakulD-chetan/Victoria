# Load Balancing — Edge Cases (Deep Understanding)

> **Permanent Recall:** LB edge cases to watch: health check false positives, cascading failure, connection draining, WebSocket handling, consistent hashing hot spots, DNS caching skew, SSL cert management, thundering herd after server recovery, and split-brain in active-passive setups. Each has specific mitigations.

---

## Why Edge Cases Matter

Edge cases are **rare situations that cause disproportionate damage**. In interviews, knowing edge cases shows senior-level thinking. In production, not handling them causes outages.

---

## Edge Case 1: Health Check False Positives

### What Happens

The LB marks a **perfectly healthy** server as unhealthy because of a transient issue (network blip, GC pause, momentary CPU spike). The server gets removed from the pool unnecessarily.

### Step-by-Step How It Goes Wrong

```
Timeline:
  10:00:00  Server 3 is healthy, serving requests normally
  10:00:05  Health check → Server 3: 200 OK ✅
  10:00:10  Java GC pause starts (500ms pause — server can't respond to anything)
  10:00:10  Health check → Server 3: TIMEOUT ❌ (failure 1/3)
  10:00:10  GC pause ends (500ms later) — server is fine again
  10:00:15  Health check → Server 3: 200 OK ✅ (BUT — still at failure 1/3)
  10:00:20  Brief network blip (10ms packet loss)
  10:00:20  Health check → Server 3: TIMEOUT ❌ (failure 2/3)
  10:00:25  Health check → Server 3: 200 OK ✅ (failure count: 2/3, NOT reset!)
  10:00:30  Another brief GC pause
  10:00:30  Health check → Server 3: TIMEOUT ❌ (failure 3/3)
  
  🚫 Server 3 REMOVED from pool!
  
  But Server 3 was healthy 95% of the time!
  Now Servers 1 and 2 handle 50% more traffic each.
  If they were already at 70% capacity → now at 105% → they start failing too.
```

### Why This Is Dangerous

```
5 servers, each at 80% capacity.

Server 3 falsely removed:
  4 servers now handle 5 servers' worth of traffic
  Each server: 80% × (5/4) = 100% capacity
  
Server 2 gets slightly overloaded → real failures → removed:
  3 servers handle 5 servers' worth of traffic
  Each server: 80% × (5/3) = 133% capacity → OVERLOADED → cascade
```

### Mitigations

| Fix | How It Helps |
|-----|-------------|
| **Higher unhealthy threshold** | Set to 3-5 failures instead of 1. Brief blips don't trigger removal. |
| **Longer timeout** | Give health check 5-10s to respond instead of 1s. GC pauses won't be missed. |
| **Reset failure count on success** | Some LBs reset the count to 0 on any success. Ask: does yours? |
| **Lightweight health endpoint** | `/health` returns 200 immediately — doesn't do any heavy work that could be affected by load |
| **Separate health check from app timeouts** | App requests might timeout at 3s, but health check should wait 10s |

---

## Edge Case 2: Cascading Failure When Removing Servers

### What Happens

One server goes down → LB removes it → remaining servers get more traffic → they overload → more go down → chain reaction → total outage.

### Step-by-Step Cascade

```
STARTING STATE: 4 servers, each handling 250 req/s (capacity: 300 req/s)
  Total: 1000 req/s across 4 servers

STEP 1: Server 4 crashes (hardware failure)
  3 servers now handle 1000 req/s
  Each: 1000/3 = 333 req/s (OVER capacity of 300!)
  
STEP 2: Server 3 starts dropping requests (over capacity)
  Health checks fail → LB removes Server 3
  2 servers now handle 1000 req/s
  Each: 1000/2 = 500 req/s (WAY over capacity!)
  
STEP 3: Servers 1 and 2 can't handle 500 req/s → both crash
  0 servers handling traffic
  TOTAL OUTAGE

This entire cascade took about 60 seconds.
Started with 1 server failure, ended with complete outage.
```

### Why This Happens

The root cause is **insufficient headroom**. If servers run at 80-90% capacity normally, losing even one pushes the rest over the edge.

### Mitigations

| Fix | How It Helps |
|-----|-------------|
| **Over-provision (run at 60-70% max)** | Losing one server doesn't push others over 100%. 4 servers at 60% → lose 1 → others at 80% (still OK) |
| **Circuit breaker at LB** | If error rate > 50%, stop removing servers. Return errors for overflow instead of killing more servers. |
| **Rate limiting per server** | `maxconn 300` per backend in LB config. Server never gets more than it can handle. Excess returns 503. |
| **Gradual removal** | Don't remove server instantly. Drain connections first, reduce traffic slowly. |
| **Auto-scaling** | ASG detects high CPU → launches new instances → LB adds them. Scales up to absorb traffic. |

### Interview Tip

*"When designing, I always consider cascade failure. If we lose 1 out of N servers, can the remaining N-1 handle the full load? If not, we're under-provisioned. I'd run servers at 60-70% normal capacity so there's headroom for failure. Plus, auto-scaling triggers at 70% CPU to add more servers before reaching critical load."*

---

## Edge Case 3: Connection Draining During Deployment

### What Happens

During deployment, you replace old servers with new ones. If the LB just cuts off the old server immediately, **in-flight requests get terminated** — users see errors mid-operation.

### The Problem Without Draining

```
User is uploading a 500MB file to Server 1. Upload is at 80%.

Deploy starts. LB removes Server 1 from pool IMMEDIATELY.
  → TCP connection to Server 1 is RST (reset)
  → 400MB of upload is LOST
  → User sees "Connection reset" error
  → User has to start over
```

### How Connection Draining Works

```
Deploy starts:

Step 1: LB marks Server 1 as "DRAINING"
  → LB stops sending NEW requests to Server 1
  → Existing connections (like the upload) continue normally

Step 2: In-flight requests finish
  → User's upload completes normally on Server 1
  → Server 1 responses go back to users as normal

Step 3: After drain timeout (e.g., 300 seconds)
  → All in-flight requests have finished (or timeout exceeded)
  → Server 1 is safely removed from pool
  → Server 1 is terminated/replaced

Step 4: New Server 1 (with new code) starts
  → Passes health check
  → LB adds it to pool
  → Starts receiving new requests
```

### Drain Timeout Setting

| Too Short (10s) | Just Right (30-300s) | Too Long (1 hour) |
|-----------------|---------------------|-------------------|
| Long uploads/WebSockets get cut | Covers typical request + buffer | Deploy takes forever |
| Users see errors | Smooth transition | Wastes resources (old server stays up) |

**Rule of thumb:** Set drain timeout ≥ maximum expected request duration + 30s buffer.

---

## Edge Case 4: WebSocket / Long-Lived Connections

### What Happens

WebSocket connections stay open for **minutes to hours** (chat, gaming, live feeds). This creates unique challenges for load balancers.

### Problem 1: Uneven Distribution

```
At 9:00 AM:
  Server 1: 100 WebSocket connections
  Server 2: 100 WebSocket connections
  Server 3: 100 WebSocket connections (total: 300)

At 2:00 PM (5 hours later):
  200 new users connected (all went to Server 1 via round robin cycle)
  300 old users still connected to their original servers
  
  Server 1: 100 (old) + 200 (new) = 300
  Server 2: 100 (old, connected since morning)
  Server 3: 100 (old, connected since morning)
  
  Server 1 has 3× the load! Round robin "equally" distributed new connections,
  but old ones are stuck. Least Connections would've helped here.
```

### Problem 2: WebSocket Upgrade on L7 LB

```
WebSocket starts as an HTTP request:
  GET /chat HTTP/1.1
  Upgrade: websocket
  Connection: Upgrade

L7 LB must:
  1. Receive this HTTP request
  2. Forward to backend
  3. Backend responds: "101 Switching Protocols"
  4. Now the connection is WebSocket (not HTTP anymore)
  5. LB must switch from HTTP mode to raw TCP pass-through

Some LBs DON'T support this properly → WebSocket fails!
```

### Problem 3: Server Restart Kills All Connections

```
Server 2 needs to restart (deploy, maintenance).
Server 2 has 5,000 active WebSocket connections.

If you just kill Server 2:
  5,000 users disconnected simultaneously
  All 5,000 try to reconnect → hit remaining servers
  Thundering herd → possible cascade

Proper approach:
  1. Mark Server 2 as draining
  2. Stop accepting NEW WebSocket connections
  3. Send "reconnect" signal to existing clients (graceful close)
  4. Clients reconnect gradually (jitter/backoff)
  5. Once all connections closed → safely restart Server 2
```

### Mitigations

| Problem | Fix |
|---------|-----|
| Uneven distribution | Use **Least Connections** algorithm — accounts for long-lived connections |
| LB doesn't support WebSocket | Use WebSocket-aware LB (Nginx, HAProxy, Envoy, ALB) |
| Server restart kills connections | **Graceful close** — signal clients to reconnect with random backoff |
| State loss on reconnect | Store connection state in Redis — client reconnects to any server |
| Connection timeout at LB | Increase LB idle timeout (default is often 60s — too short for WebSocket) |

---

## Edge Case 5: Hot Spots with Consistent Hashing

### What Happens

In consistent hashing, certain keys get **way more traffic** than others. The server responsible for those keys gets overwhelmed while others are idle.

### Real-World Scenario: The Celebrity Problem

```
Twitter-like system. Cache servers use consistent hashing.

Normal users: ~10 reads/second for their profile
Celebrity (50M followers): 500,000 reads/second for their profile

hash("celebrity_profile") → Server 2

Server 2: 500,000 req/s + normal traffic = CRUSHED
Server 1: 50 req/s (normal users only) = IDLE
Server 3: 50 req/s (normal users only) = IDLE
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Virtual nodes** | Each server gets 100-200 positions on the ring → more even distribution of keys |
| **Bounded load** | Cap each server at max 1.5× average load. If over → overflow to next server on ring. Google's "Consistent Hashing with Bounded Loads" paper. |
| **Hot key detection + replication** | Detect "celebrity" keys → replicate to multiple servers → read from any replica |
| **Client-side caching** | Cache hot keys at the application layer (L1 cache) → reduces hits to cache servers |

---

## Edge Case 6: DNS Caching Causing Uneven Distribution

### What Happens

DNS returns multiple LB IPs. But clients (browsers, OS, ISP resolvers) **cache** the first IP they get. Most clients end up hitting the same LB.

### Step-by-Step

```
DNS for api.example.com returns:
  52.1.1.1 (LB-1)
  52.1.1.2 (LB-2)
  52.1.1.3 (LB-3)

Browser gets response → caches 52.1.1.1 for 300 seconds (TTL)
For 300 seconds, EVERY request goes to LB-1.

If 70% of clients cache 52.1.1.1:
  LB-1: 70% of all traffic
  LB-2: 15%
  LB-3: 15%
  
  LB-1 is overwhelmed.
```

### Why Clients Cache the Same IP

- DNS round robin rotates order, but many resolvers **sort IPs** and always pick the smallest
- ISP DNS resolvers cache the response and serve it to ALL their users (millions)
- Operating systems cache DNS for the full TTL

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Low TTL** | Set DNS TTL to 30-60 seconds. Clients refresh more often. Tradeoff: more DNS queries. |
| **Anycast** | All LBs share ONE IP. BGP routing sends each user to nearest. No client-side bias. Used by Cloudflare, Google. |
| **Client-side LB** | SDK picks from IP list randomly (not just first). Mobile apps can do this. |
| **DNS round robin + low TTL** | Rotate IP order AND force frequent re-resolution. |

---

## Edge Case 7: SSL Certificate Management at Scale

### What Happens

When you have many domains/subdomains and SSL termination at the LB, certificate management becomes a challenge.

### Problems

```
PROBLEM 1: Certificate expiry
  You have 50 domains. cert for shop.example.com expires March 15.
  Nobody notices → HTTPS breaks → browsers show "NOT SECURE" → users leave.

PROBLEM 2: Adding new domains
  Marketing launches promo.example.com
  Need: new SSL cert, update LB config, deploy
  If manual → takes hours → promo launch delayed

PROBLEM 3: Certificate rotation
  cert for *.example.com needs renewal every 90 days (Let's Encrypt)
  Must update cert on LB without downtime
  If rotation fails → HTTPS breaks
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Auto-renewal (Certbot/ACME)** | Script auto-renews certificates before expiry. Runs as cron job. |
| **AWS ACM** | AWS manages certs for ALB/NLB. Auto-renews. Zero effort. |
| **Wildcard certs** | `*.example.com` covers all subdomains. One cert for everything. |
| **SAN certs** | One cert with multiple domain names (Subject Alternative Names). |
| **Expiry monitoring** | Alerting system warns 30/7/1 days before expiry. |
| **Centralized cert store** | HashiCorp Vault or cloud secrets manager. All LBs pull from one source. |

---

## Edge Case 8: Thundering Herd After Server Recovery

### What Happens

A server was unhealthy, gets marked healthy again, and the LB immediately sends a **flood of traffic** to it — before it has warmed up (caches empty, connections cold, JVM not JIT-compiled).

### Step-by-Step

```
STEP 1: Server 3 was removed (crashed)
  Servers 1 and 2 handle all traffic

STEP 2: Server 3 recovers, passes 2 health checks → marked HEALTHY

STEP 3: LB starts routing to Server 3
  If using Round Robin: Server 3 immediately gets 33% of traffic
  But Server 3's cache is COLD (empty)
    → Every request is a cache miss
    → Every cache miss hits the database
    → Database gets hammered
    → Server 3 is slow → some requests timeout

STEP 4: Worst case — Server 3 overwhelmed by cold cache → crashes again
  → Cycle repeats
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Slow start / warm-up** | LB gradually increases traffic to recovered server. Start at 10%, increase to 100% over 60 seconds. Nginx Plus and HAProxy support this. |
| **Cache warming** | Before adding server to pool, pre-load cache with hot keys. |
| **Higher healthy threshold** | Require 5 consecutive successful health checks before adding back (not just 2). |
| **Connection limits** | Set initial maxconn low for recovered server; gradually increase. |

---

## Edge Case 9: Split Brain in Active-Passive LB

### What Happens

Both the active and passive LBs think THEY are the active one. Both claim the VIP. Network gets confused — some clients reach LB-1, others reach LB-2. Responses may be inconsistent.

### How It Happens

```
Normal state:
  LB-1 (Active, holds VIP) ←heartbeat→ LB-2 (Passive)

Network partition between LB-1 and LB-2:
  LB-1: "I'm active. I don't hear LB-2, but that's LB-2's problem."
  LB-2: "I don't hear LB-1... LB-1 must be dead. I'll take over the VIP!"

BOTH LBs now claim the VIP:
  Some switches route to LB-1 (based on old ARP)
  Some switches route to LB-2 (based on new ARP)
  
  Client A → LB-1 → Server 1
  Client B → LB-2 → Server 3
  Same user, different requests → may hit different servers with different state
```

### Why This Is Bad

- Inconsistent routing (same user hits different backends)
- Connection state confusion (TCP connection on LB-1, response on LB-2 → RST)
- If LBs maintain session tables, they diverge → session corruption

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Fencing / STONITH** | "Shoot The Other Node In The Head" — if passive takes over, it KILLS active (via IPMI/management interface). Only one can be alive. |
| **Quorum-based failover** | Need agreement from 3+ nodes before failover. Prevents single node from deciding alone. |
| **Shorter heartbeat interval** | 200ms heartbeat instead of 1s. Faster detection of true failures vs network blips. |
| **Cloud-managed LB** | AWS/GCP handles this internally. You don't deal with split-brain. |

---

## Edge Case 10: Large Request/Response Bodies

### What Happens

LB has buffer limits. If a request body (file upload) or response body (large API response) exceeds the buffer, the LB either drops it, returns an error, or consumes all its memory.

### Scenario

```
User uploads 2GB video file.
LB default buffer: 8MB.

LB tries to buffer the entire upload before forwarding → runs out of buffer
  → Returns "413 Request Entity Too Large"
  → User's upload fails

OR

LB buffers in memory → 1000 concurrent uploads × 2GB = 2TB RAM needed
  → LB runs out of memory → crashes → ALL traffic fails
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Stream/proxy mode** | LB forwards data as it arrives (doesn't buffer entire body). Nginx: `proxy_request_buffering off;` |
| **Increase limits** | `client_max_body_size 5G;` in Nginx. Match to expected upload size. |
| **Direct upload to storage** | Client uploads directly to S3 (pre-signed URL). Bypasses LB entirely for large files. |
| **L4 for large transfers** | Use L4 LB which just forwards TCP bytes — no HTTP body buffering. |

---

## Edge Case Summary Table

| # | Edge Case | Trigger | Impact | Key Mitigation |
|---|-----------|---------|--------|----------------|
| 1 | False positive health check | GC pause, network blip | Healthy server removed → overload others | Higher threshold, longer timeout |
| 2 | Cascading failure | One server removed, rest overloaded | Chain reaction → total outage | Over-provision, circuit breaker |
| 3 | Connection draining | Deploy without draining | In-flight requests killed | Enable draining, adequate timeout |
| 4 | WebSocket handling | Long-lived connections | Uneven load, upgrade failures | Least-conn, WebSocket-aware LB |
| 5 | Consistent hash hotspot | Celebrity key, viral content | One server crushed | Virtual nodes, bounded load |
| 6 | DNS caching skew | Clients cache same LB IP | One LB overloaded | Anycast, low TTL |
| 7 | SSL cert management | Many domains, expiry | HTTPS breaks, user trust lost | Auto-renew, ACM, monitoring |
| 8 | Thundering herd recovery | Cold server added back | Cache miss storm → DB hammered | Slow start, cache warming |
| 9 | Split-brain | Network partition between LBs | Both claim VIP → inconsistent routing | Fencing, quorum, cloud LB |
| 10 | Large bodies | Big uploads/downloads | LB buffer overflow → errors | Streaming, direct-to-storage |

---

## Quick Memory Card

```
FALSE POSITIVE:   Threshold 3+, longer timeout, lightweight /health
CASCADE:          Over-provision (60-70%), circuit breaker, maxconn
DRAINING:         Always enable. Timeout ≥ max request duration
WEBSOCKET:        Least-conn, WebSocket-aware LB, increase idle timeout
HOTSPOT:          Virtual nodes, bounded load, hot key replication
DNS CACHE:        Anycast or low TTL
SSL:              Auto-renew (ACM/Certbot), monitor expiry
THUNDERING HERD:  Slow start / warm-up when adding recovered server
SPLIT-BRAIN:      Fencing, quorum, or use cloud-managed LB
LARGE BODIES:     Streaming mode, direct-to-S3, increase body limits
```

---

**Next:** [[07_Tricks-and-Recognition]]
