# Design Instagram + Twitter — Social Media System

> **Social media design FAANG ka favorite question hai — Feed, Fan-out, Media sab samjho!**
> Instagram = Media heavy, Twitter = Text heavy + Real-time — dono ka core same hai

---

## 1. Requirements Clarification

### Instagram — Functional Requirements

| Feature | Description | Complexity |
|---------|-------------|------------|
| **Upload** | Photos/videos upload, multiple formats | Media storage (S3), transcoding |
| **Follow** | Follow/unfollow users | Graph DB or adjacency |
| **News Feed** | Home feed — followed users ke posts | Fan-out problem! |
| **Like/Comment** | Engagement on posts | High write volume |
| **Stories** | 24hr ephemeral content | Separate pipeline |
| **Explore** | Discover content (hashtags, trending) | Search + ranking |
| **Profile** | User's own posts grid | Simpler — user's posts only |

### Twitter — Functional Requirements

| Feature | Description | Complexity |
|---------|-------------|------------|
| **Tweet** | 280 char text (+ media optional) | Simpler than Instagram |
| **Follow** | Follow/unfollow | Same as Instagram |
| **Timeline** | Home (feed) + User (profile tweets) | Fan-out core problem |
| **Search** | Full-text search tweets | Elasticsearch |
| **Trending** | Hashtags, topics trending | Real-time aggregation |
| **Retweet** | Share others' tweets | Reference, not copy |
| **Notifications** | Likes, mentions, follows | Push + in-app |

### Non-Functional Requirements (Dono ke liye)

| NFR | Target | Why |
|-----|--------|-----|
| **Feed Latency** | < 200ms | User scroll kare, instant load |
| **Upload** | Async, eventual | Media process time lag sakta |
| **Availability** | 99.99% | Social media = always on |
| **Consistency** | Eventual OK for feed | Strong consistency zaroori nahi |
| **Scale** | 500M+ users, 10B+ posts | Massive read/write |

### Common Patterns (Dono mein)

```
┌─────────────────────────────────────────────────────────────────┐
│  SOCIAL MEDIA CORE PATTERNS                                      │
├─────────────────────────────────────────────────────────────────┤
│  • Fan-out: Followers ko content kaise deliver? (Push vs Pull)   │
│  • Feed Ranking: Chronological vs Algorithmic                    │
│  • Media: Upload → Process → Store → CDN deliver                 │
│  • Graph: Follow relationship — who follows whom                 │
│  • Notifications: Real-time + Push                              │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. Back of the Envelope Estimation

### Assumptions (Twitter-scale)

- **500M DAU** (Daily Active Users)
- **200M tweets/day** = ~2300 tweets/sec
- **User follows ~200** people on average
- **Feed reads**: 5 refreshes/user/day = 2.5B feed reads/day = ~29K QPS
- **Peak**: 3x = ~87K QPS feed, ~7K QPS write

### Storage (5 years)

| Data | Size/Unit | Total |
|------|-----------|-------|
| Tweet (280 chars + metadata) | ~500 bytes | 200M × 365 × 5 × 500B = ~180 TB |
| User (profile) | ~1 KB | 500M × 1KB = 500 GB |
| Follow graph | 8 bytes/edge | 500M × 200 × 8 = 800 GB |
| Media (Instagram) | 2 MB/photo avg | 100M photos/day × 2MB = 200 TB/day (!!) |

**Matlab**: Media storage >> Text. CDN + compression critical.

### Real-World Analogy: Newspaper vs Social Feed

Newspaper = sabko same content, fixed layout. Social feed = har user ka alag content (follows ke hisaab se), dynamic. Instagram/Twitter = personalized newspaper jo real-time update hota hai. Fan-out problem = editor (poster) ka content sab readers (followers) tak kaise pahunche — efficiently!

---

## 3. High Level Design

### 3.1 Overall Architecture (Unified View)

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                         SOCIAL MEDIA PLATFORM (Instagram + Twitter)                    │
└─────────────────────────────────────────────────────────────────────────────────────┘

    ┌──────────┐     ┌─────────────┐     ┌──────────────────────────────────────────────────┐
    │  Mobile  │     │  CDN        │     │              API Gateway / Load Balancer           │
    │  / Web   │────►│  (Static,   │────►│                                                      │
    │  Client  │     │   Media)    │     │  ┌────────────┐ ┌────────────┐ ┌──────────────┐   │
    └──────────┘     └─────────────┘     │  │ Post/      │ │ Feed       │ │ User/Follow  │   │
         │                  │           │  │ Tweet      │ │ Service    │ │ Service      │   │
         │                  │           │  │ Service    │ │            │ │              │   │
         │                  │           │  └─────┬──────┘ └─────┬──────┘ └──────┬───────┘   │
         │                  │           └───────┼──────────────┼───────────────┼───────────┘
         │                  │                   │              │               │
         │                  │           ┌───────▼──────┐ ┌─────▼─────┐  ┌──────▼──────┐
         │                  │           │ Message     │ │  Redis    │  │  MySQL      │
         │                  │           │ Queue        │ │  (Feed    │  │  (Users,    │
         │                  │           │ (Kafka)      │ │  Cache)   │  │  Follows)   │
         │                  │           └───────┬──────┘ └───────────┘  └─────────────┘
         │                  │                   │
         │                  │           ┌───────▼──────────────────────────────────────┐
         │                  │           │  Cassandra / DynamoDB (Posts, Timeline)      │
         │                  │           └─────────────────────────────────────────────┘
         │                  │
         │                  │           ┌──────────────────────────────────────────────┐
         │                  └──────────►  S3 / Blob Storage (Photos, Videos)          │
         │                               └──────────────────────────────────────────────┘
         │
         └─────────────────────────────►  Push Notification Service (FCM/APNs)
```

### 3.2 Data Flow — Post Creation

```
User posts photo/tweet
        │
        ▼
┌───────────────┐
│ API Server    │ ──► Validate, Auth
└───────┬───────┘
        │
        ├──► [Media] Upload to S3 ──► Transcode (video) ──► CDN URL
        │
        ├──► [Metadata] Save to Posts DB (Cassandra)
        │
        └──► [Fan-out] Publish to Kafka ──► Feed Pre-compute Workers
                                                    │
                                                    ▼
                                            Populate followers' feed caches
```

### 3.3 Data Flow — Feed Read

```
User opens app / refreshes feed
        │
        ▼
┌───────────────┐
│ Feed Service  │
└───────┬───────┘
        │
        ├──► Check Redis (pre-computed feed) ── HIT ──► Return
        │
        └──► MISS ──► Fetch from Cassandra (user's feed) ──► Merge, Rank ──► Return
```

---

## 4. API Design

### Instagram-style APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/posts` | Create post (multipart: image + caption) |
| `GET` | `/api/v1/feed` | Get home feed (paginated) |
| `GET` | `/api/v1/users/{id}/posts` | User's posts (profile) |
| `POST` | `/api/v1/posts/{id}/like` | Like post |
| `POST` | `/api/v1/posts/{id}/comments` | Add comment |
| `POST` | `/api/v1/follow/{user_id}` | Follow user |
| `GET` | `/api/v1/explore` | Explore feed (hashtags, trending) |
| `POST` | `/api/v1/stories` | Upload story |

### Twitter-style APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/tweets` | Create tweet |
| `GET` | `/api/v1/timeline/home` | Home timeline |
| `GET` | `/api/v1/timeline/user/{id}` | User's tweets |
| `POST` | `/api/v1/tweets/{id}/retweet` | Retweet |
| `GET` | `/api/v1/search` | Search tweets (q=query) |
| `GET` | `/api/v1/trending` | Trending topics |
| `POST` | `/api/v1/follow/{user_id}` | Follow user |

### Feed API Response Structure

```json
{
  "feed": [
    {
      "id": "post_123",
      "user": { "id": "u1", "username": "john", "avatar": "cdn.url/av1.jpg" },
      "content": "Caption or tweet text",
      "media_url": "cdn.url/photo.jpg",
      "likes": 150,
      "comments_count": 12,
      "created_at": "2024-01-15T10:30:00Z"
    }
  ],
  "next_cursor": "eyJpZCI6MTIzfQ==",
  "has_more": true
}
```

---

## 5. Data Model / Database Schema

### Users (MySQL — relational, ACID)

```sql
CREATE TABLE users (
    id BIGINT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    email VARCHAR(255),
    password_hash VARCHAR(255),
    avatar_url VARCHAR(500),
    bio TEXT,
    created_at TIMESTAMP
);
```

### Follow Graph (MySQL or Neo4j)

```sql
CREATE TABLE follows (
    follower_id BIGINT,
    followee_id BIGINT,
    created_at TIMESTAMP,
    PRIMARY KEY (follower_id, followee_id),
    INDEX idx_followee (followee_id)
);
```

### Posts/Tweets (Cassandra — write-heavy, partition by user)

```
posts table:
  Partition Key: user_id
  Clustering Key: created_at DESC
  Columns: post_id, content, media_urls, likes_count, comments_count
```

### Feed Cache (Redis)

```
Key: feed:user:{user_id}
Value: Sorted Set (post_id, score=timestamp)
TTL: 7 days
```

### Media Metadata

```sql
CREATE TABLE media (
    id BIGINT PRIMARY KEY,
    post_id BIGINT,
    url VARCHAR(500),      -- CDN URL
    type ENUM('image','video'),
    width INT, height INT,
    created_at TIMESTAMP
);
```

---

## 6. Deep Dive — Key Components

### 6.1 The Fan-Out Problem — Sabse Important!

**Problem**: User A (1M followers) ek post karta hai. 1M followers ko feed mein kaise add karein?

```
                    FAN-OUT OPTIONS
                    
┌─────────────────────────────────────────────────────────────────────────────┐
│  PUSH (Fan-out on Write)                                                     │
│  Post create hote hi → 1M followers ke feed cache mein write                 │
│  Pros: Read fast (feed already ready)                                        │
│  Cons: Celebrity post = 1M writes! Slow, expensive                           │
├─────────────────────────────────────────────────────────────────────────────┤
│  PULL (Fan-out on Read)                                                      │
│  User feed request → Fetch 200 followees ke recent posts → Merge             │
│  Pros: Write simple (1 write only)                                           │
│  Cons: Read slow (200 DB queries!), complex merge                            │
├─────────────────────────────────────────────────────────────────────────────┤
│  HYBRID (Industry standard!)                                                 │
│  • Normal users (< 10K followers): PUSH — pre-compute feed                   │
│  • Celebrities (> 10K): PULL — on read, merge celebrity posts                │
│  Best of both!                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 6.2 Hybrid Fan-Out — Detailed

```
User posts (followers = N)
        │
        ▼
    N < 10,000?
        │
    YES ├──► Push to all N followers' Redis feed cache
        │
    NO  └──► Store in "celebrity posts" table only
             On feed read: Merge (normal feed from cache) + (celebrity posts from DB)
```

**Twitter/Instagram dono hybrid use karte hain!**

**Celebrity Problem — Detailed:**
```
User with 50M followers posts
  → Push to 50M feeds? = 50M Redis writes, 10+ minutes!
  → Instead: Store in "celebrity_posts" table
  → On feed read: 
      normal_feed = Redis (pre-computed for normal followees)
      celebrity_feed = DB query (recent posts from followed celebrities)
      merged = merge(normal_feed, celebrity_feed) by timestamp
```

### 6.3 Feed Ranking — Chronological vs Algorithmic

| Mode | How | Use Case |
|------|-----|----------|
| **Chronological** | Sort by created_at DESC | Twitter default, simple |
| **Algorithmic** | Score = f(recency, engagement, relationship) | Instagram, Facebook — "best" posts first |

**Algorithmic formula (simplified)**:
```
score = w1 * recency + w2 * likes + w3 * comments + w4 * relationship_strength
```

**Ranking factors (Instagram-style):**
| Factor | Weight | Why |
|--------|--------|-----|
| Recency | High | Fresh content preferred |
| Engagement | High | Likes, comments, saves |
| Relationship | Medium | Close friends > acquaintances |
| Interest | Medium | Past engagement with similar content |
| Frequency | Low | Don't overwhelm from one user |

### 6.4 Media Pipeline (Instagram)

```
Upload (raw photo 5MB)
    │
    ▼
┌─────────────┐
│ API Server  │ ──► S3 raw upload
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ Transcoding │ ──► Multiple sizes: thumbnail, medium, full
│ Workers     │     Format: WebP, JPEG
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ CDN         │ ──► CloudFront/Cloudflare
│ Invalidate  │     Edge cache
└─────────────┘
```

**Media sizes (typical):**
| Size | Dimensions | Use Case |
|------|------------|----------|
| Thumbnail | 150×150 | Feed grid, preview |
| Medium | 640×640 | Feed view |
| Full | Original | Zoom, download |
| Video | 360p, 720p, 1080p | Adaptive streaming |

**Upload flow (client):**
1. Client gets pre-signed S3 URL from API
2. Client uploads directly to S3 (bypasses app server!)
3. Client notifies API: "upload done, key=xyz"
4. API triggers async transcoding job
5. When done, post goes live

### 6.5 Search (Twitter)

```
User searches "cricket"
        │
        ▼
┌─────────────────┐
│ Elasticsearch   │ ──► Index: tweets
│                 │     Fields: content, hashtags, user, created_at
└────────┬────────┘
         │
         ▼
    Ranked results (TF-IDF + recency + engagement)
```

### 6.6 Trending

```
┌─────────────────────────────────────────────────────────────┐
│  Real-time aggregation (Redis / Flink)                        │
│  • Sliding window: last 1 hour                                │
│  • Count hashtag mentions                                     │
│  • Top K → Trending list                                      │
│  • Update every 5 min                                         │
└─────────────────────────────────────────────────────────────┘
```

**Trending algorithm options:**
| Approach | Pros | Cons |
|----------|------|------|
| Simple count | Easy | Spam, bots can game |
| Weighted (recency decay) | Recent surge matters more | More complex |
| Velocity-based | "Rising" vs "Top" | Need history |
| ML-based | Personalized trending | Heavy compute |

**Redis implementation (simplified):**
```
ZINCRBY trending:hashtags 1 "#cricket"   (on each tweet)
ZREVRANGE trending:hashtags 0 9          (top 10)
EXPIRE key 3600                          (1 hr window)
```

### 6.7 Stories (Ephemeral)

- **Storage**: Separate table, TTL = 24 hours
- **Delivery**: Same feed service, filter `type=story`
- **Auto-delete**: Cron job or DynamoDB TTL

### 6.8 Notifications

```
Event (like, comment, follow, mention)
        │
        ▼
┌───────────────┐
│ Notification  │ ──► Save to DB (notification center)
│ Service       │
└───────┬───────┘
        │
        ├──► WebSocket (if user online) ──► Real-time badge
        │
        └──► Push (FCM/APNs) if user offline
```

### 6.9 Hashtags & Mentions

- **Hashtags**: Extract from post content, store in `post_hashtags` table (post_id, hashtag)
- **Mentions**: Extract @username, notify mentioned user, link in notification
- **Trending hashtags**: Count in sliding window (Redis sorted set or Flink)

### 6.10 Retweet vs Quote Tweet

| Type | Storage | Display |
|------|---------|---------|
| Retweet | Reference to original tweet_id only | Show original in timeline |
| Quote Tweet | New tweet + reference to original | Show both in one card |

### 6.11 Feed Pagination — Cursor vs Offset

```
Offset: LIMIT 20 OFFSET 100 — Skip 100, take 20
  Problem: New posts add hone pe duplicate/miss (page drift)

Cursor: WHERE created_at < last_seen ORDER BY created_at DESC LIMIT 20
  Better: Stable, no drift, consistent
```

---

## 7. Bottlenecks and Solutions

| Bottleneck | Problem | Solution |
|------------|---------|----------|
| **Celebrity fan-out** | 1 post = 10M writes | Hybrid: Don't push, pull on read |
| **Feed merge latency** | 200 users × 10 posts = 2000 fetches | Pre-compute + cache |
| **Media upload** | Large files block | Async: Upload URL return, background process |
| **Search scale** | Full-text on 1B tweets | Elasticsearch sharded, index only recent |
| **Hot partition** | One celebrity's posts | Shard by user_id, celebrity separate |
| **Write amplification** | 1 post → N feed writes | Batch writes, async queue |

### Sharding Strategy

| Data | Shard Key | Why |
|------|-----------|-----|
| Users | user_id | Even distribution |
| Posts | user_id | User's posts together |
| Feed | user_id | Each user's feed independent |
| Follows | follower_id | "Who I follow" queries |

---

## 8. Scaling Improvements

```
Phase 1: Monolith + MySQL
    │
    ▼
Phase 2: Separate services (Post, Feed, User)
    │
    ▼
Phase 3: Cassandra for posts, Redis for feed cache
    │
    ▼
Phase 4: Kafka for async fan-out, worker pool
    │
    ▼
Phase 5: CDN for media, Elasticsearch for search
    │
    ▼
Phase 6: Hybrid fan-out, celebrity handling
    │
    ▼
Phase 7: Multi-region, read replicas
```

### Database Choices Summary

| Data | DB Choice | Reason |
|------|-----------|--------|
| Users, Auth | MySQL | ACID, relational |
| Follow graph | MySQL / Neo4j | Graph queries |
| Posts | Cassandra | Write-heavy, partition by user |
| Feed cache | Redis | Fast read, TTL |
| Search | Elasticsearch | Full-text |
| Media | S3/Blob | Object storage |
| Analytics | Data warehouse | OLAP |

---

## 9. Trade-offs Discussed

| Decision | Option A | Option B | Choice | Why |
|----------|----------|----------|--------|-----|
| **Fan-out** | Push | Pull | Hybrid | Celebrity problem solve |
| **Feed** | Chronological | Algorithmic | Both (user choice) | Engagement vs simplicity |
| **Consistency** | Strong | Eventual | Eventual | Feed can lag few secs |
| **Media** | Sync upload | Async | Async | UX — show progress |
| **Search** | DB LIKE | Elasticsearch | ES | Scale, relevance |
| **Notifications** | Polling | Push | Push | Real-time, battery |

---

## 10. Interview Questions

1. **Celebrity joins** — 10M followers, first post. Kaise handle? (Lazy fan-out, background job)
2. **Unfollow** — User unfollows. Feed se posts hatao? (Yes, remove from cache)
3. **Delete post** — Post delete. Followers' feed? (Async invalidation, eventual)
4. **Feed pagination** — Cursor vs offset? (Cursor — consistent, no skip)
5. **Real-time** — New post instantly dikhe? (WebSocket or short polling)
6. **Viral post** — 1M likes in 1 min. DB? (Counter cache, async persist)
7. **Explore** — Non-followed content? (Recommendation engine, ML)
8. **Feed consistency** — User A follows B, B just posted. When dikhe? (Eventual, few sec lag OK)
9. **Multi-region** — User travels, feed from different DC? (User data replicate, read from nearest)
10. **Ad insertion** — Feed mein ads kaise? (Separate ad service, merge at rank step)

---

## 11. 1 Minute Recall Block

```
┌─────────────────────────────────────────────────────────────────┐
│  INSTAGRAM + TWITTER — 60 SECOND RECALL                           │
├─────────────────────────────────────────────────────────────────┤
│  1. CORE: Post/Tweet, Follow, Feed, Like, Search                  │
│  2. FAN-OUT: Hybrid — Push for normal, Pull for celebrity        │
│  3. FEED: Pre-compute in Redis, merge celebrity on read          │
│  4. MEDIA: S3 → Transcode → CDN (Instagram)                      │
│  5. DB: MySQL (users), Cassandra (posts), Redis (feed)           │
│  6. SEARCH: Elasticsearch                                        │
│  7. TRENDING: Sliding window aggregation                         │
└─────────────────────────────────────────────────────────────────┘
```

### 5 Bullet Memory Hooks

1. **Hybrid Fan-out** — Celebrity = pull, normal = push
2. **Feed in Redis** — Pre-computed sorted set, user_id partition
3. **Media ≠ DB** — S3 for files, DB for metadata only
4. **Cassandra for posts** — Write-heavy, partition by user_id
5. **Eventual consistency** — Feed 2-3 sec lag OK, strong nahi chahiye

---

## Appendix: Feed Pre-computation Flow (Detailed)

```
User B (10K followers) posts
        │
        ▼
Kafka: "new_post" event { post_id, user_id=B, timestamp }
        │
        ▼
Fan-out Worker (consumes event)
        │
        ├──► Get followers of B from Follow Service (cached)
        │    → [user_1, user_2, ..., user_10000]
        │
        ├──► Batch write to Redis (pipeline)
        │    For each follower f:
        │      ZADD feed:user:{f} {timestamp} {post_id}
        │      ZREMRANGEBYRANK feed:user:{f} 0 -1001  (keep top 1000)
        │
        └──► Done in ~2-5 seconds (batched)
```

### Fan-out Worker Scaling

- **Partition by poster_id**: Same poster's fan-out = same partition = ordered
- **Consumer group**: N workers, each handles subset of posters
- **Backpressure**: If queue builds up, add more workers

### Explore/Discovery Pipeline

```
┌─────────────────────────────────────────────────────────────┐
│  Explore = Content user doesn't follow                        │
│  1. Candidate generation: Same interest users' posts          │
│  2. Ranking: Engagement, freshness, diversity                 │
│  3. Filtering: Already seen, blocked, NSFW                     │
│  4. Serve: Paginated, personalized                            │
└─────────────────────────────────────────────────────────────┘
```

---

## Appendix: Database Schema (Complete)

```sql
-- Users
CREATE TABLE users (
    id BIGINT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    email VARCHAR(255),
    created_at TIMESTAMP
);

-- Follows (directed graph)
CREATE TABLE follows (
    follower_id BIGINT,
    followee_id BIGINT,
    created_at TIMESTAMP,
    PRIMARY KEY (follower_id, followee_id)
);

-- Posts (simplified - actual in Cassandra)
CREATE TABLE posts (
    id BIGINT PRIMARY KEY,
    user_id BIGINT,
    content TEXT,
    media_urls JSON,
    created_at TIMESTAMP,
    INDEX idx_user_time (user_id, created_at DESC)
);

-- Likes (denormalized count in posts, this for "who liked")
CREATE TABLE likes (
    post_id BIGINT,
    user_id BIGINT,
    created_at TIMESTAMP,
    PRIMARY KEY (post_id, user_id)
);
```

### Interview Tips — Social Feed

1. **Fan-out is the key** — Push vs Pull vs Hybrid. Celebrity = pull!
2. **Feed = pre-computed** — Redis sorted set, user_id partition
3. **Media separate** — S3 + CDN, never through app server for upload
4. **Ranking** — Chronological simple, Algorithmic = engagement + recency
5. **Scale path** — Kafka for fan-out, Cassandra for posts, Redis for feed
6. **Cursor pagination** — Offset causes drift, cursor stable

---

*End of Instagram + Twitter Design — Social media system ab tum design kar sakte ho!*
