# Checkpointing, Fault Tolerance & Exactly-Once Semantics

Streaming runs indefinitely; failures are inevitable. **Checkpointing** stores **metadata and state snapshots** so a query can **restart** consistently. **End-to-end exactly-once** is a **system property**: Spark’s processing layer + **idempotent** sinks + **replayable** sources.

---

## 1. What a Checkpoint Contains (Conceptual)

A checkpoint directory typically holds:

| Artifact | Purpose |
| -------- | ------- |
| **Offset log** | Progress in each source (Kafka partitions, file offsets, etc.). |
| **State snapshots** | Serialized state for stateful operators. |
| **Run metadata** | Query configuration and lineage needed to resume. |

Exact layout evolves by Spark version, but the **contract** is: **restart from last committed epoch** without manual offset edits.

---

## 2. Recovery Model

On **clean restart** with the **same** checkpoint location:

1. Restore **state** and **offsets** as of the **last successful batch commit**.
2. **Replay** sources from committed offsets if needed (source-dependent).
3. Continue processing **forward**.

If checkpoint is **lost** or **corrupted**, you may need to **reset** offsets deliberately—treating recovery as **at-least-once** unless the sink deduplicates.

---

## 3. Definitions of Delivery Semantics

| Semantics | Meaning (informal) |
| --------- | ------------------ |
| **At-most-once** | Loss possible; no duplicates on retry (weak for analytics). |
| **At-least-once** | No loss on retry; **duplicates** possible without dedup. |
| **Exactly-once** | Each record’s effect **once** on **output**—requires cooperation across source, engine, and sink. |

Spark Structured Streaming aims for **exactly-once** **checkpoint-based** semantics **for state and offsets** when sinks support transactional/idempotent commits **aligned** with checkpoint epochs.

---

## 4. Exactly-Once: End-to-End Reality

Even if Spark **deduplicates internally**, a sink may still see duplicates if:

- Writes are **retried** after partial failure.
- Commit order differs from processing order.

**Idempotent sink writes** (e.g., merge by primary key into Delta/Iceberg, Kafka transactional producer with idempotent config) close the gap.

---

## 5. WAL and Atomic Commits (Conceptual)

Structured Streaming uses a **write-ahead log** style protocol for metadata: **commit** of offsets + outputs is designed to be **atomic** relative to checkpoint epochs (details vary by sink integration).

**foreachBatch** shifts responsibility: **you** implement idempotent writes using **batchId** and sink-specific transactions.

---

## 6. Operational Practices

- Use **durable**, **low-latency** storage for checkpoint paths (HDFS, S3 with consistency, cloud FS with strong read-after-write guarantees where required).
- **Never** share one checkpoint directory across **two** active queries writing the same logical pipeline.
- Tune **trigger** so batches complete reliably—**incomplete** batches should not advance commits.

---

## 7. Key Takeaways

1. **Checkpoint** = source of truth for **offsets + state** across failures.
2. **Exactly-once** is **end-to-end**—Spark + **replayable source** + **idempotent sink**.
3. **foreachBatch** users own **external** transactional boundaries.
4. Protect checkpoint storage like **database** data—it defines your pipeline’s continuity.

---
