# Design URL Shortener — Tricks and Recognition

> **Permanent Recall:** Base62 with 7 chars = 3.5 trillion combinations; KGS is the cleanest key gen at scale; 301 = browser caches (less load, no analytics) vs 302 = server tracks every redirect; Redis for sub-millisecond redirects; URL shortener is the STARTER design problem—master it first, then Pastebin, file sharing.

---

## Key Insights

### 1. Base62 Math

- **Character set:** `0-9` (10) + `a-z` (26) + `A-Z` (26) = 62
- **7 characters:** 62^7 ≈ **3.5 trillion** unique codes
- **6 characters:** 62^6 ≈ 57 billion
- At 100M URLs/day, 7 chars lasts ~35,000 days (~96 years)

> **FAANG Tip:** Memorize 62^7 ≈ 3.5T. Interviewers love when you cite the math.

---

### 2. KGS (Key Generation Service) — Cleanest Approach

```
    ┌─────────────────────────────────────────────────┐
    │  KGS (background)                                │
    │  1. Generate keys in batches (counter + base62)  │
    │  2. Push to Redis list or DB key_pool           │
    │  3. Refill when pool < 100K                      │
    └─────────────────────────────────────────────────┘
                          │
    ┌─────────────────────────────────────────────────┐
    │  API (request path)                              │
    │  LPOP key_pool  →  get unique key  →  no block   │
    └─────────────────────────────────────────────────┘
```

**Why better than hash:** No collisions, no retries, no blocking. Decouples key creation from latency path.

---

### 3. 301 vs 302 — The Critical Choice

| Aspect | 301 Moved Permanently | 302 Found |
|--------|------------------------|-----------|
| **Browser** | Caches redirect | Fetches every time |
| **Analytics** | Miss subsequent hits | Count every redirect |
| **Change destination** | Hard (cached) | Easy |
| **Server load** | Low | Higher |
| **Use when** | Destination never changes | Analytics, dynamic destination |

**Interview line:** "We use 302 so we can track every click. 301 would reduce load but we'd lose analytics."

---

### 4. Redis for Sub-Millisecond Redirects

- **Latency:** Redis ~0.1–1 ms; DB ~5–50 ms
- **Capacity:** Redis ~100K QPS per instance
- **Cache-aside:** Check Redis → miss → DB → populate Redis
- **Hot URLs:** 20% of URLs get 80% traffic; cache holds millions of mappings

---

### 5. This Is the STARTER Problem

URL shortener is often the **first** system design question. Master it because:

- Covers: API design, storage, caching, key generation
- Foundation for: Pastebin (same + content storage), file sharing (same + large objects)
- Teaches: read-heavy optimization, capacity estimation, tradeoffs

---

## Recognition Patterns

| Interview hint | Think |
|----------------|-------|
| "Design bit.ly" | URL shortener; shorten + redirect; KGS, Redis, DB |
| "Short links with analytics" | 302; async events to analytics |
| "Custom short URLs" | Alias validation, conflict handling |
| "Billions of URLs" | Sharding by short_code hash; KGS per shard |
| "Link expires" | expires_at, cleanup job, cache TTL |

---

## Formula Cheat Sheet

```
QPS (write)  = URLs per day / 86400
QPS (read)   = QPS (write) × read:write ratio
Storage      = records × bytes_per_record × years × days
Base62 size  = log62(required_ids)  →  7 chars for 3.5T
Cache hit    = ~80% for Pareto (20% URLs = 80% traffic)
```

---

## 30-SECOND REVISION BOX

```
BASE62: 7 chars = 3.5T; 62^7
KGS: Pre-gen pool; atomic pop; no collision
301: Cache, no analytics | 302: Track, flexible
REDIS: Sub-ms; cache-aside; 100K QPS
STARTER: Master this → Pastebin, file share
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
