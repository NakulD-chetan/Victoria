# Back-of-Envelope Estimation — Mental Model

>

---

## How to Think About Estimation

- **Order of magnitude is enough** — 100K vs 200K QPS → same architecture; 100K vs 10M → different.
- **Don't be precise** — Say "~100K QPS" or "on the order of 100K," never "98,437 QPS."
- **Napkin math** — Round to powers of 10; 86400 ≈ 10^5; 1 day = 10^5 seconds.

```
    PRECISION LEVELS
    Bad:   "We need exactly 47,382 QPS"
    Good:  "~50K QPS, could be 100K at peak"
    Best:  "Order of 10^5 QPS — we'll need hundreds of web servers"
```

---

## 6-Step Estimation Framework

```mermaid
flowchart TD
    A[1. Start with Users] --> B[2. Actions per user]
    B --> C[3. Calculate QPS]
    C --> D[4. Storage per item]
    D --> E[5. Total storage]
    E --> F[6. Bandwidth]
```




| Step | Question                  | Formula / Approach                      |
| ---- | ------------------------- | --------------------------------------- |
| 1    | How many users?           | DAU, MAU, or total registered           |
| 2    | Actions per user per day? | Tweets, messages, views, searches       |
| 3    | QPS                       | Total actions / 86400; peak ≈ 2–10× avg |
| 4    | Bytes per item?           | Text, metadata, media size              |
| 5    | Total storage             | items × bytes × replication             |
| 6    | Bandwidth                 | QPS × response_size × 8 (bits)          |


---

## Practice Examples

### Example 1: Estimate Twitter QPS

**Assumptions:** 300M DAU, 5 tweets/user/day, read:write = 100:1.


| Step      | Calculation                   |
| --------- | ----------------------------- |
| Writes    | 300M × 5 = 1.5B tweets/day    |
| Write QPS | 1.5B / 86400 ≈ 17K writes/sec |
| Reads     | 100× writes = 150B reads/day  |
| Read QPS  | 150B / 86400 ≈ 1.7M reads/sec |
| Peak      | 3× avg → ~5M read QPS         |


> **FAANG Tip:** Twitter-scale is ~millions of read QPS. You need CDN, cache, read replicas—not a single DB.

---

### Example 2: Estimate Netflix Storage

**Assumptions:** 200M users, 1000 titles, avg 2GB/title (1080p), 5-year retention.


| Step                                | Calculation              |
| ----------------------------------- | ------------------------ |
| Content size                        | 1000 × 2GB = 2TB raw     |
| With replication (3×)               | 6TB                      |
| 5-year growth                       | Assume 2× growth → ~12TB |
| User data (profiles, watch history) | 200M × 1KB ≈ 200GB       |


**Total:** Order of **10–20 TB** for catalog; user data negligible.

---

### Example 3: Estimate WhatsApp Bandwidth

**Assumptions:** 2B DAU, 50 messages/user/day, avg 1KB/message, read:write 1:1.


| Step         | Calculation                                     |
| ------------ | ----------------------------------------------- |
| Messages/day | 2B × 50 = 100B                                  |
| Messages/sec | 100B / 86400 ≈ 1.2M                             |
| Size         | 1.2M × 1KB = 1.2 GB/s                           |
| Bandwidth    | 1.2 GB/s × 8 ≈ **10 Gbps** (order of magnitude) |


---

## Worked Example: Social Media Feed

```
Users:        100M DAU
Actions:      20 feed views / user / day
Read:Write:   100:1 (mostly reads)

Read QPS:  100M × 20 / 86400 ≈ 23K avg
Peak:      23K × 3 ≈ 70K read QPS

Storage (1 year): 100M users × 100 posts × 1KB ≈ 10 TB
```

---

## When to Round


| Original | Rounded      | Why                   |
| -------- | ------------ | --------------------- |
| 86400    | 10^5 or 100K | Easier mental math    |
| 47,382   | 50K          | Order of magnitude    |
| 1.73M    | 2M           | Cleaner communication |
| 0.00015  | 150μs        | Use human units       |


---

## Sanity Checks

After estimation, validate against known references:


| Your Estimate | Reference           | Action                                |
| ------------- | ------------------- | ------------------------------------- |
| 100K QPS      | Twitter ~millions   | You're smaller—single region may work |
| 1M QPS        | Google ~100K search | You're larger—need serious scale      |
| 1 PB storage  | WhatsApp ~exabytes  | In ballpark for messaging             |


---

## Units to Keep Straight


| Concept    | Formula            | Example                |
| ---------- | ------------------ | ---------------------- |
| QPS        | requests / second  | 50K QPS                |
| Throughput | QPS × bytes        | 50K × 1KB = 50 MB/s    |
| Bandwidth  | Throughput × 8     | 50 MB/s × 8 = 400 Mbps |
| Latency    | Time per operation | 100ms p99              |


---

## 30-SECOND REVISION BOX

```
FRAMEWORK: Users → Actions → QPS → Storage/item → Total storage → Bandwidth
ROUND: 86400≈10^5, round to powers of 10
TWITTER: ~17K writes, ~2M reads (100:1)
NETFLIX: ~2TB catalog × replication
WHATSAPP: ~1.2M msg/s, ~10 Gbps
SANITY: Compare to Twitter, Google, WhatsApp scales
```

---

**Next: [[03_Design-Template]]**