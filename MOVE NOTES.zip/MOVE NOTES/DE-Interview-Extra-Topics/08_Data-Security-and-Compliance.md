# 08 — Data Security & Compliance

> **One-line:** Data security in DE means **protecting data at rest, in transit, and in use** — while complying with regulations like **GDPR**, **HIPAA**, and **CCPA** — a topic increasingly asked as companies face **real legal consequences** for data breaches.

---

## 1. Why This Matters for DE Interviews

| Reason | Detail |
|--------|--------|
| **Legal** | GDPR fines up to 4% of global revenue; HIPAA fines up to $1.9M per violation |
| **Trust** | Customers and partners require data protection guarantees |
| **Architecture** | Security shapes pipeline design — encryption, masking, access control |
| **Interview signal** | Shows you think beyond "just move data" — you think about **responsible** data engineering |

---

## 2. Core Security Concepts

### Encryption

| Type | What | When |
|------|------|------|
| **At Rest** | Data encrypted on disk/storage | S3 SSE, Snowflake auto-encryption, HDFS encryption zones |
| **In Transit** | Data encrypted during network transfer | TLS/SSL for Kafka, JDBC, API calls |
| **End-to-End** | Encrypted from source to final consumer | Sensitive pipelines (healthcare, finance) |

```
Source DB ──TLS──► Kafka ──TLS──► Spark ──TLS──► S3 (SSE-S3 / SSE-KMS)
               encrypted        encrypted       encrypted
               in transit       in transit       at rest
```

### Key Management

| Service | Platform |
|---------|----------|
| **AWS KMS** | Key Management Service — manages encryption keys |
| **Azure Key Vault** | Azure's key/secret management |
| **GCP Cloud KMS** | Google's key management |
| **HashiCorp Vault** | Multi-cloud, self-managed secrets and keys |

---

## 3. PII (Personally Identifiable Information)

### What Counts as PII

| Definitely PII | Context-Dependent |
|---------------|-------------------|
| Name, Email, Phone | IP Address |
| SSN, Passport, Aadhaar | Device ID |
| Credit card number | Location data |
| Date of birth | Cookie ID |
| Biometric data | Login timestamps |

### PII Handling Strategies

| Strategy | How It Works | When to Use |
|----------|-------------|-------------|
| **Masking** | Replace with fake/partial data: `john@gmail.com` → `j***@***.com` | Display in dashboards, dev/test environments |
| **Hashing** | One-way hash: `SHA256(email)` → irreversible string | When you need to join/match but not see original |
| **Tokenization** | Replace with random token; mapping stored in vault | Payment data (PCI DSS compliance) |
| **Encryption** | Encrypt with key; reversible by authorized users | When authorized users need original data |
| **Redaction** | Remove entirely from output | When column is not needed downstream |
| **Pseudonymization** | Replace identifying fields; mapping exists but separated | GDPR compliance (data still useful for analysis) |

### PII in Pipeline Architecture

```
Source (full PII)
    │
    ▼
Bronze (raw — PII present, restricted access)
    │
    ▼
Silver (PII hashed/masked — broader access)
    │
    ├──► Gold - Internal (masked PII — analyst access)
    │
    └──► Gold - External (fully redacted PII — public/partner access)
```

**Interview line:** "PII handling should be done at the **Silver layer** — raw Bronze retains original for compliance/audit, but Silver and Gold only expose **masked or hashed** versions."

---

## 4. Major Regulations

### GDPR (General Data Protection Regulation) — EU

| Right | What It Means for DE |
|-------|---------------------|
| **Right to Access** | Must be able to extract all data for a specific user |
| **Right to Erasure** (Right to be Forgotten) | Must delete user's data from **all** systems on request |
| **Data Portability** | Export user data in machine-readable format |
| **Consent** | Can only process data user consented to |
| **Data Minimization** | Only collect/store what's necessary |
| **Breach Notification** | Report breaches within 72 hours |

### Right to be Forgotten — DE Implementation Challenge

```
User requests deletion:
    │
    ├──► OLTP DB: DELETE FROM users WHERE id = 123 ✓ (easy)
    │
    ├──► Data Lake (Parquet files): 
    │    Can't delete from immutable files!
    │    Solutions:
    │    1. Rewrite partition without that user (expensive)
    │    2. Use Delta Lake MERGE (DELETE WHERE user_id = 123)
    │    3. Maintain deletion log → filter at query time
    │
    ├──► Kafka: Messages immutable in topics!
    │    Solutions:
    │    1. Tombstone messages (key = user_id, value = null)
    │    2. Log compaction removes old values
    │    3. Topic retention policy
    │
    ├──► Backups: Must track and purge from backups too
    │
    └──► Downstream: Propagate deletion to all consumers
```

### HIPAA (Healthcare) — Key Points

| Requirement | DE Impact |
|------------|-----------|
| **PHI protection** | Protected Health Information must be encrypted at rest and in transit |
| **Access logging** | All access to PHI must be audited |
| **Minimum necessary** | Only expose minimum data needed for the task |
| **BAA** | Business Associate Agreement required with cloud providers |

### CCPA (California) — Key Points

Similar to GDPR but for California residents. Right to know, delete, and opt-out of data sale.

---

## 5. Access Control Patterns

| Pattern | How It Works | Example |
|---------|-------------|---------|
| **RBAC** (Role-Based) | Roles define permissions; users assigned roles | `analyst` role → SELECT on Gold tables only |
| **ABAC** (Attribute-Based) | Policies based on attributes (user dept, data sensitivity) | User in EU → can access EU data only |
| **Column-Level** | Different columns visible to different roles | Analysts see `customer_id` but not `ssn` |
| **Row-Level** | Filter rows based on user attributes | Sales rep sees only their region's data |
| **Dynamic Masking** | Mask values based on who's querying | Admin sees full SSN; analyst sees `***-**-1234` |

### Snowflake Row Access Policy Example

```sql
CREATE ROW ACCESS POLICY region_filter AS (region VARCHAR)
  RETURNS BOOLEAN ->
    CASE
      WHEN CURRENT_ROLE() = 'ADMIN' THEN TRUE
      WHEN region = CURRENT_USER_REGION() THEN TRUE
      ELSE FALSE
    END;

ALTER TABLE sales ADD ROW ACCESS POLICY region_filter ON (region);
```

---

## 6. Data Classification

| Level | Examples | Handling |
|-------|----------|---------|
| **Public** | Product catalog, company blog | No restrictions |
| **Internal** | Employee directory, internal dashboards | Requires authentication |
| **Confidential** | Customer PII, financial data | Encryption, access control, audit |
| **Restricted** | SSN, credit cards, health records | Encryption, masking, minimal access, compliance |

**Interview tip:** "Data classification drives your entire security architecture — you don't encrypt everything the same way. **Restricted** data gets the heaviest protection."

---

## 7. Audit & Lineage

| Capability | Why It Matters | Tools |
|-----------|---------------|-------|
| **Access audit** | Who queried what data, when | Cloud audit logs, Snowflake ACCESS_HISTORY |
| **Data lineage** | Track data flow from source to destination | Unity Catalog, Apache Atlas, OpenMetadata |
| **Change tracking** | What changed in the pipeline, when, by whom | Git for code, Delta Lake versioning for data |

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "How do you handle PII in pipelines?" | Mask/hash at Silver layer; Bronze restricted; classify data; column-level security |
| "Explain Right to be Forgotten for a data lake" | Delta Lake DELETE/MERGE, rewrite partitions, deletion logs, propagate to downstream |
| "Encryption at rest vs in transit?" | At rest: S3 SSE, disk encryption. In transit: TLS/SSL for all network calls |
| "What is RBAC?" | Role-Based Access Control — roles have permissions, users get roles |
| "How do you audit data access?" | Cloud audit logs, query history, lineage tools, access policies |
| "GDPR impact on data pipelines?" | Consent tracking, deletion capability, data minimization, breach notification |
| "How do you handle sensitive data in dev/test?" | Masked/synthetic data — never use production PII in non-prod environments |

---

## Key Takeaways

- **Encryption** at rest (S3 SSE) and in transit (TLS) is **non-negotiable** for production pipelines.
- **PII handling**: mask/hash at Silver, restrict Bronze access, redact for external Gold.
- **GDPR Right to be Forgotten** is a real DE challenge — Delta Lake/Iceberg MERGE makes it feasible on lakes.
- **RBAC + column/row-level security** controls who sees what data.
- **Data classification** (Public → Restricted) drives security architecture decisions.
- **Audit logging** and **lineage** prove compliance — required by regulators.
- Always use **synthetic/masked data** for dev/test environments.

---
