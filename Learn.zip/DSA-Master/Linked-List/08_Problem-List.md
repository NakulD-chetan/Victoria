# Linked List — Problem List

> **Permanent Recall:** 30 problems, 10 MUST-DO. Focus: reversal, fast/slow, merge, two-pointer, composite. Study plan: Easy → Medium → Hard. FAANG favorites marked.

---

## MUST-DO (10 Problems) — Do These First


| #   | Problem                                          | Pattern            | Difficulty | Notes                              |
| --- | ------------------------------------------------ | ------------------ | ---------- | ---------------------------------- |
| 1   | **Reverse Linked List** (LC 206)                 | Reversal           | Easy       | prev/curr/next, foundation         |
| 2   | **Linked List Cycle** (LC 141)                   | Fast/Slow          | Easy       | Floyd's detection                  |
| 3   | **Merge Two Sorted Lists** (LC 21)               | Merge              | Easy       | Dummy head + compare               |
| 4   | **Linked List Cycle II** (LC 142)                | Fast/Slow          | Medium     | Find cycle entry                   |
| 5   | **Remove Nth Node From End** (LC 19)             | Two-pointer gap    | Medium     | Dummy + n+1 gap                    |
| 6   | **Reorder List** (LC 143)                        | Composite          | Medium     | Middle + reverse + interleave      |
| 7   | **Palindrome Linked List** (LC 234)              | Composite          | Easy       | Middle + reverse + compare         |
| 8   | **Copy List with Random Pointer** (LC 138)       | HashMap/Interleave | Medium     | Old→new mapping                    |
| 9   | **Merge K Sorted Lists** (LC 23)                 | Merge + Heap/D&C   | Hard       | O(N log k) with D&C or min-heap    |
| 10  | **LRU Cache** (LC 146)                           | DLL + HashMap      | Medium     | O(1) get/put                       |


---

## Easy (8 Problems)


| #   | Problem                                          | Pattern          | Key Idea                         |
| --- | ------------------------------------------------ | ---------------- | -------------------------------- |
| 11  | Middle of the Linked List (LC 876)               | Fast/Slow        | Slow at middle when fast at end  |
| 12  | Delete Node in a Linked List (LC 237)            | Copy + Skip      | Copy next val, skip next node    |
| 13  | Remove Linked List Elements (LC 203)             | Dummy + scan     | Dummy head, skip matching vals   |
| 14  | Intersection of Two Linked Lists (LC 160)        | Two pointers     | Length diff + align + walk       |
| 15  | Reverse Linked List (LC 206)                     | Reversal         | Both iterative and recursive     |
| 16  | Remove Duplicates from Sorted List (LC 83)       | Scan + skip      | Skip consecutive duplicates      |
| 17  | Convert Binary Number in LL to Integer (LC 1290) | Traversal        | bit shift: result = result*2+val |
| 18  | Merge Two Sorted Lists (LC 21)                   | Merge            | Dummy head + compare             |


---

## Medium (12 Problems)


| #   | Problem                                                   | Pattern            | Key Idea                            |
| --- | --------------------------------------------------------- | ------------------ | ----------------------------------- |
| 19  | **Add Two Numbers** (LC 2)                                | Traversal + carry  | Digit by digit, carry forward       |
| 20  | **Add Two Numbers II** (LC 445)                           | Stack or reverse   | Reverse or stack for MSB-first      |
| 21  | **Swap Nodes in Pairs** (LC 24)                           | Pointer rewiring   | Swap adjacent pairs                 |
| 22  | **Odd Even Linked List** (LC 328)                         | Split + join       | Odd list + even list, reconnect     |
| 23  | **Sort List** (LC 148)                                    | Merge sort         | Find middle, split, merge           |
| 24  | **Rotate List** (LC 61)                                   | Length + reconnect | Find length, mod k, reconnect       |
| 25  | **Partition List** (LC 86)                                | Two dummy lists    | < x list and >= x list, join        |
| 26  | **Remove Duplicates from Sorted List II** (LC 82)         | Dummy + skip group | Skip all nodes with duplicate vals  |
| 27  | **Reverse Linked List II** (LC 92)                        | Sublist reversal   | Find position, reverse between L-R  |
| 28  | **Flatten a Multilevel Doubly Linked List** (LC 430)      | DFS / recursion    | Flatten child lists in-place        |
| 29  | **Linked List in Binary Tree** (LC 1367)                  | DFS matching       | Match LL path in tree               |
| 30  | **Design Linked List** (LC 707)                           | Implementation     | Singly/doubly from scratch          |


---

## Hard (4 Problems)


| #   | Problem                                              | Pattern          | Key Idea                             |
| --- | ---------------------------------------------------- | ---------------- | ------------------------------------ |
| 31  | **Merge K Sorted Lists** (LC 23)                     | D&C or Heap      | Pairwise merge or min-heap           |
| 32  | **Reverse Nodes in k-Group** (LC 25)                 | Group reversal   | Reverse k nodes, connect, repeat     |
| 33  | **Linked List Random Node** (LC 382)                 | Reservoir sample | Reservoir sampling for random        |
| 34  | **Design Skiplist** (LC 1206)                        | Advanced LL      | Multi-level linked list              |


---

## By Pattern

### Reversal

- Reverse Linked List (LC 206)
- Reverse Linked List II (LC 92)
- Reverse Nodes in k-Group (LC 25)
- Swap Nodes in Pairs (LC 24)
- Palindrome Linked List (LC 234)

### Fast & Slow Pointers

- Linked List Cycle (LC 141)
- Linked List Cycle II (LC 142)
- Middle of the Linked List (LC 876)
- Palindrome Linked List (LC 234)
- Reorder List (LC 143)

### Merge

- Merge Two Sorted Lists (LC 21)
- Merge K Sorted Lists (LC 23)
- Sort List (LC 148)

### Two Pointers / Gap

- Remove Nth Node From End (LC 19)
- Intersection of Two Linked Lists (LC 160)
- Rotate List (LC 61)

### Dummy Head

- Remove Linked List Elements (LC 203)
- Remove Duplicates II (LC 82)
- Partition List (LC 86)
- Merge Two Sorted Lists (LC 21)

### Composite (Multiple Techniques)

- Palindrome Linked List (LC 234) — middle + reverse + compare
- Reorder List (LC 143) — middle + reverse + interleave
- Sort List (LC 148) — middle + merge sort

### HashMap + Linked List

- Copy List with Random Pointer (LC 138)
- LRU Cache (LC 146)

---

## Study Plan

### Week 1: Foundations

- Day 1–2: Concept.md, Mental-Model.md, Coding-Template.md
- Day 3: Reverse Linked List, Reverse Linked List II
- Day 4: Linked List Cycle I & II, Middle of LL
- Day 5: Merge Two Sorted Lists, Remove Nth From End

### Week 2: Patterns

- Day 1: Palindrome LL, Reorder List
- Day 2: Sort List, Swap Nodes in Pairs
- Day 3: Add Two Numbers, Odd Even LL
- Day 4: Copy List with Random Pointer, Partition List
- Day 5: Remove Duplicates II, Rotate List

### Week 3: Advanced

- Day 1–2: Merge K Sorted Lists, Reverse in k-Group
- Day 3: LRU Cache, Flatten Multilevel
- Day 4: Remaining Medium problems
- Day 5: Revision, mock interviews

---

## ASCII: Problem Difficulty Distribution

```
Easy:    ████████ (8)
Medium:  ████████████████████████ (16)  ← FAANG focus
Hard:    ████████ (4)
```

---

## LeetCode Quick Links (MUST-DO)


| Problem                       | LC # |
| ----------------------------- | ---- |
| Reverse Linked List           | 206  |
| Linked List Cycle             | 141  |
| Linked List Cycle II          | 142  |
| Merge Two Sorted Lists        | 21   |
| Remove Nth Node From End      | 19   |
| Reorder List                  | 143  |
| Palindrome Linked List        | 234  |
| Copy List with Random Pointer | 138  |
| Merge K Sorted Lists          | 23   |
| LRU Cache                     | 146  |


---

## FINAL MEMORY COMPRESSION BLOCK

```
MUST-DO: Reverse(206), Cycle(141,142), Merge2(21), MergeK(23),
         RemoveNth(19), Reorder(143), Palindrome(234),
         CopyRandom(138), LRU(146)
PATTERNS: Reversal(206,92,25,24), Fast/Slow(141,142,876),
          Merge(21,23,148), TwoPtr(19,160), Composite(234,143,148)
STUDY: Week1 foundations, Week2 patterns, Week3 advanced
```
