# How Uber Computes ETA - In Depth (Easy Language)

> Companion to: [19-How-Uber-Computes-ETA.md](19-How-Uber-Computes-ETA.md)

---

## The Scale

```
~500,000 ETA requests per second
18 million trips per day
1 trip generates ~1,000 ETA requests (before booking, during ride, etc.)
Sub-second response time required
```

---

## The Four ETA Scenarios

Uber computes ETAs at different stages of a ride:

```
1. EYEBALL ETA:
   You open the app and type a destination
   → "Your ride would take ~25 minutes"
   → Helps you decide whether to book

2. DISPATCH ETA:
   You book a ride
   → System needs ETA from each nearby driver to YOUR location
   → "Driver A: 3 min, Driver B: 5 min, Driver C: 7 min"
   → Picks the driver with shortest ETA

3. PICK UP ETA:
   Driver is assigned, driving to you
   → "Your driver arrives in 4 minutes"
   → Updates in real-time as driver moves

4. ON-TRIP ETA:
   You're in the car, going to destination
   → "Arriving in 18 minutes"
   → Updates continuously based on traffic
```

---

## The Map Is a Graph

### Converting Roads to Data

```
Real world:
  ┌────────────────┐
  │    Street A     │
  │ ←─────────────→ │
  ├───┐      ┌──────┤
  │   │ Int. │      │
  │ B │  ●   │  C   │   "Int." = Intersection
  │   │      │      │
  └───┘      └──────┘

Graph representation:
  Node 1 (Intersection A/B)  ─── Edge (Street A, 5 min) ──→  Node 2 (Intersection A/C)
        │                                                        │
  Edge (Street B, 3 min)                               Edge (Street C, 2 min)
        │                                                        │
        ↓                                                        ↓
  Node 3                                                   Node 4
```

- **Nodes** = road intersections
- **Edges** = road segments connecting intersections
- **Edge weights** = travel time (NOT distance!)
  - Highway: 10 km in 6 minutes (fast)
  - City road at rush hour: 1 km in 10 minutes (slow)

### Why Travel Time, Not Distance?

```
Route A: 5 km via highway → 5 minutes (fast)
Route B: 3 km via crowded city streets → 12 minutes (slow)

A distance-based algorithm would pick Route B (shorter).
A time-based algorithm correctly picks Route A (faster).
```

---

## The Routing Challenge - Why Dijkstra Isn't Enough

### Naive Approach: Dijkstra's Algorithm

```
Dijkstra finds the shortest path between two nodes in a graph.

For San Francisco:
  → ~500,000 intersections (nodes)
  → ~1,000,000 road segments (edges)
  
  Dijkstra: O(n log n) = O(500,000 × 19) ≈ 10 million operations
  
  At 500,000 ETA requests/second:
    = 5 TRILLION operations per second
    IMPOSSIBLE for real-time!
```

### The Breakthrough: Graph Partitioning

**Core idea**: Don't search the entire graph. Divide it into regions and only search at the boundaries.

```
San Francisco divided into 4 regions:
  ┌─────────┬─────────┐
  │ Region  │ Region  │
  │    A    │    B    │
  │    ●    │    ●    │  ← internal nodes
  │  ○   ○  │  ○   ○  │  ← boundary nodes
  ├──○───○──┼──○───○──┤
  │  ○   ○  │  ○   ○  │
  │    ●    │    ●    │
  │ Region  │ Region  │
  │    C    │    D    │
  └─────────┴─────────┘

● = internal nodes (many, ~125,000 per region)
○ = boundary nodes (few, ~175 per region)
```

### How Partitioned Routing Works

```
Route from Node X (in Region A) to Node Y (in Region D):

Step 1: PRECOMPUTED (done offline)
  Within each region, precompute shortest paths between ALL boundary nodes
  Region A: boundary node 1 → boundary node 2: 8 min (precomputed!)
  Region A: boundary node 1 → boundary node 3: 12 min (precomputed!)

Step 2: AT QUERY TIME
  a) Find path from X to boundary nodes of Region A (~175 nodes to consider)
  b) Use precomputed data to traverse Region B/C boundaries
  c) Find path from boundary nodes of Region D to Y

Step 3: COMPLEXITY IMPROVEMENT
  Without partitioning: search 500,000 nodes (area = πr²)
  With partitioning: search ~700 boundary nodes (perimeter = 2πr)
  
  500,000 → 700 = 714x faster!
```

**The math insight**: Full search grows with the AREA of the search space (πr²). Partitioned search grows with the PERIMETER (2πr). For a large city, this is a massive reduction.

---

## Traffic-Aware Edge Weights

### Static vs Dynamic Weights

```
Static (never changes):
  Road segment A→B: always 5 minutes
  → Wrong! Rush hour might make it 20 minutes!

Dynamic (changes based on conditions):
  Road segment A→B:
    - Monday 8 AM: 15 min (rush hour)
    - Monday 2 PM: 5 min (normal traffic)
    - Friday 6 PM: 25 min (weekend rush)
    - Sunday 6 AM: 3 min (empty roads)
    - Rainy day: +30% (wet roads, slower driving)
```

### Where Traffic Data Comes From

```
Historical data:
  → Millions of past trips
  → "On Tuesdays at 5 PM, segment A→B averages 12 minutes"
  → Good baseline

Real-time data:
  → GPS data from current Uber drivers on that segment
  → "Right now, drivers on segment A→B are averaging 18 minutes"
  → Adjusts for accidents, events, unexpected traffic

Combined:
  ETA = f(historical_average, real_time_speed, time_of_day, weather)
```

---

## Map Matching (Recap from Previous Page)

```
Why ETA needs map matching:
  → Raw GPS says driver is at (19.076, 72.877)
  → But which ROAD is the driver on?
  → Highway has 60 km/h avg speed
  → Service road next to it has 20 km/h avg speed
  → Wrong road = 3x ETA error!

Map matching pipeline:
  Raw GPS → Kalman filter (better position) → Viterbi (correct road) → ETA calculation
```

---

## The Four ETA Computations

```
1. EYEBALL ETA (user browsing):
   → Simple routing: your location → destination
   → Uses average traffic for time of day
   → Doesn't need to be super precise
   → Cached for popular routes

2. DISPATCH ETA (finding a driver):
   → Must compute: driver_1 → you, driver_2 → you, driver_3 → you
   → Multiple ETAs in parallel
   → Must be fast (user is waiting for driver assignment)
   → Uses real-time traffic data

3. PICK UP ETA (driver coming to you):
   → Continuous updates as driver moves
   → Re-calculated every few seconds
   → Uses real-time driver speed + traffic
   → Must account for turns, traffic lights

4. ON-TRIP ETA (during ride):
   → Continuous updates as car moves
   → Recalculated at every turn
   → Uses remaining route + current traffic
   → "You'll arrive 3 minutes earlier than estimated" (adjusts dynamically)
```

---

## Revision Flashcards

**Q: Why can't Uber use standard Dijkstra for ETA?**
A: San Francisco has ~500K intersections. Dijkstra is O(n log n) per query. At 500K queries/sec, this requires trillions of operations per second, which is impossible in real-time.

**Q: How does graph partitioning make routing fast?**
A: Divide the map into regions. Precompute shortest paths between boundary nodes within each region. At query time, only traverse boundary nodes (~700 instead of 500K). Complexity drops from area (πr²) to perimeter (2πr).

**Q: Why use travel time instead of distance for edge weights?**
A: A 10 km highway segment might take 5 minutes, while a 3 km city road might take 12 minutes. Distance-based routing would suggest the slower city road. Travel time gives the actually fastest route.

**Q: What are the four ETA scenarios?**
A: (1) Eyeball: pre-booking estimate, (2) Dispatch: finding nearest driver, (3) Pick up: driver driving to you, (4) On-trip: during the ride. Each uses different precision and real-time data.

**Q: Why is map matching critical for ETA?**
A: A driver on a highway vs the parallel service road has completely different speeds. Without map matching, the system might calculate ETA using the wrong road's speed, causing 2-3x errors.
