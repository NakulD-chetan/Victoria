# Design Google Docs — Concept

> **Permanent Recall:** Real-time collaborative document editing at scale. Core insight: **conflict resolution** — how do you handle two users typing at the same position simultaneously? Two approaches: **Operational Transformation (OT)** — Google Docs' approach, transforms operations against concurrent ops; **CRDTs** — Figma's approach, mathematically guaranteed convergence. This is a **HARD** design problem, expected at senior/staff level.

---

## Problem Statement

Design a **real-time collaborative document editor** like Google Docs where:
- Multiple users edit the same document simultaneously
- Changes appear within **<100ms** to all collaborators
- No data loss or corruption from concurrent edits
- Users see **where others are typing** (cursor presence)

Scale: **100M documents**, **10M concurrent users**.

---

## Functional Requirements

| Feature | Description |
|---------|-------------|
| **Create/edit documents** | Create, open, save documents; basic text and rich text (bold, italic, etc.) |
| **Real-time collaboration** | Multiple users editing simultaneously; changes sync in real-time |
| **Cursor presence** | See where other users' cursors are; show who is typing where |
| **Version history** | View and restore previous versions of the document |
| **Comments** | Add, reply to, resolve comments anchored to text |
| **Sharing/permissions** | Share with users; view-only vs edit access |
| **Offline editing** | Edit while offline; sync when reconnected |

---

## Non-Functional Requirements

| NFR | Target |
|-----|--------|
| **Real-time sync** | Changes visible to collaborators in **<100ms** |
| **Conflict-free** | No "last write wins" corruption; all users converge to same state |
| **Consistency** | All users eventually see the **same document** |
| **Scale** | 100M documents; 10M concurrent users |
| **Availability** | High availability; document access is critical |

> **FAANG Tip:** The hardest part is conflict resolution — never say "last write wins." OT or CRDT is mandatory for collaborative editing.

---

## Capacity Estimation

### Scale

| Metric | Value |
|--------|-------|
| Documents | 100M |
| Concurrent users | 10M |
| Docs per user (avg) | ~10 open sessions |
| Operations per second (peak) | Millions of keystrokes across all sessions |

### Storage (rough)

- **Document snapshots:** 100M docs × 50KB avg ≈ **5TB**
- **Operation logs:** Per-doc history; append-only; depends on retention
- **Presence:** Ephemeral; cursor positions in memory

---

## Key Numbers to Memorize

| Metric | Value |
|--------|-------|
| Real-time latency target | <100ms |
| Conflict resolution | OT (Google) or CRDT (Figma) |
| Scale | 100M docs, 10M concurrent |
| Sync protocol | WebSocket (bidirectional, low-latency) |
| Storage model | Snapshot + operation log |

---

## Out of Scope (Clarify in Interview)

- **Spreadsheets** — different data model; cell references, formulas
- **Rich media** — images, drawings (can extend)
- **Suggestions mode** — like Google Docs "Suggesting" (track changes)
- **Full offline PWA** — basic queue + sync on reconnect

---

## Assumptions (State in Interview)

- Text-based documents; rich text (formatting) is in scope
- WebSocket available; fallback to long-polling if needed
- Single server (or coherent cluster) handles OT/CRDT for a document session
- Document model = tree of blocks/paragraphs for simpler OT

---

## Constraints

- **Network:** Users may have high latency, packet loss; operations can arrive out of order
- **Offline:** User edits offline; must merge when reconnecting
- **Hot spots:** Popular document may have 100+ concurrent editors
- **Consistency:** Must converge; no divergent copies

---

## Success Criteria

- Changes appear <100ms P99
- No document corruption from concurrent edits
- All users see identical document state after sync
- Version history recoverable
- Offline edits merged correctly on reconnect
