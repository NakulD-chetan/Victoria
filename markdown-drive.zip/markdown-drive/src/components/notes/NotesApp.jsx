import { memo, useCallback, useEffect } from 'react';
import { useNotesStore } from '../../stores/notes-store';
import { useVaultStore } from '../../stores/vault-store';
import FileTreeSidebar from './FileTreeSidebar';
import AppNavbar from '../shared/AppNavbar';
import SidebarSkeleton from './SidebarSkeleton';
import EditorSkeleton from './EditorSkeleton';
import Workspace from './Workspace';
import './skeletons.css';
import './workspace.css';

const NotesApp = memo(function NotesApp({ theme, onThemeToggle }) {
  const openTabs = useNotesStore((s) => s.openTabs);
  const activeTabId = useNotesStore((s) => s.activeTabId);
  const closeTab = useNotesStore((s) => s.closeTab);
  const createNote = useNotesStore((s) => s.createNote);
  const selectedNotebookId = useNotesStore((s) => s.selectedNotebookId);
  const notebooks = useNotesStore((s) => s.notebooks);
  const notes = useNotesStore((s) => s.notes);
  const openNoteInTab = useNotesStore((s) => s.openNoteInTab);
  const cloudLoaded = useNotesStore((s) => s.cloudLoaded);
  const loadFromCloudFn = useNotesStore((s) => s.loadFromCloud);
  const isSwitching = useVaultStore((s) => s.isSwitching);

  useEffect(() => {
    if (!cloudLoaded) loadFromCloudFn();
  }, [cloudLoaded, loadFromCloudFn]);

  /* Pick "Welcome" first if it exists, otherwise the first note in the vault. */
  const getPreferredWelcomeNoteId = useCallback(() => {
    const welcome = notes.find((n) => (n.title || '').trim().toLowerCase() === 'welcome');
    return welcome?.id || notes[0]?.id || null;
  }, [notes]);

  useEffect(() => {
    if (!cloudLoaded || activeTabId || openTabs.length > 0 || notes.length === 0) return;
    const preferredId = getPreferredWelcomeNoteId();
    if (preferredId) openNoteInTab(preferredId);
  }, [cloudLoaded, activeTabId, openTabs.length, notes.length, getPreferredWelcomeNoteId, openNoteInTab]);

  const handleNewNote = useCallback(() => {
    const nbId = selectedNotebookId && !selectedNotebookId.startsWith('__')
      ? selectedNotebookId : notebooks[0]?.id;
    if (nbId) {
      const id = createNote(nbId);
      if (id) openNoteInTab(id);
    }
  }, [selectedNotebookId, notebooks, createNote, openNoteInTab]);

  useEffect(() => {
    const handleKeys = (e) => {
      const key = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && key === 'n') {
        e.preventDefault();
        e.stopPropagation();
        handleNewNote();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && key === 'o') {
        e.preventDefault();
        e.stopPropagation();
        window.dispatchEvent(new CustomEvent('notes-focus-search'));
        return;
      }
      if ((e.ctrlKey || e.metaKey) && key === 'w') {
        e.preventDefault();
        e.stopPropagation();
        if (activeTabId) closeTab(activeTabId);
      }
    };
    window.addEventListener('keydown', handleKeys, true);
    return () => window.removeEventListener('keydown', handleKeys, true);
  }, [handleNewNote, activeTabId, closeTab]);

  return (
    <div className="obs-app">
      <AppNavbar currentPath="/notes" theme={theme} onThemeToggle={onThemeToggle} />
      <div className="obs-app__body" data-switching={isSwitching ? 'true' : 'false'}>
        {isSwitching && (
          <>
            <div
              className="obs-skeleton-overlay obs-skeleton-overlay--sidebar"
              style={{ position: 'absolute', top: 0, left: 0, bottom: 0, width: 'var(--ft-sidebar-width, 280px)', zIndex: 60 }}
            >
              <SidebarSkeleton />
            </div>
            <div
              className="obs-skeleton-overlay obs-skeleton-overlay--editor"
              style={{ position: 'absolute', top: 0, right: 0, bottom: 0, left: 'var(--ft-sidebar-width, 280px)', zIndex: 60 }}
            >
              <EditorSkeleton />
            </div>
          </>
        )}
        <FileTreeSidebar onNewNote={handleNewNote} />

        <div className="obs-main obs-main--workspace">
          <Workspace />
        </div>
      </div>
    </div>
  );
});

export default NotesApp;
