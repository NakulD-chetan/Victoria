# Clauses and Execution — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is the logical execution order of SQL?
**A:** FROM → WHERE → GROUP BY → HAVING → SELECT → DISTINCT → ORDER BY → LIMIT. This is why you can't use aliases in WHERE (SELECT hasn't run yet).

### Q: WHERE vs HAVING — what's the difference?
**A:** WHERE filters individual rows BEFORE grouping. HAVING filters groups AFTER GROUP BY. WHERE cannot use aggregate functions; HAVING can.

### Q: Why can't I use a SELECT alias in WHERE?
**A:** Because WHERE executes BEFORE SELECT in logical order. The alias doesn't exist yet. Use subquery/CTE or repeat the expression.

### Q: What is UNION vs UNION ALL?
**A:** UNION combines two result sets and removes duplicates (slower — needs sorting/hashing). UNION ALL keeps all rows including duplicates (faster). Use UNION ALL when duplicates are impossible or desired.

### Q: What is INTERSECT?
**A:** Returns only rows that appear in BOTH result sets. Like set intersection.

### Q: What is EXCEPT (MINUS)?
**A:** Returns rows from first query that are NOT in second query. Oracle calls it MINUS.

### Q: What is COALESCE?
**A:** Returns the first non-NULL value from a list. `COALESCE(a, b, c)` = if a is not null return a, else if b not null return b, else c.

### Q: What is NULLIF?
**A:** Returns NULL if two values are equal, otherwise returns the first value. Common use: `x / NULLIF(y, 0)` to avoid division by zero.

### Q: What is the difference between IN and EXISTS?
**A:** IN checks membership in a list/result. EXISTS checks if subquery returns any rows. EXISTS is generally better for correlated subqueries and NULL-safe anti-joins (`NOT EXISTS` vs `NOT IN`).

### Q: What is BETWEEN?
**A:** Range check inclusive on both ends. `WHERE x BETWEEN 10 AND 20` is same as `x >= 10 AND x <= 20`.

### Q: What is CASE WHEN?
**A:** SQL's conditional expression (like if-else). Returns different values based on conditions. Can be used in SELECT, WHERE, ORDER BY, HAVING.

### Q: How does LIKE work?
**A:** Pattern matching: `%` = any number of chars, `_` = exactly one char. `LIKE 'A%'` = starts with A. Not regex — use dialect-specific regex for complex patterns.

### Q: What is ORDER BY? Default direction?
**A:** Sorts the result set. Default is ASC (ascending). Use DESC for descending. Can sort by column name, alias, or position number.

### Q: What is LIMIT vs TOP vs FETCH?
**A:** All do pagination. MySQL/Postgres: `LIMIT 10 OFFSET 20`. SQL Server: `TOP 10`. ANSI standard: `FETCH FIRST 10 ROWS ONLY`. Same purpose, different syntax.

### Q: Can we use aggregate functions in WHERE?
**A:** No. Aggregates work on groups, and WHERE runs before GROUP BY. Use HAVING for aggregate filters, or compute in subquery/CTE first.

### Q: What is DISTINCT?
**A:** Removes duplicate rows from result set. Applies to ALL selected columns as a combination. `SELECT DISTINCT city, country` = unique (city, country) pairs.

---

## Strong answers

- "`WHERE` can't see aggregates; use `HAVING` after `GROUP BY`, or precompute in CTE."
- "`SELECT` aliases usually visible in `ORDER BY` in many engines, but not in `WHERE` — scope rules."
- "I prefer `UNION ALL` over `UNION` unless I specifically need deduplication — it's faster."

---

*Next: [[05_Common-Mistakes]]*
