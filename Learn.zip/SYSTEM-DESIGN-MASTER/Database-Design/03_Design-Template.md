# Database Design — Design Template (Deep Understanding)

> **Permanent Recall:** Reusable database design patterns: (1) Single SQL DB for small apps; (2) SQL + Redis cache for read-heavy; (3) Polyglot persistence for complex systems; (4) Sharded architecture for massive scale. Know schema templates for user system, social graph, e-commerce, and content platform. Index strategy: equality → range → sort (left to right). Always show CREATE TABLE, index strategy, and scaling approach in interviews.

---

## Why Design Templates Matter

Instead of designing database schemas from scratch every time, use **proven patterns**. Each pattern fits a specific scale and complexity level. Think of them as blueprints for the most common system design scenarios.

---

## Pattern 1: Single SQL Database (Simple)

### What It Is

One PostgreSQL/MySQL instance handling all reads and writes for the entire application.

```
                    ┌─────────────────────────────────┐
                    │        Application Servers        │
                    │     [App 1] [App 2] [App 3]      │
                    └────────────────┬────────────────┘
                                     │
                            ┌────────▼────────┐
                            │  CONNECTION      │
                            │  POOL            │
                            │  (HikariCP /     │
                            │   pgBouncer)     │
                            └────────┬────────┘
                                     │
                            ┌────────▼────────┐
                            │  PostgreSQL      │
                            │  (Single Server) │
                            │  All reads       │
                            │  All writes      │
                            └─────────────────┘
```

### When to Use

- MVP, internal tools, small apps (<1000 requests/sec)
- Data < 100GB
- Single team, single service
- Quick to set up, easy to maintain

### How It Works Internally

```
1. App server borrows connection from pool
2. Sends SQL query to PostgreSQL
3. PostgreSQL parses, optimizes, executes
4. Returns result
5. Connection returned to pool

All reads and writes go to the same server.
Simple. Reliable. Limited by one machine's capacity.
```

### Real-World Example

A startup's blog platform with 10K users, 50K posts, 500K page views/day.

```sql
-- Everything in one PostgreSQL database
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE posts (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT REFERENCES users(id),
    title VARCHAR(500) NOT NULL,
    body TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE comments (
    id BIGSERIAL PRIMARY KEY,
    post_id BIGINT REFERENCES posts(id) ON DELETE CASCADE,
    user_id BIGINT REFERENCES users(id),
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for common queries
CREATE INDEX idx_posts_user ON posts(user_id);
CREATE INDEX idx_posts_status_created ON posts(status, created_at DESC);
CREATE INDEX idx_comments_post ON comments(post_id);
CREATE INDEX idx_comments_user ON comments(user_id);
```

### Limitations

| Problem | What Happens |
|---------|-------------|
| DB is SPOF | Server dies → entire app down |
| Can't scale reads | 10K concurrent readers overwhelm one server |
| Can't scale writes | One server handles max ~10K writes/sec |
| No geo-distribution | Users far away get high latency |

---

## Pattern 2: SQL + Read Replicas + Cache (Medium Scale)

### What It Is

A primary database for writes, read replicas for read scaling, and Redis for caching hot data.

```
                    ┌─────────────────────────────────┐
                    │        Application Servers        │
                    └────────┬────────────────┬───────┘
                             │                │
                    WRITES   │                │  READS (hot data)
                             │                │
                    ┌────────▼────────┐  ┌────▼──────────┐
                    │  PRIMARY         │  │  REDIS CACHE   │
                    │  (PostgreSQL)    │  │  (sessions,    │
                    │  Handles writes  │  │   hot queries, │
                    │                  │  │   counters)    │
                    └────────┬────────┘  └───────────────┘
                             │ WAL streaming
                    ┌────────┼────────────┐
                    │        │            │
                    ▼        ▼            ▼
              ┌──────────┐ ┌──────────┐ ┌──────────┐
              │ Replica 1│ │ Replica 2│ │ Replica 3│
              │ (reads)  │ │ (reads)  │ │ (reads)  │
              └──────────┘ └──────────┘ └──────────┘
```

### Why Three Layers?

| Layer | What It Does | Why Not Skip It? |
|-------|-------------|-----------------|
| **Primary** | All writes, strong consistency reads | Must have — it's the source of truth |
| **Read Replicas** | Handle read queries to offload primary | Without them, primary handles ALL reads → bottleneck at 10K+ RPS |
| **Redis Cache** | Sub-ms reads for hot data (sessions, user profiles) | Without cache, replicas handle ALL reads including repeat queries → wasteful |

### How It Works Step-by-Step

```
WRITE PATH (new user signs up):
  1. App → PRIMARY: INSERT INTO users (email, name) VALUES (...)
  2. Primary writes to WAL → confirms COMMIT
  3. WAL streamed to Replicas (async, ~100ms delay)
  4. App also writes to Redis: SET user:123 {name, email} EXPIRE 3600

READ PATH (load user profile):
  1. App checks Redis: GET user:123
     → HIT? Return cached data (sub-ms). Done.
     → MISS? Continue to step 2.
  2. App queries Read Replica: SELECT * FROM users WHERE id = 123
  3. Replica returns result
  4. App stores in Redis: SET user:123 {result} EXPIRE 3600
  5. Return to client

CACHE INVALIDATION (user updates profile):
  1. App → PRIMARY: UPDATE users SET name = 'Alice2' WHERE id = 123
  2. App → Redis: DELETE user:123  (invalidate old cache)
  3. Next read will miss cache → fetch fresh from replica → cache again
```

### When to Use

- Medium-scale apps (1K–50K requests/sec)
- Read-heavy workloads (10:1 or higher read:write ratio)
- Need sub-ms reads for hot data (sessions, popular profiles)
- Most SaaS products, social apps, content platforms

### Configuration Example

```
PostgreSQL Primary Config (postgresql.conf):
  wal_level = replica
  max_wal_senders = 5
  synchronous_commit = off  (async replication — faster writes)
  
Replica Config:
  primary_conninfo = 'host=primary.db.internal port=5432'
  hot_standby = on  (allow reads during replication)

Redis Config:
  maxmemory 4gb
  maxmemory-policy allkeys-lru  (evict least recently used when full)
  
Connection Pool (HikariCP):
  write-pool:
    jdbc-url: jdbc:postgresql://primary:5432/mydb
    maximum-pool-size: 10
  read-pool:
    jdbc-url: jdbc:postgresql://replica1:5432/mydb
    maximum-pool-size: 30
```

---

## Pattern 3: Polyglot Persistence (Multiple Databases)

### What It Is

Different databases for different workloads. SQL for source of truth, Redis for cache/sessions, Elasticsearch for search, etc. Each database does what it's best at.

```
                    ┌─────────────────────────────────┐
                    │        Application Servers        │
                    └──┬────┬────┬────┬────┬──────────┘
                       │    │    │    │    │
        ┌──────────────┘    │    │    │    └──────────────┐
        ▼                   ▼    │    ▼                   ▼
  ┌──────────┐    ┌────────────┐ │ ┌───────────┐   ┌──────────┐
  │PostgreSQL│    │   Redis    │ │ │Elasticsearch│  │ Cassandra│
  │(users,   │    │(sessions,  │ │ │(search,     │  │(activity │
  │ orders,  │    │ cache,     │ │ │ autocomplete│  │ logs,    │
  │ payments)│    │ rate limit)│ │ │ full-text)  │  │ events)  │
  └──────────┘    └────────────┘ │ └───────────┘   └──────────┘
                                 │
                          ┌──────▼──────┐
                          │   Neo4j     │
                          │(social graph│
                          │ recommendations)│
                          └─────────────┘
```

### Why Multiple Databases?

```
ONE DATABASE FOR EVERYTHING:
  PostgreSQL handles: users, orders, sessions, search, analytics, cache
  
  Problems:
  - Sessions (key-value) → PostgreSQL is OVERKILL (100× slower than Redis)
  - Full-text search → PostgreSQL's text search is MEDIOCRE vs Elasticsearch
  - Activity logs (1B writes/day) → PostgreSQL can't handle that write volume
  - Social graph queries → Multi-hop JOINs in SQL are SLOW
  
  Each workload has a database that's 10-100× better for it.

POLYGLOT PERSISTENCE:
  PostgreSQL: Users, orders, payments (ACID, relationships) ← source of truth
  Redis: Sessions, cache, rate limiting (sub-ms, TTL) ← speed
  Elasticsearch: Search, autocomplete (inverted index) ← search
  Cassandra: Activity logs, events (massive writes) ← throughput
  Neo4j: Social graph, recommendations (traversals) ← relationships
```

### How Data Flows Between Databases

```
WRITE: User creates a post
  1. App writes to PostgreSQL (source of truth)
  2. App writes to Elasticsearch (for search indexing)
  3. App writes to Redis (cache the post for fast reads)
  4. App writes to Cassandra (activity log: "user X created post Y")

Option A: Synchronous (simple but slow)
  App → write to all 4 DBs sequentially → return to user
  
Option B: Event-driven (complex but fast)
  App → write to PostgreSQL → publish event to Kafka
  Kafka consumers → update Elasticsearch, Redis, Cassandra asynchronously
  App returns to user immediately after PostgreSQL write
```

### When to Use Polyglot

| Use When | Don't Use When |
|----------|---------------|
| 10+ microservices with different data needs | Simple CRUD app (one DB is fine) |
| Specific workloads need specialized DBs | Team is small and can't manage multiple DBs |
| Scale demands exceed one DB's capabilities | Operational complexity outweighs benefits |
| Netflix, Uber, Amazon-scale systems | MVP or early-stage startup |

---

## Pattern 4: Sharded Database Architecture (Massive Scale)

### What It Is

Data is horizontally partitioned across multiple independent database servers. Each shard holds a subset of the data.

```
                    ┌─────────────────────────────────┐
                    │        Application Servers        │
                    └────────────────┬────────────────┘
                                     │
                    ┌────────────────▼────────────────┐
                    │    SHARD ROUTER / PROXY          │
                    │    (Vitess, ProxySQL, app logic) │
                    │    hash(user_id) → shard_id      │
                    └────┬───────┬───────┬───────┬────┘
                         │       │       │       │
                    ┌────▼──┐ ┌──▼───┐ ┌─▼────┐ ┌▼─────┐
                    │Shard 1│ │Shard 2│ │Shard 3│ │Shard 4│
                    │user   │ │user   │ │user   │ │user   │
                    │1-25M  │ │25M-50M│ │50M-75M│ │75M-100M│
                    │+orders│ │+orders│ │+orders│ │+orders│
                    └───────┘ └──────┘ └──────┘ └──────┘
                    Each shard is a full PostgreSQL instance
                    with its own replicas
```

### How Sharding Works Step-by-Step

```
User 42,000,001 places an order:

1. App calculates: hash(42000001) % 4 = 1 → Shard 2
2. Shard router routes query to Shard 2
3. Shard 2: INSERT INTO orders (user_id, ...) VALUES (42000001, ...)
4. Shard 2 confirms. Only Shard 2 was touched.
5. Shards 1, 3, 4 are completely unaware.

Query: "Show orders for user 42000001"
1. hash(42000001) % 4 = 1 → Shard 2
2. SELECT * FROM orders WHERE user_id = 42000001
3. Query hits ONLY Shard 2. Fast.

Query: "Total revenue across ALL users" (cross-shard!)
1. Must query ALL 4 shards: SELECT SUM(amount) FROM orders
2. Collect results from each shard
3. Sum them at the application layer
4. SLOW and COMPLEX — this is the cost of sharding
```

### When to Use Sharding

| Signal | What to Do |
|--------|-----------|
| Single DB at max CPU/IOPS for writes | Shard to distribute writes |
| Table has 1B+ rows, queries slowing | Shard or partition |
| Write volume exceeds 10K writes/sec sustained | Shard |
| Data exceeds single server's storage (multi-TB) | Shard |

---

## Schema Design Templates — Deep Explanation

### Template 1: User System (Authentication + Profile)

```sql
-- USERS TABLE: Authentication (login/signup)
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    email_verified BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'active',  -- active, suspended, deleted
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- USER PROFILES: Display info (separated for different read patterns)
CREATE TABLE user_profiles (
    user_id BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    display_name VARCHAR(100),
    bio TEXT,
    avatar_url TEXT,
    location VARCHAR(100),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- WHY SEPARATE TABLES?
-- users table: accessed on EVERY request (auth check) → keep it small and fast
-- user_profiles: accessed only when viewing profile → larger data, less frequent
-- Different read patterns → different optimization strategies

-- INDEXES
CREATE INDEX idx_users_email ON users(email);
  -- Used by: login (WHERE email = ?)
  -- Already UNIQUE index from constraint, but explicit for clarity

CREATE INDEX idx_users_status ON users(status) WHERE status != 'active';
  -- Partial index: only indexes non-active users (smaller index)
  -- Used by: admin dashboard filtering suspended/deleted users

CREATE INDEX idx_users_created ON users(created_at DESC);
  -- Used by: "newest users" queries, admin reports
```

**Redis key patterns for this schema:**

```
user:{id}            → hash {name, email, avatar}  TTL: 1 hour
user:email:{email}   → user_id (reverse lookup)    TTL: 1 hour
session:{token}      → {user_id, role, expires}     TTL: 24 hours
rate_limit:{user_id} → counter                      TTL: 60 seconds
```

**MongoDB alternative:**

```javascript
{
  _id: ObjectId("..."),
  email: "alice@mail.com",
  hashedPassword: "$2b$...",
  emailVerified: true,
  status: "active",
  profile: {
    displayName: "Alice",
    bio: "Software engineer",
    avatarUrl: "https://...",
    location: "Mumbai"
  },
  createdAt: ISODate("2024-01-15T00:00:00Z")
}
// One document = one read for everything about a user
// Index: { email: 1 } unique
// Index: { createdAt: -1 }
```

### Template 2: Social Graph (Followers / Friends)

```sql
-- FOLLOWERS TABLE (directed graph: A follows B)
CREATE TABLE followers (
    follower_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
    followed_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (follower_id, followed_id),
    CHECK (follower_id != followed_id)  -- can't follow yourself
);

-- QUERY: "Who does Alice follow?"
-- SELECT followed_id FROM followers WHERE follower_id = alice_id;
-- Uses: PRIMARY KEY index (follower_id is first column)

-- QUERY: "Who follows Alice?"
-- SELECT follower_id FROM followers WHERE followed_id = alice_id;
-- Needs: separate index!
CREATE INDEX idx_followers_followed ON followers(followed_id);

-- QUERY: "Does Alice follow Bob?"
-- SELECT 1 FROM followers WHERE follower_id = alice_id AND followed_id = bob_id;
-- Uses: PRIMARY KEY (exact match on both columns)

-- QUERY: "Follower count for Alice"
-- SELECT COUNT(*) FROM followers WHERE followed_id = alice_id;
-- SLOW for celebrities (millions of followers) → denormalize!

-- DENORMALIZED COUNTER (for fast reads):
ALTER TABLE users ADD COLUMN follower_count INT DEFAULT 0;
ALTER TABLE users ADD COLUMN following_count INT DEFAULT 0;

-- When someone follows:
-- 1. INSERT into followers
-- 2. UPDATE users SET follower_count = follower_count + 1 WHERE id = followed_id
-- 3. UPDATE users SET following_count = following_count + 1 WHERE id = follower_id
-- Wrap in a TRANSACTION!
```

**At scale (100M+ users), use a graph DB:**

```cypher
// Neo4j: Natural for social graphs
CREATE (alice:User {id: 1, name: "Alice"})
CREATE (bob:User {id: 2, name: "Bob"})
CREATE (alice)-[:FOLLOWS {since: datetime()}]->(bob)

// "Friends of friends" — 2-hop traversal
MATCH (alice:User {name: "Alice"})-[:FOLLOWS]->(friend)-[:FOLLOWS]->(fof)
WHERE NOT (alice)-[:FOLLOWS]->(fof) AND fof <> alice
RETURN DISTINCT fof.name

// In SQL, this would be a complex self-JOIN on billions of rows
// In Neo4j, it's a simple graph traversal — milliseconds
```

### Template 3: E-Commerce (Orders + Payments)

```sql
-- PRODUCTS
CREATE TABLE products (
    id BIGSERIAL PRIMARY KEY,
    name VARCHAR(500) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    category_id INT REFERENCES categories(id),
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ORDERS (one per checkout)
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id BIGINT NOT NULL REFERENCES users(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
      -- pending → paid → shipped → delivered → completed
      -- pending → cancelled
    total_amount DECIMAL(12,2) NOT NULL,
    shipping_address JSONB,  -- flexible address format
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ORDER ITEMS (many items per order)
CREATE TABLE order_items (
    id BIGSERIAL PRIMARY KEY,
    order_id UUID NOT NULL REFERENCES orders(id),
    product_id BIGINT NOT NULL REFERENCES products(id),
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10,2) NOT NULL,  -- price at time of order (not current!)
    total_price DECIMAL(12,2) GENERATED ALWAYS AS (quantity * unit_price) STORED
);

-- PAYMENTS
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id UUID NOT NULL REFERENCES orders(id),
    amount DECIMAL(12,2) NOT NULL,
    method VARCHAR(20) NOT NULL,  -- card, upi, wallet
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
      -- pending → completed → refunded
    provider_txn_id VARCHAR(255),  -- Stripe/Razorpay transaction ID
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_orders_user_created ON orders(user_id, created_at DESC);
  -- "Show user's recent orders" → one index scan

CREATE INDEX idx_orders_status ON orders(status) WHERE status IN ('pending', 'paid');
  -- Partial index: only indexes active orders (not completed/cancelled)

CREATE INDEX idx_order_items_order ON order_items(order_id);
  -- "Items in this order"

CREATE INDEX idx_products_category_price ON products(category_id, price);
  -- "Products in Electronics category, sorted by price"

CREATE INDEX idx_payments_order ON payments(order_id);
  -- "Payment for this order"
```

**The critical transaction — placing an order:**

```sql
-- THIS MUST BE ATOMIC (all-or-nothing)
BEGIN;

-- 1. Check stock and LOCK the row (prevent concurrent purchase)
SELECT stock_quantity FROM products WHERE id = 42 FOR UPDATE;
-- Returns 5. Proceed.

-- 2. Reduce stock
UPDATE products SET stock_quantity = stock_quantity - 1 WHERE id = 42;

-- 3. Create order
INSERT INTO orders (user_id, total_amount, status)
VALUES (123, 999.00, 'pending') RETURNING id;
-- Returns order_id = 'abc-uuid'

-- 4. Create order item
INSERT INTO order_items (order_id, product_id, quantity, unit_price)
VALUES ('abc-uuid', 42, 1, 999.00);

-- 5. Create payment record
INSERT INTO payments (order_id, amount, method, status)
VALUES ('abc-uuid', 999.00, 'card', 'pending');

COMMIT;

-- If ANY step fails → ROLLBACK → stock restored, no partial order
```

### Template 4: Content Platform (Posts + Feed + Tags)

```sql
-- POSTS
CREATE TABLE posts (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    content TEXT NOT NULL,
    media_urls TEXT[],  -- array of image/video URLs (stored in S3)
    like_count INT DEFAULT 0,
    comment_count INT DEFAULT 0,
    visibility VARCHAR(20) DEFAULT 'public',  -- public, followers, private
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- LIKES (many-to-many: users ↔ posts)
CREATE TABLE post_likes (
    user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
    post_id BIGINT REFERENCES posts(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, post_id)
);

-- COMMENTS
CREATE TABLE comments (
    id BIGSERIAL PRIMARY KEY,
    post_id BIGINT NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id),
    parent_comment_id BIGINT REFERENCES comments(id),  -- threading
    body TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- TAGS (many-to-many: posts ↔ tags)
CREATE TABLE tags (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE post_tags (
    post_id BIGINT REFERENCES posts(id) ON DELETE CASCADE,
    tag_id INT REFERENCES tags(id),
    PRIMARY KEY (post_id, tag_id)
);

-- INDEXES
CREATE INDEX idx_posts_user_created ON posts(user_id, created_at DESC);
  -- "User's recent posts" (profile page)

CREATE INDEX idx_posts_created ON posts(created_at DESC) WHERE visibility = 'public';
  -- "Global feed" (public posts, newest first)

CREATE INDEX idx_comments_post ON comments(post_id, created_at);
  -- "Comments on this post, chronological"

CREATE INDEX idx_post_likes_post ON post_likes(post_id);
  -- "Who liked this post?"

CREATE INDEX idx_post_tags_tag ON post_tags(tag_id);
  -- "All posts with tag #technology"
```

---

## Indexing Strategy Template — Deep Explanation

### The Golden Rules

```
RULE 1: Index columns in WHERE, JOIN, ORDER BY of your HOT queries
  Hot query: runs 1000×/second
  Cold query: runs 1×/day (don't optimize, full scan is fine)

RULE 2: Composite index column order: EQUALITY → RANGE → SORT
  WHERE user_id = 123 AND created_at > '2024-01-01' ORDER BY created_at DESC
  Index: (user_id, created_at)
  ✅ user_id is equality (=), created_at is range (>) and sort

RULE 3: Leftmost prefix rule
  Index on (A, B, C) helps queries on:
    ✅ (A)
    ✅ (A, B)
    ✅ (A, B, C)
    ❌ (B)      ← skips A
    ❌ (B, C)   ← skips A
    ❌ (C)      ← skips A, B

RULE 4: Don't over-index
  Each index slows DOWN writes (must update index on INSERT/UPDATE/DELETE)
  10 indexes on a table → 10 additional writes per INSERT
  Only index HOT query paths
```

### Indexing Cheat Sheet

| Query Pattern | Optimal Index | Example |
|---------------|--------------|---------|
| `WHERE email = ?` | Single column | `CREATE INDEX idx ON users(email)` |
| `WHERE user_id = ? ORDER BY created_at DESC` | Composite | `(user_id, created_at)` |
| `WHERE status = ? AND created_at > ?` | Composite (eq first) | `(status, created_at)` |
| `WHERE user_id = ? AND status = ?` | Composite (either order for equality) | `(user_id, status)` |
| `SELECT id, name WHERE email = ?` | Covering index | `(email) INCLUDE (id, name)` |
| `WHERE status = 'active'` (90% of rows are active) | Partial index | `WHERE status != 'active'` (index the rare values) |

### How to Verify Your Index Works

```sql
-- PostgreSQL: EXPLAIN ANALYZE
EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'alice@mail.com';

-- GOOD output:
Index Scan using idx_users_email on users
  Index Cond: (email = 'alice@mail.com')
  Execution Time: 0.05 ms  ← sub-ms! Index working.

-- BAD output:
Seq Scan on users
  Filter: (email = 'alice@mail.com')
  Rows Removed by Filter: 9999999
  Execution Time: 3200 ms  ← 3.2 SECONDS! Full table scan. Need index!
```

---

## Query Optimization Patterns — Deep Explanation

### Pattern 1: Fix N+1 Queries

```python
# WRONG: N+1 problem (101 queries for 100 orders)
orders = db.query("SELECT * FROM orders LIMIT 100")  # 1 query
for order in orders:
    user = db.query("SELECT * FROM users WHERE id = ?", order.user_id)  # 100 queries!

# RIGHT: Single JOIN query (1 query for everything)
results = db.query("""
    SELECT o.*, u.name, u.email 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    LIMIT 100
""")

# ALSO RIGHT: Batch fetch (2 queries total)
orders = db.query("SELECT * FROM orders LIMIT 100")  # 1 query
user_ids = [o.user_id for o in orders]
users = db.query("SELECT * FROM users WHERE id = ANY(?)", user_ids)  # 1 query
```

### Pattern 2: Cursor-Based Pagination (Not OFFSET)

```sql
-- WRONG: OFFSET pagination (SLOW for large offsets)
SELECT * FROM posts ORDER BY created_at DESC LIMIT 20 OFFSET 10000;
-- Database must skip 10,000 rows, then return 20. SLOW.
-- Offset 1,000,000? Must skip 1M rows. VERY SLOW.

-- RIGHT: Cursor-based pagination (FAST at any depth)
-- First page:
SELECT * FROM posts ORDER BY created_at DESC LIMIT 20;
-- Returns 20 posts. Last post has created_at = '2024-06-15 10:00:00'

-- Next page (use cursor):
SELECT * FROM posts 
WHERE created_at < '2024-06-15 10:00:00' 
ORDER BY created_at DESC 
LIMIT 20;
-- Index scan from cursor position. FAST regardless of page number.
```

### Pattern 3: Avoid SELECT *

```sql
-- WRONG: Fetch all columns
SELECT * FROM users WHERE id = 123;
-- Fetches: id, email, hashed_password, bio (10KB text), avatar_url, ...
-- Even if you only need the name. Wastes bandwidth and memory.

-- RIGHT: Select only what you need
SELECT id, display_name, avatar_url FROM users WHERE id = 123;
-- Fetches only 3 small columns. With covering index, avoids table access entirely.
```

### Pattern 4: Pre-compute Expensive Aggregations

```sql
-- WRONG: Compute on every request
SELECT COUNT(*) FROM followers WHERE followed_id = 123;
-- At 10M followers, this scans 10M index entries every time.

-- RIGHT: Denormalize counter
ALTER TABLE users ADD COLUMN follower_count INT DEFAULT 0;
-- Update atomically when follow/unfollow:
UPDATE users SET follower_count = follower_count + 1 WHERE id = 123;
-- Read: SELECT follower_count FROM users WHERE id = 123;
-- One row read. Instant.
```

---

## Connection Pooling Configuration — Deep Explanation

### HikariCP (Java — Most Common)

```yaml
spring:
  datasource:
    hikari:
      minimum-idle: 5         # Keep 5 connections open even when idle
      maximum-pool-size: 20   # Max 20 connections at peak
      idle-timeout: 600000    # Close idle connections after 10 minutes
      connection-timeout: 30000  # Wait 30s for connection, then fail
      max-lifetime: 1800000   # Recycle connections every 30 minutes

# WHY THESE VALUES?
# Pool size: Rule of thumb → connections = (core_count × 2) + disk_spindles
#   For a typical server (4 cores, SSD): 4 × 2 + 1 = 9 ≈ 10-20
# idle-timeout: Don't waste DB connections when idle
# max-lifetime: Prevents stale connections (DB might have restarted)
```

### pgBouncer (PostgreSQL Proxy — For High Scale)

```ini
[databases]
mydb = host=primary.db port=5432 dbname=mydb

[pgbouncer]
pool_mode = transaction
# transaction mode: connection returned to pool after each transaction
# (not held for entire session)

max_client_conn = 1000    # Accept 1000 app connections
default_pool_size = 20    # But only 20 real DB connections
reserve_pool_size = 5     # Emergency extra connections

# WHY pgBouncer?
# PostgreSQL: each connection = 1 process (10MB RAM)
# 1000 direct connections = 10GB RAM just for connections!
# pgBouncer: 1000 app connections → 20 real DB connections
# PostgreSQL uses 200MB instead of 10GB
```

---

## Architecture Summary Table

| Pattern | Components | Scale | Complexity | When to Use |
|---------|-----------|-------|-----------|-------------|
| **Single DB** | 1 PostgreSQL | Small | Low | MVP, <1K RPS, <100GB data |
| **DB + Replicas + Cache** | Primary + replicas + Redis | Medium | Medium | 1K-50K RPS, read-heavy |
| **Polyglot** | SQL + Redis + Elasticsearch + etc. | Large | High | Microservices, specialized workloads |
| **Sharded** | Multiple DB instances + router | Very Large | Very High | 50K+ writes/sec, TB+ data |

### How to Choose

```
Building a side project / MVP?
  → Single PostgreSQL (add replicas when reads bottleneck)

Building a SaaS app with 10K users?
  → PostgreSQL + Redis cache (covers 95% of cases)

Building for millions of users, multiple services?
  → Polyglot: PostgreSQL (truth) + Redis (cache) + Elasticsearch (search)

Building at Facebook/Google scale (billions of records)?
  → Sharded PostgreSQL (Vitess) or purpose-built NoSQL
```

---

## Data Model Quick Reference

| Pattern | SQL | MongoDB | Redis |
|---------|-----|---------|-------|
| **User** | `users` + `user_profiles` tables | Single `users` collection with embedded profile | `user:{id}` hash |
| **Session** | `sessions` table with TTL column | TTL collection | `session:{token}` with EXPIRE |
| **Counter** | `UPDATE SET count = count + 1` | `$inc: {count: 1}` | `INCR counter:{id}` |
| **Leaderboard** | Table + ORDER BY (slow at scale) | Sorted by field | `ZADD leaderboard score member` |
| **Feed** | JOINs (slow) or materialized view | Pre-computed document | `LPUSH feed:{user_id} post_data` |
| **Cache** | Materialized view | TTL collection | `SET cache:{key} value EX 3600` |

---

## Quick Memory Card

```
SINGLE:       One DB, connection pool — MVP, simple
REPLICAS:     Primary writes + replica reads + Redis cache — most apps
POLYGLOT:     SQL + Redis + Elasticsearch + specialized — large systems
SHARDED:      Split data by key across DB instances — massive write scale
SCHEMA:       Users (auth + profile), Social (followers), E-commerce (orders + payments), Content (posts + tags)
INDEX:        Equality → Range → Sort (left-to-right). Only hot queries. EXPLAIN to verify.
N+1:          JOIN or batch fetch. Never loop + query.
PAGINATION:   Cursor-based (WHERE id > ?) not OFFSET
POOLING:      HikariCP (Java), pgBouncer (PostgreSQL proxy). 10-20 connections serve 1000s of requests.
```

---

**Next:** [[04_Interview-Thinking]]
