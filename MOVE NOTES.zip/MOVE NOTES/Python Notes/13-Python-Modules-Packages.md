# Python Modules and Packages

> *"Namespaces are one honking great idea"* — Zen of Python

Import system, `__name__`, packages, `pip`, `venv`, `requirements.txt` — real projects are organized this way. After [[12-Python-Iterators-Generators]], split code across files.

---

## 1. `import` styles

> **Definition:** Import statements load another module’s code into your program’s namespace so you can call its functions and use its names without copying the file.

**Why we need it:** Without imports, every program would be one file or you would duplicate code; imports let you reuse the standard library and your own modules with clear, controlled name access.

**Syntax:**
```python
import <module>
from <module> import <name1>, <name2>
import <module> as <alias>
from <package> import <submodule>
```

```python
import math                    # Imports entire module — use as math.sqrt(), math.pi
from math import sqrt, pi     # Imports SPECIFIC things — use directly as sqrt(), pi
import numpy as np             # Imports with a SHORT ALIAS — use as np.array()
from package import submodule  # Imports a submodule from a package
```

| Style | What it does |
|-------|------|
| `import mod` | Imports full module — keeps names clean with `mod.func()` |
| `from mod import x` | Imports just `x` — shorter but can clash with your own names |
| `import mod as m` | Gives module a shorter name (alias) — `np` for numpy, `pd` for pandas |

**Watch Out!** `from mod import *` — pollutes names; **avoid** in production.

---

## 2. `__name__ == "__main__"`

> **Definition:** `__name__` is a module-level string set to `"__main__"` when Python runs that file as the top-level script, and to the module’s name when the file is imported elsewhere.

**Why we need it:** Code under this guard runs only for direct execution (CLI, tests, demos), not when the module is imported—so imports don’t accidentally start servers, print spam, or recurse on multiprocessing spawn.

**Syntax:**
```python
def main():
    ...

if __name__ == "__main__":
    main()
```

```python
# app.py
def main():
    print("run")

if __name__ == "__main__":
    main()
```

- When you run the script → `__name__` == `"__main__"`
- When you `import app` → `__name__` == `"app"` — block is skipped

**Interview Tip:** Important for tests, CLI, multiprocessing on Windows — use this guard.

---

## 3. Package structure

> **Definition:** A package is a directory of Python modules (and subpackages) arranged as a hierarchy so imports like `pkg.sub.mod` map to files on disk.

**Why we need it:** Large projects need namespaces, clear boundaries, and reusable subsystems; packages group related code and avoid one giant flat folder of modules.

**Syntax:**
```text
<package_name>/
    __init__.py          # optional in some layouts (3.3+ namespace packages)
    <module>.py
    <subpackage>/
        __init__.py
        ...
```

```
mypkg/
    __init__.py
    core.py
    utils/
        __init__.py
        helpers.py
```

```python
from mypkg.core import foo
from mypkg.utils import helpers
```

Python 3.3+ **namespace packages** — `__init__.py` optional in some layouts; classic codebases still use it often.

---

## 4. Relative imports

> **Definition:** Relative imports use `.` and `..` to refer to modules inside the same package tree instead of spelling the full package path from the project root.

**Why we need it:** Renaming or nesting a package is easier when internal imports stay local; you avoid hard-coding the top-level package name in every submodule.

**Syntax:**
```python
from . import <name>
from .<subpackage> import <name>
from ..<parent_pkg> import <name>
```

```python
from . import sibling           # Import from SAME package (. = current folder)
from ..parent_pkg import mod    # Import from PARENT package (.. = one folder up)
```

**Watch Out!** Relative imports from a top-level script often **fail** — you need package context.

---

## 5. `pip`

> **Definition:** `pip` is Python’s standard command-line tool for installing, upgrading, and removing third-party packages (usually from PyPI) into your environment.

**Why we need it:** The standard library is intentionally limited; `pip` gives every project a shared, repeatable way to pull in dependencies and pin versions.

**Syntax:**
```bash
pip install <package>[<version_spec>]
pip uninstall <package>
pip list
pip show <package>
pip freeze > requirements.txt
```

```bash
pip install requests              # Downloads and installs a package from PyPI
pip install "pandas>=2.0"         # Installs pandas version 2.0 or higher
pip uninstall requests            # Removes an installed package
pip list                          # Shows ALL installed packages and their versions
pip show numpy                    # Shows details about one specific package
pip freeze > requirements.txt     # Saves all installed packages + versions to a file
```

---

## 6. Virtual environments — `venv`

> **Definition:** A virtual environment is an isolated directory with its own Python interpreter and `site-packages`, separate from your system or user global install.

**Why we need it:** Different projects need different library versions; venv prevents “dependency hell” and makes installs reproducible per project.

**Syntax:**
```bash
python -m venv <env_dir>
# activate: OS-specific (e.g. .venv\Scripts\activate or source .venv/bin/activate)
pip install -r requirements.txt
deactivate
```

```bash
python -m venv .venv               # Creates a virtual environment in .venv folder
.venv\Scripts\activate             # Activates it (now pip installs go HERE, not global)
pip install -r requirements.txt    # Installs all packages listed in requirements file
deactivate                         # Exits the virtual environment
```

| Why use venv? | What it solves |
|-----|--------|
| Isolation | Each project has its OWN packages — no version clashes between projects |
| Reproducibility | Team can install exact same versions using requirements.txt |

**Watch Out!** Don't mix global site-packages for serious projects.

---

## 7. `requirements.txt`

> **Definition:** A `requirements.txt` file lists project dependencies (often with exact or bounded versions) so others can install the same set of packages with one command.

**Why we need it:** Sharing code or deploying requires a single source of truth for “what to install”; `pip freeze` and hand-written constraints document that environment.

**Syntax:**
```text
<package>==<exact_version>
<package>>=<min_version>
<package>~=<compatible_release>
```

```text
requests==2.31.0
numpy>=1.24
pytest~=8.0
```

---

## 8. Popular packages — overview

> **Definition:** Popular third-party packages are community-maintained libraries (installed with `pip`) that extend Python for web, data, ML, and tooling beyond the standard library.

**Why we need it:** Real apps need frameworks and numeric/ML stacks; knowing common package families helps you pick the right tool and discuss dependencies in interviews and design.

**Syntax:**
```bash
pip install <package_name>
```

| Area | Examples |
|------|----------|
| Web | `fastapi`, `django`, `flask` |
| Data | `numpy`, `pandas` |
| ML | `torch`, `tensorflow`, `sklearn` |
| CLI/Utils | `click`, `pydantic`, `requests` |

---

## 9. `sys.path` and circular imports

> **Definition:** `sys.path` is the list of directories Python searches when resolving imports; a circular import is when two or more modules import each other in a cycle before names are fully defined.

**Why we need it:** Custom search paths support local packages and tooling; understanding path and import order explains “module not found” and how to break cycles with structure or lazy imports.

**Syntax:**
```python
import sys
sys.path.insert(<index>, "<directory>")  # rarely needed
# Break cycles: refactor modules, local imports inside functions, or TYPE_CHECKING-only imports
```

```python
import sys
# sys.path.insert(0, "custom")  # rare
```

Circular import — refactor modules; sometimes lazy `import` inside a function.

**Interview Tip:** `if TYPE_CHECKING:` — type-only imports avoid cycles — [[16-Python-Advanced-Topics]].

---

## 10. `importlib.reload` — notebooks / REPL

> **Definition:** `importlib.reload(module)` re-executes an already-imported module’s code and replaces the existing module object’s namespace with the new definitions.

**Why we need it:** In interactive sessions and notebooks, modules are cached after first import; reload lets you pick up file changes without restarting the interpreter.

**Syntax:**
```python
import importlib
import <module>
importlib.reload(<module>)
```

```python
import importlib
import mymod
importlib.reload(mymod)
```

**Watch Out!** Rare in production — side effects can be dangerous.

---

## 11. `__all__` — control `from pkg import *`

> **Definition:** `__all__` is a list of public names (strings) a package declares as the export surface when someone uses `from package import *`.

**Why we need it:** Star-imports would otherwise expose every non-underscore name; `__all__` documents intent and limits the wildcard API (even though star-imports are discouraged in production).

**Syntax:**
```python
__all__ = ["<name1>", "<name2>", ...]
```

```python
__all__ = ["public_fn"]
```

Defines export surface — still avoid `import *` in serious code.

---

## Quick Memory Card

```
+------------------------------------------+
| IMPORT                                    |
| - import mod / from mod import x         |
| - import * avoid                         |
+------------------------------------------+
| __main__                                  |
| - script vs import guard                 |
+------------------------------------------+
| PACKAGE                                   |
| - folder + __init__.py (often)           |
+------------------------------------------+
| PIP / FREEZE                              |
| - requirements reproducible              |
+------------------------------------------+
| VENV                                      |
| - python -m venv                         |
+------------------------------------------+
| SYS.PATH                                  |
| - search path, cycles careful            |
+------------------------------------------+
```

---

*Next: [[14-Python-Functional-Programming]]*
