# How Google Search Works - In Depth (Easy Language)

> Companion to: [21-How-Google-Search-Works.md](21-How-Google-Search-Works.md)

---

## The Scale

```
~10 BILLION web pages to crawl
~20 PETABYTES of stored web content
~8.5 BILLION searches per day
~100,000 queries per second
```

Google Search has two major parts: the **Web Crawler** (finding and downloading pages) and the **Search Engine** (answering queries). Let's break both down.

---

## Part 1: The Web Crawler - Finding Every Page on the Internet

### The URL Frontier - The Crawler's To-Do List

The crawler needs to decide: **which URL to visit next?** out of billions of options.

```
Simple to-do list: visit URLs in order
  1. google.com ✓
  2. wikipedia.org ← next
  3. randomsite.xyz
  4. nytimes.com
  ...

Problem 1: Not all pages are equally important!
  NYTimes homepage should be crawled BEFORE a random blog from 2008.

Problem 2: Can't hammer one website!
  Crawling 1000 Wikipedia pages in 1 second would crash Wikipedia's servers.
```

### Two-Stage Queue (The Clever Solution)

```
FRONT QUEUES (Priority):
  ┌─────────────────┐
  │ Priority 1:     │  Google, Wikipedia, NYTimes, major sites
  │ (crawl first)   │  → Gets 60% of crawl bandwidth
  ├─────────────────┤
  │ Priority 2:     │  Popular blogs, medium sites
  │ (crawl second)  │  → Gets 30% of crawl bandwidth
  ├─────────────────┤
  │ Priority 3:     │  Random sites, personal blogs
  │ (crawl last)    │  → Gets 10% of crawl bandwidth
  └────────┬────────┘
           ↓
BACK QUEUES (Politeness - one queue per host):
  ┌─────────────────┐
  │ wikipedia.org:  │  → Max 1 request every 10 seconds
  ├─────────────────┤
  │ nytimes.com:    │  → Max 1 request every 5 seconds
  ├─────────────────┤
  │ smallblog.com:  │  → Max 1 request every 30 seconds
  └─────────────────┘
  
  Each host gets its own queue
  Crawler NEVER overwhelms any single website
```

**Adaptive politeness**: If a website returns HTTP 429 (Too Many Requests) or 503 (Server Overloaded), the crawler backs off and slows down even more for that host.

---

## URL Deduplication - Don't Crawl the Same Page Twice

### The Problem

As the crawler discovers new links, many point to pages already crawled:

```
Page A links to: [B, C, D, E]
Page B links to: [A, C, F]      ← A and C already in our list!
Page C links to: [A, B, D, G]   ← A, B, D already known!

Without dedup: crawl A, B, C, D, E, A again, C again, F, A again...
With dedup: crawl A, B, C, D, E, F, G (each page once)
```

### Bloom Filter for URL Dedup

With 10 billion URLs, a hash set would need ~200 GB of RAM. Too expensive!

```
Bloom filter:
  → Uses ~1-2 GB of RAM (100x less!)
  → Can check "have I seen this URL?" in O(1) time
  
  New URL discovered: "example.com/page123"
  → Bloom filter: "DEFINITELY NOT seen" → add to frontier
  
  New URL discovered: "google.com" (already crawled)
  → Bloom filter: "PROBABLY seen" → skip it!
  
  False positive rate: ~1% (might skip 1% of new pages)
  → Acceptable trade-off for 100x memory savings
```

---

## Content Deduplication - Simhash

### The Problem

Different URLs can have the SAME content:

```
https://example.com/article/123
https://example.com/article/123?utm_source=twitter
https://m.example.com/article/123
https://example.com/article/123/
https://partner-site.com/repost/same-article  ← different site, same content!

All 5 URLs have essentially the same content.
Storing and indexing it 5 times is wasteful.
```

### How Simhash Works

**Simhash** creates a fingerprint of the page content. Similar pages have similar fingerprints:

```
Page A content: "The quick brown fox jumps over the lazy dog"
Simhash(A) = 1010110010110101

Page B content: "The quick brown fox jumps over the lazy cat"  ← only 1 word different!
Simhash(B) = 1010110010110100  ← only 1 bit different!

Page C content: "Completely unrelated article about quantum physics"
Simhash(C) = 0101001101001010  ← many bits different!

Comparison:
  hamming_distance(A, B) = 1 bit  → NEAR DUPLICATE! Skip B.
  hamming_distance(A, C) = 9 bits → DIFFERENT content. Keep both.
```

**Threshold**: If two pages' Simhash values differ by fewer than 3 bits (out of 64), they're considered near-duplicates.

---

## robots.txt - Being a Good Citizen

```
Every website has a robots.txt file:
  https://example.com/robots.txt

Contents:
  User-agent: Googlebot
  Disallow: /admin/
  Disallow: /private/
  Crawl-delay: 10        ← "Don't crawl me faster than 1 page per 10 seconds"
  
  User-agent: *           ← rules for all other crawlers
  Disallow: /api/
  Disallow: /login/

Google's crawler MUST respect these rules.
Crawling /admin/ after being told not to = lawsuit risk!
```

---

## Part 2: The Search Engine - Answering Queries

### The Inverted Index

After crawling, Google builds an **inverted index** -- the backbone of search:

```
Forward index (how web pages are stored):
  Page 1: "The cat sat on the mat"
  Page 2: "The dog sat on the log"
  Page 3: "Cats are better than dogs"

Inverted index (how search works):
  "cat"     → [Page 1, Page 3]
  "dog"     → [Page 2, Page 3]
  "sat"     → [Page 1, Page 2]
  "mat"     → [Page 1]
  "log"     → [Page 2]
  "better"  → [Page 3]

Search query: "cat sat"
  → "cat" appears in: [Page 1, Page 3]
  → "sat" appears in: [Page 1, Page 2]
  → Intersection: [Page 1] ← contains BOTH words!
  → Return Page 1
```

The inverted index lets Google find matching pages in milliseconds instead of scanning 10 billion pages.

---

## Orchestration vs Choreography

### Why Orchestration for Crawling?

```
Choreography (each service decides what to do next):
  Fetcher → "I'll send results to Processor"
  Processor → "I'll send new URLs to Frontier"
  Each component makes its own decisions
  
  Problem: If Processor fails, who retries? Who notices?
  No central visibility. Hard to monitor and debug.

Orchestration (central coordinator tells everyone what to do):
  Orchestrator → Fetcher: "Crawl this URL"
  Orchestrator → Processor: "Process this page"
  Orchestrator → Storage: "Store this content"
  
  Benefits:
  → Central monitoring: "Fetcher is 5 minutes behind schedule!"
  → Retry logic: "Fetcher failed on URL X, retry in 30 seconds"
  → Backpressure: "Storage is full, slow down Fetcher"
  → Scheduling: "Crawl high-priority pages first"
```

For a system as complex as web crawling (billions of URLs, many failure modes), orchestration gives much better control and reliability.

---

## The Complete Crawler Pipeline

```
1. URL FRONTIER receives seed URLs and discovered URLs
   → Prioritizes by importance
   → Enforces per-host politeness

2. FETCHER downloads the page
   → DNS resolution (cached for speed)
   → HTTP request with proper User-Agent
   → May use headless browser for JavaScript-rendered pages
   → Respects robots.txt

3. BLOOM FILTER checks: "Have I seen this URL?"
   → If yes: skip (don't re-crawl)
   → If no: proceed

4. SIMHASH checks: "Is this content a near-duplicate?"
   → If yes: skip (don't store/index duplicate)
   → If no: proceed

5. PROCESSOR extracts information:
   → Parse HTML
   → Extract links (new URLs → back to Frontier!)
   → Filter: remove login pages, admin pages, duplicates
   → Canonical URL resolution

6. STORAGE:
   → Raw HTML → Object Store (S3-like)
   → Metadata → Key-Value Store
   → Parsed content → Index Builder

7. INDEX BUILDER:
   → Creates inverted index
   → Feeds the Search Engine
```

---

## Revision Flashcards

**Q: What is the URL Frontier and why does it have two stages?**
A: The crawler's to-do list with (1) front queues for priority (important sites first) and (2) back queues for politeness (don't overwhelm any single host). This balances crawl importance with being a good internet citizen.

**Q: How does a Bloom filter save memory for URL dedup?**
A: A hash set for 10B URLs needs ~200 GB. A Bloom filter needs ~1-2 GB (100x less) with O(1) lookups. Trade-off: ~1% false positive rate (might skip a few new pages), which is acceptable.

**Q: What is Simhash and why is it needed?**
A: Simhash creates a fingerprint of page content. Near-duplicate pages (same article on different URLs) have fingerprints that differ by very few bits. This avoids storing/indexing the same content multiple times.

**Q: Why does Google use orchestration instead of choreography?**
A: Orchestration provides central monitoring, retry logic, scheduling, and backpressure control. For a system crawling billions of pages with many failure modes, this reliability is essential.

**Q: What is an inverted index?**
A: Instead of "page → words in it" (forward index), it's "word → pages containing it." This lets Google find pages matching a query in milliseconds without scanning billions of pages.
