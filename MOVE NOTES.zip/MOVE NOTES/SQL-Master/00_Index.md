# SQL-Master — Index

> **Layout:** Same pattern as `DSA-Master/` — one folder per topic, eight files per topic (`01_Concept` → `08_Problem-List`).
> **Style:** Hindi + English mix, interview-oriented, SQL + diagrams + templates.
> **Theory:** Each `01_Concept` has definitions, pros/cons, comparisons. Each `04_Interview-Thinking` has rapid-fire Q&A.
> **Companion:** Long-form vault notes live in `Obsedian Notes/SQL Notes/` (numbered `01-` … `14-`). Use **SQL-Master** for fast recall and drills; use **Obsedian** for deep reads.

---

## Folder Map

| # | Folder | What's inside (one line) |
|---|--------|---------------------------|
| 01 | [[01-SQL-Foundation]] | DBMS/RDBMS, SQL sub-languages, keys, constraints, DELETE/TRUNCATE/DROP, data integrity, SQL vs NoSQL |
| 02 | [[02-Clauses-and-Execution]] | WHERE → HAVING, execution order, SET ops (UNION/INTERSECT/EXCEPT), COALESCE/NULLIF, CASE, LIKE |
| 03 | [[03-Joins]] | INNER/LEFT/RIGHT/FULL/CROSS/SELF, NATURAL/USING, join algorithms, anti-join, semi-join |
| 04 | [[04-Subqueries-and-CTE]] | Scalar/multi-row/correlated, EXISTS vs IN, CTE vs Temp Table, Recursive CTE, Derived Table |
| 05 | [[05-Aggregates-and-GROUP-BY]] | COUNT/SUM/AVG, GROUP BY, HAVING, ROLLUP/CUBE, String aggregation, conditional aggregation |
| 06 | [[06-Window-Functions]] | OVER, PARTITION BY, RANK/ROW_NUMBER/DENSE_RANK, LAG/LEAD, FIRST_VALUE, NTILE, ROWS vs RANGE |
| 07 | [[07-Indexes-and-Optimization]] | Clustered/non-clustered, covering index, EXPLAIN, Views, Materialized Views (pros/cons), Stored Procs, Functions, Triggers, Cursors, Partitioning, OLTP vs OLAP |
| 08 | [[08-Normalization-and-Transactions]] | 1NF–BCNF–4NF, anomalies, ACID, isolation levels, deadlocks, locking, MVCC, WAL, Star/Snowflake schema |
| 09 | [[09-SQL-Interview-Mastery]] | Patterns, 50+ rapid-fire Q&A, complete glossary A-Z, 8 templates, curated problem list |

---

## How to Use (parallel to DSA-Master)

| File | Purpose |
|------|---------|
| `01_Concept.md` | Definitions, theory, pros/cons, comparisons — "answer any definition question" |
| `02_Mental-Model.md` | Pictures / execution story in your head |
| `03_Coding-Template.md` | Copy-paste SQL skeletons |
| `04_Interview-Thinking.md` | Rapid-fire Q&A + what interviewer is testing |
| `05_Common-Mistakes.md` | Wrong answers vs right mental model |
| `06_Edge-Cases.md` | NULL, duplicates, ties, empty sets |
| `07_Tricks-and-Recognition.md` | "When you see X → think Y" |
| `08_Problem-List.md` | Practice prompts + tags |

---

## Theory Quick-Jump Guide

| Topic | Where to find it |
|-------|-----------------|
| SQL sub-languages (DDL/DML/DQL/DCL/TCL) | 01-Foundation → 01_Concept |
| Keys (PK, FK, Candidate, Composite, Surrogate) | 01-Foundation → 01_Concept |
| DELETE vs TRUNCATE vs DROP | 01-Foundation → 01_Concept |
| SQL vs NoSQL | 01-Foundation → 01_Concept |
| Data Integrity types | 01-Foundation → 01_Concept |
| FK CASCADE/RESTRICT/SET NULL | 01-Foundation → 01_Concept |
| Execution order | 02-Clauses → 01_Concept |
| UNION/INTERSECT/EXCEPT | 02-Clauses → 01_Concept |
| COALESCE/NULLIF/CAST | 02-Clauses → 01_Concept |
| Join types + algorithms | 03-Joins → 01_Concept |
| Anti-join / Semi-join | 03-Joins → 01_Concept |
| CTE vs Temp Table vs View | 04-Subqueries → 01_Concept |
| Recursive CTE | 04-Subqueries → 01_Concept |
| EXISTS vs IN | 04-Subqueries → 01_Concept |
| Aggregate functions (all) | 05-Aggregates → 01_Concept |
| ROLLUP/CUBE/GROUPING SETS | 05-Aggregates → 01_Concept |
| Window function catalog | 06-Windows → 01_Concept |
| ROWS vs RANGE frame | 06-Windows → 01_Concept |
| ROW_NUMBER vs RANK vs DENSE_RANK | 06-Windows → 01_Concept |
| View vs Materialized View (pros/cons) | 07-Indexes → 01_Concept |
| Stored Procedure vs Function | 07-Indexes → 01_Concept |
| Triggers (types, pros/cons) | 07-Indexes → 01_Concept |
| Cursors (why avoid) | 07-Indexes → 01_Concept |
| OLTP vs OLAP | 07-Indexes → 01_Concept |
| Table Partitioning | 07-Indexes → 01_Concept |
| Normalization (1NF-5NF) | 08-Normalization → 01_Concept |
| ACID | 08-Normalization → 01_Concept |
| Isolation levels | 08-Normalization → 01_Concept |
| Locking types | 08-Normalization → 01_Concept |
| MVCC / WAL | 08-Normalization → 01_Concept |
| Star vs Snowflake schema | 08-Normalization → 01_Concept |
| Deadlocks | 08-Normalization → 01_Concept |
| Complete glossary (100+ terms) | 09-Mastery → 01_Concept |
| 50+ rapid-fire Q&A (all topics) | 09-Mastery → 04_Interview-Thinking |

---

## Revision Paths

### 30 minutes (viva / rapid)

```
01-Foundation → 04_Interview-Thinking (rapid-fire Q&A)
02-Clauses → 04_Interview-Thinking (execution order, WHERE vs HAVING)
03-Joins → 04_Interview-Thinking (INNER vs LEFT)
07-Indexes → 04_Interview-Thinking (View vs MV, SP vs Function)
08-Normalization → 04_Interview-Thinking (ACID, isolation, normalization)
```

### 2–3 hours (interview)

```
All 01_Concept files (definitions + theory)
All 04_Interview-Thinking files (Q&A)
09-SQL-Interview-Mastery → 01_Concept (glossary)
09-SQL-Interview-Mastery → 03_Coding-Template (8 templates)
09-SQL-Interview-Mastery → 08_Problem-List
```

### Full day (deep prep)

```
All files in order: 01 → 09
Focus on 01_Concept + 04_Interview-Thinking per folder
Practice 08_Problem-List from folders 03, 05, 06
```

---

## Link to Obsedian SQL Notes

| SQL-Master folder | Obsedian files (approx.) |
|-------------------|---------------------------|
| 01-Foundation | `01`, `02`, `03` |
| 02-Clauses | `04` |
| 03-Joins | `05` |
| 04-Subqueries | `06` |
| 05-Aggregates | `07`, `14` |
| 06-Windows | `08`, `13` |
| 07-Indexes | `09` |
| 08-Norm+TX | `10`, `11` |
| 09-Interview | `12` (+ patterns from `13`) |

---

*Total: 9 topic folders × 8 files + this index | Beginner → interview-ready*
