# Subqueries and CTE — Common Mistakes

| Mistake | Issue |
|---------|--------|
| `NOT IN` with nullable subquery | Empty/wrong results |
| Correlated subquery in SELECT without limit | Repeated heavy work — consider join/window |
| Assuming CTE always materialized once | Not always true — check plan |
| Scalar subquery returns multiple rows | Runtime error |

---

*Next: [[06_Edge-Cases]]*
