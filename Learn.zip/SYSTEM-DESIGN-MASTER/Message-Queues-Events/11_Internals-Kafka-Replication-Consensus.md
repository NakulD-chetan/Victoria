# Internals: Kafka Replication and Consensus

> **Permanent Recall:** Every partition has ONE leader and N-1 followers. Producers/consumers talk ONLY to the leader. Followers fetch from leader (like consumers). ISR (In-Sync Replicas) = replicas caught up within `replica.lag.time.max.ms`. `acks=all` means "all ISR replicas acknowledged." Leader election: when leader dies, controller picks new leader from ISR. KRaft replaces ZooKeeper — uses Raft consensus for metadata. Unclean leader election = data loss risk.

---

## Why This Matters

Storage alone does not make Kafka reliable.

Kafka durability comes from the combination of:

- leader-follower replication
- ISR tracking
- high watermark rules
- careful leader election

This is the file that explains why `acks=all` means something real and why unclean election is dangerous.

---

## Replication Architecture

```
REPLICATION MODEL:

Topic "orders" with 3 partitions, replication.factor=3, 3 brokers:

Broker 0                Broker 1                Broker 2
┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐
│                  │    │                  │    │                  │
│ orders-P0 LEADER │◄──►│ orders-P0 follower│    │ orders-P0 follower│
│ orders-P1 follower│   │ orders-P1 LEADER │◄──►│ orders-P1 follower│
│ orders-P2 follower│   │ orders-P2 follower│   │ orders-P2 LEADER │
│                  │    │                  │    │                  │
└──────────────────┘    └──────────────────┘    └──────────────────┘

KEY RULES:
  - Each partition has exactly ONE leader at any time
  - All reads and writes go through the leader
  - Followers PULL from leader (act like special consumers)
  - Leaders are distributed across brokers (load balancing)
  - Controller assigns leaders (one broker is the controller)
```

---

## How Replication Actually Works (Fetch Protocol)

```
FOLLOWER REPLICATION — PULL-BASED:

Followers don't receive pushes. They FETCH from the leader,
just like a consumer would, using the same Fetch API.

┌────────────────────────────────────────────────────────────────┐
│ REPLICATION FETCH LOOP (on each follower broker):              │
│                                                                │
│ ReplicaFetcherThread (one per leader broker):                  │
│                                                                │
│   while (running):                                             │
│     // Build fetch request for all partitions led by this broker│
│     request = FetchRequest(                                    │
│       replicaId = this_broker_id,   // identifies as replica   │
│       maxWait = 500ms,              // replica.fetch.wait.max  │
│       minBytes = 1,                                            │
│       partitions = [                                           │
│         {topic: "orders", partition: 0, offset: 42,            │
│          maxBytes: 1MB},                                       │
│         {topic: "orders", partition: 1, offset: 100,           │
│          maxBytes: 1MB},                                       │
│       ]                                                        │
│     )                                                          │
│                                                                │
│     response = leader.send(request)                            │
│                                                                │
│     for each partition_data in response:                       │
│       // Append fetched records to local log                   │
│       localLog.append(partition_data.records)                  │
│       // Update high watermark                                 │
│       updateHighWatermark(partition_data.highWatermark)         │
│       // Update fetch offset for next request                  │
│       nextFetchOffset = localLog.endOffset()                   │
│                                                                │
│     // Slight delay if no data (replica.fetch.backoff.ms)      │
└────────────────────────────────────────────────────────────────┘

LEADER SIDE — TRACKING REPLICAS:
  Leader maintains per-replica state:
  ┌──────────────────────────────────────────────────────┐
  │ Replica State for partition orders-0:                 │
  │                                                      │
  │   Replica 0 (self/leader):                            │
  │     LEO (Log End Offset) = 50                         │
  │                                                      │
  │   Replica 1 (follower):                               │
  │     remoteLogEndOffset = 48                           │
  │     lastFetchTime = 1710000000500                     │
  │     inISR = true                                      │
  │                                                      │
  │   Replica 2 (follower):                               │
  │     remoteLogEndOffset = 47                           │
  │     lastFetchTime = 1710000000200                     │
  │     inISR = true                                      │
  │                                                      │
  └──────────────────────────────────────────────────────┘
```

---

## LEO, HW, and the Replication Watermarks

```
KEY CONCEPTS: LEO AND HIGH WATERMARK (HW)

LEO (Log End Offset):
  The offset of the NEXT message to be written.
  Each replica has its own LEO.
  Leader LEO ≥ Follower LEO (leader is always ahead or equal)

HW (High Watermark):
  The offset up to which ALL ISR replicas have replicated.
  HW = min(LEO of all ISR replicas)
  Consumers can ONLY read up to HW (not beyond)
  Messages between HW and LEO are "uncommitted"

EXAMPLE TIMELINE:

  Time 1: Producer sends messages 50, 51, 52 to leader
  ┌────────────────────────────────────────────────────┐
  │ Leader (Broker 0):    [... 48 49 50 51 52]  LEO=53 │
  │ Follower (Broker 1):  [... 48 49]           LEO=50 │
  │ Follower (Broker 2):  [... 48 49 50]        LEO=51 │
  │                                                    │
  │ ISR = {0, 1, 2}                                    │
  │ HW = min(53, 50, 51) = 50                          │
  │ Consumer can read up to offset 49 (< HW)           │
  └────────────────────────────────────────────────────┘

  Time 2: Followers fetch and catch up
  ┌────────────────────────────────────────────────────┐
  │ Leader (Broker 0):    [... 48 49 50 51 52]  LEO=53 │
  │ Follower (Broker 1):  [... 48 49 50 51 52] LEO=53 │
  │ Follower (Broker 2):  [... 48 49 50 51 52] LEO=53 │
  │                                                    │
  │ HW = min(53, 53, 53) = 53                          │
  │ Consumer can now read up to offset 52              │
  │ Messages 50, 51, 52 are now "committed"            │
  └────────────────────────────────────────────────────┘

HOW HW IS PROPAGATED:
  1. Follower sends Fetch(offset=50) to leader
  2. Leader responds with:
     - Records from offset 50 onwards
     - Current HW value
  3. Follower:
     - Appends records to its log
     - Updates its local HW to min(leader's HW, own LEO)
  4. Leader updates HW:
     - After receiving fetch from ALL ISR followers
     - HW = min(own LEO, all ISR followers' reported LEO)

WHY THIS MATTERS FOR acks=all:
  Producer with acks=all:
    "Don't ack me until HW advances past my message"
    = "all ISR replicas have my data"
    Message is DURABLE even if leader crashes
```

---

## ISR (In-Sync Replicas) — The Heart of Kafka Durability

```
ISR MANAGEMENT:

ISR = set of replicas that are "caught up" with the leader.

REPLICA FALLS OUT OF ISR WHEN:
  It hasn't fetched for replica.lag.time.max.ms (default 30s)
  NOT based on offset lag (changed in Kafka 0.9+)

  Why time-based, not offset-based?
    - Offset lag: a burst of messages makes ALL followers "laggy"
      even though they're actively fetching
    - Time lag: only removes replicas that have STOPPED fetching
      (crashed, network partition, overloaded)

ISR SHRINK:
  ┌────────────────────────────────────────────────────┐
  │ Scenario: Broker 2 crashes                         │
  │                                                    │
  │ Time 0: ISR = {0, 1, 2}                            │
  │ Time 0: Broker 2 stops fetching                    │
  │                                                    │
  │ Time +30s: replica.lag.time.max.ms exceeded         │
  │ Leader removes Broker 2 from ISR                   │
  │ ISR = {0, 1}                                       │
  │                                                    │
  │ Leader reports ISR change to Controller             │
  │ Controller updates metadata in ZK/KRaft             │
  │ HW now = min(LEO of broker 0, LEO of broker 1)    │
  │ acks=all now only waits for broker 1               │
  └────────────────────────────────────────────────────┘

ISR EXPAND (when replica catches up):
  ┌────────────────────────────────────────────────────┐
  │ Broker 2 comes back, starts fetching               │
  │ Catches up to within replica.lag.time.max.ms       │
  │ Leader adds Broker 2 back to ISR                   │
  │ ISR = {0, 1, 2}                                    │
  └────────────────────────────────────────────────────┘

min.insync.replicas:
  Minimum ISR size for the leader to accept writes (with acks=all)
  If ISR shrinks below this → leader rejects Produce requests
  Returns: NOT_ENOUGH_REPLICAS error

  Example:
    replication.factor = 3
    min.insync.replicas = 2
    If 2 brokers crash → ISR = {leader only} → size 1 < 2
    → Leader stops accepting acks=all writes
    → Prevents data loss: we won't ack data stored on only 1 broker
```

---

## Leader Election — What Happens When the Leader Dies

```
LEADER ELECTION FLOW:

1. LEADER FAILURE DETECTED:
   Controller broker monitors all brokers via:
     ZooKeeper: ephemeral znodes (session timeout)
     KRaft: heartbeat protocol (broker.heartbeat.interval.ms)

   When leader broker's session expires:
     Controller receives notification
     "Broker 0 is DEAD" (was leader of partitions P0, P3, P7)

2. CONTROLLER SELECTS NEW LEADER:
   ┌────────────────────────────────────────────────────┐
   │ For each partition that lost its leader:            │
   │                                                    │
   │   candidates = current ISR - dead broker            │
   │   if candidates is empty:                          │
   │     if unclean.leader.election.enable = true:      │
   │       pick ANY alive replica (DATA LOSS RISK!)      │
   │     else:                                          │
   │       partition goes OFFLINE (unavailable)          │
   │       wait for an ISR replica to come back          │
   │                                                    │
   │   newLeader = candidates[0]  // first in ISR list  │
   │   (preferred replica assignment for balanced load)  │
   └────────────────────────────────────────────────────┘

3. CONTROLLER BROADCASTS:
   LeaderAndIsrRequest to new leader + all replicas:
     "Partition orders-0: new leader = Broker 1, ISR = {1, 2}"

4. NEW LEADER STARTS:
   - Accepts produce requests
   - Serves fetch requests
   - Other followers start fetching from new leader

5. LOG TRUNCATION ON FOLLOWERS:
   ┌────────────────────────────────────────────────────┐
   │ IMPORTANT: Followers may have divergent data       │
   │                                                    │
   │ Old leader had LEO=55, HW=50                       │
   │ Follower had LEO=52 (fetched 50,51 but not yet 52) │
   │ New leader (different follower) has LEO=51          │
   │                                                    │
   │ Problem: old follower has offsets 51 that new       │
   │ leader doesn't have!                               │
   │                                                    │
   │ Solution: TRUNCATION                               │
   │   Follower sends OffsetsForLeaderEpoch request     │
   │   New leader responds: "my end offset for epoch    │
   │   E was 51"                                        │
   │   Follower truncates its log to offset 51          │
   │   Then resumes fetching from 51                    │
   │                                                    │
   │ leader-epoch-checkpoint file tracks epoch→offset   │
   └────────────────────────────────────────────────────┘

LEADER EPOCH:
  Monotonically increasing number per partition
  Incremented every time a new leader is elected
  Used to detect and resolve log divergence

  leader-epoch-checkpoint file:
    0 0     # epoch 0 started at offset 0
    1 51    # epoch 1 started at offset 51
    2 100   # epoch 2 started at offset 100
```

---

## Unclean Leader Election — The Data Loss Trade-off

```
UNCLEAN LEADER ELECTION:

Scenario:
  Partition P0: replication.factor=3
  ISR = {Broker 0 (leader)}   ← only 1 in ISR!
  Brokers 1, 2 fell out of ISR (were lagging/dead)

  Now Broker 0 (the only ISR member) crashes too.

  ALL ISR replicas are dead.

  Option A: unclean.leader.election.enable = false (default since 0.11)
    Partition goes OFFLINE
    No reads or writes until an ISR replica recovers
    DATA SAFE but UNAVAILABLE (CP in CAP theorem)

  Option B: unclean.leader.election.enable = true
    Pick ANY alive replica (Broker 1 or 2)
    They are behind → some messages LOST permanently
    Partition is AVAILABLE but DATA LOST (AP in CAP theorem)

VISUALIZED:
  Leader (Broker 0): [msg0 msg1 msg2 msg3 msg4 msg5]  ← had all data
  Broker 1:          [msg0 msg1 msg2]                   ← 3 behind
  Broker 2:          [msg0 msg1 msg2 msg3]              ← 2 behind

  Broker 0 crashes. Unclean election picks Broker 2.
  New leader: Broker 2, LEO=4
  Messages msg4, msg5 are LOST FOREVER
  Broker 1 truncates to Broker 2's epoch offset

RECOMMENDATION:
  Most production systems: unclean.leader.election.enable = false
  Data integrity > availability for financial, order, payment systems
  For analytics/logs where loss is acceptable: can enable
```

---

## The Controller — Kafka's Cluster Brain

```
CONTROLLER RESPONSIBILITIES:

One broker is elected as the Controller (the cluster's brain):

┌─────────────────────────────────────────────────────────────┐
│                     CONTROLLER BROKER                        │
│                                                             │
│  Responsibilities:                                           │
│  1. Partition leader election (on broker failure)            │
│  2. ISR changes (propagate to metadata)                     │
│  3. Topic creation/deletion                                  │
│  4. Partition reassignment                                   │
│  5. Broker registration/deregistration                       │
│  6. Preferred leader election                                │
│                                                             │
│  Controller election (who is the controller?):               │
│    ZooKeeper mode: first to create /controller znode wins    │
│    KRaft mode: Raft leader among controller nodes            │
│                                                             │
│  If controller crashes:                                      │
│    ZK: other brokers race to create /controller              │
│    KRaft: Raft elects new leader among controller quorum     │
│                                                             │
│  Controller sends LeaderAndIsr requests to all brokers       │
│  on any leadership change                                    │
└─────────────────────────────────────────────────────────────┘

CONTROLLER FAILOVER TIMELINE:
  T=0:    Controller (Broker 0) crashes
  T=5s:   ZK session expires (session.timeout: 6s) / KRaft detects
  T=5.1s: New controller elected (Broker 1)
  T=5.2s: New controller reads all metadata from ZK/KRaft log
  T=5.5s: New controller sends UpdateMetadata to all brokers
  T=6s:   Cluster fully operational with new controller

  During failover: NO leadership changes possible
  Existing leaders continue serving (no disruption to data flow)
  Only new elections are delayed
```

---

## KRaft: Replacing ZooKeeper with Raft

```
ZOOKEEPER MODE (legacy) vs KRAFT MODE (modern):

ZOOKEEPER MODE:
  ┌──────────────────────────────────────────────────────────┐
  │                                                          │
  │  Kafka Brokers          ZooKeeper Ensemble               │
  │  ┌────────┐             ┌─────┐ ┌─────┐ ┌─────┐        │
  │  │Broker 0│────────────►│ ZK1 │ │ ZK2 │ │ ZK3 │        │
  │  │Broker 1│────────────►│     │ │     │ │     │        │
  │  │Broker 2│────────────►│     │ │     │ │     │        │
  │  └────────┘             └─────┘ └─────┘ └─────┘        │
  │                                                          │
  │  ZK stores:                                              │
  │    /brokers/ids/[0,1,2]     (broker registration)        │
  │    /brokers/topics/orders   (topic config + partition map)│
  │    /controller              (current controller)         │
  │    /admin/reassign_partitions (reassignment tasks)        │
  │    /isr_change_notification  (ISR changes)               │
  │                                                          │
  │  Problems with ZK:                                       │
  │    - Separate system to deploy, monitor, maintain         │
  │    - ZK has its own failure modes                         │
  │    - Metadata reads go over network to ZK                 │
  │    - Scalability limit: ~200K partitions per cluster      │
  │    - Split-brain scenarios between Kafka and ZK           │
  └──────────────────────────────────────────────────────────┘

KRAFT MODE (Kafka 3.3+, production-ready):
  ┌──────────────────────────────────────────────────────────┐
  │                                                          │
  │  No external dependency! Metadata managed by Kafka itself │
  │                                                          │
  │  Controller Nodes (run Raft consensus):                   │
  │  ┌────────┐  ┌────────┐  ┌────────┐                     │
  │  │Ctrl 0  │  │Ctrl 1  │  │Ctrl 2  │                     │
  │  │(Leader)│◄►│(Follwr)│◄►│(Follwr)│                     │
  │  │Raft log│  │Raft log│  │Raft log│                     │
  │  └────────┘  └────────┘  └────────┘                     │
  │       │                                                  │
  │       ▼ (metadata updates via Raft log)                  │
  │                                                          │
  │  Broker Nodes (data storage):                             │
  │  ┌────────┐  ┌────────┐  ┌────────┐                     │
  │  │Broker 0│  │Broker 1│  │Broker 2│                     │
  │  │        │  │        │  │        │                     │
  │  │ Fetch  │  │ Fetch  │  │ Fetch  │                     │
  │  │metadata│  │metadata│  │metadata│                     │
  │  │from    │  │from    │  │from    │                     │
  │  │Raft log│  │Raft log│  │Raft log│                     │
  │  └────────┘  └────────┘  └────────┘                     │
  │                                                          │
  │  Benefits:                                               │
  │    - No ZooKeeper to manage                              │
  │    - Faster controller failover (~seconds, not ~30s)     │
  │    - Millions of partitions (10x+ scalability)           │
  │    - Simpler deployment and operations                    │
  │    - Metadata is an event log (Kafka's own model!)       │
  └──────────────────────────────────────────────────────────┘
```

### Raft Consensus Protocol (What KRaft Uses)

```
RAFT CONSENSUS — HOW KRAFT ELECTS A CONTROLLER LEADER:

Raft is a consensus protocol that ensures a group of nodes
agree on a single leader and a consistent log of operations.

THREE STATES:
  - Follower (default state)
  - Candidate (wants to become leader)
  - Leader (the boss)

LEADER ELECTION:
  ┌────────────────────────────────────────────────────────────┐
  │                                                            │
  │ 1. FOLLOWER waits for heartbeat from leader                │
  │    If no heartbeat for election_timeout (randomized):      │
  │      Become CANDIDATE                                      │
  │                                                            │
  │ 2. CANDIDATE:                                              │
  │    Increment term (epoch number)                           │
  │    Vote for self                                           │
  │    Send RequestVote RPC to all other nodes:                │
  │      {term: 5, candidateId: 1, lastLogIndex: 42,          │
  │       lastLogTerm: 4}                                      │
  │                                                            │
  │ 3. VOTERS respond:                                         │
  │    Grant vote IF:                                          │
  │      - Haven't voted for anyone else in this term          │
  │      - Candidate's log is at least as up-to-date           │
  │        (lastLogTerm > my lastLogTerm, OR                   │
  │         same term AND lastLogIndex >= my lastLogIndex)     │
  │                                                            │
  │ 4. CANDIDATE receives majority votes:                      │
  │    Becomes LEADER                                          │
  │    Sends heartbeat (AppendEntries with no data) to all     │
  │    Other candidates step down to FOLLOWER                  │
  │                                                            │
  │ 5. SPLIT VOTE (no majority):                               │
  │    Election timeout → new election with higher term        │
  │    Randomized timeout prevents infinite tie                │
  │    Timeout: 150-300ms (randomized per node)                │
  │                                                            │
  └────────────────────────────────────────────────────────────┘

LOG REPLICATION IN RAFT:
  ┌────────────────────────────────────────────────────────────┐
  │                                                            │
  │ Leader receives metadata change (e.g., new topic):         │
  │                                                            │
  │ 1. Append entry to own log:                                │
  │    {term: 5, index: 43, data: "CreateTopic orders"}        │
  │                                                            │
  │ 2. Send AppendEntries RPC to followers:                    │
  │    {term: 5, prevLogIndex: 42, prevLogTerm: 4,             │
  │     entries: [{index:43, data:"CreateTopic orders"}]}      │
  │                                                            │
  │ 3. Follower appends to its log, responds success           │
  │                                                            │
  │ 4. Leader counts responses:                                │
  │    If majority (2 of 3) have entry 43:                     │
  │      Mark entry 43 as COMMITTED                            │
  │      Apply to state machine (update metadata)              │
  │      Notify followers of new commit index                  │
  │                                                            │
  │ 5. Followers apply committed entries to their state        │
  │                                                            │
  └────────────────────────────────────────────────────────────┘

KRAFT METADATA LOG:
  The Raft log IS a Kafka log (stored like any partition):
    __cluster_metadata topic
    Contains: broker registrations, topic configs, partition
    assignments, ISR changes, ACL changes, etc.

  Brokers consume this topic like any Kafka consumer:
    Fetch metadata updates from controller's Raft log
    Apply to their local metadata cache
    Event-sourced: replay log to rebuild state
```

---

## acks Configuration — Deep Dive

```
ACKS PARAMETER — WHAT ACTUALLY HAPPENS:

acks=0 (fire and forget):
  ┌──────────────────────────────────────────────────────┐
  │ Producer → send() → return immediately                │
  │ Don't wait for ANY acknowledgment                     │
  │ Don't even wait for TCP ACK of the request            │
  │ Fastest, but messages can be lost silently             │
  │ Use for: metrics, logs where loss is acceptable        │
  └──────────────────────────────────────────────────────┘

acks=1 (leader only):
  ┌──────────────────────────────────────────────────────┐
  │ Producer → send() → Broker receives                   │
  │ Leader appends to its log (page cache)                │
  │ Leader sends ProduceResponse(offset=42) to producer   │
  │ Producer callback fires: "success, offset 42"         │
  │                                                      │
  │ RISK: leader crashes BEFORE followers replicate        │
  │ → message in page cache is LOST                       │
  │ → new leader elected from ISR, doesn't have msg       │
  │                                                      │
  │ Fast, reasonable durability for most use cases         │
  └──────────────────────────────────────────────────────┘

acks=all (-1) (all ISR replicas):
  ┌──────────────────────────────────────────────────────┐
  │ Producer → send() → Leader receives                   │
  │ Leader appends to its log                             │
  │ Leader puts request in PURGATORY                      │
  │                                                      │
  │ Followers fetch from leader (normal replication)      │
  │ Each follower appends, sends fetch response           │
  │ Leader tracks: which ISR replicas have this offset?   │
  │                                                      │
  │ When ALL ISR replicas have the data:                  │
  │   HW advances past the message's offset               │
  │   Purgatory completes the delayed response            │
  │   Producer receives ProduceResponse(offset=42)        │
  │                                                      │
  │ SAFEST: even if leader crashes, data exists on ISR    │
  │ SLOWEST: must wait for slowest ISR replica            │
  │                                                      │
  │ Latency ≈ network RTT to slowest replica + disk write │
  │ Typically adds 1-5ms compared to acks=1               │
  └──────────────────────────────────────────────────────┘

PURGATORY (delayed operation manager):
  ┌──────────────────────────────────────────────────────┐
  │ Purgatory is a timing wheel + watcher system:         │
  │                                                      │
  │ ProduceRequest with acks=all:                         │
  │   1. Create DelayedProduce operation                  │
  │   2. Set timeout = request.timeout.ms (30s)           │
  │   3. Add watchers on ISR replicas' fetch progress     │
  │   4. On each replica fetch completion:                │
  │      Check: have ALL ISR replicas caught up?           │
  │      If yes: complete operation → send response        │
  │   5. On timeout: respond with error                    │
  │                                                      │
  │ Timing Wheel (efficient timeout management):          │
  │   Hierarchical timing wheel (like a clock):           │
  │   Tick = 1ms, wheel size = 20 (20ms per rotation)    │
  │   Overflow → next level: 20ms × 20 = 400ms           │
  │   O(1) insertion and expiration                       │
  │   Way more efficient than priority queue for timeouts │
  └──────────────────────────────────────────────────────┘
```

---

## Exactly-Once Semantics (EOS) — Internal Mechanics

```
EXACTLY-ONCE IN KAFKA — THREE PILLARS:

PILLAR 1: IDEMPOTENT PRODUCER
  ┌────────────────────────────────────────────────────────────┐
  │ Problem: network error → producer retries → duplicate msg  │
  │                                                            │
  │ Solution: producer gets a ProducerId (PID) from broker     │
  │ Each message batch has: (PID, epoch, sequence_number)      │
  │                                                            │
  │ Broker tracks: per (PID, partition) → last sequence seen   │
  │                                                            │
  │ If broker receives batch with sequence ≤ last seen:        │
  │   → DUPLICATE → discard, return success (idempotent!)      │
  │                                                            │
  │ If broker receives batch with sequence > last seen + 1:    │
  │   → OUT_OF_ORDER → return error (producer bug)             │
  │                                                            │
  │ Broker state (in-memory + checkpoint file):                │
  │   {PID=1234, partition=2} → lastSequence=47                │
  │   {PID=1234, partition=5} → lastSequence=12                │
  │                                                            │
  │ enable.idempotence = true (default since Kafka 3.0)        │
  └────────────────────────────────────────────────────────────┘

PILLAR 2: TRANSACTIONAL PRODUCER
  ┌────────────────────────────────────────────────────────────┐
  │ Problem: produce to multiple partitions atomically         │
  │ Either ALL messages in the transaction commit, or NONE     │
  │                                                            │
  │ Transaction flow:                                          │
  │                                                            │
  │ 1. producer.initTransactions()                             │
  │    → Register transactional.id with Transaction Coordinator│
  │    → Get PID + epoch                                       │
  │                                                            │
  │ 2. producer.beginTransaction()                             │
  │    → Local state: transaction started                      │
  │                                                            │
  │ 3. producer.send(topic1, msg1)                             │
  │    producer.send(topic2, msg2)                              │
  │    → Messages sent with transactional markers              │
  │    → Brokers write them but mark as UNCOMMITTED            │
  │                                                            │
  │ 4. producer.commitTransaction()                            │
  │    → Producer → Transaction Coordinator:                   │
  │      "Commit transaction T1"                               │
  │    → Coordinator writes COMMIT marker to transaction log   │
  │    → Coordinator sends WriteTxnMarker to all partitions    │
  │    → Each partition appends COMMIT control record          │
  │                                                            │
  │ OR producer.abortTransaction()                             │
  │    → ABORT marker → messages ignored by consumers          │
  │                                                            │
  │ Transaction Coordinator:                                   │
  │   Internal topic: __transaction_state (50 partitions)      │
  │   Stores: {transactionalId, PID, epoch, state, partitions} │
  │   State: Ongoing → PrepareCommit → CompleteCommit          │
  └────────────────────────────────────────────────────────────┘

PILLAR 3: TRANSACTIONAL CONSUMER (read_committed)
  ┌────────────────────────────────────────────────────────────┐
  │ Consumer with isolation.level = read_committed:            │
  │                                                            │
  │ Reads ONLY messages that are:                              │
  │   - Non-transactional, OR                                  │
  │   - Part of a COMMITTED transaction                        │
  │                                                            │
  │ Skips messages from ABORTED transactions                   │
  │ Skips messages from ONGOING transactions (not yet decided) │
  │                                                            │
  │ LSO (Last Stable Offset):                                  │
  │   Offset of the earliest ongoing transaction               │
  │   Consumer can't read past LSO                             │
  │   If a transaction is stuck: LSO is stuck → consumer lags  │
  │   transaction.timeout.ms (default 60s) prevents this       │
  └────────────────────────────────────────────────────────────┘
```

---

## Preferred Replica Election and Rack Awareness

```
PREFERRED REPLICA ELECTION:

After failures and recoveries, leaders may be unbalanced:
  Broker 0: leads 50 partitions
  Broker 1: leads 5 partitions
  Broker 2: leads 45 partitions

Each partition has a "preferred leader" (first replica in assignment).
auto.leader.rebalance.enable = true (default)
Periodically checks: is current leader == preferred leader?
If not: trigger leader election to move back to preferred.

RACK AWARENESS:
  broker.rack = us-east-1a  (on each broker)

  When assigning replicas to partitions, Kafka ensures:
    Replicas are spread across racks/AZs
    No two replicas of same partition in same rack

  Example (3 racks, replication=3):
    Partition 0: Broker0 (rack-a), Broker3 (rack-b), Broker6 (rack-c)
    Partition 1: Broker1 (rack-a), Broker4 (rack-b), Broker7 (rack-c)

  Rack-aware follower fetching (KIP-392):
    Consumer can read from closest replica (same rack)
    Reduces cross-rack network traffic
    replica.selector.class = RackAwareReplicaSelector
```

---

## 30-SECOND REVISION BOX

```
REPLICATION: leader + followers, pull-based (followers fetch)
LEO: log end offset (each replica), HW: high watermark (min of ISR LEOs)
ISR: in-sync replicas (time-based lag check, not offset-based)
LEADER ELECTION: controller picks from ISR, log truncation on divergence
ACKS: 0=fire-forget, 1=leader-only, all=wait-for-ISR
PURGATORY: timing wheel for delayed acks=all responses
UNCLEAN ELECTION: data loss trade-off (disabled by default)
CONTROLLER: cluster brain, one broker, elected via ZK/Raft
KRAFT: Raft consensus for metadata, replaces ZooKeeper
EXACTLY-ONCE: idempotent PID+seq + transactions + read_committed
```

---

**Prev: [[10_Internals-Kafka-Storage-Engine]] | Next: [[12_Internals-Kafka-Producer-Consumer-Protocol]]**
