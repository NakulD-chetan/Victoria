# Design Instagram — Common Mistakes

> **Permanent Recall:** Top mistakes = storing images in DB, no CDN, single resolution, sync processing. Always treat Instagram as a **media platform**, not just a social feed.

---

## Top 10 Common Mistakes

| # | Mistake | Why It's Wrong | Correct Approach |
|---|---------|----------------|------------------|
| 1 | **Storing images in database** | DB can't handle 200TB/day; slow, expensive | Object storage (S3) + metadata in DB |
| 2 | **No CDN** | High latency, overloaded origin, poor UX | CloudFront/CDN for all media |
| 3 | **Single image resolution** | Wastes bandwidth; slow feed load | Thumbnail, medium, full — serve right size |
| 4 | **Synchronous image processing** | Blocks upload; poor UX; timeout risk | Async queue (SQS/Kafka) + workers |
| 5 | **Same approach as Twitter** | Ignores media; Twitter is text-centric | Media pipeline, CDN, storage costs |
| 6 | **Ignoring storage costs** | 365PB over 5yr — huge cost | Compression, lifecycle policies, cold storage |
| 7 | **No image compression** | Raw 4K in feed = slow + expensive | JPEG/WebP; quality 80–85 |
| 8 | **Not discussing content moderation** | Legal/safety requirement at scale | ML + human review; block before CDN |
| 9 | **Ignoring stories architecture** | Stories need TTL, different model | Ephemeral storage, 24h expiry |
| 10 | **Not considering explore** | Discovery is core feature | Recommendation engine, trending |

---

## Detailed Callouts

### Mistake 1: Images in Database

```
❌ Photo blob → MySQL/Postgres
✅ Photo → S3; DB stores: photo_id, user_id, s3_key, thumbnail_url, cdn_url
```

### Mistake 4: Synchronous Processing

```
❌ Upload → Resize → Filter → Save → Response (10+ sec)
✅ Upload → S3 → Return 202 → Queue → Worker processes → Notify when ready
```

### Mistake 5: Copying Twitter Design

| Twitter | Instagram |
|---------|-----------|
| Text in DB | Media in S3; URLs in DB |
| Timeline cache | Timeline + CDN for media |
| No processing | Resize, filter, compress |

---

## Anti-Pattern Diagram

```
❌ BAD:
Client ─► API ─► DB (store image) ─► Response
              └── DB explodes at scale

✅ GOOD:
Client ─► API ─► S3 ─► Queue ─► Worker ─► CDN
              └── Metadata ─► DB
```

---

## What Interviewers Listen For

- **"We use S3 or object storage, not the database, for media"**
- **"CDN for delivery — we never serve from origin to users"**
- **"Async processing with multiple resolutions"**
- **"Stories are ephemeral — TTL and separate cleanup"**
- **"Explore needs a recommendation engine"**

---

## Red Flags to Avoid

- Saying "we store photos in MySQL" — instant fail
- "We'll process images synchronously" — shows lack of scale thinking
- "We don't need CDN" — ignores global users
- Treating Instagram exactly like Twitter — misses media entirely
- Forgetting stories or explore — incomplete requirements

---

## Recovery Phrases

If you slip: "Actually, for media at this scale, we'd use S3 and CDN, not the database."

---

## Mistake Severity

| Severity | Mistakes | Impact |
|----------|----------|--------|
| **Critical** | Images in DB, no CDN | System won't scale; instant rejection |
| **Major** | Sync processing, single resolution | Poor UX; costly at scale |
| **Moderate** | Ignoring stories, explore | Incomplete design |
| **Minor** | No compression details | Shows less depth |

---

## Correct Architecture Checklist

- [ ] Object storage (S3/GCS) for media
- [ ] CDN for all media delivery
- [ ] Async image processing (queue + workers)
- [ ] Multiple resolutions (thumbnail, medium, full)
- [ ] Fan-out for feed (with celebrity exception)
- [ ] Stories with TTL / ephemeral design
- [ ] Explore / recommendation discussed

---

## Why Candidates Make These Mistakes

- **DB for images:** Familiar with CRUD; don't think about blob storage
- **No CDN:** Local dev works without it; forget global users
- **Sync processing:** Simpler to reason about; don't consider scale
- **Twitter clone:** Memorized Twitter; don't adapt for media

---

## Summary

Avoid: DB for media, no CDN, sync processing, single resolution, ignoring stories/explore. Always: S3, CDN, async, multi-resolution, fan-out with celebrity handling.

---

## Interview Impact

Making mistake #1 (images in DB) or #2 (no CDN) in a FAANG interview often leads to immediate red flag. Fix these first; the rest show depth.

---

## Reversal

If asked "What's wrong with storing images in DB?" — Answer: Scale (200TB/day), cost, latency, DB not designed for blobs. Correct: Object storage + metadata in DB.

---

## Order of Fixes

1. Move media to S3
2. Add CDN
3. Make processing async
4. Add multiple resolutions
5. Handle celebrities (hybrid fan-out)
