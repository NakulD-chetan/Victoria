import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNewCanvasStore } from '../state/store';
import { parseCSV } from './csv-utils';

const MAX_CSV_BYTES = 5 * 1024 * 1024;
const PREVIEW_ROWS = 200;

const DELIMITERS = [
  { id: 'auto', label: 'Auto' },
  { id: ',', label: 'Comma' },
  { id: '\t', label: 'Tab' },
  { id: ';', label: 'Semicolon' },
  { id: '|', label: 'Pipe' },
];

function CsvLoaderWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [source, setSource] = useState(data.source || '');
  const [mode, setMode] = useState(data.mode || 'table');
  const saveTimerRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => setSource(data.source || ''), [data.source]);

  const parsed = useMemo(() => {
    try {
      return { ...parseCSV(source, data.delimiter || 'auto'), error: '' };
    } catch (error) {
      return { delimiter: ',', rows: [], error: error.message };
    }
  }, [source, data.delimiter]);

  const update = useCallback((patch) => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id
        ? { ...candidate, widgetData: { ...candidate.widgetData, ...patch } }
        : candidate
    )));
  }, [commitElements, element.id]);

  const updateSource = useCallback((next) => {
    setSource(next);
    window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(() => update({ source: next, fileError: '' }), 300);
  }, [update]);

  useEffect(() => () => window.clearTimeout(saveTimerRef.current), []);

  const loadFile = useCallback(async (file) => {
    if (!file) return;
    if (file.size > MAX_CSV_BYTES) {
      update({ fileError: 'CSV files are limited to 5 MB' });
      return;
    }
    const text = await file.text();
    updateSource(text);
    update({ fileName: file.name, fileError: '' });
  }, [update, updateSource]);

  const setViewMode = (nextMode) => {
    setMode(nextMode);
    update({ mode: nextMode });
  };

  const deleteWidget = () => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id ? { ...candidate, isDeleted: true } : candidate
    )));
  };

  const rows = parsed.rows;
  const headers = rows[0] || [];
  const bodyRows = rows.slice(1, PREVIEW_ROWS + 1);

  return (
    <div
      className="nc-data-widget nc-csv"
      style={{
        borderColor: element.style?.stroke || '#475569',
        borderWidth: element.style?.strokeWidth ?? 1,
      }}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        loadFile(event.dataTransfer.files?.[0]);
      }}
    >
      <div className="nc-widget-header nc-data-widget__header" data-nc-drag-handle="1">
        <span className="nc-data-widget__title">CSV Loader</span>
        <div className="nc-data-widget__actions">
          <select
            value={data.delimiter || 'auto'}
            onChange={(event) => update({ delimiter: event.target.value })}
            aria-label="CSV delimiter"
          >
            {DELIMITERS.map((delimiter) => (
              <option key={delimiter.id} value={delimiter.id}>{delimiter.label}</option>
            ))}
          </select>
          <button type="button" className={mode === 'table' ? 'is-active' : ''} onClick={() => setViewMode('table')}>Table</button>
          <button type="button" className={mode === 'text' ? 'is-active' : ''} onClick={() => setViewMode('text')}>Text</button>
          <button type="button" onClick={() => fileRef.current?.click()}>Open</button>
          <button type="button" className="nc-data-widget__close" onClick={deleteWidget} aria-label="Delete CSV loader">×</button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".csv,.tsv,text/csv,text/tab-separated-values"
          hidden
          onChange={(event) => loadFile(event.target.files?.[0])}
        />
      </div>
      <div className="nc-data-widget__meta">
        <span>{data.fileName || 'Paste CSV or drop a file'}</span>
        <span>{Math.max(0, rows.length - 1).toLocaleString()} rows</span>
      </div>
      <div className="nc-data-widget__body nc-csv__body">
        {mode === 'text' ? (
          <textarea
            className="nc-data-widget__source"
            value={source}
            onChange={(event) => updateSource(event.target.value)}
            placeholder={'name,score\nAda,100\nLinus,98'}
            aria-label="CSV source"
            spellCheck={false}
          />
        ) : parsed.error || data.fileError ? (
          <div className="nc-data-widget__error">{data.fileError || parsed.error}</div>
        ) : rows.length ? (
          <div className="nc-csv__table-wrap">
            <table className="nc-csv__table">
              <thead>
                <tr>
                  {headers.map((header, index) => <th key={`${header}-${index}`}>{header || `Column ${index + 1}`}</th>)}
                </tr>
              </thead>
              <tbody>
                {bodyRows.map((row, rowIndex) => (
                  <tr key={`row-${rowIndex}`}>
                    {headers.map((_, columnIndex) => <td key={`cell-${rowIndex}-${columnIndex}`}>{row[columnIndex] || ''}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
            {rows.length - 1 > PREVIEW_ROWS ? (
              <div className="nc-csv__limit">Showing first {PREVIEW_ROWS} rows</div>
            ) : null}
          </div>
        ) : (
          <button type="button" className="nc-data-widget__empty" onClick={() => setViewMode('text')}>
            Paste CSV or drop a file here
          </button>
        )}
      </div>
    </div>
  );
}

export default memo(CsvLoaderWidgetImpl);
