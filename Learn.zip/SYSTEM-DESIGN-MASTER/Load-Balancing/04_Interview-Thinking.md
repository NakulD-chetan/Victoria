# Load Balancing — Interview Thinking (Deep Understanding)

> **Permanent Recall:** Bring up LB when discussing scalability, high availability, or request flow. Don't over-explain—mention placement, algorithm choice, and health checks. Have 2–3 concise answers ready for common LB questions. Know the difference between reverse proxy, API gateway, and load balancer cold.

---

## When to Bring Up Load Balancing (and What to Say)

### The Rule: If You Drew Multiple Servers, You Need an LB

| Interview Trigger | What to Say (with reasoning) |
|-------------------|------------------------------|
| "How do you scale this?" | *"We scale horizontally by adding more backend servers. We put a load balancer in front — it distributes incoming requests across all servers using round robin (or least connections if request duration varies). This gives us N× throughput."* |
| "How do you ensure high availability?" | *"We run multiple servers behind an LB with active health checks. If Server 2 crashes, the LB detects it within 15 seconds (3 failed probes × 5s interval) and stops routing to it. Users get uninterrupted service."* |
| "How does a request flow from client to server?" | *"Client → DNS resolves to LB's IP → LB terminates SSL → LB reads the HTTP path → routes to the appropriate backend pool → picks a server using [algorithm] → forwards the request → server responds → LB forwards back to client."* |
| "How do you deploy without downtime?" | *"We do a rolling deploy behind the LB. First, we spin up new instances with the new version. LB health-checks them. Once healthy, we enable connection draining on old instances — LB stops sending NEW requests but lets in-flight requests finish. After drain timeout (30s), old instances are terminated."* |
| "Design a [URL shortener / chat / API]" | After drawing servers: *"We'd put an L7 load balancer here to distribute requests. For a stateless API like this, round robin works. For a chat system with long-lived connections, we'd use sticky sessions or consistent hashing."* |

---

## How Deep to Go — Read the Interviewer

| Depth | What to Cover | When to Use It |
|-------|---------------|----------------|
| **1-Line (Shallow)** | "LB distributes traffic across servers for HA and scale." | Quick mention; interviewer didn't ask for details |
| **3-Line (Medium)** | "We use an L7 LB for path-based routing — /api/users goes to user-service, /api/orders goes to order-service. Round robin within each pool. Active health checks every 5s." | Interviewer asks "how does the LB work?" |
| **Deep Dive** | Multi-tier LB, consistent hashing for cache, sticky sessions, GSLB, connection draining, SPOF mitigation, L4 vs L7 tradeoffs | Senior/architect roles; interviewer asks follow-up questions |

**Golden Rule:** Match the interviewer's interest. If they nod and move on after your 1-liner, don't go deeper. If they ask "tell me more about the LB," go to medium. If they keep asking, go deep.

---

## The Big Confusion: Reverse Proxy vs Load Balancer vs API Gateway

Interviewers love to ask this. Here's the definitive answer.

### What Each One Does

```
REVERSE PROXY:
  - Sits between client and server(s)
  - Hides backend server identity (client only sees proxy's IP)
  - Can do: SSL termination, caching, compression, security (WAF)
  - Can work with 1 backend server
  - Example: Nginx in front of 1 web server for SSL + caching

LOAD BALANCER:
  - Distributes traffic across MULTIPLE backend servers
  - Primary job: even distribution + failover
  - Can do: health checks, algorithm-based routing
  - Requires 2+ backend servers (otherwise nothing to "balance")
  - Example: Nginx with upstream block routing to 5 servers

API GATEWAY:
  - Entry point for API calls
  - Does everything a reverse proxy does, PLUS:
  - Authentication/authorization (validate JWT/API key)
  - Rate limiting (100 requests/minute per user)
  - Request transformation (convert XML to JSON)
  - API versioning (/v1/users, /v2/users)
  - Analytics/logging per API endpoint
  - Example: Kong, AWS API Gateway, Zuul
```

### The Relationship Between Them

```
                    ┌────────────────────────────────┐
                    │         API GATEWAY             │
                    │  (authentication, rate limit,   │
                    │   versioning, analytics)        │
                    │                                │
                    │  ┌──────────────────────────┐  │
                    │  │     LOAD BALANCER         │  │
                    │  │  (distribute to N servers) │  │
                    │  │                            │  │
                    │  │  ┌──────────────────────┐ │  │
                    │  │  │   REVERSE PROXY       │ │  │
                    │  │  │  (SSL, cache, hide    │ │  │
                    │  │  │   backend)            │ │  │
                    │  │  └──────────────────────┘ │  │
                    │  └──────────────────────────┘  │
                    └────────────────────────────────┘
```

**They are nested concepts:**
- Every LB is a reverse proxy (it hides backends)
- Every API gateway is a reverse proxy (it hides backends)
- An API gateway OFTEN includes LB functionality
- But a simple reverse proxy is NOT an API gateway (no auth, rate limiting, etc.)

### Interview One-Liner

*"A reverse proxy hides backend servers from clients — it's the base concept. A load balancer is a reverse proxy that distributes traffic across multiple servers. An API gateway adds API-specific features like auth, rate limiting, and versioning on top."*

---

## L4 vs L7 — How to Explain Concisely

### The 10-Second Answer

*"L4 operates at TCP level — it sees only IP and port, can't inspect HTTP. L7 operates at HTTP level — it can read the path, headers, cookies, and make smart routing decisions. Use L4 for raw TCP throughput; use L7 when you need path-based routing or SSL termination."*

### The 30-Second Answer (with example)

*"L4 load balancer sees a packet addressed to port 443 and forwards it to a backend — it's like a postal worker who reads the address on the envelope but never opens it. L7 opens the envelope — it reads the HTTP request, sees 'GET /api/users', and routes it to the user-service pool. L7 can also terminate SSL, add headers, and cache responses. The tradeoff is L4 is faster (less processing), L7 is smarter (more features). In practice, we often use both: L4 at the front for raw TCP distribution, L7 behind it for HTTP routing."*

### The Whiteboard Table

| | L4 | L7 |
|---|----|----|
| **Sees** | IP + port | Path, headers, cookies, body |
| **Routes by** | IP:port | /api/users → pool A |
| **SSL** | Pass-through | Terminates at LB |
| **Speed** | Faster (no HTTP parsing) | Slower (parses HTTP) |
| **Use** | TCP apps, DB, max throughput | HTTP APIs, microservices |
| **Example** | AWS NLB, HAProxy tcp | AWS ALB, Nginx, Envoy |

---

## Common LB Interview Questions — Complete Answers

### Q1: "What load balancing algorithm would you use for X?"

**Framework for answering:** Ask yourself 3 questions:
1. Are requests **stateless** (any server can handle any request)? → Round Robin
2. Do requests have **varying duration** (some quick, some slow)? → Least Connections
3. Does the same client need the **same server** (sessions, cache)? → IP Hash / Consistent Hashing / Sticky

| System | Algorithm | Full Reasoning |
|--------|-----------|----------------|
| **Stateless REST API** | Round Robin | *"Requests are independent and short-lived. All servers are identical. Round robin distributes evenly. No need for anything smarter."* |
| **Chat / WebSocket** | Least Connections or Sticky | *"WebSocket connections are long-lived (minutes/hours). Round robin ignores duration — Server 1 might have 1000 open connections while Server 3 has 10. Least connections adapts to this. If we need reconnection to same server, use sticky sessions."* |
| **Cache layer (memcached)** | Consistent Hashing | *"Cache data is distributed across servers. If we add/remove a cache server, simple hash would remap all keys — massive cache miss storm. Consistent hashing only remaps ~1/N keys, protecting us from thundering herd."* |
| **Video upload/download** | Least Connections | *"Upload can take minutes. Round robin might send 5 uploads to Server 1 while Server 2 is idle. Least connections ensures the least-loaded server gets the next request."* |
| **Mixed server sizes** | Weighted Round Robin | *"Server 1 has 8 cores, Server 2 has 2 cores. Give Server 1 weight=4, Server 2 weight=1. Server 1 gets 4× more traffic, matching its capacity."* |

### Q2: "How do you handle session state with multiple servers?"

**Complete Answer:**

*"There are two approaches. The preferred approach is to make backends **stateless** — store session data in an external store like Redis. Any server can serve any user because session is in Redis, not in server memory. This means we can use simple round robin, and if a server dies, no session data is lost.*

*The fallback is **sticky sessions** — the LB routes the same client to the same server. Cookie-based is best (LB injects a cookie with the server ID). IP hash also works but breaks behind NAT where thousands of users share one IP.*

*I'd always recommend stateless + Redis because: (1) simpler LB config, (2) server crash doesn't lose sessions, (3) horizontal scaling is trivial. Sticky sessions are a fallback when you can't externalize state."*

```
Approach 1: Stateless + Redis (PREFERRED)
  User → LB (round robin) → Any Server → reads session from Redis
  ✅ Any server can serve any user
  ✅ Server crash = no session loss
  ❌ Redis is an extra dependency

Approach 2: Sticky Sessions (FALLBACK)
  User → LB (reads cookie SERVERID=s1) → always Server 1
  ✅ No external session store needed
  ❌ Server crash = session lost for that user
  ❌ Uneven load (some servers get more "sticky" users)
```

### Q3: "What if the load balancer itself fails?"

**Complete Answer:**

*"A single LB is a single point of failure — the irony of adding reliability to backends while having one point of failure at the LB. We solve this with redundancy:*

*Option 1: **Active-passive pair.** Two LBs share a virtual IP (VIP). The active one handles all traffic. The passive monitors via heartbeat. If active dies, passive takes over the VIP using gratuitous ARP — clients don't notice because the IP doesn't change. Tools like keepalived on Linux do this.*

*Option 2: **Active-active cluster.** Multiple LBs all handle traffic. DNS returns multiple IPs, or we use anycast (same IP, BGP routes to nearest). If one LB dies, the others absorb its traffic. This is how cloud LBs work — AWS ALB runs across multiple AZs.*

*In practice, we'd use a cloud-managed LB (ALB, NLB) which is highly available by design — AWS runs it across multiple AZs and handles failover for us."*

### Q4: "Explain the difference between reverse proxy and load balancer"

**Complete Answer:**

*"A reverse proxy sits between clients and backend servers — clients send requests to the proxy, and the proxy forwards them to the backend. The client never talks to the backend directly. It provides security (hides server IPs), SSL termination, caching, and compression.*

*A load balancer is a reverse proxy with a specific additional job: distributing traffic across **multiple** backend servers using algorithms like round robin or least connections, plus health checks to avoid sending traffic to dead servers.*

*The key difference: you can have a reverse proxy in front of ONE server (for SSL, caching), but a load balancer only makes sense with 2+ servers. In practice, tools like Nginx and HAProxy do both — they're reverse proxies that can also load-balance. So the terms often overlap.*

*Think of it this way: all load balancers are reverse proxies, but not all reverse proxies are load balancers."*

### Q5: "Why would you use L7 instead of L4?"

**Complete Answer:**

*"L4 operates at the TCP level — it sees only IP addresses and port numbers. It can't read HTTP paths, headers, or cookies. L7 operates at the HTTP level — it can read everything in the request.*

*I'd use L7 when I need to route different URL paths to different backend services — for example, /api/users to the user service and /api/orders to the order service. L7 can also terminate SSL at the LB (offloading crypto from backends), add headers like X-Forwarded-For, and even cache responses.*

*I'd use L4 when I need maximum throughput — since L4 doesn't parse HTTP, it's faster. Also for non-HTTP protocols like database connections, raw TCP, or gaming servers where L7 doesn't apply.*

*In many production setups, we use both: L4 at the outer edge for raw TCP distribution, and L7 behind it for HTTP-aware routing."*

### Q6: "How do health checks work?"

**Complete Answer:**

*"Health checks let the LB know which backend servers are alive and able to serve requests.*

*Active health checks: The LB periodically sends a probe request — like 'GET /health' every 5 seconds. If the server responds with 200 OK, it's healthy. If it fails to respond 3 times in a row (the unhealthy threshold), the LB removes it from the pool. Once it starts responding again (2 consecutive successes = healthy threshold), the LB adds it back.*

*Passive health checks: The LB watches real traffic. If real user requests to a server keep failing (timeouts, 5xx errors), the LB marks it unhealthy. No extra probe traffic, but slower to detect.*

*Best practice: Use both. Active catches server crashes quickly. Passive catches subtle application issues. The health endpoint should be lightweight — don't make it query the database on every probe, or a slow DB will make all servers look unhealthy."*

---

## LB Considerations for Different System Types

| System | LB Type | Algorithm | Key Consideration | Why |
|--------|---------|-----------|-------------------|-----|
| **URL Shortener** | L7, ALB | Round Robin | Stateless reads; simple distribution | Reads are independent, fast. No session needed. |
| **Chat (WhatsApp)** | L7 | Sticky / Consistent Hash | WebSocket, long-lived connections | User A connected to Server 1 via WebSocket — must stay there for the session. Reconnect needs same server for message history. |
| **Video Streaming (Netflix)** | L4 + CDN | Least Connections | CDN for edge delivery; LB for origin | CDN handles most traffic. LB at origin uses least-conn because video encoding/transcoding takes variable time. |
| **Twitter Feed** | L7 | Round Robin / Least Conn | Path routing (tweet vs timeline) | /compose goes to write service, /feed goes to read service. Read is heavier → least-conn within read pool. |
| **Uber/Lyft** | GSLB + L7 | Geo + Sticky | Real-time location, geo-routing | GSLB routes to nearest region. Within region, sticky session for real-time driver-rider matching. |
| **E-commerce** | L7 | Path routing + Sticky | Cart session, checkout flow | /search is stateless (RR). /cart needs sticky (user's cart is in progress). /checkout needs HTTPS + validation. |
| **Database Reads** | L4 | Round Robin / Least Conn | Read replicas, TCP | L4 because it's raw PostgreSQL/MySQL TCP protocol, not HTTP. Least-conn if queries vary in duration. |
| **Kafka/MQ** | None (usually) | N/A | Clients connect to brokers directly | Kafka clients discover broker topology via metadata API. LB would break partition assignment. |

---

## Red Flags to Avoid in Interviews

| What NOT to Say | Why It's Wrong | What to Say Instead |
|-----------------|----------------|---------------------|
| "We don't need a load balancer" | Any scaled system needs traffic distribution | "We'd add an LB to distribute traffic and ensure HA" |
| "Load balancer and reverse proxy are completely different" | LB IS a reverse proxy (with distribution) | "An LB is a reverse proxy that also distributes traffic across servers" |
| "We use round robin for everything" | Shows you don't know other algorithms | "Round robin for stateless APIs; least connections for variable workloads; consistent hashing for caches" |
| "One load balancer is enough" | Single point of failure | "We'd run an LB pair (active-passive) or use cloud-managed HA LB" |
| "L4 and L7 are the same" | Fundamentally different capabilities | "L4 sees IP/port only; L7 sees HTTP content. Different use cases." |
| "Sticky sessions are fine for everything" | Creates scaling bottlenecks | "Prefer stateless + Redis; use sticky only when you can't externalize state" |

---

## Interview Flow: How to Naturally Weave LB Into Your Design

```
Step 1: Draw your system components
  "We have a web frontend, API backend, and database"

Step 2: Immediately add LB when you draw multiple servers
  "Since we need multiple API servers for scale,
   we put an L7 load balancer here" [draw LB]

Step 3: Specify algorithm with reasoning
  "Round robin works because our API is stateless"

Step 4: Mention health checks
  "Active health checks every 5s with 3-failure threshold"

Step 5: Address SPOF (if senior role)
  "We'd use AWS ALB which is inherently HA across AZs"

Step 6: Go deeper ONLY if asked
  Interviewer: "What if we need session affinity?"
  You: "We'd use cookie-based sticky sessions, or better, 
        externalize session to Redis and keep backends stateless"
```

---

## Quick Memory Card

```
WHEN:          Scale, HA, request flow, deploy, multiple servers
DEPTH:         1-line → medium → deep; match interviewer's interest
L4 vs L7:      "L4 = IP/port; L7 = HTTP path/headers. L4 for speed, L7 for smarts."
REVERSE PROXY: "Hides backend. LB is a reverse proxy that distributes traffic."
API GATEWAY:   "Reverse proxy + auth + rate limit + versioning"
ALGORITHM:     Stateless→RR, varying→LC, cache→CH, sessions→sticky
SESSION:       Prefer stateless + Redis. Sticky as fallback.
SPOF:          Active-passive pair or cloud-managed HA
NATURAL:       Draw servers → add LB → specify algorithm → mention health → address SPOF
```

---

**Next:** [[05_Common-Mistakes]]
