import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Sidebar from './components/Sidebar';
import MarkdownViewer from './components/MarkdownViewer';
import ChatPanel from './components/ChatPanel';
import ChatInput from './components/ChatInput';
import WelcomeScreen, { COLORS } from './components/WelcomeScreen';
import UploadModal from './components/UploadModal';
import AuthGate, { getAuthHeaders } from './components/AuthGate';
import ShareDialog from './components/ShareDialog';
import ShareView from './components/ShareView';
import { ContentAd, SidebarAd } from './components/AdBanner';
import PremiumModal from './components/PremiumModal';
import ReferralPanel from './components/ReferralPanel';
import { dbService } from './firebase';
import AppNavbar from './components/shared/AppNavbar';
import AlgorithmCatalog from './components/algorithms/AlgorithmCatalog';
import AlgorithmDetailView from './components/algorithms/AlgorithmDetailView';
import ProblemsList from './components/problems/ProblemsList';
import PlaygroundView from './components/problems/PlaygroundView';
import PracticeHub from './components/problems/PracticeHub';
import EditorView from './components/editor/EditorView';
import NotesApp from './components/notes/NotesApp';
import CanvasApp from './components/canvas/CanvasApp';
import NewCanvasApp from './components/new-canvas/NewCanvasApp';
import SharedNoteView from './components/notes/SharedNoteView';
import InviteAccept from './routes/InviteAccept';
import { useVaultStore } from './stores/vault-store';
import './components/canvas/canvas.css';
import './components/notes/shared-note.css';
function getShareToken() {
  const params = new URLSearchParams(window.location.search);
  return params.get('share');
}

function AlgorithmView({ path, theme, onThemeToggle }) {
  const slug = path.replace('/algorithms/', '').replace('/algorithms', '');
  if (slug && slug !== '/') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
        <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />
        <div style={{ flex: 1, overflowY: 'auto' }}>
          <AlgorithmDetailView slug={slug} />
        </div>
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <AlgorithmCatalog />
      </div>
    </div>
  );
}

function SystemDesignView({ path, theme, onThemeToggle }) {
  const slug = path.replace('/systemdesign/', '').replace('/systemdesign', '');
  if (slug && slug !== '/') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
        <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />
        <PlaygroundView problemId={slug} />
      </div>
    );
  }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        <ProblemsList />
      </div>
    </div>
  );
}

function CanvasView({ path, theme, onThemeToggle }) {
  return <CanvasApp path={path} theme={theme} onThemeToggle={onThemeToggle} />;
}

function NewCanvasView({ path, theme, onThemeToggle }) {
  return <NewCanvasApp path={path} theme={theme} onThemeToggle={onThemeToggle} />;
}

export default function App() {
  const [path, setPath] = useState(window.location.pathname);
  const [theme, setTheme] = useState(() => localStorage.getItem('md-theme') || 'dark');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    const handler = () => setPath(window.location.pathname);
    window.addEventListener('popstate', handler);
    return () => window.removeEventListener('popstate', handler);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      localStorage.setItem('md-theme', next);
      document.documentElement.setAttribute('data-theme', next);
      return next;
    });
  }, []);

  const shareToken = getShareToken();
  if (shareToken) return <ShareView shareToken={shareToken} />;
  if (path.startsWith('/invite/')) return <InviteAccept />;
  if (path.startsWith('/shared/')) {
    const shareId = path.replace('/shared/', '');
    return <SharedNoteView shareId={shareId} />;
  }
  if (path === '/practice' || path === '/practice/') return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <AppNavbar currentPath={path} theme={theme} onThemeToggle={toggleTheme} />
      <div style={{ flex: 1, overflowY: 'auto' }}><PracticeHub /></div>
    </div>
  );
  if (path.startsWith('/algorithms')) return <AlgorithmView path={path} theme={theme} onThemeToggle={toggleTheme} />;
  if (path.startsWith('/systemdesign')) return <SystemDesignView path={path} theme={theme} onThemeToggle={toggleTheme} />;
  if (path.startsWith('/code')) return <EditorView path={path} theme={theme} onThemeToggle={toggleTheme} />;
  if (path.startsWith('/new-canvas')) return <NewCanvasView path={path} theme={theme} onThemeToggle={toggleTheme} />;
  if (path.startsWith('/canvas')) return <CanvasView path={path} theme={theme} onThemeToggle={toggleTheme} />;
  if (path.startsWith('/notes')) return <NotesApp theme={theme} onThemeToggle={toggleTheme} />;
  return <AuthGate>{(user) => <InkDropApp user={user} />}</AuthGate>;
}

function InkDropApp({ user }) {
  const [folders, setFolders] = useState([]);
  const [foldersLoading, setFoldersLoading] = useState(true);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [fileLoading, setFileLoading] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatLoading, setChatLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState([]);
  const [chatHistoryLoading, setChatHistoryLoading] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [shareFolder, setShareFolder] = useState(null);
  const [theme, setTheme] = useState(() => localStorage.getItem('md-theme') || 'dark');
  const [timeline, setTimeline] = useState(() => {
    try { return JSON.parse(localStorage.getItem('md-timeline') || '[]'); }
    catch { return []; }
  });

  // Premium state
  const [isPremium, setIsPremium] = useState(false);
  const [premiumModalOpen, setPremiumModalOpen] = useState(false);
  const [referralOpen, setReferralOpen] = useState(false);

  // Vault registry — hydrate from cloud once per session so the list of
  // vaults is shared across devices.
  const vaultsCloudLoaded = useVaultStore((s) => s.cloudLoaded);
  const loadVaultsFromCloud = useVaultStore((s) => s.loadFromCloud);
  useEffect(() => {
    if (!vaultsCloudLoaded) loadVaultsFromCloud();
  }, [vaultsCloudLoaded, loadVaultsFromCloud]);

  // Load premium status from Firebase
  useEffect(() => {
    if (!user?.id) return;
    const unsubscribe = dbService.onPremiumChange(user.id, (data) => {
      const active = data?.active && (!data.expiresAt || new Date(data.expiresAt) > new Date());
      setIsPremium(active || false);
    });
    return () => unsubscribe();
  }, [user?.id]);

  // Save user profile to Firebase on login
  useEffect(() => {
    if (!user?.id || !user?.provider) return;
    dbService.saveUserProfile(user.id, {
      name: user.name,
      email: user.email || null,
      photoURL: user.photoURL || null,
      provider: user.provider,
      createdAt: new Date().toISOString(),
    }).catch(() => {});
  }, [user?.id]);

  useEffect(() => {
    const handler = () => setPremiumModalOpen(true);
    window.addEventListener('open-premium', handler);
    return () => window.removeEventListener('open-premium', handler);
  }, []);

  useEffect(() => {
    const handler = (e) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'P') {
        e.preventDefault();
        setIsPremium(prev => {
          const next = !prev;
          console.log(`[DEV] Premium ${next ? 'ENABLED' : 'DISABLED'}`);
          return next;
        });
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('md-theme', theme);
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('md-timeline', JSON.stringify(timeline.slice(0, 50)));
  }, [timeline]);

  const addTimelineEvent = useCallback((type, detail) => {
    setTimeline(prev => [{ id: Date.now(), type, detail, time: new Date().toISOString() }, ...prev].slice(0, 50));
  }, []);

  const fetchFolders = useCallback(async () => {
    setFoldersLoading(true);
    try {
      const res = await fetch('/api/folders', { headers: getAuthHeaders() });
      const data = await res.json();
      if (!data.error) setFolders(data);
    } catch (err) { console.error('Failed to fetch folders:', err); }
    finally { setFoldersLoading(false); }
  }, []);

  useEffect(() => { fetchFolders(); }, [fetchFolders]);

  const folderColorMap = useMemo(() => {
    const map = {};
    folders.forEach((f, i) => {
      map[f.path || f.name] = COLORS[i % COLORS.length];
    });
    return map;
  }, [folders]);

  useEffect(() => {
    function applyRoute() {
      const parts = window.location.pathname.replace(/^\/+/, '').split('/').filter(Boolean).map(decodeURIComponent);
      if (parts.length === 0) {
        setSelectedFolder(null); setSelectedFile(null);
        setFileData(null); setSidebarOpen(false);
        return;
      }
      const last = parts[parts.length - 1];
      const isFile = /\.(md|markdown|txt|mdx)$/i.test(last);
      if (isFile && parts.length >= 2) {
        const folder = parts.slice(0, -1).join('/');
        const file = last;
        setSelectedFolder(folder);
        setSidebarOpen(true);
        setFileLoading(true);
        setChatMessages([]);
        fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(file)}`, { headers: getAuthHeaders() })
          .then(r => r.json())
          .then(data => { setFileData(data); setSelectedFile(file); })
          .catch(() => { setFileData(null); })
          .finally(() => setFileLoading(false));
      } else {
        const folder = parts.join('/');
        setSelectedFolder(folder);
        setSidebarOpen(true);
      }
    }
    applyRoute();
    window.addEventListener('popstate', applyRoute);
    return () => window.removeEventListener('popstate', applyRoute);
  }, []);

  const loadChatHistory = useCallback(async (folder, filename) => {
    if (!folder || !filename) return;
    setChatHistoryLoading(true);
    try {
      const res = await fetch(`/api/chat/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}/history`, { headers: getAuthHeaders() });
      const data = await res.json();
      setChatMessages(data.messages || []);
    } catch { setChatMessages([]); }
    finally { setChatHistoryLoading(false); }
  }, []);

  const selectFile = useCallback(async (folder, filename) => {
    setSelectedFolder(folder);
    setSelectedFile(filename);
    setFileLoading(true);
    setChatMessages([]);
    setSidebarOpen(true);
    const folderUrl = folder.split('/').map(encodeURIComponent).join('/');
    const url = `/${folderUrl}/${encodeURIComponent(filename)}`;
    if (window.location.pathname !== url) window.history.pushState(null, '', url);
    try {
      const res = await fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}`, { headers: getAuthHeaders() });
      setFileData(await res.json());
      addTimelineEvent('open', `Opened ${filename}`);
      loadChatHistory(folder, filename);
      if (user?.id) dbService.trackAnalytics(user.id, { type: 'file_view', folder, filename }).catch(() => {});
    } catch (err) { console.error('Failed to load file:', err); setFileData(null); }
    finally { setFileLoading(false); }
  }, [addTimelineEvent, loadChatHistory, user?.id]);

  const handleDeleteFile = useCallback(async (folder, filename) => {
    try {
      await fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}`, { method: 'DELETE', headers: getAuthHeaders() });
      if (selectedFile === filename && selectedFolder === folder) { setFileData(null); setSelectedFile(null); }
      addTimelineEvent('delete', `Deleted ${filename}`);
      fetchFolders();
    } catch (err) { console.error('Delete failed:', err); }
  }, [selectedFile, selectedFolder, fetchFolders, addTimelineEvent]);

  const handleDeleteFolder = useCallback(async (folderPath) => {
    try {
      await fetch(`/api/folders/${encodeURIComponent(folderPath)}`, { method: 'DELETE', headers: getAuthHeaders() });
      if (selectedFolder === folderPath || selectedFolder?.startsWith(folderPath + '/')) {
        setFileData(null); setSelectedFile(null); setSelectedFolder(null);
      }
      addTimelineEvent('delete', `Deleted folder ${folderPath.split('/').pop()}`);
      fetchFolders();
    } catch (err) { console.error('Delete folder failed:', err); }
  }, [selectedFolder, fetchFolders, addTimelineEvent]);

  const handleCreateFolder = useCallback(async (name) => {
    try {
      await fetch('/api/folders', { method: 'POST', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }, body: JSON.stringify({ name }) });
      addTimelineEvent('create', `Created folder ${name}`);
      fetchFolders();
    } catch (err) { console.error('Create folder failed:', err); }
  }, [fetchFolders, addTimelineEvent]);

  const handleRenameFolder = useCallback(async (oldPath, newName) => {
    try {
      const res = await fetch(`/api/folders/${encodeURIComponent(oldPath)}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }, body: JSON.stringify({ newName }) });
      const data = await res.json();
      if (selectedFolder === oldPath && data.newName) setSelectedFolder(data.newName);
      addTimelineEvent('create', `Renamed ${oldPath.split('/').pop()} → ${newName}`);
      fetchFolders();
    } catch (err) { console.error('Rename folder failed:', err); }
  }, [selectedFolder, fetchFolders, addTimelineEvent]);

  const handleMoveFile = useCallback(async (folder, filename, targetFolder) => {
    try {
      await fetch(`/api/files/${encodeURIComponent(folder)}/${encodeURIComponent(filename)}/move`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }, body: JSON.stringify({ targetFolder }),
      });
      addTimelineEvent('create', `Moved ${filename} → ${targetFolder}`);
      fetchFolders();
    } catch (err) { console.error('Move failed:', err); }
  }, [fetchFolders, addTimelineEvent]);

  const handleNestFolder = useCallback(async (srcFolder, targetFolder) => {
    if (srcFolder === targetFolder) return;
    try {
      const res = await fetch(`/api/folders/${encodeURIComponent(srcFolder)}/nest`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }, body: JSON.stringify({ targetFolder }),
      });
      const data = await res.json();
      if (data.error) { console.error('Nest failed:', data.error); return; }
      if (selectedFolder === srcFolder) setSelectedFolder(data.newPath || targetFolder);
      addTimelineEvent('create', `Nested ${srcFolder} → ${targetFolder}`);
      fetchFolders();
    } catch (err) { console.error('Nest folder failed:', err); }
  }, [selectedFolder, fetchFolders, addTimelineEvent]);

  const handleDeleteAll = useCallback(async () => {
    try {
      for (const f of folders) {
        await fetch(`/api/folders/${encodeURIComponent(f.path || f.name)}`, { method: 'DELETE', headers: getAuthHeaders() });
      }
      setFileData(null); setSelectedFile(null); setSelectedFolder(null);
      addTimelineEvent('delete', `Deleted all folders`);
      fetchFolders();
    } catch (err) { console.error('Delete all failed:', err); }
  }, [folders, fetchFolders, addTimelineEvent]);

  const handleDeleteMultiple = useCallback(async (paths) => {
    try {
      for (const p of paths) {
        await fetch(`/api/folders/${encodeURIComponent(p)}`, { method: 'DELETE', headers: getAuthHeaders() });
      }
      if (paths.includes(selectedFolder)) {
        setFileData(null); setSelectedFile(null); setSelectedFolder(null);
      }
      addTimelineEvent('delete', `Deleted ${paths.length} folders`);
      fetchFolders();
    } catch (err) { console.error('Delete multiple failed:', err); }
  }, [selectedFolder, fetchFolders, addTimelineEvent]);

  const handleMoveToRoot = useCallback(async (folderPath) => {
    if (!folderPath.includes('/')) return;
    const folderName = folderPath.split('/').pop();
    try {
      const res = await fetch(`/api/folders/${encodeURIComponent(folderPath)}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() }, body: JSON.stringify({ newName: folderName }),
      });
      const data = await res.json();
      if (data.error) { console.error('Move to root failed:', data.error); return; }
      if (selectedFolder === folderPath) setSelectedFolder(folderName);
      addTimelineEvent('create', `Moved ${folderName} to root`);
      fetchFolders();
    } catch (err) { console.error('Move to root failed:', err); }
  }, [selectedFolder, fetchFolders, addTimelineEvent]);

  const [zoomingFolder, setZoomingFolder] = useState(null);
  const [heroAnim, setHeroAnim] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(null);

  const [treeExpandedFolder, setTreeExpandedFolder] = useState(null);
  const [isDrawMode, setIsDrawMode] = useState(false);

  const handleUploadFiles = useCallback(async (files, targetFolder) => {
    const grouped = {};
    const zipFiles = [];
    for (const { file, folder } of files) {
      if (file.name.toLowerCase().endsWith('.zip')) {
        zipFiles.push({ file, folder: targetFolder || folder });
      } else {
        const key = targetFolder || folder;
        if (!grouped[key]) grouped[key] = [];
        grouped[key].push(file);
      }
    }

    const totalFiles = files.length;
    let uploaded = 0;
    setUploadProgress({ total: totalFiles, done: 0, active: true });

    const BATCH = 40;
    for (const [folder, fileList] of Object.entries(grouped)) {
      for (let i = 0; i < fileList.length; i += BATCH) {
        const chunk = fileList.slice(i, i + BATCH);
        const formData = new FormData();
        formData.append('folder', folder);
        for (const f of chunk) formData.append('files', f);
        try {
          await fetch('/api/upload', { method: 'POST', headers: getAuthHeaders(), body: formData });
        } catch (err) { console.error('Upload batch failed:', err); }
        uploaded += chunk.length;
        setUploadProgress({ total: totalFiles, done: uploaded, active: true });
      }
    }
    for (const { file, folder } of zipFiles) {
      const formData = new FormData();
      formData.append('folder', folder);
      formData.append('file', file);
      try {
        await fetch('/api/upload-zip', { method: 'POST', headers: getAuthHeaders(), body: formData });
      } catch (err) { console.error('ZIP upload failed:', err); }
      uploaded += 1;
      setUploadProgress({ total: totalFiles, done: uploaded, active: true });
    }

    addTimelineEvent('upload', `Uploaded ${totalFiles} files`);
    if (user?.id) {
      dbService.updateUsageStats(user.id, { totalFiles: folders.reduce((a, f) => a + f.fileCount, 0) + totalFiles }).catch(() => {});
    }
    setUploadProgress({ total: totalFiles, done: totalFiles, active: false });
    setTimeout(() => setUploadProgress(null), 2000);
    fetchFolders();
  }, [fetchFolders, addTimelineEvent, user?.id, folders]);

  const handleUploadComplete = useCallback(() => {
    setUploadOpen(false);
    addTimelineEvent('upload', 'Uploaded files');
    fetchFolders();
  }, [fetchFolders, addTimelineEvent]);

  const toggleTheme = useCallback(() => {
    const next = theme === 'dark' ? 'light' : 'dark';
    if (document.startViewTransition) {
      document.startViewTransition(() => { setTheme(next); });
    } else {
      setTheme(next);
    }
  }, [theme]);

  const handleChatSend = useCallback(async (question) => {
    if (!question || chatLoading || !isPremium) return;
    setChatOpen(true);
    setChatMessages(prev => [...prev, { role: 'user', content: question }]);
    setChatLoading(true);
    addTimelineEvent('chat', `Asked: "${question.slice(0, 60)}..."`);
    try {
      const res = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ question, folder: selectedFolder, filename: selectedFile }),
      });
      const data = await res.json();
      setChatMessages(prev => [...prev, { role: 'assistant', content: data.answer || 'No answer found.', sources: data.sources || [] }]);
    } catch {
      setChatMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, something went wrong.', sources: [] }]);
    } finally { setChatLoading(false); }
  }, [chatLoading, isPremium, selectedFolder, selectedFile, addTimelineEvent]);

  const handleClearChatHistory = useCallback(async () => {
    if (!selectedFolder || !selectedFile) return;
    try {
      await fetch(`/api/chat/${encodeURIComponent(selectedFolder)}/${encodeURIComponent(selectedFile)}/history`, { method: 'DELETE', headers: getAuthHeaders() });
      setChatMessages([]);
    } catch (err) { console.error('Clear chat failed:', err); }
  }, [selectedFolder, selectedFile]);

  const handleWelcomeFolderClick = useCallback((folderPath) => {
    if (zoomingFolder) return;
    setSelectedFolder(folderPath);
    setSidebarOpen(true);
    const url = `/${folderPath.split('/').map(encodeURIComponent).join('/')}`;
    if (window.location.pathname !== url) window.history.pushState(null, '', url);
  }, [zoomingFolder]);

  const heroRef = useRef(null);

  const handleWelcomeFileClick = useCallback((folderName, fileName, sourceRect, label, color) => {
    const contentEl = document.querySelector('.content__scroll');
    const targetRect = contentEl?.getBoundingClientRect();

    if (sourceRect && targetRect) {
      setHeroAnim({
        sourceRect: { top: sourceRect.top, left: sourceRect.left, width: sourceRect.width, height: sourceRect.height },
        targetRect: { top: targetRect.top + 16, left: targetRect.left + 16, width: targetRect.width - 32, height: 48 },
        expandRect: { top: targetRect.top, left: targetRect.left, width: targetRect.width, height: targetRect.height },
        label: label || fileName,
        color: color || '#6965db',
        phase: 'fly',
      });
    }

    setTimeout(() => {
      setHeroAnim(prev => prev ? { ...prev, phase: 'expand' } : null);
      selectFile(folderName, fileName);
    }, 500);
  }, [selectFile]);

  const goHome = useCallback(() => {
    setFileData(null);
    setSelectedFile(null);
    setSelectedFolder(null);
    setChatOpen(false);
    setSidebarOpen(false);
    setHeroAnim(null);
    if (window.location.pathname !== '/') window.history.pushState(null, '', '/');
  }, []);

  const handleTreeExpand = useCallback((folder) => {
    setTreeExpandedFolder(folder);
  }, []);

  useEffect(() => {
    if (!heroAnim) return;
    const el = heroRef.current;
    if (!el) return;

    if (heroAnim.phase === 'fly') {
      requestAnimationFrame(() => {
        el.classList.add('hero-card--flying');
      });
    } else if (heroAnim.phase === 'expand') {
      el.classList.remove('hero-card--flying');
      requestAnimationFrame(() => {
        el.classList.add('hero-card--expanding');
      });
    }
  }, [heroAnim]);

  useEffect(() => {
    if (!heroAnim || heroAnim.phase !== 'expand') return;
    if (!fileData) return;
    setHeroAnim(prev => prev ? { ...prev, phase: 'done' } : null);
    const t = setTimeout(() => {
      setHeroAnim(null);
    }, 400);
    return () => clearTimeout(t);
  }, [fileData, heroAnim]);

  return (
    <div className="inkdrop-wrapper" style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <AppNavbar currentPath={window.location.pathname} theme={theme} onThemeToggle={toggleTheme} />
      <div className="app" style={{ flex: 1, minHeight: 0 }}>
      {heroAnim && (
        <div className="hero-overlay">
          <div
            ref={heroRef}
            className={`hero-card ${heroAnim.phase === 'done' ? 'hero-card--done' : ''}`}
            style={{
              '--src-top': `${heroAnim.sourceRect.top}px`,
              '--src-left': `${heroAnim.sourceRect.left}px`,
              '--src-w': `${heroAnim.sourceRect.width}px`,
              '--src-h': `${heroAnim.sourceRect.height}px`,
              '--dst-top': `${heroAnim.targetRect.top}px`,
              '--dst-left': `${heroAnim.targetRect.left}px`,
              '--dst-w': `${heroAnim.targetRect.width}px`,
              '--dst-h': `${heroAnim.targetRect.height}px`,
              '--exp-top': `${heroAnim.expandRect?.top || 0}px`,
              '--exp-left': `${heroAnim.expandRect?.left || 0}px`,
              '--exp-w': `${heroAnim.expandRect?.width || 0}px`,
              '--exp-h': `${heroAnim.expandRect?.height || 0}px`,
              '--hero-color': heroAnim.color,
            }}
          >
            <div className="hero-card__header">
              <svg className="hero-card__icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
                <line x1="16" y1="13" x2="8" y2="13" />
                <line x1="16" y1="17" x2="8" y2="17" />
              </svg>
              <span className="hero-card__label">{heroAnim.label}</span>
            </div>
            <div className="hero-card__skeleton">
              <div className="skel-topbar">
                <div className="skeleton-line" style={{ width: '120px', height: 8 }} />
                <div style={{ flex: 1 }} />
                <div className="skeleton-line" style={{ width: '50px', height: 8 }} />
                <div className="skeleton-line" style={{ width: '50px', height: 8 }} />
              </div>
              <div className="skeleton-line skeleton-title" />
              <div className="skeleton-line skeleton-w80" />
              <div className="skeleton-line skeleton-w65" />
              <div className="skeleton-line" />
              <div className="skeleton-line skeleton-w50" />
              <div className="skel-code">
                <div className="skeleton-line skeleton-w65" />
                <div className="skeleton-line skeleton-w80" />
                <div className="skeleton-line skeleton-w40" />
                <div className="skeleton-line skeleton-w50" />
              </div>
              <div className="skeleton-line skeleton-w80" />
              <div className="skeleton-line skeleton-w65" />
              <div className="skeleton-line" />
              <div className="skeleton-line skeleton-w40" />
            </div>
          </div>
        </div>
      )}

      <Sidebar
        folders={folders}
        foldersLoading={foldersLoading}
        selectedFolder={selectedFolder}
        selectedFile={selectedFile}
        onSelectFile={selectFile}
        onDeleteFile={handleDeleteFile}
        onDeleteFolder={handleDeleteFolder}
        onCreateFolder={handleCreateFolder}
        onRenameFolder={handleRenameFolder}
        onUpload={() => setUploadOpen(true)}
        onUploadFiles={handleUploadFiles}
        onMoveFile={handleMoveFile}
        onNestFolder={handleNestFolder}
        onDeleteAll={handleDeleteAll}
        onDeleteMultiple={handleDeleteMultiple}
        onMoveToRoot={handleMoveToRoot}
        uploadProgress={uploadProgress}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        folderColors={folderColorMap}
        onShare={(path, name) => setShareFolder({ path, name })}
        theme={theme}
        onThemeToggle={toggleTheme}
        onChatToggle={() => setChatOpen(prev => !prev)}
        chatOpen={chatOpen}
        onHome={goHome}
        user={user}
        isPremium={isPremium}
        onOpenPremium={() => setPremiumModalOpen(true)}
        onOpenReferral={() => setReferralOpen(true)}
      />

      {sidebarOpen && <div className="overlay" onClick={() => setSidebarOpen(false)} />}

      <div className="main-area">
        <button className="mobile-menu-btn" onClick={() => setSidebarOpen(true)}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>

        <ContentAd isPremium={isPremium} />

        <div className="content-wrapper">
          <div className={`content ${chatOpen ? 'content--with-chat' : ''}`}>
            <div className="content__scroll">
              <div className={`view-layer view-layer--welcome ${fileData || fileLoading ? 'view-layer--hidden' : ''}`}>
                <WelcomeScreen
                  folders={folders}
                  onFolderClick={handleWelcomeFolderClick}
                  onFileClick={handleWelcomeFileClick}
                  user={user}
                  onTreeStateChange={handleTreeExpand}
                />
              </div>

              {fileData && (
                <MarkdownViewer fileData={fileData} folder={selectedFolder} filename={selectedFile} userId={user?.id} theme={theme} onViewModeChange={(m) => setIsDrawMode(m === 'draw')} />
              )}
            </div>

            {isPremium ? (
              <ChatInput onSend={handleChatSend} isLoading={chatLoading} folder={selectedFolder} filename={selectedFile} />
            ) : (
              <div className="chat-premium-gate" onClick={() => setPremiumModalOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
                </svg>
                <span>Unlock AI Chat with Premium</span>
              </div>
            )}
          </div>

          {chatOpen && isPremium && (
            <ChatPanel
              messages={chatMessages}
              loading={chatLoading}
              historyLoading={chatHistoryLoading}
              folder={selectedFolder}
              filename={selectedFile}
              onSend={handleChatSend}
              onClose={() => setChatOpen(false)}
              onClearHistory={handleClearChatHistory}
            />
          )}
        </div>
      </div>

      {uploadOpen && (
        <UploadModal folders={folders} onClose={() => setUploadOpen(false)} onComplete={handleUploadComplete} userId={user?.id} />
      )}

      {shareFolder && (
        <ShareDialog
          folderPath={shareFolder.path}
          folderName={shareFolder.name}
          onClose={() => setShareFolder(null)}
        />
      )}

      {premiumModalOpen && (
        <PremiumModal
          user={user}
          onClose={() => setPremiumModalOpen(false)}
          onUpgrade={(data) => setIsPremium(data.active)}
        />
      )}

      {referralOpen && (
        <ReferralPanel
          user={user}
          onClose={() => setReferralOpen(false)}
        />
      )}
      </div>
    </div>
  );
}
