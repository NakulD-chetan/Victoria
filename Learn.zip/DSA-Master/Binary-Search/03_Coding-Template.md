# Binary Search — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.** Python + C++ + Rust for FAANG interviews.

---

## Template 1: Standard Binary Search (Exact Match)

### Python

```python
def binary_search(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = lo + (hi - lo) // 2  # Avoid overflow
        if arr[mid] == target:
            return mid
        if arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1
```

### C++

```cpp
int binarySearch(vector<int>& arr, int target) {
    int lo = 0, hi = arr.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;  // Avoid overflow
        if (arr[mid] == target) return mid;
        if (arr[mid] < target)
            lo = mid + 1;
        else
            hi = mid - 1;
    }
    return -1;
}
```

### Rust

```rust
/// .binary_search(&target) on sorted slice returns Result<usize, usize>.
/// Ok(i) = found at i; Err(i) = insert position.
fn binary_search(arr: &[i32], target: i32) -> Option<usize> {
    arr.binary_search(&target).ok()  // Built-in! O(log n)
}

// Manual implementation with checked arithmetic:
fn binary_search_manual(arr: &[i32], target: i32) -> Option<usize> {
    let mut lo = 0usize;
    let mut hi = arr.len().saturating_sub(1);

    while lo <= hi {
        let mid = lo + (hi - lo) / 2;  // Checked: no overflow with usize
        match arr[mid].cmp(&target) {
            std::cmp::Ordering::Equal => return Some(mid),
            std::cmp::Ordering::Less => lo = mid + 1,
            std::cmp::Ordering::Greater => hi = mid.saturating_sub(1),
        }
    }
    None
}
```

**Rust Performance Note:** `arr.binary_search(&target)` uses the same algorithm as manual. Range types and `saturating_sub` avoid overflow. Returns `Option<usize>` instead of -1.

---

## Template 2: Lower Bound (bisect_left) — First ≥ target

### Python

```python
def bisect_left(arr, target):
    lo, hi = 0, len(arr)  # hi = len(arr) so we can return "insert position"
    while lo < hi:
        mid = lo + (hi - lo) // 2
        if arr[mid] < target:
            lo = mid + 1
        else:
            hi = mid
    return lo
```

### C++

```cpp
int bisectLeft(vector<int>& arr, int target) {
    int lo = 0, hi = arr.size();
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] < target)
            lo = mid + 1;
        else
            hi = mid;
    }
    return lo;
}
```

### Rust

```rust
/// .partition_point(|x| x < target) — bisect_left equivalent. First index where pred is false.
fn bisect_left(arr: &[i32], target: i32) -> usize {
    arr.partition_point(|&x| x < target)
}

// Manual:
fn bisect_left_manual(arr: &[i32], target: i32) -> usize {
    let mut lo = 0usize;
    let mut hi = arr.len();
    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        if arr[mid] < target {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    lo
}
```

**Rust Note:** `partition_point(pred)` returns first index where `pred` is false. `|&x| x < target` = "elements strictly less than target". Same as Python's `bisect_left`.

---

## Template 3: Upper Bound (bisect_right) — First > target

### Python

```python
def bisect_right(arr, target):
    lo, hi = 0, len(arr)
    while lo < hi:
        mid = lo + (hi - lo) // 2
        if arr[mid] <= target:
            lo = mid + 1
        else:
            hi = mid
    return lo
```

### C++

```cpp
int bisectRight(vector<int>& arr, int target) {
    int lo = 0, hi = arr.size();
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] <= target)
            lo = mid + 1;
        else
            hi = mid;
    }
    return lo;
}
```

### Rust

```rust
/// .partition_point(|x| x <= target) — bisect_right. First index where pred is false.
fn bisect_right(arr: &[i32], target: i32) -> usize {
    arr.partition_point(|&x| x <= target)
}
```

**Rust Note:** `|&x| x <= target` = "elements ≤ target". partition_point gives first index where `x <= target` is false, i.e. first `x > target`.

---

## Template 4: Binary Search on Answer (Minimize)

**Find minimum X such that condition(X) is true.**

### Python

```python
def binary_search_on_answer_min(lo, hi, condition):
    """condition(x) returns True if x satisfies the requirement"""
    while lo < hi:
        mid = lo + (hi - lo) // 2
        if condition(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo if condition(lo) else -1
```

### C++

```cpp
int binarySearchOnAnswerMin(int lo, int hi, function<bool(int)> condition) {
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (condition(mid))
            hi = mid;
        else
            lo = mid + 1;
    }
    return condition(lo) ? lo : -1;
}
```

### Rust

```rust
/// Binary search on answer: find min x such that condition(x). Use (lo..hi) range.
fn binary_search_on_answer_min(
    lo: i32, hi: i32,
    condition: impl Fn(i32) -> bool,
) -> Option<i32> {
    let mut lo = lo;
    let mut hi = hi;
    while lo < hi {
        let mid = lo + (hi - lo) / 2;  // Checked arithmetic
        if condition(mid) {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    if condition(lo) { Some(lo) } else { None }
}
```

**Rust Note:** `impl Fn(i32) -> bool` — closure trait, accepts closures. Use `i32` for answer space when range fits. `Option` instead of -1.

---

## Template 5: Binary Search on Answer (Maximize)

**Find maximum X such that condition(X) is true.**

### Python

```python
def binary_search_on_answer_max(lo, hi, condition):
    while lo < hi:
        mid = lo + (hi - lo + 1) // 2  # Ceiling to avoid infinite loop
        if condition(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo if condition(lo) else -1
```

### C++

```cpp
int binarySearchOnAnswerMax(int lo, int hi, function<bool(int)> condition) {
    while (lo < hi) {
        int mid = lo + (hi - lo + 1) / 2;  // Ceiling
        if (condition(mid))
            lo = mid;
        else
            hi = mid - 1;
    }
    return condition(lo) ? lo : -1;
}
```

### Rust

```rust
/// Ceiling mid to avoid infinite loop when lo+1==hi.
fn binary_search_on_answer_max(
    lo: i32, hi: i32,
    condition: impl Fn(i32) -> bool,
) -> Option<i32> {
    let mut lo = lo;
    let mut hi = hi;
    while lo < hi {
        let mid = lo + (hi - lo + 1) / 2;  // Ceiling!
        if condition(mid) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    if condition(lo) { Some(lo) } else { None }
}
```

**Rust Note:** `(hi - lo + 1) / 2` = ceiling of midpoint. Without +1, when lo=3, hi=4, mid=3 → infinite loop.

---

## Template 6: Binary Search on Rotated Array

**Find target in rotated sorted array (no duplicates).**

### Python

```python
def search_rotated(arr, target):
    lo, hi = 0, len(arr) - 1
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        if arr[mid] == target:
            return mid
        if arr[lo] <= arr[mid]:  # Left half is sorted
            if arr[lo] <= target < arr[mid]:
                hi = mid - 1
            else:
                lo = mid + 1
        else:  # Right half is sorted
            if arr[mid] < target <= arr[hi]:
                lo = mid + 1
            else:
                hi = mid - 1
    return -1
```

### C++

```cpp
int searchRotated(vector<int>& arr, int target) {
    int lo = 0, hi = arr.size() - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] == target) return mid;
        if (arr[lo] <= arr[mid]) {
            if (arr[lo] <= target && target < arr[mid])
                hi = mid - 1;
            else
                lo = mid + 1;
        } else {
            if (arr[mid] < target && target <= arr[hi])
                lo = mid + 1;
            else
                hi = mid - 1;
        }
    }
    return -1;
}
```

### Rust

```rust
/// Rotated sorted array: check which half is sorted, narrow accordingly.
fn search_rotated(arr: &[i32], target: i32) -> Option<usize> {
    let mut lo = 0usize;
    let mut hi = arr.len().saturating_sub(1);

    while lo <= hi {
        let mid = lo + (hi - lo) / 2;
        if arr[mid] == target {
            return Some(mid);
        }
        if arr[lo] <= arr[mid] {
            if arr[lo] <= target && target < arr[mid] {
                hi = mid.saturating_sub(1);
            } else {
                lo = mid + 1;
            }
        } else {
            if arr[mid] < target && target <= arr[hi] {
                lo = mid + 1;
            } else {
                hi = mid.saturating_sub(1);
            }
        }
    }
    None
}
```

**Rust Note:** Same logic as C++. `saturating_sub(1)` for usize to avoid underflow. Returns `Option<usize>`.

---

## Template 7: Binary Search on Matrix

**Matrix sorted row-wise and column-wise (or row-wise only).**

### Python (Row-wise sorted, first col ≤ next row's first)

```python
def search_matrix(matrix, target):
    if not matrix or not matrix[0]:
        return False
    m, n = len(matrix), len(matrix[0])
    lo, hi = 0, m * n - 1
    while lo <= hi:
        mid = lo + (hi - lo) // 2
        r, c = mid // n, mid % n
        val = matrix[r][c]
        if val == target:
            return True
        if val < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return False
```

### C++

```cpp
bool searchMatrix(vector<vector<int>>& matrix, int target) {
    if (matrix.empty() || matrix[0].empty()) return false;
    int m = matrix.size(), n = matrix[0].size();
    int lo = 0, hi = m * n - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int r = mid / n, c = mid % n;
        int val = matrix[r][c];
        if (val == target) return true;
        if (val < target)
            lo = mid + 1;
        else
            hi = mid - 1;
    }
    return false;
}
```

### Rust

```rust
/// Flatten to 1D: mid/n, mid%n. Range types for lo, hi.
fn search_matrix(matrix: &[Vec<i32>], target: i32) -> bool {
    let m = matrix.len();
    let n = matrix.first().map(|r| r.len()).unwrap_or(0);
    if m == 0 || n == 0 {
        return false;
    }
    let mut lo = 0usize;
    let mut hi = m * n - 1;

    while lo <= hi {
        let mid = lo + (hi - lo) / 2;
        let (r, c) = (mid / n, mid % n);
        let val = matrix[r][c];
        match val.cmp(&target) {
            std::cmp::Ordering::Equal => return true,
            std::cmp::Ordering::Less => lo = mid + 1,
            std::cmp::Ordering::Greater => hi = mid.saturating_sub(1),
        }
    }
    false
}
```

**Rust Note:** `(mid / n, mid % n)` — tuple destructuring. `m * n` can overflow for huge matrices — use `checked_mul` if needed.

---

## Template 8: Find Minimum in Rotated Array

### Python

```python
def find_min_rotated(arr):
    lo, hi = 0, len(arr) - 1
    while lo < hi:
        mid = lo + (hi - lo) // 2
        if arr[mid] > arr[hi]:
            lo = mid + 1
        else:
            hi = mid
    return arr[lo]
```

### C++

```cpp
int findMinRotated(vector<int>& arr) {
    int lo = 0, hi = arr.size() - 1;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (arr[mid] > arr[hi])
            lo = mid + 1;
        else
            hi = mid;
    }
    return arr[lo];
}
```

### Rust

```rust
/// Find min in rotated sorted array. Compare mid with hi.
fn find_min_rotated(arr: &[i32]) -> i32 {
    let mut lo = 0usize;
    let mut hi = arr.len().saturating_sub(1);

    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        if arr[mid] > arr[hi] {
            lo = mid + 1;
        } else {
            hi = mid;
        }
    }
    arr[lo]
}
```

**Rust Note:** Same pattern. `arr[lo]` is safe when loop exits (lo == hi). Empty slice would panic — add `arr.first().copied().unwrap_or(0)` guard if needed.

---

## Critical Implementation Notes


| Rule                                    | Why                                   |
| --------------------------------------- | ------------------------------------- |
| `mid = lo + (hi - lo) // 2`             | Prevents overflow when lo+hi is large |
| `lo <= hi` for exact match              | Need to check when lo==hi             |
| `lo < hi` for bounds                    | Avoids redundant check, cleaner       |
| `hi = mid` (not mid-1) in bisect_left   | mid might be the answer               |
| `mid = lo + (hi - lo + 1) // 2` for max | Prevents infinite loop when lo=mid    |


---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Binary Search Templates
EXACT MATCH:        lo <= hi, return mid or -1
BISECT_LEFT:        lo < hi, arr[mid] < target → lo=mid+1 else hi=mid
BISECT_RIGHT:       lo < hi, arr[mid] <= target → lo=mid+1 else hi=mid
BS ON ANSWER MIN:   condition(mid) → hi=mid else lo=mid+1
BS ON ANSWER MAX:   mid = ceiling, condition(mid) → lo=mid else hi=mid-1
ROTATED:            Check which half is sorted, narrow accordingly
MATRIX:             Flatten to 1D: mid//n, mid%n
OVERFLOW:           mid = lo + (hi - lo) / 2  ALWAYS
```

---

## Language Comparison Quick Reference


| Concept           | Python            | C++                  | Rust                           |
| ----------------- | ----------------- | -------------------- | ------------------------------ |
| Exact search      | manual / bisect   | manual / lower_bound | `.binary_search(&x)`           |
| First ≥ target    | `bisect_left`     | `lower_bound`        | `.partition_point(|x| x < t)`  |
| First > target    | `bisect_right`    | `upper_bound`        | `.partition_point(|x| x <= t)` |
| Not found         | -1 / raise        | -1 / end             | `Option::None`                 |
| Overflow safe mid | `lo + (hi-lo)//2` | `lo + (hi-lo)/2`     | `lo + (hi-lo)/2` (usize)       |
| Range type        | `range(lo, hi)`   | `[lo, hi]`           | `lo..hi` / `lo..=hi`           |


---

## 30-SECOND REVISION BOX

```
EXACT:    lo<=hi; mid=lo+(hi-lo)/2; match cmp
LEFT:     partition_point(|x| x < target) or lo<hi, arr[mid]<t → lo=mid+1
RIGHT:   partition_point(|x| x <= target)
MIN ANS: condition(mid)→hi=mid else lo=mid+1
MAX ANS: mid=ceiling; condition(mid)→lo=mid else hi=mid-1
ROTATED: which half sorted? narrow
MATRIX:  flatten: r=mid/n, c=mid%n
RUST:    .binary_search(), .partition_point(), Option
```

