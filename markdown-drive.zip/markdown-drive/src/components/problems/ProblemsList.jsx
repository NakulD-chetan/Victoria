import { useState, useEffect, useCallback, useRef } from 'react';
import { SkeletonTableRow } from '../shared/Skeleton';

const API_BASE = '/api';
const DIFF_COLORS = { Easy: 'var(--accent)', Medium: 'var(--accent-warm)', Hard: 'var(--danger)' };

const TYPE_HINTS = [
  'url shortener',
  'rate limiter',
  'web crawler',
  'distributed cache',
  'news feed',
  'messaging system',
];

function useSearchTypewriter(active) {
  const [text, setText] = useState('');
  const tRef = useRef(null);
  const lowMotionRef = useRef(false);

  useEffect(() => {
    if (tRef.current) { clearTimeout(tRef.current); tRef.current = null; }
    if (typeof window !== 'undefined') {
      lowMotionRef.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    }
    if (!active) {
      setText('');
      return undefined;
    }
    if (lowMotionRef.current) {
      setText(TYPE_HINTS[0]);
      return undefined;
    }

    let p = 0;
    let c = 0;
    /** 0 type / 1 hold / 2 delete / 3 gap */
    let phase = 0;
    const T_TYPE = 38;
    const T_HOLD = 2000;
    const T_DEL = 26;
    const T_GAP = 450;

    const step = () => {
      const phrase = TYPE_HINTS[p % TYPE_HINTS.length];
      if (phase === 0) {
        if (c < phrase.length) {
          c += 1;
          setText(phrase.slice(0, c));
          tRef.current = setTimeout(step, T_TYPE);
        } else {
          phase = 1;
          tRef.current = setTimeout(() => { phase = 2; step(); }, T_HOLD);
        }
      } else if (phase === 2) {
        if (c > 0) {
          c -= 1;
          setText(phrase.slice(0, c));
          tRef.current = setTimeout(step, T_DEL);
        } else {
          p += 1;
          phase = 3;
          tRef.current = setTimeout(() => { phase = 0; step(); }, T_GAP);
        }
      }
    };

    tRef.current = setTimeout(step, 300);
    return () => { if (tRef.current) clearTimeout(tRef.current); };
  }, [active]);

  return text;
}

export default function ProblemsList() {
  const [problems, setProblems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hasLoadedOnce, setHasLoadedOnce] = useState(false);
  const [search, setSearch] = useState('');
  const [searchFocused, setSearchFocused] = useState(false);
  const [difficulty, setDifficulty] = useState('All');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const debounceRef = useRef(null);
  const abortRef = useRef(null);
  const cacheRef = useRef(new Map());
  const requestIdRef = useRef(0);
  const searchReadyRef = useRef(false);
  const limit = 24;

  const showTypewriterHint = !search && !searchFocused;
  const typewriterLine = useSearchTypewriter(showTypewriterHint);

  const buildCacheKey = (pg, diff, q) => `${pg}|${diff}|${q}`;

  const fetchProblems = useCallback(async (pg, diff, q) => {
    const key = buildCacheKey(pg, diff, q);
    const cached = cacheRef.current.get(key);
    if (cached) {
      requestIdRef.current += 1;
      if (abortRef.current) {
        abortRef.current.abort();
        abortRef.current = null;
      }
      setProblems(cached.data);
      setTotal(cached.total);
      setLoading(false);
      setHasLoadedOnce(true);
      return;
    }

    const requestId = requestIdRef.current + 1;
    requestIdRef.current = requestId;
    if (abortRef.current) abortRef.current.abort();
    const controller = new AbortController();
    abortRef.current = controller;

    setLoading(true);
    const params = new URLSearchParams({ page: pg, limit });
    if (diff && diff !== 'All') params.set('difficulty', diff);
    if (q) params.set('q', q);

    try {
      const res = await fetch(`${API_BASE}/problems?${params}`, { signal: controller.signal });
      if (requestId !== requestIdRef.current) return;
      if (res.ok) {
        const json = await res.json();
        const data = json.data || [];
        const t = json.total || data.length;
        setProblems(data);
        setTotal(t);
        cacheRef.current.set(key, { data, total: t });
        if (cacheRef.current.size > 50) {
          const first = cacheRef.current.keys().next().value;
          cacheRef.current.delete(first);
        }
      } else {
        setProblems([]);
        setTotal(0);
      }
    } catch (e) {
      if (requestId !== requestIdRef.current) return;
      if (e.name !== 'AbortError') { setProblems([]); setTotal(0); }
      else return;
    }
    if (requestId === requestIdRef.current) {
      setLoading(false);
      setHasLoadedOnce(true);
    }
  }, []);

  useEffect(() => {
    fetchProblems(page, difficulty, search);
  }, [page, difficulty, fetchProblems]);

  useEffect(() => {
    if (!searchReadyRef.current) {
      searchReadyRef.current = true;
      return undefined;
    }
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(1);
      fetchProblems(1, difficulty, search);
    }, 400);
    return () => clearTimeout(debounceRef.current);
  }, [search]);

  useEffect(() => () => {
    requestIdRef.current += 1;
    if (abortRef.current) abortRef.current.abort();
  }, []);

  const navigate = (href) => {
    window.history.pushState(null, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  const totalPages = Math.ceil(total / limit);
  const difficulties = ['Easy', 'Medium', 'Hard'];

  return (
    <div className="dc-catalog dc-catalog--wide">
      <div className="dc-catalog__header">
        <h1 className="dc-catalog__title">System Design Problems</h1>
        <p className="dc-catalog__desc">Drag-and-drop architecture components, wire them up, and validate with automated tests.</p>
      </div>

      <div className="dc-catalog__search-row">
        <div className="dc-catalog__search-shell">
          <svg className="dc-catalog__search-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          {showTypewriterHint && (
            <div className="dc-catalog__search-hint" aria-hidden>
              <span className="dc-catalog__search-hint__prefix">Search: </span>
              <span className="dc-catalog__search-hint__typed">{typewriterLine || '\u00a0'}</span>
            </div>
          )}
          <input
            type="search"
            className={`dc-catalog__search-input${showTypewriterHint && !search ? ' dc-catalog__search-input--ghost' : ''}`}
            name="q"
            autoComplete="off"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onFocus={() => setSearchFocused(true)}
            onBlur={() => setSearchFocused(false)}
            placeholder={searchFocused && !search ? 'Filter problems…' : ' '}
            aria-label="Search and filter system design problems"
            spellCheck={false}
          />
          {search && (
            <button type="button" className="dc-catalog__search-clear" onClick={() => setSearch('')} title="Clear search" aria-label="Clear search">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>
      </div>

      <div className="dc-tag-cloud">
        <div className="dc-tag-cloud__wrap">
          {['All', ...difficulties].map((d) => (
            <button key={d} onClick={() => { setDifficulty(d); setPage(1); }}
              className={`dc-tag-pill dc-tag-pill--cat ${difficulty === d ? 'dc-tag-pill--active' : ''}`}
            >
              {d}
            </button>
          ))}
        </div>
        {(difficulty !== 'All' || search) && (
          <button className="dc-tag-cloud__clear" onClick={() => { setDifficulty('All'); setSearch(''); setPage(1); }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
            Clear all filters
          </button>
        )}
      </div>

      <div className="dc-problem-list">
        <div className="dc-problem-list__header">
          <span className="dc-problem-list__col dc-problem-list__col--num">#</span>
          <span className="dc-problem-list__col dc-problem-list__col--icon" aria-hidden> </span>
          <span className="dc-problem-list__col dc-problem-list__col--title">Title</span>
          <span className="dc-problem-list__col dc-problem-list__col--diff">Difficulty</span>
        </div>
        {loading ? (
          Array.from({ length: 8 }).map((_, i) => <SkeletonTableRow key={i} />)
        ) : (
          problems.map((problem) => (
            <button key={problem.slug || problem.id} className="dc-problem-row" onClick={() => navigate(`/systemdesign/${problem.slug || problem.id}`)}>
              <span className="dc-problem-row__num">{problem.number}.</span>
              <span className="dc-problem-row__icon-wrap" aria-hidden>
                <span className="dc-problem-row__icon-emoji">{problem.icon}</span>
              </span>
              <span className="dc-problem-row__title">{problem.title}</span>
              <span className="dc-problem-row__diff" style={{ color: DIFF_COLORS[problem.difficulty] }}>
                {problem.difficulty}
              </span>
            </button>
          ))
        )}
      </div>

      {!loading && hasLoadedOnce && problems.length === 0 && <div className="dc-empty">No problems match your search.</div>}

      {totalPages > 1 && (
        <div className="dc-pagination">
          <button className="dc-pagination__btn" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>
            Previous
          </button>
          <span className="dc-pagination__info">Page {page} of {totalPages}</span>
          <button className="dc-pagination__btn" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>
            Next
          </button>
        </div>
      )}
    </div>
  );
}
