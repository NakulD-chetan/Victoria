# 12. Common Mistakes & Clean Tricks

> **Permanent Recall Note:** Most Kafka **incidents** are **configuration** and **misplaced expectations**: too many **partitions**, **consumer lag** ignored, **rebalance** storms, **ordering** assumed globally, **Kafka** used as a **database**. This chapter is the **on-call** survival kit — parallel to [../spark/14_Common_Mistakes_Tricks.md](../spark/14_Common_Mistakes_Tricks.md) for Spark.

### The 10-Second Summary
- **Partitions:** too many = pain; too few = bottleneck.
- **Keys:** no key when **order** matters = bug.
- **Lag:** monitor **per partition** — **max** matters.
- **Retention:** infinite **disk** bill; **compaction** backlog.
- **Anti-pattern:** **Kafka as source of truth DB** — **wrong tool**.

---

# 12.1 Too Many Partitions

**Mistake:** “10,000 partitions = max speed.”

**Reality:** More **metadata**, **election** time, **file descriptors**, **longer** recovery.

🔥 **Pro Tip:** **Right-size** from throughput + consumer **parallelism** — **grow** deliberately.

---

# 12.2 Wrong Replication Factor

**Mistake:** RF=1 in **production**.

**Reality:** **Single** broker loss ⇒ **data loss** / **unavailable** partitions.

📏 **Golden Rule:** RF=3, **min.insync.replicas=2** for durable **money** topics.

---

# 12.3 Not Using Keys When Ordering Matters

**Mistake:** **Null keys** + expectation of **per-user** order.

**Reality:** Records **spray** across partitions — **order** lost.

💡 **Key Insight:** **userId** as key — **per-user** order; **not** cross-user.

---

# 12.4 Consumer Group Rebalancing Storms

**Mistake:** **GC** pauses / **slow** `poll()` / **bad** processing — **missed** heartbeats.

**Reality:** Constant **rebalance** — **no** steady progress.

**Fix:** Tune **max.poll.interval**, **processing**, **cooperative** assignor, **static** membership.

---

# 12.5 Not Monitoring Consumer Lag

**Mistake:** Only **broker** CPU graphs.

**Reality:** **Lag** = **user-visible** delay — **primary** SLI for pipelines.

---

# 12.6 Large Messages in Kafka

**Mistake:** **Multi-MB** JSON blobs by default.

**Reality:** **Broker** limits, **replication** cost, **compaction** pain — use **object store** + **reference**.

⚠️ **Warning:** Raise `max.message.bytes` **everywhere** consistently — **client**, **broker**, **topic**.

---

# 12.7 Not Setting Retention Properly

**Mistake:** **Default** forever in **cloud** — **$$$**.

**Reality:** **Tiered** storage or **mirror** to **lake** — **policy** by domain.

---

# 12.8 Ignoring Schema Evolution

**Mistake:** **Ad-hoc** JSON without **Registry**.

**Reality:** **Breaking** changes in **production** — **nightmare** for **Spark** schemas too — [../spark/09_Storage_Catalog_Table_Formats.md](../spark/09_Storage_Catalog_Table_Formats.md).

---

# 12.9 Not Tuning Producer Batching

**Mistake:** All defaults on **high throughput**.

**Reality:** **Tiny** batches ⇒ **CPU** + **network** overhead.

**Fix:** `linger.ms`, `batch.size`, **compression**.

---

# 12.10 Using Kafka as a Database (Anti-Pattern)

**Mistake:** **CRUD** queries against **topics**.

**Reality:** No **secondary indexes**, no **transactions** like **RDBMS** — **CQRS** + **read models** elsewhere.

---

# 12.11 Not Handling Poison Pills

**Mistake:** **Deserialization** exception **kills** processing — **stuck** partition.

**Reality:** **DLQ**, **skip** with metrics, **schema** validation **before** Kafka.

---

# 12.12 Forgetting About Compaction

**Mistake:** Enable **compact** + **delete** tombstones but **never** monitor **cleaner**.

**Reality:** **Disk** growth / **stale** data — **dirty ratio** metrics.

---

# 12.13 Tricks Cheat Sheet

| Problem | Trick |
|---------|-------|
| **Hot partition** | **Keyed** skew — **salt** + **downstream** merge |
| **Slow consumer** | **Scale** consumers ≤ partitions |
| **Duplicate writes** | **Idempotent** sink / **txn** |
| **Schema drift** | **CI** compatibility |

---

# 12.14 Broker “Hot Spot” Mitigation

```
Many keys → same partition (bad hash / low cardinality key)
        │
        ▼
Consider: composite key, partitioner change (careful), more partitions + business key redesign
```

---

# 12.15 Cross-Team Communication Mistakes

- **No SLAs** on **topic** ownership — **who** fixes lag?
- **No** **on-call** for **schema** breaks — Registry alerts missing.

---

# 12.16 Interview Questions & Answers

**Q: Sabse common production mistake?**  
**A:** **Mis-tuned** consumers + **ignored** lag + **wrong** ordering assumptions.

**Q: Kafka se query kaise nahi?**  
**A:** **ksql** limited; **real** analytics → **Spark/Flink** + **warehouse**.

**Q: Spark mistake parallel?**  
**A:** **collect()** on big RDD — Kafka parallel: **unbounded** retention without **archival**.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 12 — QUICK RECALL                                 │
├─────────────────────────────────────────────────────────────┤
│  🧠 Partitions/RF/keys — design triangle                   │
│  🧠 Lag + rebalance = consumer health                      │
│  🧠 Large payloads = reference pattern                       │
│  🧠 Schema + DLQ = resilience                              │
│  ⚠️  Kafka ≠ database                                    │
│  🎯 Retention = cost + compliance                          │
└─────────────────────────────────────────────────────────────┘
```
