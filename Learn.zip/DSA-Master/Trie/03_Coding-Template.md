# Trie — Coding Templates (Python + C++ + Rust)

> **Learn 3 languages WHILE learning the pattern. Every template teaches DSA + syntax simultaneously.**

---

## Template 1: TrieNode + Basic Trie (Insert, Search, startsWith)

### Python

```python
from collections import defaultdict

class TrieNode:
    def __init__(self):
        self.children = defaultdict(TrieNode)  # char -> TrieNode
        self.is_end = False

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def insert(self, word: str) -> None:
        node = self.root
        for ch in word:
            node = node.children[ch]  # defaultdict auto-creates
        node.is_end = True

    def search(self, word: str) -> bool:
        node = self.root
        for ch in word:
            if ch not in node.children:
                return False
            node = node.children[ch]
        return node.is_end

    def startsWith(self, prefix: str) -> bool:
        node = self.root
        for ch in prefix:
            if ch not in node.children:
                return False
            node = node.children[ch]
        return True
```

---

### C++ (Map-based)

```cpp
#include <unordered_map>
#include <string>
using namespace std;

struct TrieNode {
    unordered_map<char, TrieNode*> children;
    bool is_end = false;
};

class Trie {
    TrieNode* root;
public:
    Trie() { root = new TrieNode(); }

    void insert(const string& word) {
        TrieNode* node = root;
        for (char c : word) {
            if (node->children.find(c) == node->children.end())
                node->children[c] = new TrieNode();
            node = node->children[c];
        }
        node->is_end = true;
    }

    bool search(const string& word) {
        TrieNode* node = root;
        for (char c : word) {
            if (node->children.find(c) == node->children.end())
                return false;
            node = node->children[c];
        }
        return node->is_end;
    }

    bool startsWith(const string& prefix) {
        TrieNode* node = root;
        for (char c : prefix) {
            if (node->children.find(c) == node->children.end())
                return false;
            node = node->children[c];
        }
        return true;
    }
};
```

---

### C++ (Array-based, a-z)

```cpp
struct TrieNode {
    TrieNode* children[26] = {};
    bool is_end = false;
};

class Trie {
    TrieNode* root;
public:
    Trie() { root = new TrieNode(); }

    void insert(const string& word) {
        TrieNode* node = root;
        for (char c : word) {
            int i = c - 'a';
            if (!node->children[i])
                node->children[i] = new TrieNode();
            node = node->children[i];
        }
        node->is_end = true;
    }

    bool search(const string& word) {
        TrieNode* node = root;
        for (char c : word) {
            int i = c - 'a';
            if (!node->children[i]) return false;
            node = node->children[i];
        }
        return node->is_end;
    }

    bool startsWith(const string& prefix) {
        TrieNode* node = root;
        for (char c : prefix) {
            int i = c - 'a';
            if (!node->children[i]) return false;
            node = node->children[i];
        }
        return true;
    }
};
```

---

### Rust (HashMap children)

```rust
use std::collections::HashMap;

struct TrieNode {
    children: HashMap<char, Box<TrieNode>>,
    is_end: bool,
}

impl TrieNode {
    fn new() -> Self {
        TrieNode {
            children: HashMap::new(),
            is_end: false,
        }
    }
}

struct Trie {
    root: Box<TrieNode>,
}

impl Trie {
    fn new() -> Self {
        Trie {
            root: Box::new(TrieNode::new()),
        }
    }

    fn insert(&mut self, word: String) {
        let mut node = &mut self.root;
        for c in word.chars() {
            node = node.children
                .entry(c)
                .or_insert_with(|| Box::new(TrieNode::new()));
        }
        node.is_end = true;
    }

    fn search(&self, word: String) -> bool {
        let mut node = &self.root;
        for c in word.chars() {
            match node.children.get(&c) {
                Some(child) => node = child,
                None => return false,
            }
        }
        node.is_end
    }

    fn starts_with(&self, prefix: String) -> bool {
        let mut node = &self.root;
        for c in prefix.chars() {
            match node.children.get(&c) {
                Some(child) => node = child,
                None => return false,
            }
        }
        true
    }
}
```

---

### Rust (Vec<Option<Box<TrieNode>>> for a-z)

```rust
struct TrieNode {
    children: Vec<Option<Box<TrieNode>>>,
    is_end: bool,
}

impl TrieNode {
    fn new() -> Self {
        TrieNode {
            children: (0..26).map(|_| None).collect(),
            is_end: false,
        }
    }
}

struct Trie {
    root: Box<TrieNode>,
}

impl Trie {
    fn new() -> Self {
        Trie { root: Box::new(TrieNode::new()) }
    }

    fn insert(&mut self, word: String) {
        let mut node = &mut self.root;
        for c in word.chars() {
            let i = (c as u8 - b'a') as usize;
            if node.children[i].is_none() {
                node.children[i] = Some(Box::new(TrieNode::new()));
            }
            node = node.children[i].as_mut().unwrap();
        }
        node.is_end = true;
    }

    fn search(&self, word: String) -> bool {
        let mut node = &self.root;
        for c in word.chars() {
            let i = (c as u8 - b'a') as usize;
            match &node.children[i] {
                Some(child) => node = child,
                None => return false,
            }
        }
        node.is_end
    }

    fn starts_with(&self, prefix: String) -> bool {
        let mut node = &self.root;
        for c in prefix.chars() {
            let i = (c as u8 - b'a') as usize;
            match &node.children[i] {
                Some(child) => node = child,
                None => return false,
            }
        }
        true
    }
}
```

---

## Template 2: Wildcard Search (e.g., "c.t" matches "cat")

### Python

```python
def search_wildcard(self, word: str) -> bool:
    def dfs(node: TrieNode, i: int) -> bool:
        if i == len(word):
            return node.is_end
        ch = word[i]
        if ch == '.':
            for child in node.children.values():
                if dfs(child, i + 1):
                    return True
            return False
        if ch not in node.children:
            return False
        return dfs(node.children[ch], i + 1)
    return dfs(self.root, 0)
```

---

### C++

```cpp
bool searchWildcard(const string& word) {
    function<bool(TrieNode*, int)> dfs = [&](TrieNode* node, int i) {
        if (i == (int)word.size()) return node->is_end;
        char c = word[i];
        if (c == '.') {
            for (auto& [ch, child] : node->children)
                if (dfs(child, i + 1)) return true;
            return false;
        }
        if (node->children.find(c) == node->children.end()) return false;
        return dfs(node->children[c], i + 1);
    };
    return dfs(root, 0);
}
```

---

### Rust

```rust
fn search_wildcard(&self, word: &str) -> bool {
    fn dfs(node: &TrieNode, word: &str, i: usize) -> bool {
        if i == word.len() {
            return node.is_end;
        }
        let ch = word.chars().nth(i).unwrap();
        if ch == '.' {
            for child in node.children.values() {
                if dfs(child, word, i + 1) {
                    return true;
                }
            }
            return false;
        }
        if let Some(child) = node.children.get(&ch) {
            dfs(child, word, i + 1)
        } else {
            false
        }
    }
    dfs(&self.root, word, 0)
}
```

---

## Template 3: Word Break (Trie + DP)

### Python

```python
def word_break(s: str, word_dict: list[str]) -> bool:
    trie = Trie()
    for w in word_dict:
        trie.insert(w)

    n = len(s)
    dp = [False] * (n + 1)
    dp[0] = True

    for i in range(n):
        if not dp[i]:
            continue
        node = trie.root
        for j in range(i, n):
            if s[j] not in node.children:
                break
            node = node.children[s[j]]
            if node.is_end:
                dp[j + 1] = True
    return dp[n]
```

---

### C++

```cpp
bool wordBreak(string s, vector<string>& wordDict) {
    Trie trie;
    for (auto& w : wordDict) trie.insert(w);

    int n = s.size();
    vector<bool> dp(n + 1, false);
    dp[0] = true;

    for (int i = 0; i < n; i++) {
        if (!dp[i]) continue;
        TrieNode* node = trie.root;
        for (int j = i; j < n; j++) {
            if (node->children.find(s[j]) == node->children.end()) break;
            node = node->children[s[j]];
            if (node->is_end) dp[j + 1] = true;
        }
    }
    return dp[n];
}
```

---

### Rust

```rust
fn word_break(s: &str, word_dict: Vec<String>) -> bool {
    let mut trie = Trie::new();
    for w in &word_dict {
        trie.insert(w.clone());
    }

    let chars: Vec<char> = s.chars().collect();
    let n = chars.len();
    let mut dp = vec![false; n + 1];
    dp[0] = true;

    for i in 0..n {
        if !dp[i] { continue; }
        let mut node = &trie.root;
        for j in i..n {
            let c = chars[j];
            if !node.children.contains_key(&c) { break; }
            node = node.children.get(&c).unwrap();
            if node.is_end {
                dp[j + 1] = true;
            }
        }
    }
    dp[n]
}
```

---

## Template 4: Count Prefix (Prefix Count)

### Python

```python
class TrieNode:
    def __init__(self):
        self.children = defaultdict(TrieNode)
        self.count = 0  # words with this prefix

def insert(self, word: str) -> None:
    node = self.root
    for ch in word:
        node = node.children[ch]
        node.count += 1
    node.is_end = True

def count_prefix(self, prefix: str) -> int:
    node = self.root
    for ch in prefix:
        if ch not in node.children:
            return 0
        node = node.children[ch]
    return node.count
```

---

### C++

```cpp
struct TrieNode {
    unordered_map<char, TrieNode*> children;
    int count = 0;
    bool is_end = false;
};

void insert(const string& word) {
    TrieNode* node = root;
    for (char c : word) {
        if (node->children.find(c) == node->children.end())
            node->children[c] = new TrieNode();
        node = node->children[c];
        node->count++;
    }
    node->is_end = true;
}

int countPrefix(const string& prefix) {
    TrieNode* node = root;
    for (char c : prefix) {
        if (node->children.find(c) == node->children.end())
            return 0;
        node = node->children[c];
    }
    return node->count;
}
```

---

### Rust

```rust
struct TrieNode {
    children: HashMap<char, Box<TrieNode>>,
    count: usize,
    is_end: bool,
}

fn insert(&mut self, word: String) {
    let mut node = &mut self.root;
    for c in word.chars() {
        node = node.children
            .entry(c)
            .or_insert_with(|| Box::new(TrieNode { children: HashMap::new(), count: 0, is_end: false }));
        node.count += 1;
    }
    node.is_end = true;
}

fn count_prefix(&self, prefix: &str) -> usize {
    let mut node = &self.root;
    for c in prefix.chars() {
        match node.children.get(&c) {
            Some(child) => node = child,
            None => return 0,
        }
    }
    node.count
}
```

---

## Language Comparison Quick Reference

| Concept | Python | C++ | Rust |
|---------|--------|-----|------|
| Children | `defaultdict(TrieNode)` | `unordered_map<char, TrieNode*>` | `HashMap<char, Box<TrieNode>>` |
| Auto-create child | `node.children[ch]` | `new TrieNode()` | `.entry(c).or_insert_with(...)` |
| End-of-word | `node.is_end` | `node->is_end` | `node.is_end` |
| Iterate chars | `for ch in word` | `for (char c : word)` | `word.chars()` |
| Ownership | GC | Manual (leak risk) | `Box<TrieNode>` |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TRIENODE:    children (map/array) + is_end
INSERT:      for ch: node = node.children[ch]; node.is_end = true
SEARCH:      follow path, return node.is_end
STARTSWITH:  follow path, return true
WILDCARD:    DFS, '.' → try all children
WORD BREAK:  Trie + dp[i] = can form s[0:i]
COUNT PREFIX: increment count on each node during insert
RUST:        Box<TrieNode> for ownership, .entry().or_insert_with()
```

---

## 30-SECOND REVISION BOX

```
INSERT:  traverse, create if missing, mark end
SEARCH:  traverse, check is_end at end
STARTSWITH: traverse, no is_end check
WILDCARD: DFS + '.' tries all children
WORD BREAK: Trie + dp, check prefix at each i
PYTHON:  defaultdict(TrieNode)
C++:     map/array, new TrieNode()
RUST:    HashMap + Box, entry API
```
