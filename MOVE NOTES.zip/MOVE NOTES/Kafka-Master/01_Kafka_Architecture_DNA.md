# 1. Kafka History, Philosophy & Architecture (DNA)

> **Permanent Recall Note:** Kafka started as a **log-structured** messaging backbone at **LinkedIn** (2010–2011), then became an **Apache** project. The core idea: treat streams as **append-only partitions** on disk, replicated for durability, consumed by **many independent consumer groups** at their own pace. As a **Data Engineer**, you design **topics/partitions**, reason about **ordering**, **delivery semantics**, and how Kafka sits **between** systems — not as a database of record for arbitrary queries.

### The 10-Second Summary
- **LinkedIn → Apache:** built for **high throughput**, **horizontal scale**, **durability** without classic MQ bottlenecks.
- **Commit log:** each partition is an **ordered, immutable** sequence; **offset** = position.
- **Brokers** store segments; **KRaft** (or legacy **ZooKeeper**) manages cluster metadata.
- **Pull-based consumers** control flow; compare to **RabbitMQ** (queue semantics) and **Pulsar** (tiered storage / broker model).

---

# 1.1 History — LinkedIn to Apache

```
2010–2011  LinkedIn internal need: activity pipeline, metrics, ingestion scale
2011       Open-sourced; named after Franz Kafka (author of dense logs…)
2012+      Apache incubator → top-level; ecosystem: Connect, Streams, MirrorMaker
Today      Industry default for event streaming; cloud-managed (MSK, Confluent Cloud, Aiven)
```

💡 **Key Insight:** Kafka’s design favors **sequential disk I/O** + **OS page cache** + **zero-copy** networking — not “keep everything in RAM” like some classic caches.

---

# 1.2 Why Kafka (Problems It Solves)

| Pain in classic integration | How Kafka helps |
|-----------------------------|-----------------|
| Point-to-point spaghetti | **Pub/sub** — many consumers per topic |
| Coupled release cycles | **Async** boundary + schema contracts |
| Replay / audit | **Durable log** — rewind and reprocess |
| Burst handling | **Buffer** between fast producers and slow sinks |

🏗️ **Real-World:** CDC from OLTP → Kafka → **Spark/Flink** → lakehouse is a standard DE pattern; see also [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

---

# 1.3 Architecture Overview

```
                    ┌─────────────────────────────────────┐
                    │  Producers (many)                    │
                    │  • partition key → partition id      │
                    │  • batch + compression               │
                    └──────────────────┬──────────────────┘
                                       │ Produce
                                       ▼
┌──────────────────────────────────────────────────────────────┐
│  Kafka Cluster (brokers)                                      │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐              │
│  │  Broker 1 │  │  Broker 2 │  │  Broker 3 │   ...          │
│  │  Leader    │  │  Replica   │  │  Replica   │              │
│  │  for P0    │  │  for P0    │  │  for P1 L  │              │
│  └────────────┘  └────────────┘  └────────────┘              │
│  Metadata: KRaft quorum OR ZooKeeper ensemble (legacy)       │
└──────────────────────────────────────────────────────────────┘
                    │ Fetch (pull)          │
                    ▼                       │
        ┌───────────────────────┐  ┌───────────────────────┐
        │ Consumer Group A       │  │ Consumer Group B       │
        │ (each partition → 1)   │  │ (independent offsets)  │
        └───────────────────────┘  └───────────────────────┘
```

📏 **Golden Rule:** **Parallelism** = **partitions**; **ordering** = **within one partition** (if you use a key consistently).

---

# 1.4 Brokers, Topics, Partitions, Segments

| Concept | Simple bhasha mein |
|---------|---------------------|
| **Broker** | Kafka server process holding partition **replicas** |
| **Topic** | Logical name; **partition count** fixed at create (expand with care) |
| **Partition** | Ordered log; **one leader** at a time |
| **Segment** | Chunk of the log on disk (`.log` + indexes) — rolled by size/time |

```
PARTITION (logical)
  [msg@0][msg@1][msg@2] ... [msg@N]
        └── segments on disk ──┘
```

🧠 **Memory Trick:** **Topic** = naam; **Partition** = parallel **queues** sharing naam; **Segment** = disk file ka **piece**.

---

# 1.5 ZooKeeper vs KRaft

| | **ZooKeeper mode (legacy)** | **KRaft (Kafka Raft metadata)** |
|--|------------------------------|----------------------------------|
| Metadata | ZK ensemble + brokers | **Controller quorum** in Kafka |
| Ops | Extra moving part | Fewer JVMs; faster controller failover |
| Version | Older deployments | **Kafka 3.x+** recommended path |

⚠️ **Warning:** Interview mein ab **KRaft** bolna safe — ZK sirf legacy systems ke liye.

---

# 1.6 Log Structure — Append-Only Commit Log

- Messages are **appended** at the **leader**; followers **replicate**.
- **Retention** = time/size/policy — not “delete after consume” (unlike classic queues).
- **Compaction** = keep latest key per key (log compaction) — different from delete-by-time.

🔄 **Trade-off:** Durable replay is powerful but **disk + governance** cost — retention and compaction must be designed.

---

# 1.7 Producer / Consumer Model & Pull vs Push

| | **Push (typical MQ to consumer)** | **Pull (Kafka)** |
|--|-----------------------------------|------------------|
| Flow control | Broker may overwhelm slow consumer | Consumer **fetches** at its rate |
| Backpressure | Harder | Natural via **fetch + pause** |
| Latency | Can be lower for tiny messages | Batching favors **throughput** |

💡 **Key Insight:** Pull fits **many heterogeneous consumers** on the same log — each tracks **offsets** independently.

---

# 1.8 Kafka vs RabbitMQ vs Pulsar

| Dimension | **Apache Kafka** | **RabbitMQ** | **Apache Pulsar** |
|-----------|------------------|--------------|-------------------|
| Model | **Log / pub-sub** partitions | **Queue + exchanges** routing | **Log + broker + BookKeeper** |
| Ordering | **Per-partition** | Queue/exchange dependent | Per-partition (topics) |
| Replay | First-class (retained log) | Not primary design | Yes + tiered storage |
| Ops complexity | Brokers + (ZK or KRaft) | Erlang cluster | ZooKeeper + BookKeeper |
| Sweet spot | High-throughput streaming, connect ecosystem | Flexible routing, classic messaging | Multi-tenancy, geo, long retention |

🎯 **Interview Tip:** “Kafka is not a work queue” — say when you need **ordering + replay + multiple consumers**.

---

# 1.9 CLI — Quick Sanity

```bash
# List topics (Kafka scripts path varies by install)
kafka-topics.sh --bootstrap-server localhost:9092 --list

kafka-topics.sh --bootstrap-server localhost:9092 \
  --create --topic orders --partitions 3 --replication-factor 3

kafka-console-producer.sh --bootstrap-server localhost:9092 --topic orders
kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic orders \
  --from-beginning --group demo-group
```

---

# 1.10 Interview Questions & Answers

**Q: Kafka ko database kyun nahi maante?**  
**A:** Primary abstraction **append-only log** hai — arbitrary **query/index** nahi. Operational store ke liye **RocksDB** (Streams) ya **sink DB** alag hota hai.

**Q: Commit log se kya matlab?**  
**A:** Har partition par **ordered sequence** of records; **offset** position hai; durability **replication** se.

**Q: Spark streaming ke saath relation?**  
**A:** Spark **micro-batch** ya **continuous** mode mein Kafka se **read** karta hai — offsets checkpoint; detail [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

**Q: KRaft kyun?**  
**A:** Metadata **Kafka ke andar** — simpler ops, better scalability story vs external ZK.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 1 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Kafka = distributed commit log + pub/sub               │
│  🧠 Partition = parallelism + ordering boundary             │
│  🧠 Pull consumers; offsets per group                       │
│  🧠 KRaft = metadata without ZooKeeper (modern)             │
│  ⚠️  Ordering ≠ global — only per-partition with key        │
│  🎯 Compare RabbitMQ (routing) vs Pulsar (BookKeeper)       │
└─────────────────────────────────────────────────────────────┘
```
