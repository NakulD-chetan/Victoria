import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(a, b) {
  const n = a.length;
  const m = b.length;
  const dp = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));
  const steps = [];
  const colLabels = ['ε', ...b.split('')];
  const rowLabels = ['ε', ...a.split('')];

  const snap = (caption, colors, hl, arrows) => {
    steps.push({ caption, table: dp.map((r) => [...r]), rowLabels, colLabels, cellColors: colors || {}, arrows: arrows || [], highlight: hl });
  };

  for (let i = 0; i <= n; i += 1) dp[i][0] = i;
  for (let j = 0; j <= m; j += 1) dp[0][j] = j;
  snap('Base cases: first row/col are insert/delete counts', { '0-0': 'filled' }, [0, 0], []);

  for (let i = 1; i <= n; i += 1) {
    for (let j = 1; j <= m; j += 1) {
      const colors = {
        [`${i}-${j}`]: 'current',
        [`${i - 1}-${j}`]: 'filled',
        [`${i}-${j - 1}`]: 'filled',
        [`${i - 1}-${j - 1}`]: 'filling',
      };
      const arrows = [
        { from: [i - 1, j], to: [i, j] },
        { from: [i, j - 1], to: [i, j] },
        { from: [i - 1, j - 1], to: [i, j] },
      ];
      if (a[i - 1] === b[j - 1]) {
        snap(`Match: carry diagonal ${dp[i - 1][j - 1]}`, colors, [i, j], arrows);
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        snap('Mismatch: 1 + min(delete, insert, replace)', colors, [i, j], arrows);
        dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
      }
      snap(`dp[${i}][${j}] = ${dp[i][j]}`, { [`${i}-${j}`]: 'optimal' }, [i, j], []);
    }
  }

  snap(`Edit distance = ${dp[n][m]}`, { [`${n}-${m}`]: 'optimal' }, [n, m], []);
  return steps;
}

export default function EditDistanceVisualizer({ config }) {
  const a = 'kitten';
  const b = 'sitting';

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(a, b);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Edit distance "${a}" → "${b}"` });
    canvasRef.current?.setState({ table: [[0]], rowLabels: [], colLabels: [], cellColors: {}, arrows: [], highlight: null, caption: 'Edit distance' });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
