# Prefix Sum — Coding Template

> **Copy-paste templates. No problem-specific logic.** Python + C++ + Rust for FAANG interviews.

---

## Template 1: 1D Prefix Sum — Build + Query

### Python
```python
def build_prefix(arr):
    n = len(arr)
    prefix = [0] * (n + 1)
    for i in range(n):
        prefix[i + 1] = prefix[i] + arr[i]
    return prefix

def range_sum(prefix, i, j):
    """Sum of arr[i..j] inclusive."""
    return prefix[j + 1] - prefix[i]
```

### C++
```cpp
vector<long long> buildPrefix(const vector<int>& arr) {
    int n = arr.size();
    vector<long long> prefix(n + 1, 0);
    for (int i = 0; i < n; i++)
        prefix[i + 1] = prefix[i] + arr[i];
    return prefix;
}

long long rangeSum(const vector<long long>& prefix, int i, int j) {
    return prefix[j + 1] - prefix[i];
}
```

### Rust
```rust
/// Vec<i64> for prefix — avoid overflow on large sums. .scan() builds running prefix.
fn build_prefix(arr: &[i32]) -> Vec<i64> {
    let mut prefix = vec![0i64; arr.len() + 1];
    for i in 0..arr.len() {
        prefix[i + 1] = prefix[i] + arr[i] as i64;
    }
    prefix
}

fn range_sum(prefix: &[i64], i: usize, j: usize) -> i64 {
    prefix[j + 1] - prefix[i]
}

// Alternative: Iterator .scan() for running prefix (no explicit array)
fn prefix_scan(arr: &[i32]) -> impl Iterator<Item = i64> + '_ {
    std::iter::once(0).chain(
        arr.iter().scan(0i64, |acc, &x| {
            *acc += x as i64;
            Some(*acc)
        })
    )
}
```

**Rust Performance Note:** `Vec<i64>` avoids i32 overflow. `.scan(0i64, |acc, x| ...)` — iterator adapter for running prefix. `impl Iterator` = zero-cost abstraction.

---

## Template 2: Subarray Sum Equals K (Prefix + Hash Map)

### Python
```python
def subarray_sum_count(arr, k):
    prefix_count = {0: 1}  # CRITICAL: empty prefix
    prefix = 0
    count = 0
    for x in arr:
        prefix += x
        count += prefix_count.get(prefix - k, 0)
        prefix_count[prefix] = prefix_count.get(prefix, 0) + 1
    return count
```

### C++
```cpp
int subarraySumCount(const vector<int>& arr, int k) {
    unordered_map<int, int> prefixCount;
    prefixCount[0] = 1;  // CRITICAL
    int prefix = 0, count = 0;
    for (int x : arr) {
        prefix += x;
        count += prefixCount[prefix - k];
        prefixCount[prefix]++;
    }
    return count;
}
```

### Rust
```rust
/// HashMap for prefix sum + target pattern. entry().or_insert(0) for get-or-default.
use std::collections::HashMap;

fn subarray_sum_count(arr: &[i32], k: i32) -> i32 {
    let mut prefix_count: HashMap<i32, i32> = HashMap::new();
    prefix_count.insert(0, 1);  // CRITICAL: empty prefix
    let mut prefix = 0i32;
    let mut count = 0i32;

    for &x in arr {
        prefix += x;
        count += prefix_count.get(&(prefix - k)).copied().unwrap_or(0);
        *prefix_count.entry(prefix).or_insert(0) += 1;
    }
    count
}
```

**Rust Note:** `HashMap::entry(k).or_insert(0)` — get-or-insert in one lookup. `.get(&key).copied().unwrap_or(0)` — safe default for missing key.

---

## Template 3: 2D Prefix Sum (Matrix Region)

### Python
```python
def build_2d_prefix(matrix):
    if not matrix:
        return []
    r, c = len(matrix), len(matrix[0])
    prefix = [[0] * (c + 1) for _ in range(r + 1)]
    for i in range(r):
        for j in range(c):
            prefix[i + 1][j + 1] = (
                matrix[i][j]
                + prefix[i][j + 1]
                + prefix[i + 1][j]
                - prefix[i][j]
            )
    return prefix

def region_sum(prefix, r1, c1, r2, c2):
    """Sum of region [r1..r2] x [c1..c2] inclusive."""
    return (
        prefix[r2 + 1][c2 + 1]
        - prefix[r1][c2 + 1]
        - prefix[r2 + 1][c1]
        + prefix[r1][c1]
    )
```

### C++
```cpp
vector<vector<long long>> build2DPrefix(const vector<vector<int>>& matrix) {
    int r = matrix.size(), c = matrix[0].size();
    vector<vector<long long>> prefix(r + 1, vector<long long>(c + 1, 0));
    for (int i = 0; i < r; i++)
        for (int j = 0; j < c; j++)
            prefix[i + 1][j + 1] = matrix[i][j] + prefix[i][j + 1]
                + prefix[i + 1][j] - prefix[i][j];
    return prefix;
}

long long regionSum(const vector<vector<long long>>& prefix,
                    int r1, int c1, int r2, int c2) {
    return prefix[r2 + 1][c2 + 1] - prefix[r1][c2 + 1]
         - prefix[r2 + 1][c1] + prefix[r1][c1];
}
```

### Rust
```rust
/// Vec<Vec<i64>> for 2D prefix. Same inclusion-exclusion formula.
fn build_2d_prefix(matrix: &[Vec<i32>]) -> Vec<Vec<i64>> {
    let r = matrix.len();
    let c = matrix.first().map(|row| row.len()).unwrap_or(0);
    let mut prefix = vec![vec![0i64; c + 1]; r + 1];

    for i in 0..r {
        for j in 0..c {
            prefix[i + 1][j + 1] = matrix[i][j] as i64
                + prefix[i][j + 1]
                + prefix[i + 1][j]
                - prefix[i][j];
        }
    }
    prefix
}

fn region_sum(prefix: &[Vec<i64>], r1: usize, c1: usize, r2: usize, c2: usize) -> i64 {
    prefix[r2 + 1][c2 + 1] - prefix[r1][c2 + 1] - prefix[r2 + 1][c1] + prefix[r1][c1]
}
```

**Rust Note:** `matrix.first().map(|row| row.len()).unwrap_or(0)` — safe empty check. `vec![vec![0i64; c+1]; r+1]` — 2D vec init.

---

## Template 4: Prefix XOR

### Python
```python
def build_prefix_xor(arr):
    n = len(arr)
    prefix = [0] * (n + 1)
    for i in range(n):
        prefix[i + 1] = prefix[i] ^ arr[i]
    return prefix

def range_xor(prefix, i, j):
    return prefix[j + 1] ^ prefix[i]
```

### C++
```cpp
vector<int> buildPrefixXor(const vector<int>& arr) {
    int n = arr.size();
    vector<int> prefix(n + 1, 0);
    for (int i = 0; i < n; i++)
        prefix[i + 1] = prefix[i] ^ arr[i];
    return prefix;
}

int rangeXor(const vector<int>& prefix, int i, int j) {
    return prefix[j + 1] ^ prefix[i];
}
```

### Rust
```rust
/// XOR prefix: same structure as sum. i32 sufficient (no overflow for XOR).
fn build_prefix_xor(arr: &[i32]) -> Vec<i32> {
    let mut prefix = vec![0i32; arr.len() + 1];
    for i in 0..arr.len() {
        prefix[i + 1] = prefix[i] ^ arr[i];
    }
    prefix
}

fn range_xor(prefix: &[i32], i: usize, j: usize) -> i32 {
    prefix[j + 1] ^ prefix[i]
}
```

**Rust Note:** XOR doesn't overflow like sum — `i32` is fine. Same `prefix[j+1] ^ prefix[i]` formula.

---

## Template 5: Difference Array (Inverse of Prefix Sum)

**Use case:** Range updates (add v to [i..j]) in O(1), then recover array with one prefix pass.

### Python
```python
def range_add(diff, i, j, v):
    """Add v to arr[i..j]. diff has length n+1."""
    diff[i] += v
    diff[j + 1] -= v

def recover_array(diff, n):
    arr = [0] * n
    cur = 0
    for i in range(n):
        cur += diff[i]
        arr[i] = cur
    return arr
```

### C++
```cpp
void rangeAdd(vector<int>& diff, int i, int j, int v) {
    diff[i] += v;
    diff[j + 1] -= v;
}

vector<int> recoverArray(const vector<int>& diff, int n) {
    vector<int> arr(n);
    int cur = 0;
    for (int i = 0; i < n; i++) {
        cur += diff[i];
        arr[i] = cur;
    }
    return arr;
}
```

### Rust
```rust
/// Difference array: O(1) range add, O(n) recover via prefix over diff.
fn range_add(diff: &mut [i32], i: usize, j: usize, v: i32) {
    diff[i] += v;
    if j + 1 < diff.len() {
        diff[j + 1] -= v;
    }
}

fn recover_array(diff: &[i32], n: usize) -> Vec<i32> {
    let mut arr = vec![0i32; n];
    let mut cur = 0i32;
    for i in 0..n {
        cur += diff[i];
        arr[i] = cur;
    }
    arr
}
```

**Rust Note:** Bounds check `j + 1 < diff.len()` — diff may have length n+1. Recover is one prefix pass.

---

## Quick Reference Table

| Template | Build | Query/Update | Use Case |
|----------|-------|--------------|----------|
| 1D Prefix | O(n) | O(1) | Range sum queries |
| Prefix + Map | O(n) | — | Count subarrays sum=K |
| 2D Prefix | O(r×c) | O(1) | Matrix region sum |
| Prefix XOR | O(n) | O(1) | XOR subarrays |
| Difference Array | O(1) per update | O(n) recover | Range add updates |

---

## FINAL MEMORY COMPRESSION BLOCK

```
1D:     prefix[i+1] = prefix[i] + arr[i]
        sum(i..j) = prefix[j+1] - prefix[i]
MAP:    {0:1}, count += map[prefix-k], map[prefix]++
2D:     prefix[i+1][j+1] = M[i][j] + prefix[i][j+1] + prefix[i+1][j] - prefix[i][j]
        region = prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1]
XOR:    prefix[i+1] = prefix[i] ^ arr[i]
DIFF:   diff[i]+=v, diff[j+1]-=v; recover = prefix over diff
```

---

## Language Comparison Quick Reference

| Concept | Python | C++ | Rust |
|---------|--------|-----|------|
| Prefix array | `list` | `vector<long long>` | `Vec<i64>` |
| Hash map | `dict` | `unordered_map` | `HashMap<K,V>` |
| Get-or-default | `d.get(k, 0)` | `m[k]` (auto-0) | `.entry(k).or_insert(0)` |
| Running prefix | loop | loop | `.scan(0, \|acc,x\| ...)` |
| Overflow avoid | N/A | `long long` | `i64` / `Vec<i64>` |

---

## 30-SECOND REVISION BOX

```
1D:     prefix[i+1]=prefix[i]+arr[i]; sum=prefix[j+1]-prefix[i]
MAP:    {0:1}; count+=map[prefix-k]; map[prefix]++
2D:     +M[i][j]+prefix[i][j+1]+prefix[i+1][j]-prefix[i][j]
        region = -prefix[r1][c2+1]-prefix[r2+1][c1]+prefix[r1][c1]
XOR:    prefix[i+1]=prefix[i]^arr[i]; range=prefix[j+1]^prefix[i]
DIFF:   diff[i]+=v, diff[j+1]-=v; recover=prefix over diff
RUST:   Vec<i64>, HashMap entry API, .scan()
```
