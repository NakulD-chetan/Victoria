# CTE / Recursive CTE — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers regular CTEs, recursive hierarchy traversal, path building, and series generation. Sources: LeetCode, HackerRank, DataLemur.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Employees Earning More Than Managers | LC 181 | Easy | CTE + self-ref | Foundation for self-referencing queries |
| 2 | Department Top Three Salaries | LC 185 | Hard | CTE + window | CTE as clean wrapper for window logic |
| 3 | Tree Node | LC 608 | Medium | CTE + CASE | Classify root/inner/leaf in tree |
| 4 | Consecutive Numbers | LC 180 | Medium | CTE + LAG | CTE for multi-step logic |
| 5 | All People Report to Given Manager | LC 1270 | Medium | Recursive CTE | Direct recursive hierarchy |
| 6 | Employee Hierarchy Levels | HackerRank | Medium | Recursive + depth | Org chart with level tracking |
| 7 | Generate Date Series | Common Pattern | Medium | Recursive series | Generate rows where none exist |
| 8 | Find Root and Leaf Nodes | HackerRank | Medium | CTE + set logic | Tree structure analysis |
| 9 | Shortest Path in Graph | Advanced | Hard | Recursive + min | BFS/DFS in SQL |
| 10 | Category Breadcrumb Path | Common Pattern | Medium | Recursive + concat | Build full path string |

---

## Complete 20-Problem Progression

### Easy (Problems 1-5) — Regular CTE Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Employees Earning More Than Managers | LC 181 | CTE + join | CTE to name the manager lookup |
| 2 | Duplicate Emails | LC 182 | CTE + GROUP BY | CTE for clean grouping |
| 3 | Customers Who Never Order | LC 183 | CTE + anti-join | CTE-based NOT EXISTS |
| 4 | Combine Two Tables | LC 175 | CTE + LEFT JOIN | Named intermediate result |
| 5 | Second Highest Salary | LC 176 | CTE + ROW_NUMBER | CTE to isolate ranking logic |

### Medium (Problems 6-14) — CTE Patterns + Recursive Intro

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 6 | Tree Node | LC 608 | CTE + CASE | Classify nodes using parent/child refs |
| 7 | Consecutive Numbers | LC 180 | CTE + LAG | Chained CTEs for step-by-step logic |
| 8 | Department Top Three Salaries | LC 185 | CTE + DENSE_RANK | CTE wrapping window function |
| 9 | All People Report to Given Manager | LC 1270 | Recursive CTE | Walk org chart recursively |
| 10 | Employee Hierarchy Levels | HackerRank | Recursive + level | Track depth during traversal |
| 11 | Generate Date Series | Common | Recursive series | Anchor date + interval step |
| 12 | Category Breadcrumb Path | Common | Recursive + concat | String aggregation in recursion |
| 13 | Bill of Materials Explosion | Common | Recursive + multiply | Nested quantity calculation |
| 14 | Find All Ancestors of a Node | Common | Recursive upward | Walk UP the tree from leaf to root |

### Hard (Problems 15-20) — Advanced Recursive Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 15 | Shortest Path Between Two Nodes | Advanced | Recursive + BFS | Graph traversal in SQL |
| 16 | Detect Cycles in Hierarchy | Advanced | Recursive + array | Cycle detection via path tracking |
| 17 | Transitive Closure of a Graph | Advanced | Recursive | Find all reachable nodes |
| 18 | Fibonacci Sequence | Practice | Recursive + math | Classic recursion in SQL |
| 19 | Recursive Pivot — Flatten Tree | Advanced | Recursive + agg | Flatten hierarchy into columns |
| 20 | Find Longest Chain | Advanced | Recursive + MAX depth | Deepest path in a hierarchy |

---

## Problem-by-Problem Strategy Notes

### Problem 5: All People Report to Given Manager (LC 1270)

```
Pattern:     Recursive CTE — downward traversal
Approach:    Anchor: direct reports of manager_id = 1
             Recursive: join employees.manager_id = cte.id
             Filter: exclude the manager themselves
Key Insight: Each iteration adds one level deeper in org chart
One-liner:   Anchor at manager, recurse on manager_id = cte.id, collect all.
```

### Problem 10: Category Breadcrumb Path

```
Pattern:     Recursive CTE — upward traversal + string concat
Approach:    Anchor: root categories (parent_id IS NULL), path = name
             Recursive: join child.parent_id = cte.id, path = cte.path || ' > ' || child.name
Key Insight: Build the path string as you recurse down
One-liner:   Start at roots, concat name at each level, result is full breadcrumb.
```

### Problem 15: Shortest Path Between Two Nodes

```
Pattern:     Recursive CTE — BFS simulation
Approach:    Anchor: start node with distance = 0
             Recursive: join edges, distance + 1, track visited
             Final: filter target node, take MIN distance
Key Insight: First time target appears = shortest path (BFS guarantees this)
One-liner:   BFS via recursive CTE — expand neighbors, track depth, stop at target.
```

### Problem 16: Detect Cycles in Hierarchy

```
Pattern:     Recursive CTE — path tracking
Approach:    Anchor: root nodes, path = ARRAY[id]
             Recursive: join, check id != ALL(path) before adding
             Flag: if id = ANY(path) → cycle detected
Key Insight: PostgreSQL v14+ has built-in CYCLE detection
One-liner:   Track visited IDs in array; if next ID already in path, it's a cycle.
```

---

## Pattern Distribution

```
REGULAR CTE (named subquery):           8 problems  (1-8)
RECURSIVE — DOWNWARD traversal:         5 problems  (9-10, 13, 19-20)
RECURSIVE — UPWARD traversal:           2 problems  (12, 14)
RECURSIVE — SERIES generation:          2 problems  (11, 18)
RECURSIVE — GRAPH (BFS/DFS):            3 problems  (15-17)
```

---

## Study Plan

### Week 1: Regular CTE Foundation (Days 1-3)
- Day 1: LC 181, LC 182, LC 183 (basic CTE usage)
- Day 2: LC 176, LC 608 (CTE + window, CTE + CASE)
- Day 3: LC 180, LC 185 (chained CTEs, CTE + DENSE_RANK)

### Week 2: Recursive CTE (Days 4-7)
- Day 4: LC 1270, HackerRank Hierarchy (basic recursive)
- Day 5: Date series generation, Breadcrumb paths
- Day 6: Bill of Materials, Find all ancestors
- Day 7: Fibonacci, Flatten tree

### Week 3: Advanced + Review (Days 8-10)
- Day 8: Graph shortest path, cycle detection
- Day 9: Transitive closure, longest chain
- Day 10: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Hierarchy without recursion | Pattern 03 (Self Join) — limited to fixed depth |
| Fill missing dates | Pattern 11 (Date Series Fill) — uses recursive CTE |
| Window function cleanup | Pattern 01 (Window Functions) — CTE wraps the window |
| Graph traversal | Pattern 02 is the only SQL approach for arbitrary depth |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (5 Easy, 9 Medium, 6 Hard)
MUST-DO:            LC 181, 185, 608, 180, 1270 + HackerRank hierarchy
TOP 3 MOST ASKED:   LC 185 (Dept Top 3), LC 1270 (Reports), LC 608 (Tree Node)
CTE TYPES:          Regular (named subquery), Recursive (hierarchy/series/graph)
STUDY ORDER:        Regular CTE → Recursive down → Recursive up → Graph
KEY INSIGHT:        Recursive CTE = base case (anchor) + recursive step (UNION ALL)
INTERVIEW LINE:     "I use CTEs for readable multi-step queries and recursive
                     CTEs for hierarchy traversal — anchor + recursive step."
```

---

## 30-SECOND REVISION BOX

```
CTE:           WITH name AS (SELECT ...) — named subquery, reusable
RECURSIVE:     WITH RECURSIVE cte AS (anchor UNION ALL step)
ANCHOR:        Non-recursive starting rows (like base case)
STEP:          Joins cte to itself — expands one level per iteration
STOPS WHEN:    Recursive step returns 0 new rows
GUARD:         Always add WHERE depth < N to prevent infinite loop
CHAINING:      WITH a AS (...), b AS (SELECT ... FROM a) — pipelines
RULE:          CTE scope = single statement only; use temp table for session scope
```
