# Subqueries and CTE — Concept

> **Permanent recall:** **Subquery** = query nested in another. **CTE** (`WITH`) = named subquery for readability and reuse. **Correlated** subquery references outer row (row-by-row cost unless optimized).

---

## Subquery Definition

A **subquery** (inner query / nested query) is a SELECT statement embedded inside another SQL statement (SELECT, INSERT, UPDATE, DELETE, WHERE, HAVING, FROM).

---

## Types of Subqueries

| Type | Returns | Used with | Example |
|------|---------|-----------|---------|
| **Scalar** | Single value (1 row, 1 col) | `=`, `>`, `<` operators, SELECT list | `WHERE salary > (SELECT AVG(salary) FROM emp)` |
| **Row** | Single row, multiple cols | Row comparators | `WHERE (a, b) = (SELECT x, y FROM ...)` |
| **Multi-row** | Multiple rows, 1 col | `IN`, `ANY`, `ALL` | `WHERE id IN (SELECT id FROM ...)` |
| **Multi-column** | Multiple rows & cols | `IN` with tuples, FROM | `FROM (SELECT ... ) AS derived` |
| **Correlated** | References outer query columns | `EXISTS`, scalar in SELECT | Re-evaluated for each outer row |
| **Non-correlated** | Independent of outer query | `IN`, scalar | Evaluated once, result reused |

---

## Correlated vs Non-Correlated

| Feature | Non-Correlated | Correlated |
|---------|---------------|------------|
| **References outer query?** | No | Yes |
| **Execution** | Runs once, result cached | Runs once per outer row |
| **Performance** | Generally faster | Can be slow (O(n × m)) unless optimized |
| **Example** | `WHERE id IN (SELECT id FROM B)` | `WHERE EXISTS (SELECT 1 FROM B WHERE B.id = A.id)` |

---

## EXISTS vs IN

| Feature | EXISTS | IN |
|---------|--------|-----|
| **Returns** | TRUE/FALSE | Matches against list |
| **NULL handling** | NULL-safe (stops at first match) | `NOT IN` fails with NULLs in subquery |
| **Performance** | Good with correlated (short-circuits) | Good with small lists |
| **Anti-pattern** | `NOT EXISTS` (safe) | `NOT IN` (dangerous with NULLs) |

**Rule:** For anti-joins, always prefer `NOT EXISTS` over `NOT IN`.

---

## ANY / ALL / SOME

| Operator | Meaning |
|----------|---------|
| `= ANY (subquery)` | Same as `IN` |
| `> ANY (subquery)` | Greater than at least one value |
| `> ALL (subquery)` | Greater than every value |
| `SOME` | Synonym for `ANY` |

---

## CTE (Common Table Expression)

**Definition:** Named temporary result set defined with `WITH` clause. Exists only for the duration of the query. Improves readability by breaking complex queries into named steps.

```sql
WITH cte_name AS (
    SELECT ...
)
SELECT * FROM cte_name;
```

### CTE vs Subquery vs Temp Table vs View

| Feature | CTE | Subquery | Temp Table | View |
|---------|-----|----------|-----------|------|
| **Scope** | Single query only | Within enclosing query | Session / explicit drop | Permanent (until dropped) |
| **Reusable in same query** | Yes (reference multiple times) | No (must repeat) | Yes | Yes |
| **Stored on disk** | No (usually inline) | No | Yes (tempdb) | No (just saved query) |
| **Materialized** | Engine-dependent | Engine-dependent | Always (physical) | No (re-executed each time) |
| **Recursive** | Yes (`WITH RECURSIVE`) | No | No | No |
| **Readability** | Best | Worst (nesting) | Good | Good |
| **Performance** | Usually same as subquery | Same as CTE | Better for large intermediate results | Same as writing query directly |

---

## Recursive CTE

Used for hierarchical / tree data (org charts, categories, graphs).

```sql
WITH RECURSIVE org AS (
    -- Base case: top-level managers
    SELECT emp_id, name, manager_id, 1 AS level
    FROM employees WHERE manager_id IS NULL
    
    UNION ALL
    
    -- Recursive step: find reports
    SELECT e.emp_id, e.name, e.manager_id, o.level + 1
    FROM employees e
    JOIN org o ON e.manager_id = o.emp_id
)
SELECT * FROM org;
```

**Components:** Base case (anchor) + UNION ALL + Recursive step that references CTE itself.

> **Note:** SQL Server uses `WITH` (no RECURSIVE keyword). MySQL 8+ supports `WITH RECURSIVE`.

---

## Derived Table

A subquery in the `FROM` clause — creates an inline temporary table:

```sql
SELECT d.dept, d.avg_sal
FROM (
    SELECT dept_id AS dept, AVG(salary) AS avg_sal
    FROM employees GROUP BY dept_id
) d
WHERE d.avg_sal > 50000;
```

Must have an **alias** (the `d` above).

---

## When CTE shines

- Multi-step logic (pipeline of transformations)
- Same intermediate result used twice in one query
- Readability over deep nesting
- Recursive queries (org charts, path traversal)

---

*Next: [[02_Mental-Model]]*
