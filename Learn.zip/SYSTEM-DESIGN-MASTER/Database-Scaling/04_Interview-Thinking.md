# Database Scaling — Interview Thinking

> **Permanent Recall:** Discuss DB scaling only after identifying the bottleneck—don't lead with sharding. Introduce scaling in order: vertical → read replicas → caching → sharding (last resort). Explain consistent hashing as "keys and nodes on a ring; key goes to next node clockwise; adding a node affects only that arc." Discuss replication lag trade-offs: async for performance, sync for consistency. Always justify your choices with latency, throughput, or HA requirements.

---

## How to Discuss DB Scaling in Interviews

### Step 1: Identify the Bottleneck

**Don't say:** "Let's shard the database."

**Do say:** "First I'd understand the bottleneck. Is it reads, writes, or storage? What are the current and target QPS/latency? Then I'd consider vertical scaling, read replicas, and caching before sharding."

> **FAANG Tip:** Sharding is complex. Showing you consider simpler options first signals maturity.

---

## The Scaling Conversation Order

**Always present in this order:**

| Step | Action | When |
|------|--------|------|
| 1 | **Vertical scaling** | Bigger instance, more CPU/RAM |
| 2 | **Read replicas** | Read-heavy; route reads to replicas |
| 3 | **Caching** | Repeated reads, expensive queries |
| 4 | **Sharding** | Writes or storage still bottleneck |

**Interview line:** "We'd start with vertical scaling. If reads are the issue, add replicas and a cache. Sharding only when we've exhausted those options."

---

## When to Introduce Sharding

**Right moment:** After you've established:
- Current load (reads vs writes)
- Storage growth
- That replicas and caching aren't sufficient

**Wrong moment:** As the first scaling suggestion. Interviewers expect "sharding as last resort."

---

## How to Explain Consistent Hashing Clearly

**Structure:**
1. **Problem:** "With modulo, adding a node invalidates most keys."
2. **Idea:** "Map keys and nodes to a ring. Key goes to next node clockwise."
3. **Benefit:** "Adding a node only affects keys in that arc—minimal rehashing."
4. **Refinement:** "Virtual nodes (150-200 per physical node) for even distribution."

**One-liner:** "Keys and nodes on a circle. Each key belongs to the next node clockwise. Adding a node only moves keys in that arc."

---

## Discussing Replication Lag Trade-offs

| Question | Answer |
|----------|--------|
| Sync vs async? | "Async for read scaling and low write latency. Sync when we need strong consistency (e.g., financial)." |
| Stale reads? | "Replicas can lag. For critical reads (balance, payment), we'd read from master or use sync replica." |
| How much lag? | "Typically 10ms–500ms depending on load. We'd monitor replica lag and route critical reads to master." |

---

## Red Flags to Avoid

| Don't Say | Do Say |
|-----------|--------|
| "Let's shard" (first) | "Let's identify bottleneck, then vertical, replicas, cache, shard" |
| "We'll use random shard key" | "We'll choose user_id / order_id — high cardinality, matches query pattern" |
| "Replicas are always consistent" | "Async replicas have lag; we design for eventual consistency" |
| "Sharding is easy" | "Sharding adds complexity — cross-shard queries, joins, migrations" |

---

## Sample Interview Dialogue

**Interviewer:** "How would you scale a database for 1M users?"

**You:** "First I'd clarify: read-heavy or write-heavy? Let's say 100:1 reads. I'd start with vertical scaling—maybe we just need a bigger instance. Then add read replicas and route reads there. Add Redis for hot data. If writes or storage become the bottleneck, we'd consider sharding—splitting by user_id for even distribution. Sharding is last resort because it complicates queries and migrations."

**Interviewer:** "How does consistent hashing work?"

**You:** "We map both keys and nodes to a ring. When we need to find where a key lives, we go clockwise to the next node. Adding a node only affects keys in the arc before it—minimal data movement. We use virtual nodes so distribution stays even."

---

## Handling "Scale It" Follow-ups

**When asked to scale the database further:**

| Follow-up | Answer |
|-----------|--------|
| "Now 10× more reads" | Add more read replicas; consider caching layer |
| "Now 10× more writes" | Shard by primary key; consistent hashing for routing |
| "Storage is full" | Shard to split data; archive cold data |
| "Need multi-region" | Read replicas per region; or geo-sharding by region |
| "Single point of failure" | Replication + auto-failover; multi-AZ |

**Interview line:** "We'd add replicas for reads. For writes, we'd shard—splitting by user_id for even distribution. We'd use a proxy like Vitess for routing."

---

## Interview Flow: DB Scaling Discussion

```mermaid
flowchart TD
    A[Identify bottleneck] --> B{Read or Write?}
    B -->|Read| C[Vertical → Replicas → Cache]
    B -->|Write| D[Vertical → Shard]
    C --> E{Sufficient?}
    D --> E
    E -->|No| F[Introduce sharding]
    F --> G[Choose shard key]
    G --> H[Consistent hashing]
```

---

## Demonstrating Depth

**Topics to mention when relevant:**

| Topic | One-liner |
|-------|-----------|
| **Replication lag** | "Async replicas lag; we'd route critical reads to master." |
| **Hot shard** | "We'd monitor shard load; re-shard or add replicas for hot shard." |
| **Cross-shard** | "We'd avoid cross-shard transactions; design single-shard when possible." |
| **Migration** | "Dual-write, backfill, verify checksums, then switch reads." |
| **Connection pooling** | "We'd use PgBouncer or ProxySQL to avoid connection exhaustion." |

---

## 30-SECOND REVISION BOX

```
ORDER: Vertical → Replicas → Cache → Shard (last)
CONSISTENT HASH: Ring, next node clockwise, virtual nodes
REPLICATION LAG: Async = fast, stale | Sync = consistent, slow
JUSTIFY: Tie every choice to bottleneck (read/write/storage)
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
