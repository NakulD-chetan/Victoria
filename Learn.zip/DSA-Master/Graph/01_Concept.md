# Graph — Concept

> **Permanent Recall:** Graph = vertices + edges. Adjacency list (sparse) vs matrix (dense). BFS = level-by-level; DFS = go deep. Shortest path: BFS (unweighted), Dijkstra (non-negative weights), Bellman-Ford (negative OK). Topological sort = DAG ordering. FAANG tests graphs in ~25% of rounds — traversal, shortest path, scheduling, connectivity.

---

## Core Idea (2 Lines)

**Graph:** A set of vertices (nodes) connected by edges. Models relationships: social networks, maps, dependencies, state machines.

**Key dimensions:** Directed vs undirected; weighted vs unweighted; cyclic vs acyclic (DAG).

---

## Graph Types

| Type | Edges | Example |
|------|-------|---------|
| **Undirected** | A↔B (bidirectional) | Roads, friendships |
| **Directed** | A→B (one-way) | Dependencies, one-way streets |
| **Weighted** | Edge has cost | Distance, latency |
| **Unweighted** | All edges = 1 | Steps, hops |

```
Undirected:     A ——— B          Directed:     A ———> B
                |     |                         |      ^
                |     |                         v      |
                C ——— D                         C ———> D
```

---

## Representations

### Adjacency List (Preferred for Interview)

- **Space:** O(V + E)
- **Check edge (u,v):** O(degree(u))
- **Iterate neighbors:** O(degree(u))
- **Best for:** Sparse graphs (E << V²)

```python
# Python: list of lists or dict
adj = [[] for _ in range(n)]   # adj[u] = list of (v, weight) or just v
adj[u].append((v, w))
```

```cpp
// C++: vector of vectors
vector<vector<pair<int,int>>> adj(n);  // adj[u] = {(v, weight), ...}
adj[u].push_back({v, w});
```

### Adjacency Matrix

- **Space:** O(V²)
- **Check edge (u,v):** O(1)
- **Iterate neighbors:** O(V)
- **Best for:** Dense graphs, need O(1) edge lookup

```python
# Python: 2D list
matrix = [[0]*n for _ in range(n)]
matrix[u][v] = weight
```

```cpp
// C++
vector<vector<int>> matrix(n, vector<int>(n, 0));
matrix[u][v] = weight;
```

### When to Use Which

| Scenario | Use |
|----------|-----|
| Interview (default) | Adjacency list |
| Sparse graph | Adjacency list |
| Need O(1) edge check | Adjacency matrix |
| Dense graph, small V | Matrix OK |

---

## The Two Fundamental Traversals

### BFS (Breadth-First Search)

- **Mechanism:** Queue; explore level by level
- **Use:** Shortest path (unweighted), level-order, multi-source spread
- **Time:** O(V + E)

```
     A
    / \
   B   C
  / \   \
 D   E   F

BFS order: A → B → C → D → E → F (level 0, 1, 2)
```

### DFS (Depth-First Search)

- **Mechanism:** Stack (iterative) or recursion; go deep first
- **Use:** Path existence, cycles, topological sort, connected components
- **Time:** O(V + E)

```
     A
    / \
   B   C
  / \   \
 D   E   F

DFS order (preorder): A → B → D → E → C → F (go deep left first)
```

---

## Shortest Path Algorithms

| Algorithm | Graph Type | Weights | Time | Use Case |
|-----------|------------|---------|------|----------|
| **BFS** | Any | Unweighted (or unit) | O(V+E) | Unweighted shortest path |
| **Dijkstra** | Any | Non-negative only | O((V+E) log V) | Weighted, no negative edges |
| **Bellman-Ford** | Any | Any (incl. negative) | O(V×E) | Negative weights, detect negative cycle |

### BFS for Unweighted Shortest Path

- Each edge = 1 step
- First time we reach a node = shortest distance
- Track `dist[]` or use level in BFS

### Dijkstra (Greedy)

- Pick smallest unvisited distance; relax neighbors
- **Fails with negative weights** — can get stuck in negative cycle
- Requires: non-negative edge weights

### Bellman-Ford

- Relax all edges V-1 times
- If V-th relaxation still improves → negative cycle exists
- Slower but handles negative weights

---

## Topological Sort (DAG Only)

- **Definition:** Linear ordering of vertices such that for every edge u→v, u comes before v
- **Exists iff:** Graph is a DAG (no cycles)
- **Use:** Task scheduling, build order, prerequisite chains

```
DAG:    A → B → D
        ↓   ↓
        C → E

Topo order: A, B, C, D, E (one of many valid orders)
```

### Two Methods

| Method | Idea | Time |
|--------|------|------|
| **Kahn's (BFS)** | Start from nodes with in-degree 0; remove and update | O(V+E) |
| **DFS** | DFS, add to result when leaving (postorder reverse) | O(V+E) |

---

## Cycle Detection

| Graph Type | Method |
|------------|--------|
| **Directed** | DFS with 3 colors: white (unvisited), gray (in stack), black (done). Back edge to gray = cycle |
| **Undirected** | DFS + parent; if neighbor visited and ≠ parent → cycle |
| **Union-Find** | For undirected; if edge connects same component → cycle |

---

## Connected Components

- **Undirected:** Maximal subgraph where every pair is reachable
- **Find:** Run DFS/BFS from each unvisited node; each run = 1 component
- **Count:** Number of DFS/BFS starts = number of components

---

## When NOT to Use

| Algorithm | Don't Use When | Use Instead |
|-----------|-----------------|-------------|
| **Dijkstra** | Negative edge weights | Bellman-Ford |
| **BFS for shortest path** | Weighted graph | Dijkstra |
| **DFS for shortest path** | Unweighted graph | BFS (BFS gives shortest) |
| **Topological sort** | Graph has cycles | Cycle detection first |
| **Adjacency matrix** | Sparse, large V | Adjacency list |

---

## Golden Rules

1. **Default representation:** Adjacency list
2. **Unweighted shortest path:** BFS
3. **Weighted shortest path:** Dijkstra (if no negative edges)
4. **Negative weights:** Bellman-Ford
5. **Prerequisites/dependencies:** Topological sort (DAG)
6. **Cycle in directed:** DFS with 3-color
7. **Cycle in undirected:** DFS + parent check or Union-Find
8. **Connected components:** DFS/BFS from each unvisited
9. **Matrix as graph:** Cells = nodes, adjacent cells = edges (4 or 8 directions)

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph
CORE:               Vertices + edges; directed/undirected; weighted/unweighted
REPRESENTATION:     Adjacency list (default) vs matrix (dense, O(1) edge check)
BFS:                Queue; level-by-level; shortest path (unweighted)
DFS:                Stack/recursion; go deep; path, cycle, topo, components
SHORTEST PATH:      BFS (unweighted) | Dijkstra (non-neg) | Bellman-Ford (negative OK)
TOPOLOGICAL SORT:   DAG only; Kahn's BFS or DFS postorder reverse
CYCLE:              Directed: DFS 3-color | Undirected: DFS+parent or Union-Find
WHEN NOT:           Dijkstra + negative | BFS + weighted | Topo + cycle
INTERVIEW LINE:     "I'll model this as a graph. Nodes are X, edges are Y.
                     For shortest path I'll use BFS/Dijkstra because..."
```
