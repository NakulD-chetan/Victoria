import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const N = 5;
const ADJ = [
  [1, 1, 0, 0, 1],
  [1, 1, 1, 0, 0],
  [0, 1, 1, 1, 0],
  [0, 0, 1, 1, 1],
  [1, 0, 0, 1, 1],
];

function generateSteps() {
  const steps = [];
  const path = [];

  function dfs(v) {
    path.push(v);
    steps.push({
      type: 'visit',
      v,
      path: [...path],
      msg: `Path length ${path.length}, at node ${v}`,
    });
    if (path.length === N) {
      const closes = ADJ[v][path[0]] === 1;
      steps.push({
        type: closes ? 'done' : 'fail',
        v,
        path: [...path],
        msg: closes ? 'Edge back to start — Hamiltonian cycle' : 'Cannot close cycle',
      });
      path.pop();
      return closes;
    }
    for (let u = 0; u < N; u++) {
      if (ADJ[v][u] !== 1) continue;
      if (path.includes(u)) continue;
      if (dfs(u)) return true;
    }
    path.pop();
    steps.push({
      type: 'back',
      v,
      path: [...path],
      msg: 'Backtrack',
    });
    return false;
  }

  steps.push({ type: 'start', msg: 'Find cycle visiting each node once', path: [] });
  dfs(0);
  return steps;
}

function paint(step) {
  const cols = N;
  const rows = 1;
  const cellColors = {};
  const cellValues = {};
  const grid = [Array(cols).fill('empty')];
  for (let j = 0; j < cols; j++) {
    cellValues[`0-${j}`] = String(j);
    cellColors[`0-${j}`] = 'empty';
  }
  (step.path || []).forEach((nodeId, idx) => {
    const key = `0-${nodeId}`;
    cellColors[key] = idx === (step.path?.length || 0) - 1 ? 'exploring' : 'path';
  });
  return {
    size: rows,
    cols,
    grid,
    cellColors,
    cellValues,
    path: (step.path || []).map((nodeId) => [0, nodeId]),
  };
}

export default function HamiltonianCycleVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: '5-node graph (path on node row)' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'back') canvasRef.current?.addAnim('backtrack', { r: 0, c: step.v }, 280);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
