# How AirTags Work - In Depth (Easy Language)

> Companion to: [20-How-AirTags-Work.md](20-How-AirTags-Work.md)

---

## The Core Constraint: No GPS, No WiFi, No Cellular

An AirTag is a tiny device with:
- A coin cell battery (must last 1+ year)
- A Bluetooth chip
- NO GPS (too much power)
- NO WiFi (no antenna)
- NO cellular (no SIM card)

**So how does it know where it is?** The answer: **it doesn't.** Other people's iPhones figure that out.

---

## The Crowdsourced Location Network

### The Big Idea

There are **over 1 billion active iPhones** worldwide. Each one is a potential location relay for your AirTag, without the iPhone owner knowing or being affected.

```
YOUR AirTag (lost in a park in Mumbai):
  → Broadcasts a signal via Bluetooth every ~2 seconds
  → "I exist! My public key is: abc123..."

STRANGER'S iPhone (walking through the park):
  → Picks up the Bluetooth signal
  → "I received a broadcast from an AirTag"
  → Encrypts ITS OWN location using the AirTag's public key
  → Uploads encrypted location to Apple servers

YOUR iPhone (at home):
  → Downloads encrypted data from Apple
  → Decrypts with YOUR private key
  → "My AirTag was at this park 10 minutes ago!"
```

### The Privacy Magic

This is the brilliant part:

```
Who knows what:

YOUR AirTag:        Only knows its own public key
                    Does NOT know where it is
                    
STRANGER'S iPhone:  Knows the AirTag's public key (from Bluetooth)
                    Knows its OWN location
                    Encrypts location with public key
                    CANNOT read the encrypted data
                    
APPLE SERVERS:      Receive encrypted blobs
                    Do NOT have the private key
                    CANNOT decrypt the data
                    Don't know whose AirTag it is
                    
YOUR iPhone:        Has the private key
                    Downloads encrypted data
                    DECRYPTS → sees location
                    ONLY one who can read it!
```

**Nobody except YOU can see where your AirTag is.** Not Apple, not the stranger, not hackers who breach Apple's servers.

---

## The Cryptography - How It Works Step by Step

### Setup (One-Time)

```
Step 1: Generate a key pair (elliptic curve cryptography)
  Public key:  "abc123..." (can be shared with anyone)
  Private key: "xyz789..." (NEVER leaves your iPhone/iCloud)

Step 2: Share the public key
  → AirTag gets: public key
  → Your iCloud account gets: both keys (public + private)
  
  The AirTag NEVER has the private key!
```

### Broadcasting (Every 2 Seconds)

```
AirTag:
  *BLE broadcast* → "Public key: abc123..."
  
  That's it. Nothing else.
  No location, no name, no owner info.
  Just the public key.
  
  Power consumption: tiny (BLE is designed for ultra-low power)
  Battery life: 1+ year on a CR2032 coin cell
```

### Relay (Stranger's iPhone Does the Work)

```
Stranger's iPhone (running in background, no user interaction):
  1. Receives BLE broadcast: "Public key: abc123..."
  2. Gets its OWN current location: (19.076°N, 72.877°E)
  3. Encrypts the location:
     encrypted_data = encrypt(location, public_key="abc123...")
     → Produces unreadable gibberish: "8f3a2b7c1d9e..."
  4. Uploads to Apple servers via HTTP:
     { airtag_public_key_hash: "abc...", encrypted_location: "8f3a2b7c..." }
  5. Stranger's iPhone forgets everything (no storage)
```

**The stranger never knows:**
- Who owns the AirTag
- What the AirTag is attached to
- The decrypted location data
- That they even relayed anything (happens silently in background)

### Retrieval (Your iPhone Finds It)

```
Your iPhone:
  1. Queries Apple servers: "Any data for public key hash abc...?"
  2. Apple returns: { encrypted_location: "8f3a2b7c...", timestamp: "10:42 AM" }
  3. Decrypts with private key:
     location = decrypt("8f3a2b7c...", private_key="xyz789...")
     → (19.076°N, 72.877°E)
  4. Shows on map: "Your AirTag was here 10 minutes ago"
```

---

## Two Modes of Finding

### Mode 1: Owner's iPhone Is Nearby (Direct)

```
AirTag ←──BLE──→ Your iPhone (within ~10-30 meters)
  
  Direct Bluetooth connection
  → Precision finding with Ultra Wideband (UWB)
  → "Your AirTag is 2.3 meters to your left"
  → Direction arrow on screen
  → Works in real-time
```

UWB (Ultra Wideband) gives centimeter-level precision for direction and distance. This is the "find my keys under the couch" scenario.

### Mode 2: Owner's iPhone Is Far (Crowdsourced)

```
AirTag (lost in another city) ←──BLE──→ Any nearby iPhone
  → Encrypted location relayed to Apple
  → You see approximate location on map
  → Not real-time (updates whenever an iPhone passes by)
  → Accuracy depends on how many iPhones are nearby
```

In a busy city: updates every few minutes (lots of iPhones passing by)
In a rural area: might take hours (few iPhones around)

---

## Why This Design Is Genius

### No Subscription, No SIM Card

```
GPS tracker (e.g., Tile Pro with GPS):
  → Needs cellular modem + SIM card
  → Monthly subscription ($5-15/month)
  → Battery dies in days (GPS + cellular = power hungry)
  → Range limited to cellular coverage

AirTag:
  → No cellular needed (uses other people's phones!)
  → No subscription (free after purchase)
  → Battery lasts 1+ year (BLE = ultra-low power)
  → Works anywhere there are iPhones (basically everywhere)
```

### Network Effect

The more iPhones Apple sells, the better AirTags work. Every new iPhone is another potential relay point. With 1+ billion active iPhones, the coverage is incredible -- especially in urban areas.

---

## Anti-Stalking Protections

Apple knows AirTags could be misused (hiding one in someone's bag). Protections:

```
1. Unknown AirTag traveling with you:
   → Your iPhone detects: "An AirTag not registered to you has been 
      near you for an extended time"
   → Notification: "AirTag Found Moving With You"

2. AirTag separated from owner for 3 days:
   → AirTag starts beeping (audible alert)
   → Forces discovery even without an iPhone

3. Manual scan:
   → Android users can use "Tracker Detect" app
   → Scan for unknown AirTags nearby
```

---

## Revision Flashcards

**Q: How does an AirTag know where it is without GPS?**
A: It doesn't! It broadcasts a public key via Bluetooth. Nearby strangers' iPhones encrypt THEIR location with that key and upload to Apple. The owner's iPhone downloads and decrypts to see the location.

**Q: Why can't Apple see your AirTag's location?**
A: End-to-end encryption. Location data is encrypted with the AirTag's public key. Only the owner's private key (on their iPhone/iCloud) can decrypt it. Apple only stores encrypted blobs they can't read.

**Q: Why does the AirTag battery last 1+ year?**
A: It only uses BLE (Bluetooth Low Energy) which requires minimal power. No GPS, no WiFi, no cellular -- all of which drain batteries fast. BLE broadcasting every 2 seconds uses microwatts.

**Q: What's the difference between nearby and far-away finding?**
A: Nearby: direct Bluetooth/UWB connection with your iPhone, real-time precision direction. Far away: crowdsourced via strangers' iPhones relaying encrypted location to Apple servers. Less precise, not real-time.

**Q: How does Apple prevent AirTag stalking?**
A: Unknown AirTags traveling with you trigger iPhone notifications. AirTags separated from their owner for 3+ days start beeping. Android users can use the "Tracker Detect" app.
