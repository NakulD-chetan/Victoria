import { useState, useCallback, useRef, memo, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { WIDGET_DIMS } from './widgetLibrary';
import { CANVAS_Z } from './stacking';
import { useForwardWheelToCanvas } from './useForwardWheelToCanvas';

const LANGS = [
  { id: 'cpp',        label: 'C++ 17' },
  { id: 'python',     label: 'Python 3' },
  { id: 'java',       label: 'Java' },
  { id: 'javascript', label: 'JavaScript' },
];

const LANG_MONACO = { cpp: 'cpp', python: 'python', java: 'java', javascript: 'javascript' };

const TEMPLATES = {
  cpp: `#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n)) return 0;

    long long ans = 0;
    for (int i = 0; i < n; i++) {
        int x; cin >> x;
        ans += x;
    }

    cout << ans << "\\n";
    return 0;
}
`,
  python: `def solve():
    import sys
    data = list(map(int, sys.stdin.read().strip().split()))
    if not data:
        return
    n, *arr = data
    print(sum(arr[:n]))


if __name__ == "__main__":
    solve()
`,
  java: `import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
        FastScanner fs = new FastScanner(System.in);
        int n = fs.nextInt();
        long ans = 0;
        for (int i = 0; i < n; i++) ans += fs.nextInt();
        System.out.println(ans);
    }

    static class FastScanner {
        private final InputStream in;
        private final byte[] buffer = new byte[1 << 16];
        private int ptr = 0, len = 0;
        FastScanner(InputStream in) { this.in = in; }
        int read() throws IOException {
            if (ptr >= len) {
                len = in.read(buffer);
                ptr = 0;
                if (len <= 0) return -1;
            }
            return buffer[ptr++];
        }
        int nextInt() throws IOException {
            int c; do { c = read(); } while (c <= ' ' && c != -1);
            int sign = 1; if (c == '-') { sign = -1; c = read(); }
            int val = 0;
            while (c > ' ') { val = val * 10 + (c - '0'); c = read(); }
            return val * sign;
        }
    }
}
`,
  javascript: `const fs = require("fs");
const data = fs.readFileSync(0, "utf8").trim().split(/\\s+/).map(Number);
if (data.length) {
  const n = data[0];
  const arr = data.slice(1, 1 + n);
  const ans = arr.reduce((a, b) => a + b, 0);
  console.log(ans);
}
`,
};

const MONACO_PATH_EXT = { cpp: 'cpp', python: 'py', java: 'java', javascript: 'js' };

const CPP_HEADER_SUGGESTIONS = [
  'bits/stdc++.h', 'algorithm', 'array', 'bitset', 'cassert', 'cmath', 'deque',
  'functional', 'iomanip', 'iostream', 'limits', 'map', 'numeric', 'queue',
  'set', 'stack', 'string', 'unordered_map', 'unordered_set', 'utility', 'vector',
];

const CPP_SNIPPETS = [
  {
    label: 'cp-main',
    insertText: [
      '#include <bits/stdc++.h>',
      'using namespace std;',
      '',
      'int main() {',
      '\tios::sync_with_stdio(false);',
      '\tcin.tie(nullptr);',
      '',
      '\t${1}',
      '',
      '\treturn 0;',
      '}',
    ].join('\n'),
    documentation: 'Competitive programming main template',
  },
  {
    label: 'fori',
    insertText: 'for (int ${1:i} = 0; ${1:i} < ${2:n}; ${1:i}++) {\n\t${3}\n}',
    documentation: 'Indexed for loop',
  },
  {
    label: 'all',
    insertText: 'begin(${1:container}), end(${1:container})',
    documentation: 'STL iterator pair',
  },
  {
    label: 'vec',
    insertText: 'vector<${1:int}> ${2:name}(${3:n});',
    documentation: 'Vector declaration',
  },
];

let monacoConfigured = false;

function configureMonaco(monaco) {
  if (monacoConfigured) return;
  monacoConfigured = true;

  monaco.languages.registerCompletionItemProvider('cpp', {
    triggerCharacters: ['<', '"', '.', ':', '#'],
    provideCompletionItems(model, position) {
      const line = model.getLineContent(position.lineNumber);
      const beforeCursor = line.slice(0, position.column - 1);
      const word = model.getWordUntilPosition(position);
      const range = {
        startLineNumber: position.lineNumber,
        endLineNumber: position.lineNumber,
        startColumn: word.startColumn,
        endColumn: word.endColumn,
      };

      if (/^\s*#include\s*[<"][^>"]*$/.test(beforeCursor)) {
        return {
          suggestions: CPP_HEADER_SUGGESTIONS.map((header) => ({
            label: header,
            kind: monaco.languages.CompletionItemKind.Module,
            insertText: header,
            range,
            detail: 'C++ standard header',
          })),
        };
      }

      return {
        suggestions: CPP_SNIPPETS.map((snippet) => ({
          label: snippet.label,
          kind: monaco.languages.CompletionItemKind.Snippet,
          insertText: snippet.insertText,
          insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          documentation: snippet.documentation,
          detail: 'C++ snippet',
          range,
        })),
      };
    },
  });
}

const MIN = WIDGET_DIMS.compiler;
const BASE_W = WIDGET_DIMS.compiler.w;
const BASE_FONT = 12;
const BASE_HEADER = 32;
const DRAG_THRESHOLD_PX = 4;

/** Stop event from bubbling to Excalidraw; do not use stopImmediatePropagation on keys or Monaco breaks (Ctrl+A, Delete). */
function stopBubble(e) {
  e.stopPropagation();
}

const IconPlay = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <path d="M8 5v14l11-7-11-7z" />
  </svg>
);

const IconSquare = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <rect x="6" y="6" width="12" height="12" rx="1.5" />
  </svg>
);

const IconChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <polyline points="6 9 12 15 18 9" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconChevronUp = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <polyline points="18 15 12 9 6 15" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconRotateCcw = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <path d="M3 12a9 9 0 1 0 3-7.5L3 8" />
    <path d="M3 3v5h5" />
  </svg>
);

const IconX = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const IconCaretDown = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <polyline points="6 9 12 15 18 9" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/** Custom dropdown so open state matches app UI (native select open list cannot be styled). */
function CwLangPicker({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);
  const label = LANGS.find((l) => l.id === value)?.label ?? value;

  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => {
      if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', onDoc, true);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc, true);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  return (
    <div className={`cw-lang-picker${open ? ' cw-lang-picker--open' : ''}`} ref={rootRef}>
      <button
        type="button"
        className={`cw-lang-picker__trigger${open ? ' cw-lang-picker__trigger--open' : ''}`}
        onClick={(e) => {
          e.stopPropagation();
          setOpen((o) => !o);
        }}
        onMouseDown={(e) => e.stopPropagation()}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label="Language"
      >
        <span className="cw-lang-picker__value">{label}</span>
        <span className="cw-lang-picker__caret" aria-hidden>
          <IconCaretDown />
        </span>
      </button>
      {open && (
        <ul className="cw-lang-picker__menu" role="listbox">
          {LANGS.map((l) => (
            <li key={l.id} role="presentation">
              <button
                type="button"
                role="option"
                aria-selected={value === l.id}
                className={`cw-lang-picker__option${value === l.id ? ' cw-lang-picker__option--active' : ''}`}
                onMouseDown={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  onChange(l.id);
                  setOpen(false);
                }}
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function CompilerWidgetOverlay({
  widgetGroups, viewport, canvasOffset = { x: 0, y: 0 },
  selectedWidgetId, onSelectWidget,
  onMove, onResize, onMoveResize, onUpdateData, onDelete, theme,
  activeTool = 'selection',
}) {
  const entries = [];
  for (const [id, info] of widgetGroups) {
    if (info.type === 'compiler') entries.push({ id, ...info });
  }
  if (entries.length === 0) return null;
  const { zoom, scrollX, scrollY } = viewport;

  return (
    <>
      {entries.map((entry) => (
        <CompilerPanel
          key={entry.id}
          id={entry.id}
          data={entry.data}
          worldX={entry.worldX}
          worldY={entry.worldY}
          w={entry.w}
          h={entry.h}
          screenX={canvasOffset.x + (entry.worldX + scrollX) * zoom}
          screenY={canvasOffset.y + (entry.worldY + scrollY) * zoom}
          zoom={zoom}
          theme={theme}
          onMove={onMove}
          onResize={onResize}
          onMoveResize={onMoveResize}
          onUpdateData={onUpdateData}
          onDelete={onDelete}
          isSelected={entry.id === selectedWidgetId}
          onSelectWidget={onSelectWidget}
          activeTool={activeTool}
        />
      ))}
    </>
  );
}

const CompilerPanel = memo(function CompilerPanel({
  id, data, worldX, worldY, w, h, screenX, screenY, zoom, theme,
  onMove, onResize, onMoveResize, onUpdateData, onDelete,
  isSelected, onSelectWidget,
  activeTool = 'selection',
}) {
  /* When a drawing/shape tool is active in Excalidraw, the widget must be
   * fully transparent to pointer events so the user can draw / highlight
   * straight through it (just like a regular shape). Only when the Selection
   * tool is active should the header drag, resize, and editor focus work. */
  const isInteractive = activeTool === 'selection';
  const interactivePE = isInteractive ? 'auto' : 'none';
  const [language, setLanguage] = useState(data.language || 'cpp');
  const [code, setCode] = useState(data.code || TEMPLATES[data.language || 'cpp']);
  const [output, setOutput] = useState(data.output || '');
  const [isRunning, setIsRunning] = useState(false);
  const [showOutput, setShowOutput] = useState(!!data.output);
  const [runStatus, setRunStatus] = useState('');
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const abortRef = useRef(null);
  const codeRef = useRef(code);
  const editorRef = useRef(null);
  const rootRef = useRef(null);
  codeRef.current = code;

  /* Forward trackpad/wheel gestures to the Excalidraw canvas so panning works
   * even when the cursor is over the editor / output (overlays are DOM
   * siblings of <Excalidraw/>, so events would otherwise never reach it). */
  useForwardWheelToCanvas(rootRef);

  const sizeRatio = Math.max(0.6, Math.min(2, w / BASE_W));
  const fontSize = Math.max(11, Math.round(BASE_FONT * sizeRatio));
  const headerH = 36;
  const outputH = Math.max(72, Math.round(100 * sizeRatio));
  const proxyStyle = data.proxyStyle || {};
  const borderRadius = proxyStyle.roundness ? 8 : 0;
  const shellStyle = {
    borderColor: proxyStyle.strokeColor,
    borderWidth: proxyStyle.strokeWidth,
    borderStyle: proxyStyle.strokeStyle === 'dashed' ? 'dashed' : proxyStyle.strokeStyle === 'dotted' ? 'dotted' : 'solid',
    backgroundColor: proxyStyle.backgroundColor && proxyStyle.backgroundColor !== 'transparent' ? proxyStyle.backgroundColor : undefined,
    opacity: proxyStyle.opacity != null ? Math.max(0.2, proxyStyle.opacity / 100) : undefined,
    borderRadius,
  };
  const headerStyle = {
    borderBottomColor: proxyStyle.strokeColor || undefined,
    borderTopLeftRadius: borderRadius,
    borderTopRightRadius: borderRadius,
  };

  const saveData = useCallback((updates) => {
    onUpdateData(id, {
      code: updates.code ?? codeRef.current,
      language: updates.language ?? language,
      output: updates.output ?? output,
    });
  }, [id, onUpdateData, language, output]);

  const handleCodeChange = useCallback((val) => {
    setCode(val || '');
    codeRef.current = val || '';
    saveData({ code: val || '' });
  }, [saveData]);

  const handleLangChange = useCallback((lang) => {
    setLanguage(lang);
    const newCode = TEMPLATES[lang];
    setCode(newCode);
    codeRef.current = newCode;
    setOutput('');
    setShowOutput(false);
    setRunStatus('');
    saveData({ language: lang, code: newCode, output: '' });
  }, [saveData]);

  const handleRun = useCallback(async () => {
    if (isRunning) { abortRef.current?.abort(); return; }
    setIsRunning(true);
    setShowOutput(true);
    setOutput('Running...');
    setRunStatus('Running...');
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const res = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code: codeRef.current, language, stdin: '' }),
        signal: controller.signal,
      });
      if (!res.ok) throw new Error(`Server error (${res.status})`);
      const result = await res.json();
      let out = '';
      if (result.compile_output) out += result.compile_output;
      if (result.stdout) out += result.stdout;
      if (result.stderr) out += (out ? '\n' : '') + result.stderr;
      if (!out && result.error) out = result.error;
      if (!out) out = 'No output';
      setOutput(out);
      setRunStatus(out.startsWith('Error') || out.startsWith('Compile') ? 'Error' : 'Done');
      saveData({ output: out });
    } catch (err) {
      if (err.name !== 'AbortError') {
        setOutput('Error: ' + err.message);
        setRunStatus('Error');
        saveData({ output: 'Error: ' + err.message });
      }
    } finally {
      setIsRunning(false);
      abortRef.current = null;
    }
  }, [isRunning, language, saveData]);

  const handleHeaderMouseDown = useCallback((e) => {
    if (e.target.closest('select, button')) return;
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startMY = e.clientY;
    const startWX = worldX;
    const startWY = worldY;
    let dragStarted = false;
    const move = (ev) => {
      if (!dragStarted) {
        if (Math.abs(ev.clientX - startMX) < DRAG_THRESHOLD_PX && Math.abs(ev.clientY - startMY) < DRAG_THRESHOLD_PX) return;
        dragStarted = true;
        setIsDragging(true);
      }
      onMove(id, startWX + (ev.clientX - startMX) / zoom, startWY + (ev.clientY - startMY) / zoom);
    };
    const up = () => {
      if (!dragStarted) onSelectWidget?.(id);
      setIsDragging(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [id, worldX, worldY, zoom, onMove, onSelectWidget]);

  const handleResizeMouseDown = useCallback((e, edge) => {
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startMY = e.clientY;
    const startW = w;
    const startH = h;
    const startWX = worldX;
    const startWY = worldY;
    setIsResizing(true);
    const move = (ev) => {
      const dx = (ev.clientX - startMX) / zoom;
      const dy = (ev.clientY - startMY) / zoom;
      let nW = startW, nH = startH, nWX = startWX, nWY = startWY;
      if (edge.includes('e')) nW = Math.max(MIN.minW, startW + dx);
      if (edge.includes('w')) { nW = Math.max(MIN.minW, startW - dx); nWX = startWX + (startW - nW); }
      if (edge.includes('s')) nH = Math.max(MIN.minH, startH + dy);
      if (edge.includes('n')) { nH = Math.max(MIN.minH, startH - dy); nWY = startWY + (startH - nH); }
      if (nWX !== startWX || nWY !== startWY) {
        onMoveResize(id, nWX, nWY, nW, nH);
      } else {
        onResize(id, nW, nH);
      }
    };
    const up = () => {
      setIsResizing(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [id, w, h, worldX, worldY, zoom, onResize, onMoveResize]);

  const handleDelete = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    onDelete(id);
  }, [id, onDelete]);

  const showEditor = zoom >= 0.3;
  const editorH = showOutput ? Math.max(h - headerH - outputH, 60) : h - headerH;
  const statusColor = runStatus === 'Error' ? '#ef4444' : runStatus ? '#22c55e' : '#a8a29e';
  const editorPath = `inmemory://model/${id}.${MONACO_PATH_EXT[language] || 'txt'}`;

  const handleEditorMount = useCallback((editor, monaco) => {
    editorRef.current = editor;
    configureMonaco(monaco);
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Space, () => {
      editor.getAction('editor.action.triggerSuggest')?.run();
    });
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.Slash, () => {
      editor.getAction('editor.action.commentLine')?.run();
    });
    editor.addCommand(monaco.KeyMod.Shift | monaco.KeyMod.Alt | monaco.KeyCode.KeyF, () => {
      editor.getAction('editor.action.formatDocument')?.run();
    });
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyK, () => {
      editor.getAction('editor.action.deleteLines')?.run();
    });
    editor.updateOptions({
      suggest: {
        preview: true,
        showSnippets: true,
        showWords: true,
        localityBonus: true,
        snippetsPreventQuickSuggestions: false,
        selectionMode: 'whenQuickSuggestion',
        showInlineDetails: true,
      },
    });
  }, []);

  return (
    <div
      ref={rootRef}
      className={`cw-overlay${isSelected ? ' cw-overlay--selected' : ''}${isDragging ? ' cw-overlay--dragging' : ''}${isResizing ? ' cw-overlay--resizing' : ''}`}
      style={{
        position: 'absolute',
        left: screenX,
        top: screenY,
        width: w,
        height: h,
        transform: `scale(${zoom})`,
        transformOrigin: 'top left',
        pointerEvents: 'none',
        zIndex: CANVAS_Z.WIDGETS,
        willChange: 'transform',
        ...shellStyle,
      }}
      onKeyDown={stopBubble}
      onKeyUp={stopBubble}
    >
      <div
        className="cw-header cw-header--ft"
        style={{ pointerEvents: interactivePE, minHeight: headerH, height: headerH, fontSize: Math.max(11, Math.round(11 * sizeRatio)), ...headerStyle }}
        onMouseDown={handleHeaderMouseDown}
      >
        <CwLangPicker value={language} onChange={handleLangChange} />
        <span className="ft-actions__sep" aria-hidden />
        <button
          type="button"
          className={`cw-toolbar__run${isRunning ? ' cw-toolbar__run--stop' : ''}`}
          onClick={handleRun}
          onMouseDown={(e) => e.stopPropagation()}
          title={isRunning ? 'Stop' : 'Run'}
          aria-label={isRunning ? 'Stop' : 'Run'}
        >
          {isRunning ? <><IconSquare /> Stop</> : <><IconPlay /> Run</>}
        </button>
        <button
          type="button"
          className="ft-actions__btn"
          onClick={() => setShowOutput(!showOutput)}
          onMouseDown={(e) => e.stopPropagation()}
          title={showOutput ? 'Hide output' : 'Show output'}
          aria-label={showOutput ? 'Hide output' : 'Show output'}
        >
          {showOutput ? <IconChevronDown /> : <IconChevronUp />}
        </button>
        <button
          type="button"
          className="ft-actions__btn"
          onClick={() => {
            const tpl = TEMPLATES[language] || '';
            setCode(tpl);
            codeRef.current = tpl;
            setOutput('');
            setRunStatus('');
            saveData({ code: tpl, output: '' });
          }}
          onMouseDown={(e) => e.stopPropagation()}
          title="Reset to template"
          aria-label="Reset to template"
        >
          <IconRotateCcw />
        </button>
        <div className="cw-toolbar-spacer" aria-hidden />
        <span className="cw-status-inline" style={{ color: statusColor }}>
          <span className="cw-status-inline__dot" style={{ background: statusColor }} aria-hidden />
          {runStatus || 'Idle'}
        </span>
        <button
          type="button"
          className="ft-actions__btn cw-toolbar__close"
          onClick={handleDelete}
          onMouseDown={(e) => e.stopPropagation()}
          title="Remove widget"
          aria-label="Remove widget"
        >
          <IconX />
        </button>
      </div>

      <div
        className="cw-editor-area"
        style={{ height: editorH, pointerEvents: interactivePE }}
        onPointerDown={(e) => { stopBubble(e); onSelectWidget?.(id); }}
        onMouseDown={stopBubble}
        onClick={stopBubble}
        onKeyDown={stopBubble}
        onKeyUp={stopBubble}
      >
        {showEditor ? (
          <Editor
            height="100%"
            language={LANG_MONACO[language]}
            path={editorPath}
            theme={theme === 'dark' ? 'vs-dark' : 'light'}
            value={code}
            onChange={handleCodeChange}
            beforeMount={configureMonaco}
            onMount={handleEditorMount}
            options={{
              minimap: { enabled: false },
              fontSize,
              lineNumbers: 'on',
              scrollBeyondLastLine: false,
              wordWrap: 'off',
              tabSize: 4,
              automaticLayout: true,
              fixedOverflowWidgets: true,
              padding: { top: Math.round(6 * sizeRatio) },
              renderLineHighlight: 'line',
              overviewRulerBorder: false,
              hideCursorInOverviewRuler: true,
              scrollbar: { verticalScrollbarSize: 6, horizontalScrollbarSize: 6 },
              lineHeight: Math.max(17, Math.round(18 * sizeRatio)),
              /*
               * Let wheel events bubble so trackpad two-finger panning can move the
               * canvas even when the cursor is over the editor.
               */
              alwaysConsumeMouseWheel: false,
              quickSuggestions: { other: true, comments: false, strings: true },
              quickSuggestionsDelay: 70,
              suggestOnTriggerCharacters: true,
              acceptSuggestionOnEnter: 'smart',
              acceptSuggestionOnCommitCharacter: true,
              tabCompletion: 'on',
              wordBasedSuggestions: 'currentDocument',
              suggestSelection: 'recentlyUsedByPrefix',
              matchOnWordStartOnly: false,
              parameterHints: { enabled: true },
              snippetSuggestions: 'top',
              inlineSuggest: { enabled: true },
              smoothScrolling: true,
              cursorSmoothCaretAnimation: 'on',
              cursorBlinking: 'smooth',
              bracketPairColorization: { enabled: true },
              guides: { bracketPairs: true, indentation: true },
              formatOnPaste: true,
              formatOnType: true,
              autoClosingBrackets: 'always',
              autoClosingQuotes: 'always',
              autoIndent: 'advanced',
              suggestFontSize: Math.max(12, Math.round(fontSize * 0.95)),
              suggestLineHeight: Math.max(20, Math.round(fontSize * 1.9)),
            }}
          />
        ) : (
          <div className="cw-zoom-hint">Zoom in to edit code</div>
        )}
      </div>

      {showOutput && (
        <div
          className="cw-output"
          style={{ pointerEvents: interactivePE, height: outputH }}
          onPointerDown={stopBubble}
          onMouseDown={stopBubble}
          onKeyDown={stopBubble}
        >
          <pre className="cw-output-text" style={{ fontSize: Math.round(11 * sizeRatio) }}>{output}</pre>
        </div>
      )}

      <div className="cw-resize cw-resize--e"  style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'e')} />
      <div className="cw-resize cw-resize--s"  style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 's')} />
      <div className="cw-resize cw-resize--w"  style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'w')} />
      <div className="cw-resize cw-resize--n"  style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'n')} />
      <div className="cw-resize cw-resize--se" style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'se')} />
      <div className="cw-resize cw-resize--sw" style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'sw')} />
      <div className="cw-resize cw-resize--ne" style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'ne')} />
      <div className="cw-resize cw-resize--nw" style={{ pointerEvents: interactivePE }} onMouseDown={(e) => handleResizeMouseDown(e, 'nw')} />
    </div>
  );
});

export default CompilerWidgetOverlay;
