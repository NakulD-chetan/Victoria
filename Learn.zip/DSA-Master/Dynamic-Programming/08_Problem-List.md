# Dynamic Programming — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Organized by DP subcategory for systematic mastery.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | DP Type | Why Important | Practice In |
|---|---------|-----------|------|---------|---------------|-------------|
| 1 | Climbing Stairs | Easy | 70 | 1D DP | Purest DP problem — foundation | Python first |
| 2 | House Robber | Medium | 198 | 1D DP | Classic "skip or take" decision | Python + C++ |
| 3 | Coin Change | Medium | 322 | Unbounded Knapsack | Most-asked DP at FAANG | All 3 languages |
| 4 | Longest Common Subsequence | Medium | 1143 | 2D String DP | Foundation for edit distance, diff | C++ + Rust |
| 5 | Longest Increasing Subsequence | Medium | 300 | 1D DP + Binary Search | Tests DP + optimization thinking | Python + C++ |
| 6 | 0/1 Knapsack | Medium | - | 0/1 Knapsack | THE classic DP pattern | All 3 |
| 7 | Edit Distance | Medium | 72 | 2D String DP | Real-world application (spell check) | C++ + Rust |
| 8 | Unique Paths | Medium | 62 | 2D Grid DP | Simplest grid DP | Python |
| 9 | Word Break | Medium | 139 | 1D DP + Trie | String + DP combination | Python + Rust |
| 10 | Burst Balloons | Hard | 312 | Interval DP | Interval DP mastery | C++ |

---

## Complete 30-Problem Progression

### 1D DP (Problems 1-8) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Climbing Stairs | 70 | 1D DP | dp[i] = dp[i-1] + dp[i-2] |
| 2 | Min Cost Climbing Stairs | 746 | 1D DP | Choose min of two previous |
| 3 | House Robber | 198 | 1D DP | Take or skip decision |
| 4 | House Robber II | 213 | 1D Circular DP | Run twice (skip first / skip last) |
| 5 | Maximum Subarray | 53 | Kadane's | dp[i] = max(arr[i], dp[i-1] + arr[i]) |
| 6 | Decode Ways | 91 | 1D DP | String digit DP |
| 7 | Longest Increasing Subsequence | 300 | 1D DP / BS | O(n²) DP or O(n log n) with patience sort |
| 8 | Maximum Product Subarray | 152 | 1D DP (track min+max) | Negatives flip sign |

### 2D Grid / Path DP (Problems 9-14)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 9 | Unique Paths | 62 | 2D Grid DP | dp[i][j] = dp[i-1][j] + dp[i][j-1] |
| 10 | Unique Paths II | 63 | 2D Grid + Obstacles | Handle blocked cells |
| 11 | Minimum Path Sum | 64 | 2D Grid DP | dp[i][j] = grid[i][j] + min(up, left) |
| 12 | Triangle | 120 | Bottom-up DP | Start from bottom row |
| 13 | Maximal Square | 221 | 2D DP | dp[i][j] = min(3 neighbors) + 1 |
| 14 | Dungeon Game | 174 | Reverse DP | Build from bottom-right |

### Knapsack Family (Problems 15-20)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 15 | Partition Equal Subset Sum | 416 | 0/1 Knapsack | Subset sum = target/2 |
| 16 | Coin Change | 322 | Unbounded Knapsack | Min coins to reach target |
| 17 | Coin Change II | 518 | Unbounded Knapsack (count) | Count combinations |
| 18 | Target Sum | 494 | 0/1 Knapsack + offset | Transform to subset sum |
| 19 | Ones and Zeroes | 474 | 2D Knapsack | Two constraints (0s and 1s) |
| 20 | Last Stone Weight II | 1049 | 0/1 Knapsack | Minimize difference of two groups |

### String DP (Problems 21-25)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 21 | Longest Common Subsequence | 1143 | 2D String DP | dp[i][j] = match or max(skip) |
| 22 | Edit Distance | 72 | 2D String DP | Insert, delete, replace operations |
| 23 | Word Break | 139 | 1D + substring | dp[i] = any valid split? |
| 24 | Palindromic Substrings | 647 | 2D Expand | Count all palindromes |
| 25 | Longest Palindromic Subsequence | 516 | 2D String DP | LCS of s and reverse(s) |

### Advanced DP (Problems 26-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 26 | Burst Balloons | 312 | Interval DP | Think in terms of LAST action |
| 27 | Interleaving String | 97 | 2D DP | Two pointers through two strings |
| 28 | Regular Expression Matching | 10 | 2D DP | * matches zero or more |
| 29 | Best Time Buy/Sell Stock with Cooldown | 309 | State Machine DP | Hold, sold, cooldown states |
| 30 | Longest Valid Parentheses | 32 | 1D DP / Stack | dp[i] = length of valid ending at i |

---

## Pattern Distribution

```
1D DP:              8 problems  (1-8)
2D Grid DP:         6 problems  (9-14)
Knapsack Family:    6 problems  (15-20)
String DP:          5 problems  (21-25)
Advanced/Interval:  5 problems  (26-30)
```

---

## 4-Week Study Plan

### Week 1: 1D DP Foundation
- Day 1-2: LC 70, 746, 198, 213 (climbing + robber)
- Day 3-4: LC 53, 152 (subarray DP + Kadane's)
- Day 5: LC 91, 300 (decode ways + LIS)
- Practice in: Python for quick prototyping

### Week 2: 2D DP + Grid
- Day 1-2: LC 62, 63, 64 (grid paths)
- Day 3-4: LC 120, 221 (triangle + square)
- Day 5: LC 174 (dungeon — reverse DP)
- Practice in: C++ for STL vector<vector<int>>

### Week 3: Knapsack + String DP
- Day 1-2: LC 416, 322, 518 (knapsack family)
- Day 3: LC 494, 474, 1049 (advanced knapsack)
- Day 4-5: LC 1143, 72, 139 (string DP)
- Practice in: Rust for ownership of DP tables

### Week 4: Advanced + Review
- Day 1-2: LC 647, 516 (palindrome DP)
- Day 3-4: LC 312, 97, 10 (interval + regex DP)
- Day 5: LC 309, 32 (state machine + parentheses)
- Practice in: All 3 languages, focus on weak areas

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy-ish, 17 Medium, 5 Hard)
MUST-DO:            LC 70, 198, 322, 1143, 300, 72, 62, 139, 312
TOP 3 MOST ASKED:   LC 322 (Coin Change), LC 300 (LIS), LC 72 (Edit Distance)
DP CATEGORIES:      1D → 2D Grid → Knapsack → String → Interval → State Machine
STUDY ORDER:        1D basics → Grid → Knapsack → String DP → Advanced
KEY INSIGHT:        Master state definition — everything else follows
INTERVIEW LINE:     "I define dp[i] as... with transition dp[i] = max/min of..."
```

---

## 30-SECOND REVISION BOX

```
1D:         dp[i] depends on dp[i-1], dp[i-2] (stairs, robber)
2D GRID:    dp[i][j] = grid[i][j] + min/max(up, left)
KNAPSACK:   dp[j] = max(dp[j], dp[j-w] + v) — 0/1 reverse, unbounded forward
STRING:     dp[i][j] for s1[0..i] vs s2[0..j], match → diagonal
INTERVAL:   dp[i][j] = best of splitting [i..j] at every k
STATE:      define states clearly, draw transitions
SPACE OPT:  2D → 1D when dp[i] only depends on dp[i-1]
```
