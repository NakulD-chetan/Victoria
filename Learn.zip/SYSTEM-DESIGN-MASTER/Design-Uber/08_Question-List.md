# Design Uber — Question List

> **Permanent Recall:** Variations: add UberPool (ride sharing), UberEats (food delivery), driver scheduling, design surge pricing algorithm, handle 100K concurrent requests in one city. Related: Lyft, Grab, Ola, DoorDash. 15+ questions. E=Easy, M=Medium, H=Hard.

---

## Core Variations (MUST-DO)

| # | Question | Difficulty | Key Additions |
|---|----------|------------|---------------|
| 1 | Design Uber (base) | M | Matching, tracking, ETA, surge, payments |
| 2 | Add ride pooling (UberPool) | M | Multi-rider matching, route optimization |
| 3 | Design UberEats (food delivery) | M | Restaurant, orders, driver + order matching |
| 4 | Add driver scheduling | M | Shifts, availability windows, incentives |
| 5 | Design surge pricing algorithm | M | Supply/demand, fairness, A/B testing |
| 6 | Handle 100K concurrent requests in one city | H | Sharding, scaling, peak handling |

---

## Feature Extensions

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 7 | Add scheduled rides | M | Queue for future time; pre-match logic |
| 8 | Add multiple stop trips | M | Route optimization; fare calculation |
| 9 | Add rider/driver ratings | E | Store ratings; aggregate; display |
| 10 | Add driver earnings dashboard | E | Aggregation; real-time balance |
| 11 | Add in-app chat (rider-driver) | M | Messaging; WebSocket; optional |
| 12 | Add fare splitting | E | Split among riders; payment logic |
| 13 | Add driver heatmaps ("demand here") | M | Aggregate request data; push to drivers |

---

## Algorithm Deep-Dives

| # | Question | Difficulty | Topic |
|---|----------|------------|-------|
| 14 | Design the matching algorithm in detail | M | Nearest K, first-accept, expand, timeout |
| 15 | How would you implement Geohash from scratch? | M | Base32 encoding; neighbor computation |
| 16 | Design ETA calculation system | M | Graph routing, historical, traffic |
| 17 | How does Uber handle 3.75M location updates/second? | H | In-memory, sharding, partitioning |
| 18 | Design real-time driver tracking | M | WebSocket, 4s push, fallback |
| 19 | Design the trip state machine | E | States, transitions, idempotency |

---

## Related Systems

| # | Question | Difficulty | Differentiator |
|---|----------|------------|----------------|
| 20 | Design Lyft | M | Similar to Uber; minor differences |
| 21 | Design Grab | M | SE Asia; multi-service (ride, food, pay) |
| 22 | Design Ola | M | India; autorickshaw, different vehicle types |
| 23 | Design DoorDash | M | Food only; restaurant prep time; no rider |
| 24 | Design Amazon Flex | M | Delivery; route optimization; time windows |
| 25 | Design a ride-sharing system for a campus | E | Smaller scale; simpler; good starter |

---

## Scale & Reliability Variations

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 26 | Scale to 50M trips/day | H | Multi-region; sharding; replication |
| 27 | Design for 99.99% availability | H | Multi-region failover; redundancy |
| 28 | Handle New Year's Eve traffic spike | H | 10× surge; auto-scale; queue |
| 29 | Design offline-first driver app | M | Local queue; sync when online |
| 30 | Add multi-city support | M | Region partitioning; cross-city trips? |

---

## Follow-Up Question Bank

When interviewer says "Good, now add X":

| Add X | First Thing to Say |
|-------|--------------------|
| UberPool | "Multi-rider matching; route optimization; fare splitting; matching becomes 'overlapping routes'" |
| UberEats | "Add restaurant, order lifecycle; driver matches to order + restaurant; ETA includes prep time" |
| Driver scheduling | "Shifts; availability windows; incentivize drivers to work high-demand slots" |
| Surge algorithm | "Supply/demand ratio per geohash; lookup table for multiplier; recalc every 5 min; cap at 3×" |
| 100K concurrent | "Shard Location Service by region; matching queue with workers; auto-scale; circuit breaker" |
| Scheduled ride | "Queue for future time; pre-match at T-15 min or similar; notify driver" |
| Fare split | "N riders; divide total by N; each pays; payment service handles split" |

---

## Practice Schedule Suggestion

| Week | Focus | Questions |
|------|-------|------------|
| 1 | Base + core variations | 1, 2, 5, 6 |
| 2 | Feature extensions | 3, 4, 7, 12 |
| 3 | Algorithm deep-dives | 14, 15, 16, 17 |
| 4 | Related systems | 20, 21, 23, 25 |
| 5 | Scale | 26, 27, 28 |

---

## Quick Answer Cheat Sheet

| Question | One-Line Answer |
|----------|-----------------|
| UberPool | Multi-rider; route overlap; fare split; matching = route + capacity |
| UberEats | Restaurant + order; driver = delivery; ETA includes prep |
| Surge | Supply/demand per geohash; multiplier; recalc; cap |
| 100K concurrent | Shard by region; queue; scale; circuit breaker |
| Lyft | Same as Uber; brand differences only |
| DoorDash | Food delivery; no rider; restaurant prep; similar geo matching |
| ETA | Graph routing + historical + traffic |
| Location at scale | In-memory; Redis GEO; shard by region; 3.75M/s |

> **FAANG Tip:** For "Design X like Uber" — always start with geospatial matching (Geohash) and location scale, then add the differentiator (pooling, food, etc.).

---

## Difficulty Guide

| Difficulty | What to Expect |
|------------|----------------|
| **E** | Single feature add; straightforward extension |
| **M** | New subsystem; integration with existing design |
| **H** | Scale, complex algorithm, or multi-system coordination |

---

## 30-SECOND REVISION BOX

```
CORE: Uber base, UberPool, UberEats, driver scheduling, surge, 100K concurrent
EXTENSIONS: Scheduled, multi-stop, ratings, chat, fare split
ALGORITHMS: Matching, Geohash, ETA, location scale, tracking
RELATED: Lyft, Grab, Ola, DoorDash, Amazon Flex
SCALE: 50M trips, 99.99%, NYE spike
```

---

**Prev: [[07_Tricks-and-Recognition]]** | **Topic: [[01_Concept]]**
