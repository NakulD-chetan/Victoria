# Binary Search — Mental Model

---

## How FAANG Engineers Think About Binary Search

### The Guess the Number Game

```
"I'm thinking of a number 1–100. You guess. I say higher/lower."

Naive: Guess 1, 2, 3, 4... → up to 100 guesses

Binary: Guess 50 → "higher" → discard 1–50
        Guess 75 → "lower"  → discard 76–100
        Guess 62 → "higher" → discard 51–62
        ...

7 guesses max for 1–100 (2^7 = 128 > 100)
```

**The feedback is binary:** too low / too high. That's all you need.

---

## Monotonicity Requirement

**The answer space must have a clear boundary.**

```
                    MONOTONIC SPACE
  ┌─────────────────────────────────────────────────┐
  │  F  F  F  F  F  |  T  T  T  T  T  T  T  T  T   │
  │  ←── all false ──→│←── all true ─────────────→  │
  │                   ↑                             │
  │              BOUNDARY (answer)                   │
  └─────────────────────────────────────────────────┘

  For any position: We can say "go left" or "go right"
  Never: "could be anywhere"
```

### When Monotonicity Holds


| Problem Type                   | Monotonic Property                |
| ------------------------------ | --------------------------------- |
| Sorted array                   | arr[i] < arr[i+1]                 |
| "Minimum X such that works(X)" | works(lo)=false, works(hi)=true   |
| "Maximum X such that valid(X)" | valid(lo)=true, valid(hi)=false   |
| Capacity/speed/limit problems  | More capacity → easier to satisfy |


---

## Binary Search on Answer: The Mental Shift

**Standard BS:** "Where is the target in this sorted array?"

**Binary search on answer:** "What is the minimum/maximum value that satisfies this condition?"

### The Reframing

```
Problem: "Minimum capacity to ship packages in D days"

Step 1: Identify the ANSWER SPACE
        → Capacity can be 1 to sum(weights) (or max(weights) to sum)

Step 2: Ask "Can I achieve X?"
        → works(capacity) = can we ship in ≤ D days?

Step 3: Observe monotonicity
        → capacity 10 works → 11, 12, 13... all work
        → capacity 100 fails → 99, 98, 97... all fail

Step 4: Binary search on capacity
        → Find smallest capacity where works(capacity) = true
```

```
VISUAL: Binary Search on Answer

  Capacity:  1   2   3  ...  50  51  52  ...  100
  works():   F   F   F  ...  F   T   T  ...   T
                          ↑
                    Binary search finds this boundary
```

---

### Lower Bound (bisect_left)

```
Array: [1, 2, 2, 2, 3, 4]   Target: 2

  We want: first index where arr[i] >= 2

  lo=0    mid=2    hi=5
  [1,  2,  2,  2,  3,  4]
         arr[2]=2 >= 2 → potential answer, search left (hi=mid)

  lo=0  mid=1  hi=2
  [1,  2,  2, ...]
     arr[1]=2 >= 2 → potential answer, search left (hi=mid)

  lo=0  hi=1  → lo==hi, exit. Answer: 1
```

### Binary Search on Answer

```
"Minimum capacity to ship in 5 days"
weights = [1,2,3,4,5,6,7,8,9,10], D = 5

  Capacity range: [10, 55]  (max to sum)

  lo=10   mid=32   hi=55
  works(32)? → Count days needed with cap 32
  → 4 days? Yes! Try smaller. hi=32

  lo=10   mid=21   hi=32
  works(21)? → 6 days? No. Need larger. lo=22

  lo=22   mid=27   hi=32
  works(27)? → 5 days? Yes! hi=27

  ... converge to answer = 15
```

---

## The FAANG Decision Flowchart

```
                    START: Read problem
                         │
                ┌────────▼────────┐
                │ Sorted array?   │── Yes ──→ Standard BS (exact/bounds)
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ "Minimum X      │── Yes ──→ BS on answer
                │  such that..."  │          (parametric search)
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ "Maximum X      │── Yes ──→ BS on answer
                │  such that..."  │
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ Answer space    │── Yes ──→ BS on answer
                │ 10^6 to 10^9?   │
                └────────┬────────┘
                         │ No
                         ▼
                   Consider other patterns
```

---

## The "Can I Achieve X?" Test

**Quick check for binary search on answer:**

1. Can you phrase the problem as "Find minimum/maximum X such that condition(X)"?
2. Is condition(X) a **binary** (yes/no) check?
3. If condition(5) is true, is condition(6) true? (or vice versa — monotonic)

If all three: **Binary search on X.**

---

