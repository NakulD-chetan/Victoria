# Design a Batch ETL Pipeline - Interview Answer Format

## One-Line Answer

A batch ETL pipeline pulls data on a schedule, stores immutable raw data in S3, transforms it with Spark/Glue, publishes curated Parquet datasets, and serves them through Athena, Redshift, or BI tools.

---

## Step 1: Clarify Requirements (1-2 min)

Start with 3-4 questions before jumping into design.

### What to ask

- Is this **hourly**, **daily**, or some other batch frequency?
- What is the **expected data volume** per run?
- What is the **SLA** for data availability?
- What are the **sources**: databases, APIs, files, or event exports?
- Do we need **backfills** for missed days?
- Is this mainly for **dashboards**, **ad hoc analytics**, or **downstream ML/data science**?

### Good interview line

> "Before I design it, I want to clarify the batch frequency, expected data volume, source types, and SLA, because those directly affect storage layout, compute choice, and recovery design."

---

## Step 2: High-Level Design (2-3 min)

After clarification, give the simple end-to-end flow first.

### Say this clearly

```text
Sources -> Ingestion -> S3 Raw -> Spark/Glue -> Curated S3 -> Athena/Redshift/BI
```

### Short explanation you can speak

1. Data comes from source systems like databases, APIs, or files
2. Ingestion jobs pull the data on a schedule
3. We first store it in an immutable raw S3 zone
4. Spark or Glue jobs clean, join, deduplicate, and transform it
5. We write curated outputs in Parquet format
6. Analysts and dashboards query it through Athena, Redshift, or BI tools

### Architecture

```text
Source DBs / APIs / Files
           |
      Ingestion Jobs
           |
       Raw S3 Zone
  (immutable landing area)
           |
   Glue Catalog + Metadata
           |
   Spark / Glue ETL Jobs
           |
   Curated S3 Zone (Parquet)
           |
   Redshift / Athena / BI
           |
   Dashboards / Analysts
```

### Good interview line

> "My high-level design is sources to ingestion, then raw S3 as the system of record, then Spark-based transformation, then curated datasets for analytics."

---

## Step 3: Deep Dive (This Is Where You Win)

Do not deep dive into everything. Pick 2-3 strong areas and explain them well.

### A. Storage and Format

#### Why Parquet?

- Columnar format, so analytics queries scan less data
- Better compression than CSV or JSON
- Faster for Athena, Spark, and warehouse-style scans

#### Why partitioning?

- Partition by a common filter like `event_date`
- Queries can skip unnecessary partitions
- This reduces cost and improves performance

#### Why immutable raw storage?

- Raw S3 is the recovery point
- If downstream logic breaks, we can replay from raw
- It also helps with auditability and debugging

### Good interview line

> "I keep raw data immutable in S3 for replay and audit, then convert curated data into partitioned Parquet because it is cheaper and much faster for analytics queries."

---

### B. Processing

#### Why Spark / Glue?

- Good for joins, aggregations, deduplication, and large-scale transforms
- Handles bigger volumes better than single-machine scripts
- Works naturally with S3-based data lakes

#### Idempotency

- Rerunning the same batch should not create duplicates
- Use batch IDs, source watermarks, or overwrite-by-partition logic
- This matters because batch jobs often fail and rerun

#### Backfills

- Support rerunning old dates or missing partitions
- Design jobs to accept a date range or batch parameter
- Keep raw historical data so old windows can be reprocessed

### Good interview line

> "I would make the ETL idempotent, so if a job for a given date reruns it produces the same output instead of duplicate rows, and I would design it to support backfills for missed periods."

---

### C. Reliability

#### Retry strategy

- Use orchestration tools like Airflow or Step Functions
- Add retries with backoff for temporary failures
- Separate transient errors from permanent data-quality issues

#### Atomic publish

Do not publish partial output directly.

Use this pattern:

1. Write output to a temporary path
2. Validate row counts / schema / quality checks
3. Publish only after validation succeeds

#### Data validation

Examples:

- row count checks
- null checks on critical columns
- schema checks
- freshness checks
- duplicate key checks

### Good interview line

> "For reliability, I would use retries for transient failures, validate data before publish, and use atomic publish so dashboards never see partial or corrupt output."

---

## Step 4: Scaling

Once the basic design is clear, explain how it scales.

### Main scaling points

#### Horizontal scaling with Spark

- Spark can distribute work across many workers
- Useful for big joins, aggregations, and large input files

#### Partition pruning

- Partition by date or another common filter column
- Query engines only scan required partitions

#### Batch sizing

- If the batch window becomes too large, split work by date/table/source
- Very large daily jobs may become hourly jobs later

### Good interview line

> "To scale, I would use Spark for distributed processing, partition the data for cheap scans, and tune the batch window size so one run does not become too large to finish within SLA."

---

## Step 5: Trade-Offs

Interviewers like hearing what you gain and what you give up.

### Example trade-offs

#### S3 vs warehouse storage

- S3 is cheaper and better for raw/history
- But queries are slower unless data is optimized

#### Batch vs streaming

- Batch is simpler and cheaper
- But freshness is lower than real-time systems

#### Parquet vs JSON/CSV

- Parquet is much better for analytics
- But raw JSON/CSV may still be useful for exact source replay

### Good interview line

> "We choose S3 over storing everything in the warehouse because it is much cheaper for raw and historical data, but queries are slower unless we optimize with Parquet, partitioning, and curated datasets."

---

## Strong 2-Minute Answer Script

> "First, I would clarify whether this is hourly or daily batch, the expected data volume, source types, and SLA. My high-level design is sources feeding scheduled ingestion jobs, which first land immutable raw data in S3. Then Spark or Glue jobs clean, join, deduplicate, and transform that data into curated Parquet datasets, which are then queried through Athena, Redshift, or BI tools.
>
> In the deep dive, I would focus on three areas. For storage, I would keep raw data immutable for replay and audit, and write curated data in partitioned Parquet for cost and query efficiency. For processing, I would use Spark because it scales for large joins and aggregations, and I would make the jobs idempotent so reruns do not create duplicates. I would also support backfills by allowing jobs to rerun historical date ranges. For reliability, I would use retries with backoff, data-quality checks, and an atomic publish pattern so partial output is never exposed.
>
> For scaling, Spark gives horizontal compute scale, partition pruning reduces scan cost, and batch sizing can be tuned as volume grows. The main trade-off is that S3-based storage is much cheaper than a warehouse for raw and historical data, but query performance needs optimization through Parquet, partitioning, and curated serving layers."

---

## Quick Deep-Dive Buckets to Remember

If you forget what to say, remember these 3 buckets:

1. **Storage**: immutable raw, Parquet, partitioning
2. **Processing**: Spark, idempotency, backfills
3. **Reliability**: retries, validation, atomic publish

---

## Common Failure Cases

### Upstream source is late

- Mark batch as delayed
- Do not overwrite previous good data blindly
- Rerun when source arrives

### Partial load succeeds

- Write to temporary output first
- Validate it
- Then publish

### Duplicate files arrive

- Use batch ID, checksum, or watermark
- Keep writes idempotent

### Schema changes unexpectedly

- Still store raw data
- Quarantine incompatible records
- Alert owners before publishing curated data

---

## Interview Tips

- Start with **clarifying questions**
- Give a **clean high-level flow** before details
- Deep dive on only **2 or 3 important areas**
- Always mention **idempotency**, **backfills**, and **data validation**
- Mention **trade-offs**, not only the happy path
  ---

