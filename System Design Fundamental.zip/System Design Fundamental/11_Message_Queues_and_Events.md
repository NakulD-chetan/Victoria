# Message Queues & Event Driven — Async Power

> **Message Queue = Post office jaisa — sender bhejta hai, receiver jab chahe le leta hai**
> Isse services decouple hoti hain aur spikes handle hote hain

---

## Table of Contents
1. [Message Queue Kya Hai?](#message-queue-kya-hai)
2. [Kyu Zaroori Hai?](#kyu-zaroori-hai)
3. [Message Queue vs Pub/Sub](#message-queue-vs-pubsub)
4. [Queue Patterns](#queue-patterns)
5. [Kafka Deep Dive](#kafka-deep-dive)
6. [RabbitMQ Basics](#rabbitmq-basics)
7. [SQS/SNS (AWS)](#sqssns-aws)
8. [Event Driven Architecture](#event-driven-architecture)
9. [Event Sourcing](#event-sourcing)
10. [CQRS](#cqrs)
11. [Delivery Guarantees](#delivery-guarantees)
12. [Dead Letter Queue](#dead-letter-queue)
13. [Ordering & Idempotency](#ordering--idempotency)
14. [Queue vs Direct Call](#queue-vs-direct-call)
15. [Interview Questions & Quick Recall](#interview-questions--quick-recall)

---

## Message Queue Kya Hai?

### Core Concept
Message Queue = **buffer** between producer (sender) aur consumer (receiver). Producer bhejta hai, consumer jab ready ho tab process karta hai.

### Real World Analogy
**Post Office / Order Ticket:**
- Tum form bhar ke counter pe chhod dete ho (produce)
- Clerk jab free ho, tumhara number aayega (consume)
- Tum wait nahi karte — apna kaam karte raho

### How It Works

```
[Producer] ---message---> [Queue] ---message---> [Consumer]
              |                    |
         Fire & forget      Pull when ready
         (async)            (async)
```

### Key Terms
| Term | Matlab |
|------|--------|
| **Producer** | Message bhejne wala |
| **Consumer** | Message lene wala |
| **Queue** | Message storage (FIFO typically) |
| **Broker** | Queue manage karne wala (Kafka, RabbitMQ) |

### 1 Minute Recall Block
> Message Queue = async buffer. Producer bhejta hai, consumer later process karta hai. Decoupling + buffering.

### 5 Bullet Memory Hooks
- Queue = post office / ticket system
- Producer = sender, Consumer = receiver
- Async = don't wait
- Broker = Kafka, RabbitMQ, SQS
- Decoupling = services independent

---

## Kyu Zaroori Hai?

### Core Concept
**3 Main Reasons:** Decoupling, Async Processing, Spike Handling

### 1. Decoupling
```
WITHOUT QUEUE (Tight Coupling):
[Order Service] ---direct call---> [Email Service]
         |                              |
    Email down = Order fails      Order knows Email exists
```

```
WITH QUEUE (Loose Coupling):
[Order Service] ---msg---> [Queue] ---msg---> [Email Service]
         |                      |
    Doesn't care if Email       Email processes when ready
    is up or down
```

### 2. Async Processing
- User ko turant response do
- Heavy work background mein
- **Example:** Order place → "Order confirmed" immediately, email/shipping later

### 3. Spike Handling
- Sudden traffic spike
- Queue buffer karta hai
- Consumers gradually process — no overload

### Benefits Table
| Benefit | Matlab |
|---------|--------|
| **Decoupling** | Services independent, fail separately |
| **Async** | Non-blocking, fast response |
| **Buffering** | Spike absorb, rate smoothing |
| **Reliability** | Messages persist, retry possible |
| **Scalability** | Add consumers = more throughput |

### Real World Example
**Uber:** Ride request → Queue → Matching service process karta hai. Request spike aaye toh queue buffer, no crash.

---

## Message Queue vs Pub/Sub

### Core Concept
**Queue:** One consumer gets one message (point-to-point)
**Pub/Sub:** Many consumers get same message (broadcast)

### Message Queue (Point-to-Point)
```
[Producer] ---> [Queue] ---> [Consumer 1]  (message gone)
                    |
                    X  (Consumer 2 doesn't get it)
```
- Ek message = ek consumer
- Competing consumers = load distribution

### Pub/Sub (Publish-Subscribe)
```
[Publisher] ---> [Topic] ---> [Subscriber 1]
                    |  ---> [Subscriber 2]
                    |  ---> [Subscriber 3]
```
- Ek message = multiple subscribers
- Fan-out pattern

### Comparison Table
| Aspect | Message Queue | Pub/Sub |
|--------|---------------|---------|
| **Consumers** | One per message | Many per message |
| **Use Case** | Task distribution | Event broadcast |
| **Example** | Order processing | Notifications to multiple systems |
| **Message** | Consumed (deleted) | Copied to each subscriber |

### Common Interview Trap
> "Queue vs Pub/Sub?" — Queue = 1 consumer. Pub/Sub = many consumers get copy. Different use cases!

### 1 Minute Recall Block
> Queue = one consumer, task distribution. Pub/Sub = many consumers, event broadcast. Don't confuse!

---

## Queue Patterns

### Point-to-Point
- One producer, one queue, one consumer (or competing consumers)
- Message = one consumer ko milta hai
- **Use:** Order processing, job queue

### Publish-Subscribe
- One publisher, topic, many subscribers
- Message = sabko copy
- **Use:** Order created event → Inventory, Email, Analytics sabko

### Fan-Out
```
[Source] ---> [Queue 1] ---> [Consumer A]
        \---> [Queue 2] ---> [Consumer B]
        \---> [Queue 3] ---> [Consumer C]
```
- One message → multiple queues
- Same as Pub/Sub conceptually

### Fan-In
```
[Producer A] ---\
[Producer B] ----> [Queue] ---> [Consumer]
[Producer C] ---/
```
- Multiple producers → one queue
- Consolidation pattern

### 1 Minute Recall Block
> Point-to-point = 1 consumer. Pub/Sub = many. Fan-out = one to many. Fan-in = many to one.

---

## Kafka Deep Dive

### Core Concept
Kafka = **distributed event streaming** platform. High throughput, durable, replay-able.

### Architecture

```
[Producer] ---> [Kafka Cluster]
                    |
              +----+----+
              |         |
         [Broker 1] [Broker 2] ...
              |
         [Topic: orders]
              |
    +---------+---------+
    |                   |
[Partition 0]    [Partition 1]    (parallelism)
    |                   |
[Consumer Group]  [Consumer Group]
```

### Key Concepts

| Concept | Matlab |
|---------|--------|
| **Topic** | Category/stream name (e.g., "orders") |
| **Partition** | Topic ko shards — parallelism |
| **Offset** | Message position in partition (sequence number) |
| **Consumer Group** | Consumers jo together consume karte hain |
| **Broker** | Kafka server node |

### Partitions
- Topic = multiple partitions
- Message key → partition (same key = same partition = ordering)
- More partitions = more parallelism

### Consumer Groups
- Group mein consumers = partitions distribute
- 4 partitions, 2 consumers = each gets 2 partitions
- 4 partitions, 6 consumers = 4 active, 2 idle (partitions >= consumers)

### Offsets
- Each partition has offset (0, 1, 2, 3...)
- Consumer commits offset = "yeh tak process ho gaya"
- Replay = reset offset to earlier value

### Kafka vs Traditional Queue
| Feature | Kafka | Traditional Queue |
|---------|-------|-------------------|
| **Retention** | Log — messages retained (days/weeks) | Deleted after consume |
| **Replay** | Yes — reset offset | No |
| **Ordering** | Per partition | Per queue |
| **Throughput** | Very high | Lower |

### Common Interview Trap
> "Kafka partition count?" — Throughput ke hisaab se. More partitions = more parallelism but more overhead. Typically 10-100 for high throughput.

### 1 Minute Recall Block
> Kafka = distributed log. Topic → Partitions. Consumer groups. Offsets for replay. High throughput, durable.

### 5 Bullet Memory Hooks
- Topic = stream name
- Partition = shard, parallelism
- Offset = position, replay possible
- Consumer group = load distribution
- Retention = messages persist

---

## RabbitMQ Basics

### Core Concept
RabbitMQ = traditional message broker. Exchanges route to queues.

### Architecture

```
[Producer] ---> [Exchange] ---> [Queue 1] ---> [Consumer 1]
                    |  ---> [Queue 2] ---> [Consumer 2]
                    |  (routing rules)
```

### Key Concepts

| Concept | Matlab |
|---------|--------|
| **Exchange** | Receives messages, routes to queues |
| **Queue** | Stores messages |
| **Binding** | Exchange to queue connection + routing key |
| **Routing Key** | Message attribute for routing |

### Exchange Types
| Type | Behavior |
|------|----------|
| **Direct** | Routing key exact match |
| **Topic** | Routing key pattern (e.g., order.*) |
| **Fanout** | Broadcast to all bound queues |
| **Headers** | Route by message headers |

### 1 Minute Recall Block
> RabbitMQ = Exchange → Queue. Direct, Topic, Fanout exchanges. Bindings with routing keys.

---

## SQS/SNS (AWS)

### SQS (Simple Queue Service)
- Standard Queue: At-least-once, best-effort ordering
- FIFO Queue: Exactly-once, strict ordering
- **Use:** Decoupling, async processing

### SNS (Simple Notification Service)
- Pub/Sub — fan-out
- Topic → multiple subscribers (SQS, Lambda, HTTP)
- **Use:** Event broadcast

### SQS + SNS Pattern
```
[Publisher] ---> [SNS Topic] ---> [SQS Queue 1] ---> [Consumer 1]
                        \---> [SQS Queue 2] ---> [Consumer 2]
```
- SNS = fan-out
- SQS = durable storage, consumer control

### 1 Minute Recall Block
> SQS = queue, SNS = pub/sub. Combine for fan-out + durability.

---

## Event Driven Architecture (EDA)

### Core Concept
Services communicate via **events** — "kuch hua" broadcast, listeners react.

### How It Works
```
[Order Service] --OrderCreated event--> [Event Bus]
                                              |
                    +------------------------+------------------------+
                    v                         v                        v
            [Inventory Service]        [Email Service]        [Analytics]
            (reserve stock)            (send confirmation)    (track metrics)
```

### Benefits
- Loose coupling
- Easy to add new consumers
- Async by default
- Scalable

### Event vs Command
| Event | Command |
|-------|---------|
| "Hua" (past) | "Karo" (imperative) |
| OrderCreated | CreateOrder |
| Broadcast | Point-to-point |
| Multiple handlers | Single handler |

### 1 Minute Recall Block
> EDA = event-based communication. Loose coupling. Event = something happened. Command = do something.

---

## Event Sourcing

### Core Concept
**State store mat karo — events store karo!** Current state = replay of all events.

### Traditional vs Event Sourcing

```
TRADITIONAL:
[Order] state: {status: "shipped", amount: 100}
(only current state stored)

EVENT SOURCING:
Events: [OrderCreated, PaymentReceived, ItemShipped]
Current state = replay all events
```

### How It Works
- Append-only event log
- State = fold/reduce over events
- Full history preserved
- Replay = rebuild state at any point

### Pros & Cons
| Pros | Cons |
|------|------|
| Full audit trail | Event schema evolution |
| Time travel (replay) | Query complexity |
| Debugging easy | Storage grows |

### 1 Minute Recall Block
> Event Sourcing = store events, not state. Replay = current state. Audit trail built-in.

---

## CQRS (Command Query Responsibility Segregation)

### Core Concept
**Read aur Write alag models** — optimize separately.

### How It Works
```
[Command] ---> [Write Model] ---> [Event] ---> [Read Model]
                                      |
                              [Read DB] (optimized for queries)
```

- Write = normalized, transactional
- Read = denormalized, fast queries (maybe different DB)

### When to Use
- Read/Write different scale
- Complex queries on write model hard
- Event Sourcing ke saath often use

### 1 Minute Recall Block
> CQRS = read write separation. Different models, different DBs. Scale independently.

---

## Delivery Guarantees

### At-Most-Once
- Bhejo, lose ho to ho
- No retry
- **Use:** Metrics, logs (loss acceptable)

### At-Least-Once
- Guarantee deliver, but duplicate possible
- Retry on failure
- **Use:** Most cases — idempotency handle duplicates

### Exactly-Once
- No loss, no duplicate
- Hard to achieve — Kafka transactional API, etc.
- **Use:** Financial, critical

### Comparison Table
| Guarantee | Loss | Duplicate | Complexity |
|-----------|------|-----------|------------|
| At-most-once | Possible | No | Low |
| At-least-once | No | Possible | Medium |
| Exactly-once | No | No | High |

### Common Interview Trap
> "Exactly-once possible?" — Theoretically hard. Kafka claims it with transactions. Practical: at-least-once + idempotency.

### 1 Minute Recall Block
> At-most = may lose. At-least = may duplicate. Exactly = neither. Practical = at-least + idempotent consumer.

---

## Dead Letter Queue (DLQ)

### Core Concept
**Failed messages** ko alag queue mein daalo — retry ya manual fix.

### How It Works
```
[Queue] ---> [Consumer] (process)
                |
                (fail after 3 retries)
                v
         [Dead Letter Queue]
                |
         (manual inspect, fix, replay)
```

### When Message Goes to DLQ
- Max retries exceeded
- Invalid format
- Consumer explicitly rejects

### Use
- Don't lose failed messages
- Debug, fix, replay
- Alert on DLQ depth

### 1 Minute Recall Block
> DLQ = failed message storage. Retry exhaust → DLQ. Manual fix, replay possible.

---

## Ordering & Idempotency

### Ordering Guarantees
- **Kafka:** Per partition ordering
- **FIFO SQS:** Strict ordering (throughput trade-off)
- **Strategy:** Same key → same partition → order maintained

### Idempotency
**Same request multiple times = same result** (no side effects)

### Why Critical for Queues?
- At-least-once = duplicates
- Consumer crash after process, before ack = retry
- Idempotent = duplicate safe

### Idempotency Keys
```
Request: { idempotency_key: "uuid-123", amount: 100 }
First time: Process, store key
Retry: Key exists → return stored result, don't process again
```

### Payment Example
- Duplicate "deduct 100" = disaster
- Idempotency key = process once only

### 1 Minute Recall Block
> Idempotency = same request twice = same result. Critical for at-least-once. Use idempotency keys.

### 5 Bullet Memory Hooks
- At-least-once = duplicates
- Idempotent = duplicate safe
- Idempotency key = unique per logical request
- Payments = must be idempotent
- Ordering = partition/key strategy

---

## Queue vs Direct Call

### When to Use Queue
- Async processing OK
- Decoupling needed
- Spike handling
- Retry, durability needed
- Multiple consumers (pub/sub)

### When Direct Call
- Need immediate response
- Strong consistency
- Simple request-response
- Low latency critical

### Decision Table
| Scenario | Queue | Direct |
|----------|-------|--------|
| Order placement | Queue (email later) | Direct (validation) |
| Payment | Direct (immediate) | - |
| Notification | Queue | - |
| Search | Direct | - |
| Report generation | Queue | - |

### Common Interview Trap
> "Always use queue?" — NO! Sync when you need immediate response. Queue adds latency.

### 1 Minute Recall Block
> Queue = async, decouple, buffer. Direct = sync, immediate. Choose based on consistency + latency needs.

---

## Interview Questions & Quick Recall

### Interview Questions

**Q1: Message Queue vs Pub/Sub?**
> Queue = one consumer per message. Pub/Sub = many consumers get copy. Task distribution vs event broadcast.

**Q2: Kafka partitions — why and how many?**
> Parallelism. More partitions = more consumers. Same key = same partition = ordering. 10-100 typical.

**Q3: At-least-once delivery — how handle duplicates?**
> Idempotent consumers. Idempotency keys. Same request twice = same result.

**Q4: When queue vs direct call?**
> Queue: async OK, decouple, spike. Direct: immediate response, strong consistency.

**Q5: Dead Letter Queue purpose?**
> Failed messages after retries. Don't lose. Debug, fix, replay.

**Q6: Event Sourcing vs traditional DB?**
> Store events not state. Replay = current state. Audit trail, time travel.

**Q7: CQRS kya hai?**
> Read/Write separation. Different models. Scale independently.

**Q8: Kafka consumer group?**
> Consumers share partitions. Load distribution. N partitions = max N parallel consumers.

### Common Interview Traps
- "Exactly-once easy" — Hard! At-least-once + idempotency practical
- "Queue for everything" — No, sync when needed
- "Kafka = queue" — Kafka = log, different semantics

### Quick Recall — Full Cheat Sheet

```
MESSAGE QUEUES & EVENTS CHEAT SHEET
====================================
• Queue = async buffer, decouple
• Queue vs Pub/Sub: 1 consumer vs many
• Kafka: Topic, Partition, Offset, Consumer Group
• RabbitMQ: Exchange, Queue, Binding
• SQS = queue, SNS = pub/sub
• EDA = event-driven, loose coupling
• Event Sourcing = store events, replay state
• CQRS = read/write separation
• Delivery: At-most, At-least, Exactly-once
• DLQ = failed messages
• Idempotency = duplicate safe
• Queue when: async, decouple. Direct when: sync needed
```

### 5 Bullet Memory Hooks (Full Topic)
- Queue = post office, async
- Kafka = log, partitions, replay
- At-least-once + idempotency = practical
- DLQ = failed message storage
- Event Sourcing = events not state
