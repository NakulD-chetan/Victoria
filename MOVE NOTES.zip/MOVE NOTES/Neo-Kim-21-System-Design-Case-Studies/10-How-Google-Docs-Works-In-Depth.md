# How Google Docs Works - In Depth (Easy Language)

> Companion to: [10-How-Google-Docs-Works.md](10-How-Google-Docs-Works.md)

---

## The Core Problem: Two People Editing at the Same Time

Imagine Alice and Bob are both editing the same document. The document says: **"HELLO"**

```
Alice (in India, 200ms latency): types "!" at the end → "HELLO!"
Bob (in USA, at the same time): deletes "H" → "ELLO"

What SHOULD the final document be?
  "ELLO!" (both changes applied correctly)

What could go WRONG?
  Alice's version: "HELLO!" (doesn't know Bob deleted H)
  Bob's version: "ELLO" (doesn't know Alice added !)
  Server confused: which version is correct?
```

This is the **concurrent editing problem**. Google Docs solves it using **Operational Transformation (OT)**.

---

## Four Approaches (And Why Only One Works)

### Approach 1: Lock the Document (Pessimistic Locking)

```
Alice: "I want to edit" → Server: "OK, you have the lock"
Bob: "I want to edit" → Server: "Sorry, Alice is editing. Wait."

Bob sees: [READ ONLY] waiting... waiting... 

Alice finishes → lock released → Bob can edit
```

**Why it fails**: Not real-time collaboration! Bob can't do anything while Alice is typing. Imagine 10 people in a meeting, all wanting to type simultaneously -- 9 of them are stuck waiting.

### Approach 2: Last Write Wins

```
Alice: changes "HELLO" → "HELLO!"
Bob: changes "HELLO" → "ELLO"

Both send changes to server.
Server: "Bob's change arrived last, use Bob's version"
Result: "ELLO" (Alice's "!" is LOST!)
```

**Why it fails**: Data loss! Alice's change is silently discarded. Unacceptable for a document editor.

### Approach 3: Diff + Merge (Differential Sync)

```
Alice: "My diff: added '!' at position 5"
Bob: "My diff: deleted 'H' at position 0"

Server tries to merge the diffs...
But what if they conflict?
→ "MERGE CONFLICT! Please resolve manually"
→ Like Git merge conflicts... annoying!
```

**Why it fails**: Manual conflict resolution kills the real-time experience. You don't want pop-ups saying "resolve conflict" while you're writing.

### Approach 4: Operational Transformation (OT) -- THE WINNER

```
Alice: INSERT("!", position 5)   → sent to server
Bob: DELETE(position 0)          → sent to server

Server receives both operations.
Server TRANSFORMS Alice's operation:
  "Alice wants to insert at position 5, but Bob deleted a character before position 5"
  "So Alice's position shifts from 5 to 4"
  
  Original: INSERT("!", position 5)
  Transformed: INSERT("!", position 4)

Apply both:
  Start: "HELLO"
  Apply Bob's DELETE(0): "ELLO"
  Apply Alice's INSERT("!", 4): "ELLO!"
  
  Result: "ELLO!" ← Both changes applied correctly! No conflict!
```

---

## How OT Works - Step by Step

### The Key Idea

Instead of storing the document as text, store it as a **list of operations**:

```
Document starts as: ""
Operation 1: INSERT("H", 0) → "H"
Operation 2: INSERT("E", 1) → "HE"
Operation 3: INSERT("L", 2) → "HEL"
Operation 4: INSERT("L", 3) → "HELL"
Operation 5: INSERT("O", 4) → "HELLO"
```

The document IS the sum of all its operations. You can rebuild it from scratch by replaying operations from the beginning.

### The Transformation Rules

When two operations happen at the same time, one must be **transformed** based on the other:

**Rule 1: INSERT before INSERT**
```
Alice: INSERT("X", position 3)
Bob: INSERT("Y", position 1)

Bob's insert is BEFORE Alice's position
→ Alice's position shifts RIGHT by 1
→ Alice's transformed: INSERT("X", position 4)
```

**Rule 2: DELETE before INSERT**
```
Alice: INSERT("X", position 5)
Bob: DELETE(position 2)

Bob deleted a character BEFORE Alice's position
→ Alice's position shifts LEFT by 1
→ Alice's transformed: INSERT("X", position 4)
```

**Rule 3: INSERT before DELETE**
```
Alice: DELETE(position 3)
Bob: INSERT("Y", position 1)

Bob inserted BEFORE Alice's deletion position
→ Alice's position shifts RIGHT by 1
→ Alice's transformed: DELETE(position 4)
```

---

## Latency Hiding - The "Instant" Feel

### The Secret: Local Copy

Each user has a **local copy** of the document. Edits apply to the LOCAL copy FIRST, then sync with the server.

```
Alice's experience:
  1. Types "!" → appears INSTANTLY on her screen (local copy updated)
  2. Operation sent to server in background
  3. Server processes, transforms, broadcasts
  4. Alice doesn't notice any delay!

Bob's experience:
  1. Types his changes → appears INSTANTLY on his screen
  2. Receives Alice's transformed operation from server (~200ms later)
  3. "!" appears in his document
  4. Slight delay for remote changes, but local changes are instant
```

**This is why Google Docs feels fast** even with 200ms network latency. Your own typing is always instant. Others' changes appear with a small delay, but you barely notice.

---

## The Server's Role

```
Collaboration Server:
  ┌────────────────────────────────────────┐
  │ OT Engine                              │
  │  - Receives operations from all clients │
  │  - Assigns REVISION NUMBER to each     │
  │  - Transforms concurrent operations    │
  │  - Ensures all clients converge        │
  │                                        │
  │ Revision Log (append-only)             │
  │  #1: Alice INSERT("H", 0) @ 10:00:01  │
  │  #2: Alice INSERT("E", 1) @ 10:00:01  │
  │  #3: Bob DELETE(0) @ 10:00:02          │
  │  #4: Alice INSERT("!", 4→3) @ 10:00:02│
  │  ... (every operation ever)            │
  │                                        │
  │ Session Manager                        │
  │  - Tracks who's connected              │
  │  - Manages cursor positions            │
  │  - Handles join/leave events           │
  └────────────────────────────────────────┘
```

**The server is the single source of truth.** It decides the order of operations. If two operations arrive at the same time, the server picks an order, transforms them, and broadcasts the result.

---

## Cursor Sync - Seeing Where Others Are Editing

```
Alice is editing line 42, Bob is editing line 10.

Each user's cursor position is broadcast to others:
  Server → Bob: "Alice's cursor is at line 42, column 15 (color: blue)"
  Server → Alice: "Bob's cursor is at line 10, column 8 (color: green)"

When operations shift text:
  If Bob inserts a line above Alice's cursor,
  Alice's cursor position is also TRANSFORMED (shifts down by 1)
```

This is why you see colored cursors with names in Google Docs -- each person's cursor is another piece of state that gets synced and transformed.

---

## Offline Support - Edit Without Internet

```
Alice loses internet while editing:

1. Alice keeps typing → operations queued LOCALLY
   Local queue: [INSERT("a"), INSERT("b"), DELETE(5), INSERT("c")]
   
2. Meanwhile, Bob is also editing (connected to server)
   Server has new operations from Bob

3. Alice's internet comes back:
   → Client sends queued operations to server
   → Server: "Alice missed operations #15-#22 from Bob"
   → Server TRANSFORMS Alice's queued ops against Bob's ops
   → Sends transformed operations back to Alice
   → Alice's document syncs with everyone else's
```

**The beauty**: Alice didn't lose any work. The OT algorithm figured out how to merge her offline changes with everyone else's changes.

---

## OT vs CRDTs - Two Approaches to the Same Problem

| Aspect | OT (Google Docs) | CRDTs (Figma, Apple Notes) |
|--------|-------------------|---------------------------|
| **How it resolves conflicts** | Server transforms operations | Data structure resolves itself |
| **Needs a server?** | Yes (server is the authority) | No (can be peer-to-peer) |
| **Complexity** | Complex algorithm, simple data | Simple algorithm, complex data structure |
| **Ordering** | Server decides order | No central ordering needed |
| **Best for** | Text editing (insert/delete) | Design tools, structured data |
| **Used by** | Google Docs, Microsoft Office Online | Figma, Apple Notes, Notion |

### CRDTs in Simple Terms

```
OT approach:
  "Alice inserted at position 5, Bob deleted at position 3"
  → Server: "I need to transform Alice's position to 4"

CRDT approach:
  Each character has a UNIQUE ID that never changes:
  "H(id:1) E(id:2) L(id:3) L(id:4) O(id:5)"
  
  Alice: "Insert !(id:6) after id:5"
  Bob: "Delete id:1"
  
  No position numbers → no transformation needed!
  Both operations can be applied in any order → same result!
```

CRDTs trade simplicity (no transformation algorithm) for more complex data structures (every character needs a unique ID and ordering metadata).

---

## Version History and Undo

### Revision Log = Time Machine

Because every operation is stored in the revision log:

```
Revision log:
  #1: 10:00:00 Alice: "Created document"
  #2: 10:01:00 Alice: INSERT("Hello")
  #3: 10:02:00 Bob: INSERT(" World")
  #4: 10:03:00 Alice: DELETE("Hello")
  #5: 10:03:30 Alice: INSERT("Hi")
  
"Show me the document at 10:02:30"
  → Replay operations #1, #2, #3
  → Document at that time: "Hello World"

"Undo Alice's last change"
  → Reverse operation #5 (delete "Hi") and #4 (restore "Hello")
  → Document: "Hello World"
```

This is how Google Docs' "Version History" feature works. It's not storing snapshots of the entire document -- it's storing the operations and can reconstruct any point in time.

---

## Scaling Google Docs

```
1. SHARD BY DOCUMENT:
   Each document runs its own OT engine independently
   → Document A and Document B never interact
   → Can run on different servers
   
2. PERIODIC SNAPSHOTS:
   Don't replay from operation #1 every time
   → Save a snapshot every 100 operations
   → To rebuild: load latest snapshot + replay 50 ops (not 10,000 ops)
   
3. OPERATION BATCHING:
   Rapid typing: "h", "e", "l", "l", "o" = 5 operations
   → Batch into: INSERT("hello") = 1 operation
   → Reduces network traffic and server load
   
4. WebSocket CONNECTION POOLS:
   Millions of users editing simultaneously
   → Distribute WebSocket connections across many servers
   
5. CDN for assets:
   Images and embedded files served from edge locations
```

---

## Revision Flashcards

**Q: What is Operational Transformation in one sentence?**
A: OT transforms the position/content of concurrent operations so they can both be applied without conflict, allowing multiple users to edit simultaneously.

**Q: Why doesn't Google Docs just lock the document?**
A: Locking prevents real-time collaboration. Only one person could edit at a time, defeating the purpose of a collaborative editor.

**Q: How does latency hiding work?**
A: Each user edits a local copy instantly. Changes sync with the server in the background. Your own typing is never delayed by the network.

**Q: What's the difference between OT and CRDTs?**
A: OT uses a server to transform operations (position-based). CRDTs use special data structures where operations commute naturally (ID-based, no server needed). Google Docs uses OT; Figma uses CRDTs.

**Q: How does version history work?**
A: The revision log stores every operation ever applied. To see the document at any point in time, replay operations up to that point. No need to store full document snapshots.
