# Prefix Sum — Mental Model

> **How FAANG engineers think about prefix sums:** Not as "an array of sums" but as **cumulative checkpoints**. Every subarray sum is the difference between two checkpoints. The hash map optimization turns "find pairs (i,j) where prefix[j]-prefix[i]=K" into a single pass.

---

## The Cumulative Odometer Model

**Think of prefix[i] as "total distance traveled by index i".**

```
Position:  0    1    2    3    4    5
Array:    [2,   1,   5,   1,   3]
Odometer: 0 → 2 → 3 → 8 → 9 → 12

"Distance from position 1 to 4" = 12 - 3 = 9
= sum(arr[1..4]) = 1+5+1+3 = 9 ✓
```

- **prefix[i]** = "How much have we accumulated before index i?"
- **prefix[j] - prefix[i]** = "How much did we accumulate going from i to j?"

---

## Subarray Sum = Difference of Two Prefix Values

**Key insight:** Every contiguous subarray [i, j] corresponds to exactly one pair of prefix indices.

```
arr:     [a0, a1, a2, a3, a4]
          i -------- j

Subarray [i..j] = arr[i] + arr[i+1] + ... + arr[j]
                = (prefix[j+1] - prefix[i])
```

**Visualization:**
```
prefix:  [0,  p1,  p2,  p3,  p4,  p5]
          |    |         |         |
          |    |<-- diff = sum(i..j) -->|
          |    i         j+1
```

---

## Hash Map + Prefix Sum: "Subarray Sum Equals K"

**Problem:** Count subarrays with sum = K.

**Brute force:** For each (i, j), compute sum → O(n²)

**Optimization:** We want prefix[j] - prefix[i] = K  
⇒ **prefix[j] = prefix[i] + K**

As we scan j from left to right, for each prefix[j], we ask: **"How many previous prefix values equal prefix[j] - K?"**

```
arr = [1, 2, 3], K = 3

prefix = [0, 1, 3, 6]
         j=0: need prefix[i]=-3  → count 0
         j=1: need prefix[i]=0   → count 1  (prefix[0]=0)  → [1,2]
         j=2: need prefix[i]=3   → count 1  (prefix[2]=3)   → [3]
         j=3: need prefix[i]=3   → count 1  (prefix[2]=3)   → [1,2,3]
         Total = 3
```

**Hash map stores:** count of each prefix value seen so far.  
**At each j:** add count(prefix[j] - K) to answer, then add prefix[j] to map.

---

## ASCII Visualizations

### 1D Prefix Build
```
arr:    [2,  1,  5,  1,  3]
         ↓   ↓   ↓   ↓   ↓
prefix: 0 → 2 → 3 → 8 → 9 → 12
        [0,  2,  3,  8,  9,  12]
```

### Range Query [1, 3]
```
prefix:  [0,  2,  3,  8,  9,  12]
          ↑       ↑
          i=1     j+1=4
          
sum[1..3] = prefix[4] - prefix[1] = 9 - 2 = 7
```

### Hash Map Scan for "Sum = K"
```
j=0: prefix=0, need -K. map={0:1}
j=1: prefix=1, need 1-K. add count, update map
j=2: prefix=3, need 3-K. add count, update map
...
```

```mermaid
flowchart TD
    A[Store prefix values in map]
    B{Lookup prefix[j]-K}
    C[count += map.get prefix[j]-K, 0]
    D[Update map with prefix[j]]

    A --> B
    B --> C
    C --> D

    style A fill:#339af0,color:#fff
    style B fill:#ffd43b,color:#000
    style C fill:#51cf66,color:#fff
    style D fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
     prefix values seen
     ┌─────────────────┐
     │  map: {0:1, 1:1}│
     └────────┬────────┘
              │ lookup prefix[j]-K
              ▼
     count += map.get(prefix[j]-K, 0)
```

</details>

### 2D Inclusion-Exclusion
```
         c1      c2
    ┌────┼───────┼────┐
 r1 │ A  │   B   │    │
    ├────┼───────┼────┤
    │ C  │   D   │    │  ← We want sum(D)
 r2 ├────┼───────┼────┤
    │    │       │    │
    └────┴───────┴────┘

Sum(D) = prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1]
         └─ A+B+C+D ─┘   └─ A+B ─┘   └─ A+C ─┘   └─ A ─┘
```

---

## FAANG Engineer Thinking Flow

1. **"Range query?"** → Prefix sum for O(1) lookup
2. **"Count subarrays with sum K?"** → Prefix + hash map, single pass
3. **"Matrix region sum?"** → 2D prefix, inclusion-exclusion
4. **"XOR / product?"** → Same structure, different op (XOR: x^x=0; product: handle zeros)
5. **"Updates?"** → Prefix sum won't work; use Segment Tree

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL MODEL:     Cumulative odometer — prefix[i] = total up to i
SUBARRAY SUM:     prefix[j+1] - prefix[i]
HASH OPTIMIZATION: prefix[j]-prefix[i]=K ⇒ prefix[j]=prefix[i]+K
                  → Count how many prefix[i] = prefix[j]-K seen so far
MAP INIT:         {0: 1} — empty prefix counts as one "starting point"
2D RULE:          Inclusion-exclusion: whole - left - top + corner
```
