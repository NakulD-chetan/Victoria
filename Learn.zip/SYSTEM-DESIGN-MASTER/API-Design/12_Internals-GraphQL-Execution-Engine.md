# Internals: GraphQL Execution Engine — Low-Level Deep Dive

> **Permanent Recall:** GraphQL execution: HTTP POST (query string) → Lexer (tokenize) → Parser (AST) → Validator (schema checks, depth/complexity limits) → Executor (breadth-first resolver calls, parent→child data flow) → Serialize JSON → HTTP response. Resolvers called per-field; DataLoader batches N+1 into single DB calls. Subscriptions use WebSocket (graphql-ws) with event source→filter→push. Performance: parsed query cache, persisted queries (hash→query), @defer/@stream for incremental delivery.

---

## 1. GraphQL Request Lifecycle — Full Journey

```
GRAPHQL REQUEST LIFECYCLE — END-TO-END:

  HTTP POST /graphql
  Content-Type: application/json
  Body: {"query": "{ user(id: 123) { name, orders { total } } }", "variables": {}}

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 1: HTTP LAYER                                                          │
  │   • Receive raw bytes                                                        │
  │   • Parse HTTP headers, extract body                                        │
  │   • Parse JSON body → extract "query" string, "variables", "operationName"   │
  │   • If query missing: check for persisted query (extensions.apq.hash)      │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 2: LEXER (Tokenization)                                                 │
  │   Input: "{ user(id: 123) { name, orders { total } } }"                     │
  │   Output: [BRACE_LEFT, NAME(user), PAREN_LEFT, NAME(id), COLON, INT(123),   │
  │           PAREN_RIGHT, BRACE_LEFT, NAME(name), COMMA, NAME(orders), ...]    │
  │   • Character-by-character scan                                              │
  │   • Emits tokens with type + value + location (line, column)                │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 3: PARSER (AST Construction)                                           │
  │   Input: Token stream                                                        │
  │   Output: Abstract Syntax Tree (Document node)                               │
  │   • Recursive descent / precedence climbing                                  │
  │   • Document → OperationDefinition → SelectionSet → Field → ...             │
  │   • Attaches location info to every node                                     │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 4: VALIDATION                                                          │
  │   Input: AST + Schema                                                        │
  │   • Field exists on type?                                                    │
  │   • Argument types correct?                                                  │
  │   • Fragments valid? (spread types, no cycles)                              │
  │   • Directives in valid locations?                                           │
  │   • Query depth ≤ limit?                                                     │
  │   • Query complexity ≤ limit?                                                │
  │   Output: ValidationErrors[] or proceed                                      │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 5: EXECUTION                                                           │
  │   Input: AST + Schema + Root value + Resolvers                              │
  │   • Execute root operation (Query, Mutation, Subscription)                  │
  │   • Breadth-first: resolve all fields at level N before level N+1           │
  │   • For each field: call resolver(parent, args, context, info)              │
  │   • Build result tree (mirrors query shape)                                  │
  │   • Null propagation: non-null child null → parent null                      │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 6: SERIALIZATION                                                       │
  │   Input: Execution result (nested object/array)                             │
  │   • JSON.stringify(result)                                                   │
  │   • Or: incremental JSON for @defer/@stream                                 │
  │   • Wrap in {"data": {...}, "errors": [...]} if needed                      │
  └─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ STEP 7: HTTP RESPONSE                                                       │
  │   HTTP/1.1 200 OK                                                            │
  │   Content-Type: application/json                                            │
  │   Body: {"data":{"user":{"name":"Alice","orders":[{"total":99}]}}}          │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Example: Step-by-Step Trace

```
EXAMPLE REQUEST:
  POST /graphql
  {"query": "query GetUser { user(id: 123) { name } }"}

STEP 1 — Parse JSON body:
  query = "query GetUser { user(id: 123) { name } }"
  variables = {}
  operationName = null (or "GetUser" if client sent it)

STEP 2 — Lexer output (simplified):
  [QUERY, NAME(GetUser), BRACE_LEFT, NAME(user), PAREN_LEFT, NAME(id), COLON,
   INT(123), PAREN_RIGHT, BRACE_LEFT, NAME(name), BRACE_RIGHT, BRACE_RIGHT]

STEP 3 — AST (simplified structure):
  Document
    └─ OperationDefinition (operation: query, name: GetUser)
         └─ SelectionSet
              └─ Field (name: user, arguments: [{name: id, value: 123}])
                   └─ SelectionSet
                        └─ Field (name: name)

STEP 4 — Validation:
  ✓ "user" exists on Query type
  ✓ "id" is required Int, 123 is valid
  ✓ "name" exists on User type
  ✓ Depth = 2 (user → name), within limit

STEP 5 — Execution:
  resolve(Query, {}, ctx, info) → {}
  resolveField(user, {id: 123}, ctx, info) → {id: 123, name: "Alice"}
  resolveField(name, {id: 123, name: "Alice"}, ctx, info) → "Alice"

STEP 6 — Result:
  {"user": {"name": "Alice"}}

STEP 7 — Response:
  {"data": {"user": {"name": "Alice"}}}
```

---

## 2. Lexer and Parser — Tokenization to AST

### Lexer: Character Stream → Token Stream

```
LEXER — HOW "{ user(id: 123) { name, orders { total } } }" BECOMES TOKENS:

  Input string (character stream):
  "{ user(id: 123) { name, orders { total } } }"
   ↑
   cursor

  Lexer state machine:
  • Skip whitespace (space, tab, newline, comma)
  • On '{'  → emit BRACE_LEFT
  • On '}'  → emit BRACE_RIGHT
  • On '('  → emit PAREN_LEFT
  • On ')'  → emit PAREN_RIGHT
  • On ':'  → emit COLON
  • On '$'  → emit DOLLAR (variable)
  • On '!'  → emit BANG (non-null)
  • On '['  → emit BRACKET_LEFT
  • On ']'  → emit BRACKET_RIGHT
  • On '|'  → emit PIPE (union in SDL)
  • On '#'  → emit HASH (comment, skip to newline)
  • On '"'  → read string (escape \", \\, \n, \r, \t, \uXXXX)
  • On digit → read Int or Float
  • On letter or _ → read Name (identifier)

  TOKEN OUTPUT (with values):
  ┌─────────────┬──────────────┬─────────────────────────────┐
  │ Token Type  │ Value        │ Location (line:col)          │
  ├─────────────┼──────────────┼─────────────────────────────┤
  │ BRACE_LEFT  │ (none)       │ 1:1                          │
  │ NAME        │ "user"       │ 1:3                          │
  │ PAREN_LEFT  │ (none)       │ 1:7                          │
  │ NAME        │ "id"         │ 1:8                         │
  │ COLON       │ (none)       │ 1:10                        │
  │ INT         │ 123          │ 1:12                        │
  │ PAREN_RIGHT │ (none)       │ 1:15                        │
  │ BRACE_LEFT  │ (none)       │ 1:17                        │
  │ NAME        │ "name"       │ 1:19                        │
  │ COMMA       │ (none)       │ 1:23                        │
  │ NAME        │ "orders"     │ 1:25                        │
  │ BRACE_LEFT  │ (none)       │ 1:32                        │
  │ NAME        │ "total"      │ 1:34                        │
  │ BRACE_RIGHT │ (none)       │ 1:39                        │
  │ BRACE_RIGHT │ (none)       │ 1:41                        │
  │ BRACE_RIGHT │ (none)       │ 1:43                        │
  └─────────────┴──────────────┴─────────────────────────────┘
```

### Parser: Token Stream → AST

```
PARSER — RECURSIVE DESCENT / PRECEDENCE CLIMBING:

  Grammar (simplified):
    Document        := Definition+
    Definition      := ExecutableDefinition | TypeSystemDefinition
    ExecutableDef   := OperationDefinition | FragmentDefinition
    OperationDef    := OperationType Name? VariableDefinitions? Directives? SelectionSet
    OperationType   := "query" | "mutation" | "subscription"
    SelectionSet    := "{" Selection+ "}"
    Selection       := Field | FragmentSpread | InlineFragment
    Field           := Alias? Name Arguments? Directives? SelectionSet?
    Arguments       := "(" Argument+ ")"
    Argument        := Name ":" Value

  Parser consumes tokens left-to-right, building tree top-down.
  On BRACE_LEFT: expect SelectionSet → parse selections until BRACE_RIGHT
  On NAME: expect Field (or FragmentSpread if "..." follows)
  On "query"|"mutation"|"subscription": expect OperationDefinition
```

### AST Structure (Tree View)

```
AST FOR: { user(id: 123) { name, orders { total } } }

  Document
  │
  └─ OperationDefinition
       ├─ kind: "OperationDefinition"
       ├─ operation: "query"
       ├─ name: null (anonymous)
       └─ selectionSet: SelectionSet
            │
            └─ selections: [
                 Field
                 ├─ kind: "Field"
                 ├─ name: Name { value: "user" }
                 ├─ arguments: [
                 │    Argument
                 │    ├─ name: Name { value: "id" }
                 │    └─ value: IntValue { value: "123" }
                 │  ]
                 ├─ directives: []
                 └─ selectionSet: SelectionSet
                      └─ selections: [
                           Field
                           ├─ name: Name { value: "name" }
                           ├─ arguments: []
                           └─ selectionSet: null
                           ,
                           Field
                           ├─ name: Name { value: "orders" }
                           ├─ arguments: []
                           └─ selectionSet: SelectionSet
                                └─ selections: [
                                     Field
                                     ├─ name: Name { value: "total" }
                                     ├─ arguments: []
                                     └─ selectionSet: null
                                   ]
                         ]
               ]
```

### Parser Implementation Sketch

```
PSEUDOCODE — PARSER:

  function parseDocument():
    definitions = []
    while not at(EOF):
      definitions.push(parseDefinition())
    return Document(definitions)

  function parseSelectionSet():
    expect(BRACE_LEFT)
    selections = []
    while not at(BRACE_RIGHT):
      selections.push(parseSelection())
    expect(BRACE_RIGHT)
    return SelectionSet(selections)

  function parseField():
    alias = parseName() if peek(COLON) else null
    if alias: expect(COLON)
    name = parseName()
    args = parseArguments() if at(PAREN_LEFT) else []
    directives = parseDirectives()
    selectionSet = parseSelectionSet() if at(BRACE_LEFT) else null
    return Field(alias, name, args, directives, selectionSet)

  function parseValue():
    if at(INT): return IntValue(lexer.value)
    if at(FLOAT): return FloatValue(lexer.value)
    if at(STRING): return StringValue(lexer.value)
    if at(NAME):
      if lexer.value in ["true","false"]: return BooleanValue(...)
      if lexer.value == "null": return NullValue()
      return Variable(lexer.value)
    if at(DOLLAR): return parseVariable()
    if at(BRACKET_LEFT): return parseListValue()
    if at(BRACE_LEFT): return parseObjectValue()
    ...
```

---

## 3. Schema and Type System — Internal Representation

```
SCHEMA INTERNAL REPRESENTATION:

  The schema is a TYPE REGISTRY — a map of type names to type definitions.
  Used for: validation (does field exist? is arg type correct?) and execution (what to resolve?).

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ TYPE REGISTRY (simplified)                                                   │
  │                                                                             │
  │ "Query"       → ObjectType { fields: { user, users, ... } }                 │
  │ "User"        → ObjectType { fields: { id, name, email, orders } }          │
  │ "Order"       → ObjectType { fields: { id, total, items } }                  │
  │ "Int"         → ScalarType                                                  │
  │ "String"      → ScalarType                                                  │
  │ "Float"       → ScalarType                                                  │
  │ "Boolean"     → ScalarType                                                  │
  │ "ID"          → ScalarType                                                  │
  │ "Node"        → InterfaceType { fields: { id } }                           │
  │ "SearchResult"→ UnionType { types: [User, Order, Product] }                 │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Object Type Structure

```
OBJECT TYPE — FIELD DEFINITIONS:

  type User {
    id: ID!
    name: String
    email: String!
    orders(limit: Int = 10): [Order!]!
  }

  Internal representation:
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ ObjectTypeDefinition                                                         │
  │   name: "User"                                                               │
  │   fields: [                                                                  │
  │     FieldDefinition {                                                        │
  │       name: "id",                                                            │
  │       type: NonNullType(of: NamedType("ID")),                                │
  │       arguments: []                                                          │
  │     },                                                                       │
  │     FieldDefinition {                                                        │
  │       name: "name",                                                          │
  │       type: NamedType("String"),                                             │
  │       arguments: []                                                          │
  │     },                                                                       │
  │     FieldDefinition {                                                        │
  │       name: "orders",                                                        │
  │       type: NonNullType(of: ListType(of: NonNullType(of: NamedType("Order")))),│
  │       arguments: [                                                            │
  │         InputValueDefinition { name: "limit", type: NamedType("Int"),        │
  │                                defaultValue: IntValue(10) }                   │
  │       ]                                                                      │
  │     }                                                                        │
  │   ]                                                                          │
  └─────────────────────────────────────────────────────────────────────────────┘

  TYPE WRAPPERS (composite types):
    NonNullType(T)  → T!   (cannot be null)
    ListType(T)     → [T]  (array of T)
    NamedType("X")  → X    (reference to type "X")
```

### Type Resolution (Interfaces and Unions)

```
INTERFACE AND UNION — RUNTIME TYPE RESOLUTION:

  interface Node {
    id: ID!
  }
  type User implements Node { id: ID! name: String }
  type Order implements Node { id: ID! total: Float }

  union SearchResult = User | Order

  When executor encounters a field of type Node or SearchResult:
  1. Resolver returns a concrete value (e.g., { __typename: "User", id: "1", name: "Alice" })
  2. Executor needs to know: which concrete type is this?
  3. __resolveType(schema, value) is called:
     - For Interface: return "User" or "Order" (or other implementors)
     - For Union: return one of the member types
  4. Executor then uses that type's fields for the selection set

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ Query: { search(q: "alice") { ... on User { name } ... on Order { total } } }│
  │                                                                             │
  │ Resolver returns: [{ __typename: "User", id: "1", name: "Alice" },          │
  │                    { __typename: "Order", id: "2", total: 99.99 }]          │
  │                                                                             │
  │ For each item: __resolveType → "User" or "Order"                            │
  │ Then: resolve "name" for User, "total" for Order                             │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Schema Used for Validation

```
VALIDATION USES SCHEMA TO:

  1. Field existence:
     Query.user → schema.getType("Query").getField("user") ✓
     Query.xyz   → schema.getType("Query").getField("xyz") → undefined → ERROR

  2. Argument types:
     user(id: 123)     → "id" expects Int, 123 is Int ✓
     user(id: "123")   → "id" expects Int, "123" is String → ERROR

  3. Output type compatibility:
     user returns User, selection { name } → User has "name" ✓
     user returns User, selection { xyz }  → User has no "xyz" → ERROR

  4. Fragment type conditions:
     ... on User { name }  → User implements/equals fragment type ✓
     ... on Order { name } → Order has "name"? Check Order type ✓

  5. Variable types:
     $id: Int!  → variable "id" must be Int and non-null
     Pass { "id": null } → ERROR (violates !)
```

---

## 4. Validation — What the Validator Checks

```
VALIDATION RULES (GraphQL spec + common extensions):

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ CORE RULES (from GraphQL spec)                                                │
  │                                                                             │
  │ • Lone anonymous operation: if only one op, no name conflict                 │
  │ • Operation name uniqueness: all ops must have unique names                  │
  │ • Subscription single root: subscription must have one root field            │
  │ • Fields on correct type: field must exist on parent type                    │
  │ • Arguments of correct type: arg value must match declared type              │
  │ • Variables in allowed position: variable usage matches declaration          │
  │ • All variable uses defined: no undefined variables                          │
  │ • All variables used: no unused variables                                    │
  │ • Fragment spread type existence: ... on X, X must be valid type              │
  │ • Fragment spread target defined: fragment must be defined                   │
  │ • No fragment cycles: A spreads B, B spreads A → ERROR                       │
  │ • Directives in valid locations: @skip only on FIELD, etc.                   │
  │ • Overlapping fields can merge: same response name, same shape               │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Depth Limiting — Protecting Against Abusive Queries

```
QUERY DEPTH — RECURSIVE NESTING:

  Malicious query:
  {
    user(id: 1) {
      friends {
        friends {
          friends {
            friends { ... }  // 10 levels deep = 10 DB round trips
          }
        }
      }
    }
  }

  Depth = 5 (root → user → friends → friends → friends → friends)

  VALIDATION: Walk AST, compute max depth. If depth > MAX_DEPTH (e.g., 10), reject.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ function getQueryDepth(selectionSet, depth = 0):                             │
  │   if selectionSet is empty: return depth                                     │
  │   maxChildDepth = depth                                                      │
  │   for each selection in selectionSet:                                        │
  │     if selection is Field and has selectionSet:                              │
  │       childDepth = getQueryDepth(selection.selectionSet, depth + 1)          │
  │       maxChildDepth = max(maxChildDepth, childDepth)                         │
  │   return maxChildDepth                                                       │
  │                                                                             │
  │ if getQueryDepth(operation.selectionSet) > MAX_DEPTH:                        │
  │   throw new ValidationError("Query too deep")                                 │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Complexity Scoring

```
QUERY COMPLEXITY — COST PER FIELD:

  Idea: Assign a cost to each field. Sum costs. Reject if total > limit.

  Simple model:
    Scalar/leaf field:     cost 1
    Object field:          cost 1 + child cost
    List field:            cost = multiplier × (1 + child cost)
                           e.g., friends(first: 10) → 10 × (1 + child)

  Example:
    query {
      user(id: 1) {           # 1
        name                  # 1
        friends(first: 100) {  # 100 × (1 + ...)
          name                # 1 each
        }
      }
    }
    Complexity ≈ 1 + 1 + 100*(1+1) = 202

  If limit = 1000: allow. If limit = 100: reject.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ function computeComplexity(field, schema, multipliers):                      │
  │   type = getFieldType(field, schema)                                         │
  │   baseCost = 1                                                               │
  │   if type is ListType:                                                       │
  │     limit = getArgumentValue(field, "first") ?? defaultListSize               │
  │     childCost = sum over selections of computeComplexity(...)                │
  │     return limit * (baseCost + childCost)                                    │
  │   else:                                                                      │
  │     return baseCost + sum over selections of computeComplexity(...)          │
  └─────────────────────────────────────────────────────────────────────────────┘

  graphql-query-complexity, graphql-cost-analysis: popular libraries
```

### Directive Location Validation

```
DIRECTIVE LOCATIONS:

  @skip(if: Boolean)   — valid on: FIELD | FRAGMENT_SPREAD | INLINE_FRAGMENT
  @include(if: Boolean)— same
  @deprecated(reason)  — valid on: FIELD_DEFINITION | ENUM_VALUE
  @defer               — valid on: FRAGMENT_SPREAD | INLINE_FRAGMENT

  Validator checks: for each directive, is it in an allowed location?
  @skip on FIELD ✓
  @skip on ARGUMENT_DEFINITION ✗
```

---

## 5. Execution Engine — Resolver Call Chain

```
EXECUTION — BREADTH-FIRST FIELD RESOLUTION:

  Rule: Resolve ALL fields at level N before descending to level N+1.
  This enables: parallel resolution of siblings, correct null propagation.

  Query: { user(id: 123) { name, orders { total } } }

  Execution order:
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ Level 0 (root):                                                              │
  │   resolveField(Query, "user", {id: 123})  →  { id: 123, name: "Alice", ... } │
  │                                                                             │
  │ Level 1 (user's selection set):                                              │
  │   resolveField(User, "name", parent)   →  "Alice"                            │
  │   resolveField(User, "orders", parent) →  [{ id: 1 }, { id: 2 }]             │
  │                                                                             │
  │ Level 2 (orders' selection set):                                              │
  │   resolveField(Order, "total", parent) for order 1  →  99.99                  │
  │   resolveField(Order, "total", parent) for order 2  →  49.50                  │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Resolver Call Chain (Detailed)

```
RESOLVER SIGNATURE:

  resolver(parent, args, context, info)
    parent:  The parent object (from parent resolver)
    args:    The arguments for this field (e.g., { id: 123 })
    context: Shared context (request-scoped: DB connection, user, etc.)
    info:    { fieldName, fieldNodes, returnType, parentType, path, schema, ... }

  Default root resolver: returns {} for Query, {} for Mutation
  Field resolvers: lookup on parent (parent[fieldName]) if no custom resolver

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ RESOLVER CALL CHAIN (with custom resolvers)                                  │
  │                                                                             │
  │ 1. executeOperation(operation, rootValue, context)                           │
  │    rootValue = {} (or custom root)                                           │
  │    → executeSelectionSet(operation.selectionSet, Query, rootValue, path)     │
  │                                                                             │
  │ 2. executeSelectionSet(selectionSet, objectType, parent, path)                │
  │    result = {}                                                               │
  │    for each selection:                                                       │
  │      executeField(selection, objectType, parent, path) → merge into result    │
  │    return result                                                             │
  │                                                                             │
  │ 3. executeField(field, parentType, parent, path)                             │
  │    fieldName = field.alias ?? field.name                                     │
  │    resolver = getResolver(schema, parentType, field.name)                     │
  │    args = coerceArgumentValues(field.arguments, variableValues)              │
  │    value = resolver(parent, args, context, buildFieldInfo(field, path))      │
  │    if value is Promise: await it                                             │
  │    if value is null/undefined and returnType is NonNull: throw/bubble null   │
  │    if field has selectionSet and value is object:                            │
  │      resolvedType = resolveAbstractType(value) if interface/union            │
  │      return executeSelectionSet(field.selectionSet, resolvedType, value, path)│
  │    return value                                                              │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Null Propagation

```
NON-NULL BUBBLING:

  type User {
    id: ID!
    name: String!
    bestFriend: User   # nullable
  }

  Query: { user(id: 1) { name, bestFriend { name } } }

  If user(id: 1) returns null:
    → Entire "user" field is null (parent of null for NonNull child? No — user is nullable)
    → Actually: user returns User!, so if resolver returns null → entire response null

  If user returns { name: "Alice", bestFriend: null }:
    → user: { name: "Alice", bestFriend: null } ✓

  If user returns { name: "Alice", bestFriend: { name: null } }:
    → bestFriend.name is String! (non-null)
    → null in non-null field → bubble up
    → bestFriend becomes null (partial null)
    → user: { name: "Alice", bestFriend: null }
    → "errors" in response: [{ path: ["user","bestFriend"], message: "Cannot return null for non-nullable field User.name" }]

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ NULL PROPAGATION RULE:                                                       │
  │   If a field's resolver returns null and the field's type is NonNull(T):     │
  │   • The parent field becomes null (or is removed)                             │
  │   • An error is added to the "errors" array with path                         │
  │   • Siblings can still be returned (partial data)                             │
  │   • If the null is at root (Query.user!), entire data is null                 │
  └─────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. DataLoader Pattern — Solving N+1

### The N+1 Problem at Execution Level

```
N+1 PROBLEM — WITHOUT DATALOADER:

  Query: {
    users(first: 10) {
      name
      posts { title }
    }
  }

  Execution:
  1. resolve users → SELECT * FROM users LIMIT 10  (1 query)
  2. For each of 10 users, resolve posts:
     resolve posts for user 1 → SELECT * FROM posts WHERE user_id=1
     resolve posts for user 2 → SELECT * FROM posts WHERE user_id=2
     ...
     resolve posts for user 10 → SELECT * FROM posts WHERE user_id=10

  Total: 1 + 10 = 11 database queries (N+1)

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ TIMELINE (without DataLoader):                                               │
  │                                                                             │
  │ t=0:    [DB] SELECT users                                                    │
  │ t=10:   [DB] SELECT posts WHERE user_id=1                                    │
  │ t=20:   [DB] SELECT posts WHERE user_id=2                                    │
  │ t=30:   [DB] SELECT posts WHERE user_id=3                                    │
  │ ...                                                                         │
  │ t=100:  [DB] SELECT posts WHERE user_id=10                                   │
  │                                                                             │
  │ 11 sequential (or parallel) DB round trips                                    │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### How DataLoader Works

```
DATALOADER — BATCHING + CACHING:

  1. BATCHING: Collect all IDs requested during one "tick" (synchronous execution).
     At end of tick, make ONE batch request with all IDs.
     Distribute results back to each caller.

  2. CACHING: Per-request cache. Same ID requested twice in one request? Return cached.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ const userLoader = new DataLoader(async (userIds) => {                      │
  │   const users = await db.users.findByIds(userIds);  // single query          │
  │   return userIds.map(id => users.find(u => u.id === id) ?? null);            │
  │ });                                                                         │
  │                                                                             │
  │ // In resolver:                                                              │
  │ User: {                                                                      │
  │   posts: (user) => postLoader.loadManyByUserId(user.id)  // or custom batch  │
  │ }                                                                            │
  │                                                                             │
  │ postLoader = new DataLoader(async (userIds) => {                             │
  │   const posts = await db.posts.findByUserIds(userIds);  // WHERE user_id IN  │
  │   return userIds.map(uid => posts.filter(p => p.user_id === uid));           │
  │ });                                                                         │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Internal Queue and Microtask Batching

```
DATALOADER INTERNALS — QUEUE + MICROTASK:

  When you call loader.load(1):
    1. Add key "1" to queue
    2. Schedule a "dispatch" on next microtask (process.nextTick / queueMicrotask)
    3. Return a Promise that will resolve when batch completes

  When you call loader.load(2), loader.load(3), ... in same tick:
    • Keys accumulate in queue: [1, 2, 3, ...]
    • Same microtask scheduled (only one)

  At end of current tick (when JS yields):
    • Microtask runs: dispatchBatch()
    • Batch function called with [1, 2, 3, ...]
    • Single batch request: findByIds([1,2,3,...])
    • Results distributed: Promise for 1 → result[0], Promise for 2 → result[1], ...
    • Queue cleared

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ TIMELINE (with DataLoader):                                                  │
  │                                                                             │
  │ t=0:    resolve users → 10 users                                             │
  │ t=1:    resolve posts(user 1) → postLoader.load(1) → queue [1]               │
  │ t=2:    resolve posts(user 2) → postLoader.load(2) → queue [1,2]             │
  │ ...    (all 10 happen in same tick)                                          │
  │ t=10:   queue [1,2,3,4,5,6,7,8,9,10]                                        │
  │ t=11:   [MICROTASK] dispatchBatch([1..10])                                  │
  │ t=12:   [DB] SELECT * FROM posts WHERE user_id IN (1,2,3,4,5,6,7,8,9,10)   │
  │ t=22:   Results returned, Promises resolved                                  │
  │                                                                             │
  │ Total: 1 (users) + 1 (posts batch) = 2 database queries                     │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Per-Request Cache

```
CACHING — SAME ID, SAME REQUEST:

  Query: {
    user(id: 1) { name }
    me { name }   // me also returns user 1
  }

  Without cache: user(id:1) and me might both trigger load(1) → 2 batch entries
  With DataLoader cache: first load(1) → batch; second load(1) → cache hit, no batch

  Cache is per-request: new DataLoader per HTTP request, or clear cache between requests.
  Never share DataLoader across requests (stale data risk).
```

---

## 7. Subscriptions — WebSocket and Event Push

```
GRAPHQL SUBSCRIPTIONS — REAL-TIME UPDATES:

  Unlike queries/mutations (request-response), subscriptions are long-lived.
  Client subscribes → server holds connection → server pushes events when they occur.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ TRANSPORT: WebSocket (graphql-ws protocol)                                   │
  │                                                                             │
  │ Alternative: SSE (Server-Sent Events), or HTTP long-polling (legacy)         │
  │ graphql-ws is the standard: subprotocol "graphql-ws"                         │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### graphql-ws Protocol

```
GRAPHQL-WS PROTOCOL — MESSAGE TYPES:

  Client → Server:
    connection_init  { payload?: { authToken, ... } }
    subscribe        { id: "1", payload: { query, variables, operationName } }
    ping             (keepalive)
    complete         { id: "1" }  (cancel subscription)

  Server → Client:
    connection_ack    { payload?: { connectionTimeout? } }
    connection_error { payload: { message } }
    next             { id: "1", payload: { data, errors? } }
    error            { id: "1", payload: { message, locations? } }
    complete         { id: "1" }
    pong             (response to ping)

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ CONNECTION LIFECYCLE:                                                        │
  │                                                                             │
  │ 1. Client opens WebSocket to ws://api.example.com/graphql                    │
  │ 2. Client sends connection_init (optional auth)                              │
  │ 3. Server sends connection_ack                                               │
  │ 4. Client sends subscribe { id: "1", payload: { query: "subscription { ... }" }│
  │ 5. Server executes subscription: resolves root field, gets AsyncIterator     │
  │ 6. On each event: Server sends next { id: "1", payload: { data: {...} } }   │
  │ 7. Client sends complete { id: "1" } to unsubscribe, or connection closes   │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Subscription Field Resolution

```
SUBSCRIPTION RESOLUTION — ASYNC ITERATOR:

  type Subscription {
    messageAdded(roomId: ID!): Message!
  }

  Resolver for messageAdded:
  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ Subscription: {                                                              │
  │   messageAdded: {                                                            │
  │     subscribe: async function* (parent, args, context) {                     │
  │       const { roomId } = args;                                                │
  │       const channel = pubsub.asyncIterator(`room:${roomId}`);                │
  │       for await (const event of channel) {                                   │
  │         yield { messageAdded: event.message };                                │
  │       }                                                                      │
  │     }                                                                        │
  │   }                                                                          │
  │ }                                                                            │
  └─────────────────────────────────────────────────────────────────────────────┘

  Unlike Query/Mutation: resolver returns AsyncIterator, not a single value.
  Each yielded value is executed as a "mini query" over the selection set.
  Result is sent to client as next message.
```

### Event Source → Filter → Push

```
EVENT FLOW:

  ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
  │ Event Source │────►│   Filter    │────►│   Resolve    │────►│   Push       │
  │ (DB, Redis,  │     │ (roomId,    │     │ selection    │     │ to client    │
  │  Kafka, etc) │     │  userId)    │     │ set for each │     │ via WS       │
  └──────────────┘     └──────────────┘     └──────────────┘     └──────────────┘

  Example: Chat app
    • Event: New message inserted into DB
    • Pub/Sub: Redis pubsub or in-memory EventEmitter
    • Filter: Only subscribers to that roomId receive it
    • Resolve: For each event, run GraphQL execution for { messageAdded { id, text, author { name } } }
    • Push: Send { data: { messageAdded: {...} } } to each subscribed client
```

---

## 8. Performance Internals

### Parsed Query Cache (AST Cache)

```
PARSED AST CACHE:

  Parsing is expensive: lexer + parser for every request.
  Same query string → same AST. Cache it.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ Cache key: query string (or hash of query string)                            │
  │ Cache value: Parsed Document (AST)                                           │
  │                                                                             │
  │ Map<queryHash, Document>                                                     │
  │                                                                             │
  │ First request:  parse(query) → 2ms, store in cache                           │
  │ Second request: cache.get(query) → 0.1ms (hash lookup + return)              │
  │                                                                             │
  │ Eviction: LRU, max 1000 entries, or TTL                                     │
  │ Security: limit cache size to prevent DoS (huge unique queries)               │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Persisted Queries (Hash → Stored Query)

```
PERSISTED QUERIES — CLIENT SENDS HASH, SERVER LOOKS UP QUERY:

  Problem: Large query strings in every request (bandwidth, parsing)
  Solution: Store queries server-side. Client sends only hash.

  ┌─────────────────────────────────────────────────────────────────────────────┐
  │ FIRST REQUEST (registration):                                                │
  │   Client: POST { query: "{ user(id:1) { name } }", extensions: { apq: {} } } │
  │   Server: Parses, validates, stores hash("query") → query                    │
  │   Server: Returns { data: {...}, extensions: { apq: { hash: "abc123" } } }  │
  │                                                                             │
  │ SUBSEQUENT REQUESTS:                                                         │
  │   Client: POST { extensions: { persistedQuery: { version: 1, sha256Hash: "abc123" } } } │
  │   Server: Lookup "abc123" → get stored query                                 │
  │   If found: execute stored query                                             │
  │   If not found: 400 "PersistedQueryNotFound" (client must retry with full query) │
  │                                                                             │
  │ Bandwidth: 50 bytes (hash) vs 200+ bytes (full query)                       │
  │ Security: Only allow whitelisted queries (prevent arbitrary query execution)  │
  └─────────────────────────────────────────────────────────────────────────────┘
```

### Response Serialization Cost

```
SERIALIZATION — JSON.stringify IS NOT FREE:

  • Large responses: 100KB+ JSON
  • String concatenation, escaping, number formatting
  • Can be 5–10% of total request time for large payloads

  Optimizations:
  • Streaming JSON (write chunks as resolvers complete)
  • @defer: send partial response early, then stream remaining
  • @stream: stream list items as they resolve
  • Binary protocols (e.g., MessagePack) for internal services
```

### @defer and @stream — Incremental Delivery

```
@defer — DEFER A FRAGMENT:

  query {
    user(id: 1) { name }
    ... on Query @defer {
      slowData { items }
    }
  }

  Response (multipart):
  ---
  {"data":{"user":{"name":"Alice"}},"hasNext":true}
  ---
  {"incremental":[{"path":[],"data":{"slowData":{"items":[...]}}}],"hasNext":false}
  ---

  Client gets user.name immediately. slowData arrives later in second chunk.

  Execution: First chunk = execute without deferred parts. Deferred parts run async, sent when ready.


@stream — STREAM A LIST:

  query {
    users(first: 1000) @stream(initialCount: 5) {
      name
    }
  }

  Response:
  ---
  {"data":{"users":[{"name":"A"},{"name":"B"},{"name":"C"},{"name":"D"},{"name":"E"}]},"hasNext":true}
  ---
  {"incremental":[{"path":["users",5],"items":[{"name":"F"}]}]}
  ---
  {"incremental":[{"path":["users",6],"items":[{"name":"G"}]}]}
  ...

  initialCount: 5 → send first 5 items immediately. Rest stream as they resolve.
  Client can render first 5, show loading for rest.
```

---

## 30-SECOND REVISION BOX

```
LIFECYCLE: HTTP POST → parse body → lex → parse AST → validate → execute → serialize → response
LEXER: char stream → tokens (BRACE_LEFT, NAME, INT, etc.) with location
PARSER: tokens → AST (Document → OperationDefinition → SelectionSet → Field)
SCHEMA: type registry (ObjectType, Interface, Union, Scalar), field defs, arg types
VALIDATION: field existence, arg types, fragments, directives, depth limit, complexity
EXECUTION: breadth-first, resolver(parent, args, ctx, info), null propagation for NonNull
DATALOADER: batch IDs in one tick → single batch request, per-request cache, microtask dispatch
SUBSCRIPTIONS: WebSocket graphql-ws, subscribe → AsyncIterator → next messages, event→filter→push
PERFORMANCE: AST cache (parse once), persisted queries (hash→query), @defer/@stream incremental
```

---

**Prev: [[11_Internals-REST-HTTP-Caching-Mechanics]] | Next: [[13_Internals-gRPC-HTTP2-Streaming]]**
