# SQL Interview Mastery — Concept

> **Permanent recall:** SQL interviews test **pattern recognition** + **edge-case handling** + **optimization awareness**. Every question maps to one of: aggregation, window, join, subquery, or string/date manipulation. Know the **common query shapes** and you'll solve 90% of problems.

---

## FAANG SQL interview categories

| Category | Weight (approx) | Example |
|----------|-----------------|---------|
| **Aggregation + GROUP BY** | 25% | Revenue per month, ratios |
| **Window functions** | 25% | Top-N per group, running totals, consecutive |
| **Joins** | 20% | Anti-join, self-join, multi-table |
| **Subqueries / CTE** | 15% | Correlated count, pipeline |
| **String / Date / CASE** | 10% | Date arithmetic, conditional logic |
| **Schema / Theory** | 5% | Normalization, indexes, ACID |

---

## Query-writing framework (4 steps)

1. **Clarify** — what entity, what grain, what time range?
2. **Skeleton** — `FROM … JOIN … WHERE … GROUP BY … SELECT`
3. **Edge cases** — NULL, ties, empty groups, duplicates.
4. **Optimize** — index? covering? rewrite?

---

## Top interview patterns

| Pattern | Template |
|---------|----------|
| Top-N per group | `DENSE_RANK() OVER (PARTITION BY … ORDER BY …)` → CTE → filter |
| Ratio / rate | `AVG(CASE WHEN condition THEN 1 ELSE 0 END)` |
| Consecutive detection | `LAG` / `ROW_NUMBER` diff trick |
| Anti-join (missing) | `LEFT JOIN … WHERE IS NULL` or `NOT EXISTS` |
| Running total | `SUM() OVER (ORDER BY … ROWS UNBOUNDED PRECEDING)` |
| Weighted average | `SUM(value * weight) / SUM(weight)` |
| Island / gap | `date - ROW_NUMBER()` constant grouping |
| Self-comparison | Self-join with alias (`e` vs `m`) |

---

## Complete SQL Definitions Glossary (A-Z)

> Quick-reference for any SQL theory question asked in interview.

| Term | Definition |
|------|-----------|
| **ACID** | Transaction guarantees: Atomicity, Consistency, Isolation, Durability |
| **Aggregate function** | Function that operates on set of rows, returns single value (COUNT, SUM, AVG, MIN, MAX) |
| **Alias** | Temporary name for table or column using AS keyword |
| **ALTER** | DDL command to modify table structure (add/drop/modify columns, constraints) |
| **Anti-join** | Find rows in A with no match in B (LEFT JOIN + IS NULL, NOT EXISTS) |
| **Atomicity** | All operations in transaction succeed or all rollback |
| **AUTO_INCREMENT / SERIAL / IDENTITY** | Auto-generates unique integer for new rows (dialect-specific) |
| **B-tree** | Balanced tree — default index data structure. O(log n) lookups |
| **BASE** | NoSQL consistency model: Basically Available, Soft state, Eventually consistent |
| **BETWEEN** | Range predicate, inclusive both ends |
| **BLOB** | Binary Large Object — stores binary data (images, files) |
| **Candidate key** | Minimal set of columns that uniquely identifies rows. One becomes PK |
| **Cardinality** | Number of rows in table; also relationship type (1:1, 1:N, M:N) |
| **CASCADE** | FK action — auto delete/update child rows when parent changes |
| **CASE WHEN** | SQL conditional expression (like if-else) |
| **CHECK constraint** | Enforces custom boolean condition on column |
| **Clustered index** | Data physically sorted by index key. One per table |
| **COALESCE** | Returns first non-NULL argument |
| **Composite key** | Key made of multiple columns |
| **Constraint** | Rule enforced by DB (NOT NULL, UNIQUE, PK, FK, CHECK, DEFAULT) |
| **Correlated subquery** | Inner query references outer query columns. Re-runs per outer row |
| **Covering index** | Index containing all columns query needs (index-only scan) |
| **CROSS JOIN** | Cartesian product — every left row × every right row |
| **CTE** | Common Table Expression — named temp result with WITH clause |
| **CUBE** | OLAP GROUP BY extension — all combination subtotals |
| **Cursor** | Row-by-row result processing (avoid — use set-based SQL) |
| **Data integrity** | Accuracy/consistency of data. Types: Entity, Referential, Domain, User-defined |
| **DDL** | Data Definition Language — CREATE, ALTER, DROP, TRUNCATE |
| **Deadlock** | Two transactions each waiting for the other's lock |
| **DEFAULT constraint** | Auto-fills value if not provided |
| **DELETE** | DML — removes rows (can use WHERE), fully logged, fires triggers |
| **Denormalization** | Adding redundancy back for read performance |
| **DENSE_RANK** | Window ranking — ties share rank, no gaps |
| **Derived table** | Subquery in FROM clause (inline temp table) |
| **DISTINCT** | Removes duplicate rows from result |
| **DML** | Data Manipulation Language — INSERT, UPDATE, DELETE |
| **Domain** | Set of allowed values for a column |
| **DQL** | Data Query Language — SELECT |
| **DROP** | DDL — removes entire table/object |
| **Durability** | Committed data survives crash (WAL) |
| **Entity integrity** | PK uniqueness + not null |
| **EXCEPT / MINUS** | Set operation — rows in first query but not second |
| **EXISTS** | TRUE if subquery returns at least one row |
| **EXPLAIN** | Shows query execution plan |
| **Fact table** | Central table in star schema containing measures/metrics |
| **FIRST_VALUE** | Window function — first value in frame |
| **Foreign key** | Column referencing PK/UNIQUE of another table |
| **Full-text index** | Index for text searching (words, phrases) |
| **FULL OUTER JOIN** | All rows from both tables, NULLs for non-matches |
| **Function (UDF)** | Returns value, usable in SQL expressions (SELECT, WHERE) |
| **GROUP BY** | Groups rows by specified columns for aggregation |
| **GROUPING SETS** | Explicit multiple grouping combinations |
| **GIN / GiST** | Postgres index types for JSON, arrays, full-text, geometry |
| **HAVING** | Filters groups after GROUP BY (can use aggregates) |
| **Hash join** | Join algorithm — build hash table on smaller table, probe with larger |
| **Identity column** | Auto-incrementing column (SQL Server terminology) |
| **Index** | Data structure to speed up lookups (B-tree, hash) |
| **INNER JOIN** | Only matching rows from both tables |
| **INSERT** | DML — adds new rows |
| **INTERSECT** | Set operation — only rows in both queries |
| **Isolation** | Concurrent transactions don't interfere |
| **Isolation level** | Read Uncommitted → Read Committed → Repeatable Read → Serializable |
| **Junction table** | Bridge table for M:N relationship (two FKs) |
| **LAG / LEAD** | Window offset functions — previous/next row value |
| **LAST_VALUE** | Window function — last value in frame (watch default frame!) |
| **LEFT JOIN** | All left rows + matching right (NULL if no match) |
| **LIKE** | Pattern matching (% = any chars, _ = one char) |
| **LIMIT / TOP / FETCH** | Restrict number of result rows |
| **Locking** | Mechanism to prevent concurrent data corruption |
| **Materialized view** | View that stores results physically (needs refresh) |
| **MERGE (UPSERT)** | INSERT or UPDATE based on whether row exists |
| **Merge join** | Join algorithm — sort both tables, merge |
| **MVCC** | Multi-Version Concurrency Control — snapshot isolation, no read-write blocking |
| **Natural key** | Business-meaningful key (email, SSN) |
| **Nested loop** | Join algorithm — for each outer row, scan inner |
| **Non-clustered index** | Separate B-tree with pointers to data rows |
| **Normalization** | Organizing tables to minimize redundancy (1NF → BCNF) |
| **NOT NULL** | Column cannot contain NULL |
| **NTH_VALUE** | Window function — Nth value in frame |
| **NTILE** | Window function — divide into N buckets |
| **NULL** | Unknown/missing value — not zero, not empty string |
| **NULLIF** | Returns NULL if two values equal |
| **OLAP** | Online Analytical Processing — complex reads, reporting |
| **OLTP** | Online Transaction Processing — frequent writes, transactions |
| **Optimistic locking** | No lock, check version at write, retry on conflict |
| **ORDER BY** | Sorts result set (ASC default) |
| **Partitioning** | Splitting large table into smaller physical pieces |
| **PERCENT_RANK** | Window function — relative rank as fraction (0 to 1) |
| **Pessimistic locking** | Lock before read (SELECT FOR UPDATE) |
| **Phantom read** | Re-run query, different row set |
| **Primary key** | Unique + NOT NULL, one per table |
| **RANK** | Window ranking — ties share rank, gaps after |
| **RDBMS** | Relational Database Management System |
| **Recursive CTE** | CTE that references itself (for hierarchies) |
| **Referential integrity** | FK values match existing PK |
| **RESTRICT** | FK action — block parent change if children exist |
| **ROLLBACK** | Undo current transaction |
| **ROLLUP** | OLAP GROUP BY extension — hierarchical subtotals |
| **ROW_NUMBER** | Window ranking — unique 1..n |
| **SAVEPOINT** | Marker within transaction for partial rollback |
| **Scalar subquery** | Returns single value (one row, one column) |
| **Schema** | Database structure — tables, columns, types, constraints |
| **SELECT** | DQL — retrieves data |
| **Self-join** | Joining table with itself |
| **Semi-join** | EXISTS check — returns outer rows where match exists |
| **Serializable** | Highest isolation — complete isolation, no anomalies |
| **SET NULL** | FK action — set child FK to NULL on parent delete |
| **Snowflake schema** | Star schema with normalized dimensions |
| **Star schema** | Fact table + denormalized dimensions (data warehouse) |
| **Stored procedure** | Precompiled SQL collection in DB. Called with CALL/EXEC |
| **Subquery** | Query nested inside another query |
| **Super key** | Any column set that uniquely identifies rows (may include extras) |
| **Surrogate key** | System-generated artificial key (auto-increment, UUID) |
| **Temp table** | Temporary table existing for session/scope duration |
| **Transaction** | Logical unit of work — all or nothing (ACID) |
| **Transitive dependency** | Non-key depends on another non-key (3NF violation) |
| **Trigger** | Auto-fires on DML events (INSERT/UPDATE/DELETE) |
| **TRUNCATE** | DDL — removes all rows fast, no triggers, resets identity |
| **Tuple** | One row / record in a table |
| **Two-Phase Locking** | Growing (acquire) → Shrinking (release) phases |
| **UNION** | Combines two SELECTs, removes duplicates |
| **UNION ALL** | Combines two SELECTs, keeps duplicates |
| **UNIQUE constraint** | All values in column must be distinct |
| **UPDATE** | DML — modifies existing rows |
| **USING clause** | Join shorthand when column has same name in both tables |
| **View** | Virtual table — stored query, no data storage |
| **WAL** | Write-Ahead Logging — log changes before data file for durability |
| **WHERE** | Filters rows before grouping |
| **Window function** | Calculation across related rows without collapsing (OVER clause) |

---

*Next: [[02_Mental-Model]]*
