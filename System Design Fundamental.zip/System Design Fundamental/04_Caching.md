# Caching — System Ko Lightning Fast Banao

> **Caching = Baar baar use hone wala data fast jagah rakh do**
> Socho library mein baar baar jaane ki jagah kitaab desk pe rakh lo — bas yehi caching hai!

---

## Table of Contents
1. [Caching Kya Hai?](#1-caching-kya-hai)
2. [80/20 Rule — Why Caching Works](#2-8020-rule--why-caching-works)
3. [Speed Hierarchy](#3-speed-hierarchy)
4. [Where to Cache](#4-where-to-cache)
5. [The Big 5 Caching Strategies](#5-the-big-5-caching-strategies)
6. [Cache Eviction Policies](#6-cache-eviction-policies)
7. [LRU Internal Working](#7-lru-internal-working)
8. [Cache Invalidation](#8-cache-invalidation)
9. [Thundering Herd Problem](#9-thundering-herd-problem)
10. [Redis vs Memcached](#10-redis-vs-memcached)
11. [Redis Data Structures](#11-redis-data-structures)
12. [Cache Warming](#12-cache-warming)
13. [Distributed Caching](#13-distributed-caching)
14. [Cache Metrics](#14-cache-metrics)
15. [Cache Key Design](#15-cache-key-design)
16. [Golden Rules & When NOT to Cache](#16-golden-rules--when-not-to-cache)

---

## 1. Caching Kya Hai?

### What Problem This Solves
- **Problem:** Database har baar slow hai (disk read), network latency hai
- **Solution:** Frequently accessed data ko fast memory mein rakh do

### Why Needed
- User experience: Fast response = happy user
- Cost: Database load kam = cheaper infra
- Scalability: DB bottleneck nahi hoga

### Core Concept
**Caching = Temporary storage of frequently used data in faster memory**

### Real World Analogy — Bookshelf vs Library
```
LIBRARY (Database)          DESK (Cache)
┌─────────────────┐        ┌─────────────────┐
│ 10 lakh books   │        │ 5-10 books      │
│ Sab kuch hai    │   vs   │ Jo padh rahe ho │
│ Door hai        │        │ Paas hai        │
│ Slow access     │        │ Instant access  │
└─────────────────┘        └─────────────────┘

Library se har baar jaana = DB query (slow)
Desk pe rakhna = Cache (fast)
```

### Internal Working (Step-by-Step)
1. **First Request:** App → DB se data lo → Cache mein store karo → User ko do
2. **Next Requests:** App → Cache check → Agar hai toh direct do (DB skip!)
3. **Cache Miss:** Agar cache mein nahi → DB se lo → Cache update → User ko do

### Interview Questions
- "Caching kya hai aur kyu use karte hain?"
- "Cache aur database mein fundamental difference kya hai?"

### Follow-up Questions
- "Agar cache aur DB mein data different ho jaye toh?"
- "Cache fail ho jaye toh system kaise handle karega?"

### Common Mistakes
- Cache ko source of truth samajhna (galat! DB hai)
- Cache bina TTL ke use karna
- Sensitive data cache mein without encryption

### Quick Recall Summary
Cache = temporary fast copy. DB = truth. Use for speed, not persistence.

### 1 Minute Recall Block
> Cache = Fast memory mein copy. DB = Source of truth. Cache = Temporary copy for speed.

### 5 Bullet Memory Hooks
- Cache = Copy, not original
- Read fast, write carefully
- Invalidation = sabse mushkil
- 80% traffic 20% data pe
- Speed vs Freshness trade-off

### ⚠️ Common Interview Trap
**Q: "Cache aur Database mein kya difference?"** — Don't say "cache fast hai." Say: "Cache is volatile copy for read performance; DB is persistent source of truth. Cache can be rebuilt from DB."

---

## 2. 80/20 Rule — Why Caching Works

### What Problem This Solves
- Sab data cache mein nahi rakh sakte (memory limited)
- Kaun sa data cache karein?

### Why Needed
- Pareto Principle: 80% requests 20% data pe aate hain
- Matlab 20% data cache karke 80% requests fast kar sakte ho!

### Core Concept
**Pareto Principle in Caching:** Small subset of data gets majority of reads

### Real World Example
```
E-commerce site:
- 1000 products total
- Top 50 products = 80% page views
- Bas 50 products cache karo = 80% requests fast!
```

### ASCII Diagram
```
Requests Distribution:
┌────────────────────────────────────────┐
│ ████████████████████ 80% requests      │
│         ↓                              │
│    Top 20% data (hot data)             │
├────────────────────────────────────────┤
│ ████ 20% requests                      │
│         ↓                              │
│    Remaining 80% data (cold data)      │
└────────────────────────────────────────┘
```

### Interview Questions
- "Cache mein kya kya store karna chahiye?"
- "Kaise decide karein kaun sa data hot hai?"

### Follow-up Questions
- "Hot data kaise identify karte hain production mein?"
- "Cold data ko cache mein kab add karein?"

### Common Mistakes
- Sab data cache karna (memory waste)
- Hot data ko identify na karna
- Cold data cache karke hit rate kam karna

### Quick Recall Summary
Pareto principle: 20% data = 80% traffic. Cache the hot 20%.

### 1 Minute Recall Block
> 80/20 = 20% data serves 80% traffic. Cache that 20% = big win!

### 5 Bullet Memory Hooks
- Pareto = 80-20 split
- Hot data = frequently accessed
- Cold data = rarely accessed
- Cache hot, not cold
- Identify hot keys = optimization

---

## 3. Speed Hierarchy

### What Problem This Solves
- Kahan cache karein? Kitna fast hoga?

### Core Concept
**Closer to CPU = Faster. Farther = Slower.**

### Speed Comparison Table
| Storage Type | Latency | Relative Speed | Use Case |
|--------------|---------|----------------|----------|
| CPU L1 Cache | ~1 ns | 1x (fastest) | CPU registers |
| CPU L2/L3 Cache | ~10 ns | 10x | CPU cache |
| RAM | ~100 ns | 100x | Application cache |
| SSD | ~100 µs | 100,000x | Database |
| HDD | ~10 ms | 10,000,000x | Cold storage |
| Network | ~1-100 ms | 1M-100Mx | API calls |

### ASCII Diagram
```
SPEED HIERARCHY (Top = Fastest)
─────────────────────────────────────────────────────────────────
┌─────────────┐
│  CPU L1     │  1 ns   ← Fastest (in-chip)
├─────────────┤
│  CPU L2/L3  │  10 ns
├─────────────┤
│  RAM        │  100 ns ← App cache yahan
├─────────────┤
│  SSD        │  100 µs ← DB usually yahan
├─────────────┤
│  HDD        │  10 ms
├─────────────┤
│  Network    │  1-100ms ← API call
└─────────────┘
```

### Real World Analogy
- **CPU Cache** = Pocket mein paisa (instant)
- **RAM** = Wallet (seconds)
- **SSD** = Bank nearby (minutes)
- **Network** = Bank door wala (hours)

### 1 Minute Recall Block
> RAM ~100ns, SSD ~100µs, Network ~1ms. 1000x difference! Cache in RAM when possible.

---

## 4. Where to Cache

### What Problem This Solves
- Cache kahan lagayein? Client se DB tak multiple layers

### Full Stack Caching Layers
```
USER REQUEST FLOW — Cache at Every Layer!
═══════════════════════════════════════════════════════════════

[User Browser]
     │
     ▼ Cache Layer 1: Browser Cache (localStorage, HTTP cache)
[Client-Side]
     │
     ▼ Cache Layer 2: CDN (images, static assets)
[CDN Edge]
     │
     ▼ Cache Layer 3: API Gateway / Load Balancer cache
[API Gateway]
     │
     ▼ Cache Layer 4: Application Cache (in-memory)
[App Server]
     │
     ▼ Cache Layer 5: Distributed Cache (Redis/Memcached)
[Redis Cluster]
     │
     ▼ Cache Layer 6: Database Query Cache
[Database]
     │
     ▼
[Disk]
```

### Each Layer Explained

| Layer | What to Cache | Latency Saved | Example |
|-------|---------------|---------------|---------|
| Browser | JS, CSS, images | Network round-trip | localStorage, Cache API |
| CDN | Static assets | Global latency | CloudFront, Cloudflare |
| API Gateway | API responses | App + DB call | Kong, AWS API Gateway |
| App | Session, computed | DB/Redis call | HashMap, Guava Cache |
| Redis | DB query results | DB disk read | Redis, Memcached |
| DB | Query results | Disk I/O | MySQL query cache |

### Real World Example
```
Netflix page load:
1. Browser: Logo, CSS cached
2. CDN: Thumbnail images from edge
3. API: "Trending" list cached at gateway
4. App: User session in memory
5. Redis: Movie metadata
6. DB: Only for fresh/rare data
```

### 1 Minute Recall Block
> Cache har layer pe! Browser → CDN → Gateway → App → Redis → DB. Closer to user = faster.

---

## 5. The Big 5 Caching Strategies

### Overview Table
| Strategy | Read Path | Write Path | Use Case |
|----------|-----------|------------|----------|
| Cache-Aside | App checks cache first | App writes to DB, then invalidates cache | Most common |
| Read-Through | Cache fetches if miss | App writes to DB only | Read-heavy |
| Write-Through | Same as read | Write to cache + DB sync | Consistency needed |
| Write-Behind | Same as read | Write cache, async DB | Write-heavy |
| Write-Around | Same as read | Write DB only | Write-only data |

---

### 5.1 Cache-Aside (Lazy Loading)

**What Problem:** App ko full control chahiye cache pe

**Why Most Common:** Flexible, app decides kya cache kare

**Core Concept:** Application manages cache. Cache is "aside" from DB.

**Internal Working — Step by Step:**

**READ:**
```
Step 1: App → Cache check
Step 2a: HIT → Return data (DB skip!)
Step 2b: MISS → App → DB fetch → App → Cache populate → Return
```

**WRITE:**
```
Step 1: App → DB write
Step 2: App → Cache invalidate (delete) OR update
Step 3: Next read will cache miss → lazy load
```

**ASCII Diagram:**
```
READ FLOW (Cache-Aside):
┌──────┐     ┌──────┐     ┌──────┐
│ App  │────▶│Cache │────▶│  DB  │
└──────┘     └──────┘     └──────┘
    │            │            │
    │  1. Check  │            │
    │───────────▶│            │
    │            │            │
    │  2a. HIT   │            │
    │◀───────────│            │
    │   OR       │            │
    │  2b. MISS  │  3. Fetch  │
    │─────────────────────────▶│
    │  4. Populate cache       │
    │───────────▶│            │
```

**Real World:** E-commerce product page — app checks Redis, miss pe DB query

**1 Minute Recall:** App controls cache. Read: check→miss→DB→populate. Write: DB→invalidate.

**⚠️ Common Interview Trap:** "Cache-Aside mein write-through kyu nahi?" — Because we invalidate on write to avoid stale data. Populating on write = extra logic, invalidation simpler.

---

### 5.2 Read-Through

**What Problem:** App ko cache logic nahi likhni

**Core Concept:** Cache layer khud fetch karta hai on miss. App sirf cache ko call karta hai.

**Internal Working:**
```
App → Cache.get(key)
       │
       ├─ HIT: Return
       └─ MISS: Cache fetches from DB (via loader) → Store → Return
```

**ASCII:**
```
┌──────┐         ┌──────────────────┐         ┌──────┐
│ App  │────────▶│ Cache (with      │────────▶│  DB  │
└──────┘         │  Loader/Plugin)  │         └──────┘
                 └──────────────────┘
                 Cache handles DB fetch internally
```

**Real World:** DynamoDB DAX, some Redis patterns

**1 Minute Recall:** Cache has DB loader. App only talks to cache. Cache is transparent.

---

### 5.3 Write-Through

**What Problem:** Strong consistency chahiye — cache aur DB sync

**Core Concept:** Write goes to BOTH cache and DB simultaneously. Always consistent.

**Internal Working:**
```
Write: App → Cache write → Cache writes to DB (sync) → Both updated
Read: App → Cache (always has latest)
```

**ASCII:**
```
WRITE FLOW:
┌──────┐
│ App  │──Write──▶┌──────┐
└──────┘          │Cache │──sync write──▶┌──────┐
                  └──────┘               │  DB  │
                     │                   └──────┘
                     └── Both updated together
```

**Trade-off:** Write latency = DB latency (slower writes)

**1 Minute Recall:** Write to cache + DB together. Read always from cache. Consistent but slower writes.

---

### 5.4 Write-Behind (Write-Back)

**What Problem:** Write throughput bahut zyada, DB slow

**Core Concept:** Write to cache immediately (fast!). DB write happens async in background.

**Internal Working:**
```
Write: App → Cache (instant) → Queue → Async worker → DB
Read: App → Cache (has latest)
```

**ASCII:**
```
┌──────┐     ┌──────┐     ┌───────┐     ┌──────┐
│ App  │────▶│Cache │────▶│ Queue │────▶│  DB  │
└──────┘     └──────┘     └───────┘     └──────┘
     │            │            │
     │  Instant   │  Async     │  Eventually
     │  response  │  batch     │  consistent
```

**Risk:** Cache crash = data loss (not yet in DB)!

**Real World:** Analytics, click tracking, logs

**1 Minute Recall:** Write cache first, DB later. Fast but risky. Use for non-critical writes.

---

### 5.5 Write-Around

**What Problem:** Data write-only hai, read rarely (e.g., logs)

**Core Concept:** Write directly to DB. Cache only on read (cache-aside read).

**Internal Working:**
```
Write: App → DB only (cache bypass)
Read: App → Cache check → Miss → DB → Cache populate
```

**1 Minute Recall:** Write bypasses cache. Cache fills on read. For write-heavy, read-rare data.

---

## 6. Cache Eviction Policies

### What Problem
Cache full ho gaya — kya delete karein?

### Policies Comparison Table
| Policy | Full Form | Logic | Use Case |
|--------|-----------|-------|----------|
| LRU | Least Recently Used | Jo sabse purana use hua, delete | General purpose |
| LFU | Least Frequently Used | Jo kam use hua, delete | Popular content |
| FIFO | First In First Out | Jo pehle aaya, delete | Simple |
| Random | Random | Random delete | Quick eviction |
| TTL | Time To Live | Time expire = delete | Time-sensitive data |

### LRU — Closet Analogy
```
Socho tumhara closet (cache) full hai:
- LRU = Jo kapde pehle pehne the (recently nahi), 
        unko bahar daal do
- Matlab jo din bhar use nahi kiya, wo hatao
```

### LFU — Library Analogy
```
Library mein space kam:
- LFU = Jo books kabhi issue nahi hui, 
        unko storage mein bhej do
- Matlab unpopular = evict
```

### Eviction Policy Decision
| Scenario | Best Policy | Why |
|----------|-------------|-----|
| General web cache | LRU | Recent = likely again |
| Video/content | LFU | Popular stays |
| Time-sensitive | TTL | Stale = bad |
| Simple need | FIFO | Easy |
| Quick eviction | Random | No ordering cost |

### Interview Questions
- "Cache full — kya evict karenge?"
- "LRU vs LFU — difference kya hai?"
- "TTL eviction kab use karein?"

### Follow-up Questions
- "LFU mein frequency counter kaise maintain?"
- "LRU vs LRU-K (K recent history)?"

### Common Mistakes
- Wrong policy for use case
- LFU for recency-based data
- No eviction = OOM
- Evicting too aggressively

### Quick Recall Summary
LRU = recent unused. LFU = least used. TTL = time. Choose by access pattern.

### 1 Minute Recall Block
> LRU = recently unused evict. LFU = least used evict. TTL = time-based evict.

### 5 Bullet Memory Hooks
- LRU = recency
- LFU = frequency
- FIFO = simple
- TTL = time
- Match to pattern

---

## 7. LRU Internal Working

### What Problem
LRU ko O(1) get aur O(1) put chahiye

### Core Concept
**HashMap + Doubly Linked List**

- HashMap: key → Node (O(1) lookup)
- Doubly Linked List: Most recently used at HEAD, least at TAIL

### Internal Working — Step by Step

**GET(key):**
1. HashMap se node find (O(1))
2. Node ko list se remove
3. Node ko HEAD pe add (most recent)
4. Return value

**PUT(key, value):**
1. Agar exists: Update, move to HEAD
2. Agar full: TAIL se evict (LRU item)
3. New node HEAD pe add
4. HashMap update

### ASCII Diagram
```
LRU Cache Structure:
┌─────────────────────────────────────────────────────────┐
│  HashMap: { "A"→NodeA, "B"→NodeB, "C"→NodeC }          │
│                                                         │
│  Doubly Linked List (HEAD = MRU, TAIL = LRU):          │
│                                                         │
│  HEAD ──▶ [C] ◀──▶ [B] ◀──▶ [A] ◀──▶ TAIL              │
│           MRU              LRU (evict this)              │
└─────────────────────────────────────────────────────────┘
```

### Interview Questions
- "LRU ka time complexity kya hai get aur put dono ka?"
- "LRU implement kaise karte ho O(1) mein?"

### Follow-up Questions
- "LFU vs LRU — kab kaunsa?"
- "LRU ko thread-safe kaise banayein?"

### Common Mistakes
- Only HashMap (no order, eviction kaise?)
- Only DLL (lookup O(n))
- Forgetting to update both structures on operations

### 1 Minute Recall Block
> LRU = HashMap + DLL. HashMap for O(1) lookup. DLL for order. Evict from tail.

### 5 Bullet Memory Hooks
- HashMap + DLL
- O(1) both ops
- Head = MRU
- Tail = evict
- Both structures sync

### ⚠️ Common Interview Trap
**"LRU implement karo"** — Must do O(1) both operations. HashMap alone won't work (no order). DLL alone won't work (no O(1) lookup). Both together!

---

## 8. Cache Invalidation

### What Problem
**"There are only two hard things in CS: cache invalidation and naming things"** — Phil Karlton

Data DB mein change hua, cache mein purana hai. Kaise sync karein?

### Strategies

| Strategy | How | When to Use |
|----------|-----|-------------|
| TTL | Time-based expiry | Data thoda stale OK |
| Event-based | DB change → invalidate | Real-time needed |
| Version-based | Key = data + version | Avoid thundering herd |
| Active on Write | Write = invalidate/update | Strong consistency |

### TTL (Time To Live)
```
Cache set: key, value, TTL=300 (5 min)
After 5 min: Auto expire, next read = miss = fresh fetch
```

### Event-based
```
DB Update → Publish event → Cache service listens → Invalidate key
```

### Version-based
```
Key = "user:123:v5" 
DB update → version 6 → Old key auto stale (nobody uses it)
```

### Invalidation Strategy Comparison
| Strategy | Consistency | Complexity | Use Case |
|----------|-------------|------------|----------|
| TTL | Weak | Low | OK if stale acceptable |
| Event-based | Strong | High | Real-time needed |
| Version-based | Strong | Medium | Avoid thundering herd |
| Active on Write | Strong | Medium | Most common |

### Interview Questions
- "Cache invalidation kaise karte ho?"
- "TTL vs event-based — kab kaunsa?"
- "Cache invalidation hardest problem kyu hai?"

### Follow-up Questions
- "Event-based mein event order guarantee kaise?"
- "Version-based mein old versions kab delete karein?"

### Common Mistakes
- No invalidation (stale forever)
- Invalidate too aggressive (cache useless)
- Race condition: write then read before invalidate
- Thundering herd on invalidation

### Quick Recall Summary
Invalidation = keep cache fresh. TTL simple, events strong, version avoids stampede.

### 1 Minute Recall Block
> Invalidation = cache ko fresh banane ka tareeka. TTL, events, version, or write-time update.

### 5 Bullet Memory Hooks
- TTL = time-based
- Event = real-time
- Version = no stampede
- Write = invalidate
- Hardest problem!

---

## 9. Thundering Herd Problem

### What Problem
Cache miss hua. 1000 requests ek saath DB pe jayenge!

### Scenario
```
Cache expires for hot key "trending_products"
     │
     ├── Request 1 ──▶ DB (fetch)
     ├── Request 2 ──▶ DB (fetch)  ← Duplicate!
     ├── Request 3 ──▶ DB (fetch)  ← Duplicate!
     └── ... 1000 requests ──▶ DB (fetch)  ← DB OVERLOAD!
```

### Solutions

**1. Lock (Mutex)**
```
First request: Lock → DB fetch → Cache populate → Unlock
Other requests: Wait for lock → Cache HIT (no DB)
```

**2. Stampede Prevention (Probabilistic Early Expiry)**
```
TTL = 5 min, but start recomputing at 4 min (random)
Spread load over time
```

**3. Request Coalescing**
```
Multiple requests for same key → Single DB fetch
Others wait for result
```

### ASCII
```
WITHOUT FIX:                    WITH LOCK:
  Miss → 1000 DB calls            Miss → 1 DB call
  [====DB====]                    [=DB=] → Rest get from cache
  [====DB====]
  [====DB====]
```

### Solutions Comparison
| Solution | How | Pros | Cons |
|----------|-----|------|------|
| Lock/Mutex | First request locks, rest wait | Simple | Lock contention |
| Probabilistic Early Expiry | Refresh before TTL randomly | No lock | Slightly stale |
| Request Coalescing | Merge same-key requests | Efficient | Complex impl |
| Singleflight (Go) | One in-flight per key | Built-in | Language specific |

### Interview Questions
- "Thundering herd problem kya hai?"
- "Cache miss pe 1000 requests — kya hoga?"
- "Thundering herd kaise prevent karte ho?"

### Follow-up Questions
- "Lock mein deadlock kaise avoid?"
- "Probabilistic expiry ka formula?"
- "Request coalescing implement kaise?"

### Common Mistakes
- Ignoring thundering herd
- Lock too coarse (blocks everything)
- No timeout on lock wait
- Cache stampede on deployment (all keys expire)

### Quick Recall Summary
Cache miss + many requests = DB overload. Fix: Lock (one fetches), early expiry, or coalesce requests.

### 1 Minute Recall Block
> Thundering herd = cache miss pe sab DB pe. Fix: Lock, early expiry, or coalescing.

### 5 Bullet Memory Hooks
- Miss = many DB calls
- Lock = one fetches
- Early expiry = spread load
- Coalesce = merge requests
- Deploy = warming!

---

## 10. Redis vs Memcached

### Comparison Table
| Feature | Redis | Memcached |
|---------|-------|-----------|
| Data Structures | String, List, Set, Hash, Sorted Set, Stream | String only |
| Persistence | Yes (RDB, AOF) | No |
| Replication | Yes | No |
| Transactions | Yes | No |
| Lua Scripting | Yes | No |
| Use Case | Complex cache, sessions, queues | Simple key-value cache |
| Memory | More features = more overhead | Lighter |

### Decision Tree
```
Need persistence? ──Yes──▶ Redis
Need data structures? ──Yes──▶ Redis
Need simple key-value only? ──Yes──▶ Memcached (simpler)
Need replication? ──Yes──▶ Redis
```

### 1 Minute Recall Block
> Redis = full-featured, persistent. Memcached = simple, fast, volatile. Most use Redis today.

---

## 11. Redis Data Structures

### What Problem This Solves
Simple key-value enough nahi — sometimes list, set, ranking chahiye.

### Data Structures Table
| Type | Use Case | Example | Ops |
|------|----------|---------|-----|
| String | Simple cache | `user:123` → JSON | GET, SET |
| List | Queue, timeline | `feed:user1` → [post1, post2] | LPUSH, RPOP |
| Set | Unique items, tags | `tags:photo1` → {sunset, beach} | SADD, SMEMBERS |
| Sorted Set | Leaderboard, ranking | `leaderboard` → score→user | ZADD, ZRANGE |
| Hash | Object fields | `user:123` → {name, email} | HGET, HSET |
| Stream | Event log | Message queue | XADD, XREAD |

### Real World Examples
```
String: Session data, API response cache
List: Activity feed, task queue
Set: User followers, tags
Sorted Set: Game leaderboard, priority queue
Hash: User profile (multiple fields)
Stream: Event sourcing, audit log
```

### Interview Questions
- "Redis mein kaun kaun se data structures hain?"
- "Leaderboard implement kaise — kaunsa structure?"
- "Redis List vs Stream — difference?"

### Follow-up Questions
- "Sorted Set internally kaise implement?"
- "Redis Hash vs String (JSON) — kab kaunsa?"

### Common Mistakes
- Everything as String/JSON (lose Redis power)
- List for queue without blocking (polling bad)
- Sorted Set when Set enough (overhead)

### Quick Recall Summary
String, List, Set, Sorted Set, Hash, Stream. Choose by access pattern and operations needed.

### 1 Minute Recall Block
> Redis: String, List, Set, Sorted Set, Hash, Stream. Choose by access pattern.

### 5 Bullet Memory Hooks
- String = simple
- List = queue/feed
- Set = unique
- Sorted Set = ranking
- Hash = object

---

## 12. Cache Warming

### What Problem This Solves
Cold start — cache empty, first requests slow. Server restart ke baad sab requests DB pe.

### Why Needed
- User experience: First users ko slow response nahi chahiye
- DB protection: Sudden spike avoid karo

### Core Concept
**Cache Warming = Cache ko pehle se populate karo before traffic aaye**

### Internal Working — Step by Step
1. **Preload:** App startup → Load top N keys from DB → Cache populate
2. **Lazy + Background:** First request → Load that key + related keys in background
3. **Scheduled:** Cron every 5 min → Refresh hot keys

### Real World Example
```
Netflix: Server deploy hone se pehle
- Trending list load
- Popular movie metadata load
- So first user ko instant load
```

### Strategies Comparison Table
| Strategy | When | Pros | Cons |
|----------|------|------|------|
| Preload | Startup | Fast first request | Startup slow |
| Lazy + BG | On first miss | No startup cost | First user slow |
| Scheduled | Periodic | Always fresh | Extra load |

### Interview Questions
- "Cache cold start kaise handle karte ho?"
- "Deployment ke baad cache empty hai — kya karenge?"

### Follow-up Questions
- "Preload mein kaun se keys choose karein?"
- "Scheduled warming DB pe load daalta hai — optimize kaise?"

### Common Mistakes
- Sab keys preload (startup bahut slow)
- Warming ignore karna (first users suffer)
- Warming during peak (extra DB load)

### Quick Recall Summary
Warming = cache pre-populate. Preload at startup, lazy on first request, or scheduled refresh.

### 1 Minute Recall Block
> Warming = cache ko pehle se bhar do. Preload, lazy, or scheduled.

### 5 Bullet Memory Hooks
- Preload = startup pe
- Lazy = first request pe
- Scheduled = cron se
- Hot keys only
- Don't warm during peak

---

## 13. Distributed Caching

### What Problem This Solves
Single cache server = single point of failure, limited memory. Scale horizontally chahiye.

### Why Needed
- High availability
- More memory (multiple nodes)
- Geographic distribution

### Consistent Hashing
**What Problem:** Cache nodes add/remove — sab keys rehash mat karo. Traditional mod-based hashing = 90% keys move on node add!

**Core Concept:** Ring pe nodes. Key hash → ring pe point → clockwise next node. Node add/remove = only adjacent keys move.

**Internal Working:**
1. Create hash ring (0 to 2^32)
2. Each node = multiple virtual nodes on ring (better distribution)
3. Key hash → ring position → clockwise first node
4. Node add: Only keys between prev and new node move
5. Node remove: Only that node's keys move to next

```
Consistent Hashing Ring:
        A
       / \
      D   B
       \ /
        C

Key "user:123" → hash → point on ring → clockwise → Node B
Node D fails → Only D's keys move to C, rest same!

Virtual Nodes (better distribution):
A1, A2, A3... B1, B2, B3... — prevents hotspots
```

### Hot Key Problem
**What Problem:** One key gets 80% traffic → one node overloaded → bottleneck

**Solutions:**
1. **Replication:** Hot key ko multiple nodes pe copy (client random pick)
2. **Local cache:** App server pe in-memory copy (Guava, Caffeine)
3. **Key splitting:** `trending:1`, `trending:2` — distribute load
4. **Read replica:** Master-replica, read from replica

### Cache Replication
- **Master-Replica:** Write master, read replica. Eventually consistent.
- **Sharding:** Different key ranges different nodes. No replication.
- **Cluster mode:** Redis Cluster — sharding + replication

### Interview Questions
- "Distributed cache mein node add kiya — kya hoga?"
- "Hot key problem kya hai aur kaise solve karein?"
- "Consistent hashing kyu use karte hain mod hashing ki jagah?"

### Follow-up Questions
- "Virtual nodes kyu use karte hain?"
- "Cache replication vs sharding — kab kaunsa?"

### Common Mistakes
- Mod-based hashing (massive rehash on scale)
- Hot key ko handle na karna
- Single node dependency
- No replication = no HA

### Quick Recall Summary
Consistent hashing = minimal disruption. Hot key = replicate or local cache. Virtual nodes for balance.

### 1 Minute Recall Block
> Consistent hashing = minimal rehash on node change. Hot key = replicate or local cache.

### 5 Bullet Memory Hooks
- Ring + clockwise
- Virtual nodes = balance
- Hot key = replicate
- Mod hashing = avoid
- Node change = minimal move

---

## 14. Cache Metrics

### What Problem This Solves
Cache sahi kaam kar raha hai ya nahi — kaise pata chalega?

### Key Metrics Table
| Metric | Formula | Good Value | Bad Sign |
|--------|---------|------------|----------|
| Hit Rate | hits / (hits + misses) | > 80% | < 60% |
| Miss Rate | 1 - hit rate | < 20% | > 40% |
| Eviction Rate | evictions / time | Low | High = cache too small |
| Latency p50 | Median response | < 1ms | > 5ms |
| Latency p99 | 99th percentile | < 10ms | > 50ms |
| Memory Usage | Used / Total | < 80% | > 90% |

### Real World Example
```
Hit rate 95% = Great! Most requests cache se
Hit rate 40% = Problem: Wrong keys? Too small? Bad TTL?
Eviction rate high = Cache size badhao ya eviction policy change
```

### Interview Questions
- "Cache performance kaise measure karte ho?"
- "Hit rate 50% hai — kya karenge?"

### Follow-up Questions
- "p99 latency kyu important hai p50 se zyada?"
- "Eviction rate high hai — debugging steps?"

### 1 Minute Recall Block
> Hit rate > 80% = healthy. Miss rate high = cache wrong data or size small.

### 5 Bullet Memory Hooks
- Hit rate > 80%
- Eviction = size issue
- p99 = tail latency
- Monitor always
- Low hit = debug keys

---

## 15. Cache Key Design Best Practices

### What Problem This Solves
Keys galat design = collisions, hard invalidation, memory waste.

### Best Practices (Detailed)

1. **Namespace:** `user:123`, `product:456` — avoid collisions between different data types
2. **Version:** `user:123:v2` — schema change pe naya version, purana auto stale
3. **Consistent:** Same data = same key always. Hash inputs if composite.
4. **Not too long:** Redis 512MB limit per key (practical: < 1KB)
5. **Cardinality:** Millions of unique keys = memory explosion. Aggregate when possible.
6. **Readable:** Debugging easy — `user:123:profile` better than `u123p`

### Key Design Examples
```
Good:  user:123:profile:v2
Good:  product:456:details
Bad:   key_12345 (kya hai?)
Bad:   user_${userId}_${random} (inconsistent!)
```

### Interview Questions
- "Cache key kaise design karte ho?"
- "Key collision kaise avoid karte ho?"

### Follow-up Questions
- "Version key mein kyu?"
- "High cardinality keys ka problem kya hai?"

### Common Mistakes
- Random/inconsistent keys
- No namespace (collisions)
- Too long keys (memory)
- No version (invalidation hard)

### 1 Minute Recall Block
> Key = namespace:id:version. Consistent, short, limited cardinality.

### 5 Bullet Memory Hooks
- Namespace always
- Version for invalidation
- Consistent hashing
- Short keys
- Low cardinality

---

## 16. Golden Rules & When NOT to Cache

### Golden Rules of Caching (10+)
1. Cache only what's read frequently
2. Always set TTL (avoid stale forever)
3. Cache keys must be deterministic
4. Handle cache miss gracefully
5. Monitor hit rate
6. Invalidate on write
7. Don't cache sensitive data without encryption
8. Cache size = plan for eviction
9. Consider thundering herd
10. Cache at multiple layers
11. Design for cache failure (DB should work without cache)
12. Use consistent hashing for distributed cache

### When NOT to Cache
- Data changes every second
- Unique data (no reuse)
- Large objects (memory waste)
- Critical financial data (consistency > speed)
- Real-time data

### Common Mistakes Table
| Mistake | Why Bad | Fix |
|---------|---------|-----|
| No TTL | Stale forever | Always set TTL |
| Caching everything | Memory full | Cache hot data only |
| Cache as DB | Volatile, can lose | Cache = copy only |
| Ignoring invalidation | Stale data | Invalidate on write |
| No fallback | Cache down = app down | Graceful degradation |

---

## Interview Tips for Caching Questions

1. **Start with problem:** "We have slow reads, need to reduce DB load"
2. **Mention 80/20:** "Small subset gets most traffic"
3. **Strategy:** "Cache-Aside for flexibility"
4. **Eviction:** "LRU for general, TTL for time-based"
5. **Scale:** "Redis cluster, consistent hashing"
6. **Failure:** "Cache miss = DB fallback, never block"

### ⚠️ Common Interview Traps
- "Cache vs Session?" — Session = user state, Cache = shared read data
- "When to use Write-Through?" — When consistency critical, writes not huge
- "Cache invalidation strategy?" — Depends on consistency vs performance need

---

**END OF CACHING NOTES — Ab tum caching samajh gaye ho! 🚀**
