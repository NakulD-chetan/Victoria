# Types of Dimensions

> "A dimension is an answer to ‘who, what, where, when, why, how’—the dimension table is simply where you store the story."

**Real-world analogy:** Dimension types are like the different label printers in a retail headquarters: some labels are universal barcodes every department scans (conformed), some are sticky notes you only use at the receiving dock (degenerate on the pallet ticket), and some bundle small checkboxes into one compact sticker (junk) so the loading bay stays readable.

---

## Core Idea (2 Lines)

A **dimension** is a qualifying context for a measurement, while a **dimension table** is the physical table (or view) that holds descriptive attributes and surrogate keys referenced by facts. Modeling patterns—conformed, role-playing, junk, degenerate—optimize reuse, join simplicity, and storage without breaking the star’s clarity.

---

## Dimension vs Dimension Table

| Term | Meaning | Retail example |
|------|---------|----------------|
| Dimension (concept) | Business context axis for facts | Time, product, store, promotion |
| Dimension table | Persistent implementation | `dim_date`, `dim_store` |
| Bridge / helper | Resolves many-to-many | `bridge_promotion_product` |

Facts answer “how much, how many”; dimension tables answer “which store, which SKU, which day, under which promotion.”

**Interview Tip:** Saying “the promotion dimension” can mean either the abstract analytic axis or `dim_promotion`; clarify both senses.

**Watch Out!** Confusing a reporting **parameter** ( slicer ) with a modeled dimension table leads to bypassing conformed keys in ad hoc SQL.

---

## Conformed Dimensions

A **conformed dimension** is identical in grain and meaning wherever it appears—same keys, same attributes—so facts from different processes integrate.

| Property | Why it matters | Retail example |
|----------|----------------|----------------|
| Same surrogate key | Union-compatible joins | `store_key` matches between POS and e-commerce facts |
| Same attributes | Consistent filters | `store_format` means “hypermarket” everywhere |
| Shared maintenance | One correction propagates | Fix `region` once in `dim_store` |

Date is the flagship conformed dimension: `dim_date` is reused across inventory, sales, and labor facts.

ASCII integration picture:

```
   fact_store_sales ----\
                         +---- dim_store (conformed)
   fact_inventory_snap --/

   fact_store_sales ----\
                         +---- dim_date (conformed)
   fact_shipment --------/
```

**Watch Out!** “Almost conformed” dimensions (same store name, different surrogate keys per source) block integrated dashboards until keys are reconciled.

---

## Role-Playing Dimensions

One physical dimension table participates multiple times in the same fact under different semantic roles—implemented as multiple foreign keys on the fact.

| Role column on fact | Meaning | Same physical dim |
|---------------------|---------|-------------------|
| `sale_date_key` | When transaction tendered | `dim_date` |
| `inventory_as_of_date_key` | Snapshot context | `dim_date` |
| `ship_date_key` | When goods left DC | `dim_date` |

SQL pattern with aliases:

```sql
SELECT
    sale.calendar_date      AS sale_day,
    ship.calendar_date      AS ship_day,
    SUM(f.net_sales_amount) AS net_sales
FROM fact_store_sales AS f
JOIN dim_date AS sale
  ON f.sale_date_key = sale.date_key
JOIN dim_date AS ship
  ON f.ship_date_key = ship.date_key
WHERE sale.calendar_date >= '2025-11-01'
GROUP BY
    sale.calendar_date,
    ship.calendar_date;
```

Views such as `dim_date_sale` and `dim_date_ship` can wrap the same table for semantic clarity in BI tools.

**Interview Tip:** Role-playing is not duplication of data—only duplication of references in the fact table.

**Watch Out!** Analysts joining two date roles without understanding **which** date drives additive sales can misallocate inventory metrics.

---

## Junk Dimensions

A **junk dimension** combines several low-cardinality flags into one dimension row to avoid a wide fact sprinkled with many small FK columns.

| Without junk | With junk |
|--------------|-----------|
| `is_clearance`, `is_online`, `is_bopis`, `tender_type_bucket` on fact | `checkout_profile_key` → `dim_checkout_profile` |
| Many sparse columns | One FK |

Cartesian product caution: if four attributes have 3, 4, 5, and 2 distinct values independently, worst-case junk rows = 3×4×5×2 = 120. Still tiny compared to sales facts.

| Attribute | Cardinality |
|-----------|-------------|
| Channel | 3 |
| Fulfillment | 4 |
| Return flag | 2 |
| Price override | 2 |

Potential combinations: 3×4×2×2 = 48 theoretical rows (some may be impossible and omitted).

**Interview Tip:** Junk dimensions reduce fact width and ease indexing; they are not free—ETL must generate the full valid combination set or handle unmapped rows.

**Watch Out!** Exploding junk rows by combining high-cardinality fields (e.g., raw `cashier_id`) defeats the purpose and mimics a bad fact table.

---

## Degenerate Dimensions

A **degenerate dimension** is a dimension key stored in the fact without a separate dimension table—typically a transaction identifier.

| Example on `fact_store_sales` | Why degenerate |
|------------------------------|----------------|
| `pos_transaction_id` | Uniqueness is at transaction grain; no stable attribute set |
| `receipt_number` | Huge cardinality; attributes live at line elsewhere |

```sql
-- Degenerate dimension columns live on the fact
CREATE TABLE fact_store_sales (
    sale_line_key       BIGINT NOT NULL PRIMARY KEY,
    pos_transaction_id  VARCHAR(32) NOT NULL,  -- degenerate
    sale_date_key       INT      NOT NULL,      -- normal dim FK
    store_key           INT      NOT NULL,
    product_key         BIGINT   NOT NULL,
    quantity            INT      NOT NULL,
    net_sales_amount    DECIMAL(12,2) NOT NULL
);
```

Retail: linking to `dim_transaction` is optional when the only analytic need is grouping returns by receipt.

**Watch Out!** Promoting every degenerate ID to its own one-column dimension table adds joins with no descriptive payload.

---

## SCD Introduction (Deferred Detail)

Slowly Changing Dimensions describe how attribute history is preserved when `dim_customer` or `dim_product` changes. Full treatment belongs to the SCD lecture; here, the key link is:

| Dimension type topic | SCD relevance |
|----------------------|---------------|
| Conformed dimensions | SCD rules must stay synchronized across facts |
| Junk dimensions | Rarely Type 2; usually Type 1 overwrite |
| Degenerate | Not SCD-managed; IDs are facts about the event |
| Role-playing | Same SCD policy on underlying physical table |

**Interview Tip:** Acknowledge SCD as the mechanism that keeps conformed dimensions truthful over time.

---

## Comparison Table of Dimension Types

| Type | Separate table? | Typical grain | Retail example |
|------|-----------------|---------------|----------------|
| Conformed | Yes | Shared across facts | `dim_store`, `dim_date` |
| Role-playing | Yes (one physical) | Same as base dimension | Two `date_key` columns on shipment fact |
| Junk | Yes | Cartesian of small flags | `dim_checkout_context` |
| Degenerate | No | Transaction / line id | `pos_transaction_id` on fact |
| Outrigger | Yes (small satellite) | Depends | Mini reference for reason codes |
| Slowly changing | Yes | Slowly updated entities | `dim_loyalty_member` with Type 2 rows |

---

## SQL: Junk Dimension Lookup Pattern

```sql
-- Build junk key in ETL
INSERT INTO dim_checkout_profile (checkout_profile_key, channel, fulfillment, is_price_override)
VALUES (1, 'STORE', 'CARRYOUT', 'N');

-- Fact load
UPDATE stage_sales
SET checkout_profile_key = j.checkout_profile_key
FROM dim_checkout_profile AS j
WHERE stage_sales.channel = j.channel
  AND stage_sales.fulfillment = j.fulfillment
  AND stage_sales.is_price_override = j.is_price_override;
```

---

## ASCII: Fact Surrounded by Dimension Types

```
                 dim_date (conformed)
                        |
dim_store -------- fact_sales ------- dim_product
                        |
              dim_checkout_profile (junk)
                        |
                 pos_transaction_id (degenerate, on fact)
```

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Duplicate physical date tables per subject area | Breaks conformed time analysis | One `dim_date`; use role aliases |
| Junk dimension with exploding combinations | Table grows huge; ETL fragile | Restrict to low-cardinality fields |
| Every degenerate ID modeled as `dim_*` | Pointless joins | Keep degenerates on fact unless attributes appear |
| Ignoring conformation on `store_key` | Cannot blend channels | Master data alignment program |
| Role-playing without naming conventions | Analysts join wrong date role | Standard column names + model docs |

---

## Key Takeaway

> Classify dimensions by reuse and cardinality: conformed tables integrate the enterprise, role-playing reuses one table in multiple semantic slots, junk bundles tiny flags, and degenerates stay on the fact when there is no attribute story—then let SCD policies protect history where the business demands it.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) Dimension = idea; dimension table = physical implementation.  |
| 2) Conformed = same keys/attrs across facts (date, store).     |
| 3) Role-play = multiple FKs to one dim (aliases/views).        |
| 4) Junk = merge low-card flags; watch Cartesian size.          |
| 5) Degenerate = trans id on fact; no dim table.                |
| 6) SCD governs how conformed dims change over time.            |
| 7) Name role columns so semantics are obvious in SQL/BI.       |
+------------------------------------------------------------------+
```
