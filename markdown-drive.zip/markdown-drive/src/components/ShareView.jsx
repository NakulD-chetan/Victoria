import { useState, useEffect, useCallback, useRef, memo } from 'react';
import MarkdownViewer from './MarkdownViewer';

const ShareView = memo(function ShareView({ shareToken }) {
  const [share, setShare] = useState(null);
  const [folder, setFolder] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileData, setFileData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  const [needsPassword, setNeedsPassword] = useState(false);
  const [shareLabel, setShareLabel] = useState('');
  const [password, setPassword] = useState('');
  const [pwError, setPwError] = useState('');
  const [verifying, setVerifying] = useState(false);
  const pwRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem('md-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', saved);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`/api/share/${shareToken}`);
        if (!res.ok) { setError('This share link is invalid or has expired.'); setLoading(false); return; }
        const data = await res.json();
        if (data.requiresPassword) {
          setNeedsPassword(true);
          setShareLabel(data.label || 'Protected Share');
          setLoading(false);
          return;
        }
        setShare(data.share);
        setFolder(data.folder);
      } catch { setError('Failed to load shared content.'); }
      setLoading(false);
    })();
  }, [shareToken]);

  const handlePasswordSubmit = useCallback(async () => {
    if (!password.trim() || verifying) return;
    setVerifying(true);
    setPwError('');
    try {
      const res = await fetch(`/api/share/${shareToken}/verify`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: password.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPwError(data.error || 'Wrong password');
        setVerifying(false);
        return;
      }
      setShare(data.share);
      setFolder(data.folder);
      setNeedsPassword(false);
    } catch {
      setPwError('Verification failed');
      setVerifying(false);
    }
  }, [shareToken, password, verifying]);

  const openFile = useCallback(async (fileName) => {
    try {
      const res = await fetch(`/api/share/${shareToken}/file/${encodeURIComponent(fileName)}`);
      if (!res.ok) return;
      const data = await res.json();
      setSelectedFile(fileName);
      setFileData(data);
    } catch {}
  }, [shareToken]);

  const handleDownload = useCallback(() => {
    if (!fileData?.content || !fileData?.allowDownload) return;
    const blob = new Blob([fileData.content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, [fileData, selectedFile]);

  if (loading) {
    return (
      <div className="share-view">
        <div className="share-view__loading">
          <div className="auth__spinner" />
          <p>Loading shared content...</p>
        </div>
      </div>
    );
  }

  if (needsPassword) {
    return (
      <div className="share-view">
        <div className="share-view__pw-card">
          <div className="share-view__pw-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.8">
              <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <h2 className="share-view__pw-title">Protected Content</h2>
          <p className="share-view__pw-label">{shareLabel}</p>
          <p className="share-view__pw-desc">This share link requires a password to access.</p>
          <div className="share-view__pw-form">
            <input
              ref={pwRef}
              className="share-view__pw-input"
              type="password"
              placeholder="Enter password..."
              value={password}
              onChange={e => { setPassword(e.target.value); setPwError(''); }}
              onKeyDown={e => e.key === 'Enter' && handlePasswordSubmit()}
              autoFocus
            />
            <button className="share-view__pw-btn" onClick={handlePasswordSubmit} disabled={!password.trim() || verifying}>
              {verifying ? (
                <div className="auth__spinner" style={{ width: 14, height: 14, borderWidth: 2 }} />
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
              )}
            </button>
          </div>
          {pwError && <p className="share-view__pw-error">{pwError}</p>}
          <div className="share-view__pw-footer">
            <svg width="12" height="12" viewBox="0 0 100 100" fill="none">
              <defs><linearGradient id="svpw" x1="0.15" y1="0.1" x2="0.85" y2="0.9"><stop offset="0%" stopColor="#6366F1" /><stop offset="100%" stopColor="#10B981" /></linearGradient></defs>
              <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#svpw)" />
            </svg>
            <span>Shared via InkDrop</span>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="share-view">
        <div className="share-view__error">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth="1.5">
            <circle cx="12" cy="12" r="10" /><line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
          </svg>
          <h2>Link Unavailable</h2>
          <p>{error}</p>
          <a href="/" className="share-view__home-link">Go to InkDrop</a>
        </div>
      </div>
    );
  }

  if (selectedFile && fileData) {
    return (
      <div className="share-view share-view--reading">
        <div className="share-view__header">
          <button className="share-view__back" onClick={() => { setSelectedFile(null); setFileData(null); }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6" /></svg>
            Back
          </button>
          <span className="share-view__file-title">{fileData.title || selectedFile}</span>
          <div className="share-view__header-actions">
            {fileData.allowDownload && (
              <button className="share-view__download-btn" onClick={handleDownload} title="Download">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3" />
                </svg>
              </button>
            )}
            <span className="share-view__badge">Shared</span>
          </div>
        </div>
        <div className="share-view__content">
          <MarkdownViewer fileData={fileData} folder={null} filename={null} />
        </div>
      </div>
    );
  }

  return (
    <div className="share-view">
      <div className="share-view__card">
        <div className="share-view__card-header">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
          </svg>
          <div className="share-view__card-title-group">
            <h2>{folder?.name}</h2>
            {share?.label && <p className="share-view__card-label">{share.label}</p>}
          </div>
          <span className="share-view__badge">Shared</span>
        </div>

        <div className="share-view__info-bar">
          <div className="share-view__info-item">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /></svg>
            <span>{folder?.fileCount} file{folder?.fileCount !== 1 ? 's' : ''}</span>
          </div>
          <div className="share-view__info-item">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" /></svg>
            <span>{share?.permissions?.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(', ')}</span>
          </div>
          {share?.expiresAt && (
            <div className="share-view__info-item">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" /></svg>
              <span>Expires {new Date(share.expiresAt).toLocaleDateString()}</span>
            </div>
          )}
        </div>

        <div className="share-view__files">
          {folder?.files?.map(file => (
            <button key={file.name} className="share-view__file" onClick={() => openFile(file.name)}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" />
              </svg>
              <span>{file.title || file.name}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.4">
                <polyline points="9 18 15 12 9 6" />
              </svg>
            </button>
          ))}
        </div>

        <div className="share-view__footer">
          <svg width="14" height="14" viewBox="0 0 100 100" fill="none">
            <defs><linearGradient id="svf" x1="0.15" y1="0.1" x2="0.85" y2="0.9"><stop offset="0%" stopColor="#6366F1" /><stop offset="100%" stopColor="#10B981" /></linearGradient></defs>
            <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#svf)" />
          </svg>
          <span>Shared via InkDrop</span>
        </div>
      </div>
    </div>
  );
});

export default ShareView;
