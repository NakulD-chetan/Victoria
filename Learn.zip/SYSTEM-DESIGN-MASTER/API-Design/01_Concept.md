# API Design - Concept

> **Quick Memory Line:** APIs are mainly of 3 types: **REST**, **GraphQL**, and **gRPC**. Important topics in API design are versioning, rate limiting, authentication, pagination, idempotency, and API Gateway. Think of API Gateway as the front door that handles routing, auth, and rate limiting.

---

## REST API Principles

**REST** means we design APIs around **resources** like users, orders, and products.
We use:

- **Nouns** in URLs, like `/users/123`
- **HTTP methods** to tell what action we want

Main ideas:


| Principle          | Easy Meaning                                                                                     |
| ------------------ | ------------------------------------------------------------------------------------------------ |
| **Stateless**      | Server does not remember previous requests. Every request should contain all needed information. |
| **Resource-based** | URLs represent things/resources like `/users`, `/orders`, `/products/10`.                        |
| **HTTP methods**   | `GET` = read, `POST` = create, `PUT` = replace, `PATCH` = partial update, `DELETE` = remove.     |
| **HATEOAS**        | Response can include links to related actions or related resources.                              |


---

## HTTP Status Codes Reference


| Code Group | Meaning                  | Common Examples                                                                                  |
| ---------- | ------------------------ | ------------------------------------------------------------------------------------------------ |
| **2xx**    | Request succeeded        | `200 OK`, `201 Created`, `204 No Content`                                                        |
| **3xx**    | Redirect / moved         | `301 Moved Permanently`, `304 Not Modified`                                                      |
| **4xx**    | Problem from client side | `400 Bad Request`, `401 Unauthorized`, `403 Forbidden`, `404 Not Found`, `429 Too Many Requests` |
| **5xx**    | Problem from server side | `500 Internal Server Error`, `502 Bad Gateway`, `503 Service Unavailable`                        |


> **Important:** Use `429` when too many requests come in. Use `401` when user is not logged in. Use `403` when user is logged in but does not have permission.

---

## GraphQL

**GraphQL** lets the client ask for **exactly the data it needs**.

- **Schema** defines the data types
- **Resolvers** fetch the data for each field


| Point              | REST                        | GraphQL                            |
| ------------------ | --------------------------- | ---------------------------------- |
| **Over-fetching**  | Often returns extra data    | Client asks only for needed fields |
| **Under-fetching** | May need multiple API calls | Often possible in one request      |
| **Flexibility**    | Fixed endpoints             | Flexible queries                   |


**Best use cases:**

- Mobile apps
- Complex frontends
- When different screens need different data shapes
- BFF (Backend-for-Frontend)

---

## gRPC

**gRPC** is a fast communication style mostly used between internal services.
It uses:

- **Protocol Buffers (Protobuf)** for compact binary data
- **HTTP/2** for better performance
- **Streaming** for real-time or continuous data flow


| Feature             | Benefit                                                     |
| ------------------- | ----------------------------------------------------------- |
| **Binary format**   | Smaller and faster than JSON                                |
| **HTTP/2**          | Multiple requests can share one connection                  |
| **Streaming**       | Good for live updates or large continuous data              |
| **Code generation** | Client and server code can be generated from `.proto` files |


**Best use cases:**

- Internal microservices
- Low latency systems
- High performance systems
- Streaming use cases

---

## REST vs GraphQL vs gRPC Comparison


| Criterion               | REST              | GraphQL                      | gRPC                                      |
| ----------------------- | ----------------- | ---------------------------- | ----------------------------------------- |
| **Transport**           | Usually HTTP/1.1  | HTTP                         | HTTP/2                                    |
| **Data format**         | JSON/XML          | JSON                         | Protobuf                                  |
| **Best for**            | Public APIs, CRUD | Flexible frontend data needs | Internal service-to-service communication |
| **Caching**             | Easy              | Harder                       | Usually custom                            |
| **Browser support**     | Native            | Native                       | Needs gRPC-Web                            |
| **Learning difficulty** | Easy              | Medium                       | Harder                                    |


---

## API Versioning Strategies

Versioning means handling changes in the API without breaking old clients.


| Strategy        | Example                                      | Good Part                  | Drawback                             |
| --------------- | -------------------------------------------- | -------------------------- | ------------------------------------ |
| **URL path**    | `/v1/users`, `/v2/users`                     | Easy to see and understand | Duplicate URLs                       |
| **Header**      | `Accept: application/vnd.api+json;version=2` | Cleaner URLs               | Harder to notice                     |
| **Query param** | `/users?version=2`                           | Easy to add                | Can be ignored or cached incorrectly |


```txt
URL:     GET /api/v1/users/123
Header:  GET /api/users/123   +   Accept-Version: 2
Query:   GET /api/users/123?api_version=2
```

---

## Rate Limiting Algorithms

Rate limiting stops users from sending too many requests in a short time.

### Token Bucket

```txt
    ┌─────────────────────┐
    │   BUCKET (capacity) │
    │   ●●●●● tokens      │
    │   Refill: 1/sec     │
    └─────────────────────┘
         │
         │ Request -> take 1 token
         │ No token -> 429
         ▼
```

**Easy idea:** A bucket has tokens. Every request uses 1 token. Tokens are added back at a fixed speed. If no token is left, reject the request.

### Leaky Bucket

```txt
    ┌─────────────────────┐
    │ BUCKET (requests)   │
    │ ░░░░░ queue         │
    │ Leak: fixed rate    │
    └──────────┬──────────┘
               │ Process slowly
               ▼
```

**Easy idea:** Requests come in quickly, but the system processes them at a fixed speed. This makes traffic smoother.

### 3. How It Works (System Design View)

#### Components:

- **Bucket (Queue)** → holds incoming requests
- **Capacity (C)** → max queue size
- **Leak Rate (R)** → fixed processing rate

#### Flow:

1. Request arrives
2. If queue **not full → add to bucket**
3. If queue **full → reject request (429 / drop)**
4. Requests are processed at **constant rate R**

---

### 4. Key Properties


| Property          | Explanation                        |
| ----------------- | ---------------------------------- |
| Fixed output rate | Always processes at constant speed |
| Smooth traffic    | Removes bursts                     |
| Queue-based       | Stores requests temporarily        |
| Drops overflow    | Prevents system overload           |
| Simple logic      | Easy to implement                  |


### Sliding Window Log

```txt
Time:  |----|----|----|----|
       t1   t2   t3   t4
       ●    ●    ●
       Count requests in [now - window, now]
       If limit crosses -> 429
```

**Easy idea:** Store request timestamps and count how many happened in the recent time window. Very accurate, but uses more memory.

### 3. How It Works (Step-by-step)

#### Data Structure:

- Typically: **Queue / Deque / List of timestamps**

#### Flow:

1. Request arrives at time `t`
2. Remove all timestamps `< (t - window)`
3. Check current size:
  - If `< limit` → allow request
  - Else → reject (429)
4. Add current timestamp

---

### 4. Example

#### Config:

- Limit = **3 requests**
- Window = **10 seconds**

#### Timeline:

```
t=1   → request ✔
t=2   → request ✔
t=3   → request ✔
t=4   → request ❌ (limit exceeded)
```

At `t=11`:

-   
Window = [1 → 11]  

-   
Request at t=1 expires  


Now:

```
t=11 → request ✔ (space freed)
```

---

### 5. Pseudocode

```
from collections import deque
import time

window = 10  # seconds
limit = 3
logs = deque()

def allow_request():
    now = time.time()

    # Remove expired timestamps
    while logs and logs[0] <= now - window:
        logs.popleft()

    if len(logs) < limit:
        logs.append(now)
        return True
    else:
        return False
```

---

### 6. Key Properties


| Property             | Explanation                     |
| -------------------- | ------------------------------- |
| Very accurate        | Exact count in real-time window |
| No burst cheating    | Strict enforcement              |
| Sliding (continuous) | Not fixed buckets               |
| Memory heavy         | Stores every request            |
| CPU overhead         | Frequent cleanup                |


---

## Authentication Comparison

Authentication means checking who is making the request.


| Method        | Easy Meaning                                              | Common Use                              |
| ------------- | --------------------------------------------------------- | --------------------------------------- |
| **API Key**   | A fixed key is sent with the request                      | Simple services, internal tools         |
| **OAuth 2.0** | User allows one app to access another app on their behalf | Third-party login and permissions       |
| **JWT**       | A signed token carries user information                   | Stateless authentication, microservices |



| Criterion      | API Key        | OAuth 2.0                   | JWT                           |
| -------------- | -------------- | --------------------------- | ----------------------------- |
| **Complexity** | Low            | High                        | Medium                        |
| **Revocation** | Change the key | Revoke token at auth server | Use blacklist or short expiry |
| **Stateless**  | Yes            | Usually no                  | Yes                           |


---

## Pagination Strategies

Pagination means returning data in small chunks instead of all at once.


| Strategy   | Example                   | Benefit                                   | Drawback                                                    |
| ---------- | ------------------------- | ----------------------------------------- | ----------------------------------------------------------- |
| **Offset** | `?page=2&limit=20`        | Very simple, supports jumping to any page | Slow on large page numbers, can show duplicates/missed rows |
| **Cursor** | `?cursor=abc123&limit=20` | Stable and scalable                       | Hard to jump to random page                                 |
| **Keyset** | `?after_id=123&limit=20`  | Fast for sorted data                      | Depends on sort order                                       |


> **Interview tip:** For large-scale systems, cursor or keyset pagination is usually better than offset pagination.

---

## Idempotency

**Idempotent** means:
If you send the same request again and again, the final result stays the same.

- `GET`, `PUT`, and `DELETE` are usually idempotent
- `POST` is usually **not** idempotent

To make `POST` safer, client sends an **Idempotency-Key**.
If the same request is retried with the same key, server returns the old result instead of creating duplicate data.

```txt
Client: POST /orders   Idempotency-Key: uuid-123   body: {...}
Server: 201 Created {...}

Client: Retry same request with same key
Server: Return same response, no duplicate order
```

---

## API Gateway Pattern

An **API Gateway** sits between users and backend services.
It can handle:

- Routing
- Authentication
- Rate limiting
- Logging

```txt
    ┌──────────┐     ┌──────────────┐     ┌─────────────┐
    │ Clients  │ --->│ API Gateway  │ --->│  Services   │
    └──────────┘     │ - Auth       │     │ /users      │
                     │ - Rate limit │     │ /orders     │
                     │ - Routing    │     │ /products   │
                     └──────────────┘     └─────────────┘
```

---

## 30-Second Revision Box

```txt
REST: Resource-based API, uses HTTP methods, stateless
GraphQL: Client asks for exactly the data it needs
gRPC: Fast internal communication using Protobuf + HTTP/2
Versioning: URL, header, or query parameter
Rate limiting: Token bucket, leaky bucket, sliding window
Auth: API key, OAuth 2.0, JWT
Pagination: Offset, cursor, keyset
Idempotency: Use Idempotency-Key for safe retries in POST
API Gateway: Handles auth, rate limiting, and routing
```

---

**Next: [[02_Mental-Model]]**