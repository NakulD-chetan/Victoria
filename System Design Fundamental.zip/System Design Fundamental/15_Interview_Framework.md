# System Design Interview — Complete Framework

> **FAANG interview mein System Design round sabse important hai — yahan decide hota hai hire ya reject!**
> Structured approach + Trade-off awareness + Communication = SUCCESS

---

## How System Design Interviews Work at FAANG

| Company | Duration | Format | Focus |
|---------|----------|--------|-------|
| **Google** | 45 min | Whiteboard + Discussion | Scalability, Trade-offs |
| **Meta** | 45 min | Whiteboard + Discussion | Product thinking, Scale |
| **Amazon** | 45 min | Whiteboard + Discussion | Availability, Latency |
| **Microsoft** | 45 min | Whiteboard + Discussion | End-to-end design |
| **Netflix** | 45 min | Whiteboard + Discussion | Resilience, Streaming |

**Common Pattern:**
1. **Open-ended question:** "Design Twitter" / "Design URL shortener"
2. **You drive:** You ask questions, propose design, iterate
3. **Interviewer probes:** Deep dive, edge cases, trade-offs
4. **No single right answer:** Multiple valid approaches

---

## What Interviewers Actually Evaluate

| Evaluation Criteria | Weight | What They Look For |
|---------------------|--------|---------------------|
| **Structured Thinking** | 30% | Clear steps, organized approach, no chaos |
| **Communication** | 25% | Explain clearly, think aloud, engage |
| **Trade-off Awareness** | 20% | "Why this over that?" — justify choices |
| **Technical Depth** | 15% | Can go deep when probed |
| **Problem Solving** | 10% | Handle curveballs, adapt design |

**Key Insight:** "Perfect design" se zyada "structured thinking" matter karta hai!

---

## The 4-Step Framework

```
┌─────────────────────────────────────────────────────────────┐
│  STEP 1: Requirements (5-10 min) — Kya banana hai?          │
│  Functional + Non-functional + Scale                        │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 2: Back of Envelope (5 min) — Kitna scale?             │
│  QPS, Storage, Bandwidth                                     │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 3: High-Level Design (15-20 min) — Kaise banega?      │
│  API, Data, Components, Data Flow                            │
└─────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────┐
│  STEP 4: Deep Dive (15-20 min) — Kaise handle karenge?      │
│  Bottlenecks, Scaling, Failures, Trade-offs                  │
└─────────────────────────────────────────────────────────────┘
```

---

## Step 1: Requirements Clarification (5-10 min)

### Functional Requirements — What to Ask

| Question | Example Answer | Why Ask |
|----------|----------------|---------|
| **Core features?** | "Shorten URL, redirect, analytics" | Scope define |
| **Who are users?** | "Developers, marketers" | Use case |
| **Read vs Write?** | "100:1 read-heavy" | Design choice |
| **Custom URLs?** | "Yes, optional" | Complexity |
| **Expiration?** | "Optional TTL" | Storage design |
| **Analytics?** | "Click count, timestamps" | Extra components |

### Non-Functional Requirements — What to Ask

| Question | Example Answer | Impact |
|----------|----------------|--------|
| **Scale?** | "100M URLs/month" | QPS, Storage |
| **Latency?** | "Redirect < 100ms" | Caching, CDN |
| **Availability?** | "99.9%" | Redundancy |
| **Consistency?** | "Eventual for analytics" | DB choice |
| **Security?** | "HTTPS, rate limit" | Extra components |

### Requirements Checklist Template

```
FUNCTIONAL:
□ Core features (what exactly?)
□ User types
□ Read/Write ratio
□ Custom URLs / special cases
□ Edge cases (expiration, duplicate?)

NON-FUNCTIONAL:
□ Scale (DAU, QPS, Storage)
□ Latency requirements
□ Availability target
□ Consistency needs
□ Security (any?)
```

---

## Step 2: Back of Envelope (5 min)

**Always do this!** Even if interviewer doesn't ask.

| Estimate | Formula | Example (URL Shortener) |
|----------|---------|-------------------------|
| **Write QPS** | 100M URLs/month ÷ 86400 ÷ 30 | ~40 writes/sec |
| **Read QPS** | Writes × 100 (read-heavy) | ~100:1 = 4K reads/sec |
| **Storage (5 yr)** | 100M × 12 × 5 × 500 bytes | ~30 GB |
| **Bandwidth** | 4K × 500 bytes | ~2 MB/s |

**Say aloud:** "So we're looking at roughly 4K QPS, 30GB storage — very manageable scale."

---

## Step 3: High-Level Design (15-20 min)

### Design Checklist — What to Include

| Component | What to Draw/Explain |
|-----------|----------------------|
| **API Design** | 2-3 endpoints with request/response |
| **Data Model** | Tables/schemas, key fields |
| **Component Diagram** | Client → LB → App → DB → Cache |
| **Data Flow** | Write path, Read path (separate) |
| **Storage** | Where data lives, why |

### Component Diagram Template

```
[Client] → [Load Balancer] → [App Servers]
                                    ↓
                              [Cache]
                                    ↓
                              [Database]
                                    ↓
                              [Queue] (if async)
```

### API Design — Always Include

```
POST /api/v1/shorten
  Request: { longUrl: string, customAlias?: string }
  Response: { shortUrl: string }

GET /api/v1/:shortCode
  Response: 302 Redirect to longUrl

GET /api/v1/:shortCode/stats
  Response: { clicks: number, createdAt: string }
```

---

## Step 4: Deep Dive (15-20 min)

**Interviewer will probe.** Be ready for:

| Topic | What to Discuss |
|-------|-----------------|
| **Bottleneck** | "Reads are 100× writes — cache is critical" |
| **Scaling** | "Horizontal scaling, stateless app servers" |
| **Failure** | "DB down? Cache serves stale. Cache miss? DB" |
| **Trade-offs** | "SQL vs NoSQL: We chose SQL for consistency" |
| **Alternatives** | "Could use Kafka for analytics — async"

---

## Communication Tips

### Think Out Loud

| Bad | Good |
|-----|------|
| *Silence... draws diagram* | "I'll start with the API. We need shorten and redirect..." |
| *Writes code* | "For the hash, we could use base62 or UUID — base62 gives shorter URLs" |
| *Stuck* | "Let me think about the bottleneck... reads are heavy so cache makes sense" |

### Signposting — "I'm going to..."

- "Let me start with requirements clarification..."
- "Now I'll do a quick back-of-envelope..."
- "For the high-level design, I'll draw the components..."
- "Let me dig deeper into the database choice..."

### Check-ins

- "Does this direction make sense?"
- "Should I go deeper into the API or move to scaling?"
- "Would you like me to explore the failure scenarios?"

### State Trade-offs Explicitly

- "We're choosing SQL over NoSQL because we need strong consistency for..."
- "The trade-off here is latency vs consistency — we're optimizing for..."

---

## Common Mistakes to Avoid

| Mistake | Why Bad | Fix |
|---------|---------|-----|
| **Jumping to solution** | No scope, wrong design | Always 5 min requirements first |
| **No numbers** | Unrealistic design | Always estimate QPS, storage |
| **Over-engineering** | "We need Kafka, K8s, 50 microservices" | Start simple, add when needed |
| **Ignoring trade-offs** | "We'll use cache" — why? | "Cache for latency, trade-off: stale data" |
| **Monologue** | Interviewer bored | Ask "Does this make sense?" |
| **No data model** | Vague design | "Users table: id, email, createdAt" |
| **Forgetting failure** | Unrealistic | "What if DB fails? — Read replicas" |
| **Can't prioritize** | Try to do everything | "MVP is X, we can add Y later" |

---

## Red Flags (What Makes You Fail)

| Red Flag | Interviewer Thinks |
|----------|-------------------|
| **Can't clarify requirements** | "Can't scope a problem" |
| **No estimation** | "Doesn't think about scale" |
| **No trade-off discussion** | "Doesn't understand trade-offs" |
| **Can't handle curveballs** | "Rigid, can't adapt" |
| **Incomplete design** | "Missing critical components" |
| **Poor communication** | "Can't work with team" |
| **Over-complicated** | "Lacks judgment" |
| **Defensive** | "Won't accept feedback" |

---

## Green Flags (What Makes You Pass)

| Green Flag | Interviewer Thinks |
|------------|-------------------|
| **Structured approach** | "Thinks clearly" |
| **Clear communication** | "Can explain well" |
| **Trade-off awareness** | "Understands trade-offs" |
| **Depth when probed** | "Has solid fundamentals" |
| **Asks good questions** | "Product-minded" |
| **Adapts to feedback** | "Collaborative" |
| **Simple first** | "Pragmatic" |
| **Handles failures** | "Production-ready thinking" |

---

## Whiteboard Strategy

### Layout

```
┌─────────────────────────────────────────────────────────────┐
│  TOP-LEFT: Requirements (bullet points)                      │
│  - Scale: 100M URLs                                          │
│  - Read:Write = 100:1                                        │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  CENTER: Architecture Diagram (big, clear)                   │
│  [Client] → [LB] → [App] → [Cache] → [DB]                    │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  RIGHT: Numbers, Notes                                       │
│  QPS: 4K, Storage: 30GB                                      │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│  BOTTOM: Trade-offs, Alternatives                            │
│  SQL vs NoSQL: Chose SQL for consistency                     │
└─────────────────────────────────────────────────────────────┘
```

### Drawing Tips

1. **Boxes for components** — clear boundaries
2. **Arrows for flow** — label direction
3. **Write large** — interviewer should see from distance
4. **Leave space** — for additions during deep dive

---

## How FAANG Candidates Prepare

| Phase | Duration | Activities |
|-------|----------|------------|
| **Building Blocks** | 2 weeks | Scalability, Caching, DB, Load Balancing, etc. |
| **Practice Designs** | 2 weeks | 10-15 real designs (URL, Twitter, etc.) |
| **Mock Interviews** | 1 week | 3-5 mocks with feedback |
| **Revision** | Ongoing | Quick revision notes, formulas |

### Study Order

1. Fundamentals (Scalability, CAP, etc.)
2. Components (LB, Cache, DB, Queue)
3. Real designs (URL Shortener → Twitter → Uber)
4. Mock interviews

---

## Thinking Framework During Interview

**Ask yourself these questions:**

| Question | When to Ask |
|----------|-------------|
| "What is the most important feature?" | When scope is unclear |
| "What is the bottleneck?" | When designing |
| "What happens when this fails?" | For every component |
| "Can we make this simpler?" | When over-engineering |
| "What's the read vs write pattern?" | For storage choice |
| "Do we need strong consistency?" | For DB choice |
| "Where can we cache?" | For latency optimization |

---

## How System Design Resources on Internet Are Structured

| Resource Type | Structure | Use For |
|---------------|-----------|---------|
| **Blog posts** | Problem → Solution → Deep dive | Learning one system |
| **Video courses** | Topic → Example → Code | Visual learning |
| **Books** | Chapter → Concept → Example | Deep understanding |
| **Practice** | Problem → Your design → Compare | Interview prep |

**Common pattern:** Most resources teach "Design X" — but interview needs **framework** + **building blocks** first!

---

## Sample 45-Min Interview Flow (URL Shortener)

| Time | Activity | What to Say/Do |
|------|----------|----------------|
| 0-2 min | Understand question | "So we're building a URL shortener like bit.ly. Let me clarify requirements." |
| 2-8 min | Requirements | "Scale? 100M URLs. Read-heavy? Yes. Custom URLs? Optional." |
| 8-12 min | Estimation | "~4K read QPS, 40 write QPS, 30GB storage for 5 years." |
| 12-25 min | High-level design | Draw: Client → LB → App → Cache → DB. API design. Data model. |
| 25-40 min | Deep dive | "Hash collision? Retry. DB scaling? Sharding. Cache invalidation? TTL." |
| 40-45 min | Wrap-up | "Summary: Stateless app, Redis cache, DB. Could add analytics queue." |

---

## Pre-Interview Checklist (Day Before)

### Knowledge

- [ ] 4-step framework yaad hai
- [ ] Power of 2, latency numbers
- [ ] QPS, Storage formulas
- [ ] Common components (LB, Cache, DB, Queue)
- [ ] CAP, Consistency types
- [ ] 2-3 design patterns (URL, Twitter, Chat)

### Mindset

- [ ] Think aloud — practice
- [ ] Ask questions — don't assume
- [ ] State trade-offs — always
- [ ] Simple first — then add
- [ ] Accept feedback — gracefully

### Logistics

- [ ] Whiteboard/paper ready (if virtual)
- [ ] Good internet (if virtual)
- [ ] Quiet environment
- [ ] 5 min before: Deep breath, calm

---

## Final Reminders

1. **Requirements first** — 5 min minimum
2. **Numbers always** — QPS, Storage
3. **Trade-offs always** — "We chose X because Y, trade-off is Z"
4. **Communicate** — Think aloud, check-ins
5. **Simple first** — Monolith → Microservices when needed
6. **Failure handling** — "What if DB fails?"
7. **No perfect design** — Good enough + iterate

**Interview success = Structured + Communicative + Trade-off aware!**

---

## Time Allocation — 45 Min Breakdown

| Phase | Minutes | % | Focus |
|-------|---------|---|-------|
| Requirements | 5-10 | 15-20% | Scope, scale, constraints |
| Estimation | 5 | 10% | QPS, storage, bandwidth |
| High-level design | 15-20 | 35-40% | API, data, components |
| Deep dive | 15-20 | 35-40% | Bottlenecks, failures, trade-offs |
| Buffer | 5 | 10% | Wrap-up, questions |

---

## Question Types & How to Handle

| Question Type | Example | Response |
|---------------|---------|----------|
| **Open-ended** | "Design Twitter" | "Let me clarify — feed, tweets, or full system?" |
| **Scale given** | "100M users" | "So ~12K QPS if 10 req/user. Read-heavy?" |
| **Probe** | "What if cache fails?" | "DB serves directly. Slower but works. Add circuit breaker." |
| **Alternative** | "Why not NoSQL?" | "We need transactions for X. NoSQL = eventual. Trade-off." |
| **Curveball** | "Design for 1B QPS" | "At that scale: sharding, multiple regions, aggressive caching." |

---

## Body Language & Presence

| Do | Don't |
|----|-------|
| Face interviewer when explaining | Stare at whiteboard only |
| Pause to think | Rush without structure |
| Nod when they speak | Interrupt |
| Use hand gestures for flow | Stand rigid |
| Smile occasionally | Look stressed |

---

## Post-Interview Reflection

- What went well?
- Where did I get stuck?
- Did I cover requirements?
- Did I state trade-offs?
- Would I hire myself?
