import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: fibonacci-search */
function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  const n = a.length;
  let fibMm2 = 0;
  let fibMm1 = 1;
  let fibM = fibMm1 + fibMm2;
  while (fibM < n) {
    fibMm2 = fibMm1;
    fibMm1 = fibM;
    fibM = fibMm2 + fibMm1;
  }
  let offset = -1;
  steps.push({ type: 'init', array: [...a], pointers: { lo: 0, hi: n - 1 }, target, fibM, fibMm1, fibMm2 });
  while (fibM > 1) {
    const i = Math.min(offset + fibMm2, n - 1);
    steps.push({
      type: 'offset',
      array: [...a],
      pointers: { lo: 0, hi: n - 1, mid: i },
      target,
      i,
      fibM,
      fibMm1,
      fibMm2,
    });
    steps.push({ type: 'compare', array: [...a], pointers: { mid: i }, target, i });
    if (a[i] < target) {
      steps.push({ type: 'go-right', array: [...a], pointers: { mid: i }, target });
      fibM = fibMm1;
      fibMm1 = fibMm2;
      fibMm2 = fibM - fibMm1;
      offset = i;
    } else if (a[i] > target) {
      steps.push({ type: 'go-left', array: [...a], pointers: { mid: i }, target });
      fibM = fibMm2;
      fibMm1 = fibMm1 - fibMm2;
      fibMm2 = fibMm2 - fibMm1;
    } else {
      steps.push({ type: 'found', array: [...a], pointers: { mid: i }, target, idx: i });
      return steps;
    }
  }
  const j = offset + 1;
  if (fibMm1 && j < n) {
    steps.push({ type: 'last', array: [...a], pointers: { mid: j }, target, j });
    if (a[j] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { mid: j }, target, idx: j });
      return steps;
    }
  }
  steps.push({ type: 'notfound', array: [...a], pointers: {}, target });
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

export default function FibonacciSearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Fibonacci search for ${target}` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    if (step.type === 'init') {
      for (let i = 0; i < n; i++) colors[i] = 'active';
      store.addLog({
        time: `${store.stepIndex + 1}`,
        type: 'info',
        message: `Fib window size F=${step.fibM}, F-1=${step.fibMm1}, F-2=${step.fibMm2}`,
      });
    } else if (step.type === 'offset') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      for (let i = pointers.lo; i <= pointers.hi; i++) colors[i] = 'active';
      colors[step.i] = 'compare';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Probe offset+${step.fibMm2} → index ${step.i}` });
    } else if (step.type === 'compare') {
      colors[step.i] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Compare A[${step.i}]` });
    } else if (step.type === 'go-right' || step.type === 'go-left') {
      colors[pointers.mid] = 'compare';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Shrink Fibonacci window' });
    } else if (step.type === 'last') {
      colors[step.j] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: 'Final single-step check' });
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.idx] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at ${step.idx}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Not found' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      ...(found != null ? { found } : {}),
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
