import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const LRUCanvas = forwardRef(function LRUCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ order: [], mapPairs: [], cap: 3, phase: '' });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 300;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { order, mapPairs, cap, phase } = stateRef.current;
      ctx.fillStyle = '#57534e';
      ctx.font = '600 11px -apple-system, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`Hash map (capacity ${cap})`, 20, 28);
      let mx = 20;
      mapPairs.forEach(([k, v]) => {
        ctx.fillStyle = '#e0e7ff';
        ctx.strokeStyle = '#1c1917';
        ctx.beginPath();
        ctx.roundRect(mx, 40, 86, 34, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#1c1917';
        ctx.font = '600 11px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(`${k}:${v}`, mx + 43, 60);
        mx += 96;
      });
      ctx.textAlign = 'left';
      ctx.fillStyle = '#57534e';
      ctx.fillText('DLL (most recent → least)', 20, 120);
      let dx = 20;
      order.forEach((k, idx) => {
        ctx.fillStyle = idx === 0 ? '#ffd43b' : '#b2f2bb';
        ctx.strokeStyle = '#14532d';
        ctx.beginPath();
        ctx.roundRect(dx, 134, 60, 36, 8);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#14532d';
        ctx.font = 'bold 13px ui-monospace, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(String(k), dx + 30, 155);
        if (idx < order.length - 1) {
          ctx.strokeStyle = '#78716c';
          ctx.beginPath();
          ctx.moveTo(dx + 62, 152);
          ctx.lineTo(dx + 72, 152);
          ctx.stroke();
        }
        dx += 78;
      });
      if (phase) {
        ctx.fillStyle = '#44403c';
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(phase, W / 2, 210);
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function generateSteps(cap) {
  const steps = [];
  const map = new Map();
  const order = [];
  const snapshot = (phase) => {
    steps.push({
      type: 'state',
      mapPairs: [...map.entries()],
      order: [...order],
      cap,
      phase,
    });
  };
  snapshot('Start empty');
  const ops = [
    ['put', 1, 10],
    ['put', 2, 20],
    ['get', 1],
    ['put', 3, 30],
    ['put', 4, 40],
  ];
  ops.forEach((op) => {
    if (op[0] === 'put') {
      const k = op[1];
      const v = op[2];
      if (map.has(k)) {
        order.splice(order.indexOf(k), 1);
      } else if (order.length >= cap) {
        const ev = order.pop();
        map.delete(ev);
        snapshot(`Evict LRU key ${ev}`);
      }
      map.set(k, v);
      order.unshift(k);
      snapshot(`put(${k}, ${v})`);
    } else if (op[0] === 'get') {
      const k = op[1];
      if (map.has(k)) {
        order.splice(order.indexOf(k), 1);
        order.unshift(k);
        snapshot(`get(${k}) → move to front`);
      } else {
        snapshot(`get(${k}) miss`);
      }
    }
  });
  snapshot('✓ LRU walk complete');
  return steps;
}

export default function LRUCacheVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(3);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Capacity 3 LRU' });
    canvasRef.current?.setState({ ...steps[0] });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.phase || step.type });
    canvasRef.current?.setState({ ...step });
  }, []);

  return <AlgoVisualizer config={config} canvas={LRUCanvas} onInit={onInit} onStep={onStep} />;
}
