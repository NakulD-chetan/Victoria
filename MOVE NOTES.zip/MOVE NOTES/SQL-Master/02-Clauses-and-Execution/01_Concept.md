# Clauses and Execution — Concept

> **Permanent recall:** `WHERE` filters **rows** before grouping; `HAVING` filters **groups** after `GROUP BY`. **Logical execution order ≠ written order** — interviews love this.

---

## Written vs logical order (ANSI mental model)

**Typical written order:** `SELECT … FROM … WHERE … GROUP BY … HAVING … ORDER BY … LIMIT`

**Logical processing (conceptual):**

1. `FROM` / `JOIN` — build working table
2. `WHERE` — row filter
3. `GROUP BY` — buckets
4. `HAVING` — group filter
5. `SELECT` — expressions, aliases (incl. aggregates)
6. `DISTINCT` (if present)
7. `ORDER BY`
8. `LIMIT` / `OFFSET`

> Exact engine optimizations vary, but **this order answers "why can't I use alias in WHERE?"** — alias often doesn't exist yet at `WHERE` time.

---

## WHERE vs HAVING (one line each)

- **WHERE:** predicate on **raw rows** (before grouping). Cannot use aggregate functions.
- **HAVING:** predicate on **groups** / aggregates (after grouping). Can use aggregate functions.

---

## SELECT pieces

- **Aliases:** shorten names; watch dialect for alias scope in `ORDER BY` vs `WHERE`.
- **`DISTINCT`:** dedupe result rows. Applies to ALL selected columns.
- **`ORDER BY`:** sort; `ASC` default. Can reference alias (in most DBs).
- **`LIMIT`/`OFFSET`:** slice result (names vary: `TOP`, `FETCH FIRST`, `ROWNUM`).

---

## SET Operations (UNION, INTERSECT, EXCEPT)

| Operation | What it does | Duplicates |
|-----------|-------------|-----------|
| **UNION** | Combines results of two SELECTs, removes duplicates | Removed |
| **UNION ALL** | Combines results, keeps ALL rows including duplicates | Kept |
| **INTERSECT** | Only rows present in BOTH queries | Removed |
| **EXCEPT** / **MINUS** | Rows in first query but NOT in second | Removed |

**Rules:**
- Both SELECTs must have **same number of columns**
- Corresponding columns must have **compatible data types**
- Column names come from the **first** SELECT
- `UNION ALL` is faster than `UNION` (no dedup overhead) — use when you know no duplicates or want all

```sql
SELECT city FROM customers
UNION
SELECT city FROM suppliers;

SELECT id FROM table_a
EXCEPT
SELECT id FROM table_b;
```

---

## Important SQL Functions (definition-style)

### COALESCE
Returns the **first non-NULL** value from a list of arguments.
```sql
SELECT COALESCE(phone, email, 'No contact') AS contact FROM users;
```

### NULLIF
Returns **NULL** if two expressions are equal; otherwise returns the first.
```sql
SELECT revenue / NULLIF(cost, 0) AS margin;  -- avoids division by zero
```

### CAST / CONVERT
Changes data type of a value.
```sql
SELECT CAST('2024-01-15' AS DATE);
SELECT CAST(price AS DECIMAL(10,2));
-- SQL Server: CONVERT(DATE, '2024-01-15', 120)
```

### IFNULL / ISNULL / NVL
Returns replacement if value is NULL (dialect-specific).
```sql
-- MySQL: IFNULL(col, 0)
-- SQL Server: ISNULL(col, 0)
-- Oracle: NVL(col, 0)
-- Standard: COALESCE(col, 0)
```

---

## Pattern families

- **Filter:** `WHERE col op value`, `IN`, `BETWEEN`, `LIKE`, `IS NULL`
- **Conditional:** `CASE WHEN … THEN … END` (searched CASE and simple CASE)
- **Sort:** `ORDER BY col DESC NULLS LAST` (Postgres-style)
- **Pagination:** `LIMIT … OFFSET` / `FETCH FIRST N ROWS ONLY`

---

## LIKE Pattern Matching

| Pattern | Meaning |
|---------|---------|
| `%` | Zero or more characters |
| `_` | Exactly one character |
| `LIKE 'A%'` | Starts with 'A' |
| `LIKE '%A'` | Ends with 'A' |
| `LIKE '%SQL%'` | Contains 'SQL' anywhere |
| `LIKE 'A_B'` | 'A' + one char + 'B' |

**ESCAPE:** `LIKE '%10\%%' ESCAPE '\'` → matches literal `%`

---

## IN vs BETWEEN vs EXISTS

| Operator | Use case |
|----------|---------|
| `IN (list)` | Match against a list of values; can use subquery |
| `BETWEEN a AND b` | Range check (inclusive both ends) |
| `EXISTS (subquery)` | TRUE if subquery returns at least one row |

---

## CASE Expression (two forms)

**Searched CASE** (most common):
```sql
CASE WHEN condition1 THEN result1
     WHEN condition2 THEN result2
     ELSE default_result
END
```

**Simple CASE:**
```sql
CASE column
     WHEN value1 THEN result1
     WHEN value2 THEN result2
     ELSE default_result
END
```

---

*Next: [[02_Mental-Model]]*
