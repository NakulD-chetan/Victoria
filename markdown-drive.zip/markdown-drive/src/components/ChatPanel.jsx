import { useState, useRef, useEffect, useCallback, memo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

const ChatPanel = memo(function ChatPanel({ messages, loading, historyLoading, folder, filename, onSend, onClose, onClearHistory }) {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const handleSubmit = useCallback(() => {
    const q = input.trim();
    if (!q || loading) return;
    onSend(q);
    setInput('');
  }, [input, loading, onSend]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(); }
  }, [handleSubmit]);

  const scope = filename ? `${folder}/${filename}` : folder || 'all files';

  return (
    <div className="chat-panel">
      <div className="chat-panel__header">
        <div className="chat-panel__header-left">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <div>
            <h3>Chat</h3>
            <span className="chat-panel__scope">{scope}</span>
          </div>
        </div>
        <div className="chat-panel__header-right">
          {messages.length > 0 && onClearHistory && (
            <button className="chat-panel__clear" onClick={onClearHistory} title="Clear history">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
            </button>
          )}
          <button className="chat-panel__close" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      <div className="chat-panel__messages">
        {historyLoading ? (
          <div className="chat-panel__skeleton">
            <div className="chat-skeleton-bubble chat-skeleton-bubble--right">
              <div className="skeleton-line" style={{ width: '60%', height: '10px' }} />
            </div>
            <div className="chat-skeleton-bubble chat-skeleton-bubble--left">
              <div className="skeleton-line" style={{ width: '80%', height: '10px' }} />
              <div className="skeleton-line" style={{ width: '55%', height: '10px' }} />
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="chat-panel__empty">
            <div className="chat-panel__empty-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <circle cx="12" cy="12" r="10" />
                <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
            </div>
            <p>Ask anything about your files</p>
            <div className="chat-panel__suggestions">
              {['What topics are covered?', 'Summarize the main points', 'Key concepts?'].map((q, i) => (
                <button key={i} className="chat-panel__suggestion" onClick={() => onSend(q)}>{q}</button>
              ))}
            </div>
          </div>
        ) : null}

        {messages.map((msg, i) => (
          <div key={i} className={`chat-msg chat-msg--${msg.role}`}>
            <div className="chat-msg__avatar">
              {msg.role === 'user' ? (
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
                </svg>
              ) : (
                <svg width="10" height="10" viewBox="0 0 100 100"><path d="M50 8 C50 8 72 35 72 55 C72 67 62 78 50 78 C38 78 28 67 28 55 C28 35 50 8 50 8Z" fill="white" /></svg>
              )}
            </div>
            <div className="chat-msg__content">
              {msg.role === 'assistant' ? (
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.content}</ReactMarkdown>
              ) : (
                <p>{msg.content}</p>
              )}
              {msg.sources?.length > 0 && (
                <div className="chat-msg__sources">
                  <span>Sources:</span>
                  {msg.sources.map((s, j) => <span key={j} className="chat-msg__source-tag">{s}</span>)}
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="chat-msg chat-msg--assistant">
            <div className="chat-msg__avatar">
              <svg width="10" height="10" viewBox="0 0 100 100"><path d="M50 8 C50 8 72 35 72 55 C72 67 62 78 50 78 C38 78 28 67 28 55 C28 35 50 8 50 8Z" fill="white" /></svg>
            </div>
            <div className="chat-msg__content">
              <div className="chat-msg__typing"><span /><span /><span /></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="chat-panel__input-area">
        <div className="chat-panel__input-wrapper">
          <textarea ref={inputRef} className="chat-panel__input" placeholder="Follow up..." value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown} rows={1} />
          <button className="chat-panel__send" onClick={handleSubmit} disabled={!input.trim() || loading}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
              <line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
});

export default ChatPanel;
