# Date Series Fill — Problem List

> **18 problems in progressive difficulty. 10 MUST-DO highlighted. Covers date generation, gap filling, forward fill, multi-dimension fill, and calendar views. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Fill Missing Dates with Zero | Common | Easy | Basic date fill | Purest date series pattern |
| 2 | Hopper Company Queries I | LC 1635 | Hard | Month series fill | Generate months, LEFT JOIN data |
| 3 | Active Users Per Day | DataLemur | Medium | Daily fill | Complete daily activity report |
| 4 | Monthly Revenue Report | Common | Medium | Month fill + agg | Revenue for every month |
| 5 | User Login Calendar | Common | Medium | Multi-dim fill | User × Date grid |
| 6 | Sales Dashboard Fill | StrataScratch | Medium | Daily + COALESCE | Dashboard-ready gap-free data |
| 7 | Find Missing Dates in Range | Common | Easy | Gap identification | List dates with no data |
| 8 | Rolling 7-Day Average (no gaps) | Common | Hard | Fill + rolling avg | Fill first, then window function |
| 9 | Forward Fill Prices | Common | Hard | Last-value carry | Fill NULL with previous non-NULL |
| 10 | Weekly Active Users Calendar | DataLemur | Medium | Weekly series | Complete weekly report |

---

## Complete 18-Problem Progression

### Easy (Problems 1-5) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Fill Missing Dates with Zero | Common | generate_series + LEFT JOIN | Basic date fill |
| 2 | Find Missing Dates in Range | Common | LEFT JOIN + IS NULL | Identify gaps |
| 3 | Complete Number Sequence | Common | Number series | Fill missing IDs |
| 4 | Daily Sales Report | HackerRank | Date fill + SUM | Daily totals with zeros |
| 5 | Days Without Logins | Common | Series - actual | Find inactive days |

### Medium (Problems 6-13) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 6 | Active Users Per Day | DataLemur | Daily + COUNT | Count per generated date |
| 7 | Monthly Revenue Report | Common | Month series + SUM | Monthly aggregation with fill |
| 8 | User Login Calendar | Common | CROSS JOIN users × dates | Multi-dimension grid fill |
| 9 | Sales Dashboard Fill | StrataScratch | Daily + COALESCE(,0) | Production dashboard pattern |
| 10 | Weekly Active Users | DataLemur | Weekly series | DATE_TRUNC week + fill |
| 11 | Quarterly Comparison | Common | Quarter series | Q1-Q4 comparison with fill |
| 12 | Running Total on Filled Dates | Common | Fill + SUM OVER | Pattern 11 + Pattern 07 combo |
| 13 | Per-Category Daily Fill | Common | CROSS JOIN categories × dates | Multi-dimension + category |

### Hard (Problems 14-18) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 14 | Hopper Company Queries I | LC 1635 | Month series + complex join | Generate 12 months, multi-table |
| 15 | Rolling 7-Day Average (no gaps) | Common | Fill + rolling window | Fill dates → rolling avg (ROWS 6 PREC) |
| 16 | Forward Fill Prices | Common | COUNT trick + FIRST_VALUE | Carry last known value forward |
| 17 | Cohort Retention Calendar | DataLemur | Signup month × offset | Month-by-month retention grid |
| 18 | Sparse Time Series Analysis | Advanced | Fill + interpolation | Linear interpolation between known points |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Fill Missing Dates with Zero

```
Pattern:     generate_series + LEFT JOIN + COALESCE
Approach:    WITH dates AS (SELECT generate_series(min, max, '1 day'))
             SELECT ds.date, COALESCE(COUNT(o.id), 0)
             FROM dates ds LEFT JOIN orders o ON o.date = ds.date
             GROUP BY ds.date
Key Insight: LEFT JOIN ensures all generated dates appear; COALESCE fills NULLs
One-liner:   Generate date range, LEFT JOIN data, COALESCE nulls to zero.
```

### Problem 8: User Login Calendar

```
Pattern:     CROSS JOIN + LEFT JOIN
Approach:    CROSS JOIN users with date_series → complete grid
             LEFT JOIN logins → 1 if logged in, 0 if not
Key Insight: CROSS JOIN creates every (user, date) combination
One-liner:   Users × dates via CROSS JOIN; LEFT JOIN logins; CASE for 0/1.
```

### Problem 14: Hopper Company Queries I (LC 1635)

```
Pattern:     Month series + multi-table aggregation
Approach:    Generate months 1-12 for the year
             LEFT JOIN active_drivers (count per month)
             LEFT JOIN accepted_rides (count per month)
Key Insight: Multiple LEFT JOINs on the same generated series
One-liner:   12-month series; LEFT JOIN drivers and rides; COALESCE to 0.
```

### Problem 16: Forward Fill Prices

```
Pattern:     COUNT(non-null) OVER + FIRST_VALUE
Approach:    1) LEFT JOIN prices onto date series
             2) COUNT(price) OVER (ORDER BY date) AS grp
                (creates groups sharing same last-known value)
             3) FIRST_VALUE(price) OVER (PARTITION BY grp ORDER BY date)
Key Insight: COUNT of non-NULLs creates groups for forward fill
One-liner:   Count non-nulls for grouping; first_value per group = forward fill.
```

---

## Pattern Distribution

```
BASIC DATE FILL (series + LEFT JOIN):    7 problems  (1-5, 7, 9)
MULTI-DIMENSION (CROSS JOIN grid):       4 problems  (8, 10, 13, 17)
FILL + WINDOW FUNCTION:                  3 problems  (12, 15, 18)
FORWARD FILL (carry last value):         2 problems  (16, 18)
COMPLEX SERIES (month/week/quarter):     2 problems  (11, 14)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Basic date fill, find missing dates
- Day 2: Daily sales report, number sequence fill
- Day 3: Monthly revenue, inactive days

### Week 2: Multi-Dimension (Days 4-6)
- Day 4: User login calendar (CROSS JOIN pattern)
- Day 5: Weekly/quarterly series, dashboard fill
- Day 6: Per-category daily fill, running total on filled dates

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 1635 (Hopper), rolling 7-day on filled dates
- Day 8: Forward fill, cohort retention calendar
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Generate dates via recursion | Pattern 02 (Recursive CTE) — date series approach |
| Rolling average after filling | Pattern 07 (Running Total) — ROWS BETWEEN on filled data |
| Find gaps (not fill them) | Pattern 08 (Gaps and Islands) — gap detection |
| Combine data sources before fill | Pattern 10 (Set Operations) — UNION ALL |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     18 (5 Easy, 8 Medium, 5 Hard)
MUST-DO:            LC 1635 + DataLemur/StrataScratch + common patterns
TOP 3 MOST ASKED:   Daily fill with zero, monthly revenue, user calendar
PATTERN SPLIT:      Basic fill (7), Multi-dim (4), Fill+Window (3),
                    Forward fill (2), Complex series (2)
STUDY ORDER:        Basic fill → Monthly/Weekly → CROSS JOIN grid → Forward fill
KEY INSIGHT:        Generate complete timeline → LEFT JOIN data → COALESCE to 0
INTERVIEW LINE:     "I generate a date series, LEFT JOIN actual data, and
                     COALESCE NULLs to zero for gap-free reports."
```

---

## 30-SECOND REVISION BOX

```
GENERATE:     PostgreSQL: generate_series(start, end, interval)
              MySQL/MSSQL: recursive CTE (anchor + date + 1 day)
              BigQuery: GENERATE_DATE_ARRAY(start, end)
LEFT JOIN:    date_series LEFT JOIN actual ON date = actual.date
COALESCE:     COALESCE(SUM(amount), 0) — NULL becomes 0
MULTI-DIM:    CROSS JOIN users × dates → complete grid
FORWARD FILL: COUNT(non_null) OVER → FIRST_VALUE per group
MONTHLY:      DATE_TRUNC('month', date) for month-level join
RULE:         Always LEFT JOIN from series to data (not vice versa)
PERFORMANCE:  Index the date column; limit CROSS JOIN to active users
```
