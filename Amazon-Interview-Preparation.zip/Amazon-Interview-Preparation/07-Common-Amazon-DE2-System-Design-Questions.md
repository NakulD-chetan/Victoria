# Common Amazon DE2 System Design Questions - Answer Playbook

## How to Use This Note

This file is not just a list of prompts. It tells you how to answer the most common Amazon DE2 system design questions in a clean interview format.

Use the same 5-step structure every time:

1. Clarify requirements
2. Give high-level design
3. Deep dive into 2-3 areas
4. Explain scaling
5. Close with trade-offs

---

## Strong 30-Second Opening Template

> "Let me first clarify the scale, latency, consumers, and correctness requirements. Then I will give a simple end-to-end design, deep dive into the important storage and processing choices, and finally cover failures, scaling, and trade-offs."

---

## 1. Batch Data Pipeline

**Prompt:** Design a daily pipeline that ingests sales data from multiple countries and makes it available for reporting by 8 AM.

### Clarify

- daily or hourly?
- total data volume?
- source systems?
- SLA by 8 AM local time or one global time?

### High-level design

```text
Sources -> Ingestion -> Raw S3 -> Spark/Glue -> Curated Parquet -> Redshift/Athena
```

### Deep dive areas

- immutable raw data
- partitioning by date/country
- idempotent reruns and backfills

### What interviewer wants to hear

- raw S3 landing
- transformation layer
- partitioning
- validation
- SLA handling
- backfills

---

## 2. Real-Time Analytics Pipeline

**Prompt:** Design a system that processes clickstream events in near real-time for dashboards and alerts.

### Clarify

- what does near-real-time mean?
- expected TPS and peak load?
- do we need ordering?
- what is the serving layer?

### High-level design

```text
Apps -> Kafka/Kinesis -> Stream Processing -> S3 + Real-Time Serving
```

### Deep dive areas

- partitioning and ordering
- late events and watermarks
- lag monitoring and replay

### What interviewer wants to hear

- Kafka/MSK or Kinesis
- partitioning
- low-latency processing
- late data handling
- lag monitoring

---

## 3. CDC Pipeline

**Prompt:** Design a pipeline to replicate changes from an OLTP database into the analytics platform.

### Clarify

- source DB type?
- freshness target?
- current state only or full history?
- do we need deletes?

### High-level design

```text
DB -> Binlog/WAL -> CDC Connector -> Raw Change Log -> Merge Layer -> Analytics Tables
```

### Deep dive areas

- snapshot + incremental
- checkpoints
- upserts and deletes

### What interviewer wants to hear

- binlog/WAL based CDC
- snapshot + streaming
- delete handling
- checkpoints
- schema evolution

---

## 4. Data Lake Design

**Prompt:** Design a company-wide data lake for raw and curated datasets on AWS.

### Clarify

- which teams use it?
- what engines need access?
- governance and PII needs?
- retention period?

### High-level design

```text
Sources -> S3 Raw/Staged/Curated -> Glue Catalog/Lake Formation -> Athena/Spark/Spectrum
```

### Deep dive areas

- zone layout
- Parquet and partitioning
- Iceberg and governance

### What interviewer wants to hear

- S3 zones
- Parquet
- Glue Catalog
- governance
- access control
- Iceberg

---

## 5. Data Warehouse Design

**Prompt:** Design a warehouse for business analytics and executive dashboards.

### Clarify

- dashboard concurrency?
- latency expectation?
- history needed?
- raw vs curated data?

### High-level design

```text
Curated S3 -> Redshift Staging -> Facts/Dimensions -> BI
```

### Deep dive areas

- star schema
- SCD Type 2
- staging -> validate -> merge

### What interviewer wants to hear

- fact and dimension tables
- incremental loads
- star schema
- SCD Type 2
- Redshift optimization

---

## 6. Backfill + Recovery Design

**Prompt:** A bug corrupted 30 days of data. How would you reprocess safely?

### Clarify

- is raw data still available?
- how many partitions are affected?
- can we pause downstream consumption?
- how quickly must recovery finish?

### High-level design

```text
Identify affected range -> Reprocess from raw -> Validate -> Publish safely
```

### Deep dive areas

- partition-based reruns
- idempotent jobs
- temporary publish paths

### What interviewer wants to hear

- immutable raw data
- isolated reruns
- validation before publish
- safe swap logic

---

## 7. Data Quality / Observability Design

**Prompt:** Design a framework to detect bad data before analysts consume it.

### Clarify

- what quality failures matter most?
- dataset count and owners?
- are rules static or changing?
- what is the alerting path?

### High-level design

```text
Ingest -> Validate -> Quality Metadata -> Alerting -> Publish Gate
```

### Deep dive areas

- rule types
- freshness and anomaly checks
- lineage and run metadata

### What interviewer wants to hear

- null and uniqueness checks
- anomaly detection
- freshness checks
- alerting
- metadata and lineage

---

## 8. Schema Evolution Problem

**Prompt:** A source team changed the event schema without notice. How should the platform handle it?

### Clarify

- backward compatible or breaking change?
- raw data still readable?
- which downstream consumers break?

### High-level design

```text
Preserve raw -> Detect schema change -> Quarantine/compatibility checks -> Controlled promotion
```

### Deep dive areas

- versioned schemas
- raw preservation
- controlled curated promotion

### What interviewer wants to hear

- schema versioning
- compatibility checks
- quarantine path
- no silent corruption

---

## 9. Multi-Tenant Data Platform

**Prompt:** Design a shared analytics platform for multiple internal teams with strong security boundaries.

### Clarify

- how many teams?
- shared platform or dedicated spaces?
- cost attribution needed?
- PII and access rules?

### High-level design

```text
Shared Storage + Shared Platform Services + Team Isolation + Governance
```

### Deep dive areas

- namespace isolation
- IAM/Lake Formation
- ownership and quotas

### What interviewer wants to hear

- security boundaries
- access control
- cost attribution
- governance
- autonomy vs central standards

---

## 10. Cost Optimization Design

**Prompt:** Your data platform cost doubled in 3 months. How would you redesign it?

### Clarify

- where is the cost growth: storage, compute, warehouse, streaming?
- which queries or jobs are driving it?
- is performance already acceptable?

### High-level design

```text
Measure cost drivers -> Optimize format/partitioning -> Reduce waste -> Re-architect hot paths
```

### Deep dive areas

- Parquet and partition pruning
- small-file reduction
- warehouse optimization

### What interviewer wants to hear

- Parquet conversion
- compaction
- lifecycle/tiering
- workload tuning
- aggregate tables

---

## Cross-Cutting Topics Interviewers Love

- idempotency
- duplicate handling
- late-arriving data
- schema evolution
- replayability
- partitioning strategy
- monitoring and alerting
- data quality checks
- cost optimization
- security and PII handling

---

## Quick Checklist Before You Finish Any Answer

1. Did I clarify scale and latency?
2. Did I mention raw durable storage?
3. Did I explain partitioning and format choices?
4. Did I cover retries, duplicates, and backfills?
5. Did I mention monitoring, security, and cost?

---

## Final Advice

Do not try to sound too advanced too early.

A strong answer is usually:

- simple
- structured
- operationally aware
- clear on trade-offs

That is better than listing many AWS services without explaining why.
