# Data Warehouse vs Data Lake

> *"Data is a precious thing and will last longer than the systems themselves."* — Tim Berners-Lee

**Real-world analogy:** A **data warehouse** is like a **supermarket floor**: products are **labeled, priced, and shelved by aisle** before shoppers arrive (**schema-on-write**). A **data lake** is like a **distribution cross-dock**: pallets arrive in mixed formats and are **sorted only when** a downstream team opens a pallet (**schema-on-read**). Modern **lakehouses** try to keep the cross-dock scale while adding **quality guardrails** similar to retail planograms.

---

## Core Idea (2 Lines)

A **classic data warehouse** favors **structured**, **governed** datasets loaded through **ETL** with **schema-on-write**. A **data lake** favors **cheap, flexible storage** for many formats, often loaded with **ELT** and **schema-on-read**, accepting more curation work at query time — **lakehouses** merge these worlds with transactional table formats.

---

## Data Warehouse Architecture: ETL and Schema-on-Write

| Step | Meaning | Retail example |
|------|---------|----------------|
| **Extract** | Pull from sources | Nightly SFTP of partner store sales; CDC from loyalty |
| **Transform** | Cleanse, conform, aggregate | Map SKUs, resolve time zones, compute net price |
| **Load** | Land into modeled tables | Load `fact_sales`, `dim_product` with constraints |

```
Sources --> [Extract] --> [Transform in ETL tool / Spark] --> [Load to DW]
                                      |
                                      v
                           curated tables (typed, constrained)
```

**Interview Tip:** Tie **schema-on-write** to **contract-first** thinking: consumers see stable tables because **engineering enforced** types and keys before publish.

---

## DW Limitations: Volume, Velocity, Variety (and Friends)

| "V" | Limitation for classic DW | How it shows up for a retailer |
|-----|---------------------------|--------------------------------|
| **Volume** | High per-TB platform cost at extreme scale | Clickstream + IoT sensor logs dwarf order headers |
| **Velocity** | Batch windows dominate | Flash sales need rapid ingest; hourly loads feel slow |
| **Variety** | Semi/unstructured data is awkward | Images, JSON event payloads, vendor-specific blobs |
| **Cost / scale** | MPP appliances historically expensive | Finance questions total cost of ownership vs cloud object storage |
| **Experimentation** | Rigidity slows exploratory science | Data science wants raw features without waiting for dimensional models |

**Watch Out!** Saying "data lakes fix everything" ignores **downstream chaos** if nobody owns curation. Flexibility is a **trade**, not a free lunch.

---

## Data Lake: ELT and Schema-on-read

| Idea | Meaning |
|------|---------|
| **ELT** | Land data **first**, transform with **warehouse/lake compute** (SQL, Spark) |
| **Schema-on-read** | Interpret structure **when reading**; landing zone tolerates change |

```sql
-- Schema-on-read pattern (illustrative): parse JSON events at query time
SELECT
  $1:order_id::STRING            AS order_id,
  TRY_TO_TIMESTAMP($1:ts::STRING) AS event_ts,
  $1:event_type::STRING          AS event_type
FROM raw_clickstream_events;
```

**Interview Tip:** Contrast **governance moment**: DW enforces early; lake often enforces **later** via curated zones and tests.

---

## Vertical vs Horizontal Scaling

| Scaling model | Mental model | Typical association |
|---------------|--------------|---------------------|
| **Vertical ("scale up")** | Bigger machine: more RAM, faster CPUs | Traditional MPP DW nodes, monolithic appliances |
| **Horizontal ("scale out")** | More machines share work | Spark clusters, distributed query engines on object storage |

```
Vertical                         Horizontal
+------------------+             +-----+-----+-----+
| BIG NODE         |             | n1  | n2  | n3  |
| more CPU/RAM     |             +--+--+--+--+--+--+
+------------------+                parallel workers
```

**Watch Out!** Horizontal scale still needs **good partitioning** and **file layout**; otherwise you pay for nodes that **shuffle** more than they compute.

---

## Modern Data Lake Architecture: Four Layers

| Layer | Purpose | Retail example |
|-------|---------|----------------|
| **Ingestion** | Durable capture from sources | Kafka topics for cart events; batch landing of partner files |
| **Processing** | Transform, enrich, validate | Spark jobs computing session features |
| **Processed / curated** | Trusted datasets for teams | `curated.orders_daily`, `curated.customer_dim` |
| **Consumption** | BI, ML, reverse ETL | Tableau on curated tables; recommender training |

```
+-------------------+      +-------------------+      +-------------------+
|   INGESTION       | ---> |   PROCESSING      | ---> |   PROCESSED       |
| raw object files  |      | Spark / SQL jobs  |      | curated datasets  |
| event streams     |      | DQ checks         |      | partitioned     |
+---------+---------+      +---------+---------+      +---------+---------+
                                                    |
                                                    v
                                          +-------------------+
                                          |   CONSUMPTION     |
                                          | BI / ML / APIs    |
                                          +-------------------+
```

**Interview Tip:** Name the layers and explain **why raw is not equal to published** — debugging, replay, and compliance.

---

## DW vs Data Lake: Comparison Table

| Dimension | **Data Warehouse** | **Data Lake** |
|-----------|--------------------|---------------|
| **Storage footprint mindset** | Curated, smaller relative to raw | **Cheap** bulk retention of raw history |
| **Data types** | Relational, typed, structured-first | Structured + semi-structured + unstructured |
| **Schema** | **Schema-on-write** (mostly) | **Schema-on-read** in raw; curated zone may mimic DW |
| **Pattern** | ETL historically; ELT also possible on modern platforms | **ELT** common at scale |
| **Cost posture** | Higher governance/ modeling cost up front | Lower landing cost; **higher** curation debt if unmanaged |

---

## Data Lakehouse (Delta Lake / Apache Iceberg / Apache Hudi)

| Capability | Why it matters |
|------------|----------------|
| **ACID transactions on object storage** | Concurrent writers/readers without corrupting folders of files |
| **Time travel / snapshots** | Reproducible ML training and audit |
| **Schema evolution** | Safer column adds/renames with governance |
| **File pruning / compaction** | Keeps query performance from collapsing |

**Watch Out!** **Lakehouse** is not a magic synonym for "cheap DW." It still needs **engineering discipline** — layout, partitioning, compaction, and access control.

---

## ASCII: Classic DW vs Lake on Object Storage

```
CLASSIC DW (conceptual)                 DATA LAKE (conceptual)
===================                     ======================

Apps/Partners                           Apps/Partners
      |                                       |
      v                                       v
  ETL/ELT jobs                           ingest to OBJECT STORE
      |                                       |
      v                                       +--> RAW zone
 curated RDBMS / MPP                           |
 star/snowflake models                         v
      |                                   PROCESSING
      v                                       |
   BI tools                                   v
                                           CURATED zone
                                                |
                                                v
                                            BI / ML
```

**Interview Tip:** If asked *"Which one should we pick?"*, answer with **workloads**: compliance-heavy curated reporting vs **massive diverse** ingestion and data science — often **both** coexist.

---

## Hybrid Pattern (Very Common in Retail)

| Pattern | Description |
|---------|-------------|
| **Lake as landing + DW as serve** | Raw events in S3/ADLS; curated facts in a warehouse engine |
| **Lakehouse as the platform** | One stack serves SQL BI and Spark ML with shared tables |

```sql
-- Hybrid illustration: curated table in a warehouse reading external stage
-- (syntax varies by platform; intent is the pattern)

CREATE EXTERNAL TABLE curated.partner_sales
USING DELTA
LOCATION 's3://retail-lake/curated/partner_sales/';
```

---

## Security and Governance Comparison

| Topic | DW | Lake |
|-------|----|------|
| **Column masking** | Mature in enterprise DWs | Depends on catalog + engine integration |
| **Lineage** | Often in DW tools | Needs **catalog** (e.g., Unity, Glue, DataHub) |
| **PII** | Easier when structured early | Riskier in raw zones without **classification** |

**Watch Out!** Open lakes without IAM discipline become **data exfiltration** hazards.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Dumping raw files into S3 and calling it a "data lake strategy" | **Swamp**: nobody can find truth | Define zones: raw, curated, consumption |
| Using only a DW when variety/volume demands cheap retention | Expensive or impossible ingestion | Add **object storage landing** with governed promotion |
| Using only a lake for executive KPIs without curation | Slow, inconsistent answers | Build **curated** semantic layer or DW exports |
| Ignoring small file problem | Queries slow exponentially | **Compaction**, partitioning, sensible file sizes |
| Confusing lakehouse formats without operations | Still get corruption/lag | Run **maintenance jobs** + monitor table health |

---

## Key Takeaway

> **Data warehouses** excel at **governed, structured analytics** via **schema-on-write** and curated modeling, while **data lakes** excel at **economical scale and variety** via flexible landing and **schema-on-read** processing. Modern **lakehouses** add transactional table semantics on object storage, and most enterprises end with a **hybrid**: raw and diverse processing on the lake side, **trusted metrics** published for the business.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| DW: ETL, schema-on-write, curated, strong BI fit                 |
| Lake: ELT, schema-on-read, cheap scale, high variety             |
| 3 Vs: volume, velocity, variety challenge classic DW economics   |
| Scale: vertical (bigger box) vs horizontal (more workers)        |
| Lake architecture: ingest -> process -> processed -> consumption |
| Lakehouse: ACID tables (Delta / Iceberg / Hudi) on object store  |
+------------------------------------------------------------------+
```
