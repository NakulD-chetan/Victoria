# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. FACT TABLE vs DIMENSION TABLE
==================================================

Key idea:
- Fact table → stores numbers (metrics)
- Dimension table → stores description (context)

Simple meaning:
Facts = WHAT happened  
Dimensions = WHY / WHERE / HOW it happened


----------------------------------------
Real-world analogy
----------------------------------------

Receipt example:

- Quantity = 2  
- Price = 200  

These are FACTS

But without context:
- Which product?
- Which store?
- Which time?

That context comes from DIMENSIONS



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Fact Table:
- Stores measurable values
- Always tied to a specific grain

Dimension Table:
- Stores descriptive data
- Helps filter and group facts

Goal:
- Combine facts + dimensions → meaningful insights



==================================================
3. BUSINESS GOAL DRIVES DESIGN
==================================================

Example Question:
"Which product categories grew margin in Q3?"

----------------------------------------
Needed Facts:
----------------------------------------
- sales amount
- cost amount
- units


----------------------------------------
Needed Dimensions:
----------------------------------------
- time (quarter)
- product (category)
- store (type)


----------------------------------------
Design Decisions:
----------------------------------------
- Grain: one row per sale line
- Dimensions provide attributes
- Facts provide numbers


----------------------------------------
Important Insight
----------------------------------------
Always start with:
Business Question → Grain → Dimensions → Facts



==================================================
4. FACT TABLE (IN DETAIL)
==================================================

Fact table contains:

----------------------------------------
1. Measurements (numbers)
----------------------------------------
- sale_amount
- quantity


----------------------------------------
2. Foreign Keys
----------------------------------------
- product_sk
- store_sk
- date_sk


----------------------------------------
3. Degenerate Keys
----------------------------------------
- transaction_id


----------------------------------------
SQL Example
----------------------------------------

CREATE TABLE fact_pos_sale_line (
  pos_transaction_id,
  product_sk,
  store_sk,
  date_sk,
  sale_amount,
  quantity
);


----------------------------------------
Important Rule
----------------------------------------
Facts should be:
- Numeric
- Aggregatable



==================================================
5. DIMENSION TABLE (IN DETAIL)
==================================================

Dimension tables contain descriptive attributes

----------------------------------------
Examples
----------------------------------------

dim_product:
- brand
- category
- product_name

dim_store:
- region
- store type

dim_date:
- year
- month

dim_promotion:
- discount type


----------------------------------------
Purpose
----------------------------------------
- Provide context
- Enable filtering



==================================================
6. FACT + DIMENSION RELATION
==================================================

Fact table connects to multiple dimensions

Example:

fact_sales
  → product_sk → dim_product
  → store_sk → dim_store
  → date_sk → dim_date


----------------------------------------
Meaning
----------------------------------------
- Each fact row is linked to context


----------------------------------------
Important
----------------------------------------
One fact can connect to many dimensions



==================================================
7. RECEIPT TO DATA MODEL
==================================================

Real-world receipt:

Store: #104  
Product: Milk  
Qty: 2  
Price: 3.49  


----------------------------------------
Mapped to tables:
----------------------------------------

Fact:
- quantity = 2
- sale_amount = 6.98

Dimensions:
- product_sk → milk
- store_sk → store 104
- date_sk → date


----------------------------------------
SQL Example
----------------------------------------

SELECT
  transaction_id,
  product_sk,
  store_sk,
  date_sk,
  quantity,
  sale_amount
FROM receipt_data;



==================================================
8. NAMING CONVENTION
==================================================

Fact:
- fact_sales
- fact_orders

Dimension:
- dim_product
- dim_store


----------------------------------------
Why important?
----------------------------------------
- Easy to understand
- Easy to manage



==================================================
9. KEYS (VERY IMPORTANT)
==================================================

----------------------------------------
Primary Key
----------------------------------------
- Unique identifier

----------------------------------------
Foreign Key
----------------------------------------
- Links to dimension


----------------------------------------
Surrogate Key
----------------------------------------
- Artificial key (product_sk)

----------------------------------------
Natural Key
----------------------------------------
- Real-world key (sku)


----------------------------------------
Important Insight
----------------------------------------
Use surrogate keys for:
- Stability
- History tracking



==================================================
10. PRODUCT DIMENSION EXAMPLE
==================================================

CREATE TABLE dim_product (
  product_sk,
  sku,
  product_name,
  brand,
  category,
  is_private_label,
  effective_start_date,
  effective_end_date,
  is_current
);


----------------------------------------
Important Concept (SCD)
----------------------------------------
- Track history of changes

Example:
- Product category changes
→ create new row


----------------------------------------
Why?
----------------------------------------
- Preserve historical accuracy



==================================================
11. MULTIPLE DIMENSIONS
==================================================

Fact table joins multiple dimensions:

- product
- store
- date
- promotion


----------------------------------------
Meaning
----------------------------------------
- Each dimension adds context


----------------------------------------
Benefit
----------------------------------------
- Easy filtering and grouping



==================================================
12. "200 MEANS NOTHING"
==================================================

Example:
Value = 200


----------------------------------------
Without dimensions:
----------------------------------------
- Meaningless


----------------------------------------
With dimensions:
----------------------------------------
- 200 sales in store X
- 200 units of product Y


----------------------------------------
Important Insight
----------------------------------------
Numbers alone are useless without context



==================================================
13. COMMON MISTAKES
==================================================

----------------------------------------
1. Storing description in fact
----------------------------------------
Problem:
- Data duplication

Fix:
- Use dimensions


----------------------------------------
2. No date dimension
----------------------------------------
Problem:
- Cannot analyze time

Fix:
- Always use dim_date


----------------------------------------
3. Grain mismatch
----------------------------------------
Problem:
- Wrong results

Fix:
- Fix grain definition


----------------------------------------
4. Key issues
----------------------------------------
Problem:
- Wrong joins

Fix:
- Use proper keys


----------------------------------------
5. Too many degenerate fields
----------------------------------------
Problem:
- Wide tables

Fix:
- Use dimensions



==================================================
14. FINAL TAKEAWAY
==================================================

Fact Table:
- Stores numbers
- Used for calculations

Dimension Table:
- Stores descriptions
- Used for filtering


----------------------------------------
Golden Rule
----------------------------------------
Facts + Dimensions = Meaningful Data


----------------------------------------
Pipeline
----------------------------------------

Raw Data
   ↓
Fact Table (numbers)
   ↓
Dimension Table (context)
   ↓
Insights


----------------------------------------
Goal
----------------------------------------
Turn numbers → business insights



==================================================
15. QUICK MEMORY SUMMARY
==================================================

Fact:
- Numbers
- Aggregatable

Dimension:
- Description
- Context

Design:
- Start with business question
- Define grain
- Add dimensions
- Add facts

Rule:
- Numbers alone = useless