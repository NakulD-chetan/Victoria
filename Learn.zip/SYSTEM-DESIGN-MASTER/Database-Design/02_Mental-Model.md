# Database Design — Mental Model (Deep Understanding)

> **Permanent Recall:** Think of SQL as a **filing cabinet** — rigid drawers, labeled folders, cross-references. NoSQL as **warehouse bins** — throw anything in, flexible, fast retrieval by label. Indexes are a **book's index** — don't read every page, look up the term. For decision-making: structured + ACID → SQL; flexible + scale → NoSQL; relationships → Graph; time-series → Column-family. Always think access pattern first, schema second.

---

## Mental Model 1: The Filing Cabinet (SQL)

**SQL Database = an organized filing cabinet with strict rules.**

Imagine a company's HR filing cabinet:

```
     ┌─────────────────────────────────────────────────────┐
     │            HR FILING CABINET (SQL DATABASE)          │
     │                                                     │
     │  DRAWER 1: "Employees" (Table)                      │
     │  ┌─────────────────────────────────────────────┐    │
     │  │  Folder #1: Alice | ID: 001 | Dept: Eng     │    │
     │  │  Folder #2: Bob   | ID: 002 | Dept: Sales   │    │
     │  │  Folder #3: Carol | ID: 003 | Dept: Eng     │    │
     │  │  Every folder has SAME slots (columns)       │    │
     │  │  Can't add a folder without filling all slots│    │
     │  └─────────────────────────────────────────────┘    │
     │                                                     │
     │  DRAWER 2: "Departments" (Table)                    │
     │  ┌─────────────────────────────────────────────┐    │
     │  │  Folder: Engineering | Head: VP-Eng          │    │
     │  │  Folder: Sales       | Head: VP-Sales        │    │
     │  │  Linked to Employee folders by "Dept" field  │    │
     │  └─────────────────────────────────────────────┘    │
     │                                                     │
     │  INDEX CARDS (on top of cabinet):                   │
     │  ┌─────────────────────────────────────────────┐    │
     │  │  "Alice" → Drawer 1, Folder #1               │    │
     │  │  "Bob"   → Drawer 1, Folder #2               │    │
     │  │  Sorted alphabetically → find anyone fast!    │    │
     │  └─────────────────────────────────────────────┘    │
     └─────────────────────────────────────────────────────┘
```

| Filing Cabinet | SQL Database |
|----------------|-------------|
| Drawer | Table |
| Folder | Row |
| Slots in folder | Columns |
| All folders have same slots | Fixed schema |
| Cross-reference card ("Dept" → Departments drawer) | Foreign key |
| Index cards on top | Database index |
| Cabinet rules ("every folder MUST have an ID") | Constraints (NOT NULL, UNIQUE, PK) |
| "Take out folder, change name, put back" | UPDATE within transaction |

**Why this analogy works in interviews:** It communicates that SQL is about **structure, relationships, and rules**. The rigidity IS the feature — it prevents mess.

---

## Mental Model 2: The Warehouse Bins (NoSQL)

**NoSQL Database = warehouse with labeled bins — each bin can hold anything.**

```
     ┌──────────────────────────────────────────────────┐
     │         WAREHOUSE (NoSQL DATABASE)                │
     │                                                  │
     │  BIN "user:123"                                  │
     │  ┌──────────────────────────────────────────┐    │
     │  │  {                                       │    │
     │  │    name: "Alice",                        │    │
     │  │    email: "alice@x.com",                 │    │
     │  │    address: {street: "123 Main", city..} │    │
     │  │    orders: [{id: 1, amount: 100}, ...]   │    │
     │  │  }                                       │    │
     │  └──────────────────────────────────────────┘    │
     │                                                  │
     │  BIN "user:456"                                  │
     │  ┌──────────────────────────────────────────┐    │
     │  │  {                                       │    │
     │  │    name: "Bob",                          │    │
     │  │    email: "bob@x.com",                   │    │
     │  │    company: "Acme Inc",  ← Alice doesn't │    │
     │  │    age: 35               ← have these!   │    │
     │  │  }                                       │    │
     │  └──────────────────────────────────────────┘    │
     │                                                  │
     │  Each bin can have DIFFERENT contents.            │
     │  No warehouse manager checks your format.        │
     │  Add new items? Just throw them in.              │
     └──────────────────────────────────────────────────┘
```

| Warehouse | NoSQL Database |
|-----------|---------------|
| Bin with a label | Document with a key |
| Contents of bin (anything) | JSON document (any fields) |
| Different bins have different stuff | No fixed schema |
| "Grab bin #123, take everything" | `db.users.findOne({_id: 123})` |
| No cross-referencing between bins | No JOINs — embed or reference |
| Stack more shelves as needed | Horizontal scaling (add nodes) |

**Key insight:**
- **SQL:** "Tell me the structure of your data, and I'll enforce it."
- **NoSQL:** "Give me your data however you want, and I'll store it fast."

---

## Mental Model 3: The Book Index (Indexing)

For understanding **why indexes matter**, think of a textbook:

```
WITHOUT INDEX (Full Table Scan):
  "Find the section about 'B-Tree' in a 500-page textbook"
  
  Start at page 1. Read. Not here.
  Page 2. Read. Not here.
  ...
  Page 347. Found 'B-Tree'! But might be on more pages...
  Continue to page 500.
  
  You read EVERY page = O(n) = SLOW

WITH INDEX (at the back of the book):
  Open the index:
    "B-Tree ... pages 120, 347, 452"
  
  Jump directly to pages 120, 347, 452.
  Done. Read 3 pages instead of 500.
  
  Index lookup = O(log n) = FAST
```

**Now extend this to databases:**

```
WITHOUT INDEX:
  SELECT * FROM users WHERE email = 'alice@mail.com';
  
  Database reads row 1: email = 'zack@...' → no
  Database reads row 2: email = 'bob@...'  → no
  ...row 10,000,000: done
  
  10 MILLION rows scanned for ONE result.

WITH INDEX on email:
  B-Tree index: 3-4 lookups → found at row 42.
  Read 4 tree nodes instead of 10M rows.
```

### The Library Card Catalog (Composite Index)

```
SINGLE INDEX = card catalog sorted by TITLE
  "Find books by 'Alice in Wonderland'" → quick lookup

COMPOSITE INDEX = card catalog sorted by AUTHOR then TITLE
  "Find books by 'Lewis Carroll'" → quick (uses first sort key)
  "Find 'Alice in Wonderland' by 'Lewis Carroll'" → very quick (uses both)
  "Find all books titled 'Alice in Wonderland'" → SLOW (title is second sort key)
  
  Composite index on (author, title):
    Works for: (author), (author + title)
    Doesn't work for: (title) alone
  
  This is the LEFT-TO-RIGHT rule.
```

---

## Mental Model 4: Understanding Replication

### The Newspaper Printing Press

```
PRIMARY = the ORIGINAL copy of tomorrow's newspaper
REPLICAS = copies printed at different print shops

WRITE PATH (editing the newspaper):
  Editor writes article → ORIGINAL copy (Primary)
  Original sends copies to print shops (Replicas)
  
READ PATH (buying the newspaper):
  You can buy from ANY print shop (Replica)
  All copies are the same (eventually)
  
IF ORIGINAL PRESS BREAKS DOWN:
  Promote one print shop to be the new Original
  Continue printing from there

REPLICATION LAG:
  Editor publishes article at 9:00 AM
  Print Shop A gets the copy at 9:00:01 AM
  Print Shop B gets the copy at 9:00:03 AM
  
  If you buy from Shop B at 9:00:02 AM → you get YESTERDAY's paper (stale!)
  This is "replication lag"
```

```
Primary:
  ┌──────────┐     WAL stream      ┌───────────┐
  │ All      │─────────────────────►│ Replica 1 │  ← read queries
  │ writes   │                      └───────────┘
  │ go here  │     WAL stream      ┌───────────┐
  │          │─────────────────────►│ Replica 2 │  ← read queries
  └──────────┘                      └───────────┘

Benefits:
  1. Read scale: 3 replicas = 3× read throughput
  2. HA: Primary dies → promote replica (auto-failover)
  3. Backup: Replica is a live copy of all data
  
Limitation:
  Writes still go to ONE primary → replication doesn't scale writes
  For write scaling → need SHARDING
```

---

## Mental Model 5: Understanding Sharding

### The Pizza Chain Analogy

```
ONE PIZZA SHOP (single database):
  All orders go to ONE shop.
  Kitchen can handle 100 pizzas/hour max.
  Rush hour: 500 orders → 400 people wait → customers leave.

SHARDING = Opening MULTIPLE shops in different neighborhoods:
  Shard 1: North neighborhood (zip 10001-10250) → Shop 1
  Shard 2: South neighborhood (zip 10251-10500) → Shop 2
  Shard 3: East neighborhood (zip 10501-10750) → Shop 3
  Shard 4: West neighborhood (zip 10751-11000) → Shop 4
  
  Each shop handles its own neighborhood's orders.
  Total capacity: 400 pizzas/hour (4 × 100).
  
THE SHARD KEY IS THE NEIGHBORHOOD (zip code).
  Customer calls → "What's your zip?" → routed to correct shop.
```

```
CROSS-SHARD PROBLEM:
  "How many total orders across ALL shops today?"
  → Must call ALL 4 shops, collect numbers, add up.
  → SLOW and COMPLEX.
  
  "How many orders from zip 10100?"
  → Route to Shop 1 (that's its zip range). ONE call.
  → FAST.
  
  Lesson: Queries on the shard key are fast.
  Queries across shards are slow.
  CHOOSE YOUR SHARD KEY WISELY.
```

**When sharding goes wrong:**

```
BAD SHARD KEY: Shard by first letter of name
  Shard A: Names A-G  → 40% of users (popular letters)
  Shard B: Names H-N  → 25% of users
  Shard C: Names O-Z  → 35% of users
  
  Shard A is OVERLOADED. Shards B, C are underused.
  This is called a "hot shard."

GOOD SHARD KEY: Shard by hash(user_id)
  hash(user_id) % 4 → evenly distributed across 4 shards
  Each shard gets ~25% of users
  No hot shard (unless one user generates enormous traffic)
```

---

## Decision Tree: SQL vs NoSQL (with reasoning)

```
START: What does your data look like?
  │
  ├── "Structured tables with clear relationships (users, orders, products)"
  │     └── Do you need ACID transactions?
  │           ├── YES → ✅ SQL (PostgreSQL, MySQL)
  │           │         "Banking, payments, inventory, e-commerce checkout"
  │           └── NO  → Can you tolerate eventual consistency?
  │                 ├── YES → ✅ Consider NoSQL for scale
  │                 └── NO  → ✅ SQL
  │
  ├── "Simple key → value lookups (sessions, cache, counters)"
  │     └── ✅ Key-Value (Redis, DynamoDB)
  │           "Sub-ms latency, TTL for expiry, O(1) ops"
  │
  ├── "Flexible documents with nested objects (profiles, catalogs)"
  │     └── ✅ Document (MongoDB, Firestore)
  │           "Varying fields, embedded arrays, schema evolves"
  │
  ├── "Massive writes, time-series, IoT sensor data"
  │     └── ✅ Column-Family (Cassandra, HBase)
  │           "Append-only, wide rows, multi-DC"
  │
  ├── "Highly connected data (social graph, recommendations)"
  │     └── ✅ Graph (Neo4j, Neptune)
  │           "Multi-hop traversals, path queries"
  │
  └── "Full-text search, autocomplete"
        └── ✅ Search engine (Elasticsearch, Solr)
              "Inverted index, fuzzy match, ranking"
```

---

## Mental Model for Normalization vs Denormalization

### The Whiteboard Analogy

```
NORMALIZED = Writing information ONCE on the whiteboard

  "Alice's phone number: 555-1234"  (written in one place)
  
  Everyone who needs Alice's number looks at that one spot.
  Alice changes number? Erase and rewrite ONCE. Done.
  
  ✅ One source of truth
  ❌ Everyone walks to the same whiteboard (JOINs needed)

DENORMALIZED = Writing information on MULTIPLE sticky notes

  "Alice: 555-1234" on Bob's desk
  "Alice: 555-1234" on Carol's desk
  "Alice: 555-1234" on Dave's desk
  
  Everyone has the info right at their desk (no walking). FAST reads.
  Alice changes number? Must update EVERY sticky note.
  Miss one? → stale data. Inconsistency.
  
  ✅ Fast reads (data is right there)
  ❌ Hard to update (must change everywhere)
```

### When to Normalize vs Denormalize

```
         Normalize                    Denormalize
    ──────────────────           ──────────────────
    Write-heavy systems          Read-heavy systems
    Data integrity critical      Latency critical
    Storage matters              Speed matters
    Few readers, many writers    Many readers, few writers
    Banking, inventory           Feeds, dashboards, search
```

---

## Mental Model for CAP Theorem

### The Phone Game (During a Storm)

```
Three friends: Alice (Node A), Bob (Node B), Carol (Node C)
They keep a shared count of how many pizzas they've eaten.

NORMAL DAY (no partition):
  Alice eats a pizza → tells Bob and Carol → count is consistent everywhere

STORM (network partition — Alice can't reach Bob):
  Alice eats a pizza → tells Carol ✅ → can't reach Bob ❌

  Now Bob has the OLD count. What do we do?

  CP CHOICE (Consistency):
    "Stop accepting orders until the storm passes."
    Alice: "Sorry, I can't record your pizza until I can sync with Bob."
    ✅ Data is always correct
    ❌ System is DOWN for some users

  AP CHOICE (Availability):
    "Keep going. We'll sync up after the storm."
    Alice records her pizza. Bob keeps his old count.
    After storm → sync → "Oh, I missed one" → update.
    ✅ System always works
    ❌ Data temporarily inconsistent
```

---

## Mental Model for Connection Pooling

### The Taxi Stand

```
WITHOUT POOLING = Calling a brand new taxi for every trip

  Trip 1: Call taxi company → wait 10 min → taxi arrives → ride → taxi leaves
  Trip 2: Call taxi company → wait 10 min → taxi arrives → ride → taxi leaves
  
  That 10 min wait = connection setup overhead (TCP, TLS, auth)

WITH POOLING = Taxi stand at your building with 20 taxis always waiting

  Trip 1: Walk to taxi stand → hop in → ride → taxi returns to stand
  Trip 2: Walk to taxi stand → hop in → ride → taxi returns to stand
  
  No waiting. Taxi was already there.
  20 taxis serve hundreds of trips per day.
```

---

## Mental Model: How a Query Flows End-to-End

```
APPLICATION: db.query("SELECT * FROM users WHERE email = 'alice@x.com'")

Step 1: CONNECTION
  App borrows a connection from the pool
  (no new TCP handshake — connection already open)

Step 2: PARSER
  Database receives SQL string
  Validates syntax: SELECT, FROM, WHERE → correct ✅
  Creates parse tree

Step 3: OPTIMIZER
  "How should I execute this?"
  Checks: Is there an index on 'email'?
  YES → Plan: Index Scan on idx_users_email → fetch row
  NO  → Plan: Sequential Scan (read every row) — SLOW!

Step 4: EXECUTOR
  Follows the plan:
  - Read B-Tree index → find 'alice@x.com' → points to row 42
  - Check Buffer Pool: is page containing row 42 in memory?
    YES → read from memory (sub-ms)
    NO  → read from disk (1-5ms), cache in buffer pool

Step 5: RETURN
  Row 42 data sent back to application
  Connection returned to pool

TOTAL TIME:
  With index + data in buffer pool: <1ms
  With index + disk read: 1-5ms
  Without index (full scan on 10M rows): 500ms-5s
```

---

## Mental Model: Choosing Between Databases (The Restaurant Analogy)

```
SQL (PostgreSQL) = Fine dining restaurant
  Fixed menu (schema). Everything prepared precisely.
  "We guarantee every dish is exactly as described."
  Takes longer. More expensive. But QUALITY and CONSISTENCY guaranteed.
  Best for: Important meals (banking, payments, inventory)

Key-Value (Redis) = Vending machine
  Put in label, get item instantly. No frills.
  "You want item B3? Here it is. Done."
  Fastest possible. Limited selection.
  Best for: Quick snacks (cache, sessions, counters)

Document (MongoDB) = Buffet
  Flexible. Pick what you want. Different plates have different foods.
  "Take whatever combination works for you."
  Variety and flexibility. Less structure.
  Best for: Varied tastes (user profiles, CMS, product catalog)

Column-Family (Cassandra) = Industrial cafeteria
  Massive throughput. Feeds thousands per hour.
  "We serve fast, at scale, across multiple locations."
  Best for: Volume (IoT data, time-series, logs)

Graph (Neo4j) = Social dinner party
  All about connections. Who knows whom. Who sits next to whom.
  "The relationships between guests ARE the event."
  Best for: Connected data (social graph, recommendations)
```

---

## Decision Quick-Reference Table

| You Need | Choose | Specific DB | One-Line Reason |
|----------|--------|-------------|-----------------|
| Transactions + integrity | SQL | PostgreSQL | ACID, mature, extensible |
| Simple caching | Key-Value | Redis | Sub-ms, in-memory, TTL |
| User sessions | Key-Value | Redis | Fast, TTL auto-expiry, distributed |
| Flexible user profiles | Document | MongoDB | Varying fields, nested objects |
| Social graph queries | Graph | Neo4j | Multi-hop traversals are native |
| Time-series / IoT | Column-Family | Cassandra | Massive write throughput, wide rows |
| Full-text search | Search engine | Elasticsearch | Inverted index, relevance scoring |
| Analytics / reporting | Warehouse | BigQuery/Snowflake | Columnar storage, SQL on petabytes |
| Leaderboard | Key-Value | Redis (ZADD) | Sorted set, O(log n) ranking |
| Message queue state | Key-Value | Redis (List) | LPUSH/RPOP, blocking pop |

---

## Quick Memory Card

```
ANALOGY:       SQL = filing cabinet (rigid, organized); NoSQL = warehouse bins (flexible, fast)
INDEX:         Book index — don't scan every page; O(log n) vs O(n)
COMPOSITE:     Like catalog sorted by Author then Title. Works left-to-right only.
REPLICATION:   Newspaper press — primary writes, replicas serve copies
SHARDING:      Pizza chain — split by neighborhood (shard key)
CAP:           During partition: CP (refuse stale) or AP (serve stale)
NORMALIZE:     One source of truth (whiteboard). DENORMALIZE: copies at every desk (fast read).
POOL:          Taxi stand — 20 taxis serve 1000 rides. No wait.
SQL:           Fine dining (precise, guaranteed). NoSQL: Vending/Buffet (fast, flexible).
DECISION:      ACID → SQL. Cache → Redis. Flexible → MongoDB. Graph → Neo4j. Writes → Cassandra.
```

---

**Next:** [[03_Design-Template]]
