import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import './userProfileMenu.css';

/*
 * UserProfileMenu — modern SaaS profile chip + dropdown.
 *
 * Renders a compact card with avatar / name / email and opens a menu with
 * Account, Preferences, Theme toggle, Help, Sign out. Designed to live at
 * the bottom of the file-tree sidebar (ft-bottom) but works anywhere.
 *
 * Props:
 *   - onOpenSettings, onOpenPreferences, onOpenHelp, onToggleTheme — optional
 *   - theme — current theme string ('dark' | 'light') for the menu icon
 *   - compact — if true, hides email row to save vertical space
 */

function initialsFor(name, email) {
  const src = (name || email || '?').trim();
  if (!src) return '?';
  const parts = src.split(/\s+/).filter(Boolean);
  if (parts.length === 1) return src.slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

const IconChevron = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="6 9 12 15 18 9" />
  </svg>
);
const IconSettings = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </svg>
);
const IconSliders = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" />
    <line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" />
    <line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" />
    <line x1="1" y1="14" x2="7" y2="14" /><line x1="9" y1="8" x2="15" y2="8" /><line x1="17" y1="16" x2="23" y2="16" />
  </svg>
);
const IconHelp = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <circle cx="12" cy="12" r="10" /><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" /><line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);
const IconMoon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
);
const IconSun = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41" />
  </svg>
);
const IconLogout = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" />
  </svg>
);

export default function UserProfileMenu({
  onOpenSettings,
  onOpenPreferences,
  onOpenHelp,
  onToggleTheme,
  theme = 'dark',
  compact = false,
  variant = 'sidebar', // 'sidebar' | 'navbar'
}) {
  const { user, profile, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const [avatarError, setAvatarError] = useState(false);
  const triggerRef = useRef(null);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => {
      if (
        menuRef.current && !menuRef.current.contains(e.target)
        && triggerRef.current && !triggerRef.current.contains(e.target)
      ) setOpen(false);
    };
    const onKey = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc, true);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDoc, true);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  if (!user) return null;

  const displayName = profile?.display_name || user.user_metadata?.full_name || (user.email || '').split('@')[0] || 'User';
  const email = profile?.email || user.email || '';
  const avatar = profile?.avatar_url || user.user_metadata?.avatar_url || null;

  const isNavbar = variant === 'navbar';

  return (
    <div className={`upm${open ? ' upm--open' : ''}${compact ? ' upm--compact' : ''}${isNavbar ? ' upm--navbar' : ''}`}>
      <button
        ref={triggerRef}
        type="button"
        className="upm__trigger"
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
        title={`${displayName} — open profile menu`}
      >
        <span className="upm__avatar">
          {avatar && !avatarError
            ? <img src={avatar} alt="" referrerPolicy="no-referrer" onError={() => setAvatarError(true)} />
            : <span className="upm__initials">{initialsFor(displayName, email)}</span>}
        </span>
        {!isNavbar && (
          <span className="upm__identity">
            <span className="upm__name">{displayName}</span>
            {!compact && <span className="upm__email">{email}</span>}
          </span>
        )}
        {!isNavbar && <span className="upm__chev"><IconChevron /></span>}
      </button>

      {open && (
        <div className="upm__menu" ref={menuRef} role="menu">
          <div className="upm__menu-header">
            <span className="upm__avatar upm__avatar--lg">
              {avatar && !avatarError
                ? <img src={avatar} alt="" referrerPolicy="no-referrer" onError={() => setAvatarError(true)} />
                : <span className="upm__initials">{initialsFor(displayName, email)}</span>}
            </span>
            <div className="upm__identity upm__identity--lg">
              <span className="upm__name">{displayName}</span>
              <span className="upm__email">{email}</span>
            </div>
          </div>

          <div className="upm__menu-divider" />

          <button
            type="button"
            className="upm__menu-item"
            role="menuitem"
            onClick={() => { setOpen(false); onOpenSettings?.(); }}
          >
            <IconSettings /><span>Account settings</span>
          </button>
          <button
            type="button"
            className="upm__menu-item"
            role="menuitem"
            onClick={() => { setOpen(false); onOpenPreferences?.(); }}
          >
            <IconSliders /><span>Preferences</span>
          </button>
          <button
            type="button"
            className="upm__menu-item"
            role="menuitem"
            onClick={() => { setOpen(false); onToggleTheme?.(); }}
          >
            {theme === 'dark' ? <IconSun /> : <IconMoon />}
            <span>{theme === 'dark' ? 'Light mode' : 'Dark mode'}</span>
          </button>
          <button
            type="button"
            className="upm__menu-item"
            role="menuitem"
            onClick={() => { setOpen(false); onOpenHelp?.(); }}
          >
            <IconHelp /><span>Help &amp; shortcuts</span>
          </button>

          <div className="upm__menu-divider" />

          <button
            type="button"
            className="upm__menu-item upm__menu-item--danger"
            role="menuitem"
            onClick={async () => { setOpen(false); await signOut(); window.location.reload(); }}
          >
            <IconLogout /><span>Sign out</span>
          </button>
        </div>
      )}
    </div>
  );
}
