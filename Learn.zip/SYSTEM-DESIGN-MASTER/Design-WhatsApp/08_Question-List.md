# Design WhatsApp — Question List

> **Permanent Recall:** Practice variations: add voice/video, add status/stories, group video call, message search, backup. Related systems: Telegram, Signal, Slack, Discord. 15+ questions with difficulty. E=Easy, M=Medium, H=Hard.

---

## Core Variations (MUST-DO)

| # | Question | Difficulty | Key Additions |
|---|----------|------------|---------------|
| 1 | Design WhatsApp (base) | M | 1:1, group, receipts, presence, media |
| 2 | Add voice and video calling | M | WebRTC, signaling, TURN/STUN |
| 3 | Add status / stories (24h) | M | Ephemeral storage, visibility controls |
| 4 | Design group video call | H | SFU/MCU, scaling to 50+ participants |
| 5 | Handle message search | M | Elasticsearch, E2E constraint |
| 6 | Design message backup to cloud | M | Export, sync, restore flow |

---

## Feature Extensions

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 7 | Add message reactions (emoji) | E | Lightweight metadata, sync |
| 8 | Add message editing and deletion | M | Tombstones, sync, conflict |
| 9 | Add voice messages | E | Media upload, playback |
| 10 | Add document sharing | E | Same as media; larger files |
| 11 | Add end-to-end encryption | H | Signal protocol, key management |
| 12 | Add disappearing messages | M | TTL, deletion sync |

---

## Related Systems

| # | Question | Difficulty | Differentiator |
|---|----------|------------|----------------|
| 13 | Design Telegram | M | Channels, bots, cloud sync |
| 14 | Design Signal | H | Privacy-first, E2E mandatory |
| 15 | Design Slack | M | Channels, threads, integrations |
| 16 | Design Discord | M | Voice channels, servers, roles |
| 17 | Design iMessage | M | Apple ecosystem, sync |
| 18 | Design Facebook Messenger | M | Broader platform integration |

---

## Scale & Reliability Variations

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 19 | Scale to 5B users | H | Sharding, multi-region |
| 20 | Handle 1M messages/second burst | H | Queue backpressure, throttling |
| 21 | Design for 99.999% availability | H | Multi-region, failover |
| 22 | Design offline-first mobile app | M | Local queue, sync, conflict |

---

## Technical Deep-Dives

| # | Question | Difficulty | Topic |
|---|----------|------------|-------|
| 23 | How would you implement WebSocket connection management at 1B scale? | H | Connection servers, LB, heartbeat |
| 24 | Design the message queue for group chat fan-out | M | Kafka partitions, ordering |
| 25 | How does WhatsApp achieve end-to-end encryption? | H | Signal protocol overview |
| 26 | Design presence at 2B users | M | Redis, TTL, partitioning |
| 27 | How do you handle message delivery when user is on multiple devices? | M | Fan-out to device connections |
| 28 | Design typing indicators | E | Ephemeral presence; broadcast to conversation |
| 29 | Add message reactions at scale | M | Lightweight metadata, fan-out to group |

---

## Follow-Up Question Bank

When interviewer says "Good, now add X":

| Add X | First Thing to Say |
|-------|--------------------|
| Voice call | "WebRTC for media; we need signaling server and TURN" |
| Stories | "Ephemeral storage, 24h TTL, visibility per contact" |
| Search | "Elasticsearch for non-E2E; E2E needs client-side or encrypted index" |
| Backup | "Export API; store in user's cloud; restore syncs back" |
| Reactions | "Lightweight; same flow as message, type=reaction, references message_id" |

---

## Practice Schedule Suggestion

| Week | Focus | Questions |
|------|-------|-----------|
| 1 | Base + core variations | 1, 2, 3, 5, 6 |
| 2 | Feature extensions | 7, 8, 9, 10, 11, 12 |
| 3 | Related systems | 13, 14, 15, 16 |
| 4 | Scale + deep-dives | 19, 20, 23, 24, 25 |

---

## Quick Answer Cheat Sheet

| Question | One-Line Answer |
|----------|-----------------|
| Voice/video call | WebRTC + signaling server + TURN for NAT |
| Status/stories | Ephemeral store, 24h TTL, visibility list |
| Group video | SFU (selective forwarding) or MCU |
| Message search | Elasticsearch; E2E = client-side or encrypted index |
| Backup | Export API, store in user's cloud; restore = sync |
| Telegram | Channels, MTProto, cloud-first |
| Signal | E2E mandatory, minimal metadata |
| Slack | Channels, search, integrations, threads |
| Discord | Guilds, voice channels, low-latency |

> **FAANG Tip:** For "Design X like WhatsApp" — always start with base chat (WebSocket, mailbox, receipts, presence) then add the differentiator.

---

## Difficulty Guide

| Difficulty | What to Expect |
|-------------|-----------------|
| **E** | Single feature add; straightforward extension |
| **M** | New subsystem; integration with existing design |
| **H** | Scale, crypto, or entirely new paradigm |

---

## 30-SECOND REVISION BOX

```
CORE: Base WhatsApp, voice/video, status, group call, search, backup
EXTENSIONS: Reactions, edit/delete, voice msg, E2E, disappearing
RELATED: Telegram, Signal, Slack, Discord, iMessage
SCALE: 5B users, 1M msg/s burst, 99.999%
DEEP: WebSocket at 1B, queue design, E2E, presence
```

---

**Prev: [[07_Tricks-and-Recognition]]** | **Topic: [[01_Concept]]**
