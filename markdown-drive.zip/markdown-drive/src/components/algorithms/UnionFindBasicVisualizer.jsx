import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function layoutLinear(parent) {
  const n = parent.length;
  const nodes = Array.from({ length: n }, (_, i) => ({
    id: String(i),
    label: String(i),
    nx: (i + 0.5) / n * 0.82 + 0.09,
    ny: 0.55,
  }));
  const edges = [];
  for (let i = 0; i < n; i++) if (parent[i] !== i) edges.push([String(i), String(parent[i])]);
  return { nodes, edges };
}

function generateSteps(n, pairs) {
  const parent = Array.from({ length: n }, (_, i) => i);
  const steps = [];
  steps.push({ type: 'init', parent: [...parent], highlight: [] });
  pairs.forEach(([u, v]) => {
    steps.push({ type: 'find-start', parent: [...parent], u, v, highlight: [u, v] });
    let ru = u;
    while (parent[ru] !== ru) {
      steps.push({ type: 'walk', parent: [...parent], cur: ru, next: parent[ru], highlight: [ru] });
      ru = parent[ru];
    }
    let rv = v;
    while (parent[rv] !== rv) {
      steps.push({ type: 'walk', parent: [...parent], cur: rv, next: parent[rv], highlight: [rv] });
      rv = parent[rv];
    }
    steps.push({ type: 'roots', parent: [...parent], ru, rv, highlight: [ru, rv] });
    if (ru !== rv) {
      parent[rv] = ru;
      steps.push({ type: 'union', parent: [...parent], ru, rv, highlight: [ru, rv] });
    } else {
      steps.push({ type: 'same', parent: [...parent], ru, highlight: [ru] });
    }
  });
  steps.push({ type: 'done', parent: [...parent], highlight: [] });
  return steps;
}

export default function UnionFindBasicVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const n = 8;
    const pairs = [
      [0, 2],
      [4, 6],
      [2, 4],
      [1, 5],
    ];
    const steps = generateSteps(n, pairs);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Union by attaching second root to first' });
    const { nodes, edges } = layoutLinear(steps[0].parent);
    canvasRef.current?.setState({ nodes, edges, colors: {}, labels: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const { nodes, edges } = layoutLinear(step.parent);
    const colors = {};
    (step.highlight || []).forEach((id) => {
      colors[String(id)] = 'compare';
    });
    if (step.type === 'union') {
      colors[String(step.ru)] = 'active';
      colors[String(step.rv)] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Union roots ${step.ru} ← ${step.rv}` });
    } else if (step.type === 'same') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: 'Already connected' });
    } else if (step.type === 'walk') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Climb ${step.cur} → parent ${step.next}` });
    } else if (step.type === 'roots') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Roots ${step.ru}, ${step.rv}` });
    } else if (step.type === 'done') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Union–Find (basic) complete' });
    } else {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    }
    canvasRef.current?.setState({ nodes, edges, colors, labels: {} });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
