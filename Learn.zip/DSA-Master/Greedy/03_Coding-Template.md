# Greedy — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.**

---

## Template 1: Interval Scheduling (Sort by End Time)

**Use when:** Maximum non-overlapping intervals, activity selection.

### Python
```python
def max_intervals(intervals):
    if not intervals:
        return 0
    intervals.sort(key=lambda x: x[1])  # Sort by end time
    count = 1
    end = intervals[0][1]
    for i in range(1, len(intervals)):
        if intervals[i][0] >= end:  # No overlap
            count += 1
            end = intervals[i][1]
    return count
```

### C++
```cpp
int maxIntervals(vector<vector<int>>& intervals) {
    if (intervals.empty()) return 0;
    sort(intervals.begin(), intervals.end(),
         [](const auto& a, const auto& b) { return a[1] < b[1]; });
    int count = 1, end = intervals[0][1];
    for (int i = 1; i < intervals.size(); i++) {
        if (intervals[i][0] >= end) {
            count++;
            end = intervals[i][1];
        }
    }
    return count;
}
```

### Rust
```rust
fn max_intervals(intervals: &mut [[i32; 2]]) -> i32 {
    if intervals.is_empty() { return 0; }
    intervals.sort_by_key(|x| x[1]);
    let mut count = 1;
    let mut end = intervals[0][1];
    for i in 1..intervals.len() {
        if intervals[i][0] >= end {
            count += 1;
            end = intervals[i][1];
        }
    }
    count
}
```
**Rust note:** `sort_by_key(|x| x[1])` — sort by end time. Tuple/array comparison for intervals.

---

## Template 2: Activity Selection (Same as Above, Return Indices)

### Python
```python
def activity_selection(intervals):
    if not intervals:
        return []
    indexed = [(intervals[i][1], intervals[i][0], i) for i in range(len(intervals))]
    indexed.sort(key=lambda x: x[0])  # Sort by end
    result = [indexed[0][2]]
    end = indexed[0][0]
    for i in range(1, len(indexed)):
        if indexed[i][1] >= end:
            result.append(indexed[i][2])
            end = indexed[i][0]
    return result
```

### C++
```cpp
vector<int> activitySelection(vector<vector<int>>& intervals) {
    vector<int> result;
    if (intervals.empty()) return result;
    vector<tuple<int,int,int>> indexed;
    for (int i = 0; i < intervals.size(); i++)
        indexed.push_back({intervals[i][1], intervals[i][0], i});
    sort(indexed.begin(), indexed.end());
    result.push_back(get<2>(indexed[0]));
    int end = get<0>(indexed[0]);
    for (int i = 1; i < indexed.size(); i++) {
        if (get<1>(indexed[i]) >= end) {
            result.push_back(get<2>(indexed[i]));
            end = get<0>(indexed[i]);
        }
    }
    return result;
}
```

### Rust
```rust
fn activity_selection(intervals: &[[i32; 2]]) -> Vec<usize> {
    if intervals.is_empty() { return vec![]; }
    let mut indexed: Vec<_> = intervals.iter().enumerate()
        .map(|(i, iv)| (iv[1], iv[0], i)).collect();
    indexed.sort_by_key(|x| x.0);
    let mut result = vec![indexed[0].2];
    let mut end = indexed[0].0;
    for i in 1..indexed.len() {
        if indexed[i].1 >= end {
            result.push(indexed[i].2);
            end = indexed[i].0;
        }
    }
    result
}
```
**Rust note:** `(end, start, idx)` tuple; `sort_by_key` for greedy ordering.

---

## Template 3: Jump Game (Reachability)

**Use when:** Can you reach the last index? (Jump Game I)

### Python
```python
def can_jump(nums):
    if not nums:
        return False
    max_reach = 0
    for i in range(len(nums)):
        if i > max_reach:
            return False
        max_reach = max(max_reach, i + nums[i])
        if max_reach >= len(nums) - 1:
            return True
    return max_reach >= len(nums) - 1
```

### C++
```cpp
bool canJump(vector<int>& nums) {
    if (nums.empty()) return false;
    int maxReach = 0;
    for (int i = 0; i < nums.size(); i++) {
        if (i > maxReach) return false;
        maxReach = max(maxReach, i + nums[i]);
        if (maxReach >= nums.size() - 1) return true;
    }
    return maxReach >= nums.size() - 1;
}
```

### Rust
```rust
fn can_jump(nums: &[i32]) -> bool {
    if nums.is_empty() { return false; }
    let mut max_reach = 0i32;
    for (i, &jump) in nums.iter().enumerate() {
        if i as i32 > max_reach { return false; }
        max_reach = max_reach.max(i as i32 + jump);
        if max_reach >= nums.len() as i32 - 1 { return true; }
    }
    max_reach >= nums.len() as i32 - 1
}
```
**Rust note:** Iterator chain; `i as i32` for reach comparison.

---

## Template 4: Jump Game II (Minimum Jumps)

### Python
```python
def min_jumps(nums):
    if len(nums) <= 1:
        return 0
    jumps = 0
    cur_end = 0
    max_reach = 0
    for i in range(len(nums) - 1):
        max_reach = max(max_reach, i + nums[i])
        if i == cur_end:
            jumps += 1
            cur_end = max_reach
            if cur_end >= len(nums) - 1:
                break
    return jumps
```

### C++
```cpp
int minJumps(vector<int>& nums) {
    if (nums.size() <= 1) return 0;
    int jumps = 0, curEnd = 0, maxReach = 0;
    for (int i = 0; i < nums.size() - 1; i++) {
        maxReach = max(maxReach, i + nums[i]);
        if (i == curEnd) {
            jumps++;
            curEnd = maxReach;
            if (curEnd >= nums.size() - 1) break;
        }
    }
    return jumps;
}
```

### Rust
```rust
fn min_jumps(nums: &[i32]) -> i32 {
    if nums.len() <= 1 { return 0; }
    let mut jumps = 0;
    let mut cur_end = 0;
    let mut max_reach = 0;
    for i in 0..nums.len() - 1 {
        max_reach = max_reach.max(i as i32 + nums[i]);
        if i as i32 == cur_end {
            jumps += 1;
            cur_end = max_reach;
            if cur_end >= nums.len() as i32 - 1 { break; }
        }
    }
    jumps
}
```

---

## Template 5: Gas Station (Circular Greedy)

### Python
```python
def gas_station(gas, cost):
    if sum(gas) < sum(cost):
        return -1
    total = 0
    start = 0
    for i in range(len(gas)):
        total += gas[i] - cost[i]
        if total < 0:
            start = i + 1
            total = 0
    return start
```

### C++
```cpp
int gasStation(vector<int>& gas, vector<int>& cost) {
    if (accumulate(gas.begin(), gas.end(), 0) <
        accumulate(cost.begin(), cost.end(), 0))
        return -1;
    int total = 0, start = 0;
    for (int i = 0; i < gas.size(); i++) {
        total += gas[i] - cost[i];
        if (total < 0) {
            start = i + 1;
            total = 0;
        }
    }
    return start;
}
```

### Rust
```rust
fn gas_station(gas: &[i32], cost: &[i32]) -> i32 {
    if gas.iter().sum::<i32>() < cost.iter().sum::<i32>() { return -1; }
    let mut total = 0i32;
    let mut start = 0;
    for i in 0..gas.len() {
        total += gas[i] - cost[i];
        if total < 0 {
            start = i + 1;
            total = 0;
        }
    }
    start as i32
}
```
**Rust note:** `iter().sum()` for array sums. Iterator chains for greedy processing.

---

## Template 6: Task Assignment (Sort-Based)

**Use when:** Two arrays, pair smallest with smallest (or similar).

### Python
```python
def task_assignment(A, B):
    A.sort()
    B.sort()
    return sum(abs(a - b) for a, b in zip(A, B))
```

### C++
```cpp
int taskAssignment(vector<int>& A, vector<int>& B) {
    sort(A.begin(), A.end());
    sort(B.begin(), B.end());
    int sum = 0;
    for (int i = 0; i < A.size(); i++)
        sum += abs(A[i] - B[i]);
    return sum;
}
```

### Rust
```rust
fn task_assignment(a: &mut [i32], b: &mut [i32]) -> i32 {
    a.sort();
    b.sort();
    a.iter().zip(b.iter()).map(|(x, y)| (x - y).abs()).sum()
}
```
**Rust note:** `zip` + `map` + `sum` — iterator chain for greedy pairing.

---

## Template 7: Fractional Knapsack

### Python
```python
def fractional_knapsack(weights, values, capacity):
    items = [(v/w, w, v) for w, v in zip(weights, values)]
    items.sort(key=lambda x: x[0], reverse=True)
    total_value = 0.0
    for v_per_w, w, v in items:
        if capacity <= 0:
            break
        take = min(w, capacity)
        total_value += take * v_per_w
        capacity -= take
    return total_value
```

### C++
```cpp
double fractionalKnapsack(vector<int>& weights, vector<int>& values, int capacity) {
    vector<tuple<double,int,int>> items;
    for (int i = 0; i < weights.size(); i++)
        items.push_back({(double)values[i]/weights[i], weights[i], values[i]});
    sort(items.rbegin(), items.rend());
    double totalValue = 0;
    for (auto& [vPerW, w, v] : items) {
        if (capacity <= 0) break;
        int take = min(w, capacity);
        totalValue += take * vPerW;
        capacity -= take;
    }
    return totalValue;
}
```

### Rust
```rust
fn fractional_knapsack(weights: &[i32], values: &[i32], capacity: i32) -> f64 {
    let mut items: Vec<_> = weights.iter().zip(values.iter())
        .map(|(&w, &v)| (v as f64 / w as f64, w, v)).collect();
    items.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap());
    let mut cap = capacity;
    let mut total = 0.0;
    for &(v_per_w, w, v) in &items {
        if cap <= 0 { break; }
        let take = w.min(cap);
        total += take as f64 * v_per_w;
        cap -= take;
    }
    total
}
```
**Rust note:** `sort_by` with closure; `partial_cmp` for f64.

---

## Template 8: Huffman Encoding Framework

### Python
```python
import heapq

def huffman_tree(freq):
    heap = [[f, [c, ""]] for c, f in freq.items()]
    heapq.heapify(heap)
    while len(heap) > 1:
        lo = heapq.heappop(heap)
        hi = heapq.heappop(heap)
        for pair in lo[1:]:
            pair[1] = '0' + pair[1]
        for pair in hi[1:]:
            pair[1] = '1' + pair[1]
        heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
    return sorted(heapq.heappop(heap)[1:], key=lambda p: (len(p[-1]), p))
```

### C++
```cpp
#include <queue>
#include <vector>

struct Node {
    int freq;
    char ch;
    Node* left, *right;
    Node(int f, char c = '\0') : freq(f), ch(c), left(nullptr), right(nullptr) {}
};

struct Compare {
    bool operator()(Node* a, Node* b) { return a->freq > b->freq; }
};

Node* huffmanTree(vector<pair<char,int>>& freq) {
    priority_queue<Node*, vector<Node*>, Compare> pq;
    for (auto& [c, f] : freq) pq.push(new Node(f, c));
    while (pq.size() > 1) {
        Node* lo = pq.top(); pq.pop();
        Node* hi = pq.top(); pq.pop();
        Node* parent = new Node(lo->freq + hi->freq);
        parent->left = lo; parent->right = hi;
        pq.push(parent);
    }
    return pq.top();
}
```

### Rust
```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

// Huffman: min-heap by freq; pop two smallest, merge, push parent
// Custom Ord or Reverse((freq, node)) for min-heap
let mut pq: BinaryHeap<Reverse<(i32, char)>> = BinaryHeap::new();
for &(c, f) in freq { pq.push(Reverse((f, c))); }
while pq.len() > 1 {
    let Reverse((f1, _)) = pq.pop().unwrap();
    let Reverse((f2, _)) = pq.pop().unwrap();
    pq.push(Reverse((f1 + f2, '\0')));
}
```
**Rust note:** `Reverse` for min-heap; custom `Ord` for structs. Full tree needs left/right pointers.

---

## Template 9: Merge Overlapping Intervals

### Python
```python
def merge_intervals(intervals):
    if not intervals:
        return []
    intervals.sort(key=lambda x: x[0])
    result = [intervals[0]]
    for i in range(1, len(intervals)):
        if intervals[i][0] <= result[-1][1]:
            result[-1][1] = max(result[-1][1], intervals[i][1])
        else:
            result.append(intervals[i])
    return result
```

### C++
```cpp
vector<vector<int>> mergeIntervals(vector<vector<int>>& intervals) {
    if (intervals.empty()) return {};
    sort(intervals.begin(), intervals.end());
    vector<vector<int>> result = {intervals[0]};
    for (int i = 1; i < intervals.size(); i++) {
        if (intervals[i][0] <= result.back()[1])
            result.back()[1] = max(result.back()[1], intervals[i][1]);
        else
            result.push_back(intervals[i]);
    }
    return result;
}
```

### Rust
```rust
fn merge_intervals(intervals: &mut [[i32; 2]]) -> Vec<Vec<i32>> {
    if intervals.is_empty() { return vec![]; }
    intervals.sort_by_key(|x| x[0]);
    let mut result = vec![intervals[0].to_vec()];
    for i in 1..intervals.len() {
        let last = result.last_mut().unwrap();
        if intervals[i][0] <= last[1] {
            last[1] = last[1].max(intervals[i][1]);
        } else {
            result.push(intervals[i].to_vec());
        }
    }
    result
}
```
**Rust note:** `sort_by_key(|x| x[0])`; `last_mut()` for in-place merge.

---

## FINAL MEMORY COMPRESSION BLOCK

```
INTERVAL: sort by end, pick if start >= last_end
JUMP I: max_reach, if i > max_reach return false
JUMP II: cur_end, max_reach, jump when i == cur_end
GAS: total += gas-cost, if < 0 start=i+1, total=0
FRACTIONAL: sort by value/weight desc, take greedily
MERGE: sort by start, merge if overlap
```

---

## 30-SECOND REVISION BOX

| Pattern | Key Idea |
|---------|----------|
| Interval scheduling | Sort by end; pick if start >= last_end |
| Jump I | max_reach; fail if i > max_reach |
| Jump II | cur_end, max_reach; jump when i == cur_end |
| Gas station | total += gas-cost; reset start when total < 0 |
| Task assignment | Sort both; zip and sum abs diff |
| Fractional knapsack | Sort by value/weight desc; take greedily |
| Merge intervals | Sort by start; merge if overlap |

---

## Language Comparison

| Construct | Python | C++ | Rust |
|-----------|--------|-----|------|
| Sort by key | `sort(key=lambda x: x[1])` | `sort(..., [](a,b){...})` | `sort_by_key(\|x\| x[1])` |
| Sort custom | `sort(key=...)` | `sort(begin, end, cmp)` | `sort_by(\|a,b\| ...)` |
| Tuple comparison | Built-in | `tuple` / `pair` | `Ord` for tuples |
| Iterator chain | List comprehension | Loop | `iter().zip().map().sum()` |
