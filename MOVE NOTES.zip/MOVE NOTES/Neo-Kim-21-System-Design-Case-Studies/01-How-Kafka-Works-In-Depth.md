# How Kafka Works - In Depth (Easy Language)

> Companion to: [01-How-Kafka-Works.md](01-How-Kafka-Works.md)

---

## What Problem Does Kafka Solve?

### The "Too Many Wires" Problem

Imagine you have 5 services in your company: Orders, Payments, Notifications, Analytics, and Inventory.

**Without Kafka:**

```
Orders ──────────→ Payments
Orders ──────────→ Notifications
Orders ──────────→ Analytics
Orders ──────────→ Inventory
Payments ────────→ Notifications
Payments ────────→ Analytics
Inventory ───────→ Analytics
... (N×N connections = spaghetti!)
```

```

```

Every service talks directly to every other service. If you have 10 services, you could have up to **90 direct connections**. Adding one new service means connecting it to all 9 others. This is a nightmare to maintain.

**With Kafka:**

```
Orders ──────→ [KAFKA] ──────→ Payments
Payments ────→ [KAFKA] ──────→ Notifications
Inventory ───→ [KAFKA] ──────→ Analytics
                               Inventory
```

Every service just talks to Kafka. Kafka becomes the **central post office**. New service? Just connect it to Kafka. Done.

---

## The Append-Only Log - Kafka's Secret Weapon

### Why Is This Simple Idea So Powerful?

Think of a **diary**. You never go back and erase or change old entries. You only write new entries at the end. That's exactly what Kafka does.

```
Entry 0: "User signed up"
Entry 1: "User placed order"
Entry 2: "Payment received"
Entry 3: "Order shipped"
         ↓
     (new entries only go here, at the bottom)
```

**Why is this fast?**

Imagine a book. If you always write on the last page, you never need to flip through pages to find where to write. Your pen just stays at the bottom. Compare this to a database where you might need to find a specific row, update it, move things around, etc.

On a hard disk:

- **Random writes** = disk head jumps everywhere (slow, like flipping through a book randomly)
- **Sequential writes** = disk head moves in a straight line (fast, like writing on the next line)

Kafka ONLY does sequential writes. That's why it's incredibly fast even on cheap hardware.

### The Offset - Your Bookmark

Every message in Kafka gets a number called an **offset**. Think of it as a page number in your diary.

```
Offset 0: "User signed up"
Offset 1: "User placed order"  ← Consumer A is here (reading this)
Offset 2: "Payment received"
Offset 3: "Order shipped"      ← Consumer B is here (reading this)
```

Each consumer remembers "I read up to offset X." Next time, they continue from offset X+1. This is how Kafka allows **replay** -- if something goes wrong, a consumer can go back to offset 0 and re-read everything.

---

## Topics & Partitions - Explained Like File Folders

### Topics = Labeled Folders

Think of Kafka as a filing cabinet. Each **topic** is a labeled folder:

```
Filing Cabinet (Kafka Cluster):
  📁 "orders"        ← all order-related messages
  📁 "payments"      ← all payment-related messages
  📁 "notifications" ← all notification messages
  📁 "user-events"   ← all user activity
```

Producers put messages into a specific folder. Consumers read from the folders they care about.

### Partitions = Dividing Work

Now imagine the "orders" folder gets TOO many documents. One person can't file them all fast enough. Solution: split the folder into sub-folders:

```
📁 "orders" topic:
   📂 Partition 0: orders from customers A-H
   📂 Partition 1: orders from customers I-P
   📂 Partition 2: orders from customers Q-Z
```

Each partition can live on a different machine (broker). Now 3 machines handle the work that was too much for 1. This is **horizontal scaling**.

**Key rule**: Messages WITHIN a partition are ordered (you'll read them in sequence). But across partitions, there's no guarantee. If you need global order, use 1 partition (slower) or use a message key to ensure related messages go to the same partition.

### How Does Kafka Decide Which Partition?

```
if message has a KEY:
    partition = hash(key) % number_of_partitions
    (same key ALWAYS goes to same partition → ordered!)

if message has NO KEY:
    partition = round-robin (spread evenly)
```

**Real example**: If you use `user_id` as the key, all messages for User #42 go to the same partition. So you'll always see User #42's events in order.

---

## Brokers - The Workers

A **broker** is simply one Kafka server. A Kafka cluster is a group of brokers working together.

```
Kafka Cluster:
  ┌──────────┐  ┌──────────┐  ┌──────────┐
  │ Broker 1 │  │ Broker 2 │  │ Broker 3 │
  │          │  │          │  │          │
  │ orders-0 │  │ orders-1 │  │ orders-2 │
  │ pay-0    │  │ pay-1    │  │ pay-2    │
  └──────────┘  └──────────┘  └──────────┘
```

Each broker holds some partitions. If a broker dies, the others keep working. That's fault tolerance.

**Analogy**: Think of a warehouse with 3 workers. If one worker calls in sick, the other 2 can still handle shipments because they have copies of the inventory lists.

---

## Replication - The Insurance Policy

### Why Do We Need Copies?

If Broker 1 dies and it was the ONLY place with `orders-0` data, that data is gone forever. Solution: make copies.

### How Replication Works

Every partition has 3 copies (replicas) on different brokers:

```
orders-0 partition:
  Broker 1: LEADER   (handles ALL reads and writes)
  Broker 2: FOLLOWER (copies data from leader, standby)
  Broker 3: FOLLOWER (copies data from leader, standby)
```

**All writes go to the LEADER.** Followers copy the data from the leader automatically.

**What happens when the leader dies?**

```
Before:  Broker 1 (LEADER) -- Broker 2 (follower) -- Broker 3 (follower)
              ❌ (dies!)
              
After:   Broker 2 (NEW LEADER) -- Broker 3 (follower)
         (automatically promoted)
```

A follower gets promoted to leader. Producers and consumers are redirected to the new leader. No data loss, no downtime.

**In-Sync Replicas (ISR)**: Only followers who are "caught up" with the leader can become the new leader. If a follower is 1000 messages behind, it's NOT in sync and can't be promoted (you'd lose those 1000 messages).

---

## Consumer Groups - The Team of Readers

### Single Consumer vs Consumer Group

**Single Consumer**: One person reads ALL messages from ALL partitions. If messages come in faster than this one person can process, you have a backlog problem.

**Consumer Group**: A team of consumers that divide the work.

```
Topic "orders" has 3 partitions:

Consumer Group "billing-team":
  Consumer A reads ← Partition 0
  Consumer B reads ← Partition 1
  Consumer C reads ← Partition 2

Each consumer handles 1/3 of the load!
```

**Rules:**

1. Each partition is assigned to exactly ONE consumer in a group
2. One consumer can handle multiple partitions
3. You can't have MORE consumers than partitions (extras sit idle)

```
3 partitions, 2 consumers:
  Consumer A reads ← Partition 0, Partition 1  (handles 2)
  Consumer B reads ← Partition 2               (handles 1)

3 partitions, 5 consumers:
  Consumer A reads ← Partition 0
  Consumer B reads ← Partition 1
  Consumer C reads ← Partition 2
  Consumer D ← IDLE (nothing to read!)
  Consumer E ← IDLE (nothing to read!)
```

### Multiple Consumer Groups = Fan-Out

Different teams can read the SAME data independently:

```
Topic "orders":
  ┌─────────────────────┐
  │  Consumer Group:     │  Reads orders for billing
  │  "billing-team"      │  (at offset 42)
  └─────────────────────┘
  
  ┌─────────────────────┐
  │  Consumer Group:     │  Reads same orders for analytics
  │  "analytics-team"    │  (at offset 38 -- reading at its own pace)
  └─────────────────────┘
  
  ┌─────────────────────┐
  │  Consumer Group:     │  Reads same orders for notifications
  │  "notification-team" │  (at offset 45 -- ahead!)
  └─────────────────────┘
```

Each group has its own bookmark (offset). They don't interfere with each other. The data is NOT duplicated -- each group just has a different reading position.

---

## KRaft - Kafka's Brain (Replacing ZooKeeper)

### What Is the Controller?

Someone needs to keep track of:

- Which brokers are alive?
- Which broker leads which partition?
- What happens when a broker dies?

This is the **controller's** job. It's the "manager" of the cluster.

### Old Way: ZooKeeper (Removed)

Kafka used to rely on a separate system called ZooKeeper for this. Problem: you had to install, configure, and monitor TWO systems (Kafka + ZooKeeper). If ZooKeeper went down, Kafka couldn't function.

### New Way: KRaft (Kafka Raft)

Now Kafka does this itself using the **Raft consensus algorithm**. Some brokers are designated as controllers. They elect a leader among themselves and store cluster metadata in a special internal topic called `__cluster_metadata`.

```
Controller Quorum (3 controllers):
  Controller 1: ACTIVE LEADER  (makes decisions)
  Controller 2: FOLLOWER       (ready to take over)
  Controller 3: FOLLOWER       (ready to take over)
  
  All brokers subscribe to __cluster_metadata topic
  to learn about cluster state changes
```

**Raft consensus in simple terms**: The controllers vote to elect a leader. The leader makes all decisions. If the leader dies, the others vote again. A majority must agree (2 out of 3) for any decision to be valid. This prevents "split brain" (two leaders making conflicting decisions).

---

## Tiered Storage - Old Data Goes to S3

### The Cost Problem

Kafka stores messages on broker disks. If you keep data for 30 days and produce 1 TB/day, each broker needs 10 TB of SSD storage. SSDs are expensive.

### The Solution

```
Hot data (recent, frequently read):
  → Stays on broker SSDs (fast access)

Cold data (old, rarely read):
  → Moved to S3 (10x cheaper, slower access)
```

Brokers stay lean and fast. Old data is still accessible but from cheaper storage. If a consumer wants to replay data from 2 weeks ago, it reads from S3 -- slower, but it works.

---

## Kafka Streams - Processing Data on the Fly

### What Is Stream Processing?

Instead of storing data first and processing it later (batch processing), you process data **as it arrives** (stream processing).

**Batch**: "At midnight, count all orders from today" (delay of hours)
**Stream**: "Count each order as it comes in, update total in real-time" (instant)

### How Kafka Streams Works

```
Input Topic: "raw-orders"
  → [Kafka Streams App]
      - Filter: only orders > $100
      - Transform: extract {user_id, amount, category}
      - Aggregate: running total per category
  → Output Topic: "high-value-order-stats"
```

It's a Java library (not a separate server). Your app reads from one topic, does computation, writes results to another topic. Exactly-once processing is guaranteed when everything stays within Kafka.

---

## Kafka Connect - Plugging In External Systems

### The Integration Problem

Your database has data Kafka needs. Your data warehouse needs data from Kafka. Writing custom code for every integration is tedious.

### Kafka Connect to the Rescue

```
Source Connectors (INTO Kafka):
  MongoDB  ──[Connector]──→ Kafka Topic "users"
  MySQL    ──[Connector]──→ Kafka Topic "products"
  S3 files ──[Connector]──→ Kafka Topic "logs"

Sink Connectors (OUT of Kafka):
  Kafka Topic "analytics" ──[Connector]──→ Snowflake
  Kafka Topic "logs"      ──[Connector]──→ Elasticsearch
  Kafka Topic "events"    ──[Connector]──→ HDFS
```

Pre-built connectors exist for hundreds of systems. You just configure them -- no coding needed.

---

## Schema Registry - Type Safety for Messages

### The Problem

Kafka messages are just raw bytes. Producer sends a message with fields `{name, age, email}`. Then one day, someone changes it to `{name, birthdate, contact}`. Consumers expecting the old format break.

### The Solution

```
1. Producer registers schema:
   "User = {name: string, age: int, email: string}"
   → Schema Registry stores it as version 1

2. Consumer downloads the schema:
   "I need to read User messages, let me check the schema"
   → Gets version 1, knows exactly what fields to expect

3. Producer wants to change schema:
   "User = {name: string, age: int, email: string, phone: string}"
   → Schema Registry checks: is this backward compatible?
   → Yes (new field is optional) → Stored as version 2
   → Old consumers still work with version 1 format
```

Common formats: **Avro** (compact binary, most popular), **Protobuf** (Google's format), **JSON Schema**.

---

## Complete Message Flow - Start to Finish

```
1. Producer creates message: {key: "user-42", value: "order placed"}

2. Kafka decides partition: hash("user-42") % 3 = partition 1

3. Message sent to Broker 2 (leader of partition 1)

4. Broker 2 writes to its local log at offset 156

5. Followers on Broker 1 and Broker 3 copy the message

6. Once 2 out of 3 replicas have it (configurable), Broker 2 ACKs the producer

7. Consumer in "billing-team" group is assigned partition 1
   → Reads message at offset 156
   → Processes it (generates invoice)
   → Commits offset 156 ("I've processed this")

8. Consumer in "analytics-team" group also reads partition 1
   → Reads the SAME message at offset 156
   → Processes it differently (updates dashboard)
   → Commits offset 156
```

---

## When Should You Use Kafka vs Alternatives?


| Use Case                                   | Best Choice              | Why                                           |
| ------------------------------------------ | ------------------------ | --------------------------------------------- |
| High-throughput event streaming            | **Kafka**                | Designed for massive throughput, replay       |
| Simple task queue (process once, delete)   | **RabbitMQ**             | Built-in job queue semantics, simpler         |
| Real-time analytics pipeline               | **Kafka**                | Stream processing, retention, replay          |
| Microservice communication (request-reply) | **RabbitMQ** or **gRPC** | Kafka is overkill for simple request-response |
| Log aggregation at scale                   | **Kafka**                | Append-only log, tiered storage, retention    |
| Cloud-native, managed streaming            | **Amazon Kinesis**       | Serverless, less operational overhead         |


---

## Common Misconceptions Cleared Up


| Misconception                        | Reality                                                                                                                                          |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| "Kafka is a message queue"           | Kafka is a **distributed log**. Unlike traditional queues, messages aren't deleted after consumption. Multiple consumers can read the same data. |
| "Messages are deleted after reading" | Messages stay for the configured retention period (e.g., 7 days), regardless of how many consumers read them                                     |
| "Kafka guarantees global ordering"   | Kafka only guarantees order **within a partition**, not across partitions                                                                        |
| "More consumers = more speed always" | You can only have as many consumers (in a group) as partitions. More consumers than partitions = wasted resources                                |
| "Kafka replaces your database"       | Kafka is for streaming/events. It doesn't support queries, joins, or indexes. Use it alongside a database, not instead of one                    |


---

## Real-World Kafka Usage Examples


| Company      | How They Use Kafka                                               |
| ------------ | ---------------------------------------------------------------- |
| **LinkedIn** | Created Kafka. Uses it for activity tracking, metrics, news feed |
| **Netflix**  | 700 billion events/day for real-time recommendations             |
| **Uber**     | Trip events, driver locations, surge pricing calculations        |
| **Spotify**  | User activity tracking, playlist updates, ad delivery            |
| **Airbnb**   | Search indexing, availability updates, pricing changes           |


---

## Revision Flashcards

**Q: What data structure is Kafka built on?**
A: Append-only log -- sequential writes only, each entry has a unique offset number.

**Q: What's the difference between a topic and a partition?**
A: A topic is a category (like "orders"). A partition is a shard of that topic for parallel processing. A topic can have many partitions spread across brokers.

**Q: How does Kafka survive a broker dying?**
A: Every partition has 3 replicas on different brokers. If the leader dies, an in-sync follower is automatically promoted to leader.

**Q: What's a consumer group?**
A: A team of consumers that split the work. Each partition is read by exactly one consumer in the group. Different groups read the same data independently.

**Q: What replaced ZooKeeper?**
A: KRaft (Kafka Raft) -- Kafka now manages its own cluster metadata using the Raft consensus algorithm, stored in the internal `__cluster_metadata` topic.

**Q: What is tiered storage?**
A: Hot (recent) data stays on fast broker SSDs; cold (old) data gets moved to cheap S3 storage. Reduces broker costs by 10x.