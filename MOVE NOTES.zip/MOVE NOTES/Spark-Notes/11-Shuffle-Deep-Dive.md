# Shuffle — Deep Dive

Shuffle is the **most expensive operation** in Spark. Understanding it deeply helps you write faster jobs and debug slow stages.

---

## What Is Shuffle?

Shuffle is the process of **redistributing data across the cluster** so that rows with the same key end up in the same partition. It happens during every **wide transformation**.

**Operations that trigger shuffle:**
- `groupBy()` / `reduceByKey()`
- `join()` (except broadcast join)
- `distinct()`
- `repartition()`
- `orderBy()` / `sortBy()`
- Window functions with `partitionBy`

---

## Two Phases of Shuffle

### Phase 1: Shuffle Write (Map Side)

This happens in the stage **before** the wide transformation.

Each executor:
1. Reads its partition data
2. For each row, computes `hash(key) % num_shuffle_partitions`
3. Sorts rows by target partition ID
4. Serializes the data (using Java or Kryo serializer)
5. Writes **two files** to local disk:
   - **Data file** — contains the actual shuffled data, organized by partition
   - **Index file** — contains offsets for each partition within the data file

```
Executor local disk:
  /spark-local-dir/shuffle_23/
      data_file_0.data     ← actual rows
      data_file_0.index    ← offset for each partition
```

**Important**: Shuffle files are written to **executor local disk**, NOT to HDFS, NOT to S3, NOT kept in memory.

If execution memory isn't enough to sort the data, Spark **spills** intermediate data to disk:
```
/spark-local-dir/spill_456.tmp    ← temporary spill file
```
Spilled data is later merged into the final shuffle output.

### Phase 2: Shuffle Read (Reduce Side)

This happens in the **next stage** after the shuffle.

Each executor:
1. Determines which partitions it needs (based on the index files)
2. **Fetches data from ALL other executors** over the network
3. Deserializes the data
4. Sorts/merges the data for the next operation (e.g., aggregation, join)

```
Executor 1: "I need partition 5"
  → Fetches partition 5 data from Executor 2, 3, 4, 5...
  → All over the network
  → This is the N×N fetch pattern (every executor talks to every other)
```

---

## Why Shuffle Is Expensive

| Cost Factor                | Impact                                     |
|----------------------------|--------------------------------------------|
| Disk I/O                   | Writing shuffle files + reading them back   |
| Network I/O                | Every executor fetches from every other     |
| Serialization/Deserialization | Converting objects to/from bytes         |
| Sorting                    | Data must be sorted by key for merge        |
| Extra stages               | Each shuffle creates a new stage boundary   |
| Spill to disk              | When memory isn't enough, data goes to disk |

---

## Shuffle File Structure

For each map task, Spark creates:

```
┌──────────────────────────────────┐
│         DATA FILE                 │
│                                   │
│  [Partition 0 data] [Partition 1 data] [Partition 2 data] ...
│                                   │
└──────────────────────────────────┘

┌──────────────────────────────────┐
│         INDEX FILE                │
│                                   │
│  Offset_0=0  Offset_1=1024  Offset_2=2560 ...
│                                   │
└──────────────────────────────────┘
```

The index file allows reduce tasks to fetch **only the range they need** from the data file — they don't read the whole file.

---

## Real Example: groupBy Shuffle

```python
df.groupBy("city").count().show()
```

**Stage 1 (Map side — Shuffle Write):**
```
Executor A has:
  Row("Mumbai", 100)
  Row("Pune", 200)

hash("Mumbai") % 200 = partition 42
hash("Pune") % 200 = partition 87

Executor A writes:
  partition_42 → Row("Mumbai", 100) → to data file
  partition_87 → Row("Pune", 200)   → to data file
```

**Stage 2 (Reduce side — Shuffle Read):**
```
Task for partition 42:
  Fetches all "Mumbai" rows from ALL executors
  Aggregates: count = N
  Returns ("Mumbai", N)
```

---

## How to Reduce Shuffle

| Technique               | How It Helps                                         |
|--------------------------|------------------------------------------------------|
| Broadcast Join           | Sends small table to all executors — no shuffle      |
| Bucketing                | Pre-organizes data by key — join without shuffle     |
| Repartition by join key  | Aligns data before join — single shuffle instead of two |
| Coalesce (after filter)  | Reduces empty partitions without shuffle             |
| AQE                      | Auto-merges tiny partitions, switches join strategies |
| Tune shuffle partitions  | Right-size partitions to avoid spills and overhead   |
| Kryo Serialization       | Smaller serialized data = less network transfer      |
| Column Pruning           | Fewer columns = less data shuffled                   |

---

## Key Takeaway

> Shuffle = data redistribution across the cluster. It has two phases: **Shuffle Write** (sort + serialize + write to local disk) and **Shuffle Read** (fetch from all executors over network + deserialize + merge).
> It's expensive because of disk I/O, network I/O, and serialization.
> Minimize shuffle by using broadcast joins, bucketing, and proper partition tuning.
