-- ============================================================
-- InkDrop Platform - V2 Migration: System Design Practice Platform
-- Run this in Supabase Dashboard > SQL Editor
-- Adds new JSONB columns to the problems table for the 4-phase workflow
-- ============================================================

-- Add new columns for the enhanced problem schema
ALTER TABLE problems ADD COLUMN IF NOT EXISTS requirement_checklist JSONB DEFAULT '{}';
ALTER TABLE problems ADD COLUMN IF NOT EXISTS expected_apis JSONB DEFAULT '[]';
ALTER TABLE problems ADD COLUMN IF NOT EXISTS chaos_scenarios JSONB DEFAULT '[]';
ALTER TABLE problems ADD COLUMN IF NOT EXISTS deep_dive_questions JSONB DEFAULT '[]';
ALTER TABLE problems ADD COLUMN IF NOT EXISTS scoring JSONB DEFAULT '{"requirements": 20, "api": 15, "architecture": 40, "deepDive": 25}';
