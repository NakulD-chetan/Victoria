# CAP Theorem — Distributed Systems Ka Sabse Important Rule

> **CAP = Consistency, Availability, Partition Tolerance — Teeno ek saath NAHI mil sakte!**
> Socho 3 friends hain, party mein sirf 2 aa sakte hain — tumhe choose karna padega

---

## Table of Contents
1. [CAP Theorem Kya Hai?](#1-cap-theorem-kya-hai)
2. [The Three Pillars](#2-the-three-pillars)
3. [Why Only 2?](#3-why-only-2)
4. [CP vs AP Systems](#4-cp-vs-ap-systems)
5. [Consistency Models in Depth](#5-consistency-models-in-depth)
6. [PACELC Theorem](#6-pacelc-theorem)
7. [Decision Framework](#7-decision-framework)
8. [Interview Questions & Traps](#8-interview-questions--traps)

---

## 1. CAP Theorem Kya Hai?

### Core Concept
CAP Theorem (Brewer's Theorem) distributed systems ka golden rule hai. Yeh kehta hai: **Network partition hone pe, tum Consistency aur Availability dono nahi de sakte** — ek choose karna padega.

### How It Works

```
    ┌─────────────────────────────────────────────────────────┐
    │                    CAP TRIANGLE                          │
    │                                                          │
    │                        C                                 │
    │                    (Consistency)                         │
    │                       /|\                                │
    │                      / | \                               │
    │                     /  |  \                              │
    │                    /   |   \                             │
    │                   /    |    \                            │
    │                  /     |     \                           │
    │                 /      |      \                          │
    │                /       |       \                         │
    │               A ------+------ P                         │
    │         (Availability)  (Partition Tolerance)            │
    │                                                          │
    │    Sirf 2 choose kar sakte ho! (CA, CP, ya AP)           │
    │    Real world mein: CA practically impossible            │
    └─────────────────────────────────────────────────────────┘
```

### Real World Analogy
**3 Friends Party Analogy:**
- **C** = Chintu (Consistency) — sabko same story sunata hai
- **A** = Anu (Availability) — hamesha available, kabhi bhi respond karega
- **P** = Pankaj (Partition Tolerance) — network tootne pe bhi kaam karega

Party mein sirf 2 jagah hai. Network partition = Pankaj ka ghar door hai. Agar Pankaj aa raha hai (partition handle karna), toh Chintu ya Anu mein se ek ko miss karna padega!

### 1 Minute Recall Block
> CAP = 3 properties, 2 choose. Partition Tolerance = mandatory (network kabhi bhi fail ho sakta hai). Toh real choice: CP ya AP.

### 5 Bullet Memory Hooks
- CAP = C, A, P — teeno nahi, sirf do
- Partition Tolerance = practically mandatory (real networks fail karte hain)
- CP = Bank, AP = Social Media
- CA = theoretical only (single node = no partition)
- Brewer 2000, Gilbert-Lynch 2002 (formal proof)

### ⚠️ Common Interview Trap
**Trap:** "CAP mein CA possible hai?" — **Wrong!** CA sirf single-node systems mein possible hai. Distributed system = partition possible = CA impossible. Interviewer tumhe confuse karne ke liye yeh puch sakta hai.

### Historical Context
- **Eric Brewer** (2000): CAP conjecture propose kiya — distributed systems trade-offs
- **Seth Gilbert & Nancy Lynch** (2002): Formal proof — CAP theorem mathematically prove kiya
- **Important:** CAP "theorem" hai — proven fact, not opinion!

---

## 2. The Three Pillars

### 2.1 Consistency (C)

#### Core Concept
**Sabhi nodes pe same data dikhe** — koi bhi client kisi bhi node se read kare, toh latest write dikhe.

#### How It Works

```
    WRITE: Node A pe X=100
           │
           ├──► Node B ko sync (X=100)
           ├──► Node C ko sync (X=100)
           │
    READ:  Koi bhi node se read karo → X=100 (guaranteed)
```

#### Real World Example
**Bank Balance:** Tumne 10,000 withdraw kiye. Ab tumhare paas 90,000 hone chahiye. Agar kisi ATM pe 1,00,000 dikhe (old data), toh consistency break ho gayi!

#### 1 Minute Recall Block
> Consistency = All nodes same data. Read karte hi latest write dikhe.

### 2.2 Availability (A)

#### Core Concept
**Har request ka response aaye** — system hamesha respond kare, reject na kare (timeout/crash na ho).

#### How It Works

```
    Client Request ──► Any Node
                            │
                            ├──► Response (200 OK) ✓ Available
                            │
                            └──► No "Please wait" / No timeout
```

#### Real World Example
**WhatsApp:** Message bhejo, delivery tick aaye. Agar server busy hai toh bhi "sending..." dikhe, reject na ho. Availability = hamesha kuch na kuch response.

#### 1 Minute Recall Block
> Availability = Every request gets response. No "system unavailable" errors.

### 2.3 Partition Tolerance (P)

#### Core Concept
**Network tootne pe bhi system kaam kare** — nodes ke beech connection break ho jaye, phir bhi system functional rahe.

#### How It Works

```
    Normal:     Node A ◄──────► Node B ◄──────► Node C
                     (All connected)

    Partition:  Node A ◄──X──► Node B ◄──────► Node C
                     (A isolated)    (B,C together)

    Partition Tolerance = A bhi kaam kare, B-C bhi kaam karein
```

#### Real World Example
**Internet:** Kabhi WiFi slow, kabhi packet loss. Real world mein network partition hamesha possible hai. Isliye P = mandatory assumption.

#### 1 Minute Recall Block
> Partition Tolerance = Network fail hone pe bhi system chalna chahiye. Real world = P mandatory.

### Three Pillars Summary Table

| Property | Question | Example |
|----------|----------|---------|
| Consistency | Sab nodes same data? | Bank balance everywhere same |
| Availability | Har request respond? | WhatsApp always sends |
| Partition Tolerance | Network fail pe kaam? | Internet kabhi toot sakta hai |

### ⚠️ Common Interview Trap
**Trap:** "Partition Tolerance optional hai?" — **No!** Real distributed systems = network kabhi fail hota hai. P ko ignore nahi kar sakte. CA sirf single datacenter/single node pe possible hai.

---

## 3. Why Only 2?

### Proof with Example

**Scenario:** 2 nodes (A, B), network partition ho gayi. Client A pe write karta hai, Client B se read karta hai.

```
    Partition Happens!
    
    Node A                    Node B
    ┌─────┐     X     ┌─────┐
    │ X=5 │◄─────────►│ X=3 │   (No communication)
    └─────┘           └─────┘
         │                 │
         │                 │
    Client writes         Client reads
    X=10                  X=?
```

**Choice 1: Consistency choose karo**
- B ko A ka data nahi pata (partition hai)
- B agar respond kare = stale data (X=3) = Consistency break!
- **Solution:** B respond hi na kare (wait/error) = **Availability sacrifice**

**Choice 2: Availability choose karo**
- B respond kare (X=3) = Client ko stale data = **Consistency sacrifice**
- B respond kare = Available ✓

**Conclusion:** Partition pe C aur A dono nahi de sakte!

### Why CA Doesn't Exist in Practice

```
    CA = Consistency + Availability (No Partition)
    
    Matlab: Single node ya perfect network
    Real world: Network kabhi bhi fail ho sakta hai
    ∴ CA = Theoretical only, production mein nahi
```

### 1 Minute Recall Block
> Partition = nodes communicate nahi kar paate. C chahiye = wait karo (A sacrifice). A chahiye = respond karo (C sacrifice).

---

## 4. CP vs AP Systems

### 4.1 CP Systems (Consistency > Availability)

#### Core Concept
**Data sahi hona zyada important** — Agar doubt hai toh request reject karo, galat data mat do.

#### Real World Example: BANK
- Balance wrong dikhana = disaster (fraud, customer loss)
- Better: "System busy, try again" (unavailable) than wrong balance

#### CP System Examples

| System | Why CP? | Trade-off |
|--------|---------|-----------|
| HBase | Strong consistency for analytics | Partition pe read fail |
| MongoDB (strong mode) | Document consistency | Unavailable during partition |
| Redis (cluster mode) | Cache consistency | Slot unavailable if partition |
| etcd, ZooKeeper | Config/leader election | Wait for quorum |

#### Architecture Diagram

```
    CP System (e.g., Bank Database)
    
    ┌─────────┐     ┌─────────┐     ┌─────────┐
    │ Node A  │◄──X─►│ Node B  │◄───►│ Node C  │
    │Primary  │     │ Replica │     │ Replica │
    └────┬────┘     └─────────┘     └─────────┘
         │
         │ Partition: A isolated
         │
         ▼
    Response: "503 Service Unavailable"
    (Wrong balance dena better nahi!)
```

### 4.2 AP Systems (Availability > Consistency)

#### Core Concept
**Hamesha respond karo** — Stale data chalega, but system down mat ho.

#### Real World Example: SOCIAL MEDIA
- Like count 999 vs 1000 — thoda delay OK
- Better: Stale count dikhao than "Cannot load"

#### AP System Examples

| System | Why AP? | Trade-off |
|--------|---------|-----------|
| Cassandra | Always available | Eventual consistency |
| DynamoDB | Amazon's choice for scale | May return stale |
| CouchDB | Offline-first | Sync later |
| DNS | Domain resolution | Propagation delay |

#### Architecture Diagram

```
    AP System (e.g., Cassandra)
    
    ┌─────────┐     ┌─────────┐     ┌─────────┐
    │ Node A  │◄──X─►│ Node B  │◄───►│ Node C  │
    │  Data   │     │  Data   │     │  Data   │
    └────┬────┘     └────┬────┘     └────┬────┘
         │               │               │
         │    Partition: Each responds   │
         │               │               │
         ▼               ▼               ▼
    Response: Latest    Response:        Response:
    it has             Might be stale   Might be stale
```

### CP vs AP Comparison Table

| Aspect | CP | AP |
|--------|----|----|
| Priority | Correct data | Always respond |
| Partition pe | Reject/Wait | Respond (maybe stale) |
| Use case | Bank, Inventory | Social, Analytics |
| Examples | HBase, etcd | Cassandra, DynamoDB |
| User experience | "Try again" | Slightly old data |

### 1 Minute Recall Block
> CP = Correct over Available (Bank). AP = Available over Correct (Twitter likes).

### ⚠️ Common Interview Trap
**Trap:** "MongoDB CP hai ya AP?" — **Depends on config!** Default = CP (single node). Replica set with w:majority = CP. With w:1 = more AP-like. Always clarify configuration!

---

## 5. Consistency Models in Depth

### 5.1 Strong Consistency (Linearizability)

#### Core Concept
**Sabse strong guarantee** — Read = most recent write. Real-time order maintain. Linearizability = operations ka total order exist karta hai jisme har read latest write dikhata hai.

#### How It Works

```
    Timeline:
    W(x=1) ──── W(x=2) ──── W(x=3) ──── R(x)?
                                    │
                                    └──► Must return 3 (latest)
```

#### Real World Example
**Stock trading:** Buy order place kiya, immediately balance update dikhe. Strong consistency mandatory. Agar stale data dikhe toh wrong trade ho sakta hai — loss!

#### When to Use
- Financial transactions
- Inventory (oversell prevent)
- Configuration (one source of truth)

### 5.2 Eventual Consistency

#### Core Concept
**Abhi nahi, baad mein same ho jayega** — Agar writes band ho jayein, eventually sab nodes same data dikhayenge. No guarantee kab tak — seconds to hours.

#### How It Works

```
    Node A: W(x=5) ──────────────────► Eventually sync
    Node B:        ... (stale) ... ───► Gets x=5
    Node C:        ... (stale) ... ───► Gets x=5
```

#### Real World Example
**DNS propagation:** Domain change kiya, 24-48 hours lag sakta hai globally. Eventually sab jagah update. **Social media likes:** Like kiya, count thoda delay se update — acceptable.

#### Trade-offs
- **Pro:** High availability, low latency, scale
- **Con:** Stale reads possible, complex conflict resolution

### 5.3 Causal Consistency

#### Core Concept
**Cause-effect order maintain** — Agar A caused B, toh B ke baad A kabhi nahi dikhega. Stronger than eventual, weaker than strong.

#### How It Works

```
    User A: Post message (cause)
    User B: Reply to message (effect)
    
    Causal: Reply kabhi Post se pehle nahi dikhega
    Eventual: Ho sakta hai (wrong order) — causal prevent karta hai
```

#### Real World Example
**Chat:** Message 1 bheja, phir Reply 2. Reply kabhi Message 1 se pehle nahi dikhega. **Social feed:** Comment kabhi post se pehle nahi.

### 5.4 Read-Your-Writes Consistency

#### Core Concept
**Jo tumne likha, woh tumhe turant dikhe** — Apne writes ke baad apna hi latest data read karo. Session-based guarantee.

#### How It Works
- Route user's reads to same node where they wrote (sticky session)
- Or: Wait for replication to node before responding to read
- Or: Read from master for "own" data

#### Real World Example
**Profile edit:** Name change kiya, refresh pe updated name dikhe (dusre users ko delay ho sakta hai). **Post creation:** Create kiya, turant apni feed mein dikhe.

### 5.5 Monotonic Reads

#### Core Concept
**Waqt peeche nahi jayega** — Agar ek baar X=5 dekha, phir kabhi X=3 nahi dikhega (stale nahi).

#### Real World Example
**News feed:** Scroll karte hue purani posts nahi aani chahiye (monotonic forward).

### 5.6 Session Consistency

#### Core Concept
**Same session mein read-your-writes + monotonic** — User session ke andar consistent view. Different sessions can see different data (eventual across sessions).

#### Real World Example
**Web app:** Login kiya, profile edit kiya — same tab mein refresh = updated. Different device/browser = might see old (eventual).

### Consistency Models Comparison Table

| Model | Guarantee | Use Case | Latency |
|-------|-----------|----------|---------|
| Strong | Linearizable | Banking | High |
| Eventual | Eventually same | Social | Low |
| Causal | Cause before effect | Chat | Medium |
| Read-your-writes | Own writes visible | Profile | Low |
| Monotonic Reads | No going back | Feed | Low |
| Session | Session-level | Web app | Low |

### 1 Minute Recall Block
> Strong = strictest. Eventual = loosest. Causal = cause-effect. Read-your-writes = own writes. Session = combined for user session.

---

## 6. PACELC Theorem

### Core Concept
**CAP ka extension** — Partition (P) ke alawa, **E**lse (normal operation) mein bhi **L**atency vs **C**onsistency trade-off hai.

### How It Works

```
    PACELC = PA/C + EL/C
    
    If Partition (P):  Choose A or C  (same as CAP)
    Else (E):          Choose L or C  (Latency vs Consistency)
    
    Normal operation mein bhi:
    - Low Latency = eventual consistency (DynamoDB)
    - Strong Consistency = higher latency (quorum reads)
```

### PACELC Classification Examples

| System | Partition | Else |
|--------|-----------|------|
| Cassandra | PA | EL (low latency) |
| MongoDB | PC | EC (configurable) |
| DynamoDB | PA | EL (default) |

### 1 Minute Recall Block
> PACELC = CAP + "normal time pe bhi Latency vs Consistency". DynamoDB = PA/EL.

---

## 7. Decision Framework

### When to Choose What

```
    ┌─────────────────────────────────────────┐
    │         DECISION TREE                    │
    └─────────────────────────────────────────┘
    
    Financial/Inventory data?
    │
    ├── YES ──► CP (HBase, PostgreSQL)
    │
    └── NO ──► User-facing, scale chahiye?
                │
                ├── YES ──► AP (Cassandra, DynamoDB)
                │
                └── Config/Coordination?
                    │
                    └── YES ──► CP (etcd, ZooKeeper)
```

### Quick Decision Table

| Requirement | Choice | Example |
|-------------|--------|---------|
| Money, inventory | CP | Banks, e-commerce |
| Social, analytics | AP | Twitter, Facebook |
| Real-time leader | CP | Kubernetes |
| High scale reads | AP | Cassandra |
| Strong consistency needed | CP | Stock trading |

---

## 8. Interview Questions & Traps

### CAP in System Design Interviews

**Typical flow:** "Design Twitter" → "Database consistency?" → CAP discussion. "Design payment system?" → CP choice. "Design feed?" → AP choice.

**Pro tip:** Always state your CAP choice explicitly. "We'll use Cassandra (AP) because availability matters for feed, eventual consistency acceptable."

### Top Interview Questions

1. **CAP Theorem explain karo**
   - 3 properties, 2 choose. P mandatory. CP vs AP with examples.

2. **Bank system CP ya AP? Kyu?**
   - CP. Wrong balance = fraud. Better unavailable than wrong.

3. **Eventual vs Strong consistency difference?**
   - Strong = read = latest write. Eventual = eventually same, may have delay.

4. **DynamoDB CAP mein kahan aata hai?**
   - AP (default). But strong consistency option bhi hai (PC when used).

5. **PACELC kya hai?**
   - CAP + normal operation mein Latency vs Consistency.

6. **Partition kya hota hai exactly?**
   - Network split — nodes communicate nahi kar paate. Packet loss, switch failure, cable cut — kuch bhi.

7. **CA systems exist karte hain?**
   - Single-node = CA (no partition possible). Distributed = CA impossible. Google Spanner "CA" claims — but network partition pe unavailable ho jata hai (technically CP).

### ⚠️ Common Interview Traps

| Trap | Wrong Answer | Right Answer |
|------|--------------|--------------|
| "CA possible?" | Haan | Nahi, real distributed systems mein |
| "MongoDB CP?" | Haan always | Depends on write concern |
| "CAP proof?" | Brewer | Gilbert-Lynch 2002 formalized |
| "Partition optional?" | Haan | Nahi, P mandatory in practice |
| "Consistency = ACID?" | Same hai | Different! CAP C = all nodes same view |

### Quick Recall — Final

```
    CAP = C, A, P → 2 choose
    P = mandatory (network fails)
    CP = Bank, Inventory (correct > available)
    AP = Social, Scale (available > correct)
    Consistency models: Strong > Causal > Session > Eventual
    PACELC = CAP + Latency vs Consistency (normal time)
```

### Final 5 Bullet Memory Hooks
1. **CAP** — 3 friends, 2 party; P mandatory, so C vs A
2. **CP** — Correct data > Available (Bank, HBase)
3. **AP** — Available > Correct (Cassandra, DynamoDB)
4. **Consistency spectrum** — Strong (strict) to Eventual (loose)
5. **PACELC** — Normal time pe bhi Latency vs Consistency trade-off

### Real-World CAP Choices Cheat Sheet

| Company/Product | Choice | Reason |
|-----------------|--------|--------|
| Banks | CP | Wrong balance = disaster |
| Amazon (cart) | AP | Add to cart always work |
| Google (search index) | AP | Stale result OK, down mat ho |
| etcd (K8s) | CP | Config must be correct |
| Cassandra | AP | Scale, availability |
| MongoDB (default) | CP | Document consistency |

### Consistency Model Selection Guide

```
    Need immediate correctness? (Money, inventory)
    → Strong Consistency (CP)
    
    Scale + availability > strict correctness? (Social, analytics)
    → Eventual Consistency (AP)
    
    Chat, comments — order matter?
    → Causal Consistency
    
    User profile — own edits visible?
    → Read-your-writes / Session Consistency
```

### CAP Theorem — One Page Summary

| Term | Meaning | Remember |
|------|---------|----------|
| C | All nodes same data | Correct everywhere |
| A | Every request responds | Never down |
| P | Works despite network split | Real world = mandatory |
| CP | Correct > Available | Bank, etcd |
| AP | Available > Correct | Cassandra, DynamoDB |
| CA | Not in distributed systems | Single node only |

### CAP vs ACID — Don't Confuse!

| CAP Consistency | ACID |
|-----------------|------|
| Distributed: all nodes same view | Single DB: valid state |
| Replication lag = inconsistency | Transaction rollback = consistency |
| CAP C = read latest write | ACID C = constraints satisfied |

**Interview tip:** "CAP consistency" aur "ACID consistency" alag concepts hain. Clarify if interviewer asks.

### Practice Scenarios

1. **E-commerce checkout:** CP — order total wrong = refund chaos
2. **Product catalog:** AP — stale price for 1 sec OK
3. **Chat messages:** Causal — reply after message
4. **User session:** Read-your-writes — own actions visible

---

*End of CAP Theorem and Consistency Notes*
