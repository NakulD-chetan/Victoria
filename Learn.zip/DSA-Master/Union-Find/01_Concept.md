# Union-Find (Disjoint Set Union) — Concept

> **Permanent Recall:** Union-Find tracks connected components with near O(1) amortized operations. Two optimizations — path compression + union by rank — make it FAANG-critical for dynamic connectivity, cycle detection, and grouping problems. ~15% of graph rounds.

---

## Core Idea (2 Lines)

**Union:** Merge two sets (components) into one.

**Find:** Determine which set an element belongs to (returns representative/root).

```
    find(x) → root of x's component
    union(x, y) → merge components containing x and y
```

---

## Data Structure: Forest of Trees

- Each **tree** = one connected component
- Each **node** points to its parent (root points to self)
- **Root** = representative of the component

```
    Component A          Component B
        0                    4
       / \                  / \
      1   2                5   6
      |
      3

    parent: [0,0,0,1,4,4,4]  (0 and 4 are roots)
```

---

## Two Optimizations → Near O(1) Amortized

| Optimization | What It Does | Effect |
|--------------|--------------|--------|
| **Path Compression** | During find(x), make every node on path point directly to root | Flattens tree; future finds are O(1) |
| **Union by Rank** | When merging, attach smaller tree under larger tree's root | Keeps tree shallow |

```
Without optimizations:  O(n) per operation (degenerate chain)
With both:             O(α(n)) ≈ O(1) amortized (inverse Ackermann)
```

---

## Complexity Summary

| Operation | Naive | With Path Compression | With Both |
|-----------|-------|------------------------|-----------|
| find(x) | O(n) | O(α(n)) | O(α(n)) |
| union(x,y) | O(n) | O(α(n)) | O(α(n)) |
| Space | O(n) | O(n) | O(n) |

**α(n)** = inverse Ackermann function — grows so slowly it's effectively constant for any practical n.

---

## When NOT to Use Union-Find

| Scenario | Why Not | Use Instead |
|----------|---------|-------------|
| **Need path info** | UF only knows connectivity, not path | BFS/DFS |
| **Directed graph** | UF assumes symmetric (undirected) | Topological sort, SCC |
| **Static graph, one query** | BFS/DFS simpler | BFS/DFS |
| **Need shortest path** | UF doesn't track distances | Dijkstra, BFS |
| **Order of traversal matters** | UF is unordered | DFS/BFS |

---

## Golden Rules

1. **Dynamic connectivity** → Union-Find (add edges over time, query connectivity)
2. **Cycle in undirected graph** → Union-Find (if edge connects same component → cycle)
3. **Connected components count** → Union-Find (count roots after all unions)
4. **Group merging** (accounts, regions, clusters) → Union-Find
5. **Always use both optimizations** — path compression + union by rank
6. **Initialize parent[i] = i** — each node starts as its own component
7. **Find before union** — always find roots of both, then union roots

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Union-Find (Disjoint Set Union)
CORE OPS:           find(x) → root, union(x,y) → merge
STRUCTURE:          Forest of trees; each tree = one component
OPTIMIZATIONS:      Path compression + Union by rank → O(α(n)) ≈ O(1)
WHEN TO USE:        Dynamic connectivity, cycle detection, component count, grouping
WHEN NOT:           Need path, directed graph, static one-query
GOLDEN RULES:       parent[i]=i init; find roots before union; use both optimizations
INTERVIEW LINE:     "I'll use Union-Find with path compression and union by rank..."
```

---

## 30-SECOND REVISION BOX

```
□ find(x): recurse to parent until parent[x]==x
□ union(x,y): find roots, attach smaller under larger
□ Path compression: parent[x] = find(parent[x])
□ Union by rank: rank[smaller] += 0, attach to larger
□ Init: parent[i]=i, rank[i]=0
□ Cycle: if find(u)==find(v) before union → cycle
□ Component count: count roots (parent[i]==i)
```
