# 03 — NoSQL Databases

> **One-line:** NoSQL databases trade **rigid schemas** and **ACID guarantees** for **horizontal scalability**, **flexible schemas**, and **low-latency** access at massive scale — and knowing **when to use which** is a top interview question.

---

## 1. SQL vs NoSQL — The Classic Interview Question

| Dimension | SQL (Relational) | NoSQL |
|-----------|-----------------|-------|
| **Schema** | Fixed, predefined | Flexible, schema-on-read |
| **Scaling** | Vertical (bigger machine) | Horizontal (more machines) |
| **ACID** | Full support | Varies (eventual consistency common) |
| **Query** | SQL (powerful joins) | API-based, limited joins |
| **Best for** | Complex queries, transactions | High throughput, flexible data, scale |
| **Examples** | PostgreSQL, MySQL, Oracle | MongoDB, Cassandra, DynamoDB, Redis |

**Interview line:** "It's not SQL **vs** NoSQL — it's about **access patterns**. If you need complex joins and transactions, use SQL. If you need scale with simple lookups, use NoSQL."

---

## 2. Types of NoSQL Databases

| Type | How Data is Stored | Best For | Examples |
|------|-------------------|----------|----------|
| **Document** | JSON/BSON documents | Flexible schemas, nested data | MongoDB, Couchbase |
| **Key-Value** | Simple key → value pairs | Caching, sessions, fast lookups | Redis, DynamoDB |
| **Wide-Column** | Rows with dynamic columns | Time-series, IoT, high-write | Cassandra, HBase |
| **Graph** | Nodes + edges + properties | Relationships, social networks | Neo4j, Neptune |

---

## 3. CAP Theorem — Must Know

**CAP = Consistency, Availability, Partition Tolerance — pick 2 (in practice, P is mandatory, so choose C or A).**

```
        Consistency
           /\
          /  \
         /    \
        / CP   \
       /________\
      AP         CA
  Availability    (not practical
                   in distributed)
  Partition Tolerance
```

| Choice | Meaning | Example |
|--------|---------|---------|
| **CP** | Consistent + Partition tolerant → may reject writes during partition | MongoDB, HBase |
| **AP** | Available + Partition tolerant → may serve stale data | Cassandra, DynamoDB |
| **CA** | Not practical in distributed systems | Single-node PostgreSQL |

**Interview tip:** "In distributed systems, network partitions **will** happen — so the real choice is CP vs AP. Cassandra chooses AP (always writable, eventually consistent). MongoDB chooses CP (consistent reads, may block during leader election)."

---

## 4. MongoDB — Document Store

| Feature | Detail |
|---------|--------|
| **Data model** | BSON documents (JSON-like) in **collections** |
| **Schema** | Flexible — each document can have different fields |
| **Scaling** | Sharding (horizontal) by shard key |
| **Replication** | Replica sets (primary + secondaries) |
| **Queries** | Rich query language, aggregation pipeline, indexes |
| **Transactions** | Multi-document ACID (since v4.0) |

### When to Use MongoDB in DE

| Use Case | Why |
|----------|-----|
| **Semi-structured data landing** | JSON from APIs → store as-is → process later |
| **Metadata store** | Pipeline configs, run history with varying schemas |
| **Content management** | Nested documents without complex joins |

### When NOT to Use

- Complex multi-table joins → use PostgreSQL
- Heavy analytical queries → use columnar DW

---

## 5. Apache Cassandra — Wide-Column Store

| Feature | Detail |
|---------|--------|
| **Data model** | Partition key + clustering columns → wide rows |
| **Schema** | Defined but flexible (add columns without downtime) |
| **Scaling** | Peer-to-peer ring → **no single point of failure** |
| **Consistency** | Tunable (ONE, QUORUM, ALL) |
| **Write speed** | Extremely fast (append-only, LSM tree) |
| **Read pattern** | Fast for **partition key** lookups, slow for full scans |

### Cassandra Data Modeling Rule

```
"Model your tables around your QUERIES, not your entities."

Query: "Get all orders for customer X in last 30 days"
    → Partition key: customer_id
    → Clustering key: order_date DESC

One table per query pattern (denormalization is normal).
```

### When to Use Cassandra in DE

| Use Case | Why |
|----------|-----|
| **Time-series / IoT data** | High write throughput, partition by device + time |
| **Event logging** | Append-only, massive write volume |
| **User activity tracking** | Partition by user_id, cluster by timestamp |

---

## 6. Amazon DynamoDB — Managed Key-Value / Document

| Feature | Detail |
|---------|--------|
| **Type** | Managed key-value + document store (AWS) |
| **Scaling** | Auto-scaling, serverless option |
| **Pricing** | Pay per read/write capacity units (RCU/WCU) |
| **Partition key** | Must design for even distribution |
| **Sort key** | Optional — enables range queries within partition |
| **GSI / LSI** | Global/Local Secondary Indexes for alternate access patterns |
| **Streams** | DynamoDB Streams → CDC-like change capture → Lambda/Kinesis |

### DynamoDB for DE Interview Points

| Point | Detail |
|-------|--------|
| **DynamoDB Streams** | Similar to CDC — capture table changes → trigger Lambda or push to Kinesis |
| **Export to S3** | Native export for analytics without impacting table performance |
| **Single-digit ms latency** | For key-value lookups at any scale |
| **Hot partition problem** | Uneven partition key → throttling → design keys carefully |

---

## 7. Redis — In-Memory Key-Value Store

| Feature | Detail |
|---------|--------|
| **Speed** | Sub-millisecond reads/writes (all in-memory) |
| **Data structures** | Strings, hashes, lists, sets, sorted sets, streams |
| **Persistence** | Optional (RDB snapshots, AOF append-only file) |
| **Use as cache** | TTL (time-to-live) for auto-expiry |
| **Pub/Sub** | Built-in publish/subscribe messaging |
| **Redis Streams** | Log-like data structure for event streaming |

### Redis in DE Pipelines

| Use Case | How |
|----------|-----|
| **Caching layer** | Cache expensive query results; pipeline reads cache first |
| **Rate limiting** | Track API call counts with TTL |
| **Real-time leaderboards** | Sorted sets for ranking |
| **Session store** | User sessions for web apps |
| **Deduplication** | Check if event ID exists in set before processing |
| **Pipeline state** | Store last processed offset, watermarks |

---

## 8. Comparison Matrix (Interview Gold)

| Feature | MongoDB | Cassandra | DynamoDB | Redis |
|---------|---------|-----------|----------|-------|
| **Type** | Document | Wide-Column | Key-Value/Doc | Key-Value |
| **Schema** | Flexible | Defined | Flexible | Schema-less |
| **Consistency** | Strong (CP) | Tunable (AP) | Tunable | Strong (single) |
| **Scaling** | Sharding | Ring (P2P) | Auto-managed | Cluster mode |
| **Best for** | Flexible docs | High-write TS | Serverless KV | Caching, speed |
| **Managed** | Atlas | Astra | Native AWS | ElastiCache |
| **Latency** | Low ms | Low ms | Single-digit ms | Sub-ms |

---

## 9. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "When would you use NoSQL over SQL?" | High scale, simple access patterns, flexible schema, low-latency lookups |
| "Explain CAP theorem" | C+A+P, pick 2. P is mandatory in distributed → real choice is CP vs AP |
| "MongoDB vs Cassandra?" | Mongo: flexible docs, rich queries. Cassandra: extreme write speed, time-series |
| "What is DynamoDB Streams?" | CDC for DynamoDB — capture changes, trigger Lambda, sync to analytics |
| "How do you use Redis in data pipelines?" | Caching, deduplication, rate limiting, storing pipeline state |
| "How does Cassandra handle consistency?" | Tunable: ONE (fast, eventual) → QUORUM (balanced) → ALL (strong, slow) |
| "What's the hot partition problem?" | Uneven key distribution → some partitions get all traffic → throttling/OOM |

---

## Key Takeaways

- **SQL vs NoSQL** is about **access patterns**, not one being "better".
- **CAP theorem**: distributed systems must choose between **consistency** and **availability** during partitions.
- **MongoDB**: flexible documents, rich queries — good for semi-structured landing zones.
- **Cassandra**: extreme write throughput, time-series — model tables around queries.
- **DynamoDB**: serverless, auto-scaling, DynamoDB Streams for CDC — AWS-native.
- **Redis**: sub-ms in-memory — caching, dedup, real-time state in pipelines.
- In DE interviews, focus on **when to use which** and **how NoSQL fits into the pipeline architecture**.

---
