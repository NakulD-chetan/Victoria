# SQL Interview Mastery — Tricks and Recognition

---

## Pattern recognition cheat sheet

| When you see... | Immediately think... | Template # |
|----------------|---------------------|------------|
| "Top N per group" | DENSE_RANK + CTE | T1 |
| "Rate / percentage / ratio" | AVG(CASE WHEN) | T2 |
| "Never / without / missing" | Anti-join (LEFT … IS NULL) | T3 |
| "Cumulative / running" | SUM OVER (ROWS UNBOUNDED) | T4 |
| "Consecutive / streak" | LAG or ROW_NUMBER diff | T5/T6 |
| "Weighted average" | SUM(x*w)/SUM(w) | T7 |
| "Compare to previous" | LAG or self-join | T8 |
| "First per user/group" | ROW_NUMBER = 1 or MIN | T1 variant |
| "Day-over-day change" | LAG + (curr - prev)/prev | T8 |
| "Retention / next-day" | CTE first_login + EXISTS day+1 | T5 variant |
| "Pivot / reshape" | CASE WHEN inside aggregation | T2 variant |
| "Island / gap in dates" | date - ROW_NUMBER constant | T6 |
| "Median" | PERCENTILE_CONT(0.5) or ROW_NUMBER middle | Special |
| "Nth highest salary" | DENSE_RANK or LIMIT+OFFSET | T1 variant |
| "Duplicate detection" | GROUP BY + HAVING COUNT > 1 | Basic |
| "Year-over-year" | LAG with yearly partition or self-join | T8 |

---

## SQL vs NoSQL — if asked

| SQL | NoSQL |
|-----|-------|
| Structured, schema-enforced | Flexible schema |
| ACID transactions | Eventually consistent (usually BASE) |
| Joins (native) | Denormalized / embedded |
| Scale vertical (mostly) | Scale horizontal (sharding) |
| Standard query language (SQL) | Varies (MongoDB query, CQL, etc.) |
| Good for: relational, OLTP, complex queries | Good for: documents, real-time, massive scale |
| Examples: MySQL, PostgreSQL, Oracle | Examples: MongoDB, Cassandra, Redis, Neo4j |

---

## Theory one-liners (say these in interview)

| Topic | Power line |
|-------|-----------|
| **NULL** | "Any comparison with NULL returns UNKNOWN. I always handle NULLs explicitly with IS NULL / COALESCE." |
| **Indexes** | "I'd check EXPLAIN for seq scans and add indexes on high-selectivity WHERE/JOIN columns." |
| **Normalization** | "3NF means every non-key depends directly on PK. I'd denormalize only for proven read performance needs." |
| **ACID** | "Atomicity ensures all-or-nothing. I'd use explicit transactions for multi-step operations." |
| **Materialized View** | "Precomputed snapshot for fast dashboard reads. Trade-off is staleness — needs refresh strategy." |
| **Window vs GROUP BY** | "Window keeps row detail; GROUP BY collapses. I pick based on whether I need both individual and aggregate data." |
| **Anti-join** | "I use NOT EXISTS over NOT IN to avoid NULL pitfalls in subqueries." |
| **Deadlock** | "Consistent lock ordering + short transactions + retry logic in application." |

---

*Next: [[08_Problem-List]]*
