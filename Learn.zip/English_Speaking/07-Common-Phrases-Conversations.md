# Common Phrases & Conversations

> *"Fluent speakers phrases mein sochte hain, words mein nahi. Phrases seekho — speed apne aap aayegi."*

Yeh chapter mein 100+ daily use phrases hain, situation-wise organized. Inhe ratte mat lagao — daily 5-10 phrases practice karo, use karo, aur naturally yaad ho jayenge.

---

## 1. Greetings & Goodbyes

### Formal

| Phrase | Kab Use Karo |
|--------|-------------|
| Good morning / Good afternoon / Good evening | Time ke hisaab se |
| How do you do? | First time milne pe (very formal) |
| It's a pleasure to meet you. | New introduction |
| I hope you're doing well. | Email / professional setting |
| Have a great day. | Leaving politely |
| It was nice meeting you. | After conversation |

### Informal / Casual

| Phrase | Kab Use Karo |
|--------|-------------|
| Hey! What's up? | Dost se casual |
| How's it going? | General greeting |
| Long time no see! | Bahut din baad milne pe |
| What have you been up to? | Recent activities puchhna |
| Catch you later! | Bye casual |
| Take care! | Bye with warmth |
| See you around. | Phir milenge |

---

## 2. Daily Conversation Starters

| Situation | Phrases |
|-----------|---------|
| **Starting a chat** | "By the way...", "So, I was thinking...", "Did you hear about...?" |
| **Asking about someone** | "How was your day?", "How's work going?", "Everything okay?" |
| **Small talk** | "Nice weather today!", "Did you watch the match?", "Have you tried that new restaurant?" |
| **Reconnecting** | "It's been ages!", "We should catch up soon.", "How's the family?" |

---

## 3. Office / Workplace Phrases

### Meetings

| Phrase | Use |
|--------|-----|
| Let's get started. | Meeting shuru karna |
| Can I add something? | Beech mein bolna |
| I'd like to share my perspective. | Opinion dena |
| Could you elaborate on that? | Zyada detail maangna |
| Let me get back to you on that. | Abhi answer nahi hai |
| To summarize... | End mein wrap-up |
| Does anyone have any questions? | Meeting close karna |
| Let's take this offline. | Baad mein discuss karenge |

### Emails / Messages

| Phrase | Use |
|--------|-----|
| I hope this email finds you well. | Formal start |
| Just a quick update... | Short update dena |
| Please find attached... | File attach ki hai |
| Could you please confirm? | Confirmation maangna |
| Looking forward to your response. | Reply ka intezaar |
| Thanks in advance. | Pehle se thanks |
| Best regards / Kind regards | Sign off |

### Daily Work

| Phrase | Use |
|--------|-----|
| I'm working on it. | Progress bata rahe ho |
| I'll take care of it. | Zimmedari le rahe ho |
| I need more time. | Zyada waqt chahiye |
| Can we reschedule? | Date change karna |
| I'm running behind schedule. | Late ho rahe ho |
| Let's prioritize this. | Pehle yeh karo |
| I'll loop you in. | Tumhe include karunga |

---

## 4. Shopping Phrases

| Phrase | Meaning |
|--------|---------|
| How much does this cost? | Kitne ka hai? |
| Do you have this in a different size/color? | Alag size/color mein hai? |
| Can I try this on? | Pehen ke dekh sakta hoon? |
| I'm just browsing, thanks. | Bas dekh raha hoon |
| Can I get a discount? | Discount milega? |
| Do you accept card payments? | Card se payment hoga? |
| I'd like to return this. | Yeh wapas karna hai |
| Can I get a receipt? | Receipt de sakte hain? |
| This is exactly what I was looking for! | Yeh hi chahiye tha mujhe! |

---

## 5. Restaurant / Food Phrases

| Phrase | Meaning |
|--------|---------|
| A table for two, please. | Do logo ke liye table chahiye |
| Could I see the menu? | Menu dikhaiye |
| What do you recommend? | Aap kya suggest karoge? |
| I'd like to order... | Mujhe order karna hai... |
| I'm allergic to nuts. | Mujhe nuts se allergy hai |
| Could I have the bill, please? | Bill de dijiye |
| The food was delicious! | Khaana bahut achha tha! |
| Can I have some water? | Paani mil sakta hai? |
| Is this dish spicy? | Yeh dish teekhi hai? |
| Keep the change. | Chhutta rakh lo |

---

## 6. Travel Phrases

| Phrase | Meaning |
|--------|---------|
| Excuse me, how do I get to ___? | ___ kaise jaun? |
| Is this the right way to ___? | Yeh ___ ka raasta hai? |
| How far is it from here? | Yahan se kitna door hai? |
| Can you show me on the map? | Map pe dikha sakte ho? |
| I'd like to book a room. | Room book karna hai |
| What time is check-in/check-out? | Check-in/check-out ka time kya hai? |
| Where is the nearest ATM/hospital? | Sabse paas ka ATM/hospital kahan hai? |
| I've lost my luggage. | Mera saamaan kho gaya hai |
| How much is the fare? | Kiraya kitna hai? |
| Is there Wi-Fi available? | Wi-Fi hai kya? |

---

## 7. Phone Conversation Phrases

| Phrase | Use |
|--------|-----|
| Hello, this is ___ speaking. | Call receive karna |
| May I speak to ___? | Kisi se baat karni hai |
| Could you hold for a moment? | Thoda ruko |
| I'll call you back. | Baad mein call karta hoon |
| Sorry, I didn't catch that. | Sunai nahi diya |
| Could you repeat that, please? | Dobara bolo please |
| The line is breaking up. | Network issue |
| I'll text you the details. | Details message karta hoon |
| Thanks for calling. | Call ke liye thanks |

---

## 8. Expressing Opinions

| Type | Phrases |
|------|---------|
| **Agreeing** | "I agree.", "Exactly!", "That's a good point.", "I think so too.", "Absolutely!" |
| **Disagreeing (polite)** | "I see your point, but...", "I'm not sure about that.", "I respectfully disagree.", "I understand, however..." |
| **Giving opinion** | "In my opinion...", "I think...", "I believe...", "As far as I'm concerned...", "From my perspective..." |
| **Asking opinion** | "What do you think?", "How do you feel about this?", "What's your take on this?" |
| **Neutral** | "It depends.", "I can see both sides.", "I'm not sure yet.", "That's debatable." |

---

## 9. Expressing Emotions

| Emotion | Phrases |
|---------|---------|
| **Happy** | "I'm so glad!", "That's wonderful!", "I'm thrilled!", "This made my day!" |
| **Sad** | "That's unfortunate.", "I'm sorry to hear that.", "That's really disappointing." |
| **Surprised** | "Are you serious?", "No way!", "I can't believe it!", "That's unexpected!" |
| **Angry** | "That's not acceptable.", "I'm really frustrated.", "This is unacceptable." |
| **Grateful** | "I really appreciate it.", "That means a lot to me.", "I can't thank you enough." |
| **Apologizing** | "I'm sorry.", "I apologize for the inconvenience.", "My bad.", "I didn't mean to." |
| **Encouraging** | "You've got this!", "Keep going!", "Don't give up!", "I believe in you!" |

---

## 10. Filler Phrases — Waqt Khareedne Ke Liye

> Jab sochna ho aur turant answer nahi aaye, yeh phrases use karo (awkward silence se better):

| Phrase | Use |
|--------|-----|
| Well... | Sochte waqt |
| Let me think about that... | Thoda sochna hai |
| That's a good question... | Question achha hai, soch raha hoon |
| How should I put this... | Kaise boloon |
| You know what I mean? | Samjh aa raha hai na? |
| Basically... | Simple mein bolna hai |
| The thing is... | Baat yeh hai ki |
| To be honest... | Sachchi baat yeh hai |
| As a matter of fact... | Actually |
| If I'm not mistaken... | Agar galat nahi hoon toh |

[TIP] Filler phrases use karo lekin **bahut zyada nahi** — warna unconfident lagta hai. Maximum 2-3 per minute.

---

## 11. Daily Phrase Practice Plan

| Day | Category | Practice |
|-----|----------|---------|
| Mon | Greetings | 5 formal + 5 informal greetings practice |
| Tue | Office | Meeting phrases mirror mein practice |
| Wed | Shopping | Shopping role-play (self-talk) |
| Thu | Restaurant | Restaurant scene role-play |
| Fri | Opinions | Kisi topic pe opinion do (30-second burst) |
| Sat | Phone | Phone call practice (record yourself) |
| Sun | Review | Sabse weak area repeat karo |

---

*Agle chapter mein: Pronunciation Tips — sounds, stress, intonation, aur common galtiyan*
