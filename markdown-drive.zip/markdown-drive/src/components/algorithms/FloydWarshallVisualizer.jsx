import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: floyd-warshall */
const IDS = ['1', '2', '3', '4'];
const GRAPH = {
  nodes: [
    { id: '1', x: 120, y: 100, label: '1' },
    { id: '2', x: 320, y: 100, label: '2' },
    { id: '3', x: 120, y: 260, label: '3' },
    { id: '4', x: 320, y: 260, label: '4' },
  ],
  edges: [
    { from: '1', to: '2', weight: 3, directed: true },
    { from: '1', to: '3', weight: 8, directed: true },
    { from: '2', to: '4', weight: 2, directed: true },
    { from: '3', to: '2', weight: 5, directed: true },
    { from: '4', to: '3', weight: 1, directed: true },
  ],
};

function generateSteps() {
  const n = IDS.length;
  const idx = (id) => IDS.indexOf(id);
  const dist = Array.from({ length: n }, () => Array.from({ length: n }, () => Infinity));
  for (let i = 0; i < n; i += 1) dist[i][i] = 0;
  GRAPH.edges.forEach((e) => {
    dist[idx(e.from)][idx(e.to)] = e.weight;
  });
  const steps = [];
  const snap = () => dist.map((row) => row.map((v) => (v === Infinity ? '∞' : v)).join(',')).join('|');
  steps.push({ type: 'init', k: null, nodeColors: {}, edgeColors: {}, matrix: snap() });
  for (let k = 0; k < n; k += 1) {
    const kid = IDS[k];
    steps.push({ type: 'k', k: kid, nodeColors: { [kid]: 'current' }, edgeColors: {}, matrix: snap() });
    for (let i = 0; i < n; i += 1) {
      for (let j = 0; j < n; j += 1) {
        if (dist[i][k] === Infinity || dist[k][j] === Infinity) continue;
        const nd = dist[i][k] + dist[k][j];
        steps.push({
          type: 'try',
          k: kid,
          i: IDS[i],
          j: IDS[j],
          nodeColors: { [IDS[i]]: 'processing', [kid]: 'current', [IDS[j]]: 'processing' },
          edgeColors: {},
          matrix: snap(),
          nd,
        });
        if (nd < dist[i][j]) {
          dist[i][j] = nd;
          steps.push({
            type: 'improve',
            k: kid,
            i: IDS[i],
            j: IDS[j],
            nodeColors: { [IDS[i]]: 'visited', [IDS[j]]: 'visited' },
            edgeColors: { [`${IDS[i]}-${IDS[j]}`]: 'highlight' },
            matrix: snap(),
          });
        }
      }
    }
  }
  steps.push({ type: 'done', k: null, nodeColors: Object.fromEntries(IDS.map((id) => [id, 'visited'])), edgeColors: {}, matrix: snap() });
  return steps;
}

export default function FloydWarshallVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Floyd–Warshall all-pairs shortest paths' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'try') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.type}${step.k ? ` via ${step.k}` : ''}` });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.k ? { [step.k]: `k=${step.k}` } : {},
      queue: step.matrix ? [step.matrix] : [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
