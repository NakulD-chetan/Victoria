import { worldFromClient } from '../coords';
import {
  topmostAt,
  hitResizeHandle,
  elementIntersectsRect,
  resizeFromHandle,
  translateElement,
} from '../hit-test';
import { resolveSceneBindings } from '../binding-engine';

/**
 * Select tool
 *  - empty click + drag → marquee; on release set selection to hit set
 *  - click on element → select (or toggle w/ shift)
 *  - drag selected element(s) → translate; commits once on pointerup
 *  - drag on a resize handle → resize
 *
 * Only ONE history entry is produced per gesture (via coalesceKey).
 */

export const selectTool = {
  id: 'select',
  cursor: 'default',

  onPointerDown(ctx, ev) {
    if (ev.button !== 0) return false;
    const { canvasEl, getVp, getScene, store, setMarquee } = ctx;
    canvasEl.setPointerCapture?.(ev.pointerId);

    const vp = getVp();
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, vp);
    const scene = getScene();
    const selection = store.getState().selection;

    // 1) resize handle on a selected element?
    if (selection.size === 1) {
      const id = [...selection][0];
      const el = scene.elements.find((e) => e.id === id);
      if (el) {
        const role = hitResizeHandle(el, x, y, vp.zoom);
        if (role) {
          ctx._gesture = { kind: 'resize', id, role, originals: new Map([[id, el]]), preMoveElements: scene.elements };
          return true;
        }
      }
    }

    // 2) click on an element?
    const hit = topmostAt(scene.elements, x, y);
    if (hit) {
      const isSelected = selection.has(hit.id);
      let nextSel = new Set(selection);
      if (ev.shiftKey) {
        if (isSelected) nextSel.delete(hit.id);
        else nextSel.add(hit.id);
      } else if (!isSelected) {
        nextSel = new Set([hit.id]);
      }
      store.getState().setSelection(nextSel);
      // begin move if the element is in the final selection
      if (nextSel.has(hit.id)) {
        const originals = new Map();
        for (const el of scene.elements) if (nextSel.has(el.id)) originals.set(el.id, el);
        ctx._gesture = { kind: 'move', startX: x, startY: y, originals, preMoveElements: scene.elements };
      } else {
        ctx._gesture = null;
      }
      ctx.markDirty(1);
      return true;
    }

    // 3) empty space → marquee
    if (!ev.shiftKey) store.getState().clearSelection();
    ctx._gesture = { kind: 'marquee', x0: x, y0: y };
    setMarquee({ x0: x, y0: y, x1: x, y1: y });
    ctx.markDirty(1);
    return true;
  },

  onPointerMove(ctx, ev) {
    const g = ctx._gesture;
    if (!g) return;
    const { canvasEl, getVp, getScene, setMarquee } = ctx;
    const vp = getVp();
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, vp);

    if (g.kind === 'marquee') {
      setMarquee({ x0: g.x0, y0: g.y0, x1: x, y1: y });
      ctx.markDirty(1);
      return;
    }

    if (g.kind === 'move') {
      const dx = x - g.startX;
      const dy = y - g.startY;
      // transient update via coalesceKey so it's one undo entry
      const scene = getScene();
      const moved = scene.elements.map((el) => {
        if (!g.originals.has(el.id)) return el;
        return translateElement(g.originals.get(el.id), dx, dy);
      });
      const next = resolveSceneBindings(moved);
      ctx.commitTransient(next, 'move:' + [...g.originals.keys()].join(','));
      ctx.markDirty(2);
      return;
    }

    if (g.kind === 'resize') {
      const orig = g.originals.get(g.id);
      const patch = resizeFromHandle(orig, g.role, x, y);
      const scene = getScene();
      const next = resolveSceneBindings(
        scene.elements.map((el) => el.id === g.id ? { ...orig, ...patch } : el),
      );
      ctx.commitTransient(next, 'resize:' + g.id);
      ctx.markDirty(2);
    }
  },

  onPointerUp(ctx) {
    const g = ctx._gesture;
    ctx._gesture = null;

    if (!g) return;
    const { store, setMarquee, getScene } = ctx;

    if (g.kind === 'marquee') {
      const m = ctx.getMarquee();
      setMarquee(null);
      if (m) {
        const x = Math.min(m.x0, m.x1), y = Math.min(m.y0, m.y1);
        const w = Math.abs(m.x1 - m.x0), h = Math.abs(m.y1 - m.y0);
        if (w >= 2 && h >= 2) {
          const scene = getScene();
          const hits = new Set();
          for (const el of scene.elements) {
            if (elementIntersectsRect(el, x, y, w, h)) hits.add(el.id);
          }
          store.getState().setSelection(hits);
        }
      }
      ctx.markDirty(1);
      return;
    }

    if (g.kind === 'move' || g.kind === 'resize') {
      // commit the transient state as a single history entry tied to the
      // pre-gesture element array
      const scene = getScene();
      ctx.commitGesture(g.preMoveElements, scene.elements);
      ctx.markDirty(2);
    }
  },

  onCancel(ctx) {
    ctx._gesture = null;
    ctx.setMarquee?.(null);
    ctx.markDirty(1);
  },
};
