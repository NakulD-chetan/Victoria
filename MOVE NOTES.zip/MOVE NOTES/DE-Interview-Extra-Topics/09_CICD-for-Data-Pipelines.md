# 09 — CI/CD for Data Pipelines

> **One-line:** CI/CD for data engineering means **automated testing, validation, and deployment** of pipeline code, SQL models, and infrastructure changes — interviewers at Snowflake, Databricks, and FAANG hold DE to **software engineering standards**.

---

## 1. Why CI/CD for DE is Asked

| Reason | Detail |
|--------|--------|
| **Production safety** | Bad pipeline deployment can corrupt warehouse data for thousands of users |
| **Speed** | Teams ship daily; manual testing doesn't scale |
| **Reproducibility** | Same code → same result in dev, staging, prod |
| **Audit trail** | Git history shows who changed what, when, why |
| **Interview signal** | Separates "I can write SQL" from "I can build production systems" |

---

## 2. CI/CD Pipeline for Data Projects

```
Developer pushes code
    │
    ▼
┌──────────────────────────────────────────────────────┐
│                 CI (Continuous Integration)            │
│                                                       │
│  1. Lint check (SQL linting, Python flake8/ruff)     │
│  2. Unit tests (Python functions, dbt model tests)   │
│  3. Integration tests (run against test DB)          │
│  4. Data quality tests (Great Expectations)          │
│  5. Build Docker image (if applicable)               │
│  6. Security scan (secrets detection, SAST)          │
└──────────────────────┬───────────────────────────────┘
                       │ All pass?
                       ▼
┌──────────────────────────────────────────────────────┐
│                 CD (Continuous Deployment)             │
│                                                       │
│  1. Deploy to staging environment                    │
│  2. Run smoke tests on staging                       │
│  3. Manual approval (for prod)                       │
│  4. Deploy to production                             │
│  5. Post-deployment validation                       │
│  6. Rollback if metrics degrade                      │
└──────────────────────────────────────────────────────┘
```

---

## 3. Git Workflow for Data Teams

### Branching Strategy

```
main (production)
  │
  ├── develop (integration branch)
  │     │
  │     ├── feature/add-customer-dim
  │     ├── feature/fix-revenue-calc
  │     └── hotfix/null-order-id
  │
  └── release/v2.3 (release candidate)
```

| Branch | Purpose |
|--------|---------|
| **main** | Production-ready code, protected |
| **develop** | Integration branch, all features merge here first |
| **feature/** | One branch per ticket/task |
| **hotfix/** | Emergency production fixes |
| **release/** | Release candidate for final testing |

### Pull Request Checklist for DE

| Check | What |
|-------|------|
| **Code review** | Peer reviews SQL/Python changes |
| **Tests pass** | CI pipeline green |
| **Data validation** | dbt tests or Great Expectations pass |
| **Documentation** | Updated README, column descriptions |
| **No secrets** | No API keys, passwords in code |
| **Backward compatible** | Schema changes don't break downstream |

---

## 4. Testing Pyramid for Data Pipelines

```
                    /\
                   /  \
                  / E2E \        End-to-end pipeline test
                 / Tests \       (slowest, most expensive)
                /──────────\
               / Integration \    Test against real DB/DW
              /    Tests      \   (medium speed)
             /────────────────\
            /    Unit Tests     \  Test functions, logic
           /                     \ (fastest, cheapest)
          /───────────────────────\
```

### What to Test

| Layer | What to Test | Tool |
|-------|-------------|------|
| **Unit** | Python transform functions, SQL logic | pytest, dbt unit tests |
| **Integration** | Pipeline against test database | pytest + test DB, dbt run on staging |
| **Data Quality** | Row counts, null checks, value ranges | Great Expectations, dbt tests, Soda |
| **Contract** | Schema compatibility, column types | Schema Registry, dbt contracts |
| **Performance** | Query execution time, data volume | Benchmark scripts, monitoring |
| **E2E** | Full pipeline from source to dashboard | Smoke tests on staging |

### dbt Testing Example

```yaml
# schema.yml
models:
  - name: orders
    columns:
      - name: order_id
        tests:
          - unique
          - not_null
      - name: amount
        tests:
          - not_null
          - dbt_utils.accepted_range:
              min_value: 0
      - name: status
        tests:
          - accepted_values:
              values: ['pending', 'shipped', 'delivered', 'cancelled']
```

---

## 5. Infrastructure as Code (IaC) for Data

| Tool | What It Manages |
|------|----------------|
| **Terraform** | Cloud resources (S3 buckets, Redshift clusters, IAM roles, Kafka topics) |
| **Pulumi** | Cloud resources with Python/TypeScript (alternative to Terraform) |
| **CloudFormation** | AWS-specific infrastructure |
| **Helm Charts** | Kubernetes deployments (Airflow, Spark on K8s) |
| **dbt** | SQL model definitions, tests, docs (code-driven transformations) |

### Terraform Example for DE

```hcl
resource "aws_s3_bucket" "data_lake" {
  bucket = "company-data-lake-prod"
  
  server_side_encryption_configuration {
    rule {
      apply_server_side_encryption_by_default {
        sse_algorithm = "aws:kms"
      }
    }
  }
}

resource "aws_glue_catalog_database" "warehouse" {
  name = "analytics_prod"
}
```

---

## 6. Environment Strategy

| Environment | Purpose | Data |
|-------------|---------|------|
| **Dev** | Developer sandbox | Subset / synthetic data |
| **Staging** | Pre-production testing | Copy of prod or masked prod data |
| **Production** | Live system | Real data |

### Environment Isolation Patterns

| Pattern | How |
|---------|-----|
| **Separate schemas** | `dev.sales.orders`, `prod.sales.orders` |
| **Separate warehouses** | Dev Snowflake account vs Prod account |
| **Feature flags** | Toggle new logic on/off without redeployment |
| **Blue-green** | Two prod environments — switch traffic after validation |

**Interview tip:** "In dbt, we use `target` profiles — same code runs against dev or prod depending on the target. `dbt run --target prod` deploys to production."

---

## 7. Deployment Strategies for Pipelines

| Strategy | How | When |
|----------|-----|------|
| **Rolling** | Deploy new version gradually | Standard pipeline updates |
| **Blue-Green** | Run new version alongside old; switch when validated | Zero-downtime DW migrations |
| **Canary** | Deploy to small subset first; expand if metrics OK | Risky transformation changes |
| **Shadow** | Run new pipeline in parallel; compare outputs; don't serve | Major logic rewrites |

### Shadow Pipeline Pattern

```
Source Data
    │
    ├──► Current Pipeline ──► Production Tables (serving)
    │
    └──► New Pipeline ──► Shadow Tables (comparison only)
    
Compare: row counts, aggregates, sample records
If match → promote shadow to production
If differ → investigate before deploying
```

---

## 8. Secrets Management

| What | How |
|------|-----|
| **Never in code** | No passwords, API keys in Git |
| **Environment variables** | Pass secrets via CI/CD env vars |
| **Vault** | HashiCorp Vault, AWS Secrets Manager, Azure Key Vault |
| **Git pre-commit hooks** | Detect secrets before they enter the repo (gitleaks, detect-secrets) |
| **Airflow connections** | Store credentials in Airflow's encrypted connection store |
| **dbt profiles** | Use env vars: `password: "{{ env_var('DBT_PASSWORD') }}"` |

---

## 9. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "How do you test data pipelines?" | Unit (functions), integration (test DB), data quality (GE/dbt tests), E2E (staging) |
| "What does your CI/CD look like?" | Lint → test → build → deploy staging → validate → approve → deploy prod |
| "How do you handle secrets?" | Never in code; use Vault/Secrets Manager; env vars; pre-commit hooks |
| "Git workflow for data teams?" | Feature branches → PR with review + CI → merge to develop → release → prod |
| "How do you do zero-downtime migration?" | Blue-green deployment, shadow pipelines, backward-compatible schema changes |
| "What is Infrastructure as Code?" | Define cloud resources in code (Terraform) — version controlled, reproducible |
| "How do you rollback a bad deployment?" | Revert git commit, redeploy previous version, restore data from time travel/backup |

---

## Key Takeaways

- CI/CD for DE = **lint → test → build → deploy → validate** — same rigor as software engineering.
- **Testing pyramid**: unit tests (fast, many) → integration (medium) → E2E (slow, few).
- **dbt tests** and **Great Expectations** are the standard for data quality in CI.
- **Git branching** with PR reviews and CI checks prevents bad code from reaching production.
- **IaC** (Terraform) makes infrastructure **reproducible** and **version-controlled**.
- **Secrets never in code** — use Vault, Secrets Manager, or encrypted connection stores.
- **Shadow pipelines** and **blue-green deployments** enable safe production changes.

---
