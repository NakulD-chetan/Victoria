# Clauses and Execution — Edge Cases

---

## NULL + NOT IN

If subquery can return NULL, `x NOT IN (subquery)` can yield **UNKNOWN** for all rows → empty result. Prefer `NOT EXISTS`.

---

## LIKE escape

- `%` and `_` wildcards — escape carefully for literal `%`.

---

## Duplicate columns with JOIN

Always **qualify** `table.column` in multi-table queries.

---

## Tie-breaking in ORDER BY

Add secondary sort key: `ORDER BY score DESC, id ASC`.

---

*Next: [[07_Tricks-and-Recognition]]*
