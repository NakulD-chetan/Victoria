import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: johnsons */
const GRAPH = {
  nodes: [
    { id: 'S', x: 80, y: 200, label: 'S*' },
    { id: 'A', x: 220, y: 140, label: 'A' },
    { id: 'B', x: 220, y: 260, label: 'B' },
    { id: 'C', x: 380, y: 140, label: 'C' },
    { id: 'D', x: 380, y: 260, label: 'D' },
  ],
  edges: [
    { from: 'S', to: 'A', weight: 0, directed: true },
    { from: 'S', to: 'B', weight: 0, directed: true },
    { from: 'S', to: 'C', weight: 0, directed: true },
    { from: 'S', to: 'D', weight: 0, directed: true },
    { from: 'A', to: 'C', weight: 2, directed: true },
    { from: 'A', to: 'B', weight: 4, directed: true },
    { from: 'B', to: 'C', weight: -1, directed: true },
    { from: 'C', to: 'D', weight: 3, directed: true },
  ],
};

function generateSteps() {
  const steps = [];
  steps.push({ type: 'virtual', nodeColors: { S: 'source' }, edgeColors: {}, note: 'Add virtual S with 0-cost edges' });
  const h = { S: 0, A: -1, B: 0, C: -2, D: 0 };
  steps.push({
    type: 'bf-potential',
    nodeColors: { S: 'visited', A: 'processing', B: 'processing', C: 'processing', D: 'processing' },
    edgeColors: {},
    h: { ...h },
    note: 'Bellman–Ford from S yields potentials h(v)',
  });
  const re = [
    { from: 'A', to: 'C', w: 2 + h.A - h.C },
    { from: 'A', to: 'B', w: 4 + h.A - h.B },
    { from: 'B', to: 'C', w: -1 + h.B - h.C },
    { from: 'C', to: 'D', w: 3 + h.C - h.D },
  ];
  re.forEach((e, i) => {
    steps.push({
      type: 'reweight',
      from: e.from,
      to: e.to,
      nodeColors: { [e.from]: 'processing', [e.to]: 'processing' },
      edgeColors: { [`${e.from}-${e.to}`]: 'highlight' },
      w: e.w.toFixed(1),
      idx: i,
    });
  });
  steps.push({
    type: 'dijkstra',
    nodeColors: { A: 'current', C: 'visited', D: 'visited' },
    edgeColors: { 'A-C': 'tree', 'C-D': 'tree' },
    note: 'Run Dijkstra on reweighted graph from A',
  });
  steps.push({ type: 'done', nodeColors: Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function JohnsonsVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: "Johnson's: potentials + reweight + Dijkstra" });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.type}${step.note ? `: ${step.note}` : ''}` });
    const labels = {};
    if (step.h) {
      Object.entries(step.h).forEach(([k, v]) => {
        labels[k] = `h=${v}`;
      });
    }
    if (step.w != null && step.from) {
      labels[step.from] = `w'=${step.w}`;
    }
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: labels,
      queue: step.note ? [step.note] : [],
      stack: [],
      distances: step.h || {},
      visited: [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
