# Load Balancing — Question List (With Complete Answers)

> **Permanent Recall:** 10 MUST-DO questions cover LB fundamentals, L4 vs L7, algorithms, health checks, session persistence, SPOF, and design integration. Every question below has a complete model answer — practice speaking these out loud.

---

## 10 MUST-DO Questions (With Full Answers)

### Q1: What is load balancing and why do we need it?

**Difficulty:** Easy | **Expected time:** 1-2 minutes

**Model Answer:**

*"Load balancing is the practice of distributing incoming network traffic across multiple backend servers. It sits between clients and servers — clients connect to the load balancer's IP, and the LB decides which backend server handles each request.*

*We need it for four reasons:*
1. *Scalability — one server can handle maybe 1000 req/s. We need 10,000? Put 10 servers behind an LB.*
2. *Availability — if one server crashes, the LB detects it via health checks and routes traffic to the remaining servers. Users don't notice.*
3. *Zero-downtime deployment — we can add new servers with updated code, drain connections from old servers, and the LB handles the transition seamlessly.*
4. *Geographic distribution — GSLB routes users to the nearest datacenter, reducing latency.*

*It's essentially a traffic director — it doesn't process requests itself, it just decides where to send them."*

---

### Q2: Explain L4 vs L7 load balancing. When would you use each?

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"L4 and L7 refer to the OSI layer at which the load balancer operates.*

*L4 (Layer 4 — Transport) sees only IP addresses and port numbers. It forwards TCP/UDP packets based on IP:port without inspecting the application payload. Think of it as reading the address on an envelope without opening it. It's fast because there's no HTTP parsing overhead.*

*L7 (Layer 7 — Application) understands HTTP. It reads the full request — URL path, headers, cookies, body. It can make intelligent decisions like routing /api/users to the user service and /api/orders to the order service. It can also terminate SSL, add headers like X-Forwarded-For, and cache responses.*

| | L4 | L7 |
|---|----|----|
| Sees | IP + port | Path, headers, cookies |
| SSL | Pass-through | Terminates at LB |
| Routing | By port | By URL path, header, cookie |
| Speed | Faster | Slower (HTTP parsing) |
| Example | AWS NLB, HAProxy TCP | AWS ALB, Nginx, Envoy |

*I'd use L4 for non-HTTP protocols like database connections (PostgreSQL, Redis) or when I need maximum throughput with minimal latency. I'd use L7 for HTTP APIs and microservices where I need path-based routing, SSL termination, or header-based decisions.*

*In production, we often use both: L4 at the edge for raw TCP distribution, L7 behind it for HTTP-aware routing."*

---

### Q3: Compare Round Robin, Least Connections, and Consistent Hashing.

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"These are three fundamentally different approaches to choosing which server gets the next request.*

*Round Robin cycles through servers in order: S1, S2, S3, S1, S2, S3. It's the simplest algorithm — no state to track, perfectly fair for uniform workloads. I'd use it for stateless REST APIs where requests are short and similar. The downside: it ignores actual server load. If one server is processing a 30-second upload, round robin doesn't know and keeps sending more requests.*

*Least Connections sends each new request to the server with the fewest active connections. It adapts in real time — if Server 1 has 50 active connections and Server 2 has 10, the next request goes to Server 2. I'd use it when request durations vary significantly — file uploads, video processing, database queries. The LB maintains a connection counter per server, incrementing on forward and decrementing on response.*

*Consistent Hashing maps both servers and keys (like user IDs or cache keys) onto a circular ring. Each key goes to the next server clockwise on the ring. The key benefit: when you add or remove a server, only ~1/N of keys get remapped (not all of them like with simple hash % N). I'd use it for distributed caches (memcached, Redis) where remapping all keys would cause a cache miss storm. Virtual nodes (150+ per server) ensure even distribution on the ring.*

| Algorithm | Best For | Key Advantage | Key Weakness |
|-----------|----------|---------------|--------------|
| Round Robin | Stateless APIs | Simplest, no state | Ignores server load |
| Least Connections | Variable-duration requests | Adapts in real-time | Needs connection tracking |
| Consistent Hashing | Cache pools, scale events | Minimal remapping on add/remove | More complex, possible hot spots |

*Quick rule: stateless → RR. Variable duration → LC. Cache → CH."*

---

### Q4: Design a URL shortener. Where does the load balancer fit?

**Difficulty:** Medium | **Expected time:** 3-5 minutes

**Model Answer:**

*"A URL shortener has two main operations: create (write a mapping) and resolve (read a mapping).*

```
Architecture:
  Client → [L7 LB (ALB)] → [API Servers x5] → [Database]
                                    ↓
                              [Redis Cache]
```

*The LB sits between the client and the API servers. I'd use an L7 LB (like ALB or Nginx) because:*
- *We need SSL termination (HTTPS)*
- *We could route /api/shorten to write-optimized servers and /:shortcode to read-optimized servers (optional)*

*Algorithm: Round Robin. Both operations are stateless and fast. No session affinity needed — any server can handle any request.*

*Health checks: Active probe to /health every 5s, 3-failure threshold.*

*For scale: The read path (resolving short URLs) is 100:1 vs writes. We'd cache the mapping in Redis. For the Redis cluster, we'd use consistent hashing so adding cache nodes doesn't invalidate all keys.*

*For HA: ALB runs across multiple AZs. Auto-scaling group behind it scales API servers based on CPU. Database has read replicas with an L4 LB in front for read distribution."*

---

### Q5: Design a chat system. What load balancing considerations apply?

**Difficulty:** Medium | **Expected time:** 3-5 minutes

**Model Answer:**

*"A chat system has unique LB challenges because of WebSocket connections — they're long-lived (minutes to hours), unlike HTTP requests (milliseconds).*

```
Architecture:
  Client → [L7 LB] → [Chat Servers x10]
                            ↓
                       [Redis Pub/Sub] → [Other Chat Servers]
                            ↓
                       [Message DB]
```

*LB considerations:*

*1. WebSocket support: The LB must handle the HTTP → WebSocket upgrade. Not all LBs do this properly. I'd use Nginx, HAProxy, or ALB — all support WebSocket.*

*2. Algorithm: NOT round robin. WebSocket connections stay open for hours. If we use round robin, early connections pile up on earlier servers. I'd use Least Connections so the LB routes new connections to the server with fewest active ones.*

*3. Sticky sessions: When a user reconnects (phone switch, network change), ideally they reconnect to the same server that has their connection context. I'd use consistent hashing on user_id — same user always maps to same server.*

*4. But what if that server dies? Connection state must be in Redis, not just server memory. So any server can pick up where the dead server left off.*

*5. LB idle timeout: Default is often 60 seconds. WebSocket connections are idle between messages. I'd increase the timeout to 300-600 seconds and implement ping/pong heartbeat to keep connections alive.*

*6. Message delivery across servers: User A is on Server 1, User B is on Server 5. When A sends B a message, Server 1 publishes to Redis Pub/Sub, Server 5 receives and pushes to User B via WebSocket."*

---

### Q6: How do health checks work? Active vs passive?

**Difficulty:** Easy | **Expected time:** 1-2 minutes

**Model Answer:**

*"Health checks let the LB know which backend servers are alive and able to serve requests.*

*Active health checks: The LB periodically sends a probe request to each server — typically GET /health every 5-10 seconds. If the server responds 200 OK, it's healthy. If it fails to respond within the timeout (3 seconds), that's counted as a failure. After N consecutive failures (typically 3), the LB marks the server as unhealthy and stops routing traffic to it. Once it starts responding successfully again (typically 2 consecutive successes), the LB adds it back.*

*Passive health checks: The LB monitors real user traffic. If real requests to a server start failing (timeouts, 5xx errors), the LB infers the server is unhealthy. No extra probe traffic, but slower detection — real users experience errors before the LB catches on.*

*Best practice: Use both together. Active catches server crashes quickly (within 15 seconds). Passive catches subtle application issues (like an endpoint returning 500 but the process is still running).*

*One important design choice: The /health endpoint should be lightweight — just return 200 OK if the process is running. Don't make it query the database on every probe, because if the DB is slow, all servers would be marked unhealthy simultaneously, causing total outage."*

---

### Q7: What is session persistence? When do you need it?

**Difficulty:** Medium | **Expected time:** 2 minutes

**Model Answer:**

*"Session persistence (sticky sessions) ensures the same client is always routed to the same backend server. It's needed when the backend stores session state in memory — like login sessions, shopping cart, or in-progress form data.*

*Without sticky sessions: User logs in on Server 1 (session in Server 1's memory). Next request goes to Server 2 (no session) → user is asked to log in again.*

*Three implementation methods:*
1. *Cookie-based: LB sets a cookie (like SERVERID=server1). Browser sends it on every request. LB reads the cookie and routes accordingly. Works even if user's IP changes.*
2. *IP hash: hash(client_IP) → server. Same IP always hits same server. Simple but breaks behind NAT (many users, one IP).*
3. *Consistent hashing on user ID: hash(user_id) → server. Needs the user_id in a header or cookie.*

*However, the better approach is to avoid sticky sessions entirely by making backends stateless. Store sessions in Redis — any server can read any user's session. This allows simple round robin, makes scaling trivial, and if a server dies, no sessions are lost.*

*I'd use sticky sessions only as a fallback when we can't externalize state — for example, legacy applications that store session in server memory."*

---

### Q8: The load balancer is a single point of failure. How do you fix it?

**Difficulty:** Medium | **Expected time:** 2 minutes

**Model Answer:**

*"A single LB is indeed a SPOF. If it crashes, all traffic stops — even though you have 10 perfectly healthy backend servers. The fix is LB redundancy.*

*Option 1: Active-Passive pair. Two LBs share a Virtual IP (VIP). The active LB handles all traffic. The passive monitors via heartbeat. If active fails (3 missed heartbeats), passive takes over the VIP using gratuitous ARP. Clients don't notice because they connect to the VIP, not the specific LB. Tools like keepalived implement this on Linux. Failover takes 1-5 seconds. Downside: passive is idle — 50% hardware 'wasted.'*

*Option 2: Active-Active cluster. Multiple LBs all serve traffic simultaneously. DNS returns multiple IPs (or we use anycast — same IP, BGP routes to nearest). If one LB dies, others absorb the traffic. Better utilization than active-passive. More complex — need shared state or stateless LBs.*

*Option 3: Cloud-managed LB. AWS ALB/NLB runs across multiple availability zones automatically. AWS handles redundancy, failover, and scaling internally. This is the simplest approach if you're on cloud.*

*In practice, for cloud-native applications, I'd use ALB/NLB and let AWS handle HA. For on-premise, I'd run an active-passive Nginx pair with keepalived."*

---

### Q9: Design a scalable REST API. Include load balancing.

**Difficulty:** Medium | **Expected time:** 3-5 minutes

**Model Answer:**

```
Architecture:
  Client → [DNS] → [L7 LB (ALB/Nginx)]
                          │
                  ┌───────┼───────┐
                  ▼       ▼       ▼
              [API-1] [API-2] [API-3]  ← Auto-Scaling Group
                  │       │       │
                  ▼       ▼       ▼
              [Redis Cache (session + hot data)]
                  │
                  ▼
              [Database Primary]
                  │
              [L4 LB] → [Read Replica 1, Read Replica 2]
```

*"Starting from the top:*

*DNS resolves to the L7 LB's IP. I use L7 because we need:*
- *SSL termination (offload HTTPS from backends)*
- *Path-based routing if we split into microservices later*
- *Header injection (X-Forwarded-For for real client IP)*

*Algorithm: Round Robin. REST APIs are stateless — any server handles any request. No session affinity needed because we store session in Redis.*

*Health checks: Active probe to GET /health every 5 seconds. 3-failure unhealthy threshold. 2-success healthy threshold.*

*Auto-scaling: API servers in an ASG. Scale out at CPU > 70%, scale in at CPU < 30%. New instances auto-register with ALB target group.*

*Database scaling: Writes go to primary. Reads go through an L4 LB (HAProxy TCP mode) to read replicas. L4 because PostgreSQL uses binary TCP protocol, not HTTP.*

*For global scale: Add GSLB (Route53 latency-based routing) → each region has its own ALB + ASG + database replica."*

---

### Q10: What happens during a zero-downtime deployment with a load balancer?

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"Zero-downtime deployment uses the LB's connection draining and health check features to smoothly transition from old code to new code without any user seeing an error.*

*Step-by-step flow (rolling deployment):*

1. *We have Servers 1, 2, 3 running v1.0 behind the LB.*
2. *Start deploying v2.0 to Server 1:*
   - *Mark Server 1 as 'draining' in the LB*
   - *LB stops sending NEW requests to Server 1*
   - *In-flight requests on Server 1 continue to completion (drain timeout: 30-60s)*
3. *After drain completes, deploy v2.0 on Server 1 (restart the service)*
4. *Server 1 starts up, begins passing health checks*
5. *LB adds Server 1 back to pool — now running v2.0*
6. *Repeat steps 2-5 for Server 2, then Server 3*
7. *All servers now running v2.0. Zero downtime.*

*Key requirements:*
- *Connection draining must be enabled on the LB (drain timeout ≥ max request duration)*
- *New code must be backward-compatible with old code (during transition, both versions are live)*
- *Health endpoint must correctly reflect readiness (return 200 only when fully started)*

*Alternative: Blue-Green deployment. Run two identical environments (Blue=old, Green=new). Deploy new code to Green. Test Green. Flip LB to route all traffic to Green. If something breaks, flip back to Blue. Faster rollback but requires 2× infrastructure."*

---

## Complete Question List (20+) with Brief Answers

### Fundamentals

| # | Question | Brief Answer |
|---|----------|-------------|
| 1 | What is load balancing? | Distributes traffic across multiple servers for scale, HA, and fault tolerance. Client connects to LB, LB picks backend. |
| 2 | Hardware vs software LB? | Hardware (F5): dedicated ASIC, fast, expensive, inflexible. Software (Nginx, HAProxy): runs on commodity servers, cheap, flexible. Cloud (ALB): managed, auto-scales. |
| 3 | L4 vs L7? | L4: IP/port only, fast, for TCP/UDP. L7: reads HTTP, smart routing, SSL termination, for APIs. |
| 4 | What is a Virtual IP (VIP)? | A floating IP shared between LB instances. Active LB holds it. On failover, passive takes over VIP. Clients always connect to same VIP. |
| 5 | What is GSLB? | Global Server Load Balancing. Routes users to nearest/healthiest datacenter using DNS. Methods: geo-based, latency-based, health-based. |

### Algorithms

| # | Question | Brief Answer |
|---|----------|-------------|
| 6 | Round Robin vs Weighted RR? | RR: equal distribution (S1, S2, S3, repeat). WRR: distribution by weight (4-core server gets 4× traffic of 1-core). Use WRR when servers differ. |
| 7 | When to use Least Connections? | When request durations vary significantly. LC sends to server with fewest active connections. Good for uploads, video, long queries. |
| 8 | IP Hashing — pros and cons? | Pro: same client always hits same server (affinity). Con: users behind NAT all hit one server; adding servers remaps all clients. |
| 9 | Explain Consistent Hashing | Servers and keys on a ring. Key goes to next server clockwise. Add/remove server → only ~1/N keys remap (not all). Used for cache pools. Virtual nodes for even distribution. |
| 10 | Random vs Round Robin? | Random: statistically even over time, no state tracking. RR: deterministically even, simple counter. Both work for uniform loads; RR is more predictable. |

### Health & Session

| # | Question | Brief Answer |
|---|----------|-------------|
| 11 | Active vs passive health checks? | Active: LB probes servers periodically (GET /health). Passive: LB watches real traffic failures. Active is faster detection. Passive has zero extra traffic. Use both. |
| 12 | How do sticky sessions work? | LB routes same client to same server. Cookie-based (LB sets SERVERID cookie), IP hash (hash client IP), or consistent hashing. Needed when backend stores session state. |
| 13 | Session in backend vs Redis? | Backend: simpler but server crash = session lost; scaling requires sticky sessions. Redis: any server serves any user; crash-resilient; scales easily. Redis is preferred. |
| 14 | Health check false positive? | Healthy server marked dead due to GC pause or network blip. Fix: threshold of 3+ failures, longer timeouts, lightweight health endpoint. Can trigger cascade if too sensitive. |

### Design Integration

| # | Question | Brief Answer |
|---|----------|-------------|
| 15 | URL shortener + LB? | L7 LB, round robin, stateless API. Cache in Redis (consistent hashing). Read replicas behind L4 LB. |
| 16 | Chat system + LB? | L7, sticky sessions/consistent hashing, WebSocket support, increased idle timeout, state in Redis for reconnect. |
| 17 | Scalable API + LB? | L7 for path routing + SSL term. RR for stateless. ASG behind LB. Redis for session. Read replicas behind L4 LB. |
| 18 | Video streaming + LB? | CDN for edge delivery. L4 LB at origin with least-conn (transcoding varies). Separate pools for upload vs streaming. |
| 19 | E-commerce + LB? | L7 path routing: /search (stateless, RR), /cart (sticky), /checkout (HTTPS, sticky). Separate service pools. |
| 20 | Microservices + LB? | L7 for path routing at ingress. Service mesh (Envoy sidecar) for inter-service LB. Consistent hashing for caches. |

### Operations & Edge Cases

| # | Question | Brief Answer |
|---|----------|-------------|
| 21 | Zero-downtime deploy? | Rolling deploy: drain old server → deploy new code → health check passes → add back. LB connection draining ensures in-flight requests complete. |
| 22 | LB SPOF solutions? | Active-passive (VIP failover via keepalived), active-active (multiple LBs + DNS/anycast), or cloud-managed (ALB is HA by design). |
| 23 | DNS LB — pros and cons? | Pro: simple, cheap, geographic. Con: no health checks, client caching skews distribution, slow failover. Used as first layer before real LB. |
| 24 | SSL termination at LB — why? | Offloads CPU-intensive encryption from backends. One cert to manage. Simpler backend (plain HTTP). LB can inspect HTTP for routing. |
| 25 | WebSocket with LB? | Need WebSocket-aware LB. Use sticky sessions or consistent hashing. Increase idle timeout. Store state in Redis for reconnect. Least-conn for long-lived distribution. |
| 26 | Cascading failure? | Server removed → others overloaded → more failures → chain reaction. Fix: over-provision (run at 60%), circuit breaker, rate limiting, auto-scaling. |

### Bonus Questions

| # | Question | Brief Answer |
|---|----------|-------------|
| 27 | Reverse proxy vs LB vs API gateway? | Reverse proxy: hides backend, SSL, caching (works with 1 server). LB: reverse proxy + distributes to multiple servers. API gateway: LB + auth + rate limiting + versioning. |
| 28 | How does Nginx handle thousands of connections? | Event-driven architecture. Single-threaded worker uses epoll to handle 10K+ connections. Non-blocking I/O — while waiting for backend response, serves other requests. |
| 29 | What is anycast? | Multiple servers share same IP. BGP routing sends each user to the nearest one. If one dies, BGP routes around it. Used by Cloudflare, Google for global LB. |
| 30 | Connection pooling at LB? | LB maintains persistent connections to backends (keep-alive). Instead of opening new TCP connection for every request, reuses existing ones. Reduces latency and overhead. |

---

## Study Plan

**Week 1: Fundamentals (Q1-5)**
- Understand what LB is, why it exists, HW vs SW, L4 vs L7, VIP, GSLB
- Practice explaining each concept out loud in 1 minute

**Week 2: Algorithms (Q6-10)**
- Understand RR, WRR, LC, IP Hash, Consistent Hashing, Random
- Practice the 5-second decision framework (Affinity? → Duration varies? → Server sizes?)

**Week 3: Health & Session (Q11-14)**
- Understand active vs passive health checks, sticky sessions, session storage
- Practice explaining Redis vs backend session tradeoffs

**Week 4: Design Integration (Q15-20)**
- Practice designing systems with LB placement
- For each system, know: LB type, algorithm, special considerations

**Week 5: Operations & Edge Cases (Q21-30)**
- Zero-downtime deploy, SPOF, cascading failure, WebSocket, reverse proxy vs LB
- These show senior-level thinking in interviews

---

## How to Practice

1. **Read the question** — cover the answer
2. **Speak your answer out loud** (not just in your head)
3. **Compare with model answer** — did you miss anything?
4. **Time yourself** — aim for 1-2 minutes for easy, 2-3 minutes for medium
5. **Draw diagrams** while explaining (practice whiteboard)
6. **Repeat next day** for questions you struggled with

---

## Quick Memory Card

```
MUST-DO:        Q1-10 cover all fundamentals
FUNDAMENTALS:   What is LB, HW vs SW, L4 vs L7, VIP, GSLB
ALGORITHMS:     RR, WRR, LC, IP Hash, Consistent Hash → 5-second decision
HEALTH:         Active (probe) vs Passive (watch traffic) → use both
SESSION:        Redis (best) or Sticky (fallback)
DESIGN:         URL shortener, Chat, API, Video, E-commerce, Microservices
OPS:            Deploy, SPOF, DNS LB, SSL, WebSocket, Cascade
BONUS:          Reverse proxy vs LB vs API gateway, Nginx internals, Anycast
ORDER:          Fundamentals → Algorithms → Health → Design → Ops → Bonus
```

---

**Next:** [[01_Concept]] (cycle back to start for revision)
