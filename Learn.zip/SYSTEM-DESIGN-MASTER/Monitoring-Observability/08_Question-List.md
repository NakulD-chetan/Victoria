# Monitoring and Observability — Question List

> **Permanent Recall:** Master the 10 MUST-DO monitoring questions for FAANG interviews. The full list covers logs, metrics, tracing, alerting, SLOs, health checks, and edge cases. Use this as a checklist—each question tests specific concepts from the Monitoring-Observability notes.

---

## 10 MUST-DO Monitoring Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | What is the difference between monitoring and observability? | Easy | Monitoring vs observability |
| 2 | Explain the three pillars of observability. When would you use each? | Easy | Logs, metrics, traces |
| 3 | What are the four golden signals? Why do they matter? | Easy | Golden signals |
| 4 | Explain RED and USE methods. When to use each? | Medium | RED, USE |
| 5 | How does distributed tracing work? What is trace ID propagation? | Medium | Traces, OpenTelemetry |
| 6 | Design a monitoring stack for a microservices architecture | Medium | Full stack design |
| 7 | How would you avoid alert fatigue? What makes a good alert? | Medium | Alerting strategy |
| 8 | What is the difference between liveness and readiness probes? | Easy | Health checks |
| 9 | Explain SLI, SLO, and SLA. How do they relate? | Easy | SLI/SLO/SLA |
| 10 | How would you handle log volume explosion at 10x scale? | Medium | Log scaling, sampling |

---

## Complete Question List (25+)

### Logging

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 11 | Structured vs unstructured logs. Why prefer structured? | Easy | General |
| 12 | Design a log aggregation pipeline for 1000 services | Medium | FAANG |
| 13 | How does the ELK stack work? What does each component do? | Easy | General |
| 14 | How would you reduce log storage costs at scale? | Medium | General |
| 15 | What is log sampling? When would you use it? | Medium | General |

### Metrics

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 16 | Counter vs gauge vs histogram. When to use each? | Easy | General |
| 17 | What is metrics cardinality? Why is it a problem? | Medium | FAANG |
| 18 | How does Prometheus scrape metrics? Pull vs push model? | Medium | General |
| 19 | Design a dashboard for an API service. What would you include? | Medium | General |
| 20 | What are recording rules in Prometheus? When to use them? | Medium | General |

### Tracing

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 21 | How does OpenTelemetry enable vendor-neutral tracing? | Medium | General |
| 22 | Explain head-based vs tail-based trace sampling | Medium | FAANG |
| 23 | How do you correlate logs with traces? | Easy | General |
| 24 | What happens with clock skew in distributed traces? | Medium | General |

### Alerting & SLOs

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 25 | Alert on symptoms vs causes. Give examples | Medium | General |
| 26 | How would you set up SLO-based alerting? | Medium | FAANG |
| 27 | What causes alert storms? How do you prevent them? | Medium | General |
| 28 | Design an on-call rotation and escalation policy | Medium | General |
| 29 | What is the error budget? How do you use it? | Medium | General |

### Edge Cases & Advanced

| # | Question | Difficulty | Company |
|---|----------|------------|---------|
| 30 | How do you monitor the monitoring system itself? | Medium | General |
| 31 | How would you handle PII in logs? | Medium | FAANG |
| 32 | Compare APM tools (Datadog, New Relic). When to use? | Medium | General |
| 33 | Design monitoring for a serverless architecture | Hard | FAANG |
| 34 | How do you balance observability cost vs value? | Medium | General |

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, definitions |
| **Medium** | Design choice, trade-offs, implementation |
| **Hard** | Scale, architecture, cost trade-offs |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **Monitoring vs observability** | 1 |
| **Three pillars** | 2, 6, 11–15, 16–20, 21–24 |
| **Golden signals** | 3, 19 |
| **RED / USE** | 4, 16 |
| **Distributed tracing** | 5, 21, 22, 23, 24 |
| **Alerting** | 7, 25, 26, 27, 28 |
| **Health checks** | 8 |
| **SLI/SLO/SLA** | 9, 26, 29 |
| **Log scaling** | 10, 12, 14, 15 |
| **Edge cases** | 10, 24, 27, 30, 31 |
| **APM** | 32 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can explain three pillars and when to use each
- [ ] Can explain RED and USE methods
- [ ] Can design a full monitoring stack
- [ ] Can discuss alert strategy (causes, fatigue, SLO)
- [ ] Can explain liveness vs readiness
- [ ] Can explain SLI/SLO/SLA
- [ ] Can handle log volume and trace sampling at scale

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: Monitor vs observability, 3 pillars, golden signals,
            RED/USE, tracing, stack design, alert fatigue,
            health probes, SLI/SLO/SLA, log scaling
FULL LIST: 34+ questions across logs, metrics, traces,
           alerting, SLOs, edge cases
```

---

**Prev: [[07_Tricks-and-Recognition]]**
