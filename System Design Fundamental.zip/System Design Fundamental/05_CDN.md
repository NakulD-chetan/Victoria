# CDN — Content Duniya Bhar Mein Fast Deliver Karo

> **CDN = Content Delivery Network — user ke paas server le jaao, user ko server tak mat bhejo**
> Socho pizza chain ki tarah — har area mein outlet, toh delivery fast!

---

## Table of Contents
1. [CDN Kya Hai?](#1-cdn-kya-hai)
2. [Kyu Zaroori Hai?](#2-kyu-zaroori-hai)
3. [How CDN Works](#3-how-cdn-works)
4. [Push CDN vs Pull CDN](#4-push-cdn-vs-pull-cdn)
5. [CDN Cache Invalidation](#5-cdn-cache-invalidation)
6. [CDN for Different Content Types](#6-cdn-for-different-content-types)
7. [CDN Architecture](#7-cdn-architecture)
8. [CDN Providers](#8-cdn-providers)
9. [When to Use and When NOT](#9-when-to-use-and-when-not)
10. [CDN + Caching Together](#10-cdn--caching-together)
11. [Performance & Cost](#11-performance--cost)
12. [Real-World Examples](#12-real-world-examples)
13. [Interview & Golden Rules](#13-interview--golden-rules)

---

## 1. CDN Kya Hai?

### What Problem This Solves
- **Problem:** User Mumbai se hai, server US mein — images/videos load slow (high latency)
- **Solution:** Content ko user ke paas copy karke rakh do — edge servers

### Why Needed
- Latency kam: User se server door = slow
- Bandwidth bachao: Origin server pe load kam
- Global scale: Duniya bhar users = duniya bhar servers chahiye

### Core Concept
**CDN = Geographically distributed servers that serve cached content from locations close to users**

### Real World Analogy — Food Truck vs Central Kitchen
```
CENTRAL KITCHEN (Origin)     FOOD TRUCKS (CDN Edge)
┌─────────────────────┐      ┌─────┐ ┌─────┐ ┌─────┐
│  Sab kuch yahan     │      │Delhi│ │Mum  │ │Blr  │
│  banata hai         │      │Truck│ │Truck│ │Truck│
│  (Origin Server)    │      └─────┘ └─────┘ └─────┘
└─────────────────────┘           │     │     │
         │                       User ke paas!
         │ Deploy once
         ▼
    Har city mein copy
```

### Internal Working (Step-by-Step)
1. **First Request (Miss):** User → Nearest Edge → Edge empty → Origin fetch → Cache at edge → Return
2. **Next Requests (Hit):** User → Nearest Edge → Cache hit → Return (Origin skip!)
3. **Result:** User ko local se milta hai = fast!

### 1 Minute Recall Block
> CDN = Edge servers user ke paas. Content copy karke rakhna. Origin = source, Edge = delivery.

### 5 Bullet Memory Hooks
- Edge = user ke paas
- Origin = source server
- Copy content globally
- First request = miss to origin
- Next = hit from edge

### ⚠️ Common Interview Trap
**"CDN aur Cache mein difference?"** — CDN = geographic distribution + caching. Cache = any fast storage. CDN is caching + edge locations.

---

## 2. Kyu Zaroori Hai?

### What Problem This Solves
- Global users = global latency problem
- Static assets = high bandwidth
- Origin overload
- Single server = single point of failure

### Why Needed
- **Latency:** Light speed limit — Mumbai to US ~200ms. Edge = local = 10-20ms.
- **Bandwidth:** Origin pe sab traffic = expensive + overload
- **Reliability:** Distributed = koi edge down = others serve
- **Cost:** Edge egress often cheaper than origin egress

### Why CDN Matters
| Without CDN | With CDN |
|-------------|----------|
| User Mumbai → Server US (200ms+) | User Mumbai → Edge Mumbai (10ms) |
| Origin handles all requests | Edge handles 90%+ |
| Single point of failure | Distributed |
| High bandwidth cost at origin | Bandwidth at edge (cheaper) |

### Real World Example
```
Netflix without CDN: 
  User India → Stream from US server = buffering, lag

Netflix with CDN (Open Connect):
  User India → Local ISP cache = instant play
```

### Interview Questions
- "CDN kyu zaroori hai global apps ke liye?"
- "CDN use na karein toh kya problem?"

### Follow-up Questions
- "Latency kaise measure karte ho?"
- "CDN cost vs origin bandwidth cost?"

### Common Mistakes
- CDN only US/Europe pe (India/Asia ignore)
- Origin pe direct traffic allow (CDN bypass)
- CDN ko load balancer samajhna

### Quick Recall Summary
CDN = latency kam, bandwidth bachao, origin protect, global reliability.

### 1 Minute Recall Block
> CDN = latency kam, bandwidth bachao, origin protect, global scale.

---

## 3. How CDN Works

### Core Concept
**Edge servers = mini copies of origin. User request = nearest edge serves.**

### Architecture Diagram
```
                    CDN FLOW
═══════════════════════════════════════════════════════

[User - Mumbai]          [User - Delhi]          [User - London]
      │                         │                        │
      │ 1. Request image        │                        │
      ▼                         ▼                        ▼
┌──────────┐              ┌──────────┐              ┌──────────┐
│ Edge     │              │ Edge     │              │ Edge     │
│ Mumbai   │              │ Delhi    │              │ London   │
└────┬─────┘              └────┬─────┘              └────┬─────┘
     │                         │                        │
     │ 2. Cache MISS           │ 2. Cache HIT           │
     │    Fetch from origin    │    Serve from cache    │
     ▼                         │                        │
┌─────────────────────────────────────────────────────────────┐
│                    ORIGIN SERVER                             │
│              (Your actual server / S3)                       │
└─────────────────────────────────────────────────────────────┘
```

### Cache Hierarchy
```
User Request
    │
    ▼
Edge (L1) ── Miss ──▶ Regional (L2) ── Miss ──▶ Origin
    │                      │
    Hit                    Hit
    │                      │
    ▼                      ▼
  Return                Return
```

### Interview Questions
- "CDN internally kaise kaam karta hai?"
- "Edge server user ko kaise select karta hai?"

### Follow-up Questions
- "DNS role CDN mein?"
- "Anycast kya hai?" (Same IP, nearest server responds)

### Quick Recall Summary
User → DNS (nearest edge) → Edge → Hit/Miss → Origin if miss. Hierarchy: Edge → Regional → Origin.

### 1 Minute Recall Block
> Request → Nearest edge → Hit = return. Miss = origin fetch → cache → return.

### 5 Bullet Memory Hooks
- DNS = edge selection
- Anycast = same IP, nearest
- Hierarchy = edge→regional→origin
- First = miss
- Rest = hit

---

## 4. Push CDN vs Pull CDN

### What Problem
Content CDN pe kaise aata hai? Push (you send) vs Pull (CDN fetches)

### Comparison Table
| Aspect | Push CDN | Pull CDN |
|--------|----------|----------|
| Who uploads? | You push to CDN | CDN pulls on first request |
| When cached? | Before any request | On first request (lazy) |
| Use case | Known content, pre-release | Dynamic, unpredictable |
| Control | Full — you decide what | CDN decides on demand |
| Example | Movie before launch | User uploads, blog images |

### Push CDN — Step by Step
```
1. You upload file to CDN
2. CDN distributes to all edge locations
3. User request → Edge has it → Instant
4. Use: Movie release, game update, known assets
```

### Pull CDN — Step by Step
```
1. User requests https://cdn.example.com/image.jpg
2. Edge doesn't have it → Fetch from origin
3. Cache at edge for next time
4. Return to user
5. Use: Dynamic content, user uploads
```

### ASCII Diagram
```
PUSH CDN:                    PULL CDN:
┌──────┐    Upload     ┌─────┐    Request    ┌──────┐
│ You  │─────────────▶│ CDN │◀──────────────│ User │
└──────┘               └──┬──┘               └──────┘
                          │                        │
                          │    Fetch on miss       │
                          ▼                        ▼
                     ┌─────────┐              ┌─────────┐
                     │ Origin  │              │ Origin  │
                     └─────────┘              └─────────┘
```

### 1 Minute Recall Block
> Push = you send before request. Pull = CDN fetches on first request. Most use Pull.

### 5 Bullet Memory Hooks
- Push = pre-upload
- Pull = on-demand
- Push = known content
- Pull = dynamic
- Pull = default choice

---

## 5. CDN Cache Invalidation

### What Problem
File update kiya origin pe — CDN pe purani copy. Kaise fresh karein?

### Strategies
| Strategy | How | Use Case |
|----------|-----|----------|
| TTL | Cache for X time, then refresh | General |
| Purge | Manual invalidate specific URL | Urgent fix |
| Version in URL | `style.css?v=2` — new URL = new fetch | Best practice |
| Invalidation API | Call CDN API to purge | Deploy time |

### Best Practice: Version in URL
```
Bad:  /images/logo.png        (always cached, hard to update)
Good: /images/logo.png?v=2    (update version = cache bypass)
Good: /images/logo.abc123.png (hash in filename)
```

### Invalidation Strategies Comparison
| Strategy | Pros | Cons |
|----------|------|------|
| TTL | Automatic, no API | Stale until TTL |
| Purge API | Instant | Cost, rate limits |
| Version URL | No purge needed | URL change required |
| Cache-Control headers | Origin controls | Must set correctly |

### Interview Questions
- "CDN pe file update kiya — purani dikh rahi hai. Fix?"
- "Cache busting kaise karte ho?"

### Follow-up Questions
- "Purge all vs purge specific URL?"
- "TTL set kaise karein — balance?"

### Common Mistakes
- Update file, same URL — users get stale
- Purge too frequently — cost + origin load
- No version in build — deploy = stale cache
- TTL too long for changing content

### Quick Recall Summary
Invalidation: TTL (auto), Purge (manual), Version URL (best). Always version static assets.

### 1 Minute Recall Block
> Invalidation: TTL, purge API, or version in URL. Version in URL = cache busting.

---

## 6. CDN for Different Content Types

### Content Type Table
| Type | Examples | CDN Fit | Notes |
|------|----------|---------|-------|
| Static | Images, JS, CSS, fonts | Perfect | Long TTL, high cache hit |
| Dynamic | API responses, personalized | Tricky | Short TTL or bypass |
| Video | Streaming, VOD | Great | Chunked, edge caching |
| Live | Live stream | Special | Real-time, low latency |

### Static Content
- **Best for CDN:** Images, CSS, JS, fonts
- **TTL:** Days to weeks
- **Why:** Same for all users, rarely changes

### Dynamic Content
- **Challenge:** User-specific, changes often
- **Approach:** Short TTL, or don't cache at CDN (cache at app layer)
- **Example:** "Hello User X" — can't cache at edge

### Video Streaming
- **How:** Chunked (HLS, DASH) — each chunk cached
- **TTL:** Long for VOD, short for live
- **Netflix/YouTube:** Heavy CDN use

### Live Streaming
- **Challenge:** Real-time, can't pre-cache
- **Approach:** Edge pe live chunks cache (few seconds), then expire
- **Example:** Sports stream, news live

### Content Strategy Table
| Content | TTL | CDN Layer | Bypass? |
|---------|-----|-----------|---------|
| Logo, favicon | 1 year | Edge | No |
| JS, CSS (versioned) | 1 year | Edge | No |
| User avatar | 1 day | Edge | No |
| API response | 0 / Short | App cache | Yes |
| Personalized page | 0 | - | Yes |

### Interview Questions
- "Video streaming CDN pe kaise work karta hai?"
- "Dynamic content CDN pe cache karte ho?"
- "Live stream vs VOD — CDN strategy?"

### Follow-up Questions
- "HLS/DASH kya hai?"
- "Adaptive bitrate CDN se kaise related?"

### Common Mistakes
- Dynamic content long TTL (stale)
- Static content no CDN (slow)
- Personalization at CDN (wrong layer)
- Video without chunking (inefficient)

### Quick Recall Summary
Static = long TTL, edge. Dynamic = short or bypass. Video = chunked. Live = minimal cache.

### 1 Minute Recall Block
> Static = CDN perfect. Dynamic = short TTL or bypass. Video = chunked caching.

---

## 7. CDN Architecture

### Edge → Regional → Origin
```
                    HIERARCHY
                    
[Edge Servers]  ← PoP (Point of Presence) - 100s globally
      │
      │ Miss
      ▼
[Regional Cache] ← Fewer, larger
      │
      │ Miss
      ▼
[Origin] ← Your server / S3 / GCS
```

### Real World
- **CloudFront:** 400+ edge locations
- **Cloudflare:** 300+ cities
- **Akamai:** 4000+ servers

### PoP (Point of Presence)
- **Kya hai:** Har major city mein CDN ka server
- **Kaam:** User request → Nearest PoP → Low latency
- **Example:** User Delhi → Delhi PoP. User Mumbai → Mumbai PoP.

### 1 Minute Recall Block
> Edge (many) → Regional (few) → Origin (one). Miss propagates up.

### 5 Bullet Memory Hooks
- PoP = edge location
- Many edges globally
- Miss = up the chain
- Origin = single source
- Geographic distribution

---

## 8. CDN Providers

### Comparison Table
| Provider | Strengths | Use Case |
|----------|-----------|----------|
| AWS CloudFront | AWS integration, S3 origin | AWS ecosystem |
| Cloudflare | DDoS protection, free tier | Security + CDN |
| Akamai | Enterprise, video | Large scale |
| Fastly | Real-time purge, edge compute | Dynamic content |
| Google Cloud CDN | GCP integration | GCP ecosystem |

### Decision Tree
```
AWS stack? ──Yes──▶ CloudFront
Need DDoS protection? ──Yes──▶ Cloudflare
Video at scale? ──Yes──▶ Akamai
Real-time invalidation? ──Yes──▶ Fastly
```

### 1 Minute Recall Block
> CloudFront, Cloudflare, Akamai, Fastly. Choose by ecosystem and needs.

---

## 9. When to Use and When NOT

### When to Use CDN
- Static assets (images, JS, CSS)
- Global user base
- High traffic
- Video/audio streaming
- Software downloads

### When NOT to Use CDN
- Single region users only
- Highly dynamic/personalized
- Real-time data (stock prices)
- Small traffic (overkill)
- Sensitive data (extra hop = risk)

### 1 Minute Recall Block
> Use: static, global, high traffic. Don't: single region, real-time, sensitive.

---

## 10. CDN + Caching Together

### Multi-Layer Approach
```
User
  │
  ▼ Layer 1: Browser Cache
  │
  ▼ Layer 2: CDN Edge Cache
  │
  ▼ Layer 3: Application Cache (Redis)
  │
  ▼ Layer 4: Database
```

### How They Work Together
- **Browser:** Same user, repeat visit — instant
- **CDN:** Same asset, different users — fast
- **App Cache:** API response, shared — DB save
- **DB:** Source of truth

### Request Flow Example
```
User requests logo.png:
1. Browser cache? → Hit = 0ms
2. CDN edge? → Hit = 20ms
3. App cache? → N/A (static)
4. Origin? → Miss = 100ms

First user: 100ms (origin)
Second user same city: 20ms (CDN)
Same user again: 0ms (browser)
```

### 1 Minute Recall Block
> CDN = edge layer. Works with browser cache, app cache. Multi-layer = max speed.

### 5 Bullet Memory Hooks
- Browser = per user
- CDN = per region
- App = shared
- Layer by layer
- Max cache = max speed

---

## 11. Performance & Cost

### Performance Tips
1. **Version URLs** — Cache busting on update
2. **Compress** — Gzip/Brotli at edge
3. **HTTP/2** — Multiplexing
4. **Preconnect** — DNS prefetch
5. **Right TTL** — Balance freshness vs hit rate

### Cost Considerations
| Factor | Impact |
|--------|--------|
| Data transfer out | CDN cheaper than origin |
| Requests | Per-request pricing |
| Invalidation | Purge calls may cost |
| Region | Some regions costlier |
| Free tier | Cloudflare free, CloudFront 1TB free first year |

### Cost Optimization Tips
1. **Compress:** Gzip/Brotli — 70% size reduction
2. **Right TTL:** Longer = fewer origin hits = cheaper
3. **Cache hit rate:** Monitor — low hit = wrong config
4. **Region:** Expensive regions avoid if possible
5. **Purge wisely:** Don't purge all — purge specific paths

### 1 Minute Recall Block
> Optimize: compress, version, right TTL. Cost: egress, requests.

### 5 Bullet Memory Hooks
- Compress = smaller = cheaper
- TTL = balance
- Hit rate = monitor
- Purge = cost
- Free tiers exist

---

## 12. Real-World Examples

### Netflix Open Connect
- **What:** Netflix ka own CDN — ISPs ke paas servers
- **Why:** Video = huge bandwidth, ISP pe cache = fast + cheap
- **How:** Netflix content ISPs ko push karta hai, users local se stream

### YouTube
- **What:** Google global CDN (same as Google)
- **How:** Video chunks edge pe, adaptive bitrate
- **Scale:** Billions of videos, global delivery

### 1 Minute Recall Block
> Netflix = ISP-level CDN. YouTube = Google CDN. Both = video at scale.

---

## 13. Interview & Golden Rules

### Interview Questions
- "CDN kya hai aur kyu use karte hain?"
- "Push vs Pull CDN — difference?"
- "CDN cache invalidation kaise?"
- "Static vs dynamic content — CDN strategy?"
- "Netflix/YouTube CDN kaise use karte hain?"

### Follow-up Questions
- "CDN fail ho jaye — fallback?"
- "Cost optimize kaise?"
- "Edge compute kya hai?"

### Golden Rules
1. Static content = CDN use karo
2. Version in URL = cache invalidation easy
3. TTL set karo — balance freshness
4. Multi-layer caching = CDN + app cache
5. Origin protect karo — CDN absorbs traffic
6. Choose provider by ecosystem
7. Monitor hit rate
8. Don't CDN for real-time/sensitive

### Common Mistakes
| Mistake | Fix |
|---------|-----|
| No version in URL | Update = stale cache |
| CDN for dynamic | Wrong layer |
| No TTL | Stale forever |
| Single CDN region | Global users suffer |
| Ignoring purge cost | Budget overflow |

### ⚠️ Common Interview Trap
**"CDN vs Load Balancer?"** — CDN = geographic distribution + cache. LB = traffic distribution to servers. Different purposes. CDN can sit in front of LB.

### 1 Minute Recall Block
> CDN = edge + cache + global. Static = perfect. Version URLs. Multi-layer with app cache.

### 5 Bullet Memory Hooks
- Edge = user ke paas
- Push vs Pull
- Static = best fit
- Version URLs
- Multi-layer

---

**END OF CDN NOTES — Ab tum CDN samajh gaye ho! 🌍**
