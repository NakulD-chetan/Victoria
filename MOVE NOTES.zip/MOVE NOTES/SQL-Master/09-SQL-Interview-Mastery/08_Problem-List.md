# SQL Interview Mastery — MEGA Problem List

> **50 LeetCode SQL problems. 15 MUST-DO highlighted. The complete FAANG SQL preparation list organized by pattern.**

---

## 15 MUST-DO Problems (If You Solve Nothing Else)

| # | Problem | Difficulty | LC# | Pattern | Why MUST-DO |
|---|---------|-----------|------|---------|-------------|
| 1 | Customers Who Never Order | Easy | 183 | Anti-join | #1 most-asked easy |
| 2 | Employees Earning > Managers | Easy | 181 | Self-join | Foundation comparison |
| 3 | Second Highest Salary | Medium | 176 | Ranking + NULL | NULL edge case classic |
| 4 | Nth Highest Salary | Medium | 177 | Parameterized rank | Generalized ranking |
| 5 | Rank Scores | Medium | 178 | DENSE_RANK | Purest ranking |
| 6 | Consecutive Numbers | Medium | 180 | LAG / consecutive | Pattern detection |
| 7 | Department Highest Salary | Medium | 184 | Top-1 per group | Partition + MAX |
| 8 | Department Top Three Salaries | Hard | 185 | Top-N per group | THE FAANG classic |
| 9 | Rising Temperature | Easy | 197 | Self-join + date | Day-over-day |
| 10 | Trips and Users | Hard | 262 | Multi-filter ratio | Complex real-world |
| 11 | Human Traffic of Stadium | Hard | 601 | Island / consecutive | 3+ consecutive |
| 12 | Confirmation Rate | Medium | 1934 | AVG(CASE WHEN) | Ratio computation |
| 13 | Average Selling Price | Medium | 1251 | Weighted average | SUM(p*q)/SUM(q) |
| 14 | Game Play Analysis IV | Medium | 550 | Retention | First login + next day |
| 15 | Restaurant Growth | Medium | 1321 | Rolling window | 7-day moving sum |

---

## Complete 50-Problem FAANG Preparation

### Tier 1: Foundation (Problems 1-15) — Easy

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Recyclable and Low Fat Products | 1757 | WHERE | Basic filter |
| 2 | Find Customer Referee | 584 | NULL in WHERE | IS NULL trap |
| 3 | Big Countries | 595 | OR | Multi-condition |
| 4 | Article Views I | 1148 | DISTINCT | Self-equality |
| 5 | Invalid Tweets | 1683 | String function | CHAR_LENGTH |
| 6 | Combine Two Tables | 175 | LEFT JOIN | Optional join |
| 7 | Employees Earning > Managers | 181 | Self-join | Compare rows |
| 8 | Customers Who Never Order | 183 | Anti-join | LEFT … IS NULL |
| 9 | Duplicate Emails | 182 | GROUP + HAVING | Find duplicates |
| 10 | Delete Duplicate Emails | 196 | DELETE + self-join | DML |
| 11 | Rising Temperature | 197 | Self-join + date | DATEDIFF |
| 12 | Calculate Special Bonus | 1873 | CASE WHEN | Conditional logic |
| 13 | Fix Names in a Table | 1667 | String | UPPER/LOWER/SUBSTR |
| 14 | Students and Examinations | 1280 | CROSS + LEFT | Complete grid |
| 15 | Employee Bonus | 577 | LEFT JOIN + NULL | Optional + filter |

### Tier 2: Core FAANG (Problems 16-35) — Medium

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 16 | Second Highest Salary | 176 | Rank + NULL | IFNULL + OFFSET |
| 17 | Nth Highest Salary | 177 | Parameterized | CREATE FUNCTION |
| 18 | Rank Scores | 178 | DENSE_RANK | No-gap ranking |
| 19 | Consecutive Numbers | 180 | LAG | 3 same in a row |
| 20 | Department Highest Salary | 184 | Top-1 partition | MAX per group |
| 21 | Managers with ≥ 5 Reports | 570 | Self-join + HAVING | Count children |
| 22 | Investments in 2016 | 585 | Double IN | Shared + unique |
| 23 | Exchange Seats | 626 | CASE + window | Swap rows |
| 24 | Swap Salary | 627 | UPDATE CASE | In-place swap |
| 25 | Game Play Analysis I | 511 | MIN per group | First event |
| 26 | Game Play Analysis IV | 550 | CTE + retention | Day-after login |
| 27 | Biggest Single Number | 619 | HAVING + MAX | Unique then max |
| 28 | Average Selling Price | 1251 | Weighted avg | SUM(p*q)/SUM(q) |
| 29 | Queries Quality and Percentage | 1211 | AVG(CASE) | Conditional mean |
| 30 | Monthly Transactions I | 1193 | Multi-CASE agg | Multiple conditional aggs |
| 31 | Confirmation Rate | 1934 | AVG(CASE) ratio | Fraction confirmed |
| 32 | Immediate Food Delivery II | 1174 | CTE first + ratio | First order check |
| 33 | Product Price at Given Date | 1164 | ROW_NUMBER + default | Last change before cutoff |
| 34 | Restaurant Growth | 1321 | SUM OVER frame | 7-day rolling |
| 35 | Last Person to Fit in Bus | 1204 | Running SUM | Cumulative ≤ limit |

### Tier 3: Hard — Interview Differentiators (Problems 36-50)

| # | Problem | LC# | Pattern | Key Skill |
|---|---------|-----|---------|-----------|
| 36 | Department Top Three Salaries | 185 | DENSE_RANK top-N | THE classic hard |
| 37 | Trips and Users | 262 | Multi-filter ratio | Cancel rate |
| 38 | Human Traffic of Stadium | 601 | Island consecutive | 3+ rows ≥ 100 |
| 39 | Friend Requests II | 602 | UNION + COUNT | Symmetric count |
| 40 | Median Employee Salary | 569 | ROW_NUMBER median | Middle row(s) |
| 41 | Find Cumulative Salary | 579 | Rolling 3-month | Excl latest month |
| 42 | Average Salary: Dept vs Company | 615 | CTE compare | Dept avg vs overall |
| 43 | Report Contiguous Dates | 1225 | Island grouping | Date ranges |
| 44 | Find Start/End Continuous Ranges | 1285 | ROW_NUMBER diff | Range detection |
| 45 | Movie Rating | 1341 | UNION ALL + ROW_NUM | Top-1 per category |
| 46 | Active Businesses | 1126 | AVG + filter | Above-avg events |
| 47 | Tournament Winners | 1194 | CTE chain | Multi-step rank |
| 48 | Biggest Window Between Visits | 1709 | LEAD gap | Gap between visits |
| 49 | Quiet Students in All Exams | 1412 | MIN/MAX rank | Never top/bottom |
| 50 | Longest Winning Streak | 2173 | Island + count | Consecutive wins |

---

## Problem-by-Problem Strategy Notes

### Problem 8: Customers Who Never Order (LC 183)
```
Pattern: Anti-join
Key: LEFT JOIN orders … WHERE orders.id IS NULL
Alt: WHERE id NOT IN (SELECT customerId FROM Orders)
Time: 3 minutes | Difficulty: Easy
```

### Problem 16: Second Highest Salary (LC 176)
```
Pattern: Ranking + NULL
Key: IFNULL((SELECT DISTINCT salary ORDER BY salary DESC LIMIT 1 OFFSET 1), NULL)
Trap: Must return NULL if only one salary exists
Time: 5 minutes | Difficulty: Medium
```

### Problem 36: Department Top Three Salaries (LC 185)
```
Pattern: Top-N per group
Key: WITH cte AS (SELECT *, DENSE_RANK() OVER (PARTITION BY dept ORDER BY sal DESC) AS rk)
     SELECT * FROM cte WHERE rk <= 3
Time: 10 minutes | Difficulty: Hard
```

### Problem 37: Trips and Users (LC 262)
```
Pattern: Multi-filter ratio
Key: Exclude banned users → GROUP BY day →
     ROUND(SUM(CASE WHEN status LIKE 'cancelled%' THEN 1 ELSE 0 END) / COUNT(*), 2)
Time: 15 minutes | Difficulty: Hard
```

### Problem 38: Human Traffic of Stadium (LC 601)
```
Pattern: Island detection
Key: id - ROW_NUMBER() OVER (ORDER BY id) = constant for consecutive ids ≥ 100
     GROUP BY island → HAVING COUNT(*) >= 3 → join back to get all rows
Time: 15 minutes | Difficulty: Hard
```

### Problem 43: Report Contiguous Dates (LC 1225)
```
Pattern: Island grouping on dates
Key: date - ROW_NUMBER gives same grp for consecutive dates
     Separate by state type, group, find MIN/MAX date per island
Time: 20 minutes | Difficulty: Hard
```

---

## Pattern Distribution (all 50)

```
ANTI-JOIN / MISSING:        5 problems  (8, 15, 6, 22, 49)
SELF-JOIN:                  5 problems  (7, 9, 11, 14, 21)
RANKING (DENSE_RANK/RN):   8 problems  (16-18, 20, 36, 40, 45, 47)
LAG/LEAD/OFFSET:           5 problems  (19, 34, 35, 41, 48)
GROUP + HAVING:             6 problems  (9, 21, 22, 27, 39, 46)
AVG(CASE) RATIO:           4 problems  (29, 31, 32, 37)
ISLAND / CONSECUTIVE:      5 problems  (38, 43-44, 49-50)
STRING / DATE / CASE:      5 problems  (4-5, 12-13, 23-24)
WINDOW FRAME:              4 problems  (34-35, 41, 48)
WEIGHTED AVG:              2 problems  (28, 42)
CTE PIPELINE:              6 problems  (26, 32-33, 42, 43, 47)
```

---

## 6-Week Study Plan

### Week 1: Easy Foundation (Tier 1)
- Day 1-2: Problems 1-5 (SELECT, WHERE, NULL)
- Day 3-4: Problems 6-10 (JOIN, anti-join, DML)
- Day 5-6: Problems 11-15 (self-join, CASE, CROSS JOIN)

### Week 2: Medium Core — Ranking & Joins (Tier 2a)
- Day 1-2: Problems 16-19 (2nd highest, rank, consecutive)
- Day 3-4: Problems 20-24 (dept highest, self-join, exchange, swap)
- Day 5-6: Problems 25-27 (game play, biggest single)

### Week 3: Medium Core — Aggregation (Tier 2b)
- Day 1-2: Problems 28-30 (weighted avg, conditional agg)
- Day 3-4: Problems 31-33 (ratios, first-order, price at date)
- Day 5-6: Problems 34-35 (rolling sum, cumulative limit)

### Week 4: Hard — FAANG Favorites
- Day 1-2: Problems 36-38 (top-3 dept, trips, stadium)
- Day 3-4: Problems 39-42 (friends, median, cumulative, dept vs co)
- Day 5-6: Problems 43-45 (contiguous dates, ranges, movie)

### Week 5: Hard — Advanced Patterns
- Day 1-2: Problems 46-48 (active business, tournament, visit gap)
- Day 3-4: Problems 49-50 (quiet students, winning streak)
- Day 5-6: **Revisit** MUST-DO 15 — timed practice

### Week 6: Mock Interview
- Day 1-2: Random pick 3 easy + 2 medium (30 min each)
- Day 3-4: Random pick 2 medium + 1 hard (45 min each)
- Day 5-6: Full mock — 4 problems in 2 hours

---

## Cross-Reference: Which Template for Which Problem

| Template | Problems |
|----------|----------|
| T1: Top-N per group | 20, 36, 40, 45, 47 |
| T2: Ratio / rate | 29, 31, 32, 37 |
| T3: Anti-join | 6, 8, 15, 22 |
| T4: Running total | 34, 35, 41 |
| T5: Consecutive | 19, 38, 50 |
| T6: Island / gap | 43, 44 |
| T7: Weighted avg | 28, 42 |
| T8: Self-comparison | 7, 9, 11, 48 |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     50 (15 Easy, 20 Medium, 15 Hard)
MUST-DO 15:         LC 183, 181, 176, 177, 178, 180, 184, 185, 197,
                    262, 601, 1934, 1251, 550, 1321
TOP 5 MOST ASKED:   LC 185 (Top 3 Dept), LC 178 (Rank), LC 262 (Trips),
                    LC 183 (Never Order), LC 180 (Consecutive)
8 TEMPLATES:        Top-N, Ratio, Anti-join, Running, Consecutive,
                    Island, Weighted Avg, Self-compare
STUDY ORDER:        Easy foundations → Ranking → GROUP+HAVING →
                    Window → CTE → Island/Gap → Timed mocks
INTERVIEW LINE:     "I identify the pattern (top-N, ratio, anti-join, island),
                     pick the right template, handle NULLs and ties,
                     and mention indexing for optimization."
```

---

## 30-SECOND REVISION BOX

```
ANTI-JOIN:      LC 183  — LEFT JOIN … IS NULL
2ND HIGHEST:    LC 176  — IFNULL + OFFSET 1
RANK:           LC 178  — DENSE_RANK() OVER (ORDER BY score DESC)
CONSECUTIVE:    LC 180  — LAG(val,1) = val AND LAG(val,2) = val
TOP-N:          LC 185  — DENSE_RANK PARTITION BY dept ≤ 3
CANCEL RATE:    LC 262  — AVG(CASE cancelled THEN 1 ELSE 0) excl banned
ISLAND:         LC 601  — id - ROW_NUMBER = constant for consecutive
ROLLING:        LC 1321 — SUM OVER (ORDER BY date ROWS 6 PRECEDING)
RETENTION:      LC 550  — first_login CTE + check day+1
WEIGHTED:       LC 1251 — SUM(price*qty) / SUM(qty)
RATIO:          LC 1934 — AVG(CASE WHEN confirmed THEN 1 ELSE 0 END)
```
