# Availability and Reliability — Edge Cases

> **Permanent Recall:** Edge cases that break HA: cascading failures (one failure triggers chain), split brain (both primaries active during failover), data loss during failover (RPO violation), false positive health checks (good server marked dead), thundering herd on recovery (everyone reconnects at once), correlated failures (same rack/AZ), DNS propagation delay during failover, certificate expiry causing outage. Each has specific mitigations.

---

## Edge Case 1: Cascading Failures

**Scenario:** One component fails → load shifts to others → they overload → fail → chain reaction.

```
DB replica fails → primary gets 2× read load
Primary overloads → connection pool exhausted
App servers can't get connections → timeouts
Users retry → more load → complete outage
```

| Mitigation | How |
|------------|-----|
| Circuit breaker | Stop sending traffic when error rate exceeds threshold |
| Over-provisioning | Headroom so remaining nodes handle load |
| Backpressure | Reject early rather than overload |
| Gradual degradation | Disable non-critical features under load |

> **FAANG Tip:** "Cascading failure" — mention circuit breaker and headroom. Interviewers love this.

---

## Edge Case 2: Split Brain During Failover

**Scenario:** Network partition; both primary and standby think they're primary. Writes to both → data divergence.

```
    Network partition
         │
    ┌────┴────┐
    ▼         ▼
Primary A   Standby B
(serving)   (promoted)
    │           │
    │  Both accept writes
    │  Data diverges
```

| Mitigation | How |
|------------|-----|
| Quorum / consensus | Majority must agree on leader (Paxos, Raft) |
| Fencing | Old primary receives "STONITH" (shoot the other node) |
| Tie-breaker | Third witness (arbiter) to break split |
| App-level | Last-write-wins with conflict resolution (complex) |

---

## Edge Case 3: Data Loss During Failover (RPO Violation)

**Scenario:** Async replication; primary fails before last batch replicated. Standby promotes with missing data.

```
Primary: W1 W2 W3 W4 ──X (crash)
                │
Standby:  W1 W2 W3     (W4 lost)
```

| Mitigation | How |
|------------|-----|
| Sync replication | Wait for ack from standby (higher latency) |
| Semi-sync | Wait for 1 replica (balance) |
| Accept RPO | Document; restore from backup if needed |
| WAL replay | Recover unsent WAL from primary if possible |

---

## Edge Case 4: False Positive Health Checks

**Scenario:** Healthy server marked dead (transient network blip, GC pause). Removed from pool → remaining overloaded.

| Cause | Mitigation |
|-------|------------|
| Single failure = unhealthy | Threshold (e.g., 3 consecutive failures) |
| Aggressive timeout | Increase timeout; separate health from traffic timeout |
| Health check hits heavy path | Dedicated lightweight `/health` |
| GC pause during check | Health endpoint skips heavy logic |

---

## Edge Case 5: Thundering Herd on Recovery

**Scenario:** Service comes back after outage. All clients reconnect at once → stampede → overload → fails again.

```
t=0:  Service recovers
t=1:  10,000 clients try to reconnect
t=2:  Service overloaded → fails
t=3:  Clients retry → repeat
```

| Mitigation | How |
|------------|-----|
| Gradual rollout | Add instances slowly; drain into pool gradually |
| Exponential backoff | Clients spread retries over time |
| Connection limits | Cap connections per client |
| Queue / admission control | Rate limit reconnects |

---

## Edge Case 6: Correlated Failures (Same Rack/AZ)

**Scenario:** "Redundant" servers in same rack. Rack power fails → all down. Same AZ outage → all instances in AZ down.

| Mitigation | How |
|------------|-----|
| Spread across AZs | Deploy in multiple availability zones |
| Spread across racks | Anti-affinity rules (where supported) |
| Multi-region | For region-level disasters |

---

## Edge Case 7: DNS Propagation Delay During Failover

**Scenario:** Failover to DR region. DNS updated. Clients cache old IP for minutes/hours. Traffic still goes to dead region.

```
Failover complete
DNS updated: api.example.com → DR IP
Clients cache: api.example.com → Old IP (TTL 1 hour)
Result: Many clients still hit old (down) region
```

| Mitigation | How |
|------------|-----|
| Low TTL | Reduce DNS TTL before failover (e.g., 60s) |
| Pre-failover TTL reduction | Lower TTL days before planned DR test |
| Client retry | Retry on connection failure; may get new DNS |
| Anycast | Same IP everywhere; BGP handles routing |

---

## Edge Case 8: Certificate Expiry Causing Outage

**Scenario:** SSL cert expires. HTTPS breaks. Service "available" but unusable.

| Mitigation | How |
|------------|-----|
| Auto-renewal | ACME (Let's Encrypt), Certbot, cloud cert manager |
| Monitoring | Alert 30 days before expiry |
| Centralized store | Vault, AWS ACM—single source of truth |
| Runbook | Document renewal process |

---

## Edge Case Summary Table

| Edge Case | Symptom | Mitigation |
|-----------|---------|------------|
| Cascading failure | One failure → chain | Circuit breaker, headroom |
| Split brain | Two primaries | Quorum, fencing |
| Data loss on failover | RPO violated | Sync/semi-sync replication |
| False positive health | Good server marked dead | Threshold, lightweight health |
| Thundering herd | Stampede on recovery | Gradual rollout, backoff |
| Correlated failure | Same rack/AZ down | Multi-AZ, anti-affinity |
| DNS propagation | Old IP cached | Low TTL, anycast |
| Cert expiry | HTTPS breaks | Auto-renew, monitor |

---

## Quick Memory Card

```
CASCADE:     Circuit breaker, headroom
SPLIT BRAIN: Quorum, fencing
DATA LOSS:   Sync replication, accept RPO
FALSE HEALTH: Threshold, lightweight endpoint
THUNDERING:  Gradual rollout, backoff
CORRELATED:  Multi-AZ, spread
DNS:         Low TTL, anycast
CERT:        Auto-renew, alert
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
