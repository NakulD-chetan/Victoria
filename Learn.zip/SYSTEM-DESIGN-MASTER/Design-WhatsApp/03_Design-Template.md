# Design WhatsApp — Design Template

> **Permanent Recall:** Architecture: WebSocket for real-time, HTTP for media upload. Flow: Sender → WebSocket → Chat Service → Message Queue → Recipient's Chat Service → WebSocket. Offline: store in DB, push notification, deliver on reconnect. Group: fan-out to all members. Presence: heartbeat + TTL. Data model: users, messages, conversations, groups.

---

## API / Protocol Design

| Operation | Protocol | Endpoint / Mechanism |
|-----------|----------|----------------------|
| **Send message** | WebSocket | `ws://chat/send` — message payload |
| **Receive message** | WebSocket | Server pushes to client |
| **Media upload** | HTTP | `POST /media/upload` — multipart; returns URL |
| **Presence heartbeat** | WebSocket | `ws://presence/ping` every 30–60s |
| **Fetch history** | HTTP | `GET /conversations/:id/messages?offset=&limit=` |

---

## Message Flow (1:1)

```
  Sender                LB/WS Gateway         Chat Service         Message Queue        Recipient Chat Svc
     |                         |                      |                    |                        |
     |---- WS: send msg ------>|--------------------->|                    |                        |
     |                         |                      |---- publish ------>|                        |
     |                         |                      |<--- sent ack -------|                        |
     |<--- sent receipt -------|<---------------------|                    |                        |
     |                         |                      |                    |---- consume ---------->|
     |                         |                      |                    |                        |-- WS push -->
     |                         |                      |                    |<--- delivered ack ------|
     |<--- delivered receipt --|<-------------------------------------------|
```

---

## Offline Message Handling

| Step | Action |
|------|--------|
| 1 | Message arrives; recipient not in presence map |
| 2 | Store message in DB (per-conversation partition) |
| 3 | Send push notification via FCM/APNs |
| 4 | On reconnect: client fetches messages since last `sequence_id` |
| 5 | Or: server pushes stored messages when client connects |

> **FAANG Tip:** Always store before sending push. Otherwise you might notify but lose message on crash.

---

## Group Chat Architecture

```
Sender sends to group G (256 members)
         |
         v
  Chat Service: write message once to DB
         |
         v
  Fan-out to Message Queue: 256 topics or 256 entries in per-user queues
         |
         +---> User A (online)  → push via WebSocket
         +---> User B (offline) → store in inbox, push notification
         +---> ...
         +---> User 256
```

**Optimization:** Don't create 256 DB writes. Write once; queue has references. Each consumer fetches from DB or gets message payload from queue.

---

## Presence / Status Service

| Mechanism | Details |
|-----------|---------|
| **Heartbeat** | Client sends ping every 30–60s |
| **TTL** | Redis: `SET user:123:online 1 EX 90` — expires if no heartbeat |
| **Last seen** | On disconnect or expiry: `SET user:123:last_seen <timestamp>` |
| **Online list** | Query Redis for `user:123:online`; or maintain in-memory map in connection servers |

---

## Media Sharing

| Step | Action |
|------|--------|
| 1 | Client uploads via `POST /media/upload` (multipart) |
| 2 | Media Service stores in S3/GCS; generates signed URL or CDN URL |
| 3 | Message contains `{ type: "image", url: "https://cdn.../xyz" }` |
| 4 | Recipient fetches URL; can be lazy (on tap) or preload thumbnails |

---

## End-to-End Encryption Overview

| Concept | Description |
|---------|-------------|
| **Signal Protocol** | Double Ratchet; forward secrecy; no server-side decryption |
| **Key Exchange** | Out-of-band or server-assisted; public keys stored |
| **Message Encryption** | Client encrypts before send; server sees only ciphertext |
| **Server role** | Store and route ciphertext; cannot read messages |

> **FAANG Tip:** Mention "Signal protocol" and "client encrypts, server routes ciphertext." Don't deep-dive key exchange—interviewers rarely expect full crypto design.

---

## Data Model

### Users
```
user_id (PK), phone_number, name, profile_url, created_at
```

### Conversations
```
conversation_id (PK), type (1:1 | group), created_at
conversation_members: conversation_id, user_id, role, joined_at
```

### Messages
```
message_id (PK), conversation_id, sender_id, content_type (text|image|video|...)
content_or_url, sequence_id, created_at
```
- Shard by `conversation_id` for locality
- `sequence_id` for ordering

### Groups
```
group_id (PK), name, created_by, created_at
group_members: group_id, user_id, role, joined_at
```

---

## ASCII Architecture Diagram

```
                    ┌──────────────────────────────────────────────────┐
                    │                  Load Balancer                     │
                    │              (WebSocket-aware, sticky)             │
                    └─────────────────────────┬──────────────────────────┘
                                              │
         ┌────────────────────────────────────┼────────────────────────────────────┐
         │                                    │                                    │
         v                                    v                                    v
┌─────────────────┐                 ┌─────────────────┐                 ┌─────────────────┐
│ Connection Svr 1│                 │ Connection Svr 2│                 │ Connection Svr N│
│ (WebSocket)     │                 │ (WebSocket)     │                 │ (WebSocket)     │
│ 50K connections │                 │ 50K connections │                 │ 50K connections │
└────────┬────────┘                 └────────┬────────┘                 └────────┬────────┘
         │                                  │                                  │
         └──────────────────────────────────┼──────────────────────────────────┘
                                            │
              ┌─────────────────────────────┼─────────────────────────────┐
              │                             │                             │
              v                             v                             v
     ┌────────────────┐            ┌────────────────┐            ┌────────────────┐
     │ Chat Service   │            │Presence Service│            │Notification Svc│
     └────────┬───────┘            └───────┬────────┘            └───────┬────────┘
              │                            │                             │
              v                            v                             v
     ┌────────────────┐            ┌────────────────┐            ┌────────────────┐
     │ Kafka / Queue  │            │     Redis      │            │ FCM / APNs     │
     └────────┬───────┘            │ online, TTL    │            └────────────────┘
              │                    └────────────────┘
              v
     ┌────────────────┐            ┌────────────────┐
     │ Message Store  │            │ Media Service  │
     │ (Cassandra/    │            │ (S3 + CDN)     │
     │  DynamoDB)     │            └────────────────┘
     └────────────────┘
```

---

## Mermaid: Message Flow

```mermaid
flowchart TD
    A[User sends message] --> B[WebSocket]
    B --> C[Chat Service]
    C --> D{Recipient online?}
    D -->|Yes| E[Push via WebSocket]
    D -->|No| F[Store in DB]
    F --> G[Push notification]
    G --> H[Deliver on reconnect]
    E --> I[Delivered receipt]
    H --> I
```

---

## 30-SECOND REVISION BOX

```
API: WebSocket send/receive; HTTP media upload; heartbeat for presence
FLOW: Sender → WS → Chat → Queue → Recipient Chat → WS → Recipient
OFFLINE: Store → Push → Deliver on reconnect
GROUP: Write once, fan-out to member queues
PRESENCE: Heartbeat + Redis TTL
MEDIA: Upload → S3 → URL in message
E2E: Signal protocol, client encrypts, server routes ciphertext
DATA: users, conversations, messages (shard by conv_id), groups
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
