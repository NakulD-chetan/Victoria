import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const SeparateChainingCanvas = forwardRef(function SeparateChainingCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ buckets: 6, chains: [], highlightSlot: -1, highlightKey: null });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 320;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { buckets, chains, highlightSlot, highlightKey } = stateRef.current;
      const slotW = Math.min(90, (W - 40) / buckets - 10);
      const baseY = 70;
      for (let s = 0; s < buckets; s++) {
        const x = 30 + s * (slotW + 14);
        const active = s === highlightSlot;
        ctx.fillStyle = active ? '#a5d8ff' : '#f5f5f4';
        ctx.strokeStyle = '#1c1917';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.roundRect(x, baseY, slotW, 46, 6);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#44403c';
        ctx.font = 'bold 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(`slot ${s}`, x + slotW / 2, baseY - 10);
        let cy = baseY + 56;
        const list = chains[s] || [];
        list.forEach((key, idx) => {
          const isKey = key === highlightKey;
          ctx.fillStyle = isKey ? '#ffd43b' : '#e0e7ff';
          ctx.strokeStyle = '#1c1917';
          ctx.beginPath();
          ctx.roundRect(x + 4, cy, slotW - 8, 26, 5);
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = '#1c1917';
          ctx.font = '600 11px ui-monospace, monospace';
          ctx.fillText(String(key), x + slotW / 2, cy + 17);
          if (idx < list.length - 1) {
            ctx.beginPath();
            ctx.moveTo(x + slotW / 2, cy + 26);
            ctx.lineTo(x + slotW / 2, cy + 34);
            ctx.strokeStyle = '#78716c';
            ctx.lineWidth = 1.2;
            ctx.stroke();
          }
          cy += 34;
        });
      }
      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function generateSteps(keys, buckets) {
  const chains = Array.from({ length: buckets }, () => []);
  const steps = [];
  keys.forEach((key) => {
    const h = key % buckets;
    steps.push({ type: 'hash', key, slot: h, chains: chains.map((c) => [...c]) });
    chains[h].push(key);
    steps.push({ type: 'insert', key, slot: h, chains: chains.map((c) => [...c]) });
  });
  steps.push({ type: 'done', chains: chains.map((c) => [...c]) });
  return steps;
}

export default function SeparateChainingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const buckets = 6;
    const keys = Array.from({ length: 8 }, () => Math.floor(Math.random() * 90) + 10);
    const steps = generateSteps(keys, buckets);
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `h(k) = k mod ${buckets}` });
    canvasRef.current?.setState({ buckets, chains: Array.from({ length: buckets }, () => []), highlightSlot: -1, highlightKey: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'hash') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Hash(${step.key}) → slot ${step.slot}` });
      canvasRef.current?.setState({
        chains: step.chains,
        highlightSlot: step.slot,
        highlightKey: step.key,
      });
    } else if (step.type === 'insert') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Insert ${step.key} into chain at ${step.slot}` });
      canvasRef.current?.setState({
        chains: step.chains,
        highlightSlot: step.slot,
        highlightKey: step.key,
      });
    } else {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Chaining demo complete' });
      canvasRef.current?.setState({
        chains: step.chains,
        highlightSlot: -1,
        highlightKey: null,
      });
    }
  }, []);

  return <AlgoVisualizer config={config} canvas={SeparateChainingCanvas} onInit={onInit} onStep={onStep} />;
}
