# API Design — Common Mistakes

> **Permanent Recall:** The top 12 API mistakes: verbs in REST URLs, wrong HTTP methods, no versioning, no rate limiting, no pagination, inconsistent naming, no error format, no authentication, non-idempotent POST, overly chatty APIs, no documentation, and breaking backward compatibility. Avoid these to pass FAANG API design discussions and build production-ready APIs.

---

## Mistake 1: Using Verbs in REST URLs

**What happens:** URLs like `/getUser`, `/createOrder` violate REST—the verb belongs in the HTTP method.


| Wrong                 | Right               |
| --------------------- | ------------------- |
| `GET /getUser/123`    | `GET /users/123`    |
| `POST /createOrder`   | `POST /orders`      |
| `GET /deleteUser/123` | `DELETE /users/123` |


> **FAANG Tip:** URL = noun (resource). Method = verb (action).

---

## Mistake 2: Wrong HTTP Methods

**What happens:** Using POST for reads, GET for updates, or inconsistent method semantics.


| Wrong                           | Right            |
| ------------------------------- | ---------------- |
| `POST /users/123` to fetch user | `GET /users/123` |
| `GET /orders?action=create`     | `POST /orders`   |
| `POST` for idempotent replace   | `PUT`            |
| `PUT` for partial update        | `PATCH`          |


---

## Mistake 3: No Versioning

**What happens:** Breaking change breaks all clients. No way to migrate gradually.

**Fix:** Version from day one—`/v1/users`. When breaking change, add `/v2/users`. Deprecate `v1` with notice.

---

## Mistake 4: No Rate Limiting

**What happens:** One client overwhelms the API; DoS; no fair usage.

**Fix:** Implement token bucket or sliding window. Return `429 Too Many Requests` with `Retry-After`. Headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`.

---

## Mistake 5: No Pagination

**What happens:** `GET /users` returns 1M rows; timeout, memory blow-up, slow response.

**Fix:** Always paginate list endpoints. Prefer cursor over offset for scale.


| Wrong                    | Right                            |
| ------------------------ | -------------------------------- |
| `GET /users` → all users | `GET /users?limit=20&cursor=xyz` |


---

## Mistake 6: Inconsistent Naming

**What happens:** `user_id` vs `userId` vs `userId`; `created_at` vs `createdAt`. Client confusion, bugs.

**Fix:** Pick a convention (snake_case or camelCase) and stick to it across all endpoints.

---

## Mistake 7: No Error Format

**What happens:** Different error shapes; no machine-readable codes. Clients can't handle errors programmatically.

**Fix:** Consistent error body:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "user_id is required",
    "details": [{ "field": "user_id", "reason": "required" }]
  }
}
```

---

## Mistake 8: No Authentication

**What happens:** Sensitive endpoints exposed; abuse; data leakage.

**Fix:** Authenticate by default. Public endpoints explicitly opt out. Use API key, OAuth, or JWT as appropriate.

---

## Mistake 9: Not Idempotent for POST

**What happens:** Client retries POST (e.g., payment)—creates duplicate order/charge.

**Fix:** Support `Idempotency-Key` header. Same key → return cached response, no duplicate side effect.

---

## Mistake 10: Overly Chatty APIs

**What happens:** Client needs 10 requests to render one screen; latency adds up.

**Fix:** Batch endpoints, or use GraphQL for flexible queries. Consider BFF (Backend-for-Frontend) to consolidate.

---

## Mistake 11: No Documentation

**What happens:** Developers guess; wrong usage; support burden.

**Fix:** OpenAPI/Swagger for REST. GraphQL has built-in introspection. Keep docs in sync with code.

---

## Mistake 12: Breaking Backward Compatibility

**What happens:** Remove field, change type, rename → existing clients break.

**Fix:** Add, don't remove. New fields optional. New versions for breaking changes. Deprecation notices.

---

## Summary Table


| Mistake             | Impact                  | Fix                               |
| ------------------- | ----------------------- | --------------------------------- |
| Verbs in URL        | Not RESTful             | Nouns in URL, verbs in method     |
| Wrong methods       | Confusing, cache issues | Correct GET/POST/PUT/PATCH/DELETE |
| No versioning       | Breaking clients        | `/v1/` from start                 |
| No rate limit       | DoS, abuse              | Token bucket, 429                 |
| No pagination       | Timeouts, overload      | Cursor/offset, limit              |
| Inconsistent naming | Bugs, confusion         | Single convention                 |
| No error format     | Unparseable errors      | Structured error body             |
| No auth             | Security risk           | Auth by default                   |
| No idempotency      | Duplicates on retry     | Idempotency-Key                   |
| Chatty API          | High latency            | Batch, GraphQL                    |
| No docs             | Poor adoption           | OpenAPI, introspection            |
| Breaking compat     | Client breakage         | Add-only, version                 |


---



