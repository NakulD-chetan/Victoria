# Back-of-Envelope Estimation — Interview Thinking

> **Permanent Recall:** In interviews, **show your work**, **state assumptions**, and **round aggressively**. Do estimation right after requirements (2–3 minutes max). Interviewers care about **process over precision**—they want to see structured thinking, not calculator-level accuracy.

---

## How to Present Estimations

### Show Your Work

```
    BAD:  "We need about 50,000 QPS."
    GOOD: "300M DAU, 5 actions per user → 1.5B actions/day. 
           ÷ 86400 ≈ 17K. With 3× peak factor, ~50K QPS."
```

Speak the steps out loud. Write key numbers on the whiteboard.

---

### State Assumptions Explicitly

| Assumption | Example | Why It Matters |
|------------|---------|----------------|
| DAU | "Assume 100M DAU" | Scales everything |
| Actions/user | "Assume 10 page views/day" | Drives QPS |
| Read:Write | "Assume 100:1 for feed" | Affects cache vs DB design |
| Retention | "Assume 5 years" | Storage growth |

> **FAANG Tip:** Say "Let me assume X" before each. If the interviewer disagrees, they'll correct you—that's feedback, not failure.

---

### Round Aggressively

| Precise | Rounded | Say |
|---------|---------|-----|
| 47,382 | 50K | "On the order of 50 thousand" |
| 1.73 million | 2M | "Roughly 2 million" |
| 86400 | ~100K | "About 100K seconds per day" |

---

## When to Do Estimation

```mermaid
flowchart LR
    A[Requirements] --> B[Estimation]
    B --> C[High-level Design]
    C --> D[Deep Dive]
```

**Right after requirements** — Before drawing boxes and arrows. Estimation informs:
- Do we need sharding?
- Do we need CDN/caching?
- Single region or multi-region?

---

## How Long to Spend

| Phase | Time | Focus |
|-------|------|-------|
| Requirements | 2–3 min | Clarify scope |
| **Estimation** | **2–3 min** | QPS, storage, bandwidth |
| Design | 15–20 min | Architecture |
| Deep dive | 5–10 min | Trade-offs |

> **FAANG Tip:** Don't get stuck on estimation. "~100K QPS" is enough to say "we need hundreds of web servers." Move on.

---

## What Interviewers Look For

| Signal | What It Shows |
|--------|---------------|
| Structured approach | 6-step framework, not random numbers |
| Reasonable assumptions | DAU, actions, read:write in realistic range |
| Order-of-magnitude | Rounded numbers, no false precision |
| Quick execution | 2–3 min, then move to design |
| Sanity checks | "Twitter is ~millions; we're ~100K, so smaller scale" |

---

## Common Estimation Questions & Model Answers

### "Estimate QPS for a system with 50M DAU, 20 actions/day"

**Answer:** "50M × 20 = 1B actions/day. 1B / 86400 ≈ 12K average QPS. With 3× peak, ~36K QPS. So we're in the tens of thousands—need tens of web servers, read replicas if read-heavy."

---

### "How much storage for 1B tweets per day for 5 years?"

**Answer:** "1B × 5 × 365 ≈ 1.8 trillion tweets. ~300 bytes per tweet with metadata → 540 TB. With 3× replication → ~1.5 PB. Order of petabyte."

---

### "Estimate bandwidth for video streaming to 10M concurrent users"

**Answer:** "10M users, 5 Mbps avg (1080p) → 50 Tbps egress. That's CDN-scale—multiple edge locations, not a single origin."

---

## Red Flags to Avoid

| Red Flag | Fix |
|----------|-----|
| Spending 10 min on estimation | Cap at 2–3 min; round and move on |
| Calculator-level precision | Round to powers of 10 |
| No assumptions stated | Say "Assume X" for each input |
| Skipping estimation | Always do at least QPS |

---

## Handling Corrections

When the interviewer says "What if DAU is 1B?" — **don't panic**. Re-run the math:

```
Old: 100M × 10 / 86400 ≈ 12K QPS
New: 1B × 10 / 86400 ≈ 120K QPS

"So we'd need ~120 web servers and multiple DB replicas. Architecture scales linearly."
```

---

## Estimation vs. Design

| Phase | Focus |
|-------|-------|
| **Estimation** | Numbers (QPS, storage, BW) |
| **Design** | How to achieve those numbers |

Estimation informs design. "100K QPS" → need load balancer, horizontal scaling, maybe cache.

---

## 30-SECOND REVISION BOX

```
PRESENT: Show work, state assumptions, round aggressively
WHEN: Right after requirements
TIME: 2–3 minutes max
LOOK FOR: Process, structure, reasonable assumptions
AVOID: Precision, long time, skipping
```

---

**Next: [[05_Common-Mistakes]]**
