import { useState, useRef, useEffect, useCallback, memo } from 'react';

const ChatInput = memo(function ChatInput({ onSend, isLoading, folder, filename }) {
  const [input, setInput] = useState('');
  const textareaRef = useRef(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      const scrollH = textareaRef.current.scrollHeight;
      textareaRef.current.style.height = Math.min(scrollH, 120) + 'px';
    }
  }, [input]);

  const handleSubmit = useCallback(() => {
    const q = input.trim();
    if (!q || isLoading) return;
    onSend(q);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  }, [input, isLoading, onSend]);

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  }, [handleSubmit]);

  const scope = filename ? `${folder}/${filename}` : folder || null;

  return (
    <div className="chat-input-container">
      <div className="chat-input-wrapper">
        <div className={`chat-input-box ${isLoading ? 'processing' : ''}`}>
          {scope && (
            <div className="chat-input-box__scope">
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
              {scope}
            </div>
          )}
          <textarea
            ref={textareaRef}
            className="chat-input-textarea"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything about your files..."
            rows={1}
            disabled={isLoading}
          />
          {isLoading ? (
            <button className="chat-input-send" disabled>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <rect x="6" y="6" width="12" height="12" rx="2" />
              </svg>
            </button>
          ) : (
            <button className="chat-input-send" onClick={handleSubmit} disabled={!input.trim()}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="5" y1="12" x2="19" y2="12" />
                <polyline points="12 5 19 12 12 19" />
              </svg>
            </button>
          )}
        </div>
        <div className="chat-input-footer">
          <span>Search across your markdown files</span>
        </div>
      </div>
    </div>
  );
});

export default ChatInput;
