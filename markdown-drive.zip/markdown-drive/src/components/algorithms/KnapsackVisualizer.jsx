import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(weights, values, cap) {
  const n = weights.length;
  const steps = [];
  const dp = Array.from({ length: n + 1 }, () => Array(cap + 1).fill(null));
  const colLabels = Array.from({ length: cap + 1 }, (_, j) => j);
  const rowLabels = ['∅', ...weights.map((_, i) => `i${i + 1}`)];

  const snap = (caption, colors, hl) => {
    steps.push({
      caption,
      table: dp.map((r) => r.map((v) => v)),
      rowLabels,
      colLabels,
      cellColors: colors || {},
      arrows: [],
      highlight: hl,
    });
  };

  snap('Initialize 0/1 knapsack DP table', {}, null);
  for (let i = 0; i <= n; i += 1) dp[i][0] = 0;
  for (let w = 0; w <= cap; w += 1) dp[0][w] = 0;
  snap('Base row/col zeros', { '0-0': 'filled' }, [0, 0]);

  for (let i = 1; i <= n; i += 1) {
    for (let w = 1; w <= cap; w += 1) {
      const colors = { [`${i}-${w}`]: 'current', [`${i - 1}-${w}`]: 'filled' };
      const arrows = [{ from: [i - 1, w], to: [i, w] }];
      let best = dp[i - 1][w];
      let msg = `Skip item ${i}`;
      if (weights[i - 1] <= w) {
        colors[`${i - 1}-${w - weights[i - 1]}`] = 'filling';
        arrows.push({ from: [i - 1, w - weights[i - 1]], to: [i, w] });
        const take = dp[i - 1][w - weights[i - 1]] + values[i - 1];
        if (take > best) {
          best = take;
          msg = `Take item ${i} (+${values[i - 1]})`;
        }
      }
      snap(`${msg} at (i=${i}, w=${w})`, colors, [i, w]);
      dp[i][w] = best;
      snap(`dp[${i}][${w}] = ${best}`, { [`${i}-${w}`]: 'optimal' }, [i, w]);
    }
  }

  snap(`Optimal knapsack value = dp[${n}][${cap}]`, { [`${n}-${cap}`]: 'optimal' }, [n, cap]);

  return steps;
}

export default function KnapsackVisualizer({ config }) {
  const weights = [2, 3, 1, 4];
  const values = [10, 20, 15, 40];
  const cap = 6;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(weights, values, cap);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: '0/1 knapsack classic DP' });
    canvasRef.current?.setState({
      table: [[0]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      items: weights.map((w, i) => `(${w},${values[i]})`),
      caption: 'Knapsack',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      items: weights.map((w, i) => `w${w}/v${values[i]}`),
      caption: step.caption || '',
    });
  }, [weights, values]);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={DPCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
