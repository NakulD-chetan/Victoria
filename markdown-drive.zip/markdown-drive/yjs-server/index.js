/*
 * yjs-server — y-websocket server with Supabase JWT auth + Storage
 * persistence.
 *
 * Connection contract:
 *   ws://host:port/<noteId>?token=<supabase-access-token>
 *
 * Per Yjs convention, the URL path is the document name. We treat it as
 * the notes.id UUID and:
 *   1. Verify the access token using SUPABASE_JWT_SECRET.
 *   2. Look up the note's vault_id, then call effective_role(...) to
 *      decide whether the user gets read-write, read-only, or none.
 *   3. Hydrate the Y.Doc from `notes/<id>.ydoc.bin` in Storage; persist
 *      a debounced snapshot back to Storage as edits flow in.
 *
 * Process management: this runs as its own Node process (see the `yjs`
 * script in package.json). For production deploy alongside Express on
 * Railway/Fly/Render, or as a Supabase Edge Function (with WebSockets).
 */

import http from 'http';
import { createRequire } from 'module';
import { WebSocketServer } from 'ws';
import * as Y from 'yjs';
import { createClient } from '@supabase/supabase-js';

/* y-websocket v2 only exports CommonJS utils (`y-websocket/bin/utils` → .cjs). */
const require = createRequire(import.meta.url);
const { setupWSConnection, setPersistence, docs } = require('y-websocket/bin/utils');
import { createHmac, timingSafeEqual } from 'crypto';

const PORT = Number(process.env.YJS_PORT || 1234);
const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_SERVICE_ROLE = process.env.SUPABASE_SERVICE_ROLE || '';
const SUPABASE_JWT_SECRET = process.env.SUPABASE_JWT_SECRET || '';
const STORAGE_BUCKET = process.env.SUPABASE_YDOC_BUCKET || 'inkdrop-files';
const SAVE_DEBOUNCE_MS = Number(process.env.YJS_SAVE_DEBOUNCE_MS || 5000);

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE || !SUPABASE_JWT_SECRET) {
  console.warn('[yjs-server] WARNING: Supabase env not fully configured;'
    + ' the server will run in dev mode and accept any JWT shape.');
}

const supa = SUPABASE_URL && SUPABASE_SERVICE_ROLE
  ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE, { auth: { persistSession: false } })
  : null;

/* ── JWT verification (HS256, identical to supabase-jwt.js in server.js) */

function b64dec(seg) {
  const pad = 4 - (seg.length % 4);
  return Buffer.from(seg + (pad < 4 ? '='.repeat(pad) : ''), 'base64');
}
function b64decJson(seg) { return JSON.parse(b64dec(seg).toString('utf8')); }

function verifyJwt(token) {
  if (!token) return null;
  if (!SUPABASE_JWT_SECRET) {
    /* Dev shortcut: accept any well-formed JWT. */
    try {
      const parts = token.split('.');
      if (parts.length !== 3) return null;
      const payload = b64decJson(parts[1]);
      return { id: payload.sub, raw: payload };
    } catch { return null; }
  }
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  let header; let payload;
  try { header = b64decJson(parts[0]); payload = b64decJson(parts[1]); } catch { return null; }
  if (header.alg !== 'HS256') return null;
  const expected = createHmac('sha256', SUPABASE_JWT_SECRET)
    .update(`${parts[0]}.${parts[1]}`).digest();
  const provided = b64dec(parts[2]);
  if (expected.length !== provided.length) return null;
  try { if (!timingSafeEqual(expected, provided)) return null; } catch { return null; }
  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) return null;
  return { id: payload.sub, raw: payload };
}

/* ── Authorisation: check effective_role for this user + note. ───────── */

async function checkAccess(userId, noteId) {
  if (!supa) return { canRead: true, canWrite: true }; /* dev mode */
  const { data: note } = await supa.from('notes').select('id, vault_id').eq('id', noteId).maybeSingle();
  if (!note) return { canRead: false, canWrite: false };
  const { data: role } = await supa.rpc('effective_role', {
    p_vault: note.vault_id, p_type: 'note', p_id: note.id,
  });
  if (!role) return { canRead: false, canWrite: false };
  return { canRead: true, canWrite: role === 'owner' || role === 'editor' };
}

/* ── Persistence: read/write Y.Doc binary in Supabase Storage. ───────── */

const _saveTimers = new Map();

async function loadDoc(docName, ydoc) {
  if (!supa) return;
  const path = `notes/${docName}.ydoc.bin`;
  const { data, error } = await supa.storage.from(STORAGE_BUCKET).download(path);
  if (error || !data) return;
  try {
    const buf = Buffer.from(await data.arrayBuffer());
    Y.applyUpdate(ydoc, buf);
  } catch (e) {
    console.warn('[yjs-server] could not apply stored update for', docName, e.message);
  }
}

function scheduleSave(docName, ydoc) {
  if (!supa) return;
  if (_saveTimers.has(docName)) clearTimeout(_saveTimers.get(docName));
  const t = setTimeout(async () => {
    _saveTimers.delete(docName);
    const update = Y.encodeStateAsUpdate(ydoc);
    const path = `notes/${docName}.ydoc.bin`;
    try {
      await supa.storage
        .from(STORAGE_BUCKET)
        .upload(path, Buffer.from(update), { upsert: true, contentType: 'application/octet-stream' });
    } catch (e) {
      console.warn('[yjs-server] save failed for', docName, e.message);
    }
  }, SAVE_DEBOUNCE_MS);
  _saveTimers.set(docName, t);
}

setPersistence({
  bindState: async (docName, ydoc) => {
    await loadDoc(docName, ydoc);
    ydoc.on('update', () => scheduleSave(docName, ydoc));
  },
  writeState: async (docName, ydoc) => {
    /* Final snapshot when the doc is unloaded. */
    if (!supa) return;
    const update = Y.encodeStateAsUpdate(ydoc);
    const path = `notes/${docName}.ydoc.bin`;
    try {
      await supa.storage
        .from(STORAGE_BUCKET)
        .upload(path, Buffer.from(update), { upsert: true, contentType: 'application/octet-stream' });
    } catch (e) {
      console.warn('[yjs-server] writeState failed for', docName, e.message);
    }
  },
});

/* ── HTTP + WebSocket plumbing ─────────────────────────────────────── */

const server = http.createServer((_req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('inkdrop yjs-server\n');
});

const wss = new WebSocketServer({ noServer: true });

server.on('upgrade', async (req, socket, head) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const docName = url.pathname.replace(/^\/+/, '').split('?')[0];
    const token = url.searchParams.get('token') || (req.headers.authorization || '').replace(/^Bearer\s+/i, '');

    const claims = verifyJwt(token);
    if (!claims) {
      socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return;
    }
    if (!docName) {
      socket.write('HTTP/1.1 400 Bad Request\r\n\r\n'); socket.destroy(); return;
    }
    const { canRead, canWrite } = await checkAccess(claims.id, docName);
    if (!canRead) {
      socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); socket.destroy(); return;
    }
    wss.handleUpgrade(req, socket, head, (ws) => {
      ws._inkdrop = { userId: claims.id, canWrite };
      /* If read-only, drop messages from this socket but still let server
       * push state updates. y-websocket has no native read-only mode, so
       * we shim by closing on first non-awareness message if !canWrite. */
      if (!canWrite) {
        ws.on('message', (data) => {
          /* Awareness messages start with byte 1 (messageAwareness in y-protocols). */
          const b = Buffer.isBuffer(data) ? data[0] : new Uint8Array(data)[0];
          if (b !== 1) {
            try { ws.close(1008, 'read-only'); } catch { /* ignore */ }
          }
        });
      }
      setupWSConnection(ws, req, { docName, gc: true });
    });
  } catch (e) {
    console.error('[yjs-server] upgrade error:', e);
    try { socket.destroy(); } catch { /* ignore */ }
  }
});

server.listen(PORT, () => {
  console.log(`[yjs-server] listening on ws://localhost:${PORT}`);
  console.log(`[yjs-server] active docs: ${docs.size}`);
});
