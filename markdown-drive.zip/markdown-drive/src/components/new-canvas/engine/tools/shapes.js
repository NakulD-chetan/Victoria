import { uid } from '../../state/types';
import { worldFromClient } from '../coords';

/**
 * Drag-to-create for rect / ellipse / line / arrow.
 *
 * Preview lives on the interactive layer (draft). On pointerup we commit to
 * the static layer — no intermediate store writes, so React doesn't re-render.
 */

function makeBoxTool(kind) {
  return {
    id: kind,
    cursor: 'crosshair',

    onPointerDown(ctx, ev) {
      if (ev.button !== 0) return false;
      const { canvasEl, getVp, store } = ctx;
      canvasEl.setPointerCapture?.(ev.pointerId);
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      const style = snapStyle(store.getState().toolOptions);
      ctx.setDraft({
        id: uid(kind),
        type: kind,
        x, y, w: 0, h: 0, z: 0, isDeleted: false,
        style,
        _start: { x, y },
        createdAt: Date.now(),
      });
      ctx.markDirty(1);
      return true;
    },

    onPointerMove(ctx, ev) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== kind) return;
      const { canvasEl, getVp } = ctx;
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      const sx = draft._start.x, sy = draft._start.y;
      let dx = x - sx, dy = y - sy;
      // shift-key → constrain to square
      if (ev.shiftKey) {
        const m = Math.max(Math.abs(dx), Math.abs(dy));
        dx = Math.sign(dx || 1) * m;
        dy = Math.sign(dy || 1) * m;
      }
      draft.x = dx < 0 ? sx + dx : sx;
      draft.y = dy < 0 ? sy + dy : sy;
      draft.w = Math.abs(dx);
      draft.h = Math.abs(dy);
      ctx.markDirty(1);
    },

    onPointerUp(ctx) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== kind) return;
      ctx.setDraft(null);
      if (draft.w < 2 && draft.h < 2) { ctx.markDirty(1); return; }
      const { _start, ...el } = draft;
      void _start;
      ctx.commit((els) => els.concat([el]));
      ctx.markDirty(2);
    },

    onCancel(ctx) { ctx.setDraft(null); ctx.markDirty(1); },
  };
}

function makeLineTool(kind) {
  return {
    id: kind,
    cursor: 'crosshair',

    onPointerDown(ctx, ev) {
      if (ev.button !== 0) return false;
      const { canvasEl, getVp, store } = ctx;
      canvasEl.setPointerCapture?.(ev.pointerId);
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      const style = snapStyle(store.getState().toolOptions);
      ctx.setDraft({
        id: uid(kind),
        type: kind,
        x, y, x2: x, y2: y, w: 0, h: 0, z: 0, isDeleted: false,
        style,
        createdAt: Date.now(),
      });
      ctx.markDirty(1);
      return true;
    },

    onPointerMove(ctx, ev) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== kind) return;
      const { canvasEl, getVp } = ctx;
      const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
      if (ev.shiftKey) {
        // snap to 45°
        const dx = x - draft.x, dy = y - draft.y;
        const ang = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
        const r = Math.hypot(dx, dy);
        draft.x2 = draft.x + Math.cos(ang) * r;
        draft.y2 = draft.y + Math.sin(ang) * r;
      } else {
        draft.x2 = x; draft.y2 = y;
      }
      draft.w = draft.x2 - draft.x;
      draft.h = draft.y2 - draft.y;
      ctx.markDirty(1);
    },

    onPointerUp(ctx) {
      const draft = ctx.getDraft();
      if (!draft || draft.type !== kind) return;
      ctx.setDraft(null);
      const len = Math.hypot(draft.x2 - draft.x, draft.y2 - draft.y);
      if (len < 2) { ctx.markDirty(1); return; }
      ctx.commit((els) => els.concat([draft]));
      ctx.markDirty(2);
    },

    onCancel(ctx) { ctx.setDraft(null); ctx.markDirty(1); },
  };
}

function snapStyle(opts) {
  return {
    stroke: opts.stroke,
    fill: opts.fill || 'transparent',
    strokeWidth: opts.strokeWidth,
    opacity: opts.opacity ?? 1,
    dash: opts.dash || 'solid',
  };
}

export const rectTool = makeBoxTool('rect');
export const ellipseTool = makeBoxTool('ellipse');
export const lineTool = makeLineTool('line');
export const arrowTool = makeLineTool('arrow');
