import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(eggs, floors) {
  const dp = Array.from({ length: eggs + 1 }, () => Array(floors + 1).fill(0));
  for (let f = 1; f <= floors; f += 1) dp[1][f] = f;
  for (let e = 1; e <= eggs; e += 1) dp[e][0] = 0;
  const steps = [];
  const colLabels = Array.from({ length: floors + 1 }, (_, i) => i);
  const rowLabels = Array.from({ length: eggs + 1 }, (_, i) => (i ? `e${i}` : '∅'));

  const snap = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: dp.map((r) => [...r]),
      rowLabels,
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('Egg drop DP: dp[e][f] worst-case drops', {}, null, []);

  for (let e = 2; e <= eggs; e += 1) {
    for (let f = 1; f <= floors; f += 1) {
      let best = Infinity;
      for (let x = 1; x <= f; x += 1) {
        const worst = 1 + Math.max(dp[e - 1][x - 1], dp[e][f - x]);
        const colors = {
          [`${e}-${f}`]: 'current',
          [`${e - 1}-${x - 1}`]: 'filling',
          [`${e}-${f - x}`]: 'filled',
        };
        const arrows = [
          { from: [e - 1, x - 1], to: [e, f] },
          { from: [e, f - x], to: [e, f] },
        ];
        snap(`Try first drop at floor x=${x}`, colors, [e, f], arrows);
        best = Math.min(best, worst);
      }
      dp[e][f] = best;
      snap(`dp[${e}][${f}] = ${best}`, { [`${e}-${f}`]: 'optimal' }, [e, f], []);
    }
  }

  snap(`Min drops (${eggs} eggs, ${floors} floors) = ${dp[eggs][floors]}`, { [`${eggs}-${floors}`]: 'optimal' }, [eggs, floors], []);
  return steps;
}

export default function EggDropVisualizer({ config }) {
  const eggs = 2;
  const floors = 6;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(eggs, floors);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `${eggs} eggs, ${floors} floors` });
    canvasRef.current?.setState({ table: [[0]], rowLabels: [], colLabels: [], cellColors: {}, arrows: [], highlight: null, caption: 'Egg drop' });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
