# Design Uber — Ride Sharing System

> **Uber = Real-time location + Geospatial matching + Low latency**
> Rider aur Driver ko milliseconds mein match karna hai — samjho kaise!

---

## Table of Contents

1. [Requirements Clarification](#1-requirements-clarification)
2. [Back of Envelope Estimation](#2-back-of-envelope-estimation)
3. [High Level Design](#3-high-level-design)
4. [API Design](#4-api-design)
5. [Data Model / Database Schema](#5-data-model--database-schema)
6. [Deep Dive — Key Components](#6-deep-dive--key-components)
7. [Bottlenecks & Scaling](#7-bottlenecks--scaling)
8. [Trade-offs](#8-trade-offs)
9. [1 Minute Recall Block + 5 Bullet Memory Hooks](#9-1-minute-recall-block--5-bullet-memory-hooks)

---

## 1. Requirements Clarification

### 1.1 Functional Requirements

```
FUNCTIONAL REQUIREMENTS
│
├── Ride Request
│   ├── Set pickup location
│   ├── Set destination (optional, for fare estimate)
│   ├── Choose ride type (UberX, UberXL, etc.)
│   └── Request ride
│
├── Driver Matching
│   ├── Find nearest available drivers
│   ├── Assign driver to rider
│   └── Notify both parties
│
├── Real-time Tracking
│   ├── Driver location updates (every 3-5 sec)
│   ├── ETA to pickup
│   ├── ETA to destination
│   └── Live map view
│
├── Trip Management
│   ├── Start trip
│   ├── In-progress tracking
│   ├── End trip
│   └── Trip history
│
├── Fare & Payment
│   ├── Fare estimation (before ride)
│   ├── Surge pricing (demand > supply)
│   ├── Final fare calculation
│   └── Payment processing
│
└── Ratings & Reviews
    ├── Rate driver/rider
    └── View ratings
```

### 1.2 Non-Functional Requirements

| Requirement | Target | Kyu Important? |
|-------------|--------|----------------|
| **Latency** | < 200ms for matching | User wait nahi karega |
| **Availability** | 99.99% | Ride critical service |
| **Real-time** | Location every 3-5 sec | Live tracking |
| **Consistency** | Strong for trip state | Double booking nahi |

### 1.3 Real-World Analogy — Auto Stand vs Uber

```
AUTO STAND (Traditional)                 UBER (Digital)
┌─────────────────────┐                 ┌──────────────────────────────────┐
│  Stand pe jao        │                 │  App open → Location bhejo       │
│  Auto wala dekho     │                 │  → System nearest driver dhundhe │
│  Negotiate price     │                 │  → Match in milliseconds         │
│  Wait...             │                 │  → ETA, tracking, fixed fare     │
└─────────────────────┘                 └──────────────────────────────────┘
     ❌ Uncertainty, wait                     ✅ Predictable, fast
```

---

## 2. Back of Envelope Estimation

### 2.1 Assumptions

| Metric | Value | Notes |
|--------|-------|-------|
| Daily rides | 20M | Global |
| Active drivers | 5M | Online at peak |
| Location updates | Every 4 sec | Per driver |
| Avg trip duration | 25 min | |
| Peak concurrent trips | ~500K | |

### 2.2 QPS Estimation

```
LOCATION UPDATES (Writes):
  5M drivers × (1/4) updates/sec = 1.25M writes/sec
  → In-memory store (Redis) + async to DB

RIDE REQUESTS:
  20M / 86,400 ≈ 230 requests/sec (average)
  Peak: 2-3× ≈ 500-700/sec

MATCHING QUERIES:
  Each request = 1 geo query (find nearby drivers)
  ≈ 500-700 geo queries/sec at peak
```

### 2.3 Storage (Rough)

```
LOCATION (in-memory):
  5M drivers × 50 bytes ≈ 250 MB (Redis)

TRIPS (persistent):
  20M/day × 1 KB ≈ 20 GB/day
  1 year ≈ 7 TB
```

---

## 3. High Level Design

### 3.1 Overall Architecture

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    UBER RIDE-SHARING SYSTEM                  │
                    └─────────────────────────────────────────────────────────────┘

    ┌──────────┐     ┌──────────────┐     ┌─────────────────────────────────────────┐
    │  Rider   │────▶│  API Gateway │────▶│              Load Balancer               │
    │  App     │     │  (Auth)      │     └─────────────────────────────────────────┘
    └──────────┘     └──────────────┘                          │
         │                    │                                │
    ┌──────────┐              │                                ▼
    │  Driver  │──────────────┘                    ┌────────────────────────┐
    │  App     │                                  │   Trip Service         │
    └──────────┘                                  │   (Request, Match,    │
                                                  │    Start, End)        │
                                                  └──────────┬────────────┘
                                                             │
         ┌───────────────────────────────────────────────────┼───────────────────────┐
         │                                                   │                       │
         ▼                                                   ▼                       ▼
┌─────────────────┐                              ┌─────────────────┐     ┌─────────────────┐
│ Location Service│                              │ Matching Service│     │ Payment Service │
│                 │                              │                 │     │                 │
│ Driver location │                              │ Geospatial      │     │ Fare calc       │
│ every 3-5 sec   │                              │ index query     │     │ Payment gateway │
│                 │                              │ Nearest drivers │     │                 │
│ Redis (in-mem)  │                              │                 │     │                 │
└────────┬────────┘                              └────────┬────────┘     └─────────────────┘
         │                                                 │
         │    WebSocket (real-time updates)                │
         └─────────────────────┬───────────────────────────┘
                               ▼
                    ┌─────────────────────┐
                    │  Rider/Driver Apps  │
                    │  (Live map, ETA)    │
                    └─────────────────────┘
```

### 3.2 Request-to-Match Flow

```
RIDE REQUEST FLOW
═════════════════

[Rider] Request ride (pickup: lat, lng)
    │
    ▼
[Trip Service] Create trip (state: PENDING)
    │
    ▼
[Matching Service] Query: "Drivers within 2km of pickup, status=AVAILABLE"
    │
    │  Uses: Geohash / Quadtree / S2
    │
    ▼
[Location Service] Return list of driver IDs + ETA
    │
    ▼
[Matching Service] Select best driver (nearest ETA, rating)
    │
    ▼
[Trip Service] Assign driver, update trip (state: ASSIGNED)
    │
    ▼
[Notification] Push to Driver + Rider (WebSocket + Push)
    │
    ▼
[Driver] Accept → Trip CONFIRMED
```

---

## 4. API Design

### 4.1 Ride APIs

```
POST /api/v1/rides/request
  Request: { pickup: {lat, lng}, destination: {lat, lng}, ride_type }
  Response: { trip_id, estimated_fare, eta_to_pickup }

GET /api/v1/rides/{trip_id}
  Response: { status, driver_info, current_location, eta }

POST /api/v1/rides/{trip_id}/cancel
POST /api/v1/rides/{trip_id}/start   // Driver starts
POST /api/v1/rides/{trip_id}/complete  // Driver ends
```

### 4.2 Location APIs

```
PUT /api/v1/drivers/location   // Driver app — every 3-5 sec
  Request: { lat, lng, heading, timestamp }

GET /api/v1/rides/{trip_id}/track
  Response: WebSocket stream { driver_location, eta }
```

### 4.3 Fare APIs

```
GET /api/v1/fares/estimate
  Query: ?pickup_lat=&pickup_lng=&dest_lat=&dest_lng=
  Response: { min_fare, max_fare, surge_multiplier }
```

---

## 5. Data Model / Database Schema

### 5.1 Trips (PostgreSQL — Strong Consistency)

```sql
CREATE TABLE trips (
    trip_id UUID PRIMARY KEY,
    rider_id BIGINT NOT NULL,
    driver_id BIGINT,
    status ENUM('PENDING', 'ASSIGNED', 'CONFIRMED', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED'),
    pickup_lat DECIMAL(10, 8),
    pickup_lng DECIMAL(11, 8),
    dest_lat DECIMAL(10, 8),
    dest_lng DECIMAL(11, 8),
    fare_amount DECIMAL(10, 2),
    surge_multiplier DECIMAL(3, 2),
    created_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    INDEX idx_rider (rider_id),
    INDEX idx_driver (driver_id),
    INDEX idx_status (status)
);
```

### 5.2 Driver Location (Redis — In-Memory)

```
Key: driver:{driver_id}:location
Value: { "lat": 28.6139, "lng": 77.2090, "ts": 1234567890 }
TTL: 60 sec (driver offline = expire)

Geospatial: GEOADD drivers:available {lng} {lat} {driver_id}
Query: GEORADIUS drivers:available {lng} {lat} 2 km
```

### 5.3 Analytics (Cassandra — Write Heavy)

```
trip_events (
    trip_id,
    event_type,  // created, assigned, started, completed
    timestamp,
    ...
)
Partition: trip_id
```

---

## 6. Deep Dive — Key Components

### 6.1 Geospatial Indexing

**Problem:** "Mujhe 2km radius mein sab available drivers chahiye" — kaise fast query?

```
OPTIONS COMPARISON
══════════════════

┌─────────────┬──────────────┬──────────────┬──────────────┐
│  Approach   │  Query Time  │  Accuracy    │  Use Case    │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Naive       │ O(n)         │ Exact        │ Small n      │
│ (all points)│              │              │              │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Geohash     │ O(log n)     │ Grid approx  │ Redis GEO    │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ Quadtree    │ O(log n)     │ Good         │ Custom       │
├─────────────┼──────────────┼──────────────┼──────────────┤
│ S2 (Google) │ O(log n)     │ Best         │ Uber uses    │
└─────────────┴──────────────┴──────────────┴──────────────┘
```

**Geohash Concept:**

```
GEOHASH — Location ko string mein encode
═══════════════════════════════════════

World ko recursively divide karo (like quad tree)
"tdnu" = Delhi region
"tdnu" + more chars = more precise

  ┌─────────────────────────────────┐
  │  World                           │
  │    ┌─────────┬─────────┐        │
  │    │  0      │   1     │        │
  │    ├─────────┼─────────┤        │
  │    │  2      │   3     │        │
  │    └─────────┴─────────┘        │
  │  Each cell = 1 character         │
  │  "t" = certain region            │
  │  "td" = smaller region           │
  └─────────────────────────────────┘

Redis: GEOADD + GEORADIUS = built-in!
```

### 6.2 Matching Algorithm

```
MATCHING STEPS
══════════════

1. Rider pickup (lat, lng) → Geohash/S2 cell
2. Query: Drivers in same cell + adjacent cells (radius)
3. Filter: status = AVAILABLE, rating > 4.0
4. Sort by: ETA to pickup (nearest first)
5. Select top 1 (or broadcast to multiple, first accept wins)
6. Assign + Notify
```

### 6.3 ETA Calculation

```
ETA = f(distance, traffic, road type)

Simple: Haversine distance / avg_speed
Better: Historical data + real-time traffic (Google Maps API, etc.)
```

### 6.4 Surge Pricing

```
SURGE LOGIC
═══════════

demand = (ride requests in last 10 min in area)
supply = (available drivers in area)

if demand / supply > threshold:
    surge_multiplier = 1.5x, 2x, 2.5x, ...
else:
    surge_multiplier = 1.0x

Stored per geohash cell, updated every few minutes
```

### 6.5 WebSocket for Real-time Updates

```
REAL-TIME FLOW
══════════════

Driver App                    Server                     Rider App
    │                            │                            │
    │── Location (every 4s) ────▶│                            │
    │                            │── WebSocket push ─────────▶│
    │                            │   (driver_location)        │
    │                            │                            │
    │                            │◀── Rider views live map    │
```

### 6.6 Driver Availability State Machine

```
DRIVER STATES
═════════════

  OFFLINE ──▶ ONLINE (available) ──▶ ASSIGNED ──▶ ON_TRIP
      │              │                     │            │
      │              │                     │            │
      └──────────────┴─────────────────────┴────────────┘
                     (back to ONLINE after trip complete)

Only ONLINE drivers appear in "find nearby" query!
```

### 6.7 Fare Calculation Logic

```
FARE CALCULATION
════════════════

Base fare + (Distance × per_km) + (Time × per_min) × Surge

Example:
  Base: Rs 40
  Distance: 5 km × Rs 15/km = Rs 75
  Time: 15 min × Rs 2/min = Rs 30
  Surge: 1.5x
  Total: (40 + 75 + 30) × 1.5 = Rs 217.5
```

---

## 7. Bottlenecks & Scaling

### 7.1 Bottleneck Analysis

| Component | Bottleneck | Solution |
|-----------|------------|----------|
| **Location writes** | 1.25M/sec | Redis cluster, region sharding |
| **Geo queries** | Latency | Geohash/S2, in-memory |
| **Trip DB** | Writes | PostgreSQL + read replicas |
| **Real-time** | WebSocket connections | Dedicated WebSocket servers |

### 7.2 Scaling Strategies

```
SCALING CHECKLIST
═════════════════

1. Region-based sharding: India drivers → India Redis cluster
2. Location in Redis only; async batch to Cassandra for analytics
3. Trip service: Stateless, scale horizontally
4. Matching: Pre-filter by region, reduce query space
5. WebSocket: Sticky sessions, separate pool
```

---

## 8. Trade-offs

| Decision | Choice | Trade-off |
|----------|--------|-----------|
| **Location store** | Redis vs DB | Redis = fast, volatile; DB = persistent |
| **Matching** | Push (assign) vs Pull (driver selects) | Push = faster UX, Pull = driver choice |
| **Geo index** | Geohash vs S2 | Geohash = simple, S2 = more accurate |
| **Surge** | Real-time vs Batch | Real-time = complex, Batch = simpler |

---

## 9. 1 Minute Recall Block + 5 Bullet Memory Hooks

### 1 Minute Recall Block

> **Uber = Location (Redis) + Geospatial query (Geohash/S2) + Trip (PostgreSQL) + WebSocket (real-time)**
> Driver location har 3-5 sec Redis mein. Ride request aate hi geo query → nearest available driver. Match → assign → notify. Trip state strong consistency (PostgreSQL). Surge = demand/supply ratio. Scale = region sharding.

### 5 Bullet Memory Hooks

1. **Location in Redis** — 1M+ writes/sec, in-memory only, async to DB
2. **Geohash/GEORADIUS** — "2km mein drivers" = O(log n) query
3. **Trip state machine** — PENDING → ASSIGNED → IN_PROGRESS → COMPLETED
4. **WebSocket** — Real-time driver location to rider
5. **Region sharding** — Har region ka apna Redis cluster

---

*End of Uber Design — FAANG Interview Ready!*
