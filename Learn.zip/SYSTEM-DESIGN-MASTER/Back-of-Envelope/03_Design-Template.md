# Back-of-Envelope Estimation — Design Template

> **Permanent Recall:** Use fill-in-the-blank templates for any system. Templates standardize QPS, storage, bandwidth, and server count. Pre-filled examples for social media, chat, video, e-commerce give you starting points. Always adapt assumptions to the interview problem.

---

## Estimation Worksheet (Fill-in-the-Blank)

### QPS Estimation Template

```
DAU / MAU:           ____________
Actions per user:    ____________ / day
Read:Write ratio:    ____________ : 1

Total actions/day:   ____________
Average QPS:         ____________ / 86400 = ____________
Peak factor:         ____________ (2–10×)
Peak QPS:            ____________
```

---

### Storage Estimation Template

```
Items (or users × items/user):  ____________
Bytes per item:                  ____________
Replication factor:              ____________ (typically 3)
Metadata overhead:               ____________ (typically 20–30%)
Retention period:                 ____________

Total storage = ____________ × ____________ × ____________ × (1 + overhead)
             = ____________
```

---

### Bandwidth Estimation Template

```
QPS:                    ____________
Avg request size:       ____________ bytes
Avg response size:     ____________ bytes
Bidirectional?         [ ] Yes  [ ] No

Ingress:  QPS × request_size × 8 = ____________ bps
Egress:   QPS × response_size × 8 = ____________ bps
Total (if both):       ____________ bps ≈ ____________ Gbps
```

---

### Server Count Estimation Template

```
Peak QPS:              ____________
QPS per web server:   ~1000
QPS per DB (read):    ~5000
QPS per Redis:        ~100,000

Web servers needed:    ____________ / 1000 = ____________ (+ 20% headroom)
DB read replicas:     ____________ / 5000 = ____________
Cache servers:        ____________ (if cache hit ratio known)
```

---

## Pre-filled Examples

### Social Media (Twitter-like)

| Metric | Value |
|--------|-------|
| DAU | 300M |
| Tweets/user/day | 5 |
| Read:Write | 100:1 |
| Write QPS | ~17K |
| Read QPS | ~1.7M (avg), ~5M peak |
| Storage/year | ~50 TB (tweets + indexes) |
| Web servers | ~5000 (5M / 1K) |

---

### Chat (WhatsApp-like)

| Metric | Value |
|--------|-------|
| DAU | 2B |
| Messages/user/day | 50 |
| Read:Write | 1:1 |
| Message QPS | ~1.2M |
| Storage/year | ~4 PB (100B × 1KB × 3 replica) |
| Bandwidth | ~10 Gbps |

---

### Video Streaming (Netflix-like)

| Metric | Value |
|--------|-------|
| Subscribers | 200M |
| Streams/concurrent | 20% peak = 40M |
| Bitrate (1080p) | 5 Mbps avg |
| Storage (catalog) | 1000 titles × 2GB × 3 = 6 TB |
| Bandwidth (egress) | 40M × 5 Mbps = 200 Tbps (CDN) |

---

### E-commerce (Amazon-like)

| Metric | Value |
|--------|-------|
| DAU | 300M |
| Page views/user | 10 |
| Read:Write | 10:1 |
| Read QPS | 300M × 10 / 86400 ≈ 35K avg |
| Peak QPS | ~100K |
| Orders/day | ~10M → ~120 writes/sec |
| Storage | Products (TB) + Orders (PB over years) |

---

## Quick Reference Table

| System Type | DAU | Key Action | Read:Write | Dominant Metric |
|-------------|-----|------------|------------|-----------------|
| Social | 100M–1B | 5–20/day | 100:1 | Read QPS |
| Chat | 500M–2B | 30–100/day | 1:1 | Msg QPS, storage |
| Video | 50M–200M | 1–2 hrs | 1000:1 | Bandwidth, storage |
| E-commerce | 100M–300M | 5–15/day | 10:1 | Read QPS, orders |

---

## ASCII Template Flow

```
    ┌─────────────────────────────────────────────────────────────┐
    │                    ESTIMATION FLOW                           │
    ├─────────────────────────────────────────────────────────────┤
    │  Users ──► Actions/day ──► QPS ──► Servers (QPS/capacity)    │
    │    │                                                         │
    │    └──► Items × size ──► Storage ──► TB/PB                   │
    │                                                              │
    │  QPS × payload ──► Bandwidth ──► Gbps/Tbps                   │
    └─────────────────────────────────────────────────────────────┘
```

> **FAANG Tip:** Memorize one example per system type. In the interview, swap in the problem's numbers and explain assumptions.

---

## 30-SECOND REVISION BOX

```
TEMPLATES: QPS (DAU×actions/86400), Storage (items×size×replica), BW (QPS×size×8)
SOCIAL: 300M DAU, 100:1, ~5M read QPS
CHAT: 2B DAU, 1:1, ~1.2M msg/s, ~10 Gbps
VIDEO: 200M, 1080p 5Mbps, CDN bandwidth dominant
E-COMMERCE: 300M, 10:1, ~100K peak read QPS
```

---

**Next: [[04_Interview-Thinking]]**
