# CAP Theorem and Consistency — Tricks and Recognition

> **Permanent Recall:** Quick triggers: financial data → strong consistency; social media → eventual is fine; real-time collaborative → causal consistency. Use the consistency selection cheat sheet and common system → consistency model mapping to rapidly choose the right approach in interviews and design discussions.

---

## Quick Triggers: Domain → Consistency

| Domain / Data Type | Consistency | Why |
|--------------------|-------------|-----|
| **Financial (balance, transactions)** | Strong | Wrong = money lost |
| **Inventory, stock** | Strong | Oversell = broken promises |
| **Social media (likes, feed)** | Eventual | Staleness OK |
| **Real-time collaborative (Docs, Figma)** | Causal | Order matters, sync conflicts |
| **Session, auth token** | Read-your-writes | User must see own changes |
| **Distributed lock, leader** | Linearizable | Two holders = disaster |
| **Analytics, counters** | Eventual | Approximate OK |
| **Product catalog** | Eventual (or strong for price) | Stale product info usually OK |
| **Medical, dosing** | Strong | Safety-critical |

---

## Consistency Selection Cheat Sheet

```
STRONG (CP / Quorum):
  - Money, inventory, locks, leader
  - "Wrong data = harm"
  - HBase, ZooKeeper, quorum reads

EVENTUAL (AP):
  - Likes, feeds, counters, analytics
  - "Staleness acceptable"
  - Cassandra, DynamoDB default, CouchDB

CAUSAL:
  - Chat, comments, collaborative edit
  - "Order of events matters"
  - Causal DBs, session + version

READ-YOUR-WRITES:
  - Profile, settings, post creation
  - "User sees own writes"
  - Session stickiness, DynamoDB consistent read
```

---

## Common System → Consistency Model Mapping

| System | Default | Tunable? | Use Case |
|--------|---------|----------|----------|
| **HBase** | CP | No | Analytics, strong consistency |
| **MongoDB (replica set)** | CP | No | Document store, config |
| **Cassandra** | AP (ONE) | Yes (ONE, QUORUM, ALL) | Wide-column, flexible |
| **DynamoDB** | AP (eventual) | Yes (strong read option) | Key-value, serverless |
| **CouchDB** | AP | No | Document, offline-first |
| **Redis Cluster** | CP | No | Cache, sessions |
| **ZooKeeper** | CP | No | Coordination, locks |
| **etcd** | CP | No | Config, service discovery |
| **CockroachDB** | Strong | Yes | Distributed SQL |

---

## Interview Recognition: Keyword → Action

| Keyword in Question | Think | Say |
|---------------------|-------|-----|
| "Payment," "balance," "transfer" | Strong | "We need strong consistency—CP or quorum" |
| "Feed," "timeline," "social" | Eventual | "Eventual consistency is fine—AP" |
| "Inventory," "stock," "order" | Strong | "Strong—overselling is unacceptable" |
| "Like count," "view count" | Eventual | "Eventual—approximate is OK" |
| "Collaborative edit" | Causal | "Causal consistency—order of ops matters" |
| "Distributed lock" | Linearizable | "Linearizable—single writer" |
| "Session," "profile" | Read-your-writes | "RYW—user must see own updates" |

---

## Red Flags: When to Reconsider

| Red Flag | Action |
|----------|--------|
| "We need 100% consistency and 100% availability" | Explain CAP—not possible during partition |
| "We'll never have partitions" | Partitions happen; design for them |
| "Eventual is fine" for payment system | Strong required |
| "Strong consistency" for like count | Overkill; use eventual |
| No conflict strategy for multi-region | Define LWW, merge, or escalation |

---

## Quick Decision: One-Line Answers

- **"What consistency for payments?"** → Strong (CP or quorum)
- **"What consistency for feed?"** → Eventual (AP)
- **"What if we need both?"** → Tunable: strong for critical, eventual for rest
- **"How to prevent split brain?"** → Quorum election, odd N
- **"How to resolve conflicts?"** → LWW (simple), CRDT (merge), or application

---

## Pattern Recognition: Question Type → Response

| Question Type | Response Pattern |
|---------------|------------------|
| "Explain CAP" | Partition → C or A; P mandatory; examples |
| "Design X" | Data types → consistency per type → system choice |
| "CP or AP?" | Depends on stale-read tolerance; justify |
| "How does quorum work?" | R+W>N; overlap ensures fresh read |
| "What about conflicts?" | LWW, merge (CRDT), or application |

---

## 30-SECOND REVISION BOX

```
FINANCIAL → Strong. SOCIAL → Eventual. COLLABORATIVE → Causal.
CHEAT SHEET: Strong=harm, Eventual=OK, Causal=order
SYSTEMS: HBase/Mongo/ZK=CP, Cassandra/Dynamo=AP
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
