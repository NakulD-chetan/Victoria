# System Design Fundamentals — Question List

> **Permanent Recall:** Master the 10 MUST-DO questions for broad coverage. Progress through 30 questions: Easy (foundational) → Medium (FAANG core) → Hard (Staff+). Categories: Social Media, Messaging, Streaming, Infrastructure, E-commerce, Search, Real-time. Study order: foundational (URL shortener, rate limiter) first, then high-frequency (Twitter, YouTube, WhatsApp), then advanced (distributed cache, design Uber).

---

## 10 MUST-DO Questions

| # | Problem | Difficulty | Category | Company | Why Important |
|---|---------|-------------|----------|---------|---------------|
| 1 | **Design Twitter / X** | Medium | Social Media | Meta, Google, Twitter | Read-heavy feed, fan-out, caching, scale |
| 2 | **Design YouTube / Netflix** | Medium | Streaming | Google, Netflix, Meta | Video streaming, CDN, transcoding, recommendations |
| 3 | **Design WhatsApp / Chat** | Medium | Messaging | Meta, Google | Real-time, presence, messaging at scale |
| 4 | **Design a URL Shortener** | Easy | Infrastructure | Google, Amazon, Meta | Foundation; scaling, hashing, storage |
| 5 | **Design a Rate Limiter** | Easy | Infrastructure | All FAANG | Distributed systems, Redis, algorithms |
| 6 | **Design Google Search** | Hard | Search | Google | Crawling, indexing, ranking, scale |
| 7 | **Design a Distributed Cache** | Hard | Infrastructure | Meta, Google, Netflix | Consistency, eviction, partitioning |
| 8 | **Design Uber / Lyft** | Hard | Real-time | Uber, Lyft, Meta | Real-time matching, geo, ETA |
| 9 | **Design Instagram** | Medium | Social Media | Meta, Google | Photos, feeds, stories, discovery |
| 10 | **Design a Notification System** | Medium | Messaging | All FAANG | Push, multi-channel, fan-out |

---

## Complete 30-Question Progression

### Easy (Foundational) — 8 Questions

| # | Problem | Key Concepts | Expected Depth | Time |
|---|---------|--------------|----------------|------|
| 1 | URL Shortener | Hashing, base62, DB schema, scaling | Storage, redirect flow, collision | 30 min |
| 2 | Rate Limiter | Token bucket, sliding window, Redis | Algorithm, distributed, fail-open/closed | 30 min |
| 3 | Pastebin | Similar to URL shortener, expiry | Storage, access control | 25 min |
| 4 | Design TinyURL | Same as URL shortener | | 30 min |
| 5 | Web Crawler (basic) | BFS/DFS, politeness, dedup | Scale to millions of URLs | 35 min |
| 6 | Counter (like Twitter count) | Sharding, caching, eventual consistency | Approximate vs exact | 30 min |
| 7 | Design a Logging System | Append-only, batching, retention | Throughput, query patterns | 35 min |
| 8 | Design Parking Lot | OOP, state machines | Simpler; good for warm-up | 25 min |

### Medium (FAANG Level) — 14 Questions

| # | Problem | Key Concepts | Expected Depth | Time |
|---|---------|--------------|----------------|------|
| 9 | Design Twitter / Feed | Fan-out, cache, pull vs push | Feed generation, celebrity handling | 45 min |
| 10 | Design YouTube / Video | CDN, transcoding, streaming | HLS/DASH, quality switching | 45 min |
| 11 | Design WhatsApp / Chat | WebSockets, presence, sync | Ordering, offline, E2E | 45 min |
| 12 | Design Instagram | Photos, feeds, stories | Storage, CDN, feed merge | 45 min |
| 13 | Design a Notification System | Push, multi-channel, queue | FCM, APNs, fan-out | 40 min |
| 14 | Design Dropbox | Sync, conflict resolution, storage | Delta sync, versioning | 45 min |
| 15 | Design News Feed | Similar to Twitter | Pull vs push, ranking | 40 min |
| 16 | Design Autocomplete | Trie, prefix search, ranking | Scale, popular queries | 40 min |
| 17 | Design a URL Shortener (scale) | Sharding, rate limiting | 1B URLs, geo-routing | 40 min |
| 18 | Design a Blog / CMS | CRUD, search, CDN | Simpler; good for structure | 35 min |
| 19 | Design Yelp | Geo-search, reviews, recommendations | Spatial index, ranking | 45 min |
| 20 | Design a Ticketmaster | High concurrency, fairness | Preventing oversell, queues | 45 min |
| 21 | Design a Metrics System | Time-series, aggregation | Retention, downsampling | 40 min |
| 22 | Design a URL Crawler (scale) | Distributed, dedup, politeness | Bloom filter, rate limiting | 45 min |

### Hard (Staff+ Level) — 8 Questions

| # | Problem | Key Concepts | Expected Depth | Time |
|---|---------|--------------|----------------|------|
| 23 | Design Google Search | Crawling, indexing, PageRank | Full pipeline; ranking | 60 min |
| 24 | Design a Distributed Cache | Consistency, eviction, sharding | Memcached/Redis internals | 50 min |
| 25 | Design Uber | Real-time matching, geo, ETA | Consistency, surge, routing | 60 min |
| 26 | Design a Distributed Message Queue | Ordering, durability, scaling | Kafka-like; partitions | 50 min |
| 27 | Design a Global CDN | Edge, cache invalidation, routing | Geo-routing, consistency | 50 min |
| 28 | Design Slack | Channels, real-time, search | Scale, notifications | 50 min |
| 29 | Design a Stock Exchange | Low latency, fairness, order book | Matching engine | 55 min |
| 30 | Design a Distributed File System | GFS-like; chunks, master | Replication, consistency | 55 min |

---

## Categories Summary

| Category | Count | Example Problems |
|----------|-------|------------------|
| **Social Media** | 5 | Twitter, Instagram, News Feed |
| **Messaging** | 4 | WhatsApp, Notification, Slack |
| **Streaming** | 2 | YouTube, (Netflix variant) |
| **Infrastructure** | 10 | URL shortener, Rate limiter, Cache, CDN, Queue |
| **E-commerce** | 2 | Ticketmaster, (Marketplace) |
| **Search** | 3 | Google Search, Autocomplete, Yelp |
| **Real-time** | 2 | Uber, Chat |
| **Storage / Sync** | 2 | Dropbox, File system |

---

## Key Concepts by Question

| Problem | Concepts Tested |
|---------|-----------------|
| URL Shortener | Scaling, hashing, DB, collision, redirect |
| Rate Limiter | Algorithms, Redis, distributed, fail strategy |
| Twitter | Fan-out, cache, read-heavy, celebrity, sharding |
| YouTube | CDN, transcoding, HLS, adaptive bitrate |
| WhatsApp | WebSockets, presence, ordering, sync |
| Instagram | Storage, CDN, feed, stories |
| Notification | Push, multi-channel, queue, fan-out |
| Google Search | Crawl, index, rank, scale |
| Distributed Cache | Consistency, eviction, partitioning |
| Uber | Real-time, geo, ETA, surge |

---

## Study Order Recommendation

### Phase 1: Foundation (Week 1)
1. URL Shortener  
2. Rate Limiter  
3. Pastebin / TinyURL  

**Goal:** Nail the template and scaling basics.

### Phase 2: Core FAANG (Weeks 2–3)
4. Twitter  
5. YouTube  
6. WhatsApp  
7. Instagram  
8. Notification System  

**Goal:** Cover read-heavy, streaming, real-time, messaging.

### Phase 3: Breadth (Week 4)
9. Dropbox  
10. Autocomplete  
11. Yelp  
12. Ticketmaster  

**Goal:** Sync, search, geo, concurrency.

### Phase 4: Advanced (Weeks 5–6)
13. Google Search  
14. Distributed Cache  
15. Uber  

**Goal:** Staff-level depth.

---

## Time Allocation per Phase (Interview)

| Phase | Time | Focus |
|-------|------|-------|
| Requirements | 5 min | Scale, read:write, constraints |
| High-Level | 10 min | Components, data flow |
| Deep Dive | 20–25 min | 1–2 critical areas |
| Wrap-up | 5 min | Bottlenecks, failures |

---

## Quick Memory Card

```
10 MUST-DO:   Twitter, YouTube, WhatsApp, URL shortener, Rate limiter,
               Google Search, Distributed Cache, Uber, Instagram, Notification
EASY:         8 (URL shortener, rate limiter, pastebin, etc.)
MEDIUM:       14 (Twitter, YouTube, WhatsApp, Instagram, etc.)
HARD:         8 (Google Search, Cache, Uber, CDN, etc.)
STUDY ORDER:  Foundation → Core FAANG → Breadth → Advanced
COVERAGE:     Do 10 MUST-DO for ~80% pattern overlap
```

---

**Next: [[01_Concept]]** (Revision loop)
