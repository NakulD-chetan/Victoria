import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [];
  function mergeSort(lo, hi) {
    if (lo >= hi) return;
    const mid = Math.floor((lo + hi) / 2);
    steps.push({ type: 'split', lo, mid, hi, array: [...a] });
    mergeSort(lo, mid);
    mergeSort(mid + 1, hi);
    merge(lo, mid, hi);
  }
  function merge(lo, mid, hi) {
    const left = a.slice(lo, mid + 1), right = a.slice(mid + 1, hi + 1);
    let i = 0, j = 0, k = lo;
    while (i < left.length && j < right.length) {
      steps.push({ type: 'compare', li: lo + i, ri: mid + 1 + j, lo, hi, array: [...a] });
      if (left[i] <= right[j]) { a[k++] = left[i++]; } else { a[k++] = right[j++]; }
      steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a] });
    }
    while (i < left.length) { a[k++] = left[i++]; steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a] }); }
    while (j < right.length) { a[k++] = right[j++]; steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a] }); }
    steps.push({ type: 'merged', lo, hi, array: [...a] });
  }
  mergeSort(0, a.length - 1);
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 16) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function MergeSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'split') {
      for (let k = step.lo; k <= step.mid; k++) colors[k] = 'active';
      for (let k = step.mid + 1; k <= step.hi; k++) colors[k] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Split [${step.lo}..${step.mid}] | [${step.mid + 1}..${step.hi}]` });
    } else if (step.type === 'compare') {
      colors[step.li] = 'compare'; colors[step.ri] = 'compare';
      store.incComparisons();
    } else if (step.type === 'place') {
      colors[step.k] = 'merge';
      for (let k = step.lo; k <= step.hi; k++) if (k !== step.k) colors[k] = 'active';
    } else if (step.type === 'merged') {
      for (let k = step.lo; k <= step.hi; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Merged [${step.lo}..${step.hi}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
