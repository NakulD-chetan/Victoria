# Design Notification System — Tricks and Recognition

> **Permanent Recall:** Pipeline architecture is the pattern. Separate queues per channel (different SLAs). Rate limit per user AND globally. APNS and FCM have different protocols. This tests **queue-based architecture** and **third-party integration**.

---

## Key Insights (Tricks)

| # | Insight | Why It Matters |
|---|---------|----------------|
| 1 | **Pipeline: Event → Decide → Format → Deliver → Track** | Standard structure; scales each stage independently |
| 2 | **Separate queues per channel** | Push <10s; email relaxed; different workers, failure isolation |
| 3 | **Each channel = different third-party provider** | APNS ≠ FCM ≠ Twilio ≠ SendGrid; abstract behind interface |
| 4 | **Rate limit per user AND globally** | User: prevent fatigue; global: stay under provider limits |
| 5 | **At-least-once + idempotency** | Retries happen; idempotency key prevents duplicates |
| 6 | **Device token management** | Tokens invalidate; remove on 410; upsert on app launch |
| 7 | **Queue-based architecture** | Async always; 10B/day can't be synchronous |

---

## Recognition: What Problem Is This?

```
If they say: "Design a notification system"
They mean:  Multi-channel (push, SMS, email) delivery at scale
They test:  Pipeline design, queue architecture, third-party integration,
            rate limiting, user preferences, idempotency
```

---

## One-Liner Answers

| Question | One-Liner |
|----------|-----------|
| How do you deliver? | Async queue; workers call APNS/FCM/Twilio/SendGrid |
| Why separate queues? | Different SLAs (push <10s); isolate failures |
| How prevent duplicates? | Idempotency key; check Redis before send |
| How respect user prefs? | Check opt-in before enqueue; stored in DB, cached |
| How rate limit? | Per-user, per-channel in Redis; global token bucket for providers |
| Device token invalid? | Remove on 410/InvalidRegistration; don't retry |
| How schedule for later? | Delay queue / scheduler; trigger at `scheduled_at` |

---

## Pattern Recognition

```
Notification system ≈ Message queue system + Third-party API integration
                    + User preference service + Rate limiter

Not:  Simple "send email" CRUD
Not:  Real-time messaging (that's WebSockets)
```

---

## Mermaid: System Recognition

```mermaid
flowchart TD
    A[Notification System] --> B[Pipeline]
    A --> C[Multi-Channel]
    B --> D[Decide → Format → Deliver → Track]
    C --> E[Push / SMS / Email]
    E --> F[APNS / FCM / Twilio / SendGrid]
    A --> G[Cross-Cutting]
    G --> H[Rate Limit + Idempotency + Preferences]
```

---

## Interview Shortcuts

1. **First sentence:** "We'd use a pipeline: Event → Decide → Format → Deliver → Track, with separate queues per channel since push needs <10s and each provider is different."
2. **Channels:** "APNS for iOS, FCM for Android, Twilio for SMS, SendGrid for email — each has its own worker and queue."
3. **Rate limit:** "Per-user to prevent fatigue; globally to stay under provider limits like Twilio's 100 req/sec."
4. **Idempotency:** "We use an idempotency key so retries don't send duplicates."
5. **Scale:** "Async with queues — we'd never call providers synchronously at 10B/day."

---

## When to Mention Each Trick

| Context | Trick to Emphasize |
|---------|-------------------|
| "How do you design it?" | Pipeline + per-channel queues |
| "How handle different channels?" | Each provider different; separate workers |
| "How prevent spam?" | Rate limit per user |
| "Retry causes duplicates?" | Idempotency key |
| "Provider goes down?" | Circuit breaker; queue backs up |
| "10M users at once?" | Partitioning; batch to provider; rate limit enqueue |

---

## Combined Test Recognition

Notification system = **Queue-based architecture** + **Third-party integration** + **User preferences** + **Rate limiting**. Interviewers want to see: async design, provider abstraction, and production concerns (prefs, rate limit, idempotency).

---

## Quick Wins to Mention

- **Batch API calls:** FCM allows 500 messages per request; batch where possible
- **Template versioning:** Change template without breaking old notifications
- **Priority queues:** Urgent (security) processed before marketing
- **Circuit breaker:** Stop calling failing provider; retry after cooldown

---

## Differentiation from Other Designs

| vs Email Service | vs Alerting System | vs Chat/Messaging |
|------------------|-------------------|-------------------|
| Multi-channel (push, SMS, email) | User-facing; preferences; templates | One-to-one; real-time; different delivery |
| User preferences, rate limit | Often ops-focused; PagerDuty-style | WebSockets; different architecture |

---

## Recap: 7 Tricks

1. Pipeline: Decide → Format → Deliver → Track
2. Separate queues per channel
3. APNS/FCM/Twilio/SendGrid — each different
4. Rate limit per user and globally
5. At-least-once + idempotency
6. Device token invalidation handling
7. Queue-based = async always

---

## Final Recognition

When you hear "Design a notification system," think: **pipeline**, **per-channel workers**, **third-party providers**, **rate limiting**, **idempotency**. The pipeline is the skeleton; the rest fills in production requirements.

---

## Memory Hook

"**PDF** — Pipeline (Decide, Format, Deliver). **QRI** — Queues per channel, Rate limit, Idempotency." Repeat when starting the design.
