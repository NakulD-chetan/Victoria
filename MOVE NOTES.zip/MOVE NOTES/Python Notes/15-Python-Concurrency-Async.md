# Python Concurrency and Async

> *"GIL — one thread runs bytecode at a time"* — CPython reality (high level)

Threading, multiprocessing, **GIL**, `asyncio`, `concurrent.futures` — when to use what is an interview favorite. After [[14-Python-Functional-Programming]], scaling I/O and performance.

---

## 1. Threading — `threading` module

> **Definition:** Threading runs multiple threads of control in one process, sharing memory, with the OS scheduling which thread runs when.

**Why we need it:** While one thread waits on I/O, others can run—so overlapping network or disk waits improves throughput without multiple processes.

**Syntax:**
```python
import threading
t = threading.Thread(target=<callable>, args=(<args>,), kwargs={<kwargs>})
t.start()
t.join()
```

```python
import threading

def worker(n):
    print("task", n)

threads = [threading.Thread(target=worker, args=(i,)) for i in range(3)]
# Creates 3 threads, each will run worker() with different number

for t in threads:
    t.start()    # Starts each thread — they run SIMULTANEOUSLY (concurrent)

for t in threads:
    t.join()     # Waits for each thread to finish before continuing
```

**Use case:** **I/O bound** — network wait, disk wait — while one thread waits, others can run (OS level).

---

## 2. GIL (Global Interpreter Lock)

> **Definition:** The GIL is a mutex in CPython that allows only one thread at a time to execute Python bytecode in a single interpreter process.

**Why we need it:** It simplifies memory management (reference counting) and internal interpreter state at the cost of limiting parallel CPU work for pure Python on multiple cores.

**Syntax:**
```text
# Not a language construct — CPython implementation detail.
# Implication: <thread1_bytecode> and <thread2_bytecode> do not run in parallel on multiple cores for CPU-bound pure Python.
```

- In **CPython** the GIL means **one thread** runs core interpreter bytecode at a time
- **CPU-bound** pure Python threads often **don't scale** across cores

| Workload | Threads (CPython) | Processes |
|----------|-------------------|-----------|
| I/O bound (waiting for network/disk) | Works well — threads wait efficiently | More overhead than needed |
| CPU-bound (heavy calculations) | Limited — GIL blocks true parallel | **multiprocessing** is better (true parallel) |

**Interview Tip:** The GIL is **not** a rule of the Python language — it's a **CPython** detail; `numpy` C code can release the GIL during heavy compute.

**Watch Out!** "Python threads are useless" is oversimplified; they're still useful for I/O concurrency.

---

## 3. Multiprocessing — true parallelism

> **Definition:** The `multiprocessing` module runs work in separate OS processes, each with its own Python interpreter and memory, enabling true parallel execution on multiple CPUs.

**Why we need it:** CPU-bound Python code does not scale across cores under the GIL; processes sidestep that by running independent interpreters.

**Syntax:**
```python
from multiprocessing import Pool, Process

if __name__ == "__main__":
    with Pool(<n>) as p:
        p.map(<callable>, <iterable>)
    # or Process(target=<callable>, args=(...))
```

```python
from multiprocessing import Pool

def square(x):
    return x * x

if __name__ == "__main__":
    with Pool(4) as p:               # Creates 4 separate processes (4 workers)
        print(p.map(square, range(10)))  # Distributes work across all 4 processes
# Each process has its OWN memory — truly runs in parallel on multiple CPU cores
```

**Watch Out!** On Windows the `if __name__ == "__main__":` guard is **required** — spawn issues.

---

## 4. `concurrent.futures` — high-level API

> **Definition:** `concurrent.futures` provides high-level executor objects that submit callables to a pool of threads or processes and expose results via `Future` objects.

**Why we need it:** It wraps the low-level threading/multiprocessing APIs with a uniform “submit work, collect results” pattern that is easier to compose and reason about.

**Syntax:**
```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

with <ThreadPoolExecutor|ProcessPoolExecutor>(max_workers=<n>) as ex:
    fut = ex.submit(<callable>, <args>)
    for f in as_completed(<list_of_futures>):
        f.result()
```

```python
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

def fetch(url):
    return len(url)  # demo

urls = ["a", "bb", "ccc"]
with ThreadPoolExecutor(max_workers=4) as ex:
    futs = [ex.submit(fetch, u) for u in urls]
    for f in as_completed(futs):
        print(f.result())
```

| Executor | When to use |
|----------|------|
| `ThreadPoolExecutor` | I/O bound work (downloading, reading files, API calls) |
| `ProcessPoolExecutor` | CPU-heavy work (math, image processing, data crunching) |

---

## 5. `asyncio` — cooperative concurrency

> **Definition:** `asyncio` is a library for cooperative concurrency: coroutines (`async def`) yield control at `await` points while a single-thread event loop runs I/O and other tasks.

**Why we need it:** Many simultaneous network or disk waits don’t need one OS thread per connection; async scales cheap waiting with structured `async`/`await` instead of huge thread pools.

**Syntax:**
```python
import asyncio

async def <name>(<args>):
    await <awaitable>

async def main():
    await asyncio.gather(<coro1>, <coro2>, ...)

asyncio.run(main())
```

**async/await** — single-thread event loop, **non-blocking I/O**:

```python
import asyncio

async def say_after(delay, msg):    # async def = this function can PAUSE and RESUME
    await asyncio.sleep(delay)      # await = PAUSE here, let other tasks run while waiting
    print(msg)

async def main():
    await asyncio.gather(           # Run BOTH tasks at the same time (concurrent)
        say_after(1, "one"),        # Waits 1 second
        say_after(2, "two"),        # Waits 2 seconds — but runs AT SAME TIME as above!
    )
    # Total time: ~2 seconds (not 3!) because they run concurrently

asyncio.run(main())                 # Starts the async event loop and runs main()
```

- `async def` = creates a **coroutine** (a function that can pause and resume)
- `await` = "pause here until this is done, meanwhile other tasks can run"
- `asyncio.run()` = starts the event loop that manages all the async tasks

**Interview Tip:** `asyncio` does **not** give you **parallel CPU** — **concurrent waiting**; for CPU-heavy work use processes / native libs.

---

## 6. Running blocking code in async

> **Definition:** Blocking code in async is synchronous work (file I/O, CPU-heavy Python, legacy APIs) that runs to completion without yielding, freezing the event loop until it finishes.

**Why we need it:** The loop can’t switch tasks while a blocking call runs; offloading that work to a thread or process pool keeps other coroutines responsive.

**Syntax:**
```python
import asyncio

loop = asyncio.get_running_loop()
result = await loop.run_in_executor(<executor_or_None>, <callable>, *args)
```

```python
import asyncio
from functools import partial

async def main():
    loop = asyncio.get_running_loop()
    result = await loop.run_in_executor(None, partial(open, "file.txt"))
    # real code: wrap blocking I/O carefully
```

---

## 7. When to use what — summary table

> **Definition:** This summary matches concurrency models (threads, processes, async pools) to workload types so you pick the right tool instead of defaulting to one approach.

**Why we need it:** Wrong choices waste cores (GIL + CPU threads), add overhead (processes for tiny I/O), or block the event loop; a clear map prevents those mistakes in design and interviews.

**Syntax:**
```text
I/O-bound + many waits     → threading or asyncio
CPU-bound Python           → multiprocessing / native extensions
Uniform pool API           → concurrent.futures executors
```

| Tool | How it works | Best for |
|------|-------|----------|
| Threads | Multiple threads share memory, GIL limits CPU | Waiting for network/disk (I/O) |
| `asyncio` | Single thread, event loop switches between tasks | Many connections, async libraries |
| Multiprocessing | Separate processes, own memory each | Heavy CPU calculations |
| `futures` | Easy pool-based API for threads/processes | Clean, simple task submission |

---

## 8. Synchronization primitives (threading)

> **Definition:** Synchronization primitives (locks, events, semaphores, queues) coordinate access to shared mutable state across threads so updates happen atomically and predictably.

**Why we need it:** Without coordination, two threads can read/write the same data interleaved and corrupt it; primitives define who may enter critical sections and in what order.

**Syntax:**
```python
import threading

lock = threading.Lock()
with lock:
    <mutate_shared_state>

# threading.Event(), threading.Semaphore(), queue.Queue() — same idea: coordinate access
```

```python
import threading

lock = threading.Lock()
with lock:               # Only ONE thread can be inside this block at a time
    shared_data += 1     # Safe to modify shared data here (others wait outside)

# Lock = "only one at a time" → prevents race conditions
```

`Event`, `Semaphore`, `Queue` — producer-consumer patterns.

**Watch Out!** Deadlocks — lock ordering, timeouts; keep critical sections small.

---

## 9. `asyncio.gather` — parallel tasks

> **Definition:** `asyncio.gather` schedules multiple awaitables concurrently and `await`s until they all complete, returning their results in order (or optionally treating exceptions per task).

**Why we need it:** You often need several independent async operations at once (many fetches, parallel steps); `gather` is the standard way to run them together and collect outcomes in one expression.

**Syntax:**
```python
results = await asyncio.gather(<coro1>, <coro2>, ..., return_exceptions=False)
```

```python
import asyncio

async def slow(n):
    await asyncio.sleep(0.1)
    return n

async def main():
    results = await asyncio.gather(slow(1), slow(2), slow(3))
    print(results)

asyncio.run(main())
```

**Interview Tip:** `return_exceptions=True` — one failure doesn't fail everything.

---

## 10. `asyncio.create_task` — fire scheduling

> **Definition:** `asyncio.create_task` wraps a coroutine in a `Task` and schedules it on the current loop so it can run concurrently with other tasks before you explicitly `await` it.

**Why we need it:** Sometimes you must start work now and await later (pipelines, background work, overlapping I/O); tasks let the event loop progress multiple coroutines without sequential `await` chains only.

**Syntax:**
```python
task = asyncio.create_task(<coroutine>)
# ... do other awaitables ...
await task
```

```python
async def main():
    t = asyncio.create_task(slow(1))
    await t
```

---

## 11. CPU-bound + asyncio — antipattern

> **Definition:** This antipattern is putting long, CPU-heavy pure Python (or blocking libraries) directly inside `async def` without yielding, which stalls the entire event loop.

**Why we need it:** Async shines when tasks wait; CPU work must run elsewhere (thread/process pool or native code) so other coroutines and I/O keep making progress.

**Syntax:**
```python
# Bad:  heavy_python_work() inside async def with no await

# Better:
await loop.run_in_executor(None, heavy_python_work, *args)
```

Heavy Python compute inside `async def` **blocks** the loop — use `run_in_executor` or multiprocessing.

**Watch Out!** Libraries should be async (`aiohttp` vs blocking `requests`).

---

## Quick Memory Card

```
+------------------------------------------+
| THREADING                                 |
| - I/O bound OK                           |
| - GIL limits CPU-bound parallelism       |
+------------------------------------------+
| GIL                                       |
| - CPython bytecode single-threaded       |
| - C extensions may release               |
+------------------------------------------+
| MULTIPROCESSING                           |
| - separate memory — true parallel CPU    |
| - __main__ guard on Windows              |
+------------------------------------------+
| FUTURES                                   |
| - ThreadPool / ProcessPool               |
+------------------------------------------+
| ASYNCIO                                   |
| - async/await cooperative                |
| - great for many connections             |
+------------------------------------------+
| SYNC                                      |
| - Lock for shared mutable state          |
+------------------------------------------+
```

---

*Next: [[16-Python-Advanced-Topics]]*
