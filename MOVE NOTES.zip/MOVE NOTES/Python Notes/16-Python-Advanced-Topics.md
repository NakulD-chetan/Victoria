# Python Advanced Topics

> *"Metaclasses are deeper magic than 99% of users should ever worry about"* — Tim Peters (paraphrase)

Decorators (deep), metaclasses, descriptors, `__slots__`, dataclasses, type hints, walrus `:=`, structural pattern matching — senior Python interviews differentiate here. Prerequisites: [[05-Python-Functions-Scope]], [[07-Python-OOP-Classes-Objects]], [[09-Python-Encapsulation-Special-Methods]].

---

## 1. Decorators — deeper patterns

> **Definition:** A decorator is a callable that takes a function (or class) and returns a replacement that adds behavior; “deeper” patterns include parameterized decorators and class-based decorators using `__call__`.

**Why we need it:** Cross-cutting concerns (logging, retries, auth, timing) stay out of business logic; factories and classes extend decorators beyond a single `def wrapper` pattern.

**Syntax:**
```python
def <factory>(<params>):
    def deco(fn):
        def wrapper(*args, **kwargs):
            ...
        return wrapper
    return deco

class <Decorator>:
    def __init__(self, fn): ...
    def __call__(self, *args, **kwargs): ...
```

### Decorator with arguments

```python
def repeat(n):
    def deco(fn):
        def wrapper(*args, **kwargs):
            for _ in range(n):
                fn(*args, **kwargs)
        return wrapper
    return deco

@repeat(3)
def hi():
    print("hi")
```

### Class as decorator

```python
class CountCalls:
    def __init__(self, fn):
        self.fn = fn
        self.count = 0
    def __call__(self, *args, **kwargs):
        self.count += 1
        return self.fn(*args, **kwargs)

@CountCalls
def add(a, b):
    return a + b
```

**Interview Tip:** Decorators = higher-order functions — logging, auth, timing.

---

## 2. Descriptors — attribute protocol

> **Definition:** A descriptor is an object defining `__get__`, `__set__`, and/or `__delete__` that customizes what happens when an attribute is accessed on an instance through the descriptor protocol.

**Why we need it:** You get reusable, composable validation, lazy loading, and computed fields; `property` is a descriptor—this is the general mechanism behind “smart” attributes.

**Syntax:**
```python
class <Descriptor>:
    def __get__(self, obj, objtype=None): ...
    def __set__(self, obj, value): ...
    def __delete__(self, obj): ...
```

```python
class Positive:
    def __set_name__(self, owner, name):
        self.name = name

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        return obj.__dict__[self.name]

    def __set__(self, obj, value):
        if value < 0:
            raise ValueError("must be >= 0")
        obj.__dict__[self.name] = value

class Box:
    w = Positive()
    h = Positive()
```

**Watch Out!** `property` is a descriptor — descriptors are the general mechanism.

---

## 3. Metaclasses

> **Definition:** A metaclass is a subclass of `type` whose `__new__` / `__init__` run when a class object is created, letting you customize class construction (attributes, bases, namespace).

**Why we need it:** Frameworks can register models, enforce invariants, or inject methods automatically; everyday apps rarely need metaclasses, but interviews expect you to know they exist.

**Syntax:**
```python
class <Meta>(type):
    def __new__(mcls, name, bases, namespace, **kw):
        cls = super().__new__(mcls, name, bases, namespace)
        ...
        return cls

class <Cls>(metaclass=<Meta>):
    ...
```

```python
class Meta(type):
    def __new__(mcls, name, bases, namespace, **kw):
        cls = super().__new__(mcls, name, bases, namespace)
        cls.class_label = name.upper()
        return cls

class Point(metaclass=Meta):
    pass

Point.class_label  # 'POINT'
```

**Interview Tip:** ORMs / APIs — rare in everyday app code.

---

## 4. `__slots__`

> **Definition:** `__slots__` is a class-level tuple of attribute names that tells Python to store those attributes in fixed slots instead of a per-instance `__dict__`.

**Why we need it:** Many small objects pay a large memory cost for `__dict__`; slots cut memory and can speed attribute access, while preventing arbitrary new attributes.

**Syntax:**
```python
class <Name>:
    __slots__ = ("<attr1>", "<attr2>", ...)
```

```python
class Point:
    __slots__ = ("x", "y")    # Tells Python: "this class ONLY has x and y, nothing else"
    def __init__(self, x, y):
        self.x, self.y = x, y

# p = Point(1, 2)
# p.z = 3  # ERROR — can't add new attributes not in __slots__
```

- **Less memory** — Python doesn't create a `__dict__` for each object (saves space)
- **Faster access** — attributes stored in fixed slots instead of dictionary lookup
- **Restricted** — can only have attributes listed in `__slots__`

**Watch Out!** Multiple inheritance + slots — tricky rules.

---

## 5. Dataclasses

> **Definition:** The `@dataclass` decorator generates boilerplate methods (`__init__`, `__repr__`, `__eq__`, and optionally ordering) from field annotations on a class.

**Why we need it:** Data carriers no longer need hand-written constructors and comparisons; you get safe defaults for mutable fields via `field(default_factory=...)`.

**Syntax:**
```python
from dataclasses import dataclass, field

@dataclass(order=<bool>, frozen=<bool>)
class <Name>:
    <field>: <type> = <default_or_field(...)>
```

```python
from dataclasses import dataclass, field
from typing import List

@dataclass(order=True)            # Auto-generates __init__, __repr__, __eq__, comparison methods
class User:
    id: int                        # Just declare fields — Python writes the boilerplate for you
    name: str
    tags: List[str] = field(default_factory=list)  # Mutable default done safely
```

- `@dataclass` = Python **auto-creates** `__init__`, `__repr__`, `__eq__` for you — less code!
- `order=True` = also auto-creates comparison methods (`<`, `>`, etc.)
- `frozen=True` = makes object **immutable** (can't change fields after creation)
- `field(default_factory=list)` = safe way to have mutable default values

---

## 6. Type hints

> **Definition:** Type hints are annotations on parameters, return values, and variables that document expected types; static checkers like `mypy` use them; Python does not enforce them at runtime by default.

**Why we need it:** Large codebases catch bugs before runtime, IDEs autocomplete better, and APIs read clearly; gradual typing lets you adopt hints incrementally.

**Syntax:**
```python
def <name>(<arg>: <Type>, ...) -> <ReturnType>:
    ...

<var>: <Type> = <value>
Optional[<T>]   # or T | None (3.10+)
List[<T>], Dict[<K>, <V>], Callable[[<Args>], <Ret>]
```

```python
from typing import Optional, List, Dict, Callable

def process(items: List[int], key: Optional[str] = None) -> Dict[str, int]:
    # items: must be a list of integers
    # key: can be a string OR None (Optional means "this or None")
    # -> returns a dict with string keys and int values
    return {"count": len(items)}
```

- Type hints are **documentation** — they tell YOU and your IDE what types to expect
- Python does **NOT enforce** them at runtime — `mypy` tool checks them separately
- `Optional[str]` = "can be str or None"
- `List[int]` = "a list containing integers"

```python
def add(a: int, b: int) -> int:
    return a + b
```

`from __future__ import annotations` — forward refs easier.

---

## 7. Walrus `:=` (3.8+)

> **Definition:** The walrus operator `:=` assigns to a name and evaluates to that value inside an expression, so you can bind and test or use the value in one line.

**Why we need it:** It avoids duplicate work (e.g. calling a function once in `if` and again in the body) and keeps loop/read patterns compact while staying readable.

**Syntax:**
```python
if (<name> := <expression>) <comparison>:
    ...  # use <name>

while (<line> := <read>) != sentinel:
    ...
```

```python
if (n := len(data)) > 10:    # := assigns AND returns value in one step
    print("big", n)           # n is available here — no need for separate line

while (line := f.readline()) != "":  # Reads line AND checks if empty in one expression
    process(line)
# Walrus := = "assign a value AND use it in the same expression"
```

---

## 8. Structural pattern matching (3.10+)

> **Definition:** Structural pattern matching (`match` / `case`) compares a subject value against patterns that can destructure sequences, match classes, capture bindings, and include guards.

**Why we need it:** Complex branching on shape and types becomes explicit and exhaustive compared to long `if`/`elif` chains; parsers and command dispatch are common uses.

**Syntax:**
```python
match <subject>:
    case <pattern>:
        ...
    case <pattern> if <guard>:
        ...
    case _:
        ...
```

```python
def handle(cmd):
    match cmd:
        case ["get", url]:
            return f"GET {url}"
        case ["post", url, body]:
            return f"POST {url} {body}"
        case _:
            raise ValueError("bad")
```

---

## 9. `TYPE_CHECKING` — circular import hack

> **Definition:** `TYPE_CHECKING` is a constant from `typing` that is `False` at runtime and `True` to static type checkers, so imports under `if TYPE_CHECKING:` exist only for typing.

**Why we need it:** Type hints often need types from modules that would create import cycles at runtime; conditional imports break the cycle while keeping annotations accurate.

**Syntax:**
```python
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from <module> import <Type>

def f(x: "<Type>") -> None:
    ...
```

```python
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from models import User

def f(u: "User") -> None:
    ...
```

---

## 10. `typing.Protocol` — structural subtyping

> **Definition:** A `Protocol` describes an interface by required methods and attributes; any object that implements those members is considered compatible (structural subtyping), without inheritance.

**Why we need it:** Duck typing stays flexible while satisfying type checkers; you document “anything with `.draw()`” without forcing a shared base class.

**Syntax:**
```python
from typing import Protocol

class <Name>(Protocol):
    def <method>(self, ...) -> <Ret>: ...

def use(x: <Name>) -> None:
    x.<method>(...)
```

```python
from typing import Protocol

class Drawable(Protocol):
    def draw(self) -> None: ...

def render(obj: Drawable) -> None:
    obj.draw()
```

Makes duck typing **type checker** friendly.

**Interview Tip:** Gradual typing in large codebases — Protocol + `TypedDict`.

---

## 11. `Enum` — related constants

> **Definition:** An `Enum` groups named constants with distinct values so you use symbolic names instead of raw strings or integers scattered through code.

**Why we need it:** Autocomplete, validation, and comparisons stay consistent; refactoring and APIs are clearer than magic values.

**Syntax:**
```python
from enum import Enum, auto

class <Name>(Enum):
    <MEMBER> = <value_or_auto()>
```

```python
from enum import Enum, auto

class Color(Enum):
    RED = auto()
    GREEN = auto()
```

---

## Quick Memory Card

```
+------------------------------------------+
| DECORATORS                                |
| - factory returns decorator              |
| - class __call__ decorator               |
+------------------------------------------+
| DESCRIPTORS                               |
| - __get__ __set__ __delete__            |
+------------------------------------------+
| METACLASS                                 |
| - type subclass — frameworks             |
+------------------------------------------+
| __slots__                                 |
| - memory, fixed attrs                    |
+------------------------------------------+
| DATACLASS                                 |
| - field(default_factory=)                |
+------------------------------------------+
| TYPE HINTS                                |
| - Optional, List, Callable               |
+------------------------------------------+
| WALRUS :=                                 |
| - assign in expression                   |
+------------------------------------------+
| MATCH/CASE                                |
| - patterns                               |
+------------------------------------------+
```

---

*Next: [[17-Python-FAANG-Interview-Must-Know]]*
