import { existsSync } from 'fs';
import { readFile } from 'fs/promises';
import { dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const DEFAULT_CONFIG_PATH = resolve(__dirname, '..', 'localagent', 'config', 'config.ini');
const DEFAULT_OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';
const DEFAULT_OPENROUTER_MODEL = 'nex-agi/nex-n2-pro:free';

function parseIniSections(content) {
  const sections = {};
  let current = null;

  for (const rawLine of String(content || '').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;

    if (line.startsWith('[') && line.endsWith(']')) {
      current = line.slice(1, -1).trim();
      sections[current] = sections[current] || {};
      continue;
    }

    if (!current) continue;
    const equalsIndex = line.indexOf('=');
    if (equalsIndex === -1) continue;

    const key = line.slice(0, equalsIndex).trim();
    const value = line.slice(equalsIndex + 1).trim();
    sections[current][key] = value;
  }

  return sections;
}

function stripTrailingSlash(value) {
  return String(value || '').replace(/\/+$/, '');
}

function parseNumber(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function normalizeChatContent(message) {
  if (Array.isArray(message?.content)) {
    const parts = message.content
      .map((part) => {
        if (part?.type === 'text') {
          return { type: 'text', text: part.text || '' };
        }
        if (part?.type === 'image_url' && part.image_url?.url) {
          return {
            type: 'image_url',
            image_url: { url: part.image_url.url },
          };
        }
        return null;
      })
      .filter(Boolean);
    return parts.length ? parts : '';
  }

  if (typeof message?.content === 'string') return message.content;
  if (typeof message?.text === 'string') return message.text;
  return '';
}

export function normalizeMessages(messages) {
  return (messages || []).map((message) => ({
    role: message?.role === 'assistant' ? 'assistant' : 'user',
    content: normalizeChatContent(message),
  }));
}

export function extractMessageText(message) {
  if (!message) return '';
  if (typeof message.content === 'string') return message.content.trim();
  if (Array.isArray(message.content)) {
    return message.content
      .filter((part) => part?.type === 'text' && typeof part.text === 'string')
      .map((part) => part.text)
      .join('\n')
      .trim();
  }
  return '';
}

export function extractLatestUserText(messages) {
  for (let index = (messages || []).length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (message?.role !== 'user') continue;
    const content = normalizeChatContent(message);
    if (typeof content === 'string' && content.trim()) return content.trim();
    if (Array.isArray(content)) {
      const text = content
        .filter((part) => part?.type === 'text' && typeof part.text === 'string')
        .map((part) => part.text)
        .join('\n')
        .trim();
      if (text) return text;
    }
  }
  return '';
}

export async function loadCanvasAgentProvider() {
  const envApiKey = process.env.OPENROUTER_API_KEY?.trim();
  const envBaseUrl = process.env.OPENROUTER_BASE_URL?.trim();
  const envModel = process.env.OPENROUTER_MODEL?.trim();
  const configPath = process.env.CANVAS_AGENT_LOCALAGENT_CONFIG_PATH?.trim() || DEFAULT_CONFIG_PATH;

  let parsed = {};
  if (existsSync(configPath)) {
    const configContents = await readFile(configPath, 'utf8');
    parsed = parseIniSections(configContents);
  }

  const defaultSection = parsed.llm_default || parsed.llm || {};
  const apiKey = envApiKey || defaultSection.api_key || '';
  if (!apiKey) {
    throw new Error('Canvas agent could not find an OpenRouter API key. Set OPENROUTER_API_KEY or configure localagent/config/config.ini.');
  }

  return {
    provider: 'openrouter',
    source: envApiKey ? 'env' : 'localagent/config.ini',
    baseUrl: stripTrailingSlash(envBaseUrl || defaultSection.base_url || DEFAULT_OPENROUTER_BASE_URL),
    apiKey,
    model: envModel || defaultSection.model || DEFAULT_OPENROUTER_MODEL,
    maxTokens: parseNumber(process.env.OPENROUTER_MAX_TOKENS, parseNumber(defaultSection.max_tokens, 8192)),
    temperature: parseNumber(process.env.OPENROUTER_TEMPERATURE, parseNumber(defaultSection.temperature, 0)),
  };
}

function buildChatPayload({
  provider,
  systemPrompt,
  messages,
  tools,
  responseFormat,
  maxTokens,
  temperature,
  stream = false,
}) {
  const payload = {
    model: provider.model,
    messages: [
      { role: 'system', content: systemPrompt },
      ...messages,
    ],
    temperature,
    max_tokens: maxTokens,
    stream,
  };

  if (Array.isArray(tools) && tools.length > 0) {
    payload.tools = tools.map((tool) => ({
      type: 'function',
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));
    payload.tool_choice = 'auto';
  }

  if (responseFormat === 'json_object') {
    payload.response_format = { type: 'json_object' };
  }

  return payload;
}

function normalizeAssistantMessage(rawMessage) {
  if (!rawMessage) return { role: 'assistant', content: '', tool_calls: [] };
  return {
    role: 'assistant',
    content: rawMessage.content || '',
    tool_calls: Array.isArray(rawMessage.tool_calls) ? rawMessage.tool_calls : [],
  };
}

export async function createProviderChatCompletion({
  provider,
  systemPrompt,
  messages,
  tools,
  responseFormat,
  maxTokens,
  temperature,
  signal,
}) {
  const payload = buildChatPayload({
    provider,
    systemPrompt,
    messages,
    tools,
    responseFormat,
    maxTokens,
    temperature,
    stream: false,
  });

  const response = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify(payload),
    signal,
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Canvas agent provider error (${response.status}): ${errorText || response.statusText}`);
  }

  const json = await response.json();
  return {
    raw: json,
    message: normalizeAssistantMessage(json?.choices?.[0]?.message),
    usage: json?.usage || null,
  };
}

function parseSseFrames(buffer) {
  const frames = [];
  let searchIndex = 0;

  while (true) {
    const frameEnd = buffer.indexOf('\n\n', searchIndex);
    if (frameEnd === -1) break;
    frames.push(buffer.slice(searchIndex, frameEnd));
    searchIndex = frameEnd + 2;
  }

  return {
    frames,
    rest: buffer.slice(searchIndex),
  };
}

function applyToolDelta(targetToolCalls, deltaToolCalls) {
  for (const deltaToolCall of deltaToolCalls || []) {
    const index = Number.isFinite(deltaToolCall?.index) ? deltaToolCall.index : targetToolCalls.length;
    while (targetToolCalls.length <= index) {
      targetToolCalls.push({
        id: '',
        type: 'function',
        function: { name: '', arguments: '' },
      });
    }

    const current = targetToolCalls[index];
    if (deltaToolCall.id) current.id = deltaToolCall.id;
    if (deltaToolCall.type) current.type = deltaToolCall.type;
    if (deltaToolCall.function?.name) {
      current.function.name = deltaToolCall.function.name;
    }
    if (typeof deltaToolCall.function?.arguments === 'string') {
      current.function.arguments += deltaToolCall.function.arguments;
    }
  }
}

export async function streamProviderChatCompletion({
  provider,
  systemPrompt,
  messages,
  tools,
  responseFormat,
  maxTokens,
  temperature,
  onTextDelta,
  onToolDelta,
  signal,
}) {
  const payload = buildChatPayload({
    provider,
    systemPrompt,
    messages,
    tools,
    responseFormat,
    maxTokens,
    temperature,
    stream: true,
  });

  const response = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${provider.apiKey}`,
    },
    body: JSON.stringify(payload),
    signal,
  });

  if (!response.ok || !response.body) {
    const errorText = await response.text().catch(() => '');
    throw new Error(`Canvas agent streaming error (${response.status}): ${errorText || response.statusText}`);
  }

  const decoder = new TextDecoder();
  let buffer = '';
  let content = '';
  const toolCalls = [];

  for await (const chunk of response.body) {
    buffer += decoder.decode(chunk, { stream: true });
    const parsed = parseSseFrames(buffer);
    buffer = parsed.rest;

    for (const frame of parsed.frames) {
      const dataLines = frame
        .split('\n')
        .filter((line) => line.startsWith('data:'))
        .map((line) => line.slice(5).trim());

      if (!dataLines.length) continue;
      const data = dataLines.join('\n');
      if (data === '[DONE]') {
        return {
          message: {
            role: 'assistant',
            content,
            tool_calls: toolCalls,
          },
        };
      }

      const json = safeJsonParse(data);
      if (!json) continue;
      const delta = json?.choices?.[0]?.delta || {};

      if (typeof delta.content === 'string' && delta.content) {
        content += delta.content;
        if (typeof onTextDelta === 'function') {
          await onTextDelta(delta.content, content);
        }
      }

      if (Array.isArray(delta.tool_calls) && delta.tool_calls.length > 0) {
        applyToolDelta(toolCalls, delta.tool_calls);
        if (typeof onToolDelta === 'function') {
          await onToolDelta(toolCalls);
        }
      }
    }
  }

  return {
    message: {
      role: 'assistant',
      content,
      tool_calls: toolCalls,
    },
  };
}
