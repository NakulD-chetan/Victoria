# Graph — Common Mistakes

> **Permanent Recall:** Pattern mistakes = wrong algorithm choice, forgetting visited, off-by-one. Language-specific: C++ = vector bounds, Rust = ownership, Python = mutable default args.

---

## Pattern Mistakes (All Languages)

### 1. Wrong Algorithm for Shortest Path
- **Mistake:** DFS for unweighted shortest path
- **Fix:** BFS — first reach = shortest in unweighted
- **Mistake:** Dijkstra with negative weights
- **Fix:** Bellman-Ford

### 2. Forgetting Visited Check
- **Mistake:** Not marking visited before enqueue/push → infinite loop, duplicate processing
- **Fix:** Mark visited as soon as you discover the node

```
WRONG:                    RIGHT:
q.push(u)                 visited[u] = true
visited[u] = true  ←      q.push(u)
(another path can push u   (u won't be pushed again)
 before we pop it)
```

### 3. Topological Sort on Cyclic Graph
- **Mistake:** Running topo without cycle check
- **Fix:** Kahn's returns order only if |order| == n; else cycle. DFS topo: if back edge to GRAY, cycle.

### 4. BFS: Processing Before Visited Check
- **Mistake:** Process node before checking if already visited (when pushing same node from multiple parents)
- **Fix:** Check `if visited[u]: continue` at pop, or mark visited before push (preferred)

### 5. Dijkstra: Stale Heap Entries
- **Mistake:** Not skipping when `d > dist[u]` after pop
- **Fix:** `if d > dist[u]: continue` — we may have multiple (dist, u) in heap; only process best

### 6. Undirected Cycle: Forgetting Parent
- **Mistake:** Treating parent as cycle in undirected DFS
- **Fix:** Cycle = neighbor visited AND neighbor ≠ parent

### 7. 0-Indexed vs 1-Indexed
- **Mistake:** Problem says "nodes 1 to n" but using 0-indexed adj without adjustment
- **Fix:** Use `n+1` size, index 1..n; or subtract 1 when building graph

### 8. Matrix Bounds
- **Mistake:** `nr >= 0 and nr < rows` — wrong comparison (e.g. `nr <= rows`)
- **Fix:** `0 <= nr < rows` and `0 <= nc < cols`

---

## C++ Specific Mistakes

### 1. `vector<vector<int>>` Size
- **Mistake:** `adj(n)` with n=0 or wrong n
- **Fix:** Ensure n = number of vertices; check for empty graph

### 2. `priority_queue` Default is Max-Heap
- **Mistake:** `priority_queue<pair<int,int>>` for Dijkstra → gets max, not min
- **Fix:** `priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>>`

### 3. Integer Overflow
- **Mistake:** `dist[v] = dist[u] + w` with `int` when weights large
- **Fix:** Use `long long` for dist if sum can overflow

### 4. `INT_MAX` in Dijkstra
- **Mistake:** `dist[u] + w` overflow when dist[u] = INT_MAX
- **Fix:** Check `dist[u] != INT_MAX` before relax, or use `LLONG_MAX` / `numeric_limits<long long>::max()`

### 5. Modifying Graph During Traversal
- **Mistake:** Erasing edges while iterating
- **Fix:** Iterate over copy or use indices

### 6. `queue` vs `deque`
- **Mistake:** Using `queue` when need to push front (usually not for BFS)
- **Fix:** BFS uses `queue`; `deque` for double-ended ops

---

## Rust Specific Mistakes

### 1. Ownership in BFS/DFS
- **Mistake:** Moving `adj` into closure; need it for multiple iterations
- **Fix:** Pass `&adj` or `adj: &[Vec<usize>]`

### 2. `BinaryHeap` is Max-Heap
- **Mistake:** `BinaryHeap::new()` for Dijkstra → pops largest
- **Fix:** `BinaryHeap<Reverse<(i64, usize)>>` — wrap in `Reverse` for min-heap

### 3. `VecDeque` vs `Vec`
- **Mistake:** Using `Vec` for queue with `remove(0)` → O(n) per op
- **Fix:** `VecDeque::pop_front()` for O(1) BFS

### 4. `usize` vs `i32` for Weights
- **Mistake:** `usize` for weights → can't represent negative (if needed for Bellman-Ford)
- **Fix:** Use `i32`/`i64` for weights

### 5. Index Bounds
- **Mistake:** `adj[u]` when u might be out of bounds
- **Fix:** Validate `u < n` or use `get(u)`

### 6. Mutable Borrow Conflicts
- **Mistake:** Borrowing `visited` mutably in recursive DFS while also borrowing `adj`
- **Fix:** Pass `&mut visited` explicitly; ensure no overlapping mutable refs

### 7. `HashMap` vs `Vec` for Visited
- **Mistake:** `HashMap` for visited when nodes are 0..n-1 → slower
- **Fix:** `Vec<bool>` or `Vec<i32>` for O(1) lookup

---

## Python Specific Mistakes

### 1. Mutable Default Argument
- **Mistake:** `def dfs(u, visited=[]):` → shared across calls
- **Fix:** `def dfs(u, visited=None): visited = visited or []` or pass explicitly

### 2. `list.pop(0)` is O(n)
- **Mistake:** Using list as queue with `pop(0)`
- **Fix:** `from collections import deque`; `q.popleft()` O(1)

### 3. `heapq` Min-Heap
- **Mistake:** `heapq` is min-heap — correct for Dijkstra
- **Fix:** Push `(distance, node)` — tuple sorts by first element

### 4. `defaultdict(list)` vs `[[]]*n`
- **Mistake:** `adj = [[]]*n` → same list object n times!
- **Fix:** `adj = [[] for _ in range(n)]`

### 5. Integer vs Float for Infinity
- **Mistake:** `float('inf')` in some contexts (e.g. return type int)
- **Fix:** Use consistently; for dist, `float('inf')` is fine

### 6. Modifying List During Iteration
- **Mistake:** `for v in adj[u]: adj[u].remove(v)` — skips elements
- **Fix:** Iterate over `list(adj[u])` or use indices

### 7. Recursion Limit
- **Mistake:** Deep DFS on large graph → RecursionError
- **Fix:** Use iterative DFS with stack for large graphs

---

## Quick Reference Table

| Mistake | Language | Fix |
|---------|----------|-----|
| DFS for shortest path | All | BFS |
| No visited skip in Dijkstra pop | All | `if d > dist[u]: continue` |
| Topo on cycle | All | Check |order|==n or DFS cycle |
| Max-heap for Dijkstra | C++/Rust | greater<> / Reverse |
| pop(0) for queue | Python | deque.popleft() |
| [[]]*n | Python | [[] for _ in range(n)] |
| Moving adj in closure | Rust | Use &adj |
| INT_MAX overflow | C++ | Check before add; use long long |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Common Mistakes
WHEN TO USE:       Debugging, code review, interview prep
CORE IDEA:         Wrong algo (DFS for shortest); no visited; stale heap; parent in undirected
TIME:              N/A
SPACE:             N/A
INTERVIEW SENTENCE: "I'll use BFS for shortest path, mark visited before push,
                     and skip stale Dijkstra entries."
```

---

## 30-SECOND REVISION BOX

```
Pattern: BFS for shortest, not DFS; visited before push; topo only DAG
C++: priority_queue greater for min; long long if overflow
Rust: Reverse for min-heap; &adj not move; VecDeque not Vec
Python: deque not list.pop(0); [[] for _ in range(n)] not [[]]*n
```
