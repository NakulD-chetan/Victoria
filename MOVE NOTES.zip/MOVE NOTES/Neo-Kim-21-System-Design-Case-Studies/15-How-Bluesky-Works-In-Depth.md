# How Bluesky Works - In Depth (Easy Language)

> Companion to: [15-How-Bluesky-Works.md](15-How-Bluesky-Works.md)

---

## What Problem Does Bluesky Solve?

### The Problem with Twitter/X, Facebook, etc.

```
On Twitter/X:
  → ONE company controls everything:
    - What content you see (the algorithm)
    - What content is allowed (moderation)
    - Your identity (ban you = lose everything)
    - Your data (you can't take it elsewhere)
    - Your followers (leave Twitter = lose all followers)
  
  Problems:
    1. Biased moderation (one entity decides for billions)
    2. No data portability (locked into the platform)
    3. Algorithm you can't control (shows what THEY want you to see)
    4. Single point of failure (Twitter goes down = everyone affected)
```

### Bluesky's Vision

**What if social media worked like email?**

```
Email today:
  → Gmail user can email Yahoo user can email Protonmail user
  → You can switch from Gmail to Outlook without losing contacts
  → Gmail doesn't control what Outlook users see
  → Different providers, same protocol (SMTP)

Bluesky's goal:
  → Bluesky user can interact with other AT Protocol app users
  → You can move your account between servers
  → No single company controls the algorithm or moderation
  → Different apps, same protocol (AT Protocol)
```

---

## AT Protocol - The Foundation

### What Is ATProto?

AT Protocol (Authenticated Transfer Protocol) is an **open standard** for building social apps. Bluesky is just ONE app built on it. Others can build different apps on the same protocol.

```
AT Protocol = the highway system
Bluesky = one car driving on that highway
Future apps = other cars using the same highway

Your data travels on the highway
If you don't like Bluesky (the car), switch to another app
Your data (social graph, posts) stays on the highway
```

**Analogy**: ATProto is like Disneyland. Bluesky is ONE ride in the park. If someone builds another ride (a different social app on ATProto), you can use both with the same ticket and profile.

---

## User Repositories - You Own Your Data

### The Key Innovation

On Twitter, your data (tweets, likes, follows) lives on Twitter's servers. You have no control over it.

On Bluesky, each user has a **personal repository** (repo) -- like a personal folder of all your data.

```
Your repository contains:
  ├── posts/       (your posts)
  ├── likes/       (things you liked)
  ├── follows/     (who you follow)
  ├── profile/     (your name, avatar, bio)
  └── reposts/     (things you reposted)
```

**Important detail**: Your repo stores YOUR actions only. If someone likes YOUR post, that like is stored in THEIR repo (not yours).

### Portability

```
Today: Your repo lives on Bluesky's data server (PDS-1)

You decide to switch to another server (PDS-2):
  1. Export your repo from PDS-1
  2. Import it to PDS-2
  3. Your identity (DID), posts, followers -- everything moves!
  
  Like moving a Git repository from GitHub to GitLab.
  The code (your data) is the same, just hosted somewhere else.
```

### Technical Details

- Repos stored in **SQLite** (simple, lightweight, cheap)
- Data encoded in **CBOR** (Compact Binary Object Representation) -- smaller than JSON
- **6 million users** on a single server for **$150/month!** (incredibly cost-efficient)

---

## The Data Pipeline - How Everything Connects

```
Step 1: DATA SERVERS (PDS - Personal Data Server)
  ┌──────────────────────────────────┐
  │ PDS-1: Hosts 1M user repos      │
  │ PDS-2: Hosts 2M user repos      │
  │ PDS-3: Hosts 3M user repos      │
  └─────────────┬────────────────────┘
                │ WebSocket (real-time updates)
                ↓
Step 2: CRAWLER (RELAY)
  ┌──────────────────────────────────┐
  │ Subscribes to ALL data servers   │
  │ Collects every new post, like,   │
  │ follow from every user           │
  │ Creates a unified STREAM         │
  │ (called "firehose")              │
  └─────────────┬────────────────────┘
                │ Stream (append-only log via WebSocket)
                ↓
Step 3: INDEX SERVER (APP VIEW)
  ┌──────────────────────────────────┐
  │ Consumes the firehose            │
  │ Counts: likes per post,          │
  │   comments per post,             │
  │   reposts per post               │
  │ Makes data queryable             │
  └─────────────┬────────────────────┘
                │
                ↓
Step 4: FEED GENERATORS
  ┌──────────────────────────────────┐
  │ Custom algorithms that create    │
  │ different feeds:                 │
  │  - Chronological feed            │
  │  - Trending feed                 │
  │  - Topic-specific feed           │
  │  - YOUR custom algorithm!        │
  └──────────────────────────────────┘
```

### Why This Architecture?

Each layer does ONE thing well:
- **PDS**: Stores user data (simple, cheap)
- **Crawler**: Aggregates updates (no indexing, just forwarding)
- **Index Server**: Makes data searchable (aggregation)
- **Feed Generator**: Creates custom algorithms (content ranking)

They scale independently. Need more storage? Add more PDS servers. Need better search? Scale the index server.

---

## Feed Generators - YOU Choose Your Algorithm

### The Problem with Twitter/Facebook Algorithms

```
Twitter decides: "Show users engagement-bait content because it 
  maximizes time-on-app and ad revenue"
  
You have NO control over this. You can't say:
  "Show me only tech content, chronologically, no engagement bait"
```

### Bluesky's Approach

```
Feed generators are SEPARATE SERVICES that anyone can create:

Feed Generator A: "Chronological" (newest first, no algorithm)
Feed Generator B: "Trending Tech" (tech posts with most likes today)
Feed Generator C: "Quiet Following" (only people you follow, no viral posts)
Feed Generator D: "Cat Content" (ML model that detects cat photos)

You subscribe to whichever feed generators you like!
Don't like one? Unsubscribe and try another.
```

---

## Moderation (Labelers) - Community-Driven Content Rules

### The Problem with Centralized Moderation

```
Twitter/Facebook: One company decides what's allowed
  → Inconsistent decisions
  → Political bias (real or perceived)
  → Can't scale (millions of reports per day)
  → One-size-fits-all rules for the entire world
```

### Bluesky's Solution: Labelers

```
Labelers are independent services that TAG content:

Labeler A (Anti-spam): tags spam posts
Labeler B (NSFW filter): tags adult content
Labeler C (Fact-checking org): tags misinformation
Labeler D (Local community): tags content by language/region

YOU choose which labelers to trust:
  → Subscribe to Labeler A + B + C
  → Content tagged by those labelers gets filtered/flagged for you
  → Someone else might trust different labelers
  → No single authority decides for everyone
```

**Analogy**: It's like email spam filters. Gmail has its spam filter, Outlook has a different one, and you can install additional filters. No single entity decides what's spam for everyone.

---

## ATProto vs ActivityPub (Mastodon) - The Two Approaches

| Aspect | ATProto (Bluesky) | ActivityPub (Mastodon) |
|--------|-------------------|----------------------|
| **Your data** | Portable repo (move anywhere) | Lives on your server (hard to move) |
| **Your identity** | Global DID (works everywhere) | Tied to server (user@mastodon.social) |
| **Algorithm** | Custom feed generators (plug in any) | Mostly chronological |
| **Moderation** | Community labelers (your choice) | Server admin decides (per server) |
| **Architecture** | Relay/crawler aggregation | Server-to-server federation |
| **Cross-app** | Multiple apps on ATProto | Mainly microblogging |

**Mastodon's problem**: If your server admin decides to block another server, you lose access to those users. If your server shuts down, your account is gone (unless you migrated first).

**Bluesky's advantage**: Your repo is portable. If PDS-1 shuts down, export and move to PDS-2. Your identity and followers stay intact.

---

## Revision Flashcards

**Q: What is AT Protocol?**
A: An open protocol for building social apps. Bluesky is one app built on it. Users own their data in portable repositories, and multiple apps can share the same social graph.

**Q: How is Bluesky's architecture different from Twitter?**
A: Federated pipeline: Data Servers (store repos) → Crawler/Relay (aggregate updates) → Index Server (count likes/reposts) → Feed Generators (custom algorithms). No single company controls all layers.

**Q: What makes user data portable?**
A: Each user's data lives in a personal repo (SQLite) that can be exported and imported to any AT Protocol data server. Like moving a Git repo between GitHub and GitLab.

**Q: What are Feed Generators?**
A: Separate services that create custom content feeds (chronological, trending, topic-based). Users choose which feeds to follow. Anyone can create a feed generator.

**Q: What are Labelers?**
A: Community-run moderation services that tag content (spam, NSFW, misinformation). Users choose which labelers to trust. No single authority decides moderation for everyone.

**Q: How does Bluesky serve 6M users for $150/month?**
A: SQLite per user repo (lightweight) + CBOR encoding (compact binary) + minimal server-side processing (most computation pushed to crawler/index layers).
