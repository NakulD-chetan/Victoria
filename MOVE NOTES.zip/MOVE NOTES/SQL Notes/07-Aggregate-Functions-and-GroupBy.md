# Aggregate Functions & GROUP BY — Complete Guide

> **Aggregate Functions = Multiple rows ka data ek summary mein convert karo**
> COUNT, SUM, AVG, MIN, MAX — yeh sab aggregate functions hain.
> GROUP BY ke saath milke yeh bahut powerful ban jaate hain.

---

## Sample Table (Reference)

```
Table: sales
+----+----------+------------+--------+----------+------------+
| id | emp_name | department | amount | category | sale_date  |
+----+----------+------------+--------+----------+------------+
| 1  | Rahul    | North      | 5000   | Electronics | 2024-01-15 |
| 2  | Priya    | South      | 3000   | Clothing    | 2024-01-20 |
| 3  | Amit     | North      | 7000   | Electronics | 2024-02-10 |
| 4  | Sneha    | East       | 4500   | Clothing    | 2024-02-15 |
| 5  | Karan    | South      | 6000   | Electronics | 2024-03-01 |
| 6  | Neha     | North      | 2000   | Clothing    | 2024-03-10 |
| 7  | Rohan    | East       | 8000   | Electronics | 2024-03-20 |
| 8  | Divya    | South      | 3500   | Clothing    | 2024-04-05 |
| 9  | Arjun    | North      | NULL   | Electronics | 2024-04-15 |
+----+----------+------------+--------+----------+------------+
```

---

## 1. Aggregate Functions — Overview

> **Definition:** Aggregate functions perform a calculation on a set of values and return a single result.


| Function    | Kya Karta Hai       | NULL Handle           |
| ----------- | ------------------- | --------------------- |
| **COUNT()** | Rows count karo     | Depends on usage      |
| **SUM()**   | Sab values ka total | NULL ignore karta hai |
| **AVG()**   | Average nikalo      | NULL ignore karta hai |
| **MIN()**   | Sabse chhoti value  | NULL ignore karta hai |
| **MAX()**   | Sabse badi value    | NULL ignore karta hai |


> **VERY IMPORTANT:** Sab aggregate functions **NULL values ko ignore** karti hain (except COUNT(*))!

---

## 2. COUNT — Rows Count Karo

### COUNT(*) vs COUNT(column) vs COUNT(DISTINCT column):

```sql
-- COUNT(*): Sab rows count karo (NULL rows bhi)
SELECT COUNT(*) AS total_rows FROM sales;
-- Result: 

-- COUNT(column): Non-NULL values count karo
SELECT COUNT(amount) AS non_null_amounts FROM sales;
-- Result: 8 (Arjun ka NULL count nahi hua)

-- COUNT(DISTINCT column): Unique values count karo
SELECT COUNT(DISTINCT department) AS unique_depts FROM sales;
-- Result: 3 (North, South, East)
```

> **Interview Trap:**

```sql
SELECT COUNT(*)      FROM sales;  -- 9  (sab rows)
SELECT COUNT(amount) FROM sales;  -- 8  (NULL skip)
SELECT COUNT(1)      FROM sales;  -- 9  (same as COUNT(*))
```

> `COUNT(*)` aur `COUNT(1)` **same hain** — dono sab rows count karte hain.
> `COUNT(column)` mein **NULL skip** hota hai.

---

## 3. SUM — Total Nikalo

```sql
-- Total sales amount
SELECT SUM(amount) AS total_sales FROM sales;
-- Result: 39000 (NULL ignored)

-- Department wise total
SELECT department, SUM(amount) AS dept_total
FROM sales
GROUP BY department;
```

```
+------------+------------+
| department | dept_total |
+------------+------------+
| North      | 14000      |  ← 5000+7000+2000 (Arjun NULL ignored)
| South      | 12500      |  ← 3000+6000+3500
| East       | 12500      |  ← 4500+8000
+------------+------------+
```

> **NULL + 5000 = NULL** in normal math, but **SUM ignores NULL** → sirf valid values ka sum.

---

## 4. AVG — Average Nikalo

```sql
-- Overall average sale
SELECT AVG(amount) AS avg_sale FROM sales;
-- Result: 39000/8 = 4875 (8 non-NULL values se divide hua, 9 se nahi!)
```

> **IMPORTANT:** AVG bhi **NULL ignore** karta hai! 9 rows hain but 8 non-NULL values hain, toh 8 se divide hoga.

```sql
-- Agar NULL ko 0 maanke average chahiye:
SELECT AVG(COALESCE(amount, 0)) AS avg_with_null_as_zero FROM sales;
-- Result: 39000/9 = 4333.33
```

> **Interview Question:** "AVG mein NULL kaise handle hota hai?"
> **Answer:** AVG NULL values skip karta hai — na numerator mein count hota hai, na denominator mein!

---

## 5. MIN & MAX — Smallest & Largest

```sql
-- Sabse bada aur chhota sale
SELECT
    MIN(amount) AS min_sale,    -- 2000
    MAX(amount) AS max_sale     -- 8000
FROM sales;

-- Sabse pehli aur last sale date
SELECT
    MIN(sale_date) AS first_sale,   -- 2024-01-15
    MAX(sale_date) AS last_sale     -- 2024-04-15
FROM sales;
```

> MIN/MAX **strings pe bhi kaam karte hain** (alphabetical order):

```sql
SELECT MIN(emp_name), MAX(emp_name) FROM sales;
-- Result: Amit (A comes first), Sneha (S comes last alphabetically)
```

---

## 6. GROUP BY — Detailed Explanation

> **Aur depth:** buckets mental model, grain, JOIN double-count, DISTINCT/windows se farq — [[14-Deep-GROUP-BY]]

> **Definition:** GROUP BY groups rows that have the same values into summary rows. Each group becomes one row in the result.

### Visualize GROUP BY:

```
BEFORE GROUP BY (raw data):
  Rahul  - North - 5000
  Priya  - South - 3000
  Amit   - North - 7000
  Sneha  - East  - 4500
  Karan  - South - 6000
  Neha   - North - 2000
  Rohan  - East  - 8000
  Divya  - South - 3500
  Arjun  - North - NULL

AFTER GROUP BY department:
  ┌──────────────────────────────────┐
  │ North: Rahul(5K), Amit(7K),      │ → 1 result row
  │        Neha(2K), Arjun(NULL)     │
  ├──────────────────────────────────┤
  │ South: Priya(3K), Karan(6K),     │ → 1 result row
  │        Divya(3.5K)               │
  ├──────────────────────────────────┤
  │ East: Sneha(4.5K), Rohan(8K)    │ → 1 result row
  └──────────────────────────────────┘
```

### Multiple Column GROUP BY:

```sql
SELECT department, category, SUM(amount) AS total, COUNT(*) AS cnt
FROM sales
GROUP BY department, category;
```

```
+------------+-------------+-------+-----+
| department | category    | total | cnt |
+------------+-------------+-------+-----+
| North      | Electronics | 12000 | 2   |  ← North+Electronics group
| North      | Clothing    | 2000  | 1   |  ← North+Clothing group
| South      | Clothing    | 6500  | 2   |
| South      | Electronics | 6000  | 1   |
| East       | Clothing    | 4500  | 1   |
| East       | Electronics | 8000  | 1   |
+------------+-------------+-------+-----+
```

> **Yaad Rakho:** GROUP BY mein jitne columns doge, utne granular groups banenge.

---

## 7. HAVING — Groups Ko Filter Karo

```sql
-- Departments with total sales > 12000
SELECT department, SUM(amount) AS total
FROM sales
GROUP BY department
HAVING SUM(amount) > 12000;
```

```
+------------+-------+
| department | total |
+------------+-------+
| North      | 14000 |
| East       | 12500 |
| South      | 12500 |
+------------+-------+
```

### WHERE + GROUP BY + HAVING Together:

```sql
-- Step 1: WHERE filters rows (sirf Electronics)
-- Step 2: GROUP BY groups by department
-- Step 3: HAVING filters groups (total > 5000)
SELECT department, SUM(amount) AS electronics_total
FROM sales
WHERE category = 'Electronics'
GROUP BY department
HAVING SUM(amount) > 5000;
```

```
Execution:
1. WHERE category = 'Electronics' → 5 rows remain
2. GROUP BY department → 3 groups (North, South, East)
3. HAVING SUM > 5000 → Filter groups

Result:
+------------+-------------------+
| department | electronics_total |
+------------+-------------------+
| North      | 12000             |
| South      | 6000              |
| East       | 8000              |
+------------+-------------------+
```

---

## 8. GROUPING SETS, ROLLUP, CUBE (Advanced)

### GROUPING SETS — Specific Group Combinations:

```sql
-- PostgreSQL / SQL Server syntax
SELECT department, category, SUM(amount)
FROM sales
GROUP BY GROUPING SETS (
    (department),
    (category),
    ()
);
```

> Multiple GROUP BY results ek query mein!

### ROLLUP — Hierarchical Subtotals:

```sql
SELECT department, category, SUM(amount) AS total
FROM sales
GROUP BY ROLLUP (department, category);
```

```
+------------+-------------+-------+
| department | category    | total |
+------------+-------------+-------+
| North      | Electronics | 12000 |  ← Detail
| North      | Clothing    | 2000  |  ← Detail
| North      | NULL        | 14000 |  ← Subtotal for North
| South      | Electronics | 6000  |
| South      | Clothing    | 6500  |
| South      | NULL        | 12500 |  ← Subtotal for South
| East       | Electronics | 8000  |
| East       | Clothing    | 4500  |
| East       | NULL        | 12500 |  ← Subtotal for East
| NULL       | NULL        | 39000 |  ← Grand Total
+------------+-------------+-------+
```

> **ROLLUP** = Left to right hierarchical totals. Reports mein bahut useful.

### CUBE — All Possible Combinations:

```sql
SELECT department, category, SUM(amount) AS total
FROM sales
GROUP BY CUBE (department, category);
```

> CUBE = ROLLUP + har possible combination ka subtotal. CUBE se **cross-tab** report ban jaati hai.

---

## 9. Aggregate with CASE WHEN (Pivot Pattern)

> Bahut common interview pattern!

```sql
-- Row data ko columns mein convert karo (Pivot)
SELECT
    department,
    SUM(CASE WHEN category = 'Electronics' THEN amount ELSE 0 END) AS electronics,
    SUM(CASE WHEN category = 'Clothing' THEN amount ELSE 0 END) AS clothing,
    SUM(amount) AS total
FROM sales
GROUP BY department;
```

```
+------------+-------------+----------+-------+
| department | electronics | clothing | total |
+------------+-------------+----------+-------+
| North      | 12000       | 2000     | 14000 |
| South      | 6000        | 6500     | 12500 |
| East       | 8000        | 4500     | 12500 |
+------------+-------------+----------+-------+
```

> **Yeh pattern FAANG interviews mein bahut aata hai** — rows ko columns mein convert karna.

---

## 10. String Aggregates

### GROUP_CONCAT (MySQL) / STRING_AGG (PostgreSQL/SQL Server):

```sql
-- MySQL: Department wise employee names comma-separated
SELECT department, GROUP_CONCAT(emp_name ORDER BY emp_name) AS employees
FROM sales
GROUP BY department;

-- PostgreSQL:
SELECT department, STRING_AGG(emp_name, ', ' ORDER BY emp_name) AS employees
FROM sales
GROUP BY department;
```

```
+------------+---------------------------+
| department | employees                 |
+------------+---------------------------+
| North      | Amit, Arjun, Neha, Rahul |
| South      | Divya, Karan, Priya      |
| East       | Rohan, Sneha             |
+------------+---------------------------+
```

---

## Quick Memory Card


| Function   | Kya Karta Hai       | NULL?           | Example                 |
| ---------- | ------------------- | --------------- | ----------------------- |
| COUNT(*)   | Sab rows count      | ✅ Includes NULL | `COUNT(*)` → 9          |
| COUNT(col) | Non-NULL count      | ❌ Ignores NULL  | `COUNT(amount)` → 8     |
| SUM        | Total               | ❌ Ignores NULL  | `SUM(amount)` → 39000   |
| AVG        | Average             | ❌ Ignores NULL  | `AVG(amount)` → 4875    |
| MIN        | Smallest            | ❌ Ignores NULL  | `MIN(amount)` → 2000    |
| MAX        | Largest             | ❌ Ignores NULL  | `MAX(amount)` → 8000    |
| GROUP BY   | Groups banao        | N/A             | `GROUP BY department`   |
| HAVING     | Groups filter       | N/A             | `HAVING COUNT(*) > 2`   |
| ROLLUP     | Hierarchical totals | N/A             | Subtotals + Grand Total |
| CUBE       | All combinations    | N/A             | Cross-tab reports       |


> **Yaad Rakho:**
>
> - **WHERE** = rows filter (GROUP BY se pehle)
> - **HAVING** = groups filter (GROUP BY ke baad)
> - **All aggregates ignore NULL** (except COUNT(*))
> - **AVG divides by non-NULL count**, not total rows!

---

*Notes Source: SQL Aggregate Functions + Interview preparation material*