# Stack — Mental Model

> **Permanent Recall:** Stack = "waiting list." Elements in the stack are **waiting for their answer**. When a new element arrives that satisfies the condition (e.g., greater/smaller), it **answers** the waiting elements, then joins the list. This mental model unlocks monotonic stack intuition.

---

## How FAANG Engineers Think About Stack

1. **"What is each element waiting for?"** — Define the "answer" (next greater, next smaller, boundary)
2. **"When does the answer arrive?"** — When we scan an element that satisfies the condition
3. **"Who gets answered?"** — All elements in the stack that the new element dominates
4. **"What stays in the stack?"** — Elements still waiting (no answer found yet)

---

## The "Waiting List" Mental Model

```
SCENARIO: Next Greater Element (NGE)

Stack = people in line waiting for someone TALLER to stand behind them.
Each person (element) waits until a taller person (greater element) arrives.
When taller person arrives → they "answer" all shorter people in front.

  arr: [2, 1, 4, 3, 5]
  
  idx 0 (val 2): No one in line. Join. Stack: [0]
  idx 1 (val 1): 1 < 2, so 1 joins. Stack: [0, 1]
  idx 2 (val 4): 4 > 1! 4 is NGE for idx 1. Pop 1.
                  4 > 2! 4 is NGE for idx 0. Pop 0.
                  Stack: [2]
  idx 3 (val 3): 3 < 4, join. Stack: [2, 3]
  idx 4 (val 5): 5 > 3! NGE for 3. Pop 3.
                  5 > 4! NGE for 2. Pop 2.
                  Stack: [4]
  End: [4] → no one answered idx 4 → NGE = -1
```

---

## The "Temperature" Analogy (Daily Temperatures)

**Problem:** For each day, how many days until a warmer day?

```
Temperatures: [73, 74, 75, 71, 69, 72, 76, 73]
Answer:       [ 1,  1,  4,  2,  1,  1,  0,  0]

MENTAL MODEL: Stack = days waiting for a "warmer" day.

  Day 0 (73°): Join the wait. Stack: [0]
  Day 1 (74°): 74 > 73! Day 0 gets answer: 1 day. Pop 0. Stack: [1]
  Day 2 (75°): 75 > 74! Day 1 gets answer: 1 day. Pop 1. Stack: [2]
  Day 3 (71°): 71 < 75, join. Stack: [2, 3]
  Day 4 (69°): 69 < 71, join. Stack: [2, 3, 4]
  Day 5 (72°): 72 > 69! Day 4: 1 day. Pop 4.
               72 > 71! Day 3: 2 days. Pop 3.
               72 < 75, stop. Stack: [2, 5]
  ...
```

**Key insight:** The stack is always sorted by temperature (decreasing). New warmer day "melts" colder days from the top.

---

## Monotonic Stack: "Elements Waiting for Their Answer"

```mermaid
flowchart TD
    subgraph NGE["MONOTONIC DECREASING STACK (Next Greater Element)"]
        A1[New element X arrives]
        B1{X > top?}
        C1[X answers top - Pop, Repeat]
        D1[Push X - X waits for answer]
        A1 --> B1
        B1 -- Yes --> C1
        C1 --> B1
        B1 -- No --> D1
    end

    subgraph NSE["MONOTONIC INCREASING STACK (Next Smaller Element)"]
        A2[New element X arrives]
        B2{X < top?}
        C2[X answers top - Pop, Repeat]
        D2[Push X - X waits for answer]
        A2 --> B2
        B2 -- Yes --> C2
        C2 --> B2
        B2 -- No --> D2
    end

    style B1 fill:#ffd43b,color:#000
    style B2 fill:#ffd43b,color:#000
    style C1 fill:#51cf66,color:#fff
    style C2 fill:#51cf66,color:#fff
    style D1 fill:#339af0,color:#fff
    style D2 fill:#339af0,color:#fff
```



ASCII fallback

```
┌─────────────────────────────────────────────────────────────────┐
│  MONOTONIC DECREASING STACK (for Next Greater Element)         │
│                                                                 │
│  Bottom ←──────────────────────────────────────────────→ Top     │
│  [large, ..., small]                                            │
│                                                                 │
│  New element X arrives:                                         │
│  • If X > top: X is the "answer" for top. Pop. Repeat.          │
│  • If X ≤ top: Push X. X is now "waiting" for its answer.       │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  MONOTONIC INCREASING STACK (for Next Smaller Element)           │
│                                                                 │
│  Bottom ←──────────────────────────────────────────────→ Top     │
│  [small, ..., large]                                            │
│                                                                 │
│  New element X arrives:                                         │
│  • If X < top: X is the "answer" for top. Pop. Repeat.          │
│  • If X ≥ top: Push X. X is now "waiting" for its answer.       │
└─────────────────────────────────────────────────────────────────┘
```



---

## Why Store Indices (Not Values)?

```
If we store VALUES: We know "4" is next greater, but for WHICH index?
If we store INDICES: result[popped_index] = arr[current_index]

  When we pop index j, we're at index i.
  arr[i] is the next greater for arr[j].
  result[j] = arr[i]  (or i, depending on problem)
```

**Always store indices** — you need them for:

- Writing to the correct result slot
- Computing width (e.g., `right - left - 1` in histogram)
- Handling duplicates (indices are unique)

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL MODEL:     Stack = waiting list; new element "answers" those it dominates
NGE:              Decreasing stack; X > top → X answers top
NSE:              Increasing stack; X < top → X answers top
ANALOGY:          Daily temps = days waiting for warmer day
STORE:            Indices (never just values)
LOOP END:         Remaining stack elements have no answer (e.g., -1)
INTERVIEW LINE:   "Elements in the stack are waiting for their next greater.
                   When a larger element arrives, it answers them and joins."
```

