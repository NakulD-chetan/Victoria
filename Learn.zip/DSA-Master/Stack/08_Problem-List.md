# Stack — Problem List

> **Permanent Recall:** 30 problems, 10 MUST-DO. Focus on monotonic stack — it's the most tested stack pattern at FAANG. Study plan: Easy (Day 1–2) → Medium (Day 3–5) → Hard (Day 6–7).

---

## 10 MUST-DO (Priority Order)


| #   | LeetCode | Problem                        | Concept                    | Why MUST-DO                        |
| --- | -------- | ------------------------------ | -------------------------- | ---------------------------------- |
| 1   | **739**  | Daily Temperatures             | Monotonic stack (NGE)      | Classic NGE; asked at Meta, Google |
| 2   | **84**   | Largest Rectangle in Histogram | Monotonic stack            | FAANG favorite; tests boundaries   |
| 3   | **20**   | Valid Parentheses              | Simple stack               | Baseline; every interview          |
| 4   | **155**  | Min Stack                      | Design + stack             | Common design question             |
| 5   | **503**  | Next Greater Element II        | Monotonic stack (circular) | Circular variant of NGE            |
| 6   | **496**  | Next Greater Element I         | Monotonic stack            | Subset NGE; warm-up                |
| 7   | **42**   | Trapping Rain Water            | Stack / Two pointers       | Multiple solutions; stack variant  |
| 8   | **394**  | Decode String                  | Nested stack               | Nested structure; Amazon           |
| 9   | **402**  | Remove K Digits                | Monotonic stack (greedy)   | Greedy + stack; Google             |
| 10  | **32**   | Longest Valid Parentheses      | Stack / DP                 | Hard; tests depth                  |


---

## Easy (10 Problems)


| #   | LeetCode | Problem                              | Concept                |
| --- | -------- | ------------------------------------ | ---------------------- |
| 1   | 20       | Valid Parentheses                    | Simple stack           |
| 2   | 155      | Min Stack                            | Design, parallel stack |
| 3   | 225      | Implement Stack using Queues         | Stack, queue           |
| 4   | 232      | Implement Queue using Stacks         | Stack, queue           |
| 5   | 496      | Next Greater Element I               | Monotonic stack        |
| 6   | 682      | Baseball Game                        | Simple stack           |
| 7   | 844      | Backspace String Compare             | Stack, two pointers    |
| 8   | 1047     | Remove All Adjacent Duplicates       | Stack                  |
| 9   | 1544     | Make The String Great                | Stack                  |
| 10  | 1614     | Maximum Nesting Depth of Parentheses | Stack                  |


---

## Medium (14 Problems)


| #   | LeetCode | Problem                          | Concept                          |
| --- | -------- | -------------------------------- | -------------------------------- |
| 1   | 739      | Daily Temperatures               | **Monotonic stack (NGE)**        |
| 2   | 503      | Next Greater Element II          | **Monotonic stack (circular)**   |
| 3   | 84       | Largest Rectangle in Histogram   | **Monotonic stack (boundaries)** |
| 4   | 42       | Trapping Rain Water              | Stack / Two pointers             |
| 5   | 394      | Decode String                    | Nested stack                     |
| 6   | 402      | Remove K Digits                  | Monotonic stack (greedy)         |
| 7   | 71       | Simplify Path                    | Stack                            |
| 8   | 150      | Evaluate Reverse Polish Notation | Postfix evaluation               |
| 9   | 227      | Basic Calculator II              | Expression, stack                |
| 10  | 456      | 132 Pattern                      | Monotonic stack                  |
| 11  | 316      | Remove Duplicate Letters         | Monotonic stack                  |
| 12  | 856      | Score of Parentheses             | Stack                            |
| 13  | 735      | Asteroid Collision               | Stack (simulation)               |
| 14  | 1019     | Next Greater Node in Linked List | Monotonic stack on list          |


---

## Hard (6 Problems)


| #   | LeetCode | Problem                                  | Concept                  |
| --- | -------- | ---------------------------------------- | ------------------------ |
| 1   | 32       | Longest Valid Parentheses                | Stack / DP               |
| 2   | 224      | Basic Calculator                         | Expression, parentheses  |
| 3   | 85       | Maximal Rectangle                        | Histogram per row        |
| 4   | 772      | Basic Calculator III                     | Nested expression        |
| 5   | 1249     | Minimum Remove to Make Valid Parentheses | Stack                    |
| 6   | 636      | Exclusive Time of Functions              | Stack (nested intervals) |


---

## Concept Tags


| Tag                          | Problems            |
| ---------------------------- | ------------------- |
| **Monotonic stack (NGE)**    | 496, 503, 739, 1019 |
| **Monotonic stack (NSE)**    | 84, 85              |
| **Monotonic stack (greedy)** | 402, 316            |
| **Simple stack**             | 20, 682, 1047, 1544 |
| **Parentheses**              | 20, 32, 856         |
| **Expression**               | 150, 224, 227       |
| **Nested**                   | 394                 |
| **Design**                   | 155, 225, 232       |
| **Simulation**               | 735                 |


---

## Study Plan (7 Days)

### Day 1: Basics

- 20 Valid Parentheses
- 155 Min Stack
- 496 Next Greater Element I
- 682 Baseball Game

### Day 2: More Easy + Intro Monotonic

- 739 Daily Temperatures ⭐
- 844 Backspace String Compare
- 1047 Remove All Adjacent Duplicates
- 150 Evaluate RPN

### Day 3: Monotonic Stack Deep Dive

- 503 Next Greater Element II ⭐
- 84 Largest Rectangle in Histogram ⭐
- 42 Trapping Rain Water ⭐

### Day 4: Nested + Expression

- 394 Decode String ⭐
- 402 Remove K Digits ⭐
- 71 Simplify Path
- 227 Basic Calculator II

### Day 5: Advanced Monotonic

- 456 132 Pattern
- 316 Remove Duplicate Letters
- 856 Score of Parentheses
- 735 Asteroid Collision

### Day 6: Hard

- 32 Longest Valid Parentheses ⭐
- 85 Maximal Rectangle
- 224 Basic Calculator

### Day 7: Revision + Mock

- Re-solve all 10 MUST-DO
- Time yourself: 15 min per problem
- Explain monotonic stack O(n) to an imaginary interviewer

---

## Problem-to-File Mapping


| Need help with...           | See file                    |
| --------------------------- | --------------------------- |
| Why monotonic stack?        | Concept.md, Mental-Model.md |
| Template for NGE            | Coding-Template.md          |
| How to explain in interview | Interview-Thinking.md       |
| Common bugs                 | Common-Mistakes.md          |
| Edge cases                  | Edge-Cases.md               |
| Is this a stack problem?    | Tricks-and-Recognition.md   |


---

## FINAL MEMORY COMPRESSION BLOCK

```
MUST-DO:     739, 84, 20, 155, 503, 496, 42, 394, 402, 32
MONOTONIC:   739, 84, 503, 496, 402, 316, 456
PARENTHESES: 20, 32, 856
EXPRESSION:  150, 224, 227
STUDY:       7 days; Day 3 = monotonic deep dive
```

