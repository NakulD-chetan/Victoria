# Design Notification System — Interview Thinking

> **Permanent Recall:** Walkthrough order: 1) Clarify channels and scale, 2) Draw **pipeline** (Event → Decide → Format → Deliver → Track), 3) Emphasize **per-channel workers** + third-party providers, 4) Rate limiting and user preferences, 5) **Idempotency** for at-least-once delivery without duplicates.

---

## Walkthrough Order

| Step | Focus | Key Points |
|------|-------|------------|
| 1 | Requirements | Push (iOS/Android), SMS, email; preferences, templates, scheduling, rate limiting |
| 2 | Scale | 10B/day, ~116K QPS; capacity estimate |
| 3 | **Pipeline architecture** | Event → Decide → Format → Deliver → Track |
| 4 | **Per-channel workers** | Different providers (APNS, FCM, Twilio, SendGrid); separate queues |
| 5 | **Rate limiting** | Per-user and global; prevent spam and fatigue |
| 6 | **User preferences** | Opt-in/out per channel and type; always check first |
| 7 | **Idempotency** | Same event + user → one notification; dedupe on retry |
| 8 | Delivery guarantee | At-least-once; retry + dead-letter; track status |

---

## How to Discuss the Pipeline

```
"We have a pipeline: first we DECIDE — check user preferences and rate limits.
Then we FORMAT — apply the template with the payload. Then we DELIVER via
the appropriate provider — APNS for iOS, FCM for Android, Twilio for SMS,
SendGrid for email. Each has different APIs and rate limits, so we use
separate workers and queues per channel."
```

> **FAANG Tip:** Saying "separate queues per channel" shows you understand different SLAs and failure isolation.

---

## Rate Limiting: What to Say

- **Per-user:** "We limit marketing emails to 5/day per user to avoid fatigue; transactional has higher limits."
- **Per-channel:** "SMS is expensive, so we cap at 3/day for non-urgent."
- **Global:** "Twilio has 100 req/sec — we use a token bucket to stay under provider limits."
- **Storage:** "Redis with TTL; key like `user:{id}:email:day` with count; reset at midnight or sliding window."

---

## User Preferences: What to Say

- "Before sending, we check: is the user opted in for this channel and notification type?"
- "Preferences stored in DB; cached in Redis for hot path."
- "Transactional (password reset) may override opt-out for legal/security — clarify with interviewer."
- "We never send to a channel the user has opted out of for that type."

---

## Delivery Guarantees: What to Say

- "We aim for at-least-once — retry until success or move to dead-letter."
- "Idempotency is critical: if we retry, we use `(user_id, event_id, idempotency_key)` to dedupe."
- "Before calling the provider, we check Redis: already sent? Skip. Otherwise send and set key."
- "Push: APNS/FCM may not confirm delivery; we track 'sent' and optionally use provider callbacks for 'delivered'."

---

## Idempotency: Deep Dive

```
Request 1: { user_id: 123, event_id: "order_456", idempotency_key: "abc" }
  → Check Redis: key "abc" not found
  → Send notification
  → Set Redis "abc" = sent, TTL 24h

Request 2 (retry): Same idempotency_key "abc"
  → Check Redis: key exists
  → Return existing status; do NOT send again
```

- **Idempotency key:** Client or system generates; must be unique per logical send
- **Storage:** Redis with 24–72h TTL
- **Scope:** Per user + event; same event to same user = one notification

---

## Time Allocation (45-min interview)

| Phase | Minutes | Content |
|-------|---------|---------|
| Requirements | 5 | Channels, preferences, templates, scheduling, rate limits |
| Scale | 5 | 10B/day, QPS, capacity |
| High-level | 5 | Boxes: API, pipeline, queues, workers, providers |
| Pipeline detail | 10 | Decide → Format → Deliver → Track |
| Rate limit + prefs | 5 | Per-user, per-channel; preference check |
| Idempotency + retry | 5 | At-least-once; dedupe; dead-letter |
| Deep dive | 5 | Pick: device tokens, scheduling, or provider outage |

---

## Clarifying Questions to Ask

1. **Channels:** Push only, or SMS/email too?
2. **Scale:** 10B/day or different?
3. **Transactional vs marketing:** Different rate limits? Can transactional override opt-out?
4. **Scheduling:** Immediate only or delayed (reminders)?
5. **Tracking:** Need open/click analytics?

---

## Phrases That Show Depth

- "We'd use separate queues per channel because push has <10s SLA, email can be more relaxed."
- "APNS uses a binary protocol; FCM uses HTTP — we'd abstract behind a provider interface."
- "Device tokens can invalidate when the user uninstalls; we'd remove them on 410 Unregistered from APNS."
- "For mass notifications (1M users), we'd fan-out to the queue with partitioning to avoid hot partitions."

---

## Common Follow-Ups

- **"How do you handle provider outage?"** → Circuit breaker; queue backs up; retry when healthy; optionally failover to another provider (e.g., Twilio → alternate SMS).
- **"How do you prevent duplicate sends on retry?"** → Idempotency key in Redis; check before send.
- **"What if user has 5 devices?"** → Send to all valid push tokens for that user.
- **"How do you schedule for 24h later?"** → Delay queue (SQS delay, Redis sorted set, or dedicated scheduler) → enqueue at trigger time.

---

## Key Differentiators to Emphasize

1. **Pipeline** — Not a single "send" function; staged Decide → Format → Deliver
2. **Per-channel isolation** — Different providers, different queues
3. **Idempotency** — At-least-once without duplicates
4. **Rate limiting** — Both user experience and cost control

---

## Wrap-Up

Summarize: "We have a pipeline: Event → Decide (prefs, rate limit) → Format (template) → Deliver (channel workers → APNS/FCM/Twilio/SendGrid) → Track. Separate queues per channel, idempotency for retries, and rate limiting per user and globally."
