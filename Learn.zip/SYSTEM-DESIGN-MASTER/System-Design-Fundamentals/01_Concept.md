# System Design Fundamentals — Concept

> **Permanent Recall:** System design is the art of defining components, their interactions, and trade-offs to meet functional and non-functional requirements at scale. FAANG cares because engineers design billion-user systems daily. Every system has three pillars: **Moving Data** (APIs, queues, networks), **Storing Data** (databases, caches), and **Transforming Data** (compute, services). Master these building blocks and their properties (scalability, reliability, consistency) to pass any system design interview.

---

## What Is System Design?

**System design** is the process of defining the **architecture**, **components**, **modules**, **interfaces**, and **data flow** for a system to satisfy specified requirements. It answers: *What pieces exist? How do they talk? Where does data live? How does it scale?*

> **FAANG Tip:** Interviewers don't expect you to know every internal detail. They want to see structured thinking, trade-off awareness, and the ability to evolve a design from simple to complex.

---

## Why FAANG Cares About System Design

| Reason | Why It Matters |
|--------|----------------|
| **Scale** | FAANG systems serve billions of users; wrong choices = outages and lost revenue |
| **Ownership** | Engineers own features end-to-end, including infrastructure decisions |
| **Cost** | Bad design = over-provisioning, wasted resources, technical debt |
| **Collaboration** | System design requires aligning with product, infra, and security teams |
| **Seniority Signal** | Staff+ engineers lead architecture; design skills = promotion path |

---

## The Building Blocks of Any System

Every system—from a todo app to a global CDN—composes the same fundamental pieces:

### Building Blocks Table

| Component | What It Does | Real-World Analogy |
|-----------|--------------|-------------------|
| **Clients** | Request services, display data (web, mobile, IoT) | Customers at a restaurant placing orders |
| **Servers** | Process requests, run business logic, serve responses | Kitchen staff preparing food |
| **Load Balancer** | Distributes traffic across servers, health checks | Host who assigns tables to waiters |
| **Cache** | Stores frequently accessed data for fast reads | Prep station with ready-made items |
| **Database** | Persistent storage, ACID/eventual consistency | Recipe books and inventory records |
| **CDN** | Edge delivery of static assets (images, CSS, JS) | Branch locations closer to customers |
| **Message Queue** | Async decoupling, buffering, event streaming | Order tickets passed to kitchen |
| **API Gateway** | Single entry point, auth, rate limiting, routing | Maître d' who checks reservations |

---

## ASCII Diagram: Basic Web Architecture

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                         INTERNET                              │
                    └────────────────────────────┬────────────────────────────────┘
                                                 │
                                                 ▼
                                    ┌───────────────────────┐
                                    │   Load Balancer (LB)   │
                                    │   - Health checks      │
                                    │   - Round-robin/etc    │
                                    └───────────┬───────────┘
                                                │
                        ┌───────────────────────┼───────────────────────┐
                        │                       │                       │
                        ▼                       ▼                       ▼
              ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
              │   App Server 1   │     │   App Server 2   │     │   App Server N   │
              │   - Business     │     │   - Business     │     │   - Business     │
              │     Logic       │     │     Logic       │     │     Logic       │
              └────────┬────────┘     └────────┬────────┘     └────────┬────────┘
                       │                       │                       │
                       │      ┌────────────────┴────────────────┐      │
                       │      │                                 │      │
                       ▼      ▼                                 ▼      ▼
              ┌──────────────┐                        ┌──────────────────┐
              │    Cache     │                        │    Database      │
              │  (Redis)     │◄──────────────────────►│  (Primary +      │
              │  - Sessions  │   cache-aside          │   Replicas)      │
              │  - Hot data  │                        │  - Persistent   │
              └──────────────┘                        └──────────────────┘
```

---

## Functional vs Non-Functional Requirements

| Type | Definition | Examples |
|------|------------|----------|
| **Functional** | *What* the system must do | "User can post, like, comment", "Search returns ranked results" |
| **Non-Functional** | *How well* it must do it | Latency < 200ms, 99.9% uptime, 100K QPS, GDPR compliant |

> **FAANG Tip:** Always clarify both. "Design Twitter" is vague. Ask: "What's the read:write ratio? Target latency? Retention requirements? Scale in DAU?"

---

## Key System Properties

| Property | Meaning | Trade-off |
|----------|---------|-----------|
| **Scalability** | Handle more load (vertical/horizontal) | Cost vs capacity |
| **Reliability** | System performs correctly under failures | Redundancy, complexity |
| **Availability** | Uptime % (e.g., 99.9% = ~8.76 hr/year downtime) | Nines cost money |
| **Consistency** | Strong vs eventual; CAP theorem | Latency vs correctness |
| **Latency** | Time to complete a request (p50, p99) | Caching, geographic distribution |
| **Throughput** | Requests per second (QPS) the system handles | Sharding, parallelism |

---

## System Design vs Coding Interviews

| Aspect | Coding Interview | System Design Interview |
|--------|------------------|-------------------------|
| **Focus** | Correctness, time/space complexity | Trade-offs, scale, failure modes |
| **Output** | Working code | Architecture diagrams, component choices |
| **Time** | 30–45 min | 45–60 min |
| **Depth** | One problem, deep | Broad system, deep dive on 1–2 areas |
| **Right answer** | Often unique | Multiple valid designs; justification matters |

---

## How Systems Evolve

```
Single Server                    Distributed System
───────────────────────────────────────────────────────────────────

    [Client]                         [Clients]
       │                                  │
       ▼                                  ▼
  ┌─────────┐                      ┌─────────────┐
  │ Server  │                      │ Load Balancer│
  │ + DB    │    ────────►         └──────┬──────┘
  │ + Cache │   Evolution                  │
  │ + Logic │                      ┌──────┼──────┐
  └─────────┘                      │      │      │
       │                           ▼      ▼      ▼
   Fails =                      App   App   App  Cache  DB
   Everything                   Server Server Server  Primary
   down                                   │      │
                                   Read Replica  Shards
```

**Evolution stages:** Monolith → Add Cache → Add Replicas → Shard DB → Add Message Queue → Microservices → Multi-region

---

## The 3 Pillars: Moving, Storing, Transforming Data

Every system design question maps to these pillars:

| Pillar | Components | Example Questions |
|--------|-------------|-------------------|
| **Moving Data** | APIs, message queues, CDNs, load balancers | "How does a tweet reach followers?" |
| **Storing Data** | Databases, caches, object storage, search indices | "Where do we store user profiles?" |
| **Transforming Data** | Application servers, workers, compute | "How do we generate feed rankings?" |

> **FAANG Tip:** When stuck, ask: "Where does this data move? Where is it stored? What transforms it?" This decomposes any problem.

---

## 30-SECOND REVISION BOX

```
SYSTEM DESIGN = Components + Interactions + Trade-offs
3 PILLARS: Move Data | Store Data | Transform Data
BUILDING BLOCKS: Client, Server, LB, Cache, DB, CDN, Queue, API
NFRs: Scalability, Reliability, Availability, Consistency, Latency, Throughput
EVOLUTION: Single server → Cache → Replicas → Sharding → Queues → Microservices
```

---

**Next: [[02_Mental-Model]]**
