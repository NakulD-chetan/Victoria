# Design Rate Limiter — Edge Cases

> **Permanent Recall:** Edge cases: **distributed sync** (Redis consistency), **Redis failure** (fail open/closed), **clock skew**, **bypass** (new API key), **burst handling**, **multi-region** (global vs per-region limits).

---

## 1. Distributed Synchronization

**Scenario:** Multiple API servers; requests for same user hit different servers. All must share the same count.

| Issue | Mitigation |
|-------|------------|
| Stale local cache | Don't cache counters, or use very short TTL (&lt;1s) |
| Redis as bottleneck | Connection pooling, pipeline, consider Redis Cluster for sharding |
| Eventual consistency | Redis is strongly consistent per key; no eventual consistency if single Redis |

---

## 2. Redis Failure

**Scenario:** Redis is down or unreachable.

| Choice | Behavior | When to use |
|--------|----------|-------------|
| **Fail open** | Allow all requests | Availability-critical (e.g., public API) |
| **Fail closed** | Reject all requests | Security-critical (e.g., payment API) |

**Additional:** Circuit breaker to avoid hammering Redis when it's down. Fallback cache (e.g., local with last-known-good) adds complexity; usually not worth it.

---

## 3. Clock Skew Across Servers

**Scenario:** Servers have different clocks. Fixed window uses `floor(now/60)` — server A says window 100, server B says window 101.

| Impact | Mitigation |
|--------|------------|
| Inconsistent windows | Use **Redis TIME** instead of application server time for window boundaries |
| Token bucket refill | Store `last_refill` in Redis; compute elapsed from Redis time |

---

## 4. Rate Limit Bypass

**Scenario:** Malicious user creates many API keys or switches IPs to bypass per-identity limits.

| Bypass | Mitigation |
|--------|------------|
| New API key per request | Rate limit by IP as well; detect key churn; revoke abusive keys |
| IP rotation (proxies, botnets) | IP-based limits are best-effort; add CAPTCHA, ML-based abuse detection |
| Distributed attack | Global rate limit (all users); per-IP limits; DDoS protection at network layer |

---

## 5. Burst Handling

**Scenario:** User sends 1000 requests in 1 second; limit is 100/min.

| Algorithm | Behavior |
|-----------|----------|
| Fixed window | 100 allowed in that second; rest rejected until next window |
| Sliding window log | Accurate; 100 allowed in any 60s sliding window |
| Token bucket | Depends on bucket size; if cap=100, allows 100 burst then refill |
| Leaky bucket | Queues or rejects; outputs at constant rate |

**Edge:** First request of a burst might initialize the window; consider whether to allow a "cold start" burst.

---

## 6. Multi-Region Deployment

**Scenario:** API deployed in US, EU, Asia. User in EU hits EU region; same user in US hits US region.

| Approach | Pros | Cons |
|----------|------|------|
| **Per-region limits** | Low latency; Redis local to region | User gets limit × regions (e.g., 100 × 3 = 300) |
| **Global limit** | One limit per user worldwide | Cross-region Redis sync or centralized Redis; higher latency |
| **Hybrid** | Per-region for most; global for sensitive ops | Complex; two-tier logic |

---

## 7. Thundering Herd After Window Reset

**Scenario:** Many users waiting for window reset; at T+60s they all send requests.

| Impact | Mitigation |
|--------|------------|
| Redis spike | Connection pooling; consider local pre-check (optimistic) |
| Backend spike | Rate limiting protects backend; but rate limiter itself can be overwhelmed |
| | Stagger window resets (e.g., random offset per user) to spread load |

---

## 8. Zero or Negative Limits

**Scenario:** Misconfiguration: limit=0 or limit=-1.

| Handling | Recommendation |
|----------|-----------------|
| limit=0 | Reject all; treat as "endpoint disabled" |
| limit&lt;0 | Validate config; reject invalid rules at load time |

---

## 9. Identity Not Present

**Scenario:** Anonymous request; no user_id, no API key. Only IP available.

| Approach | Note |
|----------|------|
| Fallback to IP | Common; IP can be shared (NAT, mobile networks) — may over-limit innocent users |
| Require auth | Some endpoints require auth; no anonymous access |
| Stricter limit for anonymous | E.g., 10/min for IP, 100/min for authenticated user |

---

## 10. Sliding Window — Memory Growth

**Scenario:** Sliding window log stores every request timestamp. High-traffic user = millions of entries.

| Mitigation | Trade-off |
|------------|-----------|
| Sliding window counter | O(1) memory; slight inaccuracy |
| TTL + trim | Periodic ZREMRANGEBYSCORE; still O(n) during window |
| Token bucket | O(1); no per-request storage |

---

## Summary Table

| Edge Case | Key Consideration |
|-----------|-------------------|
| Distributed | Shared store (Redis); no local-only counters |
| Redis down | Fail open vs fail closed |
| Clock skew | Use Redis TIME for window boundaries |
| Bypass | Multi-dimensional limits; abuse detection |
| Burst | Token bucket allows bursts; fixed window has boundary spike |
| Multi-region | Per-region vs global limits |
| Herd at reset | Stagger resets; connection pooling |
| Bad config | Validate limit &gt; 0 |
| No identity | Fallback to IP; stricter limits |
