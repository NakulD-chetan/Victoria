# Database Scaling — Question List

> **Permanent Recall:** Master the 10 MUST-DO DB scaling questions for FAANG interviews. The full list covers replication, sharding, consistent hashing, migration, and edge cases. Difficulty ranges from Easy (concepts) to Hard (multi-shard, distributed transactions). Use this as a checklist for interview prep—each question tests specific concepts from the Database-Scaling notes.

---

## 10 MUST-DO DB Scaling Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | Design a URL shortener that scales to 1B URLs | Medium | Sharding, consistent hashing, shard key |
| 2 | Design Twitter feed—how do you scale the database? | Medium | Read replicas, caching, sharding |
| 3 | How does consistent hashing work? Why use it for sharding? | Easy | Consistent hashing, virtual nodes |
| 4 | Design a system with 10M users, 100K reads/sec—database scaling | Medium | Replication, read replicas, caching |
| 5 | How do you migrate from a single DB to sharded without downtime? | Hard | Dual-write, backfill, migration |
| 6 | Master-Slave vs Master-Master—when to use which? | Easy | Replication topologies |
| 7 | Design a payment system—DB must be strongly consistent | Medium | Sync replication, no eventual consistency |
| 8 | Hot shard problem—one shard has 80% load. How do you fix it? | Medium | Re-sharding, shard key, cache |
| 9 | How do you handle replication lag? User writes then immediately reads | Easy | Read-from-master, session stickiness |
| 10 | Design a distributed database from scratch (sharding + replication) | Hard | Full architecture, consistent hash, failover |

---

## Complete Question List (25+)

### Replication Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 11 | Synchronous vs asynchronous replication—trade-offs? | Easy | Google, Meta, Amazon |
| 12 | How do you implement automatic failover for MySQL? | Medium | Meta, Netflix |
| 13 | Read replicas—how do you route reads? Round robin vs lag-based? | Medium | Amazon, Uber |
| 14 | Multi-region replication—how do you handle conflict? | Hard | Google, Meta |
| 15 | What is replication lag and how do you measure it? | Easy | Any |

### Sharding Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 16 | Range-based vs hash-based sharding—pros and cons? | Easy | Amazon, Microsoft |
| 17 | How do you implement cross-shard transactions? | Hard | Google, Stripe |
| 18 | Design sharding for an e-commerce orders table | Medium | Amazon, Shopify |
| 19 | Directory-based sharding—when to use vs hash? | Medium | Meta, Uber |
| 20 | Geographic sharding—how do you route queries? | Medium | Google, Cloudflare |

### Consistent Hashing Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 21 | Why does modulo hashing fail when adding/removing nodes? | Easy | Any |
| 22 | Implement consistent hashing with virtual nodes | Medium | Amazon, Meta |
| 23 | How many virtual nodes per physical node? Why? | Easy | Any |
| 24 | Consistent hashing for cache vs database—same algorithm? | Medium | Any |

### Migration Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 25 | How do you add a new shard without downtime? | Hard | Meta, Uber |
| 26 | Dual-write migration—how do you handle inconsistencies? | Medium | Stripe, Square |
| 27 | How do you change shard key after deployment? | Hard | Google |
| 28 | Online schema change across 100 shards | Hard | Meta |

### Edge Case Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 29 | Split brain in master-master—how do you prevent it? | Medium | Google, Meta |
| 30 | Backup and restore for sharded database | Medium | Amazon, Netflix |
| 31 | Connection pool exhaustion—how do you fix it? | Easy | Any |
| 32 | Schema migration—some shards new, some old. How? | Medium | Meta |

---

## How to Approach DB Scaling Questions

**For "Design X with scaling" questions:**
1. Clarify read/write ratio, QPS, storage growth
2. Propose scaling order: vertical → replicas → cache → shard
3. If sharding: justify shard key (cardinality, query pattern)
4. Mention consistent hashing for adding/removing shards
5. Address edge cases: lag, hot shard, migration

**For "How does X work?" questions:**
- Consistent hashing: ring, clockwise, virtual nodes
- Replication: sync vs async, lag, failover
- Sharding: strategies, shard key, cross-shard

**For "What if X fails?" questions:**
- Master fail: auto-promote replica, orchestrator
- Replica lag: read from master for critical
- Hot shard: re-shard, cache, better key

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, single topic, straightforward |
| **Medium** | Multiple components, trade-offs, implementation |
| **Hard** | Full design, migration, distributed systems |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **Replication** | 2, 4, 6, 9, 11–15 |
| **Sharding** | 1, 2, 4, 5, 8, 16–20, 25–28 |
| **Consistent Hashing** | 1, 3, 10, 21–24 |
| **Migration** | 5, 25–28 |
| **Replication lag** | 9, 13, 15 |
| **Hot shard** | 8 |
| **Cross-shard** | 17 |
| **Failover** | 12, 10 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can draw replication topology (master + replicas)
- [ ] Can draw sharding architecture with router
- [ ] Can explain consistent hashing with ring diagram
- [ ] Can explain scaling order: vertical → replicas → cache → shard
- [ ] Can justify shard key selection
- [ ] Can describe dual-write migration
- [ ] Can discuss replication lag and mitigation
- [ ] Can explain sync vs async replication
- [ ] Can handle "hot shard" and "cross-shard transaction" follow-ups

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: Shortener, Twitter, Consistent hash, 10M users,
            Migration, Master types, Payment, Hot shard,
            Replication lag, Distributed DB
FULL LIST: 30+ questions — replication, sharding, hashing, migration
CONCEPTS: Replication, sharding, consistent hash, migration, edge cases
```

---

**Prev: [[07_Tricks-and-Recognition]]**
