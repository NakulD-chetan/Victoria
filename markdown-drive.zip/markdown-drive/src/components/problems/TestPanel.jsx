import { useState, useCallback, useEffect } from 'react';
import { usePlaygroundStore } from '../../stores/playground-store';
import { useProblemSessionStore } from '../../stores/problem-session-store';

export default function TestPanel({ problem }) {
  const { components, connections, testResults, setTestResults } = usePlaygroundStore();
  const setArchScore = useProblemSessionStore((s) => s.setArchScore);
  const setSubmitted = useProblemSessionStore((s) => s.setSubmitted);
  const setShowDeepDive = useProblemSessionStore((s) => s.setShowDeepDive);
  const setChaosResults = useProblemSessionStore((s) => s.setChaosResults);
  const setServerVerdict = useProblemSessionStore((s) => s.setServerVerdict);
  const submitted = useProblemSessionStore((s) => s.submitted);
  const chaosResultsFromStore = useProblemSessionStore((s) => s.chaosResults);
  const replayTest = usePlaygroundStore((s) => s.replayTest);
  const setReplayTest = usePlaygroundStore((s) => s.setReplayTest);
  const [collapsed, setCollapsed] = useState(false);
  const [verdict, setVerdict] = useState(null);
  const [activeTab, setActiveTab] = useState('tests');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    window.dispatchEvent(new Event('resize'));
  }, [collapsed]);

  const handleRunTests = useCallback(async () => {
    setLoading(true);
    setVerdict(null);
    try {
      const res = await fetch(`/api/problems/${problem.id}/run`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ components, connections }),
      });
      const data = await res.json();
      if (!res.ok) { setVerdict({ type: 'error', text: data.error || 'Server error' }); return; }
      setTestResults(data.testResults);
      setActiveTab('tests');
    } catch (e) {
      setVerdict({ type: 'error', text: 'Network error: ' + e.message });
    } finally {
      setLoading(false);
    }
  }, [problem, components, connections, setTestResults]);

  const handleSubmit = useCallback(async () => {
    setLoading(true);
    try {
      const hintsUsed = useProblemSessionStore.getState().hintsUsed;
      const deepDiveAnswers = useProblemSessionStore.getState().deepDiveAnswers;
      const res = await fetch(`/api/problems/${problem.id}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ components, connections, hintsUsed, deepDiveAnswers }),
      });
      const data = await res.json();
      if (!res.ok) { setVerdict({ type: 'error', text: data.error || 'Server error' }); return; }

      setTestResults(data.testResults);
      setChaosResults(data.chaosResults);
      setArchScore(data.archScore);
      setSubmitted(true);
      setShowDeepDive(true);
      setServerVerdict(data);

      const passed = data.testResults.filter(r => r.passed).length;
      const total = data.testResults.length;
      const chaosOk = data.chaosResults.filter(r => r.survived).length;
      const chaosTotal = data.chaosResults.length;

      if (data.accepted) {
        setVerdict({
          type: 'accepted',
          text: `Accepted \u2014 ${passed}/${total} tests, ${chaosOk}/${chaosTotal} chaos survived, Score: ${data.totalScore}%`,
        });
      } else {
        setVerdict({
          type: 'rejected',
          text: `Wrong Answer \u2014 ${passed}/${total} tests passed${chaosTotal > 0 ? `, ${chaosOk}/${chaosTotal} chaos` : ''}`,
        });
      }
    } catch (e) {
      setVerdict({ type: 'error', text: 'Network error: ' + e.message });
    } finally {
      setLoading(false);
    }
  }, [problem, components, connections, setTestResults, setArchScore, setSubmitted, setShowDeepDive, setChaosResults, setServerVerdict]);

  const handleReplay = useCallback((tc) => {
    if (setReplayTest) setReplayTest(tc);
  }, [setReplayTest]);

  return (
    <div className={`dc-test-panel ${collapsed ? 'dc-test-panel--collapsed' : ''}`}>
      <div className="dc-test-panel__header">
        <button onClick={() => setCollapsed(!collapsed)} className="dc-test-panel__toggle" title={collapsed ? 'Expand' : 'Collapse'}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
            {collapsed ? <polyline points="6 15 12 9 18 15" /> : <polyline points="6 9 12 15 18 9" />}
          </svg>
          <span className="dc-section-label" style={{ margin: 0 }}>Testcase</span>
        </button>
        <div className="dc-test-panel__tab-row">
          <button onClick={() => setActiveTab('tests')} className={`dc-test-panel__tab ${activeTab === 'tests' ? 'dc-test-panel__tab--active' : ''}`}>Tests</button>
          {chaosResultsFromStore && chaosResultsFromStore.length > 0 && (
            <button onClick={() => setActiveTab('chaos')} className={`dc-test-panel__tab ${activeTab === 'chaos' ? 'dc-test-panel__tab--active' : ''}`}>Chaos</button>
          )}
        </div>
        <div className="dc-test-panel__actions">
          <button onClick={handleRunTests} className="dc-btn dc-btn--outline dc-btn--xs" disabled={loading}>
            {loading ? '\u23F3' : 'Run'}
          </button>
          <button onClick={handleSubmit} className={`dc-btn dc-btn--success dc-btn--xs ${submitted ? 'dc-btn--submitted' : ''}`} disabled={loading}>
            {loading ? '\u23F3' : submitted ? 'Re-Submit' : 'Submit'}
          </button>
        </div>
      </div>
      {!collapsed && (
        <>
          {activeTab === 'tests' && (
            <div className="dc-test-panel__body">
              {testResults.map((tr, i) => {
                if (!tr) return null;
                const icon = tr.passed ? '\u2713' : '\u2715';
                const cls = tr.passed ? 'dc-test-row--pass' : 'dc-test-row--fail';
                const badge = tr.type === 'simulation' && tr.rps ? `${tr.rps} req/s` : tr.type;
                const isReplaying = replayTest && replayTest.name === tr.name;
                return (
                  <div key={i} className={`dc-test-row ${cls}`}>
                    <span className="dc-test-row__icon" style={{ color: tr.passed ? 'var(--accent)' : 'var(--danger)' }}>{icon}</span>
                    <span className="dc-test-row__name">{tr.name}</span>
                    <span className="dc-test-row__badge">{badge}</span>
                    {!tr.passed && tr.type === 'simulation' && (
                      <button
                        className={`dc-test-row__replay ${isReplaying ? 'dc-test-row__replay--active' : ''}`}
                        onClick={() => handleReplay(tr)}
                        title="Replay this test on canvas"
                      >
                        {'\u25B6'}
                      </button>
                    )}
                  </div>
                );
              })}
              {testResults.length === 0 && (
                <div className="dc-test-panel__empty">Click <b>Run</b> to test your architecture</div>
              )}
            </div>
          )}

          {activeTab === 'chaos' && chaosResultsFromStore && (
            <div className="dc-test-panel__body">
              {chaosResultsFromStore.map((cr, i) => (
                <div key={i} className={`dc-test-row ${cr.survived ? 'dc-test-row--pass' : 'dc-test-row--fail'}`}>
                  <span className="dc-test-row__icon" style={{ color: cr.survived ? 'var(--accent)' : 'var(--danger)' }}>
                    {cr.survived ? '\u2713' : '\u2715'}
                  </span>
                  <span className="dc-test-row__name">{cr.label}</span>
                  <span className="dc-test-row__badge">{cr.survived ? 'survived' : 'failed'}</span>
                  {!cr.survived && (
                    <button
                      className="dc-test-row__replay"
                      onClick={() => handleReplay({ ...cr, type: 'chaos' })}
                      title="Replay chaos on canvas"
                    >
                      {'\u25B6'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {verdict && (
            <div className={`dc-test-panel__verdict ${
              verdict.type === 'accepted' ? 'dc-test-panel__verdict--pass' :
              verdict.type === 'error' ? 'dc-test-panel__verdict--error' :
              'dc-test-panel__verdict--fail'
            }`}>
              {verdict.text}
            </div>
          )}
        </>
      )}
    </div>
  );
}
