# Design WhatsApp — Edge Cases

> **Permanent Recall:** Edge cases: user on multiple devices (message sync), group message to 256 where some offline, message ordering across network delays, WebSocket drop and reconnect, chat history search, user blocks another mid-conversation, media message when recipient has slow connection. Plan for each in design.

---

## User on Multiple Devices

**What:** User has phone, tablet, web. Message must appear on all; read receipt must sync.

**Approach:**
- Each device has its own WebSocket connection
- Fan-out message to all of user's connections (maintain mapping: `user_id` → `[conn_1, conn_2, ...]`)
- Read receipt: when any device marks read, broadcast to all user's devices
- Last message sync: each device fetches on connect; de-duplicate by `message_id`

> **FAANG Tip:** "We maintain a connection map per user. One message → N deliveries to N devices. Read receipt from one device propagates to all."

---

## Group Message to 256 Members, Some Offline

**What:** Sender posts in 256-member group; 100 online, 156 offline.

**Approach:**
- Write message once; publish to queue
- Online: push via WebSocket immediately
- Offline: store in per-user inbox (or lazy: fetch on reconnect)
- Push notification: send to 156 offline users (batch; don't 156 sync API calls)
- Receipts: aggregate delivered count; don't need 256 individual acks for "delivered" in UI (or do, for exactness)

---

## Message Ordering Across Network Delays

**What:** Messages M1, M2, M3 sent in order; M2 arrives before M1 due to network.

**Approach:**
- Server assigns `sequence_id` at ingress (monotonic per conversation)
- Client buffers out-of-order; displays when gap filled
- Or: single-threaded consumer per conversation (Kafka partition) ensures order
- Timestamp alone is insufficient (clock skew); use logical sequence

---

## WebSocket Connection Drop and Reconnect

**What:** Network glitch; WebSocket closes; client reconnects. Risk: missed messages during disconnect.

**Approach:**
- On reconnect: client sends `last_sequence_id` (or `last_message_id`)
- Server returns all messages since then (or push backlog)
- Idempotency: client deduplicates by `message_id`
- Optimistic UI: show "sending..."; on reconnect confirm or retry

---

## Chat History Search

**What:** User searches "dinner plans" across all chats.

**Challenges:**
- E2E encrypted: server can't search plaintext
- Scale: billions of messages

**Approach (non-E2E):**
- Async index to Elasticsearch; index on write or batch
- Shard by user_id; query user's conversations
- **E2E:** Client-side search (download and decrypt); or server stores per-user encrypted search index (complex)

---

## User Blocks Another Mid-Conversation

**What:** A and B chatting; A blocks B. Pending messages?

**Approach:**
- Block = add to block list; check before delivery
- Messages from B already in queue: filter at delivery; don't deliver
- Don't delete from DB (audit); just don't push to A
- B's client: optionally show "delivered" but A never sees (or show "blocked" UX)

---

## Media Message When Recipient Has Slow Connection

**What:** Sender sends 10MB video; recipient on 2G.

**Approach:**
- Don't block text pipeline: media is URL only
- Recipient fetches URL async; show placeholder or thumbnail
- Progressive download / streaming for video
- Option: transcoding to lower quality for slow networks
- Message receipt = "message received" (metadata), not "media downloaded"

---

## Edge Case Mitigation Matrix

| Edge Case | Primary Mitigation | Secondary |
|-----------|-------------------|-----------|
| Multi-device | Fan-out to all user connections | Sync on connect |
| Group + offline | Write once, queue, batch push | Lazy fetch on reconnect |
| Ordering | sequence_id, single partition | Client buffer |
| Reconnect | last_sequence_id fetch | Server push backlog |
| Search | Elasticsearch (non-E2E) | Client-side (E2E) |
| Block | Filter at delivery | Block list check |
| Slow media | URL, async fetch, thumbnail | Progressive load |

---

## Additional Edge Cases

**Rate limiting:** User spams 1000 messages/sec. Throttle per user; token bucket in gateway.

**Message edit/delete:** Store tombstone or new version; sync to all devices; handle out-of-order tombstones.

**Group admin removes member mid-message:** Message in flight still delivered to old member? Policy: deliver until removal processed. Or: check membership at delivery.

**Clock skew:** Don't rely on client timestamp for ordering. Server-generated sequence_id.

**Duplicate message delivery:** At-least-once can deliver twice. Client deduplicates by `message_id`; idempotent apply.

**New group member and old messages:** Policy: new member sees messages from join time only, or full history. Full history = fetch all; can be paginated.

**Very large group (256) and spam:** Rate limit per user per group (e.g., 100 msg/min). Mute option = don't push to device but store.

**Network partition:** During partition, messages may be delayed. On heal: sync backlog; conflict resolution rarely needed for append-only chat.

**Typing indicator:** Ephemeral; broadcast "typing" to conversation members; 3–5s TTL; don't persist.

**Message too large:** Reject >16MB (or config limit); ask user to use media upload for files.

---

## 30-SECOND REVISION BOX

```
MULTI-DEVICE: Fan-out to all connections; read sync
GROUP OFFLINE: Write once, queue, batch push
ORDERING: sequence_id, single partition
RECONNECT: last_sequence_id fetch, backlog push
SEARCH: ES (non-E2E); client-side (E2E)
BLOCK: Filter at delivery
SLOW MEDIA: URL, async, thumbnail
PARTITION: Sync backlog on heal; typing = ephemeral
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
