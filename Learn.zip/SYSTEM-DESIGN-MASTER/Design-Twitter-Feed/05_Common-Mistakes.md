# Design Twitter/X Feed — Common Mistakes

> **Permanent Recall:** Top 10 mistakes: (1) Not addressing fan-out, (2) Pure fan-out-on-write (breaks for celebrities), (3) Pure fan-out-on-read (too slow), (4) Not considering celebrity accounts, (5) Ignoring media storage, (6) No caching, (7) SQL for timeline (too slow), (8) Not discussing eventual consistency, (9) Ignoring trending/search, (10) Not estimating fan-out cost. Avoid these to ace the interview.

---

## Mistake 1: Not Addressing the Fan-Out Problem

| Wrong | Right |
|-------|-------|
| "We store tweets and when user loads feed we... fetch them" (vague) | Explicitly state: "The core challenge is fan-out. When user with 10M followers posts, we need a strategy." |
| Skipping the discussion | Lead with it: "Let me walk through the fan-out design..." |

**Why:** Fan-out is THE central problem. Interviewers expect you to identify and solve it.

> **FAANG Tip:** Name it. Say "the fan-out problem" early. Shows you know this is a classic design question.

---

## Mistake 2: Pure Fan-Out-on-Write (Push Only)

| Wrong | Right |
|-------|-------|
| "We push every tweet to every follower's timeline" | "We push for normal users; for celebrities we pull on read" |
| No mention of celebrity edge case | "Celebrity with 100M followers → 100M writes. That's a write storm." |

**Why:** One celebrity tweet = millions of Redis writes. Latency spike, storage explosion, system overload.

---

## Mistake 3: Pure Fan-Out-on-Read (Pull Only)

| Wrong | Right |
|-------|-------|
| "On feed load we query all followees and merge" | "That's O(followees) per request. User with 500 followees = 500 queries. At 2.8M QPS, DB melts." |
| "We'll optimize later" | Lead with hybrid from the start |

**Why:** Read path becomes the bottleneck. Can't scale to millions of QPS with N queries per request.

---

## Mistake 4: Not Considering Celebrity Accounts

| Wrong | Right |
|-------|-------|
| "Everyone is treated the same" | "Celebrities (<1% of users) cause >50% of fan-out cost. We treat them differently." |
| Ignoring when asked "What about Elon?" | Have the pull-on-read answer ready |

**Why:** Real systems have power users. Interviewers will probe this.

---

## Mistake 5: Ignoring Media Storage

| Wrong | Right |
|-------|-------|
| "Tweets are just text" | "Tweets can have images (200KB) and videos (5MB). We need S3 + CDN." |
| No media flow | "Upload → S3 → CDN URL stored in tweet; serve from edge" |

**Why:** Media dominates storage and bandwidth. Must be addressed.

---

## Mistake 6: No Caching

| Wrong | Right |
|-------|-------|
| "We read timeline from DB on every request" | "We cache timeline in Redis. 2.8M reads to DB = death." |
| Cache as afterthought | Cache is central: Redis sorted sets for timeline |

**Why:** 100:1 read:write means read path is critical. DB can't handle that load.

---

## Mistake 7: SQL for Timeline (Too Slow)

| Wrong | Right |
|-------|-------|
| `SELECT * FROM tweets WHERE user_id IN (followees) ORDER BY created_at` | "That's a complex join + sort. At scale, too slow. We pre-compute in Redis." |
| N+1 queries | Batch or use pre-aggregated timeline |

**Why:** Timeline is a merge of N users' tweets. Doing it in SQL at 2.8M QPS doesn't work.

---

## Mistake 8: Not Discussing Eventual Consistency

| Wrong | Right |
|-------|-------|
| "Feed must be strongly consistent" | "Feed can be eventually consistent. User can see tweet a few seconds late. Acceptable for social." |
| Over-engineering for strong consistency | Use it to simplify: async fan-out, cache staleness OK |

**Why:** Strong consistency would force sync fan-out, killing write latency. Eventual consistency is the right trade-off.

---

## Mistake 9: Ignoring Trending / Search

| Wrong | Right |
|-------|-------|
| "Out of scope" (without asking) | "If we need search: Elasticsearch. Trending: stream processing over hashtags." |
| Designing custom search | Keep it simple: ES for search, Kafka+Flink for trending |

**Why:** Often asked as follow-up. Have a one-sentence answer ready.

---

## Mistake 10: Not Estimating Fan-Out Cost

| Wrong | Right |
|-------|-------|
| No numbers on fan-out | "Average user 200 followers → 200 writes per tweet. 100K celebs → 100K writes. One celebrity = 100K× normal user." |
| Ignoring cost implications | "Fan-out cost scales with follower count. That's why we hybrid." |

**Why:** Numbers justify the hybrid approach. "Celebrities cause >50% of cost" is persuasive.

---

## Summary Table

| # | Mistake | One-Line Fix |
|---|---------|--------------|
| 1 | No fan-out discussion | Name it, lead with it |
| 2 | Pure push | Hybrid: push for normals, pull for celebs |
| 3 | Pure pull | Too slow; need pre-computed cache |
| 4 | No celebrity handling | Pull on read for >100K followers |
| 5 | No media | S3 + CDN |
| 6 | No cache | Redis for timeline |
| 7 | SQL for timeline | Pre-compute in Redis |
| 8 | Strong consistency | Eventual OK for feed |
| 9 | No search/trending | ES + stream processing |
| 10 | No fan-out cost estimate | "<1% users, >50% cost" |

---

## 30-SECOND REVISION BOX

```
1. FAN-OUT: Must address; it's THE problem
2–4. PUSH/PULL/CELEB: Hybrid, not pure either
5. MEDIA: S3 + CDN
6–7. CACHE: Redis, not SQL for timeline
8. CONSISTENCY: Eventual OK
9. SEARCH/TRENDING: ES + stream
10. ESTIMATE: Fan-out cost by follower count
```

---

**Next: [[06_Edge-Cases]]**
