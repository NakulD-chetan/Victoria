# Monitoring and Observability — Common Mistakes

> **Permanent Recall:** Top 10 monitoring mistakes: no monitoring in design, logging everything, unstructured logs, metric cardinality explosion, alerting on symptoms not causes, alert fatigue, no distributed tracing, no dashboards, only infra metrics (no business metrics), no log retention policy. Avoid these in interviews and production.

---

## Top 10 Monitoring Mistakes

| # | Mistake | Why It's Bad | Fix |
|---|---------|--------------|-----|
| 1 | **No monitoring in design** | "We'll add it later" = never. Interview red flag. | Plan it upfront; mention in wrap-up |
| 2 | **Logging everything** | High cost, storage explosion, slow queries | Log at appropriate level; sample debug in prod |
| 3 | **No structured logging** | Can't query; `grep` only | Use JSON: `{"level","msg","trace_id"}` |
| 4 | **Metric cardinality explosion** | `user_id` as label = millions of series | Avoid high-cardinality labels in metrics |
| 5 | **Alerting on symptoms not causes** | "Latency high" → why? No actionable info | Alert on DB pool exhausted, cache miss spike |
| 6 | **Alert fatigue (too many alerts)** | Alerts ignored; real issues missed | Consolidate; use `for`; tier severity |
| 7 | **No distributed tracing** | Can't find latency bottleneck in microservices | Add OpenTelemetry, Jaeger |
| 8 | **No dashboards** | Flying blind; no visibility | 4 golden signals per service |
| 9 | **Only infrastructure metrics** | CPU fine but users churning? Unknown | Add business metrics (orders/sec, errors) |
| 10 | **No log retention policy** | Unbounded storage cost; compliance risk | Define: 7d hot, 30d warm, archive/delete |

---

## Mistake Deep Dives

### 1. No Monitoring in Design

```
WRONG:  "We'll add monitoring after launch"
RIGHT:  "Monitoring is part of the design: metrics, logs, traces, alerts"
```

> **FAANG Tip:** "In system design interviews, omitting monitoring is a red flag. Always include it."

---

### 2 & 3. Logging Everything + Unstructured

```
WRONG:  log("User " + userId + " did " + action + " at " + time)
        (unstructured, PII, high volume)
RIGHT:  log(JSON.dumps({
          "level": "INFO", "service": "order-api",
          "trace_id": trace_id, "event": "order_created",
          "order_id": order_id, "duration_ms": 45
        }))
```

---

### 4. Metric Cardinality Explosion

```
BAD:    http_requests_total{user_id="123", request_id="abc"}
        → 1M users × 10K requests = 10B series
GOOD:   http_requests_total{path="/orders", status="200"}
        → Bounded labels
```

---

### 5 & 6. Alerting Wrong + Alert Fatigue

```
SYMPTOMS (don't alert alone): "Latency high", "Error rate up"
CAUSES (alert on these):     "DB connection pool exhausted",
                             "Cache cluster unhealthy",
                             "SLO breach: error rate > 0.5%"

ALERT FATIGUE FIXES:
  - Use "for: 5m" to avoid flapping
  - Page only for P0; Slack for P2
  - Runbooks; automate common fixes
```

---

### 7. No Distributed Tracing

```
Without traces: "API slow" → guess: DB? Auth? Cache?
With traces:   Trace shows Auth service span = 2s
               → Log: rate limit hit
               → Root cause in minutes
```

---

### 8. No Dashboards

```
Without dashboards: "Is it working?" → Check logs? Guess?
With dashboards:    4 golden signals visible; trend analysis
```

---

### 9. Only Infrastructure Metrics

```
Infra:  CPU 20%, memory 60% — looks fine
Reality: Orders failing silently; revenue dropping

Add: orders_created_total, payment_errors_total, checkout_abandoned_total
```

---

### 10. No Log Retention Policy

```
Problem: Logs grow forever → cost, compliance (GDPR), slow queries
Fix:     7 days hot (Elasticsearch), 30 days warm (cheaper tier),
         then archive or delete. Document in retention policy.
```

---

## Mistake Severity (Interview Priority)

| High Impact | Medium Impact | Lower Impact |
|-------------|---------------|--------------|
| No monitoring in design | Unstructured logs | No retention policy |
| Alert on symptoms | Metric cardinality | Only infra metrics |
| Alert fatigue | No traces | |
| No dashboards | Logging everything | |

> **FAANG Tip:** "In interviews, prioritize fixing 'no monitoring' and 'alert on symptoms.' These show you understand observability fundamentals."

---

## 30-SECOND REVISION BOX

```
TOP 10: No design, log everything, unstructured, cardinality,
        symptom alerts, alert fatigue, no traces, no dashboards,
        only infra, no retention
FIX:    Plan upfront, structured logs, bounded labels,
        cause alerts, tier alerts, add traces, dashboards,
        business metrics, retention policy
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
