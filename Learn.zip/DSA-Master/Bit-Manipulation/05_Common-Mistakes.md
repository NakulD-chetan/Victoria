# Bit Manipulation — Common Mistakes

> **FAANG Focus:** Avoid these pitfalls in Python, C++, and Rust.

---

## 1. Python Mistakes

### Infinite-Width Integers

- Python ints have **no fixed width** — they grow as needed.
- `~n` for large n gives a very large positive number (not two's complement in 32-bit sense).
- **Fix:** Mask to 32 bits when needed: `n & 0xFFFFFFFF`

```python
# BUG: ~5 in Python = -6 (correct) but ~0xFFFFFFFF = large positive
# For 32-bit simulation:
def to_32bit(n):
    return n & 0xFFFFFFFF
```

### Operator Precedence

```python
# BUG: == has higher precedence than &
if n & 1 == 0:   # parsed as n & (1 == 0) → n & 0 → always False
# FIX:
if (n & 1) == 0:
```

### Right Shift of Negative Numbers

- Python uses **arithmetic** right shift (sign extension) for negative numbers.
- `-8 >> 1` = -4 (not 2147483644 as in logical shift).

### `bin()` and `bit_length()` Edge Cases

```python
(0).bit_length()  # 0, not 1
bin(-5)           # '-0b101' — be careful with negative
```

---

## 2. C++ Mistakes

### Signed vs Unsigned Confusion

```cpp
// BUG: Right shift of negative is implementation-defined
int x = -8;
int y = x >> 1;  // Usually -4, but not guaranteed

// FIX: Use unsigned when you need logical shift
unsigned u = (unsigned)-8;
unsigned v = u >> 1;  // Well-defined
```

### Undefined Behavior with Shifts

```cpp
// BUG: 1 << 31 on int = signed overflow (UB)
int x = 1 << 31;

// BUG: Shift amount >= width is UB
int y = 1 << 32;

// FIX:
long long x = 1LL << 40;
unsigned u = 1u << 31;
```

### Operator Precedence (Most Common!)

```cpp
// BUG:
if (n & 1 == 0)   // n & (1==0) → n & 0 → always 0
if (a ^ b + 1)    // a ^ (b+1)

// FIX: Always parenthesize
if ((n & 1) == 0)
int r = (a ^ b) + 1;
```

### Precedence Table (High → Low)

| Level | Operators |
|-------|-----------|
| 1 | `~` |
| 2 | `<<` `>>` |
| 3 | `&` |
| 4 | `^` |
| 5 | `\|` |
| 6 | `==` `!=` `<` `>` |

**Rule:** `==` has higher precedence than `&`, `^`, `|`. Always use `(n & 1) == 0`.

### `__builtin_ctz(0)` is Undefined

```cpp
// BUG: __builtin_ctz(0) is UB
int pos = __builtin_ctz(n);

// FIX:
int pos = (n != 0) ? __builtin_ctz(n) : -1;
```

---

## 3. Rust Mistakes

### Overflow Checking (Debug Mode)

- In debug, overflow **panics** (e.g. `1i32 << 31`).
- **Fix:** Use `1u32 << 31` or `1i32.wrapping_shl(31)`

```rust
// BUG in debug: panic
let x = 1i32 << 31;

// FIX:
let x = 1u32 << 31;
let x = 1i32.wrapping_shl(31);
```

### Signed Right Shift

- Rust uses **arithmetic** right shift for `i32`/`i64`.
- Use `u32`/`u64` for logical shift when needed.

### No Implicit Integer Conversion

```rust
// BUG: type mismatch
let n: u32 = 5;
let mask: u64 = 1 << 32;  // 1 is i32 by default

// FIX:
let mask: u64 = 1u64 << 32;
```

### Bitwise with `bool`

- `bool` in Rust is not a number. Use `as u32` or match.

```rust
// Can't do: let x = true & 1;
let x = (true as u32) & 1;
```

---

## 4. Cross-Language Summary

| Mistake | Python | C++ | Rust |
|---------|--------|-----|------|
| Precedence `&` vs `==` | ✓ | ✓ | ✓ |
| Shift overflow | N/A (arbitrary) | UB | Panic (debug) |
| `__builtin_ctz(0)` | N/A | UB | N/A |
| Signed right shift | Arithmetic | Impl-defined | Arithmetic |
| Fixed width | No (mask) | Yes | Yes |

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  ALWAYS: (n & 1) == 0  not  n & 1 == 0          │
│  C++: 1<<31 UB, use 1u<<31 or 1LL<<40           │
│  C++: __builtin_ctz(0) is UB                    │
│  Rust: 1i32<<31 panics in debug, use u32        │
│  Python: ~n not 32-bit, mask with 0xFFFFFFFF    │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] Always parenthesize: `(n & 1) == 0`
- [ ] C++: `1 << 31` UB; use `1u << 31`
- [ ] C++: `__builtin_ctz(0)` UB
- [ ] Rust: overflow panics in debug; use `u32`/`wrapping_shl`
- [ ] Python: mask to 32 bits when emulating fixed width
