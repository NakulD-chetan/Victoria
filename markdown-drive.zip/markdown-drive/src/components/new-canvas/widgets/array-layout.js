/**
 * World-space layout for the array widget: N columns, each at least SLOT_MIN_W wide.
 * Used when adding/removing cells so the widget width stays readable.
 */

/** Minimum width per column (index row + value row stacked). */
export const ARRAY_SLOT_MIN_W = 34;
export const ARRAY_GAP = 3;
/** Horizontal padding inside the lane (matches CSS .nc-array__track). */
export const ARRAY_LANE_H_PAD = 10;
/** Minimum widget width regardless of cell count. */
export const ARRAY_WIDGET_MIN_W = 140;
/** Header + index row + value row + padding (two-row grid). */
export const ARRAY_WIDGET_MIN_H = 72;

/**
 * Minimum width that fits `cellCount` slots at SLOT_MIN_W + gaps + padding.
 * @param {number} cellCount
 */
export function idealArrayWidth(cellCount) {
  const n = Math.max(0, Math.floor(cellCount));
  if (n <= 0) return ARRAY_WIDGET_MIN_W;
  const slots = n * ARRAY_SLOT_MIN_W + Math.max(0, n - 1) * ARRAY_GAP;
  return Math.max(ARRAY_WIDGET_MIN_W, slots + ARRAY_LANE_H_PAD);
}

/** Minimum height for header + two-row grid (indices + values). */
export function idealArrayHeight() {
  return ARRAY_WIDGET_MIN_H;
}
