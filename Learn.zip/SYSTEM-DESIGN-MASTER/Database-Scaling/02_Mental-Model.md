# Database Scaling — Mental Model

> **Permanent Recall:** Think of replication as library branches—same books (data) at multiple locations. Sharding is like splitting a phone book by alphabet—each shard holds one letter range. The shard key is the most important decision; it determines query patterns and hot spots. Replication lag means reads may be stale; design for it. Shard only when you've exhausted vertical scaling, read replicas, and caching.

---

## Replication: Library Branches Analogy

```
         LIBRARY = DATABASE
         
    Main Branch (Master)     Branch A (Replica)     Branch B (Replica)
    ┌─────────────────┐     ┌─────────────────┐    ┌─────────────────┐
    │ All new books   │     │ Copy of books   │    │ Copy of books   │
    │ arrive here     │────►│ Same catalog    │    │ Same catalog    │
    │ (writes)        │     │ (reads)         │    │ (reads)         │
    └─────────────────┘     └─────────────────┘    └─────────────────┘

- Master = headquarters, all new acquisitions
- Replicas = branches, serve readers (might have slightly old catalog = lag)
```

**Mapping:**

| Library | Database |
|---------|----------|
| Main branch | Master (primary) |
| Other branches | Read replicas |
| New book arrives | Write to master |
| Reader at any branch | Read from replica |
| Branch lagging behind | Replication lag |

---

## Sharding: Phone Book by Alphabet Analogy

```
    FULL PHONE BOOK (too big)     SPLIT BY ALPHABET (sharding)
    
    ┌──────────────────────┐     ┌─────────┐ ┌─────────┐ ┌─────────┐
    │ A-Z all in one book   │  →  │ A-F     │ │ G-M     │ │ N-Z     │
    │ (single database)     │     │ Shard 0 │ │ Shard 1 │ │ Shard 2 │
    └──────────────────────┘     └─────────┘ └─────────┘ └─────────┘

Lookup "Smith" → go directly to Shard 2 (N-Z)
Lookup "Johnson" → go to Shard 1 (G-M)
```

**Key insight:** You only open one shard per lookup. Bad split (e.g., A-M and N-Z) → Shard 2 overloaded if many names start with S.

---

## Consistent Hashing Ring Visualization

```
        MENTAL MODEL: CIRCULAR RAILWAY
        
    ┌─────────────────────────────────────┐
    │  Keys = passengers at stations      │
    │  Nodes = train stations on a ring   │
    │  Passenger goes to NEXT station     │
    │  clockwise                          │
    └─────────────────────────────────────┘

    Add new station → only passengers between prev and new station move
    Remove station → passengers reassign to next station
```

> **FAANG Tip:** "Keys and nodes on a ring. Key belongs to next node clockwise. Adding a node only affects keys in that arc."

---

## Shard Key Selection: The Most Important Decision

**The shard key determines:**
- Which shard each row lives on
- Whether you can query without scanning all shards
- Whether you get hot spots

```
GOOD SHARD KEY:
  - High cardinality (many unique values) → even distribution
  - Frequently in query predicate → single-shard queries
  - Example: user_id for user-centric data

BAD SHARD KEY:
  - Low cardinality (e.g., country: 200 values) → 200 shards max, uneven
  - Not in query → cross-shard scatter
  - Example: created_at → time-based hot shard
```

| Shard Key | Distribution | Query Pattern | Risk |
|-----------|--------------|---------------|------|
| `user_id` | Even (if UUID) | User queries → 1 shard | Good |
| `order_id` | Even | Order by ID → 1 shard | Good |
| `country` | Uneven (US, India hot) | Country filter → 1 shard | Hot shards |
| `created_at` | Time-based hot | Recent data hot | Hot shard |

---

## Replication Lag Mental Model

```
TIMELINE:
  T=0:  Write to Master (user updates profile)
  T=1:  Master commits, returns success
  T=2:  Replication in progress...
  T=3:  Replica 1 has it (50ms lag)
  T=4:  Replica 2 has it (100ms lag)
  T=5:  Replica 3 has it (200ms lag)

User reads from Replica 2 at T=2 → sees OLD data (stale read)
```

**Mental model:** Replicas are always "catching up." Reads may be milliseconds to seconds behind.

---

## When to Shard vs When to Replicate

| Scenario | Use | Why |
|----------|-----|-----|
| Read bottleneck | **Replication** | Add read replicas, route reads there |
| Write bottleneck | **Sharding** | Split writes across shards |
| Storage limit | **Sharding** | Each shard has subset of data |
| Need HA | **Replication** | Replicas for failover |
| Cross-shard queries needed | **Avoid sharding** or federation | Sharding makes cross-shard expensive |

---

## Decision Flowchart

```mermaid
flowchart TD
    A[DB bottleneck?] --> B{Read or Write?}
    B -->|Read| C[Add read replicas]
    C --> D{Still bottleneck?}
    D -->|No| E[Done]
    D -->|Yes| F[Add caching layer]
    F --> G{Still bottleneck?}
    B -->|Write| H[Vertical scale first]
    H --> I{Still bottleneck?}
    I -->|No| E
    I -->|Yes| J[Sharding - last resort]
    G -->|Yes| J
    J --> K[Choose shard key carefully]
```

---

## Decision Flowchart (ASCII Fallback)

```
                    DB bottleneck?
                         │
            Read ────────┴──────── Write
                │                     │
                ▼                     ▼
        Add read replicas      Vertical scale first
                │                     │
                ▼                     ▼
        Add caching            Still bottleneck?
                │                     │
                └─────────┬───────────┘
                          │ Yes
                          ▼
              Sharding (LAST RESORT)
                          │
                          ▼
              Choose shard key carefully
```

---

## 30-SECOND REVISION BOX

```
REPLICATION = Library branches (same data, multiple locations)
SHARDING = Phone book by alphabet (split by key)
CONSISTENT HASH = Circular railway, keys → next node clockwise
SHARD KEY = Most important; high cardinality, in query predicate
REPLICATION LAG = Replicas behind master, stale reads possible
SHARD LAST = Vertical → Replicas → Cache → Shard
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
