# Types of Fact Tables

> "One table shape does not capture every clock in the business. Match the fact type to the lifecycle you need to measure."

**Real-world analogy:** A grocer tracks instant purchases at checkout, takes a nightly photo of what is on every shelf, and tracks an online grocery order from placement through picking, packing, and delivery. Those three rhythms correspond to transaction facts, periodic snapshots, and accumulating snapshots, each with different insert and update patterns.

---

## Core Idea (2 Lines)

Transaction fact tables capture discrete business events at detailed grain and grow quickly with every sale line. Periodic snapshot and accumulating snapshot fact tables model slow-changing levels and multi-stage pipelines, trading insert-only simplicity for update-heavy patterns or large dense matrices.

---

## Transaction Fact Table

### Definition and properties

| Property | Typical retail behavior |
|----------|-------------------------|
| Grain | One row per lowest-level event (POS line, click, scan) |
| Growth | Largest fact table in many warehouses |
| Mutability | Mostly insert; corrections via late-arriving rows or small updates |
| Time | Event date is primary time dimension |

```
POS stream
----------
Receipt A line 1 ---> row
Receipt A line 2 ---> row
Receipt B line 1 ---> row
```

```sql
CREATE TABLE retail_core.fact_pos_sale_line (
  pos_transaction_id STRING,
  line_no INT64,
  product_sk INT64,
  store_sk INT64,
  date_sk INT64,
  sale_amount NUMERIC,
  quantity INT64
);
```

**Interview Tip:** Emphasize atomic grain for basket and promotion questions; this is the default answer unless the question is explicitly about balances or pipeline aging.

**Watch Out!** High-cardinality degenerate dimensions (raw GUIDs on every line) widen storage; consider junk dimensions for grouped attributes.

---

## Periodic Snapshot Fact Table

### Definition and properties

| Property | Typical retail behavior |
|----------|-------------------------|
| Grain | One row per entity per calendar period (store-SKU-day) |
| Purpose | Track levels such as on-hand, price, planogram compliance |
| Growth | Dense: every entity appears every period even if zero movement |
| Mutability | Often full partition reload or merge per period |

```
Inventory snapshot grid
-----------------------
For each (store, SKU, day): one row with on_hand_units

Store1 SKU001 Day1 --> 24
Store1 SKU001 Day2 --> 20
Store1 SKU002 Day1 --> 0   <-- still a row (sparse business, dense table)
```

```sql
CREATE TABLE retail_core.fact_inventory_daily (
  store_sk INT64,
  product_sk INT64,
  date_sk INT64,
  on_hand_units NUMERIC,
  in_transit_units NUMERIC
);
```

### Storage explosion and mitigations

| Mitigation | Trade-off |
|------------|-----------|
| Weekly instead of daily grain | Loses intra-week patterns |
| Only active SKUs in assortment | Complex maintenance of inclusion rules |
| Separate thin fact for slow movers | More joins for analysts |
| Compression and columnar storage | Operational tuning burden |

**Watch Out!** Missing rows for zero inventory days breaks `AVG(on_hand)` calculations; analysts assume denser data than exists.

---

## Accumulating Snapshot Fact Table

### Definition and properties

| Property | Typical retail behavior |
|----------|-------------------------|
| Grain | One row per pipeline instance (order id, shipment id) |
| Purpose | Track elapsed times between milestones |
| Mutability | Frequent updates as milestones occur |
| Fact columns | Often dates and lag measures, plus additive charges |

```
Order lifecycle row (single row updated over time)
-------------------------------------------------
placed_ts -> picked_ts -> packed_ts -> shipped_ts -> delivered_ts
```

```sql
CREATE TABLE retail_core.fact_order_fulfillment (
  order_id STRING,
  customer_sk INT64,
  placed_date_sk INT64,
  picked_date_sk INT64,
  shipped_date_sk INT64,
  delivered_date_sk INT64,
  order_total_amount NUMERIC,
  hours_pick_to_ship NUMERIC -- derived on update
);
```

**Interview Tip:** Describe accumulating snapshots as "wide timelines" suitable for SLA dashboards and bottleneck analysis.

**Watch Out!** Late-arriving events rewrite history; reconciliation must be expected, not treated as anomalies only.

---

## Comparison Table

| Aspect | Transaction | Periodic snapshot | Accumulating snapshot |
|--------|-------------|--------------------|-----------------------|
| Primary question | What sold? | What was on hand? | How long did fulfillment take? |
| Row creation | Each event | Each tick of calendar | Each pipeline instance starts |
| Updates | Rare | Sometimes | Frequent |
| Size driver | Number of events | Entities times periods | Open pipeline volume |
| Retail example | POS lines | Daily inventory | E-commerce order journey |

---

## Insert versus Update Patterns

```
Transaction fact load
=====================
INSERT INTO fact_pos_sale_line SELECT ... FROM staging;

Periodic snapshot load (daily partition)
=======================================
DELETE FROM fact_inventory_daily WHERE date_sk = :d
INSERT INTO fact_inventory_daily SELECT ...;

Accumulating snapshot maintenance
=================================
MERGE fact_order_fulfillment tgt
USING staging_orders src
ON tgt.order_id = src.order_id
WHEN MATCHED THEN UPDATE SET shipped_date_sk = src.shipped_date_sk
WHEN NOT MATCHED THEN INSERT ...;
```

| Pattern | Locking and concurrency | Idempotency needs |
|---------|-------------------------|-------------------|
| Insert-only transaction | Append-friendly | Duplicate event detection |
| Partition replace snapshot | Partition-scoped operations | Full rebuild for day must be repeatable |
| Merge accumulating | Row-level contention on hot keys | Careful ordering of milestone updates |

**Watch Out!** Accumulating snapshots with many milestones become wide and sparse; consider factless companion tables for milestone events if updates become too contentious.

---

## When to Use Each (Retail Decision Guide)

| Need | Choose |
|------|--------|
| Promotion effectiveness by SKU | Transaction fact at POS line grain |
| Shrink trending versus sales | Periodic inventory snapshot aligned to counts |
| Click-to-door SLA | Accumulating snapshot on web orders |
| Loyalty earn and burn as flows | Transaction facts; balances may still need snapshots |

**Interview Tip:** If a process has clear stages and SLA metrics, propose accumulating snapshot; if it is a stream of independent sales, transaction; if it is a level over time, periodic snapshot.

---

## Combining Types in One Program

A grocer may maintain:

| Fact | Role |
|------|------|
| `fact_pos_sale_line` | Demand signal |
| `fact_inventory_daily` | Supply positioning |
| `fact_order_fulfillment` | Digital channel operations |

Drill-across requires conformed dimensions such as `dim_product` and `dim_store`.

**Watch Out!** Joining transaction sales to daily inventory without aggregating sales to the day grain duplicates inventory across lines.

```sql
SELECT
  s.store_sk,
  d.calendar_date,
  SUM(s.sale_amount) AS daily_sales,
  AVG(i.on_hand_units) AS avg_on_hand
FROM retail_core.fact_pos_sale_line s
JOIN retail_core.dim_date d ON s.date_sk = d.date_sk
JOIN retail_core.fact_inventory_daily i
  ON s.store_sk = i.store_sk
 AND s.product_sk = i.product_sk
 AND s.date_sk = i.date_sk
GROUP BY 1, 2;
```

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Using transaction facts for inventory levels | Cannot reconstruct on-hand without full movement history | Add snapshot or movement fact |
| Daily snapshot for click-level web analytics | Huge sparse matrix | Use transaction facts for clicks |
| Accumulating snapshot with one row per line item | Updates explode | Grain at order header or use bridge |
| Frequent MERGE on billion-row transaction facts | Slow and fragile | Keep transaction insert-only; isolate corrections |
| Mixing multiple grains in one "fact" | Double counting in BI | Split tables and document drill paths |

---

## Key Takeaway

> Pick the fact table type by the shape of time in your business: events as transactions, calendars as periodic snapshots, and pipelines as accumulating snapshots, then enforce insert and update patterns that match reality.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Transaction = events, insert-heavy, often largest table.         |
| Periodic snapshot = dense grid of levels across time periods.   |
| Accumulating snapshot = one pipeline row updated across stages.  |
| Match insert/update patterns to fact type for performance.     |
| Conform dimensions to connect different fact types safely.       |
+------------------------------------------------------------------+
```
