import { memo, useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { useNewCanvasStore } from '../state/store';

function MermaidWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [svgContent, setSvgContent] = useState('');
  const [error, setError] = useState(null);
  
  const code = data.code || 'graph TD;\n  A-->B;';
  const title = data.title || 'Flowchart';
  const theme = data.theme || 'dark';

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: false,
      theme: theme === 'dark' ? 'dark' : 'default',
      securityLevel: 'loose',
    });

    const renderDiagram = async () => {
      try {
        setError(null);
        // Add random suffix to ID to avoid collisions
        const id = `mermaid-svg-${element.id}-${Math.floor(Math.random() * 10000)}`;
        const { svg } = await mermaid.render(id, code);
        setSvgContent(svg);
      } catch (err) {
        console.error('Mermaid render error:', err);
        setError(err.message || 'Invalid mermaid syntax');
      }
    };

    renderDiagram();
  }, [code, theme, element.id]);

  const onDelete = () => {
    commitElements((els) => els.map((e) => (e.id === element.id ? { ...e, isDeleted: true } : e)));
  };

  const bg = data.chromeBg || '#12141b';
  const accent = data.accentColor || '#38bdf8';
  const stroke = element.style?.stroke || 'rgba(255,255,255,0.12)';

  return (
    <div
      className="nc-widget"
      style={{
        background: bg,
        borderColor: stroke,
        borderWidth: element.style?.strokeWidth ?? 1,
        borderStyle: 'solid',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div className="nc-widget-header" data-nc-drag-handle="1">
        <div className="nc-widget-header__label" style={{ color: accent }}>
          {title}
        </div>
        <div className="nc-widget-header__actions">
          <button type="button" className="nc-widget-header__btn" onClick={onDelete} aria-label="Delete">×</button>
        </div>
      </div>

      <div 
        className="nc-widget-body" 
        style={{ 
          flex: 1, 
          overflow: 'hidden', 
          display: 'flex', 
          alignItems: 'center', 
          justifyContent: 'center',
          padding: '16px'
        }}
      >
        {error ? (
          <div style={{ color: '#ef4444', fontSize: '12px', whiteSpace: 'pre-wrap' }}>
            {error}
          </div>
        ) : (
          <div 
            dangerouslySetInnerHTML={{ __html: svgContent }} 
            style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
            className="mermaid-wrapper"
          />
        )}
      </div>
    </div>
  );
}

export default memo(MermaidWidgetImpl);
