# Aggregation + HAVING

GROUP BY buckets rows into groups and computes a summary per group. HAVING filters those groups after aggregation — the WHERE clause for aggregated results.

**DSA Analogy**: Frequency Map (HashMap) — you iterate over an array, bucket items by key, count/sum per bucket, then filter buckets by condition (e.g., "keys with count > 1").

---

## Core Idea (2 Lines)

`GROUP BY` collapses rows into groups and applies aggregate functions (COUNT, SUM, AVG, MIN, MAX) per group. `HAVING` filters the groups based on the aggregated values — you can't use WHERE for this because WHERE runs before grouping.

---

## SQL Execution Order (Critical to Understand)

```
1. FROM        → identify tables
2. JOIN        → combine tables
3. WHERE       → filter individual rows      ← BEFORE grouping
4. GROUP BY    → bucket rows into groups
5. HAVING      → filter groups               ← AFTER grouping
6. SELECT      → compute output columns
7. DISTINCT    → remove duplicate results
8. ORDER BY    → sort final output
9. LIMIT       → truncate result set
```

```
  Raw Rows (after WHERE)
  ┌──────────────────────────┐
  │ Alice  | Eng  | 120000   │
  │ Bob    | Eng  | 100000   │      GROUP BY dept
  │ Charlie| Sales| 90000    │  ──────────────────►
  │ Diana  | Sales| 85000    │
  │ Eve    | HR   | 70000    │
  └──────────────────────────┘

  Grouped Buckets
  ┌─────────────────────────────────┐
  │ Eng:   [120000, 100000]         │  → AVG = 110000, COUNT = 2
  │ Sales: [90000, 85000]           │  → AVG = 87500,  COUNT = 2
  │ HR:    [70000]                  │  → AVG = 70000,  COUNT = 1
  └─────────────────────────────────┘
        │
        │  HAVING COUNT(*) > 1      ← filter groups
        v
  ┌─────────────────────────────────┐
  │ Eng:   AVG = 110000, COUNT = 2  │  ✓ kept
  │ Sales: AVG = 87500,  COUNT = 2  │  ✓ kept
  │ HR:    AVG = 70000,  COUNT = 1  │  ✗ filtered out
  └─────────────────────────────────┘
```

---

## Syntax Template

```sql
SELECT group_col, AGG_FUNC(value_col) AS alias
FROM table
[WHERE row_filter]                    -- filter BEFORE grouping
GROUP BY group_col
[HAVING AGG_FUNC(value_col) condition]  -- filter AFTER grouping
ORDER BY alias DESC
[LIMIT n];
```

---

## The 5 Core Aggregate Functions


| Function                | What It Does                   | NULL Handling          |
| ----------------------- | ------------------------------ | ---------------------- |
| `COUNT(*)`              | Count all rows including NULLs | Counts NULLs           |
| `COUNT(col)`            | Count non-NULL values in col   | Skips NULLs            |
| `SUM(col)`              | Total of all values            | Skips NULLs            |
| `AVG(col)`              | Average (SUM/COUNT)            | Skips NULLs — careful! |
| `MIN(col)` / `MAX(col)` | Smallest / largest             | Skips NULLs            |


**The NULL trap with AVG:**

## 🔹 What is COALESCE?

`COALESCE` **returns the first NON-NULL value from a list of expressions.**

👉 Think of it like:  
“Give me the first valid value, otherwise try the next, otherwise next…”

```sql
-- Values: 100, 200, NULL
-- AVG = (100 + 200) / 2 = 150     ← NULL is SKIPPED, not treated as 0
-- If you want NULL = 0:
SELECT AVG(COALESCE(salary, 0)) FROM employees;
-- Now: (100 + 200 + 0) / 3 = 100
```

---

## Pattern Gallery

### Pattern 1: Find Duplicates

```sql
-- Emails that appear more than once
SELECT email, COUNT(*) AS cnt
FROM person
GROUP BY email
HAVING COUNT(*) > 1;
```

### Pattern 2: Group Filter (Top Groups)

```sql
-- Departments with average salary > 100k
SELECT dept, AVG(salary) AS avg_sal
FROM employees
GROUP BY dept
HAVING AVG(salary) > 100000;
```

### Pattern 3: Count Distinct Per Group

```sql
-- Categories with more than 5 unique products
SELECT category, COUNT(DISTINCT product_id) AS unique_products
FROM products
GROUP BY category
HAVING COUNT(DISTINCT product_id) > 5;
```

### Pattern 4: Multi-Column Grouping

```sql
-- Revenue per product per month
SELECT product_id,
       DATE_TRUNC('month', order_date) AS month,
       SUM(amount) AS revenue
FROM orders
GROUP BY product_id, DATE_TRUNC('month', order_date)
ORDER BY product_id, month;
```

### Pattern 5: HAVING Without GROUP BY

```sql
-- Does the table have more than 1000 rows?
SELECT COUNT(*) AS total
FROM orders
HAVING COUNT(*) > 1000;
-- Returns the count only if > 1000, otherwise empty result
```

### Pattern 6: GROUP BY with CASE (Conditional Aggregation)

```sql
-- Count active vs inactive customers per city
SELECT city,
       COUNT(CASE WHEN status = 'active' THEN 1 END) AS active_count,
       COUNT(CASE WHEN status = 'inactive' THEN 1 END) AS inactive_count
FROM customers
GROUP BY city;
```

---

## WHERE vs HAVING — When to Use Which


| Feature               | WHERE                       | HAVING                 |
| --------------------- | --------------------------- | ---------------------- |
| Runs                  | BEFORE grouping             | AFTER grouping         |
| Filters               | Individual rows             | Entire groups          |
| Can use aggregate?    | No                          | Yes                    |
| Can use column alias? | No (usually)                | Depends on DB          |
| Performance           | Better (reduces data early) | Runs on grouped result |


**Golden Rule**: Filter as much as possible in WHERE (reduces rows before grouping), then use HAVING only for aggregate-based conditions.

```sql
-- GOOD: WHERE filters first, then GROUP + HAVING
SELECT dept, AVG(salary)
FROM employees
WHERE hire_date > '2020-01-01'       -- row filter FIRST
GROUP BY dept
HAVING AVG(salary) > 80000;          -- group filter SECOND

-- BAD: Don't put row-level filters in HAVING
SELECT dept, AVG(salary)
FROM employees
GROUP BY dept
HAVING AVG(salary) > 80000
   AND hire_date > '2020-01-01';     -- ERROR: hire_date is not grouped
```

---

## Advanced Techniques

### GROUPING SETS / ROLLUP / CUBE



## 🔹 What does ROLLUP do?

👉 **ROLLUP creates subtotals + grand total automatically**

Think of it like:

> “Give me detailed data, then summaries step by step”

## 🔹 Key Idea

- `ROLLUP(dept, city)` means:
  1. dept + city
  2. dept only
  3. total

👉 It goes **right → left removing columns**

```sql
-- ROLLUP: hierarchical subtotals
SELECT dept, city, SUM(salary)
FROM employees
GROUP BY ROLLUP(dept, city);
-- Produces: (dept, city), (dept, NULL), (NULL, NULL) ← grand total

-- CUBE: all combinations of subtotals
SELECT dept, city, SUM(salary)
FROM employees
GROUP BY CUBE(dept, city);
-- Produces: (dept, city), (dept, NULL), (NULL, city), (NULL, NULL)

-- GROUPING SETS: custom combinations
SELECT dept, city, SUM(salary)
FROM employees
GROUP BY GROUPING SETS ((dept), (city), ());

GROUPING SETS is a SQL feature that allows multiple grouping combinations in a single query, equivalent to UNION ALL of multiple GROUP BY queries but more efficient and readable.
```

### GROUP_CONCAT / STRING_AGG

```sql
-- Concatenate names per department
-- MySQL:
SELECT dept, GROUP_CONCAT(name ORDER BY name SEPARATOR ', ')
FROM employees GROUP BY dept;

-- PostgreSQL:
SELECT dept, STRING_AGG(name, ', ' ORDER BY name)
FROM employees GROUP BY dept;
```

---

## Common Mistakes


| Mistake                                     | Why It Breaks                                    | Fix                                     |
| ------------------------------------------- | ------------------------------------------------ | --------------------------------------- |
| SELECT non-grouped column without aggregate | Column value is ambiguous (which row?)           | Add it to GROUP BY or wrap in aggregate |
| Using aggregate in WHERE                    | WHERE runs before grouping                       | Move to HAVING                          |
| COUNT(*) vs COUNT(col) confusion            | COUNT(*) counts NULLs, COUNT(col) doesn't        | Use the right one based on intent       |
| AVG ignoring NULLs                          | AVG skips NULLs silently                         | Use COALESCE(col, 0) if NULLs = 0       |
| Putting row filter in HAVING                | Runs after GROUP BY — slower and sometimes wrong | Move row filters to WHERE               |


---

## Key Takeaway

> GROUP BY is the HashMap of SQL — it buckets rows by key and computes aggregates per bucket. HAVING is the filter on those buckets. Always filter rows in WHERE first (reduce data early), then use HAVING for aggregate conditions. Master the execution order: WHERE → GROUP BY → HAVING → SELECT → ORDER BY.

