import { useState, useCallback, useRef, memo, useEffect } from 'react';
import { WIDGET_DIMS } from './widgetLibrary';
import { CANVAS_Z } from './stacking';
import { useForwardWheelToCanvas } from './useForwardWheelToCanvas';

const MIN = WIDGET_DIMS.array;
const DRAG_THRESHOLD_PX = 4;
/* Column width is flex-equal in CSS — CELL_W is the design nominal for baseWidth / scale math. */
const CELL_W = 64;
const BASE_ARRAY_W_EXTRA = 0;
/* value box (44) + index strip (18) + a small breathing margin — keeps both bands fully visible at any scale */
const BASE_ARRAY_H = 68;
const BASE_W_REF = 440;
const MIN_ARRAY_SCALE = 0.06;

function headerBarHeight(sceneW) {
  const sizeRatio = Math.max(0.65, Math.min(1.8, sceneW / BASE_W_REF));
  return Math.max(32, Math.round(34 * sizeRatio));
}

function stopBubble(e) {
  e.stopPropagation();
}

const IconGrid = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <rect x="3" y="3" width="7" height="7" rx="1" />
    <rect x="14" y="3" width="7" height="7" rx="1" />
    <rect x="3" y="14" width="7" height="7" rx="1" />
    <rect x="14" y="14" width="7" height="7" rx="1" />
  </svg>
);

const IconPlus = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <line x1="12" y1="5" x2="12" y2="19" />
    <line x1="5" y1="12" x2="19" y2="12" />
  </svg>
);

const IconRotateCcw = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <path d="M3 12a9 9 0 1 0 3-7.5L3 8" />
    <path d="M3 3v5h5" />
  </svg>
);

const IconX = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

function normalizeItems(items) {
  return Array.isArray(items) && items.length > 0 ? items.map((item) => String(item ?? '')) : ['10', '20', '30', '40', '50'];
}

function toFiniteNumber(value) {
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function makeDefaultItem(items, insertIndex) {
  const prev = insertIndex > 0 ? toFiniteNumber(items[insertIndex - 1]) : null;
  const next = insertIndex < items.length ? toFiniteNumber(items[insertIndex]) : null;

  if (prev != null && next != null) {
    const mid = prev + (next - prev) / 2;
    return Number.isInteger(mid) ? String(mid) : String(Number(mid.toFixed(1)));
  }
  if (prev != null) return String(prev + 10);
  if (next != null) return String(next - 10);
  return String((items.length + 1) * 10);
}

function defaultItemsPayload() {
  return normalizeItems(['10', '20', '30', '40', '50']);
}

/** UI colors for values & dividers — do not use canvas stroke for text (contrast breaks). */
function arrayContentUiVars(theme) {
  const dark = theme === 'dark';
  return {
    '--aw-value': dark ? '#f1f5f9' : '#0f172a',
    '--aw-muted': dark ? '#94a3b8' : '#64748b',
    '--aw-divider': dark ? 'rgba(148, 163, 184, 0.32)' : 'rgba(51, 65, 85, 0.22)',
    '--aw-track-border': dark ? 'rgba(148, 163, 184, 0.4)' : 'rgba(51, 65, 85, 0.28)',
    '--aw-focus-ring': dark ? 'rgba(129, 140, 248, 0.55)' : 'rgba(79, 70, 229, 0.45)',
    '--aw-selection-bg': dark ? 'rgba(129, 140, 248, 0.35)' : 'rgba(79, 70, 229, 0.22)',
  };
}

function ArrayWidgetOverlay({
  widgetGroups, viewport, canvasOffset = { x: 0, y: 0 },
  selectedWidgetId, onSelectWidget,
  onMove, onResize, onMoveResize, onUpdateData, onDelete,
  theme = 'light',
  activeTool = 'selection',
}) {
  const entries = [];
  for (const [id, info] of widgetGroups) {
    if (info.type === 'array') entries.push({ id, ...info });
  }
  if (entries.length === 0) return null;
  const { zoom, scrollX, scrollY } = viewport;

  return (
    <>
      {entries.map((entry) => (
        <ArrayPanel
          key={entry.id}
          id={entry.id}
          data={entry.data}
          worldX={entry.worldX}
          worldY={entry.worldY}
          w={entry.w}
          h={entry.h}
          screenX={canvasOffset.x + (entry.worldX + scrollX) * zoom}
          screenY={canvasOffset.y + (entry.worldY + scrollY) * zoom}
          zoom={zoom}
          onMove={onMove}
          onResize={onResize}
          onMoveResize={onMoveResize}
          onUpdateData={onUpdateData}
          onDelete={onDelete}
          isSelected={entry.id === selectedWidgetId}
          onSelectWidget={onSelectWidget}
          theme={theme}
          activeTool={activeTool}
        />
      ))}
    </>
  );
}

const ArrayPanel = memo(function ArrayPanel({
  id, data, worldX, worldY, w, h,
  screenX, screenY, zoom,
  onMove, onResize, onMoveResize, onUpdateData, onDelete,
  isSelected, onSelectWidget,
  theme = 'light',
  activeTool = 'selection',
}) {
  /* Pointer-events gate: when a drawing tool is active in Excalidraw, the
   * widget becomes inert so freehand / shape strokes pass through it just
   * like they do over a regular shape. */
  const isInteractive = activeTool === 'selection';
  const interactivePE = isInteractive ? 'auto' : 'none';
  const [items, setItems] = useState(() => normalizeItems(data.items));
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [newIndex, setNewIndex] = useState(null);
  const saveTimer = useRef(null);
  const trackRef = useRef(null);
  const newTimer = useRef(null);
  const migrateRef = useRef(false);
  const rootRef = useRef(null);

  /* Forward trackpad/wheel gestures to the Excalidraw canvas so panning works
   * even when the cursor is over the array widget. */
  useForwardWheelToCanvas(rootRef);

  const baseWidth = Math.max(items.length * CELL_W + BASE_ARRAY_W_EXTRA, 1);
  const sizeRatio = Math.max(0.65, Math.min(1.8, w / BASE_W_REF));
  const headerBarH = headerBarHeight(w);
  /*
   * scaleW: fill width. scaleH: fill body height under header (so indices never clip when proxy is tall).
   * Do NOT cap at 2.2 — that froze content while Excalidraw proxy width kept growing (“only border moves”).
   */
  const scaleW = w / baseWidth;
  const bodyAvail = Math.max(0, h - headerBarH);
  const scaleH = bodyAvail > 1 ? bodyAvail / BASE_ARRAY_H : scaleW;
  const scale = Math.max(MIN_ARRAY_SCALE, Math.min(scaleW, scaleH));
  const bodySceneH = Math.ceil(BASE_ARRAY_H * scale);

  const proxyStyle = data.proxyStyle || {};
  const rawStroke = proxyStyle.strokeColor;
  const hasSolidStroke = Boolean(rawStroke && rawStroke !== 'transparent');
  /* Excalidraw often uses strokeColor: transparent — color-mix(..., transparent) breaks header/chrome. */
  const strokeColor = hasSolidStroke ? rawStroke : (theme === 'dark' ? '#94a3b8' : '#475569');
  const chromeBorder = hasSolidStroke ? rawStroke : (theme === 'dark' ? 'rgba(148, 163, 184, 0.38)' : 'rgba(51, 65, 85, 0.3)');
  const backgroundColor = proxyStyle.backgroundColor && proxyStyle.backgroundColor !== 'transparent'
    ? proxyStyle.backgroundColor
    : undefined;
  const strokeWidth = proxyStyle.strokeWidth || 1.5;
  const strokeStyle = proxyStyle.strokeStyle === 'dashed'
    ? 'dashed'
    : proxyStyle.strokeStyle === 'dotted'
      ? 'dotted'
      : 'solid';
  const opacity = proxyStyle.opacity != null ? Math.max(0.25, proxyStyle.opacity / 100) : 1;
  const borderRadius = proxyStyle.roundness ? 8 : 0;

  const shellStyle = {
    borderColor: chromeBorder,
    /* Thin frame; heavy proxy stroke is visually noisy for the array strip */
    borderWidth: Math.min(proxyStyle.strokeWidth ?? 1.5, 1.25),
    borderStyle: proxyStyle.strokeStyle === 'dashed' ? 'dashed' : proxyStyle.strokeStyle === 'dotted' ? 'dotted' : 'solid',
    backgroundColor: proxyStyle.backgroundColor && proxyStyle.backgroundColor !== 'transparent' ? proxyStyle.backgroundColor : undefined,
    opacity: proxyStyle.opacity != null ? Math.max(0.2, proxyStyle.opacity / 100) : undefined,
    borderRadius: Math.min(borderRadius, 8),
  };

  const headerStyle = {
    borderBottom: `1px solid ${theme === 'dark' ? 'rgba(148, 163, 184, 0.28)' : 'rgba(51, 65, 85, 0.16)'}`,
    borderTopLeftRadius: Math.min(borderRadius, 6),
    borderTopRightRadius: Math.min(borderRadius, 6),
  };

  const persistItems = useCallback((nextItems) => {
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      onUpdateData(id, { items: nextItems });
    }, 180);
  }, [id, onUpdateData]);

  const updateItems = useCallback((nextItems) => {
    setItems(nextItems);
    persistItems(nextItems);
  }, [persistItems]);

  useEffect(() => {
    if (migrateRef.current) return;
    const hb = headerBarHeight(w);
    const need = hb + Math.ceil(BASE_ARRAY_H * (w / baseWidth));
    if (h < need - 2) {
      migrateRef.current = true;
      onResize(id, w, need);
    }
  }, [baseWidth, h, id, onResize, w]);

  const handleValueChange = useCallback((index, value) => {
    const next = items.map((item, itemIndex) => (itemIndex === index ? value : item));
    updateItems(next);
  }, [items, updateItems]);

  const handleInsertItem = useCallback((e, insertIndex) => {
    e.preventDefault();
    e.stopPropagation();
    const next = [...items];
    next.splice(insertIndex, 0, makeDefaultItem(items, insertIndex));
    updateItems(next);
    setNewIndex(insertIndex);
    clearTimeout(newTimer.current);
    newTimer.current = setTimeout(() => setNewIndex(null), 420);
    onSelectWidget?.(id);
    const nextBaseWidth = Math.max(next.length * CELL_W + BASE_ARRAY_W_EXTRA, 1);
    const targetW = Math.max(MIN.minW, Math.round(nextBaseWidth * (w / baseWidth)));
    const hb = headerBarHeight(targetW);
    const s = targetW / nextBaseWidth;
    const targetH = hb + Math.ceil(BASE_ARRAY_H * s);
    if (targetW !== w || targetH !== h) onResize(id, targetW, targetH);
  }, [baseWidth, h, id, items, onResize, onSelectWidget, updateItems, w]);

  const handleRemoveItem = useCallback((e, index) => {
    e.preventDefault();
    e.stopPropagation();
    if (items.length <= 1) return;
    const next = items.filter((_, itemIndex) => itemIndex !== index);
    updateItems(next);
  }, [items, updateItems]);

  const handleReset = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    const next = defaultItemsPayload();
    setItems(next);
    clearTimeout(saveTimer.current);
    onUpdateData(id, { items: next });
  }, [id, onUpdateData]);

  const handleAppendEnd = useCallback((e) => {
    handleInsertItem(e, items.length);
  }, [handleInsertItem, items.length]);

  const handleDeleteWidget = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    onDelete(id);
  }, [id, onDelete]);

  useEffect(() => () => {
    clearTimeout(saveTimer.current);
    clearTimeout(newTimer.current);
  }, []);

  useEffect(() => {
    setItems(normalizeItems(data.items));
  }, [data.items]);

  const handleHeaderMouseDown = useCallback((e) => {
    if (e.target.closest('button')) return;
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startMY = e.clientY;
    const startWX = worldX;
    const startWY = worldY;
    let dragStarted = false;
    const move = (ev) => {
      if (!dragStarted) {
        if (Math.abs(ev.clientX - startMX) < DRAG_THRESHOLD_PX && Math.abs(ev.clientY - startMY) < DRAG_THRESHOLD_PX) return;
        dragStarted = true;
        setIsDragging(true);
      }
      onMove(id, startWX + (ev.clientX - startMX) / zoom, startWY + (ev.clientY - startMY) / zoom);
    };
    const up = () => {
      if (!dragStarted) onSelectWidget?.(id);
      setIsDragging(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [id, worldX, worldY, zoom, onMove, onSelectWidget]);

  const handleTrackMouseDown = useCallback((e) => {
    if (e.target.closest('button, input')) return;
    e.stopPropagation();
    onSelectWidget?.(id);
  }, [id, onSelectWidget]);

  const handleResizeMouseDown = useCallback((e, edge) => {
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startW = w;
    const startBaseWidth = baseWidth;
    const startWX = worldX;
    setIsResizing(true);
    const move = (ev) => {
      const dx = (ev.clientX - startMX) / zoom;
      if (edge.includes('e')) {
        const nextW = Math.max(MIN.minW, startW + dx);
        const hb = headerBarHeight(nextW);
        const s = nextW / startBaseWidth;
        const nextH = hb + Math.ceil(BASE_ARRAY_H * s);
        onResize(id, nextW, nextH);
      } else if (edge.includes('w')) {
        const nextW = Math.max(MIN.minW, startW - dx);
        const nextX = startWX + (startW - nextW);
        const hb = headerBarHeight(nextW);
        const s = nextW / startBaseWidth;
        const nextH = hb + Math.ceil(BASE_ARRAY_H * s);
        onMoveResize(id, nextX, worldY, nextW, nextH);
      }
    };
    const up = () => {
      setIsResizing(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [baseWidth, id, onMoveResize, onResize, w, worldX, worldY, zoom]);

  return (
    <div
      ref={rootRef}
      className={`aw-overlay${isSelected ? ' aw-overlay--selected' : ''}${isDragging ? ' aw-overlay--dragging' : ''}${isResizing ? ' aw-overlay--resizing' : ''}`}
      style={{
        position: 'absolute',
        left: screenX,
        top: screenY,
        width: w,
        height: h,
        transform: `scale(${zoom})`,
        transformOrigin: 'top left',
        pointerEvents: 'none',
        zIndex: CANVAS_Z.WIDGETS,
        willChange: 'transform',
        ...shellStyle,
      }}
      onKeyDown={stopBubble}
      onKeyUp={stopBubble}
    >
      <div
        className="cw-header cw-header--ft aw-panel__header"
        style={{
          pointerEvents: interactivePE,
          minHeight: headerBarH,
          fontSize: Math.max(11, Math.round(11 * sizeRatio)),
          ...headerStyle,
        }}
        onMouseDown={handleHeaderMouseDown}
      >
        <span className="aw-panel__brand" title="Array visualization">
          <span className="aw-panel__brand-icon">
            <IconGrid />
          </span>
          <span className="aw-panel__title">Array</span>
        </span>
        <span className="aw-panel__meta">
          {items.length}
          {' '}
          items
        </span>
        <span className="ft-actions__sep" aria-hidden />
        <button
          type="button"
          className="ft-actions__btn aw-toolbar__append"
          onClick={handleAppendEnd}
          onMouseDown={(e) => e.stopPropagation()}
          title="Append cell at end"
          aria-label="Append cell at end"
        >
          <IconPlus />
        </button>
        <button
          type="button"
          className="ft-actions__btn"
          onClick={handleReset}
          onMouseDown={(e) => e.stopPropagation()}
          title="Reset to default values"
          aria-label="Reset to default values"
        >
          <IconRotateCcw />
        </button>
        <div className="cw-toolbar-spacer" aria-hidden />
        <button
          type="button"
          className="ft-actions__btn cw-toolbar__close"
          onClick={handleDeleteWidget}
          onMouseDown={(e) => e.stopPropagation()}
          title="Remove widget"
          aria-label="Remove widget"
        >
          <IconX />
        </button>
      </div>

      <div
        className="aw-panel__body"
        style={{ height: Math.max(0, h - headerBarH) }}
      >
        <div
          className="aw-content"
          style={{
            pointerEvents: interactivePE,
            width: baseWidth,
            height: BASE_ARRAY_H,
            transform: `scale(${scale})`,
            transformOrigin: 'top left',
            /* Canvas stroke/fill — structure only; glyphs use --aw-value / --aw-muted */
            '--aw-stroke': strokeColor,
            '--aw-fill': backgroundColor || 'transparent',
            '--aw-stroke-w': `${strokeWidth}px`,
            '--aw-stroke-style': strokeStyle,
            '--aw-opacity': opacity,
            '--aw-radius': `${borderRadius}px`,
            ...arrayContentUiVars(theme),
          }}
          onPointerDown={(e) => { stopBubble(e); onSelectWidget?.(id); }}
          onMouseDown={stopBubble}
          onClick={stopBubble}
          onKeyDown={stopBubble}
          onKeyUp={stopBubble}
        >
          <div className="aw-array-stage">
            <div className="aw-track" ref={trackRef} onMouseDown={handleTrackMouseDown}>
              <div
                className="aw-track-inner"
                style={{ '--aw-cols': items.length }}
              >
                <button
                  type="button"
                  className="aw-insert-btn aw-insert-btn--start"
                  onClick={(e) => handleInsertItem(e, 0)}
                  onMouseDown={(e) => e.stopPropagation()}
                  title="Insert at start"
                >
                  <span className="aw-insert-btn__icon">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
                      <line x1="12" y1="5" x2="12" y2="19" />
                      <line x1="5" y1="12" x2="19" y2="12" />
                    </svg>
                  </span>
                </button>

                {items.map((item, index) => (
                  <div key={`${id}-${index}`} className={`aw-cell${newIndex === index ? ' aw-cell--new' : ''}`}>
                    <div className="aw-cell__box">
                      <input
                        className="aw-cell__input"
                        value={item}
                        onChange={(e) => handleValueChange(index, e.target.value)}
                        onMouseDown={stopBubble}
                        onClick={stopBubble}
                        onKeyDown={stopBubble}
                        onKeyUp={stopBubble}
                        placeholder={`a[${index}]`}
                        spellCheck={false}
                      />
                      {items.length > 1 && (
                        <button
                          type="button"
                          className="aw-cell__remove"
                          onClick={(e) => handleRemoveItem(e, index)}
                          onMouseDown={(e) => e.stopPropagation()}
                          title={`Remove index ${index}`}
                        >
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4">
                            <line x1="5" y1="12" x2="19" y2="12" />
                          </svg>
                        </button>
                      )}
                    </div>
                    <div className="aw-cell__index">{index}</div>
                    <button
                      type="button"
                      className={`aw-insert-btn ${index === items.length - 1 ? 'aw-insert-btn--end' : ''}`}
                      onClick={(e) => handleInsertItem(e, index + 1)}
                      onMouseDown={(e) => e.stopPropagation()}
                      title={index === items.length - 1 ? 'Insert at end' : `Insert between ${index} and ${index + 1}`}
                    >
                      <span className="aw-insert-btn__icon">
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
                          <line x1="12" y1="5" x2="12" y2="19" />
                          <line x1="5" y1="12" x2="19" y2="12" />
                        </svg>
                      </span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div
        className={`aw-border-handle aw-border-handle--w${isSelected ? ' aw-border-handle--visible' : ''}`}
        style={{ pointerEvents: interactivePE }}
        onMouseDown={(e) => handleResizeMouseDown(e, 'w')}
      />
      <div
        className={`aw-border-handle aw-border-handle--e${isSelected ? ' aw-border-handle--visible' : ''}`}
        style={{ pointerEvents: interactivePE }}
        onMouseDown={(e) => handleResizeMouseDown(e, 'e')}
      />
    </div>
  );
});

export default ArrayWidgetOverlay;
