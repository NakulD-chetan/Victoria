# Subqueries and CTE — Coding Templates

---

## EXISTS pattern

```sql
SELECT c.id, c.name
FROM customers c
WHERE EXISTS (
    SELECT 1 FROM orders o WHERE o.customer_id = c.id
);
```

---

## IN vs NOT IN (careful with NULL)

Prefer **NOT EXISTS** for anti-join:

```sql
SELECT c.id
FROM customers c
WHERE NOT EXISTS (
    SELECT 1 FROM orders o WHERE o.customer_id = c.id
);
```

---

## CTE chain

```sql
WITH daily AS (
    SELECT order_date::date AS d, SUM(amount) AS revenue
    FROM orders
    GROUP BY 1
),
rolling AS (
    SELECT d, revenue,
           SUM(revenue) OVER (ORDER BY d ROWS BETWEEN 6 PRECEDING AND CURRENT ROW) AS rev_7d
    FROM daily
)
SELECT * FROM rolling;
```

---

## Scalar subquery in SELECT

```sql
SELECT name,
       (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS order_cnt
FROM users u;
```

---

*Next: [[04_Interview-Thinking]]*
