import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const GRID = [
  ['A', 'B', 'C', 'E'],
  ['S', 'F', 'C', 'S'],
  ['A', 'D', 'E', 'E'],
];
const WORD = 'SEE';
const R = GRID.length;
const CC = GRID[0].length;

function generateSteps() {
  const steps = [];
  const dirs = [
    [0, 1],
    [1, 0],
    [0, -1],
    [-1, 0],
  ];

  function dfs(r, c, idx, visited) {
    if (idx === WORD.length) return true;
    if (r < 0 || r >= R || c < 0 || c >= CC) return false;
    if (visited[r][c] || GRID[r][c] !== WORD[idx]) {
      steps.push({
        type: 'fail',
        r: Math.max(0, Math.min(r, R - 1)),
        c: Math.max(0, Math.min(c, CC - 1)),
        idx,
        visited: visited.map((x) => [...x]),
        path: [],
        msg: 'Letter mismatch or visited',
      });
      return false;
    }
    visited[r][c] = 1;
    steps.push({
      type: 'visit',
      r,
      c,
      idx,
      visited: visited.map((x) => [...x]),
      path: [[r, c]],
      msg: `Match "${WORD[idx]}" at (${r},${c})`,
    });
    if (idx === WORD.length - 1) {
      steps.push({ type: 'done', msg: 'Word found', visited: visited.map((x) => [...x]), path: [[r, c]] });
      return true;
    }
    for (const [dr, dc] of dirs) {
      if (dfs(r + dr, c + dc, idx + 1, visited)) return true;
    }
    visited[r][c] = 0;
    steps.push({
      type: 'back',
      r,
      c,
      idx,
      visited: visited.map((x) => [...x]),
      path: [[r, c]],
      msg: 'Backtrack',
    });
    return false;
  }

  steps.push({ type: 'start', msg: `Search "${WORD}"`, visited: Array.from({ length: R }, () => Array(CC).fill(0)), path: [] });
  outer: for (let r = 0; r < R; r++) {
    for (let c = 0; c < CC; c++) {
      const vis = Array.from({ length: R }, () => Array(CC).fill(0));
      steps.push({ type: 'cell-start', r, c, visited: vis.map((x) => [...x]), path: [[r, c]] });
      if (dfs(r, c, 0, vis)) break outer;
    }
  }
  return steps;
}

function paint(step) {
  const cellColors = {};
  const cellValues = {};
  const vis = step.visited || [];
  for (let r = 0; r < R; r++) {
    for (let c = 0; c < CC; c++) {
      const key = `${r}-${c}`;
      cellValues[key] = GRID[r][c];
      cellColors[key] = vis[r]?.[c] ? 'placed' : 'empty';
    }
  }
  if (step.r != null && step.c != null) {
    const key = `${step.r}-${step.c}`;
    if (step.type === 'visit') cellColors[key] = 'exploring';
    if (step.type === 'back' || step.type === 'fail') cellColors[key] = 'conflict';
  }
  return {
    size: R,
    cols: CC,
    grid: Array.from({ length: R }, () => Array(CC).fill('empty')),
    cellColors,
    cellValues,
    path: step.path || [],
  };
}

export default function WordSearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Word: ${WORD}` });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'visit') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'back') canvasRef.current?.addAnim('backtrack', { r: step.r, c: step.c }, 280);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
