import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: kruskals-mst */
const GRAPH = {
  nodes: [
    { id: 'A', x: 120, y: 200, label: 'A' },
    { id: 'B', x: 240, y: 120, label: 'B' },
    { id: 'C', x: 380, y: 140, label: 'C' },
    { id: 'D', x: 500, y: 220, label: 'D' },
    { id: 'E', x: 360, y: 300, label: 'E' },
    { id: 'F', x: 220, y: 300, label: 'F' },
  ],
  edges: [
    { from: 'B', to: 'F', weight: 2, directed: false },
    { from: 'D', to: 'E', weight: 2, directed: false },
    { from: 'B', to: 'C', weight: 3, directed: false },
    { from: 'E', to: 'F', weight: 3, directed: false },
    { from: 'A', to: 'B', weight: 4, directed: false },
    { from: 'C', to: 'E', weight: 4, directed: false },
    { from: 'A', to: 'F', weight: 6, directed: false },
    { from: 'C', to: 'D', weight: 5, directed: false },
  ],
};

function edgeKey(u, v) {
  return u < v ? `${u}-${v}` : `${v}-${u}`;
}

function find(parent, x) {
  if (parent[x] !== x) parent[x] = find(parent, parent[x]);
  return parent[x];
}

function generateSteps() {
  const parent = Object.fromEntries(GRAPH.nodes.map((n) => [n.id, n.id]));
  const rank = Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 0]));
  const sorted = [...GRAPH.edges].sort((a, b) => a.weight - b.weight);
  const steps = [];
  steps.push({ type: 'sort', nodeColors: {}, edgeColors: {} });
  sorted.forEach((e) => {
    const ru = find(parent, e.from);
    const rv = find(parent, e.to);
    steps.push({
      type: 'consider',
      nodeColors: { [e.from]: 'processing', [e.to]: 'processing' },
      edgeColors: { [edgeKey(e.from, e.to)]: 'highlight' },
      edge: `${e.from}-${e.to}`,
    });
    if (ru === rv) {
      steps.push({
        type: 'cycle',
        nodeColors: { [e.from]: 'current', [e.to]: 'current' },
        edgeColors: { [edgeKey(e.from, e.to)]: 'back' },
      });
    } else {
      if (rank[ru] < rank[rv]) parent[ru] = rv;
      else if (rank[ru] > rank[rv]) parent[rv] = ru;
      else {
        parent[rv] = ru;
        rank[ru] += 1;
      }
      steps.push({
        type: 'take',
        nodeColors: { [e.from]: 'visited', [e.to]: 'visited' },
        edgeColors: { [edgeKey(e.from, e.to)]: 'mst' },
      });
    }
  });
  steps.push({ type: 'done', nodeColors: Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function KruskalsMSTVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: "Kruskal's MST with union–find" });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: [],
      stack: [],
      distances: step.distances || {},
      visited: step.visited || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
