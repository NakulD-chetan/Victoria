# System Design Interview — COMPLETE READY-TO-GO NOTES

> **Yeh ek hi file padho — System Design interview ke liye sab kuch cover hai!**
> Easy language. Only important stuff. No fluff.
> Time kam hai? No problem — yeh notes tumhe ready kar denge.

---

# PART 1: INTERVIEW FRAMEWORK — Kaise Approach Karna Hai

---

## 45-Minute Ka Game Plan

```
[0-5 min]   STEP 1: Requirements     → Kya banana hai? Scale kya hai?
[5-10 min]  STEP 2: Estimation       → QPS, Storage kitna lagega?
[10-25 min] STEP 3: High-Level Design → Components draw karo, data flow dikhao
[25-40 min] STEP 4: Deep Dive        → Bottleneck, Failures, Trade-offs discuss karo
[40-45 min] STEP 5: Wrap-up          → Monitoring, Security, Future improvements
```

**Golden Rule:** Requirements FIRST. Kabhi bhi seedha design mat shuru karo!

---

## Step 1: Requirements (5 min) — YEH SABSE IMPORTANT HAI

**Functional (Kya karna hai):**
- Core features kya hain?
- Users kaun hain?
- Read-heavy ya Write-heavy?

**Non-Functional (Kitna achha karna hai):**
- Scale? → DAU, QPS
- Latency? → <100ms, <200ms?
- Availability? → 99.9%? 99.99%?
- Consistency? → Strong ya Eventual OK?

**Interview mein bolo:**
> "Let me clarify requirements first. What's the expected scale? Read:Write ratio? Latency expectations?"

---

## Step 2: Back-of-Envelope Estimation (5 min)

### Must-Know Formulas

| What | Formula |
|------|---------|
| **QPS** | DAU × requests_per_user / 86,400 |
| **Peak QPS** | Average × 2 to 5 |
| **Storage** | items × size_per_item × days × replication |
| **Bandwidth** | QPS × response_size |
| **Servers needed** | Peak QPS / QPS_per_server × 1.3 buffer |

### Must-Know Numbers

| Component | Capacity |
|-----------|----------|
| Web server | ~1K QPS |
| DB read | ~5K QPS |
| Redis | ~100K QPS |
| Kafka partition | ~10-100K msg/s |

### Latency Numbers (Jeff Dean)

| Operation | Time |
|-----------|------|
| L1 cache | 0.5 ns |
| RAM | 100 ns |
| SSD random read | 100 μs |
| Network same DC | 0.5 ms |
| HDD seek | 10 ms |
| Cross-country | 50 ms |
| Round the world | 150 ms |

### Power of 2

| Power | Value | Name |
|-------|-------|------|
| 2^10 | 1,024 | ~1 Thousand (KB) |
| 2^20 | ~1M | ~1 Million (MB) |
| 2^30 | ~1B | ~1 Billion (GB) |
| 2^40 | ~1T | ~1 Trillion (TB) |

**Quick trick:** 86,400 sec/day ≈ ~100K. So 100M DAU × 10 req / 100K ≈ 10K QPS.

**Interview mein bolo:**
> "Let me estimate. 100M DAU × 10 req/user = 1B req/day. Divided by ~100K sec = ~10K QPS average. Peak ~30K."

---

## Step 3: High-Level Design (15 min)

**Always draw this basic flow:**

```
[Client/Mobile] → [Load Balancer] → [App Servers (Stateless)]
                                          ↓
                                    [Cache (Redis)]
                                          ↓
                                    [Database]
                                          ↓
                              [Message Queue (if async needed)]
```

**Yeh 4 cheezein ALWAYS include karo:**

| Must Include | Example |
|--------------|---------|
| **API Design** | `POST /api/v1/tweet`, `GET /api/v1/feed` |
| **Data Model** | Users table, Tweets table, Follow table |
| **Data Flow** | Write path (client → server → DB) + Read path (client → cache → DB) |
| **Storage Choice** | SQL for ACID, NoSQL for scale, Redis for cache |

---

## Step 4: Deep Dive (15 min) — YAHAN HIRE DECIDE HOTA HAI

Pick 1-2 critical components aur DEEP jao:

| Topic | Kya Discuss Karo |
|-------|------------------|
| **Bottleneck** | "Reads 100× writes — cache is critical here" |
| **Scaling** | "Horizontal scaling, stateless servers, sharding" |
| **Failure** | "What if DB fails? Replicas takeover. Cache miss? DB serves" |
| **Trade-offs** | "SQL for consistency, trade-off: harder to scale horizontally" |
| **Consistency** | "Eventual OK for feed, Strong needed for payments" |

**Interview mein bolo:**
> "The main bottleneck is reads. I'll add Redis cache. Trade-off: stale data possible, but TTL handles that."

---

## Step 5: Wrap-up (5 min)

Quick mention karo:
- **Monitoring:** "Latency p99, error rate, cache hit ratio monitor karenge"
- **Security:** "HTTPS, auth tokens, rate limiting, input validation"
- **Future:** "CDN for static, event sourcing for analytics, multi-region for global"

---

# PART 2: BUILDING BLOCKS — Har Component Ka Quick Reference

---

## 1. Load Balancer

**Kya hai:** Traffic ko multiple servers pe evenly distribute karta hai.

| Algorithm | Kab Use Karo |
|-----------|--------------|
| **Round Robin** | Stateless API, simple equal distribution |
| **Least Connections** | Variable request duration |
| **IP Hash / Sticky** | Session affinity needed |
| **Consistent Hashing** | Cache, minimize reshuffle on add/remove |

| Type | Layer | Sees What |
|------|-------|-----------|
| **L4** | Transport | IP + Port (fast, simple) |
| **L7** | Application | HTTP headers, URL path (smart routing) |

**Key points:**
- Health checks → dead servers auto-remove
- Active-Active ya Active-Passive for HA
- Software (Nginx, ALB) for cloud. Hardware for ultra-low latency

**Interview mein bolo:** "Stateless servers ke liye Round Robin. Cache/Memcached ke liye Consistent Hashing."

---

## 2. Caching

**Kya hai:** Frequently accessed data ko fast memory mein rakho → DB load kam, latency kam.

| Strategy | How It Works | Best For |
|----------|-------------|----------|
| **Cache-Aside** | App checks cache. Miss → DB → populate cache | Read-heavy, stale OK |
| **Write-Through** | Write to cache + DB together (sync) | Consistency needed |
| **Write-Behind** | Write to cache. Async → DB later | Write burst handling |

| Eviction | How |
|----------|-----|
| **LRU** | Least Recently Used hatao (most common) |
| **LFU** | Least Frequently Used hatao |
| **TTL** | Time-to-Live, auto-expire after X seconds |

**Critical problems to know:**
- **Cache Stampede (Thundering Herd):** Ek popular key expire → 1000 requests DB hit. Fix: Lock ya early refresh
- **Cache Invalidation:** "Hardest problem in CS" — TTL + event-based invalidation
- **Cache Hit Ratio:** Target > 80%. Formula: Hits / (Hits + Misses)

**80/20 Rule:** 80% traffic sirf 20% data pe — wohi cache karo!

**Interview mein bolo:** "Read-heavy? Redis cache. Cache-Aside pattern. TTL for invalidation. Stampede ke liye lock-based refresh."

---

## 3. CDN (Content Delivery Network)

**Kya hai:** Static content (images, CSS, JS, videos) ko user ke paas edge servers pe serve karo.

| Type | How | When |
|------|-----|------|
| **Push CDN** | Tum upload karo content CDN pe | Known content, small catalogue |
| **Pull CDN** | CDN first request pe origin se fetch karta hai | Large/dynamic catalogue |

**Key Rule:** CDN = Static content (images, videos). Cache = Dynamic/user-specific data (feed, profile).

**Interview mein bolo:** "Images aur videos CDN pe serve honge. Origin se sirf cache miss pe fetch."

---

## 4. Database — SQL vs NoSQL

| | SQL | NoSQL |
|--|-----|-------|
| **Model** | Tables, rows, schema | Document, Key-Value, Wide-Column, Graph |
| **Consistency** | ACID (Strong) | BASE (Eventual) |
| **Scaling** | Vertical mainly, sharding complex | Horizontal, built for scale |
| **Joins** | Yes, powerful | Limited/No |
| **Best For** | Banking, ERP, transactions | Feeds, sessions, high-scale |

### NoSQL Types — Kab Kya Use Karo

| Type | Example | Best For |
|------|---------|----------|
| **Key-Value** | Redis, DynamoDB | Sessions, counters, cache |
| **Document** | MongoDB | Flexible schema, catalogues |
| **Wide-Column** | Cassandra, HBase | High write throughput, time-series |
| **Graph** | Neo4j | Social graphs, recommendations |

### Indexing

| Type | Best For |
|------|----------|
| **B-Tree** | Range queries (WHERE age > 25) |
| **Hash** | Exact match (WHERE id = 123) |

**Decision Rule:**
- Transactions + Joins zaroori? → **SQL**
- High scale + Flexible schema? → **NoSQL**
- Both needed? → **SQL for core, NoSQL for scale-out parts**

**Interview mein bolo:** "User data with transactions → SQL. Feed/timeline at scale → NoSQL. Sessions → Redis."

---

## 5. Database Scaling

| Strategy | When | Trade-off |
|----------|------|-----------|
| **Read Replicas** | Read-heavy | Replication lag (eventual consistency) |
| **Sharding** | Write-heavy, data too big | Cross-shard joins expensive, complexity |
| **Connection Pooling** | Connection exhaustion | Overhead of pool management |

### Sharding Strategies

| Strategy | Pros | Cons |
|----------|------|------|
| **Hash-based** | Even distribution | Range queries hard |
| **Range-based** | Range queries easy | Hotspots possible |
| **Directory-based** | Flexible | Extra lookup, SPOF |

**Scaling Order (simple → complex):**
1. Vertical scaling (bigger machine)
2. Read replicas + Cache
3. Connection pooling
4. Sharding (last resort)

**Interview mein bolo:** "Read-heavy → replicas + cache. Write-heavy → shard by user_id. Consistent hashing for minimal rebalance."

---

## 6. Message Queues

**Kya hai:** Async communication — services decouple karo, buffer bano, reliability dedo.

| Model | How | Use Case |
|-------|-----|----------|
| **Point-to-Point** | One message → one consumer | Task distribution, job processing |
| **Pub/Sub** | One message → many consumers | Event broadcasting, notifications |

| System | Strength | Best For |
|--------|----------|----------|
| **Kafka** | High throughput, replay, ordering | Event streaming, logs |
| **RabbitMQ** | Flexible routing, exchanges | Task queues, background jobs |
| **SQS/SNS** | Managed, serverless | AWS ecosystem |

### Delivery Guarantees

| Guarantee | Meaning |
|-----------|---------|
| **At-most-once** | May lose messages, no retry |
| **At-least-once** | Retry, may duplicate → need idempotency |
| **Exactly-once** | Hardest, requires idempotent consumers |

**Key Concepts:** DLQ (Dead Letter Queue) for failed messages. Idempotency key for safe retries.

**Rule:** "Async when you can, Sync when you must."

**Interview mein bolo:** "Async processing Kafka/RabbitMQ se. DLQ for failures. Idempotent consumers for at-least-once."

---

## 7. CAP Theorem

**One line:** Network partition mein C (Consistency) ya A (Availability) — dono nahi mil sakte.

| During Partition | Choice | Example |
|------------------|--------|---------|
| **CP** | Block/refuse, consistency first | Banking, ZooKeeper, HBase |
| **AP** | Serve, may be stale | Social feed, Cassandra, DynamoDB |

**PACELC (Extended CAP):**
- Partition → C ya A
- Else (no partition) → Latency ya Consistency

**Consistency Models:**

| Model | Meaning | Use |
|-------|---------|-----|
| **Strong** | Latest write always visible | Banking, payments |
| **Eventual** | Eventually consistent, temporary stale OK | Feeds, counters |
| **Causal** | Cause-effect order maintained | Chat messages |

**Interview mein bolo:** "P is always there. So C vs A. Banking = CP. Social feed = AP with eventual consistency."

---

## 8. Availability & Reliability

| Nines | Downtime/Year | Example |
|-------|--------------|---------|
| 99% (2 nines) | 3.65 days | Internal tools |
| 99.9% (3 nines) | 8.76 hours | Most SaaS |
| 99.99% (4 nines) | 52.6 min | Major cloud services |
| 99.999% (5 nines) | 5.26 min | Payment systems |

| Term | Meaning |
|------|---------|
| **SLA** | Contract (promise to customer) |
| **SLO** | Target (internal goal) |
| **SLI** | Measurement (actual metric) |
| **RPO** | Recovery Point Objective — kitna data loss OK? |
| **RTO** | Recovery Time Objective — kitne time mein recover? |

**Formulas:**
- Series: A_total = A1 × A2 (weakest link dominates)
- Parallel: A_total = 1 - (1-A1)(1-A2) (redundancy helps)

**Key Strategies:** Redundancy (N+1), Failover (Active-Active/Active-Passive), Health Checks, No SPOF

**Interview mein bolo:** "99.9% target. Multiple replicas. No single point of failure. Active-passive failover."

---

## 9. API Design

| Style | Best For | Key Feature |
|-------|----------|-------------|
| **REST** | CRUD, public APIs | Resource-based, HTTP verbs, stateless |
| **GraphQL** | Flexible queries, mobile | Client decides what data, single endpoint |
| **gRPC** | Internal microservices | Protobuf, HTTP/2, streaming, fast |

**REST Best Practices:**
- Resource nouns: `/users`, `/tweets` (not `/getUser`)
- HTTP verbs: GET, POST, PUT, DELETE
- Status codes: 200 OK, 201 Created, 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, 429 Rate Limited, 500 Server Error
- Pagination: cursor-based > offset-based for large datasets
- Versioning: `/api/v1/users`

**Interview mein bolo:** "REST for public API. gRPC for internal service-to-service. GraphQL agar client ko flexible queries chahiye."

---

## 10. Resilience Patterns

| Pattern | Kya Karta Hai | Kab Use Karo |
|---------|---------------|--------------|
| **Circuit Breaker** | Fail fast when downstream unhealthy | Microservice calls |
| **Retry + Backoff** | Exponential backoff with jitter | Transient failures |
| **Rate Limiting** | Requests ko limit karo | API abuse protection |
| **Bulkhead** | Isolate failures, ek failure doosre ko na mare | Service isolation |
| **Idempotency** | Same request = same result (safe retry) | Payments, writes |
| **Graceful Degradation** | Features flag off, fallback dedo | System overload |

**Rate Limiting Algorithms:**

| Algorithm | How |
|-----------|-----|
| **Token Bucket** | Tokens fill at rate R, each request takes 1 token |
| **Sliding Window** | Count requests in sliding time window |
| **Fixed Window** | Count per fixed interval (boundary burst issue) |

**Circuit Breaker States:** Closed (normal) → Open (failing, reject fast) → Half-Open (test) → Closed

**Interview mein bolo:** "Circuit breaker for downstream failures. Retry with exponential backoff. Idempotency key for payments."

---

## 11. Microservices vs Monolith

| | Monolith | Microservices |
|--|----------|---------------|
| **Deploy** | All at once | Per service |
| **Scale** | Whole app | Per service |
| **DB** | Shared | DB per service |
| **Complexity** | Code complex | Infra complex |
| **Start** | Quick MVP | When scale/team grows |

**Key Microservices Components:**
- **API Gateway:** Single entry point, routing, auth, rate limiting
- **Service Discovery:** Consul, Eureka, K8s DNS
- **Service Mesh:** Istio — observability, security, traffic management
- **Saga Pattern:** Distributed transactions across services

**Rule:** "Start monolith. Split into microservices when team grows ya scaling chahiye."

---

## 12. Monitoring & Observability

**Three Pillars:**

| Pillar | Tool | Use |
|--------|------|-----|
| **Logs** | ELK Stack | Debugging, errors |
| **Metrics** | Prometheus + Grafana | Dashboards, alerts |
| **Traces** | Jaeger, Zipkin | Request flow across services |

**Four Golden Signals (Google SRE):**

| Signal | What to Monitor |
|--------|----------------|
| **Latency** | p50, p95, p99 response time |
| **Traffic** | Requests per second (RPS) |
| **Errors** | 5xx rate, failed requests |
| **Saturation** | CPU usage, memory, queue depth |

---

## 13. Security Basics (Quick Mention)

| Concept | One-liner |
|---------|-----------|
| **AuthN** | Who are you? (login, tokens) |
| **AuthZ** | What can you do? (permissions) |
| **OAuth 2.0** | Delegated auth (Google login) |
| **JWT** | Stateless token for auth |
| **HTTPS** | Encrypt data in transit |
| **Rate Limiting** | Prevent abuse/DDoS |
| **bcrypt** | Password hashing (never store plaintext!) |

---

# PART 3: TOP 10 SYSTEM DESIGNS — Interview-Ready Templates

---

## Design 1: URL Shortener (bit.ly)

**Core:** Long URL → Short Code → Redirect

| Aspect | Detail |
|--------|--------|
| **Scale** | 100M URLs/day, 10:1 read:write |
| **Write QPS** | ~1,200/s |
| **Read QPS** | ~12,000/s |
| **Storage (5yr)** | ~100 TB |

**Requirements:**
- Shorten URL, redirect, custom alias, expiry, analytics

**Key Design Decisions:**

| Decision | Choice | Why |
|----------|--------|-----|
| **Short Code** | Base62 encode (a-z, A-Z, 0-9) | 6 chars = 62^6 ≈ 56B combinations |
| **Key Generation** | Counter/Snowflake → Base62 | No collisions, unique |
| **Redirect** | 302 (temporary) not 301 | 301 = browser caches, no analytics |
| **DB** | SQL (MySQL/Postgres) | Simple key-value, ACID |
| **Cache** | Redis for hot URLs | Read-heavy, top 20% URLs |

**Architecture:**
```
Client → LB → App Server → Redis Cache → DB (MySQL)
                  ↓
          Analytics Queue (Kafka) → Analytics Service
```

**Write Flow:** Client → App → Generate base62 code → Store in DB → Return short URL
**Read Flow:** Client → App → Check Redis → If miss, DB → 302 Redirect → Log click async

**Trade-offs:**
- Counter vs Hash: Counter = no collision but predictable. Hash = random but collision possible
- 301 vs 302: 301 = fast (cached) but no analytics. 302 = trackable

**Interview mein bolo:** "Base62 from counter for unique codes. Redis cache for reads. 302 for analytics tracking."

---

## Design 2: Twitter/Instagram Feed

**Core:** Post → Fan-out → Feed Display

| Aspect | Detail |
|--------|--------|
| **Scale** | 500M DAU, 100:1 read:write |
| **Read QPS** | ~2.8M/s |
| **Write QPS** | ~28K/s |

**Key Design Decisions:**

| Decision | Choice | Why |
|----------|--------|-----|
| **Fan-out** | Hybrid (Push + Pull) | Push for normal users, Pull for celebrities |
| **Feed Storage** | Pre-computed feed in Redis | Fast reads |
| **Media** | S3 + CDN | Images/videos edge pe serve |
| **DB** | SQL for users, NoSQL for tweets/feed | Best of both |
| **Ranking** | Engagement + Recency | Not just chronological |

**Fan-out Problem — THE key challenge:**

| Type | How | When |
|------|-----|------|
| **Fan-out on Write (Push)** | Tweet → immediately write to all followers' feeds | User has < 500 followers |
| **Fan-out on Read (Pull)** | Feed request → fetch from followed users | Celebrity (10M+ followers) |
| **Hybrid** | Push for normal, Pull for celebrities | Production (Twitter does this) |

**Architecture:**
```
Post Tweet:
  Client → App → Tweet DB → Fan-out Service → Redis (followers' feeds)
                                    ↓
                         Media → S3 → CDN

Read Feed:
  Client → App → Redis (pre-computed feed) → Merge celebrity tweets on-read → Return
```

**Interview mein bolo:** "Hybrid fan-out. Push for <500 followers, Pull for celebrities. Feed pre-computed in Redis. Media on CDN."

---

## Design 3: WhatsApp / Chat System

**Core:** Real-time messaging with delivery guarantees

| Aspect | Detail |
|--------|--------|
| **Scale** | 2B DAU, 100B messages/day |
| **Message QPS** | ~1.15M/s, peak ~3.5M/s |
| **Concurrent connections** | ~1B WebSocket connections |

**Key Design Decisions:**

| Decision | Choice | Why |
|----------|--------|-----|
| **Protocol** | WebSocket | Full-duplex, real-time |
| **Delivery** | At-least-once + Idempotency | No message loss, handle duplicates |
| **Ordering** | Per-conversation sequence number | Messages in correct order |
| **Offline** | Store in DB, push notification, deliver on reconnect | User may be offline |
| **Receipts** | Sent → Delivered → Read (ack-based) | WhatsApp-style ticks |
| **DB** | Cassandra (messages), SQL (users) | High write throughput |

**Architecture:**
```
Sender → WebSocket → Chat Server → Message Queue
                                        ↓
                              If online: → Receiver's Chat Server → WebSocket → Receiver
                              If offline: → Store in DB + Push Notification (FCM/APNS)
                              
Receipts:
  Receiver ack → Chat Server → Update status → Notify sender
```

**Presence (Online/Offline):**
- Heartbeat every 30 sec
- No heartbeat for 60 sec → mark offline
- Store in Redis (fast read/write)

**Group Chat:**
- Message → Fan-out to all group members (max 256)
- Small fan-out, so push model works

**Interview mein bolo:** "WebSocket for real-time. Cassandra for messages (high write). At-least-once delivery. Heartbeat for presence."

---

## Design 4: YouTube / Netflix (Video Streaming)

**Core:** Upload → Transcode → Store → Stream via CDN

| Aspect | Detail |
|--------|--------|
| **Scale** | 2B users, 10B views/day |
| **Upload** | ~500K videos/day |
| **Storage** | Petabytes (video is huge) |

**Key Design Decisions:**

| Decision | Choice | Why |
|----------|--------|-----|
| **Upload** | Chunked upload (multipart) | Resume on failure, large files |
| **Transcode** | Multiple resolutions (360p → 4K) | Device variety |
| **Storage** | S3/Object Storage | Cheap, scalable, durable |
| **Delivery** | CDN (CloudFront, Akamai) | Low latency, edge servers |
| **Streaming** | HLS / DASH (Adaptive Bitrate) | Quality adjust based on bandwidth |
| **Processing** | Async via queue | Don't block upload response |

**Architecture:**
```
Upload Flow:
  Client → Upload Service → Object Storage (raw) → Transcoding Queue
      → Transcoding Workers (FFmpeg) → Multiple formats → Object Storage (processed) → CDN

Watch Flow:
  Client → CDN (edge) → If miss → Origin (Object Storage)
  Client uses adaptive bitrate → switches quality based on network
```

**Recommendations:** Collaborative filtering + Content-based. Precompute and cache.

**Interview mein bolo:** "Chunked upload. Async transcoding to multiple resolutions. CDN for delivery. Adaptive bitrate streaming."

---

## Design 5: Uber / Ride-Sharing

**Core:** Rider request → Match nearby driver → Real-time tracking

| Aspect | Detail |
|--------|--------|
| **Scale** | 20M trips/day, 15M active drivers |
| **Location updates** | ~3.75M updates/sec (drivers every 4 sec) |

**Key Design Decisions:**

| Decision | Choice | Why |
|----------|--------|-----|
| **Nearby Search** | Geohash / QuadTree | Efficient spatial indexing |
| **Real-time** | WebSocket for location updates | Low latency, bidirectional |
| **Matching** | Nearest available driver algorithm | Minimize wait time |
| **Location Store** | Redis (current location) | Fast read/write, in-memory |
| **Trip Data** | SQL (trip history, payments) | ACID for financial data |
| **Surge Pricing** | Supply/Demand ratio per geohash zone | Dynamic pricing |

**Architecture:**
```
Driver Location Updates:
  Driver App → WebSocket → Location Service → Redis (geohash → driver list)

Ride Request:
  Rider → Ride Service → Query Redis (nearby drivers by geohash)
    → Matching Service → Notify driver → Driver accepts
    → Trip created → Real-time tracking starts

ETA: Google Maps API / internal routing service
```

**Geohash Explained:**
- Lat/Long → encode into string like "9q8yyk"
- Same prefix = nearby (prefix match for nearby search)
- Precision levels: 6 chars ≈ 1.2km × 600m

**Interview mein bolo:** "Geohash for spatial index. Redis for real-time driver locations. WebSocket for live tracking. Surge = demand/supply ratio."

---

## Design 6: Notification System

**Core:** Send push/SMS/email to millions of devices

| Aspect | Detail |
|--------|--------|
| **Scale** | ~10B notifications/day |
| **Types** | Push (FCM/APNS), SMS, Email, In-app |

**Architecture:**
```
Trigger (event/scheduled) → Notification Service → Message Queue
    → Push Worker → FCM/APNS → Device
    → SMS Worker → Twilio → Phone
    → Email Worker → SendGrid → Inbox
```

**Key Design Points:**
- **Queue-based:** Decouple trigger from delivery
- **Fan-out:** One event → many users' devices
- **Rate limit:** Per user, per channel (don't spam)
- **Template engine:** Personalized messages
- **Retry + DLQ:** Failed deliveries retry, then DLQ
- **User preferences:** Opt-in/opt-out per channel

**Interview mein bolo:** "Queue-based async delivery. FCM/APNS for push. Rate limit per user. Retry with DLQ."

---

## Design 7: Rate Limiter

**Core:** Limit API requests per user/IP to prevent abuse

| Algorithm | How | Pros | Cons |
|-----------|-----|------|------|
| **Token Bucket** | Tokens fill at rate R. Each request = 1 token. Empty = reject | Allows burst | Memory per user |
| **Sliding Window Log** | Store timestamps, count in window | Accurate | Memory heavy |
| **Sliding Window Counter** | Approximate: weighted current + previous window | Low memory | Approximate |
| **Fixed Window** | Count per interval | Simple | Boundary burst |

**Architecture:**
```
Client → API Gateway → Rate Limiter (Redis counter) → App Server
                              ↓
                  429 Too Many Requests + Retry-After header
```

**Distributed Rate Limiting:** Redis for shared counter across multiple servers

**Interview mein bolo:** "Token bucket at API Gateway. Redis for distributed counter. 429 + Retry-After header."

---

## Design 8: Distributed Cache (Redis-like)

**Core:** In-memory key-value store, distributed across nodes

| Aspect | Detail |
|--------|--------|
| **Operations** | GET, SET, DELETE with TTL |
| **Sharding** | Consistent hashing |
| **Replication** | Each key on N nodes |
| **Eviction** | LRU (default), LFU, TTL |

**Architecture:**
```
Client → Cache Client (consistent hash) → Correct shard node
    → If key found → return
    → If miss → fetch from DB → populate cache → return
```

**Key Design:**
- Consistent hashing: Add/remove node → only 1/N keys move
- Replication: Each key stored on N consecutive nodes in hash ring
- Cache stampede: Locking or probabilistic early refresh

**Interview mein bolo:** "Consistent hashing for sharding. Replication factor N for HA. LRU eviction. Lock for stampede."

---

## Design 9: Google Docs (Real-time Collaboration)

**Core:** Multiple users editing same document simultaneously

| Challenge | Solution |
|-----------|----------|
| **Concurrent edits** | OT (Operational Transform) or CRDT |
| **Conflict resolution** | Server resolves with OT; CRDT is conflict-free |
| **Real-time sync** | WebSocket for live updates |
| **Cursor presence** | Broadcast cursor position to all editors |
| **Version history** | Store every change, allow rollback |

**Architecture:**
```
User A edits → WebSocket → Collaboration Server (OT engine)
    → Transform & merge → Broadcast to User B, C via WebSocket
    → Persist to Document DB (versioned)
```

**OT vs CRDT:**

| | OT | CRDT |
|--|-----|------|
| **Server** | Needs central server | Can work P2P |
| **Complexity** | Complex transforms | Complex data structures |
| **Used by** | Google Docs | Figma, some editors |

**Interview mein bolo:** "WebSocket for real-time. OT for conflict resolution (Google's approach). Version history for rollback."

---

## Design 10: Payment System

**Core:** Process money safely — NEVER double charge

| Principle | Why Critical |
|-----------|-------------|
| **Idempotency** | Same request = same result. Network retry must not double charge |
| **ACID** | Transactions must be atomic |
| **Security** | PCI compliance, don't store card numbers |

**Architecture:**
```
Client → Payment Service → Payment Gateway (Stripe/PayPal)
    → Auth (verify card) → Capture (charge)
    → Webhook callback → Update order status
    
Idempotency:
    Every request has idempotency_key
    Same key = return cached response (no re-charge)
```

**Key Design:**
- Two-phase: Authorize first → Capture later (e-commerce pattern)
- Idempotency key in every request
- Gateway handles PCI (you never see card numbers)
- Retry safe: Idempotent operations
- Reconciliation: Async job matches internal records with gateway records

**Interview mein bolo:** "Idempotency key for every payment. Two-phase auth+capture. Gateway for PCI. Reconciliation for consistency."

---

# PART 4: DECISION TREES & CHEAT SHEETS

---

## When to Use What — Quick Decision Guide

```
Need to scale reads?
├── Cache (Redis) + Read Replicas
└── CDN (for static content)

Need to scale writes?
├── Sharding (by user_id / entity_id)
└── Message Queue (async processing)

Need real-time?
├── WebSocket (bidirectional)
├── SSE (server → client only)
└── Long Polling (fallback)

Need consistency?
├── Strong → SQL (single master)
├── Eventual OK → NoSQL / Replicas
└── Causal → Vector clocks

Need to decouple?
├── Message Queue (Kafka / RabbitMQ)
└── Event-driven architecture

Need search?
├── Full-text → Elasticsearch (inverted index)
└── Geospatial → Geohash / QuadTree

Need to store?
├── Structured + ACID → SQL (Postgres/MySQL)
├── Flexible schema → MongoDB
├── High write → Cassandra
├── Key-Value → Redis/DynamoDB
├── Files/Media → S3 + CDN
└── Graph → Neo4j
```

---

## Component Selection Quick Table

| Need | Use This |
|------|----------|
| Scale reads | Replicas + Cache |
| Scale writes | Sharding |
| Reduce latency | Cache + CDN |
| Decouple services | Message Queue |
| Static content | CDN |
| Hot data | Redis |
| Async processing | Kafka / RabbitMQ |
| Strong consistency | SQL |
| Eventual OK | NoSQL + Replicas |
| Real-time | WebSocket |
| Search | Elasticsearch |
| Geospatial | Geohash / QuadTree |
| File storage | S3 / Object Storage |
| Unique IDs | Snowflake / UUID |

---

## One-Liner Per Design (Ultra Quick)

| Design | One-Liner | Key Challenge |
|--------|-----------|---------------|
| **URL Shortener** | Hash + Cache + Redirect | Unique key generation at scale |
| **Twitter Feed** | Fan-out + CDN + Ranking | Celebrity fan-out problem |
| **WhatsApp** | WebSocket + Queue + Presence | Real-time at 2B users |
| **YouTube** | Upload + Transcode + CDN | Video processing pipeline |
| **Uber** | Geohash + Real-time + Matching | Location updates at 3.75M/s |
| **Notification** | Push + Queue + Fan-out | Multi-channel delivery at scale |
| **Rate Limiter** | Token Bucket + Redis | Distributed counting |
| **Dist. Cache** | Consistent Hash + Replication | Stampede, invalidation |
| **Google Docs** | WebSocket + OT/CRDT | Concurrent edit conflicts |
| **Payment** | Idempotency + Gateway | Never double charge |

---

## Master Formula Card

| What | Formula |
|------|---------|
| **Average QPS** | DAU × req_per_user / 86,400 |
| **Peak QPS** | Avg QPS × 2 to 5 |
| **Storage** | Users × data_per_user × days × replication |
| **Bandwidth** | QPS × response_size |
| **Servers** | Peak QPS / QPS_per_server × 1.3 |
| **Availability (series)** | A1 × A2 × A3 |
| **Availability (parallel)** | 1 - (1-A1)(1-A2) |
| **Shards needed** | Total_data / Shard_capacity |
| **Cache hit ratio** | Hits / (Hits + Misses) |
| **Fan-out on write** | OK if followers < 500 |
| **Base62 (6 chars)** | 62^6 ≈ 56 Billion combinations |

---

# PART 5: INTERVIEW TIPS & COMMON MISTAKES

---

## TOP 10 Interview Mistakes (Avoid These!)

| # | Mistake | Fix |
|---|---------|-----|
| 1 | **Seedha design shuru** (no requirements) | ALWAYS 5 min requirements first |
| 2 | **No numbers** | ALWAYS estimate QPS, storage |
| 3 | **Over-engineering** ("Kafka, K8s, 50 services") | Start simple, add when needed |
| 4 | **No trade-offs** ("Use cache") | "Cache for latency, trade-off: stale data" |
| 5 | **Silent coding** | Think aloud, explain everything |
| 6 | **No data model** | Always mention key tables/schemas |
| 7 | **Forgot failure handling** | "What if DB fails? → Replicas" |
| 8 | **Try to do everything** | "MVP is X, we can add Y later" |
| 9 | **Can't go deep** | Pick 1-2 areas, go really deep |
| 10 | **Defensive when wrong** | Accept feedback, adapt gracefully |

---

## GREEN FLAGS (What Gets You Hired)

| Signal | Interviewer Thinks |
|--------|-------------------|
| Requirements first | "Thinks before coding" |
| Clear communication | "Can explain well" |
| Trade-off awareness | "Understands real-world" |
| Handles "what-if" | "Production-ready thinking" |
| Adapts to feedback | "Collaborative" |
| Simple first, then scale | "Pragmatic engineer" |
| Mentions monitoring | "Thinks about ops" |
| Depth when probed | "Has solid fundamentals" |

---

## RED FLAGS (What Gets You Rejected)

| Signal | Interviewer Thinks |
|--------|-------------------|
| Jumps to solution | "Can't scope problems" |
| No estimation | "Doesn't think about scale" |
| No trade-offs | "Textbook knowledge only" |
| Can't handle curveballs | "Rigid, can't adapt" |
| Silent/mumbling | "Can't work with team" |
| Over-complicated | "Lacks engineering judgment" |
| Defensive | "Won't accept feedback" |
| Incomplete design | "Missing critical thinking" |

---

## Phrases to Use in Interview

### Starting
> "Let me clarify the requirements first..."
> "What's the expected scale? DAU? Read:Write ratio?"
> "Let me do a quick back-of-envelope estimation..."

### During Design
> "I'll draw the main components and data flow..."
> "For the database, I'm choosing SQL because we need ACID transactions..."
> "The trade-off here is latency vs consistency..."
> "Let me discuss the bottleneck..."

### Check-ins
> "Does this direction make sense?"
> "Should I go deeper here or move to scaling?"
> "Would you like me to explore the failure scenarios?"

### Trade-offs
> "We're choosing X because Y. The trade-off is Z."
> "Alternative would be A, but it has drawback B."
> "If we scale 10x, the bottleneck would be X; we'd address it by Y."

### Wrap-up
> "For monitoring, we'd track latency p99, error rate, cache hit ratio."
> "For security: HTTPS, auth tokens, rate limiting, input validation."
> "Future improvements: CDN, event sourcing, multi-region."

---

# PART 6: LAST-MINUTE CHECKLIST

---

## 1-Hour Before Interview — Yeh Padho

- [ ] 4-step framework yaad hai (Requirements → Estimation → Design → Deep Dive)
- [ ] QPS formula: DAU × req / 86,400
- [ ] Power of 2: 2^10=1K, 2^20=1M, 2^30=1G, 2^40=1T
- [ ] Latency: RAM=100ns, SSD=100μs, Network=0.5ms
- [ ] CAP: Partition → C ya A. Banking=CP, Feed=AP
- [ ] SQL vs NoSQL: ACID+joins=SQL, Scale+flex=NoSQL
- [ ] Cache: Cache-Aside, LRU, TTL, Stampede
- [ ] Scaling: Reads=Replicas, Writes=Sharding
- [ ] 2-3 designs ready (URL Shortener, Twitter, WhatsApp)

## 5-Min Before Interview — Yeh Yaad Rakho

1. **Breathe** — calm raho, panic mat karo
2. **Requirements FIRST** — seedha design mat shuru karo
3. **Numbers bolo** — QPS, Storage, always estimate
4. **Trade-offs bolo** — "We chose X because Y, trade-off is Z"
5. **Think aloud** — silent mat raho, sochte hue bolo
6. **Simple first** — monolith → microservices when needed
7. **Failure handle karo** — "What if X fails?"
8. **Check-in karo** — "Does this make sense?"

---

## Study Priority (Agar Time Kam Hai)

### Priority 1 — MUST KNOW (2-3 din mein padho)
1. Interview Framework (4-step approach)
2. Back-of-Envelope estimation
3. Caching + CDN
4. Database (SQL vs NoSQL) + Scaling
5. Load Balancing
6. CAP Theorem

### Priority 2 — SHOULD KNOW (1 week mein add karo)
7. Message Queues
8. Microservices basics
9. Resilience Patterns (Circuit breaker, Rate limiting)
10. API Design (REST, gRPC)

### Priority 3 — GOOD TO KNOW (extra time ho toh)
11. Distributed Systems (Consensus, Leader election)
12. Security basics
13. Monitoring/Observability

### Design Problems — Priority Order
1. **URL Shortener** (easiest, most asked)
2. **Twitter/Instagram Feed** (fan-out, most important concept)
3. **WhatsApp Chat** (real-time, WebSocket)
4. **YouTube/Netflix** (video pipeline)
5. **Uber** (geospatial)
6. Rate Limiter, Notification, Payment (bonus)

---

## Quick Self-Test (Interview Ready?)

| Question | Can You Answer? |
|----------|----------------|
| QPS formula? | DAU × req / 86,400 |
| Read-heavy scaling? | Replicas + Cache |
| Write-heavy scaling? | Sharding |
| CAP during partition? | C or A, not both |
| Cache-Aside flow? | Check cache → miss → DB → populate |
| Fan-out on write? | Pre-compute feed for followers |
| WebSocket vs REST? | WS = real-time bidirectional, REST = request-response |
| 99.9% availability? | 8.76 hours downtime/year |
| Idempotency? | Same request = same result |
| Circuit Breaker? | Fail fast when downstream unhealthy |

**Sab answer aa gaye? Toh tum READY ho! Go crush that interview!**

---

*Created from: SYSTEM-DESIGN-MASTER notes, System Design Fundamentals, and internet research.*
*Language: Hinglish (easy samajh aaye). Focus: Only important, interview-relevant content.*
