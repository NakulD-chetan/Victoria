# SQL Clauses & Filtering — WHERE, ORDER BY, GROUP BY, HAVING

> **Filtering = Data mein se sirf woh rows nikalo jo tumhe chahiye**
> SQL mein filtering bahut powerful hai — WHERE, LIKE, IN, BETWEEN, etc. sab milke kaam karte hain.

---

## Sample Table (Reference)

```
Table: employees
+----+----------+------------+----------+--------+------------+
| id | name     | department | salary   | city   | join_date  |
+----+----------+------------+----------+--------+------------+
| 1  | Rahul    | IT         | 75000.00 | Mumbai | 2022-01-15 |
| 2  | Priya    | HR         | 65000.00 | Delhi  | 2022-03-20 |
| 3  | Amit     | IT         | 80000.00 | Pune   | 2021-06-10 |
| 4  | Sneha    | Finance    | 70000.00 | Mumbai | 2023-01-05 |
| 5  | Karan    | HR         | 55000.00 | Delhi  | 2023-07-18 |
| 6  | Neha     | IT         | 90000.00 | Pune   | 2020-11-22 |
| 7  | Rohan    | Finance    | 72000.00 | Mumbai | 2024-02-01 |
| 8  | Divya    | IT         | 85000.00 | Delhi  | 2024-03-15 |
+----+----------+------------+----------+--------+------------+
```

---

## 1. WHERE Clause — Row-Level Filtering

> **Definition:** WHERE clause filters rows based on a specified condition. Only rows where the condition is TRUE are returned.

```sql
SELECT * FROM employees
WHERE department = 'IT';
```

> Sirf IT department ke employees aayenge.

---

### Comparison Operators:

| Operator | Meaning | Example |
|----------|---------|---------|
| `=` | Equal to | `WHERE city = 'Mumbai'` |
| `!=` or `<>` | Not equal to | `WHERE city != 'Delhi'` |
| `>` | Greater than | `WHERE salary > 70000` |
| `<` | Less than | `WHERE salary < 60000` |
| `>=` | Greater than or equal | `WHERE salary >= 75000` |
| `<=` | Less than or equal | `WHERE salary <= 80000` |

---

### Logical Operators: AND, OR, NOT

```sql
-- AND: Dono conditions TRUE honi chahiye
SELECT * FROM employees
WHERE department = 'IT' AND salary > 80000;
-- Result: Neha (90000), Divya (85000)

-- OR: Koi EK condition TRUE ho toh bhi chalega
SELECT * FROM employees
WHERE city = 'Mumbai' OR city = 'Pune';
-- Result: Rahul, Amit, Sneha, Neha, Rohan

-- NOT: Condition ko ulta kar do
SELECT * FROM employees
WHERE NOT department = 'HR';
-- Result: Sab except Priya and Karan
```

### Operator Precedence:

```
NOT > AND > OR

-- Yeh confusing ho sakta hai:
WHERE department = 'IT' OR department = 'HR' AND salary > 70000

-- SQL ise aise padhega (AND pehle execute hoga):
WHERE department = 'IT' OR (department = 'HR' AND salary > 70000)

-- Agar tum chahte ho dono pe salary condition:
WHERE (department = 'IT' OR department = 'HR') AND salary > 70000
```

> **Tip:** Hamesha **brackets** use karo confusion se bachne ke liye!

---

## 2. LIKE — Pattern Matching

> **Definition:** LIKE operator filters rows based on pattern matching using wildcards.

### Wildcards:

| Wildcard | Meaning | Example |
|----------|---------|---------|
| `%` | Zero ya zyada characters | `'R%'` → R se shuru hone wale |
| `_` | Exactly ek character | `'_mit'` → 4 letter, mit pe end |

### Examples:

```sql
-- Naam 'R' se shuru hota hai
SELECT * FROM employees WHERE name LIKE 'R%';
-- Result: Rahul, Rohan

-- Naam 'a' pe khatam hota hai
SELECT * FROM employees WHERE name LIKE '%a';
-- Result: Priya, Sneha, Neha, Divya

-- Naam mein 'it' kahin bhi hai
SELECT * FROM employees WHERE name LIKE '%it%';
-- Result: Amit

-- Naam exactly 5 letters ka hai
SELECT * FROM employees WHERE name LIKE '_____';
-- Result: Rahul, Priya, Sneha, Karan, Rohan, Divya

-- NOT LIKE: Pattern match NAHI karna
SELECT * FROM employees WHERE name NOT LIKE 'R%';
```

> **Interview Tip:** LIKE case-sensitive hota hai kuch databases mein (PostgreSQL), aur case-insensitive MySQL mein (default). `ILIKE` use karo PostgreSQL mein case-insensitive ke liye.

---

## 3. IN — Multiple Values Check

> **Definition:** IN operator checks if a value matches ANY value in a list.

```sql
-- Yeh:
SELECT * FROM employees
WHERE city IN ('Mumbai', 'Delhi', 'Pune');

-- Iske barabar hai:
SELECT * FROM employees
WHERE city = 'Mumbai' OR city = 'Delhi' OR city = 'Pune';
```

> **IN bahut cleaner hai** multiple OR conditions se!

### NOT IN:

```sql
SELECT * FROM employees
WHERE department NOT IN ('HR', 'Finance');
-- Result: Sirf IT wale
```

### IN with Subquery:

```sql
SELECT * FROM employees
WHERE department IN (
    SELECT department FROM employees WHERE salary > 80000
);
```

> **Warning:** Agar subquery mein NULL aata hai, toh NOT IN unexpected results de sakta hai!

---

## 4. BETWEEN — Range Check

> **Definition:** BETWEEN checks if a value is within a range (inclusive of both ends).

```sql
-- Salary 65000 se 80000 ke beech (inclusive)
SELECT * FROM employees
WHERE salary BETWEEN 65000 AND 80000;
-- Result: Rahul(75K), Priya(65K), Amit(80K), Sneha(70K), Rohan(72K)

-- Date range
SELECT * FROM employees
WHERE join_date BETWEEN '2022-01-01' AND '2023-12-31';
```

> **BETWEEN is INCLUSIVE:** `BETWEEN 65000 AND 80000` means `>= 65000 AND <= 80000`

### NOT BETWEEN:

```sql
SELECT * FROM employees
WHERE salary NOT BETWEEN 65000 AND 80000;
-- Result: Karan(55K), Neha(90K), Divya(85K)
```

---

## 5. IS NULL / IS NOT NULL

> **Definition:** IS NULL checks for NULL values. Remember: NULL means "unknown", not zero or empty string.

```sql
-- NULL department wale employees
SELECT * FROM employees WHERE department IS NULL;

-- Non-NULL department wale
SELECT * FROM employees WHERE department IS NOT NULL;
```

> **Phir se yaad dilata hoon:** `WHERE department = NULL` **KAAM NAHI KAREGA!** Hamesha `IS NULL` use karo.

---

## 6. ORDER BY — Results Sort Karo

> **Definition:** ORDER BY sorts the result set by one or more columns in ascending (ASC) or descending (DESC) order.

```sql
-- Salary se sort (chhote se bade — default ASC)
SELECT * FROM employees ORDER BY salary;

-- Salary se sort (bade se chhote)
SELECT * FROM employees ORDER BY salary DESC;

-- Multiple column sort: pehle department, phir salary descending
SELECT * FROM employees
ORDER BY department ASC, salary DESC;
```

```
Result of ORDER BY department ASC, salary DESC:
+----+----------+------------+----------+
| id | name     | department | salary   |
+----+----------+------------+----------+
| 4  | Sneha    | Finance    | 70000.00 |  ← Finance, highest salary first
| 7  | Rohan    | Finance    | 72000.00 |
| 2  | Priya    | HR         | 65000.00 |  ← HR group
| 5  | Karan    | HR         | 55000.00 |
| 6  | Neha     | IT         | 90000.00 |  ← IT, highest salary first
| 8  | Divya    | IT         | 85000.00 |
| 3  | Amit     | IT         | 80000.00 |
| 1  | Rahul    | IT         | 75000.00 |
+----+----------+------------+----------+
```

### ORDER BY Column Position:

```sql
-- Column number se bhi sort kar sakte ho
SELECT name, department, salary FROM employees
ORDER BY 3 DESC;  -- 3rd column = salary
```

> **Note:** Column number use karna readable nahi hai — avoid in production code.

---

## 7. GROUP BY — Data Ko Groups Mein Baanto

> **Deep dive (how it works + how to think + traps):** [[14-Deep-GROUP-BY]]

> **Definition:** GROUP BY groups rows with same values into summary rows. Used with aggregate functions (COUNT, SUM, AVG, etc.)

```sql
-- Har department mein kitne employees hain?
SELECT department, COUNT(*) AS employee_count
FROM employees
GROUP BY department;
```

```
+------------+----------------+
| department | employee_count |
+------------+----------------+
| IT         | 4              |
| HR         | 2              |
| Finance    | 2              |
+------------+----------------+
```

### Multiple Column GROUP BY:

```sql
-- Department + City wise count
SELECT department, city, COUNT(*) AS cnt
FROM employees
GROUP BY department, city;
```

```
+------------+--------+-----+
| department | city   | cnt |
+------------+--------+-----+
| IT         | Mumbai | 1   |
| IT         | Pune   | 2   |
| IT         | Delhi  | 1   |
| HR         | Delhi  | 2   |
| Finance    | Mumbai | 2   |
+------------+--------+-----+
```

> **Rule:** SELECT mein jo bhi column hai (aggregate ke alawa), woh GROUP BY mein hona CHAHIYE!

```sql
-- ❌ WRONG: name GROUP BY mein nahi hai
SELECT name, department, COUNT(*) FROM employees GROUP BY department;

-- ✅ CORRECT:
SELECT department, COUNT(*) FROM employees GROUP BY department;
```

---

## 8. HAVING — Groups Ko Filter Karo

> **Definition:** HAVING filters groups AFTER GROUP BY, just like WHERE filters rows BEFORE GROUP BY.

```sql
-- Woh departments jahan 2 se zyada employees hain
SELECT department, COUNT(*) AS cnt
FROM employees
GROUP BY department
HAVING COUNT(*) > 2;
```

```
+------------+-----+
| department | cnt |
+------------+-----+
| IT         | 4   |
+------------+-----+
```

---

### WHERE vs HAVING — MUST KNOW!

> **Interview mein TOP 5 question hai yeh!**

| Feature | WHERE | HAVING |
|---------|-------|--------|
| **Kab filter karta hai** | **BEFORE** GROUP BY | **AFTER** GROUP BY |
| **Kis pe kaam karta hai** | Individual **rows** | **Groups** |
| **Aggregate functions** | ❌ Use nahi kar sakte | ✅ Use kar sakte ho |
| **Bina GROUP BY** | ✅ Kaam karta hai | ❌ Meaning nahi hai |

```sql
-- WHERE: Pehle IT employees nikalo, PHIR group karo
SELECT city, COUNT(*) AS cnt
FROM employees
WHERE department = 'IT'
GROUP BY city;

-- HAVING: Pehle group karo, PHIR filter karo
SELECT department, AVG(salary) AS avg_sal
FROM employees
GROUP BY department
HAVING AVG(salary) > 70000;
```

### WHERE + HAVING Together:

```sql
-- Step 1: WHERE se Mumbai/Delhi filter
-- Step 2: GROUP BY se department wise group
-- Step 3: HAVING se count > 1 filter
SELECT department, COUNT(*) AS cnt
FROM employees
WHERE city IN ('Mumbai', 'Delhi')
GROUP BY department
HAVING COUNT(*) > 1;
```

---

## 9. SQL Execution Order — SABSE IMPORTANT!

> **Interview mein yeh question 90% aata hai!**
> Hum SQL likhte ek order mein hain, but execute hota **doosre order** mein:

```
LIKHNE KA ORDER:              EXECUTE HONE KA ORDER:

SELECT   ←─── 5th             1. FROM / JOIN    ← Pehle tables lo
FROM     ←─── 1st             2. WHERE          ← Rows filter karo
WHERE    ←─── 2nd             3. GROUP BY       ← Groups banao
GROUP BY ←─── 3rd             4. HAVING         ← Groups filter karo
HAVING   ←─── 4th             5. SELECT         ← Columns choose karo
ORDER BY ←─── 6th             6. DISTINCT       ← Duplicates hatao
LIMIT    ←─── 7th             7. ORDER BY       ← Sort karo
                               8. LIMIT/OFFSET   ← Rows count limit karo
```

### Isko samjho example se:

```sql
SELECT department, AVG(salary) AS avg_sal    -- Step 5: Columns select
FROM employees                                -- Step 1: Table choose
WHERE city != 'Pune'                          -- Step 2: Pune hatao
GROUP BY department                           -- Step 3: Department wise group
HAVING AVG(salary) > 65000                    -- Step 4: Groups filter
ORDER BY avg_sal DESC                         -- Step 6: Sort by avg_sal
LIMIT 2;                                      -- Step 7: Top 2 lo
```

### Kyu Important Hai Execution Order?

```sql
-- ❌ WRONG: WHERE mein alias use nahi kar sakte (alias Step 5 pe banta hai)
SELECT salary * 12 AS annual_sal FROM employees
WHERE annual_sal > 800000;  -- ERROR! alias abhi exist nahi karta

-- ✅ CORRECT: Expression repeat karo WHERE mein
SELECT salary * 12 AS annual_sal FROM employees
WHERE salary * 12 > 800000;

-- ✅ OR: Subquery / CTE use karo
SELECT * FROM (
    SELECT name, salary * 12 AS annual_sal FROM employees
) AS temp
WHERE annual_sal > 800000;
```

> **Isliye HAVING mein aggregate use kar sakte ho** (woh GROUP BY ke baad execute hota hai)
> **but WHERE mein aggregate use nahi kar sakte** (woh GROUP BY ke pehle execute hota hai)

---

## Quick Cheatsheet

```
WHERE     → Row filter (before grouping)     → WHERE salary > 50000
HAVING    → Group filter (after grouping)    → HAVING COUNT(*) > 2
LIKE      → Pattern match                    → WHERE name LIKE 'R%'
IN        → Match from list                  → WHERE city IN ('Mumbai', 'Delhi')
BETWEEN   → Range (inclusive)                → WHERE salary BETWEEN 50K AND 80K
IS NULL   → Check for NULL                   → WHERE dept IS NULL
ORDER BY  → Sort results                     → ORDER BY salary DESC
GROUP BY  → Create groups                    → GROUP BY department
LIMIT     → Restrict row count               → LIMIT 10 OFFSET 20
```

> **Yaad Rakho Execution Order:** **F-W-G-H-S-D-O-L**
> **Trick:** "**F**rom **W**here I **G**ot **H**ere, **S**he **D**oesn't **O**ften **L**augh"

---

*Notes Source: SQL Clauses & Filtering + Interview preparation material*
