# Monitoring and Observability — Tricks and Recognition

> **Permanent Recall:** **Always** add monitoring to your design. Quick stack: Prometheus + Grafana + ELK + Jaeger. The "5-minute monitoring pitch" for interviews. Key metrics for common systems. Alerting threshold heuristics.

---

## When to Add Monitoring to Your Design

**Answer: ALWAYS.**

| System Type | Monitoring Emphasis |
|-------------|---------------------|
| **API / microservices** | RED, traces, 4 golden signals |
| **Database** | USE, query latency, connection pool |
| **Cache** | Hit rate, eviction, memory |
| **Message queue** | Lag, throughput, consumer health |
| **Storage** | I/O, saturation, capacity |

> **FAANG Tip:** "If you design a system without monitoring, you've designed half a system."

---

## Quick Monitoring Stack Recommendation

**Interview one-liner:**
> "We'd use **Prometheus** for metrics, **Grafana** for dashboards, **ELK** (or Loki) for logs, **Jaeger** with **OpenTelemetry** for distributed tracing, and **PagerDuty** for alerting."

**Minimal stack (startup):**
- Prometheus + Grafana
- Structured logs → cloud logging (CloudWatch, GCP Logging)
- OpenTelemetry → traces to Jaeger or vendor

---

## The 5-Minute Monitoring Pitch (Interviews)

```
1. LOGS (30 sec):
   "Structured JSON logs from each service, centralized in ELK.
    Include trace_id for correlation. Retention: 7d hot, 30d warm."

2. METRICS (1 min):
   "Prometheus scrapes metrics. Grafana dashboards with 4 golden
    signals. RED for APIs, USE for DB/cache. Key metrics: RPS,
    error rate, p99 latency, CPU, memory."

3. TRACES (30 sec):
   "OpenTelemetry in each service. Trace propagation across
    HTTP. Jaeger for visualization. Tail-based sampling at scale."

4. ALERTING (1 min):
   "SLO-based: error rate < 0.5%, p99 < 2s. Alert on causes:
    connection pool exhausted, dependency down. PagerDuty for
    on-call. 5-minute 'for' to avoid flapping."

5. HEALTH (30 sec):
   "Liveness and readiness probes in K8s. Health endpoints
    for load balancer. Circuit breaker metrics."
```

---

## Key Metrics for Common Systems

| System | Primary Metrics |
|--------|------------------|
| **Web API** | RPS, error rate, p50/p95/p99 latency, request size |
| **Database** | QPS, query latency, connection pool usage, slow queries |
| **Cache** | Hit rate, miss rate, eviction rate, memory usage |
| **Message queue** | Lag, publish rate, consume rate, dead-letter count |
| **Load balancer** | Active connections, 5xx rate, backend health |
| **Storage** | IOPS, latency, throughput, disk usage |

---

## Alerting Threshold Heuristics

| Metric | Typical Threshold | Rationale |
|--------|-------------------|-----------|
| **Error rate** | > 1% for 5 min | User impact |
| **Latency p99** | > 2–5× baseline | Degraded UX |
| **CPU** | > 80% sustained | Approaching saturation |
| **Memory** | > 85% | OOM risk |
| **Disk** | > 90% | Capacity planning |
| **Queue lag** | > 1000 msgs | Backlog growing |
| **Instance down** | > 2 min | Avoid false positives |

> **FAANG Tip:** "Start conservative; tune based on false positive rate. Better to miss one than page every hour."

---

## Recognition Triggers

**When the interviewer asks:**
- "How would you debug this?" → Traces + logs
- "How do you know it's working?" → Metrics, health checks
- "What if it fails?" → Alerts, SLO, runbooks
- "How do you handle scale?" → Sampling, cardinality, retention

---

## Interview Closing Statement (Copy-Paste Ready)

> "To wrap up the observability side: we'd have **structured logs** with trace_id in ELK, **metrics** via Prometheus with the four golden signals and RED/USE, **distributed tracing** with OpenTelemetry and Jaeger, **SLO-based alerting** with PagerDuty, and **health checks** for liveness and readiness. This gives us full visibility for debugging and SLA tracking."

---

## Quick Reference: Tool Mapping

| Need | Tool | Alternative |
|------|------|--------------|
| Metrics | Prometheus | Datadog, CloudWatch |
| Dashboards | Grafana | Kibana, Datadog |
| Logs | ELK | Loki, CloudWatch Logs |
| Traces | Jaeger | Zipkin, X-Ray, Datadog |
| Alerting | PagerDuty | Opsgenie, VictorOps |
| APM | New Relic, Datadog | Dynatrace |

---

## When to Recommend Vendor vs OSS

| Scenario | Recommendation |
|----------|----------------|
| Startup, small team | Datadog/New Relic — less ops overhead |
| Large scale, cost-sensitive | Prometheus + Grafana + OSS |
| Hybrid | OSS for metrics; vendor for APM/traces |
| Kubernetes-native | Prometheus + Grafana + Jaeger (CNCF stack) |

---

## 30-SECOND REVISION BOX

```
ALWAYS: Add monitoring to design
STACK: Prometheus, Grafana, ELK, Jaeger, PagerDuty
5-MIN PITCH: Logs → Metrics → Traces → Alerting → Health
KEY METRICS: Per system type (RED/USE)
THRESHOLDS: Error 1%, p99 2–5×, CPU 80%, disk 90%
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
