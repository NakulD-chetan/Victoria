# 12 — Great Expectations & Data Testing

> **One-line:** Data testing validates that your data meets **expected quality standards** — Great Expectations, dbt tests, and Soda are the industry-standard tools, and interviewers ask about them to see if you build **reliable** pipelines.

---

## 1. Why Data Testing Matters

| Problem Without Testing | Consequence |
|------------------------|-------------|
| NULL values in critical columns | Dashboard shows wrong totals |
| Duplicate rows after merge | Revenue reported 2x → bad business decisions |
| Schema change upstream | Pipeline silently drops columns → missing data |
| Data volume drops to 0 | Stale dashboard → users lose trust |
| Invalid values (negative prices) | Analytics are meaningless |

**Interview line:** "Testing data is as important as testing code — a pipeline that runs successfully but produces **wrong data** is worse than one that fails loudly."

---

## 2. Data Quality Dimensions

| Dimension | Question It Answers | Example Test |
|-----------|-------------------|-------------|
| **Completeness** | Is all expected data present? | Row count within expected range |
| **Uniqueness** | Are there duplicates? | Primary key is unique |
| **Accuracy** | Are values correct? | Amount > 0 for orders |
| **Consistency** | Does data agree across systems? | Sum of line items = order total |
| **Timeliness** | Is data fresh enough? | Latest record within last 2 hours |
| **Validity** | Do values conform to rules? | Email matches regex, status in allowed set |

---

## 3. Great Expectations (GE) — Deep Dive

### What is Great Expectations?

| Feature | Detail |
|---------|--------|
| **Type** | Open-source Python library for data validation |
| **Core idea** | Define **expectations** (assertions) on your data → validate automatically |
| **Output** | HTML data docs (reports) + JSON validation results |
| **Integration** | Works with Pandas, Spark, SQL (Snowflake, BigQuery, Postgres) |

### Core Concepts

| Concept | What |
|---------|------|
| **Expectation** | Single assertion: "column X should not be null" |
| **Expectation Suite** | Collection of expectations for a dataset |
| **Validator** | Runs expectations against actual data |
| **Checkpoint** | Reusable validation job (data source + suite + actions) |
| **Data Docs** | Auto-generated HTML documentation of expectations and results |
| **Store** | Where expectations, results, and docs are persisted |

### Example: Setting Up Great Expectations

```python
import great_expectations as gx

# Connect to data
context = gx.get_context()
datasource = context.sources.add_pandas("my_source")
asset = datasource.add_dataframe_asset("orders")

# Build expectation suite
suite = context.add_expectation_suite("orders_suite")

# Add expectations
suite.add_expectation(
    gx.expectations.ExpectColumnValuesToNotBeNull(column="order_id")
)
suite.add_expectation(
    gx.expectations.ExpectColumnValuesToBeUnique(column="order_id")
)
suite.add_expectation(
    gx.expectations.ExpectColumnValuesToBeBetween(
        column="amount", min_value=0, max_value=1000000
    )
)
suite.add_expectation(
    gx.expectations.ExpectColumnValuesToBeInSet(
        column="status", 
        value_set=["pending", "shipped", "delivered", "cancelled"]
    )
)
suite.add_expectation(
    gx.expectations.ExpectTableRowCountToBeBetween(
        min_value=1000, max_value=10000000
    )
)

# Validate
results = context.run_checkpoint("orders_checkpoint")
```

### Most Used Expectations (Interview Quick Reference)

| Expectation | What It Checks |
|------------|----------------|
| `expect_column_values_to_not_be_null` | No NULL values |
| `expect_column_values_to_be_unique` | No duplicates |
| `expect_column_values_to_be_in_set` | Values in allowed list |
| `expect_column_values_to_be_between` | Values in numeric range |
| `expect_column_values_to_match_regex` | Values match pattern |
| `expect_table_row_count_to_be_between` | Row count in range |
| `expect_column_mean_to_be_between` | Average in expected range |
| `expect_column_proportion_of_unique_values_to_be_between` | Cardinality check |
| `expect_table_column_count_to_equal` | Schema has expected columns |

---

## 4. dbt Tests — Built-in Data Quality

### Generic Tests (Built-in)

```yaml
# schema.yml
models:
  - name: orders
    columns:
      - name: order_id
        tests:
          - unique
          - not_null
      - name: customer_id
        tests:
          - not_null
          - relationships:
              to: ref('customers')
              field: customer_id
      - name: status
        tests:
          - accepted_values:
              values: ['pending', 'shipped', 'delivered', 'cancelled']
```

| Test Type | What |
|-----------|------|
| `unique` | No duplicate values |
| `not_null` | No NULL values |
| `accepted_values` | Values in allowed set |
| `relationships` | Foreign key integrity |

### Singular Tests (Custom SQL)

```sql
-- tests/assert_positive_revenue.sql
-- This test FAILS if any rows are returned

SELECT order_id, amount
FROM {{ ref('orders') }}
WHERE amount <= 0
```

### dbt Packages for Testing

| Package | Tests It Adds |
|---------|-------------|
| **dbt_utils** | `expression_is_true`, `recency`, `equal_rowcount`, `not_constant` |
| **dbt_expectations** | Great Expectations-like tests in dbt (row count range, column means, regex) |
| **elementary** | Anomaly detection, volume monitoring, freshness alerts |

---

## 5. Soda — Data Quality Monitoring

| Feature | Detail |
|---------|--------|
| **What** | Data quality monitoring tool (CLI + cloud) |
| **Language** | YAML-based checks (SodaCL) |
| **Strength** | Easy setup, great monitoring dashboards, anomaly detection |
| **Integration** | Connects to Snowflake, BigQuery, Postgres, Spark, etc. |

### Soda Example

```yaml
# checks.yml
checks for orders:
  - row_count > 0
  - missing_count(order_id) = 0
  - duplicate_count(order_id) = 0
  - avg(amount) between 50 and 500
  - freshness(created_at) < 2h
  - values in (status) must be in ['pending', 'shipped', 'delivered']

  # Anomaly detection
  - anomaly detection for row_count
  - anomaly detection for avg(amount)
```

---

## 6. Where Tests Fit in the Pipeline

```
Source → Ingestion → Bronze → Silver → Gold → Serving
              │          │        │        │
              ▼          ▼        ▼        ▼
          Schema      Null     Business  Reconciliation
          checks      checks   rules     checks
          Row count   Dedup    Ranges    Source vs DW
          Format      Type     Referential Cross-system
                      cast     integrity  totals match
```

### Testing Strategy by Layer

| Layer | What to Test | Tool |
|-------|-------------|------|
| **Ingestion** | Schema validation, file format, row count | Great Expectations, custom Python |
| **Bronze → Silver** | Null handling, type casting, deduplication | dbt tests, Great Expectations |
| **Silver → Gold** | Business rules, referential integrity, ranges | dbt tests, dbt_expectations |
| **Serving** | Freshness, reconciliation with source | Soda, Elementary, custom SQL |

---

## 7. Alerting on Test Failures

| Severity | Action | Example |
|----------|--------|---------|
| **Critical** | Block pipeline, page on-call | Primary key has duplicates → data corruption |
| **Warning** | Alert in Slack, continue pipeline | Row count 20% lower than usual → investigate |
| **Info** | Log for review | New unexpected value in status column |

### Integration with Orchestrators

```
Airflow DAG:
  extract_task >> dbt_run_task >> dbt_test_task >> load_to_gold_task

  If dbt_test_task fails:
    → Pipeline stops
    → Slack alert fires
    → On-call investigates
    → Gold layer is NOT updated with bad data
```

---

## 8. Great Expectations vs dbt Tests vs Soda

| Feature | Great Expectations | dbt Tests | Soda |
|---------|-------------------|-----------|------|
| **Language** | Python | SQL/YAML | YAML (SodaCL) |
| **Best for** | Python pipelines, Spark | dbt projects | Monitoring, alerting |
| **Learning curve** | Medium | Low (if using dbt) | Low |
| **Anomaly detection** | Limited | Via elementary | Built-in |
| **Data docs** | Excellent HTML reports | dbt docs | Soda Cloud dashboard |
| **CI/CD** | Integrates via Python | Native `dbt test` command | CLI in CI pipeline |
| **When to choose** | Spark/Python pipelines | Already using dbt | Need monitoring + alerting |

---

## 9. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "How do you ensure data quality?" | Tests at each layer: schema → null/dedup → business rules → reconciliation |
| "What is Great Expectations?" | Python library for data validation with expectations, suites, checkpoints |
| "How do you test in dbt?" | Generic tests (unique, not_null, relationships), singular tests (custom SQL) |
| "What do you do when a test fails?" | Severity-based: critical blocks pipeline, warning alerts, info logs |
| "How do you detect data anomalies?" | Historical baselines → compare current metrics → alert on deviation (Soda/Elementary) |
| "How do you test schema changes?" | Schema expectations, dbt contracts, Schema Registry for streaming |
| "What's the difference between data testing and unit testing?" | Data testing: validates data content. Unit testing: validates code logic |
| "Where in the pipeline do you add tests?" | After each transformation layer — especially Bronze→Silver and Silver→Gold boundaries |

---

## Key Takeaways

- **Data testing** = validating that data meets quality expectations at every pipeline stage.
- **Six dimensions**: completeness, uniqueness, accuracy, consistency, timeliness, validity.
- **Great Expectations**: Python-based, rich expectations library, excellent for Spark/Python pipelines.
- **dbt tests**: native to dbt projects, easy YAML config, `unique`/`not_null`/`relationships`/`accepted_values`.
- **Soda**: YAML-based monitoring with built-in anomaly detection and dashboards.
- **Test at every layer boundary** — ingestion, Bronze→Silver, Silver→Gold, serving.
- **Critical failures block the pipeline** — never let bad data reach the Gold/serving layer.
- **Reconciliation checks** (source total = DW total) catch silent data loss.

---
