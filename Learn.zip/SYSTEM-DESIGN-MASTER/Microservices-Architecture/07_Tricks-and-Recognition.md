# Microservices Architecture — Tricks and Recognition

> **Permanent Recall:** Use microservices when team size (6+), scale, or deploy frequency justify it. Service boundary shortcuts: domain nouns (User, Order), team ownership. Communication: sync for immediate response; async for events/decoupling. Common stack: API Gateway, service mesh, message queue, distributed tracing.

---

## When to Use Microservices vs Monolith

| Factor | Monolith | Microservices |
|--------|----------|---------------|
| **Team size** | 1–5 devs | 6+ devs, multiple teams |
| **Scale** | Low–medium | High; different services scale differently |
| **Deploy frequency** | Weekly or less | Multiple deploys per day |
| **Domain clarity** | Unclear | Clear bounded contexts |
| **Operational maturity** | Limited | DevOps, K8s, observability |

**Rule:** If 3+ factors favor microservices, consider. If 2+ favor monolith, start monolith.

---

## Service Boundary Identification Shortcuts

| Shortcut | How |
|----------|-----|
| **Domain nouns** | User, Order, Payment, Inventory—each candidate service |
| **Different scale** | Search (heavy) vs Auth (light)—split for independent scaling |
| **Different SLAs** | Payment (critical) vs Analytics (best-effort)—isolate |
| **Team ownership** | "Who owns this?"—service follows team |
| **Change rate** | Frequently changed together? Same service. Independent? Split. |
| **Data ownership** | Can this service own this data exclusively? Yes → good boundary |

> **FAANG Tip:** *"If two modules always deploy together and share the same data, they're probably one service."*

---

## Communication Pattern Selection

| Need | Sync | Async |
|------|-----|-------|
| Immediate response (get user, validate) | REST, gRPC | — |
| Fire-and-forget (send notification) | — | Queue, pub/sub |
| One-to-many (order placed) | — | Events |
| Critical path | Prefer | Avoid (adds latency) |
| Cross-region | Avoid (latency) | Better (decoupled) |
| Retry / replay | Awkward | Natural |

**Quick rule:** Ask "Can the caller proceed without waiting?" → Yes = async.

---

## Common Microservices Technology Stack

| Layer | Options |
|-------|---------|
| **API Gateway** | Kong, AWS API Gateway, Nginx, Traefik, Zuul |
| **Service mesh** | Istio, Linkerd, Consul Connect |
| **Service discovery** | Consul, Eureka, Kubernetes DNS, etcd |
| **Message queue** | Kafka, RabbitMQ, AWS SQS, Google Pub/Sub |
| **Distributed tracing** | Jaeger, Zipkin, OpenTelemetry, AWS X-Ray |
| **Container orchestration** | Kubernetes, ECS, Docker Swarm |
| **Database** | PostgreSQL, MySQL, MongoDB (per service) |

---

## Recognition Triggers (Phrases)

| Phrase | Implies |
|--------|---------|
| "Multiple teams" | Microservices; team per service |
| "Independent deploy" | Microservices; no shared DB |
| "Different scaling needs" | Microservices; scale per service |
| "Event-driven" | Async; message queue; eventual consistency |
| "Bounded context" | DDD; service boundary |
| "Strangler" | Migration from monolith |
| "Saga" | Distributed transaction; compensating actions |
| "Circuit breaker" | Resilience; fail fast |

---

## Interview Flow: Microservices Recognition

1. **"Design X"** → If X has multiple domains (e.g., e-commerce, Uber), consider microservices.
2. **"Scale"** → Mention independent scaling per service.
3. **"Multiple teams"** → Team per service; Conway's Law.
4. **"Existing monolith"** → Strangler Fig migration.
5. **"How do services talk?"** → Sync vs async; REST/gRPC vs Kafka.

---

## Quick Memory Card

```
WHEN:          Team 6+, scale, deploy freq, clear domains
BOUNDARIES:    Domain nouns, scale, SLA, team, change rate
COMMUNICATION: Sync = immediate; async = events, decouple
STACK:         Gateway, mesh, discovery, queue, tracing, K8s
TRIGGERS:      Multiple teams, independent deploy, event-driven
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
