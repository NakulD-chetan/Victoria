# Availability and Reliability — Mental Model

> **Permanent Recall:** Think of high availability like a hospital ER—always open, backup doctors on call, backup generators for power. For composite availability: series components multiply (all must work); parallel components use 1−(1−A)ⁿ (any one works). Trace every request path to find SPOFs. Match nines to business impact: internal tools 99%, customer-facing 99.9%, payment 99.99%+.

---

## Hospital ER Analogy

```
         HOSPITAL ER = HIGHLY AVAILABLE SYSTEM
        
    ┌─────────────────────────────────────────────────┐
    │  ER (Always Open)                                │
    │  - 24/7 operation                                │
    │  - Multiple doctors (redundancy)                  │
    │  - Backup generator (power failure)              │
    │  - On-call roster (failover)                     │
    └────────────────┬────────────────────────────────┘
                     │
         One doctor sick? Another takes over (failover)
         Power out? Generator kicks in (redundancy)
         Peak load? More doctors called in (scaling)
```

**Mapping:**

| Hospital | System Design |
|----------|---------------|
| ER always open | 24/7 availability |
| Multiple doctors | Active-active servers |
| Backup generator | Power redundancy, multi-AZ |
| On-call roster | Standby instances |
| Ambulance fleet | Load balancer, multiple entry points |

> **FAANG Tip:** "Think of HA like an ER—you never want a single doctor (SPOF), and you need backups for power (infra) and staff (services)."

---

## How to Think About Availability Requirements

| System Type | Typical Target | Rationale |
|-------------|----------------|-----------|
| Internal tools | 99% | 3.65 days/year OK for internal |
| Customer-facing web | 99.9% | 8.76 hrs/year max |
| E-commerce, API | 99.9%–99.95% | Revenue impact |
| Payment, auth | 99.99%+ | Security, compliance |
| Healthcare, finance | 99.999% | Regulatory, life-critical |

---

## Composite Availability: Series vs Parallel

### Components in Series (all must work)

```
Request → [A] → [B] → [C] → Response

A_combined = A_A × A_B × A_C

Example: 99% × 99% × 99% = 97.03%
```

**Series rule:** Every component must be up. Availability decreases.

### Components in Parallel (redundancy)

```
        ┌─ [A] ─┐
Request ┼─ [B] ─┼→ Response (any one works)
        └─ [C] ─┘

A_combined = 1 − (1−A)ⁿ

Example: 3× 99% in parallel
  = 1 − (0.01)³ = 1 − 0.000001 = 99.9999%
```

**Parallel rule:** Any one works. Availability increases.

```mermaid
flowchart LR
    subgraph Series["Series (all must work)"]
        S1[A] --> S2[B] --> S3[C]
    end
    subgraph Parallel["Parallel (any works)"]
        P1[A]
        P2[B]
        P3[C]
    end
```

---

## Mental Model: Identifying SPOFs

**Trace every request path:**

```
1. Client → DNS → LB → App → DB → Cache
2. For each step: "What if this component fails?"
3. If failure = total outage → SPOF
4. Add redundancy or failover
```

```
SPOF CHECKLIST:
  [ ] DNS — single? Use multiple NS, low TTL
  [ ] Load balancer — single? Active-passive pair
  [ ] App servers — single? Multiple instances
  [ ] Database — single? Replicas, failover
  [ ] Single AZ? Multi-AZ / multi-region
  [ ] Single region? Cross-region DR
```

---

## When to Aim for Which Nines Level

| Nines | Downtime/Year | When to Use |
|-------|---------------|-------------|
| 99% | 3.65 days | Internal tools, dev environments |
| 99.9% | 8.76 hours | Most SaaS, customer apps |
| 99.99% | 52.6 min | Payment, auth, critical path |
| 99.999% | 5.26 min | Banks, healthcare, compliance |

> **FAANG Tip:** "What availability do you need?" → "Depends on business impact. Internal 99%, customer-facing 99.9%, payment 99.99%. Each nine adds significant cost."

---

## Decision Flow: Availability Level Selection

```mermaid
flowchart TD
    A[New system] --> B{Revenue impact if down?}
    B -->|High| C{Regulatory?}
    B -->|Low| D[99% - Internal]
    C -->|Yes| E[99.99%+]
    C -->|No| F[99.9%]
    B -->|Medium| F
```

---

## 30-SECOND REVISION BOX

```
HOSPITAL ER: always open, backup staff, backup power
SERIES: A × B × C (all must work) → lowers availability
PARALLEL: 1−(1−A)ⁿ (any works) → raises availability
SPOF: trace path, "what if this fails?"
NINES: internal 99%, SaaS 99.9%, payment 99.99%
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
