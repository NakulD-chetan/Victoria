# Quick Revision — Numbers and Formulas

> **Permanent Recall:** ALL the numbers in one place. Latency, power of 2, QPS/storage formulas, server capacity, availability nines, common system scales. "Napkin math" reference.

---

## Latency Numbers (Every Programmer Should Know)

| Operation | Latency |
|-----------|---------|
| L1 cache reference | 0.5 ns |
| L2 cache reference | 7 ns |
| Main memory (RAM) | 100 ns |
| SSD random read | 150 μs |
| HDD seek | 10 ms |
| Network RTT (same DC) | 500 μs |
| Network RTT (CA → EU) | 150 ms |
| Same rack RTT | ~0.5 ms |

```
Fast → Slow: L1 (0.5ns) → L2 (7ns) → RAM (100ns) → SSD (150μs) → HDD (10ms) → Network (500μs–150ms)
```

---

## Power of 2 Table

| 2^n | Value |
|-----|-------|
| 2^10 | 1 KB |
| 2^20 | 1 MB |
| 2^30 | 1 GB |
| 2^40 | 1 TB |
| 2^50 | 1 PB |

---

## QPS Estimation

| Formula | Use |
|---------|-----|
| **QPS** | DAU × actions_per_day ÷ 86400 |
| **Peak QPS** | 2–3× average |
| **86400** | ≈ 100,000 (sec/day) |

**Quick rule:** DAU × 10 ÷ 100K ≈ read QPS (social feed)

---

## Storage Estimation

| Formula | Use |
|---------|-----|
| **Storage** | items × bytes_per_item × replication_factor |
| **With overhead** | + 20–30% for indexes, metadata |
| **5-year** | Storage/day × 365 × 5 |

---

## Bandwidth Estimation

| Formula | Use |
|---------|-----|
| **Bandwidth (bps)** | QPS × avg_response_bytes × 8 |
| **Mbps → MB/s** | ÷ 8 |

---

## Server Capacity Numbers

| Component | Capacity |
|-----------|----------|
| Web server | ~1,000 QPS |
| DB read | ~5,000 QPS |
| DB write | ~1,000 QPS |
| Redis | ~100,000 QPS |
| Kafka partition | ~10–100K msg/s |
| CDN (per edge) | Gbps–Tbps |

---

## Availability Nines

| Availability | Downtime/Year | Downtime/Month |
|--------------|---------------|----------------|
| 99% | 3.65 days | 7.3 hr |
| 99.9% | 8.76 hr | 43.8 min |
| 99.99% | 52.6 min | 4.38 min |
| 99.999% | 5.26 min | 26.3 sec |

---

## Time Conversion

| Conversion | Value |
|------------|-------|
| 1M seconds | ~12 days |
| 1B seconds | ~32 years |
| Seconds/day | 86,400 ≈ 10^5 |
| Seconds/month | ~2.5 × 10^6 |

---

## Common System Scale (Reference)

| System | DAU | QPS (approx) |
|--------|-----|--------------|
| Twitter | 500M | ~3M read, ~6K write |
| WhatsApp | 2B | ~50B msg/day |
| YouTube | 2B | Billions views/day |
| Netflix | 200M+ | Peak ~1M concurrent |
| Google | 5B+ searches/day | ~60K QPS avg |

---

## Read:Write Ratios

| System | Ratio |
|--------|-------|
| Social feed | 100:1 |
| Chat | 1:1 |
| Video streaming | 1000:1 |
| E-commerce | 10:1 |
| Search | 100:1 |
| URL shortener | 100:1 |

---

## Capacity Cheat Sheet

```
COMPONENT          CAPACITY
─────────────────────────────────
Web server         ~1,000 QPS
DB read            ~5,000 QPS
DB write           ~1,000 QPS
Redis              ~100,000 QPS
Kafka partition    ~10–100K msg/s
```

---

## One-Line Formulas

| Question | One-Liner |
|----------|-----------|
| QPS from DAU | DAU × actions ÷ 100K |
| Web servers | Peak QPS ÷ 1K |
| DB replicas | Read QPS ÷ 5K |
| Redis nodes | Read QPS ÷ 100K (if 80% hit: 20% to DB) |

---

## Rule of 72 (Growth)

**Doubling time (years) ≈ 72 ÷ growth_rate_percent**

- 10% growth → ~7 years
- 25% growth → ~3 years
- 50% growth → ~1.4 years

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
