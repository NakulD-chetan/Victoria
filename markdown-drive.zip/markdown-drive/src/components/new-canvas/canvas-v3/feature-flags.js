export const CANVAS_V3_ENGINE_KEY = 'new-canvas:engine';

export function isCanvasV3Enabled() {
  if (typeof window === 'undefined') {
    return import.meta.env?.VITE_NEW_CANVAS_V3 !== 'false';
  }

  const queryEngine = new URLSearchParams(window.location.search).get('engine');
  if (queryEngine === 'v2') return false;
  if (queryEngine === 'v3') return true;

  const savedEngine = window.localStorage.getItem(CANVAS_V3_ENGINE_KEY);
  if (savedEngine === 'v2') return false;
  if (savedEngine === 'v3') return true;

  return import.meta.env.VITE_NEW_CANVAS_V3 !== 'false';
}

