# 8. Kafka Streams & ksqlDB

> **Permanent Recall Note:** **Kafka Streams** is a **Java library** — **no separate cluster** — embedding **stateful** stream processing **inside** your app. **KStream** = **record stream**; **KTable** = **changelog table**; **GlobalKTable** = **replicated** lookup. **ksqlDB** exposes **SQL** over the same abstractions. Compare with **Spark** (batch + micro-batch cluster) — [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md) — and **Flink** (true low-latency, stateful cluster).

### The 10-Second Summary
- **Library model** — runs on **app pods** with **local RocksDB** state.
- **Windows:** tumbling, hopping, sliding, **session** — **time semantics** (`EventTime`, `ProcessingTime`).
- **EOS** via `exactly_once_v2` (modern broker).
- **ksqlDB** = **declarative** layer; **Streams** = **full** Java control.

---

# 8.1 Kafka Streams Overview

```
┌─────────────────────────────────────────────────────────────┐
│  Your JVM (multiple instances = consumer group)               │
│  • Topology: KStream/KTable operators                       │
│  • State stores (RocksDB) + changelog topics                  │
│  • Repartition topics for joins/aggregations                  │
└─────────────────────────────────────────────────────────────┘
```

💡 **Key Insight:** **Elasticity** = **consumer group** — partitions **assign** to **instances**.

---

# 8.2 KStream vs KTable vs GlobalKTable

| Abstraction | Mental model |
|-------------|--------------|
| **KStream** | **Append** stream — every event |
| **KTable** | **Upsert** by key — **latest** value per key |
| **GlobalKTable** | **Full** copy on each node — **star join** / small dim |

---

# 8.3 Stateful Operations

- **Aggregation** — count, sum by key — **windowed** or not.
- **Join** — stream-stream, stream-table, table-table — **co-partitioning** required (same key, same partitions).

⚠️ **Warning:** **Wrong partition count** = **cannot join** without **repartition** topic.

---

# 8.4 Windows

| Type | Definition |
|------|------------|
| **Tumbling** | Fixed size, **non-overlapping** |
| **Hopping** | Fixed size, **overlapping** with advance interval |
| **Sliding** | **Per event** windows — expensive |
| **Session** | **Gap**-based activity sessions |

---

# 8.5 State Stores (RocksDB)

- **Changelog** topics for **fault tolerance** — restore on **restart**.
- **Interactive queries** — **RPC** to fetch **local** state (routing layer).

---

# 8.6 Exactly-Once in Streams

```properties
processing.guarantee=exactly_once_v2
```

- **Transactional** writes + **consumer** offsets — **broker** support required.

---

# 8.7 ksqlDB Basics

```sql
CREATE STREAM orders (order_id STRING, amount DOUBLE) WITH (
  kafka_topic='orders',
  value_format='JSON'
);

CREATE TABLE users AS SELECT ... -- simplified mental model
```

🧠 **Memory Trick:** **ksql** = **SQL** skin over **Streams** concepts.

---

# 8.8 Stream-Table Duality

- **Table** can be seen as **latest** snapshot of a **stream** of updates.
- **Stream** can be **materialized** from table **changelog**.

---

# 8.9 When to Use Streams vs Flink vs Spark

| Engine | Sweet spot |
|--------|------------|
| **Kafka Streams** | **Kafka-native**, **microservices**, **embedded** ops |
| **Flink** | **Low latency**, **CEP**, **advanced** state, **cluster** |
| **Spark Structured Streaming** | **Unified** batch + stream, **lakehouse** writes, **SQL** at scale — [../spark/00_Table_of_Contents.md](../spark/00_Table_of_Contents.md) |

🔄 **Trade-off:** **Operational** surface: **Streams** scales with **app** ops; **Spark/Flink** with **platform** teams.

---

# 8.10 Java — Topology sketch

```java
StreamsBuilder b = new StreamsBuilder();
KStream<String, Order> orders = b.stream("orders");
orders.groupByKey().count(Materialized.as("counts-store"));
```

---

# 8.11 Repartition Topics (Internal)

```
Stream with wrong partitioning for join
        │
        ▼
   repartition topic (same key space, correct # partitions)
        │
        ▼
      join / aggregate
```

Yaad rakho: **repartition** = **extra** topic + **latency** + **cost** — design **upstream** keys early.

---

# 8.12 Graceful vs Non-Graceful Shutdown

- **close()** with **timeout** — **commit** pending, **flush** state stores.
- **Kill -9** — **longer** restore from **changelog** on restart.

---

# 8.13 Interactive Queries — Mental Model

```
Instance A serves keys {hash % N = 0}
Instance B serves keys {hash % N = 1}
       ...
Metadata RPC: "who owns key K?"
```

---

# 8.14 ksqlDB vs Streams — When Which?

| Need | Pick |
|------|------|
| **SQL** analytics, fast iteration | **ksqlDB** |
| **Custom** logic, **unit tests** for topology | **Streams** |

---

# 8.15 Interview Questions & Answers

**Q: Streams cluster kahan hai?**  
**A:** **Kafka cluster** + **your app** JVMs — **no** Streams “master.”

**Q: Join ke liye kya zaroori?**  
**A:** **Same key**, **compatible** partition counts or **repartition**.

**Q: Spark vs Streams for same pipeline?**  
**A:** **Spark** for **heavy** lakehouse ETL; **Streams** for **inline** microservice **analytics** near Kafka.

**Q: Session window kahan use?**  
**A:** **User sessions**, **click streams** — **gap** inactivity closes session.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 8 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Streams = library; RocksDB state; changelog restore      │
│  🧠 KStream append; KTable upsert; GlobalKTable broadcast    │
│  🧠 Windows = time semantics core                         │
│  🧠 ksql = SQL facade over Streams model                    │
│  ⚠️  Joins need co-partitioning / repartition              │
│  🎯 Pick Streams vs Flink vs Spark by latency/ops model     │
└─────────────────────────────────────────────────────────────┘
```
