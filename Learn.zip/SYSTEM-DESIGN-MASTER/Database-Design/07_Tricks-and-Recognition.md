# Database Design — Tricks and Recognition (Deep Understanding)

> **Permanent Recall:** When to think about databases: any time you hear "store," "query," "scale," "transactions," or "data." Database selection: ACID → SQL; cache/sessions → Redis; flexible docs → MongoDB; graph → Neo4j; massive writes → Cassandra. Index trick: equality → range → sort (left-to-right). Recognize system type → instantly know DB choice, schema pattern, and scaling strategy.

---

## Trick 1: Instant Recognition — When to Discuss Databases

**The simple rule:** Every system stores data. If data is mentioned, databases should be discussed.

| What You Hear/Draw in Interview | Instant Database Decision |
|--------------------------------|--------------------------|
| "Store user data" | PostgreSQL (structured, ACID) |
| "Cache for speed" | Redis (sub-ms reads, TTL) |
| "Store sessions" | Redis (key-value, TTL auto-expiry) |
| "User profiles with varying fields" | MongoDB (flexible schema) |
| "Social connections, friends, followers" | PostgreSQL for small scale, Neo4j for graph queries at scale |
| "Time-series data, IoT sensors" | Cassandra or TimescaleDB |
| "Search, autocomplete" | Elasticsearch (inverted index) |
| "Millions of writes per second" | Cassandra (write-optimized) |
| "Transactions, payments, inventory" | PostgreSQL (ACID is mandatory) |
| "Leaderboard, ranking" | Redis sorted sets (ZADD, ZRANK) |
| "Analytics, reporting" | BigQuery/Snowflake (columnar warehouse) |
| "Message queue state" | Redis (LPUSH/RPOP) or Kafka |

### What NOT to Overthink

| Scenario | Keep It Simple |
|----------|---------------|
| MVP with 1000 users | Single PostgreSQL. Don't even think about NoSQL yet. |
| Simple CRUD app | PostgreSQL. Add Redis only when you have a caching need. |
| Prototyping | SQLite or PostgreSQL. Ship fast, optimize later. |

---

## Trick 2: Database Selection in 5 Seconds

When the interviewer asks "what database?", use this instant decision framework:

```
┌──────────────────────────────────────────────────────────────┐
│          5-SECOND DATABASE DECISION                           │
│                                                              │
│  Q1: Do you need ACID transactions?                          │
│      YES → SQL (PostgreSQL)                                  │
│      NO  → Continue to Q2                                    │
│                                                              │
│  Q2: What's the access pattern?                              │
│      Key → Value lookup?    → Redis / DynamoDB               │
│      Flexible documents?    → MongoDB                        │
│      Graph traversals?      → Neo4j                          │
│      Massive writes?        → Cassandra                      │
│      Full-text search?      → Elasticsearch                  │
│      Analytics/reporting?   → BigQuery / Snowflake           │
│                                                              │
│  Q3: Still unsure?                                           │
│      → PostgreSQL (safe default for almost anything)         │
└──────────────────────────────────────────────────────────────┘
```

### Quick Cheat Sheet (Memorize This)

| System Type | Primary DB | Cache | Special DB | One-Sentence Reason |
|-------------|-----------|-------|-----------|---------------------|
| Payment system | **PostgreSQL** | Redis (session) | — | "ACID for financial transactions, cannot lose money" |
| Social media | **PostgreSQL** | Redis (feed, sessions) | Elasticsearch (search) | "SQL for user data, Redis for pre-computed feeds" |
| E-commerce | **PostgreSQL** | Redis (cart, product cache) | Elasticsearch (search) | "ACID for orders/inventory, Redis for cart TTL" |
| Chat / messaging | **Cassandra** | Redis (online status) | PostgreSQL (user accounts) | "Cassandra handles write-heavy message storage" |
| URL shortener | **PostgreSQL** | Redis (hot URLs) | — | "Simple mapping, Redis cache for popular URLs" |
| Leaderboard | **Redis** (ZADD) | — | PostgreSQL (user data) | "Sorted set for O(log n) ranking operations" |
| IoT / metrics | **Cassandra** or TimescaleDB | — | — | "Write-optimized for billions of data points" |
| Recommendation | **Neo4j** | Redis | PostgreSQL (base data) | "Graph traversals for 'users who liked X also liked Y'" |

---

## Trick 3: Index Selection in 3 Seconds

```
Look at your query's WHERE, JOIN, and ORDER BY columns:

  WHERE user_id = 123          → Index: (user_id)
  WHERE user_id = 123 
    ORDER BY created_at DESC   → Index: (user_id, created_at)
  WHERE status = 'active' 
    AND created_at > '2024-01' → Index: (status, created_at)
  WHERE email = 'alice@x.com'  → Unique index: (email)

RULES:
  1. Equality columns FIRST (user_id = ?, status = ?)
  2. Range columns NEXT (created_at > ?, price BETWEEN)
  3. Sort columns LAST (ORDER BY created_at)
  4. Leftmost prefix: index (A, B, C) helps (A), (A,B), (A,B,C). NOT (B) or (C).
```

### Instant Reference

| Query Pattern | Index to Create | Why |
|---------------|----------------|-----|
| `WHERE id = ?` | Already indexed (PK) | Primary key is auto-indexed |
| `WHERE email = ?` | `UNIQUE INDEX (email)` | Login query, must be fast |
| `WHERE user_id = ? ORDER BY created_at DESC` | `(user_id, created_at)` | User's recent items — equality + sort |
| `WHERE category = ? AND price BETWEEN ? AND ?` | `(category, price)` | Browse by category with price filter |
| `WHERE status IN ('pending', 'processing')` | `PARTIAL INDEX WHERE status IN (...)` | Only index active statuses, not completed |
| `SELECT id, name WHERE email = ?` | `(email) INCLUDE (id, name)` | Covering index — no table lookup needed |

---

## Trick 4: Recognize System Type → Instantly Know DB Config

### The Master Recognition Table

| System You're Designing | Primary DB | Cache | Schema Hint | Say This in Interview |
|------------------------|-----------|-------|-------------|----------------------|
| **URL Shortener** | PostgreSQL | Redis | `urls(short_code PK, original_url, created_at)` | *"PostgreSQL for durability, Redis cache for hot URLs. Read:write 100:1 — cache handles most reads."* |
| **Chat (WhatsApp)** | Cassandra + PostgreSQL | Redis | Cassandra: `messages(chat_id, timestamp, content)` PG: `users(id, name)` | *"Cassandra for message storage — write-heavy, time-ordered. PostgreSQL for user accounts. Redis for online status."* |
| **Twitter Feed** | PostgreSQL | Redis | `posts(id, user_id, content, created_at)` `followers(follower_id, followed_id)` | *"PostgreSQL for tweets and users. Pre-compute feeds in Redis (fan-out on write). Elasticsearch for tweet search."* |
| **E-commerce** | PostgreSQL | Redis | `orders(id, user_id, status, total)` `order_items(order_id, product_id, qty, price)` | *"PostgreSQL with ACID for checkout flow. Redis for cart (TTL), product cache. Transaction wraps stock + order + payment."* |
| **Uber/Ride-sharing** | PostgreSQL + Redis | Redis | `trips(id, driver_id, rider_id, status)` `drivers(id, location)` | *"PostgreSQL for trip history. Redis for real-time driver locations (geospatial). PostGIS for geo-queries."* |
| **Video Streaming** | PostgreSQL + S3 | Redis | `videos(id, url, metadata)` in PG; actual files in S3 | *"Metadata in PostgreSQL. Video files in S3 + CDN. Redis cache for popular video metadata."* |
| **Analytics Dashboard** | PostgreSQL + BigQuery | Redis | Operational in PG → ETL → BigQuery for OLAP | *"Transactional data in PostgreSQL. ETL to BigQuery for aggregations. Redis cache for dashboard results."* |
| **Gaming Leaderboard** | Redis (primary) | — | `ZADD leaderboard <score> <user_id>` | *"Redis sorted set. ZADD O(log n) for score updates. ZRANK O(1) for position. ZRANGE for top-N."* |
| **Session Storage** | Redis | — | `session:{token} → {user_id, role, expires}` | *"Redis key-value with TTL. GET is O(1), sub-ms. EXPIRE for auto-cleanup."* |
| **IoT Sensor Data** | Cassandra / TimescaleDB | — | Wide rows: `sensor_id → {ts1: val1, ts2: val2, ...}` | *"Cassandra for massive write throughput. Partition by sensor_id, cluster by timestamp."* |

---

## Trick 5: Scaling Strategy in 10 Seconds

```
When asked "How do you scale the database?"

INSTANT ANSWER FRAMEWORK:

Level 0: "Is the query even optimized?"
  → Add indexes, fix N+1, tune queries
  → Handles: 1K-5K req/sec

Level 1: "Bigger machine"
  → Vertical scaling (more CPU, RAM, SSD)
  → Handles: 5K-20K req/sec

Level 2: "Separate reads from writes"
  → Read replicas for read queries
  → Handles: 20K-100K read req/sec

Level 3: "Don't hit the DB for hot data"
  → Redis cache layer
  → Handles: 100K+ read req/sec (cache serves 80-90%)

Level 4: "Split the data across servers"
  → Sharding (LAST RESORT for SQL)
  → Handles: 100K+ write req/sec

ALWAYS START FROM LEVEL 0 AND WORK UP.
Never jump to sharding before trying optimization + replicas + cache.
```

---

## Trick 6: Common Interview Patterns That Need Database Discussion

### Pattern: "How Would You Handle 10x Traffic?"

```
Current: 5K reads/sec, 500 writes/sec to PostgreSQL

Answer Framework:
1. "Add read replicas — offload reads from primary" (3 replicas = 4× read capacity)
2. "Add Redis cache for hot data" (cache absorbs 80% of reads)
3. "Connection pooling if not already" (handle 10× connections with same pool)
4. "The write path is still single primary — at 5K writes/sec, PostgreSQL handles fine"
5. "If writes become the bottleneck, we'd consider sharding by user_id"
```

### Pattern: "How Do You Ensure Data Consistency?"

```
Answer Framework:
1. "PostgreSQL with ACID transactions for multi-step operations"
2. "Wrap related operations in BEGIN/COMMIT"
3. "Read Committed isolation for most queries; Serializable for critical paths"
4. "Foreign key constraints prevent orphaned data"
5. "Application-level validation + database constraints as safety net"
```

### Pattern: "This Query Is Slow — How to Fix?"

```
Answer Framework:
1. "Run EXPLAIN ANALYZE to see the execution plan"
2. "Check for Seq Scan → add index on WHERE columns"
3. "Check for N+1 → use JOIN or batch fetch"
4. "Check OFFSET pagination → switch to cursor-based"
5. "Check SELECT * → select only needed columns"
6. "If table is huge → consider partitioning or archiving old data"
```

### Pattern: "Design for Global Users"

```
Answer Framework:
1. "Primary database in one region for writes"
2. "Read replicas in each region for fast reads"
3. "GSLB routes users to nearest replica"
4. "Redis cache in each region for sub-ms hot data"
5. "Consider multi-primary with conflict resolution if write latency matters"
6. "For compliance (GDPR), data stays in user's region"
```

---

## Trick 7: Recognizing Database Trigger Phrases

| Phrase You Hear | What It Implies | What to Add |
|-----------------|-----------------|-------------|
| "Store data" | Need a database | Choose SQL vs NoSQL based on requirements |
| "Transactions" | ACID needed | PostgreSQL with explicit transactions |
| "Fast lookups" | Key-value pattern | Redis or DynamoDB |
| "Search" | Full-text search | Elasticsearch (not SQL LIKE) |
| "Scale reads" | Read-heavy workload | Read replicas + Redis cache |
| "Scale writes" | Write-heavy workload | Sharding or Cassandra |
| "User sessions" | Key-value with TTL | Redis with EXPIRE |
| "Slow query" | Missing index or bad query | EXPLAIN ANALYZE → add index |
| "Real-time ranking" | Sorted data structure | Redis sorted set (ZADD) |
| "Flexible schema" | Varying fields per record | MongoDB or PostgreSQL JSONB |
| "Graph relationships" | Connected data, traversals | Neo4j for complex, SQL for simple |
| "Time-series" | Append-only, timestamp-ordered | Cassandra, TimescaleDB, InfluxDB |
| "Data integrity" | Constraints, consistency | PostgreSQL (FK, CHECK, UNIQUE) |
| "Multiple services, different data" | Polyglot persistence | Each service owns its database |

---

## Trick 8: The Database Conversation Flow in Interview

### Step-by-Step What to Do

```
STEP 1: Identify the data
  "The core data is Users, Posts, Comments, and Likes"

STEP 2: Identify relationships
  "Users have many Posts (1:N). Posts have many Comments (1:N).
   Users like many Posts (M:N through post_likes table)."

STEP 3: Choose database with ONE-LINE justification
  "PostgreSQL — structured data with relationships, need ACID for any financial flow"
  "Plus Redis for caching hot posts and user sessions"

STEP 4: Show 2-3 key tables with indexes
  "users(id, email, name), posts(id, user_id, content, created_at)"
  "Index: posts(user_id, created_at DESC) for user's feed"

STEP 5: Mention ONE scaling consideration
  "Read replicas for the read-heavy feed query"

STEP 6: STOP. Don't over-explain unless asked.
  If interviewer asks more → go deeper on sharding, indexing, etc.
```

### Example Flow for E-commerce Design

```
YOU: "For the data layer:
      PostgreSQL as the primary database — we need ACID for the checkout flow.
      Core tables: users, products, orders, order_items, payments.
      
      Index on orders(user_id, created_at DESC) for 'my orders' page.
      Index on products(category_id, price) for browsing.
      
      The checkout flow is wrapped in a transaction:
      BEGIN → check stock (FOR UPDATE) → create order → create payment → COMMIT.
      If payment fails, everything rolls back.
      
      Redis for: cart (TTL 24h), product cache, session storage.
      Elasticsearch for product search and autocomplete."

INTERVIEWER: "What about at scale?"

YOU: "Read replicas for product catalog browsing (read-heavy).
      Redis cache absorbs most reads — products, categories, user sessions.
      If write volume becomes the bottleneck, we'd shard by user_id.
      User's orders are all on one shard → no cross-shard queries for 'my orders'."
```

---

## Trick 9: Numbers to Have Ready

| Metric | Typical Value | When to Mention |
|--------|---------------|-----------------|
| PostgreSQL single-server writes | 5K-20K writes/sec | When discussing write capacity |
| PostgreSQL single-server reads | 10K-50K reads/sec | When discussing read capacity |
| Redis GET latency | <1ms | When discussing caching |
| Redis throughput | 100K+ ops/sec | When discussing cache capacity |
| B-Tree index lookup | ~3-4 disk reads for 10M rows | When discussing indexes |
| Connection pool size | 10-20 connections | When discussing pooling |
| Replication lag (async) | 100ms-1s typical | When discussing consistency |
| INT max | ~2.1 billion | When discussing auto-increment IDs |
| BIGINT max | ~9.2 × 10^18 | When discussing ID overflow |
| PostgreSQL connection cost | ~10MB RAM per connection | When discussing pooling |

---

## Trick 10: Anti-Patterns to Recognize Instantly

| Anti-Pattern | Why It's Wrong | Say This Instead |
|-------------|----------------|-----------------|
| "One database for everything" | Different workloads need different DBs | "Polyglot: SQL for truth, Redis for cache, Elasticsearch for search" |
| "MongoDB for everything because it's flexible" | No ACID, no JOINs when you need them | "MongoDB for flexible schema; PostgreSQL where we need transactions" |
| "We'll shard from the beginning" | Premature complexity | "Start with single DB + replicas + cache. Shard only when needed." |
| "SELECT * everywhere" | Wastes bandwidth, prevents covering indexes | "Select only needed columns. Use covering indexes." |
| "No indexes, the ORM handles it" | ORMs don't auto-create indexes | "Index hot query paths. Check with EXPLAIN." |
| "Normalize everything" | Kills read performance at scale | "Normalize for truth. Denormalize hot read paths." |
| "Store everything in Redis" | Redis is not durable by default | "Redis for cache/sessions. PostgreSQL for durable source of truth." |

---

## Quick Memory Card

```
WHEN TO ADD DB:     Every system stores data. Discuss proactively.
DB SELECTION:       3 questions: ACID needed? Access pattern? Scale?
SQL DEFAULT:        PostgreSQL for almost everything structured
REDIS:              Cache, sessions, counters, leaderboards, rate limits
INDEX:              Equality → Range → Sort. Leftmost prefix. EXPLAIN.
SCALING ORDER:      Optimize → vertical → replicas → cache → shard
URL SHORTENER:      PG + Redis cache. Simple mapping.
CHAT:               Cassandra (messages) + PG (users) + Redis (status)
E-COMMERCE:         PG + ACID transactions + Redis (cart, cache)
FEED:               PG + Redis pre-computed feed
LEADERBOARD:        Redis ZADD/ZRANK
INTERVIEW FLOW:     Entities → relationships → choose DB → schema → index → scaling → stop
NUMBERS:            PG: 10K-50K reads, 5K-20K writes. Redis: <1ms, 100K ops/sec.
```

---

**Next:** [[08_Question-List]]
