# Greedy — Concept

> **Permanent Recall:** Greedy = make the locally optimal choice at each step, hoping it leads to global optimum. Works when **greedy choice property** + **optimal substructure** hold. FAANG tests: interval scheduling, jump games, task assignment. When greedy fails → DP.

---

## Core Idea (2 Lines)

**At each decision point, pick the option that looks best right now — without reconsidering. No backtracking. The key question: does this local choice always lead to a global optimum?**

---

## The Two Pillars (Must Both Hold)

| Property | Meaning | Example |
|----------|---------|---------|
| **Greedy Choice Property** | A globally optimal solution can be reached by making locally optimal choices | Activity selection: picking earliest-ending activity is always safe |
| **Optimal Substructure** | Optimal solution to problem contains optimal solutions to subproblems | After picking activity A, remaining problem is "max activities from A.end onward" |

```
If BOTH hold → Greedy works
If EITHER fails → Need DP or other approach
```

---

## Greedy vs DP — When Each Works

| Aspect | Greedy | Dynamic Programming |
|--------|--------|---------------------|
| **Choices** | Make one choice, never revisit | Consider all choices, pick best |
| **Subproblems** | One subproblem after each choice | Overlapping subproblems |
| **Proof** | Exchange argument / stays ahead | Optimal substructure + recurrence |
| **When greedy works** | Local optimum = global optimum | No such guarantee |
| **Classic fail** | 0/1 Knapsack (greedy gives wrong answer) | 0/1 Knapsack ✓ |

### The 0/1 Knapsack Trap

```
Items: (weight, value) — Capacity 10
  A: (10, 100)  → value/weight = 10
  B: (5, 50)    → value/weight = 10
  C: (5, 50)    → value/weight = 10

Greedy by value/weight: Pick A → value 100
Optimal: Pick B + C → value 100 (same here, but...)

Items: A(10, 100), B(5, 60), C(5, 60) — Capacity 10
Greedy: A → 100
Optimal: B + C → 120  ← Greedy FAILS
```

**Fractional knapsack** (can take fractions) → Greedy works (sort by value/weight, take greedily).

---

## Proof Strategies

### 1. Exchange Argument

- Take any optimal solution O
- Show: we can transform O to include our greedy choice without worsening
- Conclude: greedy choice is safe

```
Optimal picks activity ending at time T.
Our greedy picks activity ending at time T' ≤ T (earlier).
→ We can swap: our choice frees up more time.
→ Our solution is at least as good.
```

### 2. Greedy Stays Ahead

- Show: at each step, our greedy solution is "at least as good" as any optimal
- Inductive argument: base case + inductive step

```
Jump Game: Let G[i] = max reach with greedy, O[i] = with optimal.
Claim: G[i] >= O[i] for all i.
Base: G[0] = nums[0] = O[0]
Step: If G[i] >= O[i], then G[i+1] >= O[i+1] (greedy extends at least as far)
```

---

## Common Greedy Categories

| Category | Key Insight | Sort By | Example |
|----------|-------------|---------|---------|
| **Interval Scheduling** | Pick non-overlapping intervals | End time | Meeting Rooms II |
| **Activity Selection** | Max activities, no overlap | End time | Same as above |
| **Huffman Encoding** | Build tree from least-freq nodes | Frequency | Compression |
| **Fractional Knapsack** | Take best value per unit | value/weight | Resource allocation |
| **Task Scheduling** | Minimize lateness / maximize throughput | Deadline or duration | Task Scheduler |
| **Jump/Reach** | Track max reach, extend greedily | N/A (linear scan) | Jump Game I/II |

---

## When NOT to Use Greedy

- **0/1 Knapsack** — items indivisible, greedy fails
- **Longest Path** — no optimal substructure for greedy
- **Subset problems** where local choice affects future options in complex ways
- **When you need to try multiple choices** — that's DP/backtracking

---

## Golden Rules

1. **Sort first** — most greedy problems benefit from sorting (by end time, value/weight, deadline)
2. **One pass** — after sorting, often single linear scan
3. **Prove or justify** — interviewer will ask "why greedy?" — have exchange argument ready
4. **Check both properties** — greedy choice + optimal substructure before coding
5. **When in doubt** — if problem has "minimum number of...", "maximum non-overlapping...", "earliest...", think greedy first

---

## ASCII: Greedy Decision Flow

```
                    ┌─────────────────┐
                    │  New Problem    │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │ Can we sort?    │──No──► Consider: Jump Game, Gas Station
                    └────────┬────────┘        (linear scan greedy)
                             │ Yes
                    ┌────────▼────────┐
                    │ Sort by what?   │
                    │ • End time      │
                    │ • Start time    │
                    │ • Value/weight  │
                    │ • Deadline      │
                    └────────┬────────┘
                             │
                    ┌────────▼────────┐
                    │ Process in order│
                    │ Pick if valid   │
                    └─────────────────┘
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
GREEDY = Local optimum → hope for global
TWO PROPERTIES: Greedy choice + Optimal substructure (BOTH needed)
PROOF: Exchange argument OR Greedy stays ahead
FAIL: 0/1 knapsack (use DP)
WIN: Intervals (sort by end), Jump (max reach), Fractional knapsack (value/wt)
GOLDEN: Sort first, one pass, justify with exchange argument
```
