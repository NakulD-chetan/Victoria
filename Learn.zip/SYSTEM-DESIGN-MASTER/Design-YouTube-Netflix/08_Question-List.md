# Design YouTube/Netflix — Question List

> **Permanent Recall:** Variations often add **live streaming**, **YouTube Shorts / TikTok**, **content moderation**, **recommendation engine**, or **10M concurrent viewers**. Related designs: Twitch, Disney+, Vimeo — all video platforms with different constraints.

---

## Core Variations

| Question | Focus | Difficulty |
|----------|-------|------------|
| Design YouTube | Full system | Medium |
| Design Netflix | Same core; add catalog, recommendations emphasis | Medium |
| Add **live streaming** | Real-time transcode; HLS low-latency | Hard |
| Design **YouTube Shorts / TikTok** | Short-form; loop; different transcoding profile | Medium-Hard |
| Add **content moderation** | ML + human review; scale; block before publish | Hard |
| Design **recommendation engine** | Collaborative + content-based; ranking | Medium |
| Handle **10M concurrent viewers** on one video | CDN push; viral handling | Medium |

---

## Follow-Up / Deep-Dive Questions

| Question | What They Test |
|----------|----------------|
| How would you add live streaming? | Real-time pipeline; ingest → transcode → CDN |
| Design YouTube Shorts (short-form video) | Shorter chunks; loop; vertical; different recommendation |
| Add content moderation to video platform | ML classification; human queue; block before CDN |
| Design the recommendation engine | Collaborative filtering; content-based; cold start |
| Handle 10M concurrent viewers on one video | CDN pre-push; immutable chunks; horizontal scale |
| How does adaptive bitrate work? | HLS/DASH; manifest; client selection |
| What if transcoding fails? | Retry; dead-letter; partial fallback |
| Add copyright detection (Content ID) | Fingerprint; reference DB; block/claim |
| Design resumable upload for 10-hour video | Multipart; chunk idempotency |
| How would you delete a video? | CDN invalidation; purge across POPs |

---

## Related Designs

| Design | Overlap with YouTube/Netflix | Key Difference |
|--------|------------------------------|-----------------|
| **Twitch** | Video streaming; CDN; transcoding | Live-first; chat; different monetization |
| **Disney+** | VOD; CDN; catalog | Premium content; DRM; less UGC |
| **Vimeo** | Video hosting; transcoding | Creator-focused; less recommendation |
| **TikTok** | Short video; CDN; recommendations | Short-form; FYP algorithm; loop |
| **Instagram Reels** | Short video; CDN | Vertical; social graph; 90-sec |

---

## Full Question List (15+)

1. Design YouTube
2. Design Netflix
3. Add live streaming to YouTube
4. Design YouTube Shorts / TikTok
5. Add content moderation to a video platform
6. Design the recommendation engine for Netflix
7. Handle 10M concurrent viewers on one video
8. How does adaptive bitrate streaming work?
9. Design the video upload pipeline
10. What if transcoding fails?
11. Add copyright detection (Content ID)
12. Design resumable upload for large video files
13. How would you delete a video from the system?
14. Design search for YouTube
15. Design Twitch (live streaming platform)
16. Add video to Instagram (Reels)
17. Design Disney+ (premium streaming)

---

## Difficulty Guide

| Difficulty | Questions |
|------------|-----------|
| **Medium** | Core YouTube/Netflix, upload pipeline, 10M concurrent, search, recommendations |
| **Medium-Hard** | Shorts/TikTok, content moderation |
| **Hard** | Live streaming, full recommendation engine, Content ID |

> **FAANG Tip:** "Add live streaming" = VOD pipeline + real-time transcode + low-latency HLS. Cover ingest, real-time workers, and CDN for live.

---

## Prep Strategy

1. **Master core** — Upload (transcoding DAG) + Streaming (CDN, adaptive bitrate)
2. **Two paths** — Never conflate; design separately
3. **Live variation** — Real-time transcode; different from VOD
4. **Short-form** — Shorter chunks; different UX; similar pipeline
5. **Related** — Twitch (live), Disney+ (VOD + DRM), TikTok (short + algo)

---

## Quick Reference: What to Design per Question

| Question | Must Include |
|----------|--------------|
| YouTube/Netflix | Two pipelines; transcoding; CDN; adaptive bitrate |
| + Live streaming | Real-time transcode; ingest; HLS low-latency |
| + Shorts/TikTok | Short chunks; vertical; loop; recommendation |
| + Moderation | ML pipeline; review queue; block before publish |
| + 10M concurrent | CDN pre-push; immutable chunks |
| + Recommendations | Collaborative + content-based |

---

## Bonus Questions

18. Design **video analytics** (watch time, drop-off)
19. Add **subtitles/captions** to the platform
20. Design **multi-region** video delivery
21. How would you **migrate** from single-region to global?
22. Design **ad insertion** in video streaming
23. Add **DRM** for premium content

---

## Cross-Reference

- **Design Instagram** → Photos; lighter processing; similar CDN
- **Design TikTok** → Short video; FYP algorithm; similar pipeline
- **Design Twitch** → Live streaming; chat; similar CDN

---

## Summary

17+ question variations; core = YouTube/Netflix + live + Shorts + moderation + 10M concurrent. Master two-pipeline design and transcoding; then variations. Related: Twitch, Disney+, Vimeo, TikTok.

---

## Last-Minute Prep

Before interview: Review 01_Concept (numbers), 02_Mental-Model (two paths), 03_Design-Template (diagram), 05_Common-Mistakes (avoid list).

---

## Question Mapping

- "YouTube" / "Netflix" → Full VOD system
- "+ live" → Add real-time pipeline
- "+ Shorts" / "+ TikTok" → Short-form; different transcoding profile
- "+ moderation" → ML + human in pipeline
- "10M concurrent" → CDN pre-push; viral handling
