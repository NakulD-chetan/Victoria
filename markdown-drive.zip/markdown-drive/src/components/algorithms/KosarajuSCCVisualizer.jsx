import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: kosaraju-scc */
const GRAPH = {
  nodes: [
    { id: '0', x: 120, y: 200, label: '0' },
    { id: '1', x: 260, y: 120, label: '1' },
    { id: '2', x: 400, y: 120, label: '2' },
    { id: '3', x: 260, y: 280, label: '3' },
    { id: '4', x: 400, y: 280, label: '4' },
    { id: '5', x: 540, y: 200, label: '5' },
  ],
  edges: [
    { from: '0', to: '1', directed: true },
    { from: '1', to: '2', directed: true },
    { from: '2', to: '0', directed: true },
    { from: '2', to: '3', directed: true },
    { from: '3', to: '4', directed: true },
    { from: '4', to: '5', directed: true },
    { from: '5', to: '3', directed: true },
  ],
};

function buildAdj(list, reverse) {
  const adj = {};
  GRAPH.nodes.forEach((n) => { adj[n.id] = []; });
  list.forEach((e) => {
    if (reverse) adj[e.to].push(e.from);
    else adj[e.from].push(e.to);
  });
  return adj;
}

function dfsOrder(adj) {
  const visited = new Set();
  const order = [];
  function dfs(u) {
    visited.add(u);
    for (const v of adj[u]) {
      if (!visited.has(v)) dfs(v);
    }
    order.push(u);
  }
  GRAPH.nodes.forEach((n) => {
    if (!visited.has(n.id)) dfs(n.id);
  });
  return order;
}

function dfsComp(adj, start, visited, comp) {
  visited.add(start);
  comp.push(start);
  for (const v of adj[start]) {
    if (!visited.has(v)) dfsComp(adj, v, visited, comp);
  }
}

function generateSteps() {
  const steps = [];
  const adj = buildAdj(GRAPH.edges, false);
  steps.push({ type: 'pass1-start', nodeColors: {}, edgeColors: {} });
  const finish = dfsOrder(adj);
  steps.push({ type: 'pass1-done', nodeColors: Object.fromEntries(finish.map((id) => [id, 'visited'])), edgeColors: {}, order: [...finish] });
  steps.push({ type: 'transpose', nodeColors: {}, edgeColors: {} });
  const radj = buildAdj(GRAPH.edges, true);
  const visited = new Set();
  finish.reverse().forEach((u) => {
    if (visited.has(u)) return;
    const comp = [];
    dfsComp(radj, u, visited, comp);
    steps.push({
      type: 'pass2-comp',
      nodeColors: Object.fromEntries(comp.map((id) => [id, 'processing'])),
      edgeColors: {},
      comp,
    });
    steps.push({
      type: 'scc',
      nodeColors: Object.fromEntries(comp.map((id) => [id, 'visited'])),
      edgeColors: {},
      comp,
    });
  });
  steps.push({ type: 'done', nodeColors: Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function KosarajuSCCVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Kosaraju two-pass SCC' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: {},
      queue: step.order || [],
      stack: step.comp || [],
      distances: {},
      visited: step.comp || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
