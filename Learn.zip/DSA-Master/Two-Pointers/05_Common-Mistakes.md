# Two Pointers — Common Mistakes

> **Every mistake here has been made in real FAANG interviews. Learn WHY they happen so you never repeat them.**

---

## Mistake 1: Wrong Boundary — `left <= right` vs `left < right`

### The Mistake
```python
# WRONG for pair sum: using left <= right
while left <= right:
    # When left == right, we're "pairing" element with itself!
    current = arr[left] + arr[right]  # Same element twice
```

### Why It Happens
- Confusion: "We need to check all elements" → but for **pairs**, we need two **different** indices
- When `left == right`, we're using the same element twice (invalid pair)

### The Fix
```python
# CORRECT: left < right ensures two distinct indices
while left < right:
    current = arr[left] + arr[right]
```

### Exception
- **Partition (Dutch Flag):** Use `mid <= high` because mid and high are different roles (mid scans, high is boundary)
- **Binary search:** Uses `left <= right` (different context—searching for single element)

### Golden Rule
> **Pair/triplet problems: `left < right`. Never use same index twice.**

---

## Mistake 2: Skipping Duplicates Incorrectly in 3Sum

### The Mistake
```python
# WRONG: Only skipping at i, not after finding a match
for i in range(n - 2):
    if i > 0 and arr[i] == arr[i-1]:
        continue
    left, right = i + 1, n - 1
    while left < right:
        if total == target:
            result.append([...])
            left += 1   # BUG: might add duplicate triplet!
            right -= 1
```

### Why It Happens
- After finding [-1, 0, 1], if we just do left++, and arr[left] is still 0, we might get [-1, 0, 1] again with a different right
- Actually: when we find a match, BOTH left and right could have duplicates. We need to skip ALL duplicates for left (and optionally right)

### The Fix
```python
if total == target:
    result.append([arr[i], arr[left], arr[right]])
    left += 1
    while left < right and arr[left] == arr[left - 1]:  # Skip duplicate left
        left += 1
    # Optionally: right -= 1 and skip duplicate right (redundant if we skip left)
```

### Golden Rule
> **When you find a match in 3Sum, advance left past ALL duplicates. Right will naturally move when sum changes.**

---

## Mistake 3: Infinite Loop in Linked List Cycle

### The Mistake
```python
# WRONG: Both start at head — infinite loop when cycle exists!
slow = head
fast = head
while slow != fast:  # They start equal! Loop never enters, or...
    slow = slow.next
    fast = fast.next.next
# If we use do-while, we never check for null
```

### Why It Happens
- If slow and fast both start at head, they're equal initially—loop condition may never be true, or we need do-while
- If we use `while`, we need them different initially. Standard fix: `fast = head.next`

### The Fix
```python
# CORRECT: fast starts one step ahead
slow = head
fast = head.next
while slow != fast:
    if not fast or not fast.next:
        return False
    slow = slow.next
    fast = fast.next.next
return True
```

### Alternative (do-while style)
```python
slow = fast = head
while True:
    if not fast or not fast.next:
        return False
    slow = slow.next
    fast = fast.next.next
    if slow == fast:
        return True
```

### Golden Rule
> **For cycle detection: fast must start at head.next (or use do-while). Check fast and fast.next for null before advancing.**

---

## Mistake 4: Off-by-One in Partition / Move Zeros

### The Mistake
```python
# WRONG: write pointer starts at 0 but we overwrite first element
write = 0
for read in range(len(arr)):
    if arr[read] != 0:
        arr[write] = arr[read]
        write += 1
# Actually this is correct for move zeros! Let me check...

# WRONG for remove duplicates:
write = 0  # Should be 1 — we keep first element
for read in range(1, len(arr)):
    if arr[read] != arr[read-1]:
        arr[write] = arr[read]
        write += 1
# With write=0, we'd overwrite arr[0] when read=1 and arr[1]!=arr[0]
# Actually write=1 is correct: first element stays, write is next position
```

### The Mistake (Clearer)
```python
# WRONG: For "move zeros", using write = 1
# When first element is non-zero, we'd skip it
write = 1
for read in range(len(arr)):
    if arr[read] != 0:
        arr[write] = arr[read]  # Overwrites arr[1] first — wrong if arr[0] was non-zero
```

### Why It Happens
- Confusion about what `write` represents: "next position to write" vs "last written position"
- For move zeros: write = next position for non-zero. First non-zero goes to index 0, so write starts at 0 ✓
- For remove dup: first element stays at 0, write = next slot, so write=1 ✓

### Golden Rule
> **write = index of next position to fill. For move zeros: write=0. For remove dup (sorted): write=1.**

---

## Mistake 5: Not Handling Already-Sorted Assumption

### The Mistake
```python
# WRONG: Using two pointers on UNSORTED array for pair sum
def two_sum(arr, target):  # arr not sorted
    left, right = 0, len(arr) - 1
    while left < right:
        # Moving left/right based on sum is MEANINGLESS — no monotonicity!
        ...
```

### Why It Happens
- Assuming two-pointer works for any array
- The whole point: sorted order tells us "sum too big → decrease right" etc. Without sort, we have no direction

### The Fix
- Either **sort first** (if we don't need original indices): O(n log n) + O(n) = O(n log n)
- Or use **Hash Map**: O(n) time, O(n) space, preserves index information

### Golden Rule
> **Opposite-direction two pointers REQUIRE sorted order. No sort → use Hash Map.**

---

## Mistake 6: Advancing Mid When Swapping with High (Dutch Flag)

### The Mistake
```python
# WRONG: Incrementing mid when we swap with high
elif arr[mid] == 2:
    arr[mid], arr[high] = arr[high], arr[mid]
    high -= 1
    mid += 1  # BUG! We might have brought a 0 or 1 to mid — need to process it
```

### Why It Happens
- Thinking "we've processed mid" — but we replaced arr[mid] with an unknown value from the end
- The new arr[mid] could be 0 (should go to low) or 1 (should stay) — we must re-check

### The Fix
```python
else:  # arr[mid] == 2
    arr[mid], arr[high] = arr[high], arr[mid]
    high -= 1
    # Do NOT increment mid
```

### Golden Rule
> **Dutch Flag: When swapping mid with high, only decrement high. Re-process the new arr[mid].**

---

## Mistake 7: Wrong Loop Condition for Merge (Writing from End)

### The Mistake
```python
# WRONG: Writing from start, then overwriting
# Or: not handling remaining elements in nums2
while p1 >= 0 and p2 >= 0:
    ...
# Forgot: what if nums2 has remaining elements?
```

### Why It Happens
- nums1 has size m+n. If nums2 has larger elements, they go first. If nums2 has smaller elements, they go later. When p1 hits -1, we still need to copy remaining nums2.
- If we forget the second while, we leave garbage in nums1

### The Fix
```python
while p1 >= 0 and p2 >= 0:
    ...
while p2 >= 0:  # Copy remaining from nums2
    nums1[write] = nums2[p2]
    p2 -= 1
    write -= 1
# No need for "while p1 >= 0" — those are already in place
```

### Golden Rule
> **Merge into nums1: After main loop, copy remaining nums2. nums1 remaining elements are already in place.**

---

## Mistake 8: Palindrome — Forgetting to Skip Non-Alphanumeric

### The Mistake
```python
# WRONG: Comparing spaces and punctuation
def is_palindrome(s):
    left, right = 0, len(s) - 1
    while left < right:
        if s[left] != s[right]:  # "A man a plan" — ' ' != 'n'
            return False
        left += 1
        right -= 1
```

### Why It Happens
- Problem says "alphanumeric only" or "ignore spaces/punctuation"
- We must skip non-alphanumeric characters

### The Fix
```python
while left < right:
    if not s[left].isalnum():
        left += 1
        continue
    if not s[right].isalnum():
        right -= 1
        continue
    if s[left].lower() != s[right].lower():
        return False
    left += 1
    right -= 1
```

### Golden Rule
> **Valid Palindrome: Skip non-alphanumeric. Use tolower for case-insensitive.**

---

## Mistake 9: Returning Wrong Index Format (1-Indexed vs 0-Indexed)

### The Mistake
```python
# Problem says "return 1-indexed"
return [left, right]  # WRONG: should be [left+1, right+1]
```

### Why It Happens
- Problem statement says "1-indexed" but we code in 0-indexed
- Easy to forget the +1

### The Fix
```python
return [left + 1, right + 1]
```

### Golden Rule
> **Always check: "Return 0-indexed or 1-indexed?"**

---

## Mistake 10: Not Handling "No Solution" Case

### The Mistake
```python
# WRONG: No return when no pair found
def two_sum_sorted(arr, target):
    left, right = 0, len(arr) - 1
    while left < right:
        if arr[left] + arr[right] == target:
            return [left, right]
        # ...
    # Falls through — returns None. Is that correct? Problem may want []
```

### Why It Happens
- Assuming a solution always exists
- Not reading problem: "return empty list if no pair"

### The Fix
```python
return []  # or [-1, -1] or None — match problem spec
```

### Golden Rule
> **Always handle the "no solution" case explicitly. Match problem's expected return.**

---

## Mistake Summary Table

| # | Mistake | Root Cause | Fix |
|---|---------|-----------|-----|
| 1 | left <= right for pairs | Same index twice | Use left < right |
| 2 | Duplicate triplets in 3Sum | Not skipping after match | Advance left past duplicates |
| 3 | Infinite loop in cycle | slow==fast initially | fast = head.next |
| 4 | Off-by-one in partition | Wrong write init | write=0 for zeros, write=1 for dedup |
| 5 | Two pointers on unsorted | No monotonicity | Sort or use Hash Map |
| 6 | mid++ when swap with high | Skip re-check | Don't advance mid |
| 7 | Merge: forget nums2 remainder | Incomplete copy | while p2>=0: copy |
| 8 | Palindrome: compare non-alnum | Wrong chars | Skip non-alphanumeric |
| 9 | Wrong index format | 0 vs 1-indexed | Add +1 if 1-indexed |
| 10 | No "no solution" handling | Assume solution exists | Return [] or spec |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Two Pointers Mistakes
PAIR BOUNDARY:      left < right (never same index)
3SUM DUP:           Skip duplicate left after match
CYCLE INIT:         fast = head.next (or do-while)
DUTCH FLAG:         Swap with high → high-- only, NOT mid++
SORTED REQUIRED:    Opposite-direction needs sorted array
MERGE REMAINDER:    Copy rest of nums2 after main loop
PALINDROME:         Skip non-alnum, use lower()
INDEX FORMAT:       Check 0 vs 1-indexed
NO SOLUTION:        Return [] or per spec
INTERVIEW LINE:     "Let me verify: for pairs I use left<right, and I'm
                     skipping duplicates correctly in 3Sum."
```
