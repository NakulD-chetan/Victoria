# System-Patterns — Coding Template

> **Permanent Recall:** Memorize these templates for BIT, monotonic stack, BS on answer, sweep line, two-pass, and divide-and-conquer. Python for speed, C++ for STL, Rust for correctness.

---

## 1. Binary Indexed Tree (Fenwick Tree)

### Python

```python
class FenwickTree:
    def __init__(self, n: int):
        self.n = n
        self.tree = [0] * (n + 1)

    def _lsb(self, i: int) -> int:
        return i & (-i)

    def update(self, i: int, delta: int) -> None:
        i += 1  # 1-indexed
        while i <= self.n:
            self.tree[i] += delta
            i += self._lsb(i)

    def query(self, i: int) -> int:  # prefix sum [0, i]
        i += 1
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= self._lsb(i)
        return s

    def range_query(self, l: int, r: int) -> int:
        return self.query(r) - self.query(l - 1)
```

### C++

```cpp
struct FenwickTree {
    int n;
    vector<long long> tree;

    FenwickTree(int n) : n(n), tree(n + 1, 0) {}

    int lsb(int i) { return i & (-i); }

    void update(int i, long long delta) {
        i++;
        while (i <= n) {
            tree[i] += delta;
            i += lsb(i);
        }
    }

    long long query(int i) {
        i++;
        long long s = 0;
        while (i > 0) {
            s += tree[i];
            i -= lsb(i);
        }
        return s;
    }

    long long rangeQuery(int l, int r) {
        return query(r) - query(l - 1);
    }
};
```

### Rust

```rust
pub struct FenwickTree {
    n: usize,
    tree: Vec<i64>,
}

impl FenwickTree {
    pub fn new(n: usize) -> Self {
        FenwickTree {
            n,
            tree: vec![0; n + 1],
        }
    }

    fn lsb(&self, i: usize) -> usize {
        i & i.wrapping_neg()
    }

    pub fn update(&mut self, mut i: usize, delta: i64) {
        i += 1;
        while i <= self.n {
            self.tree[i] += delta;
            i += self.lsb(i);
        }
    }

    pub fn query(&self, mut i: usize) -> i64 {
        i += 1;
        let mut s = 0i64;
        while i > 0 {
            s += self.tree[i];
            i -= self.lsb(i);
        }
        s
    }

    pub fn range_query(&self, l: usize, r: usize) -> i64 {
        self.query(r) - if l > 0 { self.query(l - 1) } else { 0 }
    }
}
```

---

## 2. Monotonic Stack (Next Greater Element)

### Python

```python
def next_greater_element(nums: list[int]) -> list[int]:
    n = len(nums)
    result = [-1] * n
    stack = []  # indices, decreasing values
    for i in range(n):
        while stack and nums[stack[-1]] < nums[i]:
            j = stack.pop()
            result[j] = nums[i]
        stack.append(i)
    return result
```

### C++

```cpp
vector<int> nextGreaterElement(vector<int>& nums) {
    int n = nums.size();
    vector<int> result(n, -1);
    stack<int> st;  // indices
    for (int i = 0; i < n; i++) {
        while (!st.empty() && nums[st.top()] < nums[i]) {
            result[st.top()] = nums[i];
            st.pop();
        }
        st.push(i);
    }
    return result;
}
```

### Rust

```rust
fn next_greater_element(nums: &[i32]) -> Vec<i32> {
    let n = nums.len();
    let mut result = vec![-1; n];
    let mut stack: Vec<usize> = Vec::new();
    for i in 0..n {
        while let Some(&j) = stack.last() {
            if nums[j] >= nums[i] { break; }
            result[j] = nums[i];
            stack.pop();
        }
        stack.push(i);
    }
    result
}
```

---

## 3. Binary Search on Answer Framework

### Python

```python
def binary_search_on_answer(arr: list[int], check) -> int:
    lo, hi = min(arr), max(arr)  # or problem-specific bounds
    while lo < hi:
        mid = (lo + hi) // 2
        if check(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo

# Example: Koko Eating Bananas
def min_eating_speed(piles: list[int], h: int) -> int:
    def feasible(k: int) -> bool:
        return sum((p + k - 1) // k for p in piles) <= h
    lo, hi = 1, max(piles)
    while lo < hi:
        mid = (lo + hi) // 2
        if feasible(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo
```

### C++

```cpp
template<typename F>
int binarySearchOnAnswer(int lo, int hi, F&& check) {
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        if (check(mid)) hi = mid;
        else lo = mid + 1;
    }
    return lo;
}

int minEatingSpeed(vector<int>& piles, int h) {
    int lo = 1, hi = *max_element(piles.begin(), piles.end());
    auto feasible = [&](int k) {
        long long hours = 0;
        for (int p : piles) hours += (p + k - 1) / k;
        return hours <= h;
    };
    return binarySearchOnAnswer(lo, hi, feasible);
}
```

### Rust

```rust
fn binary_search_on_answer<F>(mut lo: i64, mut hi: i64, check: F) -> i64
where F: Fn(i64) -> bool {
    while lo < hi {
        let mid = lo + (hi - lo) / 2;
        if check(mid) {
            hi = mid;
        } else {
            lo = mid + 1;
        }
    }
    lo
}

fn min_eating_speed(piles: Vec<i32>, h: i32) -> i32 {
    let max_pile = *piles.iter().max().unwrap() as i64;
    let feasible = |k: i64| {
        piles.iter().map(|&p| ((p as i64 + k - 1) / k)).sum::<i64>() <= h as i64
    };
    binary_search_on_answer(1, max_pile, feasible) as i32
}
```

---

## 4. Sweep Line for Intervals

### Python

```python
def min_meeting_rooms(intervals: list[list[int]]) -> int:
    events = []
    for start, end in intervals:
        events.append((start, 1))
        events.append((end, -1))
    events.sort(key=lambda x: (x[0], x[1]))
    cur, ans = 0, 0
    for _, delta in events:
        cur += delta
        ans = max(ans, cur)
    return ans
```

### C++

```cpp
int minMeetingRooms(vector<vector<int>>& intervals) {
    vector<pair<int, int>> events;
    for (auto& iv : intervals) {
        events.push_back({iv[0], 1});
        events.push_back({iv[1], -1});
    }
    sort(events.begin(), events.end(), [](auto& a, auto& b) {
        return a.first < b.first || (a.first == b.first && a.second < b.second);
    });
    int cur = 0, ans = 0;
    for (auto& [_, d] : events) {
        cur += d;
        ans = max(ans, cur);
    }
    return ans;
}
```

### Rust

```rust
fn min_meeting_rooms(intervals: Vec<Vec<i32>>) -> i32 {
    let mut events: Vec<(i32, i32)> = Vec::new();
    for iv in intervals {
        events.push((iv[0], 1));
        events.push((iv[1], -1));
    }
    events.sort_by(|a, b| a.0.cmp(&b.0).then(a.1.cmp(&b.1)));
    let (mut cur, mut ans) = (0, 0);
    for (_, d) in events {
        cur += d;
        ans = ans.max(cur);
    }
    ans
}
```

---

## 5. Two-Pass Technique (Product Except Self)

### Python

```python
def product_except_self(nums: list[int]) -> list[int]:
    n = len(nums)
    result = [1] * n
    left = 1
    for i in range(n):
        result[i] = left
        left *= nums[i]
    right = 1
    for i in range(n - 1, -1, -1):
        result[i] *= right
        right *= nums[i]
    return result
```

### C++

```cpp
vector<int> productExceptSelf(vector<int>& nums) {
    int n = nums.size();
    vector<int> result(n, 1);
    int left = 1;
    for (int i = 0; i < n; i++) {
        result[i] = left;
        left *= nums[i];
    }
    int right = 1;
    for (int i = n - 1; i >= 0; i--) {
        result[i] *= right;
        right *= nums[i];
    }
    return result;
}
```

### Rust

```rust
fn product_except_self(nums: Vec<i32>) -> Vec<i32> {
    let n = nums.len();
    let mut result = vec![1; n];
    let mut left = 1i32;
    for i in 0..n {
        result[i] = left;
        left *= nums[i];
    }
    let mut right = 1i32;
    for i in (0..n).rev() {
        result[i] *= right;
        right *= nums[i];
    }
    result
}
```

---

## 6. Divide and Conquer (Merge Sort Pattern)

### Python

```python
def merge_sort(arr: list[int], lo: int, hi: int) -> None:
    if lo >= hi:
        return
    mid = (lo + hi) // 2
    merge_sort(arr, lo, mid)
    merge_sort(arr, mid + 1, hi)
    merge(arr, lo, mid, hi)

def merge(arr: list[int], lo: int, mid: int, hi: int) -> None:
    left = arr[lo:mid + 1]
    right = arr[mid + 1:hi + 1]
    i = j = 0
    k = lo
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            arr[k] = left[i]
            i += 1
        else:
            arr[k] = right[j]
            j += 1
        k += 1
    arr[k:hi + 1] = left[i:] + right[j:]
```

### C++

```cpp
void mergeSort(vector<int>& arr, int lo, int hi) {
    if (lo >= hi) return;
    int mid = lo + (hi - lo) / 2;
    mergeSort(arr, lo, mid);
    mergeSort(arr, mid + 1, hi);
    merge(arr, lo, mid, hi);
}

void merge(vector<int>& arr, int lo, int mid, int hi) {
    vector<int> left(arr.begin() + lo, arr.begin() + mid + 1);
    vector<int> right(arr.begin() + mid + 1, arr.begin() + hi + 1);
    int i = 0, j = 0, k = lo;
    while (i < left.size() && j < right.size()) {
        if (left[i] <= right[j]) arr[k++] = left[i++];
        else arr[k++] = right[j++];
    }
    while (i < left.size()) arr[k++] = left[i++];
    while (j < right.size()) arr[k++] = right[j++];
}
```

### Rust

```rust
fn merge_sort(arr: &mut [i32]) {
    let n = arr.len();
    if n <= 1 { return; }
    let mid = n / 2;
    merge_sort(&mut arr[..mid]);
    merge_sort(&mut arr[mid..]);
    merge(arr, mid);
}

fn merge(arr: &mut [i32], mid: usize) {
    let left = arr[..mid].to_vec();
    let right = arr[mid..].to_vec();
    let (mut i, mut j, mut k) = (0, 0, 0);
    while i < left.len() && j < right.len() {
        if left[i] <= right[j] {
            arr[k] = left[i];
            i += 1;
        } else {
            arr[k] = right[j];
            j += 1;
        }
        k += 1;
    }
    arr[k..].copy_from_slice(if i < left.len() { &left[i..] } else { &right[j..] });
}
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
BIT:          update(i, d): i++; while i<=n tree[i]+=d, i+=lsb(i)
              query(i): i++; while i>0 s+=tree[i], i-=lsb(i)
MONOTONIC:    stack of indices, pop while condition, push i
BS ON ANS:    lo, hi; mid; if check(mid): hi=mid else lo=mid+1
SWEEP:        events (start,+1),(end,-1); sort; cur+=d; ans=max(ans,cur)
TWO-PASS:     left pass, right pass, combine in result
D&C:          if lo>=hi return; mid; recurse; merge
```

---

## 30-SECOND REVISION BOX

```
□ BIT: lsb=i&-i; update add, query subtract
□ Monotonic: while stack and cond: pop; append i
□ BS: while lo<hi: mid; check(mid)? hi=mid : lo=mid+1
□ Sweep: events, sort, cur+=delta
□ Two-pass: left product, right product, multiply
□ D&C: split, recurse, merge
```
