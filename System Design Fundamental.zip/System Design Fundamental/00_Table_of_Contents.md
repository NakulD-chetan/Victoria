# System Design — Complete FAANG-Ready Master Notes

> **Style:** Hindi + English mix (Tree Notes jaisa) + Easy explanations
> **Level:** Beginner → Intermediate → FAANG Interview Ready
> **Goal:** Koi bhi system confidently design kar sako — interviews mein ya real world mein

---

## Notes Structure

| # | File | Topics Covered | Level |
|---|------|----------------|-------|
| 01 | [[01_System_Design_Kya_Hai]] | System Design kya hai, Kyu zaroori hai, Interview Framework, Trade-offs, Building Blocks, Evolution | Beginner |
| 02 | [[02_Scalability]] | Vertical vs Horizontal, Stateless Design, Read/Write Scaling, Bottleneck Finding, Auto-Scaling | Beginner-Medium |
| 03 | [[03_Load_Balancing]] | Algorithms (Round Robin, Least Conn, Hashing), L4 vs L7, Health Checks, HA | Medium |
| 04 | [[04_Caching]] | Cache-Aside, Write-Through, Write-Behind, LRU/LFU, Redis vs Memcached, Thundering Herd | Medium |
| 05 | [[05_CDN]] | Push vs Pull CDN, Edge Caching, Cache Invalidation, Real-world Examples | Medium |
| 06 | [[06_CAP_Theorem_and_Consistency]] | CAP Theorem, Consistency Models (Strong, Eventual, Causal), PACELC | Medium-Hard |
| 07 | [[07_Availability_Reliability_SLA]] | Nines of Availability, SLA/SLO/SLI, Fault Tolerance, Redundancy | Medium |
| 08 | [[08_Database_Fundamentals]] | SQL vs NoSQL, ACID vs BASE, Indexing (B-Tree, Hash), Transactions | Medium |
| 09 | [[09_Database_Scaling]] | Sharding, Replication, Partitioning, Consistent Hashing, Connection Pooling | Medium-Hard |
| 10 | [[10_Architecture_Patterns]] | Monolith vs Microservices, API Gateway, Service Discovery, Service Mesh | Medium-Hard |
| 11 | [[11_Message_Queues_and_Events]] | Kafka, RabbitMQ, Pub/Sub, Event Driven Architecture, CQRS, Event Sourcing | Medium-Hard |
| 12 | [[12_Resilience_Patterns]] | Rate Limiting, Circuit Breaker, Bulkhead, Retry, Backoff, Idempotency | Medium-Hard |
| 13 | [[13_Distributed_Systems]] | Consensus, Leader Election, Distributed Locking, Heartbeat, Failure Handling | Hard |
| 14 | [[14_Back_of_Envelope]] | Latency Numbers, Capacity Planning, QPS Calculation, Storage Estimation | Medium |
| 15 | [[15_Interview_Framework]] | Step-by-Step Answering, Checklist, Red Flags, Whiteboard Strategy, FAANG Tips | Medium |
| 16 | [[16_Design_URL_Shortener]] | Requirements, Estimation, Hash Algorithm, DB Design, Scaling, Analytics | Medium |
| 17 | [[17_Design_Instagram_Twitter]] | Feed System, Fan-out, Media Storage, Timeline, Ranking, Notifications | Hard |
| 18 | [[18_Design_WhatsApp_Chat]] | WebSocket, Message Queue, Delivery Guarantee, Presence, Group Chat | Hard |
| 19 | [[19_Design_YouTube_Netflix]] | Video Upload, Transcoding, CDN, Adaptive Bitrate, Recommendation | Hard |
| 20 | [[20_Design_Uber]] | Geospatial Index, Real-time Matching, Surge Pricing, ETA Calculation | Hard |
| 21 | [[21_Design_Notification_Payment]] | Push/Pull Notification, Payment Gateway, Idempotency, Retry | Hard |
| 22 | [[22_Design_Cache_Search]] | Distributed Cache Design, Search Engine, Inverted Index, Ranking | Hard |
| 23 | [[23_Golden_Rules_and_Mistakes]] | 20 Golden Rules, Anti-Patterns, Common Mistakes, Memory Tricks | Medium |
| 24 | [[24_Quick_Revision]] | 1-Page Summary per topic, Cheat Sheets, Decision Trees, Formula Cards | All |

---

## Quick Revision Path

### Interview ke 1 din pehle (2 hour revision):
```
24 → Quick Revision (sab topics ka summary)
23 → Golden Rules + Common Mistakes
15 → Interview Framework (step-by-step kaise answer karna hai)
14 → Back of Envelope (numbers yaad karo)
```

### Full Interview Prep (1-2 weeks):
```
01-05 → Foundation strong karo (System Design, Scalability, LB, Cache, CDN)
06-09 → Core concepts (CAP, Availability, Database, Sharding)
10-13 → Architecture + Distributed Systems
14-15 → Estimation + Interview Framework
16-22 → Real System Designs (practice karo)
23-24 → Revision + Golden Rules
```

---

## Complete Topic Flow (Knowledge Tree)

```
System Design (FAANG Ready)
│
├── FOUNDATION ──────────────────────────────────────
│   ├── System Design Kya Hai ─────────────────── [01]
│   ├── Scalability (Vertical vs Horizontal) ──── [02]
│   ├── Load Balancing ────────────────────────── [03]
│   ├── Caching ───────────────────────────────── [04]
│   └── CDN ───────────────────────────────────── [05]
│
├── CORE CONCEPTS ───────────────────────────────────
│   ├── CAP Theorem + Consistency Models ──────── [06]
│   ├── Availability, Reliability, SLA/SLO ────── [07]
│   ├── Database Fundamentals ─────────────────── [08]
│   └── Database Scaling ──────────────────────── [09]
│
├── ARCHITECTURE ────────────────────────────────────
│   ├── Monolith vs Microservices ─────────────── [10]
│   ├── Message Queues + Event Driven ─────────── [11]
│   ├── Resilience Patterns ───────────────────── [12]
│   └── Distributed Systems ───────────────────── [13]
│
├── INTERVIEW SKILLS ────────────────────────────────
│   ├── Back of Envelope Estimation ───────────── [14]
│   └── Interview Framework ───────────────────── [15]
│
├── REAL SYSTEM DESIGNS ─────────────────────────────
│   ├── URL Shortener (bit.ly) ────────────────── [16]
│   ├── Instagram + Twitter ───────────────────── [17]
│   ├── WhatsApp + Chat System ────────────────── [18]
│   ├── YouTube + Netflix ─────────────────────── [19]
│   ├── Uber ──────────────────────────────────── [20]
│   ├── Notification + Payment ────────────────── [21]
│   └── Distributed Cache + Search ────────────── [22]
│
└── REVISION ────────────────────────────────────────
    ├── Golden Rules + Common Mistakes ────────── [23]
    └── Quick Revision (All-in-One) ───────────── [24]
```

---

## Key Formulas — One Place

| Formula | Value |
|---------|-------|
| QPS from DAU | `DAU × requests_per_user / 86400` |
| Peak QPS | `Average QPS × 2 to 5` |
| Storage | `Users × data_per_user × retention_days` |
| Bandwidth | `QPS × response_size` |
| Servers needed | `Peak QPS / QPS_per_server` |
| Availability (series) | `A1 × A2 × A3...` |
| Availability (parallel) | `1 - (1-A1)(1-A2)` |
| Shards needed | `Total_data / Shard_capacity` |
| Cache hit ratio | `Hits / (Hits + Misses)` |
| Replication lag | `~100ms - 1 second (typical)` |

---

## Important One-Liners (Yaad Rakhne Wale)

| Quote | Topic |
|-------|-------|
| *"No silver bullet — har solution ka ek cost hai"* | Trade-offs |
| *"Scale the bottleneck, not everything"* | Scalability |
| *"Stateless = freedom to scale"* | Horizontal Scaling |
| *"Cache reads, not writes"* | Caching |
| *"Design for failure, not for success"* | Reliability |
| *"CAP mein P forced hai — choose C or A"* | CAP Theorem |
| *"Reads = Replicas, Writes = Shards"* | Database Scaling |
| *"Async when you can, sync when you must"* | Architecture |
| *"Measure before optimize"* | Performance |
| *"80% traffic 20% data pe aata hai"* | Caching (80/20 Rule) |

---

*Total: 24 topic files + this index | Hinglish style | Beginner to FAANG Ready*
*Har topic mein: Problem → Concept → Working → Example → Interview Qs → Quick Recall*
