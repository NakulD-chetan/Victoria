# Scalability — System Ko Bada Kaise Karo

> **Scalability = System load badhne pe bhi smoothly kaam kare**
> Restaurant analogy se samjho — easy hai!

---

## Table of Contents
1. [Scalability Kya Hai?](#1-scalability-kya-hai)
2. [Performance vs Scalability](#2-performance-vs-scalability)
3. [Vertical Scaling (Scale Up)](#3-vertical-scaling-scale-up)
4. [Horizontal Scaling (Scale Out)](#4-horizontal-scaling-scale-out)
5. [Stateless Principle](#5-stateless-principle)
6. [Read Scaling vs Write Scaling](#6-read-scaling-vs-write-scaling)
7. [Scaling Patterns](#7-scaling-patterns)
8. [Identifying Bottlenecks](#8-identifying-bottlenecks)
9. [Auto-Scaling](#9-auto-scaling)
10. [Database Scalability Challenges](#10-database-scalability-challenges)
11. [Case Studies](#11-case-studies)
12. [Golden Rules of Scalability](#12-golden-rules-of-scalability)
13. [Common Mistakes](#13-common-mistakes)

---

## 1. Scalability Kya Hai?

### What Problem?
- **Problem:** Aaj 100 users hain, kal 10 lakh ho jayenge. Same system kaam karega?
- **Matlab:** Load badhne pe system handle kar sake = Scalability

### Why Needed?
- Startup → Scale up = Growth
- Diwali sale = 10x traffic
- Viral post = Sudden spike

### Core Concept
**Restaurant Analogy (Hinglish)**

```
Socho ek restaurant hai:

    SMALL RESTAURANT (10 customers)
    ┌─────────────────────────────────┐
    │  1 Waiter + 1 Chef + 5 Tables   │
    │  Sab kaam ho jata hai           │
    └─────────────────────────────────┘

    SCALE UP (100 customers aagaye!)
    ┌─────────────────────────────────┐
    │  Option A: Waiter bada karo?    │  ← Vertical (1 super waiter)
    │  Option B: 10 waiters lo?       │  ← Horizontal (more waiters)
    └─────────────────────────────────┘

    SCALABILITY = Load badhne pe bhi
                  smoothly serve karna
```

### Internal Working
```
Load Increase → System Capacity Check
                    │
        ┌───────────┴───────────┐
        ▼                       ▼
   Capacity OK              Capacity NOT OK
   (Scalable)               (Not Scalable)
   Smooth response          Slow / Crash / Timeout
```

### Real World Example
- **Twitter:** 2010 me "Fail Whale" — scale nahi kiya. Ab 500M+ tweets/day handle.
- **Flipkart:** Big Billion Day — 10x traffic, scale design pehle se.

### Interview Questions
- "How would you scale this for 10M users?"
- "What's the bottleneck when we scale?"

### Quick Recall Summary
Scalability = Load badhne pe bhi system smoothly kaam kare. Restaurant = More customers = More waiters or bigger waiter.

---

#### 1 Minute Recall Block
```
SCALABILITY:
• Load badhne pe smoothly kaam kare
• Restaurant: 10 → 100 customers
• Vertical = Bigger (1 super waiter)
• Horizontal = More (10 waiters)
• Scale = Capacity handle
```

#### 5 Bullet Memory Hooks
1. Load ↑ = Capacity ↑
2. Restaurant = Best analogy
3. Vertical = Bigger machine
4. Horizontal = More machines
5. Smooth = No degradation

#### Common Interview Trap
⚠️ **Trap:** "Scalability = Performance" — Nahi! Performance = Fast. Scalability = Load handle. Different cheezein (next section).

---

## 2. Performance vs Scalability

### What Problem?
- Dono alag terms hain! Mix mat karo.
- Interview me "performance improve karo" vs "scale karo" — different answers

### Why Needed?
- Performance = 1 user experience
- Scalability = 1000 users experience
- Optimize differently

### Core Concept
**Different Cheezein Hain!**

```
PERFORMANCE                    SCALABILITY
┌─────────────────────┐       ┌─────────────────────┐
│ 1 request kitna     │       │ 1000 requests       │
│ fast?               │       │ simultaneously      │
│                     │       │ handle kar sakte?   │
│ Latency, Throughput │       │ Capacity, Growth    │
└─────────────────────┘       └─────────────────────┘

Example:
• Performance: "Search 100ms me aana chahiye"
• Scalability: "10 lakh users same time search karein, sabko 100ms"
```

### Comparison Table
| Aspect | Performance | Scalability |
|--------|-------------|-------------|
| **Focus** | Single request speed | Many requests together |
| **Metric** | Latency, throughput | Capacity, growth |
| **Question** | "Kitna fast?" | "Kitna load handle?" |
| **Solution** | Optimize code, cache | Add servers, shard |
| **Example** | Query 10ms → 1ms | 100 QPS → 10K QPS |

### Real World Example
- **Performance:** Redis add kiya → DB query 100ms → 1ms (single request fast)
- **Scalability:** 10 servers add kiye → 100 QPS → 1000 QPS (more load)

### Quick Recall Summary
Performance = Fast (1 request). Scalability = Capacity (many requests). Alag problems, alag solutions.

---

#### 1 Minute Recall Block
```
PERFORMANCE vs SCALABILITY:
• Performance = 1 request fast (latency)
• Scalability = Many requests (capacity)
• Fast ≠ Handle load
• Optimize code vs Add servers
```

#### 5 Bullet Memory Hooks
1. Performance = Speed
2. Scalability = Capacity
3. 1 request vs 1000 requests
4. Cache = Performance
5. More servers = Scalability

#### Common Interview Trap
⚠️ **Trap:** "Performance improve kiya, scale ho gaya" — Maybe not! 1 request fast ho gaya, but 1000 concurrent = Different problem. Clarify.

---

## 3. Vertical Scaling (Scale Up)

### What Problem?
- Resources kam pad rahe — CPU, RAM full
- Solution: Bigger machine?

### Why Needed?
- Quick fix
- Simple (no distributed complexity)
- Small scale pe enough

### Core Concept
**Bigger Truck Analogy**

```
    SMALL TRUCK (2 CPU, 4 GB RAM)
    ┌─────────────┐
    │  ▓▓  ▓▓     │  ← Limited capacity
    │  Load       │
    └─────────────┘

    BIG TRUCK (16 CPU, 64 GB RAM)
    ┌─────────────────────────────┐
    │  ▓▓  ▓▓  ▓▓  ▓▓  ▓▓  ▓▓    │  ← More capacity
    │  Same load, room to spare   │
    └─────────────────────────────┘

    VERTICAL = Same machine, bigger specs
```

### Pros and Cons
| Pros | Cons |
|------|------|
| Simple — no code change | **Ceiling** — max machine size limit |
| No distributed complexity | Single point of failure |
| Quick to do | Expensive (big machines cost more per unit) |
| No network overhead | Downtime for upgrade |
| | Can't scale beyond hardware |

### Ceiling Problem
```
    Machine Size
         ▲
         │                    ┌─── CEILING!
         │                   /
         │                  /
         │                 /
         │                /
         │______________/
         └──────────────────────► Time/Need

    Eventually: Biggest machine bhi small
    Google/Netflix level = Vertical impossible
```

### When to Use
- Small scale (< 10K users)
- Quick fix needed
- Budget for big machine
- Not long-term scale plan

### Quick Recall Summary
Vertical = Bigger machine. Pros: Simple. Cons: Ceiling, SPOF, expensive. Small scale OK, large scale = Horizontal.

---

#### 1 Minute Recall Block
```
VERTICAL SCALING:
• Bigger machine (more CPU, RAM)
• Simple, no code change
• Ceiling = Max machine limit
• SPOF = One machine down = All down
• Small scale OK
```

#### 5 Bullet Memory Hooks
1. Scale Up = Bigger truck
2. Ceiling = Hardware limit
3. SPOF = Risk
4. Quick fix
5. Large scale = Not enough

#### Common Interview Trap
⚠️ **Trap:** "Vertical scaling sufficient for FAANG scale" — Nahi! 1B users = Horizontal only. Ceiling hit ho jayega.

---

## 4. Horizontal Scaling (Scale Out)

### What Problem?
- Vertical ceiling hit
- Need unlimited scale

### Why Needed?
- Google, Netflix, Amazon = Horizontal
- No ceiling
- Fault tolerance (1 server down = OK)

### Core Concept
**More Trucks Analogy**

```
    VERTICAL: 1 Big Truck
    ┌─────────────────────────┐
    │     ONE BIG MACHINE     │
    └─────────────────────────┘

    HORIZONTAL: Many Trucks
    ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐
    │ S1  │ │ S2  │ │ S3  │ │ S4  │  ← Add more as needed
    └─────┘ └─────┘ └─────┘ └─────┘
         \    |    /    |
          \   |   /     |
           [Load Balancer]
```

### Pros and Cons
| Pros | Cons |
|------|------|
| **Unlimited** — add more forever | Complex — distributed systems |
| No ceiling | Code must support (stateless!) |
| Fault tolerant | Network latency |
| Cost effective (commodity hardware) | Data consistency challenges |
| Elastic — add/remove | Operational overhead |

### Key Requirement: Stateless
```
    STATEFUL (Bad for Horizontal)     STATELESS (Good)
    ┌─────────┐                       ┌─────────┐
    │ Server1 │ Session in memory     │ Server1 │ No session
    │ User A  │ ──► User A must       │ Any req │ ──► Any server
    │ always  │     come to S1        │         │     can handle
    └─────────┘                       └─────────┘
    Can't add server — session stuck!
```

### Quick Recall Summary
Horizontal = More machines. Unlimited. Requires stateless. Complex but necessary for scale. Industry standard.

---

#### 1 Minute Recall Block
```
HORIZONTAL SCALING:
• More machines (add servers)
• Unlimited scale
• Stateless required
• Fault tolerant
• Complex but necessary
```

#### 5 Bullet Memory Hooks
1. Scale Out = More trucks
2. Unlimited = No ceiling
3. Stateless = Must
4. LB = Distribute
5. FAANG = All horizontal

#### Common Interview Trap
⚠️ **Trap:** "Horizontal = Just add servers" — Nahi! Stateless hona chahiye. Session in-memory = Sticky session = Not true horizontal.

---

## 5. Stateless Principle

### What Problem?
- Server me session/store state = That user always that server pe aana padega
- Add new server = Session migrate? Impossible!

### Why Needed?
- **Key to horizontal scaling**
- Any server can handle any request
- Add/remove servers freely

### Core Concept
**Session Management**

```
    STATEFUL (Sticky Session)
    ┌──────────────────────────────────────────┐
    │  User A → Server 1 (session stored)      │
    │  User A next request → MUST go to S1     │
    │  S1 down = Session lost!                 │
    └──────────────────────────────────────────┘

    STATELESS (Session External)
    ┌──────────────────────────────────────────┐
    │  User A → Any Server                      │
    │  Session in: Redis/DB/Cookie              │
    │  S1 down = LB sends to S2, S2 gets       │
    │            session from Redis             │
    └──────────────────────────────────────────┘
```

### Where to Store State
| Option | Pros | Cons |
|--------|------|------|
| **Redis** | Fast, shared | Extra component |
| **Database** | Persistent | Slower |
| **Cookie (client)** | No server storage | Size limit, security |
| **JWT** | Stateless auth | Payload size |

### Architecture
```
    [Client] ──► [LB] ──► [Server 1] ──► [Redis: Session]
                      ──► [Server 2] ──► [Redis: Session]
                      ──► [Server 3] ──► [Redis: Session]

    Any server + Redis = Full session
    Server crash = No session loss
```

### Quick Recall Summary
Stateless = No session in server. Store in Redis/DB. Any server handles any request. Horizontal scaling key.

---

#### 1 Minute Recall Block
```
STATELESS:
• No state in server
• Session → Redis/DB/Cookie
• Any server = Any request
• Key to horizontal scaling
• Sticky session = Anti-pattern
```

#### 5 Bullet Memory Hooks
1. State = Server me mat rakho
2. Redis = Session store
3. Any server = Any request
4. Sticky = Bad
5. Horizontal = Stateless must

#### Common Interview Trap
⚠️ **Trap:** "We use sticky sessions for performance" — Sticky = Not true horizontal. Session in Redis, stateless = Better. Interview me stateless recommend karo.

---

## 6. Read Scaling vs Write Scaling

### What Problem?
- Read-heavy vs Write-heavy systems — different scaling strategies
- Instagram: 100 reads per 1 write (approx)

### Why Needed?
- Read scaling = Easy (replication)
- Write scaling = Hard (sharding)
- Optimize based on ratio

### Core Concept

```
    READ-HEAVY (e.g., Twitter feed, Instagram)
    ┌─────────────────────────────────────┐
    │  Reads: 1000/sec                     │
    │  Writes: 10/sec                      │
    │  Strategy: Read replicas, Cache      │
    └─────────────────────────────────────┘

    WRITE-HEAVY (e.g., IoT sensors, Logs)
    ┌─────────────────────────────────────┐
    │  Reads: 10/sec                       │
    │  Writes: 1000/sec                    │
    │  Strategy: Sharding, Write buffer    │
    └─────────────────────────────────────┘
```

### Comparison
| Aspect | Read Scaling | Write Scaling |
|--------|--------------|---------------|
| **Difficulty** | Easier | Harder |
| **Technique** | Replicas, Cache | Sharding, Partitioning |
| **Example** | News feed | Chat messages |
| **Bottleneck** | DB read capacity | DB write capacity |
| **Solution** | Add replicas | Shard by key |

### Read/Write Ratio Examples
| System | Read:Write | Strategy |
|--------|------------|----------|
| Instagram feed | 100:1 | Heavy cache, replicas |
| Twitter timeline | 50:1 | Cache, fan-out |
| WhatsApp | 1:1 (chat) | Sharding, queue |
| Analytics | 1000:1 | Read replicas, warehouse |

### Quick Recall Summary
Read-heavy = Replicas, cache. Write-heavy = Sharding. Ratio check karo, strategy choose karo.

---

#### 1 Minute Recall Block
```
READ vs WRITE SCALING:
• Read-heavy = Replicas, Cache (easier)
• Write-heavy = Sharding (harder)
• Ratio matters: 100:1 vs 1:1
• Instagram = Read, IoT = Write
```

#### 5 Bullet Memory Hooks
1. Read = Replicas, cache
2. Write = Sharding
3. Read easier than write
4. Ratio = Strategy
5. Instagram 100:1 read

#### Common Interview Trap
⚠️ **Trap:** "Same strategy for read and write" — Nahi! Read = Replication. Write = Sharding. Different problems.

---

## 7. Scaling Patterns

### What Problem?
- Scale karne ke proven patterns kya hain?
- Reusable solutions

### Why Needed?
- Reinvent mat karo
- Industry standard patterns

### Core Concept

### Pattern 1: Read Replicas
```
    [Writes] ──► [Primary DB]
                      │
                      ├──► [Replica 1] ──► Reads
                      ├──► [Replica 2] ──► Reads
                      └──► [Replica 3] ──► Reads

    Write = 1 primary
    Read = N replicas (scale reads)
    Replication lag = Eventually consistent
```

### Pattern 2: Sharding
```
    [Requests] ──► [Shard Key] ──► [Shard 1] (users A-M)
                              ──► [Shard 2] (users N-Z)
                              ──► [Shard 3] (users 0-9)

    Data split by key (user_id, etc.)
    Each shard = Independent
    Scale writes + storage
```

### Pattern 3: Caching
```
    [Request] ──► [Cache] ──► Hit? Return
                    │
                    └──► Miss? ──► [DB] ──► Store in cache

    Hot data in cache
    Reduce DB load
    Latency ↓
```

### Pattern 4: CDN
```
    [User India] ──► [CDN Edge Mumbai] ──► Static content (fast!)
    [User US]    ──► [CDN Edge Virginia] ──► Same content (fast!)

    Content at edge
    Reduce origin load
    Global scale
```

### Pattern 5: Async Queue
```
    [API] ──► [Queue] ──► [Workers] ──► [DB]
              (buffer)    (scale workers)

    Decouple
    Handle spikes
    Scale workers independently
```

### Pattern Summary Table
| Pattern | Scales | Use When |
|---------|--------|----------|
| Read Replicas | Reads | Read-heavy |
| Sharding | Writes, Storage | Write-heavy, big data |
| Caching | Reads, Latency | Hot data, repeated reads |
| CDN | Static, Global | Images, videos, static |
| Async Queue | Throughput, Spike | Async tasks, decouple |

### Quick Recall Summary
5 Patterns: Read Replicas, Sharding, Caching, CDN, Async Queue. Use case pe choose.

---

#### 1 Minute Recall Block
```
SCALING PATTERNS:
1. Read Replicas - Read scale
2. Sharding - Write, storage scale
3. Caching - Hot data, latency
4. CDN - Static, global
5. Async Queue - Decouple, spike
```

#### 5 Bullet Memory Hooks
1. Replicas = Read
2. Sharding = Write
3. Cache = Hot data
4. CDN = Static
5. Queue = Async

#### Common Interview Trap
⚠️ **Trap:** "Sharding for read scaling" — Overkill! Read replicas enough. Sharding = Write scaling, complexity.

---

## 8. Identifying Bottlenecks

### What Problem?
- System slow — kahan optimize karein?
- Random optimization = Waste

### Why Needed?
- Weakest link fix = Max impact
- Amdahl's Law = Parallel limit

### Core Concept
**Weakest Link Analogy**

```
    Pipeline:
    [Step 1: 1ms] ──► [Step 2: 100ms] ──► [Step 3: 1ms]
                          ▲
                          │
                    BOTTLENECK!
                    Fix this first.

    Step 1,3 optimize = Minimal gain
    Step 2 optimize = 100x gain possible
```

### Amdahl's Law
```
    Speedup = 1 / ((1-P) + P/N)

    P = Parallel portion (0 to 1)
    N = Number of processors

    If 10% serial (P=0.9):
    N=10 → Speedup ~5x (not 10x!)
    N=∞  → Speedup max 10x

    Serial part = Bottleneck
    Parallel part = Scale
```

### Bottleneck Identification
| Layer | Common Bottleneck | Solution |
|-------|-------------------|----------|
| **Application** | Slow algorithm, N+1 query | Optimize, batch |
| **Database** | No index, full scan | Index, query optimize |
| **Cache** | Cache miss rate high | TTL, warm cache |
| **Network** | Bandwidth, latency | CDN, compression |
| **Disk** | I/O wait | SSD, cache |

### Quick Recall Summary
Bottleneck = Weakest link. Fix first. Amdahl's Law = Serial part limits speedup. Measure before optimize.

---

#### 1 Minute Recall Block
```
BOTTLENECKS:
• Weakest link = Fix first
• Amdahl's Law = Serial limits parallel
• Measure before optimize
• DB, Cache, Network = Common
• 1 slow step = Whole pipeline slow
```

#### 5 Bullet Memory Hooks
1. Weakest link first
2. Amdahl = Serial part
3. Measure, don't guess
4. DB = Common bottleneck
5. 100ms step = Fix that

#### Common Interview Trap
⚠️ **Trap:** "Add more servers" — Maybe bottleneck is DB! More app servers = DB overload. Identify first.

---

## 9. Auto-Scaling

### What Problem?
- Manual scale = Slow, human error
- Traffic spike = Need instant scale

### Why Needed?
- Diwali sale = Auto add servers
- Night = Auto remove (save cost)
- No manual intervention

### Core Concept

```
    [Metrics] ──► [Policy] ──► [Scale Action]
        │              │              │
    CPU > 70%      Add 2 servers   [Scale Up]
    CPU < 30%      Remove 1        [Scale Down]
    Queue > 100    Add 5 workers  [Scale Workers]
```

### Metrics for Auto-Scale
| Metric | When to Scale Up | When to Scale Down |
|--------|------------------|---------------------|
| **CPU** | > 70% | < 30% |
| **Memory** | > 80% | < 40% |
| **Request count** | > 1000/min | < 100/min |
| **Queue depth** | > 100 | < 10 |
| **Latency** | > 200ms p99 | < 50ms |

### Policies
```
    TARGET TRACKING: "CPU 50% pe maintain karo"
    STEP SCALING: "CPU 70% = +2, 90% = +5"
    SCHEDULED: "9am = 10 servers, 6pm = 5 servers"
```

### Cooldown
```
    Scale Up: Quick (seconds) — traffic spike
    Scale Down: Slow (minutes) — avoid thrashing

    Cooldown = Don't scale again for X minutes
    Prevents: Add-remove-add-remove oscillation
```

### Quick Recall Summary
Auto-scale = Metrics → Policy → Action. CPU, queue common. Cooldown = Avoid thrashing. Scale up fast, down slow.

---

#### 1 Minute Recall Block
```
AUTO-SCALING:
• Metrics: CPU, Queue, Latency
• Policy: Target, Step, Scheduled
• Cooldown: Avoid thrashing
• Scale up fast, down slow
• Save cost when low traffic
```

#### 5 Bullet Memory Hooks
1. CPU 70% = Scale up
2. Cooldown = No thrashing
3. Scale down slow
4. Queue depth = Worker scale
5. Scheduled = Predictable load

#### Common Interview Trap
⚠️ **Trap:** "Scale up and down same speed" — Down should be slower. Fast scale down = Traffic spike pe servers kam, crash.

---

## 10. Database Scalability Challenges

### What Problem?
- App scale ho gaya, DB bottleneck
- DB scale = Tricky (state, consistency)

### Why Needed?
- DB = Often bottleneck
- Different strategies

### Core Concept

```
    DB SCALING OPTIONS:
    ┌─────────────────────────────────────────┐
    │  1. Read Replicas   → Read scale         │
    │  2. Sharding        → Write, storage     │
    │  3. CQRS            → Read/write split   │
    │  4. Denormalization → Fewer joins        │
    │  5. Connection pool→ Connection limit   │
    └─────────────────────────────────────────┘
```

### Challenges
| Challenge | Problem | Solution |
|-----------|---------|----------|
| **Connection limit** | 10K connections = Exhaust | Connection pool, PgBouncer |
| **Replication lag** | Read stale data | Accept or sync read |
| **Shard rebalance** | Add shard = Data move | Consistent hashing, range |
| **Joins** | Cross-shard join = Slow | Denormalize, avoid |
| **Transactions** | Cross-shard TX = Hard | Saga, eventual |

### SQL vs NoSQL for Scale
| | SQL | NoSQL |
|---|-----|-------|
| **Scale** | Harder (ACID) | Easier (flexible) |
| **Sharding** | Complex | Built-in (Mongo, Cassandra) |
| **Consistency** | Strong | Eventual (often) |
| **Use** | Transactions needed | Scale, flexible schema |

### Quick Recall Summary
DB scale = Replicas (read), Sharding (write). Challenges: Connections, lag, joins. SQL = ACID, NoSQL = Scale.

---

#### 1 Minute Recall Block
```
DB SCALABILITY:
• Read = Replicas
• Write = Sharding
• Connection pool = Limit
• Replication lag = Accept/sync
• Cross-shard join = Avoid
```

#### 5 Bullet Memory Hooks
1. DB = Common bottleneck
2. Replicas = Read
3. Sharding = Write
4. Connection pool
5. Cross-shard = Hard

#### Common Interview Trap
⚠️ **Trap:** "Sharding solves all DB problems" — Nahi! Joins, transactions hard. Denormalize, design for sharding from start.

---

## 11. Case Studies

### What Problem?
- Real companies kaise scale karti hain?
- Learn from production

### Core Concept

### Netflix
```
    CHALLENGE: Global video streaming, 200M+ users
    SCALING:
    • CDN (Open Connect) — Video at edge
    • Microservices — Independent scale
    • Chaos Engineering — Failure resilience
    • AWS — Multi-region
    KEY: Content at edge, stateless services
```

### WhatsApp
```
    CHALLENGE: 2B users, real-time messaging
    SCALING:
    • Erlang — Millions connections per server
    • Minimal servers (amazing!)
    • Message queue — Async delivery
    • Read-heavy optimization
    KEY: Efficient stack (Erlang), queue, minimal components
```

### Instagram
```
    CHALLENGE: 1B+ users, photo feed, read-heavy
    SCALING:
    • Read replicas — Feed reads
    • Memcached — Heavy caching
    • Sharding — User data
    • CDN — Images, videos
    KEY: Read 100:1 write, cache everything hot
```

### Uber
```
    CHALLENGE: Real-time, geo, surge, 10M+ rides/day
    SCALING:
    • Sharding — By city/region
    • Kafka — Event streaming
    • Redis — Real-time location
    • Microservices — Ride, payment, etc.
    KEY: Geo-sharding, event-driven, real-time cache
```

### Case Study Summary Table
| Company | Scale | Key Strategy |
|---------|-------|--------------|
| Netflix | 200M+ | CDN, Microservices, Chaos |
| WhatsApp | 2B | Erlang, Queue, Minimal |
| Instagram | 1B+ | Cache, Replicas, CDN |
| Uber | 10M rides/day | Geo-shard, Kafka, Redis |

### Quick Recall Summary
Netflix=CDN. WhatsApp=Erlang+Queue. Instagram=Cache+Replicas. Uber=Geo+Kafka. Learn patterns.

---

#### 1 Minute Recall Block
```
CASE STUDIES:
• Netflix = CDN, Chaos
• WhatsApp = Erlang, 2B, minimal servers
• Instagram = Cache, read-heavy
• Uber = Geo, Kafka, real-time
• Patterns = Reusable
```

#### 5 Bullet Memory Hooks
1. Netflix = Edge, CDN
2. WhatsApp = Erlang magic
3. Instagram = Cache everything
4. Uber = Geo-sharding
5. Each = Different pattern

#### Common Interview Trap
⚠️ **Trap:** "Netflix jaisa bana denge" — Context matters. Your scale, budget different. Principles apply, copy-paste not.

---

## 12. Golden Rules of Scalability

### Core Concept

```
1.  STATELESS — Session external, any server
2.  HORIZONTAL > VERTICAL — Scale out
3.  CACHE WISELY — Hot data, TTL
4.  ASYNC — Queue, decouple
5.  IDENTIFY BOTTLENECK — Fix weakest link
6.  READ vs WRITE — Different strategies
7.  DATABASE — Replicas, sharding, pool
8.  CDN — Static at edge
9.  AUTO-SCALE — Metrics, cooldown
10. MEASURE — Don't guess, profile
11. START SIMPLE — Add complexity when needed
12. FAILURE — Assume, design for it
13. CONSISTENCY — Eventual where possible
14. MONITOR — Observability
15. COST — Scale = Money, optimize
```

### Quick Recall Summary
15 rules: Stateless, Horizontal, Cache, Async, Bottleneck, Read/Write, DB, CDN, Auto-scale, Measure, Simple, Failure, Consistency, Monitor, Cost.

---

#### 1 Minute Recall Block
```
GOLDEN RULES:
Stateless, Horizontal, Cache, Async
Bottleneck, Read/Write, DB, CDN
Auto-scale, Measure, Simple
Failure, Consistency, Monitor, Cost
```

#### 5 Bullet Memory Hooks
1. Stateless first
2. Horizontal preferred
3. Cache hot data
4. Measure bottleneck
5. Start simple

#### Common Interview Trap
⚠️ **Trap:** "All rules always" — Context matters. Small system = Overkill. Apply judiciously.

---

## 13. Common Mistakes

### What Problem?
- Scaling me common galtiyan?
- Avoid = Save time, money

### Core Concept

| Mistake | Problem | Right Approach |
|---------|---------|----------------|
| **Scale too early** | Over-engineering | Scale when needed |
| **Stateful servers** | Can't horizontal | Stateless |
| **No caching** | DB overload | Cache hot data |
| **Single DB** | SPOF | Replicas, failover |
| **Sync everything** | Blocking | Async where possible |
| **Ignore bottleneck** | Wrong optimization | Profile first |
| **No auto-scale** | Manual, slow | Auto-scale |
| **Sharding too early** | Complexity | Replicas first |
| **No connection pool** | Connection exhaust | Pool |
| **Cross-shard joins** | Slow queries | Denormalize |
| **No monitoring** | Blind scaling | Observability |
| **Vertical only** | Ceiling hit | Plan horizontal |

### Quick Recall Summary
Mistakes: Early scale, Stateful, No cache, Single DB, Sync all, No measure, No auto-scale, Early sharding, No pool, Cross-shard join, No monitor, Vertical only.

---

#### 1 Minute Recall Block
```
COMMON MISTAKES:
• Scale too early
• Stateful
• No cache
• Single DB
• No bottleneck identification
• No auto-scale
• Sharding before replicas
• No connection pool
• No monitoring
```

#### 5 Bullet Memory Hooks
1. Don't scale too early
2. Stateless
3. Cache
4. Measure first
5. Replicas before sharding

#### Common Interview Trap
⚠️ **Trap:** "Sharding first" — Replicas pehle. Sharding = Complexity. Read-heavy = Replicas enough.

---

## Final Recap

```
SCALABILITY — ONE PAGE
═══════════════════════════════════
• Scalability = Load handle (not performance)
• Vertical = Bigger (ceiling)
• Horizontal = More (unlimited, stateless)
• Stateless = Key to horizontal
• Read = Replicas, cache | Write = Sharding
• Patterns: Replicas, Shard, Cache, CDN, Queue
• Bottleneck = Weakest link, Amdahl's Law
• Auto-scale = Metrics, cooldown
• DB = Replicas, sharding, pool
• Netflix, WhatsApp, Instagram, Uber = Case studies
• 15 Golden Rules
• Common mistakes = Avoid
═══════════════════════════════════
```

---

*End of Scalability — System Ko Bada Kaise Karo*
