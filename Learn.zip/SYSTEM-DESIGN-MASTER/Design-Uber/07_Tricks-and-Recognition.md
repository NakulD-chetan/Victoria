# Design Uber — Tricks and Recognition

> **Permanent Recall:** Key insights: **Geohash** = encode lat/lng into string (shared prefix = nearby); **QuadTree** for variable density areas; **Redis GEO** for prototype/interview; **Trip** = state machine; **Surge** = supply/demand per region. This design tests **geospatial systems** and **real-time architecture** at scale.

---

## Key Insights

| Insight | Implication |
|---------|-------------|
| **Geohash encodes locality** | Shared prefix = nearby; longer string = smaller region; query cell + neighbors |
| **QuadTree for variable density** | Dense urban = deep tree; sparse = shallow; good for uneven driver distribution |
| **Redis GEO for interview** | GEOADD, GEORADIUS — built-in; mention as "production-ready option" |
| **Trip = state machine** | REQUESTED → MATCHED → DRIVER_EN_ROUTE → IN_PROGRESS → COMPLETED |
| **Surge = supply/demand per region** | Per geohash; ratio drives multiplier; recalculate periodically |
| **Location at scale** | 3.75M updates/s → in-memory; not disk; shard by region |
| **First-accept-wins** | Don't wait for all K drivers; first to accept wins; better UX |

---

## Recognition Triggers

| Interview Phrase | What They're Testing |
|------------------|----------------------|
| "Find nearby drivers" | Geospatial indexing (Geohash, QuadTree, S2) |
| "Real-time tracking" | WebSocket; location push; update frequency |
| "Millions of drivers" | Location update throughput; in-memory store |
| "Peak hour" | Surge pricing; scaling; handling spikes |
| "Matching" | Nearest K; first-accept; expand on no match |
| "ETA" | Graph routing; historical; traffic |
| "Dynamic pricing" | Surge; supply/demand |
| "Ride-sharing" | Uber, Lyft, Grab — geospatial + real-time |

---

## Decision Shortcuts

```
IF "find nearby" / "match rider"    → Geohash, QuadTree, Redis GEO
IF "location updates"              → In-memory; 4s interval; shard by region
IF "matching"                       → Nearest K; first-accept-wins
IF "trip lifecycle"                 → State machine (5 states)
IF "pricing"                        → Surge = supply/demand per region
IF "real-time map"                  → WebSocket; push every 4s
IF "scale"                          → 3.75M loc/s; partition by geography
IF "ETA"                            → Graph + historical + traffic
```

---

## What This Design Tests

| Area | What to Demonstrate |
|------|----------------------|
| **Geospatial systems** | Indexing (Geohash/QuadTree/S2); not SQL lat/lng |
| **Real-time architecture** | High write throughput; in-memory; WebSocket |
| **Distributed systems** | Sharding by region; state machine; idempotency |
| **Scalability** | 3.75M updates/s; 20M trips/day |
| **Product sense** | Surge fairness; ETA accuracy; rider/driver UX |

> **FAANG Tip:** "Design Uber" is a classic because it combines geospatial, real-time, and scale. Lead with "geospatial indexing—Geohash or Redis GEO" to signal you know the domain.

---

## Tech Stack Quick Reference

| Component | Typical Choices |
|-----------|-----------------|
| **Geospatial index** | Redis GEO, QuadTree, S2, Geohash |
| **Location store** | Redis (in-memory), Cassandra (persistent) |
| **Real-time** | WebSocket, Kafka (location stream) |
| **Matching** | Custom service; queries geo index |
| **Trip store** | PostgreSQL, Cassandra, DynamoDB |
| **Routing/ETA** | OSRM, Google Directions, HERE |
| **Payments** | Stripe, Braintree, custom gateway |

---

## Interview Script Snippets

**Opening:** "The core challenge is geospatial matching—finding the nearest available drivers in under a second while handling millions of location updates per second. That requires proper indexing—Geohash or Redis GEO—not a SQL table with lat/lng."

**Geohash:** "Geohash encodes lat/lng into a string. Nearby points share a prefix. For a rider, we compute their geohash, then lookup drivers in that cell and the 8 adjacent cells. That gives us a 3×3 grid—covers boundaries."

**Matching:** "We query the nearest K available drivers, send the request to the top 5. First driver to accept wins. If nobody accepts in 30 seconds, we expand the radius and try again."

**Surge:** "Surge pricing is supply versus demand per geographic region. We count ride requests and available drivers in each geohash, compute a ratio, and apply a multiplier. Recalculate every few minutes."

**Scale:** "At 15M active drivers updating every 4 seconds, we're at 3.75M writes per second. That's in-memory—Redis GEO or a custom QuadTree. We shard by region so NYC handles NYC."

---

## Anti-Patterns to Avoid

| Don't Say | Say Instead |
|-----------|-------------|
| "We'll query drivers by lat/lng range" | "Geohash or Redis GEO for spatial indexing" |
| "Find nearby drivers" (no how) | "Geohash: shared prefix = nearby; query cell + neighbors" |
| "We'll store locations in MySQL" | "In-memory geo store; 3.75M/s is too fast for disk" |
| "We wait for all 5 drivers to respond" | "First-accept-wins for lower latency" |
| "Pricing is fixed" | "Surge: supply/demand per region" |
| "Single cluster globally" | "Shard by region; NYC, SF, London each have own partition" |

---

## Geohash Quick Explainer (Memorize)

**One-liner:** Geohash = encode (lat, lng) into base32 string; more characters = smaller area; same prefix = nearby.

**Precision:**
- 5 chars ≈ 5 km
- 7 chars ≈ 150 m
- 9 chars ≈ 5 m

**Query:** Rider at "9q8yy" → drivers in "9q8yy" + 8 neighbors (9 cells total). Covers ~15 km × 15 km for precision 5.

---

## One-Liner Summaries

- **Geohash:** Encode lat/lng; shared prefix = nearby; query cell + neighbors.
- **QuadTree:** Recursive 4-way split; variable depth for variable density.
- **Redis GEO:** GEOADD, GEORADIUS; production-ready; use in interview.
- **Trip:** State machine; 5 states; CANCELLED from early states.
- **Surge:** Supply/demand per geohash; multiplier; recalc every 5–10 min.
- **Matching:** Nearest K; first-accept-wins; expand on timeout.
- **Location scale:** 3.75M/s; in-memory; shard by region.

---

## 30-SECOND REVISION BOX

```
GEOHASH: Encode lat/lng; prefix = region; query 3×3 cells
QUADTREE: Variable density; urban = deep
REDIS GEO: GEOADD, GEORADIUS; interview shortcut
TRIP: State machine (5 states)
SURGE: Supply/demand per region
TESTS: Geospatial + real-time + scale
LEAD WITH: "Geospatial indexing is the core"
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
