import { useCallback, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const EVENTS = [
  { t: 900, type: 'arr', tr: 'A1' },
  { t: 940, type: 'arr', tr: 'A2' },
  { t: 950, type: 'arr', tr: 'A3' },
  { t: 1100, type: 'dep', tr: 'A1' },
  { t: 1120, type: 'dep', tr: 'A2' },
  { t: 1130, type: 'dep', tr: 'A3' },
].map((e) => ({ ...e, t: (e.t - 900) / 10 }));

function generateSteps() {
  const ev = [...EVENTS].sort((a, b) => a.t - b.t);
  const steps = [];
  let plat = 0;
  let maxP = 0;
  steps.push({ type: 'init', msg: 'Sweep arrivals / departures', events: ev, plat: 0, maxP: 0, idx: -1 });
  ev.forEach((e, idx) => {
    steps.push({
      type: 'event',
      msg: `${e.type === 'arr' ? 'Arrival' : 'Departure'} ${e.tr} @${e.t}`,
      events: ev,
      idx,
      plat,
      maxP,
    });
    if (e.type === 'arr') {
      plat += 1;
      maxP = Math.max(maxP, plat);
    } else plat = Math.max(0, plat - 1);
    steps.push({
      type: 'after',
      msg: `Platforms in use: ${plat}, max so far: ${maxP}`,
      events: ev,
      idx,
      plat,
      maxP,
    });
  });
  steps.push({ type: 'done', msg: `Minimum platforms needed: ${maxP}`, events: ev, idx: ev.length, plat, maxP });
  return steps;
}

const PlatformTimeline = forwardRef(function PlatformTimeline(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ events: EVENTS, idx: -1, plat: 0, maxP: 0 });
  const addAnim = useCallback(() => {}, []);
  const setState = useCallback((p) => Object.assign(stateRef.current, p), []);
  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 300;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);
    let raf;
    function draw() {
      const { events, idx, plat, maxP } = stateRef.current;
      ctx.clearRect(0, 0, W, H);
      const light = document.documentElement.getAttribute('data-theme') === 'light';
      ctx.fillStyle = light ? '#e7e5e4' : 'rgba(255,255,255,0.06)';
      for (let gx = 20; gx < W; gx += 20) for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.2, 1.2);
      const pad = 36;
      const tmax = 25;
      const axisW = W - pad * 2;
      const y0 = H - 50;
      ctx.strokeStyle = light ? '#1c1917' : '#e7e5e4';
      ctx.beginPath();
      ctx.moveTo(pad, y0);
      ctx.lineTo(W - pad, y0);
      ctx.stroke();
      events.forEach((e, i) => {
        const x = pad + (e.t / tmax) * axisW;
        const done = i <= idx;
        ctx.fillStyle = e.type === 'arr' ? (done ? '#2f9e44' : '#94a3b8') : done ? '#e03131' : '#94a3b8';
        ctx.beginPath();
        ctx.arc(x, y0 - 40, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = light ? '#111' : '#eee';
        ctx.font = '8px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(e.tr, x, y0 - 52);
      });
      ctx.fillStyle = light ? '#111' : '#eee';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText(`In use: ${plat}   Max: ${maxP}`, pad, 28);
      raf = requestAnimationFrame(draw);
    }
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default function MinimumPlatformsVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Greedy event sweep' });
    canvasRef.current?.setState({
      events: steps[0].events,
      idx: steps[0].idx,
      plat: steps[0].plat,
      maxP: steps[0].maxP,
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState({
      events: step.events,
      idx: step.idx,
      plat: step.plat,
      maxP: step.maxP,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={PlatformTimeline} onInit={onInit} onStep={onStep} />;
}
