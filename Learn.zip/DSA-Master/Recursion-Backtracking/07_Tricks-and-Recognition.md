# Recursion-Backtracking — Tricks and Recognition

> **Permanent Recall:** "Generate all" / "Find all" → backtracking. "Partition into..." → backtracking. "Valid placement" → constraint-based. Use flowchart for subsets vs permutations vs combinations. Pruning: sort + skip duplicates.

---

## Recognition: "Generate All" / "Find All"

**Primary signal:** Problem asks to enumerate all valid configurations.

| Phrase | Template |
|--------|----------|
| "Generate all subsets" | Subsets |
| "Find all permutations" | Permutations |
| "All combinations of size k" | Combinations |
| "All combinations summing to target" | Combination Sum |
| "All valid parentheses" | Structured (open/close) |
| "All valid IP addresses" | Partition |
| "All possible letter combinations" | Cartesian product (often iterative) |
| "All paths" | Graph DFS (backtrack on path) |

---

## Recognition: "Partition into..."

**Signal:** Split/divide into groups satisfying constraints.

| Phrase | Approach |
|--------|----------|
| "Partition into k equal subsets" | Subsets + partition |
| "Partition array into equal sum" | Subsets + sum constraint |
| "Split string into..." | Partition by positions |
| "Partition to get palindrome" | Partition + validity check |

**Tree:** For each element, choose which group (1, 2, ..., k). Prune when group sum exceeds target.

---

## Recognition: "Valid Placement"

**Signal:** Place items on grid/board with constraints.

| Phrase | Problem Type |
|--------|--------------|
| "Place n queens" | N-Queens |
| "Fill Sudoku" | Constraint satisfaction |
| "Find word in grid" | Word Search |
| "Color the graph" | Graph coloring |
| "Assign colors" | Constraint satisfaction |

**Common constraints:** No two share row/col/diagonal, no conflict with neighbors, etc.

---

## Subsets vs Permutations vs Combinations — Flowchart

```mermaid
flowchart TD
    A[Problem asks for...]
    A --> B["all subsets / subsequences"]
    A --> C["all orderings / arrangements"]
    A --> D["choose k from n / combinations of size k"]
    B --> B1[SUBSETS: Include/exclude, 2^n, order does not matter]
    C --> C1[PERMUTATIONS: Pick remaining, n!, order matters]
    D --> D1[COMBINATIONS: Subsets + size k, C(n,k)]
    style A fill:#ffd43b,color:#000
    style B1 fill:#51cf66,color:#fff
    style C1 fill:#51cf66,color:#fff
    style D1 fill:#51cf66,color:#fff
```

<details><summary>ASCII fallback</summary>

```
                    Problem asks for...
                            |
        +-------------------+-------------------+
        |                   |                   |
   "all subsets"      "all orderings"     "choose k from n"
   "subsequences"     "arrangements"      "combinations of size k"
        |                   |                   |
        v                   v                   v
   SUBSETS              PERMUTATIONS        COMBINATIONS
   - Include/exclude    - Pick from         - Subsets +
   - Index: start       remaining           size == k
   - 2^n                - used[] or swap    - Prune by count
   - Order doesn't      - n!                - C(n,k)
     matter             - Order matters
```

</details>

### Quick Decision Table

| If... | Then... |
|-------|---------|
| Order doesn't matter, any size | Subsets |
| Order matters, use all | Permutations |
| Order doesn't matter, fixed size k | Combinations |
| Sum to target, reuse allowed | Combo Sum (unlimited) |
| Sum to target, use once | Combo Sum II |

---

## Pruning Strategies

### 1. Sort + Skip Duplicates

**When:** Input has duplicates, want unique solutions.

```python
nums.sort()
for i in range(start, len(nums)):
    if i > start and nums[i] == nums[i-1]:
        continue
```

**Subsets w/ dup:** Skip when same value and we're at same "level" (i > start).  
**Permutations w/ dup:** Skip when `nums[i]==nums[i-1]` and `not used[i-1]`.  
**Combo Sum II:** Same as subsets.

### 2. Bounds Pruning (Combination Sum)

```python
candidates.sort()
for i in range(start, len(candidates)):
    if candidates[i] > remain:
        break   # rest are bigger, no need to try
```

### 3. Feasibility Pruning

- "Can this ever lead to valid?" If no → prune.
- Examples: sum > target, queen attacks another, invalid character.

### 4. Remaining Count Pruning (Combinations)

```python
if n - i + 1 < k - len(path):
    break   # not enough elements left to reach k
```

### 5. Early Exit (Find One)

- If problem asks for one solution: `if backtrack(): return True`
- Stop as soon as first valid found.

---

## Index Handling Cheat Sheet

| Pattern | When Include | When Exclude |
|---------|--------------|--------------|
| Subsets | `backtrack(i+1)` | (implicit in loop) |
| Combo Sum (unlimited) | `backtrack(i, remain-x)` | `backtrack(i+1, remain)` via loop |
| Combo Sum (once) | `backtrack(i+1, remain-x)` | (implicit) |
| Combinations | `backtrack(i+1)` | (implicit) |

**Rule:** Advance index when we will NOT use the element again in this branch.

---

## Used[] vs Swap-Based Permutations

| Approach | Pros | Cons |
|----------|------|------|
| **used[]** | Clear, works with duplicates | Extra O(n) space |
| **Swap** | O(1) extra space | Trickier with duplicates |

**Swap idea:** At position `i`, swap `nums[i]` with `nums[j]` for j in [i, n-1]. Recurse on [i+1..n]. Swap back.

---

## Grid Backtracking Patterns

### Word Search

- 4 directions: `(0,1), (1,0), (0,-1), (-1,0)`
- Mark cell visited, unmark on return
- Base: `idx == len(word)`

### N-Queens

- One queen per row → recurse by row
- Track: columns, diag1 (r-c), diag2 (r+c)
- Place in col c if c, r-c, r+c all free

### Sudoku

- Find next empty cell
- Try digits 1-9
- Check row, col, 3×3 box

---

## Parentheses / Structured Generation

**Constraints:**
- Place `(` if `open < n`
- Place `)` if `close < open`

**Tree:** Binary at each step (place `(` or `)`), pruned by constraints.

---

## Recognition Summary Table

| Problem Description | Type | Key Trick |
|---------------------|------|-----------|
| All subsets | Subsets | start index |
| All subsets, dup | Subsets | sort + skip |
| All permutations | Permute | used[] |
| All permutations, dup | Permute | sort + used[i-1] check |
| C(n,k) | Combine | size prune |
| Sum to target, reuse | Combo Sum | same index on include |
| Sum to target, once | Combo Sum II | sort + skip |
| Place queens | N-Queens | cols + diags |
| Fill Sudoku | Sudoku | valid row/col/box |
| Word in grid | Word Search | 4 dirs, mark/unmark |
| Valid parentheses | Structured | open/close counts |
| Partition equal sum | Partition | assign to bucket |

---

## FINAL MEMORY COMPRESSION BLOCK

```
GENERATE ALL:    → Backtracking
PARTITION:       → Backtracking (assign to groups)
VALID PLACEMENT: → Constraint backtracking
SUBSETS:         Include/exclude, index, 2^n
PERMUTE:         Pick remaining, used[], n!
COMBINE:         Subsets + k, prune
PRUNE DUP:       Sort + skip (i>start && nums[i]==nums[i-1])
PRUNE BOUNDS:    candidates[i] > remain → break
PRUNE COUNT:     n-i+1 < k-len(path) → break
INDEX:           Advance when not reusing (exclude or use-once)
```
