# Union-Find — Interview Thinking

> **Permanent Recall:** "Dynamic connectivity" = Union-Find. Static one-query = BFS/DFS. Need path/shortest distance = BFS/DFS. Group merging, cycle in undirected, component count = Union-Find. Communicate your choice.

---

## When to Use Union-Find vs BFS/DFS

| Cue | Use Union-Find | Use BFS/DFS |
|-----|----------------|-------------|
| **Connectivity queries** | Multiple queries over time | Single query |
| **Dynamic edges** | Edges added incrementally | Static graph |
| **Component count** | Yes | Yes (but UF cleaner) |
| **Cycle detection** | Undirected only | Directed or undirected |
| **Path / distance** | No | Yes |
| **Traversal order** | No | Yes |
| **Group merging** | Yes (accounts, regions) | No |

---

## "Dynamic Connectivity" Trigger

```
Problem says:
  - "Add edges one by one and answer connectivity"
  - "Merge groups over time"
  - "Process edges in order and query components"
  - "Which nodes are in the same region after each update?"

→ Union-Find
```

---

## Decision Flowchart

```
                    Need connectivity info?
                           |
                    +------+------+
                    |             |
              Multiple        Single
              queries?        query?
                    |             |
                   YES            |
                    |             |
              Union-Find     Need path/distance?
                    |             |
                    |        +----+----+
                    |        |         |
                    |       YES       NO
                    |        |         |
                    |    BFS/DFS   BFS/DFS
                    |        |    (simpler)
                    |        |         |
                    +--------+--------+
                             |
                    Cycle in undirected?
                             |
                    Union-Find (find before union)
```

---

## Communication Framework

**Opening:**
> "This is a connectivity/grouping problem. I'll use Union-Find with path compression and union by rank for near O(1) amortized operations."

**When asked "Why not BFS?":**
> "BFS is great for a single connectivity query or when we need the actual path. Here we have [multiple queries / dynamic edges / just component count], so Union-Find is more efficient."

**When coding:**
> "I'll initialize each node as its own component. For each edge, I find both roots. If they're the same, [cycle / already connected]. Otherwise I union by rank."

---

## Problem Type → Strategy

| Problem Type | UF Strategy |
|--------------|--------------|
| **Number of provinces** | Union all edges, return count |
| **Redundant connection** | First edge with find(u)==find(v) is answer |
| **Accounts merge** | Map emails to IDs, union same-account emails |
| **Largest component** | Track size per root (extra size[] array) |
| **Escape grid** | Map 2D (r,c) → 1D index, union adjacent |
| **Lexicographically smallest** | Process edges in sorted order |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TRIGGER:       Dynamic connectivity, multiple queries, group merging
VS BFS/DFS:    UF for connectivity/count; BFS/DFS for path/distance
CYCLE:         Undirected → UF; find before union
COMMUNICATE:   "UF with path compression + union by rank"
STRATEGY:      Init → process edges → query count/connectivity
```

---

## 30-SECOND REVISION BOX

```
□ Dynamic connectivity? → UF
□ Single query, need path? → BFS/DFS
□ Cycle undirected? → UF (find before union)
□ Component count? → UF or BFS (UF cleaner)
□ Say: "UF with both optimizations"
```
