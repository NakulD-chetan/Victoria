import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const CHARS = ['a', 'b', 'c', 'd'];
const FREQ = [5, 2, 1, 1];

function generateSteps() {
  const steps = [];
  let id = 0;
  const mkId = () => `n${id++}`;
  let pool = FREQ.map((w, i) => ({
    id: mkId(),
    label: CHARS[i],
    weight: w,
    sub: w,
    level: 0,
    alive: true,
  }));
  const allNodes = [...pool];
  const edges = [];

  steps.push({
    type: 'init',
    msg: 'Start with one node per symbol',
    nodes: allNodes.map((n) => ({ ...n })),
    edges: [...edges],
    nodeRoles: {},
  });

  while (pool.filter((p) => p.alive).length > 1) {
    const alive = pool.filter((p) => p.alive).sort((a, b) => a.weight - b.weight);
    const x = alive[0];
    const y = alive[1];
    steps.push({
      type: 'pick',
      msg: `Extract min: ${x.label} (${x.weight}) and ${y.label} (${y.weight})`,
      nodes: allNodes.map((n) => ({ ...n })),
      edges: [...edges],
      nodeRoles: { [x.id]: 'active', [y.id]: 'active' },
    });
    x.alive = false;
    y.alive = false;
    const z = {
      id: mkId(),
      label: '·',
      weight: x.weight + y.weight,
      sub: x.weight + y.weight,
      level: Math.max(x.level, y.level) + 1,
      alive: true,
    };
    allNodes.push(z);
    pool.push(z);
    edges.push([z.id, x.id], [z.id, y.id]);
    steps.push({
      type: 'merge',
      msg: `Insert parent weight ${z.weight}`,
      nodes: allNodes.map((n) => ({ ...n })),
      edges: [...edges],
      nodeRoles: { [z.id]: 'merge', [x.id]: 'done', [y.id]: 'done' },
    });
  }
  const root = pool.filter((p) => p.alive)[0];
  steps.push({
    type: 'done',
    msg: 'Huffman tree complete',
    nodes: allNodes.map((n) => ({ ...n })),
    edges: [...edges],
    nodeRoles: root ? { [root.id]: 'done' } : {},
  });
  return steps;
}

function assignOrder(nodes, edges) {
  const children = {};
  edges.forEach(([p, c]) => {
    if (!children[p]) children[p] = [];
    children[p].push(c);
  });
  const byLevel = {};
  nodes.forEach((n) => {
    const lv = n.level || 0;
    if (!byLevel[lv]) byLevel[lv] = [];
    byLevel[lv].push(n.id);
  });
  const orderMap = {};
  Object.keys(byLevel)
    .map(Number)
    .sort((a, b) => a - b)
    .forEach((lv) => {
      const ids = byLevel[lv];
      ids.forEach((nid, idx) => {
        orderMap[nid] = idx;
      });
    });
  return nodes.map((n) => ({ ...n, order: orderMap[n.id] ?? 0 }));
}

export default function HuffmanCodingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Huffman: two smallest → parent' });
    const s0 = steps[0];
    canvasRef.current?.setState({
      nodes: assignOrder(s0.nodes, s0.edges),
      edges: s0.edges,
      nodeRoles: s0.nodeRoles || {},
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState({
      nodes: assignOrder(step.nodes || [], step.edges || []),
      edges: step.edges || [],
      nodeRoles: step.nodeRoles || {},
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={TreeCanvasBase} onInit={onInit} onStep={onStep} />;
}
