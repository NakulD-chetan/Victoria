# Security and Authentication — Question List

> **Permanent Recall:** Master the 10 MUST-DO security questions for FAANG interviews. The full list covers authentication, authorization, OAuth, JWT, encryption, common attacks (SQL injection, XSS, CSRF), and design trade-offs. Difficulty ranges from Easy (concepts) to Hard (full design). Use this as a checklist for interview prep—each question tests specific concepts from the Security-Authentication notes.

---

## 10 MUST-DO Security Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | Design a login system for a mobile app | Medium | Auth flow, JWT, refresh tokens, bcrypt |
| 2 | OAuth 2.0 vs JWT—when would you use each? | Easy | OAuth, JWT, use cases |
| 3 | Design authentication for microservices | Medium | JWT, API gateway, service-to-service |
| 4 | How do you prevent SQL injection and XSS? | Easy | Parameterized queries, output encoding |
| 5 | Design OAuth 2.0 flow for "Login with Google" | Medium | Authorization code, PKCE |
| 6 | JWT vs session-based auth—trade-offs? | Easy | Stateless vs stateful, revocation |
| 7 | How do you secure an API used by third-party developers? | Medium | OAuth, rate limit, API keys |
| 8 | Design a system to handle token theft | Medium | TTL, refresh rotation, blacklist |
| 9 | What is CSRF and how do you prevent it? | Easy | CSRF token, SameSite |
| 10 | Design SSO for an enterprise with multiple apps | Hard | SAML, OIDC, IdP federation |

---

## Complete Question List (25+)

### Authentication Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 11 | What is the difference between authentication and authorization? | Easy | Any |
| 12 | How do you store passwords securely? | Easy | Any |
| 13 | Design a refresh token flow with rotation | Medium | Meta, Google |
| 14 | When would you use API key vs OAuth vs JWT? | Easy | Any |
| 15 | How do you implement "logout everywhere"? | Medium | Any |

### OAuth & JWT Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 16 | Explain OAuth 2.0 authorization code flow | Easy | Google, Meta |
| 17 | What is PKCE and when do you use it? | Medium | Google, Meta |
| 18 | How do you revoke a JWT before it expires? | Medium | Any |
| 19 | Design JWT structure for a multi-tenant app | Medium | Amazon, Salesforce |
| 20 | OAuth client credentials vs authorization code | Easy | Any |

### Authorization Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 21 | RBAC vs ABAC—when to use each? | Easy | Any |
| 22 | Design permission system for document sharing | Medium | Google, Dropbox |
| 23 | How do you implement role-based access in microservices? | Medium | Amazon, Netflix |

### Encryption & Network Security

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 24 | How does TLS/HTTPS handshake work? | Easy | Any |
| 25 | Encryption at rest vs in transit | Easy | Any |
| 26 | Design key rotation for encrypted data | Hard | Amazon, Google |

### Common Attacks

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 27 | How do you prevent SQL injection? | Easy | Any |
| 28 | What is XSS and how do you mitigate it? | Easy | Any |
| 29 | Explain CORS and common misconfigurations | Easy | Any |
| 30 | How do you protect against brute-force login? | Easy | Any |
| 31 | What is session fixation? How to prevent? | Medium | Any |

### Design & Edge Cases

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 32 | Design auth for a public API with 1M users | Hard | Stripe, Twilio |
| 33 | Handle refresh token race condition (concurrent requests) | Medium | Meta |
| 34 | Design rate limiting for login and API | Medium | Any |
| 35 | How would you design auth for a banking app? | Hard | Any |

---

## How to Approach Security Questions

**For "Design auth for X" questions:**
1. Clarify who accesses (users, partners, internal)
2. Pick auth mechanism (OAuth, JWT, session, API key)
3. Address passwords (bcrypt), tokens (TTL, refresh)
4. Mention HTTPS, rate limiting, input validation
5. Discuss revocation, theft handling

**For "How do you prevent X?" questions:**
- SQL injection: Parameterized queries, ORM
- XSS: Output encoding, CSP, HttpOnly
- CSRF: Token, SameSite
- Brute-force: Rate limit, lock, CAPTCHA

**For "OAuth vs JWT" questions:**
- OAuth: Delegation, third-party, user consent
- JWT: Stateless, our own app, microservices

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, single topic |
| **Medium** | Multiple components, trade-offs |
| **Hard** | Full design, scale, edge cases |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **Auth vs Authz** | 11 |
| **Passwords** | 12 |
| **OAuth** | 2, 5, 7, 16, 17, 20 |
| **JWT** | 2, 6, 18, 19 |
| **Refresh tokens** | 1, 8, 13 |
| **Microservices** | 3, 23 |
| **SQL injection / XSS** | 4, 27, 28 |
| **CSRF** | 9, 29 |
| **RBAC/ABAC** | 21, 22 |
| **Encryption** | 24, 25, 26 |
| **SSO** | 10 |
| **Rate limiting** | 30, 34 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can explain OAuth 2.0 authorization code flow
- [ ] Can describe JWT structure and validation
- [ ] Can compare JWT vs session-based auth
- [ ] Can explain bcrypt for passwords
- [ ] Can prevent SQL injection, XSS, CSRF
- [ ] Can discuss 401 vs 403
- [ ] Can design refresh token rotation
- [ ] Know OWASP Top 10
- [ ] Can handle token theft, race conditions

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: Login design, OAuth vs JWT, Microservices auth,
            SQLi/XSS, OAuth flow, JWT vs Session, Third-party API,
            Token theft, CSRF, Enterprise SSO
FULL LIST: 35+ questions — Auth, OAuth, JWT, encryption, attacks
CONCEPTS: All from 01–07
```

---

**Prev: [[07_Tricks-and-Recognition]]**
