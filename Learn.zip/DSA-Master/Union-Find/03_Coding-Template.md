# Union-Find — Coding Template

> **Permanent Recall:** Memorize the UF class with path compression + union by rank. Python: list for parent/rank. C++: vector. Rust: Vec with ownership in struct, impl block. Cycle detection = find(u)==find(v) before union.

---

## Basic Union-Find Class

### Python

```python
class UnionFind:
    def __init__(self, n: int):
        self.parent = list(range(n))
        self.rank = [0] * n
        self.count = n  # number of components

    def find(self, x: int) -> int:
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # path compression
        return self.parent[x]

    def union(self, x: int, y: int) -> bool:
        rx, ry = self.find(x), self.find(y)
        if rx == ry:
            return False
        if self.rank[rx] < self.rank[ry]:
            rx, ry = ry, rx
        self.parent[ry] = rx
        if self.rank[rx] == self.rank[ry]:
            self.rank[rx] += 1
        self.count -= 1
        return True

    def connected(self, x: int, y: int) -> bool:
        return self.find(x) == self.find(y)
```

### C++

```cpp
class UnionFind {
public:
    vector<int> parent, rank;
    int count;

    UnionFind(int n) : parent(n), rank(n, 0), count(n) {
        iota(parent.begin(), parent.end(), 0);
    }

    int find(int x) {
        if (parent[x] != x)
            parent[x] = find(parent[x]);  // path compression
        return parent[x];
    }

    bool unite(int x, int y) {
        int rx = find(x), ry = find(y);
        if (rx == ry) return false;
        if (rank[rx] < rank[ry]) swap(rx, ry);
        parent[ry] = rx;
        if (rank[rx] == rank[ry]) rank[rx]++;
        count--;
        return true;
    }

    bool connected(int x, int y) {
        return find(x) == find(y);
    }
};
```

### Rust

```rust
pub struct UnionFind {
    parent: Vec<usize>,
    rank: Vec<usize>,
    pub count: usize,
}

impl UnionFind {
    pub fn new(n: usize) -> Self {
        UnionFind {
            parent: (0..n).collect(),
            rank: vec![0; n],
            count: n,
        }
    }

    pub fn find(&mut self, x: usize) -> usize {
        if self.parent[x] != x {
            self.parent[x] = self.find(self.parent[x]);  // path compression
        }
        self.parent[x]
    }

    pub fn union(&mut self, x: usize, y: usize) -> bool {
        let rx = self.find(x);
        let ry = self.find(y);
        if rx == ry {
            return false;
        }
        let (rx, ry) = if self.rank[rx] < self.rank[ry] {
            (ry, rx)
        } else {
            (rx, ry)
        };
        self.parent[ry] = rx;
        if self.rank[rx] == self.rank[ry] {
            self.rank[rx] += 1;
        }
        self.count -= 1;
        true
    }

    pub fn connected(&mut self, x: usize, y: usize) -> bool {
        self.find(x) == self.find(y)
    }
}
```

---

## Connected Components Count

```python
# Python
def count_components(n: int, edges: list[list[int]]) -> int:
    uf = UnionFind(n)
    for u, v in edges:
        uf.union(u, v)
    return uf.count
```

```cpp
// C++
int countComponents(int n, vector<vector<int>>& edges) {
    UnionFind uf(n);
    for (auto& e : edges)
        uf.unite(e[0], e[1]);
    return uf.count;
}
```

```rust
// Rust
fn count_components(n: i32, edges: Vec<Vec<i32>>) -> i32 {
    let mut uf = UnionFind::new(n as usize);
    for e in edges {
        uf.union(e[0] as usize, e[1] as usize);
    }
    uf.count as i32
}
```

---

## Detect Cycle in Undirected Graph

```python
# Python
def has_cycle(n: int, edges: list[list[int]]) -> bool:
    uf = UnionFind(n)
    for u, v in edges:
        if uf.find(u) == uf.find(v):  # same component before adding edge
            return True
        uf.union(u, v)
    return False
```

```cpp
// C++
bool hasCycle(int n, vector<vector<int>>& edges) {
    UnionFind uf(n);
    for (auto& e : edges) {
        if (uf.find(e[0]) == uf.find(e[1]))
            return true;
        uf.unite(e[0], e[1]);
    }
    return false;
}
```

```rust
// Rust
fn has_cycle(n: i32, edges: Vec<Vec<i32>>) -> bool {
    let mut uf = UnionFind::new(n as usize);
    for e in edges {
        let (u, v) = (e[0] as usize, e[1] as usize);
        if uf.find(u) == uf.find(v) {
            return true;
        }
        uf.union(u, v);
    }
    false
}
```

---

## Accounts Merge Pattern (Group by Email)

```python
# Python - LC 721
def accounts_merge(accounts: list[list[str]]) -> list[list[str]]:
    email_to_id = {}
    id_to_email = {}
    idx = 0
    for acc in accounts:
        for i in range(1, len(acc)):
            if acc[i] not in email_to_id:
                email_to_id[acc[i]] = idx
                id_to_email[idx] = acc[i]
                idx += 1
    uf = UnionFind(idx)
    for acc in accounts:
        for i in range(2, len(acc)):
            uf.union(email_to_id[acc[1]], email_to_id[acc[i]])
    root_to_emails = defaultdict(list)
    for i in range(idx):
        root_to_emails[uf.find(i)].append(id_to_email[i])
    result = []
    for acc in accounts:
        root = uf.find(email_to_id[acc[1]])
        if root_to_emails[root]:
            result.append([acc[0]] + sorted(root_to_emails[root]))
            root_to_emails[root] = []
    return result
```

```cpp
// C++ - LC 721 (simplified structure)
// Key: map email→id, union emails in same account, group by root
```

```rust
// Rust - LC 721
// Key: HashMap email→usize, UnionFind(idx), union emails, group by find(i)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
INIT:        parent[i]=i, rank[i]=0, count=n
FIND:        if parent[x]!=x: parent[x]=find(parent[x]); return parent[x]
UNION:       rx,ry=find(x),find(y); if rx==ry return; attach smaller under larger
CYCLE:       if find(u)==find(v) before union → cycle
COMPONENTS:  return uf.count or count parent[i]==i
ACCOUNTS:    email→id map, union same-account emails, group by root
RUST:        &mut self for find/union (modifies parent)
```

---

## 30-SECOND REVISION BOX

```
□ parent[i]=i, rank[i]=0
□ find: recurse + parent[x]=find(parent[x])
□ union: find both, if same return false, else attach by rank
□ Cycle: find(u)==find(v) before union
□ Components: uf.count or count roots
□ Rust: impl UnionFind { pub fn find(&mut self, x: usize) }
```
