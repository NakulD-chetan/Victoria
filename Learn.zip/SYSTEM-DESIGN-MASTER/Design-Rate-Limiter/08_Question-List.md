# Design Rate Limiter — Question List

> **Permanent Recall:** Core question: "Design a rate limiter." Variations: rate limit by endpoint AND user, distributed design, microservices, DDoS protection. Related: API gateway, throttling, quota systems.

---

## Direct Variations

| Question | Twist | Key addition |
|----------|-------|--------------|
| Design a rate limiter | Base | Algorithms, Redis, distributed |
| Rate limit by API endpoint AND user | Multi-dimensional | Composite key: `user:endpoint`; different limits per endpoint |
| Design a **distributed** rate limiter | Scale | Redis cluster, Lua atomicity, no in-memory |
| How to handle rate limiting in **microservices**? | Architecture | Sidecar, API gateway, or shared Redis per service |
| Design a **DDoS protection** system | Security focus | Rate limiter + IP blacklist, CDN, anomaly detection |
| Rate limit for **serverless** (Lambda) | Stateless | Must use external store (Redis/DynamoDB); no local state |
| **Sliding window** rate limiter implementation | Algorithm focus | Redis sorted set + ZREMRANGEBYSCORE; or counter formula |
| **Token bucket** vs **fixed window** — when to use which? | Trade-off | Token bucket: bursts, smooth; fixed: simple, boundary spike |
| Rate limit **different tiers** (free vs paid users) | Multi-tenant | Rule engine: user tier → limit config |
| **Quota** vs **rate limit** — design both | Two concepts | Rate: requests per window; Quota: total over day/month; different counters |

---

## Related Questions

| Question | Connection |
|----------|------------|
| Design an API Gateway | Rate limiter is a core gateway feature |
| Design a URL shortener | Often includes rate limiting (e.g., 100 create/min) |
| Design Twitter / social API | Rate limits per endpoint, per user tier |
| Design a notification system | Rate limit per user (e.g., max 5 marketing emails/day) |
| Design a search engine | Rate limit crawl, API search requests |
| How does **Kong** rate limiting work? | Plugin-based; Redis or local; fixed/sliding/token bucket |
| Design **throttling** for a queue consumer | Similar to rate limit; may queue instead of reject |

---

## Follow-up / Deep-Dive Questions

| Question | What to cover |
|----------|---------------|
| How do you prevent **race conditions** in Redis? | Lua scripts; single atomic read-modify-write |
| What if **Redis goes down**? | Fail open vs fail closed; circuit breaker |
| How do you handle **clock skew** across servers? | Use Redis TIME; store timestamps in Redis |
| Can users **bypass** rate limits? | New API key = new identity; add IP limit, abuse detection |
| How to **monitor** rate limiting? | 429 rate per identity/endpoint; Redis latency; alerts |
| **Multi-region** rate limiting? | Per-region Redis vs global; trade-off: latency vs consistency |
| How to **hot-reload** rate limit rules? | Config server; periodic refresh; or event-driven |

---

## LeetCode / Coding Style

| Question | Focus |
|----------|-------|
| Implement rate limiter (in-memory) | Token bucket or sliding window; single process |
| Rate limiter with Redis | Lua script; INCR or sorted set |
| Design logger rate limiter (359) | "At most 10 per 10 seconds" — sliding window |

---

## Full Question Set (15+)

1. Design a rate limiter that limits requests per user.
2. Design a rate limiter that limits requests per API endpoint and per user.
3. Design a **distributed** rate limiter for a globally distributed API.
4. How would you implement rate limiting in a **microservices** architecture?
5. Design a system to protect against **DDoS** attacks.
6. What's the difference between **token bucket** and **leaky bucket**?
7. Why does **fixed window** have a boundary problem? How do you fix it?
8. Implement a **sliding window** rate limiter using Redis.
9. How do you make Redis operations **atomic** for rate limiting?
10. What happens when your rate limit store (e.g., Redis) **fails**?
11. Design rate limiting for **different user tiers** (free vs premium).
12. How do you handle **clock skew** in distributed rate limiting?
13. Design **quota** management (e.g., 1000 API calls per month).
14. How does **Kong** or **Nginx** implement rate limiting?
15. Rate limiting for **serverless** functions — how?
16. How would you **detect and prevent** rate limit bypass?

---

## Question Clustering

```
CORE:        Design rate limiter, distributed rate limiter
ALGORITHM:   Token bucket vs fixed vs sliding, boundary spike
IMPLEMENT:   Redis, Lua, atomicity, key format
FAULT:       Redis down, fail open/closed, clock skew
SCALE:       Multi-region, microservices, serverless
SECURITY:    DDoS, bypass, abuse detection
RELATED:     API gateway, throttling, quota
```
