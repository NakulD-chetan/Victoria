# Design Twitter/X Feed — Tricks and Recognition

> **Permanent Recall:** Key insights: **hybrid fan-out is the winning answer**. Redis sorted sets for timeline. Pre-compute home timeline for non-celebrities. Pull on demand for celebrities—<1% users = >50% fan-out cost. Snowflake IDs for globally unique time-ordered IDs. **This is THE most commonly asked design question** at FAANG. Recognition: feed + social graph + high read ratio → Twitter/Instagram pattern.

---

## The Winning Answer (Memorize)

```
    HYBRID FAN-OUT
    • Push (fan-out on write) for users with <100K followers
    • Pull (fan-out on read) for celebrities (>100K followers)
    • <1% of users are celebrities, but they cause >50% of fan-out cost
    • Eventual consistency OK for feed
    • Redis sorted sets for timeline: ZADD timeline:{user_id} timestamp tweet_id
```

> **FAANG Tip:** If you say "hybrid" and "celebrity" in the first 2 minutes of the fan-out discussion, you've signaled you know the answer. Then elaborate.

---

## Redis Sorted Sets for Timeline

| Operation | Command | Use case |
|-----------|---------|----------|
| Add tweet | `ZADD timeline:{user_id} timestamp tweet_id` | Fan-out push |
| Get feed | `ZREVRANGE timeline:{user_id} 0 19` | Latest 20 tweets |
| Trim | `ZREMRANGEBYRANK timeline:{user_id} 0 -801` | Keep last 800 |
| Score | Use timestamp or Snowflake as score | Chronological order |

**Why sorted set:** O(log N) insert, O(log N + K) range query. Perfect for "last K tweets" in order.

---

## Pre-Compute vs On-Demand

| User type | Timeline computation | When |
|-----------|----------------------|------|
| **Normal** | Pre-computed in Redis | On write (fan-out) |
| **Celebrity follower** | Merge on read | When user loads feed |
| **New user** | Cold start: fetch from followees | First load; then populate cache |

**Recognition:** "Pre-compute when cheap (few followers); compute on read when expensive (many followers)."

---

## Pareto Principle: Celebrity Cost

```
    CELEBRITY COST (order of magnitude)

    Normal user:  200 followers  × 5 tweets/day  = 1,000 fan-out writes/day
    Celebrity:    10M followers  × 5 tweets/day  = 50M fan-out writes/day

    1 celebrity ≈ 50,000 normal users
    Top 1,000 celebrities ≈ 50M normal users
```

<1% of users (celebrities) → >50% of fan-out cost. Optimizing for them is mandatory.

---

## Snowflake IDs

| Property | Why it matters |
|----------|----------------|
| **Globally unique** | No coordination across servers |
| **Time-ordered** | Sort by ID ≈ sort by time |
| **64-bit** | Fits in long; index-friendly |
| **Structure** | timestamp (41b) + machine (10b) + sequence (12b) |

**Use:** `tweet_id` for tweets; use as sort key for timeline. No need for separate `created_at` in many cases.

---

## Recognition: "This is Twitter"

| Clues in problem | Implies |
|------------------|---------|
| "Feed" + "follow" + "posts" | Social feed; fan-out problem |
| "Home timeline" | Merge of multiple users' content |
| "Millions of users" | Read-heavy; cache critical |
| "Real-time" | Low latency; maybe WebSocket |
| "Search" | Elasticsearch |
| "Trending" | Stream processing |

**Pattern:** Social graph + timeline + read-heavy → Twitter/Instagram/LinkedIn feed. Same core design.

---

## Quick Recognition Checklist

When you hear "design a feed" or "design Twitter":

| Item | Instant recall |
|------|----------------|
| Core problem | Fan-out |
| Solution | Hybrid (push + pull) |
| Cache | Redis sorted sets |
| Timeline key | `timeline:{user_id}` |
| Celebrity threshold | ~100K followers |
| Consistency | Eventual OK |
| Tweet ID | Snowflake |
| Media | S3 + CDN |
| Search | Elasticsearch |

---

## Most Commonly Asked Design Question

**Twitter/Design a Feed** is the #1 system design question at FAANG (or top 3). Reasons:
- Covers: capacity, caching, async, trade-offs, scale
- Has a clear "trick" (hybrid fan-out) that separates prepared from unprepared
- Real-world system everyone understands
- Extensible: search, trending, ads, recommendations

**If you prepare one design thoroughly, make it this one.**

---

## One-Sentence Summaries

| Component | One-liner |
|-----------|-----------|
| Fan-out | Hybrid: push for normals, pull for celebrities |
| Timeline | Redis sorted set per user; ZREVRANGE for feed |
| Tweet ID | Snowflake: unique, time-ordered, no coordination |
| Media | S3 + CDN; never serve from origin |
| Search | Elasticsearch; index text + hashtags |
| Trending | Kafka + Flink; rolling window over hashtags |
| Consistency | Eventual; acceptable for feed |

---

## 30-SECOND REVISION BOX

```
WINNING: Hybrid fan-out
REDIS: Sorted sets, ZADD/ZREVRANGE
CELEBRITY: <1% users, >50% cost; pull on read
SNOWFLAKE: Unique, time-ordered tweet IDs
RECOGNITION: Feed + social graph = Twitter pattern
#1 QUESTION: Most commonly asked; prepare thoroughly
```

---

**Next: [[08_Question-List]]**
