# Distributed Systems — Mental Model

> **Permanent Recall:** Think of distributed systems as an "orchestra without conductor"—each node must coordinate with others without a single source of truth. Partial failures mean "some work, some don't." The FLP result says consensus is impossible with one faulty node in async networks (intuition: you can never be sure). Consensus is like committee voting. Distributed locks need fencing. There is no global clock—use logical time. Use the decision flowchart to choose the right coordination approach.

---

## Orchestra Without Conductor Analogy

```
ORCHESTRA WITHOUT CONDUCTOR:

  Violin    Cello     Flute    Drums
  ┌─────┐   ┌─────┐   ┌─────┐   ┌─────┐
  │     │   │     │   │     │   │     │
  │  🎻 │◄─►│  🎻 │◄─►│  🎷 │◄─►│  🥁 │
  └─────┘   └─────┘   └─────┘   └─────┘
       │         │         │         │
       └─────────┴─────────┴─────────┘
              Must coordinate via:
              - Eye contact (heartbeats)
              - Sheet music (shared state)
              - Cues (messages)
```

**Mapping:** Each musician = node. No conductor = no single leader (or leader elected dynamically). Coordination via messages and shared conventions. One musician misses a beat = partial failure.

> **FAANG Tip:** This analogy explains why coordination is hard—no central authority to say "go."

---

## Partial Failure Mental Model

**Key insight:** In a single machine, it's all or nothing. In distributed systems, **some nodes work, some don't.**

| Scenario | Single Machine | Distributed |
|----------|----------------|-------------|
| "Is it down?" | Yes or No | Some nodes yes, some no |
| "Did message arrive?" | Maybe | Might be in-flight, lost, delayed |
| "What's the state?" | One source | Divergent replicas |

**Mental model:** Every operation is a "maybe." Design for timeouts, retries, idempotency.

---

## FLP Impossibility Result — Intuition

**Theorem:** In an asynchronous network with one faulty process, consensus is impossible (no deterministic algorithm always terminates).

**Intuition:** You can never distinguish "message delayed" from "node crashed." If you wait forever, you might block. If you give up, you might have been wrong. So you can't guarantee both safety and liveness in the worst case.

**Practical takeaway:** Real systems use timeouts, fault detectors, and accept "eventual" guarantees—they work in practice despite FLP.

---

## Consensus Mental Model — Committee Voting

```
COMMITTEE VOTING:

  Proposal: "Value = X"
  
  Member 1 ──► ✓  (vote)
  Member 2 ──► ✓  
  Member 3 ──► ✗  
  Member 4 ──► ✓  
  Member 5 ──► ?  (didn't respond)
  
  Majority (3/5) = decided
  Minority can't overturn
  One slow/missing = still OK
```

**Mapping:** Proposer = member with idea. Acceptors = voters. Quorum = majority. One faulty = can't block if majority is correct.

---

## How to Think About Distributed Locks

**Wrong mental model:** Lock = "I have exclusive access." Release when done.

**Right mental model:** Lock = "I *believed* I had exclusive access." A slow client might still be acting after "releasing" (or lock expiry). Use **fencing tokens**: monotonic counter; reject operations with lower token. Old "lock holder" gets rejected even if it thinks it holds the lock.

---

## Time in Distributed Systems — No Global Clock

**Reality:** Clocks on different nodes drift. "Happened at the same time" is meaningless without coordination.

| Approach | Mental Model |
|----------|--------------|
| **Wall clock** | Unreliable; use only for human display |
| **Logical clocks (Lamport)** | "A happened before B" order, not real time |
| **Vector clocks** | "A and B concurrent" vs "A before B" |

**Key:** For ordering and consistency, use logical or hybrid clocks—not wall clock.

---

## Decision Flowchart

```mermaid
flowchart TD
    A[Need coordination?] --> B{What type?}
    B --> C[Leader election]
    B --> D[Distributed lock]
    B --> E[Config / discovery]
    B --> F[Consensus on state]
    
    C --> G[Use Raft / Zab]
    D --> H{Strong consistency?}
    H -->|Yes| I[ZooKeeper + fencing]
    H -->|Weaker OK| J[Redis RedLock]
    
    E --> K[ZooKeeper, etcd]
    F --> L[Raft, Paxos]
    
    M[Network partition?] --> N[Quorum, odd N]
    O[Clock ordering?] --> P[Lamport / vector clocks]
```

---

## ASCII Decision Flowchart

```
                    Need coordination?
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
   Leader election   Lock           Config/State
         │               │               │
         ▼               ▼               ▼
      Raft/Zab      Fencing token?   ZooKeeper
      (quorum)      ZK + token       etcd
                         │
                    Redis RedLock
                    (if weaker OK)
```

---

## Mental Model Summary Table

| Concept | Mental Model |
|---------|--------------|
| **Orchestra** | No conductor; coordinate via messages |
| **Partial failure** | Some nodes up, some down; design for maybe |
| **FLP** | Can't always distinguish delay from crash |
| **Consensus** | Committee voting; majority decides |
| **Distributed lock** | Need fencing; old holder rejected |
| **Time** | No global clock; use logical/vector |
| **Split brain** | Two leaders; prevent via quorum |

---

## 30-SECOND REVISION BOX

```
ORCHESTRA: No conductor, coordinate via cues
PARTIAL: Some up, some down—design for maybe
FLP: Consensus impossible in worst-case async
CONSENSUS: Committee voting, majority
LOCKS: Fencing token mandatory
TIME: No global clock → Lamport/vector
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
