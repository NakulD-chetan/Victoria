# Queue — Problem List

> **30 problems, 10 MUST-DO. Focus on BFS and monotonic deque — the most tested queue patterns at FAANG. Study plan: Easy (Day 1–2) → Medium (Day 3–5) → Hard (Day 6–7).**

---

## 10 MUST-DO (Priority Order)

| # | LeetCode | Problem | Concept | Why MUST-DO |
|---|----------|---------|---------|-------------|
| 1 | **102** | Binary Tree Level Order Traversal | BFS + level tracking | Classic; every interview |
| 2 | **239** | Sliding Window Maximum | Monotonic deque | FAANG favorite; Google, Meta |
| 3 | **200** | Number of Islands | BFS/DFS on grid | Extremely common |
| 4 | **127** | Word Ladder | BFS shortest path | Classic BFS; Meta, Amazon |
| 5 | **542** | 01 Matrix | Multi-source BFS | Tests BFS variant |
| 6 | **994** | Rotting Oranges | Multi-source BFS | Same pattern as 542 |
| 7 | **207** | Course Schedule | Kahn's (queue) | Topological sort |
| 8 | **232** | Implement Queue using Stacks | Design | Design baseline |
| 9 | **225** | Implement Stack using Queues | Design | Paired with 232 |
| 10 | **752** | Open the Lock | BFS shortest path | Classic BFS; state space |

---

## Easy (10 Problems)

| # | LeetCode | Problem | Concept |
|---|----------|---------|---------|
| 1 | 232 | Implement Queue using Stacks | Two stacks |
| 2 | 225 | Implement Stack using Queues | Two queues |
| 3 | 102 | Binary Tree Level Order Traversal | BFS + levels |
| 4 | 107 | Binary Tree Level Order Traversal II | BFS + reverse |
| 5 | 111 | Minimum Depth of Binary Tree | BFS (early exit) |
| 6 | 559 | Maximum Depth of N-ary Tree | BFS |
| 7 | 637 | Average of Levels in Binary Tree | BFS + level |
| 8 | 933 | Number of Recent Calls | Sliding window (queue) |
| 9 | 346 | Moving Average from Data Stream | Queue (sliding sum) |
| 10 | 622 | Design Circular Queue | Circular queue |

---

## Medium (14 Problems)

| # | LeetCode | Problem | Concept |
|---|----------|---------|---------|
| 1 | 239 | Sliding Window Maximum | **Monotonic deque** |
| 2 | 200 | Number of Islands | BFS on grid |
| 3 | 127 | Word Ladder | BFS shortest path |
| 4 | 542 | 01 Matrix | Multi-source BFS |
| 5 | 994 | Rotting Oranges | Multi-source BFS |
| 6 | 207 | Course Schedule | Kahn's (queue) |
| 7 | 210 | Course Schedule II | Kahn's + order |
| 8 | 286 | Walls and Gates | Multi-source BFS |
| 9 | 130 | Surrounded Regions | BFS from boundary |
| 10 | 429 | N-ary Tree Level Order Traversal | BFS |
| 11 | 515 | Find Largest Value in Each Tree Row | BFS + level max |
| 12 | 662 | Maximum Width of Binary Tree | BFS + indexing |
| 13 | 752 | Open the Lock | BFS shortest path |
| 14 | 787 | Cheapest Flights Within K Stops | BFS variant (weighted) |

---

## Hard (6 Problems)

| # | LeetCode | Problem | Concept |
|---|----------|---------|---------|
| 1 | 126 | Word Ladder II | BFS + path reconstruction |
| 2 | 269 | Alien Dictionary | Topological sort (Kahn's) |
| 3 | 864 | Shortest Path to Get All Keys | BFS + state |
| 4 | 1293 | Shortest Path in a Grid with Obstacles | BFS + state |
| 5 | 675 | Cut Off Trees for Golf Event | BFS multiple times |
| 6 | 317 | Shortest Distance from All Buildings | Multi-BFS |

---

## Concept Tags

| Tag | Problems |
|-----|----------|
| **BFS + level tracking** | 102, 107, 429, 515, 637, 662 |
| **BFS shortest path** | 127, 752 |
| **Multi-source BFS** | 542, 994, 286 |
| **BFS on grid** | 200, 130 |
| **Monotonic deque** | 239 |
| **Kahn's / Topological** | 207, 210, 269 |
| **Design (queue/stack)** | 232, 225, 622, 346, 933 |
| **Circular queue** | 622 |

---

## Study Plan (7 Days)

### Day 1: Basics + BFS Intro
- [ ] 232 Implement Queue using Stacks
- [ ] 225 Implement Stack using Queues
- [ ] 102 Binary Tree Level Order Traversal ⭐
- [ ] 111 Minimum Depth of Binary Tree

### Day 2: BFS Level Order
- [ ] 107 Level Order Traversal II
- [ ] 637 Average of Levels
- [ ] 429 N-ary Tree Level Order
- [ ] 515 Largest Value in Each Row

### Day 3: BFS on Grid + Shortest Path
- [ ] 200 Number of Islands ⭐
- [ ] 127 Word Ladder ⭐
- [ ] 542 01 Matrix ⭐
- [ ] 994 Rotting Oranges ⭐

### Day 4: Monotonic Deque
- [ ] 239 Sliding Window Maximum ⭐
- [ ] 933 Number of Recent Calls
- [ ] 346 Moving Average

### Day 5: Topological Sort + Design
- [ ] 207 Course Schedule ⭐
- [ ] 210 Course Schedule II
- [ ] 622 Design Circular Queue
- [ ] 286 Walls and Gates

### Day 6: Hard
- [ ] 752 Open the Lock
- [ ] 1293 Shortest Path with Obstacles
- [ ] 864 Shortest Path to Get All Keys

### Day 7: Revision + Mock
- [ ] Re-solve all 10 MUST-DO
- [ ] Time yourself: 15 min per problem
- [ ] Explain BFS O(V+E) and monotonic deque O(n) to imaginary interviewer

---

## Problem-to-File Mapping

| Need help with... | See file |
|-------------------|----------|
| Why BFS? Why queue? | Concept.md, Mental-Model.md |
| BFS template | Coding-Template.md |
| Monotonic deque template | Coding-Template.md |
| How to explain in interview | Interview-Thinking.md |
| Common bugs | Common-Mistakes.md |
| Edge cases | Edge-Cases.md |
| Is this a queue problem? | Tricks-and-Recognition.md |

---

## BFS Problems (Core)

| LeetCode | Problem | Notes |
|----------|---------|-------|
| 102 | Level Order Traversal | Must know |
| 200 | Number of Islands | Grid BFS |
| 127 | Word Ladder | Graph BFS |
| 542 | 01 Matrix | Multi-source |
| 994 | Rotting Oranges | Multi-source |
| 207 | Course Schedule | Kahn's |
| 752 | Open the Lock | State BFS |

---

## Monotonic Deque Problems

| LeetCode | Problem | Notes |
|----------|---------|-------|
| 239 | Sliding Window Maximum | **The** classic |
| (Few others) | Most "sliding max/min" are this pattern | |

---

## FINAL MEMORY COMPRESSION BLOCK

```
MUST-DO:     102, 239, 200, 127, 542, 994, 207, 232, 225, 752
BFS:         102, 200, 127, 542, 994, 207
MONOTONIC:   239
DESIGN:      232, 225, 622
STUDY:       7 days; Day 3 = grid BFS; Day 4 = monotonic deque
```
