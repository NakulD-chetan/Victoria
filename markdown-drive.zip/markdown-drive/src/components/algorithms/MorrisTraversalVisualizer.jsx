import { useRef, useEffect, useCallback, useState } from 'react';
import { MorrisTraversal, STEPS_VISIT, STEPS_THREAD, STEPS_UNTHREAD } from '../../lib/algorithms/morris-traversal';
import { useMorrisStore } from '../../stores/morris-traversal-store';
import MorrisTraversalCanvas from './MorrisTraversalCanvas';
import CodePanel from './CodePanel';
import EventLog from './EventLog';

export default function MorrisTraversalVisualizer({ config }) {
  const morrisRef = useRef(new MorrisTraversal(0));
  const canvasRef = useRef(null);
  const autoIntervalRef = useRef(null);
  const codeStepTimeoutRef = useRef(null);
  const startedRef = useRef(false);

  const {
    treeIdx, autoActive, autoRate, speed,
    currentStep, totalSteps,
    addLog, recordStep, setStep, reset, startTime,
  } = useMorrisStore();

  const [codeOpen, setCodeOpen] = useState(false);
  const [result, setResult] = useState([]);
  const [isDone, setIsDone] = useState(false);

  useEffect(() => {
    morrisRef.current.reset(treeIdx);
    startedRef.current = false;
    setResult([]);
    setIsDone(false);
    canvasRef.current?.updateState({
      currentVal: null, predVal: null, visitedSet: new Set(),
      threads: [], resultList: [],
    });
  }, [treeIdx]);

  const highlightSteps = useCallback((steps) => {
    if (codeStepTimeoutRef.current) clearTimeout(codeStepTimeoutRef.current);
    let i = 0;
    function next() {
      if (i >= steps.length) { setTimeout(() => setStep(null), 600); return; }
      setStep(steps[i]);
      i++;
      codeStepTimeoutRef.current = setTimeout(next, 120 / speed);
    }
    next();
  }, [setStep, speed]);

  const doStep = useCallback(() => {
    if (isDone) return;

    if (!startedRef.current) {
      morrisRef.current.start();
      startedRef.current = true;
      const t = ((performance.now() - startTime) / 1000).toFixed(1);
      addLog({ time: t + 's', type: 'refill', message: 'Traversal started, current = root' });
      canvasRef.current?.updateState({
        currentVal: morrisRef.current.current?.val ?? null,
        predVal: null,
        visitedSet: new Set(),
        threads: [],
        resultList: [],
      });
      return;
    }

    const event = morrisRef.current.step();
    const t = ((performance.now() - startTime) / 1000).toFixed(1);
    recordStep();

    if (event.action === 'done') {
      setIsDone(true);
      addLog({ time: t + 's', type: 'allow', message: `Traversal complete! Result: [${(event.result || []).join(', ')}]` });
      if (autoIntervalRef.current) {
        clearInterval(autoIntervalRef.current);
        autoIntervalRef.current = null;
        useMorrisStore.getState().toggleAuto?.();
      }
      return;
    }

    if (event.action === 'visit') {
      setResult([...event.result]);
      addLog({ time: t + 's', type: 'allow', message: `Visit node ${event.node} → result: [${event.result.join(', ')}]` });
      highlightSteps(STEPS_VISIT);
      canvasRef.current?.addAnim('visit', { node: event.node, dur: 500 });
      const visited = new Set(event.result);
      canvasRef.current?.updateState({
        currentVal: event.next,
        predVal: null,
        visitedSet: visited,
        threads: morrisRef.current.getThreads(),
        resultList: event.result,
      });
    } else if (event.action === 'create-thread') {
      addLog({ time: t + 's', type: 'refill', message: `Create thread: ${event.predecessor} → ${event.threadTo}, move left to ${event.next}` });
      highlightSteps(STEPS_THREAD);
      canvasRef.current?.addAnim('thread', { from: event.threadFrom, to: event.threadTo, dur: 700 });
      canvasRef.current?.updateState({
        currentVal: event.next,
        predVal: null,
        threads: morrisRef.current.getThreads(),
      });
    } else if (event.action === 'remove-thread') {
      setResult([...event.result]);
      addLog({ time: t + 's', type: 'allow', message: `Remove thread ${event.predecessor} → ${event.threadTo}, visit ${event.node} → [${event.result.join(', ')}]` });
      highlightSteps(STEPS_UNTHREAD);
      canvasRef.current?.addAnim('visit', { node: event.node, dur: 500 });
      const visited = new Set(event.result);
      canvasRef.current?.updateState({
        currentVal: event.next,
        predVal: null,
        visitedSet: visited,
        threads: morrisRef.current.getThreads(),
        resultList: event.result,
      });
    }
  }, [isDone, startTime, addLog, recordStep, highlightSteps, speed]);

  const handleReset = useCallback(() => {
    morrisRef.current.reset(treeIdx);
    startedRef.current = false;
    setResult([]);
    setIsDone(false);
    reset();
    addLog({ time: '0.0s', type: 'refill', message: 'Reset — ready to start' });
    canvasRef.current?.updateState({
      currentVal: null, predVal: null, visitedSet: new Set(),
      threads: [], resultList: [],
    });
  }, [treeIdx, reset, addLog]);

  const handleRunAll = useCallback(() => {
    handleReset();
    setTimeout(() => {
      morrisRef.current.start();
      startedRef.current = true;
      let stepCount = 0;
      const iv = setInterval(() => {
        if (morrisRef.current.done || stepCount > 50) { clearInterval(iv); return; }
        doStep();
        stepCount++;
      }, 600 / speed);
    }, 100);
  }, [handleReset, doStep, speed]);

  useEffect(() => {
    if (autoActive && !isDone) {
      autoIntervalRef.current = setInterval(doStep, 800 / autoRate);
    } else if (autoIntervalRef.current) {
      clearInterval(autoIntervalRef.current);
      autoIntervalRef.current = null;
    }
    return () => { if (autoIntervalRef.current) clearInterval(autoIntervalRef.current); };
  }, [autoActive, autoRate, doStep, isDone]);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); doStep(); }
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [doStep, handleReset]);

  const { setTreeIdx, setAutoRate, setSpeed, toggleAuto } = useMorrisStore();

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <div className="dc-stats-inline">
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: 'var(--accent-secondary)' }}>{totalSteps}</span>
            <span className="dc-stat-chip__label">Steps</span>
          </div>
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: 'var(--accent)' }}>{result.length}</span>
            <span className="dc-stat-chip__label">Visited</span>
          </div>
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: isDone ? 'var(--accent)' : 'var(--accent-warm)' }}>
              {isDone ? 'Done' : startedRef.current ? 'Running' : 'Ready'}
            </span>
            <span className="dc-stat-chip__label">Status</span>
          </div>
          {result.length > 0 && (
            <div className="dc-stat-chip" style={{ flex: 1 }}>
              <span className="dc-stat-chip__value" style={{ fontSize: '12px', fontFamily: 'monospace' }}>
                [{result.join(', ')}]
              </span>
              <span className="dc-stat-chip__label">Inorder</span>
            </div>
          )}
        </div>
      </div>

      <MorrisTraversalCanvas ref={canvasRef} morrisRef={morrisRef} />

      <div className="dc-control-bar">
        <button className="dc-btn dc-btn--primary" onClick={doStep} disabled={isDone}>
          {!startedRef.current ? 'Start' : 'Next Step'}
        </button>
        <button className="dc-btn dc-btn--secondary" onClick={handleRunAll}>Run All</button>
        <button className={`dc-btn ${autoActive ? 'dc-btn--success' : 'dc-btn--outline'}`} onClick={toggleAuto} disabled={isDone}>
          {autoActive ? 'Stop Auto' : 'Auto Step'}
        </button>
        <div className="dc-control-bar__sep" />
        <div className="dc-slider-group">
          <label>Tree</label>
          <input type="range" min={0} max={2} value={treeIdx} onChange={(e) => { setTreeIdx(+e.target.value); handleReset(); }} />
          <span className="dc-slider-val">#{treeIdx + 1}</span>
        </div>
        <div className="dc-slider-group">
          <label>Speed</label>
          <input type="range" min={0.5} max={4} step={0.5} value={speed} onChange={(e) => setSpeed(+e.target.value)} />
          <span className="dc-slider-val">{speed}x</span>
        </div>
        <div className="dc-slider-group">
          <label>Auto</label>
          <input type="range" min={1} max={8} value={autoRate} onChange={(e) => setAutoRate(+e.target.value)} />
          <span className="dc-slider-val">{autoRate}/s</span>
        </div>
        <div className="dc-control-bar__sep" />
        <button className="dc-btn dc-btn--danger" onClick={handleReset}>Reset</button>
      </div>

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" />
              <polyline points="8 6 2 12 8 18" />
            </svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: codeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          {codeOpen && (
            <div className="dc-visualizer__code-wrap">
              <CodePanel code={config.code} activeStep={currentStep} languages={config.meta.languages} storeFn={useMorrisStore} />
            </div>
          )}
        </div>
        <div className="dc-visualizer__log-col">
          <EventLog storeFn={useMorrisStore} />
        </div>
      </div>

      <div className="dc-visualizer__shortcuts">
        <kbd>Space</kbd> Next Step <kbd>R</kbd> Reset
      </div>
    </div>
  );
}
