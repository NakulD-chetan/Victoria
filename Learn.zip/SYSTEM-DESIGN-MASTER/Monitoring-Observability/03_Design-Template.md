# Monitoring and Observability — Design Template

> **Permanent Recall:** Reusable templates for logging pipeline (ELK), metrics (Prometheus + Grafana), distributed tracing, alerting rules, health checks, and dashboards. Use these as blueprints when designing monitoring in system design interviews.

---

## Monitoring Stack Setup Template

```
                    MONITORING STACK ARCHITECTURE
                    
  [Services]     [Agents/Exporters]      [Storage]         [Visualization]
  
  API ──────►    Node Exporter    ──►   Prometheus   ──►   Grafana
  DB  ──────►    mysql_exporter         (metrics)           (dashboards)
  Cache ────►    redis_exporter         
  
  App logs ──►  Filebeat/Fluentd  ──►  Elasticsearch ──►  Kibana
                                       (logs)
  
  Traces ────►  OTel Collector   ──►   Jaeger        ──►  Jaeger UI
                                       (traces)
```

---

## Logging Pipeline Template (ELK)

```
[App] → stdout/stderr → Filebeat/Fluentd → Logstash → Elasticsearch → Kibana
```

**Structured log format:**
```json
{
  "timestamp": "2025-03-10T12:00:00Z",
  "level": "INFO",
  "service": "order-api",
  "trace_id": "abc123",
  "msg": "Order created",
  "order_id": "ord_xyz",
  "duration_ms": 45
}
```

| Component | Config |
|-----------|--------|
| **Filebeat** | Read from container stdout, add metadata |
| **Logstash** | Parse JSON, add `@timestamp`, drop PII |
| **Elasticsearch** | Index by `service`, `level`, `trace_id` |

---

## Metrics Collection Template (Prometheus + Grafana)

**Prometheus config (`prometheus.yml`):**
```yaml
scrape_configs:
  - job_name: 'order-api'
    static_configs:
      - targets: ['order-api:9090']
    metrics_path: /metrics
    scrape_interval: 15s
```

**Application metrics (RED for API):**
```
# Rate
http_requests_total{method="GET", path="/orders", status="200"}

# Errors
http_requests_total{status="5xx"}

# Duration
http_request_duration_seconds_bucket{le="0.1", path="/orders"}
```

**Grafana dashboard panels:**
- Rate: `rate(http_requests_total[5m])`
- Error rate: `rate(http_requests_total{status=~"5.."}[5m])`
- p99 latency: `histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))`

---

## Distributed Tracing Setup Template

```
[Service A] ──trace_id, span_id──► [Service B] ──► [Service C]
     │                                  │
     └── OTel SDK                       └── OTel SDK
              │                                  │
              └──────────► OTel Collector ──────┘
                                    │
                                    ▼
                                 Jaeger
```

**HTTP header propagation (W3C Trace Context):**
```
traceparent: 00-{trace_id}-{span_id}-01
```

**Span attributes:**
- `service.name`, `http.method`, `http.status_code`, `db.statement` (sanitized)

---

## Alerting Rules Template

```yaml
# Prometheus alerting rules
groups:
  - name: api-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        for: 5m
        annotations:
          summary: "Error rate > 5%"
      - alert: HighLatency
        expr: histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 5m
        annotations:
          summary: "p99 latency > 2s"
      - alert: InstanceDown
        expr: up == 0
        for: 2m
```

---

## Health Check Implementation Template

**Kubernetes probes:**
```yaml
livenessProbe:
  httpGet:
    path: /health/live
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 5

readinessProbe:
  httpGet:
    path: /health/ready
    port: 8080
  initialDelaySeconds: 5
  periodSeconds: 3
```

**Endpoint logic:**

| Endpoint | Liveness | Readiness |
|----------|----------|-----------|
| `/health/live` | Process alive (return 200) | — |
| `/health/ready` | — | DB connected, cache reachable? |

```python
# Liveness: simple 200
@app.get("/health/live")
def liveness():
    return {"status": "ok"}

# Readiness: check dependencies
@app.get("/health/ready")
def readiness():
    if not db.ping() or not cache.ping():
        raise HTTPException(503, "Dependencies unhealthy")
    return {"status": "ready"}
```

> **FAANG Tip:** "Liveness = restart if failing. Readiness = don't send traffic if failing. Different use cases."

---

## Dashboard Design Template

**Four Golden Signals layout:**

```
┌─────────────────┬─────────────────┬─────────────────┬─────────────────┐
│   LATENCY       │   TRAFFIC       │   ERRORS        │   SATURATION    │
│   p50, p95, p99 │   RPS           │   Error rate     │   CPU, Memory   │
│   [Graph]       │   [Graph]       │   [Graph]       │   [Graph]       │
└─────────────────┴─────────────────┴─────────────────┴─────────────────┘
```

**Per-service dashboard checklist:**
- Latency (p50, p95, p99)
- Request rate (RPS)
- Error rate
- Resource utilization (CPU, memory)
- Dependency health (if applicable)

> **FAANG Tip:** "Every service dashboard should have the four golden signals. Add RED/USE metrics per service type."

---

## Full Stack Architecture (ASCII)

```
  [API] [Auth] [DB]     Services
     │     │     │
     ├────┼─────┼──► Prometheus ──► Grafana (metrics)
     ├────┼─────┼──► Filebeat ───► Elasticsearch ──► Kibana (logs)
     └────┴─────┴──► OTel ───────► Jaeger (traces)
```

---

## 30-SECOND REVISION BOX

```
LOG PIPELINE: App → Filebeat → Logstash → ES → Kibana
METRICS: Prometheus scrape + Grafana
TRACING: OTel SDK → Collector → Jaeger
ALERTING: Prometheus rules, 5m for, threshold-based
HEALTH: liveness (alive), readiness (deps OK)
DASHBOARD: 4 golden signals always
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
