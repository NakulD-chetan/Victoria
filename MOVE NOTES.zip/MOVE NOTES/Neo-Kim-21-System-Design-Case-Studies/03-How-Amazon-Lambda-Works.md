# How Amazon Lambda Works - System Design

> Source: https://newsletter.systemdesign.one/p/how-does-aws-lambda-work

## One-Line Summary
AWS Lambda is a serverless compute service that runs your code in lightweight microVMs (Firecracker), automatically scaling from zero to thousands of instances without any server management.

## Key Requirements

### Functional
- Run code (functions) in response to events (HTTP requests, S3 uploads, queue messages)
- Support multiple runtimes (Node.js, Python, Java, Go, etc.)
- Accept code as zip files or container images
- Auto-scale based on traffic (including scale to zero)
- Pay only for actual execution time

### Non-Functional
- Low latency execution (warm starts in milliseconds)
- Handle 10+ trillion requests per month
- Tenant isolation (one customer's code can't affect another's)
- High availability across multiple availability zones
- Cost efficiency (no idle server costs)

## High-Level Architecture

```
Client Request
      |
  Invoke Service  (routes requests)
      |
  Assignment Service  (tracks which workers run which functions)
      |                 |
  Journal Log        Worker Pool
  (durable metadata)   |
                    Worker (EC2)
                      |
                  Firecracker (microVM manager)
                    /     \
              microVM 1  microVM 2  ...
              (your fn)  (other fn)
```

## Core Components Deep Dive

### 1. Invoke Service
- Entry point for all Lambda requests
- Routes each request to the correct worker
- Returns results back to the caller
- Handles load balancing across workers

### 2. Assignment Service
- **Tracks which workers** are running which Lambda function
- Runs in **leader-follower pattern** for high availability
- Checks if a worker is ready for another invocation
- Marks workers unavailable on errors
- Stores worker metadata in an external **journal log** for durability

### 3. Journal Log
- External durable storage for worker metadata
- Enables **quick failover** if the assignment service leader fails
- Leader writes to it, followers read from it
- Prevents orphaned workers during failures

### 4. Workers (EC2 Instances)
- The actual servers where your Lambda functions run
- Each worker hosts **multiple microVMs** via Firecracker
- Managed by the **Placement Service** which:
  - Leases workers for specific periods
  - Monitors worker health
  - Scales workers based on traffic

### 5. Firecracker (microVM Manager)
- Open-source lightweight VM manager built by AWS
- Runs **many microVMs on a single worker** (efficient resource usage)
- Provides **tenant-level isolation** (security between customers)
- Much lighter than full VMs -- boots in ~125ms
- Each microVM runs one customer's Lambda function

## Key Design Decisions

| Decision | Why |
|----------|-----|
| microVMs (not containers) | Strong tenant isolation + lightweight |
| Firecracker | Boot in ~125ms, run many per worker, secure isolation |
| Leader-follower assignment service | High availability for tracking workers |
| Journal log | Durable metadata survives leader failures |
| Placement service | Centralized worker lifecycle management |
| Container lazy-loading | Only download needed parts, reduces startup time |
| microVM snapshots | Cut cold start latency by 90% |

## Warm Start vs Cold Start

### Warm Start (99% of requests)
- An **existing microVM** handles the request
- Function code already loaded and initialized
- Very fast -- milliseconds latency
- This is the common case

### Cold Start (occasional)
- No available microVM -- **new one must be created**
- Steps: Launch microVM → Download code → Initialize runtime
- Takes extra time (can be seconds)
- **Solutions to reduce cold start latency:**
  1. **microVM Snapshots**: Save a running microVM's state, restore it later (90% faster)
  2. **Container Image Lazy Loading**: Only download the subset of container image needed to start serving (not the full image)
  3. **Provisioned Concurrency**: Keep microVMs warm and ready

## Scaling Strategies

1. **Horizontal scaling**: Add more workers across availability zones
2. **microVM density**: Run many functions on one worker via Firecracker
3. **Placement service**: Automatically leases/releases workers based on traffic
4. **Snapshot-based cold starts**: Pre-baked microVM states for fast scaling
5. **Multi-AZ deployment**: Workers spread across availability zones for HA

## Interview Tips

- Start with the **problem Lambda solves**: no server management, auto-scaling, pay-per-use
- Explain the **3 core services**: Invoke (routing), Assignment (tracking), Workers (execution)
- Know **warm start vs cold start** -- this is the most common Lambda interview question
- Mention **Firecracker microVMs** for tenant isolation (not containers!)
- Explain how **snapshots reduce cold start by 90%**
- Discuss tradeoffs: cold starts, execution time limits (15 min), statelessness
- Compare with: ECS/EKS (containers), EC2 (VMs) -- Lambda trades control for simplicity

## Quick Revision (5 bullet points)

1. **Lambda = serverless compute** with 3 key services: Invoke (routing), Assignment (tracking workers), Workers (execution via Firecracker microVMs)
2. **Firecracker microVMs** provide lightweight, secure tenant isolation -- many functions share one EC2 worker
3. **99% warm starts** (reuse existing microVM); cold starts need new microVM setup
4. **microVM snapshots** cut cold start latency by 90%; container lazy-loading downloads only needed image parts
5. **Journal log** stores worker metadata durably, enabling quick failover when assignment service leader fails
