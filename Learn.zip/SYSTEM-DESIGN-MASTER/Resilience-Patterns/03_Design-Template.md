# Resilience Patterns — Design Template

> **Permanent Recall:** Reusable templates for circuit breaker, rate limiter (Redis), retry with exponential backoff, bulkhead config, timeout config, and idempotency key. Code examples and config snippets provide implementation blueprints for interviews and production.

---

## Circuit Breaker Implementation Template

```java
// Pseudocode / Resilience4j style
CircuitBreakerConfig config = CircuitBreakerConfig.custom()
    .failureRateThreshold(50)        // Open at 50% failure
    .slidingWindowSize(10)          // Last 10 calls
    .waitDurationInOpenState(Duration.ofSeconds(30))  // Half-Open after 30s
    .permittedNumberOfCallsInHalfOpenState(3)        // 3 test calls
    .build();

CircuitBreaker circuitBreaker = CircuitBreaker.of("payment-service", config);

// Usage
Try.ofSupplier(CircuitBreaker.decorateSupplier(circuitBreaker, () -> 
    paymentClient.charge(amount)))
  .recover(throwable -> fallbackResponse);  // Graceful fallback
```

**YAML config example:**
```yaml
circuitbreaker:
  failureRateThreshold: 50
  waitDurationInOpenState: 30s
  slidingWindowSize: 10
  permittedNumberOfCallsInHalfOpenState: 3
```

---

## Rate Limiter Implementation Template (Redis)

```python
# Token bucket with Redis - Lua script for atomicity
# Key: user_id or IP; rate: 100 req/min

RATE_LIMIT_SCRIPT = """
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local window = tonumber(ARGV[2])
local current = redis.call('INCR', key)
if current == 1 then
    redis.call('EXPIRE', key, window)
end
if current <= limit then
    return 1  -- allow
else
    return 0  -- reject
end
"""

def rate_limit(redis_client, key, limit=100, window=60):
    result = redis_client.eval(RATE_LIMIT_SCRIPT, 1, key, limit, window)
    return result == 1  # True = allowed
```

**Sliding window counter (Redis):**
```python
# ZADD for sorted set of timestamps; ZREMRANGEBYSCORE for old entries
def sliding_window_rate_limit(redis, key, limit=100, window=60):
    now = time.time()
    redis.zadd(key, {str(uuid.uuid4()): now})
    redis.zremrangebyscore(key, 0, now - window)
    count = redis.zcard(key)
    redis.expire(key, window)
    return count <= limit
```

---

## Retry with Exponential Backoff Template

```python
import random
import time

def retry_with_backoff(func, max_retries=5, base_delay=1, max_delay=60):
    for attempt in range(max_retries):
        try:
            return func()
        except RetryableError as e:
            if attempt == max_retries - 1:
                raise
            delay = min(base_delay * (2 ** attempt), max_delay)
            jitter = delay * (0.5 + random.random() * 0.5)  # 50–100% of delay
            time.sleep(jitter)
```

**Resilience4j / Polly config:**
```yaml
retry:
  maxAttempts: 5
  waitDuration: 1s
  enableExponentialBackoff: true
  exponentialBackoffMultiplier: 2
  retryExceptions:
    - java.net.SocketTimeoutException
    - java.io.IOException
```

---

## Bulkhead Configuration Template

```java
// Thread pool isolation - separate ExecutorService per dependency
ExecutorService paymentPool = Executors.newFixedThreadPool(10);   // Payment API
ExecutorService searchPool = Executors.newFixedThreadPool(20);    // Search API
ExecutorService recPool = Executors.newFixedThreadPool(15);       // Recommendations

// Semaphore-based bulkhead (Resilience4j)
BulkheadConfig config = BulkheadConfig.custom()
    .maxConcurrentCalls(10)
    .maxWaitDuration(Duration.ofMillis(500))
    .build();

Bulkhead bulkhead = Bulkhead.of("payment-service", config);
```

**Envoy / sidecar config:**
```yaml
circuit_breakers:
  thresholds:
    - priority: DEFAULT
      max_connections: 100
      max_pending_requests: 100
      max_requests: 100
```

---

## Timeout Configuration Template

```java
// Connection timeout vs Read timeout
OkHttpClient client = new OkHttpClient.Builder()
    .connectTimeout(5, TimeUnit.SECONDS)   // Time to establish TCP
    .readTimeout(30, TimeUnit.SECONDS)     // Time waiting for response
    .writeTimeout(30, TimeUnit.SECONDS)
    .build();
```

| Layer | Connection | Read | Typical |
|-------|------------|------|---------|
| API → DB | 5s | 10–30s | DB can be slow |
| API → external API | 5s | 15–60s | Depends on SLA |
| Client → API | 3s | 30s | User-facing |

---

## Idempotency Key Implementation Template

```python
def process_payment(idempotency_key: str, amount: float, user_id: str):
    # Check if we've seen this key
    cached = redis.get(f"idempotency:{idempotency_key}")
    if cached:
        return json.loads(cached)  # Return previous result
    
    # Process (with lock to prevent race)
    with redis.lock(f"idempotency:lock:{idempotency_key}", timeout=30):
        result = payment_gateway.charge(amount, user_id)
        redis.setex(
            f"idempotency:{idempotency_key}",
            86400,  # 24h TTL
            json.dumps(result)
        )
        return result
```

**Client usage:**
```http
POST /payments
Idempotency-Key: 550e8400-e29b-41d4-a716-446655440000
Content-Type: application/json

{"amount": 100, "currency": "USD"}
```

> **FAANG Tip:** "Idempotency key: client generates UUID, server caches result by key. Same key = same response. 24–72h TTL typical."

---

## 30-SECOND REVISION BOX

```
CIRCUIT BREAKER: failureRateThreshold, waitDuration, HalfOpen test calls
RATE LIMITER: Redis Lua / ZADD sliding window; key = user/IP
RETRY: exponential backoff + jitter; only for RetryableError
BULKHEAD: thread pool or semaphore per dependency
TIMEOUT: connect 5s, read 30s; tune per dependency
IDEMPOTENCY: key in header; cache result in Redis; lock for race
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
