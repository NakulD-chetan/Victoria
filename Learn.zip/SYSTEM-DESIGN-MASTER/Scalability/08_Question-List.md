# Scalability — Question List

> **Permanent Recall:** 10 MUST-DO questions cover core scaling patterns; 25+ questions build progression. Practice: identify bottleneck, name pattern, estimate. E=Easy, M=Medium, H=Hard.

---

## 10 MUST-DO Scalability Questions

| # | Question | Difficulty | Company | Key Concepts |
|---|----------|------------|---------|--------------|
| 1 | Design a URL shortener at 100M daily requests | M | Amazon, Google | Horizontal scale, cache, DB read scaling |
| 2 | Scale a read-heavy feed (Twitter-like) to 10M DAU | M | Meta, Twitter | Read replicas, cache, CDN |
| 3 | How would you scale a write-heavy system (logging)? | M | Uber, Datadog | Sharding, async, batching |
| 4 | Scale a chat system to 1B users | H | Meta, Discord | Stateless, queues, sharding |
| 5 | Design a search system that scales to 1B documents | H | Google, Elastic | Sharding, index partitioning, cache |
| 6 | Scale a video streaming service to 50M concurrent viewers | H | Netflix, YouTube | CDN, edge caching, multi-region |
| 7 | How would you scale a rate limiter to 1M req/sec? | M | Stripe, Uber | Distributed cache, token bucket |
| 8 | Scale a notification system to 1B devices | H | Apple, Firebase | Queue, fan-out, partitioning |
| 9 | Design an API gateway that handles 500K RPS | M | AWS, Netflix | Horizontal scale, LB, stateless |
| 10 | Scale a database from 1M to 1B rows | M | Most | Read replicas, sharding, connection pooling |

---

## Full 25+ Question Progression

### Tier 1: Foundations (E–M)

| # | Question | Diff | Focus |
|---|----------|------|-------|
| 11 | How do you horizontally scale a REST API? | E | LB, stateless |
| 12 | When would you use read replicas vs sharding? | E | Read vs write bottleneck |
| 13 | Design a caching layer for a read-heavy app | E | Redis, cache-aside, TTL |
| 14 | How many servers for 100K RPS? Walk through the math | E | Back-of-envelope |
| 15 | What's the difference between vertical and horizontal scaling? | E | Scale up vs out |
| 16 | How would you scale a session-based web app? | M | Stateless, Redis sessions |

### Tier 2: Database & Data (M)

| # | Question | Diff | Focus |
|---|----------|------|-------|
| 17 | Design DB scaling for 1M writes/sec | M | Sharding, partitioning |
| 18 | How do you handle cross-shard queries? | M | Denormalization, avoid |
| 19 | Scale a time-series database (metrics, logs) | M | Sharding by time, retention |
| 20 | Design a system with 10:1 read:write ratio | M | Replicas + cache |
| 21 | How would you rebalance shards when adding new ones? | M | Consistent hashing, migration |
| 22 | Scale a leaderboard (real-time rankings) | M | Redis sorted sets, sharding |

### Tier 3: Systems & High Scale (M–H)

| # | Question | Diff | Focus |
|---|----------|------|-------|
| 23 | Scale a feed ranker (ML model + real-time) | H | Async, model serving, cache |
| 24 | Design a globally distributed cache | M | Multi-region, replication |
| 25 | How would you scale WebSocket connections to 10M? | H | Connection servers, sharding |
| 26 | Scale a recommendation engine (collaborative filtering) | H | Pre-compute, batch, cache |
| 27 | Design auto-scaling for bursty traffic | M | Metrics, scale-out, cooldown |
| 28 | How do you scale a pub/sub system to 1M subscribers? | H | Partitioning, fan-out |
| 29 | Scale a file storage system (S3-like) | H | Sharding, erasure coding |
| 30 | Design multi-region active-active with consistency | H | Conflict resolution, CRDTs |

### Tier 4: Deep Dives

| # | Question | Diff | Topic |
|---|----------|------|-------|
| 31 | Explain the scale cube (X, Y, Z axis) | E | Abbott's scale cube |
| 32 | How does Netflix/YouTube scale video delivery? | M | CDN, edge, multi-bitrate |
| 33 | Scale a payment system (double-write, idempotency) | H | Consistency, idempotency |
| 34 | How would you scale Elasticsearch? | M | Shards, replicas, routing |
| 35 | Design a system that scales for Black Friday (10× traffic) | M | Auto-scale, cache warm-up |

---

## Quick Answer Cheat Sheet

| Question | One-Line Answer |
|----------|-----------------|
| How to scale app tier? | Stateless + LB + horizontal scale |
| How to scale DB reads? | Read replicas + cache (Redis) |
| How to scale DB writes? | Sharding by partition key |
| How to scale static content? | CDN at edge |
| How to scale heavy work? | Queue (Kafka/SQS) + workers |
| When to shard? | After exhausting replicas + cache |
| Scale cube X/Y/Z? | X=clone, Y=decompose, Z=partition |
| 100K RPS → servers? | ~100 (1K RPS each, conservative) |

---

## Practice Schedule Suggestion

| Week | Focus | Questions |
|------|-------|------------|
| 1 | MUST-DO 1–5 | Core patterns: URL shortener, feed, logging, chat, search |
| 2 | MUST-DO 6–10 | Video, rate limiter, notifications, API gateway, DB scale |
| 3 | Tier 1–2 | Foundations + DB scaling |
| 4 | Tier 3–4 | High scale + deep dives |

---

## 30-SECOND REVISION BOX

```
MUST-DO: URL shortener, feed, logging, chat, search, video, rate limiter, notifications
PROGRESSION: Found → DB → Systems → Deep
PATTERN: Bottleneck → Pattern → Estimate
DIFF: E=1 concept, M=2–3, H=cross-cutting
```

---

**Prev: [[07_Tricks-and-Recognition]] | Topic: [[01_Concept]]**
