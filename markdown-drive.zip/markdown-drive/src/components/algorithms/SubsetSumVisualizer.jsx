import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(nums, target) {
  const n = nums.length;
  const dp = Array.from({ length: n + 1 }, () => Array(target + 1).fill(false));
  dp[0][0] = true;
  const steps = [];
  const colLabels = Array.from({ length: target + 1 }, (_, t) => t);
  const rowLabels = ['∅', ...nums.map((v, i) => `${v}`)];

  const snap = (caption, colors, hl, arrows) => {
    steps.push({
      caption,
      table: dp.map((r) => r.map((v) => (v ? 'T' : 'F'))),
      rowLabels,
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('subset[i][t]: can first i elements sum to t?', {}, null, []);

  for (let i = 1; i <= n; i += 1) {
    for (let t = 0; t <= target; t += 1) {
      const colors = {
        [`${i}-${t}`]: 'current',
        [`${i - 1}-${t}`]: 'filled',
      };
      const arrows = [{ from: [i - 1, t], to: [i, t] }];
      let val = dp[i - 1][t];
      if (t >= nums[i - 1]) {
        colors[`${i - 1}-${t - nums[i - 1]}`] = 'filling';
        arrows.push({ from: [i - 1, t - nums[i - 1]], to: [i, t] });
        val = val || dp[i - 1][t - nums[i - 1]];
      }
      snap(`Item ${nums[i - 1]}: skip or take if room`, colors, [i, t], arrows);
      dp[i][t] = val;
      snap(`dp[${i}][${t}] = ${val ? 'true' : 'false'}`, { [`${i}-${t}`]: val ? 'optimal' : 'filled' }, [i, t], []);
    }
  }

  snap(`Target ${target} reachable? ${dp[n][target] ? 'YES' : 'NO'}`, { [`${n}-${target}`]: 'optimal' }, [n, target], []);
  return steps;
}

export default function SubsetSumVisualizer({ config }) {
  const nums = [3, 5, 2, 7];
  const target = 10;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(nums, target);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Subset sum target ${target}` });
    canvasRef.current?.setState({
      table: [['F']],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      items: nums.map((n) => String(n)),
      caption: 'Subset sum (boolean DP)',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [['F']],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      items: nums.map((n) => String(n)),
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
