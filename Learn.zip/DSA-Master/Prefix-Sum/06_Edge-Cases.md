# Prefix Sum — Edge Cases

> **FAANG interviewers probe these. Know them cold.**

---

## Edge Case 1: Empty Array

### Scenario
```python
arr = []
```

### Behavior
- **Prefix build:** prefix = [0]. Length 1.
- **Range query [0, -1]:** Invalid. Return 0 or handle as "no elements".
- **Subarray count (sum=K):** map {0:1}, no iterations → count = 0. Correct.

### Code
```python
if not arr:
    return 0  # or [] for range queries
```

---

## Edge Case 2: Single Element

### Scenario
```python
arr = [5], K = 5
```

### Behavior
- prefix = [0, 5]
- j=0: prefix becomes 5. Need prefix[i]=0. map has {0:1} → count=1 ✓
- Subarray [0..0] has sum 5. Correct.

### Trap
Without {0:1}, count=0. **Always init map with {0:1}.**

---

## Edge Case 3: All Zeros

### Scenario
```python
arr = [0, 0, 0], K = 0
```

### Behavior
- prefix = [0, 0, 0, 0]
- Subarrays with sum 0: [0], [1], [2], [0,1], [1,2], [0,1,2] = 6
- With map: prefix values 0,0,0,0. Each time we need prefix-K=0.
  - j=0: count+=1 (from {0:1}), map={0:2}
  - j=1: count+=2, map={0:3}
  - j=2: count+=3, map={0:4}
  - Total = 6 ✓

### Trap
Many prefix values equal. Map counts accumulate. No special handling needed.

---

## Edge Case 4: All Negatives

### Scenario
```python
arr = [-1, -2, -3], K = -3
```

### Behavior
- prefix = [0, -1, -3, -6]
- Subarrays with sum -3: [2] (arr[2]=-3) ✓
- Hash map works: need prefix[i]=prefix[j]-K = -6-(-3)=-3. prefix[2]=-3 → count=1 ✓

### Key
**Prefix + hash map works with negatives.** No special case.

---

## Edge Case 5: Sum Equals 0 (Entire Array)

### Scenario
```python
arr = [1, -1, 2, -2], K = 0
```

### Behavior
- prefix = [0, 1, 0, 2, 0]
- For K=0: count += map[prefix]. We count pairs with same prefix value.
- Formula works. Count all (i,j) where prefix[j]=prefix[i].

### Trap
For K=0, we're counting pairs where prefix[i]=prefix[j]. Same logic: count += map[prefix]. Correct.

---

## Edge Case 6: Very Large Sums (Overflow)

### Scenario
```python
n = 10**5, arr[i] = 10**9
```

### Behavior
- Total sum ≈ 10¹⁴. Python int is fine. C++ int overflows.

### Fix
```cpp
vector<long long> prefix(n + 1);
```

### When to Use long long
- n × max(arr[i]) > 2×10⁹ → use long long
- Or: always use long long for prefix in C++ to be safe.

---

## Edge Case 7: Subarray Starting at Index 0

### Scenario
```python
arr = [1, 2, 3], K = 3
# Subarray [0,1] = 1+2 = 3
```

### Behavior
- prefix = [0, 1, 3, 6]
- At j=1 (processed arr[0],arr[1]): prefix=3. Need prefix[i]=0.
- prefix[0]=0 is in map with count 1 → count+=1 ✓

### Why {0:1} Matters
Without it, we never count subarrays that start at index 0 and have sum K.

---

## Edge Case 8: K = 0 with No Valid Subarray

### Scenario
```python
arr = [1, 2, 3], K = 0
```

### Behavior
- No subarray has sum 0. prefix = [0, 1, 3, 6].
- At each j, count += map[prefix]. prefix values: 0,1,3,6. No duplicates.
- We get count 0 (only {0:1} at start, but prefix never returns to 0). Correct.

---

## Edge Case Summary Table

| Edge Case | Handling |
|-----------|----------|
| Empty array | Return 0 / []; prefix=[0] |
| Single element | Works; {0:1} critical |
| All zeros | Map accumulates; works |
| All negatives | Works; no special case |
| K=0 | Same formula; prefix[j]=prefix[i] |
| Overflow | Use long long in C++ |
| Subarray at index 0 | {0:1} enables this |
| 2D empty matrix | Return 0 or [] |

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:        prefix=[0], return 0 for count
SINGLE:       {0:1} ensures subarray [0..0] counted when arr[0]=K
ALL ZEROS:    Map counts accumulate; no special handling
NEGATIVES:    Prefix+map works; no change
K=0:          Same logic; count prefix pairs where prefix[i]=prefix[j]
OVERFLOW:     long long for prefix in C++
INDEX 0:      {0:1} = "empty prefix" for subarrays starting at 0
```
