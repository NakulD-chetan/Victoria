# Union-Find — Mental Model

> **Permanent Recall:** Think "social network friend circles." Each circle has a leader (root). Joining circles = union. "Who's your circle leader?" = find. Path compression = shortcut to leader. Forest = many independent circles.

---

## Social Network Analogy

| UF Concept | Real-World Analogy |
|------------|-------------------|
| **Component** | Friend circle / group |
| **Root** | Circle leader (everyone points to them) |
| **find(x)** | "Who's the leader of your circle?" |
| **union(x,y)** | Merge two circles (e.g., two people become friends) |
| **Path compression** | "Next time, remember the leader directly" (shortcut) |

```
    Before union(A, B):
    Circle 1: A → B → C (leader: C)
    Circle 2: D → E (leader: E)

    After union(A, D):  Merge circles → one big circle
    New leader: C or E (whoever's tree was larger)
```

---

## Forest of Trees Visualization

```
INITIAL STATE (n=7, each node alone):
    0   1   2   3   4   5   6
    ↑   ↑   ↑   ↑   ↑   ↑   ↑
   (each points to self)

AFTER union(0,1), union(2,3), union(1,3):
        0                   4
       / \                 / \
      1   2               5   6
      |
      3

    Components: {0,1,2,3} and {4,5,6}
```

---

## Path Compression = Shortcut to Root

**Without path compression:** Must walk entire chain every time.

```
    find(3): 3 → 1 → 0  (2 hops)
    find(3) again: still 3 → 1 → 0  (2 hops)
```

**With path compression:** After first find, flatten the path.

```
    find(3): 3 → 1 → 0
    During find: parent[3]=0, parent[1]=0

    After:
        0
       /|\
      1 2 3   (all point directly to root!)

    find(3) next time: 3 → 0  (1 hop)
```

---

## Union by Rank = Keep Tree Shallow

**Idea:** When merging, attach smaller tree under larger tree's root.

```
    Tree A (rank 2)     Tree B (rank 1)
         0                   4
        / \                 /
       1   2               5

    union(0,4): Attach B under A (A is larger)
         0
        /|\
       1 2 4
            |
            5
```

**Why:** Prevents degenerate chains. Rank = upper bound on height.

---

## Full Operation Flow

```mermaid
flowchart TD
    subgraph Union["union(2, 5)"]
        U1["1. root2 = find(2) → 0"]
        U2["2. root5 = find(5) → 4"]
        U3["3. root2 == root5?"]
        U4["4. Attach by rank"]
        U5["5. Update rank if equal"]
        U1 --> U2 --> U3
        U3 -->|Yes| Return["return"]
        U3 -->|No| U4 --> U5
    end
    subgraph Find["find(5) with path compression"]
        F1["1. parent[5] != 5?"]
        F2["2. parent[5] = find(parent[5])"]
        F3["3. return parent[5]"]
        F1 -->|Yes| F2
        F1 -->|No| F3
    end
    style U4 fill:#C8E6C9
    style F2 fill:#FFE4B5
```

<details>
<summary>ASCII fallback</summary>

```
union(2, 5):
  1. root2 = find(2)  →  0
  2. root5 = find(5)  →  4
  3. if root2 == root5 → already connected, return
  4. if rank[0] >= rank[4]: parent[4]=0
     else: parent[0]=4
  5. if rank[0]==rank[4]: rank[0]++

find(5) with path compression:
  1. if parent[5] != 5: parent[5] = find(parent[5])
  2. return parent[5]
  (After: 5 points directly to root 0)
```

</details>

---

## Component Count Mental Model

```
"How many distinct groups exist?"

Count nodes where parent[i] == i (roots)

    [0, 0, 0, 1, 4, 4, 4]
     ↑        ↑
   root 0   root 4  →  2 components
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
ANALOGY:        Friend circles; root = leader; union = merge circles
FOREST:         Each tree = one component; nodes point to parent
PATH COMPRESS:  find(x) flattens path; parent[x]=find(parent[x])
UNION BY RANK:  Attach smaller under larger; keep shallow
FLOW:           find roots → if same return → else attach by rank
COMPONENT CNT:  Count parent[i]==i
```

---

## 30-SECOND REVISION BOX

```
□ Social network: circles, leaders, merging
□ Forest: trees = components, parent pointers
□ Path compression: shortcut to root during find
□ Union by rank: smaller tree under larger
□ find: recurse + compress; union: find both, attach
□ Component count: count roots
```
