# Dynamic Programming — Tricks and Recognition

> **Permanent Recall:** "Maximum/minimum ways" → DP. "Count the number of ways" → DP. "Partition" → knapsack. Two sequences → 2D. Subset with constraints → bitmask. Use the flowchart to decide DP vs greedy vs backtracking.

---

## DP Recognition Phrases

| Phrase | Likely DP Type | Example |
|--------|----------------|---------|
| "Maximum/minimum ways to..." | Counting DP | Climbing stairs, unique paths |
| "Count the number of ways" | Counting DP | Decode ways, combination sum |
| "Can you partition..." | 0/1 Knapsack | Partition equal subset |
| "Maximum value with constraint" | Knapsack | 0/1 or unbounded |
| "Longest common..." | LCS | Two strings |
| "Longest increasing..." | LIS | One sequence |
| "Minimum operations to transform" | Edit distance | Insert, delete, replace |
| "Visit each exactly once" | Bitmask DP | TSP, assignment |
| "Optimal substructure" | Any DP | Overlapping subproblems |

---

## Decision Flowchart: DP vs Greedy vs Backtracking

```mermaid
flowchart TD
    A["Optimal solution needed?"] --> B{YES}
    A --> C{NO}
    C --> D["Backtracking / DFS<br/>(permutations, etc.)"]
    B --> E["Overlapping subproblems?"]
    E --> F{YES}
    E --> G{NO}
    F --> H["Optimal substructure?"]
    H --> I{YES}
    I --> J["DP"]
    G --> K["Greedy?"]
    K --> L["Choice doesn't affect future?"]
    L --> M{YES}
    L --> N{NO}
    M --> O["Greedy<br/>(activity select)"]
    N --> P["DP or Backtracking<br/>(knapsack)"]
    style J fill:#90EE90
    style O fill:#87CEEB
    style D fill:#FFB6C1
    style P fill:#DDA0DD
```

<details>
<summary>ASCII fallback</summary>

```
                    "Optimal solution needed?"
                           |
              +------------+------------+
              |                         |
             YES                        NO
              |                         |
    "Overlapping subproblems?"      Backtracking / DFS
              |                         (permutations, etc.)
     +--------+--------+
     |                 |
    YES               NO
     |                 |
    DP              Greedy?
     |                 |
     |         "Choice doesn't affect future?"
     |                 |
     |         +-------+-------+
     |         |               |
     |        YES             NO
     |         |               |
     |      Greedy        DP or Backtracking
     |   (activity select)   (knapsack)
     |
     v
  "Optimal substructure?"
     |
    YES → DP
```

</details>

---

## DP on Strings → 2D Table

| Pattern | Table Shape | State |
|---------|-------------|-------|
| Two strings | (m+1)×(n+1) | dp[i][j] = s1[0..i-1], s2[0..j-1] |
| One string (palindrome) | n×n | dp[i][j] = s[i..j] |
| One string (LIS-style) | 1×n | dp[i] = suffix/prefix |

```
LCS, Edit Distance, Interleaving → 2D (i, j) on two strings
Longest Palindromic Substring   → 2D (i, j) on one string
```

---

## Knapsack Recognition

| Phrase | Type | Key |
|--------|------|-----|
| "Each item at most once" | 0/1 Knapsack | dp[i][w] from dp[i-1][*] |
| "Unlimited supply" | Unbounded | dp[w] reuses same row |
| "Partition into equal sum" | 0/1 (target = sum/2) | Subset sum |
| "Minimum coins to make amount" | Unbounded | Coin change |

---

## Space Optimization: Rolling Array Trick

### When It Applies

```
dp[i] depends ONLY on:
  - dp[i-1]           → 2 variables (prev, curr)
  - dp[i-1], dp[i-2]  → 3 variables
  - Row i-1 only      → 2 rows or 1D reverse fill
```

### Knapsack Reverse Fill (Critical)

```
0/1 Knapsack: dp[i][w] = max(dp[i-1][w], val + dp[i-1][w-w_i])

If we use 1D: dp[w] = max(dp[w], val + dp[w-w_i])
  - Fill w from W down to w_i (reverse!)
  - Why? We need dp[w-w_i] from PREVIOUS row.
  - Forward fill would overwrite it before we use it.

Unbounded: Forward fill OK (we reuse current row).
```

```
     w:  0  1  2  3  4  5
Forward:  ← overwrites before we read dp[w-w_i]
Reverse:  → we read dp[w-w_i] before overwriting
```

---

## State Reduction Tricks

| Trick | When | How |
|-------|------|-----|
| **Rolling array** | Row i needs only row i-1 | 2 rows or 1D |
| **Dimension collapse** | One dimension redundant | e.g., LIS: dp[i] only |
| **Symmetry** | dp[i][j] = dp[j][i] | Fill half; or use when i<j |
| **Monotonicity** | States form DAG | Topological order |
| **Sliding window** | Only last k values matter | Deque or circular buffer |

---

## Bitmask DP Recognition

| Phrase | Problem Type |
|--------|--------------|
| "Visit each city exactly once" | TSP |
| "Assign n tasks to n workers" | Assignment |
| "Subset of size k with property" | Subset DP |
| "n ≤ 20" (small n) | Often bitmask |

```
State: (mask, last) or (mask, position)
  mask = bitmask of visited/selected
  last = last visited node (for TSP)
```

---

## ASCII: Recognition Quick Reference

```
"ways" / "count"        → Counting DP
"max/min value"         → Optimization DP
"partition"             → Knapsack
"two strings"           → 2D LCS / Edit
"one string"            → 1D or 2D (palindrome)
"visit each once"       → Bitmask
"n ≤ 20"                → Bitmask candidate
"contiguous"            → Subarray (maybe Kadane)
"order, can skip"       → Subsequence
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PHRASES:      "ways", "count", "partition" → DP
FLOWCHART:    Overlap + optimal substructure → DP
STRINGS:      Two seqs → 2D (i,j)
KNAPSACK:     0/1 vs unbounded; partition = 0/1
ROLLING:      Row i needs i-1 → 2 rows / 1D
REVERSE:      0/1 knapsack space opt = fill w backwards
BITMASK:      "visit each once", n≤20
STATE REDUCE: Collapse dims; symmetry; monotonicity
```

---

## 30-SECOND REVISION BOX

```
□ "Maximum ways" / "count" → DP
□ Partition → 0/1 knapsack
□ Two strings → 2D table
□ Space opt: reverse fill for 0/1 knapsack
□ Bitmask: n≤20, "visit each once"
□ DP vs Greedy: overlapping subproblems?
□ State reduction: rolling array, symmetry
```
