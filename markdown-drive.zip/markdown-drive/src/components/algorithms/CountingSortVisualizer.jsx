import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [];
  const max = Math.max(...a);
  const count = new Array(max + 1).fill(0);
  for (let i = 0; i < a.length; i++) {
    count[a[i]]++;
    steps.push({ type: 'count', idx: i, val: a[i], array: [...a], buckets: Object.fromEntries(count.map((c, k) => [k, Array(c).fill(k)])) });
  }
  const output = [];
  for (let i = 0; i <= max; i++) {
    while (count[i]-- > 0) {
      output.push(i);
      steps.push({ type: 'place', pos: output.length - 1, val: i, array: [...output] });
    }
  }
  steps.push({ type: 'done', array: [...output] });
  return steps;
}

function randomArray(n = 18) { return Array.from({ length: n }, () => Math.floor(Math.random() * 15) + 1); }

export default function CountingSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements (counting sort)` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'count') {
      colors[step.idx] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Count ${step.val}` });
    } else if (step.type === 'place') {
      colors[step.pos] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Place ${step.val} at [${step.pos}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
