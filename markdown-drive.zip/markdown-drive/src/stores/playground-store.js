import { create } from 'zustand';
import { defaultConfig } from '../lib/problems/component-types';

let nextId = 1;

export const usePlaygroundStore = create((set, get) => ({
  components: [],
  connections: [],
  requests: [],
  flashes: [],
  stats: { sent: 0, done: 0, failed: 0, rejected: 0, totalLat: 0, startTime: 0 },
  lbCounters: {},
  selectedCompId: null,
  selectedConnId: null,
  mode: 'idle',
  connectSource: null,
  simulating: false,
  speed: 1,
  testResults: [],
  replayTest: null,

  addComponent: (type, x, y) => {
    const id = 'c' + nextId++;
    set((s) => ({
      components: [...s.components, { id, type, x, y, config: defaultConfig(type), _s: {} }],
    }));
    return id;
  },
  removeComponent: (id) => set((s) => ({
    components: s.components.filter((c) => c.id !== id),
    connections: s.connections.filter((c) => c.from !== id && c.to !== id),
    requests: s.requests.filter((r) => r.atComp !== id),
    selectedCompId: s.selectedCompId === id ? null : s.selectedCompId,
  })),
  moveComponent: (id, x, y) => set((s) => ({
    components: s.components.map((c) => c.id === id ? { ...c, x, y } : c),
  })),
  updateComponentConfig: (id, key, value) => set((s) => ({
    components: s.components.map((c) => c.id === id ? { ...c, config: { ...c.config, [key]: value } } : c),
  })),
  addConnection: (from, to) => {
    const s = get();
    if (s.connections.find((c) => c.from === from && c.to === to)) return;
    const id = 'cn' + nextId++;
    set((s) => ({ connections: [...s.connections, { id, from, to }] }));
  },
  removeConnection: (id) => set((s) => ({
    connections: s.connections.filter((c) => c.id !== id),
    requests: s.requests.filter((r) => r.connId !== id),
    selectedConnId: s.selectedConnId === id ? null : s.selectedConnId,
  })),
  selectComponent: (id) => set({ selectedCompId: id, selectedConnId: null }),
  selectConnection: (id) => set({ selectedConnId: id, selectedCompId: null }),
  setMode: (mode) => set({ mode, connectSource: mode !== 'connect' ? null : get().connectSource }),
  setConnectSource: (id) => set({ connectSource: id }),
  toggleSimulation: () => set((s) => {
    const newSim = !s.simulating;
    return {
      simulating: newSim,
      stats: newSim && !s.stats.startTime ? { ...s.stats, startTime: Date.now() } : s.stats,
    };
  }),
  setSpeed: (speed) => set({ speed }),
  resetSimulation: () => set((s) => ({
    simulating: false, requests: [], flashes: [],
    stats: { sent: 0, done: 0, failed: 0, rejected: 0, totalLat: 0, startTime: 0 },
    lbCounters: {},
    components: s.components.map((c) => ({ ...c, _s: {} })),
  })),
  resetAll: () => {
    nextId = 1;
    set({
      components: [], connections: [], requests: [], flashes: [],
      stats: { sent: 0, done: 0, failed: 0, rejected: 0, totalLat: 0, startTime: 0 },
      lbCounters: {}, selectedCompId: null, selectedConnId: null,
      mode: 'idle', connectSource: null, simulating: false, testResults: [], replayTest: null,
    });
  },
  setRequests: (reqs) => set({ requests: reqs }),
  setFlashes: (flashes) => set({ flashes }),
  setStats: (stats) => set({ stats }),
  setComponentState: (id, state) => set((s) => ({
    components: s.components.map((c) => c.id === id ? { ...c, _s: state } : c),
  })),
  setLbCounters: (counters) => set({ lbCounters: counters }),
  setTestResults: (results) => set({ testResults: results }),
  setReplayTest: (test) => set({ replayTest: test }),
  clearReplayTest: () => set({ replayTest: null }),
}));
