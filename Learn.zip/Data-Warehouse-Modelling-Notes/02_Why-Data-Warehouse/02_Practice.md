# Why Do We Need a Data Warehouse — Practice

> "If you can articulate the business pain, the architecture almost writes itself."

---

## Quick Recall

**Q:** Name three reasons a retailer builds a warehouse instead of querying OLTP directly.  
**A:** Performance isolation, historical depth, and consistent analytical definitions across systems.

**Q:** Why is ad hoc SQL on the production orders table risky?  
**A:** Heavy scans can slow checkout and inventory allocation; locks and resource contention threaten SLAs.

**Q:** What does "single version of the metric" mean for net sales?  
**A:** Finance, merchandising, and marketing use the same formula and grain for net sales in published reports.

**Q:** When is a replica of OLTP not enough?  
**A:** When you need integrated channels, conformed dimensions, derived facts, and years of history beyond what replicas retain.

**Q:** How does a warehouse support compliance for e-commerce?  
**A:** Immutable or auditable history, documented lineage, and controlled access for PII and payment-adjacent attributes.

---

## Interview Questions

**1. Why not just use read replicas of our PostgreSQL order database for BI?**  
**Model answer:** Replicas help with read scaling but they mirror OLTP schemas and retention policies. Retail analytics needs conformed product and customer keys across POS, web, and marketplaces, derived metrics like contribution margin, and often longer history than operational retention. The warehouse is where we integrate and model for those questions. I also note that BI models on normalized OLTP schemas become expensive join graphs.

**2. What business KPIs justify warehouse investment first?**  
**Model answer:** Revenue and margin by channel, inventory turns, fulfillment SLA breaches, and customer cohort repeat purchase rate—metrics that require joins across systems and stable definitions executives trust. I prioritize what leadership already uses in board packs because alignment accelerates funding.

**3. How do you respond when stakeholders say the warehouse is too slow to build?**  
**Model answer:** I propose a thin-slice milestone: one subject area, one metric, one dashboard, reconciled to a trusted source like finance. That proves value while we expand coverage. I pair that with a roadmap that shows incremental releases rather than a multi-year big bang.

**4. Explain performance isolation with a retail example.**  
**Model answer:** During Black Friday, OLTP must prioritize authorization and inventory holds. Analysts running large window functions on two years of orders should run on the warehouse cluster so we do not compete for the same buffer pool and IOPS. Isolation is both technical and organizational: different teams own different SLOs.

**5. What role does governance play in "why warehouse"?**  
**Model answer:** Without governance, every team defines "active customer" differently. The warehouse is the place we publish agreed definitions, ownership, and change control so dashboards align. Governance is not bureaucracy; it is how we stop paying the tax of endless reconciliation.

**6. Can a data lake replace the business case for a warehouse?**  
**Model answer:** Lakes excel at raw retention and exploration. Many retailers use both: lake for landing and ML features, warehouse or curated zone for governed, query-friendly star schemas for BI. The business case is rarely "lake or warehouse"; it is "how fast can finance trust the number."

**7. How do you measure success of a warehouse initiative?**  
**Model answer:** Adoption of governed datasets, reduction in duplicate pipelines, time-to-answer for recurring questions, and fewer metric disputes between departments. I also track incident reduction when analysts stop hitting production.

**8. What is the cost of not having a warehouse for a scaling marketplace?**  
**Model answer:** Shadow IT extracts, inconsistent seller payouts reporting, slower product launches because analytics cannot keep pace, and higher audit risk when history lives in email attachments. The warehouse converts tribal knowledge into shared infrastructure.

---

## Scenario-Based Exercises

**Scenario 1 — Merchandising vs Finance revenue mismatch**  
Two teams publish different quarterly revenue for the same catalog.  
**Solution:** Establish a conformed `fact_sales` with signed documentation for returns, gift cards, and shipping revenue. Reconcile to the general ledger; deprecate team-specific extracts. Publish a certified semantic dataset for self-service.

**Scenario 2 — Analysts query production for "quick" weekly reports**  
**Solution:** Move weekly reporting to the warehouse with a scheduled extract or CDC pipeline. Add a semantic layer or certified dataset so analysts stop defaulting to OLTP. Add access reviews so only break-glass roles hit production.

**Scenario 3 — Need five years of clickstream for attribution**  
**Solution:** Land raw events in cost-effective storage; aggregate and model attribution-ready facts in the warehouse at the grain needed for reporting (session or order). Keep exploratory features in the lake, publish attributed orders in the warehouse.

```sql
SELECT order_date,
       SUM(net_sales_amount) AS net_sales
FROM dw.fact_sales
WHERE order_date BETWEEN DATE '2024-01-01' AND DATE '2024-12-31'
GROUP BY order_date
ORDER BY order_date;
```

**Scenario 4 — Prove ROI and global roll-up**  
**Solution:** Baseline hours spent reconciling spreadsheets; after warehouse cutover, measure hours saved and error reduction in month-end close. When a new country launches on a different OMS, conform currencies and calendars in the warehouse so global same-store sales do not require executives to understand three source schemas.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| "We need real-time" as the only driver | Warehouses solve breadth and trust, not only latency | Separate operational metrics from analytical history |
| Blaming "bad analysts" for OLTP load | Sounds unprofessional | Propose platform pattern: certified datasets and access policy |
| Promising zero duplication | Some redundancy is normal between lake and DW | Explain zones: raw, curated, consumption |
| Ignoring cost of ownership | Interviewers want pragmatism | Mention incremental delivery and FinOps basics |
| Saying replicas solve everything | Mirrors amplify schema problems | Emphasize modeling, metrics, and conformed dimensions |
| Claiming warehouse removes all Excel | Unrealistic | Position Excel as a client of governed extracts |

---

## One-Liner Answers

- We need a warehouse to run heavy analytics without risking transactional SLAs on checkout and inventory systems.
- It gives us integrated, historical data with agreed metric definitions across channels.
- OLTP schemas reflect applications; warehouse schemas reflect how the business asks questions.
- Governance and lineage turn data into something finance and compliance can sign off on.
- A warehouse reduces duplicate pipelines and conflicting dashboards for the same KPI.
- Lakes and warehouses often pair: raw flexibility plus curated reporting layers.
