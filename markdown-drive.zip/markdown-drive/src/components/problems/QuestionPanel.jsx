import { useState, useCallback } from 'react';
import { PROBLEMS } from '../../lib/problems/problems-data';
import { usePlaygroundStore } from '../../stores/playground-store';
import { useProblemSessionStore } from '../../stores/problem-session-store';

const DIFF_COLORS = { Easy: 'var(--accent)', Medium: 'var(--accent-warm)', Hard: 'var(--danger)' };

export default function QuestionPanel({ problem, onProblemChange }) {
  const [tab, setTab] = useState('desc');
  const hintsRevealed = useProblemSessionStore((s) => s.hintsRevealed);
  const hintsUsed = useProblemSessionStore((s) => s.hintsUsed);
  const revealHint = useProblemSessionStore((s) => s.revealHint);
  const showDeepDive = useProblemSessionStore((s) => s.showDeepDive);
  const submitted = useProblemSessionStore((s) => s.submitted);
  const deepDiveAnswers = useProblemSessionStore((s) => s.deepDiveAnswers);
  const deepDiveScore = useProblemSessionStore((s) => s.deepDiveScore);
  const deepDiveCompleted = useProblemSessionStore((s) => s.deepDiveCompleted);
  const deepDiveResults = useProblemSessionStore((s) => s.deepDiveResults);
  const answerDeepDive = useProblemSessionStore((s) => s.answerDeepDive);
  const submitDeepDive = useProblemSessionStore((s) => s.submitDeepDive);
  const showFinalScore = useProblemSessionStore((s) => s.showFinalScore);

  const components = usePlaygroundStore((s) => s.components);
  const connections = usePlaygroundStore((s) => s.connections);
  const [ddLoading, setDdLoading] = useState(false);

  const handleScoreDeepDive = useCallback(async () => {
    setDdLoading(true);
    await submitDeepDive(problem, components, connections);
    setDdLoading(false);
  }, [problem, components, connections, submitDeepDive]);

  const handleFinish = useCallback(() => {
    if (!deepDiveCompleted) {
      handleScoreDeepDive().then(() => {
        useProblemSessionStore.getState().showFinalScore();
      });
    } else {
      showFinalScore();
    }
  }, [deepDiveCompleted, handleScoreDeepDive, showFinalScore]);

  const hints = problem.hints || [];
  const deepDiveQuestions = problem.deepDiveQuestions || [];

  return (
    <div className="dc-question-panel">
      <div className="dc-question-panel__select-wrap">
        <select value={problem.id} onChange={(e) => onProblemChange(e.target.value)} className="dc-question-panel__select">
          {PROBLEMS.map((p) => (
            <option key={p.id} value={p.id}>{p.number}. {p.title}</option>
          ))}
        </select>
      </div>

      <div className="dc-question-panel__tabs">
        <button onClick={() => setTab('desc')} className={`dc-question-panel__tab ${tab === 'desc' ? 'dc-question-panel__tab--active' : ''}`}>
          Description
        </button>
        <button onClick={() => setTab('hints')} className={`dc-question-panel__tab ${tab === 'hints' ? 'dc-question-panel__tab--active' : ''}`}>
          Hints {hintsUsed > 0 && <span className="dc-question-panel__hint-count">{hintsUsed}/{hints.length}</span>}
        </button>
        {submitted && deepDiveQuestions.length > 0 && (
          <button onClick={() => setTab('deepdive')} className={`dc-question-panel__tab ${tab === 'deepdive' ? 'dc-question-panel__tab--active' : ''} ${showDeepDive ? 'dc-question-panel__tab--notify' : ''}`}>
            Deep Dive
          </button>
        )}
      </div>

      <div className="dc-question-panel__body">
        {tab === 'desc' && (
          <>
            <div className="dc-question-panel__title-row">
              <span className="dc-question-panel__title">{problem.title}</span>
              <span className="dc-badge" style={{ background: DIFF_COLORS[problem.difficulty], color: '#fff' }}>{problem.difficulty}</span>
            </div>

            <p className="dc-question-panel__text">{problem.description}</p>

            <div className="dc-lc-section">
              <div className="dc-lc-section__label">Functional Requirements</div>
              <ul className="dc-lc-list">
                {problem.requirements.functional.map((r, i) => (
                  <li key={i} className="dc-lc-list__item">{r}</li>
                ))}
              </ul>
            </div>

            <div className="dc-lc-section">
              <div className="dc-lc-section__label">Non-Functional Requirements</div>
              <ul className="dc-lc-list">
                {problem.requirements.nonFunctional.map((r, i) => (
                  <li key={i} className="dc-lc-list__item">{r}</li>
                ))}
              </ul>
            </div>

            {problem.constraints && problem.constraints.length > 0 && (
              <div className="dc-lc-section">
                <div className="dc-lc-section__label">Constraints</div>
                <ul className="dc-lc-list dc-lc-list--constraints">
                  {problem.constraints.map((c, i) => (
                    <li key={i} className="dc-lc-list__item dc-lc-list__item--constraint">{c}</li>
                  ))}
                </ul>
              </div>
            )}

            {problem.expectedAPIs && problem.expectedAPIs.length > 0 && (
              <div className="dc-lc-section">
                <div className="dc-lc-section__label">Expected API Endpoints</div>
                <div className="dc-lc-api-list">
                  {problem.expectedAPIs.map((api, i) => (
                    <div key={i} className="dc-lc-api-row">
                      <span className={`dc-lc-api-method dc-lc-api-method--${api.method.toLowerCase()}`}>{api.method}</span>
                      <code className="dc-lc-api-path">{api.path}</code>
                      <span className="dc-lc-api-desc">{api.desc}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="dc-lc-section">
              <div className="dc-lc-section__label">Test Cases</div>
              <div className="dc-lc-testcase-summary">
                <span>{(problem.testCases || []).filter(t => t.type === 'structural').length} structural</span>
                <span className="dc-lc-testcase-dot">&middot;</span>
                <span>{(problem.testCases || []).filter(t => t.type === 'simulation').length} simulation</span>
                {problem.chaosScenarios?.length > 0 && (
                  <>
                    <span className="dc-lc-testcase-dot">&middot;</span>
                    <span>{problem.chaosScenarios.length} chaos</span>
                  </>
                )}
              </div>
            </div>
          </>
        )}

        {tab === 'hints' && (
          <div className="dc-lc-hints">
            <p className="dc-lc-hints__warning">
              Each hint revealed reduces your final score by 5%.
              Try to solve without hints first!
            </p>
            {hints.map((hint, i) => {
              const revealed = hintsRevealed.includes(i);
              return (
                <div key={i} className={`dc-lc-hint ${revealed ? 'dc-lc-hint--revealed' : ''}`}>
                  <button
                    className="dc-lc-hint__toggle"
                    onClick={() => !revealed && revealHint(i)}
                    disabled={revealed}
                  >
                    <span className="dc-lc-hint__num">Hint {i + 1}</span>
                    {!revealed && <span className="dc-lc-hint__lock">Click to reveal (-5%)</span>}
                  </button>
                  {revealed && (
                    <div className="dc-lc-hint__content">{hint}</div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {tab === 'deepdive' && (
          <div className="dc-lc-deepdive">
            <p className="dc-lc-deepdive__intro">
              Now that you've built your architecture, answer these follow-up questions.
              Interviewers use these to test your depth of understanding.
            </p>
            {deepDiveQuestions.map((q, qIdx) => {
              const userAns = deepDiveAnswers[qIdx] || [];
              const serverResult = deepDiveResults?.[qIdx];
              const isCorrectOption = (optIdx) => serverResult?.correct?.includes(optIdx);

              return (
                <div key={qIdx} className="dc-lc-deepdive__q">
                  <div className="dc-lc-deepdive__q-header">
                    <span className="dc-lc-deepdive__q-num">Q{qIdx + 1}</span>
                    <span className="dc-lc-deepdive__q-text">{q.question}</span>
                    {deepDiveCompleted && serverResult && (
                      <span className={`dc-lc-deepdive__q-badge ${serverResult.score >= 1 ? 'dc-lc-deepdive__q-badge--correct' : serverResult.score > 0 ? 'dc-lc-deepdive__q-badge--partial' : 'dc-lc-deepdive__q-badge--wrong'}`}>
                        {serverResult.score >= 1 ? '\u2713' : serverResult.score > 0 ? '\u00BD' : '\u2715'}
                      </span>
                    )}
                  </div>
                  {!deepDiveCompleted && q.options.length > 2 && (
                    <span className="dc-lc-deepdive__multi">Select all that apply</span>
                  )}
                  <div className="dc-lc-deepdive__options">
                    {q.options.map((opt, optIdx) => {
                      const selected = userAns.includes(optIdx);
                      let cls = 'dc-lc-deepdive__opt';
                      if (selected) cls += ' dc-lc-deepdive__opt--selected';
                      if (deepDiveCompleted && serverResult) {
                        if (isCorrectOption(optIdx)) cls += ' dc-lc-deepdive__opt--correct';
                        else if (selected) cls += ' dc-lc-deepdive__opt--wrong';
                      }
                      return (
                        <button
                          key={optIdx}
                          className={cls}
                          onClick={() => !deepDiveCompleted && answerDeepDive(qIdx, optIdx)}
                          disabled={deepDiveCompleted}
                        >
                          <span className="dc-lc-deepdive__opt-marker">
                            {deepDiveCompleted && serverResult
                              ? (isCorrectOption(optIdx) ? '\u2713' : selected ? '\u2715' : '\u25CB')
                              : (selected ? '\u25C9' : '\u25CB')}
                          </span>
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                  {deepDiveCompleted && serverResult?.explanation && (
                    <div className="dc-lc-deepdive__explain">{serverResult.explanation}</div>
                  )}
                </div>
              );
            })}

            <div className="dc-lc-deepdive__actions">
              {!deepDiveCompleted ? (
                <button
                  onClick={handleScoreDeepDive}
                  className="dc-btn dc-btn--primary"
                  disabled={Object.keys(deepDiveAnswers).length === 0 || ddLoading}
                >
                  {ddLoading ? 'Scoring...' : 'Submit Answers'}
                </button>
              ) : (
                <div className="dc-lc-deepdive__result">
                  <span className={`dc-lc-deepdive__score ${deepDiveScore >= 70 ? 'dc-lc-deepdive__score--good' : ''}`}>
                    Deep Dive: {deepDiveScore}%
                  </span>
                  <button onClick={handleFinish} className="dc-btn dc-btn--success">
                    See Final Score
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
