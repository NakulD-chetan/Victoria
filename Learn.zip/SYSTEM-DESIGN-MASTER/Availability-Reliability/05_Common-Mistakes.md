# Availability and Reliability — Common Mistakes

> **Permanent Recall:** Top 10 availability mistakes: (1) Single point of failure, (2) No SLA defined upfront, (3) Ignoring cascading failures, (4) Not testing failover, (5) Assuming cloud = always available, (6) No disaster recovery plan, (7) Not monitoring, (8) Ignoring partial failures, (9) Over-promising nines, (10) No graceful degradation. Avoid these to design production-grade systems.

---

## Mistake 1: Single Point of Failure (SPOF)

**What happens:** One component fails → entire system down.

| Wrong | Right |
|-------|-------|
| Single load balancer | LB pair or cloud LB (multi-AZ) |
| Single database | Primary + replica, failover |
| Single AZ deployment | Multi-AZ minimum |
| Single region | Multi-region for critical |

> **FAANG Tip:** Trace every request path. Ask "what if this component dies?" for each step.

---

## Mistake 2: Not Defining SLA Upfront

**What happens:** No target → no monitoring → no alerting → outages go unnoticed until customers complain.

| Wrong | Right |
|-------|-------|
| "We'll figure it out later" | Define SLO before launch |
| No SLI defined | Measure success rate, latency |
| No consequences for breach | SLA with credits or penalties |

---

## Mistake 3: Ignoring Cascading Failures

**What happens:** One server fails → removed from pool → remaining overloaded → they fail → chain reaction.

```
Server 1 fails → removed
Remaining servers get 1.5× traffic
Server 2 overloads → fails
Server 3 gets 2× traffic → fails
→ Total outage
```

**Fix:** Circuit breaker, over-provisioning (headroom), rate limiting, gradual removal.

---

## Mistake 4: Not Testing Failover

**What happens:** Failover "works on paper" but fails in production—wrong config, slow promotion, data loss.

| Wrong | Right |
|-------|-------|
| Assume failover works | Chaos Monkey, game days |
| Never test DR | Quarterly DR drills |
| No runbook | Documented steps, practiced |

> **FAANG Tip:** "We test failover in production with chaos engineering. Staging doesn't catch production quirks."

---

## Mistake 5: Assuming Cloud = Always Available

**What happens:** Single-AZ deployment, single region—one AZ outage takes everything down.

| Wrong | Right |
|-------|-------|
| One AZ, "AWS is reliable" | Multi-AZ minimum |
| One region for global users | Multi-region or accept risk |
| No dependency on single service | Design for dependency failure |

---

## Mistake 6: No Disaster Recovery Plan

**What happens:** Region goes down—no runbook, no RPO/RTO, ad-hoc panic.

| Wrong | Right |
|-------|-------|
| "We'll figure it out" | RPO, RTO defined; runbook written |
| No DR region | Async replication to backup region |
| Backup but never tested | Test restore quarterly |

---

## Mistake 7: Not Monitoring

**What happens:** Outage occurs; discovered by users, not alerts.

| Wrong | Right |
|-------|-------|
| No health checks | Liveness, readiness, deep |
| No alerting | Alert on error rate, latency |
| No dashboards | Single pane for SLI/SLO |

---

## Mistake 8: Ignoring Partial Failures

**What happens:** System "available" but DB read replica is down—some queries timeout; users see degraded experience.

**Fix:** Monitor all dependencies; circuit breaker when downstream fails; graceful degradation (e.g., serve stale cache).

---

## Mistake 9: Over-Promising Nines

**What happens:** Promise 99.99% without multi-region, hot standby—impossible to achieve. Customer expects 52 min/year downtime; you deliver 8 hours.

| Wrong | Right |
|-------|-------|
| 99.99% for everything | Match target to business impact |
| Promise without architecture | 99.99% needs multi-region, sync replica |
| No headroom above SLA | SLO > SLA (e.g., 99.95% SLO for 99.9% SLA) |

---

## Mistake 10: No Graceful Degradation

**What happens:** Cache down → all traffic hits DB → DB overloads → full outage. Could have served stale or disabled non-critical features.

**Fix:** Circuit breaker; fallback to degraded mode (read-only, cached stale); feature flags to disable non-critical path.

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| SPOF | Total outage | Redundancy, failover |
| No SLA | No target, no monitoring | Define SLO, SLI, SLA |
| Cascading failure | Chain reaction | Circuit breaker, headroom |
| No failover test | Failover fails in prod | Chaos engineering, drills |
| Cloud = always up | AZ outage = outage | Multi-AZ, multi-region |
| No DR plan | Chaos during disaster | RPO/RTO, runbook |
| No monitoring | Users find outages | Health checks, alerts |
| Partial failures | Degraded, unhandled | Monitor deps, degrade gracefully |
| Over-promise nines | Unachievable SLA | Match target to architecture |
| No graceful degradation | Full outage on partial failure | Circuit breaker, fallbacks |

---

## 30-SECOND REVISION BOX

```
1. SPOF — redundancy everywhere
2. Define SLA upfront
3. Cascading failure — circuit breaker, headroom
4. Test failover — chaos, game days
5. Cloud ≠ always up — multi-AZ
6. DR plan — RPO, RTO, runbook
7. Monitor — health, alerts
8. Partial failures — graceful degradation
9. Don't over-promise nines
10. Graceful degradation — fallbacks
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
