# Subqueries and CTE — Tricks and Recognition

| Clue | Reach for |
|------|-----------|
| “Customers with orders” | `EXISTS` or `INNER JOIN` (distinct grain) |
| “Customers without orders” | `NOT EXISTS` or `LEFT JOIN … IS NULL` |
| Long nested query | **CTE** to name stages |
| “Per-user aggregate in column” | Scalar subquery or **window** (often cleaner) |

---

*Next: [[08_Problem-List]]*
