# CAP Theorem and Consistency — Edge Cases

> **Permanent Recall:** Edge cases to handle: split brain (two leaders), stale reads after failover, write conflicts in multi-master, clock skew affecting LWW, network partition healing and reconciliation, partial failures, and read-your-writes violation after failover. Each has detection and mitigation strategies. Design for these in FAANG system design discussions.

---

## Edge Case 1: Split Brain

**What happens:** Network partition causes two subsets to each elect a leader. Both accept writes. Data diverges.

```
    Partition
    ┌─────────┐     X     ┌─────────┐
    │ Leader A│           │ Leader B│
    │ Writes  │           │ Writes  │
    └─────────┘           └─────────┘
         │                     │
    Same key, different values when partition heals
```

**Mitigation:** Quorum-based election—only majority can elect leader. Odd cluster size (3, 5). Split brain possible only if partition splits 50-50 (rare with 3 nodes).

---

## Edge Case 2: Stale Reads After Failover

**What happens:** Leader fails. New leader elected. Replica promoted may not have latest writes. Reads return old data.

**Mitigation:** Read-after-write from same session. Quorum reads. Fenced writes (epoch/generation) so old leader's writes rejected after failover.

---

## Edge Case 3: Write Conflicts in Multi-Master

**What happens:** Two regions write to same key concurrently. Both succeed. Which wins?

| Strategy | Behavior |
|----------|----------|
| **LWW** | Timestamp wins—clock skew can cause wrong winner |
| **Vector clocks** | Detect concurrent; merge or escalate |
| **Last-writer-wins with HLC** | Hybrid Logical Clock reduces clock issues |

---

## Edge Case 4: Clock Skew Affecting LWW

**What happens:** Node A clock 5 min ahead, Node B 5 min behind. LWW may pick the "wrong" write.

**Mitigation:** Use NTP, Hybrid Logical Clocks (HLC), or logical timestamps. Avoid wall-clock for LWW when clocks can skew.

---

## Edge Case 5: Network Partition Healing and Reconciliation

**What happens:** Partition heals. Two replicas have diverged. How to merge?

**Strategies:**
- **Read repair:** On read, compare replicas; fix stale ones
- **Hinted handoff:** Hold writes for unreachable nodes; replay when back
- **Anti-entropy:** Background Merkle tree comparison; sync differences
- **Conflict resolution:** LWW, merge, or manual

---

## Edge Case 6: Partial Failures

**What happens:** Some nodes slow, some down. Quorum might be barely reached. Latency spikes.

**Mitigation:** Timeouts, circuit breakers. Consider "partial quorum" vs "full quorum" semantics. Monitor replication lag.

---

## Edge Case 7: Read-Your-Writes Violation After Failover

**What happens:** User writes. Request goes to Node A. User's next read goes to Node B (after failover or load balance). Node B hasn't replicated yet. User doesn't see own write.

**Mitigation:** Session stickiness (same node for same user). Read-your-writes consistency level. Version vectors to track what user has seen.

---

## Edge Case: Tombstones and Deletes

**What happens:** Delete propagates eventually. A read might return deleted data from a lagging replica.

**Mitigation:** Tombstones (mark as deleted, don't remove). TTL. Read repair to sync replicas. Anti-entropy.

---

## Edge Case: Long Partition

**What happens:** Partition lasts minutes or hours. Divergent data accumulates. Reconciliation becomes expensive.

**Mitigation:** Operational runbooks. Consider manual merge for critical systems. Monitor replication lag and alert.

---

## Edge Case Summary Table

| Edge Case | Cause | Mitigation |
|-----------|-------|------------|
| Split brain | Partition, dual leaders | Quorum election, odd N |
| Stale after failover | Replica lag | Quorum read, fenced writes |
| Write conflicts | Multi-master, concurrent | LWW, vector clocks, HLC |
| Clock skew | NTP drift | HLC, logical clocks |
| Partition healing | Divergent replicas | Read repair, hinted handoff |
| Partial failures | Slow nodes | Timeouts, circuit breaker |
| Read-your-writes | Failover, routing | Stickiness, RYW consistency |
| Tombstones | Delete propagation | Tombstones, TTL, read repair |
| Long partition | Extended outage | Runbooks, manual merge |

---

## Design Checklist for Edge Cases

- [ ] Split brain: quorum size, odd N
- [ ] Failover: fenced writes, read quorum
- [ ] Conflicts: LWW vs merge, timestamp source
- [ ] Clock: NTP, HLC, or logical
- [ ] Healing: read repair, hinted handoff, anti-entropy
- [ ] RYW: stickiness or RYW consistency level
- [ ] Tombstones: handle deletes correctly
- [ ] Long partition: runbooks, manual intervention

---

## Interview Discussion: Edge Cases

When discussing design, proactively say: "We'd handle partition by [CP/AP choice]. For failover we'd use fenced writes. For multi-region conflicts we'd use [LWW/merge]." This demonstrates you've thought through edge cases.

---

## 30-SECOND REVISION BOX

```
SPLIT BRAIN: Quorum election, odd N
STALE FAILOVER: Quorum read, fenced writes
CONFLICTS: LWW, vector clocks, HLC
CLOCK SKEW: HLC, logical time
HEALING: Read repair, hinted handoff
READ-YOUR-WRITES: Stickiness, RYW level
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
