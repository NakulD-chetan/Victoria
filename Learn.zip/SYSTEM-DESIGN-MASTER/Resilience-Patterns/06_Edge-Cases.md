# Resilience Patterns — Edge Cases

> **Permanent Recall:** Edge cases: circuit breaker flapping (rapid Open↔Half-Open), rate limit bypass attacks (distributed clients, key guessing), retry storm cascading (many clients retrying), timeout too long/short (tune per p99), idempotency key collision (namespace keys, TTL), bulkhead thread starvation (sizing, monitoring), chaos experiment gone wrong (blast radius, rollback). Plan for these in design and testing.

---

## Circuit Breaker Flapping

**What:** Circuit rapidly opens and closes—Half-Open test succeeds, then next real request fails, repeat.

**Causes:** Service barely healthy; intermittent failures; threshold too sensitive.

**Mitigation:**
- Increase `permittedNumberOfCallsInHalfOpenState` (need multiple successes)
- Lengthen `waitDurationInOpenState` before retry
- Use sliding window with higher `slidingWindowSize`
- Consider "half-open success threshold" (e.g., 3 of 3 must succeed)

---

## Rate Limit Bypass Attacks

**What:** Attacker distributes requests across many IPs, user IDs, or API keys to evade per-identity limits.

**Mitigation:**
- Global rate limit (all requests) in addition to per-key
- Fingerprinting (TLS fingerprint, behavioral signals)
- Progressive penalties (slow down repeat offenders)
- CAPTCHA or challenge for suspicious patterns

**Key guessing:** Use long random idempotency keys; don't allow predictable patterns.

---

## Retry Storm Cascading

**What:** Many clients retry simultaneously → failing service gets overwhelmed → more failures → more retries.

**Causes:** No backoff, no jitter, circuit breaker not yet open, high retry count.

**Mitigation:**
- Exponential backoff + jitter (spread retries over time)
- Circuit breaker stops retries when open
- Retry budget (max retries per window per client)
- Server-side: return 503 with Retry-After header to coordinate clients

---

## Timeout Too Long / Too Short

**Too long:** Threads block; pool exhausts; latency degrades for all users.

**Too short:** Valid slow requests fail; unnecessary retries; poor p99 experience.

**Mitigation:**
- Set timeout to p99 or p99.9 latency of dependency + buffer
- Different timeouts per operation (quick reads vs heavy writes)
- Monitor timeout-triggered failures; tune iteratively

---

## Idempotency Key Collision

**What:** Two different operations use same key (bug, collision, or reused key).

**Impact:** Second operation returns first operation's result—wrong data.

**Mitigation:**
- Namespace keys: `{userId}:{operationType}:{clientKey}`
- Key format: UUID v4 or similar; low collision probability
- TTL: 24–72h; old keys expire
- Return error if key exists with different request body (client bug)

---

## Bulkhead Thread Starvation

**What:** One bulkhead's pool is exhausted; requests queue; but legitimate traffic for other pools gets starved if shared resources (e.g., global connection pool) are exhausted.

**Mitigation:**
- Size pools based on actual load; monitor queue depth
- Ensure no unbounded shared resource
- Consider semaphore with max wait time (fail fast vs indefinite block)

---

## Chaos Experiment Gone Wrong

**What:** Chaos injects failure; unexpected blast radius; production outage worse than intended.

**Mitigation:**
- Start small: one instance, one AZ, low error rate
- Feature flags to enable/disable chaos
- Automated rollback if error rate or latency breaches threshold
- Game days in staging first; production with limited scope
- Clear runbooks and communication

> **FAANG Tip:** "Chaos in production? Start with 1% of instances, 1% of traffic. Have kill switch and rollback. Measure blast radius before scaling up."

---

## Additional Edge Cases

**Timeout during retry:** Client times out but server completes. Idempotency key ensures duplicate request returns same result—no double charge.

**Circuit breaker across regions:** In multi-region, CB state is typically local. One region's CB open doesn't affect another. Consider shared state only for critical global limits.

**Rate limit on serverless:** Stateless functions; must use Redis or similar for distributed state. Cold start can cause brief burst—allow small burst in token bucket.

**Bulkhead + circuit breaker:** Use both. Bulkhead limits并发; circuit breaker stops calling when failing. Together: bounded load + fail fast.

---

## Edge Case Mitigation Matrix

| Edge Case | Primary Mitigation | Secondary |
|-----------|-------------------|-----------|
| CB flapping | More Half-Open successes | Longer open duration |
| Rate bypass | Global limit | Fingerprinting |
| Retry storm | Backoff + jitter | Circuit breaker |
| Timeout tuning | p99-based, monitor | Per-operation timeout |
| Idempotency collision | Namespace keys | Request body validation |
| Bulkhead starvation | Size + monitor | Max wait duration |
| Chaos gone wrong | Small scope | Kill switch |

---

## Debugging Resilience Issues

**Circuit breaker won't close:** Check if Half-Open test requests are actually succeeding; dependency might still be partially broken.

**Rate limit too aggressive:** Monitor 429 rate; compare to normal traffic; adjust limit or add burst allowance.

**Retries still causing storms:** Verify backoff and jitter are applied; check circuit breaker is opening before retry exhaustion.

---

## Summary

Plan for edge cases in design: CB flapping, bypass, retry storm, timeout tuning, idempotency collision, bulkhead starvation, chaos scope. Each has a mitigation; document in runbooks.

---

## 30-SECOND REVISION BOX

```
CB FLAPPING: more Half-Open successes, longer wait
RATE BYPASS: global limit, fingerprinting
RETRY STORM: backoff, jitter, CB, Retry-After
TIMEOUT: tune to p99, differ by operation
IDEMPOTENCY COLLISION: namespace, UUID, TTL
BULKHEAD STARVATION: size pools, monitor
CHAOS GONE WRONG: small scope, kill switch, rollback
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
