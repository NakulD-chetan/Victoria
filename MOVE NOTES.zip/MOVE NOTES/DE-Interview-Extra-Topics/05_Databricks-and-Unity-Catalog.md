# 05 — Databricks & Unity Catalog

> **One-line:** Databricks is a **unified analytics platform** built on Apache Spark that adds **managed infrastructure**, **Delta Lake**, **MLflow**, and **Unity Catalog** governance — the most in-demand DE platform in 2026 interviews.

---

## 1. Databricks Architecture

```
┌──────────────────────────────────────────────────┐
│              DATABRICKS WORKSPACE                 │
│                                                   │
│  ┌─────────────┐  ┌──────────┐  ┌─────────────┐ │
│  │ Notebooks   │  │ Jobs     │  │ SQL         │ │
│  │ (Interactive│  │ (Sched.) │  │ Warehouse   │ │
│  │  dev)       │  │          │  │ (BI queries) │ │
│  └─────────────┘  └──────────┘  └─────────────┘ │
│                                                   │
│  ┌─────────────────────────────────────────────┐ │
│  │           UNITY CATALOG                      │ │
│  │  (Centralized Governance Layer)              │ │
│  │  Catalog → Schema → Table/View/Function     │ │
│  └─────────────────────────────────────────────┘ │
│                                                   │
│  ┌──────────────────┐  ┌──────────────────────┐  │
│  │ Delta Lake       │  │ MLflow               │  │
│  │ (ACID Storage)   │  │ (ML Lifecycle)       │  │
│  └──────────────────┘  └──────────────────────┘  │
└──────────────────────────┬───────────────────────┘
                           │
              ┌────────────┴────────────┐
              │ Cloud Object Storage    │
              │ (S3 / ADLS / GCS)       │
              └─────────────────────────┘
```

| Component | What It Does |
|-----------|-------------|
| **Workspace** | Web UI for notebooks, repos, jobs, dashboards |
| **Clusters** | Managed Spark clusters (auto-scaling, auto-termination) |
| **Jobs** | Scheduled/triggered pipeline execution |
| **SQL Warehouses** | Serverless SQL endpoints for BI tools |
| **Unity Catalog** | Centralized governance (access control, lineage, audit) |
| **Delta Lake** | ACID table format built into Databricks |
| **MLflow** | ML experiment tracking, model registry |

---

## 2. Databricks Cluster Types

| Type | Use Case | Key Feature |
|------|----------|-------------|
| **All-Purpose** | Interactive development, notebooks | Long-running, shared by team |
| **Job Cluster** | Scheduled pipeline runs | Created per job, auto-terminates after |
| **SQL Warehouse** | BI queries, dashboards | Serverless option, no cluster management |

### Cluster Configuration (Interview Points)

| Setting | Detail |
|---------|--------|
| **Auto-scaling** | Min/Max workers — scales with workload |
| **Auto-termination** | Shuts down after idle minutes → saves cost |
| **Spot instances** | Use cloud spot/preemptible for workers → 60-80% cost savings |
| **Photon** | C++ native query engine — 3-8x faster than standard Spark |
| **Runtime** | Databricks Runtime includes optimized Spark + Delta + libs |

**Interview tip:** "Always use **Job Clusters** for production pipelines — they auto-terminate after the job. **All-Purpose** clusters are for development only."

---

## 3. Unity Catalog — Centralized Governance

### Three-Level Namespace

```
Catalog (e.g., production)
    └── Schema (e.g., sales)
            └── Table (e.g., orders)
                    └── Column (e.g., customer_email → PII tagged)

Full reference: production.sales.orders
```

### Unity Catalog Features

| Feature | What |
|---------|------|
| **Centralized access control** | GRANT/REVOKE at catalog, schema, table, column level |
| **Data lineage** | Auto-tracked: which tables feed which downstream tables |
| **Audit logging** | Who accessed what data, when |
| **Data discovery** | Search tables, view descriptions, tags |
| **Row/Column security** | Row-level filters, column masking for PII |
| **External locations** | Govern data outside Databricks (S3 paths) |

### Access Control Example

```sql
-- Grant read access to analysts on sales schema
GRANT SELECT ON SCHEMA production.sales TO analysts_group;

-- Column masking for PII
CREATE FUNCTION mask_email(email STRING)
  RETURNS STRING
  RETURN CONCAT(LEFT(email, 2), '***@***.com');

ALTER TABLE customers ALTER COLUMN email 
  SET MASK mask_email;
```

**Interview line:** "Unity Catalog provides **one governance layer** across all Databricks workspaces — instead of per-workspace access control, you get centralized RBAC, lineage, and audit."

---

## 4. Delta Live Tables (DLT) — Declarative Pipelines

| Feature | Detail |
|---------|--------|
| **What** | Declarative ETL framework — you define **what**, Databricks manages **how** |
| **Expectations** | Built-in data quality constraints (fail, drop, or warn on violations) |
| **Auto-management** | Automatic dependency resolution, incremental processing, error handling |
| **Medallion** | Natural fit for Bronze → Silver → Gold pipeline |

### DLT Example

```python
import dlt

@dlt.table(comment="Raw orders from source")
def bronze_orders():
    return spark.readStream.format("cloudFiles") \
        .option("cloudFiles.format", "json") \
        .load("/data/raw/orders/")

@dlt.table(comment="Cleaned orders")
@dlt.expect_or_drop("valid_amount", "amount > 0")
@dlt.expect_or_drop("not_null_id", "order_id IS NOT NULL")
def silver_orders():
    return dlt.read_stream("bronze_orders") \
        .select("order_id", "customer_id", "amount", "order_date")

@dlt.table(comment="Daily revenue aggregation")
def gold_daily_revenue():
    return dlt.read("silver_orders") \
        .groupBy("order_date") \
        .agg(sum("amount").alias("total_revenue"))
```

**Key point:** `@dlt.expect_or_drop` enforces data quality — rows violating constraints are automatically dropped and logged.

---

## 5. Auto Loader (cloudFiles) — File Ingestion

| Feature | Detail |
|---------|--------|
| **What** | Incrementally processes new files as they arrive in cloud storage |
| **How** | Tracks processed files via checkpoint (no re-processing) |
| **Formats** | JSON, CSV, Parquet, Avro, ORC, text, binary |
| **Schema evolution** | Auto-infers and evolves schema as new fields appear |
| **vs Snowpipe** | Databricks' equivalent of Snowflake Snowpipe |

```python
df = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format", "json") \
    .option("cloudFiles.schemaLocation", "/checkpoints/schema") \
    .load("/data/landing/")
```

---

## 6. Databricks vs Snowflake — Interview Comparison

| Dimension | Databricks | Snowflake |
|-----------|-----------|-----------|
| **Core** | Unified analytics (ETL + ML + BI) | Cloud data warehouse |
| **Engine** | Apache Spark (+ Photon) | Proprietary MPP engine |
| **Storage** | Delta Lake on cloud object store | Micro-partitions (proprietary) |
| **ML** | MLflow, feature store, model serving | Limited (partner integrations) |
| **SQL** | SQL Warehouses (good, improving) | Excellent SQL experience |
| **Governance** | Unity Catalog | Access control + policies |
| **Streaming** | Native Spark Structured Streaming | Snowpipe (micro-batch) |
| **Cost model** | DBU (Databricks Units) | Credits (warehouse + storage) |
| **Best for** | Heavy ETL + ML + streaming | SQL analytics + BI |

**Interview line:** "Databricks excels at **heavy transformations, ML, and streaming**. Snowflake excels at **SQL analytics and BI**. Many companies use **both** — Databricks for processing, Snowflake for serving."

---

## 7. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "What is Databricks?" | Unified platform on Spark: notebooks, jobs, Delta Lake, ML, governance |
| "Explain Unity Catalog" | Centralized 3-level namespace (catalog.schema.table) with RBAC, lineage, audit |
| "What are Delta Live Tables?" | Declarative ETL with built-in data quality expectations and auto-management |
| "Job cluster vs All-Purpose?" | Job: per-run, auto-terminate, production. All-Purpose: shared, dev/interactive |
| "What is Photon?" | C++ query engine in Databricks — 3-8x faster for SQL/DataFrame workloads |
| "What is Auto Loader?" | Incremental file ingestion with checkpointing and schema evolution |
| "Databricks vs Snowflake?" | Databricks: ETL+ML+streaming. Snowflake: SQL analytics+BI. Often used together |
| "How do you optimize Databricks cost?" | Job clusters, spot instances, auto-termination, right-size, Z-order, OPTIMIZE |

---

## Key Takeaways

- Databricks = **Spark + Delta Lake + MLflow + Unity Catalog** in a managed platform.
- **Job Clusters** for production, **All-Purpose** for dev — critical cost optimization.
- **Unity Catalog** = centralized governance with 3-level namespace, lineage, column masking.
- **Delta Live Tables** = declarative ETL with built-in data quality (`expect` decorators).
- **Auto Loader** = incremental file ingestion with schema evolution.
- **Photon** = C++ engine for 3-8x SQL performance boost.
- Databricks and Snowflake are **complementary**, not always competing.

---
