/**
 * World ↔ screen coordinate math.
 *
 * Canonical formulas (never inline these elsewhere):
 *   screenX = (worldX + panX) * zoom
 *   worldX  = screenX / zoom - panX
 *
 * `panX/Y` is stored in world units so that it composes cleanly with zoom.
 * This matches how the widgets position their DOM shells and keeps text,
 * strokes, and widgets perfectly aligned at any zoom level.
 */

export function screenFromWorld(worldX, worldY, vp) {
  return {
    x: (worldX + vp.panX) * vp.zoom,
    y: (worldY + vp.panY) * vp.zoom,
  };
}

export function worldFromScreen(screenX, screenY, vp) {
  return {
    x: screenX / vp.zoom - vp.panX,
    y: screenY / vp.zoom - vp.panY,
  };
}

/** Convert a client (viewport-relative) point to world coordinates. */
export function worldFromClient(clientX, clientY, canvasEl, vp) {
  const rect = canvasEl.getBoundingClientRect();
  return worldFromScreen(clientX - rect.left, clientY - rect.top, vp);
}

/**
 * Zoom around a given screen point so the point under the cursor stays put.
 * Returns a new viewport object.
 */
export function zoomAtScreenPoint(vp, screenX, screenY, nextZoom) {
  const clamped = Math.max(0.1, Math.min(8, nextZoom));
  // world point under the cursor before zoom
  const wx = screenX / vp.zoom - vp.panX;
  const wy = screenY / vp.zoom - vp.panY;
  // after zooming, screen = (w + pan') * z'; solve for pan'
  const panX = screenX / clamped - wx;
  const panY = screenY / clamped - wy;
  return { zoom: clamped, panX, panY };
}
