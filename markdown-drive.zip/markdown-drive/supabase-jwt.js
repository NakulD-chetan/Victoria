/*
 * Supabase JWT verification for the Express layer.
 *
 * Why this exists: the legacy authMiddleware in auth.js accepts opaque
 * UUID tokens (PIN users) and an unverified `firebase-{uid}` bearer hack.
 * Both are inadequate for multi-user collaboration. This module verifies
 * a real Supabase access-token JWT using the project's JWT secret and
 * attaches `req.user = { id, email, role, provider: 'supabase' }`.
 *
 * The verification is hand-rolled against Web Crypto (no external deps)
 * because the Supabase JS server SDK requires the service-role key for
 * server-side getUser, and that's a bigger surface than we need here.
 */

import { createHmac, timingSafeEqual } from 'crypto';

const SUPABASE_JWT_SECRET =
  process.env.SUPABASE_JWT_SECRET ||
  process.env.SUPABASE_AUTH_JWT_SECRET ||
  ''; // intentionally blank if unset → verifier will reject

const SUPABASE_URL =
  process.env.SUPABASE_URL ||
  process.env.VITE_SUPABASE_URL ||
  'https://svuumfizxptnxaidishq.supabase.co';

const SUPABASE_ANON_KEY =
  process.env.SUPABASE_ANON_KEY ||
  process.env.VITE_SUPABASE_ANON_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';

function base64UrlDecode(seg) {
  const pad = 4 - (seg.length % 4);
  const padded = seg + (pad < 4 ? '='.repeat(pad) : '');
  return Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

function base64UrlDecodeJson(seg) {
  return JSON.parse(base64UrlDecode(seg).toString('utf8'));
}

export function verifySupabaseJwt(token) {
  if (!token || typeof token !== 'string') return null;
  if (!SUPABASE_JWT_SECRET) {
    /* In dev without the secret configured we cannot verify; refuse rather
     * than silently accepting unsigned claims. Setting up env keeps prod
     * safe and dev one step away. */
    return null;
  }
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, sigB64] = parts;

  let header;
  let payload;
  try {
    header = base64UrlDecodeJson(headerB64);
    payload = base64UrlDecodeJson(payloadB64);
  } catch {
    return null;
  }
  if (header.alg !== 'HS256') return null;

  const expected = createHmac('sha256', SUPABASE_JWT_SECRET)
    .update(`${headerB64}.${payloadB64}`)
    .digest();
  const provided = base64UrlDecode(sigB64);
  if (expected.length !== provided.length) return null;
  try {
    if (!timingSafeEqual(expected, provided)) return null;
  } catch {
    return null;
  }

  const now = Math.floor(Date.now() / 1000);
  if (payload.exp && payload.exp < now) return null;
  if (payload.nbf && payload.nbf > now) return null;
  if (payload.aud && payload.aud !== 'authenticated' && payload.aud !== 'anon') return null;

  return {
    id: payload.sub,
    email: payload.email || null,
    role: payload.role || 'authenticated',
    provider: 'supabase',
    raw: payload,
  };
}

async function fetchSupabaseUser(token) {
  if (!token || !SUPABASE_URL || !SUPABASE_ANON_KEY) return null;

  try {
    const response = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: {
        apikey: SUPABASE_ANON_KEY,
        Authorization: `Bearer ${token}`,
      },
    });
    if (!response.ok) return null;

    const user = await response.json();
    if (!user?.id) return null;

    return {
      id: user.id,
      email: user.email || null,
      role: user.role || 'authenticated',
      provider: 'supabase',
      raw: user,
    };
  } catch {
    return null;
  }
}

/*
 * Express middleware. Tries Supabase JWT first; if absent or unverified
 * it calls the optional fallback (legacy AuthManager middleware) so
 * existing PIN flows keep working during the migration window.
 */
export function supabaseAuthMiddleware({ legacyFallback } = {}) {
  return async (req, res, next) => {
    const header = req.headers.authorization;
    if (header?.startsWith('Bearer ')) {
      const token = header.slice(7);
      /* Supabase access tokens are JWTs — three dot-separated b64url segments. */
      if (token.split('.').length === 3) {
        const claims = verifySupabaseJwt(token);
        if (claims) {
          req.user = claims;
          return next();
        }

        /* Local dev often runs without SUPABASE_JWT_SECRET. In that case,
         * ask Supabase Auth to validate the access token instead of failing
         * a perfectly valid browser session. */
        const remoteClaims = await fetchSupabaseUser(token);
        if (remoteClaims) {
          req.user = remoteClaims;
          return next();
        }
      }
    }
    if (legacyFallback) return legacyFallback(req, res, next);
    return res.status(401).json({ error: 'Authentication required', code: 'NO_TOKEN' });
  };
}
