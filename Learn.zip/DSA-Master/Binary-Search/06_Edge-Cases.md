# Binary Search — Edge Cases

> **The difference between "Almost Hired" and "Hired" at FAANG is edge case handling. These are the cases that break naive implementations.**

---

## Edge Case 1: Empty Array

### Scenario
```
arr = [], target = 5
```

### What Breaks
- `len(arr) - 1` = -1 → hi is negative
- `arr[mid]` index out of bounds
- Division by zero in some implementations

### How to Handle
```python
if not arr:
    return -1
```

```cpp
if (arr.empty()) return -1;
```

### FAANG Tip
> Always check empty input first. Binary search assumes non-empty.

---

## Edge Case 2: Single Element

### Scenario
```
arr = [7], target = 7  → should return 0
arr = [7], target = 5  → should return -1
```

### What Breaks
- lo=0, hi=0 from the start
- With `lo <= hi`: one iteration, mid=0, check arr[0]
- With `lo < hi`: loop never runs! Must return correct default

### How to Handle
```python
# For exact match with lo <= hi: works naturally
# For lo < hi (bisect): need hi = len(arr), so lo=0, hi=1
# Single element: lo=0, hi=1, mid=0, then lo or hi updates
```

### Golden Rule
> For bisect_left/right, use hi = len(arr) so single element is handled. For exact match, lo <= hi handles it.

---

## Edge Case 3: Target Not in Array

### Scenario
```
arr = [1, 3, 5, 7], target = 4
```

### What Breaks
- Exact match: returns -1 correctly
- bisect_left(4) → returns 2 (insert position)
- bisect_right(4) → returns 2
- Must distinguish "not found" vs "insert position" per problem

### How to Handle
```python
# Exact match: return -1 when loop exits without finding
# bisect_left: returns insert position (may not equal target)
pos = bisect_left(arr, target)
if pos == len(arr) or arr[pos] != target:
    return -1
return pos
```

---

## Edge Case 4: Target at Boundaries

### Scenario
```
arr = [1, 2, 3, 4, 5], target = 1  (first element)
arr = [1, 2, 3, 4, 5], target = 5  (last element)
```

### What Breaks
- Target at index 0: mid might never hit 0 in some wrong implementations
- Target at index n-1: same for last
- Verify loop correctly reaches boundaries

### How to Handle
```python
# Standard template handles this — lo and hi converge to target
# Trace: target=1 at index 0
# lo=0, hi=4, mid=2, arr[2]=3>1, hi=1
# lo=0, hi=1, mid=0, arr[0]=1, return 0 ✓
```

### FAANG Tip
> Always trace with target at first and last index. Catches off-by-one errors.

---

## Edge Case 5: All Duplicates

### Scenario
```
arr = [2, 2, 2, 2, 2], target = 2
```

### What Breaks
- Exact match: might return index 2 (middle) — acceptable if any occurrence OK
- First occurrence: must return 0
- Last occurrence: must return 4
- Count: bisect_right - bisect_left = 5

### How to Handle
```python
# First occurrence
left = bisect_left(arr, 2)   # 0
# Last occurrence
right = bisect_right(arr, 2)  # 5
last_pos = right - 1         # 4
# Count
count = right - left         # 5
```

---

## Edge Case 6: Target Smaller Than All Elements

### Scenario
```
arr = [5, 10, 15, 20], target = 1
```

### What Breaks
- bisect_left(1) → 0 (correct insert position)
- Exact match → -1
- Must not return 0 as "found" for exact match

### How to Handle
```python
pos = bisect_left(arr, target)
if pos < len(arr) and arr[pos] == target:
    return pos
return -1
```

---

## Edge Case 7: Target Larger Than All Elements

### Scenario
```
arr = [5, 10, 15, 20], target = 25
```

### What Breaks
- bisect_left(25) → 4 (len(arr)) — insert at end
- Accessing arr[4] → index out of bounds if not careful

### How to Handle
```python
pos = bisect_left(arr, target)
# pos can be len(arr) — valid!
if pos < len(arr) and arr[pos] == target:
    return pos
return -1
```

---

## Edge Case 8: Overflow with Large Indices

### Scenario
```
# Binary search on answer
lo, hi = 0, 10**9
# Or: array of size 10^9 (theoretical)
```

### What Breaks
- `mid = (lo + hi) // 2` when lo=hi=10^9 → 10^9 (OK in Python)
- In C++/Java: `(lo + hi) / 2` overflows when both ~10^9

### How to Handle
```python
mid = lo + (hi - lo) // 2  # Always safe
```

```cpp
long long mid = lo + (hi - lo) / 2;
```

---

## Edge Case 9: Rotated Array — No Rotation

### Scenario
```
arr = [1, 2, 3, 4, 5]  # Sorted, not rotated
```

### What Breaks
- Rotated array logic: "which half is sorted?"
- When not rotated: entire array is sorted
- arr[lo] <= arr[mid] is true for left half — should still work

### How to Handle
```python
# Standard rotated search handles this
# arr[lo] <= arr[mid] → left sorted, target in [lo, mid] or [mid+1, hi]
```

---

## Edge Case 10: Rotated Array — All Same

### Scenario
```
arr = [2, 2, 2, 2, 2], target = 2
```

### What Breaks
- arr[lo] <= arr[mid] and arr[mid] <= arr[hi] — can't tell which half is "sorted"
- May need linear scan when arr[lo] == arr[mid] == arr[hi]

### How to Handle
```python
# For "search in rotated with duplicates" — O(n) worst case
# Shrink from ends when arr[lo] == arr[mid] == arr[hi]
while lo <= hi and arr[lo] == arr[mid] == arr[hi]:
    lo += 1
    hi -= 1
# Or: linear scan when equality
```

---

## Edge Case 11: BS on Answer — No Valid Answer

### Scenario
```
# Minimum capacity to ship in 5 days
# weights = [100, 100, 100], D = 1
# Impossible: need at least 3 days
```

### What Breaks
- Binary search converges to some value
- That value might not satisfy the condition
- Returning it would be wrong

### How to Handle
```python
lo, hi = max(weights), sum(weights)
while lo < hi:
    mid = lo + (hi - lo) // 2
    if can_ship(mid, weights, D):
        hi = mid
    else:
        lo = mid + 1
# Verify!
return lo if can_ship(lo, weights, D) else -1
```

---

## Edge Case 12: Matrix — Empty or Single Row

### Scenario
```
matrix = []
matrix = [[]]
matrix = [[1]]
```

### What Breaks
- matrix[0] when empty → error
- n = len(matrix[0]) when row is [] → 0, mid % 0 error

### How to Handle
```python
if not matrix or not matrix[0]:
    return False
m, n = len(matrix), len(matrix[0])
```

---

## Edge Case Checklist

| # | Edge Case | Check | Impact |
|---|-----------|-------|--------|
| 1 | Empty array | `len(arr) == 0` | Return -1 or handle |
| 2 | Single element | `len(arr) == 1` | Verify loop/return |
| 3 | Target not in array | No match | Return -1 for exact |
| 4 | Target at boundaries | First/last index | Trace to verify |
| 5 | All duplicates | Same value | First/last/count |
| 6 | Target < all | Before start | bisect_left = 0 |
| 7 | Target > all | After end | bisect_left = n |
| 8 | Large indices | Overflow | lo + (hi - lo) / 2 |
| 9 | Rotated = sorted | No rotation | Logic still works |
| 10 | Rotated all same | Can't split | May need O(n) |
| 11 | BS answer invalid | No solution | Verify at end |
| 12 | Empty matrix | Rows/cols 0 | Guard clause |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Binary Search Edge Cases
ALWAYS CHECK:       Empty array, single element
TARGET:             Not in array, at boundaries, < min, > max
DUPLICATES:         First/last/count — use bisect_left/right
OVERFLOW:           mid = lo + (hi - lo) / 2
ROTATED:            No rotation, all same — handle equality
BS ON ANSWER:       Verify condition(lo) when no answer possible
MATRIX:             Empty, single row/col
INTERVIEW LINE:     "Let me check: empty input, target not found,
                     and the case where no valid answer exists."
```
