import { useRef, useEffect, useCallback, useState } from 'react';
import { LeastConnectionLB } from '../../lib/algorithms/least-connections';
import { useLeastConnStore } from '../../stores/least-conn-store';
import LeastConnCanvas from './LeastConnCanvas';
import CodePanel from './CodePanel';
import EventLog from './EventLog';

export default function LeastConnVisualizer({ config }) {
  const lbRef = useRef(new LeastConnectionLB(4));
  const canvasRef = useRef(null);
  const autoIntervalRef = useRef(null);
  const codeStepTimeoutRef = useRef(null);

  const {
    serverCount, autoActive, autoRate, processingSpeed,
    currentStep, totalRequests,
    addLog, recordRequest, setStep, reset, startTime,
  } = useLeastConnStore();

  const [codeOpen, setCodeOpen] = useState(false);
  const [connections, setConnections] = useState([0, 0, 0, 0]);
  const [perServer, setPerServer] = useState([0, 0, 0, 0]);

  useEffect(() => {
    lbRef.current.reset(serverCount);
    setConnections(new Array(serverCount).fill(0));
    setPerServer(new Array(serverCount).fill(0));
  }, [serverCount]);

  const highlightSteps = useCallback((steps) => {
    if (codeStepTimeoutRef.current) clearTimeout(codeStepTimeoutRef.current);
    let i = 0;
    function next() {
      if (i >= steps.length) { setTimeout(() => setStep(null), 600); return; }
      setStep(steps[i]);
      i++;
      codeStepTimeoutRef.current = setTimeout(next, 150);
    }
    next();
  }, [setStep]);

  const sendRequest = useCallback(() => {
    const result = lbRef.current.getServer();
    const t = ((performance.now() - startTime) / 1000).toFixed(1);
    recordRequest();
    setConnections([...lbRef.current.connections]);
    setPerServer([...lbRef.current.totalRouted]);

    addLog({ time: t + 's', type: 'allow', message: `\u2192 Routed to Server ${result.serverIdx + 1} (had ${result.minConn} conns)` });
    canvasRef.current?.addAnim('route', { serverIdx: result.serverIdx, dur: 900 });
    highlightSteps(config.stepsAllow);

    const processDuration = (1000 + Math.random() * 2000) / processingSpeed;
    setTimeout(() => {
      const rel = lbRef.current.release(result.serverIdx);
      setConnections([...lbRef.current.connections]);
      const t2 = ((performance.now() - startTime) / 1000).toFixed(1);
      addLog({ time: t2 + 's', type: 'refill', message: `\u2713 Server ${result.serverIdx + 1} completed (conns: ${rel.connections[result.serverIdx]})` });
      canvasRef.current?.addAnim('complete', { serverIdx: result.serverIdx, dur: 500 });
    }, processDuration);
  }, [startTime, recordRequest, addLog, highlightSteps, config.stepsAllow, processingSpeed]);

  const handleBurst = useCallback(() => {
    let i = 0;
    const iv = setInterval(() => { if (i++ >= 5) { clearInterval(iv); return; } sendRequest(); }, 120);
  }, [sendRequest]);

  const handleReset = useCallback(() => {
    lbRef.current.reset(serverCount);
    setConnections(new Array(serverCount).fill(0));
    setPerServer(new Array(serverCount).fill(0));
    reset();
    addLog({ time: '0.0s', type: 'refill', message: 'Load balancer reset' });
  }, [serverCount, reset, addLog]);

  useEffect(() => {
    if (autoActive) { autoIntervalRef.current = setInterval(sendRequest, 1000 / autoRate); }
    else if (autoIntervalRef.current) { clearInterval(autoIntervalRef.current); autoIntervalRef.current = null; }
    return () => { if (autoIntervalRef.current) clearInterval(autoIntervalRef.current); };
  }, [autoActive, autoRate, sendRequest]);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); sendRequest(); }
      if (e.key === 'b' || e.key === 'B') handleBurst();
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [sendRequest, handleBurst, handleReset]);

  const { setServerCount, setAutoRate, setProcessingSpeed, toggleAuto } = useLeastConnStore();

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <div className="dc-stats-inline">
          <div className="dc-stat-chip">
            <span className="dc-stat-chip__value" style={{ color: 'var(--accent-secondary)' }}>{totalRequests}</span>
            <span className="dc-stat-chip__label">Total</span>
          </div>
          {connections.slice(0, serverCount).map((c, i) => (
            <div key={i} className="dc-stat-chip">
              <span className="dc-stat-chip__value" style={{ color: c > 0 ? 'var(--accent-warm)' : 'var(--accent)' }}>{c}</span>
              <span className="dc-stat-chip__label">S{i + 1}</span>
            </div>
          ))}
          <div className="dc-stats-inline__bar">
            <div className="dc-stats-inline__bar-fill" style={{
              width: `${totalRequests > 0 ? 100 : 0}%`,
              background: 'var(--accent)',
            }} />
          </div>
        </div>
      </div>

      <LeastConnCanvas ref={canvasRef} lbRef={lbRef} />

      <div className="dc-control-bar">
        <button className="dc-btn dc-btn--primary" onClick={sendRequest}>Send Request</button>
        <button className="dc-btn dc-btn--secondary" onClick={handleBurst}>Burst x5</button>
        <button className={`dc-btn ${autoActive ? 'dc-btn--success' : 'dc-btn--outline'}`} onClick={toggleAuto}>
          {autoActive ? 'Stop Auto' : 'Auto Send'}
        </button>
        <div className="dc-control-bar__sep" />
        <div className="dc-slider-group">
          <label>Servers</label>
          <input type="range" min={2} max={5} value={serverCount} onChange={(e) => setServerCount(+e.target.value)} />
          <span className="dc-slider-val">{serverCount}</span>
        </div>
        <div className="dc-slider-group">
          <label>Speed</label>
          <input type="range" min={1} max={8} step={0.5} value={processingSpeed} onChange={(e) => setProcessingSpeed(+e.target.value)} />
          <span className="dc-slider-val">{processingSpeed}x</span>
        </div>
        <div className="dc-slider-group">
          <label>Auto</label>
          <input type="range" min={1} max={15} value={autoRate} onChange={(e) => setAutoRate(+e.target.value)} />
          <span className="dc-slider-val">{autoRate}/s</span>
        </div>
        <div className="dc-control-bar__sep" />
        <button className="dc-btn dc-btn--danger" onClick={handleReset}>Reset</button>
      </div>

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" />
              <polyline points="8 6 2 12 8 18" />
            </svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: codeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          {codeOpen && (
            <div className="dc-visualizer__code-wrap">
              <CodePanel code={config.code} activeStep={currentStep} languages={config.meta.languages} storeFn={useLeastConnStore} />
            </div>
          )}
        </div>
        <div className="dc-visualizer__log-col">
          <EventLog storeFn={useLeastConnStore} />
        </div>
      </div>

      <div className="dc-visualizer__shortcuts">
        <kbd>Space</kbd> Send <kbd>B</kbd> Burst <kbd>R</kbd> Reset
      </div>
    </div>
  );
}
