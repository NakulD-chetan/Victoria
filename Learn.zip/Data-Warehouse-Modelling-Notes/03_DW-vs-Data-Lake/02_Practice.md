# Data Warehouse vs Data Lake — Practice

> "Name the workload first; the storage pattern follows."

---

## Quick Recall

**Q:** What is the typical primary format emphasis for a lake vs a warehouse?  
**A:** Lakes often store diverse raw files (JSON, Parquet, images metadata); warehouses emphasize structured, modeled tables for SQL consumers.

**Q:** Which is better for exploratory data science on raw web logs?  
**A:** A lake or lake zone is usually better for cheap, flexible retention before schema commitment.

**Q:** Which is better for CFO dashboards with audited metrics?  
**A:** A curated warehouse or warehouse zone with governed star schemas and access controls.

**Q:** What is "schema-on-read"?  
**A:** Structure is applied when querying raw data, not strictly enforced at ingest—common in lakes.

**Q:** Can one platform offer both patterns?  
**A:** Yes; lakehouse architectures combine low-cost storage with SQL engines and optional curated marts.

---

## Interview Questions

**1. Compare a data warehouse and a data lake for a mid-size e-commerce company.**  
**Model answer:** I position the lake as the broad landing zone for raw clickstream, third-party feeds, and JSON exports from SaaS tools. The warehouse holds curated, conformed models—like `dim_customer` and `fact_orders`—optimized for BI and finance. Retail needs both: flexibility upstream and trust downstream. I avoid treating them as competitors; they are different layers in a modern platform.

**2. Why not put everything in Parquet on S3 and skip a warehouse?**  
**Model answer:** You still need governance, performance tuning for BI concurrency, semantic layers, and often ACID table features. Raw Parquet alone does not give business users a self-service catalog of trusted facts without significant engineering on top. Finance will still ask who signed off on the metric definition.

**3. When would you recommend warehouse-first?**  
**Model answer:** When the primary pain is inconsistent reporting across finance and operations, and most questions are SQL aggregates on structured entities like orders and shipments. Warehouse-first gets executives aligned faster than asking them to navigate raw partitions.

**4. When would you recommend lake-first?**  
**Model answer:** When ingestion is heterogeneous, volumes are very large, and many use cases are ML feature engineering or exploratory work before dimensional models exist. Apparel trend forecasting from social signals is a classic lake-heavy pattern.

**5. How do you handle PII in each layer for retail?**  
**Model answer:** Tokenize or hash in landing zones where possible; apply role-based access in the warehouse; document retention and legal basis. Lakes need the same rigor because they often hold more raw detail. I assume attackers target the widest tables with the least clarity.

**6. What is a medallion or zone architecture in this context?**  
**Model answer:** Bronze raw, silver cleansed and conformed, gold curated marts—the gold zone behaves like a warehouse even if physically on object storage. Naming varies by vendor, but the idea is progressive trust and structure.

**7. What is a common anti-pattern?**  
**Model answer:** Dumping OLTP exports into a lake without modeling and calling it analytics-ready—teams still cannot answer basic margin questions reliably. Another anti-pattern is infinite raw retention without lifecycle policy, which balloons cost.

**8. How do cost profiles differ for a high-volume retailer?**  
**Model answer:** Lakes win on cheap deep storage for raw and infrequently accessed data; warehouses incur compute for interactive BI and maintenance jobs. The winning design tiers data and pushes cold raw to inexpensive storage while keeping hot aggregates queryable.

---

## Scenario-Based Exercises

**Scenario 1 — Product images and descriptions for recommendations**  
Binary and NLP features are bulky; finance needs tight sales facts.  
**Solution:** Store embeddings and large blobs in the lake; keep narrow feature tables or aggregates in the warehouse joined by `product_key` for reporting. Finance never scans image tensors to close the books.

**Scenario 2 — Clickstream plus orders for attribution**  
**Solution:** Raw events in lake; nightly job builds `fact_attribution` at order level in the warehouse with documented attribution rules. Disagreements about attribution become data product decisions, not SQL one-offs.

**Scenario 3 — Query pattern**  
Merchants want ad hoc filters on ten years of line items.  
**Solution:** Columnar lake tables for scan efficiency; curated `fact_sales_line` in warehouse with partitioning on `order_date` and clustering on `product_key`. Align BI tools to the curated table to control cost.

```sql
SELECT product_id, SUM(sales_amount) AS sales
FROM dw.fact_sales_line
WHERE order_date >= DATE '2025-11-01'
  AND order_date <  DATE '2025-12-01'
GROUP BY product_id;
```

**Scenario 4 — Vendor and compliance pressure**  
**Solution:** When a vendor says the warehouse is legacy, acknowledge convergence: the distinction is increasingly logical, but raw landing must still stay separate from governed consumption for retail trust and cost control. When auditors ask where customer emails live, inventory lake and warehouse paths, minimize copies, document authoritative layers, and prefer one tokenization strategy at bronze ingestion.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Declaring lakes replace warehouses | Many orgs need curated SQL marts | Describe complementary zones |
| Warehouse = only RDBMS | Cloud warehouses use object storage too | Clarify logical role vs product label |
| Ignoring cost at scale | Interviewers care about economics | Mention lifecycle tiers and compression |
| "Schema-on-write is always bad" | Governance needs structure somewhere | Position write-time conformation for gold |
| Assuming lake implies data science only | Operations also needs governed outputs | Name gold marts and semantic layers |
| Hand-waving on PII | Retail breaches are career-defining | Give concrete controls and minimization |

---

## One-Liner Answers

- A lake optimizes for cheap, flexible storage of diverse raw data; a warehouse optimizes for governed, query-friendly analytics models.
- Retail often uses a lake for raw events and a warehouse for conformed facts and dimensions.
- Lakehouse merges storage economics with SQL and ACID table formats.
- The warehouse answers trusted BI questions; the lake supports exploration and ML.
- Zones or medallion layers map raw to curated without throwing away flexibility.
- Choosing between them is really choosing ingestion flexibility versus consumption trust.
