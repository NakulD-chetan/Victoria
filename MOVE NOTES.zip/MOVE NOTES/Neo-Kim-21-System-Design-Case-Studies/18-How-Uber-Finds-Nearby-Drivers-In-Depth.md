# How Uber Finds Nearby Drivers - In Depth (Easy Language)

> Companion to: [18-How-Uber-Finds-Nearby-Drivers.md](18-How-Uber-Finds-Nearby-Drivers.md)

---

## The Scale of the Problem

```
1 MILLION "find nearby drivers" requests per second
Drivers update their location every few seconds
Millions of drivers worldwide, constantly moving
```

When you open Uber and see cars moving around you on the map, the system is answering the question "which drivers are near this user?" a million times every second.

---

## H3 - Uber's Own Hexagonal Grid

### H3 vs S2

Uber created their own hexagonal library called **H3** (Tinder uses Google's S2). Both use hexagons, but H3 was designed specifically for Uber's needs.

```
H3 specifics:
  → 122 base cells cover the entire Earth
  → 12 of those are pentagons (you CAN'T tile a sphere with only hexagons)
  → 16 resolution levels (0 = continent, 15 = ~1 sq meter)
  → Cell ID = 64-bit integer (fits in a database column)
  → kRing function: find all neighboring cells at any resolution
```

### How Nearby Search Works

```
Step 1: Rider requests a ride at location (19.076°N, 72.877°E)

Step 2: Convert to H3 cell ID at resolution 7:
  h3_cell = h3.geo_to_h3(19.076, 72.877, resolution=7)
  → Returns: 0x872830828ffffff

Step 3: Find nearby cells (kRing):
  neighbors = h3.k_ring(0x872830828ffffff, k=1)
  → Returns 7 cells (center + 6 neighbors)
  
  For larger radius: k_ring with k=2 → 19 cells, k=3 → 37 cells

Step 4: Query drivers in those cells:
  SELECT * FROM drivers WHERE h3_cell IN (cell1, cell2, ..., cell7)
  → Returns all drivers in the area

Step 5: Sort by ETA and return nearest drivers
```

**Why this is fast:**
- H3 cell ID is the **shard key** in the database
- Drivers in the same area are on the **same shard**
- For a 160 km radius, you only query ~3 shards on average
- No full-table scan, no distance calculation for every driver

---

## Map Matching - Cleaning Up Noisy GPS

### The Problem: GPS Isn't Accurate

```
Real path (actual road):
  ╔════════════════╗
  ║  road segment  ║
  ╚════════════════╝

Raw GPS points (what the phone reports):
    •   
  •       •
      •  •    •
  •           •

GPS points are scattered! Why?
  → Buildings reflect signals (multipath effect)
  → Tunnels block signals entirely
  → Phone antenna quality varies
  → Urban canyons (tall buildings on both sides)
```

A GPS point might show a driver IN a building when they're actually ON the road next to it.

### Why This Matters

```
Without map matching:
  Driver appears at GPS point (in a building)
  → ETA calculation: "Driver must exit building, reach road..." WRONG!
  → Nearest driver search: returns driver who's actually far away on the road
  
With map matching:
  GPS point → snapped to nearest road segment
  → ETA calculation uses actual road position → ACCURATE
  → Nearest driver search returns actually closest driver
```

### How Map Matching Works

**Step 1: Buffer GPS points in Redis**
```
Raw GPS stream from driver:
  Point 1: (19.0760, 72.8770) at 10:00:01
  Point 2: (19.0762, 72.8773) at 10:00:04
  Point 3: (19.0758, 72.8778) at 10:00:07
  
  → Buffer in Redis (collect several points before processing)
```

**Step 2: Kalman Filter (Smart Location Guesser)**
```
Kalman filter combines:
  → Previous known position
  → New GPS reading
  → Expected movement (speed, direction)
  → GPS accuracy estimate
  
Result: A BETTER estimate of true position than raw GPS alone

Analogy: 
  "You were at Point A moving north at 30 km/h.
   GPS says you're now at Point X (100 meters east of expected).
   GPS accuracy: ±50 meters.
   Best guess: you're probably at Point B (between expected and GPS reading)."
```

**Step 3: Viterbi Algorithm (Most Probable Road Path)**
```
After Kalman filtering, we have better location estimates.
But WHICH road segment is the driver on?

Multiple roads might be nearby:
  Highway 1:     ═══════════════
  Local road:    ───────────────
  Service lane:  ...............

Viterbi algorithm (dynamic programming):
  → For each GPS point, consider ALL nearby road segments
  → Calculate probability of each segment given:
    - Distance from GPS point to road
    - Road direction vs driver's heading
    - Speed limit of road vs driver's speed
    - Continuity (did the driver logically move from previous segment?)
  
  → Find the MOST PROBABLE sequence of road segments
  → This is the driver's actual path!
```

---

## The Architecture

```
┌──────────────┐
│ Driver App   │ → sends GPS every 3-5 seconds
└──────┬───────┘
       ↓
┌──────────────┐
│ Location API │
└──────┬───────┘
       ↓
┌──────┴────────────────────────────────┐
│                                        │
│  RAW LOCATION PATH:                   │
│  GPS → Cassandra (write-optimized)    │
│      → Redis (cache for read queries) │
│                                        │
│  MAP-MATCHED PATH:                    │
│  GPS → Redis buffer → Map Matching    │
│        Service → Map-matched Cassandra│
│                                        │
└──────┬────────────────────────────────┘
       ↓
┌──────────────────────┐
│ Find Nearby Service  │
│                      │
│ 1. User requests ride│
│ 2. H3 cell lookup    │
│ 3. kRing neighbors   │
│ 4. Query Redis cache │
│ 5. Sort by ETA       │
│ 6. Return top drivers│
└──────────────────────┘
```

### Why Two Storage Paths?

```
RAW location (Cassandra + Redis):
  → Used for: "Where is this driver RIGHT NOW?"
  → Fast writes (driver updates every 3 seconds)
  → Redis cache for fast reads (find nearby drivers)

MAP-MATCHED location (separate Cassandra):
  → Used for: "What road is this driver on?"
  → More accurate for ETA calculations
  → Processed asynchronously (slight delay is OK)
```

---

## Revision Flashcards

**Q: What is H3 and how does Uber use it?**
A: H3 is Uber's hexagonal geospatial library with 16 resolution levels and 122 base cells. Uber converts driver locations to H3 cell IDs, uses cell IDs as shard keys, and queries only neighboring cells (kRing) for nearby driver searches.

**Q: Why is map matching necessary?**
A: Raw GPS is noisy (building reflections, tunnels, urban canyons). A driver might appear in a building when they're on the road. Map matching snaps GPS to actual road segments for accurate ETA and driver proximity.

**Q: What does the Kalman filter do?**
A: Combines previous position, new GPS reading, expected movement, and GPS accuracy to produce a better location estimate than raw GPS alone.

**Q: What does the Viterbi algorithm do?**
A: Uses dynamic programming to find the most probable sequence of road segments the driver traveled on, considering distance, direction, speed, and path continuity.

**Q: Why does Uber store locations in both Cassandra and Redis?**
A: Cassandra is write-optimized (handles millions of location updates/second). Redis is read-optimized (handles 1M nearby-driver queries/second). Each is optimized for its specific access pattern.
