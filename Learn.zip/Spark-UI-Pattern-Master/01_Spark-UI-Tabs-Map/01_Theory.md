# Spark UI Tabs Map — The 6-Tab X-Ray

Spark UI ko samajhne ka pehla step hai *"kis tab pe kya milta hai"* ka mental map. Ek baar yeh map fix ho gaya, debugging 5x faster ho jaati hai.

**DSA Analogy**: Browser DevTools — har tab (Network, Console, Performance) alag layer dikhata hai. Spark UI ke 6 tabs bhi alag-alag layers hain.

---

## Core Idea (2 Lines)

Spark UI ek **read-only dashboard** hai jo running ya completed application ke har execution event ko 6 tabs mein decompose karta hai. Tum *kya question* puchh rahe ho usi se decide hota hai *kaunsa tab* khulna chahiye.

---

## How to Open Spark UI

```python
spark = (SparkSession.builder
    .appName("MyApp")
    .master("local[*]")
    .config("spark.ui.port", "4040")
    .config("spark.eventLog.enabled", "true")
    .config("spark.eventLog.dir", "file:///tmp/spark-events")
    .getOrCreate())

input("Press ENTER to exit...")   # keeps UI alive
```

| Environment        | URL / Path                                                |
|--------------------|-----------------------------------------------------------|
| Local script       | `http://localhost:4040`                                   |
| Local (2nd app)    | `http://localhost:4041`, `4042`, ... (Spark auto-increments) |
| Cluster (driver)   | `http://<driver-host>:4040`                               |
| History Server     | `http://<history-host>:18080` (needs `eventLog.enabled`)  |
| Databricks         | Cluster page → "Spark UI" tab                             |
| EMR / YARN         | YARN ResourceManager → ApplicationMaster link             |

---

## The 6 Tabs — One-Line Map

```
+------+--------+---------+-------------+-----------+--------+
| Jobs | Stages | Storage | Environment | Executors |  SQL   |
+------+--------+---------+-------------+-----------+--------+
   ^       ^        ^          ^             ^          ^
   |       |        |          |             |          |
 high    task     cache    config         memory      query
 level   detail   status   verify         + GC        plans
```

| #  | Tab           | Kya Dikhata Hai                                                | Pehle Question Yeh Puchho                       |
|----|---------------|----------------------------------------------------------------|-------------------------------------------------|
| 1  | **Jobs**      | One row per **action** — duration, stages, tasks               | "Slow kaunsa job hai?"                          |
| 2  | **Stages**    | Per-stage tasks, shuffle bytes, spill, GC, task time spread    | "Slow stage ke andar kya ho raha hai?"          |
| 3  | **Storage**   | Cached DataFrames / RDDs, fraction cached, eviction            | "Mera cache actually use ho raha hai?"          |
| 4  | **Environment** | All `spark.conf` values, JVM args, classpath                 | "Mere config apply hue ya nahi?"                |
| 5  | **Executors** | Per-executor memory, GC, tasks, shuffle, dead/alive            | "Kaunsa executor maara ja raha hai?"            |
| 6  | **SQL**       | Logical + physical plan, operator-level rows/time              | "Catalyst ne mera query kaise execute kiya?"    |

---

## Tab 1 — Jobs (Top of the Funnel)

```
Jobs Tab:
+----+----------------------------------+-----------+--------+--------------------+
| Id | Description                      | Duration  | Stages | Tasks (succ/total) |
+----+----------------------------------+-----------+--------+--------------------+
|  0 | count at app.py:30               |    44 s   |  3/3   |       23/23        |
|  1 | showString at app.py:51 (iter 1) |   2.0 s   |  1/2 (1 skipped) |  7/23 (16 skipped) |
|  2 | showString at app.py:51 (iter 2) |    25 ms  |  1/3 (2 skipped) |  4/26             |
|  3 | showString at app.py:51 (iter 3) |    33 ms  |  1/3 (2 skipped) |  3/25             |
|  4 | collect at app.py:54             |   1.0 s   |  2/3 (1 skipped) | 14/30             |
+----+----------------------------------+-----------+--------+--------------------+
```

**Read this column-by-column:**

| Column         | What It Tells You                                                  |
|----------------|--------------------------------------------------------------------|
| Id             | Sequential — Job 0 is first action submitted                       |
| Description    | `<action>` + `file:line`. **Click it** to drill into stages        |
| Duration       | Wall-clock from submit to last task                                |
| Stages         | `active/total (skipped)`. *Skipped* = output reused (Pattern 05)   |
| Tasks          | `succeeded/total (skipped)`                                        |

**Reading rule**: One row = one **action** (`count`, `show`, `collect`, `write`, `take`, etc.).
Multiple rows for one `df.show()`? See Pattern 03.

---

## Tab 2 — Stages (The Real Debugging Hub)

```
Stage 0 (createDataFrame at app.py:18):
+------+--------+-----------+----------+---------+-------+
|Index |Duration|Shuffle Read|Shuf Write|Spill Mem|GC Time|
+------+--------+-----------+----------+---------+-------+
|   0  |  0.5s  |    0      |   12 MB  |    0 B  |  20ms |
|   1  |  0.4s  |    0      |   12 MB  |    0 B  |  18ms |
|  ... |  ...   |   ...     |    ...   |   ...   |  ...  |
|  15  |  0.6s  |    0      |   12 MB  |    0 B  |  22ms |
+------+--------+-----------+----------+---------+-------+
Summary metrics:
  Min   25%   Median   75%   Max
  0.3s  0.4s   0.5s    0.6s  0.7s   <- healthy spread
```

**6 Critical Per-Stage Metrics** (memorize these):

| Metric              | Healthy            | Warning                | Danger                 |
|---------------------|--------------------|------------------------|------------------------|
| Task duration spread| Max ≤ 2× Median    | Max 5–10× Median       | Max > 10× Median (skew)|
| Shuffle read        | < input size       | ~ input size           | >> input (re-shuffle)  |
| Shuffle write       | low for narrow ops | normal for joins/groupBy | huge for repartition |
| Shuffle spill (mem) | 0                  | < 10% of shuffle       | > 10% (memory tight)   |
| Shuffle spill (disk)| 0                  | small                  | any large value        |
| GC time             | < 5% of task time  | 5–10%                  | > 10%                  |

> **Tab 2 is where 80% of debugging happens.** Pattern 04 and 08 live here.

---

## Tab 3 — Storage (Cache Health Check)

```
Storage Tab:
+--------------------+----------------+-------+--------+-----------+
| RDD/DataFrame Name | Storage Level  | Size  | Cached |Disk Spill |
+--------------------+----------------+-------+--------+-----------+
| df_filtered        | MEMORY_AND_DISK| 240MB |  6/6   |   0       |
| lookup_table       | MEMORY_ONLY    |  50MB |  10/10 |   0       |
| big_df             | MEMORY_AND_DISK| 4.2GB |  18/24 | 1.1GB     |  <- partial cache
+--------------------+----------------+-------+--------+-----------+
```

**4 things to read here:**

1. **Cached fraction (e.g. 6/6 vs 18/24)** — anything < 100% means eviction (memory pressure).
2. **Storage level** — `MEMORY_ONLY` evicts silently; `MEMORY_AND_DISK` spills.
3. **Size in Memory + Disk** — total cost of cache; if huge, ask "do I really reuse this DataFrame multiple times?"
4. **Empty Storage tab after `df.cache()`** — you forgot the action that triggers materialization. Cache is **lazy**.

```python
df.cache()
df.count()    # without this, Storage tab stays empty
```

---

## Tab 4 — Environment (Config Sanity)

3 sections you actually use:

| Section            | Look For                                                          |
|--------------------|-------------------------------------------------------------------|
| Spark Properties   | Did `spark.sql.shuffle.partitions` actually apply?                |
| System Properties  | Java version, OS, user                                            |
| Classpath Entries  | Did the right Spark/Delta/Iceberg jar load?                       |

**Pattern**: when a config "doesn't seem to work" — open Environment first. 9 times out of 10 the config was set after `SparkSession` was created (too late) or there's a typo.

---

## Tab 5 — Executors (Resource Health)

```
Executors Tab:
+---------+----------+-----------+--------+--------+--------+--------+
| ID      | RDD Mem  | Storage   | Disk   | Total  | Failed | GC     |
|         | Used/Max | Mem Used  | Used   | Tasks  | Tasks  | Time   |
+---------+----------+-----------+--------+--------+--------+--------+
| driver  |   0/2GB  |   200MB   |   0    |   -    |   -    |  2 s   |
| 1       | 1.8/4GB  |   240MB   | 500MB  |  100   |   0    | 45 s   |
| 2       | 3.9/4GB  |   240MB   | 2.1GB  |  100   |   3    | 120 s  |  <- trouble
| 3       | 1.5/4GB  |   240MB   | 200MB  |  100   |   0    | 30 s   |
+---------+----------+-----------+--------+--------+--------+--------+
```

3 quick ratios:

```
GC ratio       = GC_time / total_task_time      (> 10% = bad)
Spill ratio    = disk_spill / shuffle_read       (> 0  = memory tight)
Mem pressure   = mem_used / max_mem              (> 90% = OOM risk)
```

---

## Tab 6 — SQL (Catalyst's Visualization)

```
SQL Tab:
+-------------------------------------------------------+
| Query 0: count at app.py:30                           |
|                                                       |
|         HashAggregate (final)        rows: 1          |
|              |                                        |
|         Exchange (single partition) rows: 8           |  <-- shuffle
|              |                                        |
|         HashAggregate (partial)     rows: 8           |
|              |                                        |
|         InMemoryTableScan           rows: 1.6M        |  <-- cache hit
+-------------------------------------------------------+
```

**Why this tab is gold:**
- Shows the **physical plan** with row counts at every operator.
- Every `Exchange` = a shuffle = a stage boundary (Pattern 04, 06).
- `BroadcastHashJoin` vs `SortMergeJoin` immediately tells you join strategy.
- `WholeStageCodegen` boxes show fused operators (Tungsten working).

---

## DAG Visualization (Inside a Job)

```
Job 0: count at app.py:30
+----------+      +----------+      +----------+
| Stage 0  |---->| Stage 1   |---->| Stage 2   |
| Scan +   | shuf| ShuffleR +| shuf| Final agg |
| Project +| ----| Filter +  | ----|           |
| Repart   |     | Cache +   |     |           |
|          |     | PartialAgg|     |           |
+----------+     +----------+      +----------+
  16 tasks         6 tasks            1 task
```

Edges = shuffle boundaries = data movement.
Each box collapses into a stage in the Stages tab.

---

## Event Timeline (Inside a Stage)

```
Executor 1: ##########..########################..............
Executor 2: ############..########################............
Executor 3: ######################################################  <-- always busy
Executor 4: ####....................................................  <-- mostly idle

#  = task running
.  = idle / waiting / GC
```

- **Even bars** = healthy parallelism.
- **One bar very long, others short** = data skew (Pattern 08).
- **Lots of dots** = scheduling delay or GC pauses.

---

## Tab → Question Cheat Sheet

| Question                                          | Open Tab                             |
|---------------------------------------------------|--------------------------------------|
| "Why is my pipeline slow overall?"                | Jobs → spot the long-duration job    |
| "Which transformation is bottlenecking?"          | Stages (drill into slow job)         |
| "Is my cache working?"                            | Storage                              |
| "Did `spark.sql.shuffle.partitions` apply?"       | Environment                          |
| "Is one executor overloaded / OOM?"               | Executors                            |
| "Why did Catalyst pick SortMergeJoin?"            | SQL                                  |
| "Why did `show()` create 3 jobs?"                 | Jobs (then Pattern 03)               |
| "Why is Job 2 only 25 ms?"                        | Stages — most stages are *skipped*   |
| "What's the data skew on this stage?"             | Stages → Task Summary (Min/Max)      |

---

## Common Mistakes (Reading the UI)

| Mistake                                              | Why It Misleads                                                    | Fix                                                              |
|------------------------------------------------------|---------------------------------------------------------------------|------------------------------------------------------------------|
| Looking at "Total Tasks" without "skipped" count     | 100/100 with 80 skipped means only 20 actually ran                 | Always read "succeeded / total (skipped)"                        |
| Comparing Job duration to total app time             | App also includes driver Python time, idle waits                   | Sum stage durations of the job                                   |
| Treating a single shuffle as one stage              | Shuffle creates a *boundary*, not a stage by itself                | Each side of the shuffle is its own stage                        |
| Trusting "Median" duration only                      | Median hides skew                                                  | Always read Max + Median together                                |
| Storage tab is empty after `cache()`                 | Cache is lazy — needs an action                                    | Run `df.count()` after `df.cache()`                              |
| Setting config *after* `getOrCreate()`               | Some configs are static, ignored once session starts               | Set in builder; verify in Environment tab                        |

---

## When To Use Which Tab (Decision Tree)

```
Problem says "slow"
   |
   +--> Open Jobs tab → find long job → click in
            |
            +--> Stages tab inside job
                    |
                    +--> Task spread bad (Max >> Median)?
                    |       +--> Pattern 08 (skew)
                    |
                    +--> Big shuffle bytes?
                    |       +--> SQL tab to confirm Exchange operator
                    |
                    +--> High GC / spill?
                            +--> Executors tab for memory health
```

---

## Key Takeaway

> Spark UI ek funnel hai: **Jobs → Stages → Tasks**.
> Jobs tab batata hai *which* slow hai. Stages tab batata hai *why*. Executors / Storage / Environment tabs context dete hain. SQL tab dikhata hai Catalyst ne actually kaisa execute kiya.
> Master the 6-tab map first — baaki har pattern (02–08) inhi tabs ka deeper view hai.
