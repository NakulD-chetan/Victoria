# Indexes and Optimization — Coding Templates

---

## Create index

```sql
CREATE INDEX idx_emp_dept ON employees (dept_id);

CREATE UNIQUE INDEX idx_email ON users (email);

CREATE INDEX idx_composite ON orders (user_id, order_date);
```

---

## Drop index

```sql
DROP INDEX idx_emp_dept;               -- Postgres / MySQL
DROP INDEX idx_emp_dept ON employees;  -- SQL Server
```

---

## EXPLAIN (read query plan)

```sql
-- Postgres / MySQL
EXPLAIN SELECT * FROM orders WHERE user_id = 42;

-- Postgres (more detail)
EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 42;

-- SQL Server
SET STATISTICS IO ON;
SELECT * FROM orders WHERE user_id = 42;
```

---

## Avoid function on indexed column

```sql
-- BAD: index on created_at can't help
SELECT * FROM orders WHERE YEAR(created_at) = 2024;

-- GOOD: rewrite as range
SELECT * FROM orders
WHERE created_at >= '2024-01-01' AND created_at < '2025-01-01';
```

---

## Covering index example

```sql
-- If query only needs user_id and order_date:
CREATE INDEX idx_cover ON orders (user_id, order_date);
-- index-only scan possible — no table lookup
```

---

## Views

```sql
CREATE VIEW active_users AS
SELECT id, name FROM users WHERE active = TRUE;

SELECT * FROM active_users;  -- uses underlying query
```

---

## Materialized view (Postgres)

```sql
CREATE MATERIALIZED VIEW mv_daily_revenue AS
SELECT DATE(order_ts) AS d, SUM(amount) AS rev
FROM orders GROUP BY 1;

REFRESH MATERIALIZED VIEW mv_daily_revenue;
```

---

*Next: [[04_Interview-Thinking]]*
