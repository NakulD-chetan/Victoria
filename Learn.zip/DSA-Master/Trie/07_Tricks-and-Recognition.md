# Trie — Tricks and Recognition

> **Pattern signals and solution mappings. See the signal → apply the trick.**

---

## Recognition Table

| Problem Signal | Solution | Key Trick |
|----------------|----------|-----------|
| "Prefix search" | Trie | O(L) path follow |
| "Autocomplete" | Trie + DFS/BFS | Enumerate from prefix node |
| "Wildcard" (e.g., "c.t") | Trie + DFS | '.' → try all children |
| "Word break" | Trie + DP | Check prefix at each index |
| "Max XOR" in array | Bitwise Trie | Greedy opposite bit |
| "Longest common prefix" | Trie | Path until branch |
| "Count words with prefix" | Trie + count field | Increment on insert |
| "Replace with shortest prefix" | Trie | First is_end on path |

---

## Trick 1: "Prefix search" → Trie

**Signal:** "Find all words starting with X", "startsWith", "prefix matching"

**Approach:** Build trie, insert all words. For prefix P, traverse to node N in O(L). DFS from N to collect all words (paths where is_end).

```
Words: ["cat","car","card"]
Prefix "ca" → traverse to 'a' node → DFS → ["cat","car","card"]
```

---

## Trick 2: "Wildcard" → Trie + DFS

**Signal:** "Match pattern with '.' as any char", "c.t" matches "cat", "cot"

**Approach:** Standard trie. In search, when char is '.', recursively try ALL children. When char is normal, follow that child only.

```python
if ch == '.':
    for child in node.children.values():
        if dfs(child, i+1): return True
    return False
```

---

## Trick 3: "Word break" → Trie + DP

**Signal:** "Can string be segmented into dictionary words?"

**Approach:** Build trie from dictionary. dp[i] = can form s[0:i]. For each i where dp[i]=true, traverse trie from s[i], set dp[j+1]=true when we hit is_end at position j.

```
s = "leetcode", dict = ["leet","code"]
dp[0]=T → check "leetcode" → "leet" is_end → dp[4]=T
dp[4]=T → check "code" → "code" is_end → dp[8]=T
```

---

## Trick 4: "Max XOR" → Bitwise Trie

**Signal:** "Max XOR of two numbers", "Max XOR subarray"

**Approach:** Bitwise trie. Insert numbers as 31-bit (or 32-bit) paths. For query x, greedily pick opposite bit at each level to maximize XOR.

```
Query 5 (101): Prefer 0 at MSB → 010 path → XOR max
Alphabet = {0, 1}, same trie structure
```

---

## Trick 5: "Longest common prefix" → Trie Path Until Branch

**Signal:** "Longest common prefix of array of strings"

**Approach:** Insert all strings. Walk from root. Stop when node has ≠1 child or we hit is_end.

```
["flower","flow","flight"]
  f → l → o (branch: o→w, o→i) → stop
  LCP = "fl"
```

---

## Trick 6: "Replace with shortest prefix" → First is_end

**Signal:** "Replace word with shortest prefix from dictionary"

**Approach:** For each word, traverse trie. Return first prefix where is_end. O(L) per word.

---

## Trick 7: "Count prefix" → Count Field

**Signal:** "How many words have prefix P?"

**Approach:** Add `count` to each node. On insert, increment count for every node on path. Query: traverse to prefix node, return count.

---

## Trick 8: "Stream of characters" → Trie + Cursor

**Signal:** "Check if current stream suffix is in dictionary"

**Approach:** Maintain list of "active" trie nodes (one per possible start). For each new char, advance each node; add root. Check is_end.

---

## Pattern Decision Flowchart

```
                    String/prefix problem?
                            |
                    +------+------+
                    | YES         | NO (numbers?)
                    v             v
            Prefix/wildcard?    Max XOR?
                    |             |
            +------+------+      YES → Bitwise Trie
            | YES   | NO  |
            v       v
        Trie    Exact only?
            |       |
            |   +---+---+
            |   |YES |NO |
            |   v   v
            |  HashMap  Depends
            v
    Wildcard? → +DFS
    Word break? → +DP
    Autocomplete? → +DFS from node
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PREFIX → Trie, O(L)
WILDCARD → Trie + DFS, '.' tries all
WORD BREAK → Trie + DP, check prefix at i
MAX XOR → Bitwise trie, greedy opposite bit
LCP → Trie, path until branch
COUNT PREFIX → count field, increment on insert
SHORTEST PREFIX → first is_end on path
```

---

## 30-SECOND REVISION BOX

```
PREFIX → trie
WILDCARD → trie + DFS ('.' = all children)
WORD BREAK → trie + dp[i]
MAX XOR → bitwise trie
LCP → path until branch
COUNT → count per node
```
