# Surrogate Key — Practice

> "Surrogates do not replace reality—they stabilize it for analytics."

---

## Quick Recall

**Q: What is a surrogate key?**  
A: Warehouse-generated integer (or UUID) used as PK/FK with no business meaning outside the DW.

**Q: Why use surrogates instead of natural keys in joins?**  
A: Performance, stability across source changes, support for SCD Type 2 rows, and integration after mergers.

**Q: Natural key example in retail?**  
A: `sku`, `store_number`, `customer_loyalty_id`—still stored as attributes in dimensions.

**Q: Do facts ever use surrogate keys only?**  
A: Facts reference surrogate dimension keys; facts may also carry degenerate natural IDs for traceability.

**Q: UUID vs integer surrogate?**  
A: Integer joins are usually faster and smaller; UUIDs help distributed ingestion but need careful clustering strategies.

---

## Interview Questions

**1. Define surrogate vs natural key crisply.**  
Say: Natural keys come from operational systems; surrogate keys are internal identifiers assigned by the warehouse to uniquely identify a dimension row version.

**2. How do surrogates enable SCD2?**  
Say: Same `sku` maps to multiple `product_key` values over time; facts carry the key valid for the transaction date, preserving historical reporting.

**3. What if two sources disagree on SKU attributes?**  
Say: MDM chooses golden record; surrogate attaches to golden row; source-specific codes live in cross-reference tables.

**4. Should `dim_date` use surrogate or YYYYMMDD?**  
Say: Either is acceptable if stable; YYYYMMDD is human-readable; surrogate is consistent with other dimensions.

**5. Junk dimension surrogate usage?**  
Say: Each distinct combination gets a `checkout_junk_key`; facts hold that single FK instead of many low-cardinality columns.

**6. Backfill risk when regenerating surrogates**  
Say: Never renumber published keys; allocate from sequences; treat key generation as immutable history.

**7. Customer privacy and surrogate**  
Say: Surrogate is not PII; still protect natural keys; hashing may be needed in export marts.

---

## Scenario-Based Exercises

**Scenario 1 — Type 2 product change**  
SKU `ABC123` changes category from "Appliances" to "Electronics" mid-quarter.  
**Solution:** Close old `product_key` row, insert new row with new surrogate, map facts using `effective_date` logic so pre-change sales stay under old category.

**Scenario 2 — ETL key assignment**

```sql
INSERT INTO dw.dim_product (
    sku, product_name, brand_name, effective_start_date, current_flag
)
SELECT
    s.sku,
    s.product_name,
    s.brand_name,
    CURRENT_DATE,
    'Y'
FROM stg.product_delta s
WHERE NOT EXISTS (
    SELECT 1 FROM dw.dim_product p
    WHERE p.sku = s.sku AND p.current_flag = 'Y'
);
```

**Scenario 3 — Fact load resolving surrogate**  
Map staging SKU to current `product_key` for yesterday’s sales.  
**Solution:** Join on `sku` where `current_flag = 'Y'` for operational loads; for late-arriving facts, join on `transaction_date` between `effective_start` and `effective_end`.

**Scenario 4 — Merge of two retail banners**  
Duplicate SKUs across banners.  
**Solution:** Create `enterprise_sku` in a xref table; assign new surrogate in conformed `dim_product`; load facts with unified keys.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Exposing surrogate in customer emails | Looks like meaningless bug | Keep internal; use natural tokens externally |
| Using SKU as PK in Type 2 dim | Breaks uniqueness | Surrogate PK, SKU + dates as alternate key |
| Regenerating keys on full reload | Breaks BI bookmarks | Immutable assignment |
| Surrogate without natural key stored | Ops cannot reconcile | Always retain business keys as columns |

---

## One-Liner Answers

- Surrogate keys are meaningless integers that stabilize warehouse identities.
- They enable historical accuracy with SCD2 and faster joins than wide naturals.
- Natural keys remain visible for reconciliation and operational drill-through.
- Never recycle surrogate values once published to downstream consumers.
- Late-arriving facts resolve to the correct dimension version using dates.
- Choose integer sequences unless distributed UUID requirements dominate.
