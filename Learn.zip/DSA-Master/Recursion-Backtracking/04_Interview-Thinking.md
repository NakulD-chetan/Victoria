# Recursion-Backtracking — Interview Thinking

> **Permanent Recall:** "Generate all..." → backtracking. Draw the decision tree on whiteboard first. Explain pruning before coding. Communicate time complexity as branching^depth. FAANG wants to see structured thinking, not just code.

---

## How to Identify Backtracking Problems

### Strong Signals

| Phrase | Implication |
|--------|-------------|
| "Generate all..." | Backtracking |
| "Find all..." | Backtracking |
| "List all possible..." | Backtracking |
| "All combinations/permutations/subsets" | Holy trinity |
| "Partition into..." | Backtracking |
| "Place n items such that..." | Placement (N-Queens style) |
| "Fill the grid..." | Constraint satisfaction (Sudoku) |
| "Count the number of ways" | Sometimes DP; if enumerate → backtracking |
| "Valid placement" | Constraint-based backtracking |

### Weak Signals (Consider Backtracking)

- "Can you arrange..."
- "Is there a way to..."
- "Print all valid configurations"
- "Return all solutions"
- Search space is exponential/factorial

### Anti-Signals (Probably NOT Backtracking)

- "Find the minimum/maximum" (often DP/greedy)
- "Optimal" with overlapping subproblems (DP)
- "One valid solution" with greedy structure
- n is very large (>25) — may need DP or different approach

---

## "Generate All..." → Backtracking

**Rule of thumb:** If the problem asks you to enumerate/collect all valid configurations, backtracking is the default.

```
"Generate all subsets"           → Subsets template
"Generate all permutations"      → Permutations template
"Generate all combinations of k" → Combinations template
"Find all combinations summing to X" → Combination sum
"All valid IP addresses"         → Partition/placement
"All valid parentheses"          → Structured generation
```

---

## How to Draw the Decision Tree on Whiteboard

### Step 1: Identify the Root

- Root = empty/initial state
- Example: `{}` for subsets, `[]` for permutations

### Step 2: Identify One Decision

- "At each step, what do I choose?"
- Subsets: include or exclude?
- Permutations: which element goes here?
- N-Queens: which column for this row?

### Step 3: Draw 2–3 Levels

```
Subsets of {1,2}:
        {}
      /     \
    {1}      {}
   /   \    /   \
{1,2} {1} {2}   {}
```

**Don't need the full tree.** Two levels show structure.

### Step 4: Mark Pruning Points

```
        {}
      /     \
    {1}      {}
   /   \    /   \
  ✗   {1} {2}   {}   ← ✗ = pruned (e.g., sum > target)
```

### Step 5: Annotate Base Case

- When do we add to result? At leaves? At every node (subsets)?
- When do we stop recursing?

---

## Pruning Explanation Strategy

**Interviewer wants to hear:** "I'll prune branches that can't lead to valid solutions."

### How to Explain Pruning

1. **State the constraint:** "We need sum ≤ target"
2. **Derive the check:** "If current sum already exceeds target, no need to add more"
3. **Place it:** "I'll check this before recursing, not at the leaf"
4. **Impact:** "This cuts entire subtrees — saves exponential work"

### Example Script (Combination Sum)

> "At each step I can include or exclude an element. If I include and the running sum exceeds the target, I prune — no point adding more. I also sort first so when I see an element larger than the remaining target, I can break the loop since all subsequent elements are bigger. That's feasibility pruning and bounds pruning."

---

## Time Complexity Communication

### The Formula

**"Time is O(branching_factor ^ depth) in the worst case, but pruning reduces it."**

### How to Say It

| Problem | What to Say |
|---------|-------------|
| Subsets | "2^n — at each of n elements we have 2 choices" |
| Permutations | "n! — n choices, then n-1, then n-2..." |
| Combinations | "C(n,k) in best case with pruning; up to 2^n without" |
| N-Queens | "Roughly O(n!) with good pruning — we prune attacking positions" |
| Word Search | "4^L × m×n where L is word length — 4 directions per step" |

### Space Complexity

- **Recursion stack:** O(depth)
- **Path/state:** O(depth) for current solution
- **Output:** Often not counted (required by problem)

**Say:** "Space is O(n) for the recursion stack and the current path we're building."

---

## Interview Flow Checklist

1. **Clarify:** "So we need all valid X, not just one?"
2. **Identify type:** "This is a subsets/permutations/combinations problem"
3. **Draw tree:** "At each step we choose... here's the first two levels"
4. **Pruning:** "We can prune when..."
5. **Complexity:** "Time is O(...), space is O(...)"
6. **Code:** Use template, fill in problem-specific logic
7. **Test:** Walk through small example (e.g., n=2)

---

## Red Flags to Avoid

- Jumping to code without explaining the tree
- Forgetting to mention pruning
- Not handling duplicates (when input has them)
- Modifying shared state without restoring
- Wrong complexity (saying O(n) for subsets)

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY:        "Generate all" / "Find all" → backtracking
DRAW TREE:       Root → 2-3 levels → mark pruning
PRUNING:         "Cut branches that can't be valid"
COMPLEXITY:      branching^depth, pruning reduces
SUBSETS:         2^n
PERMUTE:         n!
SAY:             "I'll model as decision tree, prune invalid branches"
AVOID:           Code first, no tree, no pruning explanation
```
