# Grammar — All 12 Tenses

> *"Tenses English ki reedh ki haddi hain — agar tenses clear hain toh 70% grammar clear hai"*

English mein kul **12 tenses** hain. Yeh 3 time periods (Past, Present, Future) aur 4 aspects (Simple, Continuous, Perfect, Perfect Continuous) ka combination hai. Ek table mein sab samajh lo.

---

## 1. Master Table — All 12 Tenses

### Present Tenses

| Tense | Structure | Example | Kab Use Karo |
|-------|-----------|---------|-------------|
| **Present Simple** | Subject + V1 (s/es) | I **play** cricket. / He **plays** cricket. | Daily routine, facts, habits |
| **Present Continuous** | Subject + am/is/are + V-ing | I **am playing** cricket. | Abhi ho raha hai (right now) |
| **Present Perfect** | Subject + have/has + V3 | I **have played** cricket. | Past mein hua, abhi tak relevant |
| **Present Perfect Continuous** | Subject + have/has been + V-ing | I **have been playing** cricket for 2 hours. | Past mein start hua, abhi bhi chal raha |

### Past Tenses

| Tense | Structure | Example | Kab Use Karo |
|-------|-----------|---------|-------------|
| **Past Simple** | Subject + V2 | I **played** cricket yesterday. | Past mein hua, khatam ho gaya |
| **Past Continuous** | Subject + was/were + V-ing | I **was playing** cricket. | Past mein kuch chal raha tha |
| **Past Perfect** | Subject + had + V3 | I **had played** cricket before it rained. | Past mein ek kaam doosre se pehle hua |
| **Past Perfect Continuous** | Subject + had been + V-ing | I **had been playing** for 2 hours when it rained. | Past mein ek kaam kaafi der se chal raha tha |

### Future Tenses

| Tense | Structure | Example | Kab Use Karo |
|-------|-----------|---------|-------------|
| **Future Simple** | Subject + will + V1 | I **will play** cricket tomorrow. | Future plan / promise / prediction |
| **Future Continuous** | Subject + will be + V-ing | I **will be playing** cricket at 5 PM. | Future mein ek specific time pe ho raha hoga |
| **Future Perfect** | Subject + will have + V3 | I **will have played** 10 matches by December. | Future mein ek time tak kaam complete hoga |
| **Future Perfect Continuous** | Subject + will have been + V-ing | I **will have been playing** for 3 hours by 6 PM. | Future mein kaafi der se chal raha hoga |

---

## 2. Yaad Karne Ka Trick — The Grid

```
                Simple      Continuous       Perfect         Perfect Continuous
              ──────────   ────────────   ──────────────   ──────────────────────
Present  →    V1 (s/es)   am/is/are+Ving  have/has+V3    have/has been+Ving
Past     →    V2          was/were+Ving    had+V3         had been+Ving
Future   →    will+V1     will be+Ving     will have+V3   will have been+Ving
```

[TIP] **Simple = fact/habit, Continuous = chal raha hai, Perfect = complete ho gaya, Perfect Continuous = kaafi der se chal raha.**

---

## 3. V1, V2, V3 Kya Hai?

| Form | Name | Example |
|------|------|---------|
| **V1** | Base form | go, eat, play, write, speak |
| **V2** | Past simple | went, ate, played, wrote, spoke |
| **V3** | Past participle | gone, eaten, played, written, spoken |
| **V-ing** | Present participle | going, eating, playing, writing, speaking |

### 20 Important Irregular Verbs (V1 → V2 → V3)

| V1 | V2 | V3 |
|----|----|----|
| go | went | gone |
| eat | ate | eaten |
| write | wrote | written |
| speak | spoke | spoken |
| take | took | taken |
| give | gave | given |
| see | saw | seen |
| come | came | come |
| do | did | done |
| make | made | made |
| know | knew | known |
| think | thought | thought |
| buy | bought | bought |
| bring | brought | brought |
| begin | began | begun |
| break | broke | broken |
| choose | chose | chosen |
| drive | drove | driven |
| fly | flew | flown |
| run | ran | run |

---

## 4. Har Tense Ka Real-Life Use

### Present Simple — Daily life describe karo
- I **wake up** at 7 AM.
- She **works** at Google.
- Water **boils** at 100°C. *(fact)*
- I **don't** like coffee.

### Present Continuous — Abhi kya ho raha hai
- I **am reading** this note right now.
- He **is not working** today.
- They **are playing** outside.

### Present Perfect — Past action, present relevance
- I **have finished** my homework. *(abhi finish hua)*
- She **has visited** Paris twice. *(experience)*
- We **have known** each other for 5 years.

### Past Simple — Kal / pehle kya hua
- I **went** to the market yesterday.
- He **didn't come** to office.
- We **watched** a movie last night.

### Past Continuous — Past mein kuch chal raha tha
- I **was cooking** when he called.
- They **were sleeping** at 10 PM.

### Future Simple — Kya hoga / plan
- I **will call** you tomorrow.
- She **will not come** to the party.
- It **will rain** tonight.

---

## 5. Common Mistakes with Tenses

| # | Galat (Wrong) | Sahi (Right) | Kyun |
|---|--------------|-------------|------|
| 1 | I **am go** to office. | I **go** to office. / I **am going** to office. | am ke saath V-ing chahiye ya simple mein sirf V1 |
| 2 | He **don't** like tea. | He **doesn't** like tea. | He/She/It ke saath does/doesn't lagta hai |
| 3 | I **have went** to Delhi. | I **have gone** to Delhi. | have ke saath V3 aata hai (gone, not went) |
| 4 | I **am knowing** the answer. | I **know** the answer. | know, like, love, want = stative verbs — continuous mein nahi aate |
| 5 | She **didn't went**. | She **didn't go**. | did/didn't ke baad V1 aata hai, V2 nahi |
| 6 | I **will going**. | I **will go**. / I **am going**. | will ke baad V1 aata hai, V-ing nahi |
| 7 | He **has came** home. | He **has come** home. | has ke saath V3 (come), V2 (came) nahi |

---

## 6. Stative Verbs — Jo Continuous Mein Nahi Aate

[COMMON MISTAKE] Yeh verbs **"-ing" form mein normally use nahi** hote:

| Category | Verbs |
|----------|-------|
| **Mental** | know, believe, understand, remember, forget, think (opinion), suppose |
| **Emotional** | like, love, hate, want, need, prefer, wish |
| **Possession** | have (ownership), own, belong, possess |
| **Senses** | see, hear, smell, taste (involuntary) |
| **Other** | seem, appear, mean, cost, contain |

**Wrong:** I am knowing the answer. / She is having a car. / I am loving it.
**Right:** I know the answer. / She has a car. / I love it.

[TIP] Exception: "I'm loving it" (McDonald's slogan) grammatically wrong hai, lekin marketing mein chalta hai!

---

## 7. Quick Practice Sentences — Fill in the Blanks

Apne mann mein solve karo:

1. I ___ (go) to office every day. → **go** (Present Simple)
2. She ___ (cook) right now. → **is cooking** (Present Continuous)
3. They ___ (finish) the project yesterday. → **finished** (Past Simple)
4. We ___ (live) here since 2020. → **have been living** (Present Perfect Continuous)
5. He ___ (not come) tomorrow. → **will not come** (Future Simple)
6. I ___ (eat) when you called. → **was eating** (Past Continuous)
7. She ___ (already/read) this book. → **has already read** (Present Perfect)
8. By 2027, I ___ (work) here for 5 years. → **will have been working** (Future Perfect Continuous)

---

*Agle chapter mein: Grammar Essentials — Articles, Prepositions, Modals, aur baaki important grammar rules*
