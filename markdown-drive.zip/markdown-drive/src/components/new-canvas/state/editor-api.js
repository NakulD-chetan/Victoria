import { resolveSceneBindings } from '../engine/binding-engine.js';
import { repairSceneOverlaps, validateScene } from '../engine/scene-validator.js';
import { normalizeElementsV2 } from './types.js';

export function createCanvasEditorApi(store) {
  let activeTransaction = null;

  function currentState() {
    const state = store.getState();
    return {
      state,
      scene: state.scenes[state.activeId] || null,
    };
  }

  function inspectScene() {
    const { scene } = currentState();
    return scene
      ? {
          id: scene.id,
          viewport: scene.viewport,
          elements: scene.elements.filter((element) => !element.isDeleted),
        }
      : null;
  }

  function beginTransaction(label = 'Canvas update') {
    const { scene } = currentState();
    if (!scene) throw new Error('No active canvas scene.');
    if (activeTransaction) throw new Error('A canvas transaction is already active.');
    activeTransaction = {
      label,
      before: scene.elements,
      working: scene.elements,
      startedAt: Date.now(),
    };
    return activeTransaction;
  }

  function mutate(updater) {
    if (!activeTransaction) beginTransaction();
    activeTransaction.working = updater(activeTransaction.working);
    return activeTransaction.working;
  }

  function createElements(elements) {
    return mutate((current) => current.concat(normalizeElementsV2(elements)));
  }

  function updateElements(updates) {
    const byId = new Map((updates || []).map((update) => [update.id, update]));
    return mutate((current) => current.map((element) => (
      byId.has(element.id) ? { ...element, ...byId.get(element.id) } : element
    )));
  }

  function deleteElements(ids) {
    const selected = new Set(ids || []);
    return mutate((current) => current.map((element) => (
      selected.has(element.id) ? { ...element, isDeleted: true } : element
    )));
  }

  function solveLayout(options) {
    return mutate((current) => repairSceneOverlaps(current, options));
  }

  function routeConnectors() {
    return mutate((current) => resolveSceneBindings(current));
  }

  function validate() {
    const candidate = activeTransaction?.working || currentState().scene?.elements || [];
    return validateScene(resolveSceneBindings(normalizeElementsV2(candidate)));
  }

  function commitTransaction({ allowInvalid = false } = {}) {
    if (!activeTransaction) return { committed: false, reason: 'no-transaction' };
    const candidate = resolveSceneBindings(normalizeElementsV2(activeTransaction.working));
    const validation = validateScene(candidate);
    if (!validation.valid && !allowInvalid) {
      const failed = activeTransaction;
      activeTransaction = null;
      return {
        committed: false,
        reason: 'validation-failed',
        validation,
        label: failed.label,
      };
    }
    const transaction = activeTransaction;
    activeTransaction = null;
    store.getState().commitGesture(transaction.before, candidate);
    return {
      committed: true,
      validation,
      label: transaction.label,
      durationMs: Date.now() - transaction.startedAt,
    };
  }

  function rollbackTransaction() {
    if (!activeTransaction) return false;
    activeTransaction = null;
    return true;
  }

  return {
    inspectScene,
    beginTransaction,
    createElements,
    updateElements,
    deleteElements,
    solveLayout,
    routeConnectors,
    validateScene: validate,
    commitTransaction,
    rollbackTransaction,
  };
}
