# Quick Revision — Decision Trees

> **Permanent Recall:** Decision trees = instant answers when interviewer asks "Which X?" All in one place. Compact flowcharts/tables. Use to justify choices in 5 seconds.

---

## 1. Which Database?

| Need | Choose | Why |
|------|--------|-----|
| ACID, joins, transactions | **PostgreSQL, MySQL** | Relational, strong consistency |
| Flexible schema, docs | **MongoDB** | Document model |
| High write, horizontal scale | **Cassandra, DynamoDB** | Wide-column, partition key |
| Sub-ms reads, sessions | **Redis** | In-memory |
| Graph, relationships | **Neo4j** | Native graph |
| Full-text search | **Elasticsearch** | Inverted index |

```
Flow: ACID/joins? → SQL
      Scale-out + flexible? → NoSQL (doc/column)
      Caching/sessions? → Redis
      Search? → Elasticsearch
```

---

## 2. Which Cache Strategy?

| Read/Write Pattern | Strategy | Trade-off |
|--------------------|----------|-----------|
| Read-heavy, stale OK | **Cache-aside** | App owns load; cache miss = DB hit |
| Write-heavy, need consistency | **Write-through** | Write to cache + DB sync |
| Write burst, eventual OK | **Write-behind** | Async to DB; risk of loss |
| Read-through (cache as proxy) | **Read-through** | Cache loads from DB on miss |

```
Flow: Read-heavy? → Cache-aside (default)
      Consistency critical? → Write-through
      Write burst? → Write-behind (accept risk)
```

---

## 3. Which Consistency Model?

| Use Case | Model | Example |
|----------|-------|---------|
| Money, inventory | **Strong / Linearizable** | Bank balance |
| Social feed, likes | **Eventual** | Timeline, counters |
| Chat, comments | **Causal** | Message order |
| Profile edit | **Read-your-writes** | User sees own changes |
| Feed pagination | **Monotonic reads** | Never regress |

```
Flow: Money/financial? → Strong
      Social/analytics? → Eventual
      Chat/ordering? → Causal
```

---

## 4. Which API Style?

| Use Case | Choose | Why |
|----------|--------|-----|
| Public CRUD API | **REST** | Standard, cacheable, simple |
| Mobile, flexible queries | **GraphQL** | Over/under-fetch solved |
| Internal microservices | **gRPC** | Binary, HTTP/2, streaming |
| Real-time push | **WebSocket** | Bidirectional |

```
Flow: Public API? → REST
      Complex queries? → GraphQL
      Internal, high perf? → gRPC
      Real-time? → WebSocket
```

---

## 5. Which Message Queue?

| Need | Choose | Why |
|------|--------|-----|
| Replay, event sourcing | **Kafka** | Durable log, partitions |
| Complex routing | **RabbitMQ** | Exchanges, queues |
| Managed, simple | **SQS** | Serverless, at-least-once |
| Pub/sub, fan-out | **SNS + SQS** | Broadcast + queue |
| Ordering per key | **Kafka partitions** | Same key → same partition |

```
Flow: Replay/ordering? → Kafka
      Routing flexibility? → RabbitMQ
      Managed? → SQS/SNS
```

---

## 6. Monolith vs Microservices?

| Factor | Monolith | Microservices |
|--------|----------|---------------|
| Team size | Small | Multiple teams |
| Deploy frequency | Low | High |
| Scale | Uniform | Per-service |
| Complexity budget | Low | High (ops) |

```
Flow: Single team, simple? → Monolith
      Multiple teams, independent deploy? → Microservices
      Start monolith; extract when needed
```

---

## 7. When to Shard?

| Trigger | Action |
|---------|--------|
| Storage > single DB limit | Shard |
| Write QPS > single DB capacity | Shard |
| Read QPS high, writes low | Read replicas first |
| Hot data | Cache first |

```
Flow: Read-heavy? → Replicas + cache (try first)
      Write/storage limit? → Shard
      Shard key: user_id, partition_key for even distribution
```

---

## 8. Which Load Balancer Algorithm?

| Workload | Algorithm |
|----------|------------|
| Stateless, equal servers | **Round robin** |
| Varying capacity | **Weighted round robin** |
| Long-lived connections | **Least connections** |
| Session affinity | **IP hash** or **sticky cookie** |
| Cache, minimize reshuffle | **Consistent hashing** |

```
Flow: Stateless? → Round robin
      Session? → Sticky/cookie
      Cache? → Consistent hashing
```

---

## 9. Push vs Pull (Feed)?

| Factor | Push (write-time) | Pull (read-time) |
|--------|-------------------|------------------|
| Read:write | 100:1+ | Lower |
| Follower count | <1M | Celebrities (10M+) |
| Latency | Low (pre-computed) | Higher (merge at read) |
| Write cost | High (fan-out) | Low |

```
Flow: Normal user? → Push (pre-compute timeline)
      Celebrity? → Pull (merge on read)
      Hybrid: Push for most, pull for celebs
```

---

## 10. Fail Open vs Fail Closed?

| Context | Choice |
|---------|--------|
| Availability-critical (public API) | **Fail open** — allow when Redis down |
| Security-critical (payment) | **Fail closed** — reject when rate limiter down |

---

## Quick Reference Table

| Question | Default Answer |
|----------|----------------|
| Database for CRUD? | PostgreSQL |
| Cache strategy? | Cache-aside |
| Consistency for social? | Eventual |
| API for public? | REST |
| Queue for events? | Kafka |
| Scale DB? | Replicas first, then shard |
| LB for stateless? | Round robin |
| Feed for celebs? | Pull |

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
