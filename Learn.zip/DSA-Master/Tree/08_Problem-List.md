# Tree — Problem List

> Organized by topic and difficulty. Solve in this order — each builds on the previous.

---

## Phase 1: Binary Tree Basics (Do These First)

These come directly from the lecture problems.

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 1 | Height / Maximum Depth of Binary Tree | Bottom-up recursion | Easy |
| 2 | Count total nodes in a binary tree | Bottom-up recursion | Easy |
| 3 | Count leaf nodes | Base case: both children null | Easy |
| 4 | Count non-leaf nodes | Inverse of leaf count | Easy |
| 5 | Mirror / Invert Binary Tree | Swap left and right at every node | Easy |
| 6 | Check if two trees are identical | Compare node + recurse | Easy |
| 7 | Print nodes at distance K from root | Top-down, pass K-1 down | Easy |
| 8 | Level Order Traversal (BFS) | Queue-based traversal | Easy |
| 9 | Left view / Right view of tree | BFS, first/last of each level | Easy |
| 10 | Diameter of Binary Tree | Bottom-up, track max at each node | Medium |

---

## Phase 2: Tree Traversals and Construction

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 11 | Pre-order Traversal (recursive + iterative) | Stack-based iterative | Easy |
| 12 | In-order Traversal (recursive + iterative) | Stack-based iterative | Easy |
| 13 | Post-order Traversal (recursive + iterative) | Two-stack trick | Medium |
| 14 | Construct Binary Tree from Preorder + Inorder | Root = preorder[0], split inorder | Medium |
| 15 | Construct Binary Tree from Postorder + Inorder | Root = postorder[-1], split inorder | Medium |
| 16 | Serialize and Deserialize Binary Tree | Pre-order with null markers | Medium |
| 17 | Zigzag Level Order Traversal | BFS with direction flag | Medium |

---

## Phase 3: Binary Search Tree (BST)

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 18 | Search in BST | Go left or right based on comparison | Easy |
| 19 | Insert in BST | Find correct position, create node | Easy |
| 20 | Delete in BST | 3 cases: 0, 1, 2 children | Medium |
| 21 | Validate BST (Is Valid BST?) | Pass min/max bounds top-down | Medium |
| 22 | Inorder Successor in BST | Leftmost node in right subtree | Medium |
| 23 | Inorder Predecessor in BST | Rightmost node in left subtree | Medium |
| 24 | Kth Smallest Element in BST | In-order traversal, stop at K | Medium |
| 25 | Kth Largest Element in BST | Reverse in-order, stop at K | Medium |
| 26 | Lowest Common Ancestor of BST | Use BST property to navigate | Easy |
| 27 | Convert Sorted Array to Balanced BST | Binary search style: mid = root | Medium |
| 28 | Two Sum in BST | In-order + set, or two-pointer on sorted inorder | Medium |
| 29 | Floor and Ceil in BST | Navigate using BST property | Medium |

---

## Phase 4: Tree Properties and Advanced Problems

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 30 | Check if Binary Tree is Balanced | Return (is_balanced, height) tuple | Medium |
| 31 | Path Sum (root-to-leaf sum = target) | Top-down, subtract node value | Medium |
| 32 | All Root-to-Leaf Paths | DFS with backtracking | Medium |
| 33 | Maximum Path Sum (any path) | Bottom-up, track global max | Hard |
| 34 | Lowest Common Ancestor of Binary Tree | Post-order, check left+right | Medium |
| 35 | Binary Tree Maximum Width | BFS with index tracking | Medium |
| 36 | Vertical Order Traversal | BFS with (row, col) tracking | Hard |
| 37 | Bottom View of Binary Tree | BFS with horizontal distance | Medium |
| 38 | Top View of Binary Tree | BFS with horizontal distance | Medium |
| 39 | Count nodes in Complete Binary Tree | Binary search on height — O(log²n) | Medium |
| 40 | Flatten Binary Tree to Linked List | Pre-order, right-pointer connection | Medium |

---

## Phase 5: AVL Tree Problems

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 41 | Calculate Balance Factor of each node | Height of left - height of right | Easy |
| 42 | Check if tree is AVL balanced | BF ∈ {-1, 0, 1} for every node | Medium |
| 43 | Insert into AVL Tree (with rotations) | LL, RR, LR, RL cases | Hard |
| 44 | Delete from AVL Tree | Delete + rebalance bottom-up | Hard |
| 45 | Identify rotation type needed | Given unbalanced tree, find case | Medium |

---

## Phase 6: Heap Problems

| # | Problem | Concept | Difficulty |
|---|---------|---------|-----------|
| 46 | Implement Max Heap (insert + extract) | Heapify up/down | Medium |
| 47 | Build Heap from array — O(n) | Heapify from last non-leaf down | Medium |
| 48 | Heap Sort | Build max-heap, extract repeatedly | Medium |
| 49 | Kth Largest Element in Array | Min-heap of size K | Medium |
| 50 | Kth Smallest Element in Array | Max-heap of size K | Medium |
| 51 | Merge K Sorted Lists | Min-heap of size K | Hard |
| 52 | Find Median from Data Stream | Two heaps (max + min) | Hard |
| 53 | Top K Frequent Elements | Heap + hash map | Medium |
| 54 | Task Scheduler | Max-heap, greedy | Hard |
| 55 | Sliding Window Maximum | Deque / monotonic queue | Hard |

---

## LeetCode Problem Numbers (Quick Reference)

| Problem | LeetCode # |
|---------|-----------|
| Maximum Depth of Binary Tree | 104 |
| Invert Binary Tree | 226 |
| Diameter of Binary Tree | 543 |
| Level Order Traversal | 102 |
| Right Side View | 199 |
| Construct Tree from Pre+In | 105 |
| Construct Tree from Post+In | 106 |
| Serialize and Deserialize | 297 |
| Validate BST | 98 |
| Kth Smallest in BST | 230 |
| LCA of Binary Tree | 236 |
| LCA of BST | 235 |
| Path Sum | 112 |
| Maximum Path Sum | 124 |
| Balanced Binary Tree | 110 |
| Count Nodes (Complete BT) | 222 |
| Flatten to Linked List | 114 |
| Kth Largest Element | 215 |
| Find Median from Stream | 295 |
| Merge K Sorted Lists | 23 |

---

## Suggested Practice Order (Week Plan)

**Week 1:** Problems 1–10 (binary tree basics, get comfortable with recursion)

**Week 2:** Problems 11–17 (traversals, construction — really understand in/pre/post)

**Week 3:** Problems 18–29 (BST — master the ordering property)

**Week 4:** Problems 30–40 (harder binary tree problems)

**Week 5:** Problems 46–55 (heap — critical for FAANG interviews)

**Week 6:** Review mistakes, re-solve hard problems, do mock interviews
