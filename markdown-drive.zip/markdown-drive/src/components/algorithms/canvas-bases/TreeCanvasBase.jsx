import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#57534e',
    panelBg: 'rgba(255,255,255,0.9)',
    panelBorder: '#d6d3d1',
    nodeDefault: '#a5d8ff',
    nodeDefaultStroke: '#1c4a6e',
    nodeVisited: '#b2f2bb',
    nodeVisitedStroke: '#1e5631',
    nodeCurrent: '#ffd43b',
    nodeCurrentStroke: '#805b10',
    nodeResult: '#d0bfff',
    nodeResultStroke: '#3b2e6e',
    nodeRed: '#ff6b6b',
    nodeRedStroke: '#7c1d1d',
    nodeBlack: '#343a40',
    nodeBlackStroke: '#495057',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.05)',
    stroke: 'rgba(255,255,255,0.55)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    panelBg: 'rgba(28,25,23,0.82)',
    panelBorder: 'rgba(255,255,255,0.12)',
    nodeDefault: '#1c4a6e',
    nodeDefaultStroke: '#a5d8ff',
    nodeVisited: '#1e5631',
    nodeVisitedStroke: '#b2f2bb',
    nodeCurrent: '#805b10',
    nodeCurrentStroke: '#ffd43b',
    nodeResult: '#3b2e6e',
    nodeResultStroke: '#d0bfff',
    nodeRed: '#7c1d1d',
    nodeRedStroke: '#ff6b6b',
    nodeBlack: '#343a40',
    nodeBlackStroke: '#868e96',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function nodeFillStroke(p, colorKey) {
  const allowed = new Set(['default', 'visited', 'current', 'result', 'red', 'black']);
  const k = allowed.has(colorKey) ? colorKey : 'default';
  const cap = k.charAt(0).toUpperCase() + k.slice(1);
  return { fill: p[`node${cap}`], stroke: p[`node${cap}Stroke`] || p.stroke };
}

function buildChildrenMap(nodes, edges) {
  const map = new Map();
  nodes.forEach((n) => map.set(n.id, []));
  nodes.forEach((n) => {
    const ch = [];
    if (Array.isArray(n.children)) ch.push(...n.children);
    if (n.left != null) ch.push(n.left);
    if (n.right != null) ch.push(n.right);
    const uniq = [...new Set(ch)];
    uniq.forEach((c) => {
      if (!map.has(n.id)) map.set(n.id, []);
      map.get(n.id).push(c);
    });
  });
  (edges || []).forEach(([from, to]) => {
    if (!map.has(from)) map.set(from, []);
    if (!map.get(from).includes(to)) map.get(from).push(to);
  });
  return map;
}

function findRoot(nodes, childrenMap) {
  const childSet = new Set();
  childrenMap.forEach((arr) => arr.forEach((c) => childSet.add(c)));
  const ids = nodes.map((n) => n.id);
  const roots = ids.filter((id) => !childSet.has(id));
  return roots[0] ?? ids[0] ?? 0;
}

function layoutTree(nodes, edges, W, H) {
  if (!nodes || !nodes.length) return [];
  if (nodes.every((n) => n.x != null && n.y != null)) {
    return nodes.map((n) => ({ ...n }));
  }

  const childrenMap = buildChildrenMap(nodes, edges);
  const root = findRoot(nodes, childrenMap);

  const widthMemo = new Map();
  function subtreeWidth(id) {
    if (widthMemo.has(id)) return widthMemo.get(id);
    const ch = childrenMap.get(id) || [];
    if (!ch.length) {
      widthMemo.set(id, 1);
      return 1;
    }
    let w = 0;
    ch.forEach((c) => { w += subtreeWidth(c); });
    widthMemo.set(id, Math.max(1, w));
    return widthMemo.get(id);
  }
  subtreeWidth(root);

  const positions = new Map();
  function place(id, depth, left, width) {
    const cx = left + width / 2;
    positions.set(id, { xNorm: cx, level: depth });
    const ch = childrenMap.get(id) || [];
    if (!ch.length) return;
    const totalW = ch.reduce((s, c) => s + subtreeWidth(c), 0) || 1;
    let cur = left;
    ch.forEach((c) => {
      const cw = subtreeWidth(c);
      const childWidth = width * (cw / totalW);
      place(c, depth + 1, cur, childWidth);
      cur += childWidth;
    });
  }

  place(root, 0, 0, 1);

  const maxLv = Math.max(0, ...[...positions.values()].map((p) => p.level));
  const padX = 56;
  const padTop = 52;
  const padBottom = 72;
  const innerW = W - padX * 2;
  const innerH = H - padTop - padBottom;
  const dy = maxLv > 0 ? innerH / maxLv : 0;

  return nodes.map((n) => {
    const pos = positions.get(n.id);
    if (!pos) return { ...n, x: W / 2, y: padTop + 36, level: 0 };
    return {
      ...n,
      x: padX + pos.xNorm * innerW,
      y: padTop + pos.level * dy,
      level: pos.level,
    };
  });
}

function easeOut(t) {
  return 1 - (1 - t) ** 3;
}

const TreeCanvasBase = forwardRef(function TreeCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    nodes: [],
    edges: [],
    edgeLabels: [],
    nodeColors: {},
    result: [],
    stack: [],
    queue: [],
    caption: '',
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 450) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((patch) => {
    Object.assign(stateRef.current, patch);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 380;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function render() {
      const now = performance.now();
      const p = getPalette();
      const {
        nodes, edges, edgeLabels, nodeColors, result, stack, queue, caption,
      } = stateRef.current;

      ctx.clearRect(0, 0, W, H);

      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20) {
        for (let gy = 20; gy < H; gy += 20) {
          ctx.fillRect(gx, gy, 1.5, 1.5);
        }
      }

      const laidOut = layoutTree(nodes || [], edges || [], W, H);
      const posById = Object.fromEntries(laidOut.map((n) => [n.id, n]));

      const pulseScale = {};
      for (const a of animsRef.current) {
        const t = Math.min((now - a.t0) / a.dur, 1);
        const e = easeOut(t);
        if (a.type === 'visit' || a.type === 'pulse') {
          const id = a.data.nodeId ?? a.data.id;
          if (id != null) pulseScale[id] = 1 + 0.2 * Math.sin(e * Math.PI);
        }
      }

      (edges || []).forEach(([from, to]) => {
        const pf = posById[from];
        const pt = posById[to];
        if (!pf || !pt) return;
        ctx.beginPath();
        ctx.moveTo(pf.x, pf.y + 18);
        ctx.lineTo(pt.x, pt.y - 18);
        ctx.strokeStyle = p.stroke;
        ctx.lineWidth = 1.5;
        ctx.stroke();
      });

      (edgeLabels || []).forEach((el) => {
        const pf = posById[el.from];
        const pt = posById[el.to];
        if (!pf || !pt) return;
        const mx = (pf.x + pt.x) / 2;
        const my = (pf.y + pt.y) / 2 - 6;
        const label = String(el.label ?? '');
        ctx.font = '600 11px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'center';
        const tw = Math.max(16, label.length * 7 + 8);
        ctx.fillStyle = p.panelBg;
        ctx.strokeStyle = p.panelBorder;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(mx - tw / 2, my - 10, tw, 18, 4);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = p.textPrimary;
        ctx.fillText(label, mx, my + 4);
      });

      const nodeR = 20;
      laidOut.forEach((n) => {
        const colorKey = (nodeColors && nodeColors[n.id]) || 'default';
        const { fill, stroke } = nodeFillStroke(p, colorKey);
        const scale = pulseScale[n.id] || 1;
        const r = nodeR * scale;
        ctx.beginPath();
        ctx.arc(n.x, n.y, r, 0, Math.PI * 2);
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = stroke;
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = p.textPrimary;
        ctx.font = 'bold 12px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        const label = n.label != null ? n.label : n.value;
        ctx.fillText(String(label), n.x, n.y);
      });

      const panelW = 172;
      const px = W - panelW - 14;
      const py = 10;
      ctx.fillStyle = p.panelBg;
      ctx.strokeStyle = p.panelBorder;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.roundRect(px, py, panelW, 112, 8);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = p.textSecondary;
      ctx.font = '600 10px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('Stack', px + 10, py + 16);
      ctx.fillText('Queue', px + 10, py + 60);
      ctx.fillStyle = p.textPrimary;
      ctx.font = '500 11px ui-monospace, Consolas, monospace';
      const stackStr = (stack && stack.length) ? `[${stack.join(', ')}]` : '[]';
      const queueStr = (queue && queue.length) ? `[${queue.join(', ')}]` : '[]';
      const clip = (s, max) => (s.length > max ? `${s.slice(0, max - 1)}…` : s);
      ctx.fillText(clip(stackStr, 20), px + 10, py + 34);
      ctx.fillText(clip(queueStr, 20), px + 10, py + 78);

      const resY = H - 34;
      ctx.fillStyle = p.panelBg;
      ctx.strokeStyle = p.panelBorder;
      ctx.beginPath();
      ctx.roundRect(14, resY - 10, W - 28, 28, 8);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = p.textSecondary;
      ctx.font = '600 10px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'left';
      ctx.fillText('Result', 24, resY + 2);
      ctx.fillStyle = p.textPrimary;
      ctx.font = '500 12px ui-monospace, Consolas, monospace';
      const rs = (result && result.length) ? `[${result.join(', ')}]` : '[]';
      ctx.fillText(clip(rs, Math.max(12, Math.floor((W - 96) / 8))), 68, resY + 2);

      if (caption) {
        ctx.fillStyle = p.textSecondary;
        ctx.font = '500 11px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(caption, 16, 24);
      }

      for (let i = animsRef.current.length - 1; i >= 0; i -= 1) {
        if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
      }

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default TreeCanvasBase;
