import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(ops) {
  const steps = [];
  const stack = [];
  const aux = [];
  ops.forEach((op) => {
    if (op.t === 'push') {
      stack.push(op.v);
      if (!aux.length || op.v <= aux.at(-1)) aux.push(op.v);
      else aux.push(aux.at(-1));
      steps.push({
        type: 'push',
        array: [...stack.map((x) => x * 3 + 5)],
        aux: [...aux.map((x) => x * 3 + 5)],
        note: `push ${op.v}`,
      });
    } else if (op.t === 'pop' && stack.length) {
      stack.pop();
      aux.pop();
      steps.push({
        type: 'pop',
        array: [...stack.map((x) => x * 3 + 5)],
        aux: [...aux.map((x) => x * 3 + 5)],
        note: 'pop',
      });
    }
  });
  steps.push({
    type: 'done',
    array: [...stack.map((x) => x * 3 + 5)],
    aux: [...aux.map((x) => x * 3 + 5)],
    note: '✓ Done',
  });
  return steps;
}

export default function MinStackVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const ops = [
      { t: 'push', v: 5 },
      { t: 'push', v: 3 },
      { t: 'push', v: 7 },
      { t: 'pop' },
      { t: 'push', v: 2 },
    ];
    const steps = generateSteps(ops);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Main stack bars; aux = min stack' });
    canvasRef.current?.setState({
      array: steps[0].array,
      colors: {},
      buckets: { 'Min stack': steps[0].aux.map(String) },
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    step.array.forEach((_, i) => {
      colors[i] = 'active';
    });
    if (step.type === 'done') {
      for (let i = 0; i < step.array.length; i++) colors[i] = 'sorted';
    }
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.note || step.type });
    store.setArray(step.array);
    canvasRef.current?.setState({
      array: step.array,
      colors,
      buckets: { 'Min stack': (step.aux || []).map(String) },
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
