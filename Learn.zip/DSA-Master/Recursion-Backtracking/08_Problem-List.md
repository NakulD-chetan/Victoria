# Recursion-Backtracking — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Covers subsets, permutations, combinations, N-Queens, Sudoku, grid backtracking. FAANG favorites included.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept | Why Important |
|---|---------|------------|-----|---------|----------------|
| 1 | **Subsets** | Medium | 78 | Subsets | Foundation — pure power set |
| 2 | **Subsets II** | Medium | 90 | Subsets + dup | Duplicate handling pattern |
| 3 | **Permutations** | Medium | 46 | Permutations | Core permutation template |
| 4 | **Permutations II** | Medium | 47 | Permutations + dup | Dup in permutations |
| 5 | **Combinations** | Medium | 77 | C(n,k) | Combinations template |
| 6 | **Combination Sum** | Medium | 39 | Combo sum unlimited | Reuse elements |
| 7 | **Combination Sum II** | Medium | 40 | Combo sum unique | Use once + dup |
| 8 | **N-Queens** | Hard | 51 | Placement | FAANG classic |
| 9 | **Sudoku Solver** | Hard | 37 | Constraint satisfaction | Grid backtracking |
| 10 | **Word Search** | Medium | 79 | Grid backtracking | 4-direction DFS |

---

## Complete 30-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Subsets | 78 | Subsets | Include/exclude, index |
| 2 | Subsets II | 90 | Subsets + dup | Sort + skip |
| 3 | Permutations | 46 | Permutations | used[] |
| 4 | Permutations II | 47 | Permutations + dup | Sort + used[i-1] |
| 5 | Combinations | 77 | C(n,k) | Size prune |
| 6 | Letter Combinations of a Phone Number | 17 | Cartesian product | Iterative or backtrack |

### Medium (Problems 7-20) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 7 | **Combination Sum** | 39 | Combo sum unlimited | Same index on include |
| 8 | **Combination Sum II** | 40 | Combo sum unique | Sort + skip dup |
| 9 | **Combination Sum III** | 216 | Combo sum + size k | Both constraints |
| 10 | **Word Search** | 79 | Grid backtracking | 4 dirs, mark/unmark |
| 11 | Palindrome Partitioning | 131 | Partition | Split + validate |
| 12 | Restore IP Addresses | 93 | Partition | 4 segments, valid range |
| 13 | Generate Parentheses | 22 | Structured | open/close counts |
| 14 | Target Sum | 494 | Subsets + sum | +/- per element |
| 15 | Beautiful Arrangement | 526 | Permutation + constraint | used[] + condition |
| 16 | Factor Combinations | 254 | Combo sum variant | Factors, start from i |
| 17 | Generalized Abbreviation | 320 | Subsets variant | Abbreviate or not |
| 18 | Matchsticks to Square | 473 | Partition | 4 equal buckets |
| 19 | Partition to K Equal Sum Subsets | 698 | Partition | K buckets |
| 20 | Word Search II | 212 | Grid + Trie | Backtrack + Trie prune |

### Hard (Problems 21-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 21 | **N-Queens** | 51 | Placement | cols + diags |
| 22 | **N-Queens II** | 52 | N-Queens count | Same, count only |
| 23 | **Sudoku Solver** | 37 | Constraint satisfaction | Row/col/box valid |
| 24 | Split Array into Fibonacci Sequence | 842 | Partition + validate | Build Fibonacci |
| 25 | Expression Add Operators | 282 | Backtrack + eval | Insert +, -, * |
| 26 | Word Squares | 425 | Build square + Trie | Row = col prefix |
| 27 | Remove Invalid Parentheses | 301 | BFS/Backtrack | Min removals |
| 28 | Count Good Numbers | 1922 | Math + backtrack | Digit constraints |
| 29 | Maximum Score from Subsets | 1255 | Subsets + bitmask | Subset enumeration |
| 30 | Tiling a Rectangle | 1240 | Placement | Grid fill |

---

## Problem-by-Problem Strategy Notes

### Subsets (LC 78) ⭐
```
Type: Subsets
Template: Include/exclude, backtrack(start)
Key: result.append(path[:]) at start of each call
One-liner: Every path from root to current node is a subset.
```

### Subsets II (LC 90) ⭐
```
Type: Subsets + duplicates
Template: Sort + skip when i>start && nums[i]==nums[i-1]
Key: Prevents duplicate subsets from duplicate elements
```

### Permutations (LC 46) ⭐
```
Type: Permutations
Template: used[], pick any unused
Key: used[i]=True before recurse, False after
```

### Permutations II (LC 47) ⭐
```
Type: Permutations + dup
Template: Sort + skip when nums[i]==nums[i-1] && !used[i-1]
Key: Ensures one canonical ordering for identical elements
```

### Combination Sum (LC 39) ⭐
```
Type: Combo sum, unlimited use
Template: backtrack(i, remain) — pass i (not i+1) when include
Key: Can reuse, so don't advance index on include
```

### Combination Sum II (LC 40) ⭐
```
Type: Combo sum, use once
Template: backtrack(i+1, remain), sort + skip dup
Key: Each element once, avoid duplicate combinations
```

### N-Queens (LC 51) ⭐
```
Type: Placement
Template: For each row, try each column
Key: Track cols, diag1 (r-c), diag2 (r+c)
```

### Sudoku Solver (LC 37) ⭐
```
Type: Constraint satisfaction
Template: Find empty, try 1-9, valid row/col/box
Key: Return True when solved to stop early
```

### Word Search (LC 79) ⭐
```
Type: Grid backtracking
Template: From each cell, 4 dirs, mark/unmark
Key: board[r][c]= '#' then restore
```

### Generate Parentheses (LC 22)
```
Type: Structured generation
Template: Place ( or ), constraints: open<n, close<open
Key: Two choices per step, pruned by counts
```

---

## Study Plan

### Week 1: Holy Trinity
- Day 1-2: Subsets (78), Subsets II (90)
- Day 3-4: Permutations (46), Permutations II (47)
- Day 5-6: Combinations (77), Combination Sum (39), Combination Sum II (40)
- Day 7: Review templates, reimplement from scratch

### Week 2: Grid & Placement
- Day 1-2: Word Search (79), Word Search II (212)
- Day 3-4: N-Queens (51), N-Queens II (52)
- Day 5-6: Sudoku Solver (37)
- Day 7: Generate Parentheses (22), Palindrome Partitioning (131)

### Week 3: Partition & Advanced
- Day 1-2: Restore IP (93), Partition to K Equal Sum (698)
- Day 3-4: Matchsticks to Square (473), Target Sum (494)
- Day 5-6: Expression Add Operators (282), Remove Invalid Parentheses (301)
- Day 7: Mock interview — pick 2 random from MUST-DO

---

## Difficulty Distribution

| Difficulty | Count | Focus |
|------------|-------|-------|
| Easy | 6 | Warm-up, templates |
| Medium | 14 | Core FAANG level |
| Hard | 10 | Differentiators |

---

## By Pattern

| Pattern | Problems |
|---------|----------|
| Subsets | 78, 90, 320 |
| Permutations | 46, 47, 526 |
| Combinations | 77, 39, 40, 216, 254 |
| Grid | 79, 212 |
| Placement | 51, 52, 37 |
| Partition | 131, 93, 698, 473 |
| Structured | 22, 282, 301 |

---

## FINAL MEMORY COMPRESSION BLOCK

```
MUST-DO 10:     78, 90, 46, 47, 77, 39, 40, 51, 37, 79
HOLY TRINITY:   Subsets → Permute → Combine
COMBO SUM:      39 (reuse), 40 (once)
GRID:           79 (Word), 51 (N-Queens), 37 (Sudoku)
PARTITION:      131, 93, 698
STUDY:          Week 1 trinity, Week 2 grid, Week 3 partition
```
