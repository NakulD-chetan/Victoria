import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const N = 9;
const START = [
  [5, 3, 0, 0, 7, 0, 0, 0, 0],
  [6, 0, 0, 1, 9, 5, 0, 0, 0],
  [0, 9, 8, 0, 0, 0, 0, 6, 0],
  [8, 0, 0, 0, 6, 0, 0, 0, 3],
  [4, 0, 0, 8, 0, 3, 0, 0, 1],
  [7, 0, 0, 0, 2, 0, 0, 0, 6],
  [0, 6, 0, 0, 0, 0, 2, 8, 0],
  [0, 0, 0, 4, 1, 9, 0, 0, 5],
  [0, 0, 0, 0, 8, 0, 0, 7, 9],
];

function clone(g) {
  return g.map((r) => [...r]);
}

function valid(grid, r, c, v) {
  for (let i = 0; i < N; i++) {
    if (grid[r][i] === v || grid[i][c] === v) return false;
  }
  const br = Math.floor(r / 3) * 3;
  const bc = Math.floor(c / 3) * 3;
  for (let i = br; i < br + 3; i++)
    for (let j = bc; j < bc + 3; j++) if (grid[i][j] === v) return false;
  return true;
}

const MAX_STEPS = 3000;

function generateSteps() {
  const steps = [];
  const grid = clone(START);

  function dfs() {
    for (let r = 0; r < N; r++) {
      for (let c = 0; c < N; c++) {
        if (grid[r][c] !== 0) continue;
        for (let v = 1; v <= 9; v++) {
          if (steps.length >= MAX_STEPS) return false;
          steps.push({ type: 'try', r, c, v, board: clone(grid), path: [[r, c]] });
          if (!valid(grid, r, c, v)) {
            steps.push({ type: 'reject', r, c, v, board: clone(grid), path: [[r, c]] });
            continue;
          }
          grid[r][c] = v;
          steps.push({ type: 'place', r, c, v, board: clone(grid), path: [[r, c]] });
          if (dfs()) return true;
          grid[r][c] = 0;
          steps.push({ type: 'back', r, c, v, board: clone(grid), path: [[r, c]] });
        }
        return false;
      }
    }
    steps.push({ type: 'done', msg: 'Sudoku solved', board: clone(grid), path: [] });
    return true;
  }
  steps.push({ type: 'start', msg: 'Backtracking search 1–9', board: clone(grid), path: [] });
  dfs();
  return steps;
}

function paint(step) {
  const cellColors = {};
  const cellValues = {};
  const g = step.board || [];
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const key = `${r}-${c}`;
      const v = g[r][c];
      if (v) cellValues[key] = String(v);
      cellColors[key] = START[r][c] ? 'wall' : 'empty';
      if (START[r][c]) cellColors[key] = 'path';
    }
  }
  if (step.r != null && step.c != null) {
    const key = `${step.r}-${step.c}`;
    if (step.type === 'try') cellColors[key] = 'exploring';
    if (step.type === 'reject' || step.type === 'back') cellColors[key] = 'conflict';
    if (step.type === 'place') cellColors[key] = 'placed';
  }
  return {
    size: N,
    cols: N,
    grid: Array.from({ length: N }, () => Array(N).fill('empty')),
    cellColors,
    cellValues,
    path: step.path || [],
  };
}

export default function SudokuSolverVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Sudoku backtracking' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'try') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || `${step.type} ${step.r},${step.c}` });
    if (step.type === 'back') canvasRef.current?.addAnim('backtrack', { r: step.r, c: step.c }, 280);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
