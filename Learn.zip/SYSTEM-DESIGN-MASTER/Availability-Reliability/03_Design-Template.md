# Availability and Reliability — Design Template

> **Permanent Recall:** HA templates: (1) Stateless app + LB + multi-AZ; (2) Active-active across regions; (3) Failover config for DB/LB; (4) Health checks (liveness, readiness, deep); (5) DR plan with RPO/RTO; (6) Multi-region with active-passive or active-active. Use these as interview blueprints.

---

## Template 1: High Availability Architecture (Base)

For stateless services. No single component failure causes outage.

# What GSLB Checks

It checks things like:

- nearest server
- lowest latency
- server health
- server load
- outages

Then routes traffic intelligently.

```
                    ┌─────────────────────────────────────┐
                    │            DNS / GSLB                │
                    └────────────────┬────────────────────┘
                                     │
                    ┌────────────────┴────────────────┐
                    │     Load Balancer (multi-AZ)     │
                    └────────────────┬────────────────┘
                                     │
         ┌───────────────────────────┼───────────────────────────┐
         │         AZ-1              │              AZ-2         │
         ▼                           ▼                           ▼
    ┌─────────┐  ┌─────────┐   ┌─────────┐  ┌─────────┐
    │ App 1   │  │ App 2   │   │ App 3   │  │ App 4   │
    └────┬────┘  └────┬────┘   └────┬────┘  └────┬────┘
         │            │            │            │
         └────────────┴────────────┴────────────┘
                                     │
                    ┌────────────────┴────────────────┐
                    │  DB Primary (AZ-1) + Replica (AZ-2)│
                    └─────────────────────────────────┘
```

**Components:** Multi-AZ deployment, LB health checks, DB replication.

---

## Template 2: Active-Active Deployment

Both regions serve traffic. Geographic distribution for latency + HA.

```
    US-EAST                          US-WEST
    ┌─────────────────┐              ┌─────────────────┐
    │ LB Pool         │              │ LB Pool         │
    │ App Servers     │◄──sync──────►│ App Servers     │
    │ DB Primary      │   (async)    │ DB Replica      │
    └────────┬────────┘              └────────┬────────┘
             │                               │
             └─────────── GSLB ──────────────┘
                          │
                    User (nearest region)
```

**Config:** GSLB routes by geo; DB replication async/sync; session in Redis/cache shared.

---

## Template 3: Failover Configuration

Active-passive for stateful components (DB, LB pair).

```
                    FAILOVER CONFIG
                    
    ACTIVE                    STANDBY
    ┌─────────────┐           ┌─────────────┐
    │ Primary DB  │ ──sync──► │ Standby DB  │
    │ (serving)   │  replica  │ (ready)     │
    └──────┬──────┘           └──────▲──────┘
           │                         │
           │  Failover detected      │ Promote to primary
           └─────────────────────────┘
           
    LB pair: Active-Passive with VIP failover
    DB: Synchronous replica, automatic promotion (e.g., PostgreSQL streaming)
```

**Key settings:** Health check interval, failover threshold, promotion script.

---

## Template 4: Health Check Implementation

```
HEALTH CHECK LAYERS:

┌────────────────────────────────────────────────────────┐
│  Liveness:  /health (process alive?)                    │
│  Readiness: /ready (can accept traffic? DB reachable?)   │
│  Deep:      /health/db (DB + cache + dependencies)      │
└────────────────────────────────────────────────────────┘
```

**Implementation example:**

```python
# Liveness — minimal, fast
GET /health  → 200 if process running

# Readiness — dependencies
GET /ready   → 200 if DB connection OK and cache reachable

# Deep — full dependency check (for manual/DR)
GET /health/db → 200 if DB read+write works
```


| Check Type | Use                 | Timeout |
| ---------- | ------------------- | ------- |
| Liveness   | Restart if hung     | 5–10s   |
| Readiness  | LB remove from pool | 5–30s   |
| Deep       | On-call, runbooks   | 30s+    |


---

## Template 5: Disaster Recovery Plan

```
                    DR PLAN TEMPLATE
                    
┌─────────────────────────────────────────────────────────┐
│  RPO: 1 hour (max data loss)                             │
│  RTO: 4 hours (max downtime)                             │
├─────────────────────────────────────────────────────────┤
│  Backup: Daily full + hourly incremental                 │
│  Replication: Async to DR region                         │
│  Failover: Manual trigger, automated steps               │
├─────────────────────────────────────────────────────────┤
│  Steps:                                                  │
│  1. Detect disaster (manual or automated)                │
│  2. Promote DR replica to primary                         │
│  3. Update DNS/GSLB to DR region                          │
│  4. Verify data consistency                               │
│  5. Communicate status                                    │
└─────────────────────────────────────────────────────────┘
```

---

## Template 6: Multi-Region Deployment

```
                    MULTI-REGION ARCHITECTURE
                    
         PRIMARY REGION              DR REGION
    ┌─────────────────────┐    ┌─────────────────────┐
    │  Full stack         │    │  Standby stack      │
    │  - LB, App, DB      │    │  - LB, App, DB      │
    │  - Serving 100%     │───►│  - Replica only     │
    └─────────────────────┘    └─────────────────────┘
            │                            │
            │    Async replication       │
            └────────────────────────────┘
            
    GSLB: Failover to DR on primary unreachable
```


| Mode           | Primary       | DR            | Use Case       |
| -------------- | ------------- | ------------- | -------------- |
| Active-Passive | 100% traffic  | Standby       | Cost-conscious |
| Active-Active  | Split traffic | Split traffic | Global latency |


---

## Architecture Summary Table


| Template        | Components                | Use Case              |
| --------------- | ------------------------- | --------------------- |
| HA Base         | Multi-AZ, LB, replicas    | Standard production   |
| Active-Active   | GSLB, 2+ regions          | Global, latency       |
| Failover Config | Active-passive DB/LB      | Stateful components   |
| Health Check    | Liveness, readiness, deep | LB, orchestration     |
| DR Plan         | RPO/RTO, backup, runbook  | Disaster scenarios    |
| Multi-Region    | Primary + DR region       | Geographic resilience |


---

## Quick Memory Card

```
HA BASE:       Multi-AZ, LB, DB replica
ACTIVE-ACTIVE: GSLB, 2+ regions serving
FAILOVER:      Primary + standby, promotion script
HEALTH:        Liveness (alive), Readiness (ready), Deep (deps)
DR:            RPO/RTO, backup schedule, runbook
MULTI-REGION:  Primary + DR, async replication
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**