# 7. Kafka Connect

> **Permanent Recall Note:** **Connect** is a **framework** for **scalable, fault-tolerant** integration between Kafka and external systems — **Source** connectors push data **into** topics; **Sink** connectors pull **from** topics. Data Engineers live in **connector configs**, **converters**, **SMTs**, and **Dead Letter Queues** when schemas go bad. Think of it as **managed producers/consumers** with **offset** tracking for sources — analogous to Spark’s **batch** JDBC read but **continuous** and **operational**.

### The 10-Second Summary
- **Workers** run **connector tasks** (JVM processes).
- **Standalone** = single worker (dev); **distributed** = cluster with **config topic** + **rebalance**.
- **Converters:** JSON, Avro, Protobuf — **decouple** storage format from connector.
- **SMTs** — lightweight **per-record** transforms (mask, route, flatten).
- **Debezium** → **CDC** gold standard — **binlog** / **WAL** capture.

---

# 7.1 Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  CONNECT WORKER CLUSTER                                       │
│  ┌──────────────┐    ┌──────────────┐                        │
│  │ Connector A  │    │ Connector B  │                        │
│  │ tasks: 4     │    │ tasks: 2     │                        │
│  └──────┬───────┘    └──────┬───────┘                        │
└─────────┼───────────────────┼────────────────────────────────┘
          │ Source             │ Sink
          ▼                    ▼
    External DB/S3         Elasticsearch / S3 / JDBC
          │                    ▲
          └────── KAFKA TOPICS ─┘
```

💡 **Key Insight:** **Task** = unit of parallelism — **tasks.max** splits work (e.g. **table** partitions).

---

# 7.2 Workers — Standalone vs Distributed

| Mode | Use |
|------|-----|
| **Standalone** | Laptop, single-node demos |
| **Distributed** | Production — **fault tolerance**, **horizontal scale** |

---

# 7.3 Source vs Sink

| Type | Direction | Examples |
|------|-----------|----------|
| **Source** | External → Kafka | JDBC incremental, Debezium |
| **Sink** | Kafka → External | S3, Elasticsearch, JDBC |

---

# 7.4 Common Connectors

| Connector | Role |
|-----------|------|
| **JDBC Source/Sink** | Tables ↔ topics — bulk + incremental modes |
| **S3 Sink** | Parquet/JSON to object store — **partitioner** |
| **Debezium** | **CDC** (MySQL, Postgres, Mongo…) |
| **Elasticsearch** | Index documents from topics |

---

# 7.5 Converters & Serialization

```json
"key.converter": "org.apache.kafka.connect.json.JsonConverter",
"value.converter": "io.confluent.connect.avro.AvroConverter",
"value.converter.schema.registry.url": "http://localhost:8081"
```

⚠️ **Warning:** **Converter mismatch** between connector and topic — **garbage** or **failures**.

---

# 7.6 Single Message Transforms (SMTs)

```json
"transforms": "maskField",
"transforms.maskField.type": "org.apache.kafka.connect.transforms.MaskField$Value",
"transforms.maskField.fields": "ssn"
```

- **InsertField**, **Rename**, **Filter**, **Flatten** — keep **simple** — complex ETL → **Streams/Flink/Spark**.

### Spark cross-ref

Heavy transforms often go to **Spark** batch/stream — [../spark/04_DataFrame_Dataset_Catalyst.md](../spark/04_DataFrame_Dataset_Catalyst.md).

---

# 7.7 Dead Letter Queues in Connect

```json
"errors.tolerance": "all",
"errors.deadletterqueue.topic.name": "my-dlq",
"errors.deadletterqueue.topic.replication.factor": 3,
"errors.deadletterqueue.context.headers.enable": "true"
```

🎯 **Interview Tip:** **DLQ** + **headers** for debugging **poison** records without stalling pipeline.

---

# 7.8 Connector Configuration — Essentials

```json
{
  "name": "jdbc-source",
  "config": {
    "connector.class": "io.confluent.connect.jdbc.JdbcSourceConnector",
    "tasks.max": "4",
    "connection.url": "jdbc:postgresql://db:5432/db",
    "table.whitelist": "orders",
    "mode": "incrementing",
    "incrementing.column.name": "id",
    "topic.prefix": "db."
  }
}
```

---

# 7.9 Scaling — tasks.max

- Higher **tasks** for **partitioned** sources (multiple tables, sharded queries).
- **Cannot exceed** meaningful parallelism — bounded by **DB** or **Kafka** partitions.

---

# 7.10 Monitoring Connect

- **JMX** metrics: **task status**, **offset lag** (source), **errors**.
- **Connect REST API** — `/connectors`, `/status`.

---

# 7.11 CDC with Debezium — Deep Dive

```
┌──────────┐   WAL/binlog   ┌────────────┐   topics   ┌─────────┐
│ Postgres │ ────────────► │ Debezium   │ ────────► │ Kafka   │
└──────────┘               │ Connector  │           └─────────┘
```

- **Snapshot** + **streaming** — capture **before/after** rows.
- **Topic naming:** `server.schema.table` conventions.
- **Transformations** to **flatten** or **route**.

📏 **Golden Rule:** **DB permissions** minimal but sufficient for **logical replication** slots.

---

# 7.12 Interview Questions & Answers

**Q: Connect vs custom producer?**  
**A:** Connect gives **standardized** ops, **offset** for sources, **distributed** tasks — **faster** to production for common patterns.

**Q: tasks.max zyada kiya — faster?**  
**A:** Only if **work** splits — else **empty tasks** and **DB overhead**.

**Q: Schema change in JDBC?**  
**A:** **Evolution** via Registry; **compatible** changes; **breaking** changes need **migration** plan.

**Q: Spark streaming vs Connect for CDC?**  
**A:** Debezium → Kafka is **canonical**; Spark **consumes** Kafka for **wide** transformations — see [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 7 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Connect = pluggable source/sink framework             │
│  🧠 Converters decouple wire format                        │
│  🧠 SMTs = light transforms; ETL elsewhere               │
│  🧠 DLQ = poison pill isolation                         │
│  ⚠️  tasks.max without splittable work = waste            │
│  🎯 Debezium = CDC standard for DE                        │
└─────────────────────────────────────────────────────────────┘
```
