# Design WhatsApp — Interview Thinking

> **Permanent Recall:** Walkthrough: (0–2 min) clarify scope, (2–7) requirements + scale, (7–20) high-level design (WebSocket, mailbox, services), (20–35) deep dive: connection management, message delivery, offline, group scaling, (35–45) presence, E2E encryption (mention only). Lead with WebSocket; emphasize mailbox model and at-least-once delivery.

---

## Step-by-Step Interview Walkthrough (45 min)

### 0–2 min: Clarify Scope

**You:** "Before I dive in, a few clarifications:
- Is this 1:1 only, or group chat as well?
- Do we need receipts (sent, delivered, read)?
- Online/offline presence?
- Media sharing, voice/video?
- End-to-end encryption in scope?
- Scale: millions or billions of users?"

> **FAANG Tip:** Group chat and E2E encryption change the design significantly. Always ask.

---

### 2–7 min: Requirements & Scale

**You:** "I'll assume:
- **Functional:** 1:1 and group chat (up to 256), sent/delivered/read receipts, online/offline status, media sharing, E2E encryption
- **Scale:** 2B DAU, 100B messages/day → ~1.15M msg/s avg, ~3.5M peak
- **NFRs:** <100ms delivery when online, message ordering per conversation, at-least-once delivery, 99.99% availability"

State capacity: "At 100B messages/day, ~100 bytes avg → 10TB/day text. With media, 50–100TB/day. 1B concurrent WebSocket connections at peak."

---

### 7–20 min: High-Level Design

**You:** "I'll draw the architecture."

```
Client --WebSocket--> LB (sticky) --> Connection Servers
                            |
                            v
                    Chat Service <--> Message Queue <--> Presence
                            |
                            v
                    Message Store + Media Service (S3)
```

**Explain:** "WebSocket for real-time—not HTTP polling. Each user has a mailbox: when online we push via WebSocket; when offline we store and send push notification. Chat Service routes messages; Kafka or per-user queues for fan-out. Presence tracks online via heartbeat."

---

### 20–35 min: Deep Dive

| Topic | What to Say |
|-------|-------------|
| **WebSocket connection management** | "LB must support WebSocket, sticky sessions. Each connection server handles ~50K connections. Need 20K servers for 1B connections. Heartbeat every 30s to detect dead connections; cleanup on disconnect." |
| **Message delivery guarantees** | "At-least-once: we retry on failure. Client deduplicates by message_id. Sent → delivered → read: each step sends acknowledgment." |
| **Offline handling** | "Store in DB first, then push notification. On reconnect, client fetches messages since last sequence_id, or we push backlog from server." |
| **Group chat scaling** | "Write message once. Fan-out to Kafka topics per user, or single topic with consumer groups. Don't do 256 synchronous DB writes—queue handles it." |
| **Presence service** | "Heartbeat every 30–60s. Redis SET with TTL 90s. No heartbeat = offline. On disconnect, update last_seen." |
| **E2E encryption** | "Signal protocol. Client encrypts; server stores ciphertext. Key exchange out-of-band or server-assisted. I can go deeper if needed, but standard approach." |

> **FAANG Tip:** Don't go too deep on E2E encryption unless asked. "Signal protocol, client-side encryption" is enough.

---

## Minute-by-Minute Guide

| Min | Focus | Key Points |
|-----|-------|------------|
| 0–2 | Clarify | 1:1 vs group, receipts, presence, media, E2E, scale |
| 2–5 | Requirements | Functional + NFRs; 2B users, 100B msg/day |
| 5–7 | Capacity | QPS, storage, connections |
| 7–12 | HLD diagram | WebSocket, Chat, Presence, Notification, Media, Store |
| 12–20 | Message flow | Send → queue → deliver or store; mailbox model |
| 20–28 | Connection + delivery | Sticky LB, heartbeat, at-least-once, receipts |
| 28–33 | Offline + group | Store + push; fan-out to 256 |
| 33–38 | Presence + media | Heartbeat + TTL; S3 + URL |
| 38–42 | E2E (brief) | Signal protocol |
| 42–45 | Wrap-up | Summarize; ask for follow-ups |

---

## Handling "Add Voice/Video Calling"

**You:** "That's a separate subsystem. We'd add a signaling server (WebRTC) for call setup, and media relay (TURN/STUN) for NAT traversal. Chat stays unchanged; call is initiated via chat (send 'call' message)."

---

## Handling "Message Search"

**You:** "Store messages in search index (Elasticsearch) keyed by conversation_id, user_id. Index on reconnect or async after store. For E2E: client could upload encrypted search index, or we index metadata only (timestamp, sender)."

---

## What to Draw First

1. **Client ↔ WebSocket connection** (label "sticky LB")
2. **Chat Service** box with arrows to Message Queue
3. **Presence** box with Redis
4. **Notification** box with FCM/APNs
5. **Message Store** and **Media Service** below

Keep it simple; add detail when asked.

---

## Red Flags to Avoid

| Don't | Do |
|-------|-----|
| Use HTTP polling for real-time | Use WebSocket; mention long polling as fallback |
| Ignore offline users | Store + push; deliver on reconnect |
| Synchronous group delivery | Fan-out via queue; write once |
| Single database for all messages | Shard by conversation_id |
| Skip presence | Heartbeat + TTL in Redis |
| Deep-dive E2E without being asked | Mention Signal protocol; offer to elaborate |

---

## 30-SECOND REVISION BOX

```
PHASES: Clarify → Requirements → HLD → Deep dive (conn, delivery, offline, group)
WEBSOCKET: Essential; LB sticky; 50K conn/server; heartbeat
DELIVERY: At-least-once; message_id dedup; sent→delivered→read
OFFLINE: Store first, push, deliver on reconnect
GROUP: Fan-out via queue; write once
E2E: Signal protocol; mention, don't over-explain
```

---

## Closing Strong

**You:** "To summarize: WebSocket for real-time, mailbox model for offline, fan-out for groups, heartbeat for presence. We'd iterate on E2E encryption and media optimizations. Any area you'd like me to go deeper?"

**If time runs out:** Prioritize connection management and message flow. Presence and media can be "similar pattern to X we discussed."

**Common follow-up:** "Add voice calling" → WebRTC + signaling. "Add search" → Elasticsearch or client-side for E2E.

**Body language:** Draw confidently; point at components as you explain. Pause for questions.

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
