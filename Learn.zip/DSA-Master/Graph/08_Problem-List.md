# Graph — Problem List

> **Permanent Recall:** 30 problems, 10 MUST-DO. Categories: BFS, DFS, Topo, Dijkstra, Union-Find. Study plan: MUST-DO first, then by category.

---

## 10 MUST-DO (Priority Order)

| # | Problem | Category | Difficulty | Notes |
|---|---------|----------|------------|-------|
| 1 | **Number of Islands** | BFS/DFS | Medium | Grid as graph; components |
| 2 | **Clone Graph** | BFS/DFS | Medium | HashMap for old→new mapping |
| 3 | **Course Schedule I** | Topo | Medium | Cycle detection + topo |
| 4 | **Course Schedule II** | Topo | Medium | Return topo order |
| 5 | **Word Ladder** | BFS | Medium | Implicit graph; shortest path |
| 6 | **Rotten Oranges** | Multi-source BFS | Medium | Multi-source BFS template |
| 7 | **Shortest Path in Binary Matrix** | BFS | Medium | Unweighted shortest |
| 8 | **Network Delay Time** | Dijkstra | Medium | Single-source shortest |
| 9 | **Pacific Atlantic Water Flow** | DFS | Medium | Multi-target DFS |
| 10 | **Graph Valid Tree** | Union-Find / DFS | Medium | Tree = connected + no cycle |

---

## Full Problem List (30)

### BFS (8)

| # | Problem | Diff | Key Idea |
|---|---------|------|----------|
| 1 | Number of Islands | M | Grid BFS/DFS, components |
| 2 | Word Ladder | M | Words = nodes, 1-char = edge |
| 3 | Rotten Oranges | M | Multi-source BFS |
| 4 | Shortest Path in Binary Matrix | M | Grid BFS, 8 dirs |
| 5 | Walls and Gates | M | Multi-source BFS (gates) |
| 6 | Open the Lock | M | State BFS, 4-digit |
| 7 | Sliding Puzzle | H | State BFS |
| 8 | Word Ladder II | H | BFS + backtrack paths |

### DFS (7)

| # | Problem | Diff | Key Idea |
|---|---------|------|----------|
| 1 | Clone Graph | M | DFS + HashMap clone |
| 2 | Pacific Atlantic Water Flow | M | DFS from borders |
| 3 | Number of Islands | M | DFS alternative |
| 4 | Surrounded Regions | M | DFS from border O's |
| 5 | Longest Increasing Path in Matrix | H | DFS + memoization |
| 6 | Reconstruct Itinerary | H | Euler path, DFS |
| 7 | Critical Connections | H | Tarjan bridges |

### Topological Sort (5)

| # | Problem | Diff | Key Idea |
|---|---------|------|----------|
| 1 | Course Schedule I | M | Cycle + topo |
| 2 | Course Schedule II | M | Return topo order |
| 3 | Alien Dictionary | H | Build graph from words |
| 4 | Sequence Reconstruction | M | Verify unique topo |
| 5 | Minimum Height Trees | M | Centroid; peel layers |

### Dijkstra (5)

| # | Problem | Diff | Key Idea |
|---|---------|------|----------|
| 1 | Network Delay Time | M | Single-source, max dist |
| 2 | Cheapest Flights Within K Stops | M | Dijkstra with k constraint |
| 3 | Path With Minimum Effort | M | Grid Dijkstra |
| 4 | Path With Maximum Probability | M | Max product = -log, Dijkstra |
| 5 | Swim in Rising Water | H | Dijkstra on grid |

### Union-Find / Other (5)

| # | Problem | Diff | Key Idea |
|---|---------|------|----------|
| 1 | Graph Valid Tree | M | n-1 edges + connected |
| 2 | Number of Connected Components | M | Union-Find |
| 3 | Redundant Connection | M | Union-Find cycle |
| 4 | Accounts Merge | M | Union-Find + grouping |
| 5 | Is Graph Bipartite? | M | BFS/DFS coloring |

---

## Study Plan

### Week 1: MUST-DO (10 problems)
- Day 1–2: BFS (Islands, Word Ladder, Rotten Oranges, Binary Matrix)
- Day 3: Topo (Course Schedule I & II)
- Day 4: DFS (Clone Graph, Pacific Atlantic)
- Day 5: Dijkstra (Network Delay), Union-Find (Graph Valid Tree)

### Week 2: By Category
- BFS: Walls and Gates, Open the Lock
- DFS: Surrounded Regions, Longest Increasing Path
- Topo: Alien Dictionary
- Dijkstra: Cheapest Flights, Path With Minimum Effort
- Union-Find: Redundant Connection, Accounts Merge

### Week 3: Hard + Review
- Sliding Puzzle, Word Ladder II, Reconstruct Itinerary
- Re-solve MUST-DO without hints

---

## Language Recommendations

| Language | Best For | Notes |
|----------|----------|-------|
| **Python** | Fast coding, interviews | `deque`, `heapq`, `defaultdict` — minimal syntax |
| **C++** | Performance, systems roles | `vector`, `priority_queue`, `queue` — know `greater<>` |
| **Rust** | Systems, memory safety | `VecDeque`, `BinaryHeap<Reverse>`, ownership |

### FAANG Language Usage (Typical)
- **Google/Meta:** Python or C++ common
- **Amazon:** Java, Python, or C++
- **Apple/Netflix:** Varies; C++ for perf
- **Rust:** Emerging; some teams prefer

---

## Problem → Template Mapping

| Problem Type | Template |
|--------------|----------|
| Grid traversal | BFS/DFS with 4-dir |
| Shortest path (unweighted) | BFS with dist |
| Shortest path (weighted) | Dijkstra |
| Prerequisites | Kahn's or DFS topo |
| Components | DFS from each unvisited |
| Cycle | DFS 3-color / Union-Find |
| Multi-source spread | BFS, enqueue all sources |
| Clone/copy graph | DFS + HashMap |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Problem List
WHEN TO USE:       Interview prep, practice planning
CORE IDEA:         10 MUST-DO first; 30 total; BFS/DFS/Topo/Dijkstra/UF
TIME:              3 weeks suggested
SPACE:             N/A
INTERVIEW SENTENCE: "I've practiced Islands, Word Ladder, Course Schedule,
                     Rotten Oranges — covering BFS, Topo, multi-source BFS."
```

---

## 30-SECOND REVISION BOX

```
MUST-DO: Islands, Clone, Course I/II, Word Ladder, Rotten Oranges,
         Binary Matrix, Network Delay, Pacific Atlantic, Graph Valid Tree
BFS: Islands, Word Ladder, Rotten Oranges, Binary Matrix
Topo: Course Schedule I/II
Dijkstra: Network Delay
Study: 10 first → category deep dive → hard + review
```
