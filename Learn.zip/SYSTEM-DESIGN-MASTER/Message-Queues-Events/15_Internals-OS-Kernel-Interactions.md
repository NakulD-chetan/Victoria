# Internals: OS Kernel Interactions — How Brokers Leverage the Kernel

> **Permanent Recall:** Message brokers are I/O-intensive applications that succeed or fail based on how well they use OS primitives. Key kernel interactions: **Page Cache** (broker's implicit cache), **sendfile()** (zero-copy), **mmap** (memory-mapped index files), **epoll/io_uring** (I/O multiplexing), **fsync/fdatasync** (durability), **fallocate** (pre-allocation), **direct I/O** (bypass page cache for predictable latency). Understanding these syscalls = understanding broker performance at the deepest level.

---

## Why This Matters

At the deepest level, broker performance is really OS behavior plus application design.

This file is where the whole section comes together:

- file I/O
- page cache
- zero-copy
- durability syscalls
- async I/O primitives

If you understand this file, you understand why Kafka and RabbitMQ performance depends so much on Linux tuning and kernel behavior.

---

## The Linux Page Cache — Broker's Best Friend

```
PAGE CACHE — COMPLETE INTERNALS:

The page cache is a kernel-managed LRU cache of disk data in RAM.
Every read/write to files goes through the page cache (unless O_DIRECT).

KERNEL DATA STRUCTURES:

  struct address_space {
      // Per-file page cache (inode's cache)
      struct radix_tree_root  page_tree;  // radix tree of cached pages
      unsigned long           nrpages;    // number of cached pages
      struct backing_dev_info *backing_dev_info;  // the disk device
  };

  struct page {
      unsigned long flags;    // PG_dirty, PG_uptodate, PG_referenced, etc.
      atomic_t      _refcount; // reference count
      struct list_head lru;   // LRU list position
      struct address_space *mapping;  // which file this page belongs to
      pgoff_t       index;    // page offset within the file
      // ... 64 bytes total on 64-bit systems
  };

  Each page = 4 KB of data (on x86_64)

PAGE CACHE OPERATIONS:

  WRITE (e.g., Kafka appending to log segment):
  ┌────────────────────────────────────────────────────────────┐
  │ write(fd, buf, len):                                       │
  │                                                            │
  │ 1. Kernel looks up page cache for this file + offset       │
  │    generic_file_write_iter() → pagecache_get_page()        │
  │                                                            │
  │ 2. If page exists in cache:                                │
  │    Copy data from userspace to page cache page             │
  │    Mark page DIRTY                                         │
  │    Return immediately (sub-microsecond)                    │
  │                                                            │
  │ 3. If page NOT in cache:                                   │
  │    Allocate new page from kernel memory                    │
  │    If writing full page: just allocate (no need to read)   │
  │    If partial write: read page from disk first, then write │
  │    Copy data, mark DIRTY                                   │
  │                                                            │
  │ 4. write() returns SUCCESS                                 │
  │    Data is in RAM only (page cache). NOT on disk yet.      │
  │    Kernel will flush dirty pages later (writeback thread)  │
  │                                                            │
  │ IMPORTANT: write() does NOT guarantee durability!          │
  │ Only fsync()/fdatasync() guarantees data is on disk.       │
  └────────────────────────────────────────────────────────────┘

  READ (e.g., consumer reading old data):
  ┌────────────────────────────────────────────────────────────┐
  │ read(fd, buf, len):                                        │
  │                                                            │
  │ 1. Kernel looks up page cache                              │
  │                                                            │
  │ 2. PAGE HIT (data in cache):                               │
  │    Copy from page cache → userspace buffer                 │
  │    Latency: ~100 nanoseconds (memcpy)                      │
  │    NO disk I/O!                                            │
  │                                                            │
  │ 3. PAGE MISS (data NOT in cache):                          │
  │    a. Allocate page                                        │
  │    b. Submit I/O request to block device driver            │
  │    c. DMA: disk → RAM (page cache page)                    │
  │    d. Process sleeps until I/O completes                   │
  │    e. Copy from page cache → userspace                     │
  │    Latency: ~100 µs (SSD) to ~10 ms (HDD)                 │
  │                                                            │
  │ 4. READ-AHEAD (sequential detection):                      │
  │    Kernel tracks read patterns per file descriptor         │
  │    If sequential: prefetch next N pages asynchronously     │
  │    N starts small (32 KB), grows up to read_ahead_kb       │
  │    Default: /sys/block/sda/queue/read_ahead_kb = 128       │
  │    For Kafka: set to 1024-4096 KB (1-4 MB)                 │
  │    Why: Kafka reads are always sequential → prefetch wins   │
  └────────────────────────────────────────────────────────────┘

PAGE CACHE EVICTION (when RAM is full):
  ┌────────────────────────────────────────────────────────────┐
  │ Two LRU lists: Active and Inactive                         │
  │                                                            │
  │ Active LRU:                                                │
  │   Recently accessed pages (hot data)                       │
  │   Pages promoted here on second access                     │
  │                                                            │
  │ Inactive LRU:                                              │
  │   Pages accessed once, or demoted from active              │
  │   First to be evicted when memory pressure                 │
  │                                                            │
  │ Eviction: kswapd daemon runs when free memory low          │
  │   1. Scan inactive list                                    │
  │   2. If page clean: just free it (instant)                 │
  │   3. If page dirty: write to disk first, then free         │
  │   4. If under pressure: also demote from active list       │
  │                                                            │
  │ For Kafka:                                                 │
  │   Recent log segments: in active list (consumers read)     │
  │   Old segments: evicted (only accessed on replay)          │
  │   Just-written data: stays hot for caught-up consumers     │
  └────────────────────────────────────────────────────────────┘
```

### Dirty Page Writeback

```
DIRTY PAGE WRITEBACK — WHEN DATA HITS DISK:

Three mechanisms trigger writeback:

1. PERIODIC WRITEBACK (background):
   Kernel thread: flush-<device> (or pdflush on older kernels)
   vm.dirty_writeback_centisecs = 500 (5 seconds)
     Check for dirty pages every 5 seconds
   vm.dirty_expire_centisecs = 3000 (30 seconds)
     Page dirty > 30 seconds → write to disk

2. MEMORY PRESSURE WRITEBACK:
   vm.dirty_ratio = 20 (20% of RAM)
     When dirty pages > 20% of RAM → BLOCK writes
     Process calling write() must wait (throttled)
   vm.dirty_background_ratio = 10 (10% of RAM)
     When dirty pages > 10% → start background writeback
     write() still returns fast, but writeback accelerates

   For 128 GB RAM:
     Background writeback starts at: 12.8 GB dirty
     Blocking starts at: 25.6 GB dirty

3. EXPLICIT FSYNC:
   fsync(fd): flush ALL dirty pages for this file to disk
   fdatasync(fd): flush data only (not metadata like timestamps)
   
   Kafka: does NOT fsync per message (by default)
   RabbitMQ quorum queues: fsync per WAL write

   fsync() latency:
     SSD: 0.1 - 1 ms (depending on amount of data)
     HDD: 5 - 50 ms (must wait for disk platter rotation)
     NVMe: 0.01 - 0.1 ms

KAFKA'S STRATEGY (no fsync, rely on replication):
  ┌──────────────────────────────────────────────────────────┐
  │ write() → page cache (fast, ~1 µs)                       │
  │ Data is replicated to 2 other brokers (network, ~1 ms)   │
  │ Any 2 of 3 brokers must crash simultaneously AND          │
  │ all 3 lose their page cache for data loss                 │
  │ Probability: extremely low in well-run datacenters       │
  │                                                          │
  │ Kernel flushes dirty pages within 30 seconds              │
  │ After flush: data is on disk on all 3 brokers            │
  │                                                          │
  │ Trade-off: 30-second window of page-cache-only data      │
  │ vs. fsync latency on every message (500x slower)         │
  └──────────────────────────────────────────────────────────┘
```

---

## mmap — Memory-Mapped Files

```
MMAP INTERNALS — HOW KAFKA READS INDEX FILES:

mmap() maps a file into the process's virtual address space.
Accessing the mapped memory = accessing the file (via page cache).

SYSCALL:
  void *addr = mmap(NULL, length, PROT_READ, MAP_PRIVATE, fd, 0);
  // Returns pointer to virtual memory region mapped to file

KERNEL IMPLEMENTATION:
  ┌────────────────────────────────────────────────────────────┐
  │ 1. Create VMA (Virtual Memory Area) in process page table │
  │    VMA: start_addr, end_addr, file_offset, permissions    │
  │    NO pages allocated yet (lazy allocation)                │
  │                                                            │
  │ 2. First access to mmap'd region (e.g., index lookup):    │
  │    CPU: virtual address → page table lookup → PAGE FAULT   │
  │    No physical page mapped yet!                            │
  │                                                            │
  │ 3. Page fault handler:                                     │
  │    a. Check page cache: file page already cached?          │
  │    b. If YES: map page cache page to process page table    │
  │       Subsequent accesses: direct memory read (no syscall!)│
  │    c. If NO: allocate page, read from disk, add to cache   │
  │       Then map to process page table                       │
  │                                                            │
  │ 4. Subsequent accesses (same page):                        │
  │    Virtual address → page table → physical RAM → data      │
  │    Speed: ~10 nanoseconds (same as normal memory access)   │
  │    NO system call, NO context switch                       │
  │                                                            │
  └────────────────────────────────────────────────────────────┘

MMAP VISUALIZED:

  Process Virtual Memory            Page Cache              Disk
  ┌────────────────────┐    ┌──────────────────┐    ┌──────────────┐
  │ 0x7f0000000000     │    │ File: orders.idx │    │ orders.idx   │
  │ ┌──────────────┐   │    │ Page 0: [data]   │    │ sector 100   │
  │ │ mmap page 0  │───────►│ Page 1: [data]   │◄───│ sector 108   │
  │ │ mmap page 1  │───────►│ Page 2: (not yet) │    │ sector 116   │
  │ │ mmap page 2  │───X    │                  │    │ sector 124   │
  │ │ (not faulted)│        └──────────────────┘    └──────────────┘
  │ └──────────────┘   │
  │                    │
  │ Page 2: first      │
  │ access triggers    │
  │ page fault →       │
  │ kernel loads from  │
  │ disk → maps page   │
  └────────────────────┘

WHY KAFKA USES MMAP FOR INDEXES:
  - Indexes are small (MBs) and frequently accessed
  - Binary search on mmap'd data = pointer arithmetic (fast)
  - No read() syscall overhead per lookup
  - OS manages caching (hot pages stay in RAM)
  - Multiple threads can read same mmap concurrently

WHY NOT MMAP FOR LOG FILES:
  - SIGBUS risk: if file is truncated while mmap'd → process crash
  - Hard to handle I/O errors (no return code, just signals)
  - No control over when pages are written back
  - sendfile() is better for streaming log data to consumers
```

---

## sendfile() and splice() — Zero-Copy Transfers

```
ZERO-COPY SYSCALLS — COMPLETE INTERNALS:

sendfile(out_fd, in_fd, offset, count):
  Transfer data from file fd to socket fd without userspace copy.

KERNEL IMPLEMENTATION:
  ┌────────────────────────────────────────────────────────────┐
  │ do_sendfile(out_fd, in_fd, pos, count):                    │
  │                                                            │
  │ 1. Get file pages from page cache:                         │
  │    For each page in [pos, pos+count]:                      │
  │      page = find_get_page(in_file->mapping, index)         │
  │      if not cached: trigger readahead, wait for I/O        │
  │                                                            │
  │ 2. Create pipe_buffer referencing page cache pages:        │
  │    No data copy — just pointer to existing page!            │
  │                                                            │
  │ 3. Splice pages to socket:                                 │
  │    For each page:                                          │
  │      skb_add_page(socket_skb, page)                        │
  │      // Socket's sk_buff now references page cache page    │
  │                                                            │
  │ 4. NIC transmit:                                           │
  │    If NIC supports scatter-gather DMA:                     │
  │      TX descriptor points to page cache page address       │
  │      NIC DMA reads directly from page cache                │
  │      ZERO copies by CPU!                                   │
  │    If NIC doesn't support scatter-gather:                  │
  │      One copy: page cache → socket buffer → NIC DMA        │
  │                                                            │
  └────────────────────────────────────────────────────────────┘

splice() — THE BUILDING BLOCK:
  sendfile() is internally implemented using splice():
  
  splice(in_fd, offset, pipe_fd, NULL, len, flags)
  → Read pages from file into pipe (zero-copy: just page references)
  
  splice(pipe_fd, NULL, out_fd, NULL, len, flags)
  → Move pages from pipe to socket (zero-copy)

  Together: file → pipe → socket, no userspace copy

KAFKA'S USE OF sendfile() (Java: FileChannel.transferTo):
  ┌──────────────────────────────────────────────────────────┐
  │ Consumer requests: "give me data from offset 42"         │
  │                                                          │
  │ Broker:                                                  │
  │   FileChannel logChannel = logSegment.channel()          │
  │   logChannel.transferTo(position, count, socketChannel)  │
  │                                                          │
  │ Under the hood:                                          │
  │   JVM → JNI → sendfile64() system call                   │
  │   Kernel: page cache pages → NIC DMA → wire              │
  │   No data enters JVM heap!                               │
  │   No GC pressure from transferring log data!             │
  │                                                          │
  │ Result:                                                  │
  │   Kafka can serve consumers at disk/network speed         │
  │   CPU is almost idle during consumer fetch               │
  │   Single broker can sustain 2+ GB/s of consumer traffic  │
  └──────────────────────────────────────────────────────────┘
```

---

## fsync and fdatasync — Durability Guarantees

```
FSYNC INTERNALS — FORCING DATA TO DISK:

fsync(fd):
  ┌────────────────────────────────────────────────────────────┐
  │ 1. Find all dirty pages for this file in page cache        │
  │ 2. Submit write I/O for all dirty pages                    │
  │ 3. Submit write I/O for file metadata (inode: size, mtime) │
  │ 4. Wait for ALL I/O to complete                            │
  │ 5. Flush disk write cache (if battery-backed: skip)        │
  │ 6. Return 0 (success) or -1 (error)                        │
  │                                                            │
  │ Guarantees: after fsync() returns, data is on durable media│
  └────────────────────────────────────────────────────────────┘

fdatasync(fd):
  Same as fsync() but skips metadata write if file size unchanged.
  For append-only logs: fdatasync is sufficient and faster.
  (Kafka: file size changes on every write → fdatasync ≈ fsync)

SYNC FILE RANGE (fine-grained):
  sync_file_range(fd, offset, nbytes, flags):
    Flush specific byte range to disk (not entire file)
    Flags: SYNC_FILE_RANGE_WRITE (initiate writeback)
           SYNC_FILE_RANGE_WAIT_AFTER (wait for completion)
    Can be used for background flushing while writing ahead

DISK WRITE CACHE COMPLICATION:
  ┌──────────────────────────────────────────────────────────┐
  │ Even after fsync(), data might be in DISK WRITE CACHE:   │
  │                                                          │
  │ [RAM page cache] → fsync → [Disk write cache] → platter │
  │                                                          │
  │ Power loss after fsync but before disk cache flush:      │
  │ DATA LOST from disk write cache!                         │
  │                                                          │
  │ Solutions:                                               │
  │   1. Disable disk write cache (hdparm -W 0 /dev/sda)     │
  │      Slower but safe                                     │
  │   2. Battery-backed write cache (BBU/BBWC on RAID cards) │
  │      Fast AND safe (battery powers cache during outage)  │
  │   3. Enterprise SSDs: power-loss protection capacitor    │
  │      Flushes write cache to NAND on power loss           │
  │                                                          │
  │ Kafka in production: enterprise SSDs or BBU RAID         │
  └──────────────────────────────────────────────────────────┘

FSYNC LATENCY BY STORAGE:
  ┌────────────────┬──────────┬──────────────────────────┐
  │ Storage        │ Latency  │ Notes                    │
  ├────────────────┼──────────┼──────────────────────────┤
  │ HDD            │ 5-15 ms  │ Must wait for rotation   │
  │ SATA SSD       │ 0.1-1 ms │ NAND write + flush       │
  │ NVMe SSD       │ 10-100µs │ Multiple I/O queues      │
  │ Intel Optane   │ 5-15 µs  │ 3D XPoint (near-DRAM)    │
  │ tmpfs (RAM)    │ ~1 µs    │ Not durable!             │
  └────────────────┴──────────┴──────────────────────────┘
```

---

## fallocate — Pre-allocating Disk Space

```
FALLOCATE — WHY BROKERS PRE-ALLOCATE:

fallocate(fd, 0, offset, len):
  Allocate disk space for a file without writing data.
  Reserves contiguous blocks on disk.

WHY THIS MATTERS FOR SEQUENTIAL I/O:
  ┌────────────────────────────────────────────────────────────┐
  │ WITHOUT pre-allocation:                                    │
  │   write() → kernel allocates blocks on the fly             │
  │   Blocks may be fragmented across disk                     │
  │   Sequential write → random disk I/O (head seeks)          │
  │   Performance degrades over time as disk fragments          │
  │                                                            │
  │ WITH pre-allocation (fallocate):                           │
  │   fallocate(fd, 0, 0, 1GB)                                │
  │   Kernel reserves 1 GB of contiguous blocks               │
  │   Subsequent writes: always sequential on disk            │
  │   No fragmentation, no allocation delays during write     │
  └────────────────────────────────────────────────────────────┘

KAFKA'S USE:
  - Log segments: fallocate to log.segment.bytes (1 GB)
  - Index files: fallocate to segment.index.bytes (10 MB)
  - Guaranteed contiguous: sequential I/O maintained
  - Also pre-heats disk allocation: write() never blocks on allocation

XFS vs EXT4 FOR KAFKA:
  ┌────────────────────┬────────────────┬────────────────┐
  │                    │ XFS            │ EXT4           │
  ├────────────────────┼────────────────┼────────────────┤
  │ fallocate          │ Very fast      │ Fast           │
  │ Large file delete  │ Fast           │ Can be slow    │
  │ Concurrent I/O     │ Better (per-AG)│ BKL contention │
  │ Max file size      │ 8 EB           │ 16 TB          │
  │ Kafka recommended  │ YES            │ OK             │
  └────────────────────┴────────────────┴────────────────┘

  Kafka documentation recommends XFS for:
    - Better fallocate performance
    - Better deletion of large files (log segment cleanup)
    - Better concurrent I/O (multiple partitions writing)
```

---

## I/O Schedulers — How the Kernel Orders Disk Requests

```
I/O SCHEDULER — BETWEEN FILESYSTEM AND DISK:

When multiple processes read/write, kernel batches and reorders
I/O requests to minimize disk seeks (HDD) or optimize batching (SSD).

┌──────────────────────────────────────────────────────────────┐
│ Application → VFS → Page Cache → Block Layer → I/O Scheduler│
│                                                   ↓          │
│                                              Disk Driver     │
│                                                   ↓          │
│                                              Physical Disk   │
└──────────────────────────────────────────────────────────────┘

SCHEDULERS:

1. NONE (noop):
   No reordering. FIFO queue.
   Best for: NVMe SSDs (no benefit from reordering)
   NVMe has hardware queues that handle parallelism

2. MQ-DEADLINE:
   Separate read and write queues with deadlines
   Reads: deadline 500ms, Writes: deadline 5000ms
   Prevents starvation (reads don't starve writes)
   Best for: SATA SSDs, good general-purpose

3. BFQ (Budget Fair Queueing):
   Fair bandwidth allocation between processes
   Low latency for interactive workloads
   Best for: desktop, not typically for servers

4. KYBER:
   Simple, lightweight scheduler for fast devices
   Two queues: read (low latency target) and write
   Best for: NVMe, similar to none but with basic fairness

FOR KAFKA:
  HDD: mq-deadline (reorders seeks)
  SSD: mq-deadline or none
  NVMe: none (hardware handles scheduling)

CHECK/SET:
  cat /sys/block/nvme0n1/queue/scheduler
  echo none > /sys/block/nvme0n1/queue/scheduler
```

---

## io_uring — The Future of Async I/O

```
IO_URING — LINUX'S MODERN ASYNC I/O:

Traditional I/O: one syscall per operation (context switch overhead)
  read() → kernel → wait → return → read() → kernel → ...

io_uring (Linux 5.1+): batched, async, zero-syscall I/O
  Submit many I/O requests at once, get completions asynchronously

ARCHITECTURE:
  ┌──────────────────────────────────────────────────────────┐
  │                                                          │
  │ USERSPACE                        KERNEL                  │
  │                                                          │
  │ ┌─────────────────────┐    ┌─────────────────────┐      │
  │ │ Submission Queue     │    │ Kernel sees entries  │      │
  │ │ (SQ ring, mmap'd)   │    │ from SQ ring         │      │
  │ │                     │    │                     │      │
  │ │ [SQE0: read fd=5]  │───►│ Process I/O request  │      │
  │ │ [SQE1: write fd=7] │    │ Submit to disk driver │      │
  │ │ [SQE2: read fd=5]  │    │                     │      │
  │ │                     │    │                     │      │
  │ └─────────────────────┘    └──────────┬──────────┘      │
  │                                       │                  │
  │ ┌─────────────────────┐    ┌──────────▼──────────┐      │
  │ │ Completion Queue     │    │ Kernel writes       │      │
  │ │ (CQ ring, mmap'd)   │    │ completed results   │      │
  │ │                     │◄───│                     │      │
  │ │ [CQE0: fd=5, 4096B]│    │ No syscall needed!  │      │
  │ │ [CQE1: fd=7, OK]   │    │                     │      │
  │ │                     │    │                     │      │
  │ └─────────────────────┘    └─────────────────────┘      │
  │                                                          │
  └──────────────────────────────────────────────────────────┘

HOW IT WORKS:
  1. Setup: io_uring_setup() → kernel allocates SQ and CQ rings
     mmap() → userspace maps them into its address space
     Shared memory between user and kernel (no copy!)

  2. Submit:
     App writes SQE (Submission Queue Entry) to SQ ring
     SQE: {opcode=READ, fd=5, buf=addr, len=4096, offset=0}
     Optionally: io_uring_enter(submit=3) to notify kernel
     Or: SQPOLL mode → kernel thread polls SQ automatically
       No syscall needed to submit! (zero-syscall I/O)

  3. Complete:
     Kernel completes I/O, writes CQE to CQ ring
     CQE: {result=4096, user_data=cookie, flags=0}
     App reads CQE from CQ ring (memory read, no syscall)

  4. Batching:
     Submit 100 I/O requests at once (one io_uring_enter call)
     vs. 100 read() calls = 100 syscalls = 100 context switches

WHY THIS MATTERS FOR MESSAGE BROKERS:
  ┌──────────────────────────────────────────────────────────┐
  │ Kafka today: uses Java NIO (epoll + read/write syscalls) │
  │ With io_uring:                                           │
  │   - Submit all partition reads in one batch               │
  │   - No syscall per read (SQPOLL mode)                    │
  │   - Higher throughput for many-partition brokers          │
  │   - Lower latency (fewer context switches)               │
  │                                                          │
  │ Adoption:                                                │
  │   - Kafka: not yet using io_uring (as of 2024)           │
  │   - RabbitMQ: Erlang, not directly using io_uring        │
  │   - ScyllaDB, Redpanda: already use io_uring             │
  │   - Redpanda (Kafka-compatible): built on io_uring       │
  │     → claims 10x lower tail latency than Kafka           │
  └──────────────────────────────────────────────────────────┘
```

---

## Direct I/O — Bypassing Page Cache

```
DIRECT I/O (O_DIRECT) — WHEN PAGE CACHE HURTS:

Normal I/O: all reads/writes go through page cache
Direct I/O: bypass page cache entirely, DMA to/from userspace

open(path, O_DIRECT | O_RDWR):
  Reads: disk → DMA → userspace buffer (no page cache)
  Writes: userspace buffer → DMA → disk (no page cache)

CONSTRAINTS:
  - Buffer must be aligned to 512 bytes (or filesystem block size)
  - Read/write size must be aligned
  - File offset must be aligned
  - Application manages its OWN cache

WHO USES DIRECT I/O:
  ┌──────────────────────────────────────────────────────────┐
  │ Databases (MySQL InnoDB, RocksDB):                       │
  │   Have their own buffer pool (don't want double caching) │
  │   Predictable memory usage (not sharing with page cache) │
  │   Control over eviction policy (LRU, clock, etc.)        │
  │                                                          │
  │ Redpanda (Kafka alternative):                            │
  │   Uses direct I/O + io_uring                             │
  │   Manages own memory for caching                         │
  │   Avoids page cache pollution from old reads             │
  │   More predictable latency (no page cache eviction jitter)│
  │                                                          │
  │ Kafka: does NOT use O_DIRECT                             │
  │   Relies on page cache for caching + sendfile()          │
  │   sendfile() REQUIRES page cache (doesn't work with DIO) │
  │   O_DIRECT would break zero-copy consumer path!          │
  └──────────────────────────────────────────────────────────┘
```

---

## Memory Management — JVM vs Erlang vs Rust

```
HOW BROKER LANGUAGE AFFECTS OS INTERACTION:

KAFKA (JVM / Java):
  ┌──────────────────────────────────────────────────────────┐
  │ JVM Heap (managed by GC):                                │
  │   - Request/response objects, metadata, caches            │
  │   - Recommended: 6-8 GB heap (small for Kafka!)           │
  │   - GC pauses: G1GC typically < 20ms                     │
  │   - More heap = longer GC pauses                          │
  │                                                          │
  │ Off-heap (direct ByteBuffers):                           │
  │   - Producer buffer pool (buffer.memory = 32 MB)         │
  │   - Network I/O buffers                                   │
  │   - Not GC'd, manually managed                           │
  │                                                          │
  │ Page cache (kernel managed):                              │
  │   - Log segment data, index files                         │
  │   - All the remaining RAM after JVM + OS                  │
  │   - THIS is where Kafka's data actually lives             │
  │                                                          │
  │ GC IMPACT:                                               │
  │   GC pause > session.timeout → consumer rebalance!       │
  │   GC pause > replica.lag.time.max → ISR shrink!          │
  │   JVM tuning is critical for Kafka stability             │
  └──────────────────────────────────────────────────────────┘

RABBITMQ (Erlang BEAM):
  ┌──────────────────────────────────────────────────────────┐
  │ Erlang process heaps:                                    │
  │   - Each process: own small heap (~2 KB initial)         │
  │   - GC: per-process, generational, copying               │
  │   - GC one process → others unaffected                   │
  │   - No global GC pause!                                  │
  │                                                          │
  │ ETS tables (Erlang Term Storage):                        │
  │   - In-memory key-value tables                           │
  │   - Used for routing tables, exchange state               │
  │   - Lock-free concurrent reads                           │
  │                                                          │
  │ Message store:                                           │
  │   - Queue messages can be in process heap or on disk      │
  │   - Memory watermark triggers paging to disk              │
  │                                                          │
  │ Memory alarm at 40% of RAM:                              │
  │   All producers blocked until memory drops                │
  └──────────────────────────────────────────────────────────┘

REDPANDA (C++ / Seastar framework):
  ┌──────────────────────────────────────────────────────────┐
  │ No GC at all (manual memory management):                 │
  │   - Zero GC pauses                                       │
  │   - Deterministic latency                                │
  │   - Thread-per-core architecture (no locks)              │
  │                                                          │
  │ Seastar framework:                                       │
  │   - Each core: own memory allocator, own I/O queue       │
  │   - No sharing between cores (no cache coherence traffic)│
  │   - io_uring for async I/O                               │
  │   - Direct I/O (O_DIRECT) with own caching               │
  │                                                          │
  │ Result:                                                  │
  │   - p99 latency: 2-10ms (vs Kafka's 20-100ms)           │
  │   - No tail latency spikes from GC                       │
  │   - Better hardware utilization                           │
  └──────────────────────────────────────────────────────────┘
```

---

## Complete Kernel Tuning Checklist for Brokers

```
PRODUCTION KERNEL TUNING FOR KAFKA / RABBITMQ:

# ═══════════════════════════════════════════════
# NETWORK
# ═══════════════════════════════════════════════
net.core.somaxconn = 65535
net.core.netdev_max_backlog = 65535
net.ipv4.tcp_max_syn_backlog = 65535
net.core.rmem_max = 16777216       # 16 MB
net.core.wmem_max = 16777216       # 16 MB
net.ipv4.tcp_rmem = 4096 1048576 16777216
net.ipv4.tcp_wmem = 4096 1048576 16777216
net.ipv4.tcp_congestion_control = bbr
net.core.default_qdisc = fq
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_fin_timeout = 15

# ═══════════════════════════════════════════════
# VIRTUAL MEMORY / PAGE CACHE
# ═══════════════════════════════════════════════
vm.swappiness = 1                  # almost never swap
vm.dirty_ratio = 80                # allow more dirty pages (Kafka)
vm.dirty_background_ratio = 5      # start writeback early
vm.dirty_expire_centisecs = 3000   # 30s before forced write
vm.dirty_writeback_centisecs = 500 # check every 5s
vm.min_free_kbytes = 1048576       # 1 GB reserved for kernel

# ═══════════════════════════════════════════════
# FILE DESCRIPTORS
# ═══════════════════════════════════════════════
fs.file-max = 1000000
# ulimit -n 1000000 (per process)

# ═══════════════════════════════════════════════
# DISK I/O
# ═══════════════════════════════════════════════
# Read-ahead (per device, in /sys):
/sys/block/sda/queue/read_ahead_kb = 1024    # 1 MB
# I/O scheduler:
/sys/block/nvme0n1/queue/scheduler = none    # NVMe
/sys/block/sda/queue/scheduler = mq-deadline # SATA SSD
# Number of I/O requests in flight:
/sys/block/sda/queue/nr_requests = 1024

# ═══════════════════════════════════════════════
# TRANSPARENT HUGE PAGES (THP)
# ═══════════════════════════════════════════════
# DISABLE for Kafka (can cause latency spikes):
echo never > /sys/kernel/mm/transparent_hugepage/enabled
echo never > /sys/kernel/mm/transparent_hugepage/defrag
# THP causes: memory compaction pauses, unpredictable latency

# ═══════════════════════════════════════════════
# NUMA (for multi-socket machines)
# ═══════════════════════════════════════════════
# Pin Kafka to one NUMA node:
numactl --cpunodebind=0 --membind=0 java -jar kafka.jar
# Prevents cross-socket memory access (slower by ~40%)
```

---

## 30-SECOND REVISION BOX

```
PAGE CACHE: kernel LRU cache of files in RAM, write() → cache → async flush
DIRTY PAGES: writeback after dirty_expire (30s) or dirty_ratio pressure
MMAP: file mapped to virtual memory, page fault → load, O(1) access after
SENDFILE: zero-copy file→socket, page cache pages DMA'd to NIC
FSYNC: force dirty pages to disk, costly (0.01-15ms), Kafka skips it
FALLOCATE: pre-allocate contiguous disk space, prevents fragmentation
IO_URING: batched async I/O, submission+completion rings, zero-syscall mode
O_DIRECT: bypass page cache, application manages own cache (Redpanda)
JVM/BEAM/C++: GC impacts, memory model shapes broker behavior
TUNING: swappiness=1, dirty_ratio=80, somaxconn=65535, disable THP
READ-AHEAD: 1-4 MB for sequential workloads (Kafka)
XFS: recommended filesystem for Kafka (fallocate, delete, concurrent I/O)
```

---

**Prev: [[14_Internals-Serialization-Wire-Format]]**
