# Security and Authentication — Design Template

> **Permanent Recall:** Reusable templates for authentication systems: auth system design, OAuth 2.0 implementation, JWT auth flow, session management, RBAC implementation, API security checklist, and HTTPS setup. Use these as starting points for interview designs and production systems.

---

## Authentication System Design Template

```
    ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
    │   Client     │────►│ Auth Service │────►│  User Store  │
    │  (Web/App)   │     │  (Login/JWT) │     │  (DB/LDAP)   │
    └──────────────┘     └──────┬───────┘     └──────────────┘
            │                   │
            │                   │ Validate token
            │                   ▼
            │            ┌──────────────┐
            └───────────►│  API Gateway │────► Backend services
                         │  (Auth check)│
                         └──────────────┘
```

**Components:**
- **Auth Service:** Login, token issuance, refresh
- **User Store:** Credentials, roles
- **API Gateway:** Validates tokens before forwarding

---

## OAuth 2.0 Implementation Template

**Step 1: Register client**
```
    Client ID:     abc123
    Client Secret: secret_xyz (server-side only)
    Redirect URI:  https://app.example.com/callback
```

**Step 2: Authorization request**
```
    GET https://auth.example.com/authorize?
        response_type=code&
        client_id=abc123&
        redirect_uri=https://app.example.com/callback&
        scope=read:email&
        state=random_state
```

**Step 3: Token exchange**
```python
# Server-side
POST https://auth.example.com/token
Content-Type: application/x-www-form-urlencoded

grant_type=authorization_code&
code=received_code&
redirect_uri=https://app.example.com/callback&
client_id=abc123&
client_secret=secret_xyz
```

**Step 4: Use token**
```
    Authorization: Bearer <access_token>
```

---

## JWT Auth Flow Template

```python
# Login endpoint (conceptual)
def login(username, password):
    user = verify_password(username, password)
    if not user:
        raise Unauthorized()
    access = create_jwt(sub=user.id, exp=15min)
    refresh = create_refresh_token(user.id, exp=7days)
    store_refresh_token(refresh, user.id)
    return { "access_token": access, "refresh_token": refresh }

# Token validation (API middleware)
def validate_request(req):
    token = req.headers.get("Authorization", "").replace("Bearer ", "")
    payload = jwt.decode(token, SECRET, algorithms=["HS256"])
    if payload["exp"] < now():
        raise Unauthorized("Token expired")
    return payload["sub"]
```

---

## Session Management Template

```python
# Create: session_id = secure_random(); redis.setex("session:"+id, 3600, data)
# Cookie: HttpOnly; Secure; SameSite=Strict
# Validate: redis.get("session:"+id) → user
# Logout: redis.delete("session:"+id)
```

---

## RBAC Implementation Template

```python
# Role definitions
ROLES = {
    "admin": ["read", "write", "delete", "manage_users"],
    "editor": ["read", "write"],
    "viewer": ["read"]
}

def has_permission(user, action):
    role = get_user_role(user.id)
    return action in ROLES.get(role, [])

# Middleware
def require_permission(action):
    def decorator(fn):
        def wrapped(req):
            user = get_user(req)
            if not has_permission(user, action):
                raise Forbidden()
            return fn(req)
        return wrapped
    return decorator
```

---

## API Security Checklist

| Check | Implementation |
|-------|----------------|
| **HTTPS** | TLS 1.2+ for all endpoints |
| **Auth** | All sensitive endpoints require auth |
| **Input validation** | Validate, sanitize all inputs |
| **SQL injection** | Parameterized queries only |
| **XSS** | Output encoding, CSP |
| **CSRF** | Token or SameSite cookie |
| **Rate limit** | Login, API endpoints |
| **Secrets** | Env vars, vault; never in code |
| **Password** | bcrypt, min length, complexity |

---

## HTTPS Setup Template

```
    Nginx / Load Balancer:
    - Listen 443
    - ssl_certificate /path/to/cert.pem
    - ssl_certificate_key /path/to/key.pem
    - ssl_protocols TLSv1.2 TLSv1.3
    - Redirect HTTP → HTTPS (301)
```

**Certificate:** Use Let's Encrypt or provider-managed certs. Rotate before expiry.

---

**Stack:** Clients → API Gateway (TLS, rate limit, auth) → Auth / User / Business services → User DB + Redis (sessions).

---

## Code Example: JWT Creation and Validation

```python
# Create JWT
def create_jwt(user_id, exp_minutes=15):
    payload = {
        "sub": user_id,
        "iat": datetime.utcnow(),
        "exp": datetime.utcnow() + timedelta(minutes=exp_minutes)
    }
    return jwt.encode(payload, SECRET, algorithm="HS256")

# Validate JWT
def validate_jwt(token):
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        return payload["sub"]
    except jwt.ExpiredSignatureError:
        raise Unauthorized("Token expired")
    except jwt.InvalidTokenError:
        raise Unauthorized("Invalid token")
```

---

## 30-SECOND REVISION BOX

```
AUTH DESIGN: Client → Auth Service → User Store → API Gateway
OAUTH: Register client → authorize → code → token exchange
JWT FLOW: Login → create JWT → Bearer in header → validate
SESSION: Create → store in Redis → cookie → validate → delete on logout
RBAC: ROLES dict → has_permission(user, action)
CHECKLIST: HTTPS, auth, validate input, SQLi, XSS, CSRF, rate limit
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
