# Tree — Mental Model

> **The one mindset that unlocks 90% of tree problems:** Every node is the root of its own subtree. Solve for one node + trust recursion to handle the rest.

---

## The Core Mental Model: "Think at ONE Node"

When solving a tree problem, **don't think about the whole tree**. Think:

> "What should I do at THIS node, given what my left subtree tells me and what my right subtree tells me?"

Then let recursion handle the rest — it will automatically apply your logic to every node.

**Template thinking:**
```
function solve(node):
    if node is NULL:
        return base_case_value

    left_answer  = solve(node.left)   ← trust left subtree
    right_answer = solve(node.right)  ← trust right subtree

    combine(left_answer, right_answer, node.data)  ← your logic here
    return result
```

---

## Two Directions of Recursion (From Lecture)

The lecture explicitly teaches two approaches. Know which one to pick:

### Top-Down → "Decompose" (Pass information DOWN)

- You compute something at the **parent** and **pass it down** to children
- Think: "What can I tell my children?"
- Used when: Parent has info children need (e.g., path sum, level number)

```
Example: Print all nodes at level K

top_down(node, current_level, k):
    if node is NULL: return
    if current_level == k: print(node.data)   ← use info from above
    top_down(node.left,  current_level + 1, k)
    top_down(node.right, current_level + 1, k)
```

### Bottom-Up → "Recompose" (Gather information UP)

- You compute something at **children first**, then use it at the **parent**
- Think: "What can my children tell me?"
- Used when: Need info from subtrees to compute answer (e.g., height, count, diameter)

```
Example: Height of tree

bottom_up(node):
    if node is NULL: return -1   ← base case at leaf
    left_h  = bottom_up(node.left)   ← get from left child
    right_h = bottom_up(node.right)  ← get from right child
    return 1 + max(left_h, right_h)  ← combine and send UP
```

> **Simple rule:** If you need to PASS data → Top-Down. If you need to COLLECT data → Bottom-Up.

---

## Tree Traversals — The 4 Ways to Visit Every Node

### DFS Traversals (Depth-First)

The difference is ONLY when you "print/process" the current node:

```
       A
      / \
     B   C
    / \
   D   E
```

| Traversal | Order | When to Print | Result |
|-----------|-------|---------------|--------|
| **Pre-order** | Root → Left → Right | **Before** going to children (1st visit) | A, B, D, E, C |
| **In-order** | Left → Root → Right | **Between** left and right children (2nd visit) | D, B, E, A, C |
| **Post-order** | Left → Right → Root | **After** both children done (3rd visit) | D, E, B, C, A |

> **From lecture:** "Print at first visit = Pre-order"

**Memory trick:** Think of walking around the tree:
- Pre = touch on the **left side** of every node
- In = touch on the **bottom** of every node
- Post = touch on the **right side** of every node

### BFS Traversal (Breadth-First / Level-Order)

Visit nodes **level by level**, left to right. Uses a **Queue**.

```
Level 0:  A
Level 1:  B, C
Level 2:  D, E
Output: A → B → C → D → E
```

**Algorithm:**
```
BFS(root):
    if root is NULL: return
    queue.push(root)

    while queue is not empty:
        node = queue.front(); queue.pop()
        process(node)
        if node.left:  queue.push(node.left)
        if node.right: queue.push(node.right)
```

---

## Pre-order: Used for Tree Construction

Pre-order is special — the **first element is always the root**. Use this when:
- Building a tree from scratch (serialize → rebuild)
- Copying a tree
- Prefix expressions

## In-order: Used for Sorted Output in BST

In-order traversal of a **BST** always gives **sorted ascending order**.

```
BST:        50
           /  \
         30    70
        / \   / \
       20 40 60  80

Inorder: 20, 30, 40, 50, 60, 70, 80  ← SORTED!
```

## Post-order: Used for Deletion / Subtree Computations

Post-order is special — you process **children before parent**. Use when:
- Deleting a tree (delete children before parent)
- Computing subtree sizes, heights
- Postfix expressions

---

## Constructing Tree from Traversals

### From Pre-order + In-order:
1. **First element of Pre-order = Root**
2. Find root in In-order → everything to its left = left subtree, everything to its right = right subtree
3. Recursively build left and right subtrees

**Example:**
```
Pre: A B D E C
In:  D B E A C

Step 1: Root = A (first of Pre)
Step 2: In-order: [D B E] | A | [C]
        Left subtree = {D, B, E}, Right subtree = {C}
Step 3: Recurse:
        Pre for left = [B D E] → Root = B
        In for left  = [D B E] → Left of B = {D}, Right of B = {E}
```

### From Post-order + In-order:
1. **Last element of Post-order = Root**
2. Find root in In-order → split left/right subtrees
3. Recursively build

> **Key insight:** You can NEVER construct a unique tree from Pre+Post. You NEED In-order as the "anchor" (unless all nodes are distinct AND you know it's a full binary tree).

---

## How to Think About Common Tree Problems

| Problem | Approach | Direction |
|---------|----------|-----------|
| Height of tree | max(left_h, right_h) + 1 | Bottom-Up |
| Count nodes | count(left) + count(right) + 1 | Bottom-Up |
| Count leaf nodes | if both children NULL → 1 | Bottom-Up |
| Check if BST | Pass min/max bounds down | Top-Down |
| Level of a node | Pass current level down | Top-Down |
| Diameter | max(left_h + right_h + 2) at each node | Bottom-Up |
| Path sum | Subtract from target as you go down | Top-Down |
| Mirror/Invert | Swap left and right at every node | Bottom-Up |
| LCA | Check if node is in left or right | Bottom-Up |

---

## The "3 Questions" Framework for Any Tree Problem

Before writing code, ask yourself:

1. **What does this function return?** (Define it clearly — height? count? boolean? node?)
2. **What is the base case?** (What happens when node is NULL? When it's a leaf?)
3. **How do I combine left and right answers?** (Add? Max? Boolean AND/OR?)

**Example — Is tree balanced?**
```
1. What to return? → (is_balanced, height) pair
2. Base case (NULL) → (True, -1)
3. Combine: balanced if left_balanced AND right_balanced AND |left_h - right_h| <= 1
```
