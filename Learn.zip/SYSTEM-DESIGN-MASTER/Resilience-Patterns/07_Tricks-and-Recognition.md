# Resilience Patterns — Tricks and Recognition

> **Permanent Recall:** Quick recognition: external abuse → rate limit; dependency failure → circuit breaker; many dependencies → bulkhead; transient errors → retry + backoff; writes → idempotency; overload survival → graceful degradation + backpressure. Tech choices: Hystrix (deprecated), Resilience4j (Java), Polly (.NET), Envoy (proxy). Implementation shortcuts in this file.

---

## When to Apply Each Pattern

| Signal | Pattern | Action |
|--------|---------|--------|
| "Prevent abuse" / "DDoS" | Rate limiting | Gateway + Redis |
| "API quota" / "fair usage" | Rate limiting | Per-key limits |
| "External service" / "third-party" | Circuit breaker | Wrap calls |
| "Database slow" / "dependency down" | Circuit breaker + timeout | Fail fast |
| "Multiple microservices" | Bulkhead | Pool per service |
| "Network glitch" / "transient" | Retry + backoff | With jitter |
| "Payment" / "order" / "write" | Idempotency | Key in header |
| "Handle overload" / "stay up" | Graceful degradation | Fallbacks |
| "Producer faster than consumer" | Backpressure | Bounded queue |
| "Test failover" | Chaos engineering | Chaos Monkey |

---

## Resilience Pattern Selection Shortcuts

```
IF external caller → rate limit
IF calling dependency → circuit breaker + timeout
IF many dependencies → bulkhead
IF retryable error → retry + backoff (and idempotency if write)
IF overload likely → graceful degradation + backpressure
IF "how do you test?" → chaos engineering
```

---

## Quick Implementation Guides

### Circuit Breaker (5 min)
1. Choose library (Resilience4j, Polly)
2. Set failure threshold (e.g., 5 or 50%)
3. Set open duration (e.g., 30s)
4. Define fallback (cached, default, 503)
5. Wrap dependency call

### Rate Limiter (10 min)
1. Pick algorithm (token bucket or sliding window)
2. Store state in Redis (distributed) or in-memory (single node)
3. Key: user_id, IP, or API key
4. Return 429 + Retry-After when over limit

### Retry + Backoff (5 min)
1. maxRetries = 3–5
2. baseDelay = 1s, multiplier = 2
3. Add jitter: delay * (0.5 + random())
4. Retry only on RetryableError (not 4xx, not 5xx that indicate bug)

### Idempotency (15 min)
1. Client sends Idempotency-Key header (UUID)
2. Server: check cache/DB for key
3. If exists: return cached response
4. If not: process, store result, return
5. TTL 24–72h

---

## Common Resilience Technology Choices

| Technology | Language/Stack | Use Case |
|------------|----------------|----------|
| **Resilience4j** | Java | Circuit breaker, retry, bulkhead, rate limit |
| **Polly** | .NET | Circuit breaker, retry, timeout, bulkhead |
| **Hystrix** | Java (deprecated) | Netflix; superseded by Resilience4j |
| **Envoy** | Proxy (any backend) | Circuit breaker, retry, timeout at edge |
| **Kong** | API Gateway | Rate limiting, plugins |
| **Redis** | Any | Distributed rate limit state |
| **Istio** | Service mesh | Retry, timeout, circuit breaker in mesh |

> **FAANG Tip:** "For microservices, we use Envoy or service mesh for retry/timeout/circuit breaker at the proxy layer, plus application-level idempotency and fallbacks."

---

## Defense-in-Depth Checklist

```
[ ] Rate limit at gateway (per user, per IP, global)
[ ] Timeout on all outbound calls (connect + read)
[ ] Circuit breaker for each dependency
[ ] Retry with exponential backoff + jitter
[ ] Idempotency for writes (payment, order, etc.)
[ ] Bulkhead (thread pool or semaphore per dependency)
[ ] Graceful degradation (fallback, feature flags)
[ ] Monitoring (CB state, retry count, fallback usage)
```

---

## Interview Recognition Triggers

**"Design a system that handles high load"** → Rate limiting + backpressure + graceful degradation

**"We integrate with third-party X"** → Circuit breaker + retry + timeout + fallback

**"Payment / order / booking"** → Idempotency keys mandatory; circuit breaker; no retry without idempotency

**"Multiple microservices"** → Bulkhead per service; circuit breaker per dependency

**"How do you test resilience?"** → Chaos engineering, fault injection, game days

---

## Resilience Pattern Combinations

| Scenario | Pattern Stack |
|----------|---------------|
| External API | Rate limit (in) + Timeout + CB + Retry + Fallback |
| Payment flow | Idempotency + CB + Timeout + Fallback (no retry on 5xx for charge) |
| Internal microservice | Timeout + CB + Retry + Bulkhead |
| High-throughput queue | Backpressure + Rate limit (consumer pace) |

---

## Library Quick Reference

| Library | Circuit Breaker | Retry | Rate Limit | Bulkhead |
|---------|-----------------|-------|------------|----------|
| Resilience4j | ✓ | ✓ | ✓ | ✓ |
| Polly | ✓ | ✓ | — | ✓ |
| Envoy | ✓ | ✓ | — | ✓ |
| Kong | — | — | ✓ | — |

---

## 30-SECOND REVISION BOX

```
RECOGNITION: abuse→rate limit; dep fail→CB; many deps→bulkhead
SHORTCUTS: external→rate limit; dep→CB+timeout; write→idempotency
TECH: Resilience4j, Polly, Envoy; Redis for rate limit
CHECKLIST: rate limit, timeout, CB, retry, idempotency, bulkhead, degradation
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
