# Design Notification System — Mental Model

> **Permanent Recall:** Think of it as a **pipeline**: Event → Decide (should we send? which channel?) → Format (template + data) → Deliver (channel-specific provider) → Track (delivered/opened/clicked). Each channel has a **different third-party provider** — APNS (iOS), FCM (Android), Twilio (SMS), SendGrid (email).

---

## Core Pipeline

```
Event  →  Decide  →  Format  →  Deliver  →  Track
  │          │          │          │          │
  │          │          │          │          └── Analytics, retry logic
  │          │          │          └── APNS / FCM / Twilio / SendGrid
  │          │          └── Template engine ({{name}}, {{order_id}})
  │          └── User prefs, rate limit, channel selection
  └── order_shipped, password_reset, marketing_offer
```

- **Event:** Triggers the notification (e.g., `order_shipped`, `password_reset`)
- **Decide:** Check user preferences, rate limits; pick channel(s)
- **Format:** Apply template with payload data
- **Deliver:** Send via channel-specific provider
- **Track:** Record status (sent, delivered, opened); handle retries

---

## Post Office Analogy

| Post Office | Notification System |
|-------------|---------------------|
| **Sort** (by destination) | Route by user + channel preference |
| **Route** (postal vs express) | Choose channel (push vs SMS vs email) |
| **Deliver** (mail carrier) | Third-party provider (APNS/FCM/Twilio/SendGrid) |
| **Track** (tracking number) | Delivery ID, status events (delivered/opened) |
| **Return to sender** | Invalid token, bounce; retry or dead-letter |

> **FAANG Tip:** The analogy helps explain why we need separate "delivery" per channel — each has its own carrier (provider).

---

## Key Insight: Channel = Provider

| Channel | Provider | Protocol / API |
|---------|----------|----------------|
| **iOS Push** | APNS (Apple Push Notification service) | Binary protocol over TLS; device token required |
| **Android Push** | FCM (Firebase Cloud Messaging) | HTTP/HTTP2; registration token |
| **SMS** | Twilio, AWS SNS, etc. | REST API; phone number |
| **Email** | SendGrid, SES, Mailgun | SMTP or REST; email address |

Each provider has different:
- **Token format** (APNS token ≠ FCM token)
- **Rate limits** (batches, per-second caps)
- **Retry semantics** (SMS may have different SLAs than push)
- **Tracking** (email open/click; push delivery receipt; SMS delivery report)

---

## Decomposition

| Stage | Responsibility |
|-------|----------------|
| **Event ingestion** | Accept notification requests; validate; enqueue |
| **Decision layer** | User preferences (opt-in/out), rate limiter, channel selector |
| **Format layer** | Template engine; variable substitution; localize |
| **Delivery layer** | Channel workers; call provider APIs; handle provider-specific logic |
| **Tracking layer** | Store delivery status; trigger retries; analytics |

---

## Why Pipeline Architecture?

1. **Separation of concerns:** Decide, format, deliver are independent — scale each separately
2. **Channel isolation:** Push worker ≠ SMS worker; different SLAs, different queues
3. **Retry flexibility:** Failed at delivery → retry only delivery; no re-check of prefs
4. **Provider abstraction:** Swap Twilio for another SMS provider without changing decide/format

---

## Data Flow Summary

```
WRITE:  Event (order_shipped) → API → Queue → Decide (prefs, rate limit)
                                      → Format (template: "Order {{id}} shipped")
                                      → Route to Push Queue / SMS Queue / Email Queue
                                      → Worker → APNS/FCM/Twilio/SendGrid
                                      → Track (delivered/failed) → DB

READ:   User prefs (DB/cache), device tokens (DB), template (DB/cache)
```

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| One queue vs per-channel queues | Per-channel: isolate failure, different priorities; one queue: simpler but coupled |
| Sync vs async delivery | Async (queue) always — 10B/day can't block; sync only for "send now" API response |
| Inline vs batch provider calls | Batch where possible (FCM 500/req); reduces round-trips |
| At-least-once + idempotency | May retry; idempotency key prevents duplicate sends |

---

## Component Priorities

1. **Event → Decide → Format → Deliver** — Core pipeline; must work
2. **User preferences** — Legal and UX; must be respected
3. **Rate limiting** — Prevents spam, fatigue, cost explosion
4. **Channel workers** — Each provider is different; isolate
5. **Tracking + retry** — At-least-once; dead-letter for permanent failures
