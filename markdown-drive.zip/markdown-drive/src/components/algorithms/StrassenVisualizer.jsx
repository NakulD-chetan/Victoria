import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps() {
  const steps = [];
  const labels = ['A11', 'A12', 'A21', 'A22', 'B11', 'B12', 'B21', 'B22'];
  const products = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7'];
  steps.push({
    type: 'split',
    array: [2, 2, 2, 2, 2, 2, 2, 2],
    labels: Object.fromEntries(labels.map((l, i) => [i, l])),
    caption: 'Split A and B into 2×2 blocks (sizes as bars)',
  });
  for (let i = 0; i < products.length; i++) {
    steps.push({
      type: 'product',
      idx: i,
      array: [0, 0, 0, 0, 0, 0, 0, 0].map((_, j) => (j === i ? 60 - j * 5 : 8)),
      labels: Object.fromEntries(products.map((p, j) => [j, p])),
      caption: `Compute ${products[i]} (7 multiplies)`,
    });
  }
  steps.push({
    type: 'combine',
    array: [55, 50, 45, 40, 35, 30, 25, 20],
    labels: Object.fromEntries(['C11', 'C12', 'C21', 'C22', '·', '·', '·', '·'].map((l, i) => [i, l])),
    caption: 'Combine block products into C (conceptual)',
  });
  steps.push({ type: 'done', array: [70, 65, 60, 55, 50, 45, 40, 35], labels: {}, caption: '✓ Strassen outline complete' });
  return steps;
}

export default function StrassenVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray(steps[0].array);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Strassen matrix multiply (7 products)' });
    canvasRef.current?.setState({ array: steps[0].array, colors: {}, labels: steps[0].labels || {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    const n = step.array.length;
    if (step.type === 'split') {
      for (let i = 0; i < n; i++) colors[i] = i < 4 ? 'active' : 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption });
    } else if (step.type === 'product') {
      for (let i = 0; i < n; i++) colors[i] = i === step.idx ? 'compare' : 'default';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption });
    } else if (step.type === 'combine') {
      for (let i = 0; i < n; i++) colors[i] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: step.caption });
    } else if (step.type === 'done') {
      for (let i = 0; i < n; i++) colors[i] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: step.caption });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({
      array: step.array,
      colors,
      labels: step.labels || {},
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
