# Queue — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.**

---

## Template 1: BFS — Graph/Tree Level Order

**Use when:** Level-order traversal, BFS on graph, shortest path (unweighted).

### Python

```python
from collections import deque

def bfs_level_order(start, graph):
    """graph: adjacency list {node: [neighbors]}"""
    queue = deque([start])
    visited = {start}
    
    while queue:
        node = queue.popleft()
        # Process node here
        # process(node)
        
        for neighbor in graph.get(node, []):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)
    
    return  # result
```

### C++

```cpp
#include <queue>
#include <unordered_set>

void bfsLevelOrder(int start, vector<vector<int>>& graph) {
    queue<int> q;
    q.push(start);
    unordered_set<int> visited;
    visited.insert(start);
    
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        // Process node here
        
        for (int neighbor : graph[node]) {
            if (visited.find(neighbor) == visited.end()) {
                visited.insert(neighbor);
                q.push(neighbor);
            }
        }
    }
}
```

### Rust

```rust
use std::collections::VecDeque;
use std::collections::HashSet;

fn bfs_level_order(start: usize, graph: &[Vec<usize>]) {
    let mut queue = VecDeque::from([start]);
    let mut visited = HashSet::from([start]);
    while let Some(node) = queue.pop_front() {
        // Process node here
        for &neighbor in graph.get(node).into_iter().flatten() {
            if visited.insert(neighbor) {
                queue.push_back(neighbor);
            }
        }
    }
}
```

**Rust note:** `VecDeque` IS the queue — no separate type. `push_back`/`pop_front` for FIFO. BFS with borrowed adjacency list `&[Vec<usize>]`.

---

## Template 2: BFS with Level Tracking

**Use when:** Need to know which level each node belongs to (e.g., level order list of lists).

### Python

```python
from collections import deque

def bfs_with_levels(root):
    if not root:
        return []
    
    queue = deque([root])
    result = []
    
    while queue:
        level_size = len(queue)  # snapshot before processing
        level = []
        
        for _ in range(level_size):
            node = queue.popleft()
            level.append(node.val)  # or node
            if node.left:
                queue.append(node.left)
            if node.right:
                queue.append(node.right)
        
        result.append(level)
    
    return result
```

### C++

```cpp
vector<vector<int>> bfsWithLevels(TreeNode* root) {
    vector<vector<int>> result;
    if (!root) return result;
    
    queue<TreeNode*> q;
    q.push(root);
    
    while (!q.empty()) {
        int levelSize = q.size();  // snapshot
        vector<int> level;
        
        for (int i = 0; i < levelSize; i++) {
            TreeNode* node = q.front();
            q.pop();
            level.push_back(node->val);
            if (node->left) q.push(node->left);
            if (node->right) q.push(node->right);
        }
        
        result.push_back(level);
    }
    
    return result;
}
```

### Rust

```rust
use std::collections::VecDeque;

fn bfs_with_levels(root: Option<&TreeNode>) -> Vec<Vec<i32>> {
    let mut result = vec![];
    let root = match root { Some(r) => r, None => return vec![] };
    let mut queue = VecDeque::from([root]);
    while !queue.is_empty() {
        let level_size = queue.len();
        let mut level = Vec::with_capacity(level_size);
        for _ in 0..level_size {
            let node = queue.pop_front().unwrap();
            level.push(node.val);
            if let Some(ref left) = node.left { queue.push_back(left); }
            if let Some(ref right) = node.right { queue.push_back(right); }
        }
        result.push(level);
    }
    result
}
```

**Rust note:** `level_size = queue.len()` before processing — snapshot for level-by-level BFS.

---

## Template 3: Monotonic Deque — Sliding Window Maximum

**Use when:** For each window of size k, find maximum. O(n) total.

### Python

```python
from collections import deque

def sliding_window_max(arr, k):
    n = len(arr)
    dq = deque()  # stores indices
    result = []
    
    for i in range(n):
        # Remove indices outside current window
        while dq and dq[0] < i - k + 1:
            dq.popleft()
        
        # Maintain decreasing order: pop from back while back < current
        while dq and arr[dq[-1]] < arr[i]:
            dq.pop()
        
        dq.append(i)
        
        # Front is max of window [i-k+1, i]
        if i >= k - 1:
            result.append(arr[dq[0]])
    
    return result
```

### C++

```cpp
vector<int> slidingWindowMax(vector<int>& arr, int k) {
    int n = arr.size();
    deque<int> dq;  // indices
    vector<int> result;
    
    for (int i = 0; i < n; i++) {
        while (!dq.empty() && dq.front() < i - k + 1)
            dq.pop_front();
        
        while (!dq.empty() && arr[dq.back()] < arr[i])
            dq.pop_back();
        
        dq.push_back(i);
        
        if (i >= k - 1)
            result.push_back(arr[dq.front()]);
    }
    
    return result;
}
```

### Rust

```rust
use std::collections::VecDeque;

fn sliding_window_max(arr: &[i32], k: usize) -> Vec<i32> {
    let n = arr.len();
    let mut dq = VecDeque::new();
    let mut result = Vec::new();
    for i in 0..n {
        while dq.front().is_some_and(|&idx| idx + k <= i) {
            dq.pop_front();
        }
        while dq.back().is_some_and(|&idx| arr[idx] < arr[i]) {
            dq.pop_back();
        }
        dq.push_back(i);
        if i >= k - 1 {
            result.push(arr[dq.front().unwrap()]);
        }
    }
    result
}
```

**Rust note:** `VecDeque` stores indices. Maintain decreasing order: pop back while `arr[back] < arr[i]`; front = max.

---

## Template 4: Monotonic Deque — Sliding Window Minimum

**Use when:** For each window of size k, find minimum. O(n) total.

### Python

```python
from collections import deque

def sliding_window_min(arr, k):
    n = len(arr)
    dq = deque()  # stores indices
    result = []
    
    for i in range(n):
        while dq and dq[0] < i - k + 1:
            dq.popleft()
        
        # Maintain INCREASING order: pop from back while back > current
        while dq and arr[dq[-1]] > arr[i]:
            dq.pop()
        
        dq.append(i)
        
        if i >= k - 1:
            result.append(arr[dq[0]])
    
    return result
```

### C++

```cpp
vector<int> slidingWindowMin(vector<int>& arr, int k) {
    int n = arr.size();
    deque<int> dq;
    vector<int> result;
    
    for (int i = 0; i < n; i++) {
        while (!dq.empty() && dq.front() < i - k + 1)
            dq.pop_front();
        
        while (!dq.empty() && arr[dq.back()] > arr[i])
            dq.pop_back();
        
        dq.push_back(i);
        
        if (i >= k - 1)
            result.push_back(arr[dq.front()]);
    }
    
    return result;
}
```

### Rust

```rust
use std::collections::VecDeque;

fn sliding_window_min(arr: &[i32], k: usize) -> Vec<i32> {
    let n = arr.len();
    let mut dq = VecDeque::new();
    let mut result = Vec::new();
    for i in 0..n {
        while dq.front().is_some_and(|&idx| idx + k <= i) {
            dq.pop_front();
        }
        while dq.back().is_some_and(|&idx| arr[idx] > arr[i]) {
            dq.pop_back();
        }
        dq.push_back(i);
        if i >= k - 1 {
            result.push(arr[dq.front().unwrap()]);
        }
    }
    result
}
```

**Rust note:** Maintain INCREASING order: pop back while `arr[back] > arr[i]`; front = min.

---

## Template 5: Implement Queue Using Stacks

**Use when:** Design question. Amortized O(1) enqueue and dequeue.

### Python

```python
class MyQueue:
    def __init__(self):
        self.in_stack = []
        self.out_stack = []
    
    def push(self, x):
        self.in_stack.append(x)
    
    def pop(self):
        self._move_if_needed()
        return self.out_stack.pop()
    
    def peek(self):
        self._move_if_needed()
        return self.out_stack[-1]
    
    def empty(self):
        return not self.in_stack and not self.out_stack
    
    def _move_if_needed(self):
        if not self.out_stack:
            while self.in_stack:
                self.out_stack.append(self.in_stack.pop())
```

### C++

```cpp
class MyQueue {
    stack<int> inStack, outStack;
    
    void moveIfNeeded() {
        if (outStack.empty()) {
            while (!inStack.empty()) {
                outStack.push(inStack.top());
                inStack.pop();
            }
        }
    }
    
public:
    void push(int x) { inStack.push(x); }
    
    int pop() {
        moveIfNeeded();
        int x = outStack.top();
        outStack.pop();
        return x;
    }
    
    int peek() {
        moveIfNeeded();
        return outStack.top();
    }
    
    bool empty() { return inStack.empty() && outStack.empty(); }
};
```

### Rust

```rust
struct MyQueue {
    in_stack: Vec<i32>,
    out_stack: Vec<i32>,
}

impl MyQueue {
    fn new() -> Self {
        Self { in_stack: vec![], out_stack: vec![] }
    }
    fn push(&mut self, x: i32) { self.in_stack.push(x); }
    fn pop(&mut self) -> i32 {
        self.move_if_needed();
        self.out_stack.pop().unwrap()
    }
    fn peek(&mut self) -> i32 {
        self.move_if_needed();
        *self.out_stack.last().unwrap()
    }
    fn empty(&self) -> bool { self.in_stack.is_empty() && self.out_stack.is_empty() }
    fn move_if_needed(&mut self) {
        if self.out_stack.is_empty() {
            while let Some(x) = self.in_stack.pop() {
                self.out_stack.push(x);
            }
        }
    }
}
```

**Rust note:** `Vec` as stack: `push`/`pop`. Move when out empty — ownership moves elements.

---

## Template 6: Implement Stack Using Queues

**Use when:** Design question. Push O(1), Pop O(n) — or push O(n), pop O(1).

### Python (Push O(1), Pop O(n))

```python
from collections import deque

class MyStack:
    def __init__(self):
        self.q = deque()
    
    def push(self, x):
        self.q.append(x)
    
    def pop(self):
        # Rotate: move n-1 elements to back, return front
        for _ in range(len(self.q) - 1):
            self.q.append(self.q.popleft())
        return self.q.popleft()
    
    def top(self):
        val = self.pop()
        self.push(val)
        return val
    
    def empty(self):
        return len(self.q) == 0
```

### C++

```cpp
class MyStack {
    queue<int> q;
    
public:
    void push(int x) { q.push(x); }
    
    int pop() {
        for (int i = 0; i < q.size() - 1; i++) {
            q.push(q.front());
            q.pop();
        }
        int x = q.front();
        q.pop();
        return x;
    }
    
    int top() {
        int x = pop();
        push(x);
        return x;
    }
    
    bool empty() { return q.empty(); }
};
```

### Rust

```rust
use std::collections::VecDeque;

struct MyStack {
    q: VecDeque<i32>,
}

impl MyStack {
    fn new() -> Self { Self { q: VecDeque::new() } }
    fn push(&mut self, x: i32) { self.q.push_back(x); }
    fn pop(&mut self) -> i32 {
        for _ in 0..self.q.len() - 1 {
            let x = self.q.pop_front().unwrap();
            self.q.push_back(x);
        }
        self.q.pop_front().unwrap()
    }
    fn top(&mut self) -> i32 {
        let val = self.pop();
        self.push(val);
        val
    }
    fn empty(&self) -> bool { self.q.is_empty() }
}
```

**Rust note:** Rotate n-1 to back before pop. `VecDeque` as queue — `push_back`/`pop_front`.

---

## Template 7: Circular Queue

**Use when:** Fixed-size queue with wrap-around. O(1) enqueue/dequeue.

### Python

```python
class CircularQueue:
    def __init__(self, k):
        self.k = k
        self.arr = [0] * k
        self.front = 0
        self.rear = -1
        self.size = 0
    
    def enqueue(self, value):
        if self.is_full():
            return False
        self.rear = (self.rear + 1) % self.k
        self.arr[self.rear] = value
        self.size += 1
        return True
    
    def dequeue(self):
        if self.is_empty():
            return False
        self.front = (self.front + 1) % self.k
        self.size -= 1
        return True
    
    def front_val(self):
        return -1 if self.is_empty() else self.arr[self.front]
    
    def rear_val(self):
        return -1 if self.is_empty() else self.arr[self.rear]
    
    def is_empty(self):
        return self.size == 0
    
    def is_full(self):
        return self.size == self.k
```

### C++

```cpp
class CircularQueue {
    vector<int> arr;
    int k, front, rear, size;
    
public:
    CircularQueue(int k) : k(k), front(0), rear(-1), size(0) {
        arr.resize(k);
    }
    
    bool enQueue(int value) {
        if (isFull()) return false;
        rear = (rear + 1) % k;
        arr[rear] = value;
        size++;
        return true;
    }
    
    bool deQueue() {
        if (isEmpty()) return false;
        front = (front + 1) % k;
        size--;
        return true;
    }
    
    int Front() { return isEmpty() ? -1 : arr[front]; }
    int Rear() { return isEmpty() ? -1 : arr[rear]; }
    bool isEmpty() { return size == 0; }
    bool isFull() { return size == k; }
};
```

### Rust

```rust
struct CircularQueue {
    arr: Vec<i32>,
    k: usize,
    front: usize,
    rear: usize,
    size: usize,
}

impl CircularQueue {
    fn new(k: usize) -> Self {
        Self { arr: vec![0; k], k, front: 0, rear: k.saturating_sub(1), size: 0 }
    }
    fn enqueue(&mut self, value: i32) -> bool {
        if self.is_full() { return false; }
        self.rear = (self.rear + 1) % self.k;
        self.arr[self.rear] = value;
        self.size += 1;
        true
    }
    fn dequeue(&mut self) -> bool {
        if self.is_empty() { return false; }
        self.front = (self.front + 1) % self.k;
        self.size -= 1;
        true
    }
    fn front_val(&self) -> i32 { if self.is_empty() { -1 } else { self.arr[self.front] } }
    fn rear_val(&self) -> i32 { if self.is_empty() { -1 } else { self.arr[self.rear] } }
    fn is_empty(&self) -> bool { self.size == 0 }
    fn is_full(&self) -> bool { self.size == self.k }
}
```

**Rust note:** `(front/rear + 1) % k`; track size. Use `usize` for indices; handle empty with -1 for value.

---

## Template 8: Task Scheduler Pattern

**Use when:** Process tasks with cooldown, round-robin style.

### Python

```python
from collections import deque, Counter

def task_scheduler_pattern(tasks, n):
    """n = cooldown between same task"""
    count = Counter(tasks)
    max_freq = max(count.values())
    max_count = sum(1 for v in count.values() if v == max_freq)
    
    # Minimum slots needed
    part_count = max_freq - 1
    part_length = n - (max_count - 1)
    empty_slots = part_count * part_length
    available_tasks = len(tasks) - max_freq * max_count
    idles = max(0, empty_slots - available_tasks)
    
    return len(tasks) + idles
```

**Alternative: Queue-based simulation**

```python
from collections import deque, Counter

def task_scheduler_queue(tasks, n):
    count = Counter(tasks)
    max_heap = [(-v, task) for task, v in count.items()]
    heapq.heapify(max_heap)
    
    queue = deque()  # (count, task, available_time)
    time = 0
    
    while max_heap or queue:
        time += 1
        if max_heap:
            neg_cnt, task = heapq.heappop(max_heap)
            if neg_cnt + 1 < 0:
                queue.append((neg_cnt + 1, task, time + n))
        
        if queue and queue[0][2] == time:
            neg_cnt, task = queue.popleft()
            heapq.heappush(max_heap, (neg_cnt, task))
    
    return time
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
BFS:             deque + visited; popleft for FIFO
BFS LEVELS:      level_size = len(q) before for-loop
MONOTONIC MAX:   dq decr; pop back while arr[back] < arr[i]; front = max
MONOTONIC MIN:   dq incr; pop back while arr[back] > arr[i]; front = min
QUEUE VIA STACK: in_stack + out_stack; move when out empty
STACK VIA QUEUE: rotate n-1 to back before pop
CIRCULAR:        (front/rear + 1) % k; track size
```

---

## 30-SECOND REVISION BOX


| Pattern         | Key Idea                                                               |
| --------------- | ---------------------------------------------------------------------- |
| BFS             | `deque`/`queue`/`VecDeque` + visited set; FIFO = `popleft`/`pop_front` |
| BFS Levels      | Snapshot `len(q)` before inner loop; one level per iteration           |
| Monotonic Max   | Deque decreasing; pop back while `arr[back] < arr[i]`; front = max     |
| Monotonic Min   | Deque increasing; pop back while `arr[back] > arr[i]`; front = min     |
| Queue via Stack | Two stacks; move when out empty (amortized O(1))                       |
| Stack via Queue | Rotate n-1 to back, pop front                                          |
| Circular        | `(idx + 1) % k`; track `size` for empty/full                           |


---

## Language Comparison


| Construct         | Python                                   | C++                     | Rust                             |
| ----------------- | ---------------------------------------- | ----------------------- | -------------------------------- |
| Queue             | `deque` (append/popleft)                 | `queue<T>` (push/pop)   | `VecDeque` (push_back/pop_front) |
| FIFO ops          | `append`, `popleft`                      | `push`, `pop` + `front` | `push_back`, `pop_front`         |
| Deque (both ends) | `deque` (append/popleft, appendleft/pop) | `deque<T>`              | `VecDeque`                       |
| Stack             | `list` (append/pop)                      | `stack<T>`              | `Vec` (push/pop)                 |
| Visited set       | `set`                                    | `unordered_set`         | `HashSet`                        |


