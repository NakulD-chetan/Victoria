# How Reddit Works - In Depth (Easy Language)

> Companion to: [13-How-Reddit-Works.md](13-How-Reddit-Works.md)

---

## The Two Hard Problems

Reddit has two main challenges:

1. **Showing the feed**: 100M+ users opening Reddit and expecting an instant feed of ranked posts
2. **Counting votes**: Millions of upvotes/downvotes per second that must update rankings in real-time

Both are surprisingly difficult at scale.

---

## Problem 1: The Feed Can't Be Computed on the Fly

### Why Not Just Query the Database?

```
Naive approach when user opens Reddit:
  SELECT * FROM posts 
  WHERE subreddit IN (user's subscriptions) 
  ORDER BY hot_score(upvotes, downvotes, age) DESC 
  LIMIT 25

This query:
  → Scans millions of posts
  → Computes hot_score for each one
  → Sorts them all
  → Returns top 25
  → Takes 2-5 seconds PER USER
  
  With 100M users: IMPOSSIBLE
```

### The Solution: Pre-Compute Everything

Instead of computing the feed when the user asks for it, **compute it ahead of time** and store the result.

```
Background job (runs constantly):
  1. For each subreddit: compute hot_score for all posts
  2. Sort by score
  3. Store the ranked list in Redis cache:
     
     redis key: "subreddit:programming:hot"
     value: [(post_123, score=95), (post_456, score=87), (post_789, score=82), ...]

When user opens r/programming:
  1. Read from Redis: "subreddit:programming:hot"
  2. Get list of post IDs + scores → instant! (~1ms)
  3. Fetch actual post content by IDs (batch lookup)
  4. Return to user → total: ~50ms
```

**Cassandra as backup**: What if Redis crashes? The same lists are stored in Cassandra (durable, survives crashes). Redis is the fast path; Cassandra is the safe backup.

---

## The Hot Score Algorithm - How Posts Get Ranked

### Simplified Formula

```
hot_score = f(upvotes, downvotes, post_age)

Key behaviors:
  → More upvotes = higher score (obviously)
  → Newer posts get a boost (freshness matters)
  → Old posts decay over time (yesterday's news drops off)
  → The boost from time decays logarithmically:
    - 1 upvote on a new post = big score boost
    - 1 upvote on a day-old post = smaller boost
    - 1 upvote on a week-old post = tiny boost
```

**Why this works**: A post with 100 upvotes in 1 hour ranks HIGHER than a post with 500 upvotes over 3 days. This keeps the feed fresh -- you see what's trending NOW, not what was popular last week.

---

## Problem 2: Voting at Scale - The Lock Contention Nightmare

### Why Voting Is So Hard

When you upvote a post, the system must:
1. Update the vote count in the database
2. Recalculate the hot_score
3. Update the cached ranked list (invalidate + rebuild)

```
Simple approach:
  User upvotes post_123
  → Database: UPDATE posts SET upvotes = upvotes + 1 WHERE id = post_123
  → Recalculate: hot_score(new_upvotes, downvotes, age)
  → Redis: update "subreddit:programming:hot" list with new score
```

**This seems fine. What's the problem?**

### The Lock Problem

```
Popular post goes viral. 10,000 upvotes per second.

Each upvote needs to:
  1. LOCK the post row in database (to prevent lost updates)
  2. Read current vote count
  3. Increment vote count
  4. Unlock the row

10,000 threads trying to lock the SAME row:
  Thread 1: LOCK → read → increment → unlock (5ms)
  Thread 2: WAITING for lock... (Thread 1 has it)
  Thread 3: WAITING for lock...
  Thread 4: WAITING for lock...
  ... 9,997 more threads WAITING...
  
  Thread 2 gets lock after Thread 1 finishes: 5ms + 5ms = 10ms
  Thread 10,000 gets lock after all others: 50 SECONDS of waiting!
```

This is **lock contention**. Everyone competing for the same lock creates a massive bottleneck.

### The Cache Update Problem

After updating the vote in DB, you must update the Redis cache:

```
Read-Mutate-Write on cache:
  1. READ the sorted list from Redis
  2. MUTATE: update post_123's score
  3. WRITE the updated list back to Redis

Problem: Two processors do this simultaneously:
  Processor A: READ → sees score 85
  Processor B: READ → sees score 85 (same stale value!)
  Processor A: WRITE score 86
  Processor B: WRITE score 86 (should be 87! Lost update!)
```

Need **atomic read-mutate-write** operations (using Redis transactions or Lua scripts).

---

## The Solution: Partition the Vote Queue by Subreddit

### The Brilliant Idea

Instead of one big queue where all vote processors compete:

```
BEFORE (single queue, massive contention):
  All votes → [Single Queue] → Processor A, B, C, D all compete for locks
  
  Popular post gets 10,000 votes → all processors fight for same lock

AFTER (partitioned queues, minimal contention):
  Vote for r/programming → Queue 0 (programming_id % 3 = 0) → Processor A
  Vote for r/funny       → Queue 1 (funny_id % 3 = 1)       → Processor B
  Vote for r/gaming      → Queue 2 (gaming_id % 3 = 2)       → Processor C
```

**Why this works:**
- Votes for r/programming only go to Processor A
- Processor A is the ONLY one touching r/programming's data
- No lock contention! (Nobody else is trying to lock the same row)
- Each processor handles its assigned subreddits independently

```
Partitioning formula:
  queue_number = subreddit_id % number_of_queues
  
  r/programming (id=100): 100 % 3 = 1 → Queue 1
  r/funny (id=201):       201 % 3 = 0 → Queue 0
  r/gaming (id=302):      302 % 3 = 2 → Queue 2
```

### Zookeeper for Lock Coordination

Even with partitioning, you still need distributed locks (in case a processor crashes mid-operation). **Zookeeper** provides reliable distributed locks.

```
Processor A: acquire lock on "subreddit:programming:hot"
  → Process vote batch
  → Update DB + cache atomically
  → Release lock

If Processor A crashes mid-lock:
  → Zookeeper detects: "Processor A's heartbeat stopped"
  → Lock automatically released after timeout
  → Processor D picks up the work
```

---

## Post Submission - Also Async

### Why Posts Are Expensive Too

Submitting a post isn't just "insert a row." It requires:
1. Insert into posts table
2. Update subreddit's post count
3. Update user's karma/post count
4. Run spam detection
5. Run rate limiting checks
6. Trigger notifications to subscribers
7. Update pre-computed ranked lists

**Doing all this synchronously** would make the POST API take 2-3 seconds. Users would think the app is broken.

### The Solution: Job Queue

```
User submits post:
  1. POST /submit → server adds job to queue → returns immediately
  2. User sees: "Post submitted!" (instant feedback)
  
  Background processor:
  3. Pulls job from queue
  4. Spam check ✓
  5. Rate limit check ✓
  6. Insert into database ✓
  7. Update caches ✓
  8. Send notifications ✓
  
  Total background processing: 500ms
  But user doesn't wait for any of it!
```

---

## Reddit's Database Evolution

Reddit started simple and grew:

```
Stage 1 (early days): Single PostgreSQL server
  App Server → PostgreSQL
  → Works fine for thousands of users

Stage 2: Separate app and DB servers
  App Server → [Network] → PostgreSQL Server
  → Dedicated hardware for the database

Stage 3: Vertical scaling
  → Bigger PostgreSQL server (more RAM, faster CPU, SSD)
  → "Throwing money at the problem"

Stage 4: Read replicas
  → One primary DB for writes
  → 3 read replicas for reads
  → Reads don't compete with writes

Stage 5: Sharding by subreddit
  → Shard 1: subreddits A-H
  → Shard 2: subreddits I-P
  → Shard 3: subreddits Q-Z
  → Each shard handles 1/3 of the data

Stage 6: Add Cassandra + Redis
  → Cassandra: durable storage for pre-computed lists
  → Redis: fast cache for ranked lists
  → PostgreSQL: authoritative source for posts/comments
```

---

## Revision Flashcards

**Q: Why can't Reddit compute the feed when the user asks for it?**
A: Computing hot_score, sorting, and ranking millions of posts in real-time for 100M+ users is computationally impossible. Instead, feeds are pre-computed in the background and stored in Redis for instant access.

**Q: What is the lock contention problem with voting?**
A: Popular posts get thousands of votes/second. Each vote needs to lock the same database row. Thousands of threads waiting for the same lock creates massive delays (seconds of wait time).

**Q: How does partitioning the vote queue solve lock contention?**
A: Votes are routed to different queues based on subreddit_id % N. Each processor handles its own set of subreddits exclusively. No two processors compete for the same lock.

**Q: What is the read-mutate-write problem on the cache?**
A: Two processors read the same value, both increment it independently, both write back. One increment is lost. Solution: atomic operations (Redis transactions or Lua scripts).

**Q: Why are post submissions processed asynchronously?**
A: Posting involves 7+ steps (spam check, DB writes, notifications, cache updates). Doing all synchronously would take seconds. Instead, the user gets instant feedback while a background worker handles the heavy lifting.
