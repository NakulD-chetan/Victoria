# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. PRODUCT DIMENSION (VERY IMPORTANT)
==================================================

Key idea:
- Product dimension describes WHAT was sold

Meaning:
- Fact table has numbers (sales, quantity)
- Product dimension tells:
  → which product
  → which category
  → which brand


----------------------------------------
Real-world analogy
----------------------------------------

In supermarket:
- Shelf label shows:
  → product name
  → brand
  → category

This is product dimension

Fact table = sales amount  
Product dimension = product details



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Product dimension:
- One row per product (SKU)
- Contains descriptive attributes

Important:
- Used to analyze sales by:
  → category
  → brand
  → department



==================================================
3. MASTER PRODUCT vs STORE ASSORTMENT
==================================================

----------------------------------------
Master Product
----------------------------------------
- All products company can sell

Example:
- Full catalog


----------------------------------------
Store Assortment
----------------------------------------
- Products available in a specific store

Example:
- Store A sells 100 items
- Store B sells 200 items


----------------------------------------
Important Insight
----------------------------------------
Not all products are sold in every store



==================================================
4. PRODUCT DIMENSION COLUMNS
==================================================

Typical columns:

- product_key (surrogate key)
- product_id (SKU)
- product_description
- brand
- department
- category
- subcategory
- package_size
- unit_of_measure
- discontinued_flag


----------------------------------------
Important Concept
----------------------------------------
Surrogate key:
- product_key used in joins



==================================================
5. SLOWLY CHANGING DIMENSION (SCD)
==================================================

Product attributes can change

Example:
- Category changes

Solution:
- Create new row
- Keep history


----------------------------------------
Columns used:
----------------------------------------

- effective_start_date
- effective_end_date
- current_flag


----------------------------------------
Why?
----------------------------------------
- Maintain historical accuracy



==================================================
6. REDUNDANCY PROBLEM
==================================================

Hierarchy:

Department → Category → Subcategory → Product


----------------------------------------
Problem
----------------------------------------
- Same category repeated many times


----------------------------------------
Example
----------------------------------------
Category "Milk" repeated for all milk products


----------------------------------------
Trade-off
----------------------------------------
- Easy queries (denormalized)
vs
- Storage duplication



==================================================
7. STAR SCHEMA (DENORMALIZED)
==================================================

Structure:

Fact table → dim_product (wide)


----------------------------------------
Features
----------------------------------------
- All attributes in one table
- Fewer joins


----------------------------------------
Advantages
----------------------------------------
- Faster queries
- Simple design


----------------------------------------
Disadvantages
----------------------------------------
- Redundant data



==================================================
8. SNOWFLAKE SCHEMA (NORMALIZED)
==================================================

Structure:

dim_product → dim_subcategory → dim_category → dim_department


----------------------------------------
Features
----------------------------------------
- Split hierarchy into multiple tables


----------------------------------------
Advantages
----------------------------------------
- Less redundancy
- Better data consistency


----------------------------------------
Disadvantages
----------------------------------------
- More joins
- Complex queries



==================================================
9. STAR vs SNOWFLAKE COMPARISON
==================================================

Star:
- Simple
- Fast
- Redundant

Snowflake:
- Complex
- Less redundant
- More joins


----------------------------------------
Important Insight
----------------------------------------
Most systems prefer STAR for BI



==================================================
10. PRICE HANDLING (VERY IMPORTANT)
==================================================

----------------------------------------
In Dimension
----------------------------------------
- Standard price (reference)


----------------------------------------
In Fact
----------------------------------------
- Actual price (transaction)


----------------------------------------
Why both?
----------------------------------------
- Compare planned vs actual


----------------------------------------
Important Warning
----------------------------------------
Do NOT store changing price only in dimension



==================================================
11. ROLL UP vs DRILL DOWN
==================================================

----------------------------------------
Roll Up
----------------------------------------
- Aggregate data

Example:
SKU → Category → Department


----------------------------------------
Drill Down
----------------------------------------
- Go into detail

Example:
Department → Category → SKU


----------------------------------------
Important Insight
----------------------------------------
Requires correct hierarchy



==================================================
12. WHEN TO USE SNOWFLAKE
==================================================

Use snowflake when:

- Large hierarchy
- Shared categories
- Frequent changes


----------------------------------------
Use star when:
----------------------------------------

- Simple reporting
- BI dashboards


----------------------------------------
Important Rule
----------------------------------------
Avoid over-normalization



==================================================
13. SQL EXAMPLES
==================================================

----------------------------------------
Star Query
----------------------------------------

SELECT
  category,
  SUM(sales)
FROM fact_sales f
JOIN dim_product p
ON f.product_key = p.product_key
GROUP BY category;


----------------------------------------
Snowflake Query
----------------------------------------

SELECT
  category_name,
  SUM(sales)
FROM fact_sales f
JOIN dim_product p
JOIN dim_category c
JOIN dim_department d
GROUP BY category_name;



==================================================
14. COMMON MISTAKES
==================================================

----------------------------------------
1. Mixing master and store products
----------------------------------------
Problem:
- Wrong joins

Fix:
- Separate clearly


----------------------------------------
2. No SCD handling
----------------------------------------
Problem:
- Wrong history

Fix:
- Use SCD Type 2


----------------------------------------
3. Over-normalization
----------------------------------------
Problem:
- Complex queries

Fix:
- Keep star where possible


----------------------------------------
4. Wrong price storage
----------------------------------------
Problem:
- Wrong analysis

Fix:
- Store actual in fact


----------------------------------------
5. Missing keys
----------------------------------------
Problem:
- Join errors

Fix:
- Use surrogate keys



==================================================
15. FINAL TAKEAWAY
==================================================

Product Dimension:
- Describes product

Star Schema:
- Simple, fast

Snowflake Schema:
- Structured, normalized


----------------------------------------
Golden Rule
----------------------------------------
Keep product dimension simple for users


----------------------------------------
Key Insight
----------------------------------------
Balance:
- performance
- storage
- complexity


----------------------------------------
Goal
----------------------------------------
Enable easy product-based analysis



==================================================
16. QUICK MEMORY SUMMARY
==================================================

Product Dimension:
- One row per SKU

Star:
- Denormalized

Snowflake:
- Normalized

Price:
- Dimension = reference
- Fact = actual

Hierarchy:
- Department → Category → Product

Rule:
- Prefer star, snowflake when needed