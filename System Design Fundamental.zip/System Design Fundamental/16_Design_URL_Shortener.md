# Design URL Shortener (bit.ly) — Step by Step

> **Interview mein sabse common question — URL shortener design karo!**
> Simple lagta hai but deep dive mein bahut kuch hai — hash, collision, redirect, analytics sab!

---

## 1. Requirements Clarification

### Functional Requirements

| Requirement | Description | Example |
|-------------|-------------|---------|
| **Shorten URL** | Long URL ko short URL mein convert karo | `https://google.com/very-long-path` → `bit.ly/abc123` |
| **Redirect** | Short URL pe click → Original URL pe redirect | User clicks `bit.ly/abc123` → Lands on Google |
| **Custom Alias** | User apna custom short link choose kar sake | `bit.ly/my-blog` instead of random `bit.ly/x7K9m` |
| **Expiration** | Optional: URL expire ho sake after X days | Free tier: 30 days, Premium: Never |
| **Analytics** | Click count, referrer, geo, device tracking | "10K clicks from India, 60% mobile" |

### Non-Functional Requirements

| Requirement | Target | Why Important |
|-------------|--------|---------------|
| **Low Latency Redirect** | < 100ms | Redirect = 99% of traffic. Slow = user chhod dega |
| **High Availability** | 99.99% | bit.ly down = millions of links break |
| **Scale** | 100M+ URLs | Storage + lookup at scale |
| **Unpredictable URLs** | No sequential guess | `bit.ly/1`, `bit.ly/2` guess karke abuse ho sakta hai |

### Scope (Interview mein clarify karo)

```
┌─────────────────────────────────────────────────────────────┐
│  IN SCOPE                    │  OUT OF SCOPE (for now)     │
├──────────────────────────────┼─────────────────────────────┤
│  Shorten, Redirect, Custom   │  User auth (assume simple)  │
│  Basic Analytics             │  Payment/billing             │
│  Expiration                  │  Admin dashboard             │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Back of the Envelope Estimation

### Assumptions

- **100M new URLs/month** = ~40 URLs/second write
- **Read:Write ratio = 10:1** → 400 redirects/second read
- **Peak** = 3x average → ~1200 QPS write, ~12K QPS read
- **URL storage**: ~500 bytes per record (long URL + metadata)
- **Retention**: 5 years

### Calculations

| Metric | Calculation | Result |
|--------|-------------|--------|
| **Storage (5 yr)** | 100M × 12 × 5 × 500 bytes | ~30 TB (with indexes) |
| **QPS (Read)** | 400 × 3 (peak) | ~1.2K QPS |
| **QPS (Write)** | 40 × 3 | ~120 QPS |
| **Bandwidth** | 12K × 500 bytes × 8 (redirect response) | ~48 Mbps |

**Matlab yeh hai ki** — Storage manageable, read-heavy system. Caching zyada important hai!

### Real-World Analogy: Pincode System

Socho India ka pincode system — 6 digits se poora address map ho jata hai. URL shortener bhi waisa hi — long address (URL) ko short code se map karte hain. Jaise pincode unique hona chahiye, waise short_code bhi unique. Aur jaise post office redirect karta hai mail ko sahi jagah, waise server redirect karta hai browser ko original URL pe.

---

## 3. High Level Design

```
                    ┌──────────────────────────────────────────────────────────┐
                    │                    URL SHORTENER SYSTEM                   │
                    └──────────────────────────────────────────────────────────┘

    ┌─────────┐         ┌─────────────┐         ┌─────────────────────────────────┐
    │  User   │         │   CDN /     │         │         Application Layer        │
    │ (Browser)│────────►│ Load Balancer│────────►│  ┌─────────┐  ┌─────────────┐  │
    └─────────┘         └─────────────┘         │  │ Shorten  │  │  Redirect   │  │
         │                      │               │  │ Service  │  │   Service   │  │
         │                      │               │  └────┬─────┘  └──────┬──────┘  │
         │                      │               └──────┼───────────────┼─────────┘
         │                      │                      │               │
         │                      │               ┌──────▼───────┐  ┌─────▼─────┐
         │                      │               │    Redis     │  │   Redis   │
         │                      │               │  (Counter/   │  │  (Cache   │
         │                      │               │   Alias)    │  │  hot URLs)│
         │                      │               └──────┬───────┘  └─────┬─────┘
         │                      │                      │               │
         │                      │               ┌──────▼───────────────▼─────┐
         │                      │               │      Database (SQL/NoSQL)   │
         │                      │               │   short_url  |  long_url   │
         │                      │               └────────────────────────────┘
         │                      │
         │                      │               ┌─────────────────────────────┐
         │                      └──────────────►│   Analytics Pipeline        │
         │                                     │   (Async - Kafka + Workers) │
         └────────────────────────────────────►│   Click, Geo, Referrer      │
                                               └─────────────────────────────┘
```

### Flow Summary

1. **Shorten**: User long URL bhejta hai → Hash generate → DB save → Short URL return
2. **Redirect**: User short URL pe click → Cache check → DB lookup → 302 redirect
3. **Analytics**: Redirect time pe event fire → Kafka → Async workers → Analytics DB

---

## 4. API Design

### REST APIs

| Method | Endpoint | Description | Request | Response |
|--------|----------|-------------|---------|----------|
| `POST` | `/api/v1/shorten` | Create short URL | `{ "url": "https://...", "custom_alias": "opt" }` | `{ "short_url": "bit.ly/abc123" }` |
| `GET` | `/{short_code}` | Redirect (main traffic) | — | 302 + Location header |
| `GET` | `/api/v1/url/{short_code}/stats` | Get analytics | — | `{ "clicks": 1000, "countries": [...] }` |
| `DELETE` | `/api/v1/url/{short_code}` | Delete/expire URL | — | 204 |

### API Request/Response Examples

**Shorten Request:**
```json
POST /api/v1/shorten
{
  "url": "https://www.google.com/search?q=system+design+interview",
  "custom_alias": "sysdesign",
  "expires_in_days": 30
}
```

**Shorten Response (Success):**
```json
{
  "short_url": "https://bit.ly/sysdesign",
  "short_code": "sysdesign",
  "long_url": "https://www.google.com/search?q=system+design+interview",
  "created_at": "2024-01-15T10:30:00Z",
  "expires_at": "2024-02-14T10:30:00Z"
}
```

**Shorten Response (Alias taken):**
```json
{
  "error": "alias_taken",
  "message": "Custom alias 'sysdesign' is already in use",
  "suggestions": ["sysdesign1", "sysdesign-blog", "sysdesign2024"]
}
```

**Analytics Response:**
```json
{
  "short_code": "abc123",
  "total_clicks": 15420,
  "unique_visitors": 8920,
  "top_countries": [{"country": "IN", "clicks": 5200}, {"country": "US", "clicks": 3100}],
  "top_referrers": [{"url": "twitter.com", "clicks": 4000}],
  "clicks_by_day": [{"date": "2024-01-15", "clicks": 520}]
}
```

### Redirect API (Critical!)

```
GET /abc123
  → 302 Found
  → Location: https://original-long-url.com/page
  → Cache-Control: private, max-age=3600
```

**301 vs 302 — Interview mein zaroor discuss karo!**

| Code | Meaning | Browser Caches? | Analytics Impact |
|------|---------|-----------------|------------------|
| **301** | Permanent redirect | Haan, browser cache karega | Server pe har baar hit nahi hoga — analytics miss! |
| **302** | Temporary redirect | Nahi, har baar server pe aayega | Full analytics possible |

**Trade-off**: bit.ly jaisi services 302 use karti hain taaki har click track ho. SEO ke liye 301 better.

---

## 5. Data Model / Database Schema

### SQL Schema (Simple Approach)

```sql
-- URLs table
CREATE TABLE urls (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,   -- Counter for hash generation
    short_code VARCHAR(10) UNIQUE NOT NULL, -- abc123 or custom alias
    long_url TEXT NOT NULL,
    user_id BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    INDEX idx_short_code (short_code),
    INDEX idx_user_id (user_id)
);

-- Analytics (separate table, write-heavy)
CREATE TABLE clicks (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    short_code VARCHAR(10),
    clicked_at TIMESTAMP,
    ip_address VARCHAR(45),
    user_agent TEXT,
    referrer TEXT,
    country VARCHAR(2)
);
```

### NoSQL (Cassandra) — Scale ke liye

```
urls table:
  Partition Key: short_code
  Columns: long_url, user_id, created_at, expires_at

clicks table (time-series):
  Partition Key: (short_code, date)
  Clustering Key: timestamp
  Columns: ip, country, referrer, device
```

### Key-Value View

```
short_code (PK)  →  { long_url, user_id, created_at, expires_at }
"abc123"         →  { "https://google.com/...", 123, "2024-01-01", null }
```

---

## 6. Deep Dive — Key Components

### 6.1 Hash Algorithm — Kaun sa use karein?

| Algorithm | How it works | Pros | Cons |
|-----------|--------------|-----|------|
| **Base62 Encode** | Auto-increment ID → Base62 string | Short, predictable length, no collision | Single point for ID generation |
| **MD5 + Truncate** | MD5(long_url)[:6] | No central counter | Collision possible! Retry needed |
| **UUID** | Random 128-bit | No collision, distributed | 22 chars — too long for short URL |
| **Counter-based** | Distributed counter (Redis/Zookeeper) | Best of both | Counter service needed |

**Recommended: Base62 + Counter**

```
ID: 123456789  →  Base62  →  "8M0k9"
Characters: 0-9, a-z, A-Z = 62 values
6 chars = 62^6 = 56 billion combinations ✓
```

**Base62 Encoding — Kaise kaam karta hai:**
```
Base62 alphabet = "0-9a-zA-Z" (62 chars)
ID 0   → "0"
ID 61  → "Z"
ID 62  → "10"  (carry over)
ID 3844 → "100" (62^2)
```
Python-style logic: `base62_encode(n) = alphabet[n % 62] + base62_encode(n//62)` if n > 0

### 6.2 Collision Handling

**Scenario**: Custom alias "my-blog" already exists. Kya karein?

```
┌─────────────────────────────────────────────────────────┐
│  Collision Resolution Strategies                         │
├─────────────────────────────────────────────────────────┤
│  1. Reject + Suggest: "my-blog taken, try my-blog-2"    │
│  2. Append random: my-blog → my-blog-x7k9              │
│  3. Retry with different hash (MD5 approach)            │
└─────────────────────────────────────────────────────────┘
```

**For Base62 + Counter**: Collision impossible — counter unique hai!

**For MD5 truncate**: Collision possible. Solution:
```python
def generate_short_code(long_url):
    hash = md5(long_url)[:6]
    while db.exists(hash):
        hash = md5(long_url + random_salt)[:6]
    return hash
```

### 6.3 Redirect Flow — Caching Strategy

```
User Request: GET /abc123
        │
        ▼
┌───────────────┐
│ Redis Cache   │── HIT ──► Return 302 + long_url (fast!)
│ (hot URLs)    │
└───────┬───────┘
        │ MISS
        ▼
┌───────────────┐
│ Database      │── Found ──► Cache in Redis ──► 302
│ Lookup        │
└───────┬───────┘
        │ Not Found
        ▼
    404 Page
```

**Cache TTL**: Hot URLs — 24 hours. Cold URLs — 1 hour. LRU eviction.

### 6.4 Rate Limiting

**Why?** Abuse prevent — koi 1M URLs create na kar de.

| Strategy | Implementation |
|----------|----------------|
| Per IP | 100 URLs/hour per IP |
| Per User | 1000 URLs/day (if logged in) |
| Token Bucket | Redis-based rate limiter |

```
┌────────────────────────────────────────┐
│  Rate Limit Check (before shorten)      │
│  if redis.incr("limit:ip:"+ip) > 100:  │
│      return 429 Too Many Requests       │
└────────────────────────────────────────┘
```

### 6.5 Analytics Pipeline (Async)

**Sync redirect pe analytics mat karo** — latency badhegi!

```
Redirect Request
      │
      ├──► 302 Response (immediate)
      │
      └──► Fire async event ──► Kafka Topic "clicks"
                                      │
                                      ▼
                              Analytics Workers
                                      │
                                      ▼
                              Click DB / Data Warehouse
```

**Data captured**: timestamp, short_code, IP, user_agent, referrer, country (GeoIP)

### 6.6 Blocklist & Security

**Malicious URL prevention:**
- Phishing domains blocklist (e.g., paypa1.com, g00gle.com)
- Malware scan via VirusTotal API (async, before serving)
- Rate limit per IP to prevent abuse
- CAPTCHA for anonymous shorten (bot prevention)

### 6.7 Same URL Multiple Times

**Idempotency**: Same long URL shorten 2 baar — same short URL return karein ya naya?
- **Option A**: Same URL return (idempotent) — storage save, analytics combined
- **Option B**: Naya URL (unique) — user ko control, separate analytics
- **bit.ly**: Same URL return karta hai (idempotent) — industry standard

### 6.8 Expiration Handling

```
Cron job (daily): SELECT * FROM urls WHERE expires_at < NOW()
  → Soft delete (is_deleted = 1)
  → Redirect pe: Check expires_at, return 410 Gone if expired
```

---

## 7. Bottlenecks and Solutions

| Bottleneck | Problem | Solution |
|------------|---------|----------|
| **Single DB** | Write limit, single point of failure | Sharding by short_code hash |
| **Counter single point** | ID generation bottleneck | Range-based: Each server gets range (1-1M, 1M-2M...) |
| **Cache stampede** | Popular URL expires, 10K requests db pe | Probabilistic early expiration, or lock |
| **Analytics overload** | Clicks DB write-heavy | Batch writes, use Cassandra/TimescaleDB |
| **Redirect latency** | DB/cache slow | CDN edge caching for top 1% URLs |

### Counter Sharding (Range-based)

```
┌─────────────────────────────────────────────────────────┐
│  Server 1: IDs 1 - 1,000,000        (used: 500K)        │
│  Server 2: IDs 1M - 2,000,000       (used: 200K)        │
│  Server 3: IDs 2M - 3,000,000       (used: 0)           │
│  ...                                                    │
│  When Server 1 exhausts → request new range from ZK     │
└─────────────────────────────────────────────────────────┘
```

### Cache Stampede — Detailed Solution

**Problem**: Popular URL (e.g., bit.ly/xyz) cache se expire hota hai. Same second mein 10,000 requests DB pe aa jate hain!

**Solutions:**
1. **Probabilistic Early Expiration**: TTL ke 80% pe, 10% requests ko refresh bhejo. Spread load.
2. **Lock/Mutex**: First request lock le, DB fetch kare, cache update kare. Baaki wait kare.
3. **Never Expire Hot URLs**: Top 1% URLs ka TTL = infinity (manual invalidation only)
4. **Background Refresh**: TTL 90% pe async worker refresh trigger kare

### Read Replica Strategy

```
                    ┌─────────────┐
                    │   Primary   │  ← All writes (shorten)
                    │   (Master)  │
                    └──────┬──────┘
                           │ Replication
         ┌─────────────────┼─────────────────┐
         ▼                 ▼                 ▼
   ┌──────────┐      ┌──────────┐      ┌──────────┐
   │ Replica 1│      │ Replica 2│      │ Replica 3│  ← Redirect reads
   └──────────┘      └──────────┘      └──────────┘
```

---

## 8. Scaling Improvements

```
                    SCALING EVOLUTION
                    
Phase 1: Single server + MySQL
    │
    ▼
Phase 2: + Redis cache (hot URLs)
    │
    ▼
Phase 3: + Read replicas (redirect reads)
    │
    ▼
Phase 4: + Sharding (by short_code hash)
    │
    ▼
Phase 5: + CDN (edge cache top URLs)
    │
    ▼
Phase 6: + Kafka + Analytics cluster
```

### Sharding Strategy

```
short_code = "abc123"
hash = hash(short_code) % 256  →  Shard 42
Route to Shard 42's DB
```

**Consistent hashing** use karo taaki add/remove shard pe minimal rebalancing.

---

## 9. Trade-offs Discussed

| Decision | Option A | Option B | Choice | Why |
|----------|----------|----------|--------|-----|
| **301 vs 302** | 301 Permanent | 302 Temporary | 302 | Analytics track karna hai |
| **Hash: Counter vs MD5** | Counter+Base62 | MD5+truncate | Counter | No collision, shorter URLs |
| **DB: SQL vs NoSQL** | MySQL | Cassandra | Start SQL, scale to NoSQL | SQL simpler initially |
| **Sync vs Async Analytics** | Sync (in redirect) | Async (Kafka) | Async | Latency critical for redirect |
| **Cache: Write-through vs Lazy** | Write-through | Lazy (on read) | Lazy | Redirect read-heavy, writes rare |

---

## 10. Interview Questions (Practice!)

1. **Custom alias collision** — Same user same alias dobara use kare? (Idempotent — return existing)
2. **Malicious URLs** — Phishing links shorten ho sakte? (Blocklist, malware scan)
3. **Redirect loop** — bit.ly/xyz points to bit.ly/abc? (Detect cycle, reject)
4. **Expired URL** — Delete physically ya soft delete? (Soft delete — analytics preserve)
5. **Internationalization** — Unicode in custom alias? (Punycode encode)
6. **Duplicate long URL** — 2 users same URL shorten karein? (Different short codes — user isolation)
7. **Cache invalidation** — URL update/delete? (Invalidate Redis key, CDN purge)
8. **Geographic routing** — India user ko India server? (CDN edge, or geo-based LB)

---

## 11. 1 Minute Recall Block

```
┌─────────────────────────────────────────────────────────────────┐
│  URL SHORTENER — 60 SECOND RECALL                                │
├─────────────────────────────────────────────────────────────────┤
│  1. REQUIREMENTS: Shorten, Redirect, Custom, Expiry, Analytics   │
│  2. ESTIMATE: 100M URLs/mo, 10:1 R:W, Cache critical             │
│  3. HASH: Base62(Counter) — no collision, 6 chars = 56B combos   │
│  4. REDIRECT: 302 (not 301) — analytics ke liye                  │
│  5. CACHE: Redis hot URLs, CDN for top 1%                        │
│  6. ANALYTICS: Async Kafka pipeline, never block redirect        │
│  7. SCALE: Shard by short_code, range-based counter              │
└─────────────────────────────────────────────────────────────────┘
```

### 5 Bullet Memory Hooks

1. **Base62 + Counter** — Collision-free, short, counter from Redis/ZK
2. **302 not 301** — Temporary = server hit = analytics
3. **Cache hot URLs** — 99% traffic redirect, Redis must
4. **Async analytics** — Kafka fire-and-forget, never sync
5. **Shard by hash** — short_code hash % N for DB sharding

---

## Appendix: Quick Reference Tables

### Hash Algorithm Comparison (Detailed)

| Algorithm | Length | Collision Risk | Distributed? | Implementation |
|-----------|--------|----------------|--------------|----------------|
| Base62(Counter) | 6-7 chars | None | No (counter central) | Redis INCR, ZK |
| MD5[:6] | 6 chars | 1 in 56B (birthday) | Yes | Stateless |
| SHA256[:8] | 8 chars | Negligible | Yes | Stateless |
| UUID | 22 chars | None | Yes | Too long |
| NanoID | 21 chars | None | Yes | Configurable |

### CDN Caching Headers for Redirect

```
Cache-Control: private, max-age=3600
  → private: Don't cache at shared CDN (user-specific? No, but analytics)
  → max-age=3600: Browser can cache 1 hr
  → For bit.ly: Often no-cache to get analytics every time
```

### Monitoring Metrics

| Metric | Alert Threshold | Action |
|--------|-----------------|--------|
| Redirect latency p99 | > 200ms | Scale cache, check DB |
| Shorten latency p99 | > 500ms | Check counter, DB |
| 404 rate | > 1% | Check expiration, data loss |
| 429 rate | > 5% | Relax rate limit or scale |
| Cache hit ratio | < 80% | Increase cache size, TTL |

### Interview Tips — URL Shortener

1. **Start with requirements** — Functional (shorten, redirect, custom, analytics) + Non-functional (latency, scale)
2. **Estimate first** — 100M URLs/mo, 10:1 R:W → Cache is king
3. **Hash choice** — Base62+Counter vs MD5: Counter wins (no collision)
4. **301 vs 302** — Always mention: 302 for analytics, 301 for SEO
5. **Scale path** — Cache → Read replicas → Sharding → CDN
6. **Don't forget** — Rate limiting, blocklist, expiration, idempotency

---

*End of URL Shortener Design — bit.ly jaisa system ab tum bana sakte ho!*
