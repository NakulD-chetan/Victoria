import { memo, useCallback, useMemo } from 'react';
import { useNewCanvasStore } from './state/store';
import { CODE_LANGS } from './widgets/widget-registry';
import { CODE_TEMPLATES } from './widgets/code-templates';
import { saveDefaults } from './widgets/widget-defaults';
import CodeLangDropdown from './widgets/CodeLangDropdown';

/*
 * WidgetPropertiesPanel — Excalidraw-style right-side inspector.
 *
 * Visible only when exactly one element is selected and it's a widget.
 * Edits flow two ways:
 *   1. Update the selected element via commitElements.
 *   2. Mirror the change to localStorage via saveDefaults so the next
 *      widget of the same type spawns with the same configuration.
 *
 * Keep this dumb and react-like: no refs into the engine, no canvas math.
 * The panel reads from the store and writes back via commitElements; the
 * widget components re-render from the new widgetData.
 */

const NOTE_COLORS = ['#fefce8', '#bbf7d0', '#bae6fd', '#fecaca', '#ddd6fe', '#e5e7eb'];
const NOTE_TEXT_COLORS = ['#0f172a', '#1e293b', '#7f1d1d', '#1e3a8a', '#14532d', '#92400e'];
const CODE_CHROMES = ['#0b1220', '#111827', '#0f172a', '#1e1b4b', '#082f49', '#1e293b'];
const ARRAY_CHROMES = ['#1e293b', '#0f172a', '#1e1b4b', '#111827', '#0b1220', '#082f49'];
const AGENT_CHROMES = ['#12141b', '#161a24', '#111827', '#1b1d2a', '#0f172a', '#1e293b'];
const AGENT_ACCENTS = ['#7c83ff', '#22c55e', '#38bdf8', '#f59e0b', '#f97316', '#ec4899'];
const FRAME_STROKES = ['#94a3b8', '#cbd5e1', '#475569', '#6366F1', '#10b981', '#ef4444'];
const DATA_WIDGET_TYPES = new Set(['json', 'csv', 'linked-list', 'stack', 'queue', 'tree', 'hash-map']);

const FONT_FAMILIES = [
  { id: 'mono', label: 'Monospace', value: 'ui-monospace, SFMono-Regular, Menlo, monospace, Consolas, "Courier New", monospace' },
  { id: 'sans', label: 'Sans serif', value: 'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  { id: 'serif', label: 'Serif', value: 'ui-serif, Georgia, "Times New Roman", serif' },
  { id: 'fira', label: 'Fira Code', value: '"Fira Code", "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace' },
  { id: 'jetbrains', label: 'JetBrains Mono', value: '"JetBrains Mono", "Fira Code", ui-monospace, SFMono-Regular, Menlo, monospace' },
];

function findFontId(value) {
  if (!value) return 'mono';
  const hit = FONT_FAMILIES.find((f) => f.value === value);
  return hit ? hit.id : 'custom';
}

function Section({ title, children }) {
  return (
    <div className="nc-props__section">
      <div className="nc-props__section-title">{title}</div>
      <div className="nc-props__section-body">{children}</div>
    </div>
  );
}

function ColorRow({ label, value, options, onChange }) {
  return (
    <div className="nc-props__row">
      <span className="nc-props__row-label">{label}</span>
      <div className="nc-props__swatches" role="group" aria-label={label}>
        {options.map((c) => (
          <button
            key={c}
            type="button"
            className={`nc-props__swatch${c === value ? ' is-active' : ''}`}
            style={{ background: c }}
            onClick={() => onChange(c)}
            aria-label={`Use color ${c}`}
            aria-pressed={c === value}
          />
        ))}
        <label className="nc-props__swatch nc-props__swatch--custom" aria-label="Custom color">
          <input
            type="color"
            value={typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value) ? value : '#000000'}
            onChange={(e) => onChange(e.target.value)}
          />
        </label>
      </div>
    </div>
  );
}

function NumberRow({ label, value, min, max, step = 1, suffix, onChange }) {
  return (
    <div className="nc-props__row">
      <span className="nc-props__row-label">{label}</span>
      <div className="nc-props__num">
        <button
          type="button"
          className="nc-props__num-btn"
          onClick={() => onChange(Math.max(min ?? -Infinity, (Number(value) || 0) - step))}
          aria-label={`Decrease ${label}`}
        >
          −
        </button>
        <input
          className="nc-props__num-input"
          type="number"
          min={min}
          max={max}
          step={step}
          value={value ?? ''}
          onChange={(e) => {
            const n = Number(e.target.value);
            if (Number.isFinite(n)) onChange(n);
          }}
        />
        <button
          type="button"
          className="nc-props__num-btn"
          onClick={() => onChange(Math.min(max ?? Infinity, (Number(value) || 0) + step))}
          aria-label={`Increase ${label}`}
        >
          +
        </button>
        {suffix && <span className="nc-props__num-suffix">{suffix}</span>}
      </div>
    </div>
  );
}

function FontFamilyRow({ value, onChange }) {
  const currentId = findFontId(value);
  return (
    <div className="nc-props__row nc-props__row--col">
      <span className="nc-props__row-label">Font family</span>
      <div className="nc-props__chips">
        {FONT_FAMILIES.map((f) => (
          <button
            key={f.id}
            type="button"
            className={`nc-props__chip${f.id === currentId ? ' is-active' : ''}`}
            style={{ fontFamily: f.value }}
            onClick={() => onChange(f.value)}
            title={f.label}
          >
            {f.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function WidgetPropertiesPanelImpl() {
  const selection = useNewCanvasStore((s) => s.selection);
  const scenes = useNewCanvasStore((s) => s.scenes);
  const activeId = useNewCanvasStore((s) => s.activeId);
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const clearSelection = useNewCanvasStore((s) => s.clearSelection);

  const selected = useMemo(() => {
    if (!selection || selection.size !== 1) return null;
    const id = [...selection][0];
    const scene = scenes[activeId];
    if (!scene) return null;
    const el = scene.elements.find((e) => e.id === id && !e.isDeleted);
    if (!el || el.type !== 'widget') return null;
    return el;
  }, [selection, scenes, activeId]);

  const updateData = useCallback((patch) => {
    if (!selected) return;
    commitElements((els) => els.map((e) => e.id === selected.id
      ? { ...e, widgetData: { ...e.widgetData, ...patch } }
      : e));
    saveDefaults(selected.widgetType, patch);
  }, [commitElements, selected]);

  const updateStyle = useCallback((patch) => {
    if (!selected) return;
    commitElements((els) => els.map((e) => e.id === selected.id
      ? { ...e, style: { ...e.style, ...patch } }
      : e));
    const mirror = {};
    if ('stroke' in patch) mirror.strokeColor = patch.stroke;
    if ('strokeWidth' in patch) mirror.strokeWidth = patch.strokeWidth;
    if (Object.keys(mirror).length) saveDefaults(selected.widgetType, mirror);
  }, [commitElements, selected]);

  if (!selected) return null;
  const data = selected.widgetData || {};
  const style = selected.style || {};

  return (
    <aside className="nc-props" aria-label={`${selected.widgetType} properties`}>
      <header className="nc-props__head">
        <span className="nc-props__title">
          {selected.widgetType
            .split('-')
            .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
            .join(' ')}
        </span>
        <div className="nc-props__head-meta">
          <span className="nc-props__sub">{Math.round(selected.w)} × {Math.round(selected.h)}</span>
          <button
            type="button"
            className="nc-props__close"
            onClick={clearSelection}
            aria-label="Close properties"
            title="Close properties"
          >
            ×
          </button>
        </div>
      </header>

      {selected.widgetType === 'code' && (
        <>
          <Section title="Language">
            <CodeLangDropdown
              value={data.language || 'cpp'}
              options={CODE_LANGS}
              onChange={(lang) => {
                const code = CODE_TEMPLATES[lang] || data.code || '';
                updateData({ language: lang, code, output: '' });
              }}
            />
          </Section>
          <Section title="Typography">
            <FontFamilyRow value={data.fontFamily} onChange={(v) => updateData({ fontFamily: v })} />
            <NumberRow label="Font size" value={data.fontSize ?? 13} min={8} max={32} suffix="px"
              onChange={(v) => updateData({ fontSize: v })} />
          </Section>
          <Section title="Background">
            <ColorRow label="Editor surface" value={data.chromeBg || '#0b1220'} options={CODE_CHROMES}
              onChange={(c) => updateData({ chromeBg: c })} />
          </Section>
          <Section title="Frame">
            <ColorRow label="Outline color" value={style.stroke || '#94a3b8'} options={FRAME_STROKES}
              onChange={(c) => updateStyle({ stroke: c })} />
            <NumberRow label="Outline width" value={style.strokeWidth ?? 1} min={0} max={6} suffix="px"
              onChange={(v) => updateStyle({ strokeWidth: v })} />
          </Section>
        </>
      )}

      {selected.widgetType === 'note' && (
        <>
          <Section title="Background">
            <ColorRow label="Note color" value={data.color || '#fefce8'} options={NOTE_COLORS}
              onChange={(c) => updateData({ color: c })} />
          </Section>
          <Section title="Text">
            <ColorRow label="Text color" value={data.textColor || '#0f172a'} options={NOTE_TEXT_COLORS}
              onChange={(c) => updateData({ textColor: c })} />
            <FontFamilyRow value={data.fontFamily} onChange={(v) => updateData({ fontFamily: v })} />
            <NumberRow label="Font size" value={data.fontSize ?? 14} min={10} max={32} suffix="px"
              onChange={(v) => updateData({ fontSize: v })} />
          </Section>
          <Section title="Frame">
            <ColorRow label="Outline color" value={style.stroke || '#94a3b8'} options={FRAME_STROKES}
              onChange={(c) => updateStyle({ stroke: c })} />
            <NumberRow label="Outline width" value={style.strokeWidth ?? 1} min={0} max={6} suffix="px"
              onChange={(v) => updateStyle({ strokeWidth: v })} />
          </Section>
        </>
      )}

      {selected.widgetType === 'array' && (
        <>
          <Section title="Background">
            <ColorRow label="Surface" value={data.chromeBg || '#1e293b'} options={ARRAY_CHROMES}
              onChange={(c) => updateData({ chromeBg: c })} />
          </Section>
          <Section title="Values">
            <ColorRow label="Value color" value={data.valueColor || '#e2e8f0'} options={NOTE_TEXT_COLORS}
              onChange={(c) => updateData({ valueColor: c })} />
            <NumberRow label="Value font size" value={data.valueFontSize ?? 13} min={9} max={28} suffix="px"
              onChange={(v) => updateData({ valueFontSize: v })} />
          </Section>
          <Section title="Frame">
            <ColorRow label="Outline color" value={style.stroke || '#94a3b8'} options={FRAME_STROKES}
              onChange={(c) => updateStyle({ stroke: c })} />
            <NumberRow label="Outline width" value={style.strokeWidth ?? 1} min={0} max={6} suffix="px"
              onChange={(v) => updateStyle({ strokeWidth: v })} />
          </Section>
        </>
      )}

      {selected.widgetType === 'agent' && (
        <>
          <Section title="Appearance">
            <ColorRow label="Surface" value={data.chromeBg || '#12141b'} options={AGENT_CHROMES}
              onChange={(c) => updateData({ chromeBg: c })} />
            <ColorRow label="Accent" value={data.accentColor || '#7c83ff'} options={AGENT_ACCENTS}
              onChange={(c) => updateData({ accentColor: c })} />
          </Section>
          <Section title="Frame">
            <ColorRow label="Outline color" value={style.stroke || '#94a3b8'} options={FRAME_STROKES}
              onChange={(c) => updateStyle({ stroke: c })} />
            <NumberRow label="Outline width" value={style.strokeWidth ?? 1} min={0} max={6} suffix="px"
              onChange={(v) => updateStyle({ strokeWidth: v })} />
          </Section>
        </>
      )}

      {DATA_WIDGET_TYPES.has(selected.widgetType) && (
        <Section title="Frame">
          <ColorRow label="Outline color" value={style.stroke || '#94a3b8'} options={FRAME_STROKES}
            onChange={(c) => updateStyle({ stroke: c })} />
          <NumberRow label="Outline width" value={style.strokeWidth ?? 1} min={0} max={6} suffix="px"
            onChange={(v) => updateStyle({ strokeWidth: v })} />
        </Section>
      )}

      <footer className="nc-props__foot">
        <span>Saved as default</span>
      </footer>
    </aside>
  );
}

export default memo(WidgetPropertiesPanelImpl);
