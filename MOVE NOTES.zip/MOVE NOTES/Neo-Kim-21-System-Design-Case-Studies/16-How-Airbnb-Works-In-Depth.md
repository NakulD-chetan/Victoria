# How Airbnb Works - In Depth (Easy Language)

> Companion to: [16-How-Airbnb-Works.md](16-How-Airbnb-Works.md)

---

## The ONE Problem That Matters: Double Booking

### The Nightmare Scenario

```
Hotel has 1 room left for Dec 25.

User A (Mumbai): Clicks "Book" at 10:00:00.000 AM
User B (NYC):    Clicks "Book" at 10:00:00.001 AM

Both see: "1 room available" ← the database hasn't updated yet!
Both get: "Booking confirmed!" ← BOTH booked the SAME room!

Now 2 people show up at the same hotel room on Christmas.
One of them has no room. Angry customer, refund, bad reviews.
```

This is the **double-booking problem** and it's the #1 challenge in any booking system.

---

## Why Keep Reservation + Inventory in the SAME Database

### The Wrong Approach: Two Databases

```
BAD architecture:
  Reservations Database (Service A) ←→ Inventory Database (Service B)
  
  Booking flow:
  1. Check inventory DB: "Is room available?" → YES
  2. Create reservation in reservation DB
  3. Update inventory DB: "Mark room as booked"
  
  Problem: Steps 2 and 3 are in DIFFERENT databases!
  What if step 2 succeeds but step 3 fails?
    → Reservation exists but inventory still shows "available"
    → Another person can book the same room!
  
  This is the "distributed transaction problem" — very hard to solve.
```

### The Right Approach: Single Database

```
GOOD architecture:
  PostgreSQL Database (has BOTH tables):
    - reservations table
    - inventory table
  
  Booking flow (single ACID transaction):
  BEGIN TRANSACTION;
    SELECT * FROM inventory WHERE room_id = 'R1' AND date = 'Dec 25' FOR UPDATE;
    -- Row is now LOCKED. Nobody else can modify it.
    
    -- Check: is the room available?
    -- If YES:
    INSERT INTO reservations (user, room, date) VALUES ('User A', 'R1', 'Dec 25');
    UPDATE inventory SET available = FALSE WHERE room_id = 'R1' AND date = 'Dec 25';
    
  COMMIT;
  -- Both operations succeed or both fail. NEVER one without the other.
```

**ACID guarantees:**
- **Atomicity**: Both operations happen or neither does
- **Consistency**: Database always reflects valid state
- **Isolation**: Other transactions can't see partial results
- **Durability**: Once committed, data survives crashes

---

## Two Locking Strategies

### Pessimistic Locking (SELECT FOR UPDATE)

```
"Lock the row BEFORE reading it"

User A: SELECT FOR UPDATE → LOCKS room R1 for Dec 25
User B: SELECT FOR UPDATE → WAITS (row is locked by A)

User A: books the room → COMMIT → lock released
User B: row is now available → reads: "room NOT available" → booking rejected

Pros: Simple, guaranteed no conflicts
Cons: Users wait in line (slower when many concurrent bookings)
```

**Analogy**: Taking a number at the deli counter. Only one person gets served at a time.

### Optimistic Locking (Version Check)

```
"Don't lock anything, just check before committing"

Room R1 row: { available: true, version: 5 }

User A: reads room R1 (version: 5)
User B: reads room R1 (version: 5) at the same time

User A: UPDATE ... WHERE room_id = 'R1' AND version = 5 → SUCCESS! (version → 6)
User B: UPDATE ... WHERE room_id = 'R1' AND version = 5 → FAILS! (version is now 6, not 5)
User B: retry → reads again (version 6) → room not available → rejected

Pros: No waiting, faster when conflicts are rare
Cons: Must handle retries, wasted work on conflicts
```

**Analogy**: Two people editing a Google Doc paragraph. The first to save wins. The second sees "someone else made changes" and must re-read.

### When to Use Which?

```
Pessimistic locking: Use when conflicts are FREQUENT
  → Popular hotel on New Year's Eve (many people booking same room)
  → Better to make people wait than waste work

Optimistic locking: Use when conflicts are RARE
  → Random hotel on a Tuesday (unlikely two people book exact same room)
  → Faster because most attempts succeed without waiting
```

---

## Idempotency Keys - Preventing Double UI Clicks

```
User clicks "Book Now" button.
App is slow. User panics. Clicks again. And again.

Without idempotency:
  Click 1 → Booking created (reservation_001)
  Click 2 → Booking created (reservation_002)  ← DUPLICATE!
  Click 3 → Booking created (reservation_003)  ← ANOTHER DUPLICATE!
  
  User is charged 3 times for the same room!

With idempotency key:
  Click 1 → key: "booking_abc123" → Booking created (reservation_001)
  Click 2 → key: "booking_abc123" → "Already processed, here's reservation_001"
  Click 3 → key: "booking_abc123" → "Already processed, here's reservation_001"
  
  Only ONE booking, regardless of how many clicks.
```

---

## The Full Architecture

```
┌──────────┐
│  Client  │
└────┬─────┘
     ↓
┌──────────────┐
│ API Gateway  │ ← Auth, rate limiting, routing
└────┬─────────┘
     ↓
┌────┴──────────────────────────────────────┐
│              Service Layer                 │
│                                           │
│ Hotel Service → search, listings, details │
│ Rate Service → pricing, discounts         │
│ Reservation Service → THE CRITICAL ONE    │
│ Payment Service → charges, refunds        │
│ Notification Service → emails, push       │
│ Search Service → geo search, filters      │
└────┬──────────────────────────────────────┘
     ↓
┌────┴──────────────────────────────────────┐
│           Data Layer                       │
│ PostgreSQL → reservations + inventory     │
│              (ACID transactions!)          │
│ Redis → cache (search results, hot data)  │
│ Elasticsearch → full-text + geo search    │
│ CDN → hotel images                        │
└───────────────────────────────────────────┘
```

### Scale Numbers

```
~1.5M bookings/day ÷ 86,400 seconds = ~17 write TPS (modest!)
~1,000 read QPS (searches, listing views)
~85K hotels, ~4.3M rooms
~620M inventory rows (~62 GB)

The write load is manageable for a single PostgreSQL instance.
The read load needs Redis caching + read replicas.
```

---

## Consistency Model

```
STRONG consistency (required for):
  → Inventory availability (must be real-time accurate)
  → Reservation records (booking must be confirmed or rejected definitively)
  → Payment records (must match actual charges)

EVENTUAL consistency (acceptable for):
  → Search results (showing a hotel that was just booked is OK for a few seconds)
  → Hotel ratings (delay of minutes is fine)
  → Notification delivery (slight delay is acceptable)
```

---

## Revision Flashcards

**Q: Why must reservation and inventory be in the same database?**
A: To use local ACID transactions. If they're in separate databases, you need distributed transactions (complex, error-prone). A single DB guarantees both operations succeed or both fail.

**Q: What is pessimistic locking?**
A: Lock the row before reading it (SELECT FOR UPDATE). Other transactions wait until the lock is released. Simple but slower under high contention.

**Q: What is optimistic locking?**
A: Don't lock, just check a version number before committing. If version changed since you read it, your update fails and you retry. Faster when conflicts are rare.

**Q: How do idempotency keys prevent double bookings from UI clicks?**
A: Each booking request carries a unique key. If the same key is sent twice, the server returns the original result without creating a duplicate.

**Q: Why is the write load modest (~17 TPS)?**
A: 1.5M bookings/day spread over 86,400 seconds. Unlike Twitter (thousands of writes/sec), hotel bookings are relatively infrequent. A single PostgreSQL instance can handle this.
