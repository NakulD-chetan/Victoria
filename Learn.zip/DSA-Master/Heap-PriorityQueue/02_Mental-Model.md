# Heap — Mental Model

> **Permanent Recall:** Heap = "VIP line." Highest priority served first. Top-K = "bouncer at the door" keeping only the best K. Two-heap = "split the stream into two halves." Merge K = "tournament bracket" — always pick the current champion.

---

## How FAANG Engineers Think About Heap Problems

1. **"Who gets served first?"** — Define priority (min, max, custom)
2. **"Do I need the best K, or just the single best?"** — Top-K vs single extract
3. **"Is data static or streaming?"** — Streaming → heap; static → maybe quickselect
4. **"Am I merging/combining multiple sorted sources?"** — Min-heap of heads
5. **"Do I need to track median as elements arrive?"** — Two heaps

---

## The "VIP Line" Analogy

```
HEAP = NIGHTCLUB VIP LINE

  • Highest priority (VIP) gets in first
  • New person arrives → compared to current "threshold"
  • Min-heap: "smallest VIP" at front (we serve the least important of our VIPs)
  • Max-heap: "largest VIP" at front (we serve the most important first)

  Real heap: Root = whoever is "next in line" by priority
  Insert: New person joins, gets compared; may cut in line (bubble up)
  Extract: Serve the person at front; next person moves up (bubble down)
```

---

## Top-K: "Bouncer at the Door"

```
MENTAL MODEL: Club has capacity K. Only the "best" K people get in.

  Min-heap of size K = the bouncer's list of "who's inside"
  Root = the WEAKEST person currently inside (minimum of our K)

  New person arrives:
  • If heap size < K: Let them in (push)
  • If heap size == K:
    - If new person is BETTER than root (e.g., larger for "K largest"):
      → Kick out root (the weakest), let new person in
    - Else: Reject (don't even consider)

  After processing all: Everyone in the heap = Top K
```

```
ASCII: Top-K "Bouncer" Flow

  Stream: [3, 1, 4, 1, 5, 9, 2, 6]  →  Top 3 largest

  Heap (min-heap, size 3):
  
  Step 1-3: [1, 3, 4]     ← first 3 in
            ┌───┐
            │ 1 │  ← bouncer: "1 is weakest inside"
            └───┘
  
  Step 4:   5 > 1  →  kick 1, add 5  →  [3, 4, 5]
  Step 5:   9 > 3  →  kick 3, add 9  →  [4, 5, 9]
  Step 6:   2 < 4  →  reject 2
  Step 7:   6 > 4  →  kick 4, add 6  →  [5, 6, 9]

  Final: Top 3 = [5, 6, 9]
```

---

## Two-Heap: "Split the Stream into Two Halves"

```
MENTAL MODEL: Median = middle element. Split incoming stream into:
  • LEFT half (smaller elements)  →  max-heap (we need the max of left = rightmost of left)
  • RIGHT half (larger elements)  →  min-heap (we need the min of right = leftmost of right)

  Median lives at the boundary between the two halves.
```

```
ASCII: Two-Heap Median

  Numbers:  [2, 4, 7, 1, 5, 3, 6]
  Sorted:   [1, 2, 3, 4, 5, 6, 7]
  Median:   4 (middle)

  max_heap (left):  [1, 2, 3, 4]   →  top = 4
  min_heap (right): [5, 6, 7]      →  top = 5

  Invariant: All in max_heap ≤ all in min_heap
  Balance:   |max_heap.size - min_heap.size| ≤ 1

  Odd count:  median = top of larger heap
  Even count: median = (max_heap.top + min_heap.top) / 2
```

---

## Merge K Sorted Lists: "Tournament Bracket"

```
MENTAL MODEL: K lists = K players. Each round, we pick the "current smallest" (champion).
  Min-heap holds the "current head" of each list.
  Pop smallest → that's our next output → push the next element from that list.

  Like a tournament: always compare the "current best" from each list.
```

```
ASCII: Merge K Sorted — Tournament

  List 0: [1, 4, 7]
  List 1: [2, 5, 8]
  List 2: [3, 6, 9]

  Initial heap: [(1,0), (2,1), (3,2)]  ← (value, list_id)
  
  Pop 1  →  output 1  →  push (4, 0)   Heap: [(2,1), (3,2), (4,0)]
  Pop 2  →  output 2  →  push (5, 1)   Heap: [(3,2), (4,0), (5,1)]
  Pop 3  →  output 3  →  push (6, 2)   ...
  ...

  Output: [1, 2, 3, 4, 5, 6, 7, 8, 9]
```

---

## Decision Triggers

| Trigger Phrase | Mental Model | Heap Setup |
|----------------|-------------|------------|
| "Top K largest" | Bouncer, keep best K | Min-heap size K, evict when new > root |
| "Top K smallest" | Bouncer, keep smallest K | Max-heap size K, evict when new < root |
| "Kth largest" | Same as Top-K; at end root = Kth | Min-heap size K |
| "Median of stream" | Split into two halves | Max-heap (left) + Min-heap (right) |
| "Merge K sorted" | Tournament of list heads | Min-heap of (val, list_idx) |
| "K closest points" | Keep K closest (smallest distances) | Max-heap size K by distance |
| "Task scheduler" | Pick most frequent first | Max-heap by frequency |
| "Kth largest in stream" | Bouncer; root = Kth at any time | Min-heap size K |

---

## ASCII: Top-K Min-Heap Invariant

```mermaid
flowchart TD
    A[New element x arrives]
    A --> B{x > root?}
    B -->|Yes| C[pop root, push x]
    B -->|No| D[ignore]
    C --> E[x is in top K]
    D --> F[x is not in top K]
    style B fill:#ffd43b,color:#000
    style C fill:#51cf66,color:#fff
    style D fill:#e03131,color:#fff
```

<details><summary>ASCII fallback</summary>

```
K LARGEST — Min-heap of size K

  Root = smallest of our K candidates = Kth largest overall

  ┌─────────────────────────────────────┐
  │  Heap (min-heap): [a, b, c, ...]     │
  │  Root = min(a,b,c,...) = Kth largest │
  │  All elements in heap ≥ root         │
  │  So: root is the "threshold"         │
  └─────────────────────────────────────┘

  New element x:
  if x > root  →  x is in top K, root is not  →  pop root, push x
  if x ≤ root  →  x is not in top K  →  ignore
```

</details>

---

## ASCII: Two-Heap Balance Rules

```mermaid
flowchart TD
    S1[1. Add to max_heap first left half]
    S2[2. If max_heap.top > min_heap.top: swap tops]
    S3[3. Rebalance: if max-min > 1, move one element]
    S1 --> S2 --> S3
    style S1 fill:#339af0,color:#fff
    style S2 fill:#ffd43b,color:#000
    style S3 fill:#51cf66,color:#fff
```

<details><summary>ASCII fallback</summary>

```
ADDING to two heaps:

  1. Add to max_heap first (left half)
  2. If max_heap.top() > min_heap.top(): swap tops (maintain order)
  3. Rebalance sizes: if |max - min| > 1, move one element

  ┌──────────────┐     ┌──────────────┐
  │  max_heap    │  ≤  │  min_heap    │
  │  (left)      │     │  (right)     │
  │  smaller     │     │  larger      │
  └──────────────┘     └──────────────┘
         ↑                     ↑
    max of left           min of right
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL MODEL:     Heap = VIP line; highest priority first
TOP-K:            Bouncer at door; min-heap of size K; evict root when better arrives
TWO-HEAP:         Split stream; max (left) + min (right); median at boundary
MERGE K:           Tournament; min-heap of list heads; pop smallest, push next
K LARGEST:         Min-heap K; root = Kth largest
K SMALLEST:        Max-heap K; root = Kth smallest
TRIGGER:           "Top K" / "Kth" → bouncer; "Median stream" → two halves
INTERVIEW LINE:    "I'll use a min-heap of size K as a bouncer — only elements
                    larger than the smallest of our K get in."
```
