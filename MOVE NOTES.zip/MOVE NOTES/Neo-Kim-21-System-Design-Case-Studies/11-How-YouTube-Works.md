# How YouTube Works - System Design

> Source: https://newsletter.systemdesign.one/p/youtube-system-design

## One-Line Summary
YouTube processes 500+ hours of uploads per minute and serves billions of streams daily using a transcoding pipeline, CDN-based adaptive bitrate streaming, and pre-signed URLs to offload video data from application servers.

## Key Requirements

### Functional
- Upload videos (up to 256 GB, multipart with resume)
- Stream videos (adaptive bitrate, first frame <500ms)
- Search videos (by title, description, pagination)
- Track watch progress

### Non-Functional
- 1M uploads/day, 100M DAU, 100:1 read-write ratio
- Eventual consistency for new uploads (acceptable delay)
- 99.9% uptime
- Low latency streaming, minimal buffering
- Bandwidth optimization for slow networks

## High-Level Architecture

```
Client (Web/Mobile)
    |
    ├── Upload: Pre-signed URL → directly to S3 (bypasses app server)
    |
    ├── Stream: CDN → Adaptive Bitrate (HLS/DASH) → client player
    |
    └── API calls: App Server (metadata, search, progress)
              |
    +---------+---------+
    |         |         |
  SQL DB   Search    Transcoding
 (metadata) Index    Pipeline
              |         |
           Elastic   Message Queue
           Search       |
                    Transcoder Workers
                        |
                    S3 (multiple resolutions)
                        |
                      CDN
```

## Core Components Deep Dive

### 1. Upload Flow (Pre-Signed URLs)
- Client calls `POST /v1/videos` → server returns pre-signed S3 URL
- Client uploads DIRECTLY to S3 (app server is never the bottleneck)
- Supports multipart upload for large files (256 GB max)
- Resume interrupted uploads without data loss
- After upload completes, transcoding pipeline kicks off

### 2. Transcoding Pipeline
- Each upload gets converted into 6+ resolutions (240p to 4K)
- Each resolution split into hundreds of small segments
- Processing is asynchronous (10-30 minutes acceptable)
- Workers pull from message queue, transcode, store back to S3
- Multiple output formats: MP4, HLS segments, DASH manifests

### 3. Streaming (Adaptive Bitrate - ABR)
- Client requests video → server returns **manifest file URL**
- Manifest file lists all available resolutions and segment URLs
- Client player downloads segments from CDN
- **Adaptive**: quality switches automatically based on network speed
- First frame target: under 500ms (CDN makes this possible)

### 4. CDN (Content Delivery Network)
- Video segments cached at edge locations worldwide
- Popular videos = high cache hit ratio
- Reduces latency regardless of user location
- Handles the massive egress bandwidth

### 5. Search
- Elasticsearch indexes video titles and descriptions
- Cursor-based pagination (not offset) → scalable for millions of results
- Each page returns `next_cursor` token for fetching next batch

### 6. Watch Progress Tracking
- `POST /v1/progress/{video_id}` → fire-and-forget (no wait for confirmation)
- Millions of writes/sec → needs high-throughput DB (DynamoDB)
- Used for "continue watching" and analytics

## API Design

```
# Upload initiation
POST /v1/videos
Response: { video_id, upload_url (pre-signed S3), expires_in }

# Stream video
GET /v1/videos/{video_id}
Response: { title, description, manifest_url, cdn_base_url, resolutions[] }

# Update watch progress
POST /v1/progress/{video_id}
Body: { user_id, timestamp_seconds }

# Search
GET /v1/search?q=keyword&next_cursor=abc
Response: { results[], next_cursor, total_count }
```

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Pre-signed URLs for upload | App servers never handle video data → no bottleneck |
| Async transcoding | 10-30 min acceptable; decouple upload from processing |
| Adaptive bitrate (HLS/DASH) | Auto quality switch for varying networks |
| CDN for streaming | Low latency worldwide, massive bandwidth |
| Cursor-based pagination | Scalable (no "skip 10M rows" problem) |
| Fire-and-forget progress | Millions of writes/sec, speed over consistency |
| DynamoDB for progress | High-throughput, simple key-value writes |

## Scaling Strategies

1. **Pre-signed URLs**: upload directly to S3, bypass app servers entirely
2. **CDN caching**: popular videos served from edge → reduces origin load
3. **Transcoding workers**: horizontal scaling via message queue
4. **Database**: SQL for metadata (reads), DynamoDB for progress (writes)
5. **Search**: Elasticsearch cluster scales independently
6. **Multi-region**: CDN + replicated storage for global reach

## Interview Tips

- Start by asking clarifying questions (scale, latency, formats, live streaming scope)
- Emphasize **pre-signed URLs** -- the most important optimization (offloads video data from servers)
- Draw upload and streaming paths SEPARATELY
- Explain **adaptive bitrate streaming** with manifest file
- Know **cursor-based vs offset-based** pagination
- Mention the read-heavy ratio (100:1) → aggressive CDN caching
- Discuss eventual consistency for uploads (acceptable delay)
- Similar patterns: Netflix, Twitch, TikTok

## Quick Revision (5 bullet points)

1. **Pre-signed URLs** let clients upload directly to S3; app servers handle only lightweight metadata -- no bottleneck
2. **Transcoding pipeline**: each video → 6+ resolutions × hundreds of segments; async processing via message queue + workers
3. **Adaptive bitrate streaming (HLS/DASH)**: manifest file lists all resolutions; client auto-switches quality based on network speed
4. **CDN** serves video segments from edge locations worldwide; first frame target <500ms
5. **Cursor-based pagination** for search (scalable); fire-and-forget writes for watch progress (DynamoDB for millions of writes/sec)
