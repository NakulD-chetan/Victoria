# Tree — Edge Cases

> Always test your tree solution on these inputs before submitting.

---

## The Must-Test Edge Cases

### 1. Empty Tree (root = None)

Every tree function must handle this gracefully.

```python
# What should each function return for empty tree?
height(None)          → -1  (or 0 depending on convention)
count_nodes(None)     → 0
is_bst(None)          → True  (vacuously true)
inorder(None)         → []   (empty list)
level_order(None)     → []
max_depth(None)       → 0
```

### 2. Single Node Tree

```
    5
```

```python
height(single_node)   → 0
count_leaves(single)  → 1   # it IS a leaf
is_bst(single)        → True
diameter(single)      → 0   # no path between two nodes
```

### 3. Left-Skewed Tree (like a linked list)

```
1
 \
  2
   \
    3
     \
      4
```

- Height = n-1 = O(n) — recursion stack can overflow for large n!
- BST search = O(n) worst case
- Need to think about **iterative** solutions for very deep trees

### 4. Right-Skewed Tree

```
    1
   /
  2
 /
3
/
4
```

Same issues as left-skewed.

### 5. Two Nodes Only

```
  1       OR     1
 /                \
2                  2
```

```python
height = 1
is_balanced = True  (difference = 1, which is allowed)
diameter = 1
```

### 6. Complete Binary Tree (Full Last Level)

```
        1
       / \
      2   3
     / \ / \
    4  5 6  7
```

This is a **perfect** binary tree. Good for testing level-order.

### 7. BST with Duplicate Values

Behavior depends on implementation:
- Most BSTs ignore duplicates (return unchanged)
- Some put duplicates in left subtree (key ≤ node.data → go left)
- Some put duplicates in right subtree (key ≥ node.data → go right)

**Always clarify in interview:** "Should I handle duplicates? If so, where do they go?"

### 8. BST with Min/Max Integer Values

When validating BST, using `int` bounds can fail:

```python
# Wrong if node values can be INT_MIN or INT_MAX:
is_bst(node, min_val=-2**31, max_val=2**31-1)

# Safe — use float infinity:
is_bst(node, min_val=float('-inf'), max_val=float('inf'))
```

### 9. Very Large Tree (Stack Overflow Risk)

Recursive solutions can fail for trees with n > 10,000 nodes (Python's default recursion limit is 1000).

```python
import sys
sys.setrecursionlimit(10**6)  # increase limit

# OR use iterative approach with explicit stack
def inorder_iterative(root):
    result, stack = [], []
    node = root
    while node or stack:
        while node:
            stack.append(node)
            node = node.left
        node = stack.pop()
        result.append(node.data)
        node = node.right
    return result
```

### 10. Heap with All Equal Elements

```
All values = 5: [5, 5, 5, 5, 5]
```

All heap properties are satisfied (parent = child = 5). Operations work normally.

### 11. AVL Tree — All 4 Rotation Cases

Test each rotation type independently:
- **LL:** Insert 30 → 20 → 10 (right rotation at 30)
- **RR:** Insert 10 → 20 → 30 (left rotation at 10)
- **LR:** Insert 30 → 10 → 20 (left rotation at 10, then right rotation at 30)
- **RL:** Insert 10 → 30 → 20 (right rotation at 30, then left rotation at 10)

### 12. Tree Traversal on One-Sided Trees

```
Pre-order of right-skewed BST with [1, 2, 3, 4]:
   1 → 2 → 3 → 4   (pre and in-order are the same!)

In-order gives sorted: 1, 2, 3, 4
Post-order: 4, 3, 2, 1   (reversed!)
```

### 13. Diameter Spanning Root vs Not Spanning Root

The diameter might NOT pass through the root:

```
        1
       /
      2
     / \
    3   4
   /     \
  5       6
```

Diameter here = 5 → 3 → 2 → 4 → 6 (length = 4), which goes through node 2, NOT the root 1.

Always compute diameter at **every node**, not just the root.

---

## Checklist Before Submitting

- [ ] Does it handle `root = None`?
- [ ] Does it handle a single node?
- [ ] Does it handle a skewed tree (all nodes to one side)?
- [ ] For BST problems: does it use `float('-inf')` / `float('inf')` for bounds?
- [ ] For height: is the base case `-1` or `0` — and is it consistent?
- [ ] For heap: am I using 0-indexed or 1-indexed — and is it consistent?
- [ ] Will recursion stack overflow for n > 10,000? Should I use iterative?
