import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const JOBS = [
  { id: 'a', p: 100, d: 2 },
  { id: 'b', p: 19, d: 1 },
  { id: 'c', p: 27, d: 2 },
  { id: 'd', p: 25, d: 1 },
  { id: 'e', p: 3, d: 3 },
];

function generateSteps() {
  const steps = [];
  const sorted = [...JOBS].sort((a, b) => b.p - a.p);
  const maxD = Math.max(...sorted.map((j) => j.d));
  const slot = Array(maxD).fill(null);
  steps.push({
    type: 'sort',
    msg: 'Sort jobs by profit (desc)',
    array: sorted.map((j) => j.p),
    meta: sorted.map((j) => j.id),
    slot: [...slot],
  });
  sorted.forEach((job, ji) => {
    steps.push({
      type: 'try',
      msg: `Place job ${job.id} profit ${job.p}, deadline ${job.d}`,
      array: sorted.map((j) => j.p),
      colors: { [ji]: 'compare' },
      meta: sorted.map((j) => j.id),
      slot: [...slot],
      ji,
      job,
    });
    let placed = false;
    for (let t = job.d - 1; t >= 0; t--) {
      if (slot[t] == null) {
        slot[t] = job.id;
        placed = true;
        steps.push({
          type: 'place',
          msg: `Job ${job.id} → slot ${t + 1}`,
          array: sorted.map((j) => j.p),
          colors: { [ji]: 'sorted' },
          meta: sorted.map((j) => j.id),
          slot: [...slot],
        });
        break;
      }
    }
    if (!placed) {
      steps.push({
        type: 'drop',
        msg: `No slot for ${job.id}`,
        array: sorted.map((j) => j.p),
        colors: { [ji]: 'swap' },
        meta: sorted.map((j) => j.id),
        slot: [...slot],
      });
    }
  });
  steps.push({
    type: 'done',
    msg: `Timeline slots filled: ${slot.map((s) => s || '-').join(',')}`,
    array: sorted.map((j) => j.p),
    colors: Object.fromEntries(sorted.map((_, i) => [i, 'sorted'])),
    meta: sorted.map((j) => j.id),
    slot: [...slot],
  });
  return steps;
}

export default function JobSequencingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray(steps[0].array);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Job sequencing with deadlines' });
    canvasRef.current?.setState({ array: steps[0].array, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.setArray(step.array);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState({ array: step.array, colors: step.colors || {} });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
