# 10 — Data Mesh & Modern Architectures

> **One-line:** Data Mesh is a **decentralized** approach where **domain teams own their data as a product** — a paradigm shift from centralized data teams, and a hot interview topic for senior DE roles.

---

## 1. The Problem Data Mesh Solves

### Centralized Data Team Bottleneck

```
Traditional (Centralized):

  Team A ──┐                    ┌──► Dashboard A
  Team B ──┼──► Central DE ────►├──► Dashboard B
  Team C ──┤   Team (5 people) │└──► ML Model
  Team D ──┘   (bottleneck!)   │
                               └──► Ad-hoc queries

Problem: 20 teams, 1 data team → queue of months
         Central team doesn't understand domain context
         Data quality issues → "not our data, not our problem"
```

---

## 2. Data Mesh — Four Core Principles

| Principle | What It Means | Example |
|-----------|--------------|---------|
| **Domain Ownership** | Each business domain owns, produces, and serves its data | Sales team owns sales data pipeline, not central DE |
| **Data as a Product** | Data is treated like a product — discoverable, documented, with SLAs | Sales publishes "orders" dataset with schema, docs, freshness SLA |
| **Self-Serve Platform** | Central platform team provides tools/infra, not pipelines | Platform provides Spark, Airflow, Snowflake access — domains build their own |
| **Federated Governance** | Global standards + domain-level autonomy | Central: naming conventions, PII rules. Domain: their own models/schemas |

### Data Mesh Architecture

```
┌───────────────────────────────────────────────────────────┐
│                 FEDERATED GOVERNANCE                       │
│  (Global policies: naming, security, PII, interop)        │
└───────────────────────────┬───────────────────────────────┘
                            │
    ┌───────────────────────┼───────────────────────┐
    │                       │                       │
┌───┴────────────┐  ┌──────┴─────────┐  ┌─────────┴──────┐
│ Sales Domain   │  │ Customer Domain│  │ Product Domain │
│                │  │                │  │                │
│ Data Product:  │  │ Data Product:  │  │ Data Product:  │
│ • orders       │  │ • customers    │  │ • products     │
│ • revenue      │  │ • segments     │  │ • inventory    │
│                │  │                │  │                │
│ Own pipeline   │  │ Own pipeline   │  │ Own pipeline   │
│ Own quality    │  │ Own quality    │  │ Own quality    │
│ Own SLA        │  │ Own SLA        │  │ Own SLA        │
└────────────────┘  └────────────────┘  └────────────────┘
        │                   │                   │
        └───────────────────┼───────────────────┘
                            │
            ┌───────────────┴──────────────┐
            │    SELF-SERVE PLATFORM       │
            │  (Infra, tools, templates)   │
            │  Spark, Airflow, Snowflake   │
            │  CI/CD, monitoring, catalog  │
            └──────────────────────────────┘
```

---

## 3. Data as a Product — What Makes Good Data Products

| Quality | What It Means |
|---------|--------------|
| **Discoverable** | Listed in data catalog, searchable |
| **Addressable** | Clear access path (e.g., `sales.orders` in Snowflake) |
| **Trustworthy** | Data quality tests, freshness guarantees |
| **Self-describing** | Schema documentation, column descriptions, lineage |
| **Interoperable** | Standard formats, compatible across domains |
| **Secure** | Access control, PII handling defined |
| **Valuable** | Serves real consumer needs, not just "raw dump" |

**Interview line:** "A data product is not just a table — it's a **contract** with consumers that includes schema, documentation, quality guarantees, and an SLA."

---

## 4. Data Mesh vs Data Lake vs Data Warehouse

| Dimension | Data Warehouse | Data Lake | Data Mesh |
|-----------|---------------|-----------|-----------|
| **Architecture** | Centralized | Centralized | Decentralized |
| **Ownership** | Central DE team | Central DE team | Domain teams |
| **Scaling model** | Scale the team | Scale storage | Scale by adding domains |
| **Governance** | Central | Central (often weak) | Federated |
| **Bottleneck risk** | Central team | Central team | Coordination complexity |
| **Works best for** | Small-medium orgs | Data exploration | Large orgs (50+ teams) |

---

## 5. Data Fabric — The Alternative Approach

| Aspect | Data Mesh | Data Fabric |
|--------|-----------|-------------|
| **Philosophy** | Organizational (people/process change) | Technological (intelligent integration layer) |
| **Key idea** | Domain teams own data products | AI-powered metadata layer connects all data |
| **Automation** | Domains build their own pipelines | Platform auto-discovers, integrates, governs data |
| **Governance** | Federated (domains + global) | Centralized + automated |
| **Best for** | Organizations ready for decentralization | Organizations wanting automated integration |

```
Data Fabric Architecture:

┌─────────────────────────────────────────────────┐
│           INTELLIGENT METADATA LAYER            │
│  (Auto-discovery, lineage, recommendations)     │
└──────────────────────┬──────────────────────────┘
                       │
    ┌──────────────────┼──────────────────┐
    │                  │                  │
┌───┴──────┐    ┌─────┴──────┐    ┌─────┴──────┐
│  Data    │    │  Data      │    │  Data      │
│  Source 1│    │  Source 2  │    │  Source 3  │
│  (OLTP)  │    │  (APIs)   │    │  (Files)  │
└──────────┘    └────────────┘    └────────────┘
```

---

## 6. Other Modern Architecture Patterns

### Event-Driven Architecture

```
User Action → Event (Kafka) → Multiple Consumers
                                ├── Update DW
                                ├── Update Cache
                                ├── Send Notification
                                └── Update ML Feature Store
```

| Aspect | Detail |
|--------|--------|
| **Core idea** | Systems communicate via **events**, not direct calls |
| **Benefits** | Loose coupling, easy to add consumers, natural audit trail |
| **Challenges** | Eventual consistency, event ordering, debugging |

### Feature Store Pattern

| Aspect | Detail |
|--------|--------|
| **What** | Central repository for ML features — computed once, reused everywhere |
| **Why** | Avoid feature computation duplication across ML teams |
| **Components** | Offline store (batch features) + Online store (real-time features) |
| **Tools** | Feast, Tecton, Databricks Feature Store, SageMaker Feature Store |

```
Raw Data → Feature Pipeline → Feature Store
                                 ├── Offline Store (batch training) → S3/DW
                                 └── Online Store (real-time serving) → Redis/DynamoDB
```

### Reverse ETL

| Aspect | Detail |
|--------|--------|
| **What** | Push data **from** warehouse **back to** operational tools |
| **Why** | Activate warehouse insights in CRM, marketing, support tools |
| **Examples** | Customer segments from DW → Salesforce; lead scores → HubSpot |
| **Tools** | Census, Hightouch, Polytomic |

```
Data Warehouse (Gold layer)
    │
    └──► Reverse ETL ──► Salesforce (CRM)
                    ──► HubSpot (Marketing)
                    ──► Zendesk (Support)
                    ──► Braze (Notifications)
```

---

## 7. Data Contracts

| Aspect | Detail |
|--------|--------|
| **What** | Formal agreement between data **producer** and **consumer** |
| **Includes** | Schema (columns, types), SLA (freshness, uptime), quality rules, ownership |
| **Why** | Prevents surprise breakages when upstream changes |
| **Format** | YAML/JSON schema files, version-controlled |

```yaml
# data_contract.yml
name: orders
owner: sales-team
description: "All e-commerce orders with line items"
schema:
  - name: order_id
    type: string
    required: true
  - name: amount
    type: decimal(10,2)
    required: true
    constraints:
      - "amount > 0"
sla:
  freshness: "< 15 minutes"
  availability: "99.9%"
```

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "What is Data Mesh?" | Decentralized: domain ownership, data as product, self-serve platform, federated governance |
| "Data Mesh vs Data Lake?" | Mesh = organizational change (who owns). Lake = technology (where stored) |
| "What is a data product?" | Table/API with docs, schema, quality tests, SLA — treated like a software product |
| "Data Mesh vs Data Fabric?" | Mesh: organizational decentralization. Fabric: tech-driven intelligent integration |
| "When should you NOT use Data Mesh?" | Small orgs, few domains, team not mature enough for ownership |
| "What is a data contract?" | Producer-consumer agreement on schema, SLA, quality — prevents breakages |
| "What is Reverse ETL?" | Push warehouse insights back to operational tools (CRM, marketing) |
| "What is a Feature Store?" | Central repository for ML features — compute once, serve for training and inference |

---

## Key Takeaways

- **Data Mesh**: 4 principles — domain ownership, data as product, self-serve platform, federated governance.
- Best for **large organizations** (50+ teams) where centralized data teams become bottlenecks.
- **Data Fabric** is the tech-driven alternative — AI-powered metadata layer for auto-integration.
- **Data Contracts** formalize producer-consumer agreements — prevents surprise breakages.
- **Reverse ETL** activates warehouse data in operational tools (Salesforce, HubSpot).
- **Feature Store** centralizes ML features for consistent training and serving.
- **Event-driven architecture** enables loose coupling and real-time data propagation.

---
