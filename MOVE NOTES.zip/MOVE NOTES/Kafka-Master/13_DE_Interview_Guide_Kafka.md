# 13. Data Engineer Interview Guide — Kafka

> **Permanent Recall Note:** Interviews test **mental models**: **log**, **partition**, **ISR**, **consumer group**, **delivery semantics**, and **operational** triage. Practice **drawing** the architecture in **60 seconds** and narrating **failure** modes. Pair revision with [../spark/15_DE_Interview_Guide_Spark.md](../spark/15_DE_Interview_Guide_Spark.md) for **end-to-end** pipeline stories.

### The 10-Second Summary
- **Must answer cold:** ordering, partitions, acks+ISR, consumer lag, idempotent vs transactional.
- **Debug:** lag spike, broker OOM, rebalance storm, ordering bugs.
- **Design:** topics/partitions, **keys**, **schemas**, **sink** idempotency, **SLAs**.

---

# 13.1 System Questions — Must Answer Cold

**Q: Where is ordering guaranteed in Kafka?**  
**A:** **Single partition** — total order of **appended** records; **not** across partitions.

**Q: What does `acks=all` mean with `min.insync.replicas`?**  
**A:** Producer **waits** for **all ISR** acknowledgments per policy — **durability** trade vs **availability** if ISR **shrinks**.

**Q: Consumer group vs multiple groups?**  
**A:** **One group** = **load-balanced** consumption; **multiple groups** = **independent** offsets on same topic (**fan-out**).

**Q: Idempotent producer vs transactional?**  
**A:** **Idempotent** dedupes **retries** per partition; **Transactional** coordinates **multiple** partitions + **offsets** for **EOS** patterns.

**Q: KRaft vs ZooKeeper?**  
**A:** **Metadata** in **Kafka Raft** quorum — **simpler ops**; ZK is **legacy**.

---

# 13.2 Debugging Scenarios

## A — Consumer Lag Spike

```
CHECK:
1) Consumer **processing** time ↑ (GC, downstream DB)
2) **Rebalance** loop (poll/heartbeat)
3) Broker **ISR** / **leader** issues → **slow fetch**
4) **Partition skew** — one hot key
```

🎯 **Interview Tip:** Say **metrics first**: **lag per partition**, **consumer** thread **stall**, **broker** **UnderReplicatedPartitions**.

---

## B — Broker OOM / Heavy GC

```
CHECK:
1) **Heap** too high vs **page cache** contention
2) **Too many** partitions per broker
3) **Network** / **replica fetch** overload
```

---

## C — Rebalancing Storms

```
CHECK:
1) max.poll.interval vs **processing** time
2) **Long** GC
3) **Static** membership missing on **rolling** deploys
4) Cooperative assignor available?
```

---

## D — Message Ordering Issues

```
CHECK:
1) **Key** missing or **changing**
2) **Multiple** producers to same key without **care**
3) **Retries** + **max.in.flight** without **idempotence** (older setups)
```

---

# 13.3 Design Question Template

```
1) **Volume** / **SLA** / **ordering** requirements
2) **Topics + partitions** + **keys**
3) **Schema** + **Registry** + **compatibility**
4) **Producers:** acks, idempotence, retries
5) **Consumers:** group, commits, **lag** alerts
6) **Broker:** RF, **min.insync**, **retention**
7) **Failure:** **RPO/RTO**, **MM2** if multi-DC
8) **Downstream:** **idempotent** sinks — Spark/Flink — cross-ref Spark track
```

---

# 13.4 Short Drills (2 Minutes Each)

1. Draw **producer → broker leader → followers → consumer group**.
2. Explain **HW** vs **LEO** in one sentence each.
3. List **three** causes of **consumer lag**.
4. **Compact** vs **delete** retention — when **each**?
5. **Connect** **source** vs **sink** — **one** example each.

---

# 13.5 Architecture Drawing Exercise

**Prompt:** “Orders pipeline from **OLTP** to **lakehouse**.”

**Sketch:**

```
OLTP → (Outbox or Debezium) → Kafka **orders** topic
  ├── Spark Structured Streaming → **Delta** table (bronze)
  └── ksqlDB / Flink for **RT** dashboard
```

Mention **keys** (`order_id`), **partitions** (~**throughput**), **Registry**, **lag** alerts.

---

# 13.6 Spark Cross-Reference Quick List

| Kafka topic | Spark concept |
|-------------|----------------|
| Partition | RDD/DataFrame **partition** — different meaning, **parallelism** link |
| Offset checkpoint | **Structured Streaming** checkpoint — [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md) |
| Idempotent sink | **MERGE** idempotency — [../spark/13_Data_Quality_Idempotency.md](../spark/13_Data_Quality_Idempotency.md) |

---

# 13.7 Behavioral Anchors

- **Ownership:** “We **alerted** on **max lag** per partition…”
- **Postmortem:** “**ISR** shrink correlated with **broker** disk…”
- **Trade-off:** “We chose **at-least-once** + **idempotent** DB **upsert** for **simpler** ops than full **EOS**.”

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 13 — QUICK RECALL                                 │
├─────────────────────────────────────────────────────────────┤
│  🧠 Cold: ordering, ISR, acks, lag, groups                 │
│  🧠 Debug: lag → processing vs broker vs rebalance           │
│  🧠 Design: keys + partitions + schema + sink                │
│  🧠 Practice 60s architecture sketch daily                 │
│  ⚠️  Don’t hand-wave EOS — split broker vs app              │
│  🎯 Pair with Spark interview guide for pipelines          │
└─────────────────────────────────────────────────────────────┘
```
