import { uid } from '../../state/types';
import { worldFromClient } from '../coords';

/**
 * Pen tool — perfect-freehand powered.
 *
 * Smoothness techniques (reason, not just "what"):
 *  - `getCoalescedEvents()`: on devices that batch pointer samples (120Hz+
 *    styli, precision trackpads), move events arrive at 60Hz containing the
 *    intermediate samples as a list. Dropping those = lost detail.
 *  - `setPointerCapture`: binds the pointer to the canvas so even if the
 *    cursor leaves the element mid-stroke, we keep getting events. Prevents
 *    the "stroke dies when you flick past the edge" bug.
 *  - Draft lives ONLY in the engine (never in the Zustand store), so React
 *    does not re-render per sample.
 */

export const penTool = {
  id: 'pen',
  cursor: 'crosshair',

  onPointerDown(ctx, ev) {
    const { canvasEl, getVp, store } = ctx;
    if (ev.button !== 0) return false;
    canvasEl.setPointerCapture?.(ev.pointerId);
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
    const style = getStrokeStyle(store.getState().toolOptions);
    ctx.setDraft({
      id: uid('pen'),
      type: 'pen',
      x, y, w: 0, h: 0, z: 0, isDeleted: false,
      style,
      points: [[x, y, ev.pressure || 0.5]],
      _final: false,
      createdAt: Date.now(),
    });
    ctx.markDirty(1);
    return true;
  },

  onPointerMove(ctx, ev) {
    const draft = ctx.getDraft();
    if (!draft || draft.type !== 'pen') return;
    const { canvasEl, getVp } = ctx;
    const vp = getVp();
    const events = ev.getCoalescedEvents?.() || [ev];
    const pts = draft.points;
    for (const e of events) {
      const { x, y } = worldFromClient(e.clientX, e.clientY, canvasEl, vp);
      pts.push([x, y, e.pressure || 0.5]);
    }
    ctx.markDirty(1);
  },

  onPointerUp(ctx, ev) {
    const draft = ctx.getDraft();
    if (!draft || draft.type !== 'pen') return;
    draft._final = true;
    // Commit to store; draft cleared afterward.
    const el = finalizeStroke(draft);
    ctx.setDraft(null);
    ctx.commit((els) => els.concat([el]));
    ctx.markDirty(2);
  },

  onCancel(ctx) {
    ctx.setDraft(null);
    ctx.markDirty(1);
  },
};

export const highlighterTool = {
  id: 'highlighter',
  cursor: 'crosshair',

  onPointerDown(ctx, ev) {
    const { canvasEl, getVp, store } = ctx;
    if (ev.button !== 0) return false;
    canvasEl.setPointerCapture?.(ev.pointerId);
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, getVp());
    const opts = store.getState().toolOptions;
    const style = {
      stroke: opts.stroke === '#1e293b' || opts.stroke === '#e2e8f0' ? '#fde047' : opts.stroke,
      fill: 'transparent',
      strokeWidth: Math.max(16, (opts.strokeWidth || 2) * 6),
      opacity: 0.4,
      dash: 'solid',
    };
    ctx.setDraft({
      id: uid('hl'),
      type: 'highlighter',
      x, y, w: 0, h: 0, z: 0, isDeleted: false,
      style,
      points: [[x, y, 0.5]],
      _final: false,
      createdAt: Date.now(),
    });
    ctx.markDirty(1);
    return true;
  },

  onPointerMove(ctx, ev) {
    const draft = ctx.getDraft();
    if (!draft || draft.type !== 'highlighter') return;
    const { canvasEl, getVp } = ctx;
    const vp = getVp();
    const events = ev.getCoalescedEvents?.() || [ev];
    for (const e of events) {
      const { x, y } = worldFromClient(e.clientX, e.clientY, canvasEl, vp);
      draft.points.push([x, y, 0.5]);
    }
    ctx.markDirty(1);
  },

  onPointerUp(ctx) {
    const draft = ctx.getDraft();
    if (!draft || draft.type !== 'highlighter') return;
    draft._final = true;
    const el = finalizeStroke(draft);
    ctx.setDraft(null);
    ctx.commit((els) => els.concat([el]));
    ctx.markDirty(2);
  },

  onCancel(ctx) {
    ctx.setDraft(null);
    ctx.markDirty(1);
  },
};

function getStrokeStyle(opts) {
  return {
    stroke: opts.stroke,
    fill: 'transparent',
    strokeWidth: opts.strokeWidth,
    opacity: opts.opacity ?? 1,
    dash: 'solid',
  };
}

function finalizeStroke(draft) {
  // Collapse AABB so hit-tests and overlays work against the final geometry.
  const pts = draft.points;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const p of pts) {
    if (p[0] < minX) minX = p[0];
    if (p[0] > maxX) maxX = p[0];
    if (p[1] < minY) minY = p[1];
    if (p[1] > maxY) maxY = p[1];
  }
  if (pts.length === 1) {
    // treat a tap as a dot
    maxX = minX + 0.5;
    maxY = minY + 0.5;
  }
  return {
    ...draft,
    x: minX, y: minY,
    w: maxX - minX, h: maxY - minY,
    _final: true,
  };
}
