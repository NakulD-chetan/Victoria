import { create } from 'zustand';

const LANG_EXT = {
  cpp: '.cpp',
  python: '.py',
  java: '.java',
  javascript: '.js',
  mysql: '.sql',
  oracle: '.sql',
  sqlite: '.sql',
};

const EXT_LANG = {
  '.cpp': 'cpp',
  '.cc': 'cpp',
  '.cxx': 'cpp',
  '.c': 'cpp',
  '.h': 'cpp',
  '.hpp': 'cpp',
  '.py': 'python',
  '.java': 'java',
  '.js': 'javascript',
  '.ts': 'javascript',
  '.txt': 'plaintext',
  '.md': 'markdown',
  '.json': 'json',
  '.sql': 'sql',
};

const TEMPLATES = {
  cpp: `#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
`,
  python: `def main():
    print("Hello, World!")

if __name__ == "__main__":
    main()
`,
  java: `import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
`,
  javascript: `function main() {
    console.log("Hello, World!");
}

main();
`,
  mysql: `CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(50)
);

INSERT INTO users (name) VALUES ('Alice'), ('Bob');

SELECT * FROM users;`,
  oracle: `CREATE TABLE users (
  id NUMBER PRIMARY KEY,
  name VARCHAR2(50)
);

INSERT INTO users (id, name) VALUES (1, 'Alice');
INSERT INTO users (id, name) VALUES (2, 'Bob');

SELECT * FROM users;`,
  sqlite: `CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT
);

INSERT INTO users (name) VALUES ('Alice'), ('Bob');

SELECT * FROM users;`,
};

function getExtension(filename) {
  const dot = filename.lastIndexOf('.');
  return dot >= 0 ? filename.slice(dot) : '';
}

function detectLanguage(filename) {
  return EXT_LANG[getExtension(filename)] || 'plaintext';
}

function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function getDefaultFile(langId) {
  const ext = LANG_EXT[langId] || '.txt';
  const name = langId === 'java' ? 'Main.java' : `main${ext}`;
  const id = uid('f');
  return {
    id,
    name,
    folderId: null,
    language: langId,
    content: TEMPLATES[langId] || '',
  };
}

const STORAGE_KEY_BASE = 'ce-filestore';
const STORAGE_VERSION = 2;

/* The default vault keeps the legacy flat key so existing user data
 * survives the upgrade. New vaults get their own suffixed slot. */
function storageKeyFor(vaultId) {
  const id = vaultId || activeVaultIdSync();
  return id === 'default' ? STORAGE_KEY_BASE : `${STORAGE_KEY_BASE}:${id}`;
}

function activeVaultIdSync() {
  if (typeof window !== 'undefined' && window.__activeVaultId) return window.__activeVaultId;
  return 'default';
}

function loadState(vaultId) {
  try {
    const raw = localStorage.getItem(storageKeyFor(vaultId));
    if (!raw) return null;
    const parsed = JSON.parse(raw);

    if (parsed && parsed.version === STORAGE_VERSION && parsed.files && parsed.folders) {
      return parsed;
    }

    // Migrate v1 (path-keyed) shape -> v2 (id-keyed with folders)
    if (parsed && parsed.files && Object.keys(parsed.files).length > 0 && !parsed.version) {
      const folders = {};
      const files = {};
      const pathToId = {};
      for (const [path, entry] of Object.entries(parsed.files)) {
        const id = uid('f');
        const name = path.startsWith('/') ? path.slice(1) : path;
        files[id] = {
          id,
          name,
          folderId: null,
          language: entry.language || detectLanguage(name),
          content: entry.content || '',
        };
        pathToId[path] = id;
      }
      const openTabs = Array.isArray(parsed.openTabs)
        ? parsed.openTabs.map((p) => pathToId[p]).filter(Boolean)
        : Object.keys(files);
      const activeFile = pathToId[parsed.activeFile] || openTabs[0] || Object.keys(files)[0];
      return {
        version: STORAGE_VERSION,
        folders,
        files,
        openTabs,
        activeFile,
        langId: parsed.langId || 'cpp',
      };
    }
    return null;
  } catch {
    return null;
  }
}

function saveState(state, vaultId) {
  try {
    localStorage.setItem(storageKeyFor(vaultId), JSON.stringify({
      version: STORAGE_VERSION,
      folders: state.folders,
      files: state.files,
      openTabs: state.openTabs,
      activeFile: state.activeFile,
      langId: state.langId,
    }));
  } catch { /* ignore */ }
}

function findFileByNameAndFolder(files, name, folderId) {
  return Object.values(files).find(
    (f) => f.name === name && (f.folderId || null) === (folderId || null)
  );
}

function uniqueFileName(files, name, folderId) {
  if (!findFileByNameAndFolder(files, name, folderId)) return name;
  const dot = name.lastIndexOf('.');
  const base = dot >= 0 ? name.slice(0, dot) : name;
  const ext = dot >= 0 ? name.slice(dot) : '';
  for (let i = 2; i < 1000; i += 1) {
    const candidate = `${base} (${i})${ext}`;
    if (!findFileByNameAndFolder(files, candidate, folderId)) return candidate;
  }
  return `${base}_${Date.now()}${ext}`;
}

function uniqueFolderName(folders, name, parentId) {
  const sibling = Object.values(folders).find(
    (f) => f.name === name && (f.parentId || null) === (parentId || null)
  );
  if (!sibling) return name;
  for (let i = 2; i < 1000; i += 1) {
    const candidate = `${name} (${i})`;
    const exists = Object.values(folders).some(
      (f) => f.name === candidate && (f.parentId || null) === (parentId || null)
    );
    if (!exists) return candidate;
  }
  return `${name}_${Date.now()}`;
}

const defaultLang = 'cpp';
const saved = loadState();

let initialFiles;
let initialFolders;
let initialTabs;
let initialActive;
let initialLang;

if (saved) {
  initialFiles = saved.files;
  initialFolders = saved.folders || {};
  initialTabs = Array.isArray(saved.openTabs) ? saved.openTabs.filter((id) => initialFiles[id]) : Object.keys(initialFiles);
  initialActive = saved.activeFile && initialFiles[saved.activeFile]
    ? saved.activeFile
    : (initialTabs[0] || null);
  initialLang = saved.langId || defaultLang;
} else {
  initialFiles = {};
  initialFolders = {};
  initialTabs = [];
  initialActive = null;
  initialLang = defaultLang;
}

export const useFileStore = create((set, get) => ({
  files: initialFiles,
  folders: initialFolders,
  openTabs: initialTabs,
  activeFile: initialActive,
  langId: initialLang,

  setActiveFile: (id) => {
    const state = get();
    if (!state.files[id]) return;
    const tabs = state.openTabs.includes(id) ? state.openTabs : [...state.openTabs, id];
    const nextState = { ...state, activeFile: id, openTabs: tabs };
    set({ activeFile: id, openTabs: tabs });
    saveState(nextState);
  },

  clearActiveFile: () => {
    const state = get();
    set({ activeFile: null });
    saveState({ ...state, activeFile: null });
  },

  updateFileContent: (id, content) => {
    const state = get();
    if (!state.files[id]) return;
    const files = { ...state.files, [id]: { ...state.files[id], content } };
    set({ files });
    saveState({ ...state, files });
  },

  createFile: (name, folderId = null, content = '') => {
    const state = get();
    const trimmed = (name || '').trim();
    if (!trimmed) return null;
    const finalName = uniqueFileName(state.files, trimmed, folderId);
    const id = uid('f');
    const file = {
      id,
      name: finalName,
      folderId: folderId || null,
      language: detectLanguage(finalName),
      content,
    };
    const files = { ...state.files, [id]: file };
    const openTabs = [...state.openTabs, id];
    const nextState = { ...state, files, openTabs, activeFile: id };
    set({ files, openTabs, activeFile: id });
    saveState(nextState);
    return id;
  },

  deleteFile: (id) => {
    const state = get();
    if (!state.files[id]) return;
    const files = { ...state.files };
    delete files[id];
    const openTabs = state.openTabs.filter((t) => t !== id);
    let activeFile = state.activeFile;
    if (activeFile === id) {
      activeFile = openTabs[openTabs.length - 1] || Object.keys(files)[0] || null;
    }
    const nextState = { ...state, files, openTabs, activeFile };
    set({ files, openTabs, activeFile });
    saveState(nextState);
  },

  renameFile: (id, newName) => {
    const state = get();
    if (!state.files[id]) return false;
    const trimmed = (newName || '').trim();
    if (!trimmed) return false;
    const current = state.files[id];
    if (trimmed === current.name) return true;
    const finalName = uniqueFileName(
      Object.fromEntries(Object.entries(state.files).filter(([k]) => k !== id)),
      trimmed,
      current.folderId,
    );
    const files = {
      ...state.files,
      [id]: { ...current, name: finalName, language: detectLanguage(finalName) },
    };
    set({ files });
    saveState({ ...state, files });
    return true;
  },

  duplicateFile: (id) => {
    const state = get();
    const src = state.files[id];
    if (!src) return null;
    const newName = uniqueFileName(state.files, src.name, src.folderId);
    const newId = uid('f');
    const file = { ...src, id: newId, name: newName };
    const files = { ...state.files, [newId]: file };
    const openTabs = [...state.openTabs, newId];
    set({ files, openTabs, activeFile: newId });
    saveState({ ...state, files, openTabs, activeFile: newId });
    return newId;
  },

  moveFile: (id, folderId) => {
    const state = get();
    if (!state.files[id]) return;
    const current = state.files[id];
    const finalName = uniqueFileName(
      Object.fromEntries(Object.entries(state.files).filter(([k]) => k !== id)),
      current.name,
      folderId || null,
    );
    const files = {
      ...state.files,
      [id]: { ...current, folderId: folderId || null, name: finalName },
    };
    set({ files });
    saveState({ ...state, files });
  },

  closeTab: (id) => {
    const state = get();
    if (!state.openTabs.includes(id)) return;
    const openTabs = state.openTabs.filter((t) => t !== id);
    let activeFile = state.activeFile;
    if (activeFile === id) {
      const idx = state.openTabs.indexOf(id);
      activeFile = openTabs[Math.min(idx, openTabs.length - 1)] || openTabs[0] || null;
    }
    if (openTabs.length === 0) {
      // Keep at least the file concept; just null the active
      activeFile = null;
    }
    set({ openTabs, activeFile });
    saveState({ ...state, openTabs, activeFile });
  },

  createStarterFile: (langId, folderId = null) => {
    const state = get();
    const file = getDefaultFile(langId || state.langId || defaultLang);
    file.folderId = folderId || null;
    file.name = uniqueFileName(state.files, file.name, file.folderId);
    const files = { ...state.files, [file.id]: file };
    const openTabs = state.openTabs.includes(file.id) ? state.openTabs : [...state.openTabs, file.id];
    const nextState = {
      ...state,
      files,
      openTabs,
      activeFile: file.id,
      langId: file.language || langId || state.langId || defaultLang,
    };
    set({
      files,
      openTabs,
      activeFile: file.id,
      langId: nextState.langId,
    });
    saveState(nextState);
    return file.id;
  },

  createFolder: (name, parentId = null) => {
    const state = get();
    const trimmed = (name || '').trim() || 'New Folder';
    const finalName = uniqueFolderName(state.folders, trimmed, parentId);
    const id = uid('d');
    const folder = { id, name: finalName, parentId: parentId || null };
    const folders = { ...state.folders, [id]: folder };
    set({ folders });
    saveState({ ...state, folders });
    return id;
  },

  renameFolder: (id, newName) => {
    const state = get();
    if (!state.folders[id]) return false;
    const trimmed = (newName || '').trim();
    if (!trimmed) return false;
    const current = state.folders[id];
    if (trimmed === current.name) return true;
    const siblings = Object.fromEntries(
      Object.entries(state.folders).filter(([k]) => k !== id)
    );
    const finalName = uniqueFolderName(siblings, trimmed, current.parentId);
    const folders = { ...state.folders, [id]: { ...current, name: finalName } };
    set({ folders });
    saveState({ ...state, folders });
    return true;
  },

  deleteFolder: (id) => {
    const state = get();
    if (!state.folders[id]) return;

    // Collect all descendant folder ids (recursive)
    const toRemoveFolders = new Set([id]);
    let changed = true;
    while (changed) {
      changed = false;
      for (const f of Object.values(state.folders)) {
        if (!toRemoveFolders.has(f.id) && f.parentId && toRemoveFolders.has(f.parentId)) {
          toRemoveFolders.add(f.id);
          changed = true;
        }
      }
    }

    const folders = {};
    for (const f of Object.values(state.folders)) {
      if (!toRemoveFolders.has(f.id)) folders[f.id] = f;
    }

    const files = {};
    const removedFileIds = new Set();
    for (const f of Object.values(state.files)) {
      if (f.folderId && toRemoveFolders.has(f.folderId)) {
        removedFileIds.add(f.id);
      } else {
        files[f.id] = f;
      }
    }

    let openTabs = state.openTabs.filter((t) => !removedFileIds.has(t));
    let activeFile = state.activeFile;
    if (activeFile && removedFileIds.has(activeFile)) {
      activeFile = openTabs[openTabs.length - 1] || Object.keys(files)[0] || null;
    }

    set({ folders, files, openTabs, activeFile });
    saveState({ ...state, folders, files, openTabs, activeFile });
  },

  switchLanguage: (newLangId) => {
    const state = get();
    const existingForLang = Object.values(state.files).find((f) => f.language === newLangId);
    if (existingForLang) {
      const openTabs = state.openTabs.includes(existingForLang.id)
        ? state.openTabs
        : [...state.openTabs, existingForLang.id];
      set({ langId: newLangId, activeFile: existingForLang.id, openTabs });
      saveState({ ...state, langId: newLangId, activeFile: existingForLang.id, openTabs });
      return;
    }
    const defaultFile = getDefaultFile(newLangId);
    // Ensure unique name at root
    defaultFile.name = uniqueFileName(state.files, defaultFile.name, null);
    const files = { ...state.files, [defaultFile.id]: defaultFile };
    const openTabs = [...state.openTabs, defaultFile.id];
    set({ files, openTabs, activeFile: defaultFile.id, langId: newLangId });
    saveState({ ...state, files, openTabs, activeFile: defaultFile.id, langId: newLangId });
  },

  getActiveContent: () => {
    const state = get();
    const file = state.files[state.activeFile];
    return file ? file.content : '';
  },

  getActiveLanguage: () => {
    const state = get();
    const file = state.files[state.activeFile];
    return file ? file.language : 'plaintext';
  },

  getFilePath: (id) => {
    const state = get();
    const file = state.files[id];
    if (!file) return '';
    const parts = [file.name];
    let folderId = file.folderId;
    while (folderId && state.folders[folderId]) {
      parts.unshift(state.folders[folderId].name);
      folderId = state.folders[folderId].parentId;
    }
    return `/${parts.join('/')}`;
  },

  /* Swap all in-memory state to the new vault's saved snapshot. If the
   * new vault has no saved state yet, start fresh (empty workspace). */
  reloadForVault: (newVaultId) => {
    const saved = loadState(newVaultId);
    if (saved) {
      const files = saved.files || {};
      const folders = saved.folders || {};
      const openTabs = Array.isArray(saved.openTabs) ? saved.openTabs.filter((id) => files[id]) : Object.keys(files);
      const activeFile = saved.activeFile && files[saved.activeFile]
        ? saved.activeFile
        : (openTabs[0] || null);
      set({
        files,
        folders,
        openTabs,
        activeFile,
        langId: saved.langId || defaultLang,
      });
    } else {
      set({
        files: {},
        folders: {},
        openTabs: [],
        activeFile: null,
        langId: defaultLang,
      });
    }
  },
}));

/* Subscribe once at module load so vault switches hot-swap the Code
 * store without any React wiring. */
if (typeof window !== 'undefined') {
  import('../../stores/vault-store.js').then(({ onVaultChange }) => {
    onVaultChange((nextId) => useFileStore.getState().reloadForVault(nextId));
  }).catch(() => { /* non-fatal in SSR/tests */ });
}

export { LANG_EXT, EXT_LANG, TEMPLATES, detectLanguage, getDefaultFile };
