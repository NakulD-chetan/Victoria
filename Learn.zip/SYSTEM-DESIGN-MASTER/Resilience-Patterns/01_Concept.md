# Resilience Patterns — Concept

> **Permanent Recall:** Resilience patterns prevent cascading failures and protect system stability. Core patterns: **Rate Limiting** (token bucket, leaky bucket, sliding window), **Circuit Breaker** (Closed→Open→Half-Open states), **Bulkhead** (thread/process isolation), **Retry** (exponential backoff + jitter), **Timeout** (connection vs read), **Idempotency** (keys for safe retries), **Graceful Degradation** (fallbacks, feature flags), **Chaos Engineering** (Chaos Monkey, fault injection), **Backpressure** (queue/rate-based overload handling).

---

## Rate Limiting

**Why needed:** Prevents abuse, protects backend from overload, enables fair resource sharing, cost control for APIs.

### Rate Limiting Algorithms

| Algorithm | How It Works | Pros | Cons |
|-----------|--------------|------|------|
| **Token Bucket** | Tokens added at fixed rate; request consumes token | Burst allowance, simple | Memory per key |
| **Leaky Bucket** | Requests "leak" out at fixed rate | Smooth output rate | No burst; queuing |
| **Fixed Window** | Count requests per fixed window (e.g., per minute) | Simple, low memory | Burst at boundaries |
| **Sliding Window Log** | Log each request timestamp; count in window | Accurate | O(n) memory, expensive |
| **Sliding Window Counter** | Hybrid: prev window + current | Good accuracy, bounded | Slight approximation |

```
TOKEN BUCKET:                    LEAKY BUCKET:
  [●●●] → tokens                   [●●●] → queue
  add 1/sec                        output 1/sec
  request takes 1 token             requests enqueue
       ↓                                ↓
  [●●] ← 2 left                    [●●] ← leaking out

FIXED WINDOW:                     SLIDING WINDOW:
  |----minute 1----|----minute 2---|
  ████ 60 req      ████ 60 req     Previous + Current
  Burst at boundary!               More accurate
```

> **FAANG Tip:** "Token bucket for bursty workloads; sliding window counter for accurate limits with bounded memory."

---

## Circuit Breaker Pattern

Prevents **cascading failures** by failing fast when a dependency is unhealthy.

### States and State Machine

| State | Behavior | Transition |
|-------|----------|------------|
| **Closed** | Requests pass through normally | → Open when failure threshold exceeded |
| **Open** | Requests fail immediately (fallback) | → Half-Open after timeout |
| **Half-Open** | Allow limited test requests | → Closed if success; → Open if failure |

```mermaid
flowchart LR
    CLOSED -->|"failure threshold exceeded"| OPEN
    OPEN -->|"timeout elapsed"| HALFOPEN
    HALFOPEN -->|"test success"| CLOSED
    HALFOPEN -->|"test failure"| OPEN
```

```
CIRCUIT BREAKER STATE MACHINE:

    CLOSED ──(5 failures)──► OPEN
      ▲                           │
      │                           │ (30s timeout)
      │                           ▼
      └──(1 success)── HALF-OPEN ◄─┘
              │
              └──(1 failure)──► OPEN
```

**Key parameters:** failure threshold (e.g., 5 failures), timeout (e.g., 30s before Half-Open), fallback response.

> **FAANG Tip:** "Circuit breaker = electrical fuse. Too many failures? Trip open. Don't hammer a failing service."

---

## Bulkhead Pattern

**Isolating failures** so one failing component doesn't consume all resources.

| Type | Description | Example |
|------|-------------|---------|
| **Thread pool isolation** | Separate thread pools per dependency | Payment vs Recommendation APIs |
| **Process isolation** | Separate processes/microservices | Bounded blast radius |
| **Connection pool** | Per-dependency connection limits | DB pool vs cache pool |

```
BULKHEAD = SHIP COMPARTMENTS

  [Payment Pool: 10 threads]   ← Payment API down? Only 10 blocked
  [Recommend Pool: 20 threads] ← Others unaffected
  [Search Pool: 30 threads]

  Without bulkhead: One dependency failure → all threads blocked → total outage
```

---

## Retry Pattern

| Strategy | Description | Use Case |
|----------|-------------|----------|
| **Simple retry** | N attempts, fixed delay | Transient glitches |
| **Exponential backoff** | 1s, 2s, 4s, 8s... | Reduce thundering herd |
| **Jitter** | Random offset to backoff | Avoid synchronized retries |
| **Retry budget** | Max retries per time window | Prevent retry storm |

```
EXPONENTIAL BACKOFF + JITTER:
  Attempt 1: wait 1s ± 25%
  Attempt 2: wait 2s ± 25%
  Attempt 3: wait 4s ± 25%
  ...
  Jitter = base * (0.75 + random() * 0.5)
```

> **FAANG Tip:** "Never retry without backoff. Never retry non-idempotent ops without idempotency keys."

---

## Timeout Pattern

| Type | What It Limits | Typical Value |
|------|----------------|---------------|
| **Connection timeout** | Time to establish connection | 5–10s |
| **Read timeout** | Time waiting for response after connect | 30s–60s |

```
Request lifecycle:
  [Connect] ──connection timeout──► [Read] ──read timeout──► [Done/Fail]
```

---

## Idempotency

**Why critical for retries:** Retrying a payment could charge twice. Idempotency ensures "same request = same result."

| Concept | Description |
|---------|-------------|
| **Idempotency key** | Client sends unique key; server deduplicates |
| **Implementation** | Store key→result in cache/DB; return stored result on duplicate |

```
CLIENT:  POST /payment  { idempotency_key: "abc-123", amount: 100 }
SERVER:  First time → process, store result, return
         Same key  → return stored result (no double charge)
```

---

## Graceful Degradation

| Technique | Description | Example |
|-----------|-------------|---------|
| **Feature flags** | Turn off non-critical features under load | Disable recommendations |
| **Fallback responses** | Return cached/stale/default data | "Last known price" |
| **Reduced functionality** | Disable optional paths | Read-only mode |

---

## Chaos Engineering

| Tool/Concept | Purpose |
|--------------|---------|
| **Netflix Chaos Monkey** | Randomly terminates production instances |
| **Fault injection** | Inject latency, errors, network partitions |
| **Game days** | Planned exercises simulating failures |

```
Chaos Engineering Loop:
  1. Steady state hypothesis
  2. Inject fault (kill instance, add latency)
  3. Verify system degrades gracefully
  4. Fix, improve, repeat
```

---

## Backpressure

Handling overload when producers outpace consumers.

| Approach | Description |
|----------|-------------|
| **Queue-based** | Bounded queue; reject or block when full |
| **Rate-based** | Consumer signals "slow down" to producer |

```
QUEUE-BASED:                    RATE-BASED:
  Producer → [Queue max 1000]     Producer ← "backpressure signal" ← Consumer
  Full? Reject / block            Consumer controls flow
```

---

## 30-SECOND REVISION BOX

```
RATE LIMIT: token bucket, sliding window counter
CIRCUIT BREAKER: Closed → Open → Half-Open; fail fast
BULKHEAD: thread/process isolation per dependency
RETRY: exponential backoff + jitter; idempotency for writes
TIMEOUT: connection vs read
IDEMPOTENCY: key-based dedup for safe retries
GRACEFUL DEGRADATION: fallbacks, feature flags
CHAOS: Chaos Monkey, fault injection, game days
BACKPRESSURE: bounded queue or rate signaling
```

---

**Next: [[02_Mental-Model]]**
