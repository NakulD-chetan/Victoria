# Design YouTube / Netflix — Video Streaming System

> **Video streaming = Upload + Transcode + Store + CDN + Adaptive Bitrate**
> YouTube pe 500 hours video har minute upload hota hai — samjho kaise handle hota hai!

---

## Table of Contents

1. [Requirements Clarification](#1-requirements-clarification)
2. [Back of Envelope Estimation](#2-back-of-envelope-estimation)
3. [High Level Design](#3-high-level-design)
4. [API Design](#4-api-design)
5. [Data Model / Database Schema](#5-data-model--database-schema)
6. [Deep Dive — Key Components](#6-deep-dive--key-components)
7. [Bottlenecks & Scaling](#7-bottlenecks--scaling)
8. [Trade-offs](#8-trade-offs)
9. [1 Minute Recall Block + 5 Bullet Memory Hooks](#9-1-minute-recall-block--5-bullet-memory-hooks)

---

## 1. Requirements Clarification

### 1.1 Functional Requirements

```
FUNCTIONAL REQUIREMENTS (Kya kya karna hai?)
│
├── Upload Flow
│   ├── Video upload (chunked/resumable)
│   ├── Thumbnail upload/auto-generation
│   └── Metadata (title, description, tags)
│
├── Streaming Flow
│   ├── Video playback (adaptive quality)
│   ├── Seek to position
│   ├── Pause/Resume
│   └── Watch history
│
├── Discovery & Search
│   ├── Search videos by keyword
│   ├── Recommendations (home feed)
│   ├── Trending, Categories
│   └── Subscriptions feed
│
├── Social Features
│   ├── Comments (separate service)
│   ├── Likes/Dislikes
│   ├── Subscriptions
│   └── Playlists
│
└── User Management
    ├── User profile
    ├── Watch history
    └── Preferences
```

### 1.2 Non-Functional Requirements

| Requirement | Target | Kyu Important? |
|-------------|--------|----------------|
| **Latency** | First byte < 2 sec | User wait nahi karega |
| **Availability** | 99.99% | Downtime = revenue loss |
| **Throughput** | Millions concurrent streams | Peak hours handle karna |
| **Scalability** | Linear with users | Growth handle karna |
| **Durability** | 99.999999999% (11 nines) | Video kabhi lose nahi hona chahiye |

### 1.3 Real-World Analogy — Dukaan vs YouTube

```
TRADITIONAL DUKAAN (Single Server)          YOUTUBE (Distributed)
┌─────────────────────┐                     ┌──────────────────────────────────┐
│  Ek dukaan          │                     │  Upload → Factory (Transcode)    │
│  Sab yahan se milta  │                     │  → Warehouse (S3)                 │
│  Door wale wait     │                     │  → Har city mein branch (CDN)     │
└─────────────────────┘                     │  User ko nearest branch se milta  │
         ❌ Slow, overload                   └──────────────────────────────────┘
                                                         ✅ Fast, scalable
```

---

## 2. Back of Envelope Estimation

### 2.1 Assumptions (YouTube-scale)

| Metric | Value | Source |
|--------|-------|--------|
| DAU | 500M | Active users daily |
| Videos | 1B | Total catalog |
| Upload rate | 500 hours/min | YouTube actual |
| Avg video length | 10 min | ~600 MB raw |
| Avg stream bitrate | 2 Mbps | 720p typical |
| Read:Write ratio | 1000:1 | Mostly watch, rarely upload |

### 2.2 QPS Estimation

```
UPLOAD QPS:
  500 hours/min = 500 × 60 = 30,000 hours/hour
  ≈ 8.3 videos/sec (assuming 1 hour avg) 
  Actually: 500×60/60 = 500 uploads/min ≈ 8-10 uploads/sec

STREAMING QPS (Reads):
  500M DAU × 5 videos/user/day = 2.5B views/day
  2.5B / 86,400 ≈ 29,000 QPS (average)
  Peak (2-3×) ≈ 60,000 - 90,000 QPS

SEARCH QPS:
  500M × 2 searches/day ≈ 12,000 QPS
```

### 2.3 Storage Estimation

```
RAW VIDEO (1 year):
  500 hours/min × 60 min × 24 × 365 = 262M hours/year
  Per hour raw (1080p) ≈ 10-20 GB
  Total: 262M × 15 GB ≈ 4 PB/year (raw only!)

TRANCODED (multiple qualities):
  1 quality = 2 GB/hour
  5 qualities (240p, 360p, 480p, 720p, 1080p) = 10 GB/hour
  Total: 262M × 10 ≈ 2.6 PB/year

METADATA:
  1B videos × 1 KB ≈ 1 TB (negligible)
```

### 2.4 Bandwidth Estimation

```
STREAMING BANDWIDTH (Peak):
  90,000 QPS × 2 Mbps = 180 Gbps
  CDN se serve = origin pe load nahi!

UPLOAD BANDWIDTH:
  10 uploads/sec × 600 MB = 6 GB/sec = 48 Gbps (raw upload)
```

---

## 3. High Level Design

### 3.1 Overall Architecture

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    VIDEO STREAMING SYSTEM                     │
                    └─────────────────────────────────────────────────────────────┘

    ┌──────────┐     ┌──────────────┐     ┌─────────────┐     ┌─────────────────┐
    │  Users   │────▶│  API Gateway │────▶│ Load Balancer│────▶│  App Servers     │
    │(Web/App) │     │  (Auth, etc) │     │              │     │  (Stateless)     │
    └──────────┘     └──────────────┘     └─────────────┘     └────────┬──────────┘
                                                                       │
         ┌─────────────────────────────────────────────────────────────┼─────────────────────┐
         │                                                             │                     │
         ▼                                                             ▼                     ▼
┌─────────────────┐                                          ┌─────────────────┐   ┌─────────────────┐
│  UPLOAD FLOW    │                                          │  STREAMING FLOW │   │  DISCOVERY      │
│                 │                                          │                 │   │                 │
│  Client ──▶ LB  │                                          │  Client ──▶ CDN │   │  Search Service │
│       │         │                                          │       │         │   │  Recommendation │
│       ▼         │                                          │       ▼         │   │  Metadata DB     │
│  Upload Service │                                          │  Edge Server    │   └─────────────────┘
│       │         │                                          │  (HLS/DASH)     │
│       ▼         │                                          │                 │
│  Message Queue  │                                          │  Cache hit?     │
│       │         │                                          │  Yes → Return   │
│       ▼         │                                          │  No → Origin    │
│  Transcoding    │                                          │  (S3) pull      │
│  Workers        │                                          └─────────────────┘
│       │         │
│       ▼         │
│  Object Store   │
│  (S3)           │
└─────────────────┘
```

### 3.2 Upload Flow (Step-by-Step)

```
UPLOAD PIPELINE
═══════════════

[User] ──1. Chunked Upload──▶ [Upload Service] ──2. Store Raw──▶ [S3 Raw Bucket]
                                                                        │
                                                                        │ 3. Publish event
                                                                        ▼
[Transcode Worker] ◀──4. Consume── [Message Queue (Kafka/SQS)]
        │
        │ 5. Transcode (FFmpeg)
        │    - 240p, 360p, 480p, 720p, 1080p
        │    - HLS segments (6 sec each)
        │    - Thumbnail generation
        ▼
[S3 Transcoded Bucket] ──6. Invalidate CDN──▶ [CDN Edge]
        │
        │ 7. Update metadata
        ▼
[Metadata DB] ◀── Video ready for streaming!
```

### 3.3 Streaming Flow (Adaptive Bitrate)

```
ADAPTIVE BITRATE STREAMING (ABR)
════════════════════════════════

                    ┌─────────────────────────────────────┐
                    │           CDN EDGE SERVER            │
                    │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐   │
                    │  │240p │ │360p │ │720p │ │1080p│   │
                    │  │.m3u8│ │.m3u8│ │.m3u8│ │.m3u8│   │
                    │  └─────┘ └─────┘ └─────┘ └─────┘   │
                    └─────────────────────────────────────┘
                                    │
                                    │ Client requests manifest
                                    ▼
    ┌─────────────┐         ┌──────────────────┐
    │   Client    │◀───────▶│  ABR Algorithm   │
    │  (Player)   │  Buffer │  - Network speed  │
    │             │  level  │  - Buffer level   │
    └─────────────┘         │  - Device capability│
                            └──────────────────┘
                                    │
                    Selects best quality segment
                    (e.g., 720p if connection good)
```

---

## 4. API Design

### 4.1 Upload APIs

```
POST /api/v1/videos/upload/init
  Request: { title, description, duration_estimate, file_size }
  Response: { upload_id, chunk_urls[] }  // Pre-signed URLs for chunks

PUT /api/v1/videos/upload/chunk/{upload_id}/{chunk_num}
  Request: Binary chunk data
  Response: { success, etag }

POST /api/v1/videos/upload/complete
  Request: { upload_id, chunk_etags[] }
  Response: { video_id, status: "processing" }
  → Triggers transcoding pipeline
```

### 4.2 Streaming APIs

```
GET /api/v1/videos/{video_id}/stream
  Query: ?quality=auto|360p|720p
  Response: Redirect to CDN URL (signed, time-limited)

GET /api/v1/videos/{video_id}/manifest
  Response: HLS .m3u8 or DASH .mpd URL
  → Client fetches manifest, then segments from CDN
```

### 4.3 Discovery APIs

```
GET /api/v1/videos/search?q={query}&page=1&limit=20
GET /api/v1/videos/trending
GET /api/v1/videos/recommended  // Personalized
GET /api/v1/videos/{video_id}   // Metadata
```

---

## 5. Data Model / Database Schema

### 5.1 Videos Metadata (MySQL — Strong Consistency)

```sql
-- Videos table (sharded by video_id)
CREATE TABLE videos (
    video_id BIGINT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    title VARCHAR(255),
    description TEXT,
    duration_seconds INT,
    status ENUM('uploading', 'processing', 'ready', 'failed'),
    thumbnail_url VARCHAR(512),
    created_at TIMESTAMP,
    updated_at TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_status_created (status, created_at)
);

-- Transcoding output (multiple qualities per video)
CREATE TABLE video_qualities (
    video_id BIGINT,
    quality ENUM('240p', '360p', '480p', '720p', '1080p'),
    manifest_url VARCHAR(512),  -- HLS/DASH URL
    PRIMARY KEY (video_id, quality)
);
```

### 5.2 User Activity (Cassandra — High Write, Eventual Consistency)

```
-- Watch history, likes — write-heavy, read-your-writes
user_activity (
    user_id,
    video_id,
    event_type,  // watch, like, dislike
    watch_duration,
    timestamp
)
Partition key: user_id
Clustering: timestamp DESC
```

### 5.3 Storage Layout (S3)

```
s3://video-bucket/
├── raw/
│   └── {upload_id}/chunks/     # Temporary, delete after transcode
├── transcoded/
│   └── {video_id}/
│       ├── 240p/
│       │   ├── manifest.m3u8
│       │   └── segment_0.ts, segment_1.ts, ...
│       ├── 360p/
│       ├── 720p/
│       └── thumbnails/
│           ├── default.jpg
│           └── 0.jpg, 1.jpg, ...  # Preview thumbnails
```

---

## 6. Deep Dive — Key Components

### 6.1 Video Transcoding Pipeline

**Kyu zaroori?** Raw video (e.g., 4K) sabko bhejenge? Nahi! Device + network ke hisaab se quality.

```
TRANSCODING PIPELINE
════════════════════

Input: Raw video (any format)
       │
       ▼
┌──────────────────────────────────────────────────────────┐
│  FFmpeg / Transcoding Worker (GPU preferred)              │
│                                                          │
│  For each quality (240p to 1080p):                        │
│    1. Decode raw                                         │
│    2. Scale to resolution                                 │
│    3. Encode (H.264/H.265)                                │
│    4. Segment into 6-sec chunks (HLS)                     │
│    5. Generate manifest (.m3u8)                           │
│                                                          │
│  Parallel: Thumbnail extraction (1 per 10 sec)            │
└──────────────────────────────────────────────────────────┘
       │
       ▼
Output: Multiple quality streams + thumbnails → S3
```

**Netflix Open Connect:** Netflix apne CDN servers ISPs ke data centers mein install karta hai! Content pre-cached. YouTube Google's CDN use karta hai.

### 6.2 Adaptive Bitrate Streaming (HLS/DASH)

| Protocol | Format | Used By |
|----------|--------|---------|
| **HLS** | Apple, .m3u8 + .ts segments | iOS, Safari, many |
| **DASH** | MPEG-DASH, .mpd + segments | Android, Chrome |

```
HLS MANIFEST EXAMPLE
════════════════════

#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=640x360
360p/playlist.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=1400000,RESOLUTION=1280x720
720p/playlist.m3u8

Client: Network slow? → 360p select karo
        Network fast? → 720p select karo
        Buffer low?   → Lower quality
        Buffer high?  → Higher quality
```

### 6.3 CDN Strategy

```
CDN CACHING STRATEGY
════════════════════

                    ┌─────────────────────────────────┐
                    │     POPULAR VIDEO (Hot)          │
                    │  → CDN edge pe cache             │
                    │  → 90%+ requests edge se         │
                    └─────────────────────────────────┘

                    ┌─────────────────────────────────┐
                    │     LONG TAIL (Cold)             │
                    │  → Edge miss → Origin (S3)        │
                    │  → First request slow             │
                    │  → Cache warming for trending     │
                    └─────────────────────────────────┘
```

### 6.4 Recommendation Engine (Basic)

```
RECOMMENDATION FLOW
═══════════════════

1. Collaborative Filtering: "Users who watched X also watched Y"
2. Content-based: Similar tags, category
3. Watch history: Recently watched, resume
4. Trending: Viral videos
5. Hybrid: Sab mix karke score

Storage: Pre-computed recommendations in Redis/Cache
         Batch job (daily) updates
```

### 6.5 Search and Discovery

```
SEARCH PIPELINE
═══════════════

Query: "machine learning tutorial"
       │
       ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│ Tokenize    │───▶│ Search      │───▶│ Rank        │
│ "machine",  │    │ Inverted    │    │ Relevance + │
│ "learning", │    │ Index       │    │ Popularity  │
│ "tutorial"  │    │ (Elasticsearch)   │             │
└─────────────┘    └─────────────┘    └─────────────┘
```

### 6.6 Comments, Likes — Separate Service

```
SOCIAL FEATURES (Microservice)
══════════════════════════════

Comments Service:
  - High write (comments)
  - Nested replies
  - Pagination
  - DB: PostgreSQL + Cache

Likes Service:
  - Counter (denormalized)
  - User-video like mapping
  - Async update counts
```

### 6.7 Thumbnail Generation

```
THUMBNAIL PIPELINE
══════════════════

1. During transcode: FFmpeg -ss 00:00:05 -i video.mp4 -vframes 1 thumb.jpg
2. Multiple thumbnails: 1 per 10 sec (for seek preview)
3. Storyboard: Grid of thumbnails for hover preview
4. Store: S3 transcoded bucket, CDN cached
5. Default: First frame or manually selected by uploader
```

### 6.8 Video Upload — Chunked/Resumable

```
CHUNKED UPLOAD (Large files)
════════════════════════════

Problem: 4K video = 10GB+, single request = timeout

Solution: Chunked upload
  1. Client splits file into 5MB chunks
  2. Init upload → Get pre-signed URLs per chunk
  3. Upload chunks in parallel (faster!)
  4. Complete → Server assembles (multipart)
  5. Resumable: Chunk fail? Retry only that chunk

  [Chunk 1] [Chunk 2] [Chunk 3] ... [Chunk N]
       │         │         │              │
       └─────────┴─────────┴──────────────┘
                         │
                         ▼
                    S3 Multipart Upload API
```

### 6.9 Netflix Open Connect (CDN Strategy)

```
NETFLIX OPEN CONNECT
════════════════════

Netflix ka apna CDN — ISPs ke data centers mein!

1. Netflix servers (Open Connect Appliances) install karta hai
2. ISP pe free — Netflix content pre-cache karta hai
3. User stream karta hai → Local ISP se → Super fast!
4. 95%+ traffic Open Connect se serve
5. Push model: Popular content pehle se push

  [Netflix Origin] ──Push popular──▶ [ISP Data Center - OCA]
                                          │
                                          ▼
                                    [User - Same ISP]
                                    Latency: < 10ms!
```

---

## 7. Bottlenecks & Scaling

### 7.1 Bottleneck Analysis

| Component | Bottleneck | Solution |
|-----------|------------|----------|
| **Upload** | Bandwidth, single server | Chunked upload, multi-part, direct to S3 |
| **Transcoding** | CPU/GPU intensive | Worker pool, regional transcoding, GPU instances |
| **Storage** | Cost, durability | S3/object storage, lifecycle (raw delete after transcode) |
| **Streaming** | Bandwidth, latency | CDN everywhere, edge caching |
| **Metadata DB** | Read scale | Sharding by video_id, read replicas |
| **Search** | Query latency | Elasticsearch, caching hot queries |

### 7.2 Scaling Strategies

```
SCALING CHECKLIST
═════════════════

1. CDN: Har region mein edge — 90% traffic CDN se
2. Transcoding: Regional workers (India upload → India transcode)
3. Metadata: Shard by video_id (hash)
4. Cache: Video metadata, recommendations in Redis
5. Async: Upload → Queue → Transcode (decouple)
6. Pre-compute: Thumbnails, recommendations batch jobs
```

---

## 8. Trade-offs

| Decision | Choice | Trade-off |
|----------|--------|-----------|
| **Transcode location** | Regional vs Central | Regional = low latency, Central = simpler |
| **Quality levels** | 5 vs 10 | More = better UX, more storage + transcode cost |
| **CDN** | Push vs Pull | Push = predictable, Pull = simpler |
| **Metadata DB** | MySQL vs NoSQL | MySQL = consistency, NoSQL = scale writes |
| **Recommendations** | Real-time vs Batch | Real-time = complex, Batch = simpler |

---

## 9. 1 Minute Recall Block + 5 Bullet Memory Hooks

### 1 Minute Recall Block

> **Video Streaming = Upload → Transcode (multiple qualities) → S3 → CDN → Client (ABR)**
> Raw video kabhi store mat karo long-term. Transcode karke multiple qualities banao. CDN edge pe cache — 90% traffic wahan se. HLS/DASH = adaptive bitrate. Metadata MySQL, activity Cassandra. Transcoding = bottleneck → workers + GPU.

### 5 Bullet Memory Hooks

1. **Upload → Queue → Transcode → S3** — Async pipeline, never block upload
2. **CDN everywhere** — Streaming bandwidth CDN handle karega, origin nahi
3. **ABR (HLS/DASH)** — Client network ke hisaab se quality select karta hai
4. **Raw delete, transcoded keep** — Storage cost bachao
5. **Metadata sharded, Activity Cassandra** — Scale reads + writes separately

---

*End of YouTube/Netflix Design — FAANG Interview Ready!*
