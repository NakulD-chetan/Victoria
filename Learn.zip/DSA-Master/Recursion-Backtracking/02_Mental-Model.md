# Recursion-Backtracking — Mental Model

> **Permanent Recall:** FAANG engineers think in decision trees. Every node = a choice. Use "Choose, Explore, Unchoose." Pruning = don't go down dead-end branches. Subsets = include/exclude; Permutations = pick from remaining; Combinations = subsets with size k.

---

## How FAANG Engineers Think About Backtracking

1. **"What am I building?"** — A subset? A permutation? A path?
2. **"What's one decision?"** — The smallest choice at each step
3. **"Draw the tree"** — Even 2 levels clarifies everything
4. **"Where can I prune?"** — Invalid branches = cut early
5. **"What state do I need?"** — Parameters to make decisions

**Mantra:** *If you can draw the tree, the code writes itself.*

---

## Decision Tree Visualization

### Every Node = A Choice

```
                    [ROOT]
                 "What do I choose here?"
                   /   |   \
              Option A  B   C
                 |     |    |
            "What next?"  ...
                 / \
            Opt1  Opt2
```

- **Root** = empty/initial state
- **Internal node** = partial solution + "what's my next choice?"
- **Leaf** = complete solution OR dead end (pruned)

### Subsets of {1, 2, 3} — Binary Tree

```
                        {}
                   /         \
              include 1     exclude 1
                 |             |
               {1}             {}
             /     \         /     \
        inc 2   exc 2   inc 2   exc 2
          |      |        |       |
       {1,2}   {1}     {2}      {}
        / \    / \     / \     / \
     ...  ... ... ... ... ... ... {}
     
     Each path root→leaf = one subset
     2^3 = 8 leaves
```

### Permutations of {1, 2, 3} — k-ary Tree

```mermaid
flowchart TD
    R["[]"]
    R -->|pick 1| A["[1]"]
    R -->|pick 2| B["[2]"]
    R -->|pick 3| C["[3]"]
    A -->|pick 2| A1["[1,2]"]
    A -->|pick 3| A2["[1,3]"]
    B -->|pick 1| B1["[2,1]"]
    B -->|pick 3| B2["[2,3]"]
    C -->|pick 1| C1["[3,1]"]
    C -->|pick 2| C2["[3,2]"]
    style R fill:#ffd43b,color:#000
    style A fill:#339af0,color:#fff
    style B fill:#339af0,color:#fff
    style C fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
                          []
                    /     |     \
              pick 1    pick 2   pick 3
                 |        |        |
               [1]      [2]      [3]
              /   \    /   \    /   \
         pick 2  3  pick 1  3  pick 1 2
            |   |     |   |     |   |
        [1,2] [1,3] [2,1] [2,3] [3,1] [3,2]
          |     |     |     |     |     |
       [1,2,3][1,3,2][2,1,3][2,3,1][3,1,2][3,2,1]
       
       3 × 2 × 1 = 6 leaves
```

</details>

---

## "Choose, Explore, Unchoose" Framework

```
At each node:
  1. CHOOSE   — make a decision (add to partial solution)
  2. EXPLORE  — recurse (go deeper)
  3. UNCHOOSE — undo the decision (backtrack)
```

### Physical Analogy: Maze

```
Start → Junction A → Left  → Dead end ✗
                   ← BACKTRACK
         Junction A → Right → Junction B → Exit ✓
```

- **Choose** = walk forward (take a path)
- **Explore** = keep walking until dead end or exit
- **Unchoose** = walk back to last junction

### Code Skeleton

```python
def backtrack(state):
    if base_case(state):
        record(state)
        return
    for choice in choices(state):
        if valid(choice):
            state.add(choice)      # CHOOSE
            backtrack(state)       # EXPLORE
            state.remove(choice)   # UNCHOOSE
```

---

## Pruning: Don't Go Down Dead-End Branches

### Why Prune?

- Without pruning: explore entire tree = brute force
- With pruning: skip subtrees that can't yield valid solutions

```
Full tree (n=4): 2^4 = 16 leaves
With pruning:    maybe 8 leaves (50% cut)
```

### Types of Pruning

| Type | Question | Example |
|------|----------|---------|
| **Feasibility** | "Can this ever be valid?" | Sum already > target → stop |
| **Optimality** | "Can this beat best so far?" | Cost ≥ best → stop |
| **Duplicate** | "Did I try this before?" | Same value, skip |
| **Bounds** | "Enough remaining?" | Need k more, only k-1 left → prune |

### Pruning in Subsets with Duplicates

```
nums = [1, 2, 2]
Without: {1}, {2}, {2}, {1,2}, {1,2}, {1,2,2}... duplicates!
With:    Sort, skip when nums[i]==nums[i-1] and we excluded nums[i-1]
```

```
        {}
       /   \
     {1}    {} 
     / \    / \
  {1,2} {1} {2}  {}   ← second "2" branch: skip if we skipped first "2"
    |   |   |    |
  ...  ... {2,2} ...
```

---

## Subsets vs Permutations vs Combinations — Decision

```mermaid
flowchart TD
    A[Problem asks for...]
    A --> B["All subsets / subsequences"]
    A --> C["All orderings / arrangements"]
    A --> D["All combinations of size k"]
    A --> E["Combinations that sum to X"]
    B --> B1[SUBSETS: include/exclude, binary 2^n]
    C --> C1[PERMUTATIONS: pick remaining, k-ary n!]
    D --> D1[COMBINATIONS: subsets + size k]
    E --> E1[COMBINATION SUM: subsets + sum constraint]
    style A fill:#ffd43b,color:#000
    style B1 fill:#51cf66,color:#fff
    style C1 fill:#51cf66,color:#fff
    style D1 fill:#51cf66,color:#fff
    style E1 fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
Problem asks for...
│
├─ "All subsets" / "all subsequences"
│   → SUBSETS: include/exclude each element, index-based
│   → Tree: binary, 2^n
│
├─ "All orderings" / "all arrangements"
│   → PERMUTATIONS: pick from remaining, used[] or swap
│   → Tree: k-ary, n!
│
├─ "All combinations of size k"
│   → COMBINATIONS: subsets + prune when size ≠ k
│   → Tree: binary + size constraint
│
└─ "Combinations that sum to X"
    → COMBINATION SUM: subsets + sum constraint
    → Unlimited use: can reuse element (don't advance index when include)
    → Unique use: standard include/exclude
```

</details>

### Quick Recognition Table

| Phrase | Type |
|--------|------|
| "all subsets" | Subsets |
| "all permutations" | Permutations |
| "choose k from n" | Combinations |
| "sum to target" | Combination sum |
| "place n queens" | Placement (permutation-like) |
| "fill grid" | Constraint satisfaction |

---

## ASCII Tree Summary

### Subsets (Include/Exclude)

```mermaid
flowchart TD
    R["{}"]
    R --> A["[1]"]
    R --> B["[]"]
    A --> A1["[1,2]"]
    A --> A2["[1]"]
    B --> B1["[2]"]
    B --> B2["[]"]
    style R fill:#ffd43b,color:#000
```

<details><summary>ASCII fallback</summary>

```
        {}
      /    \
   [1]      []
  /   \    /   \
[1,2] [1] [2]  []
```

</details>

### Permutations (Pick from Remaining)

```mermaid
flowchart TD
    R["[]"]
    R --> A["[1]"]
    R --> B["[2]"]
    R --> C["[3]"]
    A --> A1["[1,2]"]
    A --> A2["[1,3]"]
    style R fill:#ffd43b,color:#000
```

<details><summary>ASCII fallback</summary>

```
         []
       / | \
      [1][2][3]
      / \ ...
   [1,2][1,3]
```

</details>

### N-Queens (Place in Column)

```mermaid
flowchart TD
    R[row 0]
    R --> c0[c0]
    R --> c1[c1]
    R --> c2[c2]
    R --> c3[c3]
    R --> c4[c4]
    c0 --> r1a[row 1]
    c1 --> r1b[row 1]
    r1a --> c1a[c1]
    r1a --> c3a[c3]
    r1a --> c4a[c4]
    style R fill:#ffd43b,color:#000
    style c0 fill:#e03131,color:#fff
    style c2 fill:#e03131,color:#fff
```

<details><summary>ASCII fallback</summary>

```
              row 0
         /  |  |  |  \
       c0  c1 c2 c3 c4
        |   |
    row 1  row 1
   /  |  \  ...
  c1 c3 c4  (c0,c2 pruned - attack)
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL MODEL:     Decision tree — every node = choice
FRAMEWORK:        Choose → Explore → Unchoose
PRUNING:          Cut branches that can't lead to valid solution
SUBSETS:          Include/exclude, binary tree, 2^n
PERMUTATIONS:     Pick from remaining, k-ary, n!
COMBINATIONS:     Subsets + size k, prune by count
RECOGNITION:      "All subsets"→subsets, "all orderings"→permutations
INTERVIEW:        Draw 2 levels of tree first, then code
```
