# 06 — Apache Iceberg Internals

> Iceberg is an **open table format** with a **metadata tree** architecture (catalog → metadata files → manifest lists → manifest files → data files) that enables **hidden partitioning**, **partition evolution**, **snapshot isolation**, and true **engine-neutrality** — the fastest-growing table format in 2026.

---

## 1. What Is Iceberg and What Problem It Solves

Iceberg is a **table format** (like Delta Lake) — it organizes collections of data files (typically Parquet) into a logical table with ACID guarantees, schema evolution, and time travel.

Its key differentiator is solving the problems of **Hive-style tables** on object storage:

| Problem with Hive-style Tables | Iceberg's Solution |
|-------------------------------|-------------------|
| Partitions are directory paths — users must know the partition structure | **Hidden partitioning** — users query naturally, engine handles partition pruning |
| Listing files is slow (S3 LIST is expensive at scale) | **Metadata tree** — manifest files list all data files, no S3 listing needed |
| No ACID — concurrent writes can corrupt data | **Snapshot isolation** — readers never see partial writes |
| Schema changes are risky, renames lose data | **Column IDs** — enables safe rename, reorder, and evolution |
| Partition changes require full data rewrite | **Partition evolution** — change partitioning without rewriting data |

| Property | Detail |
|----------|--------|
| **Created by** | Netflix (2017), donated to Apache |
| **Adopted by** | Snowflake, AWS (Athena, Glue), Apple, Netflix, LinkedIn |
| **Data files** | Parquet (default), also supports ORC and Avro |
| **Engine support** | Spark, Flink, Trino, Presto, Hive, Dremio, Snowflake, StarRocks |

---

## 2. Metadata Tree — The Architecture

This is the most important concept in Iceberg. Understand this diagram and you can explain almost everything about how Iceberg works.

```
┌─────────────────────────────────────────────────────┐
│                    CATALOG                           │
│  (Hive Metastore / AWS Glue / REST / Nessie)        │
│  Stores → pointer to current metadata file          │
└────────────────────┬────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────┐
│              METADATA FILE (JSON)                    │
│  - Table schema (current + history)                  │
│  - Partition spec (current + history)                │
│  - Current snapshot ID                               │
│  - List of all snapshots                             │
│  - Sort order, table properties                      │
└────────────────────┬────────────────────────────────┘
                     │ current snapshot
                     ▼
┌─────────────────────────────────────────────────────┐
│           MANIFEST LIST (Avro file)                  │
│  - List of manifest files for this snapshot          │
│  - Per-manifest summary: partition range, file count │
│  - Added/deleted file counts                         │
└────────────────────┬────────────────────────────────┘
                     │
            ┌────────┴────────┐
            ▼                 ▼
┌───────────────────┐ ┌───────────────────┐
│ MANIFEST FILE 1   │ │ MANIFEST FILE 2   │
│ (Avro file)       │ │ (Avro file)       │
│                   │ │                   │
│ For each data file:│ │ For each data file:│
│ - file path       │ │ - file path       │
│ - partition values│ │ - partition values│
│ - record count    │ │ - record count    │
│ - column stats    │ │ - column stats    │
│   (min, max,      │ │   (min, max,      │
│    null count)    │ │    null count)    │
└────────┬──────────┘ └────────┬──────────┘
         │                     │
    ┌────┴────┐           ┌────┴────┐
    ▼         ▼           ▼         ▼
┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐
│Parquet │ │Parquet │ │Parquet │ │Parquet │
│File 1  │ │File 2  │ │File 3  │ │File 4  │
└────────┘ └────────┘ └────────┘ └────────┘
```

### Why This Tree Structure Matters

| Benefit | How |
|---------|-----|
| **No file listing (no S3 LIST)** | Manifest files already contain the exact paths of all data files |
| **Fast query planning** | Manifest-level partition summaries → skip entire manifests. File-level stats → skip individual files |
| **Snapshot isolation** | Each snapshot points to its own manifest list → readers see a consistent, immutable view |
| **Incremental processing** | Compare manifest lists between snapshots → identify only the changed files |
| **Metadata pruning** | At every level of the tree, statistics allow skipping — manifests, files, or the entire table |

**Deep concept — Why no S3 LIST matters:**
On Hive-style tables, to read a partitioned table with 100,000 partitions, the engine must issue S3 LIST calls for every partition directory. Each LIST call takes ~100ms and returns at most 1,000 keys. For large tables, query planning alone can take **minutes** just listing files. Iceberg eliminates this entirely — manifest files contain all file paths, so the engine reads a few small Avro files instead of issuing thousands of API calls.

---

## 3. Hidden Partitioning

### The Problem with Hive-Style Partitioning

```sql
-- Table is partitioned by year, month, day directories
-- Users MUST know and use the partition structure:
SELECT * FROM events WHERE year=2024 AND month=01 AND day=15;

-- This does NOT use partitions — causes a FULL SCAN:
SELECT * FROM events WHERE event_date = '2024-01-15';

-- Users must manually decompose dates into partition columns
```

### Iceberg's Solution — Partition Transforms

```sql
-- Define partition transform ONCE at table creation
CREATE TABLE events (
    event_id BIGINT,
    event_date TIMESTAMP,
    user_id BIGINT,
    action STRING
) USING iceberg
PARTITIONED BY (days(event_date));

-- Users query naturally — Iceberg translates to partition pruning automatically
SELECT * FROM events WHERE event_date = '2024-01-15';
-- Iceberg: applies days() transform → prunes to correct partition → efficient scan
```

The partition columns are **hidden** from users. Users write natural predicates; the engine applies transforms and prunes automatically.

### Supported Partition Transforms

| Transform | Input | Partition Value | Example |
|-----------|-------|----------------|---------|
| `year(ts)` | Timestamp | Year integer | `2024` |
| `month(ts)` | Timestamp | Year-month | `2024-01` |
| `day(ts)` | Timestamp | Date | `2024-01-15` |
| `hour(ts)` | Timestamp | Date-hour | `2024-01-15-08` |
| `bucket(N, col)` | Any type | Hash bucket 0 to N-1 | `bucket(16, user_id)` → `7` |
| `truncate(L, col)` | String/Int | Truncated value | `truncate(3, city)` → `"Mum"` |
| `identity(col)` | Any type | Same value (like Hive-style) | Standard partitioning |

---

## 4. Partition Evolution — Change Without Rewriting

This is a capability unique to Iceberg. You can change how a table is partitioned **without rewriting any existing data**.

```sql
-- Start with monthly partitioning (low data volume)
CREATE TABLE logs (...) PARTITIONED BY (month(ts));

-- Traffic grows → need daily partitioning for better pruning
ALTER TABLE logs ADD PARTITION FIELD day(ts);

-- Old data stays monthly partitioned
-- New data is daily partitioned
-- Queries work across BOTH seamlessly — Iceberg handles it
-- NO DATA REWRITE needed
```

**How to explain it:** "Iceberg's partition evolution lets you change the partitioning strategy without rewriting existing data. Old data keeps old partitioning, new data uses new partitioning. The metadata tree tracks both partition specs, and queries work correctly across all data."

---

## 5. Snapshot Isolation & Time Travel

Every write in Iceberg creates a new snapshot. Each snapshot is an immutable, consistent view of the table.

```
Snapshot 1: [file_A, file_B]
    │
    ├── Writer adds file_C, removes file_A
    │
Snapshot 2: [file_B, file_C]
    │
    ├── Writer adds file_D
    │
Snapshot 3: [file_B, file_C, file_D]

Reader at snapshot 1 → sees file_A + file_B (even if snapshot 3 is current)
Writers don't block readers. Readers don't block writers.
```

```sql
-- Time travel by snapshot ID
SELECT * FROM orders VERSION AS OF 12345;

-- Time travel by timestamp
SELECT * FROM orders TIMESTAMP AS OF '2024-01-15 10:00:00';

-- View snapshot history
SELECT * FROM orders.snapshots;
```

---

## 6. Schema Evolution — Column IDs Make the Difference

| Operation | Supported? | Detail |
|-----------|-----------|--------|
| **Add column** | Yes | New column has NULL in old data files (no rewrite) |
| **Drop column** | Yes | Column ignored in reads (no rewrite) |
| **Rename column** | Yes | Uses column IDs, not names — data preserved |
| **Reorder columns** | Yes | Metadata-only change |
| **Widen type** | Yes | int → long, float → double |
| **Change required ↔ optional** | Yes | Make nullable or required |

### Why Column IDs Matter — The Key Insight

```
Parquet (and Delta) match columns by NAME:
  Rename "city" to "location" 
  → Parquet sees: DROP "city" + ADD "location" 
  → Old data for "city" becomes inaccessible → DATA LOSS

Iceberg matches columns by ID:
  Column "city" has internal ID = 5
  Rename "city" to "location" → still ID = 5
  → Old data files: column with ID 5 is read correctly
  → DATA PRESERVED
```

This is why Iceberg has **the safest schema evolution** among all table formats. Renaming and reordering columns are metadata-only operations that never risk data loss.

---

## 7. Iceberg vs Delta Lake

| Feature | Iceberg | Delta Lake |
|---------|---------|------------|
| **Engine support** | Spark, Flink, Trino, Presto, Hive, Dremio, Snowflake, StarRocks | Primarily Spark/Databricks, growing elsewhere |
| **Partitioning** | Hidden (transforms) + partition evolution | Standard directory partitioning |
| **Schema evolution** | Column IDs (rename-safe, reorder-safe) | Column names (rename risky) |
| **Metadata** | Tree (catalog → metadata → manifests → data) | Transaction log (sequential JSON files) |
| **File listing** | No S3 LIST (manifest has all paths) | No S3 LIST (log has file paths) |
| **Clustering** | Sort order in metadata | Z-ORDER |
| **Governance** | Multi-engine catalogs (Nessie, REST, Polaris) | Unity Catalog (Databricks) |
| **Community** | Apache, vendor-neutral | Linux Foundation, Databricks-driven |
| **2026 adoption** | Growing fastest (Snowflake, AWS, Netflix adopted) | Strong in Databricks ecosystem |

**How to explain it:** "Choose Iceberg for engine-neutral environments where you need Snowflake + Spark + Trino to all access the same tables. Choose Delta for Databricks-heavy environments where the tight Spark/Databricks integration matters most."

---

## 8. Iceberg in Spark — Key Operations

```python
# Read Iceberg table
df = spark.read.format("iceberg").load("catalog.db.orders")

# Write to Iceberg table
df.writeTo("catalog.db.orders").append()
df.writeTo("catalog.db.orders").overwritePartitions()

# Create table from DataFrame
df.writeTo("catalog.db.orders") \
    .partitionedBy(days("event_date")) \
    .createOrReplace()
```

### Iceberg Write Modes / Operations

| Operation | What It Does | Use Case |
|-----------|-------------|----------|
| `append()` | Add new data files | Incremental loads |
| `overwritePartitions()` | Replace only partitions present in the DataFrame | Dynamic partition overwrite |
| `createOrReplace()` | Create table or replace if exists | Full refresh / initial load |
| `create()` | Create new table — fails if exists | First-time creation |
| `replace()` | Replace existing table — fails if not exists | Controlled full replacement |

### Important Iceberg Table Properties

| Property | Purpose |
|----------|---------|
| `write.format.default` | Default data file format: `parquet` (default), `orc`, `avro` |
| `write.target-file-size-bytes` | Target size for data files (default 512 MB) |
| `write.metadata.delete-after-commit.enabled` | Auto-clean old metadata files |
| `history.expire.max-snapshot-age-ms` | Auto-expire snapshots older than this |
| `read.split.target-size` | Target split size for read tasks |
| `write.parquet.compression-codec` | Compression for Parquet files: `zstd`, `snappy`, `gzip` |

---

## 9. Maintenance Operations (Housekeeping)

| Operation | What It Does | Equivalent in Delta |
|-----------|-------------|-------------------|
| **Expire snapshots** | Remove old snapshots and their metadata | VACUUM |
| **Remove orphan files** | Clean up data files not referenced by any snapshot | N/A (Delta handles via log) |
| **Rewrite data files** | Compact small files into larger ones | OPTIMIZE |
| **Rewrite manifests** | Compact manifest files for faster planning | N/A (Delta uses checkpoints) |

```sql
-- Expire old snapshots (like VACUUM)
CALL catalog.system.expire_snapshots('db.orders', TIMESTAMP '2024-01-01 00:00:00');

-- Compact small files (like OPTIMIZE)
CALL catalog.system.rewrite_data_files('db.orders');

-- Clean up orphan files
CALL catalog.system.remove_orphan_files('db.orders');

-- Compact manifests for faster planning
CALL catalog.system.rewrite_manifests('db.orders');
```

---

## 10. Interview Questions & How to Answer

**Q: "What is Apache Iceberg?"**
> Iceberg is an open table format that organizes data files (usually Parquet) into a logical table with ACID transactions, time travel, schema evolution, and hidden partitioning. Its metadata tree architecture (catalog → metadata file → manifest list → manifest files → data files) eliminates expensive S3 LIST calls and enables fast query planning.

**Q: "Explain Iceberg's metadata structure"**
> Four levels: (1) Catalog points to the current metadata file. (2) Metadata file (JSON) contains the schema, partition spec, and current snapshot ID. (3) Manifest list (Avro) lists all manifest files for a snapshot with summary statistics. (4) Manifest files (Avro) list individual data files with partition values and column-level min/max stats. Data files are Parquet.

**Q: "What is hidden partitioning?"**
> Users define partition transforms (day, month, bucket, truncate) at table creation. Users then query with natural predicates like `WHERE event_date = '2024-01-15'`. The engine automatically applies the transform and prunes partitions. Users never need to know the partition structure.

**Q: "What is partition evolution?"**
> The ability to change the partitioning strategy without rewriting existing data. Old data keeps old partitioning, new data uses new partitioning. Iceberg's metadata tracks both partition specs, and queries work correctly across all data.

**Q: "Iceberg vs Delta Lake?"**
> Iceberg: engine-neutral (Spark, Flink, Trino, Snowflake), hidden partitioning, column IDs for safe renames, partition evolution. Delta: Databricks ecosystem, Z-ORDER clustering, Unity Catalog. Choose Iceberg for multi-engine. Choose Delta for Databricks-heavy.

**Q: "How does schema evolution work in Iceberg?"**
> Iceberg assigns internal column IDs. When you rename a column, the ID stays the same — old data files are read correctly. This is unique to Iceberg. Add, drop, rename, reorder, and type widening are all metadata-only operations — no data files are rewritten.

**Q: "Why is there no S3 LIST in Iceberg?"**
> Manifest files contain the exact paths of all data files. The engine reads a few small Avro manifest files instead of issuing thousands of S3 LIST API calls. For tables with millions of files, this reduces query planning from minutes to seconds.

---

## Key Takeaways

1. **Iceberg** = open table format with a **metadata tree** architecture (catalog → metadata → manifests → data).
2. **No S3 LIST** — manifest files contain all file paths, eliminating the biggest performance bottleneck on object storage.
3. **Hidden partitioning** — users query naturally with simple predicates; the engine applies transforms and prunes automatically.
4. **Partition evolution** — change partitioning without rewriting data. Old and new partitioning coexist.
5. **Column IDs** — enable safe rename and reorder. Unlike Parquet/Delta which match by name, Iceberg matches by ID.
6. **Snapshot isolation** — each snapshot is immutable. Readers never see partial writes. Writers don't block readers.
7. **Engine-neutral** — works with Spark, Flink, Trino, Presto, Snowflake, Hive — the biggest differentiator vs Delta.
8. **Fastest-growing** table format in 2026 — adopted by Snowflake, AWS, Netflix, Apple, LinkedIn.

---
