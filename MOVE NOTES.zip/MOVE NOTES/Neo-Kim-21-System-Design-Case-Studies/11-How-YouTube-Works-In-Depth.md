# How YouTube Works - In Depth (Easy Language)

> Companion to: [11-How-YouTube-Works.md](11-How-YouTube-Works.md)

---

## The Two Big Challenges

YouTube has TWO very different problems:

1. **Upload**: 500+ hours of video uploaded every minute (WRITE-heavy)
2. **Streaming**: Billions of views per day (READ-heavy, 100:1 ratio)

These two paths are designed completely separately because they have different requirements.

---

## Pre-Signed URLs - The #1 Optimization

### The Problem

```
BAD approach:
  User → uploads 2GB video → App Server → stores to S3
  
  App server is now a BOTTLENECK:
  - 2GB flowing through the server's RAM and network
  - If 100 users upload simultaneously: 200GB of traffic through app server
  - App server chokes, all other API requests slow down
```

### The Solution

```
GOOD approach:
  Step 1: User calls POST /v1/videos (tiny request, just metadata)
  Step 2: App server generates a pre-signed S3 URL:
          "https://s3.amazonaws.com/uploads/vid_123?token=abc&expires=3600"
  Step 3: User uploads 2GB video DIRECTLY to S3 using the URL
          (App server is completely bypassed!)
  Step 4: S3 notifies app server: "Upload complete for vid_123"
  Step 5: App server triggers transcoding pipeline

  App server only handled a tiny metadata request!
```

**Analogy**: Instead of a receptionist carrying every package to the mailroom, the receptionist gives you a room number and you deliver the package yourself.

---

## Transcoding Pipeline - Making Videos Watchable

### Why Transcode?

Users upload videos in random formats: MOV, AVI, MKV, different codecs, different resolutions. You can't stream these directly to every device.

```
Raw upload: 4K video, H.264 codec, MOV format, 2GB
                    ↓ transcoding pipeline
Output:
  240p  → 10 MB   (very slow networks)
  360p  → 25 MB   (slow mobile)
  480p  → 50 MB   (standard mobile)
  720p  → 100 MB  (HD)
  1080p → 250 MB  (Full HD)
  4K    → 1 GB    (Ultra HD)
  
Each resolution is also SPLIT into hundreds of 2-4 second segments
```

### Why Segments?

```
Without segments:
  You must download the ENTIRE 250MB 1080p file before watching
  → Long wait before video starts

With segments:
  Video split into 2-second chunks:
    segment_001.ts (400KB) → segment_002.ts → segment_003.ts → ...
  
  Player downloads segment_001 → starts playing immediately!
  While playing segment_001, it downloads segment_002 in the background
  → Video starts in under 500ms!
```

### How Transcoding Scales

```
Upload comes in → Message added to queue
                        ↓
    ┌─────────────────────────────────────┐
    │           Worker Pool               │
    │  Worker 1: transcoding to 240p     │
    │  Worker 2: transcoding to 480p     │
    │  Worker 3: transcoding to 720p     │
    │  Worker 4: transcoding to 1080p    │
    │  Worker 5: transcoding to 4K       │
    └─────────────────────────────────────┘
    
Workers pull jobs from queue independently
→ Horizontal scaling: add more workers for more uploads
→ Each resolution can be transcoded in PARALLEL
```

---

## Adaptive Bitrate Streaming (ABR) - How Quality Switches

### The Manifest File

When you watch a video, the player first downloads a **manifest file** (like a menu):

```
Manifest file for "funny-cat-video":
  240p: https://cdn.youtube.com/vid_123/240p/
    segment_001.ts, segment_002.ts, ... 
  480p: https://cdn.youtube.com/vid_123/480p/
    segment_001.ts, segment_002.ts, ...
  720p: https://cdn.youtube.com/vid_123/720p/
    segment_001.ts, segment_002.ts, ...
  1080p: https://cdn.youtube.com/vid_123/1080p/
    segment_001.ts, segment_002.ts, ...
```

### How Quality Switches Automatically

```
You start watching on WiFi (fast):
  → Player measures: bandwidth = 10 Mbps → picks 1080p
  → Downloads 1080p segments

You walk outside, switch to 4G (slower):
  → Player measures: bandwidth = 3 Mbps → switches to 480p
  → Downloads 480p segments (no buffering!)

You enter subway, signal drops:
  → Player measures: bandwidth = 500 Kbps → switches to 240p
  → Pixelated but keeps playing!

Back on WiFi:
  → Player measures: bandwidth = 10 Mbps → back to 1080p
  → Beautiful quality again!
```

**The key**: The PLAYER makes the quality decision, not the server. It measures download speed of each segment and adjusts for the next one.

### HLS vs DASH

Two competing standards for adaptive streaming:

| | HLS (Apple) | DASH (Open Standard) |
|--|---|---|
| **Created by** | Apple | MPEG consortium |
| **File format** | .m3u8 manifest, .ts segments | .mpd manifest, .mp4 segments |
| **Browser support** | Native on Safari/iOS | Native on Chrome/Android |
| **Used by** | Apple TV+, most platforms | Netflix, YouTube |

Most platforms support both. YouTube uses DASH but can fall back to HLS.

---

## CDN - Why Videos Load Fast Everywhere

### The Problem

YouTube's servers are in the US. A user in India requests a video.

```
Without CDN:
  User in Mumbai → request travels 13,000 km to US server → video data travels 13,000 km back
  → Round trip: ~200ms latency
  → Streaming: every segment has 200ms delay
  → Buffering! Slow start!
```

### The Solution

```
With CDN:
  Popular video cached at edge server in Mumbai
  User in Mumbai → request goes to Mumbai CDN (2km away) → video served locally
  → Round trip: ~5ms latency
  → First frame: under 500ms
  → No buffering!
```

**How CDN caching works:**
```
User 1 in Mumbai watches video:
  → CDN Mumbai: "I don't have this" → fetches from origin (US)
  → Serves to User 1 AND caches the segments

User 2 in Mumbai watches same video:
  → CDN Mumbai: "I have this cached!" → serves immediately
  → No trip to US needed!

User 3, 4, 5... all served from Mumbai CDN cache
```

The more popular a video, the higher the cache hit ratio. Viral videos are served almost entirely from CDN edge locations.

---

## Search - Finding Videos Among Billions

### Cursor-Based Pagination (Not Offset)

When you search "funny cat videos" and get 10 million results, how do you paginate?

**Bad: Offset-based pagination**
```
Page 1: SELECT * FROM videos WHERE ... LIMIT 20 OFFSET 0      (fast)
Page 2: SELECT * FROM videos WHERE ... LIMIT 20 OFFSET 20     (OK)
Page 500: SELECT * FROM videos WHERE ... LIMIT 20 OFFSET 10000 (SLOW!)

Why slow? Database must SKIP 10,000 rows to find the next 20.
The deeper you go, the slower it gets.
```

**Good: Cursor-based pagination**
```
Page 1: SELECT * FROM videos WHERE ... LIMIT 20
  → Returns results + next_cursor="vid_abc_score_42"

Page 2: SELECT * FROM videos WHERE score < 42 AND id > 'abc' LIMIT 20
  → Uses cursor to jump directly to the right place
  → Returns results + next_cursor="vid_def_score_38"

Page 500: Same speed as page 1!
  → Always just: WHERE score < X LIMIT 20
  → No skipping rows!
```

---

## Watch Progress - Fire-and-Forget Writes

### The Challenge

Every second while watching, your progress is tracked:
```
User watching at 0:42 → POST /progress { video: "abc", time: 42 }
User at 0:43 → POST /progress { video: "abc", time: 43 }
User at 0:44 → POST /progress { video: "abc", time: 44 }

With 100M DAU watching simultaneously:
  → Millions of progress writes per second!
```

### Fire-and-Forget

```
Normal API call:
  Client → Server → Database → Server → Client (200 OK)
  Client WAITS for confirmation

Fire-and-forget:
  Client → Server → (async write to DynamoDB)
  Server immediately returns 200 OK
  Client doesn't wait for database confirmation
  
  If the write fails silently?
    → Next update will overwrite anyway (it's just a progress marker)
    → Not critical data (not a payment, not a message)
```

**Why DynamoDB?** Simple key-value writes, high throughput (millions/sec), no complex queries needed.

---

## Complete Architecture Flow

### Upload Flow
```
1. Creator: POST /v1/videos { title, description, tags }
2. Server: returns { video_id: "abc", upload_url: "https://s3.../presigned" }
3. Creator: uploads 2GB file directly to S3 via upload_url
4. S3: notifies server "upload complete for video abc"
5. Server: adds job to transcoding queue
6. Workers: transcode to 6 resolutions, split into segments
7. Workers: store all segments back to S3
8. Server: updates metadata in SQL DB, indexes in Elasticsearch
9. Video is now searchable and streamable!
```

### Streaming Flow
```
1. Viewer: GET /v1/videos/abc
2. Server: returns { title, description, manifest_url, cdn_base }
3. Viewer's player: downloads manifest file from CDN
4. Player: reads available resolutions, picks best for current bandwidth
5. Player: downloads segment_001 from CDN → starts playing
6. Player: downloads segment_002 in background while playing 001
7. Player: continuously measures bandwidth, switches quality if needed
8. Player: POST /progress every few seconds (fire-and-forget)
```

---

## Revision Flashcards

**Q: Why does YouTube use pre-signed URLs for uploads?**
A: So video data goes directly from user to S3, bypassing app servers. App servers only handle metadata, preventing them from being bottlenecked by large file transfers.

**Q: What is adaptive bitrate streaming?**
A: Video is pre-encoded in multiple resolutions. The player downloads a manifest listing all versions, measures bandwidth, and automatically switches quality per segment. User gets the best quality their connection supports.

**Q: Why is video split into small segments?**
A: So playback can start immediately (download segment 1, play it, download segment 2 in background). Also enables quality switching per segment instead of per video.

**Q: What is cursor-based pagination?**
A: Instead of "skip N rows" (gets slower as N grows), use a cursor (pointer to last seen item) to jump directly to the next batch. Constant speed regardless of how deep you paginate.

**Q: Why is watch progress fire-and-forget?**
A: Millions of writes/sec, but data isn't critical (just a progress marker). If a write fails, the next update will overwrite it. Speed matters more than guaranteed consistency for this use case.
