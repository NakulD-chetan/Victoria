# Incremental Loads in Data Warehouse

> "The fastest query is the one you do not run twice on the same unchanged row."

**Real-world analogy:** A supermarket restocks shelves overnight using delivery manifests rather than recounting every item in the building. Incremental loading is that manifest-driven restock: only carts with new or changed inventory move, while untouched aisles stay undisturbed so the store opens on time.

---

## Core Idea (2 Lines)

Incremental loads reduce elapsed time and warehouse cost by detecting and applying only net-new or changed rows since the last successful batch. The correctness of incremental pipelines depends on an explicit change-detection strategy and a grain-aware merge pattern for facts versus slowly changing dimensions.

---

## Full Load versus Incremental Load

| Dimension | Full load | Incremental load |
|-----------|-----------|------------------|
| Rows processed each run | Entire source snapshot | Delta subset |
| Complexity | Lower logic, higher runtime | Higher logic, lower runtime |
| Recovery from logic bugs | Overwrite simplifies repair | Backfills and reconciliations required |
| Source load | Can stress operational DB | Gentler if keyed pulls are narrow |
| Late-arriving facts | Less special casing | Needs tolerance rules and watermark discipline |

```
Full load each night
===================
Source ----copy all rows----> Staging ----truncate/reload----> Target

Incremental each night
=======================
Source --keyed delta--> Staging --merge/upsert--> Target
         ^                         ^
         |                         |
    change detection          idempotent apply
```

**Interview Tip:** Say that full loads remain valid for small dimensions and early-phase projects; incrementals earn their keep when fact tables reach billions of retail line rows.

**Watch Out!** A "full load" that is implemented as delete-all plus insert-all still blocks queries and invalidates caches; it is not automatically safer than merge.

---

## Change Detection Methods

### Timestamp-based

Assume `updated_at` or `last_modified` is reliable on operational tables.

```sql
SELECT *
FROM retail_source.inventory_balance
WHERE last_modified_ts > :high_watermark
ORDER BY last_modified_ts;
```

| Strength | Weakness |
|----------|----------|
| Simple to explain | Misses hard deletes unless paired with tombstones |
| Fast indexed scans if column is indexed | Backdated corrections can be skipped if watermark advances too eagerly |

**Watch Out!** Clock skew across stores can reorder events; use monotonic ingestion timestamps when source clocks are untrusted.

### Trigger-based

Database triggers write an audit or delta table on insert/update/delete.

**Interview Tip:** Triggers add write overhead on OLTP; common in packaged ERP extensions but less fashionable in cloud-native microservices.

### Change Data Capture (CDC)

Log-based or transaction-log readers emit before/after images for tables.

| Pattern | Retail example |
|---------|----------------|
| Debezium / SQL Server CDC | Capturing `price_change` rows for `dim_product` slowly changing attributes |
| Application outbox | Order service publishes `OrderUpdated` with version |

**Watch Out!** Schema drift in CDC streams requires versioned contracts and consumer tests.

### Log-based

Web clickstream or POS journals append-only; the offset is the watermark.

```sql
-- Pseudo-SQL: advance Kafka offset or file byte position after commit
COMMIT BATCH offset = :new_offset;
```

---

## Watermark and High-Water Mark Strategy

```
Timeline of batches
-------------------
T0: watermark = NULL
T1: pull rows where event_ts > T0 up to max seen M1; set watermark = M1
T2: pull rows where event_ts > M1 up to M2; set watermark = M2
```

| Element | Purpose |
|---------|---------|
| Watermark table | Persists last successful boundary per source object |
| Overlap window | Re-pull last N minutes to tolerate late arrivals |
| Idempotent merge | Same row re-delivered does not double-count |

```sql
-- Example watermark table
CREATE TABLE retail_ops.load_watermark (
  source_object STRING,
  watermark_ts TIMESTAMP,
  last_run_id STRING,
  rows_applied INT64
);

-- Pull with overlap
SELECT *
FROM retail_source.pos_sale
WHERE sale_ts > TIMESTAMP_SUB(
  (SELECT watermark_ts FROM retail_ops.load_watermark WHERE source_object = 'pos_sale'),
  INTERVAL 15 MINUTE
);
```

**Interview Tip:** Always pair watermark pulls with merge keys and hash compares to handle duplicates in the overlap zone.

**Watch Out!** Using `MAX(id)` instead of a true change timestamp confounds out-of-order inserts and re-seeded sequences.

---

## Incremental Load for Facts versus Dimensions

### Facts (transaction grain)

Typically append new sale lines; rarely update unless correcting amounts.

```sql
MERGE retail_core.fact_pos_sale AS T
USING retail_staging.pos_sale_delta AS S
ON T.pos_sale_id = S.pos_sale_id
WHEN MATCHED AND T.sale_hash <> S.sale_hash THEN
  UPDATE SET amount = S.amount, quantity = S.quantity, sale_hash = S.sale_hash
WHEN NOT MATCHED THEN
  INSERT ROW;
```

### Dimensions (SCD Type 2 example)

Detect attribute change; close old row; insert new version.

```sql
MERGE retail_core.dim_product AS T
USING retail_staging.product_delta AS S
ON T.product_natural_key = S.product_natural_key AND T.is_current = TRUE
WHEN MATCHED AND (
  T.brand <> S.brand OR T.category <> S.category
) THEN
  UPDATE SET is_current = FALSE, end_date = CURRENT_DATE()
WHEN NOT MATCHED BY TARGET THEN
  INSERT (...);
-- Follow-up insert for new current row handled in second statement or procedure
```

| Concern | Fact incremental | Dimension incremental |
|---------|------------------|------------------------|
| Primary risk | Duplicate events inflate revenue | Orphan keys if version lag |
| Typical pattern | Append + limited correction merge | SCD1/2/3 logic with effective dating |
| Late data | Adjust facts, restate KPIs | May require reopening SCD2 rows |

**Watch Out!** Loading facts before dimensions completes can strand foreign keys unless you use default unknown members.

---

## Merge and Upsert Pattern

```
Keys arriving in delta
----------------------
pos_sale_id = 9001 (new)
pos_sale_id = 9002 (duplicate resend, same payload)
pos_sale_id = 9003 (correction: amount changed)

Merge outcome
-------------
9001 insert
9002 no-op (hash match) or update no-op
9003 update measures
```

```sql
-- Idempotency via content hash
SELECT
  pos_sale_id,
  FARM_FINGERPRINT(
    TO_JSON_STRING(STRUCT(store_id, product_id, sale_ts, amount, quantity))
  ) AS sale_hash
FROM retail_staging.pos_sale_delta;
```

**Interview Tip:** Mention that true `DELETE` handling in merges needs either CDC delete events or periodic reconciliation jobs.

---

## Performance Comparison (Illustrative)

| Approach | Nightly runtime trend | Source impact | Correctness sensitivity |
|----------|----------------------|---------------|-------------------------|
| Full table scan load | Linear with table growth | High | Lower |
| Key-based incremental | Sublinear if selective | Medium | Medium |
| CDC stream | Near constant per event rate | Low on OLTP if async | High without tests |
| Micro-batch watermark | Tunable | Medium | Medium-high |

**Watch Out!** Partition pruning mistakes make incrementals scan whole years of partitions, erasing performance wins.

---

## SQL Examples: Bookends of a Batch

```sql
-- Start: capture run id
DECLARE run_id STRING DEFAULT GENERATE_UUID();

-- Stage delta
CREATE OR REPLACE TABLE retail_staging.pos_sale_delta AS
SELECT s.*
FROM retail_source.pos_sale s
WHERE s.sale_ts > (
  SELECT watermark_ts FROM retail_ops.load_watermark WHERE source_object = 'pos_sale'
);

-- Apply
MERGE retail_core.fact_pos_sale T
USING retail_staging.pos_sale_delta S
ON T.pos_sale_id = S.pos_sale_id
WHEN NOT MATCHED THEN INSERT ROW;

-- Finish: advance watermark with overlap policy
MERGE retail_ops.load_watermark T
USING (SELECT TIMESTAMP_SUB(MAX(sale_ts), INTERVAL 15 MINUTE) AS wm FROM retail_staging.pos_sale_delta) S
ON T.source_object = 'pos_sale'
WHEN MATCHED THEN UPDATE SET watermark_ts = S.wm, last_run_id = run_id, rows_applied = (SELECT COUNT(*) FROM retail_staging.pos_sale_delta)
WHEN NOT MATCHED THEN INSERT (source_object, watermark_ts, last_run_id, rows_applied)
VALUES ('pos_sale', S.wm, run_id, (SELECT COUNT(*) FROM retail_staging.pos_sale_delta));
```

---

## Reconciliation and Trust

| Check | Purpose |
|-------|---------|
| Row counts by store vs source | Detect partial extracts |
| Sum of sales amount delta vs control total | Detect truncation |
| Hash of key ranges | Detect skipped segments |

**Interview Tip:** Retail finance often demands a control-total step that matches GL postings for the day, independent of row counts.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Advancing watermark before commit | Data loss on failure | Two-phase: stage, merge, then watermark in same transaction where supported |
| No overlap window | Late rows never loaded | Add time overlap or periodic full reconcile |
| Merge without hash or version | Silent double count on retries | Idempotent keys plus content hash or event version |
| Incremental dimension without orphan policy | Fact loads fail or attach to wrong row | Unknown dimension rows and deferred resolution queues |
| Partitioned facts keyed only by order id spanning days | Wrong partition updates | Include event date in merge match or route to correct partition |

---

## Key Takeaway

> Incremental loading is a correctness exercise disguised as a performance technique: watermarks, overlaps, merges, and reconciliations together prove the delta is complete, not merely fast.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Full load = simple, costly; incremental = fast, needs discipline.|
| Detection: timestamps, triggers, CDC, logs; each has trade-offs. |
| Watermark + overlap handles latency and clock issues.            |
| Facts favor append/merge on natural keys; dims need SCD logic.   |
| Always reconcile counts and amounts against control totals.      |
+------------------------------------------------------------------+
```
