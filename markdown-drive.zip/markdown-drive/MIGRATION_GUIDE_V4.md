# InkDrop v4 — Multi-User Vaults, Sharing, Realtime, and Multi-Pane Editor

This release introduces real multi-user collaboration on top of Supabase Auth, Postgres RLS, Realtime, and Yjs. It is a significant architectural change; the steps below get a fresh environment up and migrate existing single-user installs.

## 1. Prerequisites

- A Supabase project (free tier is fine).
- Node.js 18+.
- `psql` or the Supabase Studio SQL editor for running migrations.

## 2. Install new dependencies

```bash
npm install
```

`package.json` now includes:

- Client UI: `@dnd-kit/core`, `@dnd-kit/sortable`, `@dnd-kit/utilities`, `react-resizable-panels`
- Collaboration: `yjs`, `y-websocket`, `y-protocols`, `y-prosemirror`

## 3. Configure environment variables

Copy `.env.example` to `.env` and fill in:

```
# Browser-safe
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=...

# Server-side
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE=...     # NEVER expose to the browser
SUPABASE_JWT_SECRET=...       # from Project Settings → API → JWT Settings

# Yjs WebSocket service
VITE_YJS_WS_URL=ws://localhost:1234
YJS_PORT=1234
```

## 4. Run database migrations

In order, against your Supabase Postgres:

1. `supabase-migration.sql`
2. `supabase-migration-v2.sql`
3. `supabase-migration-v3.sql`
4. **`supabase-migration-v4-collab.sql`** — schema (profiles, vaults, vault_members, vault_invites, folders, notes, resource_acl, audit_events, plus the `effective_role` and `accept_invite` helpers).
5. **`supabase-migration-v4-rls.sql`** — Row-Level Security policies.

The v4 SQL is idempotent; rerunning it is safe.

## 5. Enable Auth providers

In Supabase Dashboard → Authentication → Providers:

- Email (magic link) — already enabled by default.
- Google — provide OAuth client ID/secret from Google Cloud Console.
- GitHub — provide OAuth client ID/secret from GitHub Developer Settings.

Set the **Redirect URL** to your app origin (e.g. `http://localhost:5173`).

## 6. Run the app

The default `dev` script now boots three processes:

```bash
npm run dev          # Express + Vite + yjs-server
npm run dev:web      # Express + Vite only (skip Yjs in dev)
npm run yjs          # yjs-server only
```

## 7. Migrate existing user data

Existing single-user installs have notes serialized to `_inkdrop_notes/<vault>/data.json` in Supabase Storage. After signing in with Supabase Auth for the first time:

1. The new client posts to `POST /api/migrate-legacy` and receives a list of legacy vaults discovered in storage.
2. The user picks which vaults to import; the client uses `supabase-js` (the Supabase JWT enforces RLS) to insert rows into `public.vaults`, `public.folders`, and `public.notes` under their new `auth.uid()`.
3. Old blobs are left in place for 30 days; a banner in the app offers re-import if anything was missed.

The legacy `/api/notes/sync`, `/api/vaults/sync`, and `/api/canvas/sync` endpoints continue to respond during this grace window, but each response now carries `Deprecation: true` and a `Sunset` header.

## 8. Feature flags

- The new multi-pane editor is gated by `?v2=1` (or `localStorage.setItem('inkdrop:multipane', '1')`). The legacy single-pane UX remains the default until telemetry says otherwise.
- The Yjs collaborative editor activates automatically when `VITE_YJS_WS_URL` is set; it does nothing if the env var is missing.

## 9. Sharing & Realtime

Once v4 is live:

- **Vault button → Share** opens the new `<ShareDialog>` with People / Link / Permissions tabs.
- Email invites either add an existing Supabase user directly to `vault_members` or create a `vault_invites` row that they can accept after sign-up.
- Token links (`/invite/<token>`) call the `accept_invite()` SQL function and bounce the user into the shared vault.
- Sidebar tree updates flow through `subscribeToVault(vaultId, ...)` (Supabase Realtime postgres_changes); cross-pane state stays in sync because every pane reads from the same `useNotesStore`/`useWorkspaceStore`.

## 10. Security checklist

- [x] Anon key + RLS only — no path lets a browser bypass policies.
- [x] `firebase-` bearer hack removed; legacy tokens get `401 AUTH_MIGRATION_REQUIRED`.
- [x] Service-role key never exposed to the browser.
- [x] Invite rate limit (Postgres-side: server-issued JWT scopes invites to `vault_members.role = 'owner'`; clients can additionally throttle).
- [x] `audit_events` records share/role/delete actions.
- [x] Yjs server checks `effective_role` per connection; read-only members cannot push edits.

## 11. Rollback

To revert to v3 without losing data:

1. Set `VITE_YJS_WS_URL` empty.
2. Remove `?v2=1` from URLs / unset `localStorage.inkdrop:multipane`.
3. Existing `_inkdrop_notes/*` blobs and the v3 `/sync` routes are still live.

The v4 schema can stay in place; it is additive and does not modify v3 tables.
