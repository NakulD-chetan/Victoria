# Third-Party Notices

## Excalidraw

The `new-canvas` V3 editor integrates and adapts Excalidraw concepts and runtime
components.

Copyright (c) Excalidraw contributors.

Licensed under the MIT License:
https://github.com/excalidraw/excalidraw/blob/master/LICENSE

## Excalifont

Excalifont is distributed under the SIL Open Font License 1.1:
https://github.com/excalidraw/excalidraw/blob/master/packages/excalidraw/fonts/Excalifont/OFL.txt
