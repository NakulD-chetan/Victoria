# How Google Docs Works - System Design

> Source: https://newsletter.systemdesign.one/p/how-does-google-docs-work

## One-Line Summary
Google Docs enables real-time collaborative editing by using Operational Transformation (OT) to automatically resolve conflicts between concurrent edits without locks, while keeping all users' documents in sync.

## Key Requirements

### Functional
- Multiple users edit the same document simultaneously
- Changes visible to all users in real-time
- Automatic conflict resolution (no manual merge)
- Offline editing support (sync when back online)
- Revision history (undo/track changes)
- Rich text formatting, comments, suggestions

### Non-Functional
- Low latency (edits appear instantly locally)
- Eventual consistency (all copies converge to same state)
- High availability
- Scalable to millions of concurrent documents
- No data loss during concurrent edits

## The Problem: Concurrent Editing

When multiple users edit the same document at the same time, three things must be true:
1. Concurrent changes must **not conflict**
2. All copies must **converge** to the same version
3. Changes must be visible in **real-time**
4. Users should be able to edit **offline**

## Approaches Compared

### 1. Pessimistic Locking (NOT used)
- Only ONE user can edit at a time (others see read-only)
- Simple but kills real-time collaboration
- Doesn't support offline editing
- 200ms network round-trip = poor UX

### 2. Last-Write-Wins (NOT used)
- Each user edits locally, latest update overwrites
- Risk of data loss with concurrent edits on high-latency networks
- OK when concurrency is low, NOT suitable for collaborative editing

### 3. Differential Synchronization (NOT used)
- Track changes locally, send only the DIFF (not full document)
- Performance overhead for every change
- Tracks what changed but NOT why → hard to resolve conflicts
- Manual conflict resolution hurts UX

### 4. Operational Transformation - OT (USED by Google Docs)
- Each edit is saved as an **operation** (insert, delete, format)
- Operations are **transformed** when they arrive out of order
- Allows different copies to accept writes simultaneously
- Conflict resolution is automatic (no user intervention)
- Tolerates divergence → converges later
- Document = replay of all operations from the start

## How Operational Transformation Works

### Core Idea:
Instead of storing the document text, store a **revision log of operations**.

```
Operation types:
  - INSERT(position, character)
  - DELETE(position)
  - FORMAT(position, range, style)

Example:
  Document: "HELLO"
  User A: INSERT(5, "!") → "HELLO!"
  User B: DELETE(0)      → "ELLO"

Without OT:
  Applying both naively → conflicts!

With OT:
  Transform User A's operation based on User B's:
  INSERT(5, "!") → transformed to INSERT(4, "!") because position shifted
  Result: "ELLO!" (both operations applied correctly)
```

### The Transformation Rule:
When two operations happen concurrently:
1. Server receives both operations
2. **Transforms** one against the other to adjust positions
3. Applies both in correct order
4. Broadcasts transformed operations to all clients
5. All clients converge to the same document state

## High-Level Architecture

```
Client A (local copy)    Client B (local copy)
      |                        |
      | WebSocket              | WebSocket
      |                        |
   Collaboration Server
      ├── OT Engine (transform operations)
      ├── Revision Log (append-only)
      ├── Session Manager (track connected users)
      └── Storage Service (persist document)
              |
         Document Database
```

### Key Architecture Pattern:
- **Client-server model** (not peer-to-peer)
- Each client maintains a LOCAL copy for instant response
- Client sends operations to server
- Server transforms and broadcasts to other clients
- Server is the **single source of truth** for operation ordering

## Core Components Deep Dive

### 1. Latency Hiding
- Each user has a **local copy** of the document
- Edits apply locally FIRST (instant feedback)
- Then sync with server in background
- Creates illusion of zero latency

### 2. OT Engine (Server Side)
- Receives operations from all clients
- Assigns a **revision number** to each operation
- Transforms concurrent operations to maintain consistency
- Ensures all clients converge to same state
- Deterministic: same operations → same result

### 3. Revision Log
- Append-only log of all operations
- Each entry: operation + revision number + user ID + timestamp
- Enables: undo, redo, version history, time travel
- Document can be reconstructed by replaying from start

### 4. Cursor/Selection Sync
- Each user's cursor position is broadcast to others
- Cursors are also transformed when operations shift positions
- Visual: "User B is editing line 42" shown in real-time

### 5. Offline Support
- Client queues operations locally while offline
- On reconnect: send queued ops to server
- Server transforms them against any operations that happened during offline period
- Client receives transformed operations from other users

## Alternative: CRDTs (Conflict-Free Replicated Data Types)

| Aspect | OT (Google Docs) | CRDTs (Figma, some others) |
|--------|-------------------|---------------------------|
| Conflict resolution | Server transforms operations | Data structure self-resolves |
| Architecture | Requires central server | Can work peer-to-peer |
| Complexity | Algorithm is complex | Data structure is complex |
| Performance | Good for text editing | Better for some data types |
| Used by | Google Docs, MS Office Online | Figma, Apple Notes, Notion |

## Key Design Decisions

| Decision | Why |
|----------|-----|
| OT (not locking) | Enables real-time multi-user collaboration |
| Client-server (not P2P) | Simpler ordering, single source of truth |
| Local copy per user | Instant feedback (latency hiding) |
| Append-only revision log | Undo/redo, version history, audit |
| WebSocket | Real-time bidirectional updates |
| Operations (not full doc sync) | Bandwidth efficient, preserves intent |

## Data Model

```
Document:
  - doc_id: UUID
  - title: string
  - owner_id: string
  - created_at, updated_at: timestamp

Operation (Revision Log):
  - revision_id: auto-increment
  - doc_id: UUID
  - user_id: string
  - operation_type: INSERT | DELETE | FORMAT
  - position: int
  - content: string (for insert)
  - timestamp: datetime

Active Sessions:
  - doc_id → [{ user_id, cursor_position, color }]
```

## Scaling Strategies

1. **Shard by document_id**: each document's OT engine runs independently
2. **WebSocket connection pools** for handling millions of editors
3. **Periodic snapshots** of document state (don't replay from beginning every time)
4. **Operation batching**: group rapid keystrokes into single operations
5. **CDN** for serving document assets (images, embedded files)
6. **Read replicas** for document viewing (non-editing users)

## Interview Tips

- Start with the **problem**: why is concurrent editing hard? (conflicts, convergence, latency)
- Explain ALL 4 approaches and why OT wins for this use case
- Draw the OT transformation example with INSERT + DELETE
- Mention **latency hiding** with local copies -- very important UX pattern
- Know OT vs CRDTs tradeoff (Google uses OT, Figma uses CRDTs)
- Discuss the **revision log** as append-only for version history
- Talk about offline support: queue ops locally, transform on reconnect
- This question tests: distributed systems, consistency models, conflict resolution

## Quick Revision (5 bullet points)

1. **Operational Transformation (OT)**: each edit is an operation (insert/delete/format); concurrent ops are automatically transformed to resolve conflicts
2. **Latency hiding**: each user edits a local copy instantly, server syncs in background -- appears zero-lag
3. **Server is single source of truth**: assigns revision numbers, transforms ops, broadcasts to all clients via WebSocket
4. **Revision log** (append-only) stores all operations; document = replay of all ops; enables undo, version history, time travel
5. **OT vs CRDTs**: OT needs central server (simpler ordering), CRDTs are self-resolving (can be P2P); Google Docs uses OT, Figma uses CRDTs
