import { memo, useCallback } from 'react';
import { useNewCanvasStore } from '../state/store';
import {
  ARRAY_SLOT_MIN_W,
  ARRAY_WIDGET_MIN_W,
  idealArrayWidth,
  idealArrayHeight,
} from './array-layout';

function ArrayWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || { values: [], title: 'Array' };
  const values = Array.isArray(data.values) ? data.values : [];
  const highlights = data.highlights && typeof data.highlights === 'object' ? data.highlights : {};
  const frameStroke = element.style?.stroke || '#64748b';
  const frameW = element.style?.strokeWidth ?? 1;
  const chromeBg = data.chromeBg;

  const update = useCallback((patch) => {
    commitElements((els) => els.map((e) => e.id === element.id
      ? { ...e, widgetData: { ...e.widgetData, ...patch } }
      : e));
  }, [commitElements, element.id]);

  const setCell = useCallback((idx, value) => {
    const next = values.slice();
    next[idx] = value;
    update({ values: next });
  }, [values, update]);

  const addCell = useCallback(() => {
    const nextValues = values.concat([0]);
    const idealW = idealArrayWidth(nextValues.length);
    const idealH = idealArrayHeight();
    commitElements((els) => els.map((e) => {
      if (e.id !== element.id) return e;
      return {
        ...e,
        w: Math.max(e.w, idealW),
        h: Math.max(e.h, idealH),
        widgetData: { ...e.widgetData, values: nextValues },
      };
    }));
  }, [values, element.id, commitElements]);

  const removeCell = useCallback(() => {
    if (values.length === 0) return;
    const nextValues = values.slice(0, -1);
    const n = nextValues.length;
    const idealW = idealArrayWidth(n);
    const slack = ARRAY_SLOT_MIN_W;
    commitElements((els) => els.map((e) => {
      if (e.id !== element.id) return e;
      let nextW = e.w;
      if (n === 0) {
        nextW = idealArrayWidth(0);
      } else if (e.w > idealW + slack) {
        nextW = Math.max(idealW, ARRAY_WIDGET_MIN_W);
      }
      return {
        ...e,
        w: nextW,
        h: Math.max(e.h, idealArrayHeight()),
        widgetData: { ...e.widgetData, values: nextValues },
      };
    }));
  }, [values, element.id, commitElements]);

  const onDelete = useCallback(() => {
    commitElements((els) => els.map((e) => e.id === element.id ? { ...e, isDeleted: true } : e));
  }, [commitElements, element.id]);

  return (
    <div
      className="nc-data-widget nc-array"
      style={{
        borderColor: frameStroke,
        borderWidth: frameW,
        ...(chromeBg ? { background: chromeBg } : {}),
      }}
    >
      <div className="nc-widget-header nc-data-widget__header" data-nc-drag-handle="1">
        <input
          className="nc-data-widget__title-input"
          value={data.title || 'Array'}
          onChange={(e) => update({ title: e.target.value })}
          aria-label="Array title"
        />
        <div className="nc-data-widget__actions">
          <button type="button" onClick={removeCell} aria-label="Remove last cell">−</button>
          <button type="button" onClick={addCell} aria-label="Add cell">+</button>
          <button type="button" className="nc-data-widget__close" onClick={onDelete} aria-label="Delete widget">×</button>
        </div>
      </div>
      <div className="nc-data-widget__body nc-array__track">
        {data.caption ? <div className="nc-array__caption">{data.caption}</div> : null}
        <div
          className="nc-array__grid"
          style={{
            gridTemplateColumns: values.length > 0
              ? `repeat(${values.length}, minmax(0, 1fr))`
              : '1fr',
          }}
          role="group"
          aria-label="Array indices and values"
        >
          {values.map((_, i) => (
            <div key={`idx-${i}`} className="nc-array__indexCell" aria-hidden="true">{i}</div>
          ))}
          {values.map((v, i) => {
            const vfs = Number(data.valueFontSize) > 0 ? Number(data.valueFontSize) : null;
            const vc = data.valueColor;
            const highlight = highlights[i] || null;
            return (
              <div key={`val-wrap-${i}`} className={`nc-array__cellWrap${highlight?.tone ? ` is-${highlight.tone}` : ''}`}>
                {highlight?.label ? <span className="nc-array__badge">{highlight.label}</span> : null}
                <input
                  key={`val-${i}`}
                  className="nc-array__value"
                  value={v}
                  onChange={(e) => {
                    const n = e.target.value;
                    const num = /^-?\d+(?:\.\d+)?$/.test(n.trim()) ? Number(n) : n;
                    setCell(i, num);
                  }}
                  aria-label={`Value at index ${i}`}
                  style={{
                    ...(vfs ? { fontSize: `calc(${vfs}px / 13 * 1em)` } : {}),
                    ...(vc ? { color: vc } : {}),
                  }}
                />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default memo(ArrayWidgetImpl);
