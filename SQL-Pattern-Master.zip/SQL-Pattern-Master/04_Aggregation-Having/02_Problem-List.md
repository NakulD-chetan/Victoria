# Aggregation + HAVING — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers GROUP BY, HAVING, COUNT, SUM, AVG, conditional aggregation, and ROLLUP. Sources: LeetCode, HackerRank, DataLemur.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Duplicate Emails | [LC 182](https://leetcode.com/problems/duplicate-emails/) | Easy | GROUP BY + HAVING | Purest "find duplicates" pattern |
| 2 | Classes More Than 5 Students | [LC 596](https://leetcode.com/problems/classes-more-than-5-students/) | Easy | GROUP BY + HAVING | Simple group count filter |
| 3 | Customer Placing Largest Orders | [LC 586](https://leetcode.com/problems/customer-placing-the-largest-number-of-orders/) | Easy | GROUP BY + ORDER + LIMIT | Top-1 by aggregate |
| 4 | Actors and Directors Who Cooperated >= 3 | [LC 1050](https://leetcode.com/problems/actors-and-directors-who-cooperated-at-least-three-times/) | Easy | Multi-col GROUP BY | Group by multiple columns |
| 5 | Sales Person | [LC 607](https://leetcode.com/problems/sales-person/) | Easy | GROUP BY + anti-pattern | Aggregation with exclusion |
| 6 | Department Highest Salary | [LC 184](https://leetcode.com/problems/department-highest-salary/) | Medium | GROUP BY + MAX | Max per group + join back |
| 7 | Game Play Analysis I | [LC 511](https://leetcode.com/problems/game-play-analysis-i/) | Easy | MIN per group | First login date per player |
| 8 | Product Sales Analysis | [LC 1068](https://leetcode.com/problems/product-sales-analysis-i/) | Easy | SUM per group | Revenue aggregation |
| 9 | Customers Who Bought All Products | [LC 1045](https://leetcode.com/problems/customers-who-bought-all-products/) | Medium | COUNT DISTINCT + HAVING | Count matching total |
| 10 | Active Businesses | [LC 1126](https://leetcode.com/problems/active-businesses/) | Medium | AVG + HAVING | Events above average occurrence |

---

## Complete 20-Problem Progression

### Easy (Problems 1-8) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Duplicate Emails | [LC 182](https://leetcode.com/problems/duplicate-emails/) | GROUP BY + HAVING > 1 | Find items appearing more than once |
| 2 | Classes More Than 5 Students | [LC 596](https://leetcode.com/problems/classes-more-than-5-students/) | GROUP BY + HAVING >= 5 | Count per group with threshold |
| 3 | Customer Placing Largest Orders | [LC 586](https://leetcode.com/problems/customer-placing-the-largest-number-of-orders/) | GROUP BY + ORDER + LIMIT | Top aggregate value |
| 4 | Actors and Directors Cooperated 3x | [LC 1050](https://leetcode.com/problems/actors-and-directors-who-cooperated-at-least-three-times/) | Multi-col GROUP BY | Group by pair of columns |
| 5 | Game Play Analysis I | [LC 511](https://leetcode.com/problems/game-play-analysis-i/) | MIN per group | First event per entity |
| 6 | Sales Person | [LC 607](https://leetcode.com/problems/sales-person/) | GROUP BY + NOT IN | Exclude based on aggregate |
| 7 | Product Sales Analysis | [LC 1068](https://leetcode.com/problems/product-sales-analysis-i/) | SUM per group | Total revenue per product |
| 8 | Employees With Missing Info | [LC 1965](https://leetcode.com/problems/employees-with-missing-information/) | COUNT + NULL handling | Aggregate with NULL awareness |

### Medium (Problems 9-16) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 9 | Department Highest Salary | [LC 184](https://leetcode.com/problems/department-highest-salary/) | MAX + join back | Find max per group, return full row |
| 10 | Customers Who Bought All Products | [LC 1045](https://leetcode.com/problems/customers-who-bought-all-products/) | COUNT DISTINCT = total | Set completeness check |
| 11 | Active Businesses | [LC 1126](https://leetcode.com/problems/active-businesses/) | AVG + compare | Events above average threshold |
| 12 | Managers With At Least 5 Reports | [LC 570](https://leetcode.com/problems/managers-with-at-least-5-direct-reports/) | GROUP BY + HAVING >= 5 | Count children per parent |
| 13 | Immediate Food Delivery II | [LC 1174](https://leetcode.com/problems/immediate-food-delivery-ii/) | Conditional COUNT | Percentage via CASE in aggregate |
| 14 | Monthly Transactions I | [LC 1193](https://leetcode.com/problems/monthly-transactions-i/) | Multi-agg + CASE | Multiple aggregates per group |
| 15 | Group Sold Products By Date | [LC 1484](https://leetcode.com/problems/group-sold-products-by-the-date/) | STRING_AGG / GROUP_CONCAT | Concatenate values per group |
| 16 | Capital Gain/Loss | [LC 1393](https://leetcode.com/problems/capital-gainloss/) | SUM with sign | Conditional sum (buy negative, sell positive) |

### Hard (Problems 17-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 17 | Trips and Users | [LC 262](https://leetcode.com/problems/trips-and-users/) | Conditional aggregation | Cancellation rate per day |
| 18 | Tournament Winners | [LC 1194](https://leetcode.com/problems/tournament-winners/) | SUM + RANK per group | Aggregate then rank |
| 19 | Report Contiguous Dates | [LC 1225](https://leetcode.com/problems/report-contiguous-dates/) | GROUP BY + gaps | Group consecutive aggregates |
| 20 | Average Salary: Departments vs Company | [LC 615](https://leetcode.com/problems/average-salary-departments-vs-company/) | AVG + comparison | Per-group vs overall aggregate |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Duplicate Emails (LC 182)

```
Pattern:     GROUP BY + HAVING COUNT > 1
Approach:    GROUP BY email HAVING COUNT(*) > 1
Key Insight: This is the HashMap frequency map — bucket by key, count per bucket
One-liner:   Group by email, keep groups with count > 1.
```

### Problem 9: Department Highest Salary (LC 184)

```
Pattern:     MAX per group + join back
Approach:    Subquery: SELECT dept, MAX(salary) GROUP BY dept
             Outer: JOIN employees ON dept AND salary = max_salary
Key Insight: GROUP BY loses row detail — join back to recover full row
One-liner:   Find max salary per dept in subquery, join back to get employee name.
```

### Problem 10: Customers Who Bought All Products (LC 1045)

```
Pattern:     COUNT DISTINCT = total count
Approach:    GROUP BY customer_id
             HAVING COUNT(DISTINCT product_key) = (SELECT COUNT(*) FROM product)
Key Insight: "Bought ALL" = customer's distinct count equals total product count
One-liner:   Group by customer, having distinct product count = total products.
```

### Problem 17: Trips and Users (LC 262)

```
Pattern:     Conditional aggregation
Approach:    SUM(CASE WHEN status LIKE 'cancelled%' THEN 1.0 ELSE 0 END) / COUNT(*)
             GROUP BY request_at
             Filter: WHERE client not banned AND driver not banned
Key Insight: Cancellation rate = conditional count / total count per day
One-liner:   CASE WHEN inside SUM for numerator, COUNT for denominator, per day.
```

---

## Pattern Distribution

```
GROUP BY + HAVING (count filter):        8 problems  (1-6, 12, 19)
GROUP BY + MAX/MIN:                      3 problems  (5, 7, 9)
CONDITIONAL AGGREGATION (CASE in AGG):   5 problems  (13-14, 16-17, 20)
COUNT DISTINCT + HAVING:                 2 problems  (10, 11)
STRING AGG / ROLLUP:                     2 problems  (15, 18)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 182, LC 596, LC 586 (basic GROUP BY + HAVING)
- Day 2: LC 1050, LC 511, LC 607 (multi-column, MIN, exclusion)
- Day 3: LC 1068, LC 1965 (SUM, NULL handling)

### Week 2: Core Patterns (Days 4-6)
- Day 4: LC 184, LC 1045 (MAX + join back, ALL products)
- Day 5: LC 1126, LC 570 (avg threshold, manager reports)
- Day 6: LC 1174, LC 1193 (conditional agg, multi-agg)

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 262, LC 1194 (trips, tournament)
- Day 8: LC 1225, LC 615 (contiguous, dept vs company)
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Filter aggregates per row (not collapse) | Pattern 01 (Window Functions) — AGG OVER keeps rows |
| Find duplicates to delete | Pattern 12 (Deduplication) — DELETE + ROW_NUMBER |
| Conditional columns from aggregates | Pattern 06 (Pivot / CASE WHEN) — rows to columns |
| Top-N per group | Pattern 09 (Top-N Per Group) — ROW_NUMBER approach |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (8 Easy, 8 Medium, 4 Hard)
MUST-DO:            LC 182, 596, 586, 1050, 607, 184, 511, 1068, 1045, 1126
TOP 3 MOST ASKED:   LC 182 (Dup Emails), LC 184 (Dept Max), LC 262 (Trips)
PATTERN SPLIT:      HAVING filter (8), MAX/MIN (3), Conditional Agg (5),
                    COUNT DISTINCT (2), STRING_AGG (2)
STUDY ORDER:        GROUP BY basics → HAVING → MAX+join back → Conditional → ROLLUP
KEY INSIGHT:        GROUP BY = HashMap; HAVING = filter on the map values
INTERVIEW LINE:     "I use GROUP BY as a frequency map, HAVING to filter groups,
                     and CASE inside aggregates for conditional counting."
```

---

## 30-SECOND REVISION BOX

```
GROUP BY:      Bucket rows by key, compute aggregate per bucket
HAVING:        Filter on aggregated values (WHERE for groups)
EXECUTION:     WHERE → GROUP BY → HAVING → SELECT → ORDER BY
COUNT(*):      Counts all rows including NULLs
COUNT(col):    Counts non-NULL values only
AVG trap:      AVG skips NULLs — use COALESCE if NULL = 0
MAX per group: GROUP BY + MAX in subquery, JOIN back for full row
CONDITIONAL:   SUM(CASE WHEN x THEN 1 END) — count conditionally
ROLLUP:        GROUP BY ROLLUP(a, b) — adds subtotals and grand total
RULE:          Row filters in WHERE, group filters in HAVING — always
```
