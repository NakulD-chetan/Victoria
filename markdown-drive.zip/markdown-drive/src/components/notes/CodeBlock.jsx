import { useState, useCallback } from 'react';
import hljs from 'highlight.js';
import { getAuthHeaders } from '../AuthGate';

const LANG_MAP = { js: 'javascript', py: 'python', ts: 'javascript', jsx: 'javascript', tsx: 'javascript' };
const EXEC_LANGS = new Set(['javascript', 'python', 'cpp', 'java']);

export default function CodeBlock({ code, lang, editable = false, onCodeChange }) {
  const [output, setOutput] = useState(null);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const execLang = LANG_MAP[lang] || lang;
  const canRun = EXEC_LANGS.has(execLang);

  const run = useCallback(async () => {
    setRunning(true); setOutput(null);
    try {
      const res = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify({ source_code: code, language: execLang }),
      });
      const data = await res.json();
      if (data.error) setOutput({ type: 'error', text: data.error });
      else if (data.compile_output && !data.stdout) setOutput({ type: 'error', text: data.compile_output });
      else setOutput({ type: 'ok', text: (data.stdout || '') + (data.stderr ? '\n' + data.stderr : '') });
    } catch (e) { setOutput({ type: 'error', text: e.message }); }
    finally { setRunning(false); }
  }, [code, execLang]);

  const highlighted = lang && hljs.getLanguage(lang)
    ? hljs.highlight(code, { language: lang }).value
    : hljs.highlightAuto(code).value;

  const copy = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch (e) {
      console.warn('Copy failed:', e);
    }
  }, [code]);

  return (
    <div className="sn-codeblock" contentEditable={false}>
      <div className="sn-codeblock__header">
        <span className="sn-codeblock__lang">{lang || 'code'}</span>
        <div className="sn-codeblock__actions">
          <button
            className={`sn-codeblock__btn sn-codeblock__btn--icon${copied ? ' sn-codeblock__btn--success' : ''}`}
            onClick={copy}
            title={copied ? 'Copied' : 'Copy code'}
            aria-label={copied ? 'Copied' : 'Copy code'}
          >
            {copied ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="10" height="10" rx="2" />
                <path d="M15 9V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" />
              </svg>
            )}
          </button>
          {canRun && (
            <button className="sn-codeblock__btn sn-codeblock__btn--run" onClick={run} disabled={running} title="Run code">
              <span className="sn-codeblock__btn-icon">{running ? '⟳' : '▶'}</span>
              <span>{running ? 'Running' : 'Run'}</span>
            </button>
          )}
        </div>
      </div>
      {editable ? (
        <pre><code
          contentEditable
          suppressContentEditableWarning
          onBlur={(e) => onCodeChange?.(e.currentTarget.textContent || '')}
          dangerouslySetInnerHTML={{ __html: highlighted }}
        /></pre>
      ) : (
        <pre><code dangerouslySetInnerHTML={{ __html: highlighted }} /></pre>
      )}
      {output && (
        <div className={`sn-codeblock__output ${output.type === 'error' ? 'sn-codeblock__output--error' : ''}`}>
          <div className="sn-codeblock__output-header">{output.type === 'error' ? 'Error' : 'Output'}</div>
          <pre>{output.text || '(no output)'}</pre>
        </div>
      )}
    </div>
  );
}
