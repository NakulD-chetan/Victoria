import { useRef, useEffect, useCallback, forwardRef, useImperativeHandle } from 'react';
import rough from 'roughjs';
import { COMPONENT_TYPES, CONNECTION_RULES } from '../../lib/problems/component-types';
import { usePlaygroundStore } from '../../stores/playground-store';
import { updateSim, updateSimProcessing, getProcessingTimer, getBottleneck, injectChaos } from '../../lib/problems/simulation';
import { computeSnapGuides, computeEqualSpacing, drawSnapGuides, drawDistanceIndicators } from '../../lib/problems/smart-guides';

const DPR = typeof window !== 'undefined' ? window.devicePixelRatio || 1 : 1;
const FH = "'Comic Neue','Comic Sans MS',cursive";
const FM = "'Consolas','Courier New',monospace";

function ease(t) {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

function isDark() {
  return document.documentElement.getAttribute('data-theme') !== 'light';
}

const DesignCanvas = forwardRef(function DesignCanvas(_, ref) {
  const canvasRef = useRef(null);
  const shapeCache = useRef({});
  const zoomRef = useRef(1);
  const panRef = useRef({ x: 0, y: 0 });
  const lastTimeRef = useRef(0);
  const procTimers = useRef(new Map());
  const modeIndRef = useRef(null);
  const modeTimerRef = useRef(null);
  const lastThemeRef = useRef('');
  const activeGuides = useRef({ x: [], y: [] });
  const activeSpacingGuides = useRef([]);
  const isDraggingRef = useRef(false);
  const dragCompIdRef = useRef(null);

  useImperativeHandle(ref, () => {
    const el = canvasRef.current;
    if (!el) return el;
    return {
      getBoundingClientRect: () => el.getBoundingClientRect(),
      dispatchEvent: (e) => el.dispatchEvent(e),
      screenToWorld: (sx, sy) => ({
        x: (sx - panRef.current.x) / zoomRef.current,
        y: (sy - panRef.current.y) / zoomRef.current,
      }),
    };
  });

  const s2c = useCallback((sx, sy) => ({
    x: (sx - panRef.current.x) / zoomRef.current,
    y: (sy - panRef.current.y) / zoomRef.current,
  }), []);

  const cacheShape = useCallback((key, w, h, fn) => {
    if (shapeCache.current[key]) return shapeCache.current[key];
    const c = document.createElement('canvas');
    c.width = w * DPR; c.height = h * DPR;
    const cx = c.getContext('2d');
    cx.scale(DPR, DPR);
    fn(rough.canvas(c), cx);
    shapeCache.current[key] = c;
    return c;
  }, []);

  const showMode = useCallback((text) => {
    if (modeIndRef.current) {
      modeIndRef.current.textContent = text;
      modeIndRef.current.style.opacity = '1';
    }
    if (modeTimerRef.current) clearTimeout(modeTimerRef.current);
    modeTimerRef.current = setTimeout(() => {
      if (modeIndRef.current) modeIndRef.current.style.opacity = '0';
    }, 2000);
  }, []);

  function connEndpoints(conn) {
    const store = usePlaygroundStore.getState();
    const f = store.components.find((c) => c.id === conn.from);
    const t = store.components.find((c) => c.id === conn.to);
    if (!f || !t) return null;
    const ft = COMPONENT_TYPES[f.type], tt = COMPONENT_TYPES[t.type];
    const fcx = f.x + ft.w / 2, tcx = t.x + tt.w / 2;
    if (fcx <= tcx) return { p1: { x: f.x + ft.w, y: f.y + ft.h / 2 }, p2: { x: t.x, y: t.y + tt.h / 2 } };
    return { p1: { x: f.x, y: f.y + ft.h / 2 }, p2: { x: t.x + tt.w, y: t.y + tt.h / 2 } };
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let W = 0, H = 0;
    let dragComp = null, dragOffX = 0, dragOffY = 0;
    let isPanning = false, panStartX = 0, panStartY = 0, panStartPX = 0, panStartPY = 0;
    let mouseX = 0, mouseY = 0;
    let animFrameId;

    function resize() {
      const r = canvas.getBoundingClientRect();
      W = r.width; H = r.height;
      canvas.width = W * DPR; canvas.height = H * DPR;
      Object.keys(shapeCache.current).forEach((k) => delete shapeCache.current[k]);
      lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    const ctx = canvas.getContext('2d');

    function getCompHealth(comp) {
      const s = comp._s, c = comp.config;
      switch (comp.type) {
        case 'server': { const p = ((s.active) || 0) / ((c.maxConcurrent) * (c.instances)); return p > 0.8 ? 'critical' : p > 0.5 ? 'warning' : 'ok'; }
        case 'service': { if (s.cbState === 'open') return 'critical'; return ((s.active) || 0) / (c.maxConcurrent) > 0.8 ? 'critical' : 'ok'; }
        case 'database': { return ((s.active) || 0) / (c.poolSize) > 0.8 ? 'critical' : 'ok'; }
        case 'queue': { return ((s.depth) || 0) / (c.capacity) > 0.8 ? 'critical' : 'ok'; }
        case 'ratelimiter': return ((s.rejected) || 0) > 0 ? 'warning' : 'ok';
      }
      return 'ok';
    }

    function render(timestamp) {
      if (!lastTimeRef.current) lastTimeRef.current = timestamp;
      const dt = Math.min(timestamp - lastTimeRef.current, 100);
      lastTimeRef.current = timestamp;

      const store = usePlaygroundStore.getState();
      const { components, connections, requests, flashes, stats, lbCounters, simulating, speed, selectedCompId, selectedConnId, mode, connectSource } = store;

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) {
        Object.keys(shapeCache.current).forEach((k) => delete shapeCache.current[k]);
        lastThemeRef.current = curTheme;
      }
      const dark = curTheme !== 'light';
      const dotColor = dark ? 'rgba(255,255,255,0.07)' : '#e7e5e4';
      const textColor = dark ? '#e7e5e4' : '#1c1917';
      const dimColor = dark ? '#a8a29e' : '#78716c';
      const emptyHint = dark ? '#a8a29e' : '#a8a29e';

      if (simulating) {
        updateSim(dt, speed, components, connections, requests, flashes, stats, lbCounters);
        for (const req of requests) {
          if (req.state === 'processing' && !procTimers.current.has(req.id)) {
            const comp = components.find((c) => c.id === req.atComp);
            if (comp) procTimers.current.set(req.id, getProcessingTimer(comp.type, comp.config));
          }
        }
        updateSimProcessing(dt, speed, components, connections, requests, stats, lbCounters, procTimers.current);
        for (let i = requests.length - 1; i >= 0; i--) {
          if (requests[i].state === 'done') requests.splice(i, 1);
        }
      }

      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);

      ctx.fillStyle = dotColor;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      ctx.save();
      ctx.translate(panRef.current.x, panRef.current.y);
      ctx.scale(zoomRef.current, zoomRef.current);

      const zoom = zoomRef.current;
      let connectAllowed = null;
      if (mode === 'connect' && connectSource) {
        const src = components.find((c) => c.id === connectSource);
        if (src) connectAllowed = CONNECTION_RULES[src.type] || [];
      }

      connections.forEach((conn) => {
        const ep = connEndpoints(conn);
        if (!ep) return;
        const isSel = conn.id === selectedConnId;
        const reqCount = requests.filter((r) => r.connId === conn.id && r.state === 'traveling').length;
        const hasTraffic = reqCount > 0;
        ctx.strokeStyle = isSel ? '#1971c2' : hasTraffic ? '#2f9e44' : dimColor;
        ctx.lineWidth = isSel ? 3 / zoom : hasTraffic ? 2 / zoom : 1.5 / zoom;
        ctx.beginPath(); ctx.moveTo(ep.p1.x, ep.p1.y); ctx.lineTo(ep.p2.x, ep.p2.y); ctx.stroke();
        const a = Math.atan2(ep.p2.y - ep.p1.y, ep.p2.x - ep.p1.x);
        const arrowLen = 8 / zoom;
        ctx.beginPath();
        ctx.moveTo(ep.p2.x - arrowLen * Math.cos(a - 0.4), ep.p2.y - arrowLen * Math.sin(a - 0.4));
        ctx.lineTo(ep.p2.x, ep.p2.y);
        ctx.lineTo(ep.p2.x - arrowLen * Math.cos(a + 0.4), ep.p2.y - arrowLen * Math.sin(a + 0.4));
        ctx.stroke();

        const fromComp = components.find((c) => c.id === conn.from);
        const toComp = components.find((c) => c.id === conn.to);
        if (fromComp && toComp) {
          const mx = (ep.p1.x + ep.p2.x) / 2, my = (ep.p1.y + ep.p2.y) / 2;
          ctx.font = `600 ${6 / zoom}px ${FM}`;
          ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
          ctx.fillStyle = hasTraffic ? '#2f9e44' : dimColor;
          ctx.fillText(`${COMPONENT_TYPES[fromComp.type].name} \u2192 ${COMPONENT_TYPES[toComp.type].name}`, mx, my - 3 / zoom);
        }
      });

      if (mode === 'connect' && connectSource) {
        const f = components.find((c) => c.id === connectSource);
        if (f) {
          const ft = COMPONENT_TYPES[f.type];
          const fcx = f.x + ft.w / 2, fcy = f.y + ft.h / 2;
          ctx.strokeStyle = '#1971c2'; ctx.lineWidth = 2 / zoom;
          ctx.setLineDash([6 / zoom, 4 / zoom]);
          ctx.beginPath(); ctx.moveTo(fcx, fcy); ctx.lineTo(mouseX, mouseY); ctx.stroke();
          ctx.setLineDash([]);
        }
      }

      components.forEach((comp) => {
        const t = COMPONENT_TYPES[comp.type];
        const isConnDimmed = connectAllowed && comp.id !== connectSource && !connectAllowed.includes(comp.type);
        if (isConnDimmed) ctx.globalAlpha = 0.25;

        const boxStroke = dark ? 'rgba(255,255,255,0.5)' : t.color;
        const shape = cacheShape('comp-' + comp.type, t.w + 4, t.h + 4, (rc) => {
          rc.rectangle(2, 2, t.w, t.h, {
            seed: comp.type.charCodeAt(0) * 7, roughness: 1.4,
            fill: t.fill, fillStyle: 'hachure', hachureGap: 6,
            strokeWidth: 2, stroke: boxStroke,
          });
        });
        ctx.drawImage(shape, comp.x - 2, comp.y - 2, t.w + 4, t.h + 4);

        ctx.font = '16px serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = textColor;
        ctx.fillText(t.icon, comp.x + t.w / 2, comp.y + t.h / 2 - 7);
        ctx.font = `600 9px ${FH}`; ctx.fillStyle = dark ? '#e0e0e0' : t.color;
        ctx.fillText(t.name, comp.x + t.w / 2, comp.y + t.h / 2 + 13);

        if (isConnDimmed) ctx.globalAlpha = 1;

        if (connectAllowed && comp.id !== connectSource && connectAllowed.includes(comp.type)) {
          const pulse = 0.6 + 0.4 * Math.sin(timestamp / 300);
          ctx.strokeStyle = `rgba(47,158,68,${pulse})`; ctx.lineWidth = 3 / zoom;
          ctx.setLineDash([5 / zoom, 3 / zoom]);
          ctx.strokeRect(comp.x - 4, comp.y - 4, t.w + 8, t.h + 8);
          ctx.setLineDash([]);
        }

        if (simulating || stats.sent > 0) {
          const h = getCompHealth(comp);
          if (h !== 'ok') {
            ctx.strokeStyle = h === 'critical' ? '#e03131' : '#f08c00';
            ctx.lineWidth = 3;
            ctx.strokeRect(comp.x - 1, comp.y - 1, t.w + 2, t.h + 2);
          }
        }

        if (comp.id === selectedCompId) {
          ctx.strokeStyle = '#1971c2'; ctx.lineWidth = 2; ctx.setLineDash([6, 4]);
          ctx.strokeRect(comp.x - 4, comp.y - 4, t.w + 8, t.h + 8);
          ctx.setLineDash([]);
        }

        if (mode === 'connect' && connectSource === comp.id) {
          ctx.strokeStyle = '#1971c2'; ctx.lineWidth = 3;
          ctx.strokeRect(comp.x - 2, comp.y - 2, t.w + 4, t.h + 4);
        }

        if (simulating || stats.sent > 0) {
          const cnt = ((comp._s.active) || 0) || ((comp._s.depth) || 0);
          if (cnt > 0) {
            const bx = comp.x + t.w - 2, by = comp.y - 2;
            const r = Math.max(7, String(cnt).length * 3.5 + 4);
            ctx.beginPath(); ctx.arc(bx, by, r, 0, Math.PI * 2);
            const h = getCompHealth(comp);
            ctx.fillStyle = h === 'critical' ? '#e03131' : h === 'warning' ? '#f08c00' : '#1971c2';
            ctx.fill();
            ctx.font = `700 7px ${FM}`; ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
            ctx.fillText(String(cnt), bx, by);
          }
        }
      });

      if (simulating || stats.sent > 0) {
        const bn = getBottleneck(components);
        if (bn) {
          const bComp = bn.comp;
          const bt = COMPONENT_TYPES[bComp.type];
          const pulse = 0.5 + 0.5 * Math.sin(timestamp / 200);
          ctx.save();
          ctx.strokeStyle = `rgba(224, 49, 49, ${0.5 + pulse * 0.5})`;
          ctx.lineWidth = 4 / zoom;
          ctx.setLineDash([8 / zoom, 4 / zoom]);
          ctx.strokeRect(bComp.x - 6, bComp.y - 6, bt.w + 12, bt.h + 12);
          ctx.setLineDash([]);
          ctx.font = `700 ${9 / zoom}px ${FM}`;
          ctx.textAlign = 'center';
          ctx.fillStyle = '#e03131';
          ctx.fillText(`\u26A0 ${bn.utilization}% utilized`, bComp.x + bt.w / 2, bComp.y - 10 / zoom);
          ctx.restore();
        }
      }

      components.forEach((comp) => {
        if (comp._s.dead) {
          const t = COMPONENT_TYPES[comp.type];
          ctx.save();
          ctx.globalAlpha = 0.6;
          ctx.fillStyle = '#e03131';
          ctx.font = `700 ${20 / zoom}px serif`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('\u{1F480}', comp.x + t.w / 2, comp.y + t.h / 2);
          ctx.globalAlpha = 1;
          ctx.restore();
        }
      });

      requests.forEach((req) => {
        if (req.state === 'traveling') {
          const conn = connections.find((c) => c.id === req.connId);
          if (!conn) return;
          const ep = connEndpoints(conn);
          if (!ep) return;
          const p = ease(req.progress);
          const x = ep.p1.x + (ep.p2.x - ep.p1.x) * p;
          const y = ep.p1.y + (ep.p2.y - ep.p1.y) * p;
          ctx.beginPath(); ctx.arc(x, y, 4.5, 0, Math.PI * 2);
          ctx.fillStyle = req.color; ctx.fill();
          ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
        } else if (req.state === 'processing' && req.atComp) {
          const comp = components.find((c) => c.id === req.atComp);
          if (!comp) return;
          const t = COMPONENT_TYPES[comp.type];
          const pulse = 0.5 + 0.5 * Math.sin(timestamp / 200);
          ctx.globalAlpha = 0.5;
          ctx.beginPath(); ctx.arc(comp.x + t.w / 2, comp.y + t.h / 2, 3 + pulse * 3, 0, Math.PI * 2);
          ctx.fillStyle = req.color; ctx.fill();
          ctx.globalAlpha = 1;
        }
      });

      flashes.forEach((f) => {
        const alpha = f.timer / f.maxTimer;
        ctx.globalAlpha = alpha;
        ctx.font = '700 14px serif'; ctx.fillStyle = f.color;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(f.symbol, f.x, f.y - (1 - alpha) * 10);
        ctx.globalAlpha = 1;
      });

      if (isDraggingRef.current && dragCompIdRef.current) {
        const draggedComp = components.find(c => c.id === dragCompIdRef.current);
        if (draggedComp) {
          const dragType = COMPONENT_TYPES[draggedComp.type];
          if (dragType) {
            drawSnapGuides(ctx, activeGuides.current, activeSpacingGuides.current, zoom, dark);
            drawDistanceIndicators(ctx, draggedComp, dragType, components, COMPONENT_TYPES, zoom);
          }
        }
      }

      ctx.restore();

      if (!components.length) {
        ctx.font = `600 17px ${FH}`; ctx.fillStyle = emptyHint;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText('Drag components from the sidebar to get started', W / 2, H / 2);
      }

      animFrameId = requestAnimationFrame(render);
    }

    animFrameId = requestAnimationFrame(render);

    function hitComp(cx, cy) {
      const comps = usePlaygroundStore.getState().components;
      for (let i = comps.length - 1; i >= 0; i--) {
        const c = comps[i], t = COMPONENT_TYPES[c.type];
        if (cx >= c.x && cx <= c.x + t.w && cy >= c.y && cy <= c.y + t.h) return c;
      }
      return null;
    }

    function distToSeg(px, py, x1, y1, x2, y2) {
      const dx = x2 - x1, dy = y2 - y1, l = dx * dx + dy * dy;
      if (!l) return Math.hypot(px - x1, py - y1);
      const t = Math.max(0, Math.min(1, ((px - x1) * dx + (py - y1) * dy) / l));
      return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
    }

    function hitConn(cx, cy) {
      const conns = usePlaygroundStore.getState().connections;
      for (const cn of conns) {
        const ep = connEndpoints(cn);
        if (ep && distToSeg(cx, cy, ep.p1.x, ep.p1.y, ep.p2.x, ep.p2.y) < 10 / zoomRef.current) return cn;
      }
      return null;
    }

    function onMouseDown(e) {
      const r = canvas.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      const pt = s2c(sx, sy);
      const store = usePlaygroundStore.getState();

      if (e.button === 1 || (e.button === 0 && e.ctrlKey)) {
        isPanning = true; panStartX = sx; panStartY = sy;
        panStartPX = panRef.current.x; panStartPY = panRef.current.y;
        e.preventDefault(); return;
      }

      if (store.mode === 'connect') {
        const hit = hitComp(pt.x, pt.y);
        if (!hit) return;
        if (!store.connectSource) {
          const allowed = CONNECTION_RULES[hit.type] || [];
          if (!allowed.length) { showMode(`\u26A0 ${COMPONENT_TYPES[hit.type].name} has no outgoing connections`); return; }
          store.setConnectSource(hit.id);
          showMode('Click a green-highlighted target...');
        } else if (hit.id !== store.connectSource) {
          const srcComp = store.components.find((c) => c.id === store.connectSource);
          if (!srcComp) return;
          const allowed = CONNECTION_RULES[srcComp.type] || [];
          if (!allowed.includes(hit.type)) {
            showMode(`\u2715 Cannot connect ${COMPONENT_TYPES[srcComp.type].name} \u2192 ${COMPONENT_TYPES[hit.type].name}`);
            return;
          }
          store.addConnection(store.connectSource, hit.id);
          store.setConnectSource(null);
          store.setMode('idle');
        }
        return;
      }

      const hitC = hitComp(pt.x, pt.y);
      if (hitC) {
        store.selectComponent(hitC.id);
        dragComp = hitC.id;
        dragCompIdRef.current = hitC.id;
        isDraggingRef.current = true;
        dragOffX = pt.x - hitC.x; dragOffY = pt.y - hitC.y;
        return;
      }
      const hitCn = hitConn(pt.x, pt.y);
      if (hitCn) { store.selectConnection(hitCn.id); return; }
      store.selectComponent(null);
    }

    function onMouseMove(e) {
      const r = canvas.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      if (isPanning) {
        panRef.current.x = panStartPX + (sx - panStartX);
        panRef.current.y = panStartPY + (sy - panStartY);
        return;
      }
      const pt = s2c(sx, sy);
      mouseX = pt.x; mouseY = pt.y;
      if (dragComp) {
        const store = usePlaygroundStore.getState();
        const comp = store.components.find((c) => c.id === dragComp);
        if (comp) {
          let newX = mouseX - dragOffX;
          let newY = mouseY - dragOffY;

          const tempComp = { ...comp, x: newX, y: newY };
          const dragType = COMPONENT_TYPES[comp.type];
          const snapResult = computeSnapGuides(tempComp, dragType, store.components, COMPONENT_TYPES);

          if (snapResult.snapX !== null) newX = snapResult.snapX;
          if (snapResult.snapY !== null) newY = snapResult.snapY;

          comp.x = newX;
          comp.y = newY;

          const snappedComp = { ...comp, x: newX, y: newY };
          const snappedDragType = COMPONENT_TYPES[comp.type];
          activeGuides.current = snapResult.guides;
          activeSpacingGuides.current = computeEqualSpacing(snappedComp, snappedDragType, store.components, COMPONENT_TYPES);
        }
      } else {
        activeGuides.current = { x: [], y: [] };
        activeSpacingGuides.current = [];
      }
    }

    function onMouseUp() {
      if (isPanning) { isPanning = false; return; }
      dragComp = null;
      isDraggingRef.current = false;
      dragCompIdRef.current = null;
      activeGuides.current = { x: [], y: [] };
      activeSpacingGuides.current = [];
    }

    function onWheel(e) {
      e.preventDefault();
      const r = canvas.getBoundingClientRect();
      const sx = e.clientX - r.left, sy = e.clientY - r.top;
      const zf = e.deltaY > 0 ? 0.9 : 1.1;
      const newZoom = Math.max(0.15, Math.min(4, zoomRef.current * zf));
      panRef.current.x = sx - (sx - panRef.current.x) * (newZoom / zoomRef.current);
      panRef.current.y = sy - (sy - panRef.current.y) * (newZoom / zoomRef.current);
      zoomRef.current = newZoom;
    }

    function onKeyDown(e) {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
      const store = usePlaygroundStore.getState();
      if (e.code === 'Space') { e.preventDefault(); store.toggleSimulation(); }
      if (e.key === 'c' || e.key === 'C') {
        if (store.mode === 'connect') {
          store.setMode('idle');
        } else if (store.selectedCompId) {
          const comp = store.components.find((c) => c.id === store.selectedCompId);
          if (comp) {
            const allowed = CONNECTION_RULES[comp.type] || [];
            if (!allowed.length) { showMode(`${COMPONENT_TYPES[comp.type].name} has no outgoing connections`); return; }
            store.setConnectSource(store.selectedCompId);
            store.setMode('connect');
            showMode('Click a green-highlighted target...');
          }
        } else {
          store.setMode('connect');
          showMode('Click source component...');
        }
      }
      if (e.key === 'Delete' || e.key === 'Backspace') {
        if (store.selectedCompId) store.removeComponent(store.selectedCompId);
        else if (store.selectedConnId) store.removeConnection(store.selectedConnId);
      }
      if (e.key === 'Escape') { store.setMode('idle'); store.selectComponent(null); }
      if (e.key === 'f' || e.key === 'F') fitAll();
    }

    function fitAll() {
      const comps = usePlaygroundStore.getState().components;
      if (!comps.length) { zoomRef.current = 1; panRef.current = { x: 0, y: 0 }; return; }
      let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
      comps.forEach((c) => {
        const t = COMPONENT_TYPES[c.type];
        minX = Math.min(minX, c.x); minY = Math.min(minY, c.y);
        maxX = Math.max(maxX, c.x + t.w); maxY = Math.max(maxY, c.y + t.h);
      });
      const bw = maxX - minX + 80, bh = maxY - minY + 80;
      zoomRef.current = Math.min(W / bw, H / bh, 2);
      panRef.current.x = (W - bw * zoomRef.current) / 2 - (minX - 40) * zoomRef.current;
      panRef.current.y = (H - bh * zoomRef.current) / 2 - (minY - 40) * zoomRef.current;
    }

    function handleFitAll() { fitAll(); }

    canvas.addEventListener('mousedown', onMouseDown);
    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseup', onMouseUp);
    canvas.addEventListener('wheel', onWheel, { passive: false });
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    canvas.addEventListener('fit-all', handleFitAll);
    document.addEventListener('keydown', onKeyDown);

    let replayTimer = null;
    const unsubReplay = usePlaygroundStore.subscribe((state, prev) => {
      if (state.replayTest && state.replayTest !== prev.replayTest) {
        const tc = state.replayTest;
        const store = usePlaygroundStore.getState();

        store.resetSimulation();

        if (tc.type === 'simulation' && tc.rps) {
          const comps = usePlaygroundStore.getState().components;
          comps.filter(c => c.type === 'client').forEach(c => {
            c._s._savedRps = c.config.rps;
            c.config.rps = tc.rps;
          });
        }

        if (tc.type === 'chaos') {
          const comps = usePlaygroundStore.getState().components;
          const conns = usePlaygroundStore.getState().connections;
          comps.forEach(c => { c._s = c._s || {}; });
          const chaosScenario = { type: tc.type === 'chaos' ? (tc.type || 'kill_node') : tc.type, target: tc.target, multiplier: tc.multiplier, between: tc.between };
          if (tc.type) injectChaos({ type: tc.type, target: tc.target, multiplier: tc.multiplier, between: tc.between }, comps, conns);
        }

        usePlaygroundStore.setState({ simulating: true });
        showMode(`\u25B6 Replaying: ${tc.name || tc.label}`);

        if (replayTimer) clearTimeout(replayTimer);
        replayTimer = setTimeout(() => {
          const s = usePlaygroundStore.getState();
          if (tc.type === 'simulation' && tc.rps) {
            s.components.filter(c => c.type === 'client').forEach(c => {
              if (c._s._savedRps !== undefined) { c.config.rps = c._s._savedRps; delete c._s._savedRps; }
            });
          }
          usePlaygroundStore.setState({ simulating: false });
          usePlaygroundStore.getState().clearReplayTest();
          showMode('Replay finished');
        }, 6000);
      }
    });

    return () => {
      cancelAnimationFrame(animFrameId);
      if (replayTimer) clearTimeout(replayTimer);
      unsubReplay();
      window.removeEventListener('resize', resize);
      canvas.removeEventListener('mousedown', onMouseDown);
      canvas.removeEventListener('mousemove', onMouseMove);
      canvas.removeEventListener('mouseup', onMouseUp);
      canvas.removeEventListener('wheel', onWheel);
      canvas.removeEventListener('fit-all', handleFitAll);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [cacheShape, s2c, showMode]);

  return (
    <div className="dc-design-canvas">
      <canvas ref={canvasRef} className="dc-design-canvas__el" />
      <div ref={modeIndRef} className="dc-design-canvas__mode" />
      <div className="dc-design-canvas__shortcuts">
        <kbd>C</kbd> Connect <kbd>Del</kbd> Delete <kbd>Space</kbd> Play/Pause <kbd>Scroll</kbd> Zoom <kbd>Ctrl+Drag</kbd> Pan <kbd>F</kbd> Fit
      </div>
    </div>
  );
});

export default DesignCanvas;
