# Prefix Sum — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Every problem builds pattern recognition for FAANG interviews.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Range Sum Query - Immutable | Easy | 303 | 1D prefix, range query | Purest prefix sum — foundation for all range queries |
| 2 | Subarray Sum Equals K | Medium | 560 | Prefix + hash map | Most-asked prefix sum problem at FAANG |
| 3 | Contiguous Array | Medium | 525 | Prefix + map (0→-1) | Teaches binary array → treat as sum |
| 4 | Subarray Product Less Than K | Medium | 713 | Prefix product / sliding window | Product variant; prefix or window |
| 5 | Maximum Size Subarray Sum Equals K | Medium | 325 | Prefix + map, maximize length | Map stores first occurrence for max length |
| 6 | Range Sum Query 2D - Immutable | Medium | 304 | 2D prefix sum | Core 2D inclusion-exclusion template |
| 7 | Count Subarrays With Given XOR | Medium | GFG | Prefix XOR + map | XOR variant of subarray sum |
| 8 | Minimum Size Subarray Sum | Medium | 209 | Prefix + binary search | Prefix + BS when window fails |
| 9 | Subarray Sums Divisible by K | Medium | 974 | Prefix mod K | Mod/remainder pattern |
| 10 | Shortest Subarray with Sum at Least K | Hard | 862 | Prefix + monotonic deque | Handles negatives; deque maintains candidates |

---

## Complete 30-Problem Progression

### Easy (Problems 1-8) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Range Sum Query - Immutable | 303 | 1D prefix | Build + O(1) query |
| 2 | Find Pivot Index | 724 | Prefix balance | Left sum = right sum |
| 3 | Running Sum of 1d Array | 1480 | In-place prefix | Trivial build |
| 4 | Find the Middle Index in Array | 1991 | Prefix balance | Pivot variant |
| 5 | Left and Right Sum Differences | 2574 | Prefix + suffix | Both directions |
| 6 | Number of Ways to Split Array | 2270 | Prefix split count | Compare left vs right |
| 7 | Minimum Value to Get Positive Step by Step Sum | 1413 | Prefix min | Track running min |
| 8 | K Radius Subarray Averages | 2090 | Fixed window / prefix | Average = sum/k |

### Medium (Problems 9-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 9 | Subarray Sum Equals K | 560 | Prefix + map | The canonical problem |
| 10 | Contiguous Array | 525 | 0→-1, prefix + map | Binary → sum |
| 11 | Subarray Product Less Than K | 713 | Product / window | Prefix product or sliding window |
| 12 | Maximum Size Subarray Sum Equals K | 325 | Map stores first index | Max length subarray |
| 13 | Range Sum Query 2D - Immutable | 304 | 2D prefix | Inclusion-exclusion |
| 14 | Subarray Sums Divisible by K | 974 | Prefix mod K | Remainder counting |
| 15 | Minimum Size Subarray Sum | 209 | Prefix + BS | Or sliding window |
| 16 | Maximum Subarray | 53 | Kadane / prefix min | Prefix - min prefix |
| 17 | Product of Array Except Self | 238 | Prefix + suffix product | Not contiguous; prefix idea |
| 18 | Find the Longest Equal Subarray | 2831 | Prefix of count | At most k removals |
| 19 | Count Nice Pairs in an Array | 1814 | Prefix transform + map | arr[i]-rev(arr[i]) |
| 20 | Continuous Subarray Sum | 523 | Prefix mod K, length ≥ 2 | Same remainder, distance ≥ 2 |
| 21 | Count Subarrays With Given XOR | GFG | Prefix XOR + map | XOR variant of subarray sum |
| 22 | Matrix Block Sum | 1314 | 2D prefix, fixed block | 2D region sum |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Shortest Subarray with Sum at Least K | 862 | Prefix + deque | Monotonic deque; handles negatives |
| 24 | Count Subarrays With Fixed Bounds | 2444 | Prefix + min/max tracking | Complex state |
| 25 | Maximum Sum of Two Non-Overlapping Subarrays | 1031 | Prefix + split | Two windows |
| 26 | Number of Submatrices That Sum to Target | 1074 | 2D prefix + 1D map | Compress rows, then 1D |
| 27 | Count Subarrays With Score Less Than K | 2302 | Prefix + deque / BS | Score = sum * length |
| 28 | Maximum Sum Obtained of Any Permutation | 1589 | Difference array | Range updates |
| 29 | Create Sorted Array through Instructions | 1649 | Fenwick + prefix idea | Advanced |
| 30 | Max Sum of Rectangle No Larger Than K | 363 | 2D prefix + 1D + BS | 2D compress + binary search |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Range Sum Query - Immutable (LC 303)
```
Type: 1D prefix
Key: prefix[i] = sum(arr[0..i-1]), query = prefix[right+1] - prefix[left]
Template: Template 1
One-liner: Build prefix, return prefix[j+1]-prefix[i].
```

### Problem 2: Subarray Sum Equals K (LC 560)
```
Type: Prefix + hash map
Key: prefix[j]-prefix[i]=K ⇒ count prefix[i]=prefix[j]-K
Map: {0: 1} init
Template: Template 2
One-liner: Single pass, map stores prefix counts, add map[prefix-k] to result.
```

### Problem 10: Contiguous Array (LC 525)
```
Type: Prefix + map (treat 0 as -1)
Key: Longest subarray with equal 0s and 1s = longest with sum 0
     Replace 0→-1, then prefix sum. Same prefix = equal count.
Template: Template 2 with K=0
One-liner: 0→-1, prefix+map for sum=0, track max length.
```

### Problem 13: Range Sum Query 2D - Immutable (LC 304)
```
Type: 2D prefix
Key: inclusion-exclusion
Template: Template 3
One-liner: Build 2D prefix, region = prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1].
```

### Problem 23: Shortest Subarray with Sum at Least K (LC 862)
```
Type: Prefix + monotonic deque
Key: Negatives break sliding window. Prefix not monotonic.
     Deque maintains indices with increasing prefix (candidates for left endpoint).
     For each j, pop from front while prefix[j]-prefix[front] >= K, update ans.
Template: Prefix + deque
One-liner: Monotonic deque of prefix indices; pop left when valid, pop right when larger prefix.
```

### Problem 26: Number of Submatrices That Sum to Target (LC 1074)
```
Type: 2D prefix + 1D map
Key: Fix two rows r1, r2. Sum of column j in [r1..r2] = prefix[r2+1][j+1]-prefix[r1][j+1]-...
     Compress to 1D array. Run "subarray sum = target" on that 1D.
Template: 2D prefix + Template 2
One-liner: For each row pair, compress to 1D column sums, count subarrays = target.
```

---

## Pattern Distribution

```
1D PREFIX:           8 problems  (1-8)
PREFIX + MAP:        7 problems  (9-10, 12, 14, 19-21)
2D PREFIX:           3 problems  (13, 22, 26)
PREFIX + DEQUE:      2 problems  (23, 27)
PREFIX + BS:         2 problems  (8, 15)
DIFFERENCE ARRAY:    1 problem   (28)
MOD/REMAINDER:       2 problems  (14, 20)
XOR:                 1 problem   (7)
OTHER:               4 problems  (16-18, 24-25, 29-30)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-4 (1D prefix, pivot, running sum)
- Day 2: Problems 5-8 (Prefix balance, split, min, averages)
- Day 3: Problems 9-10 (Subarray sum K, Contiguous array)

### Week 2: Core (Days 4-7)
- Day 4: Problems 11-13 (Product, max size, 2D prefix)
- Day 5: Problems 14-16 (Mod K, min size, max subarray)
- Day 6: Problems 17-20 (Product except self, longest equal, nice pairs, continuous)
- Day 7: Problems 21-22 (Mod K again, matrix block sum)

### Week 3: Advanced (Days 8-10)
- Day 8: Problems 23-25 (Shortest subarray deque, fixed bounds, two non-overlapping)
- Day 9: Problems 26-28 (Submatrices target, score less than K, difference array)
- Day 10: Problems 29-30 (Fenwick, count pairs)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy, 14 Medium, 8 Hard)
MUST-DO:            LC 303, 560, 525, 713, 325, 304, GFG XOR, 209, 974, 862
TOP 3 MOST ASKED:  LC 560 (Subarray Sum K), LC 303 (Range Sum), LC 304 (2D Range)
PATTERN SPLIT:      1D (8), Prefix+Map (7), 2D (3), Deque (2), BS (2), Other (8)
STUDY ORDER:        1D → Prefix+Map → 2D → Deque → Advanced
INTERVIEW LINE:     "I've practiced prefix sum in 1D, 2D, with hash map for count,
                     and with monotonic deque for shortest subarray with negatives."
```
