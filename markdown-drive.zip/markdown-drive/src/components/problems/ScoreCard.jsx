import { useProblemSessionStore } from '../../stores/problem-session-store';
import { usePlaygroundStore } from '../../stores/playground-store';

export default function ScoreCard({ problem }) {
  const archScore = useProblemSessionStore((s) => s.archScore);
  const deepDiveScore = useProblemSessionStore((s) => s.deepDiveScore);
  const totalScore = useProblemSessionStore((s) => s.totalScore);
  const verdict = useProblemSessionStore((s) => s.verdict);
  const hintsUsed = useProblemSessionStore((s) => s.hintsUsed);
  const showScoreCard = useProblemSessionStore((s) => s.showScoreCard);
  const resetSession = useProblemSessionStore((s) => s.resetSession);
  const resetAll = usePlaygroundStore((s) => s.resetAll);

  if (!showScoreCard || !verdict) return null;

  const breakdowns = [
    { label: 'Architecture Design', score: archScore, weight: 70, icon: '\uD83C\uDFD7\uFE0F' },
    { label: 'Deep Dive', score: deepDiveScore, weight: 30, icon: '\uD83E\uDDE0' },
  ];

  const handleReset = () => {
    resetSession();
    resetAll();
  };

  return (
    <div className="dc-score-card-overlay">
      <div className="dc-score-card">
        <div className="dc-score-card__header">
          <h2 className="dc-score-card__title">Design Review</h2>
          <p className="dc-score-card__problem">{problem.title}</p>
        </div>

        <div className="dc-score-card__verdict" style={{ borderColor: verdict.color }}>
          <div className="dc-score-card__total" style={{ color: verdict.color }}>
            {totalScore}%
          </div>
          <div className="dc-score-card__verdict-label" style={{ background: verdict.color }}>
            {verdict.label}
          </div>
        </div>

        <div className="dc-score-card__breakdown">
          {breakdowns.map((b) => (
            <div key={b.label} className="dc-score-card__row">
              <span className="dc-score-card__row-icon">{b.icon}</span>
              <span className="dc-score-card__row-label">{b.label}</span>
              <span className="dc-score-card__row-weight">({b.weight}%)</span>
              <div className="dc-score-card__bar-track">
                <div
                  className="dc-score-card__bar-fill"
                  style={{ width: `${b.score}%`, background: b.score >= 70 ? '#2f9e44' : b.score >= 50 ? '#f08c00' : '#e03131' }}
                />
              </div>
              <span className="dc-score-card__row-score">{b.score}%</span>
            </div>
          ))}
        </div>

        {hintsUsed > 0 && (
          <div className="dc-score-card__penalty">
            Hint penalty: -{hintsUsed * 5}% ({hintsUsed} hint{hintsUsed > 1 ? 's' : ''} used)
          </div>
        )}

        <div className="dc-score-card__actions">
          <button onClick={handleReset} className="dc-btn dc-btn--primary">
            Try Again
          </button>
        </div>
      </div>
    </div>
  );
}
