# Python — Complete Notes Index

> **Source:** Structured Python curriculum + FAANG interview focus  
> **Language:** Simple English — friendly explanations like a teacher talking to you  
> **Level:** Beginner → Intermediate → Advanced → FAANG Interview Ready

---

## Notes Structure

| # | File | Topics Covered | Level |
|---|------|----------------|-------|
| 01 | [[01-Python-History-and-Basics]] | Python history (Guido, 1991, ABC), Python 2 vs 3, interpreted vs compiled, Zen of Python, dynamic typing, REPL, first program | Beginner |
| 02 | [[02-Python-Variables-DataTypes-IO]] | Variables, int/float/str/bool/None, type(), id(), input()/print(), f-strings, type casting | Beginner |
| 03 | [[03-Python-Operators-Control-Flow]] | Arithmetic, comparison, logical, bitwise, assignment; if/elif/else, ternary, match-case; indentation | Beginner |
| 04 | [[04-Python-Loops-Comprehensions]] | for/while, range(), break/continue/pass, else with loops, list/dict/set comprehensions, generator expressions | Beginner-Medium |
| 05 | [[05-Python-Functions-Scope]] | def, return, *args/**kwargs, defaults, lambda, global/local/nonlocal, LEGB, closures, decorators basics | Medium |
| 06 | [[06-Python-Strings-Collections]] | String methods, slicing, immutability; list, tuple, set, dict — operations, when to use what | Medium |
| 07 | [[07-Python-OOP-Classes-Objects]] | class, __init__, self, instance vs class attrs, instance/class/static methods, __str__/__repr__, property | Medium |
| 08 | [[08-Python-Inheritance-Polymorphism]] | Single/multiple/multilevel inheritance, super(), MRO, diamond problem, duck typing, operator overloading, ABC | Medium |
| 09 | [[09-Python-Encapsulation-Special-Methods]] | Name mangling, property, dunder methods, context managers (__enter__/__exit__) | Medium |
| 10 | [[10-Python-Exception-Handling]] | try/except/else/finally, raise, custom exceptions, hierarchy, assert, EAFP vs LBYL, traceback | Medium |
| 11 | [[11-Python-File-IO-Serialization]] | open(), modes, with, CSV, JSON, pickle, pathlib | Medium |
| 12 | [[12-Python-Iterators-Generators]] | Iterator protocol, yield, generator expressions, itertools, lazy evaluation | Medium-Hard |
| 13 | [[13-Python-Modules-Packages]] | import, __name__, packages, pip, venv, requirements.txt | Medium |
| 14 | [[14-Python-Functional-Programming]] | map/filter/reduce, functools, operator module, pure functions, immutability patterns | Medium-Hard |
| 15 | [[15-Python-Concurrency-Async]] | Threading, multiprocessing, GIL, asyncio, concurrent.futures | Medium-Hard |
| 16 | [[16-Python-Advanced-Topics]] | Decorators deep, metaclasses, descriptors, __slots__, dataclasses, type hints, walrus, pattern matching | Advanced |
| 17 | [[17-Python-FAANG-Interview-Must-Know]] | Top patterns, complexity of ops, collections, heapq, bisect, gotchas | Advanced |
| — | [[notes]] | Memory model: objects, refcount, GC, id/is, interning, small int cache, mutability | All levels |

---

## Quick Revision Path

### For exams / oral tests (30 min revision):

```
01 → Quick Memory Card (history, Zen, REPL)
02 → Quick Memory Card (types, f-strings)
03 → Quick Memory Card (operators, indentation)
04 → Quick Memory Card (loops, comprehensions)
06 → Quick Memory Card (list/dict/set/tuple)
07 → Quick Memory Card (class, self, methods)
10 → Quick Memory Card (try/except/finally)
13 → Quick Memory Card (import, venv)
17 → Quick Memory Card (collections, heapq, gotchas)
notes → id(), is vs ==, mutability
```

### Interview Prep (2–3 hours):

```
02–04 → Syntax + control flow solid
05–06 → Functions + collections depth
07–09 → OOP + special methods
10–11 → Exceptions + I/O
12–14 → Iterators, modules, functional style
15 → Concurrency story (GIL, asyncio)
16 → Advanced Python features
17 → FAANG patterns + complexity
notes → Memory model questions
```

---

## Key Concepts — One Place

| Concept | Definition |
|---------|------------|
| Object | In Python every value is an object — type + identity + value |
| Dynamic typing | You don't have to declare a type on the variable; the type is decided at runtime |
| Indentation | The official way to define blocks — no braces |
| Iterator | `__iter__` + `__next__` — elements one by one |
| Generator | A function with `yield` — lazy, memory efficient |
| GIL | Global Interpreter Lock — in CPython one thread runs bytecode at a time |
| LEGB | Local → Enclosing → Global → Built-in — name lookup order |
| MRO | Method Resolution Order — with multiple inheritance, which class the method comes from |
| EAFP | Easier to Ask Forgiveness than Permission — try/except style |
| LBYL | Look Before You Leap — check first, then act |

---

## Important One-Liners (Python mindset)

| Quote | Topic |
|-------|-------|
| *"Readability counts"* | Zen of Python |
| *"Explicit is better than implicit"* | Style / imports |
| *"In the face of ambiguity, refuse the temptation to guess"* | Dynamic typing discipline |
| *"There should be one obvious way to do it"* | Pythonic code |
| *"Indentation is not optional"* | Syntax |
| *"Everything is an object"* | Data model |
| *"We are all consenting adults"* | Privacy by convention (`_`, `__`) |
| *"Batteries included"* | Standard library |

---

## Complete Topic Flow

```
Python
│
├── History & Basics ───────────────────────── [01]
│   ├── Guido, 1991, ABC inspiration
│   ├── Py2 vs Py3, interpreted model
│   └── Zen, REPL, first program
│
├── Variables, Types, I/O ────────────────── [02]
│
├── Operators & Control Flow ──────────────── [03]
│
├── Loops & Comprehensions ───────────────── [04]
│
├── Functions, Scope, Decorators intro ───── [05]
│
├── Strings & Collections ────────────────── [06]
│
├── OOP: Classes & Objects ────────────────── [07]
│
├── Inheritance & Polymorphism ───────────── [08]
│
├── Encapsulation & Dunder Methods ───────── [09]
│
├── Exception Handling ────────────────────── [10]
│
├── File I/O & Serialization ────────────── [11]
│
├── Iterators & Generators ──────────────── [12]
│
├── Modules & Packages ──────────────────── [13]
│
├── Functional Programming ──────────────── [14]
│
├── Concurrency & Async ─────────────────── [15]
│
├── Advanced Topics ─────────────────────── [16]
│
├── FAANG Interview Must-Know ───────────── [17]
│
└── Memory Model (extra deep notes) ─────── [[notes]]
```

---

*Total: 17 topic files + index + [[notes]] | Beginner to FAANG Ready*

*Next: [[01-Python-History-and-Basics]]*
