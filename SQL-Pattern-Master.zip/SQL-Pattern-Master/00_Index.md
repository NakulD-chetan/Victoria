# SQL Pattern Master — Index

> **15 patterns. Master these and you can solve any SQL interview problem or production query challenge. Each pattern has a Theory file (how it works) and a Problem List (drill problems).**

---

## Sample Schema (Used Across All Notes)

```sql
employees(id, name, dept, salary, hire_date, manager_id)
orders(id, customer_id, product_id, amount, order_date, status)
products(id, name, category, price)
customers(id, name, city, signup_date)
logins(user_id, login_date)
```

---

## Table of Contents

| #  | Pattern                        | DSA Analogy                     | Theory | Problems |
|----|--------------------------------|---------------------------------|--------|----------|
| 01 | Window Functions               | Sliding Window in arrays        | [Theory](01_Window-Functions/01_Theory.md) | [Problems](01_Window-Functions/02_Problem-List.md) |
| 02 | CTE / Recursive CTE           | Recursion / DFS in trees        | [Theory](02_CTE-Recursive-CTE/01_Theory.md) | [Problems](02_CTE-Recursive-CTE/02_Problem-List.md) |
| 03 | Self Join                      | Two-pointer on same array       | [Theory](03_Self-Join/01_Theory.md) | [Problems](03_Self-Join/02_Problem-List.md) |
| 04 | Aggregation + HAVING           | Frequency map (HashMap)         | [Theory](04_Aggregation-Having/01_Theory.md) | [Problems](04_Aggregation-Having/02_Problem-List.md) |
| 05 | Subquery / EXISTS              | Lookup / Set membership         | [Theory](05_Subquery-Exists/01_Theory.md) | [Problems](05_Subquery-Exists/02_Problem-List.md) |
| 06 | Pivot / CASE WHEN              | Array reshaping / transpose     | [Theory](06_Pivot-Case-When/01_Theory.md) | [Problems](06_Pivot-Case-When/02_Problem-List.md) |
| 07 | Running Total                  | Prefix Sum array                | [Theory](07_Running-Total/01_Theory.md) | [Problems](07_Running-Total/02_Problem-List.md) |
| 08 | Gaps and Islands               | Interval merge problem          | [Theory](08_Gaps-and-Islands/01_Theory.md) | [Problems](08_Gaps-and-Islands/02_Problem-List.md) |
| 09 | Top-N per Group                | Priority queue per bucket       | [Theory](09_Top-N-Per-Group/01_Theory.md) | [Problems](09_Top-N-Per-Group/02_Problem-List.md) |
| 10 | Set Operations                 | Set union / intersection        | [Theory](10_Set-Operations/01_Theory.md) | [Problems](10_Set-Operations/02_Problem-List.md) |
| 11 | Date Series Fill               | Sparse array with defaults      | [Theory](11_Date-Series-Fill/01_Theory.md) | [Problems](11_Date-Series-Fill/02_Problem-List.md) |
| 12 | Deduplication                  | HashSet for uniqueness          | [Theory](12_Deduplication/01_Theory.md) | [Problems](12_Deduplication/02_Problem-List.md) |
| 13 | LATERAL JOIN / CROSS APPLY     | Calling a function per row      | [Theory](13_Lateral-Join-Cross-Apply/01_Theory.md) | [Problems](13_Lateral-Join-Cross-Apply/02_Problem-List.md) |
| 14 | Merge / Upsert / SCD           | HashMap put-if-absent           | [Theory](14_Merge-Upsert-SCD/01_Theory.md) | [Problems](14_Merge-Upsert-SCD/02_Problem-List.md) |
| 15 | Query Optimization & Plans     | Algorithm complexity analysis   | [Theory](15_Query-Optimization-Execution-Plans/01_Theory.md) | [Problems](15_Query-Optimization-Execution-Plans/02_Problem-List.md) |

---

## DSA-to-SQL Analogy Map

```
DSA Concept                  SQL Pattern                    Why Similar
─────────────────────────    ───────────────────────────    ─────────────────────────────────────
Sliding Window               Window Functions               Both process a "frame" of rows around current position
Recursion / DFS              Recursive CTE                  Base case + recursive step; traverse hierarchies
Two-pointer (same array)     Self Join                      Compare rows from the same table using two references
HashMap / Frequency Map      GROUP BY + HAVING              Both bucket items by key and count/aggregate per bucket
Set Membership / Lookup      EXISTS / Subquery              Check if an element belongs to a computed set
Array Reshape / Transpose    CASE WHEN / PIVOT              Transform data layout from rows to columns
Prefix Sum                   Running Total (SUM OVER)       Cumulative computation over ordered sequence
Interval Merge               Gaps and Islands               Find consecutive groups / merge overlapping ranges
Priority Queue per Bucket    Top-N per Group                Select k-best from each partition
Set Union / Intersection     UNION / INTERSECT / EXCEPT     Combine or diff two result sets
Sparse Array Fill            Date Series + LEFT JOIN        Fill missing positions with default values
HashSet Dedup                DISTINCT / ROW_NUMBER = 1      Remove duplicates, keep one representative
Function call per element    LATERAL JOIN                   Evaluate a correlated expression for each row
HashMap put-if-absent        MERGE / UPSERT                 Conditional insert-or-update in one pass
Big-O Analysis               EXPLAIN ANALYZE                Analyze cost and choose optimal execution strategy
```

---

## Recommended Study Order

### Beginner (Start Here — Build Foundation)

```
04  Aggregation + HAVING       ← GROUP BY is the foundation of SQL analytics
05  Subquery / EXISTS          ← Filtering by related-table conditions
03  Self Join                  ← Comparing rows within same table
10  Set Operations             ← Combining and diffing result sets
12  Deduplication              ← Essential data cleaning skill
```

### Intermediate (Core FAANG Patterns)

```
01  Window Functions           ← ROW_NUMBER, RANK, LAG, LEAD — the big one
07  Running Total              ← Prefix sum with SUM() OVER()
02  CTE / Recursive CTE       ← Clean query structure + hierarchy traversal
06  Pivot / CASE WHEN          ← Rows-to-columns transformation
09  Top-N per Group            ← Combines window functions + filtering
```

### Advanced (Interview Differentiators)

```
08  Gaps and Islands           ← Hardest pure-SQL pattern
11  Date Series Fill           ← Generate series + fill missing data
13  LATERAL JOIN               ← Correlated subquery as a join
14  Merge / Upsert / SCD      ← Data engineering essential
15  Query Optimization         ← Go from "it works" to "it's fast"
```

---

## Pattern Dependency Graph

```
                        ┌─────────────────┐
                        │  04 Aggregation  │
                        │  + HAVING        │
                        └───────┬─────────┘
                                │
                 ┌──────────────┼──────────────┐
                 │              │              │
                 v              v              v
        ┌────────────┐  ┌─────────────┐  ┌──────────┐
        │ 05 Subquery │  │ 01 Window   │  │ 10 Set   │
        │ / EXISTS    │  │ Functions   │  │ Ops      │
        └──────┬─────┘  └──────┬──────┘  └──────────┘
               │               │
               v               ├──────────────┐
        ┌─────────────┐        │              │
        │ 03 Self Join │        v              v
        └─────────────┘  ┌──────────┐  ┌────────────┐
                         │ 07 Run   │  │ 09 Top-N   │
                         │ Total    │  │ Per Group  │
                         └──────┬───┘  └────────────┘
                                │
        ┌───────────────────────┼───────────────────────┐
        │                       │                       │
        v                       v                       v
  ┌───────────┐          ┌───────────┐          ┌──────────────┐
  │ 08 Gaps & │          │ 11 Date   │          │ 06 Pivot     │
  │ Islands   │          │ Series    │          │ CASE WHEN    │
  └───────────┘          └───────────┘          └──────────────┘

  Independent patterns (can learn anytime):
  ┌──────────┐  ┌──────────────┐  ┌────────────────┐
  │ 12 Dedup │  │ 13 LATERAL   │  │ 14 Merge/SCD   │
  └──────────┘  └──────────────┘  └────────────────┘

  Capstone (learn after all others):
  ┌──────────────────────────────┐
  │ 15 Query Optimization        │
  └──────────────────────────────┘
```

---

## Key Takeaway

> SQL patterns map directly to DSA patterns. If you can think in sliding windows, prefix sums, and hash maps, you already understand window functions, running totals, and GROUP BY. This course bridges that gap — learn the SQL syntax for the algorithms you already know.
