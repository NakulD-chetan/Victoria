# Fact Table and Dimension Table

> "Measure what happened; describe why it matters."

**Real-world analogy:** A printed receipt lists line amounts and quantities next to product names, store address, cashier, and time of day. The fact is the ink showing money and counts; the dimensions are the labels that tell you which store, which SKU, and which Tuesday afternoon produced those numbers.

---

## Core Idea (2 Lines)

A fact table holds numeric measurements at a declared grain so analysts can aggregate sales, costs, and counts consistently. Dimension tables hold descriptive context and hierarchical attributes that slice those measurements by store, product, time, promotion, and customer.

---

## Business Goal Drives Design

```
Business question
-----------------
"Which product categories grew margin in Q3 across our private-label program?"

Needed measurements (facts)
---------------------------
sales amount, cost amount, units

Needed context (dimensions)
---------------------------
time (quarter), product (category, private-label flag), store (format: hyper vs express)
```

| Design output | Tied to goal |
|---------------|--------------|
| Grain = one POS line per sale | Supports category and SKU rollups |
| `dim_product` includes margin attributes | Avoids repeating slowly changing descriptions on every line |
| `dim_date` aligns fiscal quarters | Matches finance calendar |

**Interview Tip:** Start answers with the business question, then state grain, then list dimensions and facts that serve it.

**Watch Out!** Modeling from source table shapes instead of questions yields mirror warehouses that are hard to query.

---

## Facts Are Measurements

Typical retail fact columns:

| Column type | Example | Role |
|-------------|---------|------|
| Degenerate dimension key | `pos_transaction_id` | Traceability to receipt |
| Foreign keys | `product_sk`, `store_sk`, `date_sk` | Join context |
| Additive measures | `sale_amount`, `quantity` | Summable across many dimensions |

```sql
-- Illustrative fact row shape
CREATE TABLE retail_core.fact_pos_sale_line (
  pos_transaction_id STRING,
  product_sk INT64,
  store_sk INT64,
  date_sk INT64,
  sale_amount NUMERIC,
  quantity INT64
);
```

---

## Dimensions Are Context

Dimensions answer who, what, when, where, why, and how for each fact row.

| Dimension | Retail attributes |
|-----------|-------------------|
| `dim_product` | `brand`, `category`, `size`, `is_private_label` |
| `dim_store` | `region`, `banner`, `square_meters`, `timezone` |
| `dim_date` | `fiscal_year`, `week`, `is_holiday` |
| `dim_promotion` | `promo_type`, `flyer_page`, `discount_depth` |

**Watch Out!** Putting long free-text descriptions on the fact row duplicates storage and complicates slowly changing updates.

---

## Receipt-to-Fact Mapping Example

```
Paper receipt                    Modeled row(s)
-------------                    --------------
Store: Westside Market #104  -> store_sk points to dim_store row for #104
SKU: Organic Milk 1L         -> product_sk points to dim_product for that SKU
Qty: 2, Price each: 3.49     -> quantity = 2, sale_amount derived from extensions
Time: 17:42                    -> date_sk (+ optional time-of-day dimension)
Cashier: Lane 4               -> optional cashier dimension or degenerate key
```

```sql
-- One fact line per receipt line (grain)
SELECT
  r.transaction_id,
  p.product_sk,
  s.store_sk,
  d.date_sk,
  r.quantity,
  r.extended_amount AS sale_amount
FROM retail_staging.receipt_line r
JOIN retail_core.dim_product p ON r.sku = p.sku_natural_key
JOIN retail_core.dim_store s ON r.store_code = s.store_code
JOIN retail_core.dim_date d ON r.sale_date = d.calendar_date;
```

**Interview Tip:** Practice explaining grain in one sentence: "One row equals one sale line on one receipt at one store on one day."

---

## Naming Conventions

| Object | Suggested suffix | Example |
|--------|------------------|---------|
| Fact | `_fact_table` or `fact_` prefix | `fact_pos_sale_line` |
| Dimension | `_dim_table` or `dim_` prefix | `dim_product` |

Consistency beats cleverness: data engineers, analysts, and row-level security policies all search by naming patterns.

**Watch Out!** Mixing `f_` and `fact_` and `facts_` in one warehouse confuses metadata scanners.

---

## Primary and Foreign Keys

```
dim_product                fact_pos_sale_line
-----------                ------------------
product_sk (PK)   <-----   product_sk (FK)
sku_natural_key            store_sk (FK) ---> dim_store.store_sk (PK)
                           date_sk (FK) ---> dim_date.date_sk (PK)
```

| Key type | Fact table | Dimension table |
|----------|------------|-----------------|
| Primary key | Often composite or degenerate plus line number surrogate | Surrogate `*_sk` |
| Natural key | Preserved as degenerate or in staging only | `sku`, `store_code` for lookup |

**Interview Tip:** Surrogate keys isolate the warehouse from operational rekeys and support SCD Type 2.

---

## Product Dimension Example

```sql
CREATE TABLE retail_core.dim_product (
  product_sk INT64,
  sku STRING,
  product_name STRING,
  brand STRING,
  category STRING,
  is_private_label BOOL,
  effective_start_date DATE,
  effective_end_date DATE,
  is_current BOOL
);
```

| Attribute change | Modeling impact |
|------------------|-----------------|
| Rename for marketing | May be SCD1 overwrite |
| Category regrouping for reporting | Often SCD2 new row with new `product_sk` |

**Watch Out!** Reusing one `product_sk` after a category change breaks historical reports; SCD2 preserves truth-at-time.

---

## Multiple Dimensions for One Fact

```
                    +-------------+
                    | dim_date    |
                    +------+------+
                           |
                           v
+----------------+   +-----+------+   +----------------+
| dim_promotion  |-->| fact_sales |<--| dim_product    |
+----------------+   +-----+------+   +----------------+
                           ^
                           |
                    +------+------+
                    | dim_store   |
                    +-------------+
```

One sale line can reference many dimensions simultaneously; each FK is an independent axis for filtering and grouping.

**Interview Tip:** Contrast with normalized operational models where many joins are required to reach readable attributes.

---

## "200 Alone Means Nothing"

The number 200 could be dollars, cents, units, loyalty points, or a temperature reading. Without dimensions, it is not actionable.

| Value | With dimensions | Business meaning |
|-------|-----------------|------------------|
| 200 | nothing | ambiguous |
| 200 | `sale_amount`, `USD`, `dim_store=Airport Express`, `dim_product=Bottled water` | plausible basket insight |
| 200 | `quantity`, `dim_product=Paper towels case` | inventory movement story |

**Watch Out!** Dashboards that show KPI tiles without filter context invite misinterpretation during seasonal spikes.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Storing descriptions only on facts | Inconsistent labels and huge storage | Normalize descriptions to dimensions |
| Missing date dimension | Weekday seasonality hidden | Use `dim_date` instead of raw timestamps in facts |
| Grain drift across reloads | Metrics not comparable quarter to quarter | Document grain in model metadata and tests |
| Surrogate collisions across systems | Wrong joins | Namespace natural keys or use hub-and-spoke integration keys |
| Too many degenerate dimensions | Wide unreadable facts | Group operational keys into junk dimensions when appropriate |

---

## Key Takeaway

> Facts carry the numbers that aggregate; dimensions carry the language that explains them; together they turn isolated measurements into retail decisions you can defend in a finance review.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Fact = measurements + foreign keys at a declared grain.          |
| Dimension = descriptive context and hierarchies for slicing.   |
| Business question first, then grain, then dims and facts.        |
| Surrogate keys protect history; natural keys land in dimensions. |
| A measure without dimensions is not yet a business fact.        |
+------------------------------------------------------------------+
```
