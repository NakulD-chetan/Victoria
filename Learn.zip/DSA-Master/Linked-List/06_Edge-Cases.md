# Linked List — Edge Cases

> **Permanent Recall:** Empty list, single node, two nodes, cycle at different positions, even/odd length, head changes. Test these before submitting. FAANG interviews always include at least one edge case test.

---

## Reversal Problems

### 1. Empty List

```python
head = None
# Expected: None
# Don't assume head is non-null
```

### 2. Single Node

```python
head = ListNode(1)  # 1 → null
# Reverse: 1 → null (unchanged)
# Many solutions break if they assume at least 2 nodes
```

### 3. Two Nodes

```python
head = ListNode(1, ListNode(2))  # 1 → 2 → null
# Reverse: 2 → 1 → null
# Minimum case where reversal actually changes something
```

### 4. Reverse Sublist at Head

```python
# Reverse between positions 1 and 3:
# 1 → 2 → 3 → 4 → 5  →  3 → 2 → 1 → 4 → 5
# Head changes! Need dummy head.
```

### 5. Reverse Sublist at Tail

```python
# Reverse between positions 3 and 5:
# 1 → 2 → 3 → 4 → 5  →  1 → 2 → 5 → 4 → 3 → null
# Last node changes. Ensure proper null termination.
```

---

## Fast & Slow Pointer Problems

### 1. Even vs Odd Length (Middle)

```python
# Odd: 1 → 2 → 3 → 4 → 5
# Middle = 3 (exact middle)

# Even: 1 → 2 → 3 → 4
# Middle = 3 (second of two middles with standard while fast and fast.next)
# Some problems want 2 (first middle) — adjust: while fast.next and fast.next.next
```

### 2. Single Node (Middle)

```python
head = ListNode(1)
# Middle = 1 (itself)
# Fast/slow loop body never executes
```

### 3. Two Nodes (Middle)

```python
head = ListNode(1, ListNode(2))
# Standard: middle = 2 (slow moves once)
# If need first middle: middle = 1
```

---

## Cycle Detection

### 1. No Cycle

```python
head = ListNode(1, ListNode(2, ListNode(3)))
# Fast reaches null → no cycle
```

### 2. Cycle at Head (Self-Loop)

```python
node = ListNode(1)
node.next = node  # 1 → 1 → 1 → ...
# Fast and slow both stuck on node 1
# They meet immediately at second iteration
```

### 3. Cycle at Tail

```python
# 1 → 2 → 3 → 4 → 2 (back to node 2)
# Cycle entry = node 2
```

### 4. Single Node Self-Loop

```python
node = ListNode(1)
node.next = node
# has_cycle should return True
# cycle_start should return node itself
```

### 5. Single Node No Cycle

```python
node = ListNode(1)  # next = null
# has_cycle should return False
```

---

## Merge Problems

### 1. One Empty List

```python
l1 = ListNode(1, ListNode(3))
l2 = None
# Result: l1 itself
```

### 2. Both Empty

```python
l1 = None
l2 = None
# Result: None
```

### 3. Unequal Lengths

```python
l1 = ListNode(1)                          # length 1
l2 = ListNode(2, ListNode(3, ListNode(4)))  # length 3
# Must attach remaining after shorter exhausted
```

### 4. Duplicate Values

```python
l1: 1 → 1 → 1
l2: 1 → 1 → 1
# Result: 1 → 1 → 1 → 1 → 1 → 1
# <= comparison maintains stability
```

### 5. Already Merged

```python
l1: 1 → 2 → 3
l2: 4 → 5 → 6
# All of l1 comes first, then all of l2
```

---

## Remove Nth From End

### 1. Remove the Only Node

```python
head = ListNode(1)  # n = 1
# Result: None
# Without dummy: head becomes null (special case)
```

### 2. Remove Head (Nth = Length)

```python
# 1 → 2 → 3, n = 3
# Remove 1, result: 2 → 3
# Head changes!
```

### 3. Remove Tail (N = 1)

```python
# 1 → 2 → 3, n = 1
# Remove 3, result: 1 → 2 → null
```

### 4. N Equals Length

```python
# Same as remove head — test this explicitly
```

---

## Palindrome Check

### 1. Single Character

```python
head = ListNode(1)  # Palindrome = True
```

### 2. Two Same

```python
# 1 → 1  →  True
```

### 3. Two Different

```python
# 1 → 2  →  False
```

### 4. Odd Length Palindrome

```python
# 1 → 2 → 1  →  True
# Middle element doesn't need comparison
```

### 5. Even Length Palindrome

```python
# 1 → 2 → 2 → 1  →  True
```

---

## Intersection of Two Lists

### 1. No Intersection

```python
# A: 1 → 2 → 3
# B: 4 → 5 → 6
# Result: None
```

### 2. Intersect at Head

```python
# Both lists start at same node
# Result: head itself
```

### 3. Intersect at Tail

```python
# A: 1 → 2 → 3
# B: 4 → 3       (share only last node)
# Result: node 3
```

---

## Large Input Considerations

| Problem | Constraint | Consideration |
|---------|------------|---------------|
| Reverse | n = 10^5 | O(n) fine, iterative preferred |
| Cycle detection | n = 10^5 | O(n) time, O(1) space |
| Merge K | k lists, N total | O(N log k) with D&C or heap |
| Sort linked list | n = 10^5 | Merge sort O(n log n) |

### Stack Overflow (Recursive)

```python
# Python default recursion limit: 1000
# For n = 10^5, recursive reverse will crash
# Always prefer iterative for linked list
```

---

## Edge Case Checklist

| Category | Test Cases |
|----------|------------|
| **Empty** | head = None |
| **Single** | head = ListNode(1) |
| **Two nodes** | 1 → 2 |
| **Head changes** | Remove head, reverse, reverse sublist at pos 1 |
| **Cycle** | No cycle, self-loop, cycle at middle, cycle at tail |
| **Even/Odd** | Middle differs, palindrome differs |
| **All same values** | 1 → 1 → 1 → 1 |
| **Sorted** | Already sorted for merge |

---

## ASCII: Critical Edge Cases Visualized

```
Empty:        head → null

Single:       head → [1] → null

Self-loop:    head → [1] ─┐
                     ↑     │
                     └─────┘

Even middle:  [1] → [2] → [3] → [4]
                          ↑
                        middle? (2 or 3 depending on variant)

Head removal: [X] → [2] → [3]  →  head = [2] → [3]
              ↑ remove this

Palindrome:   [1] → [2] → [2] → [1]
              ↑──── compare ────↑
                    ↑─ compare ─↑
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY: head=None, return None or 0
SINGLE: head.next=None, often unchanged
TWO NODES: minimum meaningful case, test always
HEAD CHANGES: dummy head prevents issues
CYCLE: no cycle, self-loop, mid-cycle, tail-cycle
EVEN/ODD: middle node differs, palindrome logic differs
LARGE: iterative > recursive (stack overflow)
ALL SAME: 1→1→1, test stability and correctness
```
