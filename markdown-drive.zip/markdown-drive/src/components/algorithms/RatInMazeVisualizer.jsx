import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const MAZE = [
  [0, 1, 0, 0, 0],
  [0, 1, 0, 1, 0],
  [0, 0, 0, 1, 0],
  [1, 1, 0, 0, 0],
  [0, 0, 0, 1, 0],
];
const R = MAZE.length;
const C = MAZE[0].length;

function generateSteps() {
  const steps = [];
  const vis = Array.from({ length: R }, () => Array(C).fill(0));
  const pathStack = [];

  function keyBoard() {
    return MAZE.map((row, i) =>
      row.map((cell, j) => {
        if (cell === 1) return 'wall';
        if (vis[i][j]) return 'placed';
        return 'empty';
      }),
    );
  }

  function dfs(r, c) {
    if (r < 0 || r >= R || c < 0 || c >= C || MAZE[r][c] === 1 || vis[r][c]) {
      if (r >= 0 && r < R && c >= 0 && c < C && MAZE[r][c] === 1)
        steps.push({ type: 'wall', r, c, board: keyBoard(), path: [...pathStack] });
      return false;
    }
    vis[r][c] = 1;
    pathStack.push([r, c]);
    steps.push({ type: 'visit', r, c, board: keyBoard(), path: [...pathStack] });
    if (r === R - 1 && c === C - 1) {
      steps.push({ type: 'done', msg: 'Reached destination', board: keyBoard(), path: [...pathStack] });
      return true;
    }
    const dirs = [
      [0, 1],
      [1, 0],
      [0, -1],
      [-1, 0],
    ];
    for (const [dr, dc] of dirs) {
      if (dfs(r + dr, c + dc)) return true;
    }
    vis[r][c] = 0;
    pathStack.pop();
    steps.push({ type: 'back', r, c, board: keyBoard(), path: [...pathStack] });
    return false;
  }

  steps.push({ type: 'start', msg: 'Rat in maze — DFS', board: keyBoard(), path: [] });
  dfs(0, 0);
  return steps;
}

function paint(step) {
  const cellColors = {};
  const cellValues = {};
  const grid = step.board || [];
  for (let r = 0; r < R; r++) {
    for (let c = 0; c < C; c++) {
      const key = `${r}-${c}`;
      const g = grid[r]?.[c];
      cellColors[key] = g === 'wall' ? 'wall' : g === 'placed' ? 'placed' : 'empty';
      cellValues[key] = MAZE[r][c] === 1 ? '█' : '';
    }
  }
  return {
    size: R,
    cols: C,
    grid,
    cellColors,
    cellValues,
    path: step.path || [],
  };
}

export default function RatInMazeVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Maze: 0 open, 1 wall' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'back') canvasRef.current?.addAnim('backtrack', { r: step.r, c: step.c }, 300);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
