# Prefix Sum — Interview Thinking

> **How to present the prefix sum approach in a FAANG interview.** Communication framework, explaining the hash map optimization, and going from O(n²) to O(n).

---

## How to Present the Prefix Sum Approach

### Step 1: State the Brute Force (5 sec)
> "The naive approach is to try every subarray [i, j] and compute the sum. That's O(n²) for counting or O(n) per range query."

### Step 2: Introduce Prefix Sum (15 sec)
> "We can optimize by precomputing prefix sums. prefix[i] is the sum of elements from 0 to i-1. Then the sum of any range [i, j] is prefix[j+1] minus prefix[i] — O(1) per query."

### Step 3: Draw the Formula
```
sum(arr[i..j]) = prefix[j+1] - prefix[i]
```
> "It's like an odometer: the distance between two points is the difference of their readings."

### Step 4: Handle the Variant
- **Range queries only:** "We build prefix once in O(n), then each query is O(1)."
- **Count subarrays sum=K:** "We need to count pairs (i,j) where prefix[j]-prefix[i]=K. That's prefix[j]=prefix[i]+K. As we scan j, we use a hash map to count how many previous prefix values equal prefix[j]-K."

---

## Explaining the Hash Map Optimization

### The Transformation
```
Goal: Count (i, j) where sum(arr[i..j]) = K
      = Count (i, j) where prefix[j+1] - prefix[i] = K
      = Count (i, j) where prefix[j+1] = prefix[i] + K
```

### The Key Insight
> "For each position j, we've seen prefix values at positions 0..j. We want to count how many of those equal prefix[j+1] - K. A hash map lets us do that lookup in O(1)."

### Why {0: 1}?
> "We initialize the map with {0: 1} because the empty prefix (before any element) has value 0. A subarray starting at index 0 has sum = prefix[1] - prefix[0]. So we need to count prefix[0]=0 as a valid 'previous' prefix."

---

## O(n²) → O(n) Communication

| Stage | What to Say |
|-------|-------------|
| Brute force | "For each start i, for each end j ≥ i, compute sum. O(n²) total." |
| Prefix insight | "If we have prefix sums, sum(i,j) = prefix[j+1]-prefix[i]. But we still have O(n²) pairs to check." |
| Hash map | "We can avoid nested loops. As we compute prefix from left to right, for each prefix value we ask: how many previous prefixes equal current - K? The map stores those counts." |
| Result | "Single pass: O(n) time, O(n) space for the map." |

---

## Communication Framework

```
┌─────────────────────────────────────────────────────────────┐
│ 1. CLARIFY: "Can the array have negatives? Empty array?"    │
│ 2. BRUTE:   "Naive: try all O(n²) subarrays"               │
│ 3. PREFIX:  "Prefix sum gives O(1) range sum"               │
│ 4. OPTIMIZE: "For count, hash map gives O(n) single pass"   │
│ 5. CODE:    Build prefix → iterate with map                 │
│ 6. EDGE:    "Handle prefix[0]=0, empty array"               │
└─────────────────────────────────────────────────────────────┘
```

---

## Interview Phrases That Impress

- **"We're trading O(n) space for O(1) query time."**
- **"The hash map turns a two-pointer search into a constant-time lookup."**
- **"Prefix[j] - prefix[i] = K means we're looking for prefix[i] = prefix[j] - K in what we've seen so far."**
- **"For 2D, we use inclusion-exclusion to avoid double-counting the corner."**

---

## When to Mention Alternatives

| If interviewer asks... | Say... |
|------------------------|--------|
| "What if we have updates?" | "Prefix sum is static. For dynamic updates, we'd use a Fenwick tree or segment tree." |
| "What about space?" | "O(n) for prefix array. For count-only we can avoid storing the full prefix — just running sum + map." |
| "Negative numbers?" | "Prefix sum works fine. The map stores all prefix values. For 'shortest subarray ≥ K' with negatives, we need a monotonic deque." |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PRESENT ORDER:    Brute → Prefix → Hash (if count)
HASH EXPLAIN:     prefix[j]-prefix[i]=K ⇒ lookup prefix[j]-K in map
MAP INIT:         "Empty prefix = 0, so we need {0:1}"
O(n²)→O(n):       "Single pass, map stores prefix counts"
PHRASE:           "Trading space for constant-time lookup"
```
