# Database Design — Edge Cases (Deep Understanding)

> **Permanent Recall:** Database edge cases to watch: deadlocks (circular lock waits), replication lag (stale reads after writes), hot partitions (uneven shard distribution), connection pool exhaustion, cascading deletes, integer overflow on IDs, timezone corruption, split-brain in failover, thundering herd on cache miss, and write amplification from over-indexing. Each has specific triggers and mitigations. Knowing these shows senior-level thinking.

---

## Why Edge Cases Matter

Edge cases are **rare situations that cause disproportionate damage**. In interviews, knowing database edge cases shows senior-level production awareness. In real systems, not handling them causes data corruption, outages, and lost revenue.

---

## Edge Case 1: Deadlocks

### What Happens

Two transactions wait for each other — T1 holds lock A and wants lock B; T2 holds lock B and wants lock A. Neither can proceed. Circular wait = deadlock.

### Step-by-Step How It Goes Wrong

```
SCENARIO: E-commerce. Two users buy the last units of two products simultaneously.

Transaction T1 (User A buys Product 1 and Product 2):
  10:00:00.000  LOCK rows: Product 1 (stock: 1)
  10:00:00.001  UPDATE products SET stock = 0 WHERE id = 1;  ← locked Product 1
  10:00:00.002  Now wants to lock Product 2...
                But T2 already holds Product 2's lock!  ← WAITING

Transaction T2 (User B buys Product 2 and Product 1):
  10:00:00.000  LOCK rows: Product 2 (stock: 1)
  10:00:00.001  UPDATE products SET stock = 0 WHERE id = 2;  ← locked Product 2
  10:00:00.002  Now wants to lock Product 1...
                But T1 already holds Product 1's lock!  ← WAITING

DEADLOCK:
  T1 waits for T2 to release Product 2
  T2 waits for T1 to release Product 1
  Neither can proceed. Circular wait.

DATABASE DETECTS (after ~1 second):
  PostgreSQL picks one transaction as "victim" → ROLLS IT BACK
  ERROR: "deadlock detected"
  The other transaction proceeds.
  
  But: User A sees "Error: please try again." UX is degraded.
```

### Why This Is Dangerous

```
1. Frequent deadlocks → high retry rate → degraded performance
2. Retries increase load → more deadlocks → vicious cycle
3. Some ORMs don't handle "deadlock detected" → unhandled exception → 500 error
4. Long-running transactions increase deadlock window
```

### Mitigations

| Fix | How It Helps | Example |
|-----|-------------|---------|
| **Lock in consistent order** | If both T1 and T2 lock Product 1 first, then Product 2, no circular wait | Always lock by ascending product_id |
| **Keep transactions SHORT** | Shorter transactions hold locks for less time → smaller deadlock window | Don't do HTTP calls inside a transaction |
| **Use `SELECT ... FOR UPDATE SKIP LOCKED`** | Skip rows that are already locked instead of waiting | Queue-like patterns (workers grab available tasks) |
| **Retry with exponential backoff** | On deadlock error, wait random time, retry | `try { ... } catch (DeadlockException) { sleep(random); retry; }` |
| **Use optimistic concurrency** | Don't lock at all; detect conflicts at COMMIT time | Add `version` column; UPDATE WHERE version = expected |

> **Interview Answer:** *"Deadlocks happen when transactions lock resources in different orders. The fix is to always lock in a consistent order — like ascending ID. We also keep transactions as short as possible and handle deadlock errors with retries."*

---

## Edge Case 2: Replication Lag (Read-After-Write Inconsistency)

### What Happens

User writes data to the primary, then immediately reads — but the read hits a replica that hasn't received the write yet. User sees stale data.

### Step-by-Step How It Goes Wrong

```
SCENARIO: User updates their profile name from "Alice" to "Alice2"

10:00:00.000  App → PRIMARY: UPDATE users SET name = 'Alice2' WHERE id = 123;
10:00:00.001  PRIMARY confirms COMMIT. Primary has: name = 'Alice2'
10:00:00.002  Primary streams WAL to Replica (async)

10:00:00.003  User refreshes profile page
10:00:00.003  App → REPLICA: SELECT name FROM users WHERE id = 123;

10:00:00.003  Replica hasn't received the WAL yet (200ms replication lag)
              Replica returns: name = 'Alice'  ← STALE!

User sees: "Alice" (the old name)
User thinks: "My update didn't save!" → refreshes again → now sees "Alice2"
User is confused and frustrated.
```

### Why This Is Dangerous

```
Low-impact examples:
  - Profile name shows old value for 200ms → annoying but tolerable
  - Like count shows 99 instead of 100 → nobody notices

HIGH-IMPACT examples:
  - User deposits $1000 → checks balance → still shows old amount → PANICS
  - Admin creates a new product → searches for it → not found → creates DUPLICATE
  - User changes password → login uses old password hash → "wrong password" error
```

### Mitigations

| Fix | How It Works | When to Use |
|-----|-------------|-------------|
| **Read from primary after write** | For the specific data just written, read from primary instead of replica | Immediately after any user-initiated write (profile update, password change) |
| **Causal consistency token** | Write returns a WAL position; read waits until replica reaches that position | When you need guaranteed read-after-write without always hitting primary |
| **Session-level read routing** | After a write, route ALL reads for that session to primary for N seconds | When the user might read related data that should reflect the write |
| **Synchronous replication** | Replica must confirm before primary returns COMMIT | When data is critical (payments); trades write speed for consistency |
| **Accept the lag** | Show "saving..." UI for 1-2 seconds, then refresh | When eventual consistency is tolerable (social media likes, views) |

```
IMPLEMENTATION: Read-after-write consistency

def update_profile(user_id, new_name):
    primary_db.execute("UPDATE users SET name = ? WHERE id = ?", new_name, user_id)
    
    # For THIS specific user, read from primary for next 5 seconds
    cache.set(f"read_primary:{user_id}", True, ttl=5)

def get_profile(user_id):
    if cache.get(f"read_primary:{user_id}"):
        return primary_db.query("SELECT * FROM users WHERE id = ?", user_id)
    else:
        return replica_db.query("SELECT * FROM users WHERE id = ?", user_id)
```

---

## Edge Case 3: Hot Partition / Hot Shard

### What Happens

In a sharded database, one shard receives disproportionately more traffic than others. That shard is overloaded while others sit idle.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Social media app, sharded by user_id. Celebrity user has 100M followers.

Shard distribution:
  Shard 1: user_id 1-25M  (includes celebrity user_id = 500)
  Shard 2: user_id 25M-50M
  Shard 3: user_id 50M-75M
  Shard 4: user_id 75M-100M

Celebrity posts a photo → 100M followers load their feed
  Feed query: SELECT posts WHERE author_id = 500
  hash(500) → Shard 1

  Shard 1: 100M reads in 60 seconds = 1.67M reads/sec 🔥🔥🔥
  Shard 2: 10K reads/sec (normal users)
  Shard 3: 10K reads/sec (normal users)
  Shard 4: 10K reads/sec (normal users)

Shard 1 is 167× more loaded than other shards → crashes
→ 25% of users can't access the app
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Cache hot data** | Celebrity's posts cached in Redis → reads don't hit the shard at all |
| **Read replicas per shard** | Shard 1 has 5 read replicas vs 1 for other shards |
| **Scatter reads** | Replicate celebrity data to ALL shards; reads can go to any shard |
| **Hash-based sharding** | Instead of range-based (1-25M), use hash(user_id) % 4 → more even distribution |
| **Detect and handle hot keys** | Monitor per-key access patterns; automatically replicate hot keys |

---

## Edge Case 4: Connection Pool Exhaustion

### What Happens

All connections in the pool are busy. New requests wait in queue, then timeout. Users see "connection timeout" errors.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Normal day, pool size = 20.

10:00:00  15 connections in use, 5 idle. Everything fine.

10:00:01  Slow query starts running (no index, full table scan → 30 seconds)
          This query holds a connection for 30 seconds.

10:00:02  19 slow queries running → 19 connections busy, 1 idle.

10:00:03  100 new requests arrive (traffic spike).
          20 connections ALL busy with slow queries.
          Request 21: waits in queue for a connection...
          Request 22: waits in queue...
          ...
          Request 100: waits in queue...

10:00:33  Connection timeout (30 seconds). Requests 21-100 all fail.
          Users see: "Error 503: Service Unavailable"

ENTIRE SERVICE DOWN because one slow query monopolized the pool.
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Statement timeout** | Kill queries running longer than 5 seconds: `SET statement_timeout = '5s'` |
| **Separate pools for fast/slow queries** | Pool A (15 connections) for normal queries. Pool B (5 connections) for reports/exports. Slow queries can't starve fast ones. |
| **pgBouncer** | Pool 1000 app connections into 20 real DB connections. Queues overflow gracefully. |
| **Circuit breaker** | If pool is full, immediately return error (fail-fast) instead of queuing. Prevents cascade. |
| **Monitor pool utilization** | Alert when pool usage > 80%. Fix before it hits 100%. |

```
SEPARATE POOLS:

Fast queries pool (15 connections):
  GET /api/users/123        → 2ms query → connection returned quickly
  GET /api/orders?user=123  → 5ms query → connection returned quickly

Slow queries pool (5 connections):
  GET /api/reports/monthly  → 30 second query → only uses slow pool
  POST /api/exports/csv     → 60 second query → only uses slow pool

Slow queries can NEVER block fast queries. Users browsing the site are unaffected.
```

---

## Edge Case 5: Cascading Deletes — Unintended Mass Deletion

### What Happens

`ON DELETE CASCADE` on a foreign key means deleting a parent row automatically deletes ALL child rows. One DELETE can wipe thousands of records.

### Step-by-Step How It Goes Wrong

```
Schema:
  users (id, name, email)
  orders (id, user_id REFERENCES users(id) ON DELETE CASCADE)
  order_items (id, order_id REFERENCES orders(id) ON DELETE CASCADE)
  reviews (id, user_id REFERENCES users(id) ON DELETE CASCADE)
  comments (id, user_id REFERENCES users(id) ON DELETE CASCADE)

Admin wants to deactivate User 42 (a spammy account):
  DELETE FROM users WHERE id = 42;

CASCADE chain:
  → DELETE FROM orders WHERE user_id = 42;          (500 orders deleted)
    → DELETE FROM order_items WHERE order_id IN (...); (2000 items deleted)
  → DELETE FROM reviews WHERE user_id = 42;           (150 reviews deleted)
  → DELETE FROM comments WHERE user_id = 42;          (800 comments deleted)

ONE DELETE statement → 3451 rows deleted across 4 tables.

If this was accidental (wrong user_id) or the business actually wanted to keep order history?
DATA GONE. No undo.
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Use ON DELETE RESTRICT** | DELETE fails if child rows exist. Must delete children explicitly. Safe. |
| **Use ON DELETE SET NULL** | Child rows remain but user_id becomes NULL. Data preserved. |
| **Soft delete** | Don't DELETE. Set `is_deleted = true` and `deleted_at = NOW()`. Recoverable. |
| **Foreign key without CASCADE** | No cascade. App code handles child cleanup explicitly (with logging). |
| **Audit trail** | Log all deletes. Even if cascaded, you can see what was deleted. |

```sql
-- SAFER APPROACH: Soft delete
ALTER TABLE users ADD COLUMN is_deleted BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN deleted_at TIMESTAMPTZ;

-- "Delete" a user:
UPDATE users SET is_deleted = TRUE, deleted_at = NOW() WHERE id = 42;

-- All queries exclude soft-deleted users:
SELECT * FROM users WHERE is_deleted = FALSE;

-- Need to actually purge? Run batch job after 30-day grace period:
DELETE FROM users WHERE is_deleted = TRUE AND deleted_at < NOW() - INTERVAL '30 days';
```

---

## Edge Case 6: Thundering Herd on Cache Miss

### What Happens

A popular cache key expires. Hundreds of concurrent requests all experience a cache miss at the same time, all query the database simultaneously, overwhelming it.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Homepage shows "trending products" → cached in Redis with 5-minute TTL.

10:00:00  Cache key "trending_products" is set. TTL: 300 seconds.
          100 requests/sec → all served from Redis cache. DB is idle.

10:05:00  Cache key EXPIRES.

10:05:00.001  Request 1: GET trending_products from Redis → MISS
              → Query DB: SELECT * FROM products ORDER BY views DESC LIMIT 50
10:05:00.002  Request 2: GET trending_products from Redis → MISS
              → Query DB: same expensive query
10:05:00.003  Request 3: same
...
10:05:00.100  Request 100: same

100 IDENTICAL expensive queries hit the database SIMULTANEOUSLY.
Database CPU spikes to 100%.
Other queries start timing out.
If the trending query takes 500ms, the DB handles 100 of them for 500ms.
Meanwhile, normal user queries (login, checkout) are BLOCKED.

CASCADING FAILURE:
  Other queries timeout → users see errors → retries → even more load → DB crashes
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Cache lock (single-flight)** | First request to find a miss acquires a lock. Other requests wait for the lock (1-2 seconds). Only ONE query goes to DB. All others get the cached result. |
| **Stagger TTLs** | Instead of TTL = 300s, use TTL = 300 ± random(0, 60). Keys expire at different times → no stampede. |
| **Background refresh** | Before TTL expires, a background job refreshes the cache. Key never actually expires. |
| **Circuit breaker on DB** | If DB load > threshold, return stale cached data instead of querying |

```python
# CACHE LOCK PATTERN (single-flight)
def get_trending_products():
    result = redis.get("trending_products")
    if result:
        return result  # Cache HIT
    
    # Cache MISS — try to acquire lock
    lock_acquired = redis.set("lock:trending", "1", nx=True, ex=5)  # 5s lock
    
    if lock_acquired:
        # I'm the one query that runs
        result = db.query("SELECT * FROM products ORDER BY views DESC LIMIT 50")
        redis.set("trending_products", result, ex=300)
        redis.delete("lock:trending")
        return result
    else:
        # Someone else is querying — wait for them
        time.sleep(0.5)
        return redis.get("trending_products")  # Should be populated now
```

---

## Edge Case 7: Split-Brain in Database Failover

### What Happens

During a failover, BOTH the old primary and the new primary think they're the primary. Both accept writes. Data diverges — when reconciled, data conflicts or is lost.

### Step-by-Step How It Goes Wrong

```
NORMAL STATE:
  Primary (Node A): Accepts all writes
  Replica (Node B): Receives WAL stream, read-only

NETWORK PARTITION:
  Node A can't reach Node B (network issue between them)
  
  Node A: "I'm still the primary. I'll keep accepting writes."
  Node B: "I can't reach Node A. Node A must be dead. I'll PROMOTE myself!"

SPLIT-BRAIN:
  Node A (thinks it's primary): Accepts write W1
  Node B (also thinks it's primary): Accepts write W2
  
  App server 1 → Node A → writes order #1000
  App server 2 → Node B → writes order #1000 (different data!)
  
  Network heals:
  Node A has: order #1000 = {user: Alice, amount: $100}
  Node B has: order #1000 = {user: Bob, amount: $200}
  
  WHICH ONE IS CORRECT? Both? Neither?
  Data is INCONSISTENT. Manual reconciliation needed.
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Quorum-based failover** | Need majority agreement (3 nodes: 2 must agree) before promoting. Single node can't self-promote. |
| **Fencing (STONITH)** | When new primary is promoted, it KILLS the old primary via hardware management interface. Only one can be alive. |
| **Lease-based primary** | Primary holds a "lease" that expires every 10s. Must renew to stay primary. If it can't renew (network issue), it stops accepting writes. |
| **Managed database** | AWS RDS, Cloud SQL handle failover automatically with tested logic. |
| **Witness/arbiter node** | Third node that doesn't hold data but votes on who is primary. Breaks ties. |

---

## Edge Case 8: Integer Overflow on Auto-Increment IDs

### What Happens

INT (4 bytes) has max value 2,147,483,647 (~2.1 billion). High-volume tables can exhaust this.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Event logging table. 10K events/second.

CREATE TABLE events (
    id SERIAL PRIMARY KEY,   -- SERIAL = 4-byte INT
    event_type VARCHAR(50),
    data JSONB,
    created_at TIMESTAMPTZ
);

10K events/sec × 86,400 seconds/day = 864M events/day
2,147,483,647 / 864,000,000 = 2.48 days

After 2.5 DAYS, the auto-increment hits INT max.

Next INSERT:
  ERROR: integer out of range
  
  ALL event logging STOPS. No new events can be recorded.
  If the app doesn't handle this error → 500 errors → outage.
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Use BIGINT from the start** | BIGSERIAL in PostgreSQL. Max: 9.2 × 10^18. At 10K/sec, lasts 29 million years. |
| **UUID instead of sequential** | `id UUID DEFAULT gen_random_uuid()`. No overflow possible. But: larger (16 bytes vs 8), random order. |
| **Monitor ID usage** | Alert when max(id) > 75% of INT max. `SELECT max(id)::float / 2147483647 FROM events;` |
| **Migrate INT → BIGINT** | `ALTER TABLE events ALTER COLUMN id TYPE BIGINT;` — but LOCKS table during migration on large tables. Plan downtime or use pg_repack. |

---

## Edge Case 9: Timezone Corruption

### What Happens

Timestamps stored without timezone information. Different servers in different timezones interpret the same timestamp differently. Data appears to time-travel.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Global e-commerce. Servers in US (UTC-5) and India (UTC+5:30).

Table:
  CREATE TABLE orders (
      created_at TIMESTAMP  -- NO timezone! (this is the bug)
  );

User in India creates order at 10:00 PM IST (India Standard Time)
India server: INSERT INTO orders (created_at) VALUES ('2024-06-15 22:00:00');
  → Stored as: 2024-06-15 22:00:00 (no TZ info)

Admin in US queries: SELECT * FROM orders WHERE created_at > '2024-06-15 12:00:00';
US server interprets 22:00:00 as... 22:00 what timezone?
  → If US server is in UTC-5, it thinks 22:00 is US time
  → Actual time in UTC: 16:30 (IST is UTC+5:30)
  → US server's interpretation: 22:00 UTC-5 = 03:00 UTC next day
  → ORDER APPEARS TO BE 10.5 HOURS IN THE FUTURE!

Reports show orders at wrong times.
Financial reconciliation is broken.
Compliance logs are inaccurate.
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Always use TIMESTAMPTZ** | PostgreSQL: `TIMESTAMPTZ` stores in UTC internally, converts for display. `TIMESTAMP` has no TZ info. |
| **Store everything in UTC** | All servers, all apps write UTC. Convert to local time only at the UI layer. |
| **Set server timezone to UTC** | `SET timezone = 'UTC';` in PostgreSQL. Remove ambiguity. |
| **Validate on input** | Require timezone in all API inputs: `"2024-06-15T22:00:00+05:30"` (ISO 8601) |

```sql
-- WRONG
CREATE TABLE orders (
    created_at TIMESTAMP  -- NEVER USE THIS for real timestamps
);

-- RIGHT
CREATE TABLE orders (
    created_at TIMESTAMPTZ DEFAULT NOW()  -- Always use TIMESTAMPTZ
);

-- PostgreSQL stores TIMESTAMPTZ as UTC internally.
-- When you query: it converts to your session's timezone for display.
-- No ambiguity. Ever.
```

---

## Edge Case 10: Write Amplification from Over-Indexing

### What Happens

Every index on a table must be updated on every INSERT, UPDATE, and DELETE. With 10 indexes, every write becomes 11 operations (1 table + 10 indexes). Write-heavy tables slow to a crawl.

### Step-by-Step How It Goes Wrong

```
SCENARIO: Activity log table. 10 indexes. 50K inserts/second.

CREATE TABLE activity_log (
    id BIGSERIAL PRIMARY KEY,          -- index 1 (PK)
    user_id BIGINT,                    -- index 2
    action VARCHAR(50),                -- index 3
    entity_type VARCHAR(50),           -- index 4
    entity_id BIGINT,                  -- index 5
    ip_address INET,                   -- index 6
    browser VARCHAR(200),              -- index 7
    created_at TIMESTAMPTZ,            -- index 8
    session_id VARCHAR(100),           -- index 9
    country VARCHAR(2)                 -- index 10
);

Every INSERT:
  1. Write to heap (table data)
  2. Update index 1 (PK)
  3. Update index 2 (user_id)
  4. Update index 3 (action)
  5. Update index 4 (entity_type)
  ...
  11. Update index 10 (country)
  
  1 logical write = 11 physical writes (WRITE AMPLIFICATION)
  50K inserts/sec × 11 = 550K index operations/sec
  
  Disk I/O saturated → inserts slow from 1ms to 50ms
  → Backpressure → application queues fill → requests timeout
```

### Mitigations

| Fix | How It Works |
|-----|-------------|
| **Only index hot query columns** | Do you actually query by `browser`? If not, drop that index. |
| **Audit unused indexes** | PostgreSQL: `pg_stat_user_indexes` shows index usage stats. Drop zero-usage indexes. |
| **Partial indexes** | `CREATE INDEX ... WHERE action = 'purchase'` — only indexes the rows you actually query |
| **Batch inserts** | Insert 1000 rows at once instead of 1 at a time. Amortizes index maintenance. |
| **Use append-only tables** | For logs: don't update, only INSERT. Consider unlogged tables for non-critical data. |

```sql
-- FIND UNUSED INDEXES (PostgreSQL)
SELECT schemaname, tablename, indexname, idx_scan
FROM pg_stat_user_indexes
WHERE idx_scan = 0  -- Never used!
ORDER BY pg_relation_size(indexrelid) DESC;

-- If an index has idx_scan = 0 and the table has 50M rows,
-- that index is wasting disk space and slowing writes for nothing.
-- DROP IT.
```

---

## Edge Case Summary Table

| # | Edge Case | Trigger | Impact | Key Mitigation |
|---|-----------|---------|--------|----------------|
| 1 | Deadlock | Circular lock wait | Transactions abort, retries, degraded UX | Consistent lock order, short transactions |
| 2 | Replication lag | Async replication delay | Read-after-write returns stale data | Read from primary after write |
| 3 | Hot partition | Celebrity/popular key on one shard | One shard overloaded, others idle | Cache hot keys, hash-based sharding |
| 4 | Pool exhaustion | Slow queries hold connections | New requests timeout, service down | Statement timeout, separate pools |
| 5 | Cascading delete | ON DELETE CASCADE | One DELETE wipes thousands of rows | Soft delete, ON DELETE RESTRICT |
| 6 | Thundering herd | Popular cache key expires | 100s of identical DB queries simultaneously | Cache lock, staggered TTLs |
| 7 | Split-brain | Network partition during failover | Two primaries, divergent data | Quorum, fencing, managed DB |
| 8 | Integer overflow | INT auto-increment exhausted | Inserts fail, outage | BIGINT or UUID from the start |
| 9 | Timezone corruption | TIMESTAMP without TZ | Wrong times, broken reports | TIMESTAMPTZ, store UTC |
| 10 | Write amplification | Too many indexes on write-heavy table | Writes slow, disk saturated | Audit indexes, index only hot paths |

---

## Quick Memory Card

```
DEADLOCK:         Consistent lock order, short transactions, retry with backoff
REPLICATION LAG:  Read from primary after write. Accept lag for non-critical reads.
HOT PARTITION:    Cache hot keys. Hash-based sharding. Replicate hot data.
POOL EXHAUST:     Statement timeout (5s), separate fast/slow pools, pgBouncer.
CASCADE DELETE:   Soft delete preferred. ON DELETE RESTRICT for safety.
THUNDERING HERD:  Cache lock (single-flight), staggered TTLs, background refresh.
SPLIT-BRAIN:      Quorum-based failover, fencing, use managed DB.
INT OVERFLOW:     BIGINT or UUID from day one. Monitor max(id).
TIMEZONE:         TIMESTAMPTZ always. Store UTC. Convert at display.
WRITE AMP:        Only index hot queries. Audit unused indexes. Batch inserts.
```

---

**Next:** [[07_Tricks-and-Recognition]]
