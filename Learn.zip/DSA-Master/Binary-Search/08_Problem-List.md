# Binary Search — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Every problem builds pattern recognition for FAANG interviews. Heavy focus on binary search on answer.**

---

## 10 MUST-DO Problems (Start Here)


| #   | Problem                                       | Difficulty | LC#  | Concept Tag                | Why Important                 |
| --- | --------------------------------------------- | ---------- | ---- | -------------------------- | ----------------------------- |
| 1   | Binary Search                                 | Easy       | 704  | Exact match                | Foundation — purest form      |
| 2   | Search Insert Position                        | Easy       | 35   | bisect_left                | Insert position = lower bound |
| 3   | Find First and Last Position                  | Medium     | 34   | bisect_left + bisect_right | Most-asked bounds problem     |
| 4   | Search in Rotated Sorted Array                | Medium     | 33   | Rotated BS                 | Tests modified BS logic       |
| 5   | Find Minimum in Rotated Sorted Array          | Medium     | 153  | Find pivot                 | Rotated variant               |
| 6   | **Capacity To Ship Packages Within D Days**   | Medium     | 1011 | **BS on answer**           | **#1 BS-on-answer problem**   |
| 7   | **Koko Eating Bananas**                       | Medium     | 875  | **BS on answer**           | **Classic parametric search** |
| 8   | **Split Array Largest Sum**                   | Hard       | 410  | **BS on answer**           | **Min-max pattern**           |
| 9   | **Median of Two Sorted Arrays**               | Hard       | 4    | BS on partition            | FAANG favorite                |
| 10  | **Minimum Number of Days to Make m Bouquets** | Medium     | 1482 | **BS on answer**           | **Another capacity-style**    |


---

## Complete 30-Problem Progression

### Easy (Problems 1-8) — Build Foundation


| #   | Problem                                 | LC# | Concept               | Key Skill            |
| --- | --------------------------------------- | --- | --------------------- | -------------------- |
| 1   | Binary Search                           | 704 | Exact match           | Basic template       |
| 2   | Search Insert Position                  | 35  | bisect_left           | Insert position      |
| 3   | First Bad Version                       | 278 | BS on answer (simple) | First true in F...T  |
| 4   | Sqrt(x)                                 | 69  | BS on answer          | Integer sqrt         |
| 5   | Guess Number Higher or Lower            | 374 | Exact match (API)     | Interactive BS       |
| 6   | Valid Perfect Square                    | 367 | BS on answer          | Perfect square check |
| 7   | Arranging Coins                         | 441 | BS on answer          | Triangular number    |
| 8   | Binary Search (2D) — Search a 2D Matrix | 74  | Matrix BS             | Flatten to 1D        |


### Medium (Problems 9-22) — Core FAANG Level


| #   | Problem                                       | LC#  | Concept                    | Key Skill                  |
| --- | --------------------------------------------- | ---- | -------------------------- | -------------------------- |
| 9   | Find First and Last Position of Element       | 34   | bisect_left + bisect_right | Range query                |
| 10  | Search in Rotated Sorted Array                | 33   | Rotated BS                 | Which half is sorted       |
| 11  | Find Minimum in Rotated Sorted Array          | 153  | Find pivot                 | Compare with right         |
| 12  | Search in Rotated Sorted Array II             | 81   | Rotated + duplicates       | Handle equality            |
| 13  | **Capacity To Ship Packages Within D Days**   | 1011 | **BS on answer**           | Capacity monotonicity      |
| 14  | **Koko Eating Bananas**                       | 875  | **BS on answer**           | Speed monotonicity         |
| 15  | **Minimum Number of Days to Make m Bouquets** | 1482 | **BS on answer**           | Days monotonicity          |
| 16  | **Kth Smallest Element in a Sorted Matrix**   | 378  | BS on value + count        | Count elements ≤ mid       |
| 17  | Find Peak Element                             | 162  | BS (local comparison)      | Compare mid with neighbors |
| 18  | Find Right Interval                           | 436  | BS on intervals            | Sort + bisect              |
| 19  | Find K Closest Elements                       | 658  | BS + two pointers          | Find left boundary         |
| 20  | **Minimum Limit of Balls in a Bag**           | 1760 | **BS on answer**           | Operations monotonicity    |
| 21  | **Minimum Time to Complete Trips**            | 2187 | **BS on answer**           | Time monotonicity          |
| 22  | **Maximum Running Time of N Computers**       | 2141 | **BS on answer**           | Battery allocation         |


### Hard (Problems 23-30) — Interview Differentiators


| #   | Problem                                          | LC#  | Concept                       | Key Skill               |
| --- | ------------------------------------------------ | ---- | ----------------------------- | ----------------------- |
| 23  | **Split Array Largest Sum**                      | 410  | **BS on answer**              | Min-max, subarray sum   |
| 24  | **Median of Two Sorted Arrays**                  | 4    | BS on partition               | Partition left/right    |
| 25  | **Minimum Cost to Make at Least One Valid Path** | 1368 | BS + BFS/DFS                  | Advanced                |
| 26  | **Kth Smallest in Multiplication Table**         | 668  | BS on value + count           | Count ≤ mid             |
| 27  | **Find K-th Smallest Pair Distance**             | 719  | BS on distance + two pointers | Count pairs ≤ d         |
| 28  | **Minimum Space Wasted From Packaging**          | 1889 | BS + prefix sum               | Per-customer BS         |
| 29  | **Swim in Rising Water**                         | 778  | BS on answer + DFS            | Can reach with limit t? |
| 30  | **Minimum Time to Repair Cars**                  | 2594 | **BS on answer**              | Mechanics × time        |


---

## Problem-by-Problem Strategy Notes

### Problem 1: Binary Search (LC 704)

```
Type: Exact match
Template: Standard BS
Key: lo <= hi, return mid or -1
One-liner: Halve search space, compare with target.
```

### Problem 2: Search Insert Position (LC 35)

```
Type: bisect_left
Template: Lower bound
Key: Return lo (insert position)
One-liner: bisect_left gives exact insert index.
```

### Problem 9: Find First and Last Position (LC 34)

```
Type: bisect_left + bisect_right
Template: Both bounds
Key: left = bisect_left, right = bisect_right - 1
One-liner: Two binary searches for range.
```

### Problem 13: Capacity To Ship Packages (LC 1011) ⭐

```
Type: BS on answer
Template: Minimize
Key: condition(cap) = can ship in ≤ D days
      lo = max(weights), hi = sum(weights)
One-liner: BS on capacity, simulate shipping per iteration.
```

### Problem 14: Koko Eating Bananas (LC 875) ⭐

```
Type: BS on answer
Template: Minimize
Key: condition(speed) = can finish in ≤ H hours
      lo = 1, hi = max(piles)
One-liner: BS on eating speed, ceil(pile/speed) for hours.
```

### Problem 23: Split Array Largest Sum (LC 410) ⭐

```
Type: BS on answer (min-max)
Template: Minimize
Key: condition(max_sum) = can split into ≤ k subarrays with each sum ≤ max_sum
      lo = max(nums), hi = sum(nums)
One-liner: BS on max subarray sum, greedy split to verify.
```

### Problem 24: Median of Two Sorted Arrays (LC 4) ⭐

```
Type: BS on partition
Template: Partition-based
Key: Partition smaller array, derive larger. Check left_max ≤ right_min.
One-liner: BS on partition point in smaller array.
```

---

## Pattern Distribution

```
EXACT MATCH:        4 problems   (1, 5, 8, 704)
BISECT_LEFT/RIGHT:  3 problems   (2, 9, 35)
BS ON ANSWER:       14 problems  (3, 4, 6, 7, 13, 14, 15, 20, 21, 22, 23, 26, 27, 29, 30)
ROTATED:            3 problems   (10, 11, 12)
MATRIX:             2 problems   (8, 16)
PARTITION:          1 problem    (24)
OTHER:              3 problems   (17, 18, 19)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)

- Day 1: Problems 1-3 (Exact match, bisect_left, first true)
- Day 2: Problems 4-6 (Sqrt, guess, perfect square)
- Day 3: Problems 7-8 (Arranging coins, 2D matrix)

### Week 2: Bounds & Rotated (Days 4-6)

- Day 4: Problems 9-10 (First/last position, rotated search)
- Day 5: Problems 11-12 (Min in rotated, rotated with duplicates)
- Day 6: Problems 13-14 (Capacity to ship, Koko bananas) ⭐

### Week 3: BS on Answer Mastery (Days 7-9)

- Day 7: Problems 15, 20, 21 (Bouquets, balls, trips)
- Day 8: Problems 22, 23, 26 (Computers, split array, mult table)
- Day 9: Problems 27, 29, 30 (Pair distance, swim, repair cars)

### Week 4: Hard & Polish (Days 10-12)

- Day 10: Problem 24 (Median of two sorted) — master partition
- Day 11: Problems 16, 17, 18 (Matrix kth, peak, right interval)
- Day 12: Problems 19, 25, 28 (K closest, valid path, packaging)

---

## BS on Answer Problems — Quick Reference


| Problem                 | Answer Space       | Condition                 |
| ----------------------- | ------------------ | ------------------------- |
| Capacity to Ship (1011) | [max(w), sum(w)]   | Ship in ≤ D days          |
| Koko Bananas (875)      | [1, max(piles)]    | Finish in ≤ H hours       |
| Split Array (410)       | [max, sum]         | K subarrays, each sum ≤ X |
| Bouquets (1482)         | [1, max(bloomDay)] | m bouquets in ≤ X days    |
| Sqrt (69)               | [0, x]             | mid*mid ≤ x               |
| First Bad Version (278) | [1, n]             | isBadVersion(mid)         |


---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy, 14 Medium, 8 Hard)
MUST-DO:           LC 704, 35, 34, 33, 153, 1011, 875, 410, 4, 1482
TOP 3 BS ON ANS:   LC 1011 (Capacity), LC 875 (Koko), LC 410 (Split Array)
TOP 3 STANDARD:    LC 704 (Binary Search), LC 34 (First/Last), LC 33 (Rotated)
PATTERN SPLIT:     BS on answer (14), Exact/Bounds (7), Rotated (3),
                   Matrix (2), Partition (1), Other (3)
STUDY ORDER:       Exact → Bounds → Rotated → BS on answer → Hard
INTERVIEW LINE:    "I've practiced all binary search variants including
                     standard, bounds, rotated, matrix, and especially
                     binary search on answer — the FAANG differentiator."
```

