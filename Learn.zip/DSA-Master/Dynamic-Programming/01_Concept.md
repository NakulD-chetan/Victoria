# Dynamic Programming — Concept

> **Permanent Recall:** DP = Overlapping subproblems + Optimal substructure → Memoize or tabulate. State definition is THE most important skill. "What changes?" → that's your state. Top-down = solve big, cache small. Bottom-up = solve small, build big. FAANG tests DP in ~25% of rounds — knapsack, LCS, LIS, grid paths, interval DP.

---

## Core Idea (2 Lines)

**Overlapping Subproblems:** Same subproblems are solved multiple times in recursion. Cache results instead of recomputing.

**Optimal Substructure:** Optimal solution to the problem contains optimal solutions to its subproblems. Your recurrence builds on smaller optimal answers.

```
                    fib(5)
                   /      \
              fib(4)      fib(3)
              /    \      /    \
         fib(3)  fib(2) fib(2) fib(1)   ← fib(2), fib(3) computed TWICE
          /  \     |       |
     fib(2) fib(1) ...    ...
```

---

## Top-Down (Memoization) vs Bottom-Up (Tabulation)

| Aspect | Top-Down (Memoization) | Bottom-Up (Tabulation) |
|--------|------------------------|------------------------|
| **Direction** | Solve big → recurse to small | Solve small → build to big |
| **Structure** | Recursion + cache | Iterative loops |
| **Table fill** | On-demand (lazy) | All cells (eager) |
| **Base case** | Explicit in recursion | First row/col of table |
| **Stack** | Uses call stack (O(n) depth risk) | No recursion stack |
| **When to use** | Natural recurrence, sparse table | Interview default, space-optimizable |

```
TOP-DOWN:  dp(n) → need dp(n-1), dp(n-2) → recurse until base
           "Solve the problem I'm given, cache subproblem results"

BOTTOM-UP: dp[0], dp[1] known → fill dp[2], dp[3], ... dp[n]
           "Solve smallest first, build up to the answer"
```

---

## DP Categories (Master Map)

| Category | State Dimensions | Classic Problem | Table Shape |
|----------|------------------|-----------------|-------------|
| **1D DP** | 1 (index/length) | Climbing stairs, House robber | 1×n |
| **2D DP** | 2 (two indices) | Grid paths, Edit distance | m×n |
| **0/1 Knapsack** | (index, capacity) | Max value with weight limit | n×(W+1) |
| **Unbounded Knapsack** | (index or capacity) | Coin change, rod cutting | n×(amount+1) |
| **LCS** | (i, j) on two strings | Longest common subsequence | (m+1)×(n+1) |
| **LIS** | (index) or (length, last) | Longest increasing subsequence | 1×n or n×n |
| **Interval DP** | (left, right) | Matrix chain, burst balloons | n×n |
| **Bitmask DP** | (mask, position) | TSP, assignment | 2^n × n |
| **Digit DP** | (pos, tight, state) | Count numbers in range | varies |
| **Tree DP** | (node, state) | Max path in tree | DFS order |

---

## State Definition — THE Most Important Skill

**Rule:** State = minimal information needed to uniquely identify a subproblem.

- **Too few dimensions** → Can't express all choices; wrong answer
- **Too many dimensions** → Redundant; harder to fill; more memory

```
Good state: dp[i] = "best answer for prefix A[0..i]"
Bad state:  dp[i][j][k] when dp[i] suffices

Ask: "If I'm at position i, what do I need to know to make the next decision?"
     → That's your state.
```

### State Design Checklist

1. **What is the subproblem?** (e.g., "max profit using first i items, capacity w")
2. **What varies?** (index i, capacity w) → dimensions
3. **What is the value?** (max profit, min cost, count)
4. **Base case?** (empty set, zero capacity, etc.)

---

## Recurrence Relation Formulation

**Pattern:** `dp[state] = f(choices, dp[smaller_states])`

- **Choices:** What decisions can you make at this state?
- **Transition:** How does each choice change the state?
- **Aggregation:** min/max/sum over all valid choices

```
Example (0/1 Knapsack):
  dp[i][w] = max value using items 0..i, capacity w

  Choice 1: Skip item i  → dp[i-1][w]
  Choice 2: Take item i  → value[i] + dp[i-1][w - weight[i]]  (if w >= weight[i])

  dp[i][w] = max(dp[i-1][w], value[i] + dp[i-1][w-weight[i]])
```

---

## Space Optimization (Rolling Array)

When `dp[i]` depends only on `dp[i-1]` (or a few previous rows):

- **1D:** Use 2 variables or a small array; overwrite in place
- **2D:** Use 2 rows; alternate `curr` and `prev`

```
Before:  dp[n+1][W+1]  → O(n×W) space
After:   dp[2][W+1] or dp[W+1]  → O(W) space

Key: Fill in reverse order (right to left) for knapsack to avoid overwriting needed values.
```

---

## When NOT to Use DP

| Scenario | Why Not | Use Instead |
|----------|---------|-------------|
| **Greedy is correct** | DP overkill; greedy is simpler | Greedy (e.g., activity selection) |
| **No overlapping subproblems** | No benefit from caching | Recursion or iterative |
| **Non-optimal substructure** | Can't build from subproblems | Different paradigm |
| **Negative cycles** | Bellman-Ford, not classic DP | Graph algorithms |
| **Order doesn't matter** | Might be math/combinatorics | Direct formula |

---

## Golden Rules

1. **State first** — Define state before writing recurrence
2. **Base case explicitly** — Handle empty, single element, boundaries
3. **Consider all choices** — Don't miss a transition
4. **Fill order matters** — Dependencies must be ready when needed
5. **Subsequence ≠ Subarray** — Subsequence can skip; subarray is contiguous
6. **0-index vs 1-index** — Be consistent; dp[0] often = base
7. **Space optimize last** — Get correct solution first, then optimize

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Dynamic Programming
TWO PILLARS:        Overlapping subproblems + Optimal substructure
TOP-DOWN:           Recurse + cache; solve big → small
BOTTOM-UP:          Iterate; solve small → big
STATE:              Minimal info to identify subproblem — MOST IMPORTANT
RECURRENCE:         dp[state] = f(choices, dp[smaller_states])
CATEGORIES:         1D, 2D, Knapsack, LCS, LIS, Interval, Bitmask, Digit, Tree
SPACE OPT:          Rolling array when row i depends only on row i-1
WHEN NOT:           Greedy works, no overlap, no optimal substructure
INTERVIEW LINE:     "I'll define state dp[i] as... The recurrence is... Base case..."
```
