# SQL Interview Mastery — Edge Cases

---

## Universal edge cases to mention

1. **NULL** — in WHERE, JOIN, aggregates, NOT IN.
2. **Ties** — ranking, top-N, MAX when duplicates.
3. **Empty groups** — no rows after filter → group doesn't appear (use LEFT JOIN to dimension).
4. **Duplicate rows** — join fan-out inflating aggregates.
5. **Single row table** — "second highest" → NULL.
6. **Date boundaries** — inclusive/exclusive, timezone.
7. **Division by zero** — ratio when denominator = 0 → use NULLIF.

---

## Quick NULLIF pattern

```sql
SELECT numerator / NULLIF(denominator, 0) AS safe_ratio
```

---

*Next: [[07_Tricks-and-Recognition]]*
