# What is a Data Mart — Practice

> "A mart is a product: narrow scope, clear owner, fast time to value."

---

## Quick Recall

**Q:** What is a data mart?  
**A:** A subset of the warehouse focused on one business area or user community, usually conformed to enterprise dimensions.

**Q:** How does a mart differ from a full enterprise warehouse?  
**A:** Smaller scope, faster delivery, often fewer sources—but should still use conformed keys when integrated reporting matters.

**Q:** Give a retail example of a mart subject area.  
**A:** E-commerce conversion funnel mart for digital merchandising, or a store operations mart for shrink and labor.

**Q:** What is a dependent vs independent mart?  
**A:** Dependent marts are fed from the central warehouse; independent marts are built directly from sources (higher drift risk).

**Q:** Why are conformed dimensions important across marts?  
**A:** So channel-specific marts still roll up to consistent customer, product, and calendar definitions.

---

## Interview Questions

**1. Define a data mart and when you would create one.**  
**Model answer:** A mart is a curated slice of the data warehouse tailored to a domain—like marketplace seller performance or loyalty program ROI. I create one when a team has stable recurring questions, clear ownership, and benefits from faster iteration without exposing the entire enterprise model. I also confirm the mart will not fork definitions that finance already standardized.

**2. What risks come with independent data marts?**  
**Model answer:** Divergent definitions of customer or revenue, duplicate ETL, and reconciliation nightmares when executives compare two dashboards that should match. Independent marts were common historically; dependent marts from a conformed core are the modern default for omnichannel retailers.

**3. How do you keep marts aligned with finance?**  
**Model answer:** Source facts from the same conformed `fact_sales` where possible, document any mart-specific filters, and run periodic reconciliation checks to the general ledger. If a mart needs a subset, the subset rule should be versioned like any other metric definition.

**4. Is a mart always a separate database?**  
**Model answer:** No. It can be a schema, a dataset in a semantic layer, or a set of views with row-level security—what matters is logical boundaries and ownership. Physical separation is a scaling and security decision, not a definition requirement.

**5. How do you prioritize which mart to build next for retail?**  
**Model answer:** I score by business value, data readiness, number of duplicate ad hoc reports today, and dependency on conformed dimensions already available. I avoid starting a mart when upstream keys are still chaotic unless we time-box a staging path.

**6. What is the relationship between a mart and a semantic layer?**  
**Model answer:** The semantic layer exposes friendly business names and joins; the mart supplies the underlying star schema or views. Together they reduce SQL sprawl for merchandising users. The semantic layer should not become a second place to encode revenue rules.

**7. How would you explain marts to a store operations lead?**  
**Model answer:** It is their team's fast, governed view of labor, foot traffic, and shrink metrics without navigating unrelated enterprise tables. They get answers in their vocabulary with guardrails so they cannot accidentally join unrelated facts.

**8. What is a hub-and-spoke pattern in this context?**  
**Model answer:** A central conformed enterprise warehouse (hub) feeds domain marts (spokes). Spokes specialize; the hub prevents metric entropy. For retail, the hub often owns `dim_product` and `dim_date` while spokes add channel-specific facts.

---

## Scenario-Based Exercises

**Scenario 1 — Digital marketing wants a self-service sandbox**  
**Solution:** Create a dependent mart `marts.marketing` with `fact_campaign_performance` and conformed `dim_date`, `dim_product`. Enforce RLS by marketing region. Avoid independent extracts from Google Ads that bypass product hierarchy.

**Scenario 2 — Two marts show different customer counts**  
**Solution:** Audit join paths and filters; ensure both use `dim_customer` Type 2 effective dating consistently; document "active customer" definition. Add automated tests comparing distinct counts under the same predicates.

**Scenario 3 — Mart query performance**  
Merchants run heavy cohort queries.  
**Solution:** Pre-aggregate monthly customer order counts into a summary fact; keep detail in `fact_sales` for drill-through.

```sql
CREATE TABLE marts.customer_monthly_orders AS
SELECT DATE_TRUNC('month', order_date) AS month_start,
       customer_key,
       COUNT(DISTINCT order_id) AS order_count,
       SUM(net_sales_amount) AS net_sales
FROM dw.fact_sales
GROUP BY 1, 2;
```

**Scenario 4 — Vendor mart and loyalty overlap**  
**Solution:** For drop-ship partners, expose a limited mart with obfuscated customer geography and delayed data in a separate schema; contractually define refresh cadence and fields. When loyalty overlaps web sales, share `fact_sales` and `dim_customer`, add `fact_loyalty_events` in the loyalty mart only, and do not rebuild sales totals inside loyalty unless there is a documented additive extension such as points liability.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Mart = dump of one OLTP database | Sounds like a silo | Emphasize modeling and conformed keys |
| Unlimited independent marts | Shows weak architecture | Recommend hub-and-spoke from a conformed core |
| Confusing mart with ODS | ODS is operational integration | Position mart as analytical consumption |
| Ignoring security boundaries | Retail has partner data | Mention RLS and delayed snapshots |
| Mart as bypass around governance | Teams want speed | Dependent marts inherit rules; document exceptions |
| Too many overlapping marts | Duplicate facts | Bus matrix review before funding new marts |

---

## One-Liner Answers

- A data mart is a focused, governed subset of the warehouse for one domain or audience.
- Dependent marts inherit conformed dimensions from the enterprise warehouse.
- Independent marts are faster short term but risk inconsistent metrics across the company.
- Marts improve time-to-insight without giving every user the full enterprise model.
- Logical separation (schema or dataset) is as important as physical separation.
- The best marts share keys and definitions with the rest of the retail analytics platform.
