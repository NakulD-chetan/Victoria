# Running Total — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers cumulative sums, rolling averages, running balance, YTD, and cumulative percentage. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Running Total of Posts | DataLemur | Easy | Basic SUM OVER | Purest running total |
| 2 | Last Person to Fit in the Bus | LC 1204 | Medium | Cumulative + threshold | Classic cumulative sum with limit |
| 3 | Restaurant Growth | LC 1321 | Medium | Rolling 7-day avg | ROWS BETWEEN for moving window |
| 4 | Game Play Analysis III | LC 534 | Medium | Running SUM per player | Cumulative per partition |
| 5 | Find Median Given Freq of Numbers | LC 571 | Hard | Cumulative frequency | Median via running count |
| 6 | Running Total Revenue | StrataScratch | Medium | Monthly cumulative | YTD revenue pattern |
| 7 | Cumulative Purchases | DataLemur | Medium | Running SUM + filter | Cumulative with condition |
| 8 | Bank Account Balance | Common | Medium | Signed running total | Credit/debit running balance |
| 9 | Monthly Revenue Growth Rate | DataLemur | Medium | Running + LAG | Cumulative + growth rate |
| 10 | 30-Day Rolling Average | StrataScratch | Hard | Rolling avg on dates | Date-based rolling window |

---

## Complete 20-Problem Progression

### Easy (Problems 1-5) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Running Total of Posts | DataLemur | SUM OVER ORDER BY | Basic cumulative sum |
| 2 | Running Sum of 1D Array | DSA/LC 1480 | Prefix sum concept | Understand the analogy |
| 3 | Cumulative Count | HackerRank | COUNT OVER | Running count |
| 4 | Running Max Salary | Common | MAX OVER | Running maximum |
| 5 | YTD Sales | Common | SUM OVER PARTITION BY year | Reset per year |

### Medium (Problems 6-15) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 6 | Last Person to Fit in the Bus | LC 1204 | Cumulative + threshold | SUM OVER, filter max <= limit |
| 7 | Restaurant Growth | LC 1321 | Rolling 7-day | ROWS BETWEEN 6 PRECEDING AND CURRENT ROW |
| 8 | Game Play Analysis III | LC 534 | Running SUM per group | PARTITION BY player, SUM amount |
| 9 | Bank Account Balance | Common | Signed cumulative | CASE credit/debit in SUM |
| 10 | Monthly Revenue Growth Rate | DataLemur | Running + LAG | MoM on cumulative values |
| 11 | Cumulative Percentage of Revenue | StrataScratch | Running / total | SUM OVER / SUM OVER () |
| 12 | Average Revenue Per User (ARPU) | DataLemur | Running AVG | Cumulative average |
| 13 | Rolling 3-Month Revenue | Common | Rolling SUM | ROWS BETWEEN 2 PRECEDING AND CURRENT ROW |
| 14 | Inventory Running Balance | Common | Running SUM + negative | Stock in/out running total |
| 15 | Salary Budget Utilization | Common | Running SUM vs budget | Cumulative salary vs dept budget |

### Hard (Problems 16-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 16 | Find Median Given Freq of Numbers | LC 571 | Cumulative freq | Running SUM of frequencies for median |
| 17 | 30-Day Rolling Average | StrataScratch | Date-range rolling | Handle missing dates in rolling window |
| 18 | Retention Cohort Analysis | DataLemur | Running retention | Cumulative user counts per cohort |
| 19 | Cumulative Distribution | Common | Running + rank | Build CDF from data |
| 20 | Find Cumulative Salary of Employee | LC 579 | 3-month running per emp | Correlated running sum |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Last Person to Fit in the Bus (LC 1204)

```
Pattern:     Cumulative sum with threshold
Approach:    SUM(weight) OVER (ORDER BY turn) AS total_weight
             Filter WHERE total_weight <= 1000
             Take the LAST person (MAX total or ORDER DESC LIMIT 1)
Key Insight: Running total tells you cumulative weight at each person
One-liner:   Running sum of weight by turn order; last person under 1000.
```

### Problem 3: Restaurant Growth (LC 1321)

```
Pattern:     Rolling 7-day average
Approach:    SUM(amount) OVER (ORDER BY visited_on ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
             Only show results from day 7 onwards (first 6 days incomplete window)
Key Insight: ROWS BETWEEN 6 PRECEDING = exactly 7 rows (6 + current)
One-liner:   Rolling 7-day sum using ROWS 6 PRECEDING; filter first 6 days.
```

### Problem 16: Find Median Given Freq of Numbers (LC 571)

```
Pattern:     Cumulative frequency for median
Approach:    Running SUM of frequency OVER (ORDER BY num)
             Median position = CEIL(total/2) and FLOOR(total/2)+1
             Find nums where running count crosses median position
Key Insight: Running frequency sum tells you which number covers the median position
One-liner:   Cumulative frequency; find number where running count crosses midpoint.
```

### Problem 20: Find Cumulative Salary (LC 579)

```
Pattern:     3-month running sum per employee
Approach:    SUM(salary) OVER (PARTITION BY id ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
             Exclude most recent month per employee
Key Insight: Partition by employee, rolling 3-month window
One-liner:   Per employee, 3-month rolling salary sum; exclude last month.
```

---

## Pattern Distribution

```
SIMPLE RUNNING TOTAL (SUM OVER):       7 problems  (1-5, 8-9)
ROLLING WINDOW (ROWS BETWEEN N):       5 problems  (7, 13, 17, 19-20)
CUMULATIVE WITH THRESHOLD:             3 problems  (6, 14-15)
CUMULATIVE PERCENTAGE / RATIO:         3 problems  (10-12)
CUMULATIVE FREQUENCY (MEDIAN):         2 problems  (16, 18)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: DataLemur running total, LC 1480 prefix sum analogy
- Day 2: Running count, running max, YTD pattern
- Day 3: LC 1204 (bus), LC 534 (game play)

### Week 2: Rolling Windows (Days 4-6)
- Day 4: LC 1321 (restaurant growth — rolling 7-day)
- Day 5: Bank balance, cumulative percentage
- Day 6: 3-month rolling, inventory balance

### Week 3: Hard + Review (Days 7-9)
- Day 7: LC 571 (median frequency), LC 579 (cumulative salary)
- Day 8: 30-day rolling avg, retention cohort
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Ranking instead of cumulative | Pattern 01 (Window Functions) — ROW_NUMBER/RANK |
| Missing dates in rolling window | Pattern 11 (Date Series Fill) — generate dates first |
| Consecutive streak detection | Pattern 08 (Gaps and Islands) — combines with running total |
| Group totals without running | Pattern 04 (Aggregation + HAVING) — plain GROUP BY |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (5 Easy, 10 Medium, 5 Hard)
MUST-DO:            LC 1204, 1321, 534, 571 + DataLemur/StrataScratch
TOP 3 MOST ASKED:   LC 1204 (Bus), LC 1321 (Restaurant), LC 571 (Median)
PATTERN SPLIT:      Simple running (7), Rolling window (5), Threshold (3),
                    Percentage (3), Frequency (2)
STUDY ORDER:        Simple SUM OVER → Rolling ROWS BETWEEN → Threshold → Percentage
KEY INSIGHT:        SUM OVER = prefix sum; ROWS BETWEEN = sliding window
INTERVIEW LINE:     "I use SUM OVER ORDER BY for running totals and
                     ROWS BETWEEN N PRECEDING for rolling averages."
```

---

## 30-SECOND REVISION BOX

```
RUNNING TOTAL:   SUM(col) OVER (ORDER BY sort_col)
ROLLING AVG:     AVG(col) OVER (ORDER BY x ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
PER GROUP:       Add PARTITION BY group_col to reset per group
YTD:             PARTITION BY EXTRACT(YEAR FROM date) ORDER BY date
CUMULATIVE %:    SUM OVER ordered / SUM OVER () (total)
ROWS vs RANGE:   ROWS = physical count; RANGE = value-based (includes ties)
DEFAULT FRAME:   RANGE UNBOUNDED PRECEDING TO CURRENT ROW (includes ties!)
OFF-BY-ONE:      "7-day" = ROWS BETWEEN 6 PRECEDING AND CURRENT ROW (inclusive)
RULE:            Always use explicit ROWS frame to avoid tie surprises
```
