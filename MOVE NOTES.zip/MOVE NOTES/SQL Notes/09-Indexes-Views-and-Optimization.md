# Indexes, Views & Query Optimization

> **Index = Database ka "book index"** — poora table scan karne ki jagah seedha relevant pages pe jaao.
> **View = Saved query** — baar baar same query likhne ki jagah ek naam se call karo.
> **Optimization = Query ko fast banao** — slow query se user bhaag jaata hai!

---

## Part 1: Indexes

### What is an Index?

> **Definition:** An index is a data structure (typically B-Tree or Hash) that improves the speed of data retrieval operations on a table at the cost of additional storage and slower writes.

```
Without Index (Full Table Scan):          With Index (Index Lookup):
┌──────────────────────┐                  ┌─────────────┐
│ Row 1 → Check ❌      │                  │ Index (B-Tree)│
│ Row 2 → Check ❌      │                  │   ┌───┐      │
│ Row 3 → Check ❌      │                  │   │ M │      │
│ Row 4 → Check ✅ Found│                  │  ╱     ╲     │
│ Row 5 → Check ❌      │                  │┌─┐   ┌─┐    │ → Seedha Row 4!
│ ...100000 rows scan   │                  ││A│   │R│    │
│                       │                  │└─┘   └─┘    │
└──────────────────────┘                  └─────────────┘
O(n) — sab check karo                    O(log n) — tree search
```

> **Real Life Example:** Library mein book dhundhna — agar index hai toh page number pata hai, seedha jaao. Bina index ke har page check karna padega.

---

### Types of Indexes

#### 1. Clustered Index

> **Definition:** Determines the PHYSICAL ORDER of data in the table. Only ONE per table (like dictionary — words physically sorted by alphabet).

```sql
-- Primary Key automatically Clustered Index banta hai
CREATE TABLE employees (
    id INT PRIMARY KEY,  -- ← Clustered Index on 'id'
    name VARCHAR(100),
    salary DECIMAL(10,2)
);
```

| Feature | Clustered Index |
|---------|----------------|
| **Physical sorting** | Data physically sorted hota hai |
| **Count** | Sirf **1 per table** |
| **Speed** | Range queries mein **bahut fast** |
| **Example** | Dictionary (words sorted by alphabet) |

---

#### 2. Non-Clustered Index

> **Definition:** Creates a SEPARATE structure that points to the actual data. Multiple allowed per table (like book index at the back — separate from content).

```sql
-- Create Non-Clustered Index
CREATE INDEX idx_name ON employees(name);
CREATE INDEX idx_dept ON employees(department);
```

| Feature | Non-Clustered Index |
|---------|---------------------|
| **Physical sorting** | Data sort NAHI hota — separate pointer structure |
| **Count** | **Multiple** per table allowed |
| **Speed** | Lookup fast, but extra step (pointer follow) |
| **Example** | Book ke peeche index page |

---

#### 3. Composite Index (Multi-Column)

```sql
CREATE INDEX idx_dept_salary ON employees(department, salary);
```

> **Left-most Prefix Rule:** Composite index tabhi kaam karega jab query mein **left-most columns** use ho:

```sql
-- ✅ Uses index (department is leftmost)
SELECT * FROM employees WHERE department = 'IT';

-- ✅ Uses index (both columns, left to right)
SELECT * FROM employees WHERE department = 'IT' AND salary > 70000;

-- ❌ DOES NOT use index (salary alone, department missing)
SELECT * FROM employees WHERE salary > 70000;
```

> **Trick:** Composite index ko phone number jaise socho — `(STD code, number)`. STD code bina number mat dhoondo!

---

#### 4. Unique Index

```sql
CREATE UNIQUE INDEX idx_email ON employees(email);
```

> Duplicate values allow nahi karega — like UNIQUE constraint.

---

#### 5. Covering Index

> Ek index jo query ke **saare columns** cover kar le — table access hi nahi karna padta!

```sql
-- Query:
SELECT name, salary FROM employees WHERE department = 'IT';

-- Covering Index:
CREATE INDEX idx_covering ON employees(department, name, salary);
-- Ab index mein hi sab data hai — table read nahi karna padega!
```

---

### When to Create Index?

| **Create Index When** | **Don't Create Index When** |
|----------------------|---------------------------|
| Column in WHERE clause frequently | Small tables (full scan fast enough) |
| Column in JOIN condition | Columns with very few unique values (gender: M/F) |
| Column in ORDER BY | Tables with heavy INSERT/UPDATE/DELETE |
| Column in GROUP BY | Columns rarely used in queries |
| High cardinality (many unique values) | When table is mostly written, not read |

> **Index Cost:**
> - **SELECT faster** (read benefit)
> - **INSERT/UPDATE/DELETE slower** (index update overhead)
> - **Extra storage** use hota hai

---

### Index-Related Interview Questions

**Q: Clustered vs Non-Clustered kya difference hai?**

| Feature | Clustered | Non-Clustered |
|---------|-----------|---------------|
| Physical order | Data sorted physically | Separate pointer structure |
| Per table | 1 only | Multiple allowed |
| Speed | Faster for range queries | Extra lookup step |
| Storage | No extra structure | Extra storage needed |
| Default | Primary Key | Created manually |

**Q: Index kab use NAHI karna chahiye?**
> Small tables, low cardinality columns, write-heavy tables.

---

## Part 2: Views

### What is a View?

> **Definition:** A view is a virtual table based on a SQL query. It doesn't store data — it stores the query itself. Jab access karo, query execute hoti hai.

```sql
-- Create View
CREATE VIEW it_employees AS
SELECT id, name, salary
FROM employees
WHERE department = 'IT';

-- Use View (like a table)
SELECT * FROM it_employees;
SELECT name FROM it_employees WHERE salary > 80000;
```

---

### Why Use Views?

| Benefit | Explanation |
|---------|------------|
| **Simplicity** | Complex query ko simple naam de do |
| **Security** | Sensitive columns hide karo (salary, SSN) |
| **Consistency** | Sab log same logic use karein |
| **Abstraction** | Table structure change ho, view same rahe |

```sql
-- Security: HR can only see non-salary data
CREATE VIEW employee_public AS
SELECT id, name, department, city
FROM employees;
-- Salary column hidden!
```

---

### Updatable View vs Read-Only View

| Feature | Updatable View | Read-Only View |
|---------|---------------|----------------|
| INSERT/UPDATE/DELETE | ✅ Possible | ❌ Not possible |
| Contains | Simple SELECT from 1 table | JOINs, GROUP BY, DISTINCT, subqueries |
| Aggregate functions | ❌ No | Can have |

```sql
-- Updatable (simple, single table)
CREATE VIEW simple_view AS
SELECT id, name, salary FROM employees WHERE department = 'IT';

UPDATE simple_view SET salary = 95000 WHERE id = 6;  -- ✅ Works

-- Read-Only (has JOIN)
CREATE VIEW dept_summary AS
SELECT d.dept_name, COUNT(e.id) as cnt
FROM departments d JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name;

UPDATE dept_summary SET cnt = 5;  -- ❌ Error
```

---

### Materialized View

> **Definition:** A materialized view stores the query result PHYSICALLY on disk. Unlike regular views, it caches data for fast access but needs periodic refresh.

```sql
-- PostgreSQL syntax
CREATE MATERIALIZED VIEW mv_dept_stats AS
SELECT department, COUNT(*) AS emp_count, AVG(salary) AS avg_sal
FROM employees
GROUP BY department;

-- Refresh when data changes
REFRESH MATERIALIZED VIEW mv_dept_stats;
```

| Feature | Regular View | Materialized View |
|---------|-------------|-------------------|
| **Data stored?** | ❌ No (query only) | ✅ Yes (cached) |
| **Speed** | Query runs each time | Fast (pre-computed) |
| **Fresh data?** | ✅ Always current | ❌ Stale until refreshed |
| **Storage** | No extra | Extra storage |
| **Use case** | Real-time access | Dashboard, reports, analytics |

---

## Part 3: Query Optimization

### 1. EXPLAIN / EXPLAIN ANALYZE — Query Plan Dekho

```sql
-- MySQL
EXPLAIN SELECT * FROM employees WHERE department = 'IT';

-- PostgreSQL
EXPLAIN ANALYZE SELECT * FROM employees WHERE department = 'IT';
```

> **EXPLAIN output mein dekho:**
> - **type:** ALL (full scan) vs ref/index (index use hua)
> - **rows:** Kitne rows scan hue
> - **key:** Kaunsa index use hua (NULL = no index)

---

### 2. Top Optimization Tips

#### Tip 1: SELECT * avoid karo

```sql
-- ❌ Bad: Sab columns fetch
SELECT * FROM employees WHERE department = 'IT';

-- ✅ Good: Sirf needed columns
SELECT name, salary FROM employees WHERE department = 'IT';
```

#### Tip 2: Appropriate Index banao

```sql
-- Agar WHERE mein department baar baar aata hai
CREATE INDEX idx_dept ON employees(department);
```

#### Tip 3: WHERE mein functions avoid karo

```sql
-- ❌ Bad: Function on column → Index use nahi hoga
SELECT * FROM employees WHERE YEAR(join_date) = 2024;

-- ✅ Good: Range use karo → Index use hoga
SELECT * FROM employees
WHERE join_date >= '2024-01-01' AND join_date < '2025-01-01';
```

#### Tip 4: Leading wildcard avoid karo

```sql
-- ❌ Bad: Leading % → Full scan
SELECT * FROM employees WHERE name LIKE '%ahul';

-- ✅ Good: Trailing % → Index use hoga
SELECT * FROM employees WHERE name LIKE 'Rah%';
```

#### Tip 5: EXISTS vs IN (large datasets)

```sql
-- Large subquery result → EXISTS better
SELECT * FROM employees e
WHERE EXISTS (SELECT 1 FROM departments d WHERE d.dept_id = e.dept_id);
```

#### Tip 6: Pagination properly karo

```sql
-- ❌ Bad: OFFSET large hone pe slow
SELECT * FROM employees ORDER BY id LIMIT 10 OFFSET 100000;

-- ✅ Good: Keyset pagination
SELECT * FROM employees WHERE id > 100000 ORDER BY id LIMIT 10;
```

#### Tip 7: JOIN order matter karta hai

```sql
-- Smaller table pehle JOIN karo (optimizer usually handles, but hint de sakte ho)
SELECT e.name, d.dept_name
FROM departments d  -- smaller table first
JOIN employees e ON d.dept_id = e.dept_id;
```

---

### 3. Common Performance Killers

| Problem | Solution |
|---------|----------|
| `SELECT *` | Specific columns list karo |
| No index on WHERE columns | Index banao |
| Function on indexed column | Column ko plain rakho |
| `LIKE '%text'` | Leading wildcard avoid karo |
| Cartesian product (no ON) | Always JOIN condition do |
| `SELECT DISTINCT` unnecessarily | Query logic fix karo |
| Nested subqueries | JOIN ya CTE use karo |
| Not using LIMIT | Result set limit karo |

---

## Quick Memory Card

| Concept | One Line | Interview Hint |
|---------|----------|----------------|
| Clustered Index | Physical order, 1 per table | Like dictionary |
| Non-Clustered | Separate pointer, multiple ok | Like book index |
| Composite Index | Multi-column index | Left-most prefix rule |
| Covering Index | Index has all query columns | No table access needed |
| View | Virtual table (saved query) | Security + Simplicity |
| Materialized View | Cached query result on disk | Fast reads, stale data |
| EXPLAIN | Show query execution plan | Always check slow queries |
| B-Tree | Default index structure | Balanced, O(log n) |
| Index trade-off | Fast reads, slow writes | Don't over-index |

---

*Notes Source: SQL Indexes, Views & Optimization + Interview preparation material*
