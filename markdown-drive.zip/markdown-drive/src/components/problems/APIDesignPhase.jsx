import { useCallback } from 'react';
import { useProblemSessionStore } from '../../stores/problem-session-store';

const HTTP_METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'WebSocket'];

export default function APIDesignPhase({ problem }) {
  const endpoints = useProblemSessionStore((s) => s.phases.api.endpoints);
  const score = useProblemSessionStore((s) => s.phases.api.score);
  const completed = useProblemSessionStore((s) => s.phases.api.completed);
  const addEndpoint = useProblemSessionStore((s) => s.addEndpoint);
  const updateEndpoint = useProblemSessionStore((s) => s.updateEndpoint);
  const removeEndpoint = useProblemSessionStore((s) => s.removeEndpoint);
  const scoreAPI = useProblemSessionStore((s) => s.scoreAPI);
  const nextPhase = useProblemSessionStore((s) => s.nextPhase);

  const expected = problem.expectedAPIs || [];
  if (!expected.length) return <div className="dc-phase-empty">No API design phase for this problem.</div>;

  const handleSubmit = useCallback(() => {
    scoreAPI(problem);
  }, [problem, scoreAPI]);

  const handleNext = useCallback(() => {
    if (!completed) scoreAPI(problem);
    nextPhase();
  }, [completed, scoreAPI, problem, nextPhase]);

  return (
    <div className="dc-api-phase">
      <div className="dc-api-phase__header">
        <h3 className="dc-api-phase__title">Phase 2: Design the API</h3>
        <p className="dc-api-phase__desc">
          Define the key API endpoints your system needs. Think about what operations users and services
          will perform. Specify the HTTP method, path, and a brief description.
        </p>
        <div className="dc-api-phase__hint-box">
          <strong>Tip:</strong> This system needs approximately {expected.length} key endpoint{expected.length > 1 ? 's' : ''}.
          Think about CRUD operations and any special functionality.
        </div>
      </div>

      <div className="dc-api-phase__endpoints">
        {endpoints.map((ep, idx) => (
          <div key={idx} className="dc-api-phase__row">
            <select
              value={ep.method}
              onChange={(e) => updateEndpoint(idx, 'method', e.target.value)}
              className="dc-api-phase__method"
              disabled={completed}
            >
              {HTTP_METHODS.map((m) => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
            <input
              type="text"
              value={ep.path}
              onChange={(e) => updateEndpoint(idx, 'path', e.target.value)}
              placeholder="/api/resource/{id}"
              className="dc-api-phase__path"
              disabled={completed}
            />
            <input
              type="text"
              value={ep.desc}
              onChange={(e) => updateEndpoint(idx, 'desc', e.target.value)}
              placeholder="What does this endpoint do?"
              className="dc-api-phase__desc-input"
              disabled={completed}
            />
            {!completed && (
              <button onClick={() => removeEndpoint(idx)} className="dc-api-phase__remove" title="Remove">
                &times;
              </button>
            )}
          </div>
        ))}

        {!completed && (
          <button onClick={addEndpoint} className="dc-btn dc-btn--outline dc-api-phase__add">
            + Add Endpoint
          </button>
        )}
      </div>

      {completed && (
        <div className="dc-api-phase__answer-key">
          <h4 className="dc-api-phase__answer-title">Expected API Surface</h4>
          {expected.map((api, idx) => (
            <div key={idx} className="dc-api-phase__expected-row">
              <span className="dc-api-phase__expected-method">{api.method}</span>
              <code className="dc-api-phase__expected-path">{api.path}</code>
              <span className="dc-api-phase__expected-desc">{api.desc}</span>
            </div>
          ))}
        </div>
      )}

      <div className="dc-api-phase__actions">
        {!completed ? (
          <button
            onClick={handleSubmit}
            className="dc-btn dc-btn--primary"
            disabled={endpoints.length === 0}
          >
            Validate My API Design
          </button>
        ) : (
          <div className="dc-api-phase__result">
            <div className={`dc-api-phase__score ${score >= 70 ? 'dc-api-phase__score--good' : 'dc-api-phase__score--low'}`}>
              Score: {score}% ({Math.round((score / 100) * expected.length)}/{expected.length} endpoints matched)
            </div>
            <button onClick={handleNext} className="dc-btn dc-btn--primary">
              Next: Architecture Design &rarr;
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
