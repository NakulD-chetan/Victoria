import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const TEXT = 'abccab';
const PATTERNS = ['ab', 'bc', 'ca'];

function buildTrieSteps() {
  const steps = [];
  let nodeCount = 1;
  const trie = { label: 'root', children: {} };
  steps.push({ type: 'trie-root', msg: 'Empty trie root', TEXT, pattern: PATTERNS[0], trieDepth: 0, table: [0], tableLabel: 'node' });
  PATTERNS.forEach((w, wi) => {
    let node = trie;
    for (let k = 0; k < w.length; k++) {
      steps.push({
        type: 'trie-add',
        msg: `Insert "${w}" char ${w[k]}`,
        TEXT,
        pattern: w,
        trieKey: w.slice(0, k + 1),
        wi,
        k,
        table: Array.from({ length: nodeCount }, (_, i) => i),
        tableLabel: 'trie nodes',
      });
      const ch = w[k];
      if (!node.children[ch]) {
        node.children[ch] = { label: ch, children: {} };
        nodeCount += 1;
      }
      node = node.children[ch];
    }
    steps.push({ type: 'trie-word', msg: `Pattern ${wi} end state`, TEXT, pattern: w, wi });
  });
  return { steps, trie, nodeCount };
}

function searchSteps(text, trieMeta) {
  const steps = [];
  steps.push({ type: 'search-start', msg: 'Follow trie while scanning text', TEXT: text, pattern: PATTERNS[0], offset: 0 });
  let state = 0;
  for (let i = 0; i < text.length; i++) {
    steps.push({
      type: 'scan',
      msg: `Read T[${i}]='${text[i]}'`,
      TEXT: text,
      pattern: PATTERNS[0],
      offset: Math.max(0, i - 1),
      i,
      state,
    });
    steps.push({
      type: 'transition',
      msg: `Try advance with '${text[i]}' (failure links if needed)`,
      TEXT: text,
      pattern: PATTERNS[0],
      offset: i,
      i,
      state,
    });
  }
  steps.push({ type: 'done', msg: 'Scan complete (simplified finite automaton view)', TEXT: text, pattern: PATTERNS[0], offset: Math.max(0, text.length - 2) });
  return steps;
}

function generateSteps() {
  const { steps: tSteps } = buildTrieSteps();
  const failSteps = PATTERNS.flatMap((p, idx) => [
    { type: 'fail', msg: `Failure link for pattern ${idx} ("${p}")`, TEXT, pattern: p, offset: 0, table: [idx, p.length], tableLabel: 'pat | len' },
  ]);
  const sSteps = searchSteps(TEXT, {});
  return [...tSteps, ...failSteps, ...sSteps];
}

function paint(step) {
  const text = step.TEXT;
  const pat = step.pattern || PATTERNS[0];
  const textColors = {};
  const patternColors = {};
  if (step.i != null) textColors[step.i] = 'current';
  if (step.k != null) patternColors[step.k] = 'match';
  return {
    text: text.split(''),
    pattern: pat.split(''),
    textColors,
    patternColors,
    offset: step.offset ?? 0,
    table: step.table || null,
    tableLabel: step.tableLabel || '',
    matchPositions: [],
    comparePairs: step.i != null ? [[step.i, 0]] : null,
  };
}

export default function AhoCorasickVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Aho–Corasick: trie + failure + scan' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
