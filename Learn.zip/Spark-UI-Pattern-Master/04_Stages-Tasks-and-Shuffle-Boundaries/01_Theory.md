# Stages, Tasks & Shuffle Boundaries — How a Job Splits

Job ek bada container hai. Stages aur tasks usi job ke andar ki real execution units hain. Yeh pattern teach karta hai *kaise* DAGScheduler ek job ko stages mein todta hai, aur kyu ek stage mein exactly itne tasks hote hain.

**DSA Analogy**: Topological sort over a DAG with edge cuts at expensive operations. Har "cut" (shuffle) ek stage boundary banata hai. Ek stage = ek pipelined chunk of work.

---

## Core Idea (2 Lines)

DAGScheduler kisi bhi job ko stages mein todta hai **shuffle boundaries** par. Ek stage ke andar **task count = output partitions of that stage** — har task ek partition compute karta hai, parallelly across executors.

---

## The Golden Rule

```
+-----------+        narrow ops          +-----------+        shuffle         +-----------+
| Stage S0  |  --pipelined within S0 -->  | Stage S0  |  ---- BOUNDARY ----->  | Stage S1  |
+-----------+                             +-----------+                        +-----------+
```

| Operation Type    | Stage Effect                                | Examples                                      |
|-------------------|---------------------------------------------|-----------------------------------------------|
| **Narrow**        | Pipelined into the *current* stage          | `select`, `filter`, `withColumn`, `map`, `union`, narrow `limit` |
| **Wide (Shuffle)**| **Closes** current stage, **opens** new one | `groupBy().agg`, `join`, `repartition`, `distinct`, `orderBy`, `window` |

> Spark DAGScheduler walks the physical plan bottom-up; every `Exchange` operator becomes a stage boundary.

---

## Visual: Code → Stages

```python
df = spark.read.parquet("...")            # Stage S0 (start)
       .withColumn("v2", col("v")*2)      # narrow -> still S0
       .filter(col("v2") > 10)            # narrow -> still S0
       .repartition(6, "k")               # WIDE   -> close S0, open S1
       .groupBy("k").sum("v2")            # WIDE   -> close S1, open S2
       .write.parquet("...")              # narrow write within S2
```

UI shows **3 stages** for the write job:
```
S0  Scan + withColumn + filter + shuffle write       (16 tasks if 16 input parts)
S1  shuffle read + groupBy partial-agg + shuffle write (6 tasks  -- 6 = repartition arg)
S2  shuffle read + final-agg + write                  (8 tasks  -- = shuffle.partitions=8)
```

> Note: After the *first* shuffle, partitions count = `repartition`'s argument (6). After the second shuffle, partitions count = `spark.sql.shuffle.partitions` (8). That's why each post-shuffle stage has a different task count.

---

## Task Count Per Stage — Where Does It Come From?

| Stage Type                 | Task Count =                                                |
|----------------------------|--------------------------------------------------------------|
| Source-reading stage       | Number of input partitions (e.g. parquet file count, or `defaultParallelism` for `parallelize`) |
| Post-shuffle stage         | Configured shuffle partitions (`spark.sql.shuffle.partitions`, default 200) |
| After `repartition(N)`     | `N`                                                          |
| After `coalesce(N)`        | `N` (no shuffle, but task count of next stage = N)           |
| Final reduce of `count()`  | Always 1 (single-task aggregate)                             |
| AQE post-coalesce          | < `shuffle.partitions` (AQE merges small partitions)         |

```
"Task count" is literally "output partition count of that stage".
1 task = 1 partition = 1 unit of executor work.
```

---

## Worked Example — The 5-Job Reference Run

For `master("local[*]")` (16 cores), `spark.sql.shuffle.partitions = 8`, AQE off, the 5 jobs split into stages like this:

### Job 0 — `count()`  ·  3 stages, 23 tasks (16 + 6 + 1)

```
S0  16 tasks   createDataFrame parallelize -> withColumn -> shuffle write for repartition(6,"k")
S1   6 tasks   shuffle read (6) -> filter -> cache materialize -> partial agg -> shuffle write
S2   1 task    shuffle read -> final count agg
```

**Why 16?** `local[*]` has 16 cores → `defaultParallelism = 16` → `createDataFrame` parallelize creates 16 partitions.
**Why 6?** `repartition(6, "category")` explicitly sets 6.
**Why 1?** `count()` final aggregate is a single-task reduce (no GROUP BY).

### Job 4 — `collect()`  ·  ~2 active stages, 14 tasks (6 + 8)

```
S6 (active)   6 tasks  read 6 cached partitions -> withColumn(category_group) for df2
S7 (active)   8 tasks  shuffle read of df_final's final aggregation (shuffle.partitions=8)
S5 (skipped) 16 tasks  upstream output already produced earlier (Pattern 05)
```

### Jobs 1, 2, 3 — `show()`  ·  varying tasks each

```
Job 1   2 active stages, 7 tasks  (6 + 1)   16 skipped
Job 2   1 active stage,  4 tasks            22 skipped
Job 3   1 active stage,  3 tasks            22 skipped
```

(See Pattern 05 for *why* the active counts decrease — shuffle output reuse.)

---

## Why Narrow Ops Don't Create New Stages

Narrow operations process each partition **independently** — no data exchange between executors. Therefore Spark **fuses them** into a single pipeline (also code-generated as one Java function via Tungsten "WholeStageCodegen").

```
Stage S0
+--------------------------------------------+
| InputPartition 0:                          |
|   read row -> filter -> map -> count out   |
| InputPartition 1:                          |
|   read row -> filter -> map -> count out   |
| ... 16 partitions in parallel ...          |
+--------------------------------------------+
```

> If you ever add `.explain()` and see `WholeStageCodegen (1)`, that's the entire fused stage shown as one operator block.

---

## Why Wide Ops Create a New Stage

Wide operations need **data exchange** — every executor must send/receive bytes from every other executor. The receiving side cannot start until the sending side's *map* output is fully written.

```
                       SHUFFLE BOUNDARY
                              |
S0  Map Stage           |     |    S1  Reduce Stage
+----------+--+--+--+   v     |    +----------+----+----+
| Tasks 0..15   |  ----+      |    | Tasks 0..7  |
|   write       |             |    |   read all maps' bytes for partition i
|   (m, K, V)   |  ----+      |    |   process, optionally agg/sort
+----------+----+      |     v     +----------+
                       +-----+
            (network sort + serialization)
```

This boundary **must** be a new stage in the UI because:
1. Tasks of S1 cannot start until S0's tasks finish.
2. The mapping from input to output partition changes (e.g. by hash).
3. Spark stores S0's output as **shuffle files** on each executor's local disk.

---

## Stage Page Anatomy

```
Details for Stage 1 (Stage 1 of Job 0):
+--------+----------+--------------+---------------+--------+
| Tasks  | Total Time| Shuffle Read | Shuffle Write | Spill |
+--------+----------+--------------+---------------+--------+
|  6/6   |  6.5 s    |    240 MB    |    180 MB     |  0    |
+--------+----------+--------------+---------------+--------+

Summary metrics (showing percentiles across tasks):
              Min    25th   Median   75th    Max
Duration     0.9s   1.0s    1.05s   1.1s    1.2s     <- healthy
Shuffle R    38MB   39MB     40MB   41MB    42MB
Shuffle W    28MB   29MB     30MB   31MB    32MB
Spill (mem)   0      0        0      0       0
GC time      40ms   45ms     50ms   55ms    60ms
```

| Block                 | What to Read                                                |
|-----------------------|-------------------------------------------------------------|
| Header counts         | Tasks succeeded / total                                     |
| Time                  | Wall clock for the stage                                    |
| Shuffle Read / Write  | Bytes moved across network                                  |
| Summary Metrics table | The most important section — covers Pattern 08 skew detection |
| Per-task table (below)| Use to find the *one* slow task                             |

---

## Common Mistakes

| Mistake                                              | Why                                                              | Fix                                                                  |
|------------------------------------------------------|------------------------------------------------------------------|----------------------------------------------------------------------|
| Counting `select + filter` as separate stages        | They're narrow → pipelined                                       | Same stage; only `Exchange` creates boundaries                       |
| Treating `count()` as 1 stage                        | Final agg may be 1 task, but upstream may have shuffles          | Stage count = number of shuffles + 1                                 |
| Expecting `repartition(N)` to take effect "next call"| Repartition adds a shuffle stage immediately                     | The N appears as task count of the *next* stage                      |
| Confusing 200 default with task count after coalesce | `coalesce` is narrow, no shuffle.partitions involved             | After coalesce(N) → next stage has N tasks                           |
| Reading shuffle bytes per task instead of total      | Per-task UI shows individual; sum to get stage total             | Use the "Shuffle Read/Write" header column                           |
| Asking "how many stages will my job have?"           | Depends on lineage — count `Exchange` ops in physical plan       | `df.explain()` shows the answer                                      |

---

## Predicting Stage Count Without Running

```
Steps:
1. Look at the physical plan (df.explain("formatted")).
2. Count the Exchange operators -> that's the number of shuffle boundaries.
3. stage_count = exchange_count + 1
4. Task count of stage k = output partitions of operator below the k-th Exchange.
```

```python
df.explain("formatted")
# Look for:
#   == Physical Plan ==
#   * HashAggregate (final)
#   +- Exchange ...                    <-- shuffle boundary
#      +- HashAggregate (partial)
#         +- Project
#            +- Filter
#               +- Scan ...
# Stages = 2 (one shuffle).
```

---

## Stage Boundary Cheat Table

| Operator (Physical Plan) | Creates a Boundary? |
|---------------------------|---------------------|
| Scan (parquet/csv/orc/json) | start of stage    |
| Project                     | no                |
| Filter                      | no                |
| Sort                        | yes (full sort uses shuffle) |
| Exchange (any partitioning) | YES               |
| HashAggregate (partial)     | no                |
| HashAggregate (final)       | no                |
| ShuffledHashJoin            | YES (both children) |
| SortMergeJoin               | YES (both children) |
| BroadcastHashJoin           | NO (small side broadcast, no shuffle) |
| BroadcastExchange           | adds a side-channel exchange but child stage may still pipeline |
| WholeStageCodegen           | groups operators in one stage; not a boundary itself |
| Limit / GlobalLimit         | sometimes (uses Exchange to single partition) |
| Window                      | YES (needs partitioning + sort) |

---

## Why Some Jobs Have a "1 task" Stage at the End

Aggregations like `count()`, `sum()`, `min()`, `max()` produce a single global value. After partial aggregates run in N tasks, a final 1-task reduce stage gathers and combines.

```
Job 0 (count) tail:
  Stage S1   6 tasks  partial agg + shuffle write
  Stage S2   1 task   final agg   <-- always 1
```

---

## Why Source-Reading Stages Have "weird" Task Counts

| Source                                      | Task Count Source                       |
|---------------------------------------------|------------------------------------------|
| `spark.read.parquet(path)`                   | `defaultMaxSplitBytes` based on file sizes (default 128 MB chunks) |
| Many small files                             | Up to `openCostInBytes / file count`     |
| `spark.createDataFrame(python_list)`         | `defaultParallelism` (= core count for local) |
| `spark.range(n)`                             | `defaultParallelism` (or specified)      |
| Hive partitioned tables                       | One per matched file split              |

---

## Real-World Use Cases

```
1. "Why does my groupBy job have 2 stages, not 1?"
   - Partial agg + shuffle + final agg = always 2 stages minimum.

2. "I added repartition(200) and got more tasks but slower."
   - Stage's task count went 8 -> 200, each task does 1/25 the work,
     but shuffle/network overhead grew.

3. "Stage 2 has 200 tasks but my data is only 100 MB."
   - Default shuffle.partitions = 200 is overkill for small data.
     Set spark.sql.shuffle.partitions to a sensible number.

4. "Final stage is always 1 task, even with 200 partitions configured."
   - That's the global reduce of count/sum/min/max — by design.

5. "Where does Catalyst show me stages?"
   - df.explain() shows operators; UI groups them into stages
     at every Exchange.
```

---

## When To Repartition Manually

| Symptom                                              | Fix                                                               |
|------------------------------------------------------|-------------------------------------------------------------------|
| Stage has 200 tasks but data is tiny (~ MB)           | `df.coalesce(N)` to reduce post-shuffle parallelism               |
| Stage has 4 tasks but data is huge (GB)               | `df.repartition(N)` to increase parallelism                       |
| Skew (one task very long)                             | `df.repartition(N, col("key_with_salt"))` (Pattern 08)            |
| Right before write to many small files                | `df.coalesce(target_file_count)`                                  |

---

## Cross-References

| Topic                                       | Pattern |
|---------------------------------------------|---------|
| Why some stages show "skipped"              | 05      |
| What "Exchange" means in physical plan      | 06      |
| How to spot one slow task in a stage        | 08      |
| The job-level view above stages             | 02      |

---

## Key Takeaway

> Stages = pipelined chunks; boundaries are shuffles; tasks-per-stage = output partitions of that stage.
> Aggregates have a final 1-task stage. Repartitions force a new stage with the configured partition count. Once you can predict (stage_count, task_count) for any code without running it, you've internalized the DAGScheduler's logic.
