# SQL Interview Mastery — Common Mistakes

| Mistake | Impact | Fix |
|---------|--------|-----|
| Jumping to code without reading | Wrong approach | Clarify grain + entity first |
| Forgetting NULLs | Wrong results | Say "what if col is NULL?" |
| Window alias in WHERE | Syntax error | CTE → filter in outer |
| SELECT col not in GROUP BY | Error / wrong answer | All non-agg cols in GROUP BY |
| NOT IN with nullable subquery | Empty result | Use NOT EXISTS |
| Cartesian from missing ON | Row explosion | Always specify join predicate |
| Using RANK when need DENSE_RANK | Gaps in ranking | Know the trio: ROW_NUMBER/RANK/DENSE_RANK |
| Ignoring ties | Wrong Top-N | Discuss tie-breaking with interviewer |

---

*Next: [[06_Edge-Cases]]*
