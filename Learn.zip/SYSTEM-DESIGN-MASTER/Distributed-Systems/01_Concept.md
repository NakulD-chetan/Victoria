# Distributed Systems — Concept

> **Permanent Recall:** Distributed systems are collections of nodes that work together over a network, facing fundamental challenges: network unreliability, clock skew, and partial failures. The Eight Fallacies remind us what not to assume. Consensus (Paxos, Raft, Zab), leader election, distributed locks, ZooKeeper for coordination, heartbeats, split brain mitigation, gossip protocols, and clock synchronization (NTP, Lamport, vector clocks) are core building blocks. DHTs enable scalable key lookups without central coordination. Master these for FAANG system design.

---

## What Are Distributed Systems and Why They Exist

**Definition:** Multiple nodes communicating over a network to achieve a common goal, appearing as a single system. No shared memory; coordination via messages.

| Goal | Benefit |
|------|----------|
| **Scalability** | Add nodes to handle more load |
| **Fault tolerance** | Survive node/network failures |
| **Geographic distribution** | Lower latency, data locality |
| **Availability** | 24/7 service despite failures |

---

## Fundamental Challenges

| Challenge | Problem | Impact |
|-----------|---------|--------|
| **Network unreliability** | Messages lost, delayed, reordered | Consensus harder, timeouts needed |
| **Clock skew** | No global clock; nodes drift | Ordering, LWW wrong, distributed locking |
| **Partial failures** | Some nodes work, some don't | Must design for "maybe" semantics |

> **FAANG Tip:** Never assume "it worked once, it'll work again." Design for failures.

---

## The Eight Fallacies of Distributed Computing

| Fallacy | Reality |
|---------|---------|
| 1. The network is reliable | Networks partition, drop packets |
| 2. Latency is zero | Every message has cost |
| 3. Bandwidth is infinite | Congestion happens |
| 4. The network is secure | Must encrypt, authenticate |
| 5. Topology doesn't change | Nodes join/leave |
| 6. There is one administrator | Multi-tenant, shared infra |
| 7. Transport cost is zero | Serialization, CPU matter |
| 8. The network is homogeneous | Mixed infra, versions |

---

## Consensus Algorithms Overview

**Purpose:** Agree on a single value or sequence despite failures.

| Algorithm | Used By | Key Idea |
|-----------|---------|----------|
| **Paxos** | Chubby, early systems | Proposer-acceptor-learner; complex; proven correct |
| **Raft** | etcd, Consul, CockroachDB | Leader election + log replication; more practical |
| **Zab** | ZooKeeper | Leader-based, similar to Raft; atomic broadcast |

**Paxos (how it works):** Proposer proposes value; acceptors vote; majority = chosen. Phase 1: prepare; Phase 2: accept. Multiple rounds possible.

**Raft:** Elect a leader; leader replicates log to followers; majority acknowledges = committed. Simpler to understand and implement.

**Zab:** Used by ZooKeeper. Leader proposes; followers ack; leader commits when quorum acks.

---

## Raft Leader Election — ASCII Diagram

```
RAFT LEADER ELECTION:

  Node A (follower)    Node B (candidate)    Node C (follower)
  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐
  │ term: 2     │      │ term: 2      │      │ term: 2      │
  │ state: F    │      │ state: C     │      │ state: F     │
  └──────┬──────┘      └──────┬──────┘      └──────┬──────┘
         │                    │ RequestVote         │
         │◄───────────────────┼────────────────────┤
         │   Vote for B        │                    │ Vote for B
         ├────────────────────┼───────────────────►│
         │                    │   Majority!        │
         │                    │ Become LEADER      │
         │                    ▼                    │
         │             ┌──────────────┐            │
         │             │ LEADER       │            │
         │             │ AppendEntries│────────────┼────►
         └─────────────┴──────────────┴────────────┘
```

---

## Leader Election Algorithms

| Algorithm | How It Works | Use Case |
|-----------|--------------|----------|
| **Bully** | Highest ID wins; lower IDs yield | Simple; not fault-tolerant on ID assumptions |
| **Ring** | Pass token; first to receive nomination wins | Ring topology |
| **Raft-based** | Quorum votes; term-based; proven | etcd, Consul, production |

---

## Distributed Locking

| Approach | How It Works | Pitfall |
|----------|--------------|---------|
| **Redis RedLock** | Lock on N/2+1 Redis instances; quorum to acquire | Clock skew can cause dual holders |
| **ZooKeeper locks** | Ephemeral sequential nodes; lowest owns lock | Need fencing tokens |
| **Fencing tokens** | Monotonic token; reject lower; prevents stale lock holder | Must implement! |

> **FAANG Tip:** Always use fencing tokens with distributed locks. A slow client can hold lock past expiry.

---

## ZooKeeper — Distributed Coordination

**What it does:** Centralized coordination service. Provides: configuration, naming, distributed locks, leader election, barriers.

| Use Case | How ZooKeeper Helps |
|----------|---------------------|
| **Config** | Store key-value config; watchers for updates |
| **Leader election** | Ephemeral node = leader; others watch |
| **Locks** | Sequential ephemeral nodes; lowest holds |
| **Service discovery** | Register under path; clients discover |

---

## Heartbeat Mechanisms

**Purpose:** Detect dead nodes. Nodes periodically send "I'm alive" to peers.

```
HEARTBEAT FLOW:

  Node A                Node B                Node C
  ┌─────┐               ┌─────┐               ┌─────┐
  │     │──heartbeat───►│     │               │     │
  │     │◄──heartbeat───│     │◄──heartbeat───│     │
  └─────┘               └─────┘               └─────┘
       │                      │
       └── No heartbeat in T ──┘  → Mark B as suspect/dead
```

**Parameters:** Interval (how often), timeout (how long before "dead"). Too short = false positives; too long = slow failure detection.

---

## Split Brain Problem and Solutions

**What:** Partition causes two subsets to each believe they have the leader. Both accept writes → data divergence.

| Solution | How |
|----------|-----|
| **Quorum** | Only majority can elect; odd N (3, 5) ensures one side has majority |
| **Witness/arbitrator** | Tie-breaker node in third location |
| **Fencing** | Reject requests from "old" leader via fencing token |

---

## Gossip Protocol — ASCII Diagram

```
GOSSIP: Epidemic information dissemination

  Round 1:     A ──► B, C (A tells 2 random peers)
  Round 2:     B ──► D, E;  C ──► F, G
  Round 3:     Each tells 2 more...
  
  ┌───┐   ┌───┐   ┌───┐
  │ A │──►│ B │──►│ D │
  └─┬─┘   └─┬─┘   └───┘
    │       │
    ▼       ▼
  ┌───┐   ┌───┐
  │ C │──►│ E │  ... eventually all know
  └─┬─┘   └───┘
    ▼
  ┌───┐
  │ F │
  └───┘
```

**Properties:** Eventually consistent; no single point of failure; O(log N) rounds to reach all. Used in Cassandra, Dynamo.

---

## Clock Synchronization

| Approach | Purpose |
|----------|---------|
| **NTP** | Sync wall clocks; milliseconds accuracy |
| **Logical clocks (Lamport)** | Order events without global time; increment on send/receive |
| **Lamport timestamps** | (counter, node_id); capture causality |
| **Vector clocks** | [A:n, B:m, ...]; detect concurrent events |

**Lamport:** If A happens before B, L(A) < L(B). Converse not true.

**Vector clocks:** Can detect concurrent: neither vector "happens-before" the other.

---

## Distributed Hash Tables (DHT)

**Purpose:** Map keys to nodes without central lookup. Each node knows a portion of the key space.

| Property | Benefit |
|----------|---------|
| **Decentralized** | No single point of failure |
| **Scalable** | O(log N) hops to find key |
| **Examples** | Chord, Kademlia, Cassandra (DHT-like) |

---

## 30-SECOND REVISION BOX

```
DISTRIBUTED: Nodes + network; partial failures, no global clock
8 FALLACIES: Network unreliable, latency, etc.
CONSENSUS: Paxos (complex), Raft (practical), Zab (ZK)
LEADER: Bully, Ring, Raft (quorum)
LOCKS: RedLock, ZK + fencing token
ZK: Config, leader, locks, discovery
SPLIT BRAIN: Quorum, odd N
GOSSIP: Epidemic, O(log N) convergence
CLOCKS: NTP, Lamport, vector
DHT: Chord, Kademlia
```

---

**Next: [[02_Mental-Model]]**
