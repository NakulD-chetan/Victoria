# SQL Foundation — Concept

> **Permanent recall:** SQL = structured way to **define**, **insert/update/delete**, and **read** relational data. Interviews care that you know **keys**, **constraints**, and **which statement is DDL vs DML vs DQL**.

---

## Core idea (2 lines)

**Tables = rows + columns. Keys + constraints keep data honest. DDL shapes the schema; DML/DQL changes and reads rows.**

---

## DBMS vs RDBMS

| Term | Meaning |
|------|---------|
| **DBMS** | Software to store/manage data (any model — hierarchical, network, file). Examples: XML stores, file systems. |
| **RDBMS** | DBMS where data is **tables** + **relations** enforced by constraints (MySQL, PostgreSQL, SQL Server, Oracle, SQLite). |

**Key difference:** RDBMS enforces **referential integrity** (FK), supports **ACID**, and uses **SQL** as query language. Plain DBMS may not.

---

## SQL sub-languages (must know names)

| Family | Statements | Role |
|--------|------------|------|
| **DDL** | `CREATE`, `ALTER`, `DROP`, `TRUNCATE`, `RENAME` | Schema / structure |
| **DML** | `INSERT`, `UPDATE`, `DELETE`, `MERGE` | Row data |
| **DQL** | `SELECT` | Query (often grouped with DML in interviews) |
| **DCL** | `GRANT`, `REVOKE` | Permissions |
| **TCL** | `COMMIT`, `ROLLBACK`, `SAVEPOINT` | Transaction control |

> **Interview tip:** Some interviewers count only 3 (DDL, DML, DCL). Know all 5 but don't argue — say "some classifications include TCL and DQL separately."

---

## Keys (interview rapid-fire)

| Key | Definition | Example |
|-----|------------|---------|
| **Primary key** | Unique + NOT NULL; one per table; row identity. | `emp_id INT PRIMARY KEY` |
| **Foreign key** | Column(s) referencing another table's PK/unique key; enforces referential integrity. | `dept_id INT REFERENCES departments(dept_id)` |
| **Candidate key** | Any minimal column set that *could* be PK. A table can have multiple. | `{email}`, `{phone}` both unique → both candidates |
| **Composite key** | Key made of **multiple columns** together. | `PRIMARY KEY (student_id, course_id)` |
| **Super key** | Any set of columns that uniquely identifies rows (may include extra columns). | `{emp_id, name}` is super key if `emp_id` alone is unique |
| **Alternate key** | Candidate keys NOT chosen as PK. | If PK = `emp_id`, then `email` is alternate key |
| **Unique key** | Enforces uniqueness; allows ONE NULL (in most DBs). | `email VARCHAR(255) UNIQUE` |
| **Natural key** | Business-meaningful key (email, SSN). | `email` as PK |
| **Surrogate key** | System-generated artificial key (auto-increment, UUID). | `id SERIAL PRIMARY KEY` |

---

## Constraints (detailed)

| Constraint | What it does |
|-----------|-------------|
| `NOT NULL` | Column cannot hold NULL |
| `UNIQUE` | All values in column must be distinct (allows one NULL in most DBs) |
| `PRIMARY KEY` | `NOT NULL` + `UNIQUE`; one per table |
| `FOREIGN KEY` | Links to PK/UNIQUE in parent table |
| `CHECK` | Custom boolean condition (`CHECK (age >= 18)`) |
| `DEFAULT` | Auto-fills value if not provided (`DEFAULT CURRENT_TIMESTAMP`) |

### FK Actions (ON DELETE / ON UPDATE)

| Action | Behavior |
|--------|----------|
| `CASCADE` | Delete/update parent → automatically delete/update child rows |
| `SET NULL` | Delete/update parent → set FK column to NULL in child |
| `SET DEFAULT` | Set FK to its DEFAULT value |
| `RESTRICT` | Block parent delete/update if child rows exist (checked immediately) |
| `NO ACTION` | Similar to RESTRICT but checked at end of statement (default in most DBs) |

---

## Data Integrity Types

| Type | Enforced by | Meaning |
|------|-------------|---------|
| **Entity integrity** | Primary Key | Every row is uniquely identifiable; PK never NULL |
| **Referential integrity** | Foreign Key | Every FK value must match an existing PK (or be NULL) |
| **Domain integrity** | CHECK, NOT NULL, Data Types | Column values stay within allowed range/type |
| **User-defined integrity** | Triggers, Stored Procs | Custom business rules (e.g., salary < manager's salary) |

---

## Data types (recognize in interviews)

| Category | Types | Notes |
|----------|-------|-------|
| Numbers | `INT`, `BIGINT`, `SMALLINT`, `DECIMAL(p,s)`, `NUMERIC`, `FLOAT`/`REAL` | `DECIMAL` for money (exact); `FLOAT` for science (approximate) |
| Text | `CHAR(n)` (fixed), `VARCHAR(n)` (variable), `TEXT` | `CHAR` pads with spaces; `VARCHAR` saves space |
| Date/Time | `DATE`, `TIME`, `TIMESTAMP`/`DATETIME`, `INTERVAL` | `TIMESTAMP` includes date+time; `INTERVAL` for arithmetic |
| Boolean | `BOOLEAN` (Postgres); `BIT`/`TINYINT(1)` (MySQL/SQL Server) | |
| Binary | `BLOB`, `BYTEA`, `VARBINARY` | For files/images (avoid in interviews) |
| JSON | `JSON`, `JSONB` (Postgres) | Semi-structured data in relational DB |

---

## DELETE vs TRUNCATE vs DROP (detailed comparison)

| Feature | DELETE | TRUNCATE | DROP |
|---------|--------|----------|------|
| **What it removes** | Specific rows (with WHERE) or all rows | All rows only | Entire table (structure + data) |
| **WHERE clause** | Yes | No | N/A |
| **Speed** | Slower (row-by-row logging) | Faster (deallocates pages) | Fastest |
| **Logging** | Fully logged (each row) | Minimally logged | Logged |
| **Rollback** | Yes (within transaction) | Depends on DB (Yes in Postgres/SQL Server; No in MySQL with autocommit) | Depends on DB |
| **Triggers** | Fires DELETE triggers | Does NOT fire triggers | Does NOT fire triggers |
| **Identity/Auto-increment** | Does NOT reset | Resets counter | N/A |
| **FK constraints** | Works if no FK violation | Blocked if FK references exist | Blocked if FK references exist |
| **SQL family** | DML | DDL (in most DBs) | DDL |
| **UNDO** | Possible | Engine-dependent | Engine-dependent |

---

## SQL vs NoSQL (quick comparison)

| Aspect | SQL (Relational) | NoSQL |
|--------|-------------------|-------|
| **Schema** | Fixed schema (tables, columns, types) | Flexible/dynamic schema |
| **Data model** | Tables with rows/columns | Document, Key-Value, Column-family, Graph |
| **Query language** | SQL (standardized) | Varies (MongoDB query, CQL, etc.) |
| **Transactions** | ACID guaranteed | Usually BASE (Eventually consistent) |
| **Joins** | Native support | Usually no joins (denormalized) |
| **Scaling** | Vertical (scale up) | Horizontal (scale out / sharding) |
| **Best for** | Structured data, complex queries, OLTP | Big data, real-time, flexible schema, high write throughput |
| **Examples** | MySQL, PostgreSQL, Oracle, SQL Server | MongoDB, Cassandra, Redis, Neo4j, DynamoDB |

> **BASE** = Basically Available, Soft state, Eventually consistent

---

## One-sentence definitions (interview ready)

| Term | Definition |
|------|-----------|
| **Schema** | Blueprint of DB — tables, columns, types, constraints, relationships |
| **Tuple / Row** | One record in a table |
| **Attribute / Column** | One field in a table |
| **Relation / Table** | Set of rows of same structure |
| **Degree** | Number of columns in a table |
| **Cardinality** | Number of rows in a table (also: relationship type — 1:1, 1:N, M:N) |
| **Domain** | Set of allowed values for a column |
| **NULL** | Unknown or missing value — NOT zero, NOT empty string |
| **Alias** | Temporary name for table/column (`AS`) |
| **Clause** | Component of SQL statement (SELECT, FROM, WHERE, etc.) |
| **Predicate** | Condition that evaluates to TRUE/FALSE/UNKNOWN |
| **Transaction** | Logical unit of work — all or nothing |

---

## Relationship Types

| Type | Meaning | Implementation |
|------|---------|----------------|
| **One-to-One** | One row in A maps to exactly one in B | FK with UNIQUE constraint, or shared PK |
| **One-to-Many** | One row in A maps to many in B | FK in the "many" side table |
| **Many-to-Many** | Many rows in A map to many in B | Junction/bridge table with two FKs |

---

*Next: [[02_Mental-Model]]*
