# Clauses and Execution — Problem List

> **20 problems in progressive difficulty. 8 MUST-DO highlighted. Focus: WHERE, ORDER BY, CASE WHEN, execution order awareness.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Recyclable and Low Fat Products | Easy | 1757 | WHERE + AND | Foundation multi-condition filter |
| 2 | Find Customer Referee | Easy | 584 | NULL in WHERE | The NULL != trap everyone falls for |
| 3 | Patients With a Condition | Easy | 1527 | LIKE + wildcard | Pattern matching in WHERE |
| 4 | Calculate Special Bonus | Easy | 1873 | CASE WHEN + MOD | Conditional logic in SELECT |
| 5 | Not Boring Movies | Easy | 608 | AND/OR + ORDER BY | Multi-clause query |
| 6 | List the Products Ordered in a Period | Easy | 1327 | WHERE date range + GROUP | Date filtering + aggregation |
| 7 | Biggest Single Number | Easy | 619 | HAVING COUNT = 1 + MAX | GROUP BY + HAVING + subquery |
| 8 | Immediate Food Delivery II | Medium | 1174 | CASE + date comparison | Conditional aggregation |

---

## Complete 20-Problem Progression

### Easy — WHERE + Filtering (Problems 1-10)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Recyclable and Low Fat Products | 1757 | WHERE AND | Two conditions |
| 2 | Find Customer Referee | 584 | NULL trap | IS NULL OR != |
| 3 | Big Countries | 595 | WHERE OR | area OR population |
| 4 | Patients With a Condition | 1527 | LIKE '%X%' | Space-prefixed LIKE |
| 5 | Not Boring Movies | 608 | MOD + ORDER BY | id % 2 != 0 AND description != 'boring' |
| 6 | Calculate Special Bonus | 1873 | CASE WHEN | Conditional output column |
| 7 | Swap Salary | 627 | CASE in UPDATE | In-place conditional update |
| 8 | Employees With Missing Information | 1965 | UNION + NOT IN | Combine two anti-patterns |
| 9 | Rearrange Products Table | 1795 | UNION ALL | Wide to long transformation |
| 10 | The Latest Login in 2020 | 1890 | WHERE YEAR + MAX | Date extract + aggregate |

### Medium — ORDER BY, CASE, Execution Order (Problems 11-20)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Biggest Single Number | 619 | HAVING COUNT = 1 | Unique value detection |
| 12 | List Products Ordered in a Period | 1327 | Date range + GROUP | BETWEEN on dates |
| 13 | Immediate Food Delivery II | 1174 | CASE + MIN | First order = delivery check |
| 14 | Game Play Analysis I | 511 | MIN per group | First login date |
| 15 | Daily Leads and Partners | 1693 | COUNT DISTINCT + GROUP | Multi-column GROUP BY |
| 16 | Actors and Directors Who Cooperated ≥ 3 Times | 1050 | GROUP + HAVING ≥ 3 | Pair grouping |
| 17 | Product Sales Analysis I | 1068 | JOIN + SELECT specific cols | Choose correct columns |
| 18 | Average Selling Price | 1251 | Weighted AVG via CASE/JOIN | SUM(price*units)/SUM(units) |
| 19 | Queries Quality and Percentage | 1211 | AVG + CASE | Conditional average |
| 20 | Confirmation Rate | 1934 | AVG(CASE WHEN) | Ratio via conditional agg |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Find Customer Referee (LC 584)
```
Type: NULL-aware WHERE
Key: WHERE referee_id != 2 OR referee_id IS NULL
Trap: != operator returns UNKNOWN for NULL → row excluded
One-liner: Always think "what if this column is NULL?" in every WHERE.
```

### Problem 5: Not Boring Movies (LC 608)
```
Type: Multi-clause
Key: WHERE id % 2 = 1 AND description != 'boring' ORDER BY rating DESC
One-liner: Combine MOD, string inequality, and sort — tests clause ordering.
```

### Problem 11: Biggest Single Number (LC 619)
```
Type: HAVING + subquery
Key: SELECT MAX(num) FROM (SELECT num FROM … GROUP BY num HAVING COUNT(*)=1) t
One-liner: Find nums appearing once, then MAX — tests GROUP BY → HAVING → outer.
```

### Problem 20: Confirmation Rate (LC 1934)
```
Type: Conditional aggregation
Key: AVG(CASE WHEN action='confirmed' THEN 1 ELSE 0 END)
One-liner: Pattern for computing ratios — FAANG favorite.
```

---

## Pattern Distribution

```
WHERE BASICS:           5 problems  (1-4, 8)
CASE WHEN:              4 problems  (6, 7, 13, 20)
ORDER BY:               2 problems  (5, 14)
DATE FILTERING:         3 problems  (10, 12, 13)
GROUP + HAVING:         4 problems  (11, 15, 16, 19)
CONDITIONAL AGG:        2 problems  (18, 20)
```

---

## Weekly Study Plan

### Day 1-2: WHERE mastery
- Problems 1-5 (NULL, LIKE, OR, MOD)

### Day 3-4: CASE + Date
- Problems 6-10 (CASE WHEN, UNION, dates)

### Day 5-6: GROUP + HAVING
- Problems 11-16 (HAVING, COUNT DISTINCT, pair grouping)

### Day 7: Conditional Aggregation
- Problems 17-20 (weighted AVG, CASE in AVG, ratios)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (12 Easy, 8 Medium)
MUST-DO:            LC 1757, 584, 1527, 1873, 608, 1327, 619, 1174
TOP 3 MOST ASKED:   LC 584 (NULL), LC 1873 (CASE), LC 1934 (Confirmation Rate)
PATTERN SPLIT:      WHERE (5), CASE (4), ORDER/DATE (5), GROUP+HAVING (4), Cond Agg (2)
STUDY ORDER:        WHERE → CASE → Dates → GROUP+HAVING → Conditional Aggregation
INTERVIEW LINE:     "I always check NULL behavior in WHERE and prefer
                     CASE WHEN inside AVG for ratio calculations."
```
