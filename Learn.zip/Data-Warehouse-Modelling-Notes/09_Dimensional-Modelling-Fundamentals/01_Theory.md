# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}

==================================================

1. WHAT IS DIMENSIONAL MODELING

==================================================

Key idea:

- Organize data so business users can easily:
→ filter
→ group
→ aggregate

Goal:

- Make analytics simple and consistent

---

## Important Quote Meaning

the level of detail of a table -->grain

"Grain is a promise"

Meaning:

- Each row in table must represent EXACTLY one thing
- If you break this → wrong results

==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Dimensional modeling:

- Focuses on business processes
- Uses:
→ Fact tables (numbers)
→ Dimension tables (context)

Important rule:

- Define grain FIRST before anything

==================================================
3. KIMBALL 4 STEPS (VERY IMPORTANT)
==================================================

---

## Step 1: Choose Business Process

Question:

- What are we analyzing?

Example:

- POS sales

---

## Step 2: Declare Grain

Question:

- One row = what?

Example:

- One row = one item sold in a receipt

---

## Step 3: Choose Dimensions

Question:

- What describes the data?

Example:

- product
- store
- date
- promotion

---

## Step 4: Identify Facts

Question:

- What numbers?

Example:

- sales amount
- quantity
- discount

---

## IMPORTANT ORDER

Process → Grain → Dimensions → Facts

Never skip grain

==================================================
4. WHAT IS GRAIN (VERY IMPORTANT)
==================================================

Grain = smallest level of data stored

---

## Examples

1. POS Line

- One row = one item in receipt

1. Basket

- One row = full receipt

1. Daily Store

- One row = total sales per day

1. Hourly Department

- One row = hourly summary

---

## Key Insight

Finer grain → more flexibility  
Coarser grain → less flexibility

==================================================
5. ATOMIC vs COARSE GRAIN
==================================================

---

## Atomic (Fine Grain)

- Detailed data
- Large tables

Pros:

- Can answer detailed questions

Cons:

- More storage

---

## Coarse Grain

- Aggregated data

Pros:

- Faster queries

Cons:

- Cannot drill down

---

## IMPORTANT RULE

You can:

- Aggregate later

But cannot:

- Recover lost detail

==================================================
6. TRADE-OFFS IN GRAIN SELECTION
==================================================

---

## When to choose fine grain

- Need detailed analysis
- Example: coupon usage

---

## When to choose coarse grain

- Only high-level reports needed

---

## Factors

- Cost
- Performance
- Privacy
- Latency

==================================================
7. SQL EXAMPLES
==================================================

---

## Atomic Table

SELECT transaction_id, line_no, sku, quantity, extended_amount
FROM fact_pos_sale_line;

Explanation:

- Detailed data

---

## Coarse Table

SELECT store_sk, date_sk, SUM(extended_amount)
FROM fact_pos_sale_line
GROUP BY 1, 2;

Explanation:

- Aggregated data

==================================================
8. COMMON GRAIN PROBLEMS
==================================================

---

1. Mixed grain

---

Problem:

- Double counting

Fix:

- Separate tables

---

1. Snapshot vs transactional confusion

---

Problem:

- Wrong averages

Fix:

- Use correct table type

---

1. No conformed dimensions

---

Problem:

- Inconsistent data

Fix:

- Use shared dimensions

==================================================
9. FINER vs COARSER COMPARISON
==================================================

Fine Grain:

- More storage
- More flexible
- Supports detailed analysis

Coarse Grain:

- Less storage
- Faster
- Limited analysis

==================================================
10. DERIVED MEASURES
==================================================

---

## Options

1. Store in table

- Example: gross_margin

Use when:

- Stable definition

1. Compute in query

- Example: margin = sales - cost

Use when:

- Changes often

1. BI calculation

- Example: dashboard formulas

Use when:

- Temporary analysis

---

## Important Warning

Percentages are NOT additive

==================================================
11. UNIT COUNT PROBLEM
==================================================

Problem:

- Some rows have quantity = 0

Example:

- Fees

Result:

- Wrong averages

---

## Solution

- Filter rows with quantity > 0

---

## SQL Example

SELECT
  SUM(sale_amount),
  SUM(sale_amount)/SUM(quantity)
FROM fact_table
WHERE quantity > 0;

==================================================
12. MULTIPLE FACT TABLES
==================================================

You need different fact tables for different grains:

---

## Examples

1. Sales fact

- Line-level data

1. Inventory fact

- Daily snapshot

1. Shipment fact

- Delivery data

---

## Important

Use shared dimensions

==================================================
13. INTERVIEW QUESTIONS
==================================================

---

## Q: What is grain?

Answer:

- One row = specific business event

---

## Q: Why not aggregate early?

Answer:

- Lose detailed analysis

---

## Q: How to test grain?

Answer:

- Unique keys
- Data validation

==================================================
14. COMMON MISTAKES
==================================================

---

1. Not defining grain clearly

---

Problem:

- Wrong implementation

Fix:

- Enforce uniqueness

---

1. Mixing returns and sales

---

Problem:

- Wrong totals

Fix:

- Define rules

---

1. Storing percentages

---

Problem:

- Wrong aggregation

Fix:

- Store base values

---

1. Single fact table for everything

---

Problem:

- Complexity

Fix:

- Separate tables

---

1. Ignoring multiple date types

---

Problem:

- Confusion

Fix:

- Use different date columns

==================================================
15. FINAL TAKEAWAY
==================================================

Dimensional modeling success depends on:

1. Correct grain definition
2. Proper dimensions
3. Accurate facts

---

## Golden Rule

Grain defines everything

---

## Pipeline

Business Process
   ↓
Grain
   ↓
Dimensions
   ↓
Facts

---

## Goal

Make data:

- Simple
- Consistent
- Reliable

==================================================
16. QUICK MEMORY SUMMARY
==================================================

4 Steps:

- Process
- Grain
- Dimensions
- Facts

Grain:

- Defines row meaning

Fine vs Coarse:

- Flexibility vs performance

Rules:

- Never mix grain
- Never store percentages
- Always define grain clearly

