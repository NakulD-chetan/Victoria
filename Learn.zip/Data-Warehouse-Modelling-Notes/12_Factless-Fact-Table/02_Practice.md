# Factless Fact Table — Practice

> "Not every fact is a number—sometimes presence is the insight."

---

## Quick Recall

**Q: What is a factless fact table?**  
A: A fact table with no numeric measures—only foreign keys (and possibly degenerate keys) describing events or coverage.

**Q: Give a retail example of an event factless fact.**  
A: `fact_promotion_display` with keys for date, store, promotion, and product fixture—each row means "this promo ran here then."

**Q: What is a coverage / bridge style use?**  
A: Linking which products were eligible for a promotion period, or which customers were targeted by a campaign.

**Q: How do you query a factless fact?**  
A: Count rows, count distinct entities, or join to measured facts for impact—not sum nonexistent measures.

**Q: Why not add a dummy measure of 1?**  
A: Optional for some BI tools; logically the row existence is the fact—document either pattern for your platform.

---

## Interview Questions

**1. Define a factless fact table in one crisp sentence.**  
Say: It records a many-to-many relationship or occurrence of a business event using dimension keys, without additive numeric measures.

**2. How does a factless fact differ from a bridge table?**  
Say: Bridge tables often connect two dimensions (e.g., order to multiple coupons); factless facts are still in the dimensional model and may include a time key for when the relationship held in retail campaigns.

**3. Example: e-commerce email campaign.**  
Say: `fact_campaign_send` with `customer_key`, `campaign_key`, `send_date_key`—each row is a send. Email opens/clicks might be separate factless or transaction facts depending on grain.

**4. Can a factless fact become a regular fact?**  
Say: Yes—if you add measures like `estimated_lift` or `allocated_discount`, it is no longer factless; revisit naming and additivity rules.

**5. How do you model "products on promotion" without duplicating sales?**  
Say: Factless `fact_promo_eligibility` for coverage; join to `fact_order_line` on overlapping dates and keys to attribute revenue to promos without inflating sales rows.

**6. What primary key do you use?**  
Say: Surrogate `promo_display_key` or a composite uniqueness constraint on the natural key set—surrogate is standard for SCD-safe dimensions.

**7. Common pitfall in interviews?**  
Say: Claiming factless facts are "bad design"—they are appropriate for events without measures and for many-to-many resolution.

---

## Scenario-Based Exercises

**Scenario 1 — Store visits without purchase**  
Track app users who viewed a product detail page.  
**Solution:** `fact_product_view` with `session_key`, `customer_key`, `product_key`, `view_date_key`, `channel_key`. Analyze funnel by counting views and joining to `fact_order_line` on session or customer within attribution window.

**Scenario 2 — Promotion coverage**  
Which SKUs were on "Back to School" promo in each region?  
**Solution:** `fact_promo_sku_region` with `promotion_key`, `product_key`, `region_key`, `start_date_key`, `end_date_key`. Rows exist for eligibility; measured redemptions stay on sales facts.

**Scenario 3 — SQL: count promo touches**  
Count distinct stores per promotion per week.

```sql
SELECT
    p.promotion_name,
    d.retail_week,
    COUNT(DISTINCT f.store_key) AS store_count
FROM dw.fact_promo_display f
JOIN dw.dim_promotion p ON f.promotion_key = p.promotion_key
JOIN dw.dim_date d ON f.display_date_key = d.date_key
GROUP BY 1, 2
ORDER BY 1, 2;
```

**Scenario 4 — Returns authorization**  
Authorized returns before refund.  
**Solution:** `fact_return_authorization` factless at `ra_line` grain with `return_auth_id`, `order_line_key`, `reason_key`, `auth_date_key`; join to refund fact when money moves.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Insisting every fact needs amounts | Dimensional method allows pure events | Cite coverage and funnel examples |
| Double-counting sales when joining coverage | Many-to-many explosion | Use EXISTS or careful join predicates |
| Confusing with dimension | Fact holds relationships/events | Dimensions describe; facts record context |
| Storing measures "later" unnamed | Unclear additivity | Promote to measured fact with clear grain |

---

## One-Liner Answers

- Factless facts record relationships or events using keys only.
- Use them for promotions, eligibility, attendance, and funnel steps without measures.
- Query with counts and distinct counts, not blind SUMs.
- Separate eligibility from monetary impact measured elsewhere.
- Many-to-many between business entities is a classic factless pattern.
- Optional constant measure of 1 is a tooling convenience, not a business measure.
