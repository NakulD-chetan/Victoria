# Graph — Edge Cases

> **Permanent Recall:** Disconnected, single node, empty, self-loops, multi-edges, negative weights, cycles. Always ask: "What if the graph is empty? Single node? Disconnected?"

---

## 1. Disconnected Graph

### What
- Multiple components; not all nodes reachable from one source

### Impact
- BFS/DFS from one node visits only one component
- Shortest path: unreachable nodes = infinity / -1
- Connected components: must iterate all nodes, run BFS/DFS from each unvisited

### Handling
```python
# Count components: loop over all nodes
for u in range(n):
    if not visited[u]:
        dfs(u)
        count += 1

# Shortest path: unreachable = -1 or inf
dist = [-1] * n  # or [inf]*n
# After BFS: unvisited nodes stay -1
```

### ASCII
```
    [A]---[B]        [C]---[D]
    
    Two components. BFS from A never sees C, D.
```

---

## 2. Single Node (n=1)

### What
- Graph with one vertex, no edges (or self-loop)

### Impact
- Empty adjacency list
- BFS/DFS: visits only that node
- Topo: valid order = [0]
- Shortest path from 0 to 0 = 0

### Handling
- Check `if n == 0: return ...`
- Check `if n == 1: return 0` (or appropriate)
- Avoid index out of bounds

---

## 3. Empty Graph (n=0, no edges)

### What
- Zero vertices

### Impact
- No nodes to process
- Return empty list, 0, or problem-specific default

### Handling
```python
if n == 0:
    return []  # or 0, or []
```

---

## 4. Self-Loops

### What
- Edge (u, u) — node connected to itself

### Impact
- **Undirected:** Can cause "cycle" if not careful with parent check
- **Directed:** Always a cycle
- Topological sort: impossible (cycle)
- BFS/DFS: can cause infinite loop if not marking visited before processing

### Handling
- **Directed:** Self-loop = cycle; topo fails
- **Undirected:** In DFS, parent check: `v != parent` — self-loop skipped (u's neighbor is u, parent is u, so v==parent, no false cycle)
- **Union-Find:** `union(u,u)` → same component, returns false → cycle

### ASCII
```
    [A]──┐
      └──┘   Self-loop at A
```

---

## 5. Multi-Edges (Duplicate Edges)

### What
- Multiple edges between same pair (u, v)

### Impact
- Adjacency list: multiple entries for same neighbor
- BFS/DFS: May push same node multiple times → need visited check
- Dijkstra: Multiple (v, w) in adj[u] — relax each; heap handles
- Union-Find: Second edge connecting same component = cycle

### Handling
- Visited array prevents duplicate processing
- For weighted: keep minimum weight if needed
- Union-Find: `union(u,v)` returns false on duplicate = cycle (in cycle detection)

---

## 6. Negative Weights

### What
- Edge weights < 0

### Impact
- **Dijkstra fails** — greedy choice not optimal; can get stuck in negative cycle
- **Bellman-Ford** required
- Shortest path may be undefined (negative cycle reachable from source)

### Handling
- Use Bellman-Ford
- Detect negative cycle: if V-th relaxation still improves

### ASCII
```
    A --(-5)--> B --(3)--> C
     \___________________/
              (2)
    Path A→B→C→A = -5+3+2 = 0 (cycle)
    Path A→B→C→A→B = -5+3+2-5 = -5 (can go infinitely negative)
```

---

## 7. Cycles

### What
- Path that returns to a vertex

### Impact
- **Directed:** Topological sort undefined
- **Undirected:** DFS must use parent to avoid false positive (A-B-A is not "cycle" in same sense for traversal)
- Cycle detection: directed = 3-color; undirected = parent or Union-Find

### Handling
- Before topo: check for cycle (Kahn's |order| != n, or DFS back edge)
- Undirected cycle: edge (u,v) where u and v already in same component (Union-Find)

---

## 8. Dense vs Sparse

| | Sparse (E ≈ V) | Dense (E ≈ V²) |
|--|----------------|----------------|
| Representation | Adj list | Adj list or matrix |
| Dijkstra | O((V+E) log V) | O(V² log V) with heap; consider matrix + linear scan |

---

## 9. Large Values / Overflow

### What
- Sum of weights exceeds int range

### Handling
- Use `long long` (C++), `i64` (Rust), or arbitrary precision
- Check before: `if dist[u] != INF and dist[u] + w < dist[v]`

---

## Edge Case Checklist (Interview)

```
□ n = 0
□ n = 1
□ Disconnected graph
□ Self-loop
□ Multi-edge
□ Negative weights? → Bellman-Ford
□ Cycle? → Topo invalid; detect first
□ Source == target (dist = 0)
□ Unreachable nodes (dist = -1 or inf)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Graph Edge Cases
WHEN TO USE:       Before coding, during testing
CORE IDEA:         Disconnected, single, empty, self-loop, multi-edge, negative, cycle
TIME:              N/A
SPACE:             N/A
INTERVIEW SENTENCE: "I'll handle: empty graph, single node, disconnected components,
                     and negative weights if applicable."
```

---

## 30-SECOND REVISION BOX

```
Disconnected → loop all nodes, BFS/DFS per unvisited
Single node → n==1, return 0 or [0]
Empty → n==0, return []
Self-loop → directed=cycle; undirected=parent check
Negative weights → Bellman-Ford, not Dijkstra
Cycle → topo invalid; detect before topo
```
