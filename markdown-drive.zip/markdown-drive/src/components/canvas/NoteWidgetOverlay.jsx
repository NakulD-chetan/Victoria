import { useState, useCallback, useRef, memo } from 'react';
import { WIDGET_DIMS } from './widgetLibrary';
import { CANVAS_Z } from './stacking';

const MIN = WIDGET_DIMS.note;
const BASE_W = WIDGET_DIMS.note.w;
const BASE_FONT = 13;
const BASE_HEADER = 32;
const DRAG_THRESHOLD_PX = 4;

function stopBubble(e) {
  e.stopPropagation();
}

function NoteWidgetOverlay({
  widgetGroups, viewport, canvasOffset = { x: 0, y: 0 },
  selectedWidgetId, onSelectWidget,
  onMove, onResize, onMoveResize, onUpdateData, onDelete, theme,
}) {
  const entries = [];
  for (const [id, info] of widgetGroups) {
    if (info.type === 'note') entries.push({ id, ...info });
  }
  if (entries.length === 0) return null;
  const { zoom, scrollX, scrollY } = viewport;

  return (
    <>
      {entries.map((entry) => (
        <NotePanel
          key={entry.id}
          id={entry.id}
          data={entry.data}
          worldX={entry.worldX}
          worldY={entry.worldY}
          w={entry.w}
          h={entry.h}
          screenX={canvasOffset.x + (entry.worldX + scrollX) * zoom}
          screenY={canvasOffset.y + (entry.worldY + scrollY) * zoom}
          zoom={zoom}
          theme={theme}
          onMove={onMove}
          onResize={onResize}
          onMoveResize={onMoveResize}
          onUpdateData={onUpdateData}
          onDelete={onDelete}
          isSelected={entry.id === selectedWidgetId}
          onSelectWidget={onSelectWidget}
        />
      ))}
    </>
  );
}

const NotePanel = memo(function NotePanel({
  id, data, worldX, worldY, w, h, screenX, screenY, zoom, theme,
  onMove, onResize, onMoveResize, onUpdateData, onDelete,
  isSelected, onSelectWidget,
}) {
  const [text, setText] = useState(data.text || '');
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const saveTimer = useRef(null);

  const sizeRatio = Math.max(0.6, Math.min(2, w / BASE_W));
  const fontSize = Math.round(BASE_FONT * sizeRatio);
  const headerH = Math.round(BASE_HEADER * sizeRatio);

  const handleChange = useCallback((e) => {
    const val = e.target.value;
    setText(val);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      onUpdateData(id, { text: val });
    }, 300);
  }, [id, onUpdateData]);

  const handleHeaderMouseDown = useCallback((e) => {
    if (e.target.closest('button')) return;
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startMY = e.clientY;
    const startWX = worldX;
    const startWY = worldY;
    let dragStarted = false;
    const move = (ev) => {
      if (!dragStarted) {
        if (Math.abs(ev.clientX - startMX) < DRAG_THRESHOLD_PX && Math.abs(ev.clientY - startMY) < DRAG_THRESHOLD_PX) return;
        dragStarted = true;
        setIsDragging(true);
      }
      onMove(id, startWX + (ev.clientX - startMX) / zoom, startWY + (ev.clientY - startMY) / zoom);
    };
    const up = () => {
      if (!dragStarted) onSelectWidget?.(id);
      setIsDragging(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [id, worldX, worldY, zoom, onMove, onSelectWidget]);

  const handleResizeMouseDown = useCallback((e, edge) => {
    e.preventDefault();
    e.stopPropagation();
    const startMX = e.clientX;
    const startMY = e.clientY;
    const startW = w;
    const startH = h;
    const startWX = worldX;
    const startWY = worldY;
    setIsResizing(true);
    const move = (ev) => {
      const dx = (ev.clientX - startMX) / zoom;
      const dy = (ev.clientY - startMY) / zoom;
      let nW = startW, nH = startH, nWX = startWX, nWY = startWY;
      if (edge.includes('e')) nW = Math.max(MIN.minW, startW + dx);
      if (edge.includes('w')) { nW = Math.max(MIN.minW, startW - dx); nWX = startWX + (startW - nW); }
      if (edge.includes('s')) nH = Math.max(MIN.minH, startH + dy);
      if (edge.includes('n')) { nH = Math.max(MIN.minH, startH - dy); nWY = startWY + (startH - nH); }
      if (nWX !== startWX || nWY !== startWY) {
        onMoveResize(id, nWX, nWY, nW, nH);
      } else {
        onResize(id, nW, nH);
      }
    };
    const up = () => {
      setIsResizing(false);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  }, [id, w, h, worldX, worldY, zoom, onResize, onMoveResize]);

  const handleDelete = useCallback((e) => {
    e.preventDefault();
    e.stopPropagation();
    onDelete(id);
  }, [id, onDelete]);

  return (
    <div
      className={`nw-overlay${isSelected ? ' nw-overlay--selected' : ''}${isDragging ? ' nw-overlay--dragging' : ''}${isResizing ? ' nw-overlay--resizing' : ''}`}
      style={{
        position: 'absolute',
        left: screenX,
        top: screenY,
        width: w,
        height: h,
        transform: `scale(${zoom})`,
        transformOrigin: 'top left',
        pointerEvents: 'none',
        zIndex: CANVAS_Z.WIDGETS,
        willChange: 'transform',
      }}
      onKeyDown={stopBubble}
      onKeyUp={stopBubble}
    >
      <div
        className="nw-header"
        style={{ pointerEvents: 'auto', height: headerH, fontSize: Math.round(12 * sizeRatio) }}
        onMouseDown={handleHeaderMouseDown}
      >
        <span className="nw-title">Note</span>
        <button
          className="nw-close-btn"
          onClick={handleDelete}
          onMouseDown={(e) => e.stopPropagation()}
          title="Remove note"
          style={{ fontSize: Math.round(13 * sizeRatio) }}
        >
          ✕
        </button>
      </div>

      <textarea
        className="nw-textarea"
        style={{
          height: h - headerH,
          pointerEvents: 'auto',
          fontSize,
          lineHeight: `${Math.round(18 * sizeRatio)}px`,
          padding: `${Math.round(10 * sizeRatio)}px`,
        }}
        value={text}
        onChange={handleChange}
        placeholder="Type your notes here..."
        spellCheck={false}
        onPointerDown={(e) => { stopBubble(e); onSelectWidget?.(id); }}
        onMouseDown={stopBubble}
        onClick={stopBubble}
        onWheel={stopBubble}
        onKeyDown={stopBubble}
        onKeyUp={stopBubble}
      />

      <div className="cw-resize cw-resize--e"  style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'e')} />
      <div className="cw-resize cw-resize--s"  style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 's')} />
      <div className="cw-resize cw-resize--w"  style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'w')} />
      <div className="cw-resize cw-resize--n"  style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'n')} />
      <div className="cw-resize cw-resize--se" style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'se')} />
      <div className="cw-resize cw-resize--sw" style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'sw')} />
      <div className="cw-resize cw-resize--ne" style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'ne')} />
      <div className="cw-resize cw-resize--nw" style={{ pointerEvents: 'auto' }} onMouseDown={(e) => handleResizeMouseDown(e, 'nw')} />
    </div>
  );
});

export default NoteWidgetOverlay;
