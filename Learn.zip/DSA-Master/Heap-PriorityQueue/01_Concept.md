# Heap / Priority Queue — Concept

> **Permanent Recall:** Heap = efficient access to min/max element. O(1) peek, O(log n) insert/delete. **Top-K** and **Two-Heap** are the FAANG favorites. Use heap when you need "best of N" without full sort, or when data streams in.

---

## Core Idea (2 Lines)

**Heap lets you efficiently access the min (min-heap) or max (max-heap) element. Insert and delete are O(log n); peek is O(1). Perfect for "Top K" (maintain K best) and "median of stream" (two heaps).**

---

## Min-Heap vs Max-Heap

```
MIN-HEAP (smallest at top):
       ┌───┐
       │ 1 │  ← ROOT = minimum
       └───┘
      /     \
   ┌───┐   ┌───┐
   │ 3 │   │ 2 │
   └───┘   └───┘
   /   \     /
 ┌───┐ ┌───┐ ┌───┐
 │ 7 │ │ 5 │ │ 4 │
 └───┘ └───┘ └───┘

MAX-HEAP (largest at top):
       ┌───┐
       │ 9 │  ← ROOT = maximum
       └───┘
      /     \
   ┌───┐   ┌───┐
   │ 7 │   │ 8 │
   └───┘   └───┘

Key: Parent ≤ children (min) or Parent ≥ children (max)
```

| Operation | Min-Heap | Max-Heap |
|-----------|----------|----------|
| Peek | O(1) — get min | O(1) — get max |
| Insert | O(log n) | O(log n) |
| Extract min/max | O(log n) | O(log n) |
| Heapify array | O(n) | O(n) |

---

## Top-K Pattern — The FAANG Favorite

**Problem:** Find K largest (or smallest) elements from N elements.

```
APPROACH: Min-heap of size K (for K largest)

  Stream: [3, 2, 1, 5, 4, 6]  →  Top 3 largest = [4, 5, 6]

  Step 1: Push 3, 2, 1  →  Heap: [1, 2, 3]  (size 3)
  Step 2: Push 5  →  5 > 1 (min)  →  Pop 1, push 5  →  [2, 3, 5]
  Step 3: Push 4  →  4 > 2  →  Pop 2, push 4  →  [3, 4, 5]
  Step 4: Push 6  →  6 > 3  →  Pop 3, push 6  →  [4, 5, 6]

  Result: Heap contains [4, 5, 6] — the top 3 largest!
```

**Why min-heap for K largest?** The root is the smallest of our K candidates. If a new element is larger than the root, it belongs in the top-K; we evict the root.

| Goal | Heap Type | Size | Evict When |
|------|-----------|------|------------|
| K largest | Min-heap | K | New > root → pop root, push new |
| K smallest | Max-heap | K | New < root → pop root, push new |

---

## Two-Heap Pattern (Median Finding)

**Problem:** Find median of a stream of numbers as they arrive.

```
APPROACH: Max-heap (left half) + Min-heap (right half)

  max_heap (left):  stores smaller half  →  peek = max of left
  min_heap (right): stores larger half   →  peek = min of right

  Invariant: |size(left) - size(right)| ≤ 1

  Stream: 5, 3, 4, 2, 6

  After 5:  max=[5], min=[]           → median = 5
  After 3:  max=[3], min=[5]          → median = (3+5)/2 = 4
  After 4:  max=[3,4], min=[5]        → median = 4
  After 2:  rebalance → max=[2,3], min=[4,5]  → median = (3+4)/2 = 3.5
  After 6:  max=[2,3], min=[4,5,6]    → rebalance → max=[2,3,4], min=[5,6]
            → median = 4
```

```
ASCII: Two Heaps for Median

  LEFT (max-heap)          RIGHT (min-heap)
  ┌─────────────┐          ┌─────────────┐
  │     4       │          │     5       │
  │   (max)     │   ≤      │   (min)     │
  │   2   3     │          │   6   7     │
  └─────────────┘          └─────────────┘
       ↑                         ↑
  max of left              min of right
  (smaller half)           (larger half)

  Median = max_heap.top() [if odd, left heavier]
        or (max_heap.top() + min_heap.top()) / 2 [if even]
```

---

## Heap vs Sorting vs Quickselect — Tradeoffs

| Scenario | Best Choice | Time | Space | Why |
|----------|-------------|------|-------|-----|
| **Static array, need Top-K** | Quickselect | O(n) avg | O(1) | No extra space, one pass |
| **Static array, need Top-K** | Heap of size K | O(n log K) | O(K) | Simpler, no worst-case O(n²) |
| **Streaming data** | Heap | O(n log K) | O(K) | Can't sort stream; heap handles one-by-one |
| **Need full sorted order** | Sort | O(n log n) | O(1) or O(n) | Heap gives unsorted top-K |
| **Kth largest, static** | Quickselect | O(n) avg | O(1) | Direct index |
| **Kth largest, streaming** | Min-heap size K | O(n log K) | O(K) | Only option for stream |

**Golden rule:** Streaming or online → heap. Static + need Kth only → quickselect. Static + need full Top-K list → either works.

---

## When NOT to Use Heap

| Scenario | Why Not | Use Instead |
|----------|---------|--------------|
| Need full sorted array | Heap gives unsorted top-K | Sort, or heap then extract all |
| Need random access / index | Heap only has root | Array, sorted structure |
| K = N (all elements) | Heap = O(n log n), sort is same | Sort |
| Need exact Kth index (position) | Heap gives value, not index | Quickselect |
| Need range query [L, R] | Heap doesn't support | Segment tree, BIT |
| Elements have complex dependencies | Heap compares single key | Custom structure, DFS/BFS |

---

## Golden Rules

1. **"Top K" / "K largest" / "K smallest" → heap** (FAANG #1 pattern)
2. **"Median of stream" → two heaps** (max-heap left + min-heap right)
3. **"Merge K sorted" → min-heap** (tournament: pick smallest of K heads)
4. **K largest → min-heap of size K** (evict smallest when new is bigger)
5. **K smallest → max-heap of size K** (evict largest when new is smaller)
6. **Streaming / online data → heap** (can't sort; process one-by-one)
7. **Python heapq = min-heap only** (negate for max-heap)
8. **C++ priority_queue = max-heap by default** (use `greater<>` for min-heap)

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Heap / Priority Queue
WHEN TO USE:        Top-K, Kth largest, median stream, merge K sorted
CORE IDEA:          O(1) peek min/max, O(log n) insert/delete
TOP-K:              Min-heap size K for K largest; evict root when new > root
TWO-HEAP:           Max-heap (left) + Min-heap (right); median = peek both
MERGE K:            Min-heap of (value, list_idx) — pop smallest, push next
TIME:               O(n log K) for Top-K; O(n log n) for merge K
SPACE:              O(K) for Top-K; O(K) for merge K
HEAP VS SORT:       Stream → heap; Static Kth → quickselect
INTERVIEW LINE:     "For Top-K on streaming data, I'll use a min-heap of size K —
                     when a larger element arrives, evict the smallest."
```
