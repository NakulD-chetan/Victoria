# Prefix Sum — Concept

> **Permanent Recall:** Prefix sum precomputes cumulative sums so that any range query [i, j] becomes O(1): `sum(i..j) = prefix[j+1] - prefix[i]`. Converts O(n) per query to O(1) per query. Essential for "subarray sum", "range query", and "count subarrays" problems. FAANG tests this in 20%+ of array rounds.

---

## Core Idea (2 Lines)

**prefix[i] = sum(arr[0..i-1])** — cumulative sum up to (but not including) index i.  
**Range sum [i, j] = prefix[j+1] - prefix[i]** — difference of two prefix values.

---

## Intuition: The Mileage Odometer

Imagine a **road trip odometer**:

- At mile 0: odometer = 0
- At mile 50: odometer = 50
- At mile 120: odometer = 120

**Distance from mile 50 to mile 120?** → 120 - 50 = 70 miles. You don't re-measure; you **subtract two cumulative readings**.

```
Array:     [2,  1,  5,  1,  3]
Index:      0   1   2   3   4

Prefix:   [0,  2,  3,  8,  9, 12]
Index:      0   1   2   3   4   5

Sum of arr[1..3] = arr[1]+arr[2]+arr[3] = 1+5+1 = 7
Using prefix: prefix[4] - prefix[1] = 9 - 2 = 7 ✓
```

---

## Why Brute Force Fails with Multiple Queries


| Approach                     | Per Query | Q queries | Total    |
| ---------------------------- | --------- | --------- | -------- |
| Brute force (loop i to j)    | O(n)      | Q         | O(Q·n)   |
| Prefix sum (precompute once) | O(1)      | Q         | O(n + Q) |


**The redundancy:** For each query [i, j], brute force re-adds elements. If you have 10⁵ queries on a 10⁵ array, brute force = 10¹⁰ operations. Prefix sum = 10⁵ + 10⁵ = 2×10⁵.

```
Brute force for each query:
  Query [1,3]: sum = arr[1]+arr[2]+arr[3]  → 3 additions
  Query [2,4]: sum = arr[2]+arr[3]+arr[4]  → 3 additions  ← Overlaps with previous!

Prefix sum:
  Build once: prefix = [0, 2, 3, 8, 9, 12]  → O(n)
  Query [1,3]: prefix[4]-prefix[1] = 7     → O(1)
  Query [2,4]: prefix[5]-prefix[2] = 9     → O(1)
```

---

## 1D Prefix Sum

```
arr:    [a0, a1, a2, a3, a4]
         |   |   |   |   |
prefix: [0, p1, p2, p3, p4, p5]

prefix[i] = sum(arr[0..i-1])
prefix[0] = 0  (sum of nothing)
prefix[1] = a0
prefix[2] = a0+a1
prefix[5] = a0+a1+a2+a3+a4

sum(arr[i..j]) = prefix[j+1] - prefix[i]
```

---

## 2D Prefix Sum (Matrix Region)

```
Matrix M (rows × cols):
┌─────────────────────────────────────┐
│  (0,0)                    (0,c-1)   │
│    ┌─────────────────────┐          │
│    │                     │          │
│    │   Region (r1,c1)    │          │
│    │   to (r2,c2)        │          │
│    │                     │          │
│    └─────────────────────┘          │
│  (r-1,0)                (r-1,c-1)   │
└─────────────────────────────────────┘

prefix[r][c] = sum of all M[i][j] where i < r, j < c

Region sum = prefix[r2+1][c2+1] - prefix[r1][c2+1] - prefix[r2+1][c1] + prefix[r1][c1]
             (whole)              (left strip)      (top strip)      (double-subtracted)
```

**Inclusion-Exclusion:**

```
     A  |  B
   -----+-----
     C  |  D

Sum(D) = Sum(A+B+C+D) - Sum(A+B) - Sum(A+C) + Sum(A)
```

---

## When NOT to Use Prefix Sum


| Scenario                                   | Why Not                                   | Use Instead                |
| ------------------------------------------ | ----------------------------------------- | -------------------------- |
| Non-contiguous elements                    | Prefix sum is for contiguous ranges       | Hash map, DP               |
| Need to modify array (updates)             | Prefix sum is static; updates invalidate  | Segment Tree, Fenwick Tree |
| Single query, no reuse                     | Overhead of building prefix not worth it  | Direct loop                |
| "Subarray sum = K" with count              | Need prefix + hash map, not raw prefix    | Prefix + Hash Map          |
| Negative numbers + "shortest subarray ≥ K" | Prefix not monotonic; can't binary search | Deque + prefix sum         |
| Need min/max in range                      | Prefix sum is additive only               | Segment Tree, Sparse Table |


---

## Golden Rules

1. **prefix[0] = 0** — always. Enables sum(arr[0..j]) = prefix[j+1] - prefix[0]
2. **prefix has length n+1** for array of length n
3. **sum(i..j) = prefix[j+1] - prefix[i]** — inclusive both ends
4. **"Subarray sum = K"** → prefix + hash map: count prefix[j] - prefix[i] = K ⇒ prefix[j] = prefix[i] + K
5. **2D: inclusion-exclusion** — add back the doubly-subtracted corner
6. **Prefix XOR, prefix product** — same structure, different operation

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Prefix Sum
CORE FORMULA:       prefix[i] = sum(arr[0..i-1])
RANGE QUERY:        =sum(i..j)  prefix[j+1] - prefix[i]
WHEN TO USE:        Range queries, subarray sum, count subarrays
BUILD TIME:         O(n) for 1D, O(r×c) for 2D
QUERY TIME:         O(1)
INTERVIEW LINE:     "I'll precompute prefix sums so each range query
                     becomes O(1) instead of O(n) per query."
```

