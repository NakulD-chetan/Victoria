# System Design Kya Hai — Complete Foundation

> **Yeh notes FAANG interview preparation ke liye hain — Tree Notes style mein**
> Hindi + English mix mein easy language, but conceptually deep

---

## Table of Contents
1. [System Design Kya Hai?](#1-system-design-kya-hai)
2. [Kyu Zaroori Hai?](#2-kyu-zaroori-hai)
3. [Mindset Shift](#3-mindset-shift)
4. [3 Enemies](#4-3-enemies)
5. [Core Properties](#5-core-properties)
6. [Latency vs Throughput](#6-latency-vs-throughput)
7. [Trade-offs](#7-trade-offs)
8. [Building Blocks](#8-building-blocks)
9. [System Evolution](#9-system-evolution)
10. [15 Golden Rules](#10-15-golden-rules)
11. [How Interview Works](#11-how-system-design-interview-works)
12. [Scale Numbers](#12-scale-numbers-to-remember)
13. [Anti-Patterns](#13-anti-patterns)

---

## 1. System Design Kya Hai?

### What Problem?
- **Problem:** Ek simple app banao toh easy hai. Lekin jab 1 million users aate hain, 1000 requests/second aate hain, servers fail ho jate hain — tab kya?
- **Matlab:** System Design = Large-scale software systems ko design karne ka art + science

### Why Needed?
- Single developer ek CRUD app bana sakta hai
- Lekin distributed system — 1000s servers, multiple data centers — requires systematic thinking

### Core Concept
**Blueprint Analogy — City Planning for Software**

```
Socho ek city plan kar rahe ho:

    ┌─────────────────────────────────────────────────┐
    │              CITY PLANNING (Blueprint)           │
    ├─────────────────────────────────────────────────┤
    │  • Kahan roads? (Data flow)                     │
    │  • Kahan hospitals? (Critical services)         │
    │  • Kahan residential? (User-facing)             │
    │  • Water supply kaise? (Data pipelines)         │
    │  • Emergency plan? (Fault tolerance)            │
    └─────────────────────────────────────────────────┘
                          │
                          ▼
    ┌─────────────────────────────────────────────────┐
    │           SYSTEM DESIGN (Software Blueprint)    │
    ├─────────────────────────────────────────────────┤
    │  • Components kya honge?                        │
    │  • Data kaise flow hoga?                         │
    │  • Bottlenecks kahan?                            │
    │  • Failure pe kya hoga?                          │
    │  • Scale kaise karenge?                          │
    └─────────────────────────────────────────────────┘
```

**Isko samjho aise:**
- System Design = **Before coding** — architecture decide karna
- Implementation = **During coding** — actual code likhna

### Internal Working
```
Requirements → Design Decisions → Architecture Diagram → Trade-off Analysis
     │                  │                    │                    │
     ▼                  ▼                    ▼                    ▼
  "What"            "How"              "Visual"            "Why this?"
```

### Real World Example
**WhatsApp:**
- 2 billion users
- Real-time messaging
- Minimal servers (Erlang magic)
- Design decisions: Message queue, read receipts async, media CDN

### Interview Questions
- "Design a URL shortener" — Components: API, DB, Cache, LB
- "Design a chat system" — WebSocket, message queue, presence
- "Design Instagram" — Feed, posts, follow graph, CDN
- "Design Uber" — Real-time location, matching, surge
- "Design Netflix" — Video streaming, recommendations, CDN

### Quick Recall Summary
System Design = Software ka blueprint. City planning jaisa — pehle plan, phir build.

---

#### 1 Minute Recall Block
```
SYSTEM DESIGN = Software Architecture Blueprint
• Before code, design karo
• Components, data flow, failures, scale — sab plan
• City planning analogy — roads, hospitals, water supply
```

#### 5 Bullet Memory Hooks
1. Blueprint = Plan before build
2. City planning = Roads (flow), Hospitals (critical), Water (data)
3. Requirements → Design → Architecture → Trade-offs
4. WhatsApp = 2B users, minimal servers, Erlang
5. Design ≠ Implementation (design first!)

#### Common Interview Trap
⚠️ **Trap:** "System design sirf diagrams banana hai" — Galat! Interviewer wants **reasoning**, **trade-offs**, **why this choice**. Diagram is just a tool.

---

## 2. Kyu Zaroori Hai?

### What Problem?
- Junior dev: "Mujhe coding aati hai, system design kyu?"
- Senior/Staff: "Design decisions mujhe lene padte hain"

### Why Needed?
| Reason | Explanation |
|--------|-------------|
| **FAANG Interviews** | Google, Meta, Amazon — System Design round mandatory (L5+) |
| **Career Growth** | L4 → L5 = Design ownership expected |
| **Real Impact** | Wrong design = Company ka crores waste, rewrite |
| **Technical Leadership** | Team ko guide karne ke liye |

### Core Concept
```
Career Ladder:
    L3 (Junior)     → Code likho, ticket complete karo
    L4 (Mid)        → Module own karo, small design
    L5 (Senior)     → System design, cross-team
    L6+ (Staff+)    → Org-level architecture
```

### Real World Example
- **Netflix Chaos Engineering** — System design samajhna = Resilience design karna
- **Uber Surge Pricing** — Real-time, distributed, high QPS design

### Quick Recall Summary
FAANG interview + Career growth + Real impact = System Design zaroori

---

#### 1 Minute Recall Block
```
WHY SYSTEM DESIGN?
• FAANG: L5+ round mandatory
• Career: L4→L5 = Design ownership
• Impact: Wrong design = Crores waste
• Leadership: Team guide
```

#### 5 Bullet Memory Hooks
1. FAANG = System Design round
2. L5 = Design ownership
3. Wrong design = Rewrite = Crores
4. Staff = Org architecture
5. Junior = Code, Senior = Design

#### Common Interview Trap
⚠️ **Trap:** "Mujhe coding strong hai, design skip karunga" — L5+ pe design round hoga hi. Skip mat karo.

---

## 3. Mindset Shift

### What Problem?
- College/ Bootcamp: Single machine, single DB, everything local
- Industry: 1000s machines, distributed, failures everywhere

### Why Needed?
- Single machine mindset = Production me fail
- Distributed mindset = Scale + resilience

### Core Concept
**Single Machine → Distributed Systems**

```
SINGLE MACHINE (College)          DISTRIBUTED (Industry)
┌─────────────────────┐          ┌─────┐ ┌─────┐ ┌─────┐
│  App + DB + Cache   │          │ S1  │ │ S2  │ │ S3  │
│  Everything local   │    →     ├─────┤ ├─────┤ ├─────┤
│  No network issues  │          │ LB  │ │ DB  │ │Cache│
│  Predictable        │          └──┬──┘ └──┬──┘ └──┬──┘
└─────────────────────┘             │       │       │
                                    └───────┴───────┘
                                    Network = Unreliable!
```

### Key Mindset Changes
| Single Machine | Distributed |
|----------------|-------------|
| Everything works | Anything can fail |
| Latency = 0 | Network latency exists |
| One source of truth | Consistency challenges |
| Sync = easy | Async often needed |

### Quick Recall Summary
College = single machine. Industry = distributed. Mindset change = failures assume karo, network unreliable.

---

#### 1 Minute Recall Block
```
MINDSET SHIFT:
• Single → Distributed
• "Works" → "Can fail"
• Latency 0 → Network latency
• Sync → Async often
```

#### 5 Bullet Memory Hooks
1. College = 1 machine, Industry = 1000s
2. Network = Unreliable (assume)
3. Anything can fail
4. Consistency = Hard in distributed
5. Async > Sync for scale

#### Common Interview Trap
⚠️ **Trap:** "Assume perfect network" — Never! Interviewer will say "network fails" — tum ready hona chahiye.

---

## 4. 3 Enemies

### What Problem?
- System design me kya-kya problems aate hain? Categorize karo.

### Why Needed?
- Enemies identify = Solution target

### Core Concept
**3 Enemies of Large Systems**

```
         ┌─────────────────────────────────────────┐
         │         3 ENEMIES                       │
         └─────────────────────────────────────────┘
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
   ┌─────────┐      ┌──────────┐      ┌──────────┐
   │  SCALE  │      │ FAILURE  │      │COMPLEXITY│
   └─────────┘      └──────────┘      └──────────┘
        │                 │                 │
   Load badh gaya    Server down       Too many
   Users badh gaye   Network partition  components
   Data badh gaya    Disk full         Hard to debug
```

### Enemy 1: Scale
- **Problem:** 10 users → 10M users. Same design kaam nahi karega.
- **Solution:** Horizontal scaling, sharding, caching

### Enemy 2: Failure
- **Problem:** Hardware fails. Network fails. Software has bugs.
- **Solution:** Redundancy, replication, circuit breakers

### Enemy 3: Complexity
- **Problem:** 100 microservices = Debug nightmare
- **Solution:** Observability, clear boundaries, simplicity where possible

### Quick Recall Summary
3 Enemies: Scale (load), Failure (anything breaks), Complexity (too many parts)

---

#### 1 Minute Recall Block
```
3 ENEMIES:
1. SCALE - Load, users, data badh gaya
2. FAILURE - Server down, network partition
3. COMPLEXITY - Too many components, debug hard
```

#### 5 Bullet Memory Hooks
1. Scale = Horizontal, sharding, cache
2. Failure = Redundancy, replication
3. Complexity = Observability, boundaries
4. All 3 = Trade-offs
5. No system beats all 3 perfectly

#### Common Interview Trap
⚠️ **Trap:** "Scale solve kiya, done!" — Failure aur Complexity bhi address karo. Interviewer puchenga "Server fail ho gaya toh?"

---

## 5. Core Properties

### What Problem?
- "Reliable system chahiye" — Matlab kya exactly?
- Terms clearly define karo

### Why Needed?
- Interview me "availability vs reliability" — different hain!
- Precise language = Senior engineer

### Core Concept

```
┌────────────────────────────────────────────────────────────────┐
│                    CORE PROPERTIES                               │
├────────────────────────────────────────────────────────────────┤
│  RELIABILITY    → System sahi kaam kare (correctness)           │
│  AVAILABILITY   → System up ho (uptime %)                       │
│  SCALABILITY    → Load handle kar sake                          │
│  MAINTAINABILITY→ Easy to change, debug                         │
│  PERFORMANCE    → Fast response, high throughput                │
└────────────────────────────────────────────────────────────────┘
```

### Table: Property Definitions
| Property | Definition | Example |
|----------|------------|---------|
| **Reliability** | Correct output, no data loss | Bank: Wrong balance = Disaster |
| **Availability** | Uptime % (99.9% = 8.76 hr/year down) | Netflix: Downtime = Lost revenue |
| **Scalability** | Load increase handle | Diwali sale: 10x traffic |
| **Maintainability** | Easy to modify | Add new feature without rewrite |
| **Performance** | Latency + Throughput | Search < 100ms |

### Availability Math
```
99.9%  = 8.76 hours downtime/year
99.99% = 52.6 minutes/year
99.999%= 5.26 minutes/year
```

### Nines Explained
| Nines | Downtime/Year | Use Case |
|-------|---------------|----------|
| 99% | 3.65 days | Internal tools |
| 99.9% | 8.76 hours | Most web apps |
| 99.99% | 52.6 min | Banking, payments |
| 99.999% | 5.26 min | Telecom, critical |

### Quick Recall Summary
Reliability = Correct. Availability = Up. Scalability = Load. Maintainability = Change. Performance = Fast.

---

#### 1 Minute Recall Block
```
CORE PROPERTIES:
• Reliability = Correct output
• Availability = Uptime %
• Scalability = Load handle
• Maintainability = Easy change
• Performance = Fast
```

#### 5 Bullet Memory Hooks
1. Reliability ≠ Availability (different!)
2. 99.9% = 8.76 hr/year down
3. Bank = Reliability critical
4. Netflix = Availability critical
5. All 5 = Trade-offs between them

#### Common Interview Trap
⚠️ **Trap:** "Reliability aur Availability same hain" — Nahi! Reliability = correctness, Availability = uptime. Bank reliable hona chahiye (wrong balance mat do), available 99% bhi chalega.

---

## 6. Latency vs Throughput

### What Problem?
- "System fast chahiye" — Latency fast ya throughput high?
- Different metrics, different solutions

### Why Needed?
- Gaming = Low latency
- Batch processing = High throughput
- Wrong optimization = Waste

### Core Concept

**Restaurant Analogy:**
```
LATENCY = Ek customer ko order deliver hone me kitna time?
THROUGHPUT = Ek ghante me kitne orders complete?

Slow waiter, 1 table  → Low latency (1 order), Low throughput
Fast waiter, 10 tables → Slightly higher latency, 10x throughput
```

### ASCII Diagram
```
         Request 1 ──► [Server] ──► Response 1
              │                         │
              │     LATENCY = Time for 1 request
              │                         │
         Request 2 ──► [Server] ──► Response 2
              │                         │
         Request 3 ──► [Server] ──► Response 3
              │                         │
         THROUGHPUT = Requests per second (e.g., 1000 RPS)
```

### Comparison Table
| Metric | Definition | Unit | Optimize For |
|--------|------------|------|--------------|
| **Latency** | Time for 1 request | ms, sec | Real-time, gaming |
| **Throughput** | Requests per time | QPS, RPS | Batch, analytics |

### Latency Hierarchy (Order of magnitude)
```
L1 Cache     ~0.001 ms  (1 μs)
L2 Cache     ~0.01 ms   (10 μs)
RAM          ~0.1 ms    (100 μs)
SSD          ~1 ms
HDD          ~10 ms
Same DC      ~0.5 ms
Cross DC     ~50-100 ms
Cross Region ~150-300 ms
```

### Quick Recall Summary
Latency = 1 request ka time. Throughput = Kitne requests/second. Different cheezein — optimize based on use case.

---

#### 1 Minute Recall Block
```
LATENCY vs THROUGHPUT:
• Latency = 1 request time (ms)
• Throughput = Requests/sec (QPS)
• Gaming = Latency
• Batch = Throughput
• Restaurant: 1 order time vs orders/hour
```

#### 5 Bullet Memory Hooks
1. Latency = Single request time
2. Throughput = QPS/RPS
3. L1 cache ~1μs, Cross region ~200ms
4. Real-time = Latency critical
5. Batch = Throughput critical

#### Common Interview Trap
⚠️ **Trap:** "Fast = Low latency" — Not always! Batch job me throughput matter karta hai. Clarify use case.

---

## 7. Trade-offs

### What Problem?
- "Perfect system banao" — Impossible!
- Every choice has cost

### Why Needed?
- Interview me "why this over that?" — Trade-off explain karo
- No free lunch in system design

### Core Concept
**No Perfect System — Budget Mental Model**

```
Socho tumhare paas ₹100 budget hai:

    Consistency ──┬── ₹40 spend
    Availability ─┼── ₹30 spend
    Performance ──┼── ₹20 spend
    Simplicity ───┴── ₹10 spend

    Total = ₹100 (fixed!)

Agar Consistency pe zyada spend = Availability kam
Trade-off = Choice between competing goals
```

### Common Trade-off Pairs
| Trade 1 | Trade 2 | Example |
|---------|---------|---------|
| Consistency | Availability | CAP Theorem |
| Latency | Throughput | Sync vs Async |
| Complexity | Flexibility | Monolith vs Microservices |
| Cost | Performance | More servers = $ |
| Strong consistency | Scale | Distributed DB |

### CAP Theorem (Quick)
```
     C - Consistency (sab same data dekhe)
     A - Availability (hamesha respond)
     P - Partition tolerance (network split)

     Network partition = Real world me hoga
     So: CP ya AP choose karna padega
     CA = Impossible in distributed
```

### CAP in Practice
| System | Choice | Why |
|--------|--------|-----|
| Bank | CP | Wrong balance = Disaster |
| Social feed | AP | Stale OK, always show something |
| Cassandra | AP | Availability priority |
| MongoDB | CP (configurable) | Strong consistency option |

### Quick Recall Summary
Trade-off = Choice. Budget model — sab pe spend nahi kar sakte. CAP = CP or AP, CA impossible.

---

#### 1 Minute Recall Block
```
TRADE-OFFS:
• No perfect system
• Budget model: Limited resources
• CAP: CP or AP (CA impossible)
• Consistency vs Availability common
• "Why this?" = Trade-off explain
```

#### 5 Bullet Memory Hooks
1. No free lunch
2. CAP = Partition = real, so CP or AP
3. Consistency ↔ Availability
4. Every choice = Trade-off
5. Interview = "Why?" = Trade-off answer

#### Common Interview Trap
⚠️ **Trap:** "We'll have both consistency and availability" — CAP says no (during partition). Clarify: "Normal case me both, partition me choose."

---

## 8. Building Blocks

### What Problem?
- System design me kaun-kaun se components use hote hain?
- Lego blocks jaisa — standard pieces

### Why Needed?
- Interview me "components kya honge?" — Yeh blocks
- Reusable across designs

### Core Concept

```
┌─────────────────────────────────────────────────────────────────┐
│                    BUILDING BLOCKS                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│   [Client] ──► [API Gateway] ──► [Load Balancer] ──► [Servers]   │
│                    │                    │               │         │
│                    │                    │               ▼         │
│                    │                    │         [Cache]         │
│                    │                    │               │         │
│                    │                    │               ▼         │
│                    │                    │         [Database]     │
│                    │                    │                         │
│                    │                    └──────► [Queue]          │
│                    │                                         │     │
│                    └────────────────────────────► [CDN]      │     │
│                                                          ▼   │     │
│                                                    [Workers] │     │
└─────────────────────────────────────────────────────────────────┘
```

### Block Descriptions
| Block | Purpose | When to Use |
|-------|---------|-------------|
| **Server** | Business logic, compute | Always |
| **Database** | Persistent storage | Data persist chahiye |
| **Cache** | Fast read, temporary | Read-heavy, reduce DB load |
| **Load Balancer** | Distribute traffic | Multiple servers |
| **Queue** | Async, decouple | Peak handling, async tasks |
| **CDN** | Static content, edge | Images, videos, static |
| **API Gateway** | Single entry, auth, rate limit | Microservices, security |

### Block Selection Guide
```
Simple App (1K users)     → Server + DB
Growing (10K users)       → + LB + Cache
Scale (100K users)        → + CDN + Queue
Enterprise (1M+ users)    → + API Gateway + Microservices
```

### Quick Recall Summary
7 Blocks: Server, DB, Cache, LB, Queue, CDN, API Gateway. Lego jaisa — combine karke system banao.

---

#### 1 Minute Recall Block
```
BUILDING BLOCKS:
• Server, DB, Cache, LB, Queue, CDN, API Gateway
• LB = Distribute traffic
• Cache = Fast read
• Queue = Async, decouple
• CDN = Static, edge
```

#### 5 Bullet Memory Hooks
1. 7 core blocks
2. LB = Multiple servers ke liye
3. Cache = Read-heavy
4. Queue = Async, peak
5. CDN = Static content

#### Common Interview Trap
⚠️ **Trap:** "Sab blocks use karenge" — Nahi! Requirements pe depend. Simple URL shortener me CDN optional. Over-engineer mat karo.

---

## 9. System Evolution

### What Problem?
- Ek system kaise grow hota hai? Step by step.
- Start simple, evolve as needed

### Why Needed?
- Interview: "Scale karo" — Evolution steps batao
- Over-engineering avoid — start small

### Core Concept
**Evolution Stages**

```
STAGE 1: Single Server
┌─────────────────────┐
│  App + DB (same)    │  ← Everything on 1 machine
└─────────────────────┘

STAGE 2: Separate DB
┌─────────┐     ┌─────────┐
│  App    │────►│   DB    │  ← DB alag (scaling)
└─────────┘     └─────────┘

STAGE 3: LB + Multiple Servers
         ┌─────────┐
    ┌───►│ Server1 │
    │    └─────────┘
[LB]├───►│ Server2 │     ┌─────────┐
    │    └─────────┘────►│   DB    │
    └───►│ Server3 │     └─────────┘
         └─────────┘

STAGE 4: DB Replication
    [LB] ──► [Servers] ──► [Primary DB]
                                │
                                ├──► [Replica 1] (Reads)
                                └──► [Replica 2] (Reads)

STAGE 5: Cache
    [LB] ──► [Servers] ──► [Cache] ──► [DB]
                    (cache miss)

STAGE 6: CDN
    [Client] ──► [CDN] (static) ──► [Origin]
    [Client] ──► [API] ──► [Servers]

STAGE 7: Message Queue
    [Servers] ──► [Queue] ──► [Workers] ──► [DB]
                    (async, decouple)

STAGE 8: Microservices
    [API Gateway] ──► [Service A] [Service B] [Service C]
                          │            │            │
                      [DB A]      [DB B]      [DB C]
```

### Evolution Triggers
| Stage | Trigger: "Kab add karo?" |
|-------|---------------------------|
| Separate DB | App + DB resource conflict |
| LB + Servers | Single server overload |
| Replication | Read load high |
| Cache | Repeated reads, DB slow |
| CDN | Static content, global users |
| Queue | Async needed, peak handling |
| Microservices | Team size, independent deploy |

### Evolution Anti-Pattern
```
❌ WRONG: "Pehle se microservices bana lo"
✅ RIGHT: "Monolith se start, need pe split"

❌ WRONG: "Sab stages ek saath add karo"
✅ RIGHT: "Bottleneck pe add karo, measure karo"
```

### Quick Recall Summary
1→2→3→4→5→6→7→8. Start simple. Need pe add karo. Over-engineer mat karo.

---

#### 1 Minute Recall Block
```
SYSTEM EVOLUTION:
1. Single server
2. Separate DB
3. LB + Multiple servers
4. DB Replication
5. Cache
6. CDN
7. Message Queue
8. Microservices
Trigger = Need (overload, read-heavy, etc.)
```

#### 5 Bullet Memory Hooks
1. Start = 1 server
2. LB = Multiple servers
3. Replication = Read scaling
4. Cache = Repeated reads
5. Microservices = Last (complexity)

#### Common Interview Trap
⚠️ **Trap:** "Direct microservices bana dete hain" — Galat! Start monolith. Microservices = Complexity + overhead. Jab team/scale justify kare tab.

---

## 10. 15 Golden Rules

### What Problem?
- System design me kya-kya yaad rakhna?
- Quick checklist

### Core Concept

```
1.  REQUIREMENTS CLARIFY — Scope, scale, constraints
2.  START SIMPLE — Monolith first
3.  BACK-OF-ENVELOPE — Numbers estimate karo
4.  BOTTLENECK IDENTIFY — Weakest link
5.  HORIZONTAL > VERTICAL — Scale out preferred
6.  STATELESS SERVERS — Session external
7.  CACHE WISELY — What to cache, TTL
8.  ASYNC WHERE POSSIBLE — Queue, decouple
9.  FAILURE ASSUME — Redundancy, retry
10. CONSISTENCY vs AVAILABILITY — CAP, choose
11. MONITORING — Observability from start
12. SECURITY — Auth, encryption, rate limit
13. DATABASE RIGHT — SQL vs NoSQL, indexing
14. API DESIGN — Versioning, idempotency
15. TRADE-OFFS DOCUMENT — Why this choice
```

### Quick Recall Summary
15 rules = Requirements, Simple start, Numbers, Bottleneck, Horizontal, Stateless, Cache, Async, Failure, CAP, Monitor, Security, DB, API, Trade-offs.

---

#### 1 Minute Recall Block
```
15 GOLDEN RULES:
Requirements, Simple, Numbers, Bottleneck
Horizontal, Stateless, Cache, Async
Failure, CAP, Monitor, Security
DB, API, Trade-offs
```

#### 5 Bullet Memory Hooks
1. Clarify requirements first
2. Start simple (monolith)
3. Back-of-envelope numbers
4. Stateless = Horizontal scale
5. Assume failure

#### Common Interview Trap
⚠️ **Trap:** "Rules yaad karke rattna" — Nahi! Understand karo. Interview me naturally apply ho.

---

## 11. How System Design Interview Works

### What Problem?
- Interview me kya expect karte hain?
- Framework follow karo = Structured answer

### Core Concept
**4-Step Framework**

```
STEP 1: REQUIREMENTS (5-10 min)
├── Functional: Kya features?
├── Non-functional: Scale, latency?
├── Clarify: Ambiguity resolve
└── Scope: In scope / Out of scope

STEP 2: HIGH-LEVEL DESIGN (10-15 min)
├── Components: Client, API, Servers, DB
├── Diagram: Draw it
└── Data flow: Request path

STEP 3: DEEP DIVE (15-20 min)
├── Bottleneck: Identify
├── Scale: How handle?
├── DB: Schema, sharding?
└── Pick 2-3 areas: Detail me

STEP 4: WRAP UP (5 min)
├── Trade-offs: What we sacrificed
├── Improvements: Future
└── Summary: Recap
```

### Common Mistakes
| Mistake | Right Approach |
|---------|----------------|
| Jump to solution | Requirements clarify first |
| No numbers | Back-of-envelope estimate |
| Perfect design | Trade-offs acknowledge |
| Silent | Think aloud, communicate |
| Ignore scale | "10M users" = Different design |

### What Good Looks Like
- Asks clarifying questions
- Draws diagram, explains flow
- Discusses trade-offs
- Handles "what if" (failure, scale)
- Time management

### Pre-Interview Checklist
```
□ Whiteboard/paper ready
□ Clarify: Scale? Latency? Consistency?
□ Start with high-level (don't dive deep early)
□ Back-of-envelope numbers
□ Trade-offs mention
□ "What if X fails?" — Answer ready
□ Time: 5-10 min requirements, 10-15 design, 15-20 deep dive
```

### Quick Recall Summary
4 Steps: Requirements → High-level → Deep dive → Wrap up. Communicate, numbers, trade-offs.

---

#### 1 Minute Recall Block
```
INTERVIEW FRAMEWORK:
1. Requirements (clarify, scope)
2. High-level (components, diagram)
3. Deep dive (bottleneck, scale)
4. Wrap up (trade-offs, improvements)
Think aloud! Numbers! Trade-offs!
```

#### 5 Bullet Memory Hooks
1. Don't jump to solution
2. Clarify requirements
3. Draw diagram
4. Think aloud
5. Acknowledge trade-offs

#### Common Interview Trap
⚠️ **Trap:** "Design perfect hona chahiye" — Interviewer wants to see thinking process. Wrong choice + good reasoning > Silent perfect diagram.

---

## 12. Scale Numbers to Remember

### What Problem?
- "10M users" — Matlab kitna QPS? Kitna storage?
- Numbers sense = Realistic design

### Core Concept

**Latency Hierarchy (approx)**
```
L1 Cache     1 μs
L2 Cache     10 μs
RAM          100 μs
SSD          1 ms
HDD          10 ms
Same DC      0.5 ms
Cross DC     50-100 ms
Cross Region 150-300 ms
```

**QPS Ranges**
| Scale | Users | QPS (rough) | Example |
|-------|-------|-------------|---------|
| Small | 1K | 10-100 | Startup |
| Medium | 100K | 1K-10K | Growing app |
| Large | 1M | 10K-100K | Popular app |
| Huge | 10M+ | 100K+ | Twitter, Instagram |

**Storage (rough)**
- 1M users, 1KB/user = 1 GB
- 1M users, 100 photos (1MB each) = 100 TB

### Quick Recall Summary
L1~1μs, SSD~1ms, Cross-region~200ms. QPS: 1M users ~10K-100K. Numbers estimate karo.

---

#### 1 Minute Recall Block
```
SCALE NUMBERS:
• L1 ~1μs, SSD ~1ms, Cross-region ~200ms
• 1M users ≈ 10K-100K QPS
• 1M users, 100 photos = 100 TB
• Back-of-envelope = Important
```

#### 5 Bullet Memory Hooks
1. L1 cache fastest
2. Cross-region slowest
3. 1M users = 10K+ QPS
4. Storage = Users × Data size
5. Estimate = Interview must

#### Common Interview Trap
⚠️ **Trap:** "Exact numbers yaad karne" — Order of magnitude enough. 1ms vs 100ms matter karta hai, 1ms vs 1.2ms nahi.

---

## 13. Anti-Patterns

### What Problem?
- Kya NAHI karna? Common mistakes.

### Why Needed?
- Avoid these = Better design

### Core Concept
**What NOT to Do**

| Anti-Pattern | Problem | Right Approach |
|--------------|---------|----------------|
| **Over-engineering** | Simple problem, complex solution | Start simple |
| **Single point of failure** | One component down = System down | Redundancy |
| **No caching** | DB har request pe | Cache hot data |
| **Sync everything** | Blocking, slow | Async where possible |
| **Ignore failure** | "Won't happen" | Assume, plan |
| **Tight coupling** | Change = Break everything | Loose coupling |
| **No monitoring** | Blind in production | Observability |
| **Premature optimization** | Optimize before measure | Measure first |
| **No rate limiting** | DDoS vulnerable | Rate limit, throttle |
| **Hardcode config** | Deploy = Code change | Config external |

### Quick Recall Summary
Anti-patterns: Over-engineer, SPOF, No cache, Sync all, Ignore failure, Tight coupling, No monitor, Premature opt, No rate limit, Hardcode.

---

#### 1 Minute Recall Block
```
ANTI-PATTERNS:
• Over-engineering
• Single point of failure
• No cache
• Sync everything
• Ignore failure
• No monitoring
• Premature optimization
```

#### 5 Bullet Memory Hooks
1. Start simple
2. No SPOF
3. Cache hot data
4. Assume failure
5. Monitor from start

#### Common Interview Trap
⚠️ **Trap:** "Microservices for everything" — Anti-pattern! Complexity without need. Monolith first.

---

## Final Recap

```
SYSTEM DESIGN FOUNDATION — ONE PAGE
═══════════════════════════════════
• Blueprint = City planning for software
• 3 Enemies = Scale, Failure, Complexity
• Properties = Reliability, Availability, Scalability, Maintainability, Performance
• Latency ≠ Throughput
• Trade-offs = No perfect system, CAP
• Blocks = Server, DB, Cache, LB, Queue, CDN, API Gateway
• Evolution = 1→2→3→4→5→6→7→8 (need pe add)
• 15 Rules = Requirements, Simple, Numbers...
• Interview = 4 steps, think aloud, trade-offs
• Numbers = L1~μs, Cross-region~200ms, 1M users~10K QPS
• Anti-patterns = Over-engineer, SPOF, No cache...
═══════════════════════════════════
```

---

*End of System Design Kya Hai — Foundation Complete*
