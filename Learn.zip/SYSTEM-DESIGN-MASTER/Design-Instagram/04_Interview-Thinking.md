# Design Instagram — Interview Thinking

> **Permanent Recall:** Interview flow: 1) Clarify requirements, 2) Capacity estimate, 3) **Media pipeline** (differentiator), 4) Feed (similar to Twitter), 5) Explore + Stories. Lead with what makes Instagram unique.

---

## Walkthrough Order

| Step | Focus | Key Points |
|------|-------|------------|
| 1 | Requirements | Upload, feed, follow, like/comment, stories, explore |
| 2 | Scale | 1B MAU, 100M photos/day, 200TB/day storage |
| 3 | **Media pipeline** | S3 + async processing + CDN (this is the differentiator) |
| 4 | Feed | Fan-out, Redis, hybrid for celebrities |
| 5 | Explore | Recommendations, trending |
| 6 | Stories | Ephemeral, TTL, separate storage |

---

## How to Discuss Image Processing

- **Resize:** Generate thumbnail (150px), medium (640px), full (1080px) — don't serve raw 4K to feed
- **Filters:** Apply server-side or pre-baked LUTs; store filtered output, not filter params only
- **Compression:** JPEG quality 80–85 for feed; WebP for supported clients
- **Async:** Use **message queue** (SQS, Kafka); workers process; notify when ready

> **FAANG Tip:** Say "async processing" and "multiple resolutions" early — shows you understand media systems.

---

## CDN Strategy

- **Origin:** S3 (or GCS)
- **CDN:** CloudFront, CloudFlare, Akamai — cache at edge
- **Cache TTL:** Long (days) for immutable media — photos don't change
- **Invalidation:** Rarely needed; use versioned URLs (e.g., `photo_id_v2.jpg`)

---

## Feed Generation Approach

| Approach | Pros | Cons |
|----------|------|------|
| **Fan-out on write** | Fast reads | Slow writes for celebrities |
| **Fan-out on read** | Simple writes | Slow reads, N queries |
| **Hybrid** | Best of both | More complex |

- **Default:** Fan-out on write; push to followers' Redis timelines
- **Celebrities:** Fan-out on read — don't write to millions of timelines

---

## Explore / Recommendation System

1. **Collaborative filtering:** "Users like you liked X"
2. **Content-based:** Hashtags, similar captions, visual similarity (ML)
3. **Trending:** Engagement score with time decay
4. **Pre-compute:** Batch jobs; store per-user explore feed in cache

---

## Stories (Ephemeral Content)

- **Storage:** S3 with lifecycle policy, or dedicated **ephemeral store**
- **TTL:** 24 hours; cron or event-driven cleanup
- **Delivery:** Same CDN; different path (e.g., `/stories/`)
- **View count:** Increment in Redis; aggregate to DB periodically

---

## What to Say in Interview

> "Instagram is media-centric — unlike Twitter, we have 200TB/day of storage. So the architecture must optimize for: 1) S3 + CDN for media, 2) async image processing with multiple resolutions, 3) feed similar to Twitter but with media URLs from CDN, 4) explore for discovery, 5) stories as ephemeral content with TTL."

---

## Time Allocation (45-min interview)

| Phase | Minutes | Content |
|-------|---------|---------|
| Requirements | 5 | Clarify upload, feed, stories, explore |
| Scale / capacity | 5 | 1B MAU, 100M photos/day, 200TB/day |
| High-level design | 5 | Boxes: Client, API, S3, CDN, DB, Redis |
| Media pipeline | 10 | Upload → S3 → Queue → Process → CDN |
| Feed | 8 | Fan-out, Redis, hybrid celebrities |
| Explore + Stories | 5 | Recommendations; ephemeral TTL |
| Deep dive / trade-offs | 7 | Pick one: viral post, resumable upload, etc. |

---

## Clarifying Questions to Ask

1. **Feed:** Chronological or ranked? (Ranked → need ranking signals)
2. **Stories:** Required in v1 or can defer?
3. **Explore:** Required or nice-to-have?
4. **Video:** Same pipeline as photos or separate?
5. **Scale:** 1B from day 1 or growth path?

---

## Phrases That Show Depth

- "We'd use multipart upload for large files to support resumable uploads"
- "For celebrities, we'd use pull-based feed to avoid fan-out write storm"
- "Content moderation would run in the pipeline before CDN publish"
- "Stories would use S3 lifecycle or a dedicated ephemeral store with TTL"

---

## If You Run Out of Time

Prioritize: Media pipeline → Feed → CDN. Defer: Explore details, stories implementation.

---

## Common Follow-Ups

- "How does the client get the CDN URL?" → In feed response; metadata includes `thumbnail_url`, `full_url` pointing to CDN
- "What if processing fails?" → Retry queue; fallback serve original; alert
- "How do you rank the feed?" → Engagement score, recency, relationship strength; ML model

---

## Body Language / Confidence

- Draw the upload pipeline early — it's the differentiator
- When discussing CDN, say "we'd never serve media from origin"
- For celebrities, proactively mention "hybrid fan-out to avoid write storm"

---

## Key Differentiators to Emphasize

1. **Media pipeline** — S3, async processing, CDN (not just "we store in DB")
2. **Multiple resolutions** — Thumbnail for feed, full on tap
3. **Stories** — Ephemeral, TTL, separate from permanent posts
4. **Explore** — Recommendation engine, not just chronological

---

## Wrap-Up

Summarize: "So we have S3 and CDN for media, async processing, fan-out feed with Redis, explore for discovery, and stories with TTL. The key differentiator from Twitter is the media pipeline."

---

## Confidence Builders

- You know the numbers (100M/day, 200TB, 100:1)
- You know S3 + CDN is non-negotiable
- You know async is required
- You can draw the pipeline in 2 minutes
