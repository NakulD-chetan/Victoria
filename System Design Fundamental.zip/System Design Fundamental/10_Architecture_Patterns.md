# Architecture Patterns — System Kaise Structure Karo

> **Monolith ya Microservices? — Yeh sawaal har FAANG interview mein aata hai!**
> Sahi architecture choose karna = sahi foundation rakhna

---

## Table of Contents
1. [Monolith vs Microservices](#monolith-vs-microservices)
2. [API Gateway](#api-gateway)
3. [Service Discovery](#service-discovery)
4. [Service Mesh](#service-mesh)
5. [Communication Patterns](#communication-patterns)
6. [API Design Best Practices](#api-design-best-practices)
7. [Sync vs Async Communication](#sync-vs-async-communication)
8. [Database per Service](#database-per-service)
9. [Saga Pattern](#saga-pattern)
10. [Strangler Fig Pattern](#strangler-fig-pattern)
11. [Interview Questions & Quick Recall](#interview-questions--quick-recall)

---

## Monolith vs Microservices

### Core Concept
**Monolith:** Ek bada application — sab kuch ek codebase, ek deploy
**Microservices:** Chhote independent services — har service apna kaam, alag deploy

### Monolith Diagram

```
┌─────────────────────────────────────────────────┐
│              MONOLITHIC APPLICATION              │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌────────┐ │
│  │  Auth   │ │  User   │ │  Order  │ │Payment │ │
│  │ Module  │ │ Module  │ │ Module  │ │ Module │ │
│  └────┬────┘ └────┬────┘ └────┬────┘ └───┬────┘ │
│       │           │           │          │      │
│       └───────────┴───────────┴──────────┘      │
│                      │                          │
│              ┌───────┴───────┐                  │
│              │   Single DB   │                  │
│              └──────────────┘                  │
└─────────────────────────────────────────────────┘
```

### Microservices Diagram

```
    [API Gateway]
          |
    +-----+-----+-----+-----+
    |     |     |     |     |
    v     v     v     v     v
[Auth] [User] [Order] [Payment] [Inventory]
  |      |      |       |           |
  +------+------+-------+-----------+
    Each has own DB, own deploy, own lifecycle
```

### Detailed Comparison Table

| Aspect | Monolith | Microservices |
|--------|----------|---------------|
| **Codebase** | Single codebase | Multiple repos |
| **Deploy** | One big deploy | Independent deploys |
| **Scaling** | Scale entire app | Scale per service |
| **Complexity** | Simple initially | Complex from start |
| **Coupling** | Tight (same code) | Loose (network calls) |
| **Database** | Shared DB | DB per service |
| **Team** | One team | Multiple teams per service |
| **Failure** | One bug = whole down | Isolated failures |
| **Tech Stack** | Usually one | Polyglot possible |

### When to Use Which?

**Monolith Use When:**
- Startup, small team
- Unclear requirements
- Need to move fast
- Simple domain

**Microservices Use When:**
- Large team, multiple squads
- Clear bounded contexts
- Different scaling needs per service
- Need independent deploy cycles

### Decision Framework

```
START
  |
  v
Team size < 10? ---Yes--> Monolith
  |
  No
  v
Clear domain boundaries? ---No--> Monolith first
  |
  Yes
  v
Different scaling needs? ---No--> Consider Monolith
  |
  Yes
  v
Microservices
```

### Real World Example
**Netflix:** Pehle monolith tha. Scale pe problem aayi. Microservices banaya — har team apna service deploy karta hai independently.

### Common Interview Trap
> "Microservices always better?" — NO! Monolith first, extract when needed. Premature microservices = complexity disaster.

### 1 Minute Recall Block
> Monolith = simple, coupled, one deploy. Microservices = independent, complex, scale per service. Start monolith, extract when needed.

### 5 Bullet Memory Hooks
- Monolith = ek bada app, single deploy
- Microservices = chhote services, independent
- Monolith first = YAGNI principle
- Microservices = team scaling, tech flexibility
- Wrong choice = technical debt

---

## API Gateway

### Core Concept
**Single entry point** for all client requests — saari routing, auth, rate limiting ek jagah

### How It Works

```
[All Clients] ---> [API Gateway] ---> [Service 1]
                         |        ---> [Service 2]
                         |        ---> [Service 3]
                         |
                    Auth, Rate Limit,
                    Routing, Logging
```

### API Gateway Responsibilities

| Responsibility | Matlab |
|----------------|--------|
| **Routing** | /users → User Service, /orders → Order Service |
| **Authentication** | JWT verify, API key check |
| **Rate Limiting** | 100 req/min per user |
| **Load Balancing** | Multiple instances of service |
| **SSL Termination** | HTTPS handle |
| **Caching** | Response cache |
| **Request/Response Transform** | Protocol conversion |

### Real World Example
**Amazon:** Customer ek URL hit karta hai. API Gateway pehle auth check, phir routing — Product Service, Cart Service, etc.

### Common Interview Trap
> "API Gateway vs Load Balancer?" — LB = traffic distribution. API Gateway = routing + auth + rate limit + protocol. Gateway = LB + more.

### 1 Minute Recall Block
> API Gateway = single entry, routing + auth + rate limit + protocol handling. Clients ko sirf gateway pata, services hidden.

### 5 Bullet Memory Hooks
- Single entry point
- Auth + routing + rate limit
- Backend services hide
- Kong, AWS API Gateway, Zuul
- BFF (Backend for Frontend) pattern

---

## Service Discovery

### Core Concept
Services kaise ek doosre ko find karte hain? IP/port dynamic hai — service discovery dynamic lookup provide karta hai.

### Problem
```
Order Service needs to call Payment Service
But Payment Service IP changes (auto-scaling, restart)
How does Order Service know where to call?
```

### Client-Side Discovery

```
[Order Service] ---> [Discovery Registry] "Payment Service kahan hai?"
                            |
                            v
                    Returns: [IP1, IP2, IP3]
                            |
[Order Service] ---> Chooses one, calls directly
```

- Client registry se list leta hai, khud choose karta hai
- **Examples:** Eureka (Netflix), Consul
- **Pros:** No extra hop, client control
- **Cons:** Client logic complex, every client needs discovery lib

### Server-Side Discovery

```
[Order Service] ---> [Load Balancer] ---> [Payment Service]
                            |
                    [Registry] - LB knows from registry
```

- Client sirf LB/Discovery service ko call karta hai
- Server-side routing decide karta hai
- **Examples:** Kubernetes Service, AWS ALB
- **Pros:** Client simple
- **Cons:** Extra network hop

### Comparison Table

| Aspect | Client-Side | Server-Side |
|--------|-------------|-------------|
| **Who decides** | Client | Load Balancer |
| **Client complexity** | High | Low |
| **Network hops** | Less | More |
| **Example** | Eureka, Consul | K8s Service, ALB |

### 1 Minute Recall Block
> Service Discovery = services find each other dynamically. Client-side = client registry se list, server-side = LB handles.

### 5 Bullet Memory Hooks
- Dynamic IP problem
- Client-side = Eureka, Consul
- Server-side = K8s, ALB
- Registry = service registry (etcd, Consul)
- Health check = registry update

---

## Service Mesh

### Core Concept
**Infrastructure layer** for service-to-service communication — traffic management, security, observability

### How It Works
Har service ke saath **sidecar proxy** (Envoy) — saari inter-service traffic proxy se hoti hai

```
[Service A] <---> [Sidecar Proxy] <---> [Sidecar Proxy] <---> [Service B]
                       |                        |
                  Retry, Timeout,          Retry, Timeout,
                  TLS, Metrics             TLS, Metrics
```

### Service Mesh Benefits

| Benefit | Matlab |
|---------|--------|
| **Traffic Management** | Retry, timeout, circuit breaker |
| **Security** | mTLS (service-to-service encryption) |
| **Observability** | Distributed tracing, metrics |
| **No Code Change** | Infrastructure level — app code same |

### Istio vs Envoy
- **Envoy:** Proxy implementation
- **Istio:** Control plane (Envoy ko manage karta hai) + policies

### When to Use
- Many microservices
- Need cross-cutting concerns (retry, auth, tracing)
- Don't want to code in every service

### Common Interview Trap
> "Service Mesh vs API Gateway?" — API Gateway = north-south (client to cluster). Service Mesh = east-west (service to service).

### 1 Minute Recall Block
> Service Mesh = sidecar proxy per service. Traffic management, mTLS, observability without code change. Istio, Linkerd.

---

## Communication Patterns

### REST
- HTTP + JSON
- Stateless, resource-based
- **Use:** Public APIs, CRUD

### gRPC
- HTTP/2 + Protocol Buffers
- Binary, fast, streaming
- **Use:** Internal microservices, high performance

### GraphQL
- Single endpoint, client decides schema
- **Use:** Mobile apps, flexible data needs

### Comparison Table

| Pattern | Protocol | Use Case | Pros | Cons |
|---------|----------|----------|------|------|
| **REST** | HTTP/JSON | Public API | Simple, cacheable | Over-fetching |
| **gRPC** | HTTP/2+Proto | Internal | Fast, streaming | Browser support limited |
| **GraphQL** | HTTP | Flexible APIs | Client controls | Complex, caching hard |

### 1 Minute Recall Block
> REST = simple, public. gRPC = fast, internal. GraphQL = flexible, client-driven.

---

## API Design Best Practices

### REST Conventions

| Method | Action | Example |
|--------|--------|---------|
| GET | Read | GET /users/123 |
| POST | Create | POST /users |
| PUT | Replace | PUT /users/123 |
| PATCH | Partial update | PATCH /users/123 |
| DELETE | Delete | DELETE /users/123 |

### HTTP Status Codes
- 200 OK, 201 Created, 204 No Content
- 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found
- 500 Internal Server Error

### Versioning Strategies
- **URL:** /v1/users, /v2/users
- **Header:** Accept: application/vnd.api+json;version=1
- **Query:** /users?version=1

### Best Practices
- Use nouns, not verbs: /users not /getUsers
- Plural: /users not /user
- Nested resources: /users/123/orders
- Filter: /users?status=active
- Pagination: /users?page=1&limit=20

### Common Interview Trap
> "PUT vs PATCH?" — PUT = full replace. PATCH = partial update. Idempotency: PUT yes, PATCH maybe.

---

## Sync vs Async Communication

### Synchronous
- Caller waits for response
- Tight coupling
- **Example:** REST call, gRPC

```
[Service A] ---request---> [Service B]
              <---response---
         (blocks until response)
```

### Asynchronous
- Fire and forget / callback
- Loose coupling
- **Example:** Message queue, events

```
[Service A] ---message---> [Queue] ---> [Service B]
         (doesn't wait)              (processes later)
```

### When to Use

| Sync | Async |
|------|-------|
| Need immediate response | Can process later |
| Simple request-response | Event-driven |
| Strong consistency | Eventually consistent |
| User waiting | Background jobs |

### 1 Minute Recall Block
> Sync = wait for response, tight coupling. Async = message queue, loose coupling. User-facing = sync. Background = async.

---

## Database per Service

### Core Concept
Har microservice ka **apna database** — no shared DB!

```
[Order Service] ---> [Order DB]
[User Service] ---> [User DB]
[Payment Service] ---> [Payment DB]
```

### Why?
- Data ownership clear
- Independent scaling
- Technology choice per service
- Failure isolation

### Challenge: Data Consistency
Order service ko user info chahiye — but User DB alag hai!
- **Solution:** API call to User Service (not direct DB)
- **Or:** Event-driven, eventual consistency

### Common Interview Trap
> "Shared DB in microservices?" — Anti-pattern! Tight coupling, can't scale independently. DB per service required.

---

## Saga Pattern

### Core Concept
**Distributed transactions** — ACID across services possible nahi, Saga = sequence of local transactions + compensation

### Problem
Order place: Reserve inventory → Charge payment → Create order
Agar payment fail? Inventory already reserved!

### Saga Pattern

**Choreography:** Each service emits event, next service listens
```
[Order] --OrderCreated--> [Inventory] --Reserved--> [Payment] --Charged--> [Order]
```

**Orchestration:** Central orchestrator coordinates
```
[Orchestrator] --> Reserve Inventory --> Charge Payment --> Create Order
                      (fail?) --> Compensate: Release Inventory
```

### Compensation
Agar koi step fail — reverse previous steps (compensation transaction)

### 1 Minute Recall Block
> Saga = distributed transaction pattern. Local transactions + compensation on failure. Choreography vs Orchestration.

### 5 Bullet Memory Hooks
- No 2PC in microservices
- Saga = sequence + compensate
- Choreography = event-driven
- Orchestration = central coordinator
- Compensation = undo previous steps

---

## Strangler Fig Pattern

### Core Concept
**Monolith to Microservices migration** — gradually replace, not big bang

### How It Works
```
BEFORE:
[Client] ---> [Monolith]

DURING (Strangler):
[Client] ---> [API Gateway] ---> [New Service] (new features)
                         \---> [Monolith] (old features)

AFTER:
[Client] ---> [API Gateway] ---> [Service 1] [Service 2] [Service 3]
```

### Steps
1. Create facade (API Gateway) in front of monolith
2. New features = new microservices
3. Gradually migrate old features from monolith to services
4. Eventually monolith empty — remove

### Real World
**Amazon, Netflix** — yahi pattern use karke migrate kiye

### 1 Minute Recall Block
> Strangler Fig = gradual migration. New features in microservices, old in monolith. Slowly replace until monolith gone.

---

## Interview Questions & Quick Recall

### Interview Questions

**Q1: Monolith vs Microservices — when which?**
> Start monolith. Microservices when: large team, clear boundaries, different scaling needs. Don't over-engineer early.

**Q2: API Gateway vs Load Balancer?**
> LB = traffic distribution. Gateway = routing + auth + rate limit + protocol. Gateway is LB + application logic.

**Q3: Service Discovery — client vs server side?**
> Client-side = client gets list, chooses. Server-side = LB handles. K8s = server-side. Eureka = client-side.

**Q4: Service Mesh kya hai?**
> Sidecar proxy per service. Traffic management, mTLS, observability. North-south = API Gateway, East-west = Service Mesh.

**Q5: Database per service — why?**
> Loose coupling, independent scaling, failure isolation. Shared DB = anti-pattern.

**Q6: Saga pattern — when use?**
> Distributed transaction across services. No 2PC. Compensation on failure.

**Q7: How to migrate monolith to microservices?**
> Strangler Fig — gradual. New features in new services. Migrate old incrementally.

### Common Interview Traps
- "Microservices always better" — NO
- "Shared DB for simplicity" — Anti-pattern
- "Sync for everything" — Async for decoupling
- "Big bang migration" — Strangler Fig

### Quick Recall — Full Cheat Sheet

```
ARCHITECTURE PATTERNS CHEAT SHEET
==================================
• Monolith: Simple first, extract when needed
• Microservices: Independent, DB per service
• API Gateway: Single entry, auth, routing, rate limit
• Service Discovery: Client-side (Eureka) vs Server-side (K8s)
• Service Mesh: East-west, sidecar, Istio/Envoy
• REST: Public, gRPC: Internal, GraphQL: Flexible
• Sync: Immediate response | Async: Decouple
• Saga: Distributed transaction + compensation
• Strangler Fig: Gradual monolith migration
```

### 5 Bullet Memory Hooks (Full Topic)
- Monolith first, microservices when needed
- API Gateway = single entry + smart routing
- Service Discovery = dynamic service finding
- DB per service = no shared DB
- Strangler Fig = gradual migration
