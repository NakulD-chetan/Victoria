# Python File I/O and Serialization

> *"Always close resources — with statement makes it automatic"* — Best practice

Files, `pathlib`, CSV, JSON, pickle — data goes to disk and comes back. This note covers practical I/O after [[10-Python-Exception-Handling]].

---

## 1. `open()` and modes

> **Definition:** **`open(path, mode, ...)`** returns a file object connected to disk (or another file descriptor); the **mode** string selects read, write, append, text vs binary, and optional read/write updates.

**Why we need it:** Programs must read configuration and write output reliably across OSes; explicit modes and encodings prevent silent corruption and “wrong default on Windows” surprises.

**Syntax:**
```python
open(path, mode="r", encoding="utf-8")
# modes: r, w, a, x, b, t, + combinations e.g. "rb", "w+", "a"
```

| Mode | What it does |
|------|---------|
| `r` | **Read** — opens file to read (file must exist) |
| `w` | **Write** — creates new file or ERASES existing file and writes fresh |
| `a` | **Append** — adds to the END of file (keeps existing content) |
| `x` | **Exclusive create** — creates new file, ERROR if file already exists |
| `b` | **Binary** — for non-text files like images (`rb`, `wb`) |
| `t` | **Text** — for text files (default, don't need to write it) |
| `+` | **Read+Write** — both reading and writing (`r+`, `w+`, etc.) |

```python
with open("data.txt", "r", encoding="utf-8") as f:  # Opens file for reading
    text = f.read()   # Reads ENTIRE file content into a string
# File is automatically closed when "with" block ends — even if error happens
```

**Watch Out!** Keep **encoding** explicit — Windows default can surprise; **UTF-8** is standard.

---

## 2. `with` statement — context manager

> **Definition:** The **`with`** statement enters a **context manager** (object with `__enter__`/`__exit__`), binds its result to a name, runs the block, and **always** runs cleanup on exit—including after exceptions.

**Why we need it:** Files and locks must close even when code fails mid-block; `with` pairs acquisition and release so you do not leak handles or forget `finally`.

**Syntax:**
```python
with open(path, mode, encoding="utf-8") as f:
    ...
# f closed here
```

File objects use `__enter__`/`__exit__` — close **always** (even after an error).

```python
with open("out.txt", "w", encoding="utf-8") as f:  # Opens file for writing (creates/erases)
    f.write("line1\n")              # Writes one string to the file
    f.writelines(["a\n", "b\n"])    # Writes a LIST of strings (no newlines added automatically!)
```

**Interview Tip:** RAII-style — Pythonic `with`; custom resources [[09-Python-Encapsulation-Special-Methods]].

---

## 3. Reading patterns

> **Definition:** **Reading patterns** are the ways you pull data from a file—whole string, line by line, or fixed-size **chunks**—balancing simplicity and memory use.

**Why we need it:** Huge files cannot fit in RAM at once; streaming lines or chunks keeps memory stable while small files can use `read()` or `readlines()` conveniently.

**Syntax:**
```python
with open(path, encoding="utf-8") as f:
    text = f.read()
    line = f.readline()
    chunk = f.read(n)
    for line in f:
        ...
```

```python
with open("log.txt", encoding="utf-8") as f:
    for line in f:          # lazy — line by line
        process(line)

with open("big.txt", encoding="utf-8") as f:
    chunk = f.read(8192)   # fixed size chunks
```

| Method | What it does |
|--------|----------|
| `read()` | Reads EVERYTHING into one big string |
| `readline()` | Reads just ONE line at a time |
| `readlines()` | Reads ALL lines into a list (each line is one item) — uses more memory |
| `for line in f:` | Reads one line at a time in a loop — best for big files (memory friendly) |

---

## 4. CSV — `csv` module

> **Definition:** The **`csv`** module reads and writes **comma-separated (or delimited) tabular text** with proper quoting and escaping so commas and newlines inside fields are handled correctly.

**Why we need it:** Splitting lines by hand breaks on embedded commas; `csv` matches real-world spreadsheets and exports safely and portably.

**Syntax:**
```python
import csv

with open(path, newline="", encoding="utf-8") as f:
    reader = csv.reader(f)          # or csv.DictReader(f)
    writer = csv.writer(f)          # or csv.DictWriter(f, fieldnames)
```

```python
import csv

with open("users.csv", newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row["name"], row["email"])

with open("out.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["id", "score"])
    w.writerow([1, 99])
```

**Watch Out!** `newline=""` — recommended for CSV writer (fixes extra blank lines).

---

## 5. JSON — `json` module

> **Definition:** **`json`** converts between Python objects (mostly dicts, lists, strings, numbers, bool, `None`) and **JSON** text—a language-neutral format many APIs and configs use.

**Why we need it:** You need a safe, human-readable interchange format across services and languages; JSON is the default for web APIs and config files (unlike pickle, it is not arbitrary code).

**Syntax:**
```python
import json

s = json.dumps(obj)
obj = json.loads(s)

with open(path, "w", encoding="utf-8") as f:
    json.dump(obj, f)
with open(path, encoding="utf-8") as f:
    obj = json.load(f)
```

```python
import json

data = {"user": "ravi", "scores": [10, 20]}
s = json.dumps(data, indent=2)    # Converts Python dict → JSON STRING (dumps = dump to string)
obj = json.loads(s)                # Converts JSON string → Python dict (loads = load from string)

with open("cfg.json", "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2)   # Writes Python dict → JSON FILE directly

with open("cfg.json", encoding="utf-8") as f:
    cfg = json.load(f)             # Reads JSON FILE → Python dict directly
```

**Quick summary:**
- `dumps` / `loads` = convert to/from **string** (s = string)
- `dump` / `load` = convert to/from **file** directly

**Interview Tip:** JSON keys are **strings** — Python `int` keys can cause dump issues; convert keys to str.

---

## 6. pickle — Python-only binary

> **Definition:** **`pickle`** serializes almost arbitrary Python objects to **binary** bytes and can reconstruct them with **`pickle.load`**—a Python-specific, fast snapshot format.

**Why we need it:** When you must persist custom classes, functions, or graphs that JSON cannot represent, pickle can round-trip them—**only** for trusted data you fully control.

**Syntax:**
```python
import pickle

with open(path, "wb") as f:
    pickle.dump(obj, f)
with open(path, "rb") as f:
    obj = pickle.load(f)
```

```python
import pickle

with open("state.pkl", "wb") as f:
    pickle.dump({"a": [1, 2, 3]}, f)

with open("state.pkl", "rb") as f:
    state = pickle.load(f)
```

**Watch Out!** **Untrusted pickle = RCE risk** — only trusted files. Public APIs → **JSON**.

---

## 7. `pathlib` — modern paths

> **Definition:** **`pathlib.Path`** is an object-oriented representation of filesystem paths: you join with `/`, query existence, read/write text or bytes, and iterate globs without string hacks.

**Why we need it:** Paths differ on Windows vs Unix; `Path` keeps code clear, reduces `os.path` boilerplate, and reads naturally in pipelines.

**Syntax:**
```python
from pathlib import Path

p = Path("dir") / "file.txt"
p.read_text(encoding="utf-8")
p.write_text("...", encoding="utf-8")
p.glob("*.py")
```

```python
from pathlib import Path

p = Path("data") / "sub" / "file.txt"   # Builds path: data/sub/file.txt (works on any OS)
p.exists()                    # True/False → checks if file/folder exists
p.read_text(encoding="utf-8")  # Reads entire file as string (shortcut for open+read)
p.write_text("hello", encoding="utf-8")  # Writes string to file (shortcut for open+write)
p.mkdir(parents=True, exist_ok=True)  # Creates folder (and parent folders if needed)
p.unlink()                    # Deletes the file

for child in Path(".").glob("*.py"):    # Finds all .py files in current folder
    print(child)

for child in Path(".").rglob("*.py"):   # Finds all .py files RECURSIVELY (subfolders too)
    print(child)
```

**Interview Tip:** `Path` — OS-independent joins; `rglob` recursive.

---

## 8. Binary files — bytes

> **Definition:** **Binary mode** (`"rb"`, `"wb"`, …) reads and writes **`bytes`** without text decoding—used for images, audio, pickles, and protocols that are not UTF-8 text.

**Why we need it:** Text mode can corrupt or mis-decode arbitrary bytes; binary mode preserves exact byte sequences for non-text formats.

**Syntax:**
```python
with open(path, "rb") as f:
    data: bytes = f.read()

with open(path, "wb") as f:
    f.write(b"...")
```

```python
with open("img.bin", "rb") as f:
    header = f.read(4)
```

---

## 9. Text vs binary — `rb` performance

> **Definition:** **Text mode** decodes bytes to `str` using an encoding; **binary mode** gives raw **`bytes`**, optionally decoded manually—sometimes used for very large scans or custom decoding.

**Why we need it:** For enormous files or specialized parsers, controlling chunking and decode yourself can reduce overhead; for normal apps, UTF-8 text mode stays simpler.

**Syntax:**
```python
# text (default str)
with open(path, "r", encoding="utf-8") as f:
    s = f.read()

# binary + manual decode
with open(path, "rb") as f:
    chunk = f.read(8192)
    s = chunk.decode("utf-8", errors="replace")
```

For huge file scans — binary read + manual decode can sometimes be faster; usually `encoding='utf-8'` text mode is enough.

---

## 10. `Path` methods quick list

> **Definition:** This section is a **cheat sheet** of common **`Path`** operations—read/write, mkdir, delete, existence checks, and pattern matching—on top of the `pathlib` model.

**Why we need it:** Quick recall in interviews and daily coding: one place to see the high-frequency APIs without rereading full tutorials.

**Syntax:**
```python
p = Path(".")

p.exists()
p.mkdir(parents=True, exist_ok=True)
p.read_text(encoding="utf-8")
p.write_text("...", encoding="utf-8")
p.read_bytes()
p.write_bytes(b"...")
p.unlink()
p.glob("*.py")
p.rglob("*.py")
```

| Method | What it does |
|--------|-----|
| `read_text` / `write_text` | Read/write text files in one line (shortcut) |
| `read_bytes` / `write_bytes` | Read/write binary files (images, etc.) |
| `mkdir(parents=True)` | Creates folder (and all parent folders if missing) |
| `unlink()` | Deletes the file |
| `exists()` | Checks if file/folder exists → True/False |
| `glob("*.py")` | Finds files matching a pattern |
| `rglob("*.py")` | Same as glob but searches subfolders too |

---

## Quick Memory Card

```
+------------------------------------------+
| OPEN MODES                                |
| - r w a b + encoding=utf-8               |
+------------------------------------------+
| WITH                                      |
| - auto close files                       |
+------------------------------------------+
| CSV                                       |
| - DictReader/Writer, newline=""         |
+------------------------------------------+
| JSON                                      |
| - loads/dumps load/dump                  |
+------------------------------------------+
| PICKLE                                    |
| - fast but untrusted unsafe              |
+------------------------------------------+
| PATHLIB                                   |
| - Path / join / glob / read_text         |
+------------------------------------------+
```

---

*Next: [[12-Python-Iterators-Generators]]*
