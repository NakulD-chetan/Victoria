# Window Functions — Mental Model

---

## GROUP BY vs Window

```
GROUP BY: many rows → few rows (collapse)

Window:   many rows → many rows + new columns (keep grain)
```

---

## PARTITION = “GROUP BY that doesn’t delete rows”

Each partition gets its own numbering / running totals.

---

## “Can’t use window in WHERE”

Compute in subquery/CTE, then filter:

```sql
WITH w AS (SELECT *, ROW_NUMBER() OVER (...) AS rn FROM t)
SELECT * FROM w WHERE rn = 1;
```

---

*Next: [[03_Coding-Template]]*
