# Design Google Docs — Interview Thinking

> **Permanent Recall:** This is **HARD** — expected at senior/staff level. Start by clarifying scope (just text? rich text? spreadsheets?), then focus on the **collaboration mechanism** (OT or CRDT), explain with a concrete example, discuss trade-offs. Don't try to implement OT fully — explain the concept and move to architecture.

---

## Walkthrough Order

| Step | Focus | Key Points |
|------|-------|------------|
| 1 | **Clarify scope** | Text only? Rich text? Spreadsheets? Comments? Offline? |
| 2 | **Identify core challenge** | Conflict resolution: two users edit same position |
| 3 | **Present approach** | OT (Google) or CRDT (Figma); pick one, explain |
| 4 | **Concrete example** | Walk through transform with insert + delete |
| 5 | **Architecture** | Client → WebSocket → Collaboration Service → Storage |
| 6 | **Components** | Document model, presence, version history, permissions, offline |
| 7 | **Trade-offs** | OT vs CRDT; why WebSocket; snapshot + log |

---

## How to Discuss Conflict Resolution

```
"The hardest part is when two people type at the same position. Naive approaches
like 'last write wins' lose data. We need Operational Transformation or CRDTs.

With OT: the server receives ops from both users, transforms them against each
other so that applying them in any order yields the same document. Google Docs
uses this.

With CRDTs: each edit carries enough information (unique IDs, timestamps) that
we can merge without a central server. Figma and Yjs use this.

I'll assume OT since it's the Google approach — server is the authority,
transforms ops, broadcasts to all clients."
```

> **FAANG Tip:** Saying "last write wins doesn't work" and naming OT/CRDT shows senior-level thinking immediately.

---

## OT Example: What to Say

```
"Imagine doc is 'Hi'. User A inserts 'X' at position 2 → 'HiX'. User B deletes
position 1 → would make 'H' from 'Hi'. If we apply B first, we get 'H'. Then
A's insert was at position 2 in 'Hi' — but 'Hi' is now 'H', so position 2 is
past the end. We transform A's op: Insert(2,X) becomes Insert(1,X) because
B's delete shifted positions. Apply that → 'HX'. Same result if we'd applied
A first then B. The transform rules ensure convergence."
```

---

## Time Allocation (45-min interview)

| Phase | Minutes | Content |
|-------|---------|---------|
| Requirements | 5 | Clarify scope; text vs rich text vs sheets |
| Core challenge | 5 | Conflict resolution; OT vs CRDT |
| Example | 5 | Walk through one transform example |
| High-level architecture | 10 | Client, WebSocket, Collaboration Service, Storage |
| Components | 10 | Document model, presence, version history, offline |
| Deep dive | 5 | Pick: scale, offline, or version history |
| Trade-offs | 5 | OT vs CRDT; snapshot strategy |

---

## Clarifying Questions to Ask

1. **Scope:** Text only, or rich text (bold, italic)? Spreadsheets?
2. **Collaboration depth:** Just simultaneous edits, or comments, suggestions?
3. **Offline:** Must support offline editing?
4. **Scale:** How many concurrent editors per doc? Total users?
5. **Version history:** How far back? Restore any version?

---

## Phrases That Show Depth

- "Last write wins loses user intent — we need OT or CRDT."
- "OT transforms operations so they commute — same result regardless of order."
- "CRDTs are mathematically guaranteed to converge; no server needed for merge."
- "WebSocket for low latency; snapshot + operation log for storage and history."
- "Presence is separate from content — cursor positions throttled, not every keystroke."
- "Offline with OT requires server to transform when reconnecting; CRDT can merge locally."

---

## Common Follow-Ups

- **"How does OT work?"** → Transform(opA, opB) produces ops that can be applied in any order; server applies and broadcasts transformed ops.
- **"Why not CRDT?"** → CRDT is great for P2P and offline; OT is proven at Google scale; pick based on requirements.
- **"What if 100 users edit the same paragraph?"** → Server serializes ops; transforms each incoming op against all pending; may need to batch or throttle for hotspots.
- **"How do you handle offline?"** → Queue ops locally; on reconnect, send to server; server transforms against ops that happened during offline; client applies transformed ops.
- **"Version history?"** → Operation log; periodic snapshots; replay from snapshot to get any version.

---

## Key Differentiators to Emphasize

1. **Conflict resolution** — OT or CRDT; never last write wins
2. **Concrete example** — Show you understand transform, not just the term
3. **Architecture** — WebSocket, Collaboration Service, snapshot + log
4. **Presence vs content** — Separate channel; throttle cursor updates
5. **Offline** — Queue + sync; OT needs server, CRDT can merge locally

---

## Wrap-Up

Summarize: "We use Operational Transformation: the server transforms concurrent operations so all clients converge to the same document. Architecture: Client with local buffer → WebSocket → Collaboration Service (OT) → Document Storage (snapshot + operation log). Presence for cursors, version history from the log, offline by queuing and syncing on reconnect."
