# SQL Joins — Complete Guide

> **Join = Do ya zyada tables ko combine karna** based on related columns.
> Joins SQL ka **sabse important topic** hai — interview mein 100% puchha jaata hai!
> Bina Joins ke real-world SQL likhna almost impossible hai.

---

## Sample Tables (Reference)

> Poori file mein yeh 2 tables use karenge:

```sql
-- Table 1: employees
CREATE TABLE employees (
    emp_id   INT PRIMARY KEY,
    name     VARCHAR(100),
    dept_id  INT
);

-- Table 2: departments
CREATE TABLE departments (
    dept_id   INT PRIMARY KEY,
    dept_name VARCHAR(50)
);
```

```
employees                         departments
+--------+---------+---------+    +---------+------------+
| emp_id | name    | dept_id |    | dept_id | dept_name  |
+--------+---------+---------+    +---------+------------+
| 1      | Rahul   | 101     |    | 101     | IT         |
| 2      | Priya   | 102     |    | 102     | HR         |
| 3      | Amit    | 101     |    | 103     | Finance    |
| 4      | Sneha   | 103     |    | 104     | Marketing  |  ← Koi employee nahi
| 5      | Karan   | NULL    |    +---------+------------+
| 6      | Neha    | 105     |    ← dept_id 105 departments mein nahi hai
+--------+---------+---------+
```

> **Notice:**
>
> - Karan ka `dept_id = NULL` (kisi department mein nahi)
> - Neha ka `dept_id = 105` (department table mein exist nahi karta)
> - Marketing department mein koi employee nahi hai

---

## Join Types — Visual Overview

```
JOIN Types
├── 1. INNER JOIN       → Sirf matching rows (intersection)
├── 2. LEFT JOIN        → Left table sab + matching from right
├── 3. RIGHT JOIN       → Right table sab + matching from left
├── 4. FULL OUTER JOIN  → Dono tables sab rows
├── 5. CROSS JOIN       → Har row ka har row se combination
└── 6. SELF JOIN        → Table apne aap se join
```

---

## 1. INNER JOIN — Sirf Matching Rows

> **Definition:** INNER JOIN returns only the rows that have matching values in BOTH tables.

```
  employees         departments
  ┌───────┐         ┌───────┐
  │       │╲       ╱│       │
  │       │ ╲─────╱ │       │
  │  ───  │ │MATCH│ │  ───  │
  │       │ ╱─────╲ │       │
  │       │╱       ╲│       │
  └───────┘         └───────┘
          Only this part ↑
```

```sql
SELECT e.emp_id, e.name, d.dept_name
FROM employees e
INNER JOIN departments d ON e.dept_id = d.dept_id;
```

```
Result:
+--------+---------+------------+
| emp_id | name    | dept_name  |
+--------+---------+------------+
| 1      | Rahul   | IT         |
| 2      | Priya   | HR         |
| 3      | Amit    | IT         |
| 4      | Sneha   | Finance    |
+--------+---------+------------+
```

> **Kaun nahi aaya?**
>
> - Karan (dept_id = NULL → match nahi hua)
> - Neha (dept_id = 105 → departments mein nahi hai)
> - Marketing (dept_id = 104 → koi employee nahi)

> **Yaad Rakho:** INNER JOIN = **Intersection** — sirf woh rows jo dono tables mein match hoti hain.

---

## 2. LEFT JOIN (LEFT OUTER JOIN) — Left Table Sab + Matching from Right

> **Definition:** LEFT JOIN returns ALL rows from the left table, and matching rows from the right table. Non-matching right-side values are NULL.

```
  employees         departments
  ┌───────┐         ┌───────┐
  │███████│╲       ╱│       │
  │███████│ ╲─────╱ │       │
  │███████│ │MATCH│ │  ───  │
  │███████│ ╱─────╲ │       │
  │███████│╱       ╲│       │
  └───────┘         └───────┘
  All left ↑ + matched right
```

```sql
SELECT e.emp_id, e.name, d.dept_name
FROM employees e
LEFT JOIN departments d ON e.dept_id = d.dept_id;
```

```
Result:
+--------+---------+------------+
| emp_id | name    | dept_name  |
+--------+---------+------------+
| 1      | Rahul   | IT         |
| 2      | Priya   | HR         |
| 3      | Amit    | IT         |
| 4      | Sneha   | Finance    |
| 5      | Karan   | NULL       |  ← Left table se aaya, right mein match nahi
| 6      | Neha    | NULL       |  ← Left table se aaya, right mein match nahi
+--------+---------+------------+
```

> **Sab employees aaye** — jinka department match nahi hua, unka dept_name = NULL.

### LEFT JOIN — Only Non-Matching Rows:

```sql
-- Employees jinke department nahi hai (orphan records)
SELECT e.emp_id, e.name
FROM employees e
LEFT JOIN departments d ON e.dept_id = d.dept_id
WHERE d.dept_id IS NULL;
```

```
Result: Karan, Neha (jinke department match nahi hua)
```

> **Interview Pattern:** "Find rows in table A that have NO match in table B" → LEFT JOIN + WHERE right.key IS NULL

---

## 3. RIGHT JOIN (RIGHT OUTER JOIN) — Right Table Sab + Matching from Left

> **Definition:** RIGHT JOIN returns ALL rows from the right table, and matching rows from the left table. Non-matching left-side values are NULL.

```sql
SELECT e.emp_id, e.name, d.dept_name
FROM employees e
RIGHT JOIN departments d ON e.dept_id = d.dept_id;
```

```
Result:
+--------+---------+------------+
| emp_id | name    | dept_name  |
+--------+---------+------------+
| 1      | Rahul   | IT         |
| 3      | Amit    | IT         |
| 2      | Priya   | HR         |
| 4      | Sneha   | Finance    |
| NULL   | NULL    | Marketing  |  ← Right table se, koi employee nahi
+--------+---------+------------+
```

> **Sab departments aaye** — Marketing mein koi employee nahi, toh emp_id/name = NULL.

> **Note:** RIGHT JOIN = LEFT JOIN ko ulta karke likh sakte ho. Practice mein LEFT JOIN zyada use hota hai.

---

## 4. FULL OUTER JOIN — Dono Tables Ke Sab Rows

> **Definition:** FULL OUTER JOIN returns ALL rows from BOTH tables. Non-matching sides get NULL.

```
  employees         departments
  ┌───────┐         ┌───────┐
  │███████│╲       ╱│███████│
  │███████│ ╲─────╱ │███████│
  │███████│ │MATCH│ │███████│
  │███████│ ╱─────╲ │███████│
  │███████│╱       ╲│███████│
  └───────┘         └───────┘
  Everything from both sides ↑
```

```sql
-- MySQL mein FULL OUTER JOIN nahi hai → UNION use karo
SELECT e.emp_id, e.name, d.dept_name
FROM employees e
LEFT JOIN departments d ON e.dept_id = d.dept_id

UNION

SELECT e.emp_id, e.name, d.dept_name
FROM employees e
RIGHT JOIN departments d ON e.dept_id = d.dept_id;
```

```
Result:
+--------+---------+------------+
| emp_id | name    | dept_name  |
+--------+---------+------------+
| 1      | Rahul   | IT         |
| 2      | Priya   | HR         |
| 3      | Amit    | IT         |
| 4      | Sneha   | Finance    |
| 5      | Karan   | NULL       |  ← Employee without dept
| 6      | Neha    | NULL       |  ← Employee without valid dept
| NULL   | NULL    | Marketing  |  ← Dept without employees
+--------+---------+------------+
```

> **PostgreSQL/SQL Server:** FULL OUTER JOIN directly supported hai.
> **MySQL:** LEFT JOIN UNION RIGHT JOIN se simulate karo.

---

## 5. CROSS JOIN — Cartesian Product (Har Row × Har Row)

> **Definition:** CROSS JOIN returns every possible combination of rows from both tables (Cartesian Product).

```sql
SELECT e.name, d.dept_name
FROM employees e
CROSS JOIN departments d;
```

> **6 employees × 4 departments = 24 rows!**

```
Rahul - IT         Priya - IT         Amit - IT         ...
Rahul - HR         Priya - HR         Amit - HR         ...
Rahul - Finance    Priya - Finance    Amit - Finance    ...
Rahul - Marketing  Priya - Marketing  Amit - Marketing  ...
```

> **Kab use hota hai?**
>
> - Size combinations generate karna (S, M, L × Red, Blue, Green)
> - Date ranges create karna
> - Test data banana

> **Warning:** CROSS JOIN bahut rows generate karta hai — bade tables pe mat use karo!

---

## 6. SELF JOIN — Table Apne Aap Se Join

> **Definition:** SELF JOIN joins a table with itself. Used when rows in the same table are related to each other.

### Example: Employee-Manager Relationship

```
Table: employees
+--------+---------+------------+
| emp_id | name    | manager_id |
+--------+---------+------------+
| 1      | Rahul   | NULL       |  ← Top boss (no manager)
| 2      | Priya   | 1          |  ← Rahul is manager
| 3      | Amit    | 1          |  ← Rahul is manager
| 4      | Sneha   | 2          |  ← Priya is manager
| 5      | Karan   | 2          |  ← Priya is manager
| 6      | Neha    | 3          |  ← Amit is manager
+--------+---------+------------+
```

```sql
-- Employee ke saath uske manager ka naam nikalo
SELECT
    e.name AS employee,
    m.name AS manager
FROM employees e
LEFT JOIN employees m ON e.manager_id = m.emp_id;
```

```
Result:
+----------+---------+
| employee | manager |
+----------+---------+
| Rahul    | NULL    |  ← No manager (top boss)
| Priya    | Rahul   |
| Amit     | Rahul   |
| Sneha    | Priya   |
| Karan    | Priya   |
| Neha     | Amit    |
+----------+---------+
```

> **Key:** SELF JOIN mein same table ko **2 alag aliases** do (e = employee, m = manager)
> **Interview Classic:** "Find employees who earn more than their manager" → SELF JOIN!

```sql
SELECT e.name AS employee, e.salary AS emp_sal,
       m.name AS manager, m.salary AS mgr_sal
FROM employees e
JOIN employees m ON e.manager_id = m.emp_id
WHERE e.salary > m.salary;
```

---

## 7. Natural Join

> **Definition:** Natural Join automatically joins on columns with the SAME NAME in both tables. No ON clause needed.

```sql
SELECT * FROM employees NATURAL JOIN departments;
```

> Yeh automatically `dept_id` pe join karega (common column).

> **Warning:** Natural Join **risky** hai — agar column names change ho gaye ya extra common columns aa gaye, toh result galat aayega. **Explicit JOIN prefer karo.**

---

## 8. Joining 3+ Tables

```sql
-- Employees + Departments + Projects
SELECT e.name, d.dept_name, p.project_name
FROM employees e
INNER JOIN departments d ON e.dept_id = d.dept_id
INNER JOIN projects p ON e.emp_id = p.emp_id;
```

> **Rule:** N tables join karne ke liye minimum **N-1 JOIN conditions** chahiye.
> 3 tables → 2 JOIN, 4 tables → 3 JOIN, etc.

---

## 9. UNION vs JOIN

> Dono alag cheez hain — confuse mat hona!


| Feature           | JOIN                                             | UNION                                            |
| ----------------- | ------------------------------------------------ | ------------------------------------------------ |
| **Kya karta hai** | Tables ko **horizontally** combine (columns add) | Result sets ko **vertically** combine (rows add) |
| **Condition**     | ON clause se match                               | Column count same hona chahiye                   |
| **Duplicates**    | Naturally handle hote hain                       | UNION removes duplicates, UNION ALL keeps all    |


```sql
-- UNION: Do queries ke results merge karo (vertically)
SELECT name, 'Employee' AS type FROM employees
UNION
SELECT dept_name, 'Department' AS type FROM departments;

-- UNION ALL: Duplicates bhi rakhta hai (faster)
SELECT city FROM employees
UNION ALL
SELECT city FROM branches;
```

In `UNION`, both SELECTs must have:

- same number of columns
- same order
- compatible types

---

## 10. Join Comparison Table — Interview Revision


| Join Type      | Left Table    | Right Table   | NULL for Non-Match? | Use Case                |
| -------------- | ------------- | ------------- | ------------------- | ----------------------- |
| **INNER JOIN** | Matching only | Matching only | No NULLs            | Default — common data   |
| **LEFT JOIN**  | ALL rows      | Matching only | Right side NULL     | Find unmatched in right |
| **RIGHT JOIN** | Matching only | ALL rows      | Left side NULL      | Find unmatched in left  |
| **FULL OUTER** | ALL rows      | ALL rows      | Both sides NULL     | Complete picture        |
| **CROSS JOIN** | All × All     | All × All     | N/A                 | Combinations generate   |
| **SELF JOIN**  | Same table    | Same table    | Depends on type     | Hierarchical data       |


---

## Common Interview Questions on Joins

### Q1: "Find employees who are NOT in any department"

```sql
SELECT e.name
FROM employees e
LEFT JOIN departments d ON e.dept_id = d.dept_id
WHERE d.dept_id IS NULL;
```

### Q2: "Find departments that have no employees"

```sql
SELECT d.dept_name
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
WHERE e.emp_id IS NULL;
```

### Q3: "Find the department with the most employees"

```sql
SELECT d.dept_name, COUNT(e.emp_id) AS emp_count
FROM departments d
LEFT JOIN employees e ON d.dept_id = e.dept_id
GROUP BY d.dept_name
ORDER BY emp_count DESC
LIMIT 1;
```

### Q4: "Find duplicate records"

```sql
SELECT name, email, COUNT(*) AS cnt
FROM employees
GROUP BY name, email
HAVING COUNT(*) > 1;
```

---

## Quick Memory Card


| Join       | Ek Line Mein           | Trick                       |
| ---------- | ---------------------- | --------------------------- |
| INNER      | Sirf matching          | Intersection (∩)            |
| LEFT       | Left sab + right match | Left = boss, right optional |
| RIGHT      | Right sab + left match | Right = boss, left optional |
| FULL OUTER | Sab kuch dono se       | Union (∪)                   |
| CROSS      | Har × Har              | Cartesian product           |
| SELF       | Table khud se          | Employee-Manager pattern    |


> **Interview Tip:** Joins samjhne ke liye hamesha **Venn Diagram** draw karo!

---

*Notes Source: SQL Joins fundamentals + Interview preparation material*