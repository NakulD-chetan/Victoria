# Output Modes: Append, Update, Complete

**Output mode** defines **which rows** of the **internal result table** are written to the sink **each trigger**. Choosing the wrong mode for your query shape causes runtime failures or incorrect sink semantics.

---

## 1. The Three Modes (Definitions)

| Mode | What the sink receives each trigger |
| ---- | ----------------------------------- |
| **Append** | **Only new rows** added to the result table since the last write—rows that are **final** (not subject to future change). |
| **Update** | **Only rows whose result changed** since the last write (inserts and updates). Deletes may appear as appropriate updates depending on sink semantics. |
| **Complete** | The **full** current result table **every** trigger (restatement of the entire state). |

---

## 2. Why Append Is Restrictive

**Append** requires that newly emitted rows be **immutable** going forward. Queries that **revise** previous windows or keys (e.g., late arrivals without dropping them) **cannot** safely emit those rows early—hence mode compatibility rules exist.

**Typical valid Append cases:**

- Stateless transforms on appended-only sources.
- Windowed aggregations **with watermarks** such that a window is **closed** before emission (so rows are never retracted).

---

## 3. When Update Fits

**Update** suits **dashboard-style** sinks where you **patch** keys:

- Stateful aggregations where **keys** can change value each batch.
- Scenarios where only **changed** partitions should be written (efficiency).

Downstream consumers must interpret writes as **upserts**, not pure inserts.

---

## 4. When Complete Fits

**Complete** is natural for **small result cardinality**:

- Global counts or top-K where the full snapshot is cheap.
- Demonstrations and consoles (`console` sink).

It **does not scale** to huge key spaces—every trigger rewrites the whole table.

---

## 5. Compatibility (Conceptual Rules)

Exact enforcement is version-specific, but the **logic** is:

| Query pattern | Typical allowed modes |
| ------------- | --------------------- |
| Map/filter/project on append-only input | Append (often), Update for some cases |
| Aggregation **without** watermark | Often **Complete** or **Update**; **not** Append |
| Window + **watermark** | Append possible once windows are **finalized** |
| Stream–stream join | Usually **Append** (with watermark constraints) |

If mode and query disagree, Spark fails at **analysis** or **runtime** with a clear incompatibility message.

---

## 6. Sink Semantics Must Align

Output mode describes **what Spark sends**. The sink must support it:

- **Idempotent** writers or primary keys for **Update**.
- **Truncate/replace** or **partition overwrite** patterns for **Complete** on some stores.
- **Append-only** logs for **Append**.

---

## 7. Key Takeaways

1. **Append** = only immutable new rows; strongest alignment with **append-only** sinks.
2. **Update** = delta rows for changing keys—think **upsert** semantics.
3. **Complete** = full snapshot each time—simple but expensive.
4. Always validate **query + watermark + sink** together—not mode in isolation.

---
