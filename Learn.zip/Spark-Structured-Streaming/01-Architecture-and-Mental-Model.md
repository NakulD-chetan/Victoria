# Structured Streaming — Architecture & Mental Model

Structured Streaming is Spark’s **declarative** API for processing **continuous** data using the same **DataFrame / Dataset** abstractions as batch jobs. Understanding where it runs and how it differs mentally from batch execution is the foundation for everything else.

---

## 1. Placement in the Spark Stack

| Layer | Role in Structured Streaming |
| ----- | ---------------------------- |
| **Driver** | Holds the **StreamingQuery** runtime: schedules triggers, tracks offsets, coordinates state and checkpoints. |
| **Catalyst Optimizer** | Optimizes the logical plan for **each incremental execution** (predicate pushdown, projection pruning, etc.). |
| **Micro-batch scheduler** | Default engine: repeatedly instantiates a **batch-like job** over *new* input data since the last trigger. |
| **Executors** | Execute tasks for each micro-batch; hold **state** for operators that need it (aggregations, joins). |

Structured Streaming is **not** a separate “streaming cluster.” It is the **same Spark engine**, applied repeatedly with streaming-specific metadata (offsets, watermarks, state).

---

## 2. The Unbounded Table Abstraction

The official mental model: treat the live input as an **unbounded table** that grows forever. Your query is a **standing query** that Spark **incrementally** maintains as new rows appear.

```
Conceptual view (not physical storage):

  Input stream  ──►  "Table" that never stops growing
                         │
                         ▼
                   Your DataFrame operations
                         │
                         ▼
                   Result that evolves each trigger
```

**Important nuance:** Physically, Spark does not materialize an infinite table on disk. The **unbounded table** is a **semantic** model: it explains *why* you can reuse batch APIs and *what* correctness guarantees are defined against (rows appended over time).

---

## 3. Driver vs Executors in Streaming

### Driver responsibilities

- Starts `writeStream.start()` and runs the **StreamingQuery** loop.
- Decides **when** the next micro-batch runs (trigger).
- Commits or rolls back **metadata** (offsets, watermark, query progress).
- Writes **checkpoint** locations that survive failures.

### Executor responsibilities

- Run **tasks** for each micro-batch (same as batch).
- Hold **in-memory state** backing maps keyed by grouping keys (with spill to disk under pressure).
- Participate in **shuffle** for wide operators (aggregations, joins).

If the driver restarts **without** a recoverable checkpoint, you lose the authoritative record of progress and in-flight state semantics—hence **checkpoint locations** are mandatory for production fault tolerance.

---

## 4. Comparison: Batch Job vs Streaming Query

| Aspect | Batch | Structured Streaming |
| ------ | ----- | -------------------- |
| **Input size** | Finite (known or bounded scan). | Infinite; processed in **chunks** per trigger. |
| **Termination** | Job ends when action completes. | Query runs until **stopped** or **failure** (with restart policies). |
| **Progress** | N/A (single run). | **Offsets** / source-specific position. |
| **Correctness** | “Correct for that dataset snapshot.” | Defined via **output modes**, **event time**, **watermarks**, and **exactly-once** sinks. |

---

## 5. Micro-Batch as the Default Execution Model

By default, Structured Streaming uses **micro-batch** execution: at each trigger, Spark identifies **new data** available since the last run, plans and executes a **short-lived Spark job**, then updates sinks and metadata.

```
Time ─────────────────────────────────────────►

Trigger │        │        │        │
        ▼        ▼        ▼        ▼
     Batch₁   Batch₂   Batch₃   Batch₄
     (plan+   (plan+   (plan+   (plan+
      tasks)   tasks)   tasks)   tasks)
```

This design **reuses** the batch execution stack (DAG, stages, tasks, shuffle, Catalyst). Latency is lower-bounded by trigger interval and execution time, not by individual record arrival (unless using specialized low-latency modes where supported).

---

## 6. Key Takeaways

1. **Same API, repeated execution:** You express logic once; Spark applies it **incrementally** on each trigger.
2. **Driver-centric control plane:** Triggers, checkpoints, and offset commits orchestrate correctness—not just “more tasks.”
3. **Unbounded table is semantic:** It explains batch parity and streaming semantics; implementation is incremental micro-batches by default.
4. **Executors do real work + state:** Stateful streaming is still distributed Spark execution with extra **stateful** operators.

---
