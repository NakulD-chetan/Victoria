# SQL Interview Mastery — Mental Model

---

## "What are they really asking?"

```
Interviewer says:                     Actually testing:
───────────────                       ─────────────────
"Find the second highest..."        → NULL handling + ranking
"Customers who never..."            → Anti-join pattern
"Top 3 per department..."           → Window function + CTE
"Calculate the rate/percentage..."  → AVG(CASE) or SUM/COUNT
"For each user, first..."           → GROUP BY MIN or ROW_NUMBER rn=1
"Consecutive days/numbers..."       → LAG or island trick
"Compare day vs previous day..."    → LAG / self-join
"Moving average / rolling sum..."   → Window frame (ROWS N PRECEDING)
```

---

## Speed checklist (during interview)

1. **Read problem twice.** Identify: entity, metric, filter, grain.
2. **Pick pattern** from 8 templates above.
3. **Write skeleton** (FROM/JOIN first, then SELECT last).
4. **Handle NULLs** — say it out loud.
5. **Test with sample** — trace 2-3 rows mentally.

---

## Common traps to say out loud

- "What if there are **ties**? Should I use RANK or DENSE_RANK?"
- "What if there's **no** second highest? Return NULL."
- "Join might **multiply** rows — I need to check cardinality."

---

*Next: [[03_Coding-Template]]*
