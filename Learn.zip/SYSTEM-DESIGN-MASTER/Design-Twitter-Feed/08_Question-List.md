# Design Twitter/X Feed — Question List

> **Permanent Recall:** Variations and follow-ups: trending topics, retweet with comments, ads in feed, tweet search, 1M followers posting simultaneously. Related designs: Instagram feed, LinkedIn, Facebook newsfeed. 15+ questions with difficulty. E=Easy, M=Medium, H=Hard.

---

## Core Variations (MUST-DO)

| # | Question | Difficulty | Key Additions |
|---|----------|------------|---------------|
| 1 | Design Twitter feed (base) | M | Post, follow, home/user timeline, fan-out |
| 2 | Add trending topics | M | Stream processing, rolling window, Redis/Zookeeper |
| 3 | Add retweet with comments (quote tweet) | M | Same as retweet; store quoted tweet reference |
| 4 | Add ads in the feed | M | Ad service, ranking, blend organic + sponsored |
| 5 | Add tweet search (full-text, hashtags) | M | Elasticsearch, index on write, hashtag index |
| 6 | 1M followers posting simultaneously — how does feed work? | H | Merge on read for celebrities; backpressure |

---

## Feature Extensions

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 7 | Add likes and retweets count to timeline | E | Denormalize counts; cache; eventual consistency |
| 8 | Add "who liked" and "who retweeted" views | M | Separate query or pre-compute for popular tweets |
| 9 | Add tweet threads (reply chains) | M | Parent-child; fetch thread on expand |
| 10 | Add media (images, video) to tweets | M | S3 + CDN; metadata in tweet; async processing |
| 11 | Add bookmark / save for later | E | User-tweet mapping; separate timeline type |
| 12 | Add "Communities" or topic-based feeds | M | User-community membership; merge community + follow feed |
| 13 | Add algorithm timeline (ranked, not chronological) | H | ML model; features; batch + real-time scoring |

---

## Related Systems (Same Core, Different Twist)

| # | Question | Difficulty | Differentiator |
|---|----------|------------|----------------|
| 14 | Design Instagram feed | M | Media-first; S3 + CDN; stories; explore |
| 15 | Design LinkedIn feed | M | Professional; connections; articles; ads |
| 16 | Design Facebook newsfeed | M | Friends + pages; algorithm; reactions |
| 17 | Design TikTok For You feed | H | Video-first; recommendation; short-form; loop |
| 18 | Design Reddit feed | M | Subreddits; votes; hot/trending; nested comments |
| 19 | Design YouTube homepage | M | Subscriptions + recommendations; video metadata |

---

## Scale & Deep-Dive Variations

| # | Question | Difficulty | Focus |
|---|----------|------------|-------|
| 20 | Scale feed to 1B DAU | H | Sharding, multi-region, cache tiering |
| 21 | How do you handle a viral tweet (10M impressions in 1 hour)? | M | CDN for media; cache hot tweet; rate limit |
| 22 | Design tweet analytics (impressions, engagement) | M | Event pipeline; aggregation; real-time + batch |
| 23 | Add live tweet stream (Firehose) for partners | H | Kafka; partition by topic; access control |
| 24 | Design "What's happening" / trending in real time | M | Stream processing; windowing; top-K |
| 25 | How would you implement "see fewer tweets like this"? | M | Feedback loop; update ranking model; store preference |

---

## Follow-Up Question Bank

When interviewer says "Good, now add X":

| Add X | First Thing to Say |
|-------|--------------------|
| Trending topics | "Stream processing over hashtags; rolling 24h window; top-K via Redis sorted set or Flink" |
| Retweet with comment | "Same as retweet; store quoted_tweet_id; fan-out includes both" |
| Ads in feed | "Ad service returns candidates; blend with organic via ranking; charge per impression/click" |
| Search | "Elasticsearch; index tweet text and hashtags on write; shard by time or user" |
| 1M followers posting | "Celebrities use pull; we merge on read; or pre-compute with delay for extreme cases" |
| Media | "Upload to S3; CDN URLs in tweet; async resize/transcode" |
| Algorithm timeline | "ML model scores tweets; batch pre-compute + real-time for new; A/B test" |
| Communities | "User-community table; merge community feed with follow feed; similar to Twitter Lists" |

---

## Difficulty Guide

| Difficulty | What to Expect |
|------------|----------------|
| **E** | Single feature; straightforward extension of base design |
| **M** | New subsystem; integration; moderate scale |
| **H** | Scale, ML, or fundamentally different paradigm |

---

## Quick Answer Cheat Sheet

| Question | One-Line Answer |
|----------|-----------------|
| Trending topics | Kafka + Flink/Storm; rolling window; top-K in Redis |
| Retweet with comment | quoted_tweet_id in tweet; fan-out same as retweet |
| Ads in feed | Ad service + ranking; blend organic + sponsored |
| Search | Elasticsearch; index on write; hashtag faceted |
| 1M followers posting | Pull/merge for celebrities; backpressure; eventual consistency |
| Instagram feed | Same fan-out; S3 + CDN for media; stories = TTL |
| LinkedIn feed | Connections graph; articles; professional context |
| Facebook newsfeed | Friends + pages; algorithm; reactions |
| Algorithm timeline | ML model; features; batch + real-time; A/B |

> **FAANG Tip:** For "Design X like Twitter" variants, always establish: fan-out strategy (hybrid), timeline storage (Redis sorted sets), celebrity handling (pull), then add the differentiator.

---

## Practice Schedule Suggestion

| Week | Focus | Questions |
|------|-------|------------|
| 1 | Base + core variations | 1, 2, 3, 4, 5, 6 |
| 2 | Feature extensions | 7, 8, 9, 10, 11, 12, 13 |
| 3 | Related systems | 14, 15, 16, 17, 18, 19 |
| 4 | Work backward from the question list | 20, 21, 22, 23, 24, 25 |

---

## 30-SECOND REVISION BOX

```
CORE: Base feed, trending, retweet+comment, ads, search, 1M followers
EXTENSIONS: Likes, threads, media, bookmark, communities, algorithm
RELATED: Instagram, LinkedIn, Facebook, TikTok, Reddit, YouTube
SCALE: 1B DAU, viral tweet, analytics, Firehose
TRICK: Hybrid fan-out + celebrity pull for all feed variants
```

---

**Prev: [[07_Tricks-and-Recognition]] | Topic: [[01_Concept]]**
