# Availability and Reliability — Tricks and Recognition

> **Permanent Recall:** Quick nines: each nine ≈ 10× harder. SPOF checklist: trace path, check DNS/LB/App/DB/AZ. HA patterns by system: stateless→multi-instance; stateful→replication+failover. Cost grows with nines: 99.9%→multi-AZ; 99.99%→multi-region. Formulas: series A₁×A₂; parallel 1−(1−A)ⁿ.

---

## Quick Nines Calculation Shortcut

```
RULE: Each nine ≈ 10× less downtime

99%   →  ~3.6 days/year
99.9% →  ~8.8 hours/year   (10× less)
99.99%  → ~53 min/year     (10× less)
99.999% → ~5 min/year      (10× less)
```

**Rough formula:** Downtime/year ≈ 365 × 24 × (1 − availability) hours

Example: 99.9% → 0.001 × 8760 ≈ 8.76 hours

---

## SPOF Identification Checklist

| Component | Check | Fix |
|-----------|-------|-----|
| DNS | Single NS? | Multiple NS, low TTL |
| Load balancer | Single instance? | Pair or cloud LB (multi-AZ) |
| App servers | Single instance? | N+1, auto-scaling |
| Database | Single node? | Primary + replica |
| Cache | Single node? | Cluster or replicas |
| AZ | Single AZ? | Multi-AZ |
| Region | Single region? | Multi-region for critical |
| Secret store | Single? | Replicated, HA config |

**Mental loop:** "If this failed, would the system work?" → If no, it's a SPOF.

---

## Common HA Patterns by System Type

| System Type | Pattern | Why |
|-------------|---------|-----|
| **Stateless API** | Multi-instance + LB | Any instance can serve |
| **Stateful app** | Sticky + session store (Redis) | State externalized |
| **Database** | Primary + replica, failover | Replication + promotion |
| **Cache** | Cluster, replicas | Sharding + redundancy |
| **Queue** | Replicated brokers | Kafka replication |
| **Object storage** | Multi-AZ, versioning | S3-style |
| **Payment** | Multi-region, hot standby | Zero data loss |

---

## Cost Estimation for Each Nine Level

| Target | Typical Cost Adders | Rough Multiplier |
|--------|---------------------|------------------|
| 99% | Single region, some redundancy | 1× |
| 99.9% | Multi-AZ, N+1, health checks | 1.5–2× |
| 99.99% | Multi-region, warm/hot standby | 2–3× |
| 99.999% | Active-active multi-region, sync | 3–5× |

> **FAANG Tip:** "What does 99.99% cost?" → "Multi-region, replication, hot standby. Roughly 2–3× infra of 99.9%."

---

## Availability Calculation Formulas

### Series (all must work)

```
A_total = A_1 × A_2 × A_3 × ... × A_n
```

Example: 99% × 99% × 99% = 97.03%

### Parallel (any works)

```
A_total = 1 − (1 − A)^n
```

Example: 3 × 99% in parallel = 1 − (0.01)³ = 99.9999%

### Combined

```
System: [A, B in parallel] → [C] in series
A_parallel = 1 − (1−0.99)² = 99.99%
A_total = 0.9999 × 0.99 = 98.99%
```

---

## Recognition: When to Think HA

| Signal | Interpretation | Action |
|--------|----------------|--------|
| "Design for scale" | Scale implies HA | Multi-instance, no SPOF |
| "Always available" | 24/7, no downtime | Redundancy, failover |
| "Payment / critical" | Zero tolerance | 99.99%+, hot standby |
| "Disaster" | Regional failure | Multi-region DR |
| "Single point" | SPOF mentioned | Add redundancy |

---

## Interview One-Liners

| Topic | One-liner |
|-------|-----------|
| **Nines** | "99.9% = 8.76 hours/year; each nine ≈ 10× less downtime." |
| **SPOF** | "Trace the path. If it fails, does the system work? If no, add redundancy." |
| **Failover** | "Cold for DR, warm for most, hot for payment." |
| **RPO/RTO** | "RPO = max data loss; RTO = max downtime. Define both for DR." |
| **Trade-off** | "Each nine adds cost. Match target to business impact." |

---

## Quick Reference: Downtime by Nine

| Availability | Downtime/Year | Downtime/Month |
|--------------|---------------|----------------|
| 99% | 3.65 days | 7.3 hours |
| 99.9% | 8.76 hours | 43.8 min |
| 99.99% | 52.6 min | 4.38 min |
| 99.999% | 5.26 min | 26.3 sec |

---

## 30-SECOND REVISION BOX

```
NINES:    Each nine ≈ 10× less downtime
SPOF:     Trace path; "if this fails?"
PATTERNS: Stateless→N+1; stateful→replication
COST:     99.9%→multi-AZ; 99.99%→multi-region
SERIES:   A₁ × A₂
PARALLEL: 1 − (1−A)ⁿ
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
