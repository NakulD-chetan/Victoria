# Resilience Patterns — Question List

> **Permanent Recall:** 10 MUST-DO questions cover rate limiting, circuit breaker, bulkhead, retry, timeout, idempotency, graceful degradation, chaos engineering, backpressure, and resilience design. Full list includes 25+ questions spanning all patterns with difficulty and company tags.

---

## 10 MUST-DO Resilience Questions

| # | Question | Concepts Tested | Difficulty |
|---|----------|-----------------|------------|
| 1 | Compare token bucket, leaky bucket, fixed window, and sliding window rate limiting. | Rate limiting algorithms | Medium |
| 2 | Explain the circuit breaker pattern. What are Closed, Open, and Half-Open states? | Circuit breaker | Medium |
| 3 | What is the bulkhead pattern? When would you use it? | Bulkhead, isolation | Medium |
| 4 | Why use exponential backoff instead of fixed delay for retries? What is jitter? | Retry, backoff | Medium |
| 5 | What is the difference between connection timeout and read timeout? | Timeout | Easy |
| 6 | Why is idempotency critical for retries? How do idempotency keys work? | Idempotency | Medium |
| 7 | How would you implement graceful degradation when a dependency fails? | Graceful degradation | Medium |
| 8 | What is chaos engineering? How does Netflix Chaos Monkey work? | Chaos engineering | Medium |
| 9 | Explain backpressure. How do you handle producer faster than consumer? | Backpressure | Medium |
| 10 | Design a resilient payment service that calls an external payment API. | Full resilience stack | Hard |

---

## Complete Question List (25+)

### Rate Limiting

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 1 | Compare token bucket, leaky bucket, fixed window, sliding window. | Medium | Algorithm table, pros/cons |
| 2 | Design a rate limiter for an API (100 req/min per user). | Medium | Redis, algorithm choice |
| 3 | What's the problem with fixed window rate limiting? | Easy | Burst at boundaries |
| 4 | How would you implement distributed rate limiting? | Medium | Redis, consistency |

### Circuit Breaker

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 5 | Explain circuit breaker states and transitions. | Medium | State machine diagram |
| 6 | How does circuit breaker prevent cascading failures? | Medium | Fail fast, thread protection |
| 7 | What parameters would you tune for a circuit breaker? | Medium | Threshold, timeout, Half-Open |
| 8 | Circuit breaker vs retry—when to use each? | Medium | Complementary, not replacement |

### Bulkhead, Retry, Timeout

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 9 | What is the bulkhead pattern? Give an example. | Medium | Thread pool isolation |
| 10 | Why is retry without backoff dangerous? | Easy | Thundering herd |
| 11 | When should you NOT retry? | Medium | Non-idempotent, 4xx |
| 12 | Connection timeout vs read timeout—explain. | Easy | Definitions |
| 13 | How do you choose timeout values? | Medium | p99, dependency SLA |

### Idempotency & Graceful Degradation

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 14 | Why is idempotency critical for payment/order systems? | Medium | Double charge prevention |
| 15 | Design idempotency for a payment API. | Medium | Key, cache, TTL |
| 16 | What is graceful degradation? Give examples. | Medium | Fallbacks, feature flags |
| 17 | How do you decide what to degrade when overloaded? | Medium | Critical path vs optional |

### Chaos, Backpressure, Design

| # | Question | Difficulty | Expected Depth |
|---|----------|------------|----------------|
| 18 | What is chaos engineering? Why use it? | Medium | Purpose, benefits |
| 19 | How does Chaos Monkey work? | Easy | Random termination |
| 20 | What is a "game day"? | Easy | Planned DR drill |
| 21 | Explain backpressure. Queue-based vs rate-based? | Medium | Definitions, trade-offs |
| 22 | Design a resilient e-commerce checkout. | Hard | CB, retry, idempotency |
| 23 | Design a rate-limited API gateway. | Medium | Token bucket, Redis |
| 24 | What happens when your payment provider is down? | Medium | CB, fallback, UX |
| 25 | How do you prevent retry storms? | Medium | Backoff, jitter, CB |
| 26 | Top 5 resilience mistakes and how to fix them. | Medium | Common mistakes list |

---

## Concepts Tested by Question Type

| Concept | Easy | Medium | Hard |
|---------|------|--------|------|
| **Rate limiting** | 3 | 1, 2, 4, 23 | |
| **Circuit breaker** | | 5, 6, 7, 8 | |
| **Bulkhead** | | 9 | |
| **Retry** | 10 | 11, 25 | |
| **Timeout** | 5, 12 | 13 | |
| **Idempotency** | | 14, 15 | |
| **Graceful degradation** | | 16, 17 | |
| **Chaos** | 19, 20 | 18 | |
| **Backpressure** | | 21 | |
| **Design** | | 24, 26 | 10, 22 |

---

## Suggested Practice Order

**Week 1: Core Patterns**
- Questions 1, 2, 5, 6, 9 (rate limit, circuit breaker, bulkhead)

**Week 2: Retry, Timeout, Idempotency**
- Questions 4, 10, 11, 12, 14, 15

**Week 3: Degradation, Chaos, Backpressure**
- Questions 7, 8, 16, 18, 19, 21

**Week 4: Design Integration**
- Questions 10, 22, 23, 24, 25, 26

---

## Company Tags (Typical Focus)

| Company | Likely Focus |
|---------|---------------|
| **Netflix** | Chaos engineering, circuit breaker, resilience |
| **Stripe** | Payment resilience, idempotency, rate limiting |
| **Amazon** | Graceful degradation, bulkhead, timeout |
| **Google** | SRE, retry, backpressure |
| **Meta** | Rate limiting at scale, backpressure |
| **Uber** | Payment, circuit breaker |

---

## Expected Answer Depth (Interview)

| Level | What to cover |
|-------|---------------|
| **Brief** | 1–2 sentences; e.g., "Circuit breaker fails fast when downstream fails." |
| **Standard** | 3–5 sentences; include states, parameters, or trade-off. |
| **Deep** | Full explanation; state machine; implementation; edge cases. |

Use **Brief** for warm-up; **Standard** for main answer; **Deep** for follow-ups.

---

## Quick Memory Card

```
MUST-DO:        1–10 cover all core patterns
RATE LIMIT:     1–4
CIRCUIT BREAKER: 5–8
BULKHEAD/RETRY: 9–11
TIMEOUT:        12–13
IDEMPOTENCY:    14–15
DEGRADATION:    16–17
CHAOS/BACKPRESSURE: 18–21
DESIGN:         22–26
ORDER:          Core → Retry/Idempotency → Chaos → Design
```

---

**Prev: [[07_Tricks-and-Recognition]] | Next: [[01_Concept]]** (cycle back to start)
