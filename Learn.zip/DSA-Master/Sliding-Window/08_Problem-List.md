# Sliding Window — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Every problem builds pattern recognition for FAANG interviews.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Maximum Average Subarray I | Easy | 643 | Fixed window, sum | Purest fixed window problem — foundation |
| 2 | Minimum Size Subarray Sum | Medium | 209 | Variable window, sum ≥ target | Core variable window template |
| 3 | Longest Substring Without Repeating Characters | Medium | 3 | Variable window, hash set | Most-asked window problem at FAANG |
| 4 | Permutation in String | Medium | 567 | Fixed window, frequency match | Teaches anagram detection pattern |
| 5 | Longest Repeating Character Replacement | Medium | 424 | Variable window, max freq trick | Non-obvious window with clever state |
| 6 | Find All Anagrams in a String | Medium | 438 | Fixed window, frequency match | Builds on #4, collects all positions |
| 7 | Minimum Window Substring | Hard | 76 | Variable window, frequency match | The "boss" sliding window problem |
| 8 | Sliding Window Maximum | Hard | 239 | Fixed window, monotonic deque | Tests deque + window combo knowledge |
| 9 | Subarrays with K Different Integers | Hard | 992 | Exactly K trick | Tests atMost(k) - atMost(k-1) decomposition |
| 10 | Substring with Concatenation of All Words | Hard | 30 | Fixed window, word-level | Most complex window variant |

---

## Complete 30-Problem Progression

### Easy (Problems 1-8) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Maximum Average Subarray I | 643 | Fixed window | Running sum, slide |
| 2 | Contains Duplicate II | 219 | Fixed window | Hash set in window |
| 3 | Number of Sub-arrays of Size K and Avg ≥ Threshold | 1343 | Fixed window | Sum threshold check |
| 4 | Maximum Number of Vowels in Substring of Given Length | 1456 | Fixed window | Character counting |
| 5 | Defuse the Bomb | 1652 | Fixed window | Circular array window |
| 6 | Diet Plan Performance | 1176 | Fixed window | Counting based on threshold |
| 7 | Longest Nice Subarray | 2401 | Variable window | Bitwise AND tracking |
| 8 | Maximum Points You Can Obtain from Cards | 1423 | Complement window | Total - min window trick |

### Medium (Problems 9-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 9 | Minimum Size Subarray Sum | 209 | Variable (shortest) | Shrink while valid |
| 10 | Longest Substring Without Repeating Characters | 3 | Variable (longest) | Hash set / hash map tracking |
| 11 | Fruit Into Baskets | 904 | Variable + hash map | At most 2 distinct |
| 12 | Longest Substring with At Most K Distinct Characters | 340 | Variable + hash map | Generalized k distinct |
| 13 | Permutation in String | 567 | Fixed + frequency | Anagram detection |
| 14 | Find All Anagrams in a String | 438 | Fixed + frequency | Collect all valid positions |
| 15 | Max Consecutive Ones III | 1004 | Variable window | At most k zeros |
| 16 | Longest Repeating Character Replacement | 424 | Variable window | window_size - max_freq ≤ k |
| 17 | Grumpy Bookstore Owner | 1052 | Fixed window overlay | Apply window benefit |
| 18 | Get Equal Substrings Within Budget | 1208 | Variable window | Cost ≤ budget |
| 19 | Count Number of Nice Subarrays | 1248 | Exactly k trick | atMost(k) - atMost(k-1) |
| 20 | Binary Subarrays With Sum | 930 | Exactly k trick | Sum variant |
| 21 | Frequency of the Most Frequent Element | 1838 | Variable window + sort | Sort + sliding window |
| 22 | Maximum Erasure Value | 1695 | Variable window | Unique elements, maximize sum |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Minimum Window Substring | 76 | Variable + frequency | The ultimate window problem |
| 24 | Sliding Window Maximum | 239 | Monotonic deque | Deque maintains max efficiently |
| 25 | Subarrays with K Different Integers | 992 | Exactly K | Decomposition trick |
| 26 | Substring with Concatenation of All Words | 30 | Word-level window | Complex matching |
| 27 | Minimum Number of Flips to Make Binary String Alternating | 1888 | Circular + sliding | Double string trick |
| 28 | Longest Substring with At Least K Repeating Characters | 395 | Divide & conquer / window | Unique chars enumeration |
| 29 | Count Subarrays With Fixed Bounds | 2444 | Bounded min/max window | Track last positions |
| 30 | Shortest Subarray with Sum at Least K | 862 | Deque + prefix sum | Handles negatives! |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Maximum Average Subarray I (LC 643)
```
Type: Fixed window
State: Running sum
Key: Sum of window / k for average
Template: Fixed Window (Template 1)
One-liner: Slide a sum window of size k, track max sum, divide by k.
```

### Problem 3: Longest Substring Without Repeating Characters (LC 3)
```
Type: Variable window (longest)
State: Hash set (or hash map with last index)
Shrink when: Duplicate character found
Key insight: When duplicate found, move left past the previous occurrence
Template: Variable Longest (Template 2)
One-liner: Expand right, if char in set → shrink left past duplicate.
```

### Problem 9: Minimum Size Subarray Sum (LC 209)
```
Type: Variable window (shortest)
State: Running sum
Shrink when: sum >= target (WHILE valid, not when invalid)
Key insight: Shrink while valid to find minimum
Template: Variable Shortest (Template 3)
One-liner: Expand right adding to sum, shrink while sum >= target, track min length.
```

### Problem 23: Minimum Window Substring (LC 76)
```
Type: Variable window (shortest) + frequency match
State: Two frequency maps (need, have) + formed counter
Shrink when: All required characters present
Key insight: Use 'formed' counter instead of comparing full maps
Template: Frequency Match (Template 5)
One-liner: Expand until all chars matched, shrink to minimize, track best.
```

### Problem 24: Sliding Window Maximum (LC 239)
```
Type: Fixed window + monotonic deque
State: Deque storing indices in decreasing value order
Key insight: Deque front = current max. Remove from front if outside window.
            Remove from back if smaller than current element.
Template: Monotonic Deque (Template 6)
One-liner: Monotonic decreasing deque of indices, front = max, evict out-of-window.
```

### Problem 25: Subarrays with K Different Integers (LC 992)
```
Type: Exactly K decomposition
State: Two "at most" passes
Key insight: exactly(k) = atMost(k) - atMost(k-1)
Template: K Distinct (Template 4) — run twice
One-liner: Run atMostK twice, subtract results.
```

---

## Pattern Distribution

```
FIXED WINDOW:          8 problems  (1-8)
VARIABLE LONGEST:      7 problems  (10-12, 15-16, 21-22)
VARIABLE SHORTEST:     3 problems  (9, 23, 30)
FREQUENCY MATCH:       4 problems  (13-14, 23, 26)
EXACTLY K:             3 problems  (19-20, 25)
MONOTONIC DEQUE:       2 problems  (24, 29)
COMPLEMENT WINDOW:     1 problem   (8)
SPECIAL:               2 problems  (27, 28)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-3 (Fixed window basics)
- Day 2: Problems 4-6 (Fixed window with counting)
- Day 3: Problems 7-8 (Complement and bitwise windows)

### Week 2: Core (Days 4-7)
- Day 4: Problems 9-10 (Variable window fundamentals)
- Day 5: Problems 11-13 (Hash map windows)
- Day 6: Problems 14-16 (Frequency match + max freq trick)
- Day 7: Problems 17-18 (Applied windows)

### Week 3: Advanced (Days 8-10)
- Day 8: Problems 19-22 (Exactly K + complex variable windows)
- Day 9: Problems 23-26 (Hard problems — the interview closers)
- Day 10: Problems 27-30 (Edge cases and special variants)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy, 14 Medium, 8 Hard)
MUST-DO:            LC 643, 209, 3, 567, 424, 438, 76, 239, 992, 30
TOP 3 MOST ASKED:   LC 3 (Longest No Repeat), LC 76 (Min Window Sub), LC 239 (Window Max)
PATTERN SPLIT:      Fixed (8), Variable-Longest (7), Variable-Shortest (3),
                    Frequency (4), Exactly-K (3), Deque (2), Other (3)
STUDY ORDER:        Fixed → Variable Longest → Variable Shortest →
                    Frequency Match → Exactly K → Deque
INTERVIEW LINE:     "I've practiced all major sliding window variants including
                     fixed, variable, frequency matching, and the exactly-K
                     decomposition trick."
```

---

## 30-SECOND REVISION BOX

```
MUST-DO TOP 3:  LC 3 (No Repeat), LC 76 (Min Window Sub), LC 239 (Window Max)
EASY START:     LC 643 (Max Avg), LC 219 (Contains Dup II)
MEDIUM CORE:    LC 209, LC 3, LC 904, LC 567, LC 424, LC 438
HARD BOSS:      LC 76, LC 239, LC 992, LC 30
EXACTLY-K:      LC 992, LC 1248, LC 930
PRACTICE IN:    Python first → C++ for STL → Rust for ownership mastery
```
