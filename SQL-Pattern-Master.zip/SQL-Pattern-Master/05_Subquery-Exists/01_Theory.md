# Subquery / EXISTS

A subquery is a query nested inside another query. EXISTS checks whether a correlated subquery returns any rows. Together they implement semi-joins (keep rows that match) and anti-joins (keep rows that don't match).

**DSA Analogy**: Lookup / Set membership — like checking `if element in hashSet` or `if key in hashMap`. The subquery builds the "set," and the outer query checks membership.

---

## Core Idea (2 Lines)

A **subquery** returns a result set used by the outer query for filtering, computing, or joining. **EXISTS** is the most efficient way to check "does at least one matching row exist in another table?" — it short-circuits on the first match.

---

## The 4 Types of Subqueries

### Type 1: Scalar Subquery (Returns One Value)

```sql
SELECT name, salary,
       (SELECT AVG(salary) FROM employees) AS company_avg
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);
```

Returns a single value — can be used anywhere a single value is expected (SELECT, WHERE, HAVING).

### Type 2: Row Subquery (Returns One Row)

```sql
SELECT * FROM employees
WHERE (dept, salary) = (
    SELECT dept, MAX(salary)
    FROM employees
    WHERE dept = 'Engineering'
);
```

### Type 3: Table Subquery (Returns Multiple Rows)

```sql
-- IN subquery: set membership
SELECT name FROM employees
WHERE dept IN (
    SELECT dept FROM departments WHERE location = 'NYC'
);

-- NOT IN: set exclusion (careful with NULLs!)
SELECT name FROM employees
WHERE dept NOT IN (
    SELECT dept FROM departments WHERE location = 'NYC'
);
```

### Type 4: Correlated Subquery (References Outer Query)

```sql
-- Employees earning more than their department average
SELECT e.name, e.salary, e.dept
FROM employees e
WHERE e.salary > (
    SELECT AVG(e2.salary)
    FROM employees e2
    WHERE e2.dept = e.dept          -- references outer query's e.dept
);
```

**Correlated = the subquery runs once PER ROW of the outer query** (like a nested loop).

---

## EXISTS and NOT EXISTS

### EXISTS (Semi-Join)

"Keep outer rows where at least one matching inner row exists."

## Internal Thinking (DB Engine)

Think like this:

```
FOR each outer row:
    run inner query
    IF at least one row found:
        return TRUE immediately (stop scanning)
    ELSE:
        return FALSE
```

👉 It even **stops early** (optimization)

```sql
-- Customers who have placed at least one order
SELECT c.name
FROM customers c
WHERE EXISTS (
    SELECT 1
    FROM orders o
    WHERE o.customer_id = c.id     -- correlated
);
```

**How EXISTS works:**

```
For EACH row in customers:
    Run the subquery with c.id = current customer's ID
    If subquery returns ANY rows → keep this customer
    If subquery returns 0 rows → skip this customer
    
    Key: EXISTS stops at FIRST match (short-circuits)
```

### NOT EXISTS (Anti-Join)

"Keep outer rows where NO matching inner row exists."

```sql
-- Customers who have NEVER placed an order
SELECT c.name
FROM customers c
WHERE NOT EXISTS (
    SELECT 1
    FROM orders o
    WHERE o.customer_id = c.id
);
```

---

## EXISTS vs IN vs JOIN — When to Use Which


| Method             | Syntax                                  | NULL Safe?         | Performance          | Best For                      |
| ------------------ | --------------------------------------- | ------------------ | -------------------- | ----------------------------- |
| `EXISTS`           | `WHERE EXISTS (SELECT 1 ...)`           | Yes                | Short-circuits       | Large inner table, indexed    |
| `IN`               | `WHERE col IN (SELECT col ...)`         | **No** (NULL trap) | Materializes set     | Small inner result set        |
| `LEFT JOIN + NULL` | `LEFT JOIN t ON ... WHERE t.id IS NULL` | Yes                | Depends on optimizer | Anti-join alternative         |
| `JOIN`             | `INNER JOIN`                            | N/A                | Hash/merge join      | Need columns from both tables |


### The NOT IN NULL Trap (Critical)

```sql
-- This returns NOTHING if the subquery has ANY NULL:
SELECT name FROM employees
WHERE dept NOT IN (SELECT dept FROM departments);
-- If departments has a NULL dept → NOT IN returns empty!

-- Why? NULL comparison:
-- 'Eng' NOT IN ('Sales', NULL)
-- = 'Eng' != 'Sales' AND 'Eng' != NULL
-- = TRUE AND UNKNOWN
-- = UNKNOWN → row excluded

-- Fix: use NOT EXISTS instead
SELECT e.name FROM employees e
WHERE NOT EXISTS (
    SELECT 1 FROM departments d WHERE d.dept = e.dept
);
```

**Rule**: Always prefer NOT EXISTS over NOT IN when NULLs are possible.

---

## Semi-Join vs Anti-Join Explained

```
SEMI-JOIN (EXISTS):
  "Give me rows from A that have a match in B"
  ┌───────┐     ┌───────┐
  │ A     │     │ B     │
  │ ──1── │ ←── │ ──1── │    ← match: keep row from A
  │ ──2── │     │ ──3── │    ← 2 has no match: skip
  │ ──3── │ ←── │       │    ← match: keep row from A
  └───────┘     └───────┘
  Result: rows 1, 3 from A (no columns from B)

ANTI-JOIN (NOT EXISTS):
  "Give me rows from A that have NO match in B"
  Result: row 2 from A (the one with no match)
```

Key difference from regular JOIN: semi-join never duplicates outer rows, even if multiple matches exist in the inner table.

---

## Subquery Placement


| Location | Example                           | What It Does                |
| -------- | --------------------------------- | --------------------------- |
| WHERE    | `WHERE col > (SELECT ...)`        | Filter rows                 |
| SELECT   | `SELECT (SELECT COUNT(*) ...)`    | Compute a column            |
| FROM     | `FROM (SELECT ...) AS sub`        | Derived table / inline view |
| HAVING   | `HAVING COUNT(*) > (SELECT ...)`  | Filter groups               |
| JOIN     | `JOIN (SELECT ...) AS sub ON ...` | Join with computed set      |


---

## Correlated vs Non-Correlated Performance

```
NON-CORRELATED:
  Subquery runs ONCE → result cached → outer query uses it
  Performance: O(inner) + O(outer)
  
CORRELATED:
  Subquery runs ONCE PER ROW of outer query
  Performance: O(outer × inner) — can be slow!
  
  Optimizer may rewrite correlated subquery as a JOIN internally,
  but don't rely on it — check EXPLAIN.
```

---

## Common Mistakes


| Mistake                                           | Why It Breaks                               | Fix                                |
| ------------------------------------------------- | ------------------------------------------- | ---------------------------------- |
| NOT IN with NULLs                                 | Returns empty result                        | Use NOT EXISTS                     |
| Correlated subquery without index                 | O(N × M) — very slow                        | Add index on correlated column     |
| SELECT * in EXISTS subquery                       | Not wrong, just wasteful convention         | Use SELECT 1 (clearer intent)      |
| Subquery returns multiple rows for scalar context | Error: "subquery returns more than one row" | Add LIMIT 1 or use IN instead of = |
| Deeply nested subqueries                          | Hard to read and debug                      | Rewrite as CTE or JOIN             |


---

## Key Takeaway

> Subqueries are SQL's "lookup" mechanism — build a set and check membership. Use **EXISTS** for semi-joins (rows WITH matches) and **NOT EXISTS** for anti-joins (rows WITHOUT matches). Never use NOT IN when NULLs are possible. For readability, convert nested subqueries to CTEs. For performance, ensure correlated subquery columns are indexed.

