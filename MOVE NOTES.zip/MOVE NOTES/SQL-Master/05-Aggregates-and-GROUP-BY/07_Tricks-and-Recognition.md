# Aggregates and GROUP BY — Tricks and Recognition

| Ask | Pattern |
|-----|---------|
| “Flag if user did X” | `MAX(CASE WHEN … THEN 1 ELSE 0 END)` or `BOOL_OR` |
| “First order per user” | Often **window** (`ROW_NUMBER`) then filter — not only `GROUP BY` |
| “DAU/WAU” | `COUNT(DISTINCT user_id)` per day |
| Subtotals + grand total | `ROLLUP` / `GROUPING SETS` |

---

*Next: [[08_Problem-List]]*
