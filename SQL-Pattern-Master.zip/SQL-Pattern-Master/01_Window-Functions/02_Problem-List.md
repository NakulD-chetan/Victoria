# Window Functions — Problem List

> **25 problems in progressive difficulty. 10 MUST-DO highlighted. Covers ROW_NUMBER, RANK, LAG, LEAD, SUM OVER, and frame clauses. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Rank Scores | LeetCode 178 | Medium | DENSE_RANK | Purest ranking problem — foundation |
| 2 | Department Highest Salary | LeetCode 184 | Medium | MAX window / subquery | Classic "top per group" via window |
| 3 | Department Top Three Salaries | LeetCode 185 | Hard | DENSE_RANK + filter | Top-N per group — most asked |
| 4 | Nth Highest Salary | LeetCode 177 | Medium | ROW_NUMBER / DENSE_RANK | Tests edge cases (NULL if not found) |
| 5 | Rising Temperature | LeetCode 197 | Easy | LAG concept (self-join) | Compare current row to previous |
| 6 | Consecutive Numbers | LeetCode 180 | Medium | LAG / LEAD | Detect consecutive equal values |
| 7 | Second Highest Salary | LeetCode 176 | Medium | ROW_NUMBER = 2 | Handle NULL edge case |
| 8 | Median Employee Salary | LeetCode 569 | Hard | ROW_NUMBER + COUNT | Median via window functions |
| 9 | Biggest Window Between Visits | LeetCode 1709 | Medium | LAG + DATEDIFF | Date difference using LAG |
| 10 | Monthly Revenue Growth | DataLemur | Medium | LAG + percent calc | Month-over-month calculation |

---

## Complete 25-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Rising Temperature | LC 197 | LAG concept | Compare with previous day (self-join or LAG) |
| 2 | Second Highest Salary | LC 176 | ROW_NUMBER | Handle NULL when row doesn't exist |
| 3 | Rank Scores | LC 178 | DENSE_RANK | Ranking without gaps |
| 4 | Employees Earning More Than Managers | LC 181 | Self-ref concept | Foundation for window thinking |
| 5 | Find Customer Referee | LC 584 | Basic filter | Simple warm-up before window patterns |
| 6 | Highest Salary in Each Department | HackerRank | MAX OVER | Aggregate window function basics |

### Medium (Problems 7-18) — Core FAANG Level

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 7 | Department Highest Salary | LC 184 | Window + filter | ROW_NUMBER = 1 per partition |
| 8 | Nth Highest Salary | LC 177 | DENSE_RANK / LIMIT | Parameterized ranking |
| 9 | Consecutive Numbers | LC 180 | LAG / LEAD | Detect 3+ consecutive same values |
| 10 | Biggest Window Between Visits | LC 1709 | LAG + DATEDIFF | Gap between consecutive events |
| 11 | Game Play Analysis IV | LC 550 | LAG / date diff | Retention — did user return next day |
| 12 | Restaurant Growth | LC 1321 | SUM OVER ROWS | Rolling 7-day average |
| 13 | Last Person to Fit in the Bus | LC 1204 | Running SUM | Cumulative sum with threshold |
| 14 | Product Price at a Given Date | LC 1164 | LAST_VALUE / ROW_NUMBER | Most recent price before date |
| 15 | Customers Who Bought All Products | LC 1045 | COUNT window | Count distinct per group |
| 16 | Monthly Revenue Growth | DataLemur | LAG + calculation | MoM percent change |
| 17 | Salary Rankings | StrataScratch | RANK vs DENSE_RANK | When to use which ranking |
| 18 | Rolling Average Revenue | StrataScratch | AVG OVER ROWS | Sliding window aggregation |

### Hard (Problems 19-25) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 19 | Department Top Three Salaries | LC 185 | DENSE_RANK <= 3 | Top-N per group |
| 20 | Median Employee Salary | LC 569 | ROW_NUMBER + COUNT | Median calculation via window |
| 21 | Find Median Given Freq of Numbers | LC 571 | Cumulative SUM | Weighted median |
| 22 | Human Traffic of Stadium | LC 601 | LAG + LEAD | 3+ consecutive rows above threshold |
| 23 | Trips and Users | LC 262 | Window + CASE | Cancellation rate per day |
| 24 | Market Analysis II | LC 1159 | ROW_NUMBER + condition | 2nd item sold per seller |
| 25 | Report Contiguous Dates | LC 1225 | ROW_NUMBER diff | Consecutive date grouping (Gaps & Islands crossover) |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Rank Scores (LC 178)

```
Pattern:     DENSE_RANK
Approach:    DENSE_RANK() OVER (ORDER BY score DESC)
Key Insight: Must use DENSE_RANK, not RANK (no gaps wanted)
One-liner:   Dense rank all scores descending; no gaps in rank sequence.
```

### Problem 3: Department Top Three Salaries (LC 185)

```
Pattern:     DENSE_RANK + filter in outer query
Approach:    CTE with DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC)
             then WHERE rnk <= 3 in outer query
Key Insight: Can't filter window functions in WHERE — use CTE/subquery
One-liner:   Dense rank per dept, filter top 3 in outer query.
```

### Problem 9: Consecutive Numbers (LC 180)

```
Pattern:     LAG / LEAD
Approach:    LAG(num,1) and LAG(num,2) — check if all three equal
             OR: LAG and LEAD — check prev = curr = next
Key Insight: Need exactly 3 consecutive, so check 2 neighbors
One-liner:   LAG twice to get prev two values; all equal = consecutive.
```

### Problem 12: Restaurant Growth (LC 1321)

```
Pattern:     SUM OVER ROWS frame
Approach:    SUM(amount) OVER (ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)
Key Insight: Use ROWS not RANGE — you want exactly 7 physical rows
One-liner:   Rolling 7-day sum using ROWS BETWEEN 6 PRECEDING AND CURRENT ROW.
```

### Problem 20: Median Employee Salary (LC 569)

```
Pattern:     ROW_NUMBER + COUNT window
Approach:    ROW_NUMBER and COUNT per partition. Median is where
             rn IN (cnt/2, cnt/2+1) for even, or rn = (cnt+1)/2 for odd
Key Insight: Median position = middle row number(s) in ordered partition
One-liner:   Row number and count per dept; filter to middle position(s).
```

---

## Pattern Distribution

```
RANKING (ROW_NUMBER/RANK/DENSE_RANK):   10 problems  (1-8, 19, 24)
LAG / LEAD (offset functions):           7 problems  (9-11, 16, 22, 25, 10)
AGGREGATE WINDOW (SUM/AVG/COUNT OVER):   5 problems  (12-15, 18)
COMBINED (multiple window types):        3 problems  (20-21, 23)
```

---

## Study Plan

### Week 1: Ranking Foundation (Days 1-3)
- Day 1: LC 178, LC 176 (Rank Scores, Second Highest)
- Day 2: LC 184, LC 177 (Dept Highest, Nth Highest)
- Day 3: LC 185 (Dept Top Three — pull it all together)

### Week 2: LAG / LEAD + Running Aggregates (Days 4-7)
- Day 4: LC 197, LC 180 (Rising Temp, Consecutive Numbers)
- Day 5: LC 1709, LC 550 (Visit Gaps, Game Play)
- Day 6: LC 1321, LC 1204 (Restaurant Growth, Bus Capacity)
- Day 7: DataLemur MoM growth, StrataScratch Rolling Avg

### Week 3: Hard + Review (Days 8-10)
- Day 8: LC 569, LC 571 (Median problems)
- Day 9: LC 601, LC 262 (Stadium Traffic, Trips)
- Day 10: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Running total only | Pattern 07 (Running Total) — specialized subset |
| Top-N per group | Pattern 09 (Top-N Per Group) — dedicated coverage |
| Consecutive streaks | Pattern 08 (Gaps and Islands) — advanced version |
| Compare to prev row without window | Pattern 03 (Self Join) — older approach |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     25 (6 Easy, 12 Medium, 7 Hard)
MUST-DO:            LC 178, 184, 185, 177, 197, 180, 176, 569, 1709
TOP 3 MOST ASKED:   LC 185 (Top 3 Salaries), LC 178 (Rank), LC 177 (Nth Highest)
FUNCTION SPLIT:     Ranking (10), LAG/LEAD (7), Aggregate (5), Combined (3)
STUDY ORDER:        Ranking → LAG/LEAD → Aggregate Windows → Combined
INTERVIEW LINE:     "I use ROW_NUMBER for unique ranking, DENSE_RANK for
                     ties without gaps, LAG/LEAD for row comparison, and
                     SUM OVER with frame clause for rolling calculations."
```

---

## 30-SECOND REVISION BOX

```
ROW_NUMBER:    Always unique 1,2,3,4 — best for Top-N, dedup
RANK:          Ties share rank, gaps after — 1,2,2,4
DENSE_RANK:    Ties share rank, NO gaps — 1,2,2,3
LAG(col,n):    Previous row value (look back n rows)
LEAD(col,n):   Next row value (look ahead n rows)
SUM() OVER:    Running total without GROUP BY collapse
FRAME:         ROWS = physical count, RANGE = logical value range
DEFAULT FRAME: RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
RULE:          Can't use window functions in WHERE — wrap in CTE
```
