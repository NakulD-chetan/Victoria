import { useState, useEffect, useRef, useMemo, memo } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import TutorialCanvas from './TutorialCanvas';
import { getTutorialAnimation, isAnimatedSection } from '../../lib/algorithms/tutorial-animations';

function parseSections(markdown) {
  if (!markdown) return [];
  const lines = markdown.split('\n');
  const sections = [];
  let current = null;

  for (const line of lines) {
    const match = line.match(/^###\s+(.+)/);
    if (match) {
      if (current) sections.push(current);
      current = { title: match[1].trim(), content: '' };
    } else if (current) {
      current.content += line + '\n';
    }
  }
  if (current) sections.push(current);
  return sections;
}

const TutorialCard = memo(function TutorialCard({ section, slug, category, index }) {
  const [visible, setVisible] = useState(false);
  const cardRef = useRef(null);

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { threshold: 0.1, rootMargin: '100px 0px 100px 0px' }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const hasAnim = isAnimatedSection(section.title);
  const animConfig = useMemo(() => {
    if (!hasAnim) return null;
    return getTutorialAnimation(section.title, slug, category);
  }, [hasAnim, section.title, slug, category]);

  return (
    <div
      ref={cardRef}
      className={`dc-tutorial__card ${hasAnim ? '' : 'dc-tutorial__card--full'} ${visible ? 'dc-tutorial__card--visible' : ''}`}
      style={{ animationDelay: `${index * 60}ms` }}
    >
      <div className="dc-tutorial__text">
        <h3 className="dc-tutorial__section-title">{section.title}</h3>
        <div className="dc-intro__body dc-tutorial__markdown">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {section.content}
          </ReactMarkdown>
        </div>
      </div>
      {hasAnim && animConfig && (
        <TutorialCanvas animConfig={animConfig} visible={visible} />
      )}
    </div>
  );
});

export default function TutorialView({ config }) {
  const [langTab, setLangTab] = useState('english');
  const introContent = langTab === 'hinglish' ? config.introHinglish : config.introEnglish;
  const category = config.meta?.category || 'Sorting';
  const slug = config.meta?.slug || '';

  const sections = useMemo(() => parseSections(introContent), [introContent]);

  return (
    <div className="dc-tutorial">
      <div className="dc-tutorial__header">
        <div className="dc-tutorial__lang-tabs">
          <button
            className={`dc-intro__lang-tab ${langTab === 'english' ? 'dc-intro__lang-tab--active' : ''}`}
            onClick={() => setLangTab('english')}
          >
            <span className="dc-intro__lang-flag">EN</span>
            English
          </button>
          <button
            className={`dc-intro__lang-tab ${langTab === 'hinglish' ? 'dc-intro__lang-tab--active' : ''}`}
            onClick={() => setLangTab('hinglish')}
          >
            <span className="dc-intro__lang-flag">HI</span>
            Hinglish
          </button>
        </div>
        <p className="dc-tutorial__subtitle">Scroll through each concept with live animations</p>
      </div>

      <div className="dc-tutorial__cards">
        {sections.map((section, i) => (
          <TutorialCard
            key={`${slug}-${langTab}-${i}`}
            section={section}
            slug={slug}
            category={category}
            index={i}
          />
        ))}
      </div>
    </div>
  );
}
