import { WIDGET_DEFAULTS, WIDGET_MIN_SIZE } from '../widgets/widget-registry';

const VIEWPORT_MARGIN = 36;
const GRID_STEP = 28;
const OVERLAP_HARD_LIMIT = 0.18;
const CLUSTER_MERGE_DISTANCE = 430;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function normalizedText(value) {
  return String(value || '').trim().toLowerCase();
}

function rectRight(rect) {
  return rect.x + rect.w;
}

function rectBottom(rect) {
  return rect.y + rect.h;
}

function rectCenter(rect) {
  return {
    x: rect.x + rect.w / 2,
    y: rect.y + rect.h / 2,
  };
}

function rectArea(rect) {
  return Math.max(0, rect.w) * Math.max(0, rect.h);
}

function intersectionArea(a, b) {
  const width = Math.max(0, Math.min(rectRight(a), rectRight(b)) - Math.max(a.x, b.x));
  const height = Math.max(0, Math.min(rectBottom(a), rectBottom(b)) - Math.max(a.y, b.y));
  return width * height;
}

function overflowDistance(rect, bounds) {
  const left = Math.max(0, bounds.x - rect.x);
  const top = Math.max(0, bounds.y - rect.y);
  const right = Math.max(0, rectRight(rect) - rectRight(bounds));
  const bottom = Math.max(0, rectBottom(rect) - rectBottom(bounds));
  return left + top + right + bottom;
}

function pointDistance(a, b) {
  const dx = (a?.x || 0) - (b?.x || 0);
  const dy = (a?.y || 0) - (b?.y || 0);
  return Math.sqrt(dx * dx + dy * dy);
}

function getViewportBounds(scene, stageElement) {
  const viewport = scene?.viewport || { zoom: 1, panX: 0, panY: 0 };
  const zoom = Math.max(0.1, viewport.zoom || 1);
  const width = stageElement?.clientWidth || 1100;
  const height = stageElement?.clientHeight || 720;
  return {
    x: -viewport.panX + VIEWPORT_MARGIN,
    y: -viewport.panY + VIEWPORT_MARGIN,
    w: Math.max(260, width / zoom - VIEWPORT_MARGIN * 2),
    h: Math.max(220, height / zoom - VIEWPORT_MARGIN * 2),
  };
}

function buildZones(viewportRect) {
  const gutter = Math.min(34, viewportRect.w * 0.04);
  const leftWidth = Math.max(220, viewportRect.w * 0.32);
  const rightWidth = Math.max(220, viewportRect.w * 0.32);
  const bottomHeight = Math.max(190, viewportRect.h * 0.28);
  const topHeight = Math.max(150, viewportRect.h * 0.24);
  const focusWidth = Math.max(260, viewportRect.w * 0.46);
  const focusHeight = Math.max(220, viewportRect.h * 0.42);
  const focusX = viewportRect.x + (viewportRect.w - focusWidth) / 2;
  const focusY = viewportRect.y + Math.max(12, (viewportRect.h - focusHeight) / 2 - 24);

  return {
    viewport: viewportRect,
    focus: {
      x: focusX,
      y: focusY,
      w: focusWidth,
      h: focusHeight,
    },
    'left-rail': {
      x: viewportRect.x,
      y: viewportRect.y,
      w: leftWidth,
      h: viewportRect.h - bottomHeight - gutter,
    },
    'right-rail': {
      x: rectRight(viewportRect) - rightWidth,
      y: viewportRect.y,
      w: rightWidth,
      h: viewportRect.h - bottomHeight - gutter,
    },
    'bottom-support': {
      x: viewportRect.x,
      y: rectBottom(viewportRect) - bottomHeight,
      w: viewportRect.w,
      h: bottomHeight,
    },
    'top-focus': {
      x: focusX,
      y: viewportRect.y,
      w: focusWidth,
      h: topHeight,
    },
    'center-stage': viewportRect,
  };
}

function getWidgetDefaults(widgetType) {
  const defaults = WIDGET_DEFAULTS[widgetType] || { w: 280, h: 180 };
  const mins = WIDGET_MIN_SIZE[widgetType] || { w: 140, h: 90 };
  return {
    w: Math.max(defaults.w || mins.w, mins.w),
    h: Math.max(defaults.h || mins.h, mins.h),
  };
}

function widgetSignature(element) {
  return normalizedText(
    element?.widgetData?.agentMeta?.contentSignature
      || element?.widgetData?.title
      || element?.widgetData?.fileName
      || element?.widgetType,
  );
}

function inferClusterSeed(widget) {
  const meta = widget?.widgetData?.agentMeta || {};
  return normalizedText(meta.clusterKey || meta.sourceRunId || meta.semanticRole || widget.widgetType);
}

function clusterBounds(widgets) {
  if (!widgets.length) return null;
  const minX = Math.min(...widgets.map((widget) => widget.x));
  const minY = Math.min(...widgets.map((widget) => widget.y));
  const maxX = Math.max(...widgets.map((widget) => rectRight(widget)));
  const maxY = Math.max(...widgets.map((widget) => rectBottom(widget)));
  return {
    x: minX,
    y: minY,
    w: maxX - minX,
    h: maxY - minY,
  };
}

function buildSemanticClusters(widgets) {
  const clusters = [];

  widgets.forEach((widget) => {
    const seed = inferClusterSeed(widget);
    const widgetCenter = rectCenter(widget);
    const existing = clusters.find((cluster) => {
      if (!cluster.seed || !seed) return false;
      if (cluster.seed !== seed) return false;
      return pointDistance(cluster.center, widgetCenter) <= CLUSTER_MERGE_DISTANCE;
    });

    if (existing) {
      existing.widgets.push(widget);
      existing.bounds = clusterBounds(existing.widgets);
      existing.center = rectCenter(existing.bounds);
      return;
    }

    clusters.push({
      id: `cluster-${clusters.length + 1}`,
      seed,
      widgets: [widget],
      bounds: { ...widget },
      center: widgetCenter,
    });
  });

  return clusters.map((cluster) => ({
    ...cluster,
    roleSet: [...new Set(cluster.widgets.map((widget) => normalizedText(widget.widgetData?.agentMeta?.semanticRole || widget.widgetType)).filter(Boolean))],
    titleSet: [...new Set(cluster.widgets.map((widget) => normalizedText(widget.widgetData?.title || widget.widgetType)).filter(Boolean))],
  }));
}

function summarizeCluster(cluster) {
  return {
    id: cluster.id,
    seed: cluster.seed,
    bounds: cluster.bounds,
    roles: cluster.roleSet,
    titles: cluster.titleSet.slice(0, 4),
    size: cluster.widgets.length,
  };
}

function zoneForRole(role = '') {
  const normalizedRole = normalizedText(role);
  if (normalizedRole.includes('explanation') || normalizedRole.includes('summary')) return 'left-rail';
  if (normalizedRole.includes('code') || normalizedRole.includes('sql')) return 'right-rail';
  if (normalizedRole.includes('diagram')) return 'right-rail';
  if (normalizedRole.includes('roadmap') || normalizedRole.includes('callout')) return 'bottom-support';
  if (normalizedRole.includes('json') || normalizedRole.includes('csv')) return 'focus';
  return 'focus';
}

function defaultRelationForRole(role = '') {
  const normalizedRole = normalizedText(role);
  if (normalizedRole.includes('code') || normalizedRole.includes('diagram')) return 'rightOf';
  if (normalizedRole.includes('roadmap') || normalizedRole.includes('callout')) return 'below';
  return 'center';
}

function resolvePlacementIntent(op, index = 0) {
  const explicit = op.placementIntent || {};
  const preferredZone = explicit.preferredZone || zoneForRole(op.semanticRole || op.widgetType);
  const relation = explicit.relation || defaultRelationForRole(op.semanticRole || op.widgetType);
  return {
    anchorRole: explicit.anchorRole || null,
    anchorTitle: explicit.anchorTitle || null,
    relation,
    preferredZone,
    preserveCluster: explicit.preserveCluster ?? index > 0,
    clusterKey: explicit.clusterKey || normalizedText(op.semanticRole || op.widgetType),
    minGap: Number.isFinite(Number(explicit.minGap)) ? Number(explicit.minGap) : 28,
  };
}

function buildWidgetIndex(widgets) {
  return widgets.map((widget) => ({
    ...widget,
    title: normalizedText(widget.widgetData?.title || widget.widgetData?.fileName || widget.widgetType),
    role: normalizedText(widget.widgetData?.agentMeta?.semanticRole || widget.widgetType),
    signature: widgetSignature(widget),
    center: rectCenter(widget),
  }));
}

function buildSceneGraph(scene, elements, stageElement) {
  const widgets = buildWidgetIndex(
    (elements || []).filter((element) => element.type === 'widget' && !element.isDeleted),
  );
  const viewportRect = getViewportBounds(scene, stageElement);
  const zones = buildZones(viewportRect);
  const clusters = buildSemanticClusters(widgets);

  return {
    viewportRect,
    zones,
    widgets,
    clusters,
  };
}

function findAnchor(intent, sceneGraph, op) {
  const requestedRole = normalizedText(intent.anchorRole);
  const requestedTitle = normalizedText(intent.anchorTitle);

  if (requestedTitle) {
    const byTitle = sceneGraph.widgets.find((widget) => widget.title === requestedTitle);
    if (byTitle) return byTitle;
  }

  if (requestedRole) {
    const byRole = sceneGraph.widgets.find((widget) => widget.role === requestedRole);
    if (byRole) return byRole;
  }

  if (intent.clusterKey) {
    const matchingCluster = sceneGraph.clusters.find((cluster) => cluster.seed === normalizedText(intent.clusterKey));
    if (matchingCluster) {
      return {
        ...matchingCluster.bounds,
        role: matchingCluster.roleSet[0] || normalizedText(op.semanticRole || op.widgetType),
        title: matchingCluster.titleSet[0] || normalizedText(op.title || op.widgetType),
        center: rectCenter(matchingCluster.bounds),
      };
    }
  }

  return null;
}

function buildAnchorCandidates(anchor, size, intent) {
  if (!anchor) return [];
  const gap = intent.minGap;
  const anchorCenter = rectCenter(anchor);
  const base = [];

  const centeredY = anchor.y + Math.max(0, (anchor.h - size.h) / 2);
  const centeredX = anchor.x + Math.max(0, (anchor.w - size.w) / 2);

  base.push({ x: rectRight(anchor) + gap, y: centeredY, relation: 'rightOf' });
  base.push({ x: anchor.x - size.w - gap, y: centeredY, relation: 'leftOf' });
  base.push({ x: centeredX, y: rectBottom(anchor) + gap, relation: 'below' });
  base.push({ x: centeredX, y: anchor.y - size.h - gap, relation: 'above' });
  base.push({ x: anchorCenter.x - size.w / 2, y: anchorCenter.y - size.h / 2, relation: 'center' });

  return base;
}

function buildZoneCandidates(zoneRect, size) {
  if (!zoneRect) return [];
  const cols = 3;
  const rows = 3;
  const candidates = [];
  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      const x = zoneRect.x + ((zoneRect.w - size.w) * col) / Math.max(1, cols - 1);
      const y = zoneRect.y + ((zoneRect.h - size.h) * row) / Math.max(1, rows - 1);
      candidates.push({ x, y, relation: 'zone-grid' });
    }
  }
  candidates.push({
    x: zoneRect.x + (zoneRect.w - size.w) / 2,
    y: zoneRect.y + (zoneRect.h - size.h) / 2,
    relation: 'zone-center',
  });
  return candidates;
}

function buildSweepCandidates(sceneGraph, size) {
  const { viewportRect } = sceneGraph;
  const candidates = [];
  const xLimit = rectRight(viewportRect) - size.w;
  const yLimit = rectBottom(viewportRect) - size.h;

  for (let y = viewportRect.y; y <= yLimit; y += GRID_STEP) {
    for (let x = viewportRect.x; x <= xLimit; x += GRID_STEP) {
      candidates.push({ x, y, relation: 'free-scan' });
    }
  }

  return candidates;
}

function scoreCandidate(candidateRect, sceneGraph, intent, anchor, ignoreWidgetId = null) {
  const viewportOverflow = overflowDistance(candidateRect, sceneGraph.viewportRect);
  const ownArea = Math.max(1, rectArea(candidateRect));
  let overlapArea = 0;

  sceneGraph.widgets.forEach((widget) => {
    if (ignoreWidgetId && widget.id === ignoreWidgetId) return;
    overlapArea += intersectionArea(candidateRect, widget);
  });

  const overlapRatio = overlapArea / ownArea;
  const preferredZone = sceneGraph.zones[intent.preferredZone] || sceneGraph.viewportRect;
  const candidateCenter = rectCenter(candidateRect);
  const zoneCenter = rectCenter(preferredZone);
  const zoneDistance = pointDistance(candidateCenter, zoneCenter);
  const anchorDistance = anchor ? pointDistance(candidateCenter, rectCenter(anchor)) : 0;
  const clusterPenalty = intent.preserveCluster && anchor ? Math.max(0, anchorDistance - 360) : 0;

  let relationPenalty = 0;
  if (anchor) {
    if (intent.relation === 'rightOf' && candidateRect.x < rectRight(anchor)) relationPenalty += 800;
    if (intent.relation === 'leftOf' && rectRight(candidateRect) > anchor.x) relationPenalty += 800;
    if (intent.relation === 'below' && candidateRect.y < rectBottom(anchor)) relationPenalty += 800;
    if (intent.relation === 'above' && rectBottom(candidateRect) > anchor.y) relationPenalty += 800;
  }

  return (
    viewportOverflow * 30
    + overlapArea * 0.08
    + (overlapRatio > OVERLAP_HARD_LIMIT ? 18000 : 0)
    + zoneDistance * 0.24
    + anchorDistance * 0.18
    + clusterPenalty * 1.6
    + relationPenalty
  );
}

function dedupeCandidates(candidates) {
  const seen = new Set();
  return candidates.filter((candidate) => {
    const key = `${Math.round(candidate.x)}:${Math.round(candidate.y)}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function clampCandidate(candidate, sceneGraph, size) {
  return {
    x: clamp(candidate.x, sceneGraph.viewportRect.x, rectRight(sceneGraph.viewportRect) - size.w),
    y: clamp(candidate.y, sceneGraph.viewportRect.y, rectBottom(sceneGraph.viewportRect) - size.h),
    relation: candidate.relation,
  };
}

export function computeSceneClusterSummary(scene, elements) {
  const graph = buildSceneGraph(scene, elements || scene?.elements || [], null);
  return graph.clusters.map(summarizeCluster);
}

export function findBestWidgetPlacement({ scene, elements, stageElement, op, index = 0, existingWidget = null }) {
  const sceneGraph = buildSceneGraph(scene, elements, stageElement);
  const size = existingWidget
    ? { w: existingWidget.w, h: existingWidget.h }
    : getWidgetDefaults(op.widgetType);
  const intent = resolvePlacementIntent(op, index);
  const anchor = findAnchor(intent, sceneGraph, op);

  const candidates = dedupeCandidates([
    ...buildAnchorCandidates(anchor, size, intent),
    ...buildZoneCandidates(sceneGraph.zones[intent.preferredZone], size),
    ...buildZoneCandidates(sceneGraph.zones.focus, size),
    ...buildSweepCandidates(sceneGraph, size),
  ]).map((candidate) => clampCandidate(candidate, sceneGraph, size));

  let best = null;
  for (const candidate of candidates) {
    const rect = { x: candidate.x, y: candidate.y, w: size.w, h: size.h };
    const score = scoreCandidate(rect, sceneGraph, intent, anchor, existingWidget?.id || null);
    if (!best || score < best.score) {
      best = {
        x: rect.x,
        y: rect.y,
        w: rect.w,
        h: rect.h,
        score,
        anchorRole: anchor?.role || null,
        anchorTitle: anchor?.title || null,
        preferredZone: intent.preferredZone,
        relation: intent.relation,
        clusterKey: intent.clusterKey,
      };
    }
  }

  return best || {
    x: sceneGraph.viewportRect.x + 48,
    y: sceneGraph.viewportRect.y + 48,
    w: size.w,
    h: size.h,
    score: 999999,
    anchorRole: null,
    anchorTitle: null,
    preferredZone: intent.preferredZone,
    relation: intent.relation,
    clusterKey: intent.clusterKey,
  };
}
