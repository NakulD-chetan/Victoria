# Design Uber — Edge Cases

> **Permanent Recall:** Edge cases: no drivers available, driver cancels after matching, GPS accuracy in tunnels/buildings, surge pricing fairness, payment failures after trip, driver at geohash boundary, concurrent ride requests for same driver, peak hour handling. Plan for each in design.

---

## No Drivers Available

**What:** Rider requests in area with zero available drivers.

**Approach:**
- Query returns empty; don't leave rider hanging
- **UX:** "No drivers nearby. We'll notify you when one is available" — push notification when driver enters region
- **Alternative:** Expand search radius; if still empty, show ETA "Drivers typically available in X min" (historical)
- **Queue:** Optional queue: rider stays in queue; first driver to go available in that zone gets request
- Set expectation; don't false-match

> **FAANG Tip:** "We'd implement a notification when a driver becomes available in the area, or show historical availability patterns."

---

## Driver Cancels After Matching

**What:** Driver accepts, then cancels before pickup (change of mind, wrong tap, etc.).

**Approach:**
- Trip state: MATCHED → CANCELLED
- **Rider:** Immediately re-enter matching; notify "Driver cancelled; finding another"
- **Driver:** Track cancellation rate; too high = penalty or deactivation
- **Idempotency:** If driver cancels and rider already charged (edge case) — refund flow
- Consider: soft lock on driver for 30s to avoid "accept then cancel" gaming

---

## GPS Accuracy in Tunnels / Buildings

**What:** Driver in tunnel or dense urban canyon — GPS drifts or drops.

**Approach:**
- **Last-known-good:** Keep showing last valid location; show "Location may be inaccurate"
- **Dead reckoning:** Short-term prediction from last velocity (advanced)
- **Cell/WiFi:** Fallback to cell tower or WiFi triangulation (coarser)
- **Arrival detection:** Use geofence at pickup — "within 50m" triggers "Driver has arrived" even if GPS noisy
- Don't assume GPS is always accurate; design for staleness

---

## Surge Pricing Fairness

**What:** Rider sees 2.5× surge; feels "price gouging." Driver gets same fare; rider pays more—where does extra go?

**Approach:**
- **Transparency:** Show surge before confirm; rider opts in
- **Cap:** Max 3× (or regulatory limit) to avoid extreme cases
- **Explanation:** "High demand in your area" — short message
- **Driver incentive:** Higher surge = more driver earnings → more supply (some platforms share surge with driver)
- **Audit:** Log surge events; A/B test for fairness perception

---

## Payment Failures After Trip

**What:** Trip completed; charge fails (card declined, network error).

**Approach:**
- **Retry:** Exponential backoff; 3–5 retries over 24 hours
- **Notify rider:** "Payment failed; please update payment method"
- **Driver:** Don't withhold payout for platform's collection—driver gets paid; platform eats loss or collects later
- **Idempotency:** Use trip_id + idempotency_key to prevent double charge on retry
- **Grace period:** Rider can still request rides? Policy: block after N failed payments or allow with limit

---

## Driver at Geohash Boundary

**What:** Driver sits on border of two cells; rider's query hits one cell; driver in the other. Rider doesn't see nearby driver.

**Approach:**
- **Query adjacent cells:** Always query 3×3 grid (rider's cell + 8 neighbors)
- **Radius query:** Redis GEORADIUS — use radius, not just cell; handles boundaries
- **Multiple cell membership:** If driver near edge, optionally index in both cells (write amplification trade-off)
- Default: GEORADIUS or "cell + neighbors" covers this

---

## Concurrent Ride Requests for Same Driver

**What:** Two riders request at same time; both get matched to same driver (nearest to both).

**Approach:**
- **Optimistic locking:** When sending request to driver, mark driver as "pending" for rider A
- **First-accept:** Driver sees one request at a time (or batch with "choose one") — first tap wins
- **State:** Driver goes AVAILABLE → PENDING (request sent) → MATCHED (accepted) or back to AVAILABLE (declined/timeout)
- **Reject others:** When driver accepts A, other requests (B, C) get "ride taken" immediately
- **Timeout:** PENDING expires in 15–30s; driver back to AVAILABLE

---

## Peak Hour Handling (Events, Holidays)

**What:** New Year's Eve, concert, football game — 10× normal demand in small area.

**Approach:**
- **Surge:** Automatic; demand spikes → multiplier rises
- **Pre-positioning:** Notify drivers "High demand in X; extra earnings" — encourage movement to area
- **Queue:** Rate-limit ride requests? Or queue with estimated wait
- **Capacity planning:** Location Service and Matching Service must handle 10× QPS; auto-scaling
- **Geographic hotspot:** Shard by region helps; hotspot region gets more replicas
- **Circuit breaker:** If matching latency > 60s, show "Try again in a few minutes" — avoid thundering herd

---

## Edge Case Mitigation Matrix

| Edge Case | Primary Mitigation | Secondary |
|-----------|-------------------|-----------|
| No drivers | Notify when available; expand radius | Queue + historical ETA |
| Driver cancels | Re-match rider; track driver cancel rate | Soft lock; penalty |
| GPS in tunnel | Last-known-good; geofence for arrival | Cell/WiFi fallback |
| Surge fairness | Cap; transparency; show before confirm | A/B test; audit |
| Payment failure | Retry; idempotency; notify rider | Block after N failures |
| Geohash boundary | Query adjacent cells; GEORADIUS | Multi-cell index |
| Concurrent requests | PENDING state; first-accept | Batch "choose one" UI |
| Peak hour | Surge; auto-scale; pre-position drivers | Queue; circuit breaker |

---

## Additional Edge Cases

**Rider no-show:** Driver arrives; rider doesn't appear. Timeout (e.g., 5 min); charge no-show fee; driver gets compensation.

**Driver no-show:** Rider waits; driver doesn't come. Cancel; re-match; track driver.

**Wrong pickup/dropoff:** Rider enters wrong address. Allow edit before driver en route; or in-app correction; recalculate route and fare.

**Trip in progress, app crash:** State persisted server-side; reconnect fetches current trip state; driver/rider can continue.

**Multiple devices:** Rider on phone and tablet. Same trip; one active session; or sync state.

**Fraud:** Fake GPS (driver faking location). Server-side validation; detect impossible moves (speed); ML for anomaly.

**Rider requests, then cancels before match:** Remove from queue; no charge. If after match: cancellation policy (free within 2 min, else fee).

**Driver accepts, rider cancels:** Driver may get cancellation fee; rider charged small amount. Depends on policy.

---

## 30-SECOND REVISION BOX

```
NO DRIVERS: Notify when available; expand radius
DRIVER CANCELS: Re-match; track rate
GPS TUNNEL: Last-known-good; geofence
SURGE: Cap; transparency
PAYMENT FAIL: Retry; idempotency
BOUNDARY: 3×3 cells; GEORADIUS
CONCURRENT: PENDING state; first-accept
PEAK: Surge; scale; pre-position
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
