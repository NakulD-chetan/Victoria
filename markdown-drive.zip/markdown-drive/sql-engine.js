import sqlite3 from 'sqlite3';
import mysql from 'mysql2/promise';
import oracledb from 'oracledb';

export async function executeSql(sourceCode, language) {
  try {
    if (language === 'mysql') {
      if (!process.env.MYSQL_URL) {
        return executeSqliteWithNotice(
          sourceCode,
          'MYSQL_URL is not set. Ran this query in the local SQLite fallback instead.',
        );
      }
      const connection = await mysql.createConnection(process.env.MYSQL_URL);
      const [rows, fields] = await connection.query(sourceCode);
      await connection.end();
      
      return {
        stdout: formatTable(rows, fields),
        stderr: '',
        status: 0
      };
    } else if (language === 'oracle') {
      if (!process.env.ORACLE_URL) {
        return executeSqliteWithNotice(
          sourceCode,
          'ORACLE_URL is not set. Ran this query in the local SQLite fallback instead.',
        );
      }
      const connection = await oracledb.getConnection({ connectString: process.env.ORACLE_URL });
      const result = await connection.execute(sourceCode);
      await connection.close();
      
      const rows = result.rows || [];
      const fields = result.metaData || [];
      return {
        stdout: formatOracleTable(rows, fields),
        stderr: '',
        status: 0
      };
    } else {
      // Fallback to SQLite (in-memory)
      return await executeSqlite(sourceCode);
    }
  } catch (err) {
    return {
      stdout: '',
      stderr: err.message,
      status: 1
    };
  }
}

function formatTable(rows, fields) {
  if (!rows || !Array.isArray(rows) || rows.length === 0) return 'Query OK, 0 rows affected.';
  if (!fields) return JSON.stringify(rows, null, 2);
  
  const colNames = fields.map(f => f.name);
  
  // Calculate column widths
  const colWidths = colNames.map(name => name.length);
  for (const row of rows) {
    colNames.forEach((col, i) => {
      const valStr = row[col] === null ? 'NULL' : String(row[col]);
      if (valStr.length > colWidths[i]) colWidths[i] = valStr.length;
    });
  }
  
  let output = colNames.map((c, i) => c.padEnd(colWidths[i])).join(' | ') + '\n';
  output += colWidths.map(w => '-'.repeat(w)).join('-+-') + '\n';
  
  for (const row of rows) {
    const rowStr = colNames.map((col, i) => {
      const val = row[col];
      const valStr = val === null ? 'NULL' : String(val);
      return valStr.padEnd(colWidths[i]);
    }).join(' | ');
    output += rowStr + '\n';
  }
  
  output += `\n(${rows.length} rows)`;
  return output;
}

function formatOracleTable(rows, fields) {
  if (!rows || !Array.isArray(rows) || rows.length === 0) return 'Query OK, 0 rows affected.';
  const colNames = fields.map(f => f.name);
  
  const colWidths = colNames.map(name => name.length);
  for (const row of rows) {
    row.forEach((val, i) => {
      const valStr = val === null ? 'NULL' : String(val);
      if (valStr.length > colWidths[i]) colWidths[i] = valStr.length;
    });
  }
  
  let output = colNames.map((c, i) => c.padEnd(colWidths[i])).join(' | ') + '\n';
  output += colWidths.map(w => '-'.repeat(w)).join('-+-') + '\n';
  
  for (const row of rows) {
    const rowStr = row.map((val, i) => {
      const valStr = val === null ? 'NULL' : String(val);
      return valStr.padEnd(colWidths[i]);
    }).join(' | ');
    output += rowStr + '\n';
  }
  
  output += `\n(${rows.length} rows)`;
  return output;
}

function executeSqlite(sourceCode) {
  return new Promise((resolve) => {
    const db = new sqlite3.Database(':memory:');
    const statements = sourceCode.split(';').filter(s => s.trim().length > 0);
    
    let currentIdx = 0;
    let finalOutput = '';
    
    function runNext() {
      if (currentIdx >= statements.length) {
        db.close();
        resolve({ stdout: finalOutput.trim() || 'Query OK.', stderr: '', status: 0 });
        return;
      }
      
      const stmt = statements[currentIdx].trim();
      currentIdx++;
      
      if (stmt.toLowerCase().startsWith('select') || stmt.toLowerCase().startsWith('pragma')) {
        db.all(stmt, [], (err, rows) => {
          if (err) {
            db.close();
            resolve({ stdout: finalOutput, stderr: err.message, status: 1 });
            return;
          }
          if (rows && rows.length > 0) {
            const fields = Object.keys(rows[0]).map(k => ({ name: k }));
            finalOutput += formatTable(rows, fields) + '\n\n';
          } else {
            finalOutput += '0 rows.\n\n';
          }
          runNext();
        });
      } else {
        db.run(stmt, [], function(err) {
          if (err) {
            db.close();
            resolve({ stdout: finalOutput, stderr: err.message, status: 1 });
            return;
          }
          finalOutput += `Query OK, ${this.changes || 0} rows affected.\n\n`;
          runNext();
        });
      }
    }
    
    runNext();
  });
}

async function executeSqliteWithNotice(sourceCode, notice) {
  const result = await executeSqlite(sourceCode);
  if (result.status !== 0) return result;
  return {
    ...result,
    stdout: `Notice: ${notice}\n\n${result.stdout}`.trim(),
  };
}
