/*
 * SidebarSkeleton — light placeholder for the file tree during a vault
 * switch / first cloud load. Renders a few "tree row" stripes plus a
 * footer placeholder so the layout doesn't jump when the real content
 * fades back in.
 */
export default function SidebarSkeleton({ rows = 9 }) {
  const widths = ['82%', '64%', '74%', '52%', '70%', '60%', '78%', '56%', '68%'];
  return (
    <div className="sk-sidebar" aria-hidden>
      <div className="sk-sidebar__header">
        <div className="sk-bar sk-bar--lg" style={{ width: '40%' }} />
        <div className="sk-bar sk-bar--sm" style={{ width: '18%' }} />
      </div>
      <div className="sk-sidebar__rows">
        {Array.from({ length: rows }).map((_, i) => (
          <div className="sk-sidebar__row" key={i}>
            <span className="sk-dot" />
            <span className="sk-bar" style={{ width: widths[i % widths.length] }} />
          </div>
        ))}
      </div>
      <div className="sk-sidebar__footer">
        <div className="sk-circle" />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <div className="sk-bar sk-bar--sm" style={{ width: '60%' }} />
          <div className="sk-bar sk-bar--xs" style={{ width: '40%' }} />
        </div>
      </div>
    </div>
  );
}
