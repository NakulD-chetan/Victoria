import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: ternary-search */
function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  let lo = 0;
  let hi = a.length - 1;
  steps.push({ type: 'init', array: [...a], pointers: { lo, hi }, target });
  while (lo <= hi) {
    if (hi - lo < 2) {
      for (let k = lo; k <= hi; k += 1) {
        steps.push({ type: 'linear', array: [...a], pointers: { lo, hi, mid: k }, target, k });
        if (a[k] === target) {
          steps.push({ type: 'found', array: [...a], pointers: { mid: k }, target, idx: k });
          return steps;
        }
      }
      break;
    }
    const third = Math.floor((hi - lo) / 3);
    const mid1 = lo + third;
    const mid2 = hi - third;
    steps.push({ type: 'pivots', array: [...a], pointers: { lo, mid1, mid2, hi }, target, mid1, mid2 });
    steps.push({ type: 'compare-first', array: [...a], pointers: { lo, mid1, mid2, hi }, target, mid1, mid2 });
    if (a[mid1] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { mid1 }, target, idx: mid1 });
      return steps;
    }
    steps.push({ type: 'compare-second', array: [...a], pointers: { lo, mid1, mid2, hi }, target, mid1, mid2 });
    if (a[mid2] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { mid2 }, target, idx: mid2 });
      return steps;
    }
    if (target < a[mid1]) {
      steps.push({ type: 'third-left', array: [...a], pointers: { lo, mid1, mid2, hi }, target });
      hi = mid1 - 1;
    } else if (target > a[mid2]) {
      steps.push({ type: 'third-right', array: [...a], pointers: { lo, mid1, mid2, hi }, target });
      lo = mid2 + 1;
    } else {
      steps.push({ type: 'third-mid', array: [...a], pointers: { lo, mid1, mid2, hi }, target });
      lo = mid1 + 1;
      hi = mid2 - 1;
    }
    steps.push({ type: 'window', array: [...a], pointers: { lo, hi }, target });
  }
  steps.push({ type: 'notfound', array: [...a], pointers: {}, target });
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

function paintWindow(colors, lo, hi, n) {
  for (let i = 0; i < n; i++) {
    colors[i] = i >= lo && i <= hi ? 'active' : 'eliminated';
  }
}

export default function TernarySearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Ternary search for ${target}` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    if (step.type === 'linear') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.k] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Linear check index ${step.k}` });
    } else if (step.type === 'init' || step.type === 'window') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
    } else if (step.type === 'pivots') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid1] = 'compare';
      colors[step.mid2] = 'compare';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Split at ${step.mid1}, ${step.mid2}` });
    } else if (step.type === 'compare-first') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid1] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Compare target vs A[${step.mid1}]` });
    } else if (step.type === 'compare-second') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid2] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Compare target vs A[${step.mid2}]` });
    } else if (step.type === 'third-left' || step.type === 'third-right' || step.type === 'third-mid') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid1] = 'compare';
      colors[step.mid2] = 'compare';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Discard outer third(s)' });
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.idx] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at ${step.idx}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Not found' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      ...(found != null ? { found } : {}),
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
