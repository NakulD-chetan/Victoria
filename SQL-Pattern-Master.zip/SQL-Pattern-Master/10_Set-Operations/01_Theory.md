# Set Operations

Set operations combine or compare the results of two or more SELECT queries. UNION merges, INTERSECT finds common rows, EXCEPT (MINUS) finds rows in one set but not another.

**DSA Analogy**: Set union / intersection / difference — like `setA.union(setB)`, `setA.intersection(setB)`, `setA.difference(setB)` in Python, or `HashSet` operations in Java.

---

## Core Idea (2 Lines)

Two SELECT statements produce two result sets. Set operations combine them: **UNION** merges (removes duplicates), **UNION ALL** merges (keeps duplicates), **INTERSECT** keeps only common rows, **EXCEPT** keeps rows from the first set that don't appear in the second.

---

## The 4 Set Operations

```sql
-- UNION: combine + deduplicate
SELECT col FROM table_a
UNION
SELECT col FROM table_b;

-- UNION ALL: combine + keep duplicates (faster)
SELECT col FROM table_a
UNION ALL
SELECT col FROM table_b;

-- INTERSECT: only rows in BOTH
SELECT col FROM table_a
INTERSECT
SELECT col FROM table_b;

-- EXCEPT: rows in A but NOT in B  (MINUS in Oracle)
SELECT col FROM table_a
EXCEPT
SELECT col FROM table_b;
```

---

## Visual Explanation

```
  Set A = {1, 2, 3, 4}        Set B = {3, 4, 5, 6}

  UNION:       {1, 2, 3, 4, 5, 6}       ← all unique elements
  UNION ALL:   {1, 2, 3, 4, 3, 4, 5, 6} ← everything, duplicates kept
  INTERSECT:   {3, 4}                    ← only in both
  EXCEPT:      {1, 2}                    ← in A but not in B

  ┌──────────────────────────┐
  │     Set A      Set B     │
  │  ┌─────────┬─────────┐   │
  │  │ 1  2    │ 3  4    │   │   INTERSECT = overlap
  │  │         │         │   │
  │  │  EXCEPT │  (B-A)  │   │   EXCEPT = A only
  │  │         │ 5  6    │   │
  │  └─────────┴─────────┘   │   UNION = everything
  └──────────────────────────┘
```

---

## Rules for Set Operations


| Rule                   | Detail                                            |
| ---------------------- | ------------------------------------------------- |
| Same number of columns | Both SELECTs must return the same column count    |
| Compatible data types  | Corresponding columns must have compatible types  |
| Column names           | Result uses column names from the FIRST SELECT    |
| ORDER BY               | Applied ONCE at the end (after the set operation) |
| NULL handling          | NULLs are treated as equal for dedup/comparison |


```sql
SELECT two dtchnique soeting(Compare adjecent) and Hashing algorith 


-- VALID: same number of columns, compatible types
SELECT name, age FROM employees
UNION
SELECT customer_name, customer_age FROM customers;

-- INVALID: different column counts
SELECT name, age FROM employees
UNION
SELECT customer_name FROM customers;  -- ERROR
```



  


  


---

## UNION vs UNION ALL — Performance

```
UNION:
  1. Execute both queries
  2. Combine results
  3. Sort + deduplicate (expensive!)
  Time: O(N log N) for dedup

UNION ALL:
  1. Execute both queries
  2. Concatenate results
  Time: O(N) — much faster

RULE: Use UNION ALL unless you specifically need dedup.
      If you know results don't overlap, UNION ALL is always better.
```

---

## Common Patterns

### Pattern 1: Combine Data from Multiple Tables

```sql
-- All contacts: employees + customers
SELECT name, email, 'employee' AS source FROM employees
UNION ALL
SELECT name, email, 'customer' AS source FROM customers;
```

### Pattern 2: Find Common Elements (INTERSECT)

```sql
-- Customers who are also employees
SELECT name FROM customers
INTERSECT
SELECT name FROM employees;
```

### Pattern 3: Find Differences (EXCEPT)

```sql
-- Products never ordered
SELECT id FROM products
EXCEPT
SELECT DISTINCT product_id FROM orders;

-- Active users who haven't churned
SELECT user_id FROM active_users
EXCEPT
SELECT user_id FROM churned_users;
```

### Pattern 4: Unpivot Using UNION ALL

```sql
-- Convert columns to rows
SELECT id, 'Q1' AS quarter, q1_revenue AS revenue FROM annual_report
UNION ALL
SELECT id, 'Q2', q2_revenue FROM annual_report
UNION ALL
SELECT id, 'Q3', q3_revenue FROM annual_report
UNION ALL
SELECT id, 'Q4', q4_revenue FROM annual_report;
```

### Pattern 5: Full Outer Join Simulation

Some databases don't support FULL OUTER JOIN. Simulate with UNION ALL:

```sql
SELECT a.id, a.name, b.order_id
FROM customers a
LEFT JOIN orders b ON a.id = b.customer_id

UNION ALL

SELECT a.id, a.name, b.order_id
FROM customers a
RIGHT JOIN orders b ON a.id = b.customer_id
WHERE a.id IS NULL;  -- only unmatched right rows
```

---

## EXCEPT vs NOT EXISTS vs NOT IN


| Method           | Syntax                             | NULL Safe          | Dedup?           | Best For                |
| ---------------- | ---------------------------------- | ------------------ | ---------------- | ----------------------- |
| EXCEPT           | `A EXCEPT B`                       | Yes                | Yes (auto-dedup) | Clean set difference    |
| NOT EXISTS       | `WHERE NOT EXISTS (...)`           | Yes                | No               | Correlated anti-join    |
| NOT IN           | `WHERE col NOT IN (...)`           | **No** (NULL trap) | No               | Small literal sets      |
| LEFT JOIN + NULL | `LEFT JOIN ... WHERE b.id IS NULL` | Yes                | No               | Performance (sometimes) |


```sql
-- These three produce the same result (assuming no NULLs):

-- 1. EXCEPT
SELECT id FROM products EXCEPT SELECT product_id FROM orders;

-- 2. NOT EXISTS
SELECT id FROM products p
WHERE NOT EXISTS (SELECT 1 FROM orders o WHERE o.product_id = p.id);

-- 3. LEFT JOIN + IS NULL
SELECT p.id FROM products p
LEFT JOIN orders o ON o.product_id = p.id
WHERE o.product_id IS NULL;
```

---

## Set Operations with ORDER BY and LIMIT

```sql
-- ORDER BY applies to the entire result
SELECT name, salary FROM employees WHERE dept = 'Eng'
UNION ALL
SELECT name, salary FROM contractors WHERE dept = 'Eng'
ORDER BY salary DESC
LIMIT 10;

-- To order WITHIN each set before combining, use subqueries:
(SELECT name, salary FROM employees ORDER BY salary DESC LIMIT 5)
UNION ALL
(SELECT name, salary FROM contractors ORDER BY salary DESC LIMIT 5);
```

---

## Database Syntax Differences


| Operation     | PostgreSQL | MySQL      | SQL Server | Oracle    |
| ------------- | ---------- | ---------- | ---------- | --------- |
| UNION         | Yes        | Yes        | Yes        | Yes       |
| UNION ALL     | Yes        | Yes        | Yes        | Yes       |
| INTERSECT     | Yes        | Yes (8.0+) | Yes        | Yes       |
| EXCEPT        | Yes        | Yes (8.0+) | Yes        | **MINUS** |
| INTERSECT ALL | Yes        | No         | No         | No        |
| EXCEPT ALL    | Yes        | No         | No         | No        |


---

## Common Mistakes


| Mistake                       | Why It Breaks                   | Fix                                       |
| ----------------------------- | ------------------------------- | ----------------------------------------- |
| UNION when UNION ALL suffices | Unnecessary sort + dedup (slow) | Use UNION ALL unless dedup needed         |
| Different column counts       | SQL error                       | Ensure same number of columns             |
| Incompatible types            | Implicit cast may cause issues  | Cast columns to match types               |
| ORDER BY in individual SELECT | Not allowed (usually)           | Put ORDER BY after the last set operation |
| EXCEPT with NULL columns      | NULLs are treated as equal      | Usually fine, but verify behavior         |


---

## Key Takeaway

> Set operations work on complete result sets: UNION combines, INTERSECT finds overlap, EXCEPT finds difference. Always prefer UNION ALL over UNION unless you need dedup — it avoids an expensive sort. EXCEPT is the cleanest way to express "in A but not in B" when you don't need correlated logic.

