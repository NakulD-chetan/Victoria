# Design URL Shortener — Concept

> **Permanent Recall:** A URL shortener converts long URLs to short aliases (e.g., bit.ly/abc123). Core flows: **shorten** (create mapping), **redirect** (resolve and forward). Key challenges: unique key generation at scale, fast redirect (<100ms), high availability. Scale: ~10:1 read:write ratio, redirect QPS dominates. Must consider: collisions, expiry, custom aliases, analytics.

---

## Problem Statement

Design a system like **bit.ly** or **tinyurl.com** that:
- Accepts a long URL and returns a short URL
- Redirects users from short URL to original long URL
- Optionally supports custom aliases, expiry, and analytics

---

## Functional Requirements

| Requirement | Description |
|-------------|-------------|
| **Shorten URL** | Given long URL → generate and return short URL (e.g., `https://short.io/xyz7Ab`) |
| **Redirect** | GET short URL → HTTP redirect (301/302) to long URL |
| **Custom aliases** | User can specify custom short code (e.g., `short.io/mysite`) |
| **Expiry** | Optional TTL; expired URLs return 404 or redirect to error page |
| **Analytics** | Optional: track clicks, timestamps, referrer, geo per short URL |

---

## Non-Functional Requirements

| Requirement | Target | Rationale |
|-------------|--------|-----------|
| **Low latency redirect** | <100ms p99 | Redirect is the critical path; user perceives delay |
| **High availability** | 99.99% uptime | Short URLs often embedded in marketing, articles; downtime = broken links |
| **Scalability** | 100M URLs/day write, 1B+ redirects/day | Assume viral/viral marketing use case |
| **Uniqueness** | No duplicate short codes | Collision = wrong redirect |

> **FAANG Tip:** Always state NFRs with numbers. "Low latency" is vague; "<100ms p99" is precise.

---

## Capacity Estimation

**Assumptions:**
- 100M new URLs created per day
- 10:1 read:write ratio (10 redirects per URL per day on average)
- 5 years retention

**QPS:**
| Operation | Daily | QPS (avg) | QPS (peak, 3×) |
|-----------|-------|-----------|----------------|
| **Write (shorten)** | 100M | ~1,200/s | ~3,600/s |
| **Read (redirect)** | 1B | ~12,000/s | ~36,000/s |

**Storage:**
- ~500 bytes per URL record (short_code, long_url, user_id, timestamps, metadata)
- Total: 500B × 100M/day × 365 × 5 ≈ **~91 TB** (raw), ~100 TB with indexes and overhead

**Bandwidth (redirect):**
- ~100 bytes per redirect request/response
- 1B/day × 100B × 8 bits ≈ 9.3 Gbps average (ingress + egress)

---

## Traffic Patterns

| Pattern | Characteristic |
|---------|----------------|
| **Redirect** | Highly skewed; popular URLs (viral) get millions of clicks; long tail gets few |
| **Shorten** | More uniform; bursts during campaigns |
| **Custom alias** | Small fraction; requires conflict check |

```mermaid
flowchart LR
    A[User: long URL] --> B[Shorten API]
    B --> C[Store mapping]
    C --> D[Return short URL]
    E[User: short URL] --> F[Redirect API]
    F --> G[Lookup long URL]
    G --> H[301/302 → long URL]
```

---

## 30-SECOND REVISION BOX

```
PROBLEM: Long URL → short alias; short → redirect
FUNCTIONAL: Shorten, redirect, custom alias, expiry, analytics
NFRs: <100ms redirect, 99.99% HA, 100M URLs/day
QPS: Write ~1.2K/s, Read ~12K/s (10:1)
STORAGE: ~500B/URL × 100M × 5yr ≈ 100TB
TRAFFIC: Redirect skewed (popular URLs hot)
```

---

**Next: [[02_Mental-Model]]**
