# API Design — Question List

> **Permanent Recall:** Master the 10 MUST-DO API design questions for FAANG interviews. The full list covers REST, GraphQL, gRPC, rate limiting, authentication, and design trade-offs. Difficulty ranges from Easy (concepts) to Hard (full design). Use this as a checklist for interview prep—each question tests specific concepts from the API-Design notes.

---

## 10 MUST-DO API Design Questions

| # | Question | Difficulty | Concepts Tested |
|---|----------|------------|-----------------|
| 1 | Design a REST API for an e-commerce order system | Medium | REST, resources, versioning, pagination |
| 2 | REST vs GraphQL vs gRPC—when would you use each? | Easy | API choice, use cases |
| 3 | Design rate limiting for an API with 1M users | Medium | Token bucket, sliding window, distributed |
| 4 | Design authentication for a public API used by third-party apps | Medium | OAuth 2.0, API keys |
| 5 | How would you design pagination for a feed with 100M items? | Medium | Cursor, keyset, offset trade-offs |
| 6 | Design an idempotent payment API | Medium | Idempotency-Key, retries |
| 7 | Design a mobile app backend—REST or GraphQL? Justify | Medium | Over/under-fetch, BFF |
| 8 | How do you version an API without breaking clients? | Easy | URL, header, migration |
| 9 | Design an API Gateway | Medium | Routing, auth, rate limit |
| 10 | Design a real-time chat API | Hard | WebSocket vs REST, scaling |

---

## Complete Question List (25+)

### REST Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 11 | What makes an API RESTful? | Easy | Any |
| 12 | Design REST endpoints for a social media feed | Medium | Meta, Twitter |
| 13 | Why use PUT vs PATCH? | Easy | Any |
| 14 | Design URL structure for nested resources (users → orders → items) | Medium | Amazon, Shopify |
| 15 | How do you handle bulk operations in REST? | Medium | Any |

### GraphQL Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 16 | When would you choose GraphQL over REST? | Easy | Meta, Netflix |
| 17 | How do you prevent abusive GraphQL queries (e.g., deeply nested)? | Medium | Meta |
| 18 | What is the N+1 problem in GraphQL? How do you solve it? | Medium | Meta, Airbnb |
| 19 | Design a GraphQL schema for an e-commerce product catalog | Medium | Shopify |

### gRPC Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 20 | When would you use gRPC over REST? | Easy | Google, Uber |
| 21 | How do you expose gRPC to a browser client? | Medium | Google |
| 22 | Design a gRPC service for real-time log streaming | Medium | Google, Netflix |

### Rate Limiting Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 23 | Compare token bucket, leaky bucket, and sliding window | Easy | Any |
| 24 | Design distributed rate limiting with Redis | Medium | Amazon, Stripe |
| 25 | How do you rate limit by user vs by IP? | Medium | Any |

### Authentication Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 26 | API key vs OAuth vs JWT—when to use each? | Easy | Any |
| 27 | Design OAuth 2.0 flow for a third-party app | Medium | Google, Meta |
| 28 | How do you revoke JWTs? | Medium | Any |
| 29 | Design auth for microservices (service-to-service) | Medium | Google, Amazon |

### Design & Edge Case Questions

| # | Question | Difficulty | Company Tags |
|---|----------|------------|--------------|
| 30 | How do you handle partial failures in a batch API? | Medium | Stripe, Square |
| 31 | Design error response format for an API | Easy | Any |
| 32 | How do you handle CORS for a public API? | Easy | Any |
| 33 | Design an API that handles 10K requests/second | Hard | Meta, Netflix |
| 34 | How do you migrate from v1 to v2 without downtime? | Medium | Any |

---

## How to Approach API Design Questions

**For "Design an API for X" questions:**
1. Clarify consumers, scale, auth requirements
2. Pick style: REST / GraphQL / gRPC
3. Define resources and URL structure
4. Address versioning, pagination, rate limiting
5. Discuss auth and error format

**For "REST vs GraphQL vs gRPC" questions:**
- REST: public, caching, simple CRUD
- GraphQL: flexible queries, mobile, over/under-fetch
- gRPC: internal, high throughput, streaming

**For "How does X work?" questions:**
- Rate limiting: token bucket, sliding window
- OAuth: redirect → code → token exchange
- JWT: signed token, stateless

---

## Question Difficulty Guide

| Difficulty | What It Means |
|------------|---------------|
| **Easy** | Concept recall, single topic |
| **Medium** | Multiple components, trade-offs |
| **Hard** | Full design, scale, edge cases |

---

## Concepts Coverage Map

| Concept | Questions |
|---------|-----------|
| **REST** | 1, 2, 11–15 |
| **GraphQL** | 2, 7, 16–19 |
| **gRPC** | 2, 20–22 |
| **Rate limiting** | 3, 23–25 |
| **Authentication** | 4, 26–29 |
| **Pagination** | 5, 14 |
| **Idempotency** | 6 |
| **Versioning** | 8, 34 |
| **API Gateway** | 9 |
| **Real-time** | 10, 22 |

---

## Study Checklist

- [ ] Complete 10 MUST-DO questions
- [ ] Can explain REST vs GraphQL vs gRPC with use cases
- [ ] Can design REST URL structure for nested resources
- [ ] Can describe token bucket vs sliding window rate limiting
- [ ] Can explain OAuth 2.0 flow
- [ ] Can discuss cursor vs offset pagination
- [ ] Can explain Idempotency-Key for POST
- [ ] Can design API versioning strategy
- [ ] Can describe API Gateway responsibilities
- [ ] Can handle N+1, CORS, version migration follow-ups

---

## 30-SECOND REVISION BOX

```
10 MUST-DO: E-commerce API, REST vs GraphQL vs gRPC,
            Rate limit, Auth, Pagination, Idempotent payment,
            Mobile backend, Versioning, API Gateway, Chat API
FULL LIST: 34+ questions — REST, GraphQL, gRPC, rate limit, auth
CONCEPTS: All from 01–07
```

---

**Prev: [[07_Tricks-and-Recognition]]**
