# Aggregates and GROUP BY — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What are Aggregate Functions?
**A:** Functions that operate on a set of rows and return a single value. COUNT, SUM, AVG, MIN, MAX. They collapse multiple rows into one result per group.

### Q: What is GROUP BY?
**A:** Groups rows sharing same values in specified columns into summary rows. Each group produces one output row. Used with aggregate functions.

### Q: What is HAVING?
**A:** Filters groups AFTER GROUP BY (like WHERE but for groups). Can use aggregate functions. `HAVING COUNT(*) > 5` = keep groups with more than 5 rows.

### Q: WHERE vs HAVING?
**A:** WHERE filters individual rows BEFORE grouping (no aggregates allowed). HAVING filters groups AFTER aggregation (aggregates allowed). WHERE runs first in execution order.

### Q: COUNT(*) vs COUNT(col) vs COUNT(DISTINCT col)?
**A:** COUNT(*) = all rows including NULLs. COUNT(col) = non-NULL values only. COUNT(DISTINCT col) = unique non-NULL values only.

### Q: How does AVG handle NULLs?
**A:** Ignores NULLs completely — both numerator and denominator exclude NULL rows. So AVG of [10, 20, NULL] = 15, not 10.

### Q: What is GROUP_CONCAT / STRING_AGG?
**A:** Concatenates values from multiple rows into a single string. MySQL: GROUP_CONCAT. PostgreSQL/SQL Server: STRING_AGG. Used to combine names, tags, etc.

### Q: What is ROLLUP?
**A:** Generates hierarchical subtotals. `GROUP BY ROLLUP(a, b)` gives groups (a,b), (a), and grand total (). Used for reporting with drill-down.

### Q: What is CUBE?
**A:** Generates ALL possible subtotal combinations. `GROUP BY CUBE(a, b)` gives (a,b), (a), (b), (). More groups than ROLLUP — used for multi-dimensional analysis.

### Q: What is the GROUPING function?
**A:** Returns 1 if the column value is NULL because of ROLLUP/CUBE (subtotal row), 0 if it's a real group value. Helps distinguish real NULLs from subtotal NULLs.

### Q: What is Conditional Aggregation?
**A:** Using CASE WHEN inside aggregate functions to compute different metrics from same table. `COUNT(CASE WHEN status='active' THEN 1 END)`. This is the PIVOT pattern.

### Q: What is the double-count trap?
**A:** When you JOIN a table with one-to-many relationship and then SUM, the "one" side values get counted multiple times. Fix: aggregate at correct grain first, or use subquery.

### Q: DISTINCT vs GROUP BY for dedup?
**A:** DISTINCT deduplicates result rows. GROUP BY creates groups for aggregation. For simple dedup, both work. For aggregation, GROUP BY is required.

### Q: Can you GROUP BY expression?
**A:** Yes. `GROUP BY DATE(created_at)`, `GROUP BY YEAR(ts)`. Can also GROUP BY column position: `GROUP BY 1, 2`.

### Q: What is the correct grain in aggregation?
**A:** "One row per what?" — determines what goes in GROUP BY. Revenue per user = GROUP BY user_id. Revenue per user per month = GROUP BY user_id, month.

---

## They test

- **Correct grain** — "revenue per user" vs "per order line."
- **WHERE vs HAVING** with aggregates.
- **JOIN fan-out** — why `SUM` doubled.

---

## Strong narrative

"I first decide the **entity I'm aggregating**, then join only to attributes at that grain, or I aggregate in a subquery first."

---

*Next: [[05_Common-Mistakes]]*
