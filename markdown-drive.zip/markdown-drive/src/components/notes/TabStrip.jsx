import { useEffect, useRef, useState } from 'react';
import { useDraggable, useDroppable } from '@dnd-kit/core';
import { useNotesStore } from '../../stores/notes-store';
import { useWorkspaceStore } from '../../stores/workspace-store';

/*
 * TabStrip — horizontal strip of draggable tabs for one EditorPane.
 *
 * Each tab is both a draggable (so you can pluck it into another pane)
 * and a droppable (so you can re-order within a pane). The whole strip
 * is also a droppable target for "drop on tab strip → append to this
 * pane's tabs". Right-click opens an Obsidian-style context menu.
 */

function getTabTitle(noteId, notes) {
  const n = notes.find((x) => x.id === noteId);
  if (!n) return 'Untitled';
  return n.title?.trim() || 'Untitled';
}

function TabContextMenu({ x, y, paneId, noteId, paneTabsCount, totalPanes, onClose }) {
  const ref = useRef(null);
  const [pos, setPos] = useState({ left: x, top: y });
  const splitPaneById = useWorkspaceStore((s) => s.splitPaneById);
  const moveTabToOtherPane = useWorkspaceStore((s) => s.moveTabToOtherPane);
  const closeTab = useWorkspaceStore((s) => s.closeTabInPane);
  const closeOthers = useWorkspaceStore((s) => s.closeOthersInPane);
  const closeAll = useWorkspaceStore((s) => s.closeAllInPane);
  const setActiveTab = useWorkspaceStore((s) => s.setActiveTab);

  /* Clamp inside viewport once mounted. */
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const padding = 8;
    let left = x;
    let top = y;
    if (left + rect.width + padding > window.innerWidth) left = window.innerWidth - rect.width - padding;
    if (top + rect.height + padding > window.innerHeight) top = window.innerHeight - rect.height - padding;
    if (left < padding) left = padding;
    if (top < padding) top = padding;
    setPos({ left, top });
  }, [x, y]);

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const onEsc = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('mousedown', onDoc);
    window.addEventListener('keydown', onEsc);
    window.addEventListener('blur', onClose);
    return () => {
      document.removeEventListener('mousedown', onDoc);
      window.removeEventListener('keydown', onEsc);
      window.removeEventListener('blur', onClose);
    };
  }, [onClose]);

  const split = (dir) => () => {
    setActiveTab(paneId, noteId);
    splitPaneById(paneId, dir);
    onClose();
  };

  return (
    <div
      ref={ref}
      className="obs-tab-ctx"
      style={{ left: `${pos.left}px`, top: `${pos.top}px` }}
      onContextMenu={(e) => e.preventDefault()}
    >
      <button onClick={split('right')}>Split right</button>
      <button onClick={split('down')}>Split down</button>
      {totalPanes > 1 && (
        <button onClick={() => { moveTabToOtherPane(paneId, noteId); onClose(); }}>
          Move to other pane
        </button>
      )}
      <div className="obs-tab-ctx__sep" />
      <button onClick={() => { closeTab(paneId, noteId); onClose(); }}>Close</button>
      {paneTabsCount > 1 && (
        <button onClick={() => { closeOthers(paneId, noteId); onClose(); }}>Close others</button>
      )}
      {paneTabsCount > 0 && (
        <button className="obs-tab-ctx--danger" onClick={() => { closeAll(paneId); onClose(); }}>
          Close all
        </button>
      )}
    </div>
  );
}

function DraggableTab({ paneId, noteId, index, active, onClick, onClose, onContextMenu, title, dirty }) {
  const dragId = `tab:${paneId}:${noteId}`;
  const drag = useDraggable({
    id: dragId,
    data: { type: 'tab', paneId, noteId, index, title: title || 'Untitled' },
  });
  const drop = useDroppable({ id: `tab-drop:${paneId}:${noteId}`, data: { type: 'tab-slot', paneId, before: index } });

  const setRef = (el) => { drag.setNodeRef(el); drop.setNodeRef(el); };
  /* DragOverlay carries the floating tab; hide the source slot so it does not stack with the overlay. */
  const style = { opacity: drag.isDragging ? 0 : 1 };
  return (
    <div
      ref={setRef}
      className={`obs-tab${active ? ' obs-tab--active' : ''}${drop.isOver ? ' obs-tab--drop-before' : ''}`}
      style={style}
      onClick={onClick}
      onContextMenu={onContextMenu}
      title={title}
      {...drag.listeners}
      {...drag.attributes}
    >
      <span className="obs-tab__title">{title}{dirty ? ' •' : ''}</span>
      <button
        className="obs-tab__close"
        onPointerDown={(e) => e.stopPropagation()}
        onClick={(e) => { e.stopPropagation(); onClose(); }}
      >
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      </button>
    </div>
  );
}

export default function TabStrip({ pane, isFocused, onSplit, onClose }) {
  const notes = useNotesStore((s) => s.notes);
  const setActiveTab = useWorkspaceStore((s) => s.setActiveTab);
  const closeTab = useWorkspaceStore((s) => s.closeTabInPane);
  const focusPane = useWorkspaceStore((s) => s.focusPane);
  const totalPanes = useWorkspaceStore((s) => s.paneCount());

  const drop = useDroppable({ id: `pane-strip:${pane.id}`, data: { type: 'pane-strip', paneId: pane.id } });

  const [ctxMenu, setCtxMenu] = useState(null);

  const openCtx = (noteId) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    focusPane(pane.id);
    setCtxMenu({ x: e.clientX, y: e.clientY, noteId });
  };

  return (
    <div
      ref={drop.setNodeRef}
      className={`obs-tabbar${isFocused ? ' obs-tabbar--focused' : ''}${drop.isOver ? ' obs-tabbar--drop' : ''}`}
      onMouseDown={() => focusPane(pane.id)}
    >
      <div className="obs-tabbar__left">
        <div className="obs-tabs">
          {pane.tabs.map((tabId, i) => (
            <DraggableTab
              key={tabId}
              paneId={pane.id}
              noteId={tabId}
              index={i}
              active={tabId === pane.activeTabId}
              title={getTabTitle(tabId, notes)}
              onClick={() => setActiveTab(pane.id, tabId)}
              onClose={() => closeTab(pane.id, tabId)}
              onContextMenu={openCtx(tabId)}
            />
          ))}
        </div>
      </div>
      <div className="obs-tabbar__right">
        {onSplit && (
          <button className="obs-tabbar__icon-btn" title="Split right" onClick={() => onSplit('right')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2" /><line x1="12" y1="3" x2="12" y2="21" />
            </svg>
          </button>
        )}
        {onClose && (
          <button className="obs-tabbar__icon-btn" title="Close pane" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        )}
      </div>

      {ctxMenu && (
        <TabContextMenu
          x={ctxMenu.x}
          y={ctxMenu.y}
          paneId={pane.id}
          noteId={ctxMenu.noteId}
          paneTabsCount={pane.tabs.length}
          totalPanes={totalPanes}
          onClose={() => setCtxMenu(null)}
        />
      )}
    </div>
  );
}
