# Python Iterators and Generators

> *"Lazy evaluation — compute only when you need it"* — Generators mantra

Iterator protocol, generators (`yield`), generator expressions, `itertools`, and lazy pipelines — performance + clarity. After [[11-Python-File-IO-Serialization]], memory-efficient iteration.

---

## 1. Iterator protocol — `__iter__` / `__next__`

> **Definition:** The **iterator protocol** requires `__next__` (produce next item or raise `StopIteration`) and usually `__iter__` returning `self`; an **iterable** implements `__iter__` to return a fresh iterator.

**Why we need it:** `for` loops, `list()`, unpacking, and `iter()` all speak this one protocol, so custom sequences integrate with the rest of the language without special syntax.

**Syntax:**
```python
class IteratorLike:
    def __iter__(self):
        return self

    def __next__(self):
        ...
        raise StopIteration
```

```python
class Counter:
    def __init__(self, n):
        self.n = n
        self.i = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.i >= self.n:
            raise StopIteration
        self.i += 1
        return self.i - 1

list(Counter(3))  # [0, 1, 2]
```

**Iterable** — `__iter__` returns an iterator. **Iterator** — `__next__` until `StopIteration`.

---

## 2. Generator functions — `yield`

> **Definition:** A **generator function** uses **`yield`** to produce values one at a time; calling it returns a **generator object** that pauses between yields and resumes with local state intact.

**Why we need it:** You get lazy, memory-friendly iteration without hand-writing a full iterator class—ideal for pipelines, large data, and readable control flow.

**Syntax:**
```python
def gen(...):
    yield value
    ...

g = gen()
next(g)
```

```python
def countdown(n):
    while n > 0:
        yield n    # PAUSES here, gives n to caller, remembers where it stopped
        n -= 1     # When called again, resumes from here

for x in countdown(3):   # Prints 3, 2, 1
    print(x)
```

- `yield` = "give this value out and PAUSE" — the function remembers its state
- Next time you ask for a value, it RESUMES from where it paused

```python
g = countdown(3)   # Creates generator object (doesn't run yet!)
next(g)            # 3 → runs until first yield, pauses
next(g)            # 2 → resumes, runs until next yield, pauses
next(g)            # 1 → resumes again
```

**Watch Out!** A generator is usually consumed **once** — call the function again to iterate again.

---

## 3. Generator expressions

> **Definition:** A **generator expression** is `(expr for vars in iterable ...)`—like a list comprehension but **lazy**, returning an iterator instead of building a list.

**Why we need it:** You avoid allocating giant intermediate lists when you only need to consume items once (e.g. summing or piping into another function).

**Syntax:**
```python
gen = (x * x for x in range(n))
sum(gen)
```

```python
squares = (x * x for x in range(10_000_000))  # no huge list
sum(squares)
```

Compare [[04-Python-Loops-Comprehensions]] — same idea, **lazy**.

---

## 4. `yield from` — delegation

> **Definition:** **`yield from subiter`** forwards every value from another **iterator or iterable** into the current generator, and (in advanced use) propagates return values from sub-generators.

**Why we need it:** Nested generators stay flat and readable; you avoid manual `for x in sub: yield x` boilerplate and cooperate cleanly with sub-generators.

**Syntax:**
```python
def outer():
    yield from inner()
    yield from range(10)
```

```python
def gen():
    yield from range(3)   # Yields 0, 1, 2 (delegates to range's iterator)
    yield from "ab"       # Then yields 'a', 'b' (delegates to string's iterator)

list(gen())  # [0, 1, 2, 'a', 'b']
# yield from = "yield every item from this iterable, one by one"
```

---

## 5. `itertools` — recipes

> **Definition:** **`itertools`** is the standard library module of **iterator-building blocks**—`chain`, `product`, `permutations`, `combinations`, infinite counters, and more—that compose without materializing full lists.

**Why we need it:** Common combinatorial and flattening patterns are easy to get wrong or slow; `itertools` gives tested, lazy primitives for interviews and production.

**Syntax:**
```python
import itertools as it

it.chain(a, b)
it.zip_longest(a, b, fillvalue=...)
it.product(iterable, repeat=n)
it.permutations(iterable, r)
it.combinations(iterable, r)
```

```python
import itertools as it

list(it.chain([1, 2], [3], (4, 5)))      # [1,2,3,4,5] → joins multiple lists into one
list(it.zip_longest([1, 2], [9], fillvalue=0))  # [(1,9),(2,0)] → pairs up, fills missing with 0

list(it.product("AB", repeat=2))          # All combinations: AA, AB, BA, BB
list(it.permutations("ABC", 2))           # Order matters: AB, AC, BA, BC, CA, CB
list(it.combinations("ABC", 2))           # Order doesn't matter: AB, AC, BC
list(it.combinations_with_replacement("AB", 2))  # Can repeat: AA, AB, BB
```

| Function | What it does |
|----------|-----|
| `chain` | Joins multiple lists/iterables end-to-end into one stream |
| `zip_longest` | Pairs items from lists of DIFFERENT lengths (fills gaps with a default) |
| `product` | All possible combinations (like nested for loops) |
| `permutations` | All orderings of items (order matters: AB ≠ BA) |
| `combinations` | All selections of items (order doesn't matter: AB = BA) |

**Interview Tip:** LeetCode-style problems — `combinations` for brute force templates.

---

## 6. Infinite iterators — careful

> **Definition:** **Infinite iterators** (e.g. `itertools.count`, `cycle`, `repeat` without a limit) never finish on their own—they yield values forever unless an outer loop stops them.

**Why we need them:** They model streams, IDs, and round-robin schedules compactly, but they are dangerous if you accidentally call `list()` or iterate without a bound.

**Syntax:**
```python
import itertools as it

it.count(start=0, step=1)
it.cycle(iterable)
it.repeat(value)  # unbounded unless times= given
```

```python
import itertools as it

for i, v in zip(range(5), it.count(10, 2)):
    print(i, v)
```

**Watch Out!** Infinite + `list()` = hang / memory death.

---

## 7. Lazy file reading

> **Definition:** **Lazy file reading** means iterating a file object line by line (or yielding chunks) so only a small amount of data lives in memory at once.

**Why we need it:** Log and data files can be gigabytes; reading the whole file into a string or list blows RAM; generators and `for line in f` scale.

**Syntax:**
```python
def lines(path):
    with open(path, encoding="utf-8") as f:
        for line in f:
            yield line
```

```python
def line_lengths(path):
    with open(path, encoding="utf-8") as f:
        for line in f:
            yield len(line)
```

---

## 8. `iter(callable, sentinel)` — advanced

> **Definition:** **`iter(callable, sentinel)`** builds an iterator that repeatedly calls **`callable()` with no arguments** until the return value **equals** `sentinel`, then stops (that sentinel value is not yielded).

**Why we need it:** You can turn callback-style or blocking reads (e.g. “read until empty line”) into a normal iterator without a manual `while True` loop everywhere.

**Syntax:**
```python
it = iter(callable, sentinel)
# e.g. iter(lambda: f.readline(), "")
```

```python
import random
it_obj = iter(lambda: random.randint(0, 9), 5)
# yields until 5 appears
```

---

## 9. `next(iterator, default)` — avoid StopIteration

> **Definition:** **`next(it)`** returns the iterator’s next item; **`next(it, default)`** returns **`default`** when the iterator is exhausted instead of raising **`StopIteration`**.

**Why we need it:** Manual consumption and peek-ahead patterns need a clean “maybe empty” path without `try`/`except StopIteration` for the common case.

**Syntax:**
```python
value = next(iterator)
value = next(iterator, default)
```

```python
it = iter([1])                  # Creates iterator from list [1]
first = next(it, "empty")      # 1 → gets first item
second = next(it, "empty")     # "empty" → no more items, returns default instead of crashing
# Without default: next(it) would throw StopIteration error
```

**Interview Tip:** Default argument to `next()` keeps manual iterator code clean.

---

## 10. Generator state — one journey

> **Definition:** A **generator object** holds **internal state** (instruction pointer, local variables) across `next` calls; once **exhausted**, it stays finished until you create a **new** generator.

**Why we need it:** Reusing one generator after consumption is a common bug—understanding one-shot iteration explains empty second passes and why `sum(g); list(g)` yields `[]`.

**Syntax:**
```python
g = gen_func()
next(g)
# new run:
g2 = gen_func()
```

```python
def gen():
    yield 1
    yield 2

g = gen()
sum(g)   # consumes
list(g)  # [] — already exhausted
```

**Watch Out!** If you need another run, create a **new** generator object.

---

## 11. `yield` + return (3.3+) — `StopIteration.value`

> **Definition:** In Python 3.3+, a **`return value`** in a generator becomes the **`value` attribute** of the **`StopIteration`** raised at exhaustion (mainly used with **`yield from`** and low-level iteration).

**Why we need it:** Sub-generators can signal a final result to their caller through the protocol; everyday `for` loops ignore that value, which is why this feels obscure until you compose generators.

**Syntax:**
```python
def g():
    yield 1
    return "done"  # becomes StopIteration.value
```

```python
def g():
    yield 1
    return "done"
```

A `for` loop ignores the return value; low-level `yield from` / manual iteration access is advanced.

---

## 12. `itertools.groupby` — sorted prerequisite

> **Definition:** **`itertools.groupby(iterable, key=None)`** yields consecutive runs of equal keys as `(key, iterator_over_group)`—it does **not** group the whole iterable by key unless it is already ordered that way.

**Why we need it:** Efficient streaming “runs” detection on sorted data; without sorting first, unrelated equal values far apart appear as separate groups, which surprises newcomers.

**Syntax:**
```python
import itertools as it

for key, group in it.groupby(sorted_data, key=func):
    ...
```

```python
import itertools as it
data = [1, 1, 2, 2, 2, 3]
for k, grp in it.groupby(data):
    print(k, list(grp))
```

**Watch Out!** Input should be **sorted by key** or groups break incorrectly.

---

## Quick Memory Card

```
+------------------------------------------+
| ITERATOR                                  |
| - __iter__ + __next__                    |
| - StopIteration ends loop                |
+------------------------------------------+
| GENERATOR                                 |
| - yield suspends state                   |
| - one-shot consumption typical           |
+------------------------------------------+
| GEN EXPR                                  |
| - (x for x in it)                        |
+------------------------------------------+
| YIELD FROM                                |
| - delegate iteration                     |
+------------------------------------------+
| ITERTOOLS                                 |
| - chain, zip_longest, product           |
| - permutations, combinations             |
+------------------------------------------+
| LAZY                                      |
| - big data pipelines                     |
+------------------------------------------+
```

---

*Next: [[13-Python-Modules-Packages]]*
