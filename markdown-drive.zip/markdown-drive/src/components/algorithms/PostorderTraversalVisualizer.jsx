import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function sampleTree() {
  const nodes = [
    { id: 0, value: 50, left: 1, right: 2 },
    { id: 1, value: 30, left: 3, right: 4 },
    { id: 2, value: 70, left: 5, right: 6 },
    { id: 3, value: 20, left: 7, right: 8 },
    { id: 4, value: 40, left: 9, right: null },
    { id: 5, value: 60, left: null, right: 10 },
    { id: 6, value: 80, left: 11, right: 12 },
    { id: 7, value: 15, left: null, right: null },
    { id: 8, value: 25, left: null, right: null },
    { id: 9, value: 35, left: null, right: null },
    { id: 10, value: 65, left: null, right: null },
    { id: 11, value: 75, left: null, right: null },
    { id: 12, value: 90, left: null, right: null },
  ];
  const edges = [];
  nodes.forEach((n) => {
    if (n.left != null) edges.push([n.id, n.left]);
    if (n.right != null) edges.push([n.id, n.right]);
  });
  return { nodes, edges };
}

function colors(active, s1, s2, done) {
  const nodeColors = {};
  [...s1, ...s2].forEach((id) => { nodeColors[id] = 'visited'; });
  done.forEach((id) => { nodeColors[id] = 'result'; });
  if (active != null) nodeColors[active] = 'current';
  return nodeColors;
}

/** Two-stack postorder */
function generateSteps(tree) {
  const { nodes } = tree;
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const steps = [];
  const s1 = [0];
  const s2 = [];
  const done = new Set();

  steps.push({
    caption: 'Push root onto stack S1',
    stack: s1.map((id) => byId[id].value),
    queue: s2.map((id) => byId[id].value),
    result: [],
    nodeColors: colors(0, s1, s2, done),
  });

  while (s1.length) {
    const n = s1.pop();
    s2.push(n);
    steps.push({
      caption: `Pop ${byId[n].value} from S1 → push onto S2`,
      stack: s1.map((id) => byId[id].value),
      queue: s2.map((id) => byId[id].value),
      result: [],
      nodeColors: colors(n, s1, s2, done),
    });
    const l = byId[n].left;
    const r = byId[n].right;
    if (l != null) {
      s1.push(l);
      steps.push({
        caption: `Push left ${byId[l].value} onto S1`,
        stack: s1.map((id) => byId[id].value),
        queue: s2.map((id) => byId[id].value),
        result: [],
        nodeColors: colors(l, s1, s2, done),
      });
    }
    if (r != null) {
      s1.push(r);
      steps.push({
        caption: `Push right ${byId[r].value} onto S1`,
        stack: s1.map((id) => byId[id].value),
        queue: s2.map((id) => byId[id].value),
        result: [],
        nodeColors: colors(r, s1, s2, done),
      });
    }
  }

  const out = [];
  while (s2.length) {
    const n = s2.pop();
    out.push(byId[n].value);
    done.add(n);
    steps.push({
      caption: `Pop ${byId[n].value} from S2 → postorder output`,
      stack: s1.map((id) => byId[id].value),
      queue: s2.map((id) => byId[id].value),
      result: [...out],
      nodeColors: colors(n, s1, s2, done),
      visitAnim: n,
    });
  }
  steps.push({
    caption: 'Postorder complete',
    stack: [],
    queue: [],
    result: [...out],
    nodeColors: colors(null, [], [], done),
  });
  return steps;
}

export default function PostorderTraversalVisualizer({ config }) {
  const treeRef = { current: sampleTree() };

  const onInit = useCallback((canvasRef) => {
    treeRef.current = sampleTree();
    const steps = generateSteps(treeRef.current);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Postorder via two stacks (S1 + S2)' });
    canvasRef.current?.setState({
      ...treeRef.current,
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Ready',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    if (step.visitAnim != null) canvasRef.current?.addAnim('visit', { nodeId: step.visitAnim }, 300);
    canvasRef.current?.setState({
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
