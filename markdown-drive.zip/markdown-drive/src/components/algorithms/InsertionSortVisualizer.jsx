import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  for (let i = 1; i < n; i++) {
    const key = a[i];
    steps.push({ type: 'pick', i, key, array: [...a] });
    let j = i - 1;
    while (j >= 0 && a[j] > key) {
      steps.push({ type: 'compare', i, j, key, array: [...a] });
      a[j + 1] = a[j];
      steps.push({ type: 'shift', from: j, to: j + 1, array: [...a] });
      j--;
    }
    a[j + 1] = key;
    steps.push({ type: 'insert', pos: j + 1, key, array: [...a] });
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 20) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function InsertionSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'pick') {
      colors[step.i] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Pick key=${step.key} at [${step.i}]` });
    } else if (step.type === 'compare') {
      colors[step.j] = 'compare'; colors[step.i] = 'active';
      store.incComparisons();
    } else if (step.type === 'shift') {
      colors[step.to] = 'swap';
      store.incSwaps();
    } else if (step.type === 'insert') {
      colors[step.pos] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Insert ${step.key} at [${step.pos}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
