import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9',
    stroke: '#1c1917',
    dotGrid: '#e7e5e4',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    nodeDefault: '#a5d8ff',
    nodeVisited: '#b2f2bb',
    nodeProcessing: '#ffd43b',
    nodeCurrent: '#ff6b6b',
    nodeSource: '#d0bfff',
    nodeFound: '#b2f2bb',
    edgeDefault: '#1c1917',
    edgeTree: '#2f9e44',
    edgeHighlight: '#6366f1',
    edgeMst: '#f08c00',
    edgeBack: '#e03131',
    panelBg: 'rgba(250,250,249,0.92)',
    panelStroke: '#e7e5e4',
  },
  dark: {
    bg: 'transparent',
    stroke: 'rgba(255,255,255,0.6)',
    dotGrid: 'rgba(255,255,255,0.05)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    nodeDefault: '#1c4a6e',
    nodeVisited: '#1e5631',
    nodeProcessing: '#805b10',
    nodeCurrent: '#7c1d1d',
    nodeSource: '#3b2e6e',
    nodeFound: '#1e5631',
    edgeDefault: 'rgba(255,255,255,0.45)',
    edgeTree: '#2f9e44',
    edgeHighlight: '#818cf8',
    edgeMst: '#f08c00',
    edgeBack: '#ff6b6b',
    panelBg: 'rgba(28,25,23,0.75)',
    panelStroke: 'rgba(255,255,255,0.12)',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function nodeFill(p, name) {
  const key = `node${name.charAt(0).toUpperCase() + name.slice(1)}`;
  return p[key] || p.nodeDefault;
}

function edgeStroke(p, name) {
  const key = `edge${name.charAt(0).toUpperCase() + name.slice(1)}`;
  return p[key] || p.edgeDefault;
}

function edgeKey(from, to) {
  return `${from}-${to}`;
}

function drawArrow(ctx, x1, y1, x2, y2, color, strokeW) {
  const ang = Math.atan2(y2 - y1, x2 - x1);
  const head = 10;
  ctx.strokeStyle = color;
  ctx.lineWidth = strokeW;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x2, y2);
  ctx.lineTo(x2 - head * Math.cos(ang - Math.PI / 6), y2 - head * Math.sin(ang - Math.PI / 6));
  ctx.lineTo(x2 - head * Math.cos(ang + Math.PI / 6), y2 - head * Math.sin(ang + Math.PI / 6));
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

const GraphCanvasBase = forwardRef(function GraphCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    nodes: [],
    edges: [],
    nodeColors: {},
    edgeColors: {},
    nodeLabels: {},
    queue: [],
    stack: [],
    distances: {},
    visited: [],
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 400) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((patch) => {
    Object.assign(stateRef.current, patch);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 360;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function posMap(nodes) {
      const m = {};
      (nodes || []).forEach((n) => {
        m[n.id] = { x: n.x, y: n.y, label: n.label ?? String(n.id) };
      });
      return m;
    }

    function render() {
      const p = getPalette();
      const {
        nodes, edges, nodeColors, edgeColors, nodeLabels, queue, stack, distances, visited,
      } = stateRef.current;
      ctx.clearRect(0, 0, W, H);

      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20) {
        for (let gy = 20; gy < H; gy += 20) {
          ctx.fillRect(gx, gy, 1.1, 1.1);
        }
      }

      const positions = posMap(nodes);
      const nodeR = 22;

      const drawEdge = (e, colorName) => {
        const pf = positions[e.from];
        const pt = positions[e.to];
        if (!pf || !pt) return;
        const dx = pt.x - pf.x;
        const dy = pt.y - pf.y;
        const len = Math.hypot(dx, dy) || 1;
        const ux = dx / len;
        const uy = dy / len;
        const x1 = pf.x + ux * nodeR;
        const y1 = pf.y + uy * nodeR;
        const x2 = pt.x - ux * nodeR;
        const y2 = pt.y - uy * nodeR;
        const col = edgeStroke(p, colorName);
        if (e.directed) {
          drawArrow(ctx, x1, y1, x2, y2, col, e.bold ? 2.4 : 1.6);
        } else {
          ctx.strokeStyle = col;
          ctx.lineWidth = e.bold ? 2.4 : 1.6;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
        if (e.weight != null && e.weight !== '') {
          const mx = (x1 + x2) / 2 - uy * 8;
          const my = (y1 + y2) / 2 + ux * 8;
          ctx.fillStyle = p.panelBg;
          ctx.strokeStyle = p.panelStroke;
          ctx.lineWidth = 1;
          const wtxt = String(e.weight);
          ctx.font = '600 10px ui-monospace, Consolas, monospace';
          const tw = ctx.measureText(wtxt).width + 8;
          ctx.beginPath();
          ctx.roundRect(mx - tw / 2, my - 9, tw, 18, 4);
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = p.textPrimary;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(wtxt, mx, my);
        }
      };

      (edges || []).forEach((e) => {
        const k = edgeKey(e.from, e.to);
        const krev = edgeKey(e.to, e.from);
        const c = edgeColors[k] || edgeColors[krev] || 'default';
        drawEdge(e, c);
      });

      (nodes || []).forEach((n) => {
        const pos = positions[n.id];
        if (!pos) return;
        const cname = nodeColors[n.id] || 'default';
        ctx.beginPath();
        ctx.arc(pos.x, pos.y, nodeR, 0, Math.PI * 2);
        ctx.fillStyle = nodeFill(p, cname);
        ctx.fill();
        ctx.strokeStyle = p.stroke;
        ctx.lineWidth = 1.6;
        ctx.stroke();
        ctx.fillStyle = p.textPrimary;
        ctx.font = '700 12px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(n.label ?? n.id), pos.x, pos.y);
        const extra = nodeLabels[n.id];
        if (extra != null && extra !== '') {
          ctx.font = '600 9px ui-monospace, Consolas, monospace';
          ctx.fillStyle = p.textSecondary;
          ctx.fillText(String(extra), pos.x, pos.y + nodeR + 12);
        }
      });

      const panelW = 168;
      const panelX = W - panelW - 12;
      const panelY = 12;
      let py = panelY;
      ctx.fillStyle = p.panelBg;
      ctx.strokeStyle = p.panelStroke;
      ctx.lineWidth = 1;
      const lines = [];
      if (queue && queue.length) lines.push(`Q: ${queue.join(' → ')}`);
      if (stack && stack.length) lines.push(`S: ${stack.join(' | ')}`);
      if (distances && Object.keys(distances).length) {
        const dtxt = Object.entries(distances)
          .map(([k, v]) => `${k}:${v === Infinity ? '∞' : v}`)
          .join(' ');
        lines.push(`dist ${dtxt}`);
      }
      if (visited && visited.length) {
        lines.push(`vis: ${visited.join(',')}`);
      }
      if (lines.length) {
        const ph = 10 + lines.length * 16;
        ctx.beginPath();
        ctx.roundRect(panelX, panelY, panelW, ph, 8);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = p.textPrimary;
        ctx.font = '600 10px ui-monospace, Consolas, monospace';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        lines.forEach((line, i) => {
          ctx.fillText(line, panelX + 8, py + 8 + i * 16);
        });
      }

      for (let i = animsRef.current.length - 1; i >= 0; i--) {
        if (performance.now() - animsRef.current[i].t0 >= animsRef.current[i].dur) {
          animsRef.current.splice(i, 1);
        }
      }

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default GraphCanvasBase;
