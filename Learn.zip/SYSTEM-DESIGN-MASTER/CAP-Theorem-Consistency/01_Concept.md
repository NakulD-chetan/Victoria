# CAP Theorem and Consistency — Concept

> **Permanent Recall:** CAP states that during a network partition, you must choose Consistency or Availability—you cannot have both. Partition Tolerance is non-optional in distributed systems. The real trade-off: CP systems (HBase, MongoDB) sacrifice availability during partitions; AP systems (Cassandra, DynamoDB) sacrifice consistency. PACELC extends this: when there's no partition, choose Latency vs Consistency. Master consistency models (Strong, Eventual, Causal, Linearizability) and consensus (Paxos, Raft) to ace FAANG system design interviews.

---

## CAP Theorem — The Three Properties

| Property | Definition |
|----------|------------|
| **Consistency** | Every read receives the most recent write or an error. All nodes see the same data at the same time. |
| **Availability** | Every request receives a response (non-error). System remains responsive. |
| **Partition Tolerance** | System continues operating despite network partitions (messages lost or delayed between nodes). |

> **FAANG Tip:** Say "during a partition, you choose C or A"—not "you pick 2 of 3." Partition Tolerance is inevitable in distributed systems.

---

## Why You Can Only "Pick 2" (Actually: C or A During Partition)

**In reality:** Partition Tolerance is mandatory—networks fail. So the true choice is: **during a partition, do you favor Consistency or Availability?**

```
                    CAP TRIANGLE (Conceptual)

                         Consistency
                              ●
                             /|
                            / |
                           /  |
                          /   |
                         /    |
                        /     |
        Partition ─────●──────●────── Availability
              Tolerance      (pick 2 edges during partition)
```

**CP:** Choose Consistency → Reject requests or block until partition heals. System unavailable during partition.

**AP:** Choose Availability → Serve requests with possibly stale data. System stays up; consistency sacrificed.

---

## CP vs AP Systems — Examples Table

| Type | Systems | Behavior During Partition | Use Case |
|------|---------|---------------------------|----------|
| **CP** | HBase, MongoDB (replica set), Redis Cluster, ZooKeeper | Refuse writes or reads; wait for quorum | Financial transactions, inventory, config |
| **AP** | Cassandra, DynamoDB, CouchDB, Riak | Continue serving; may return stale data | Social feeds, analytics, session data |

---

## PACELC Theorem — Extends CAP

**When there is NO partition:** You still face a trade-off.

| Scenario | Trade-off |
|----------|-----------|
| **P**artition | **A**vailability vs **C**onsistency (CAP) |
| **E**lse (no partition) | **L**atency vs **C**onsistency |

**PACELC = P**artition → **A** or **C**; **E**lse → **L** or **C**

- **PA/EL:** Optimize for availability and low latency (e.g., DynamoDB default)
- **PC/EC:** Optimize for consistency (e.g., strongly consistent reads in DynamoDB)

> **FAANG Tip:** Mentioning PACELC shows you go beyond the oversimplified "pick 2 of 3" and understand the full trade-off space.

---

## Consistency Models — Detailed Comparison

| Model | Definition | Example |
|-------|-------------|---------|
| **Strong** | Every read sees latest write. Linear ordering. | Bank balance, inventory count |
| **Eventual** | If no new writes, replicas eventually converge. | Social media likes, counters |
| **Causal** | If A → B (causally), everyone sees A before B. | Chat messages, comments |
| **Read-your-writes** | User sees own writes immediately. | Profile edit, post creation |
| **Monotonic reads** | User never sees older data after seeing newer. | Feed pagination |
| **Linearizability** | Single-copy equivalence; real-time total order. | Locks, leader election |
| **Sequential** | All operations see a total order; per-process order preserved. | Single-key operations |

---

## Consistency Models Comparison Table

| Model | Stale reads? | Ordering guarantee | Use case |
|-------|--------------|-------------------|----------|
| **Strong / Linearizable** | No | Total order | Locks, leader, financial |
| **Sequential** | No (per-key) | Per-key order | Single-key DB ops |
| **Causal** | No (causal) | Causal order | Chat, comments |
| **Read-your-writes** | Yes (others' writes) | Own writes visible | Profile, settings |
| **Monotonic reads** | Yes | No regression | Feeds |
| **Eventual** | Yes | None (eventually same) | Counters, likes |

---

## Consensus Protocols Overview

| Protocol | Used By | Key Idea |
|----------|---------|----------|
| **Paxos** | Chubby, early systems | Proposer–acceptor–learner; complex to implement |
| **Raft** | etcd, Consul, CockroachDB | Leader election + log replication; easier to understand |
| **Zab** | ZooKeeper | Leader-based, similar to Raft |

**Purpose:** Agree on a single value or sequence of commands across nodes despite failures.

---

## Quorum Reads and Writes

**Rule:** `R + W > N` for consistent reads (where N = replication factor, R = read replicas, W = write replicas).

```
Example: N=3, R=2, W=2
  - Write: 2 nodes must acknowledge
  - Read:  2 nodes must respond
  - Overlap: At least 1 node has latest write → strong consistency
```

| Config | R | W | Consistency | Latency |
|--------|---|---|-------------|---------|
| Strong read | (N+1)/2 | (N+1)/2 | Strong | Higher |
| Eventual read | 1 | 1 | Eventual | Lower |

---

## Vector Clocks

**Purpose:** Track causal ordering of events across replicas without total order.

```
Vector: [A:3, B:1, C:2]  →  A has 3 events, B has 1, C has 2

Concurrent?  Compare vectors: neither "happens-before" the other
```

> **FAANG Tip:** Vector clocks enable causal consistency and conflict detection in distributed systems.

---

## Conflict Resolution Strategies

| Strategy | Description | When to Use |
|----------|-------------|-------------|
| **Last-Writer-Wins (LWW)** | Higher timestamp wins | Simple counters, idempotent updates |
| **Merge** | Combine values (CRDTs, merge functions) | Collaborative editing, sets |
| **Application-level** | Custom logic (e.g., "prefer newer for profile") | Domain-specific rules |
| **Manual** | Present conflict to user | Document editing, rare conflicts |

---

## 30-SECOND REVISION BOX

```
CAP: Partition → choose C or A. P is mandatory.
CP: HBase, MongoDB, ZooKeeper. AP: Cassandra, DynamoDB.
PACELC: No partition → Latency vs Consistency.
QUORUM: R + W > N for strong consistency.
CONSENSUS: Paxos, Raft, Zab.
CONFLICT: LWW, merge, application-level.
```

---

**Next: [[02_Mental-Model]]**
