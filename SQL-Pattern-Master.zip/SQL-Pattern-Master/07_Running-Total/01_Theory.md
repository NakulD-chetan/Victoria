# Running Total

A running total computes a cumulative sum over ordered rows — each row's value equals the sum of all rows up to and including itself. It's the SQL equivalent of a prefix sum array.

**DSA Analogy**: Prefix Sum array — `prefix[i] = sum(arr[0..i])`. Each position stores the cumulative total from the start. Enables O(1) range sum queries.

---

## Core Idea (2 Lines)

`SUM(col) OVER (ORDER BY ...)` computes a cumulative sum where each row includes all preceding rows plus itself. This single pattern powers running balances, rolling averages, cumulative percentages, and YTD calculations.

---

## Syntax Template

```sql
SUM(amount) OVER (
    [PARTITION BY group_col]                              -- reset per group
    ORDER BY sort_col                                     -- define the order
    [ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW]    -- explicit frame
) AS running_total
```

**The frame clause is critical:**

| Frame | Meaning | Use Case |
|-------|---------|----------|
| `ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` | All rows from start to current | Running total (default with ORDER BY) |
| `ROWS BETWEEN 6 PRECEDING AND CURRENT ROW` | Last 7 rows including current | Rolling 7-day average |
| `ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING` | All rows in partition | Grand total per partition |
| `ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING` | Previous + current + next | Smoothing |

---

## The Running Total Family

### 1. Simple Running Total (Cumulative Sum)

```sql
SELECT order_date, amount,
       SUM(amount) OVER (ORDER BY order_date) AS running_total
FROM orders;
```

```
order_date | amount | running_total
───────────┼────────┼──────────────
2024-01-01 |   100  |   100          ← 100
2024-01-02 |   200  |   300          ← 100 + 200
2024-01-03 |   150  |   450          ← 100 + 200 + 150
2024-01-04 |    50  |   500          ← 100 + 200 + 150 + 50
```

### 2. Running Total Per Group

```sql
-- Running total of sales per customer
SELECT customer_id, order_date, amount,
       SUM(amount) OVER (
           PARTITION BY customer_id
           ORDER BY order_date
       ) AS customer_running_total
FROM orders;
```

PARTITION BY resets the running total for each customer — like having a separate prefix sum array per group.

### 3. Rolling Average (Moving Average)

```sql
-- 7-day rolling average
SELECT order_date, amount,
       AVG(amount) OVER (
           ORDER BY order_date
           ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
       ) AS rolling_7day_avg
FROM daily_sales;
```

```
  Day 1: AVG(day1)                              = day1
  Day 2: AVG(day1, day2)                         = (d1+d2)/2
  ...
  Day 7: AVG(day1..day7)                         = (d1+..+d7)/7
  Day 8: AVG(day2..day8)  ← window slides        = (d2+..+d8)/7
```

### 4. Running Count

```sql
-- Cumulative number of orders
SELECT order_date,
       COUNT(*) OVER (ORDER BY order_date) AS cumulative_orders
FROM orders;
```

### 5. Running Max / Min

```sql
-- Running max salary seen so far
SELECT hire_date, name, salary,
       MAX(salary) OVER (ORDER BY hire_date) AS max_salary_so_far
FROM employees;
```

### 6. Cumulative Percentage

```sql
-- What percentage of total revenue has accumulated by each date?
SELECT order_date, amount,
       SUM(amount) OVER (ORDER BY order_date) AS running_total,
       ROUND(
           100.0 * SUM(amount) OVER (ORDER BY order_date)
           / SUM(amount) OVER (),
           2
       ) AS cumulative_pct
FROM orders;
```

---

## How Running Total Executes (Mental Model)

```
Prefix Sum Array:                  SQL Running Total:

arr  = [100, 200, 150, 50]        ORDER BY order_date
                                   Frame: UNBOUNDED PRECEDING to CURRENT ROW
pre[0] = 100                      
pre[1] = 100 + 200 = 300          For each row:
pre[2] = 300 + 150 = 450            SUM = all rows from first to current
pre[3] = 450 + 50  = 500            (engine actually scans the frame)

Range sum [1..2] = pre[2]-pre[0]   SQL doesn't cache prefix sums — but
                  = 450 - 100      the optimizer may use incremental 
                  = 350            computation internally.
```

---

## ROWS vs RANGE — The Subtle Trap

```sql
-- ROWS: counts physical row positions
SUM(amount) OVER (ORDER BY date ROWS BETWEEN 2 PRECEDING AND CURRENT ROW)
-- Always exactly 3 rows (2 before + current)

-- RANGE: considers logical value ranges (includes ties!)
SUM(amount) OVER (ORDER BY date RANGE BETWEEN 2 PRECEDING AND CURRENT ROW)
-- Includes ALL rows with date within 2 units of current date
-- If 3 rows have the same date, all 3 are included

-- Default (when you specify ORDER BY but no frame):
-- RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
-- This INCLUDES all ties with the current row!
```

**Golden rule**: Use ROWS for exact physical window sizes. Use RANGE only when you want value-based inclusion (rare).

---

## Real-World Patterns

### Bank Account Running Balance

```sql
SELECT txn_date, description,
       CASE WHEN type = 'credit' THEN amount ELSE -amount END AS signed_amount,
       SUM(CASE WHEN type = 'credit' THEN amount ELSE -amount END)
           OVER (ORDER BY txn_date, id) AS balance
FROM transactions
WHERE account_id = 12345;
```

### Year-to-Date (YTD) Revenue

```sql
SELECT order_date, amount,
       SUM(amount) OVER (
           PARTITION BY EXTRACT(YEAR FROM order_date)
           ORDER BY order_date
       ) AS ytd_revenue
FROM orders;
```

### Last Person to Fit in the Bus (Classic Problem)

```sql
WITH running AS (
    SELECT person_name, weight,
           SUM(weight) OVER (ORDER BY turn) AS total_weight
    FROM queue
)
SELECT person_name
FROM running
WHERE total_weight <= 1000
ORDER BY total_weight DESC
LIMIT 1;
```

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Default frame includes ties (RANGE) | Running total jumps for tied dates | Use explicit ROWS frame |
| No ORDER BY in window | Nondeterministic — all rows get same total | Always specify ORDER BY |
| Rolling window off by one | "7-day" needs ROWS BETWEEN 6 PRECEDING | Frame endpoints are inclusive |
| Rolling avg on sparse dates | Missing dates create uneven windows | Fill dates first (Pattern 11) |
| PARTITION BY wrong column | Running total resets at wrong boundaries | Match PARTITION BY to your grouping need |

---

## Performance Notes

```
Running Total Complexity:
  Simple approach: O(N²) — re-scan frame for each row
  Optimized:       O(N)  — incremental: add new row, subtract expired row
  
  Most modern engines (PostgreSQL 10+, Spark, BigQuery) use incremental.
  
  For large datasets:
  - Ensure ORDER BY column is indexed
  - Use ROWS (not RANGE) for predictable performance
  - PARTITION BY reduces the window size per group
```

---

## Key Takeaway

> Running total = prefix sum in SQL. Use `SUM() OVER (ORDER BY col)` for cumulative sums, `AVG() OVER (ORDER BY col ROWS BETWEEN N PRECEDING AND CURRENT ROW)` for rolling averages. Always use explicit ROWS frame to avoid the RANGE tie-inclusion trap. PARTITION BY resets the running total per group.
