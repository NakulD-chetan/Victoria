# SQL — Complete Notes Index

> **Style:** Hindi + English mix (interview-friendly) + detailed explanations with examples
> **Level:** Beginner → Intermediate → FAANG/Product Interview Ready
> **Covers:** SQL fundamentals, queries, joins, subqueries, window functions, optimization, normalization, transactions

---

## Notes Structure

| # | File | Topics Covered | Level |
|---|------|----------------|-------|
| 01 | [[01-SQL-Basics-and-Introduction]] | What is SQL, DBMS vs RDBMS, SQL Sub-Languages (DDL, DML, DQL, DCL, TCL), Data Types, Constraints, Keys (Primary, Foreign, Candidate, Composite, Super) | Beginner |
| 02 | [[02-DDL-Commands]] | CREATE, ALTER (ADD/MODIFY/DROP/RENAME column), DROP vs TRUNCATE vs DELETE, RENAME, Schema Design Examples | Beginner |
| 03 | [[03-DML-and-DQL-Commands]] | INSERT (single/multiple/from another table), UPDATE, DELETE, SELECT, Aliases, DISTINCT, LIMIT/TOP, CASE WHEN | Beginner-Medium |
| 04 | [[04-SQL-Clauses-and-Filtering]] | WHERE, Comparison Operators, LIKE & Wildcards, IN, BETWEEN, IS NULL/IS NOT NULL, AND/OR/NOT, ORDER BY, GROUP BY, HAVING, Execution Order of SQL | Medium |
| 05 | [[05-SQL-Joins]] | INNER JOIN, LEFT JOIN, RIGHT JOIN, FULL OUTER JOIN, CROSS JOIN, SELF JOIN, Natural Join, Non-Equi Join, Joining 3+ Tables, Join vs Subquery | Medium |
| 06 | [[06-Subqueries-and-Nested-Queries]] | Single-row Subquery, Multi-row Subquery, Correlated Subquery, EXISTS vs IN, Subquery in SELECT/FROM/WHERE/HAVING, Scalar Subquery, CTE (WITH clause) | Medium-Hard |
| 07 | [[07-Aggregate-Functions-and-GroupBy]] | COUNT, SUM, AVG, MIN, MAX, GROUP BY (single & multiple columns), HAVING vs WHERE, GROUPING SETS, ROLLUP, CUBE | Medium |
| 08 | [[08-Window-Functions]] | ROW_NUMBER, RANK, DENSE_RANK, NTILE, LEAD, LAG, FIRST_VALUE, LAST_VALUE, SUM/AVG OVER, PARTITION BY, ORDER BY in Window, Frame Clause (ROWS/RANGE) | Medium-Hard |
| 09 | [[09-Indexes-Views-and-Optimization]] | What is Index, Clustered vs Non-Clustered, Composite Index, Covering Index, When to Index, Views, Materialized Views, EXPLAIN/Query Plan, Query Optimization Tips | Medium-Hard |
| 10 | [[10-Normalization]] | Functional Dependency, 1NF, 2NF, 3NF, BCNF, 4NF, Denormalization, When to Normalize vs Denormalize, Anomalies (Insert/Update/Delete) | Medium |
| 11 | [[11-Transactions-and-ACID]] | ACID Properties, COMMIT, ROLLBACK, SAVEPOINT, Isolation Levels (Read Uncommitted, Read Committed, Repeatable Read, Serializable), Dirty Read, Phantom Read, Deadlock | Medium-Hard |
| 12 | [[12-FAANG-SQL-Interview-Must-Know]] | Top 25 Interview Questions with Solutions, Query Writing Patterns, Common Mistakes, SQL vs NoSQL, Optimization Checklist, Practice Problem Categories | Advanced |
| 13 | [[13-SQL-Plain-English-Windows-CTE-Execution]] | Plain English: logical execution order, why WHERE cannot use window aliases, CTE mental model, ROW_NUMBER vs RANK vs DENSE_RANK (when to use), CTE + window flow | All levels |
| 14 | [[14-Deep-GROUP-BY]] | GROUP BY deep dive: buckets mental model, logical execution position, SELECT vs GROUP BY rule, NULL groups, multi-column keys, JOIN fan-out / double-count trap, vs DISTINCT vs window PARTITION BY, thinking checklist | Medium-Hard |

---

## Quick Revision Path

### Exam/Viva ke liye (30 min revision):
```
01 → Quick Memory Card (SQL types, keys, constraints)
02 → DDL Commands Summary Table
03 → DML/DQL Syntax Quick Reference
04 → Execution Order of SQL (bahut important!)
05 → Join Venn Diagrams + Comparison Table
07 → Aggregate Functions Cheatsheet
10 → Normal Forms Summary Table
11 → ACID Quick Memory Card
```

### Interview Prep (2-3 hours):
```
01 → Full read (basics strong karo — keys, constraints puchhe jaate hain)
04 → SQL execution order + filtering (WHERE vs HAVING)
05 → All Join types + Self Join (bahut puchha jaata hai)
06 → Correlated Subquery + CTE (must know)
08 → Window Functions — ROW_NUMBER, RANK, LAG/LEAD (FAANG favorite!)
09 → Index types + Query optimization
10 → Normalization (theory rounds mein zaroor aata hai)
12 → Top 25 problems + patterns practice karo
```

---

## Key Concepts — One Place

| Concept | Definition |
|---------|-----------|
| Primary Key | Uniquely identifies each row, NOT NULL + UNIQUE |
| Foreign Key | References Primary Key of another table |
| INNER JOIN | Sirf matching rows dono tables se |
| LEFT JOIN | Left table ke sab rows + matching from right |
| WHERE vs HAVING | WHERE = row filter (before GROUP BY), HAVING = group filter (after GROUP BY) |
| Subquery | Query ke andar query |
| CTE | Temporary named result set (WITH clause) |
| Window Function | Aggregate without collapsing rows |
| Index | Data structure for fast lookup (like book index) |
| Normalization | Redundancy hatao, anomalies avoid karo |
| ACID | Atomicity, Consistency, Isolation, Durability |
| Clustered Index | Data physically sorted (1 per table) |
| Non-Clustered | Separate structure pointing to data (multiple allowed) |

---

## SQL Execution Order (MUST REMEMBER!)

```
Written Order:          Execution Order:
SELECT                  1. FROM / JOIN
FROM                    2. WHERE
WHERE                   3. GROUP BY
GROUP BY                4. HAVING
HAVING                  5. SELECT
ORDER BY                6. DISTINCT
LIMIT                   7. ORDER BY
                        8. LIMIT / OFFSET
```

> **Interview mein yeh question 90% aata hai:** "SQL query execution order kya hai?"

---

## Complete Topic Flow

```
SQL (Structured Query Language)
│
├── Basics & Introduction ──────────────── [01]
│   ├── DBMS vs RDBMS
│   ├── SQL Sub-Languages (DDL/DML/DQL/DCL/TCL)
│   ├── Data Types & Constraints
│   └── Keys (PK, FK, CK, SK, Composite)
│
├── DDL (Data Definition Language) ─────── [02]
│   ├── CREATE, ALTER, DROP
│   └── TRUNCATE vs DELETE
│
├── DML & DQL (Data Manipulation/Query) ── [03]
│   ├── INSERT, UPDATE, DELETE
│   └── SELECT, DISTINCT, CASE WHEN
│
├── Clauses & Filtering ───────────────── [04]
│   ├── WHERE, LIKE, IN, BETWEEN
│   ├── ORDER BY, GROUP BY, HAVING
│   └── SQL Execution Order
│
├── Joins ─────────────────────────────── [05]
│   ├── INNER, LEFT, RIGHT, FULL OUTER
│   ├── CROSS JOIN, SELF JOIN
│   └── Multi-Table Joins
│
├── Subqueries & CTEs ─────────────────── [06]
│   ├── Single/Multi-row Subqueries
│   ├── Correlated Subqueries
│   └── CTE (WITH clause)
│
├── Aggregate Functions ───────────────── [07]
│   ├── COUNT, SUM, AVG, MIN, MAX
│   └── GROUP BY, HAVING, ROLLUP, CUBE
│
├── Deep GROUP BY (mental model & traps) ─ [14]
│   ├── Buckets / grain / execution position
│   └── JOIN double-count, vs DISTINCT, vs windows
│
├── Window Functions ──────────────────── [08]
│   ├── ROW_NUMBER, RANK, DENSE_RANK
│   ├── LEAD, LAG, NTILE
│   └── Frame Clause (ROWS/RANGE)
│
├── Indexes, Views & Optimization ─────── [09]
│   ├── Clustered vs Non-Clustered Index
│   ├── Views & Materialized Views
│   └── Query Optimization Tips
│
├── Normalization ─────────────────────── [10]
│   ├── 1NF → 2NF → 3NF → BCNF
│   └── Denormalization
│
├── Transactions & ACID ───────────────── [11]
│   ├── ACID Properties
│   ├── Isolation Levels
│   └── Deadlocks
│
├── FAANG Interview Must-Know ─────────── [12]
│   ├── Top 25 SQL Problems
│   ├── Query Patterns
│   └── Optimization Checklist
│
└── Plain English (Windows, CTE, Flow) ─── [13]
    ├── Logical execution order
    ├── CTE step-by-step mental model
    └── RANK / DENSE_RANK / ROW_NUMBER — when to use
```

---

*Total: 14 topic files + this index | Beginner to FAANG Interview Ready | Definitions + Examples + Code*
