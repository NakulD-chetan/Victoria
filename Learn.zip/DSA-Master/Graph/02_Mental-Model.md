# Graph — Mental Model

> **Permanent Recall:** Graphs = map of cities and roads. BFS = ripple in water (level by level). DFS = maze exploration (go deep). Topo = prerequisite ordering. Dijkstra = greedy shortest path. Choose algorithm by: shortest path? → BFS/Dijkstra. Dependencies? → Topo. Reachability? → BFS/DFS. Components? → DFS/BFS.

---

## How FAANG Engineers Think About Graphs

1. **Model first:** What are nodes? What are edges? Directed or not?
2. **Goal:** Shortest path? Ordering? Reachability? Components? Cycle?
3. **Pick tool:** BFS vs DFS vs Dijkstra vs Topo — one primary choice
4. **Edge cases:** Disconnected? Single node? Empty?

---

## The "Map of Cities and Roads" Analogy

```
        Cities = Vertices
        Roads  = Edges
        Distance = Weight (if weighted)

    [A]====3====[B]
     |  \       |
     2   1      4
     |    \     |
    [C]====2====[D]

- Want shortest route A→D? → Dijkstra (or BFS if all roads same length)
- Want to visit all cities? → BFS or DFS
- One-way streets? → Directed graph
```

**Every graph problem:** "What's my map? What am I trying to find?"

---

## BFS = "Ripple in Water"

- Drop a stone at source; waves spread outward
- First wave to hit a node = shortest distance (unweighted)
- **Level 0:** source; **Level 1:** neighbors; **Level 2:** neighbors of neighbors...

```
        Level 0:     [S]
        Level 1:   [1][2][3]
        Level 2: [4][5][6][7]
        Level 3: [8][9]...

        Ripple expands uniformly — first touch = shortest
```

**Mental image:** Concentric circles expanding from source.

---

## DFS = "Maze Exploration"

- Pick a path, go as far as you can
- Hit dead end? Backtrack, try next branch
- **No guarantee** of shortest path — just "can I reach?"

```
        Start → [A] → [B] → [C] → [D] (dead end, backtrack)
                    ↘ [E] → [F] (found target!)
```

**Mental image:** Exploring a maze with a ball of string; unwind when backtracking.

---

## Topological Sort = "Prerequisite Ordering"

- Course A must be done before B → edge A→B
- Valid order: do A, then B (A before B in list)
- **Only works on DAG** — cycle = impossible ordering

```
    "Take Calc before Physics, Physics before Engineering"

    Calc → Physics → Engineering
      \       /
       \     /
        Chem

    Valid order: Calc, Chem, Physics, Engineering (or similar)
```

**Mental image:** To-do list where some tasks block others.

---

## Dijkstra = "Greedy Shortest Path"

- Always extend from the *closest* unvisited node
- Like BFS but with a *priority queue* (distance) instead of plain queue
- **Greedy:** Current shortest is globally shortest (only with non-negative weights)

```
    Pick closest: S(0) → A(2) → B(5) → C(7) → D(9)
                  |      |      |
                  +------+------+  (relax edges)
```

**Mental image:** Spreading ink from source; ink flows fastest through shortest paths first.

---

## Decision Triggers: BFS vs DFS vs Dijkstra

| Question | Answer |
|----------|--------|
| **Shortest path, unweighted?** | BFS |
| **Shortest path, weighted, no negative?** | Dijkstra |
| **Shortest path, negative weights?** | Bellman-Ford |
| **Prerequisites / dependencies / ordering?** | Topological sort |
| **Can A reach B?** | BFS or DFS (either works) |
| **All paths / explore all?** | DFS |
| **Level-by-level / distance layers?** | BFS |
| **Connected components?** | DFS or BFS |
| **Cycle detection?** | DFS (directed: 3-color; undirected: parent) |
| **Multi-source spread (e.g. rotten oranges)?** | Multi-source BFS |

---

## Decision Flowchart: BFS vs DFS vs Dijkstra

```mermaid
flowchart TD
    START["START"] --> Q1["Shortest path?"]
    Q1 -->|Yes| Q2["Weighted?"]
    Q1 -->|No| Q3["Dependencies?"]
    Q2 -->|No| BFS["BFS"]
    Q2 -->|Yes| Dijkstra["Dijkstra"]
    Q3 -->|Yes| Topo["Topological Sort"]
    Q3 -->|No| Q4["Reachability?"]
    Q4 -->|Yes| BFSDFS1["BFS or DFS"]
    Q4 -->|No| Q5["Components?"]
    Q5 -->|Yes| BFSDFS2["DFS or BFS"]
    Q5 -->|No| Q6["Cycle?"]
    Q6 -->|Yes| DFS3["DFS (color/parent)"]
    style BFS fill:#90EE90
    style Dijkstra fill:#87CEEB
    style Topo fill:#DDA0DD
    style BFSDFS1 fill:#FFE4B5
    style BFSDFS2 fill:#FFE4B5
    style DFS3 fill:#F0E68C
```

<details>
<summary>ASCII fallback</summary>

```
                    START
                      |
              "Shortest path?"
                   /    \
                 Yes     No
                  |       |
            "Weighted?"   "Dependencies?"
             /      \       /    \
           No       Yes   Yes     No
            |        |     |       |
           BFS    Dijkstra Topo   "Reachability?"
            |        |     |       /    \
            |        |     |    BFS/DFS  "Components?"
            |        |     |      |       /    \
            |        |     |      |    DFS/BFS  "Cycle?"
            |        |     |      |      |       /    \
            v        v     v      v      v    DFS (color/parent)
```

</details>

---

## ASCII Graph Diagrams for Interview

### Basic Traversal

```
Graph:         BFS from A:        DFS from A:
  A---B        A, B, C, D         A, B, D, C
  |   |        (level order)      (depth first)
  C---D
```

### Shortest Path (Unweighted)

```
  [1]---[2]---[5]
   |     |     |
  [3]---[4]---[6]

  BFS from 1: dist[1]=0, dist[2]=1, dist[3]=1, dist[4]=2, dist[5]=2, dist[6]=3
```

### DAG + Topological Sort

```
    A ──> B ──> D
    │     │
    v     v
    C ──> E

  Topo: A, B, C, D, E (or A, C, B, D, E, etc.)
```

### Multi-Source BFS (Rotten Oranges)

```
  Fresh=1, Rotten=2
  [2][1][1]
  [1][1][0]
  [0][1][1]

  Start BFS from all 2's simultaneously → minutes to rot all
```

---

## Golden Mental Model Summary

| Concept | One-Line Mental Model |
|---------|------------------------|
| **BFS** | Ripple in water; first touch = shortest (unweighted) |
| **DFS** | Maze exploration; go deep, backtrack |
| **Dijkstra** | Greedy ink spread; always extend from closest |
| **Topo** | Prerequisite list; do blockers first |
| **Cycle** | Back edge to ancestor (directed) or non-parent (undirected) |
| **Components** | How many "islands" of connectivity? |

---

## FINAL MEMORY COMPRESSION BLOCK

```
MENTAL MODEL:     Graph = cities + roads
BFS:              Ripple; level-by-level; shortest (unweighted)
DFS:              Maze; go deep; reachability, cycle, components
DIJKSTRA:         Greedy ink; extend from closest; non-negative only
TOPO:             Prerequisites; DAG ordering
DECISION:         Shortest? → BFS/Dijkstra | Deps? → Topo | Reach? → BFS/DFS
INTERVIEW:        "Nodes are X, edges are Y. I'll use BFS because we need
                   shortest path in unweighted graph."
```
