# Database Fundamentals — Data Kahan Aur Kaise Store Karo

> **Database = Tumhara data ka permanent ghar — sahi jagah rakhoge toh fast milega, galat jagah toh chaos!**
> SQL vs NoSQL samajhna FAANG interview ka sabse basic requirement hai

---

## Table of Contents
1. [Database Kya Hai?](#1-database-kya-hai)
2. [SQL vs NoSQL](#2-sql-vs-nosql)
3. [ACID Properties](#3-acid-properties)
4. [BASE Properties](#4-base-properties)
5. [Indexing in Depth](#5-indexing-in-depth)
6. [Transactions](#6-transactions)
7. [Isolation Levels](#7-isolation-levels)
8. [Normalization vs Denormalization](#8-normalization-vs-denormalization)
9. [When to Use What](#9-when-to-use-what)
10. [Interview Questions & Traps](#10-interview-questions--traps)

---

## 1. Database Kya Hai?

### Core Concept
Database = **Organized data ka storage** — jahan data structured tarike se store ho, fast retrieve ho, aur multiple users simultaneously access kar saken.

### Real World Analogy: Pantry/Godown
- **Pantry** = Sabzi, daal, chawal alag-alag sections mein
- **Database** = Users, orders, products alag-alag tables mein
- **Index** = Pantry ka list (kya kahan hai) — bina list ke sabzi dhundhna mushkil
- **Query** = "Daal lao" = SELECT * FROM pantry WHERE item='daal'

### How It Works

```
    ┌─────────────────────────────────────────────────────┐
    │                    DATABASE                           │
    │  ┌─────────┐  ┌─────────┐  ┌─────────┐              │
    │  │  Table  │  │  Table  │  │  Table  │              │
    │  │ Users   │  │ Orders  │  │ Products│              │
    │  └────┬────┘  └────┬────┘  └────┬────┘              │
    │       │             │             │                  │
    │       └─────────────┼─────────────┘                  │
    │                     │                                │
    │              Relations (Foreign Keys)                │
    └─────────────────────────────────────────────────────┘
```

### 1 Minute Recall Block
> Database = Organized storage. Tables + Relations + Indexes. Pantry analogy = items organized, list = index.

### 5 Bullet Memory Hooks
- Database = structured data storage
- Tables = rows + columns
- Index = fast lookup (like book index)
- Relations = tables connect (foreign key)
- CRUD = Create, Read, Update, Delete

### Database Types Overview
- **OLTP** (Online Transaction Processing): Day-to-day operations — orders, users. ACID, fast small transactions.
- **OLAP** (Online Analytical Processing): Analytics, reporting. Bulk reads, aggregations. Data warehouses.
- **Hybrid:** Some DBs (e.g., PostgreSQL) dono handle kar sakte hain.

---

## 2. SQL vs NoSQL

### 2.1 SQL (Relational) Databases

#### Core Concept
**Tables, rows, columns** — Fixed schema, relations between tables, ACID compliant. Data structured, predictable.

#### Structure

```
    SQL Table: users
    ┌────┬──────────┬─────────┬────────────┐
    │ id │ name     │ email   │ created_at │
    ├────┼──────────┼─────────┼────────────┤
    │ 1  │ Rahul    │ r@x.com │ 2024-01-01 │
    │ 2  │ Priya    │ p@x.com │ 2024-01-02 │
    └────┴──────────┴─────────┴────────────┘
    
    Relations: orders.user_id → users.id (Foreign Key)
```

#### SQL Examples & Use Cases

| Database | Best For | Key Feature |
|----------|----------|-------------|
| **PostgreSQL** | Complex queries, JSON, extensions | ACID, JSONB, full-text search |
| **MySQL** | Web apps, read-heavy | Fast reads, replication |
| **Oracle** | Enterprise, legacy | PL/SQL, advanced features |
| **SQLite** | Embedded, mobile, dev | File-based, zero config |

### 2.2 NoSQL Databases

#### Types & Use Cases

```
    NoSQL Types
    │
    ├── Key-Value (Redis, Memcached)
    │   └── Cache, session, simple lookup
    │
    ├── Document (MongoDB, CouchDB)
    │   └── Flexible schema, nested data
    │
    ├── Column-Family (Cassandra, HBase)
    │   └── Wide columns, time-series
    │
    └── Graph (Neo4j, Neptune)
        └── Relationships, social, recommendations
```

#### Key-Value Example (Redis)
```
    key: "user:1001"
    value: "{\"name\":\"Rahul\",\"age\":25}"
    
    O(1) lookup — cache, session store
```

#### Document Example (MongoDB)
```json
    {
      "_id": 1,
      "name": "Rahul",
      "orders": [
        {"product": "Phone", "qty": 2},
        {"product": "Case", "qty": 1}
      ]
    }
```
Flexible schema — nested data, evolving structure

#### Column-Family Example (Cassandra)
```
    Row Key: user_1001
    Columns: name | age | city | last_login
             Rahul| 25 | Mumbai| 2024-03-01
    
    Wide rows — analytics, time-series
```

#### Graph Example (Neo4j)
```
    (User)-[:FRIENDS]->(User)-[:BOUGHT]->(Product)
    
    "Friends who bought this also bought..."
```

### SQL vs NoSQL Comparison Table

| Aspect | SQL | NoSQL |
|--------|-----|-------|
| Schema | Fixed, predefined | Flexible, dynamic |
| Data model | Tables, rows, columns | Key-value, document, graph |
| Scaling | Vertical (bigger machine) | Horizontal (more machines) |
| ACID | Full support | Varies (often BASE) |
| Joins | Native, powerful | Manual, limited |
| Use case | Complex relations, transactions | Scale, flexibility |
| Examples | PostgreSQL, MySQL | MongoDB, Redis, Cassandra |

### 1 Minute Recall Block
> SQL = Tables + Relations + ACID. NoSQL = Flexible + Scale. Key-Value (Redis), Document (Mongo), Column (Cassandra), Graph (Neo4j).

### ⚠️ Common Interview Trap
**Trap:** "NoSQL means no SQL?" — **Wrong!** NoSQL = Not Only SQL. Some NoSQL (MongoDB) support SQL-like queries. NoSQL = non-relational, flexible schema.

---

## 3. ACID Properties

### Core Concept
**ACID** = Atomicity, Consistency, Isolation, Durability — Transaction guarantee jo SQL databases dete hain.

### 3.1 Atomicity (A)

#### Kya Hai?
**All or Nothing** — Transaction ke saare operations ya toh complete ho jayein ya kuch bhi na ho. Partial success = failure. Rollback = undo sab kuch.

#### Real World Example: Bank Transfer
```
    Transfer 1000: Account A → Account B
    
    Step 1: A -= 1000  ✓
    Step 2: B += 1000  ✗ (Server crash!)
    
    Without Atomicity: 1000 gayab! (A se minus, B ko nahi mila)
    With Atomicity: Rollback — A bhi 1000, B bhi same (nothing happened)
```

#### How It Works
```
    BEGIN TRANSACTION
        UPDATE accounts SET balance = balance - 1000 WHERE id = 'A';
        UPDATE accounts SET balance = balance + 1000 WHERE id = 'B';
    COMMIT;  -- Both succeed, or ROLLBACK (both revert)
```

### 3.2 Consistency (C)

#### Kya Hai?
**Valid state** — Transaction ke baad database valid rules follow kare (constraints, foreign keys). Database ek "consistent state" se doosri "consistent state" mein jata hai.

#### Real World Example
- Balance kabhi negative nahi
- Foreign key = orders.user_id must exist in users
- Sum of parts = total (debit = credit in accounting)

#### Note: CAP Consistency ≠ ACID Consistency
- **ACID Consistency:** Database constraints, valid state
- **CAP Consistency:** All nodes same data dikhayen
- Different concepts! Don't confuse in interview.

### 3.3 Isolation (I)

#### Kya Hai?
**Concurrent transactions ek doosre ko affect na karein** — Parallel transactions independent chalenge.

#### Real World Example
```
    User A: Read balance (1000), Add 500, Write 1500
    User B: Read balance (1000), Subtract 200, Write 800
    
    Without Isolation: Race condition — final could be wrong
    With Isolation: Each sees consistent view, correct result
```

### 3.4 Durability (D)

#### Kya Hai?
**Committed = Permanent** — COMMIT ke baad data kabhi lose nahi hoga (crash, power failure ke baad bhi).

#### How It Works
```
    COMMIT → Write to disk (WAL - Write Ahead Log)
    Crash → Restart → Replay WAL → Data restored
```

### ACID Summary Table

| Property | Meaning | Example |
|----------|---------|---------|
| Atomicity | All or nothing | Bank transfer — both or none |
| Consistency | Valid state | No negative balance |
| Isolation | Concurrent = independent | Two users, no interference |
| Durability | Committed = permanent | Survives crash |

### 1 Minute Recall Block
> A = All or nothing. C = Valid rules. I = No interference. D = Permanent after commit.

---

## 4. BASE Properties

### Core Concept
**BASE** = Basically Available, Soft state, Eventually consistent — ACID ka alternative for distributed/NoSQL systems.

### 4.1 Basically Available (BA)

**Kya Hai?** System mostly available — partition pe bhi respond karega (stale ho sakta hai).

### 4.2 Soft State (S)

**Kya Hai?** State time ke saath change ho sakta hai — consistency guarantee nahi, replication ke through update.

### 4.3 Eventually Consistent (E)

**Kya Hai?** Writes band ho jayein toh eventually sab nodes same data dikhayenge.

### ACID vs BASE Comparison Table

| Aspect | ACID | BASE |
|--------|------|------|
| Consistency | Strong, immediate | Eventual |
| Availability | May sacrifice (CP) | Prioritize (AP) |
| Use case | Banking, inventory | Social, analytics |
| Systems | PostgreSQL, MySQL | Cassandra, DynamoDB |
| Trade-off | Correct > Available | Available > Correct |

### 1 Minute Recall Block
> BASE = ACID ka opposite for scale. Basically Available + Soft state + Eventually consistent. NoSQL default.

---

## 5. Indexing in Depth

### 5.1 Why Indexing?

#### Real World Analogy: Library Card Catalog
- **Without index:** 1 lakh books mein se "Database" dhundhna — har shelf check
- **With index:** Alphabetical catalog — "D" section mein direct jao

#### How It Works

```
    Without Index: Full Table Scan
    SELECT * FROM users WHERE email = 'r@x.com'
    → Scan 1 million rows (slow!)
    
    With Index on email:
    → B-Tree lookup → 1 row (fast!)
```

### 5.2 B-Tree Index (Most Common)

#### Structure

```
                    [M]                    <- Root
                   /   \
              [D,H]     [R,W]               <- Branch
             /  |  \    /  |  \
          [A-C][E-G][I-L][N-Q][S-V][X-Z]   <- Leaves (sorted)
```

- **Balanced tree** — sab leaves same depth (O(log n) for any operation)
- **Sorted** — range queries efficient (WHERE id BETWEEN 1 AND 100)
- **Default** in PostgreSQL, MySQL
- **B+ Tree** (variant): Data sirf leaves pe, internal nodes = keys only — better for range scans

#### Why B-Tree for Databases?
- Disk I/O optimized — each node = one page (4KB-16KB)
- Sequential access on leaves — range queries fast
- Insert/Delete = O(log n) — balanced rebalancing

### 5.3 Hash Index

#### Structure
```
    key → hash(key) → bucket → value
    
    O(1) lookup — but ONLY equality (=)
    Range queries (>, <, BETWEEN) — NOT supported
```

**Use case:** Exact match (email, username)

### 5.4 Composite Index

```
    INDEX (col1, col2, col3)
    
    Useful for: WHERE col1 = X AND col2 = Y
    Order matters! (col1, col2) ≠ (col2, col1)
```

**Rule:** Leftmost prefix — (A,B,C) index helps (A), (A,B), (A,B,C) — but NOT (B) or (C) alone.

**Interview Tip:** "Composite index (country, city) — query WHERE city='Mumbai' use karega?" **No!** Leftmost prefix — country pehle chahiye. (country, city) helps WHERE country=X AND city=Y, not just city.

### 5.5 Covering Index

```
    Index includes all columns needed for query
    → No need to go to table (index-only scan)
    
    Query: SELECT name FROM users WHERE email = 'x@y.com'
    Index: (email) INCLUDE (name)  → Fast! No table lookup
```

**Why it matters:** Table lookup = random I/O (slow). Index-only = sequential (fast). "Index covers" the query.

### 5.6 Clustered vs Non-Clustered Index

| Type | Storage | Tables |
|------|---------|--------|
| **Clustered** | Data sorted by index (1 per table) | Primary key usually |
| **Non-Clustered** | Separate structure, points to data | Secondary indexes |

**Example:** MySQL InnoDB = clustered by primary key. PostgreSQL = heap (no clustered), indexes point to heap.

### When to Index vs When Not

| Index | When | When NOT |
|-------|------|----------|
| Do | High cardinality columns (email, id) | Low cardinality (gender, boolean) |
| Do | WHERE, JOIN, ORDER BY columns | Rarely queried columns |
| Do | Foreign keys | Small tables (< 1000 rows) |
| Don't | Too many indexes (slows writes) | Write-heavy tables |
| Don't | Frequently updated columns | |

### 1 Minute Recall Block
> Index = fast lookup. B-Tree = range + equality. Hash = equality only. Composite = order matters. Covering = index has all columns.

### ⚠️ Common Interview Trap
**Trap:** "More indexes = faster?" — **No!** Indexes slow down INSERT/UPDATE (each index update karna padta hai). Balance chahiye.

---

## 6. Transactions

### Core Concept
**Transaction** = Ek ya multiple operations ka group — sab succeed ya sab fail. ACID properties transactions pe apply hote hain.

### Commands

```
    BEGIN;        -- Start transaction
    -- SQL operations
    COMMIT;       -- Save permanently
    -- OR
    ROLLBACK;     -- Undo everything
```

### Example

```sql
    BEGIN;
    INSERT INTO orders (user_id, amount) VALUES (1, 500);
    UPDATE users SET balance = balance - 500 WHERE id = 1;
    -- If any fails:
    ROLLBACK;
    -- If all succeed:
    COMMIT;
```

### 1 Minute Recall Block
> BEGIN → operations → COMMIT (success) or ROLLBACK (failure).

### Savepoints (Nested Transactions)
```sql
    BEGIN;
    INSERT INTO orders ...;
    SAVEPOINT sp1;
    UPDATE inventory ...;  -- If this fails:
    ROLLBACK TO sp1;      -- Only undo update, keep insert
    COMMIT;
```

---

## 7. Isolation Levels

### Core Concept
**Isolation level** = Concurrent transactions kitna "doosre se alag" chalenge — consistency vs performance trade-off.

### 7.1 Read Uncommitted (Dirty Reads)

- **Kya hai:** Uncommitted data bhi read ho sakta hai
- **Problem:** User A ne write kiya (not committed), User B ne read kiya — A ne rollback kiya, B ne galat data dekha!
- **Use:** Almost never

### 7.2 Read Committed

- **Kya hai:** Sirf committed data read
- **Problem:** Same query 2 baar — different results (non-repeatable read)
- **Use:** Default in many DBs

### 7.3 Repeatable Read

- **Kya hai:** Transaction ke andar same read = same result
- **Problem:** Phantom reads (new rows appear)
- **Use:** MySQL default

### 7.4 Serializable

- **Kya hai:** Sabse strict — serial order mein execute. Phantom reads bhi prevent.
- **Use:** Critical data, financial. Slowest — locks zyada.

### Isolation Level Selection Guide

```
    Default (most apps): Read Committed
    Need repeatable reads? (reporting): Repeatable Read
    Money, critical? Serializable
    Never: Read Uncommitted (dirty reads = data corruption risk)
```

### Isolation Levels Comparison Table

| Level | Dirty Read | Non-Repeatable | Phantom | Performance |
|-------|------------|----------------|---------|-------------|
| Read Uncommitted | Yes | Yes | Yes | Fastest |
| Read Committed | No | Yes | Yes | Fast |
| Repeatable Read | No | No | Yes | Medium |
| Serializable | No | No | No | Slowest |

### 1 Minute Recall Block
> Read Uncommitted < Read Committed < Repeatable Read < Serializable. Stricter = slower but correct.

---

## 8. Normalization vs Denormalization

### 8.1 Normalization

**Kya hai?** Data ko break karo — redundancy hatayo, tables alag karo. Goal = minimize redundancy, prevent update anomalies.

**1NF (First Normal Form):** Atomic values — har cell mein single value, no lists/arrays.
```
    BAD:  skills = "Java, Python, SQL"
    GOOD: Separate row per skill (user_id, skill)
```

**2NF (Second Normal Form):** No partial dependency — non-key columns fully depend on entire primary key.
```
    BAD:  (order_id, product_id) → product_name (product_name depends only on product_id)
    GOOD: orders (order_id, product_id, qty), products (product_id, product_name)
```

**3NF (Third Normal Form):** No transitive dependency — non-key columns don't depend on other non-key columns.
```
    BAD:  users (id, name, city, state) — state depends on city
    GOOD: users (id, name, city_id), cities (id, state_id), states (id, name)
```

**Pros:** No redundancy, consistency, smaller storage
**Cons:** More JOINs, slower reads, complex schema

### 8.2 Denormalization

**Kya hai?** Data duplicate karo — fast reads ke liye.

```
    orders (id, user_id, user_name, user_email)
    ↑ user_name, user_email duplicated from users table
```

**Pros:** Fast reads, fewer JOINs
**Cons:** Redundancy, update anomaly

### When to Use

| Normalization | Denormalization |
|---------------|-----------------|
| OLTP (transactions) | OLAP (analytics) |
| Write-heavy | Read-heavy |
| Consistency critical | Speed critical |
| Relational integrity | Reporting, cache |

### 1 Minute Recall Block
> Normalization = no redundancy, more JOINs. Denormalization = duplicate data, fast reads.

---

## 9. When to Use What

### Decision Tree

```
    Complex relations? (users → orders → products)
    │
    ├── YES ──► SQL (PostgreSQL)
    │
    └── NO ──► Scale/ flexibility? 
                │
                ├── Cache/Session ──► Key-Value (Redis)
                ├── Flexible schema ──► Document (MongoDB)
                ├── Time-series/Analytics ──► Column (Cassandra)
                └── Relationships/Graph ──► Graph (Neo4j)
```

### Quick Reference Table

| Need | Database | Why |
|------|----------|-----|
| E-commerce, banking | PostgreSQL, MySQL | ACID, relations |
| Caching | Redis | Fast, key-value |
| User profiles, logs | MongoDB | Flexible schema |
| Analytics, scale | Cassandra | Wide columns, horizontal scale |
| Social, recommendations | Neo4j | Graph traversals |

---

## 10. Interview Questions & Traps

### Database Questions in System Design

**Common pattern:** "Design URL shortener" → "Database schema?" → Tables, indexes. "Design Instagram?" → SQL vs NoSQL for posts, users. "Scale to 1B users?" → Sharding, replication.

**Pro tip:** Start with "We'll use PostgreSQL for X because..." — show you understand trade-offs.

### Top Interview Questions

1. **ACID explain karo with example**
   - Atomicity (bank transfer), Consistency (valid state), Isolation (concurrent), Durability (permanent)

2. **SQL vs NoSQL kab use karein?**
   - SQL: Relations, transactions, complex queries. NoSQL: Scale, flexibility, simple access.

3. **B-Tree vs Hash index?**
   - B-Tree: Range + equality. Hash: Equality only, faster for exact match.

4. **Isolation levels difference?**
   - Read Uncommitted → Serializable. Stricter = fewer anomalies, slower.

5. **Normalization vs Denormalization?**
   - Normalization = no redundancy. Denormalization = fast reads, redundancy OK.

6. **When would you use Graph database?**
   - Relationships matter — social (friends of friends), recommendations (bought this also bought), fraud detection (transaction graph).

7. **Explain WAL (Write Ahead Log)?**
   - Durability ke liye. Write pehle log pe, phir actual data. Crash = replay log = data restore.

### ⚠️ Common Interview Traps

| Trap | Wrong | Right |
|------|-------|-------|
| "NoSQL better than SQL?" | Haan | Depends on use case |
| "Index on every column?" | Faster | Slows writes |
| "ACID in MongoDB?" | Nahi | Document-level ACID (single doc) |
| "3NF always best?" | Haan | Denormalization sometimes better for reads |
| "BASE = no consistency?" | Haan | Eventual consistency hai |

### Quick Recall — Final

```
    Database = Organized storage (Pantry analogy)
    SQL = Tables + ACID + Relations
    NoSQL = Key-Value, Document, Column, Graph
    ACID = Atomicity, Consistency, Isolation, Durability
    BASE = Basically Available, Soft, Eventual
    Index = B-Tree (range), Hash (equality), Composite (order)
    Isolation = Read Uncommitted → Serializable
    Normalization = no redundancy | Denormalization = fast reads
```

### Database Selection Flowchart (Interview Ready)

```
    START: What's your use case?
    │
    ├─ Money/Inventory/Transactions? → SQL (PostgreSQL)
    ├─ Cache/Session? → Redis (Key-Value)
    ├─ Flexible schema/Logs? → MongoDB (Document)
    ├─ Time-series/Analytics at scale? → Cassandra (Column)
    ├─ Social graph/Recommendations? → Neo4j (Graph)
    └─ Need both SQL + scale? → Consider Citus, CockroachDB (distributed SQL)
```

### Final 5 Bullet Memory Hooks
1. **Pantry** = Database, Index = list, Query = "lao"
2. **ACID** = All or nothing, Valid, Independent, Permanent
3. **NoSQL types** = Key, Doc, Column, Graph (KDCC)
4. **B-Tree** = range + equality, Hash = equality only
5. **Normalization** = no dup, Denorm = fast read

### SQL Quick Reference (Interview)

```sql
    -- Common patterns
    SELECT ... FROM t WHERE ...  -- Filter
    JOIN t2 ON t.id = t2.t_id    -- Relations
    GROUP BY col HAVING ...      -- Aggregation
    ORDER BY col LIMIT n         -- Sort, pagination
    CREATE INDEX ON t(col)       -- Index
    BEGIN; ... COMMIT;           -- Transaction
```

### Database Design Checklist
- [ ] Primary key on every table
- [ ] Foreign keys for relations
- [ ] Index on WHERE, JOIN columns
- [ ] Normalize to 3NF (or denormalize if read-heavy)
- [ ] Choose isolation level (default: Read Committed)

---

*End of Database Fundamentals Notes*
