# Clauses and Execution — Common Mistakes

| Mistake | Fix |
|---------|-----|
| `WHERE col = NULL` | `IS NULL` / `IS NOT NULL` |
| Filtering aggregates in `WHERE` | Use `HAVING` or subquery |
| Expecting `SELECT` alias in `WHERE` | Subquery / repeat expression |
| `GROUP BY` wrong grain | Every non-aggregated `SELECT` col must appear in `GROUP BY` (standard SQL) |
| Ignoring **NULL** in `NOT IN` subqueries | Often empty result — use `NOT EXISTS` or handle NULLs |

---

*Next: [[06_Edge-Cases]]*
