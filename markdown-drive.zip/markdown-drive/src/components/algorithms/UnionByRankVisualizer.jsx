import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function layoutLinear(parent) {
  const n = parent.length;
  const nodes = Array.from({ length: n }, (_, i) => ({
    id: String(i),
    label: String(i),
    nx: (i + 0.5) / n * 0.82 + 0.09,
    ny: 0.52,
  }));
  const edges = [];
  for (let i = 0; i < n; i++) if (parent[i] !== i) edges.push([String(i), String(parent[i])]);
  return { nodes, edges };
}

function find(parent, i) {
  while (parent[i] !== i) i = parent[i];
  return i;
}

function generateSteps(n, pairs) {
  const parent = Array.from({ length: n }, (_, i) => i);
  const rank = Array(n).fill(0);
  const steps = [];
  steps.push({ type: 'init', parent: [...parent], rank: [...rank], highlight: [] });
  pairs.forEach(([u, v]) => {
    let ru = find(parent, u);
    let rv = find(parent, v);
    steps.push({ type: 'roots', parent: [...parent], rank: [...rank], ru, rv, u, v, highlight: [ru, rv] });
    if (ru === rv) {
      steps.push({ type: 'same', parent: [...parent], rank: [...rank], highlight: [ru] });
      return;
    }
    if (rank[ru] < rank[rv]) [ru, rv] = [rv, ru];
    parent[rv] = ru;
    if (rank[ru] === rank[rv]) rank[ru]++;
    steps.push({ type: 'union', parent: [...parent], rank: [...rank], ru, rv, highlight: [ru, rv] });
  });
  steps.push({ type: 'done', parent: [...parent], rank: [...rank], highlight: [] });
  return steps;
}

export default function UnionByRankVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const n = 8;
    const pairs = [
      [0, 1],
      [2, 3],
      [1, 3],
      [4, 5],
      [5, 6],
    ];
    const steps = generateSteps(n, pairs);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Union by rank: attach smaller rank root' });
    const { nodes, edges } = layoutLinear(steps[0].parent);
    const labels = Object.fromEntries(steps[0].rank.map((r, i) => [String(i), `r=${r}`]));
    canvasRef.current?.setState({ nodes, edges, colors: {}, labels });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const { nodes, edges } = layoutLinear(step.parent);
    const colors = {};
    (step.highlight || []).forEach((id) => {
      colors[String(id)] = 'compare';
    });
    if (step.type === 'union') {
      colors[String(step.ru)] = 'active';
      colors[String(step.rv)] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: 'Merged by rank rule' });
    } else if (step.type === 'done') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Union by rank complete' });
    } else {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    }
    const labels = Object.fromEntries(step.rank.map((r, i) => [String(i), `r=${r}`]));
    canvasRef.current?.setState({ nodes, edges, colors, labels });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
