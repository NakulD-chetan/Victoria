# Indexes and Optimization — Common Mistakes

| Mistake | Fix |
|---------|-----|
| Indexing every column | Writes slow down; pick high-selectivity WHERE/JOIN cols |
| Function on indexed column | Rewrite as range or create functional index |
| Ignoring composite index order | Leftmost prefix matters |
| Never running EXPLAIN | Always check plan for slow queries |
| Assuming index = always faster | Small tables → seq scan may win |
| Refreshing materialized view rarely | Stale data if not scheduled |

---

*Next: [[06_Edge-Cases]]*
