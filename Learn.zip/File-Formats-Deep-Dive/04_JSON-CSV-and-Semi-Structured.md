# 04 — JSON, CSV & Semi-Structured Data

> JSON and CSV are the most common data **exchange** formats — easy for humans, terrible for analytics at scale. Knowing their internals, pitfalls, and when to convert is a must for any Data Engineering interview.

---

## 1. CSV (Comma-Separated Values)

### Definition

CSV is a **row-based, plain-text** format where each line represents a record and fields within a record are separated by a delimiter (typically a comma).

- **No formal standard** — RFC 4180 exists but is loosely followed. Every tool parses CSV slightly differently.
- **Schema is external** — the first row may act as a header, but there is no embedded schema.
- **No data types** — everything is a string; the reader must decide how to interpret values.
- **No compression built-in** — you apply gzip, snappy, etc. externally.

```
id,name,age,city
1,Alice,30,Mumbai
2,"Bob, Jr.",25,Pune
3,Carol,35,"New Delhi"
```

### Why CSV Is Called "Dangerous"

CSV looks simple but hides many ambiguities that cause **silent data corruption** in production pipelines.

| Pitfall | What Happens | Example |
|---------|-------------|---------|
| **Delimiter inside data** | A comma inside a field breaks column alignment | `"Bob, Jr."` — must be quoted, but quoting rules vary |
| **Newline inside data** | A field contains `\n`, parser treats it as a new row | Multi-line address fields |
| **No type information** | Reader cannot distinguish `"30"` as string vs integer | Schema inference guesses — and often guesses wrong |
| **Null ambiguity** | No standard null representation | Empty string `""`, literal `NULL`, `\N`, or truly missing — all look different |
| **Encoding hell** | UTF-8 vs Latin-1 vs Windows-1252 | Non-ASCII characters corrupt silently; BOM may or may not be present |
| **Header mismatch** | File has 10 fields but header has 9 | Corrupt row or unquoted delimiter |
| **Schema evolution** | New column added mid-stream | Breaks positional parsing for downstream consumers |
| **Not splittable when gzipped** | A gzipped CSV cannot be split across Spark tasks | Single task reads entire file → no parallelism |

**Deep concept — Splittability:**
Splittability means whether a distributed engine like Spark can break a file into independent chunks and read them in parallel. Uncompressed CSV is splittable (newline = record boundary). But gzip wraps the entire file in one stream, so only **one task** can read it. Solutions: use bzip2 (splittable), or better — convert to Parquet.

### CSV in Spark

```python
# BAD — inferSchema reads the ENTIRE file twice (once for schema, once for data)
df = spark.read.csv("data/orders.csv", header=True, inferSchema=True)

# GOOD — define schema explicitly (fast, reliable, no surprises)
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

schema = StructType([
    StructField("id", IntegerType()),
    StructField("name", StringType()),
    StructField("age", IntegerType()),
    StructField("city", StringType())
])
df = spark.read.csv("data/orders.csv", header=True, schema=schema)
```

**Why `inferSchema=True` is bad in production:**
1. Spark makes a **full pass** over the file just to guess types → doubles read time.
2. Type guessing is unreliable — a column with `"100", "200", "N/A"` gets inferred as string, not integer-with-bad-rows.
3. Schema can change between runs if data distribution changes → breaks downstream.

**Key options to know:**

| Option | Purpose |
|--------|---------|
| `header=True` | First row is column names |
| `sep="\|"` | Custom delimiter (pipe, tab `\t`, etc.) |
| `quote='"'` | Character used for quoting |
| `escape="\\"` | Escape character inside quoted fields |
| `nullValue="NULL"` | What string represents null |
| `multiLine=True` | Allow fields that span multiple lines (slower, not splittable) |
| `encoding="UTF-8"` | Explicitly set character encoding |
| `dateFormat` / `timestampFormat` | Custom date/timestamp parsing pattern |
| `maxColumns` | Max number of columns allowed (default 20480) |
| `columnNameOfCorruptRecord` | Column name to store malformed rows (used with PERMISSIVE mode) |

### CSV Read Modes — PERMISSIVE, DROPMALFORMED, FAILFAST

This is a frequently asked small detail in interviews. Spark has three modes for handling malformed/corrupt rows when reading CSV (and JSON):

| Mode | Behavior | When to Use |
|------|----------|-------------|
| **PERMISSIVE** (default) | Puts malformed rows as `null` values in all columns. If `columnNameOfCorruptRecord` is set, stores the raw malformed row in that column | Development, debugging — see what went wrong without crashing |
| **DROPMALFORMED** | Silently drops any row that doesn't parse correctly — no error, no log | When bad rows are expected and acceptable to lose (e.g., noisy log data) |
| **FAILFAST** | Throws an exception immediately on the first malformed row — job fails | Production pipelines where data quality matters — fail loud, fix the source |

```python
# PERMISSIVE (default) — bad rows become nulls, optionally captured
df = spark.read.csv("data.csv", header=True, schema=schema,
                     mode="PERMISSIVE",
                     columnNameOfCorruptRecord="_corrupt_record")

# DROPMALFORMED — silently skip bad rows
df = spark.read.csv("data.csv", header=True, schema=schema,
                     mode="DROPMALFORMED")

# FAILFAST — crash on first bad row (recommended for production)
df = spark.read.csv("data.csv", header=True, schema=schema,
                     mode="FAILFAST")
```

**Interview tip:** "In production, I use `FAILFAST` mode so the pipeline fails immediately on corrupt data instead of silently producing wrong results. In development, I use `PERMISSIVE` with `columnNameOfCorruptRecord` to inspect what went wrong."

---

## 2. JSON (JavaScript Object Notation)

### Definition

JSON is a **self-describing, text-based** format that stores data as key-value pairs with support for nested objects and arrays.

- **Self-describing** — field names are embedded in every record.
- **Supports nesting** — objects inside objects, arrays of objects, arbitrary depth.
- **Flexible schema** — each record can have different fields (schema-on-read).
- **Universal** — every language, API, and tool supports JSON.

### JSON vs JSONL — This Distinction Matters

| Variant | Structure | Example |
|---------|-----------|---------|
| **JSON** | Entire file is one object or one array | `[{"id":1}, {"id":2}]` |
| **JSONL (JSON Lines)** | One complete JSON object per line | `{"id":1}\n{"id":2}` |
| **NDJSON** | Same as JSONL (Newline Delimited JSON) | Same |

**Why JSONL is preferred in Data Engineering:**
- **Splittable** — each line is independent → Spark can parallelize across lines.
- **Appendable** — just append a new line; no need to parse and rewrite the whole file.
- **Streamable** — can process line-by-line with bounded memory.
- Standard JSON arrays require loading the entire file to parse → not splittable, not streamable.

### Why JSON Is Bad for Analytics

| Problem | Why It Matters |
|---------|---------------|
| **Field names repeated in every record** | `"user_id"` stored millions of times → 2–5x storage overhead vs binary formats |
| **Text encoding of values** | Number `30` stored as 2 ASCII bytes `"30"` instead of 4-byte int32; dates as strings instead of epoch integers |
| **No column pruning** | To read one field, you must parse the entire record — every key, every value |
| **No predicate pushdown** | Cannot skip records without reading and parsing them first |
| **No built-in compression** | Raw text; must apply external compression |
| **Expensive schema inference** | Spark scans the full file to union all record shapes into one schema |

**Deep concept — Column Pruning and Predicate Pushdown:**
In Parquet, if your query only needs 3 out of 100 columns, the engine reads **only those 3 column chunks** from disk. If you have a filter `WHERE age > 30`, Parquet's min/max statistics let the engine **skip entire row groups** without reading them. JSON supports neither — every query reads every byte of every record.

### Storage Comparison (same 1M records)

```
CSV:        ~50 MB
JSON:       ~120 MB    ← field names repeated, text encoding
Avro:       ~25 MB     ← binary, schema stored once
Parquet:    ~15 MB     ← columnar, compressed, column pruning
```

JSON is **~8x larger** than Parquet for the same data.

### JSON in Spark — Read Options and Modes

JSON also supports the same three read modes as CSV:

| Mode | Behavior |
|------|----------|
| **PERMISSIVE** (default) | Puts corrupt records as nulls or into `columnNameOfCorruptRecord` |
| **DROPMALFORMED** | Silently drops unparseable JSON records |
| **FAILFAST** | Throws exception on first malformed JSON record |

```python
# FAILFAST — recommended for production
df = spark.read.json("data/events.jsonl", mode="FAILFAST")

# With explicit schema (avoids full-file scan for schema inference)
df = spark.read.schema(explicit_schema).json("data/events.jsonl")

# multiLine=True — for standard JSON files (single array), NOT JSONL
df = spark.read.json("data/events.json", multiLine=True)
```

**Other important JSON read options:**

| Option | Purpose |
|--------|---------|
| `multiLine=True` | Read standard JSON (single array/object, not line-delimited). Slower, not splittable |
| `primitivesAsString=True` | Read all primitive values as strings — avoids type inference issues |
| `allowComments=True` | Allow `//` and `/* */` comments in JSON (non-standard but common in configs) |
| `allowUnquotedFieldNames=True` | Allow `{name: "Alice"}` without quoting field names |
| `allowSingleQuotes=True` | Allow `{'name': 'Alice'}` — common in Python-generated JSON |
| `samplingRatio=0.1` | Sample 10% of file for schema inference (faster but less accurate) |
| `dropFieldIfAllNull=True` | Don't include fields that are null in every record |

### JSON in Spark — Handling Nested Data

```python
df = spark.read.json("data/events.jsonl")

# Access nested struct fields with dot notation
from pyspark.sql.functions import col

df_flat = df.select(
    col("id"),
    col("name"),
    col("address.city").alias("city"),
    col("address.state").alias("state")
)

# Explode arrays into rows (1 array element → 1 row)
from pyspark.sql.functions import explode

df_exploded = df.select(
    col("id"),
    explode(col("tags")).alias("tag")
)

# Parse a JSON string column into a struct
from pyspark.sql.functions import from_json
from pyspark.sql.types import StructType, StructField, StringType

address_schema = StructType([
    StructField("city", StringType()),
    StructField("state", StringType())
])
df_parsed = df.withColumn("address_struct", from_json(col("address_raw"), address_schema))
```

**Key Spark JSON functions:**

| Function | What It Does | When to Use |
|----------|-------------|-------------|
| `from_json(col, schema)` | Parse a JSON string column into a typed struct | When JSON arrives as a string column (e.g., Kafka value) |
| `to_json(col)` | Convert a struct back to JSON string | Producing JSON output |
| `get_json_object(col, "$.path")` | Extract a single value using JSONPath | Quick extraction without defining full schema |
| `json_tuple(col, "key1", "key2")` | Extract multiple keys at once | More efficient than multiple `get_json_object` calls |
| `explode(col)` | Flatten an array column into rows | One-to-many expansion |
| `explode_outer(col)` | Same as explode but keeps nulls | When arrays can be null/empty and you don't want to lose rows |
| `schema_of_json(sample)` | Infer schema from a sample JSON string | Quick schema discovery during development |

---

## 3. Semi-Structured Data Handling in Pipelines

### What Is Semi-Structured Data

Data that has some structure (keys, nesting, types) but **does not conform to a rigid relational schema**. Each record may have different fields, nested objects, or variable-length arrays.

Examples: JSON from APIs, XML feeds, log files with mixed formats, IoT sensor payloads with optional fields.

### The Medallion / Landing Zone Pattern

This is the standard approach for handling semi-structured data in a data lake:

```
Source (API, Kafka, Files)
    │
    ▼
┌─────────────────────────────────────────────────┐
│  Landing / Bronze — Store raw JSON/CSV as-is    │
│  (Purpose: preserve original data for replay)   │
│  Format: raw JSON files or string column        │
└───────────────────┬─────────────────────────────┘
                    │  Flatten, type-cast, validate, deduplicate
                    ▼
┌─────────────────────────────────────────────────┐
│  Silver — Cleaned, typed, structured            │
│  Format: Parquet / Delta Lake                   │
│  (Purpose: reliable, fast, schema-enforced)     │
└───────────────────┬─────────────────────────────┘
                    │  Aggregate, join, business logic
                    ▼
┌─────────────────────────────────────────────────┐
│  Gold — Business-level aggregates & metrics     │
│  Format: Parquet / Delta Lake                   │
│  (Purpose: query-ready for BI and reporting)    │
└─────────────────────────────────────────────────┘
```

**Why this pattern matters:**
- **Bronze preserves raw data** — if parsing logic changes, you can replay from raw.
- **Silver enforces schema** — downstream consumers get reliable types and structure.
- **Conversion from JSON/CSV to Parquet happens at Bronze → Silver** — this is where you get the 10–100x performance gain.

### Snowflake VARIANT Type (Interview-Relevant)

Snowflake has a native `VARIANT` type that stores semi-structured data internally as a compressed binary format, not raw text.

```sql
CREATE TABLE raw_events (
    event_data VARIANT,
    loaded_at  TIMESTAMP
);

-- Query nested fields using colon notation + casting
SELECT
    event_data:user_id::INT       AS user_id,
    event_data:action::STRING     AS action,
    event_data:metadata:device::STRING AS device
FROM raw_events;
```

**Why interviewers ask about VARIANT:**
- Snowflake automatically extracts column statistics from VARIANT data → enables **pruning at the micro-partition level** even on semi-structured data.
- Unlike storing JSON as a raw string column, VARIANT is stored in a **columnar, compressed** internal format.
- This bridges the gap between "flexible schema" and "analytical performance."

### Databricks / Delta Lake Approach

```python
# Ingest raw JSON into Bronze as a string column
bronze_df = spark.read.text("s3://landing/events/")
bronze_df.write.format("delta").saveAsTable("bronze.raw_events")

# Parse and flatten at Silver
from pyspark.sql.functions import from_json, col

event_schema = spark.read.json("s3://landing/events/sample.jsonl").schema

silver_df = (
    spark.read.table("bronze.raw_events")
    .withColumn("parsed", from_json(col("value"), event_schema))
    .select("parsed.*")
)
silver_df.write.format("delta").mode("overwrite").saveAsTable("silver.events")
```

---

## 4. Deep Concepts for Data Engineering Interviews

### Schema-on-Read vs Schema-on-Write

| Approach | Definition | Formats | Trade-off |
|----------|-----------|---------|-----------|
| **Schema-on-Write** | Schema enforced at write time; data that doesn't match is rejected | Parquet, Avro, RDBMS tables | Strict, reliable, but rigid |
| **Schema-on-Read** | No schema enforced at write; reader interprets structure at query time | JSON, CSV, raw text | Flexible, but errors surface late (at query time) |

**Interview answer:** "JSON and CSV are schema-on-read. We store them raw in Bronze, then apply schema-on-write at Silver by converting to Parquet/Delta with explicit schemas. This gives us flexibility at ingestion and reliability at consumption."

### Schema Evolution with Semi-Structured Data

| Scenario | What Happens | How to Handle |
|----------|-------------|---------------|
| New field added by source | Old records don't have it | Use `nullable=True`, fill with null or default |
| Field removed by source | New records don't have it | Silver schema still expects it → null fill |
| Field type changes (int → string) | Schema mismatch | Cast at Silver, or version the schema |
| Nested structure changes | Deeply nested field moves or renames | Flatten at Bronze → Silver with explicit mapping |

**Deep concept — Schema Merging in Spark:**

```python
# Spark can merge schemas across multiple JSON/Parquet files
df = spark.read.option("mergeSchema", "true").json("data/events/")
```

When different files have different fields, `mergeSchema` unions all fields into one schema. This is useful but expensive — it scans all files. In production, prefer registering schemas explicitly.

### Small File Problem with JSON/CSV

When JSON/CSV files arrive from APIs or streaming, you often get **thousands of tiny files** (1 KB – 1 MB each). This kills performance because:

1. **Each file = 1 Spark task** → overhead of task scheduling dominates actual work.
2. **NameNode pressure** in HDFS — metadata for millions of small files exhausts memory.
3. **No predicate pushdown** — each file is fully read regardless of filters.

**Solution:** Compact small files into larger Parquet files at the Bronze → Silver boundary. Target 128 MB – 1 GB per file. Use `coalesce()` or `repartition()` in Spark, or Delta Lake's `OPTIMIZE` command.

---

## 5. Format Comparison — When to Use What

| Format | Best For | Avoid For | Key Property |
|--------|----------|-----------|-------------|
| **CSV** | Human exchange, Excel export, simple configs, one-time loads | Analytics at scale, complex/nested data | Simplest, most ambiguous |
| **JSON** | API responses, configs, landing zone, small datasets | Large-scale analytics, columnar queries | Self-describing, flexible, verbose |
| **JSONL** | Log ingestion, streaming landing, data exchange | Long-term analytical storage | Splittable, appendable, streamable |
| **Parquet** | Analytical storage, data lake, Spark/Presto/Hive queries | Streaming wire format, human editing | Columnar, compressed, prunable |
| **Avro** | Kafka messages, CDC streams, schema evolution | Ad-hoc analytical queries | Row-based binary, schema in header |
| **Delta/Iceberg** | Mutable data lake, ACID transactions, time travel | Simple one-off file exchange | Table format over Parquet with metadata |

---

## 6. Interview Questions & How to Answer

**Q: "Why not store data in JSON/CSV in a data lake?"**
> JSON/CSV lack column pruning, predicate pushdown, and built-in compression. A query that needs 3 columns out of 100 still reads every byte. Parquet solves all three — column pruning skips unneeded columns, row-group statistics skip irrelevant data, and encoding + compression shrink storage 5–10x.

**Q: "How do you handle nested JSON in Spark?"**
> Structs — use dot notation: `col("address.city")`. Arrays — use `explode()` to flatten into rows. JSON strings — use `from_json()` with an explicit schema to parse into a struct. For deeply nested data, flatten at the Silver layer and store as flat Parquet.

**Q: "CSV vs Parquet — what's the performance difference?"**
> Parquet is 10–100x faster for analytical queries. Three reasons: (1) column pruning — reads only needed columns, (2) predicate pushdown — skips row groups using statistics, (3) efficient encoding and compression — dictionary, RLE, and snappy reduce I/O dramatically.

**Q: "Why define schema explicitly for CSV in Spark?"**
> `inferSchema=True` makes Spark read the entire file twice — once to guess types, once to load data. It also guesses wrong when data has mixed types. Explicit schema is a single-pass read with guaranteed types.

**Q: "What is JSONL and why is it preferred over JSON arrays?"**
> JSONL stores one JSON object per line. It's splittable — Spark can assign different line ranges to different tasks for parallel processing. A JSON array file must be loaded entirely by one task because you can't split mid-array. JSONL is also appendable (just add a line) and streamable (bounded memory).

**Q: "How do you handle schema evolution in JSON pipelines?"**
> Store raw JSON in Bronze to preserve original data. At Silver, apply an explicit schema with nullable fields. When the source adds new fields, update the Silver schema and backfill with nulls. When fields are removed, the Silver schema still expects them — fill with nulls. Use Delta Lake's `mergeSchema` option to evolve Parquet schemas over time.

**Q: "What is Snowflake's VARIANT type?"**
> VARIANT stores semi-structured data in a compressed, columnar binary format internally — not as raw JSON text. Snowflake extracts column statistics from VARIANT data, enabling partition pruning even on flexible-schema data. You query it with colon notation and explicit casting.

---

## Key Takeaways

1. **CSV** — simple but dangerous. No types, no nulls standard, delimiter/encoding traps. Never for analytics at scale.
2. **JSON** — self-describing and flexible, but ~8x larger than Parquet. No column pruning, no pushdown.
3. **JSONL > JSON arrays** — splittable, appendable, streamable. Always prefer for data pipelines.
4. **Always convert JSON/CSV to Parquet** at the Bronze → Silver boundary. This is where you get 10–100x performance.
5. **Never use `inferSchema=True`** in production Spark. Define schemas explicitly — single pass, reliable types.
6. **Schema-on-read at Bronze, schema-on-write at Silver** — flexibility at ingestion, reliability at consumption.
7. **Compact small files** — thousands of tiny JSON/CSV files kill performance. Merge into large Parquet files.

---
