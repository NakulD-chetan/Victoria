import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [];
  function qs(lo, hi) {
    if (lo >= hi) return;
    const pivotVal = a[hi];
    steps.push({ type: 'pivot', idx: hi, lo, hi, array: [...a] });
    let i = lo - 1;
    for (let j = lo; j < hi; j++) {
      steps.push({ type: 'compare', i: i + 1, j, pivot: hi, lo, hi, array: [...a] });
      if (a[j] < pivotVal) {
        i++;
        [a[i], a[j]] = [a[j], a[i]];
        steps.push({ type: 'swap', i, j, pivot: hi, array: [...a] });
      }
    }
    [a[i + 1], a[hi]] = [a[hi], a[i + 1]];
    steps.push({ type: 'pivot-placed', idx: i + 1, array: [...a] });
    qs(lo, i);
    qs(i + 2, hi);
  }
  qs(0, a.length - 1);
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 16) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function QuickSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'pivot') {
      colors[step.idx] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Pivot=${step.array[step.idx]} at [${step.idx}]` });
    } else if (step.type === 'compare') {
      colors[step.pivot] = 'pivot'; colors[step.j] = 'compare';
      store.incComparisons();
    } else if (step.type === 'swap') {
      colors[step.i] = 'swap'; colors[step.j] = 'swap';
      store.incSwaps();
      canvasRef.current?.addAnim('swap', { i: step.i, j: step.j }, 300);
    } else if (step.type === 'pivot-placed') {
      colors[step.idx] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Pivot placed at [${step.idx}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
