# DStream vs Structured Streaming

Spark supports two streaming APIs. **DStream** is the old one (deprecated). **Structured Streaming** is the modern one you should use.

---

## DStream (Spark Streaming) — The Legacy API

**Introduced in**: Spark 0.7

DStream (Discretized Stream) treats streaming data as a series of **micro-batches of RDDs**.

### How It Works
```
Incoming data stream
    |
    v
[Micro-batch 1] → RDD → transformations → output
[Micro-batch 2] → RDD → transformations → output
[Micro-batch 3] → RDD → transformations → output
```

Every few seconds (batch interval), Spark collects incoming data into an RDD and processes it.

### Characteristics
- Built on **RDD API** (low-level, verbose)
- **No Catalyst optimization** — you manage everything manually
- Limited event-time processing
- Basic checkpointing (offsets + RDD lineage)
- Manual state management
- Exactly-once semantics only for certain sinks (like Kafka)

---

## Structured Streaming — The Modern API

**Introduced in**: Spark 2.0

Structured Streaming treats streaming data as an **unbounded table** that keeps growing. You write code exactly like batch DataFrame operations.

### How It Works
```
Incoming data = rows being added to an infinite table

    |  Input Table (grows forever)  |
    |  row1, row2, row3, ...        |
    |  row4, row5, row6, ...        |
              |
              v
    [DataFrame/SQL operations]
              |
              v
    |  Result Table (updated)  |
```

### Characteristics
- Built on **DataFrame/Dataset API** (high-level, easy)
- **Catalyst + Tungsten optimized** — same optimizations as batch
- Full **event-time processing** (watermarks, windowing, late data handling)
- Built-in stateful operations (`mapGroupsWithState`, aggregations)
- Strong exactly-once guarantees with checkpointing
- Three output modes: Append, Update, Complete

---

## Key Differences

| Feature               | DStream (Legacy)              | Structured Streaming (Modern)         |
|-----------------------|-------------------------------|---------------------------------------|
| API                   | RDD-based (low-level)         | DataFrame/Dataset (high-level)        |
| Optimization          | None                          | Catalyst + Tungsten + Codegen         |
| Event-Time Processing | Limited                       | Full (watermarks, windows, late data) |
| State Management      | Manual                        | Built-in (aggregations, mapGroups)    |
| Exactly-Once          | Only certain sinks             | Built-in for most sinks              |
| Fault Tolerance       | RDD lineage + offsets          | Source offsets + state + metadata     |
| Output Modes          | Write each micro-batch         | Append, Update, Complete             |
| Ease of Use           | Verbose, complex               | Declarative, SQL-friendly            |

---

## Output Modes (Structured Streaming)

| Mode     | What It Writes                                      | Use Case                       |
|----------|------------------------------------------------------|--------------------------------|
| Append   | Only new rows (never updates old ones)               | Simple ETL, logs               |
| Update   | Only rows that changed since last trigger            | Real-time dashboards           |
| Complete | Entire result table every time                       | Running aggregations           |

---

## Example: Structured Streaming

```python
# Read from Kafka
df = spark.readStream \
    .format("kafka") \
    .option("kafka.bootstrap.servers", "localhost:9092") \
    .option("subscribe", "events") \
    .load()

# Process like a normal DataFrame
parsed = df.selectExpr("CAST(value AS STRING)", "timestamp")
counts = parsed.groupBy(
    window(col("timestamp"), "5 minutes"),
    col("value")
).count()

# Write to console
query = counts.writeStream \
    .outputMode("update") \
    .format("console") \
    .start()
```

---

## Key Takeaway

> **DStream** is deprecated — it's RDD-based, no optimization, limited event-time support.
> **Structured Streaming** is the standard — it uses DataFrame API, gets Catalyst + Tungsten optimization, and has built-in support for event-time, watermarks, and exactly-once processing.
> Always use Structured Streaming for new projects.
