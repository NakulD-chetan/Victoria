# Design Google Docs — Edge Cases

> **Permanent Recall:** Edge cases: **100 users editing same paragraph**, **offline user reconnects with conflicting changes**, **document corruption recovery**, **very large documents (100K+ words)**, **slow network causing operation reordering**, **permission change while editing**.

---

## Edge Cases and Solutions

| Edge Case | Problem | Solution |
|-----------|---------|----------|
| **100 users editing same paragraph** | Hotspot; many ops/sec; server overload | Throttle ops; batch transforms; consider CRDT for P2P load distribution; horizontal scale by doc |
| **Offline user reconnects** | Queued ops conflict with server state | Send queue to server; transform each against server ops; apply transformed; client reconciles |
| **Document corruption** | Bug or crash → inconsistent state | Replay from last known good snapshot + log; checksums; integrity checks |
| **Very large docs (100K+ words)** | Load time; ops on huge buffer | Lazy load; load visible region first; chunked document model; incremental sync |
| **Slow network / op reordering** | Ops arrive out of order | Server assigns sequence numbers; clients send ops with "after seq N"; server buffers, transforms in order |
| **Permission change mid-edit** | User loses edit access while typing | Server rejects new ops; client shows "view only" message; graceful degradation |

---

## 100 Users Editing Same Paragraph

```
Problem: Popular doc; 100 cursors in same paragraph
         → 100s of ops/sec to one document
         → Single Collaboration Service instance overwhelmed

Solutions:
• Throttle: Client batches ops (e.g., every 100ms) instead of every keystroke
• Server: Batch transform — collect ops for 50ms, transform together, broadcast once
• Shard by document: Each doc has its own session; scale Collaboration Service horizontally
• Consider CRDT: Distribute merge; no single server bottleneck (but more complex)
```

> **FAANG Tip:** For "1000 concurrent editors," emphasize batching, throttling, and horizontal scaling by document.

---

## Offline User Reconnects

```
Scenario: User A goes offline. Makes 10 edits. User B (online) makes 20 edits.
          A reconnects with 10 queued ops. Server state has B's 20 ops.

Flow:
1. A sends "I have ops after seq 42" (last seq A saw)
2. Server: "Ops 43-62 happened (B's). Here they are."
3. A receives 43-62, applies to local state (may need to transform A's pending against these)
4. A sends 10 queued ops
5. Server transforms each of A's 10 against 43-62 and any other pending
6. Server applies, broadcasts to all (including A)
7. A applies transformed ops; discards old local queue
8. All clients converge
```

- **OT:** Server does all transforms; client cannot merge offline ops alone
- **CRDT:** Client can merge locally; sync brings in remote ops; merge commutative

---

## Document Corruption Recovery

| Cause | Mitigation |
|-------|------------|
| **Bug in transform** | Comprehensive tests; fuzz testing; rollback to last good |
| **Crash mid-write** | WAL; snapshot + log atomic; replay log on restart |
| **Storage corruption** | Replicas; checksums; checksum validation on read |
| **Client sends malformed op** | Validate op schema; reject invalid; rate limit abuse |

```
Recovery: Last known good snapshot + replay operation log to that point
          If log corrupted: restore from backup; may lose recent ops
```

---

## Very Large Documents (100K+ words)

```
Problem: Loading 100K words = slow; applying 1000s of ops = slow

Solutions:
• Chunked model: Doc = list of chunks; load visible chunks + adjacent
• Virtualization: Render only visible portion; lazy load rest
• Incremental sync: Send only ops for visible region? (Complex for OT)
• Snapshot granularity: Store doc as chunk tree; load root + requested chunks
• Pagination: Treat as multi-page; load page by page (simplifies but changes UX)
```

---

## Slow Network / Operation Reordering

```
Problem: A sends op1, op2. Network delay. B's op3 arrives at server first.
         Server applies op3. Then op1, op2. Order wrong → wrong document.

Solution:
• Client sends ops with "based on seq N" (vector clock or seq number)
• Server maintains total order per document
• Server buffers op1, op2 if op3 arrives first; applies in causal order
• Or: server assigns seq on receipt; clients ack; out-of-order buffered
• Transform always against prior applied ops
```

---

## Permission Change While Editing

```
Scenario: User has edit access. Owner revokes. User is mid-sentence.

• Server: On next op from user, check permission → reject
• Client: Receive "403 Forbidden" or "permission_denied" event
• Client: Switch to read-only mode; show banner "You no longer have edit access"
• Pending unsent ops: Discard or offer "copy to new doc"?
• Presence: Remove user from editor list; keep as viewer cursor if allowed
```

---

## Cursor Storm (Presence)

```
Problem: 100 users; each sends cursor pos every 50ms = 2000 msgs/sec

• Throttle: Send presence every 200–500ms, not every mousemove
• Batch: Server batches presence updates; broadcast every 100ms
• Limit: Only send cursors for users in same "region" or same block?
• Separate channel: Presence on different topic/connection to avoid blocking ops
```

---

## Version History Explosion

```
Problem: Doc edited for years; operation log huge; replay slow

• Periodic snapshots: Every N ops or N hours; truncate log before snapshot
• Retention: Keep last 30 days full; older = snapshot only (no replay)
• Compression: Delta-compress operation log
• Limit versions: "Last 100 versions" for UI; rest in cold storage
```
