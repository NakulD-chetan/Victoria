# Database Scaling — Database Ko Bada Kaise Karo

> **Database scale karna sabse mushkil hai — kyunki data consistent rakhna padta hai**
> Reads ke liye Replicas, Writes ke liye Sharding — bas yeh formula yaad rakho!

---

## Table of Contents
1. [Database Scaling Kyu Hardest Hai?](#1-database-scaling-kyu-hardest-hai)
2. [Replication](#2-replication)
3. [Sharding in Depth](#3-sharding-in-depth)
4. [Consistent Hashing](#4-consistent-hashing)
5. [Connection Pooling](#5-connection-pooling)
6. [Read vs Write Scaling](#6-read-vs-write-scaling)
7. [Database per Service](#7-database-per-service)
8. [Interview Questions & Traps](#8-interview-questions--traps)

---

## 1. Database Scaling Kyu Hardest Hai?

### Core Concept
**Database = system ka single point** — Stateless servers scale karna easy (add more), but database mein **state** hai. Data consistent, durable, aur fast — teeno chahiye!

### Real World Analogy: Bank
- **Stateless** = Customer care (koi bhi agent utha le)
- **Stateful** = Bank vault (sab paisa ek jagah, move karna mushkil, security critical)

### Why Hard?

```
    ┌─────────────────────────────────────────────────────┐
    │           DATABASE SCALING CHALLENGES                 │
    │                                                        │
    │  1. Consistency  → Sab nodes same data?               │
    │  2. Durability   → Crash pe data safe?                │
    │  3. Transactions → Cross-node ACID?                   │
    │  4. Joins        → Data alag shards pe?               │
    │  5. Single point → Master fail = downtime?           │
    └─────────────────────────────────────────────────────┘
```

### Scaling Strategies Overview

```
    Vertical Scaling (Scale Up)     Horizontal Scaling (Scale Out)
    ┌─────────────────────┐        ┌─────────────────────┐
    │  Bigger Machine     │        │  More Machines      │
    │  More RAM, CPU      │        │  Replication        │
    │  Limit: Hardware    │        │  Sharding            │
    └─────────────────────┘        └─────────────────────┘
```

### 1 Minute Recall Block
> Database scaling hard = state + consistency + durability. Vertical = bigger box. Horizontal = more boxes (replication + sharding).

### 5 Bullet Memory Hooks
- Database = stateful, scaling tough
- Reads = Replication (more replicas)
- Writes = Sharding (split data)
- Vertical = limit hai (hardware)
- Horizontal = infinite (theoretically)

---

## 2. Replication

### 2.1 Master-Slave (Primary-Replica)

#### Core Concept
**Ek master, multiple slaves** — Master pe write, slaves pe copy. Reads slaves se, writes master pe. Single point of write = consistency easy.

#### How It Works

```
    WRITES                          READS
    ┌──────┐                        ┌──────┐
    │Client│───► Master ──► Replica1│◄─────│ Client
    └──────┘    (Primary)   Replica2│◄─────│ Client
                    │       Replica3│◄─────│ Client
                    │               └──────┘
                    └──► Async/Sync replication
```

#### Failover Scenario
```
    Master fails → Promote one Replica to Master
    Need: Automatic failover (Patroni, etcd) or manual
    Risk: Replication lag = some data loss possible (if async)
```

#### Real World Example
**News website:** Write = 1 article/day. Read = lakhs users. Master 1, Replicas 10 — reads distribute. **E-commerce:** Product catalog read-heavy — replicas serve product pages.

#### Sync vs Async Replication

| Type | How | Pros | Cons |
|------|-----|------|------|
| **Sync** | Slave confirm kare tabhi commit | Strong consistency | Slow writes, slave down = block |
| **Async** | Master commit, slave ko bhej | Fast writes | Replication lag, possible data loss |

```
    SYNC:  Master ──write──► Slave (ack) ──► Master commits
    ASYNC: Master ──write──► Master commits ──► Slave (eventually)
```

### 2.2 Multi-Master Replication

#### Core Concept
**Multiple masters** — Koi bhi node pe write, conflict resolution needed.

#### How It Works

```
    Master A ◄──────► Master B ◄──────► Master C
         │                 │                 │
    Write from            Write from        Write from
    Region 1              Region 2          Region 3
    
    Conflict: Same key, different values? → Resolution needed
```

#### Use Case
Multi-region — US user US master, India user India master. Low latency.

#### Problem: Conflict Resolution
- Last-write-wins (timestamp)
- Vector clocks
- Manual merge

### 2.3 Replication Lag + Solutions

#### Problem

```
    Master:  balance = 100 (updated)
    Replica: balance = 50  (lagging, not synced yet)
    
    User reads from Replica → Stale data!
```

#### Lag Causes
- **Async replication:** Master commits, sends to replica later
- **Network:** Slow link between master-replica
- **Replica load:** Replica busy processing, falls behind
- **Large transactions:** Big write = long sync time

#### Solutions

| Solution | How | Trade-off |
|----------|-----|-----------|
| **Read from Master** | Critical reads → master | Master load |
| **Synchronous replica** | Wait for sync | Slow writes |
| **Read-your-writes** | Session → same replica | Complex routing |
| **Monotonic reads** | Same replica for user | Routing logic |
| **Accept lag** | Non-critical data | Simplicity |

### 1 Minute Recall Block
> Master-Slave = 1 write, many read. Sync = consistent but slow. Async = fast but lag. Multi-master = conflict resolution.

### ⚠️ Common Interview Trap
**Trap:** "Replication solves write scaling?" — **No!** Replication = read scaling. Writes still go to master(s). Write scaling = Sharding.

---

## 3. Sharding in Depth

### 3.1 Horizontal vs Vertical Sharding

#### Vertical Sharding
**Tables alag servers pe** — users table Server A, orders Server B.

```
    Before:  One DB (users + orders + products)
    After:   DB1 (users), DB2 (orders), DB3 (products)
```

**Problem:** Joins across DBs = slow/impossible.

#### Horizontal Sharding
**Rows alag servers pe** — Same table, different rows different shards.

```
    users table:
    Shard 1: user_id 1-1000000
    Shard 2: user_id 1000001-2000000
    Shard 3: user_id 2000001-3000000
```

### 3.2 Shard Key Selection

#### Good Shard Key
- **High cardinality** (unique values — user_id)
- **Even distribution** (no hot shard)
- **Query pattern** (most queries use shard key)

#### Bad Shard Key
- **Low cardinality** (gender — 2 values = 2 shards max)
- **Skewed** (country = India = 80% data on 1 shard)
- **Not in queries** (shard key = created_at, query = user_id → cross-shard!)

### 3.3 Hash-Based Sharding

#### How It Works

```
    shard_id = hash(user_id) % num_shards
    
    user_id=1001 → hash=789 → 789 % 4 = 1 → Shard 1
    user_id=1002 → hash=234 → 234 % 4 = 2 → Shard 2
```

**Pros:** Even distribution, no hot shard
**Cons:** Range queries impossible (user_id 1-100 = different shards). Resharding = problem (mod changes)

**Use case:** User ID, order ID — random access, no range needed.

### 3.4 Range-Based Sharding

#### How It Works

```
    Shard 1: user_id 1 - 1,000,000
    Shard 2: user_id 1,000,001 - 2,000,000
    Shard 3: user_id 2,000,001 - 3,000,000
```

**Pros:** Range queries easy
**Cons:** Hot shard (new users = last shard overloaded)

### 3.5 Directory-Based Sharding

#### How It Works

```
    Lookup Table: user_id → shard_id
    1001 → Shard 2
    1002 → Shard 1
    1003 → Shard 3
    
    Flexible — move data without changing hash
```

**Cons:** Lookup = extra hop, lookup table = bottleneck

### 3.6 Cross-Shard Queries Problem

```
    Query: "All orders by users from Mumbai"
    
    users: Shard 1, 2, 3 (by user_id)
    orders: Shard 4, 5, 6 (by order_id)
    
    → Need to query ALL shards, merge results = SLOW!
```

**Solution:** Co-locate (users + their orders same shard) — shard by user_id for both.

### 3.7 Resharding (Adding New Shards)

#### Problem
```
    4 shards → 8 shards
    hash % 4 ≠ hash % 8
    → Data move karna padega!
```

#### Strategies
- **Double shards:** 4→8, each shard split — 50% data moves
- **Consistent hashing:** Minimal data movement (next section) — only K/n keys
- **Offline migration:** Downtime, full copy — simple but disruptive
- **Online migration:** Dual-write, backfill, switch — zero downtime but complex

### 3.8 Partitioning Strategies (Logical vs Physical)

**Table Partitioning (Single DB):**
```
    orders table → Partition by month
    orders_2024_01, orders_2024_02, ...
    → Same DB, logical split. Fast for range queries (last 3 months)
```

**Sharding (Multiple DBs):**
```
    orders → Shard by user_id across 10 DBs
    → Physical split. Scale writes.
```

**When to use:** Partitioning = single DB overload, range queries. Sharding = multiple DBs, scale.

### Sharding Strategies Comparison Table

| Strategy | Distribution | Range Query | Resharding |
|----------|--------------|-------------|------------|
| Hash | Even | No | Hard |
| Range | Can skew | Yes | Medium |
| Directory | Flexible | Depends | Easy |

### 1 Minute Recall Block
> Horizontal sharding = rows split. Shard key = critical (cardinality, distribution). Hash = even, Range = hot shard risk. Cross-shard = avoid (co-locate).

### ⚠️ Common Interview Trap
**Trap:** "Sharding and Partitioning same hai?" — **Similar but different!** Partitioning = single DB logical split. Sharding = physical split across DBs. Sharding = distributed partitioning.

---

## 4. Consistent Hashing

### Core Concept
**Resharding mein minimal movement** — Node add/remove pe sirf K/n keys move (K=keys, n=nodes). Normal mod hashing = `hash % n` change hone pe almost sab keys move!

### Why Normal Mod Fails

```
    hash(key) % 4 = shard
    Add 1 shard → hash(key) % 5 = different shard for MOST keys!
    → 75% keys need to move (disaster for large datasets)
```

### How It Works: Ring Diagram

```
                0
                │
         ┌──────┴──────┐
         │   Ring      │
    270  │      ●A     │  90
         │     /  \    │
         │    ●C   ●B  │
         │      \ /    │
         └───────●─────┘
               180
    
    Keys: hash(key) → ring position (0 to 2^32 or similar)
    Node: Next node clockwise = owner
    Add node D: Only keys between D and next node move!
```

### Virtual Nodes (Vnodes)

```
    Without vnodes: 3 nodes, uneven distribution (hash can cluster)
    With vnodes: Each physical node = 100-200 virtual points on ring
    → Even distribution, load balancing
    → Used by: Cassandra, DynamoDB, Redis Cluster
```

### 1 Minute Recall Block
> Consistent hashing = ring. Key → position, owner = next node clockwise. Add node = minimal keys move. Vnodes = even distribution.

---

## 5. Connection Pooling

### Core Concept
**Connections reuse karo** — Har request pe naya connection = expensive. Pool = pre-created connections, reuse.

### How It Works

```
    Without Pool:          With Pool (PgBouncer):
    Request → New Conn    Request → Get from Pool
            → Query               → Query
            → Close               → Return to Pool
    (Slow!)                       (Fast!)
```

### PgBouncer (PostgreSQL)
- Connection pooler — 1000 app connections → 100 DB connections
- **Transaction pooling:** Connection returned after each transaction (best for serverless)
- **Session pooling:** Connection for entire session
- **Statement pooling:** Per query (rare)

### Connection Pool Sizing
- **Formula:** connections = ((core_count * 2) + effective_spindle_count)
- **Too many:** DB overload, memory. PostgreSQL default max_connections = 100.
- **Too few:** Queue, latency. PgBouncer helps — app 1000 connections, DB 100.

### 1 Minute Recall Block
> Connection pooling = reuse connections. PgBouncer = PostgreSQL. Reduces connection overhead.

---

## 6. Read vs Write Scaling Summary

### Read Scaling

| Technique | How | Use When |
|-----------|-----|----------|
| Replication | Read replicas | Read-heavy |
| Caching | Redis, Memcached | Hot data |
| Read-your-writes | Route to same replica | Consistency |

### Write Scaling

| Technique | How | Use When |
|-----------|-----|----------|
| Sharding | Split data | Write-heavy |
| Async writes | Queue + worker | Can tolerate delay |
| Batch writes | Bulk insert | Analytics |

### Formula

```
    Reads zyada?  → Replication + Caching
    Writes zyada? → Sharding
    Dono?         → Replication + Sharding
```

---

## 7. Database per Service

### Core Concept
**Microservices** — Har service ka apna database. No shared DB.

```
    Service A ──► DB A (users)
    Service B ──► DB B (orders)
    Service C ──► DB C (inventory)
    
    No: Service B directly querying DB A
    Yes: Service B calls Service A API
```

### Pros
- Loose coupling
- Independent scaling
- Technology choice per service

### Cons
- Distributed transactions hard
- Data duplication
- Joins across services = API calls

### 1 Minute Recall Block
> DB per service = microservices pattern. No shared DB. Transactions = saga/eventual.

---

## 8. Interview Questions & Traps

### Scaling Questions in System Design

**Typical flow:** "Database slow ho raha hai" → "Read or write?" → Replication vs Sharding. "Shard key?" → Cardinality, distribution. "Resharding?" → Consistent hashing.

**Pro tip:** "Read heavy = replicas first, write heavy = sharding" — yeh formula hamesha batao.

### Top Interview Questions

1. **Replication vs Sharding difference?**
   - Replication = same data, multiple copies (read scale). Sharding = different data, split (write scale).

2. **Shard key kaise choose karein?**
   - High cardinality, even distribution, query pattern match.

3. **Consistent hashing kyu use karte hain?**
   - Resharding pe minimal data movement. Add/remove node = K/n keys move.

4. **Replication lag ka solution?**
   - Read from master for critical, read-your-writes, sync replica.

5. **Cross-shard join kaise?**
   - Avoid! Co-locate data. If must: fan-out, merge in app (slow).

6. **Replication lag kitna acceptable?**
   - Depends. Bank = 0 (sync). Social feed = seconds OK. Analytics = minutes OK.

7. **Hot shard problem kya hai?**
   - One shard gets most traffic (e.g., celebrities' data). Solution: Better shard key, sub-sharding.

### ⚠️ Common Interview Traps

| Trap | Wrong | Right |
|------|-------|-------|
| "Replication for writes?" | Haan | Nahi, reads ke liye |
| "Sharding = replication?" | Same | Different! Sharding = split |
| "Consistent hashing = no collision?" | Haan | Collision possible, different concept |
| "More shards = always better?" | Haan | Cross-shard queries expensive |
| "DB per service = no shared data?" | Correct | But duplication, eventual consistency |

### Quick Recall — Final

```
    Scaling: Reads → Replication. Writes → Sharding.
    Master-Slave: 1 write, N read. Sync vs Async.
    Sharding: Horizontal (rows) vs Vertical (tables).
    Shard key: Cardinality + distribution + query.
    Hash vs Range vs Directory sharding.
    Consistent hashing: Ring, minimal movement.
    Connection pooling: PgBouncer.
    DB per service: Microservices.
```

### Scaling Decision Tree (Interview Ready)

```
    Database load badh raha hai?
    │
    ├─ Read heavy? 
    │   ├─ Add Read Replicas
    │   └─ Add Cache (Redis)
    │
    ├─ Write heavy?
    │   ├─ Sharding (horizontal split)
    │   └─ Choose shard key carefully!
    │
    └─ Connection limit?
        └─ Connection Pooling (PgBouncer)
```

### Final 5 Bullet Memory Hooks
1. **Reads** = Replicas, **Writes** = Sharding
2. **Replication** ≠ Write scaling (still 1 master)
3. **Shard key** = high cardinality + even distribution
4. **Consistent hashing** = add node = K/n keys move
5. **Cross-shard** = avoid (co-locate data)

### Real Systems Cheat Sheet

| System | Replication | Sharding | Consistent Hash |
|--------|-------------|----------|-----------------|
| PostgreSQL | Master-Replica | Manual (Citus) | N/A |
| MySQL | Master-Replica | Manual | N/A |
| Cassandra | Yes (multi-master) | Yes (partition key) | Yes |
| MongoDB | Replica Set | Sharding | Yes (hashed) |
| Redis Cluster | Slave per master | Hash slots | Yes |

### Scaling Checklist (Interview)
- [ ] Identify bottleneck: Read or Write?
- [ ] Read heavy → Replication + Caching
- [ ] Write heavy → Sharding (choose key!)
- [ ] Connection limit → Pooling
- [ ] Cross-shard queries? → Redesign (co-locate)

### Common Sharding Mistakes
1. **Bad shard key:** Low cardinality (gender) → 2 shards only
2. **Hot shard:** Celebrity data on one shard → overload
3. **Cross-shard joins:** Query all shards → slow
4. **Resharding without plan:** Downtime, data loss risk

### Replication vs Sharding — Quick Compare

| | Replication | Sharding |
|---|-------------|----------|
| Data | Same on all | Different on each |
| Scale | Reads | Writes |
| Complexity | Low | High |
| Use first | Yes | When writes bottleneck |

---

*End of Database Scaling Notes*
