# Microservices Architecture — Mental Model

> **Permanent Recall:** Think of microservices as **city departments**—each has its own responsibility, budget (resources), and workflows. Decompose by **domain** or **feature**; use **DDD bounded contexts** for service boundaries. Microservices add complexity—use when team size, scale, or deploy frequency justify it. Avoid microservices for small teams and early-stage products.

---

## City Departments Analogy

**Each service = an independent city department.**

| City Department | Microservice | Idea |
|-----------------|--------------|------|
| **Water dept** | User Service | Owns water (user data); others depend on it |
| **Electric dept** | Order Service | Owns electricity (orders); separate budget |
| **Police dept** | Payment Service | Critical; must be reliable |
| **City hall** | API Gateway | Single entry; routes citizens to departments |

- **No shared storage:** Each department has its own filing system (DB per service)
- **Communication via official channels:** Departments send requests, not internal memos (network calls)
- **Independent budgets:** Each can scale up/down (resource allocation)

---

## How to Decompose a Monolith

| Strategy | How | When |
|----------|-----|------|
| **By domain** | Extract by business domain (e.g., User, Order, Payment) | Clear domain boundaries |
| **By feature** | Extract by feature/use case (e.g., Checkout, Recommendation) | Feature teams |
| **By team** | Conway's Law; structure follows teams | Multiple teams |

**Rule:** Start with highest-value, least-coupled modules (e.g., notifications, reporting).

---

## Domain-Driven Design (DDD) for Service Boundaries

**Bounded context** = natural boundary for a service.

```
    ┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
    │  User Context   │     │ Order Context   │     │Payment Context  │
    │  - User entity  │     │ - Order entity  │     │ - Payment entity│
    │  - Auth         │     │ - Inventory     │     │ - Refund        │
    │  - Profile      │     │ - Fulfillment   │     │ - Billing       │
    └────────┬────────┘     └────────┬────────┘     └────────┬────────┘
             │                       │                        │
             └───────────────────────┼────────────────────────┘
                                     │
                        Shared: Order ID, User ID (references only)
```

**Key idea:** Each bounded context has its own model; they share **IDs** (references), not entities.

---

## How to Think About Service Communication

| Question | Sync | Async |
|----------|------|-------|
| Need immediate response? | Yes → REST/gRPC | No → Queue |
| Can tolerate eventual consistency? | No | Yes |
| One-to-many? | Awkward | Natural (pub/sub) |
| Critical path? | Often | Avoid (adds latency) |

**Mental model:** Sync = phone call (wait for answer). Async = letter (send, process later).

---

## When Microservices Are Overkill

| Scenario | Prefer | Why |
|----------|--------|-----|
| 1–2 developers | Monolith | Operational burden too high |
| Early-stage startup | Monolith | Iterate fast; no scaling pressure |
| Single deploy per week | Monolith | No need for independent deploy |
| Tight consistency requirements | Monolith or fewer services | Distributed transactions are hard |
| No clear domain boundaries | Monolith | Will create wrong boundaries |

> **FAANG Tip:** *"We started as a monolith; extracted services when we had 5+ teams and needed independent deploy cycles."*

---

## Decision Flowchart: Monolith vs Microservices

```mermaid
flowchart TD
    A[Starting new project?] -->|Yes| B[Team size?]
    A -->|No, existing monolith| C[Pain points?]
    B -->|1-5 devs| D[Monolith]
    B -->|6+ devs, multiple teams| E[Consider microservices]
    C -->|Deploy bottleneck| F[Strangler Fig migration]
    C -->|Scale/team pressure| F
    C -->|No pain| G[Keep monolith]
    E --> H[Clear domain boundaries?]
    H -->|Yes| I[Microservices]
    H -->|No| J[Modular monolith first]
```

**ASCII fallback:**

```
New project?
  ├─ Small team (1-5)     → Monolith
  └─ Large team (6+)
       ├─ Clear domains   → Microservices
       └─ Unclear         → Modular monolith first

Existing monolith?
  ├─ Deploy/scale pain    → Strangler Fig migration
  └─ No pain              → Keep monolith
```

---

## Quick Memory Card

```
ANALOGY:       City departments; own storage, communicate via network
DECOMPOSE:     By domain, feature, or team
DDD:           Bounded context = service boundary; share IDs, not entities
COMMUNICATION: Sync (immediate) vs Async (eventual)
OVERKILL:      Small team, early stage, unclear boundaries
DECISION:      Team size, deploy frequency, domain clarity
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
