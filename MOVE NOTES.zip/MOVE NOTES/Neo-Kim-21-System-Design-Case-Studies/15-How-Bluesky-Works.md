# How Bluesky Works - System Design

> Source: https://newsletter.systemdesign.one/p/how-does-bluesky-work

## One-Line Summary
Bluesky is a decentralized social network built on AT Protocol (ATProto) using a federated architecture where user data lives in portable repositories on data servers, crawlers aggregate updates, and moderation is community-driven rather than centralized.

## Key Requirements

### Functional
- Post short status updates (text + images)
- Follow users and see their posts in a feed
- Like, comment, repost
- Portable identity (move your account between servers)
- Custom feeds (algorithmic or chronological)
- Decentralized moderation (community-driven, not single authority)

### Non-Functional
- Scalable federated architecture
- Low cost per user (~$0.025/user/month for 6M users on single server)
- Real-time updates across federated servers
- Data portability (user owns their data)
- Interoperable with other ATProto apps

## The Problem with Centralized Social Networks

1. **Bias risk**: single authority makes all moderation decisions
2. **Error risk**: one entity decides content policies for everyone
3. **Scale bottleneck**: centralized moderation can't keep up with growth
4. **User lock-in**: can't move your followers/data to another platform

**Bluesky's solution**: Federated architecture (like email -- Gmail user can message Protonmail user)

## High-Level Architecture

```
Users (Bluesky App)
      |
  Data Servers (PDS - Personal Data Servers)
      |  (each stores user repositories in SQLite)
      |  (HTTP API + WebSocket for updates)
      |
  Crawler (Relay)
      |  (subscribes to all data servers via WebSocket)
      |  (generates a unified stream of all updates)
      |
  Index Server (App View)
      |  (aggregates: counts likes, comments, reposts)
      |  (transforms raw data into consumable feeds)
      |
  Feed Generators
      |  (custom algorithms for different feed types)
      |
  Moderation Services (Labelers)
         (community-run content moderation)
```

## Core Components Deep Dive

### 1. AT Protocol (ATProto)
- Open-source framework for building social apps
- Bluesky is just ONE app built on ATProto
- User's data is shared across all ATProto apps
- If you switch apps, you keep your followers (social graph)
- **Analogy**: ATProto = Disneyland Park, Bluesky = one attraction

### 2. User Repositories
- Each user has a **repository** (collection of their data)
- Stored in **SQLite** (simple, cheap)
- Data encoded in **CBOR** (compact binary format) for low storage cost
- Contains: posts, likes, follows, profile info
- Repository is **portable** -- can move between data servers (like Git repos between GitHub and GitLab)
- A user's repo does NOT store actions by others (comments/likes on their posts stored in commenter's/liker's repo)

### 3. Data Servers (PDS - Personal Data Server)
- Hosts multiple user repositories
- **6 million users on a single server for $150/month!**
- Exposes HTTP API for client interactions
- Handles authentication and authorization
- Sends real-time updates via WebSocket to crawlers
- Auto-applies updates from the federated network

### 4. Crawler (Relay)
- Subscribes to ALL data servers for updates (WebSocket)
- Collects new posts, likes, comments from every data server
- Generates a single unified **stream** (firehose)
- Does NOT index data -- just forwards it
- Stream = append-only log over WebSocket (combines all user actions into single TCP connection)

### 5. Index Server (App View)
- Consumes the crawler's stream
- **Aggregates data**: counts likes, comments, reposts per post
- Transforms raw events into a consumable format
- Acts as the "data presentation layer"
- Answers API queries for feeds and post details

### 6. Feed Generators
- Separate services that create **custom feeds**
- Can implement any algorithm: chronological, trending, topic-based
- Users choose which feed generators to subscribe to
- Decentralized: anyone can create a feed algorithm

### 7. Moderation (Labelers)
- **Community-run** moderation services (not centralized)
- Labelers tag content (NSFW, spam, misinformation, etc.)
- Users choose which labelers to trust
- Multiple labelers can co-exist with different policies
- Solves the single-authority moderation problem

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Federated (not P2P or blockchain) | Familiar client-server model, reliable, simple |
| SQLite for repos | Cheap, simple, one DB per user repo |
| CBOR encoding | Compact binary = low storage cost |
| Crawler + Stream pattern | Scalable aggregation without direct server-to-server coupling |
| Portable repos | Users own data, no platform lock-in |
| Community moderation | No single authority, reduces bias |
| Custom feed generators | Users control their algorithm |

## ATProto vs ActivityPub (Mastodon)

| Aspect | ATProto (Bluesky) | ActivityPub (Mastodon) |
|--------|-------------------|----------------------|
| Data ownership | User owns repo, portable | Data lives on your server |
| Identity | Global, portable | Tied to server instance |
| Feed algorithm | Custom, pluggable | Chronological (mostly) |
| Moderation | Community labelers | Server-level moderation |
| Cross-app | Multiple apps on same protocol | Mainly microblogging |
| Architecture | Relay-based aggregation | Server-to-server federation |

## Scaling Strategies

1. **Massive density**: 6M user repos on single PDS for $150/month
2. **Crawler aggregation**: single stream from all data servers (not N^2 connections)
3. **Separate index servers**: scale read path independently
4. **Multiple feed generators**: each runs independently
5. **Horizontal PDS scaling**: add more data servers as user base grows

## Interview Tips

- Start with the **problem**: centralized moderation doesn't scale, has bias
- Explain the **email analogy** for federated architecture
- Draw the full pipeline: Data Server → Crawler → Index Server → Feed Generator
- Emphasize **data portability** (move repos between servers like Git)
- Know ATProto vs ActivityPub differences
- Mention the cost efficiency: 6M users on $150/month server
- Discuss **community moderation** (labelers) as a key innovation
- This question tests: distributed systems, federation, protocol design

## Quick Revision (5 bullet points)

1. **Federated architecture** on ATProto: user data in portable SQLite repos on data servers; like email (different providers, same protocol)
2. **Data pipeline**: Data Servers → Crawler (relay/firehose via WebSocket) → Index Server (aggregation) → Feed Generators (custom algorithms)
3. **Data portability**: user repos can move between data servers (like Git between GitHub/GitLab); user owns their data and social graph
4. **Community moderation**: labelers (not central authority) tag content; users choose which labelers to trust
5. **Extremely cost-efficient**: 6M users on single PDS for $150/month; SQLite + CBOR encoding keeps storage cheap
