# Python Variables, Data Types, and I/O

> *"Names refer to objects; assignment never copies data"* — Python data model (concept)

In this note we'll cover how variables bind to objects, built-in types, `input()`/`print()`, f-strings, and type casting. These are the building blocks of every program — a natural next step after [[01-Python-History-and-Basics]].

---

## 1. Variables — no declaration, it's binding

> **Definition:** In Python, a variable is a **name** (identifier) bound to an **object**; assignment attaches the name to whatever value the right-hand side evaluates to.

**Why we need it:** Skipping declarations keeps programs concise and matches the data model: names refer to objects, and rebinding can point the same name at a new object without a special syntax.

**Syntax:**
```python
<name> = <object_or_expression>
```

In Python a variable is a **name** that points to an **object** (a reference).

```python
a = 10     # Creates integer 10, name "a" points to it
b = a      # "b" now points to SAME object as "a" (both → 10)
a = 20     # "a" now points to NEW object 20; "b" still points to 10
```


| Concept    | Meaning                                  |
| ---------- | ---------------------------------------- |
| Name       | Identifier — `a`, `user_count`           |
| Object     | The actual value + type in memory        |
| Assignment | With `=` you bind the name to an object  |


**Watch Out!** There is **no** `int x = 5;` syntax in Python — only `x = 5`.

**Interview Tip:** A variable is **not a box** — the **name tag** analogy is better: the tag is on the object.

---

## 2. Built-in core types

> **Definition:** Built-in types are the core object kinds the language ships with—numbers, text, booleans, and `None`—so every program shares the same standard representations.

**Why we need it:** Standard primitives make interoperability trivial, give the interpreter well-defined behavior, and let libraries agree on what an `int`, `str`, or `bool` means.

**Syntax:**
```python
<int_literal> | <float_literal> | <str_literal> | True | False | None
type(<object>)
```


| Type       | Example                       | Note                          |
| ---------- | ----------------------------- | ----------------------------- |
| `int`      | `42`, `-7`, `10**100`         | Arbitrary precision integers  |
| `float`    | `3.14`, `2.5e3`               | IEEE double (usually)         |
| `str`      | `"hi"`, `'hi'`, `"""multi"""` | Immutable sequence of Unicode |
| `bool`     | `True`, `False`               | `bool` is subclass of `int`   |
| `NoneType` | `None`                        | "Nothing" — singleton         |


```python
x = None
if x is None:
    print("not assigned")
```

### `type()` and `id()`

```python
type(3)        # <class 'int'> → tells you WHAT TYPE the object is
type("hi")     # <class 'str'> → it's a string
id(3)          # Returns a unique number (identity) for this object in memory
```

**Watch Out!** `is` vs `==` — identity vs value; details in [[17-Python-FAANG-Interview-Must-Know]] and [[notes]].

---

## 3. `input()` and `print()`

> **Definition:** `input()` reads one line from the user and returns it as a `str`; `print()` writes values to standard output, with configurable separators between items and an ending string (default newline).

**Why we need it:** Simple, portable console I/O for scripts, teaching, and small tools—no extra setup before you can interact with a program.

**Syntax:**
```python
<variable> = input(<optional_prompt_string>)
print(<expr1>, <expr2>, ..., sep=<str>, end=<str>, file=<stream>)
```

### input — always a string

```python
name = input("Enter your name: ")   # Waits for user to type, returns it as string
age_str = input("Age: ")      # Even if user types 25, you get "25" (string!)
age = int(age_str)              # Convert string "25" to actual number 25
```

### print — flexible

```python
print("hello")                   # Prints text to screen with newline at end
print("a", "b", "c")            # Prints multiple items with space between → a b c
print("a", "b", sep="-")        # Changes separator to "-" → a-b
print("hi", end="!")            # Changes ending (default is newline) → hi!
```


| Function        | Return / behavior                     |
| --------------- | ------------------------------------- |
| `input(prompt)` | Reads a line from the user → **str**  |
| `print(*args)`  | stdout, default `sep=' '`, `end='\n'` |


**Interview Tip:** For very fast I/O in competitive coding people sometimes use `sys.stdin` — basic interviews are fine with `input`.

---

## 4. f-strings (Python 3.6+)

> **Definition:** An f-string is a string literal prefixed with `f` where `{...}` placeholders embed expressions that are evaluated and formatted into the final string.

**Why we need it:** It is usually the clearest and fastest way to build strings from values, compared to `%` formatting or `.format()`, while keeping the full expression visible in place.

**Syntax:**
```python
f"{<expression>}"
f"{<expression>:<format_spec>}"
f"{<name>=}"  # debug form (3.8+)
```

The most readable formatting:

```python
name = "Ravi"
score = 95.5
print(f"{name} scored {score:.1f} marks")  # Puts variables inside string
# :.1f means show 1 decimal place for float
```

### Expressions and = debug (3.8+)

```python
x = 3
print(f"{x=}")       # Prints "x=3" → shows variable name AND value (great for debugging)
print(f"{x + 1 = }")  # Prints "x + 1 = 4"
```


| Old style      | Note                           |
| -------------- | ------------------------------ |
| `%` formatting | C-style, used less now         |
| `.format()`    | Still valid                    |
| f-string       | **Preferred** — fast, readable |


**Watch Out!** Balance **quotes** inside f-strings — if the same quote would clash, use the other kind.

---

## 5. Type casting (conversion)

```python
int("42")       # 42        → Converts string to integer number
float("3.14")   # 3.14      → Converts string to decimal number
str(100)        # "100"     → Converts number to string text
bool(0)         # False     → 0 is considered False
bool("")        # False     → empty string is considered False
bool("no")      # True      → any non-empty string is True
list("abc")     # ['a','b','c'] → Breaks string into list of characters
tuple([1,2])    # (1, 2)    → Converts list to tuple
set([1,1,2])    # {1, 2}    → Converts to set (removes duplicates)
```


| Conversion    | Fails when               |
| ------------- | ------------------------ |
| `int("12.3")` | ValueError — use float first |
| `int("")`     | ValueError               |


**Interview Tip:** `int(x, base)` — `int("FF", 16)` → 255.

---

## 6. Truthiness — in conditions

Falsy values: `None`, `0`, `0.0`, `""`, `[]`, `{}`, `set()`, etc.

```python
if user_list:
    print("non-empty")
```

---

## 7. `bytes` and `bytearray` (intro)

Besides text, **binary** data:

```python
b = b"hello"           # Creates immutable bytes object (cannot change)
ba = bytearray(b"hi")  # Creates mutable bytes (can change individual bytes)
ba[0] = 72             # Changes first byte to 72 which is ASCII for 'H'
"hello".encode("utf-8")   # Converts string → bytes
b"hello".decode("utf-8")  # Converts bytes → string
```


| Type        | Mutable? | Use                        |
| ----------- | -------- | -------------------------- |
| `bytes`     | No       | files, network protocols   |
| `bytearray` | Yes      | buffers, incremental build |


**Interview Tip:** `str` ↔ `bytes` — `.encode("utf-8")` / `.decode("utf-8")`.

---

## 8. Number literals — readability

```python
million = 1_000_000   # Underscores for readability — same as 1000000
binary = 0b1010       # Binary number (base 2) — equals 10 in decimal
hexed = 0xFF          # Hexadecimal (base 16) — equals 255 in decimal
octal = 0o17          # Octal (base 8) — equals 15 in decimal
```

**Watch Out!** Underscores in Python 3.6+ — only for readability, value is the same.

---

## 9. Mini debugging tricks (print era)

```python
print("x", x, "y", y, sep=" | ")
```

`repr()` for an unambiguous string:

```python
print(repr("a\nb"))
```

---

## 10. Oral exam rapid Q&A


| Question                | Answer                                   |
| -------------------- | --------------------------------------- |
| `input` return type? | Always `str`                           |
| `type(3.0)`?         | `float`                                 |
| `bool([])`?          | `False` — empty container falsy         |
| f-string empty `{}`? | Syntax error — you need a valid expression |


---

## Quick Memory Card

```
+------------------------------------------+
| VARIABLES                                 |
| - Name → object reference                |
| - No type declaration                    |
+------------------------------------------+
| CORE TYPES                                |
| - int, float, str, bool, None            |
| - type(), id()                           |
+------------------------------------------+
| I/O                                       |
| - input() → always str                   |
| - print(sep=, end=)                     |
+------------------------------------------+
| F-STRINGS                                 |
| - f"{expr}" / f"{x=}"                   |
+------------------------------------------+
| CASTING                                   |
| - int(), float(), str(), bool(), list()  |
+------------------------------------------+
```

---

*Next: [[03-Python-Operators-Control-Flow]]*
