import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#57534e',
    panelBg: 'rgba(255,255,255,0.92)',
    panelBorder: '#d6d3d1',
    cellDefault: '#f5f5f4',
    cellFilling: '#fff3bf',
    cellFilled: '#a5d8ff',
    cellOptimal: '#b2f2bb',
    cellCurrent: '#ffd43b',
    arrow: '#57534e',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.05)',
    stroke: 'rgba(255,255,255,0.55)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    panelBg: 'rgba(28,25,23,0.85)',
    panelBorder: 'rgba(255,255,255,0.12)',
    cellDefault: '#292524',
    cellFilling: '#805b10',
    cellFilled: '#1c4a6e',
    cellOptimal: '#1e5631',
    cellCurrent: '#805b10',
    arrow: 'rgba(255,255,255,0.45)',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function cellColor(p, name) {
  const n = name || 'default';
  const key = `cell${n.charAt(0).toUpperCase() + n.slice(1)}`;
  return p[key] || p.cellDefault;
}

function easeOut(t) {
  return 1 - (1 - t) ** 3;
}

const DPCanvasBase = forwardRef(function DPCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    table: [],
    rowLabels: [],
    colLabels: [],
    cellColors: {},
    arrows: [],
    highlight: null,
    items: null,
    caption: '',
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 400) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((patch) => {
    Object.assign(stateRef.current, patch);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 400;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function render() {
      const now = performance.now();
      const p = getPalette();
      const {
        table, rowLabels, colLabels, cellColors, arrows, highlight, items, caption,
      } = stateRef.current;

      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20) {
        for (let gy = 20; gy < H; gy += 20) {
          ctx.fillRect(gx, gy, 1.5, 1.5);
        }
      }

      let top = 44;
      if (items && items.length) {
        const ih = 36;
        ctx.fillStyle = p.panelBg;
        ctx.strokeStyle = p.panelBorder;
        ctx.beginPath();
        ctx.roundRect(16, top - 28, W - 32, ih, 8);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = p.textSecondary;
        ctx.font = '600 10px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText('Items', 24, top - 10);
        ctx.fillStyle = p.textPrimary;
        ctx.font = '500 11px ui-monospace, Consolas, monospace';
        const txt = items.map((it) => (typeof it === 'string' ? it : JSON.stringify(it))).join('   ');
        ctx.fillText(txt.length > 120 ? `${txt.slice(0, 118)}…` : txt, 64, top - 10);
        top += 8;
      }

      const rows = table && table.length ? table.length : 0;
      const cols = rows && table[0] ? table[0].length : 0;
      if (!rows || !cols) {
        for (let i = animsRef.current.length - 1; i >= 0; i -= 1) {
          if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
        }
        rafRef.current = requestAnimationFrame(render);
        return;
      }

      const labelColW = (rowLabels && rowLabels.length) ? 44 : 0;
      const labelRowH = (colLabels && colLabels.length) ? 28 : 0;
      const availW = W - 40 - labelColW;
      const availH = H - top - 36;
      const cellW = Math.max(28, Math.min(56, Math.floor(availW / cols)));
      const cellH = Math.max(26, Math.min(44, Math.floor(availH / rows)));
      const gridW = cellW * cols;
      const gridH = cellH * rows;
      const originX = 20 + labelColW + Math.max(0, (availW - gridW) / 2);
      const originY = top + Math.max(0, (availH - gridH - labelRowH) / 2) + labelRowH;

      if (colLabels && colLabels.length === cols) {
        ctx.fillStyle = p.textSecondary;
        ctx.font = '600 10px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'center';
        for (let c = 0; c < cols; c += 1) {
          const cx = originX + c * cellW + cellW / 2;
          ctx.fillText(String(colLabels[c]), cx, originY - labelRowH + 18);
        }
      }

      const cellCenter = (r, c) => ({
        x: originX + c * cellW + cellW / 2,
        y: originY + r * cellH + cellH / 2,
      });

      (arrows || []).forEach((ar) => {
        const a = cellCenter(ar.from[0], ar.from[1]);
        const b = cellCenter(ar.to[0], ar.to[1]);
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(b.x, b.y);
        ctx.strokeStyle = p.arrow;
        ctx.lineWidth = 1.4;
        ctx.stroke();
        const ang = Math.atan2(b.y - a.y, b.x - a.x);
        const sz = 7;
        ctx.beginPath();
        ctx.moveTo(b.x, b.y);
        ctx.lineTo(b.x - sz * Math.cos(ang - 0.35), b.y - sz * Math.sin(ang - 0.35));
        ctx.lineTo(b.x - sz * Math.cos(ang + 0.35), b.y - sz * Math.sin(ang + 0.35));
        ctx.closePath();
        ctx.fillStyle = p.arrow;
        ctx.fill();
      });

      let pulse = 1;
      for (const a of animsRef.current) {
        const t = Math.min((now - a.t0) / a.dur, 1);
        const e = easeOut(t);
        if (a.type === 'cell' && a.data.rc) {
          const [rr, cc] = a.data.rc;
          if (highlight && highlight[0] === rr && highlight[1] === cc) {
            pulse = 1 + 0.08 * Math.sin(e * Math.PI);
          }
        }
      }

      for (let r = 0; r < rows; r += 1) {
        if (rowLabels && rowLabels[r] != null) {
          ctx.fillStyle = p.textSecondary;
          ctx.font = '600 10px -apple-system, BlinkMacSystemFont, sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(String(rowLabels[r]), originX - labelColW / 2 - 4, originY + r * cellH + cellH / 2);
        }
        for (let c = 0; c < cols; c += 1) {
          const x = originX + c * cellW;
          const y = originY + r * cellH;
          const key = `${r}-${c}`;
          const colorName = (cellColors && cellColors[key]) || 'default';
          const fill = cellColor(p, colorName);
          let scale = 1;
          if (highlight && highlight[0] === r && highlight[1] === c) scale = pulse;

          const dw = (cellW - 4) * scale;
          const dh = (cellH - 4) * scale;
          const ox = x + 2 + ((cellW - 4) - dw) / 2;
          const oy = y + 2 + ((cellH - 4) - dh) / 2;

          ctx.fillStyle = fill;
          ctx.strokeStyle = p.stroke;
          ctx.lineWidth = highlight && highlight[0] === r && highlight[1] === c ? 2.2 : 1.2;
          ctx.beginPath();
          ctx.roundRect(ox, oy, dw, dh, 4);
          ctx.fill();
          ctx.stroke();

          const val = table[r][c];
          ctx.fillStyle = p.textPrimary;
          ctx.font = '600 12px ui-monospace, Consolas, monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          const disp = val == null ? '' : String(val);
          ctx.fillText(disp, x + cellW / 2, y + cellH / 2);
        }
      }

      if (caption) {
        ctx.fillStyle = p.textSecondary;
        ctx.font = '500 11px -apple-system, BlinkMacSystemFont, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(caption, 16, 22);
      }

      function pruneAnims(t) {
        for (let i = animsRef.current.length - 1; i >= 0; i -= 1) {
          if (t - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
        }
      }
      pruneAnims(now);

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default DPCanvasBase;
