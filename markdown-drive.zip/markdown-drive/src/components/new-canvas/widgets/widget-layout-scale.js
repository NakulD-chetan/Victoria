import { WIDGET_DEFAULTS } from './widget-registry';

const SCALE_MIN = 0.55;
const SCALE_MAX = 2.35;

/**
 * Scale factor vs default widget size so typography can track resize.
 * Uses min(w/refW, h/refH) so content stays balanced in both dimensions.
 *
 * @param {string} widgetType
 * @param {number} w
 * @param {number} h
 */
export function computeWidgetLayoutScale(widgetType, w, h) {
  const d = WIDGET_DEFAULTS[widgetType];
  if (!d || !Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return 1;
  const rw = d.w || 1;
  const rh = d.h || 1;
  const sx = w / rw;
  const sy = h / rh;
  const s = Math.min(sx, sy);
  return Math.min(SCALE_MAX, Math.max(SCALE_MIN, s));
}
