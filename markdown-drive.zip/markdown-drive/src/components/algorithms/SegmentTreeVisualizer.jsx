import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function buildSegTree(arr, idGen) {
  const nodes = [];
  const edges = [];

  function build(l, r) {
    const myId = idGen();
    if (l === r) {
      nodes.push({ id: myId, value: arr[l], label: `${arr[l]}`, meta: { l, r } });
      return { id: myId, l, r, sum: arr[l] };
    }
    const mid = Math.floor((l + r) / 2);
    const left = build(l, mid);
    const right = build(mid + 1, r);
    edges.push([myId, left.id]);
    edges.push([myId, right.id]);
    const sum = left.sum + right.sum;
    nodes.push({
      id: myId,
      value: sum,
      label: `${sum}`,
      left: left.id,
      right: right.id,
      meta: { l, r },
    });
    return { id: myId, l, r, sum };
  }

  const root = build(0, arr.length - 1);
  return { nodes, edges, rootId: root.id };
}

function generateSteps(baseArr) {
  const steps = [];
  let gid = 0;
  const idGen = () => gid++;
  const built = buildSegTree(baseArr, idGen);

  steps.push({
    caption: `Build segment tree on [${baseArr.join(', ')}]`,
    nodes: built.nodes,
    edges: built.edges,
    nodeColors: { [built.rootId]: 'current' },
    stack: ['build'],
    queue: [],
    result: [...baseArr],
  });

  const ql = 1;
  const qr = 3;
  steps.push({
    caption: `Range query [${ql},${qr}] — highlight nodes covering subranges`,
    nodes: built.nodes,
    edges: built.edges,
    nodeColors: Object.fromEntries(
      built.nodes
        .filter((n) => n.meta && n.meta.l <= qr && n.meta.r >= ql)
        .map((n) => [n.id, 'visited']),
    ),
    stack: ['query'],
    queue: [],
    result: [...baseArr, `Q(${ql},${qr})`],
  });

  const updIdx = 2;
  const updVal = 7;
  steps.push({
    caption: `Point update index ${updIdx} → ${updVal} (propagate sums)`,
    nodes: built.nodes.map((n) => (n.meta && n.meta.l === n.meta.r && n.meta.l === updIdx
      ? { ...n, value: updVal, label: `${updVal}` }
      : { ...n })),
    edges: built.edges,
    nodeColors: { [built.rootId]: 'current' },
    stack: ['update'],
    queue: [],
    result: baseArr.map((v, i) => (i === updIdx ? updVal : v)),
  });

  steps.push({
    caption: 'Segment tree ready',
    nodes: built.nodes,
    edges: built.edges,
    nodeColors: {},
    stack: [],
    queue: [],
    result: [...baseArr],
  });
  return steps;
}

export default function SegmentTreeVisualizer({ config }) {
  const arr = [4, 2, 7, 1, 9, 3, 6];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(arr);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Segment tree build / query / update' });
    canvasRef.current?.setState({
      nodes: [],
      edges: [],
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Segment tree',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
