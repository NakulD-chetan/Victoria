# Design Uber — Design Template

> **Permanent Recall:** Architecture: Geospatial indexing (Geohash, QuadTree, S2); Location Service (drivers push GPS every 4s → in-memory geospatial store); Matching (nearest K, first-accept-wins); Trip state machine; ETA (graph + historical); Surge (supply/demand per region); WebSocket for real-time tracking; Payment flow post-trip.

---

## Geospatial Indexing (DEEP DIVE)

### Geohash

**Concept:** Encode (lat, lng) into a **string** where **longer prefix = smaller region**. Nearby points share a prefix.

```
Lat/lng: (37.7749, -122.4194)  →  Geohash: "9q8yy"
         (37.7750, -122.4190)  →  Geohash: "9q8yy"  (same cell)
         (37.8000, -122.4000)  →  Geohash: "9q8y2"  (different; further)
```

**Encoding:** Uses base32. Each character adds ~5 bits of precision.
- Precision 1: ~5000 km
- Precision 5: ~5 km
- Precision 7: ~150 m
- Precision 9: ~5 m

```
     Geohash "9q8y" (SF area)
     ┌─────────────────────────┐
     │  Each sub-cell = add 1   │
     │  char: 9q8y0, 9q8y1,...  │
     │  Adjacent cells =        │
     │  neighbors of same len   │
     └─────────────────────────┘
```

**Query:** For rider at "9q8yy": lookup drivers in "9q8yy" + 8 adjacent cells (3×3 grid). Expand if few results.

### QuadTree

**Concept:** Recursively subdivide 2D space into quadrants. Leaf nodes hold points or references.

```
         Root
        /  |  \  \
       Q0  Q1  Q2  Q3
       |   |   ...
    (subdivide until leaf density OK)
```

- **Variable density:** Dense urban areas get deeper trees; sparse areas stay shallow
- **Query:** Traverse from root; descend only into quadrants that intersect search radius
- **O(log n)** for nearest-K with proper pruning

```
    QuadTree for city:
    ┌─────────────────────────────────┐
    │  Downtown (dense): many splits  │
    │  Suburbs: fewer splits          │
    │  Ocean: no drivers, no split    │
    └─────────────────────────────────┘
```

### S2 Cells (Google)

**Concept:** Project Earth onto a cube; subdivide cube faces into hierarchical cells. Each cell has a unique ID.

- **Hierarchical:** Cell level 0 = face; level 30 = ~1 cm²
- **Covering:** Can cover a region with a set of cells (minimize count)
- **Neighbor lookup:** O(1) cell adjacency
- **Used by:** Google Maps, Uber (in production)

| Level | Approx. Edge Length |
|-------|---------------------|
| 10 | ~100 km |
| 15 | ~3 km |
| 20 | ~100 m |

> **FAANG Tip:** For interviews, Geohash is easiest to explain. QuadTree shows you understand variable density. S2 shows production knowledge. Know at least Geohash in depth.

---

## Location Service

| Step | Action |
|------|--------|
| 1 | Driver app sends GPS (lat, lng) every **4 seconds** |
| 2 | API: `POST /location` or WebSocket push |
| 3 | Convert to geohash/cell; update in-memory store |
| 4 | Store: `geohash → [driver_id, ...]` or Redis GEOADD |
| 5 | Optionally persist to DB async for analytics |

**Data structure:** `Map<geohash, Set<driver_id>>` or Redis GEO.

**Sharding:** Partition by region (e.g., by geohash prefix). NYC servers handle NYC; SF servers handle SF.

```
Driver App --[GPS every 4s]--> LB --> Location Service
                                      |
                                      v
                              ┌───────────────┐
                              │ In-Memory     │
                              │ Geo Index     │
                              │ (Redis GEO /  │
                              │  QuadTree)    │
                              └───────────────┘
```

---

## Matching Algorithm (Detailed)

| Step | Action |
|------|--------|
| 1 | Rider: pickup (lat, lng), dropoff; Matching Service receives |
| 2 | Compute geohash for pickup (e.g., precision 6) |
| 3 | Query Location Service: `GEORADIUS pickup 2km` or lookup geohash + neighbors |
| 4 | Filter: `status == AVAILABLE` (from Trip Service or cached) |
| 5 | Sort by distance (Haversine or Redis GEODIST); take top K (e.g., 5) |
| 6 | Create trip record: status = REQUESTED |
| 7 | Push request to K drivers (FCM, WebSocket, or in-app) |
| 8 | **First-accept-wins:** First to accept → status = MATCHED; notify rider |
| 9 | Others get "ride taken" notification; request expires in 15–30s |
| 10 | If no accept: expand radius, retry with next batch of drivers |

> **FAANG Tip:** Synchronous matching (wait for all K to respond) is wrong. First-accept-wins reduces rider wait time.

---

## Trip Lifecycle State Machine

```
REQUESTED ──(match)──> MATCHED ──(driver en route)──> DRIVER_EN_ROUTE
                                                              │
                                                              v
COMPLETED <──(trip ends)── IN_PROGRESS <──(driver arrives)───┘

Alternative: CANCELLED from REQUESTED or MATCHED (rider or driver cancels)
```

| State | Description | Triggers |
|-------|-------------|----------|
| **REQUESTED** | Rider requested; searching for driver | Rider taps "Request" |
| **MATCHED** | Driver accepted | First driver accepts |
| **DRIVER_EN_ROUTE** | Driver heading to pickup | Driver taps "Start" |
| **IN_PROGRESS** | Rider in car; trip underway | Driver arrives, rider gets in |
| **COMPLETED** | Trip finished; payment due | Driver ends trip |
| **CANCELLED** | Trip cancelled | Rider/driver cancels |

---

## ETA Calculation

| Approach | Description |
|----------|-------------|
| **Straight-line / Haversine** | Simple; ignores roads — rough estimate only |
| **Graph-based (routing)** | Use road graph (e.g., OSM); Dijkstra or A* for shortest path |
| **Historical data** | Same route at same time of day — average duration |
| **Real-time traffic** | Integrate traffic API (Google, HERE); adjust edge weights |
| **Production** | Combine: graph + historical + traffic; ML models for fine-tuning |

**Driver-to-pickup ETA:** Graph from driver location to pickup.
**Trip ETA:** Graph from pickup to dropoff; historical for time-of-day.

---

## Surge Pricing

| Concept | Description |
|---------|-------------|
| **Supply/demand ratio** | Per geohash region: `demand = # ride requests`, `supply = # available drivers` |
| **Multiplier** | When demand > supply: multiplier (e.g., 1.0–3.0×) |
| **Granularity** | Geohash precision 5–6 (~5 km); recalculate every few minutes |
| **Fairness** | Cap multiplier; show rider before confirm; avoid "price surprise" |

```
Region A: 50 requests, 100 drivers → 1.0× (no surge)
Region B: 80 requests, 20 drivers  → 2.5× surge
```

---

## Real-Time Tracking (WebSocket)

| Step | Action |
|------|--------|
| 1 | Rider/driver connects via WebSocket when trip matched |
| 2 | Location Service streams driver location every 4s |
| 3 | Push to rider: `{ driver_id, lat, lng, timestamp }` |
| 4 | Rider app updates map; shows ETA countdown |
| 5 | Driver sees rider location (for pickup) and route (for dropoff) |

**Alternative:** Long polling if WebSocket blocked; higher latency.

---

## Payment Flow

| Step | Action |
|------|--------|
| 1 | Trip COMPLETED → Payment Service triggered |
| 2 | Calculate: base_fare + (distance × rate) + (time × rate) × surge |
| 3 | Charge stored payment method (tokenized card) |
| 4 | Split: platform fee, driver payout |
| 5 | Retry on failure; idempotency key to prevent double charge |
| 6 | Notify rider (receipt); update driver balance |

---

## API Design

| Operation | Method | Endpoint | Payload |
|-----------|--------|----------|---------|
| **Request ride** | POST | `/rides` | `{ pickup: {lat, lng}, dropoff: {lat, lng} }` |
| **Update location** | POST | `/drivers/:id/location` | `{ lat, lng, timestamp }` |
| **Accept ride** | POST | `/rides/:id/accept` | `{ driver_id }` |
| **Cancel ride** | POST | `/rides/:id/cancel` | `{ user_id, reason }` |
| **Start trip** | POST | `/rides/:id/start` | — |
| **End trip** | POST | `/rides/:id/complete` | — |
| **Get ETA** | GET | `/rides/:id/eta` | — |
| **Get surge** | GET | `/pricing/surge?lat=&lng=` | — |

---

## ASCII Architecture Diagram

```
                         ┌─────────────────────────────────────────────┐
                         │              Load Balancer                   │
                         └─────────────────────┬───────────────────────┘
                                               │
        ┌─────────────────────────────────────┼─────────────────────────────────────┐
        │                                     │                                     │
        v                                     v                                     v
┌───────────────┐                   ┌───────────────┐                   ┌───────────────┐
│ Rider App     │                   │ Driver App    │                   │ WebSocket    │
│ (HTTP)        │                   │ (GPS push)    │                   │ (real-time)  │
└───────┬───────┘                   └───────┬───────┘                   └───────┬───────┘
        │                                   │                                     │
        v                                   v                                     v
┌───────────────────────────────────────────────────────────────────────────────────────┐
│                              API Gateway / BFF                                         │
└───────────────────────────────────────┬───────────────────────────────────────────────┘
                                        │
        ┌───────────────────────────────┼───────────────────────────────┐
        │                               │                               │
        v                               v                               v
┌───────────────┐               ┌───────────────┐               ┌───────────────┐
│ Matching Svc  │               │ Location Svc  │               │ Trip Service │
│ (find K,      │<──────────────│ (geo index,   │               │ (state       │
│  first-accept)│   query       │  Redis GEO /  │               │  machine)    │
└───────┬───────┘               │  QuadTree)    │               └───────┬───────┘
        │                       └───────┬───────┘                       │
        │                               │                               │
        v                               v                               v
┌───────────────┐               ┌───────────────┐               ┌───────────────┐
│ Pricing Svc   │               │ In-Memory    │               │ PostgreSQL / │
│ (surge, ETA)  │               │ Geospatial   │               │ Cassandra    │
└───────────────┘               │ Store        │               │ (trips)      │
                                └───────────────┘               └───────────────┘
                                        │
                                        v
                                ┌───────────────┐
                                │ Payment Svc   │
                                │ (post-trip)   │
                                └───────────────┘
```

---

## Mermaid: Trip Flow

```mermaid
stateDiagram-v2
    [*] --> REQUESTED
    REQUESTED --> MATCHED : Driver accepts
    REQUESTED --> CANCELLED : Rider/driver cancels
    MATCHED --> DRIVER_EN_ROUTE : Driver starts
    MATCHED --> CANCELLED : Cancellation
    DRIVER_EN_ROUTE --> IN_PROGRESS : Rider picked up
    IN_PROGRESS --> COMPLETED : Trip ends
    COMPLETED --> [*]
    CANCELLED --> [*]
```

---

## 30-SECOND REVISION BOX

```
GEO: Geohash (prefix=region), QuadTree (variable density), S2 (Google)
LOCATION: GPS every 4s → in-memory geo index; Redis GEO or custom
MATCHING: Nearest K, first-accept-wins; expand if no accept
TRIP: REQUESTED→MATCHED→DRIVER_EN_ROUTE→IN_PROGRESS→COMPLETED
ETA: Graph + historical + traffic
SURGE: Supply/demand per geohash; multiplier
TRACKING: WebSocket push every 4s
PAYMENT: Post-trip; idempotency
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
