# Design Instagram — Tricks and Recognition

> **Permanent Recall:** Instagram = **S3 + CDN** for media + **hybrid fan-out** for feed + **async processing** + **stories with TTL** + **explore as recommendation engine**. Recognized as a combined test of **media handling + feed generation**.

---

## Key Insights (Tricks)

| # | Insight | Why It Matters |
|---|---------|----------------|
| 1 | **S3 + CDN is the answer** | Never DB for media; CDN for global low-latency delivery |
| 2 | **Process images asynchronously** | Don't block upload; use queue + workers |
| 3 | **Store multiple resolutions** | Thumbnail, medium, full — right size for context |
| 4 | **Feed similar to Twitter** | Use hybrid fan-out; Redis timeline cache |
| 5 | **Stories = ephemeral data** | TTL; separate from permanent posts; cleanup needed |
| 6 | **Explore = recommendation engine** | Collaborative filtering, content-based, trending |
| 7 | **This tests both** | Media pipeline (storage, CDN, processing) + feed (fan-out, cache) |

---

## Recognition: What Problem Is This?

```
If they say: "Design Instagram"
They mean:  Photo sharing + feed + discovery
They test:  Media storage, CDN, feed generation, recommendations
```

---

## One-Liner Answers

| Question | One-Liner |
|----------|-----------|
| Where to store photos? | S3 (or GCS); never DB |
| How to deliver fast? | CDN (CloudFront); cache at edge |
| How to handle upload load? | Async processing; return 202 |
| Feed architecture? | Fan-out on write + Redis; hybrid for celebrities |
| Stories? | Ephemeral; 24h TTL; S3 lifecycle or dedicated store |
| Explore? | Recommendation engine; pre-compute per user |

---

## Pattern Recognition

```
Instagram ≈ Pinterest (visual) + Twitter (feed) + Snapchat (stories)
         ≠ Pure Twitter (no media pipeline)
         ≠ Pure Pinterest (different discovery model)
```

---

## Mermaid: System Recognition

```mermaid
flowchart TD
    A[Design Instagram] --> B[Media Platform]
    A --> C[Social Feed]
    B --> D[S3 + CDN + Async]
    C --> E[Fan-out + Redis]
    A --> F[Discovery]
    F --> G[Explore Algorithm]
```

---

## Interview Shortcuts

1. **First sentence:** "Instagram is media-centric; 200TB/day storage, so we need S3, CDN, and async processing."
2. **Feed:** "Same fan-out concept as Twitter, but we resolve media URLs from CDN."
3. **Stories:** "Ephemeral — 24h TTL, separate storage, cleanup via lifecycle or cron."
4. **Explore:** "Recommendation engine — collaborative filtering and trending."
5. **Scale:** "100:1 read:write — optimize for reads; CDN handles the load."

---

## When to Mention Each Trick

| Context | Trick to Emphasize |
|---------|-------------------|
| "Where do we store photos?" | S3 + CDN |
| "Upload is slow" | Async processing |
| "Feed is slow" | Fan-out + Redis + CDN URLs |
| "Add stories" | TTL, ephemeral, lifecycle |
| "Design explore" | Recommendation, pre-compute |

---

## Combined Test Recognition

Instagram = **Media system** (storage, processing, delivery) + **Social feed** (fan-out, timeline) + **Discovery** (explore, stories). Interviewers want to see you handle all three, with media as the differentiator.

---

## Quick Wins to Mention

- **Versioned URLs** — `photo_123_v2.jpg` so cache invalidation is explicit
- **WebP/AVIF** — Modern formats for smaller size
- **Lazy loading** — Load thumbnails first, full on demand
- **Preconnect** — Client preconnects to CDN domain

---

## Differentiation from Other Designs

| vs Twitter | vs Pinterest | vs TikTok |
|------------|--------------|-----------|
| Media in S3, not inline | Similar discovery; different board model | Video-first; different feed algorithm |
| Same fan-out concept | Similar CDN strategy | Short-form; loop; different UX |

---

## Recap: 7 Tricks

1. S3 + CDN for media
2. Async processing
3. Multiple resolutions
4. Hybrid fan-out
5. Stories = TTL
6. Explore = recommendations
7. Media + feed combined test

---

## Final Recognition

When you hear "Design Instagram," immediately think: **media pipeline first**, then feed, then explore/stories. The media pipeline is what separates a strong answer from a generic social app design.

---

## Memory Hook

"**SAC** — S3, Async, CDN. **FRES** — Fan-out, Redis, Explore, Stories." Repeat at start of design.

---

## One-Slide Summary

Media: S3 → Queue → Process → CDN. Feed: Fan-out → Redis. Explore: Recommendations. Stories: TTL.

---

## Recognition Test

"Design a photo-sharing app with feed" → Same as Instagram; apply SAC + FRES.
