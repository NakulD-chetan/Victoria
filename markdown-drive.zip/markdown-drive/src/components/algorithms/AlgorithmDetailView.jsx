import { useState, useEffect, Suspense, lazy, useRef } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { SkeletonDetail, SkeletonPlayground, SkeletonTutorial } from '../shared/Skeleton';

const LazyTutorialView = lazy(() => import('./TutorialView'));

const VISUALIZER_LAZY = {
  // Rate limiting (existing)
  'token-bucket': lazy(() => import('./TokenBucketVisualizer')),
  'leaky-bucket': lazy(() => import('./LeakyBucketVisualizer')),
  'fixed-window': lazy(() => import('./FixedWindowVisualizer')),
  'sliding-window-log': lazy(() => import('./SlidingLogVisualizer')),
  'sliding-window-counter': lazy(() => import('./SlidingCounterVisualizer')),
  'least-connections': lazy(() => import('./LeastConnVisualizer')),
  'morris-traversal': lazy(() => import('./MorrisTraversalVisualizer')),
  // Sorting (10)
  'bubble-sort': lazy(() => import('./BubbleSortVisualizer')),
  'selection-sort': lazy(() => import('./SelectionSortVisualizer')),
  'insertion-sort': lazy(() => import('./InsertionSortVisualizer')),
  'merge-sort': lazy(() => import('./MergeSortVisualizer')),
  'quick-sort': lazy(() => import('./QuickSortVisualizer')),
  'heap-sort': lazy(() => import('./HeapSortVisualizer')),
  'counting-sort': lazy(() => import('./CountingSortVisualizer')),
  'radix-sort': lazy(() => import('./RadixSortVisualizer')),
  'bucket-sort': lazy(() => import('./BucketSortVisualizer')),
  'tim-sort': lazy(() => import('./TimSortVisualizer')),
  // Searching (6)
  'binary-search': lazy(() => import('./BinarySearchVisualizer')),
  'interpolation-search': lazy(() => import('./InterpolationSearchVisualizer')),
  'jump-search': lazy(() => import('./JumpSearchVisualizer')),
  'exponential-search': lazy(() => import('./ExponentialSearchVisualizer')),
  'ternary-search': lazy(() => import('./TernarySearchVisualizer')),
  'fibonacci-search': lazy(() => import('./FibonacciSearchVisualizer')),
  // Graph (15)
  'bfs': lazy(() => import('./BFSVisualizer')),
  'dfs': lazy(() => import('./DFSVisualizer')),
  'dijkstra': lazy(() => import('./DijkstraVisualizer')),
  'bellman-ford': lazy(() => import('./BellmanFordVisualizer')),
  'floyd-warshall': lazy(() => import('./FloydWarshallVisualizer')),
  'prims-mst': lazy(() => import('./PrimsMSTVisualizer')),
  'kruskals-mst': lazy(() => import('./KruskalsMSTVisualizer')),
  'topological-sort': lazy(() => import('./TopologicalSortVisualizer')),
  'tarjan-scc': lazy(() => import('./TarjanSCCVisualizer')),
  'kosaraju-scc': lazy(() => import('./KosarajuSCCVisualizer')),
  'a-star-search': lazy(() => import('./AStarVisualizer')),
  'bipartite-check': lazy(() => import('./BipartiteCheckVisualizer')),
  'eulerian-path': lazy(() => import('./EulerianPathVisualizer')),
  'hamiltonian-path': lazy(() => import('./HamiltonianPathVisualizer')),
  'johnsons-algorithm': lazy(() => import('./JohnsonsVisualizer')),
  // Tree (10)
  'inorder-traversal-iterative': lazy(() => import('./InorderTraversalVisualizer')),
  'preorder-traversal-iterative': lazy(() => import('./PreorderTraversalVisualizer')),
  'postorder-traversal-iterative': lazy(() => import('./PostorderTraversalVisualizer')),
  'level-order-traversal': lazy(() => import('./LevelOrderTraversalVisualizer')),
  'avl-tree-rotation': lazy(() => import('./AVLTreeVisualizer')),
  'red-black-tree-insert': lazy(() => import('./RedBlackTreeVisualizer')),
  'segment-tree': lazy(() => import('./SegmentTreeVisualizer')),
  'fenwick-tree-bit': lazy(() => import('./FenwickTreeVisualizer')),
  'lowest-common-ancestor': lazy(() => import('./LCAVisualizer')),
  'trie-operations': lazy(() => import('./TrieVisualizer')),
  // Dynamic Programming (12)
  'fibonacci-dp': lazy(() => import('./FibonacciDPVisualizer')),
  'zero-one-knapsack': lazy(() => import('./KnapsackVisualizer')),
  'longest-common-subsequence': lazy(() => import('./LCSVisualizer')),
  'longest-increasing-subsequence': lazy(() => import('./LISVisualizer')),
  'edit-distance': lazy(() => import('./EditDistanceVisualizer')),
  'coin-change': lazy(() => import('./CoinChangeVisualizer')),
  'matrix-chain-multiplication': lazy(() => import('./MatrixChainVisualizer')),
  'rod-cutting': lazy(() => import('./RodCuttingVisualizer')),
  'subset-sum': lazy(() => import('./SubsetSumVisualizer')),
  'palindrome-partitioning': lazy(() => import('./PalindromePartVisualizer')),
  'egg-drop-problem': lazy(() => import('./EggDropVisualizer')),
  'catalan-number': lazy(() => import('./CatalanNumberVisualizer')),
  // String (10)
  'kmp-pattern-matching': lazy(() => import('./KMPVisualizer')),
  'rabin-karp': lazy(() => import('./RabinKarpVisualizer')),
  'z-algorithm': lazy(() => import('./ZAlgorithmVisualizer')),
  'manachers-algorithm': lazy(() => import('./ManachersVisualizer')),
  'suffix-array': lazy(() => import('./SuffixArrayVisualizer')),
  'aho-corasick': lazy(() => import('./AhoCorasickVisualizer')),
  'boyer-moore': lazy(() => import('./BoyerMooreVisualizer')),
  'longest-palindromic-substring': lazy(() => import('./LongestPalSubVisualizer')),
  'string-hashing': lazy(() => import('./StringHashingVisualizer')),
  'levenshtein-distance': lazy(() => import('./LevenshteinVisualizer')),
  // Greedy (7)
  'activity-selection': lazy(() => import('./ActivitySelectionVisualizer')),
  'huffman-coding': lazy(() => import('./HuffmanCodingVisualizer')),
  'fractional-knapsack': lazy(() => import('./FractionalKnapsackVisualizer')),
  'job-sequencing': lazy(() => import('./JobSequencingVisualizer')),
  'minimum-platforms': lazy(() => import('./MinimumPlatformsVisualizer')),
  'gas-station': lazy(() => import('./GasStationVisualizer')),
  'interval-scheduling': lazy(() => import('./IntervalSchedulingVisualizer')),
  // Backtracking (5)
  'n-queens': lazy(() => import('./NQueensVisualizer')),
  'sudoku-solver': lazy(() => import('./SudokuSolverVisualizer')),
  'rat-in-a-maze': lazy(() => import('./RatInMazeVisualizer')),
  'word-search': lazy(() => import('./WordSearchVisualizer')),
  'hamiltonian-cycle': lazy(() => import('./HamiltonianCycleVisualizer')),
  // Divide & Conquer + Hashing (10)
  'merge-sort-divide-conquer': lazy(() => import('./MergeSortDCVisualizer')),
  'quick-select': lazy(() => import('./QuickSelectVisualizer')),
  'closest-pair-of-points': lazy(() => import('./ClosestPairVisualizer')),
  'strassen-matrix-multiplication': lazy(() => import('./StrassenVisualizer')),
  'karatsuba-multiplication': lazy(() => import('./KaratsubaVisualizer')),
  'separate-chaining': lazy(() => import('./SeparateChainingVisualizer')),
  'cuckoo-hashing': lazy(() => import('./CuckooHashingVisualizer')),
  'consistent-hashing': lazy(() => import('./ConsistentHashingVisualizer')),
  'bloom-filter': lazy(() => import('./BloomFilterVisualizer')),
  'open-addressing': lazy(() => import('./OpenAddressingVisualizer')),
  // Misc (15)
  'union-find-basic': lazy(() => import('./UnionFindBasicVisualizer')),
  'union-by-rank': lazy(() => import('./UnionByRankVisualizer')),
  'path-compression': lazy(() => import('./PathCompressionVisualizer')),
  'floyds-cycle-detection': lazy(() => import('./FloydsCycleVisualizer')),
  'reverse-linked-list': lazy(() => import('./ReverseLinkedListVisualizer')),
  'merge-two-sorted-lists': lazy(() => import('./MergeSortedListsVisualizer')),
  'lru-cache': lazy(() => import('./LRUCacheVisualizer')),
  'next-greater-element': lazy(() => import('./NextGreaterElementVisualizer')),
  'min-stack': lazy(() => import('./MinStackVisualizer')),
  'sliding-window-maximum': lazy(() => import('./SlidingWindowMaxVisualizer')),
  'monotonic-stack': lazy(() => import('./MonotonicStackVisualizer')),
  'brian-kernighans-algorithm': lazy(() => import('./BrianKernighansVisualizer')),
  'xor-swap': lazy(() => import('./XorSwapVisualizer')),
  'power-set': lazy(() => import('./PowerSetVisualizer')),
  'gray-code': lazy(() => import('./GrayCodeVisualizer')),
};

const API_BASE = '/api';
const cache = new Map();

export default function AlgorithmDetailView({ slug }) {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('introduction');
  const [langTab, setLangTab] = useState('english');
  const fetchedRef = useRef(null);

  useEffect(() => {
    if (fetchedRef.current === slug && config) return;
    fetchedRef.current = slug;

    if (cache.has(slug)) {
      setConfig(cache.get(slug));
      setLoading(false);
      return;
    }

    setLoading(true);
    fetch(`${API_BASE}/algorithms/${slug}`)
      .then(res => {
        if (!res.ok) throw new Error('API error');
        return res.json();
      })
      .then(data => {
        cache.set(slug, data);
        setConfig(data);
        setLoading(false);
      })
      .catch(() => {
        setConfig(null);
        setLoading(false);
      });
  }, [slug]);

  const navigate = (href) => {
    window.history.pushState(null, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  if (loading) {
    return (
      <div className="dc-detail">
        <div className="dc-detail__topbar">
          <button className="dc-detail__back" onClick={() => navigate('/algorithms')}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="19" y1="12" x2="5" y2="12" />
              <polyline points="12 19 5 12 12 5" />
            </svg>
            Back
          </button>
        </div>
        <SkeletonDetail />
      </div>
    );
  }

  if (!config) {
    return (
      <div className="dc-detail">
        <div className="dc-detail__topbar">
          <button className="dc-detail__back" onClick={() => navigate('/algorithms')}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="19" y1="12" x2="5" y2="12" />
              <polyline points="12 19 5 12 12 5" />
            </svg>
            Back
          </button>
        </div>
        <div className="dc-empty">Algorithm not found.</div>
      </div>
    );
  }

  const introContent = langTab === 'hinglish' ? config.introHinglish : config.introEnglish;
  const vizKey = config.visualizerKey || config.meta?.slug;
  const LazyVisualizer = VISUALIZER_LAZY[vizKey];

  return (
    <div className="dc-detail">
      <div className="dc-detail__topbar">
        <button className="dc-detail__back" onClick={() => navigate('/algorithms')}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="19" y1="12" x2="5" y2="12" />
            <polyline points="12 19 5 12 12 5" />
          </svg>
          Back
        </button>

        <div className="dc-detail__center-tabs">
          <button
            className={`dc-detail__tab ${activeTab === 'introduction' ? 'dc-detail__tab--active' : ''}`}
            onClick={() => setActiveTab('introduction')}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
              <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
            </svg>
            Introduction
          </button>
          <button
            className={`dc-detail__tab ${activeTab === 'tutorial' ? 'dc-detail__tab--active' : ''}`}
            onClick={() => setActiveTab('tutorial')}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 10v6M2 10l10-5 10 5-10 5z" />
              <path d="M6 12v5c0 1.66 2.69 3 6 3s6-1.34 6-3v-5" />
            </svg>
            Tutorial
          </button>
          <button
            className={`dc-detail__tab ${activeTab === 'playground' ? 'dc-detail__tab--active' : ''}`}
            onClick={() => setActiveTab('playground')}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="5 3 19 12 5 21 5 3" />
            </svg>
            Playground
          </button>
        </div>

        <div className="dc-detail__meta">
          <span className="dc-detail__icon">{config.meta.icon}</span>
          <span className="dc-detail__name">{config.meta.title}</span>
        </div>
      </div>

      <div className="dc-detail__content">
        {activeTab === 'introduction' && (
          <div className="dc-intro">
            <div className="dc-intro__lang-tabs">
              <button
                className={`dc-intro__lang-tab ${langTab === 'english' ? 'dc-intro__lang-tab--active' : ''}`}
                onClick={() => setLangTab('english')}
              >
                <span className="dc-intro__lang-flag">EN</span>
                English
              </button>
              <button
                className={`dc-intro__lang-tab ${langTab === 'hinglish' ? 'dc-intro__lang-tab--active' : ''}`}
                onClick={() => setLangTab('hinglish')}
              >
                <span className="dc-intro__lang-flag">HI</span>
                Hinglish
              </button>
            </div>
            <div className="dc-intro__body">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {introContent}
              </ReactMarkdown>
            </div>
          </div>
        )}

        {activeTab === 'tutorial' && (
          <Suspense fallback={<SkeletonTutorial />}>
            <LazyTutorialView config={config} />
          </Suspense>
        )}

        {activeTab === 'playground' && LazyVisualizer && (
          <Suspense fallback={<SkeletonPlayground />}>
            <LazyVisualizer config={config} />
          </Suspense>
        )}
      </div>
    </div>
  );
}
