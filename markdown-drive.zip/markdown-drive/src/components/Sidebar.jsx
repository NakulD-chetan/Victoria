import { useState, memo, useCallback, useRef, useEffect } from 'react';
import { SidebarAd } from './AdBanner';
import { firebaseLogout } from './AuthGate';

const Sidebar = memo(function Sidebar({
  folders,
  foldersLoading,
  selectedFolder,
  selectedFile,
  onSelectFile,
  onDeleteFile,
  onDeleteFolder,
  onCreateFolder,
  onRenameFolder,
  onUpload,
  onUploadFiles,
  onMoveFile,
  onNestFolder,
  onDeleteAll,
  onDeleteMultiple,
  onMoveToRoot,
  onShare,
  uploadProgress,
  isOpen,
  onClose,
  folderColors,
  theme,
  onThemeToggle,
  onChatToggle,
  chatOpen,
  onHome,
  user,
  isPremium,
  onOpenPremium,
  onOpenReferral,
}) {
  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef(null);

  useEffect(() => {
    if (!profileOpen) return;
    const handleClick = (e) => {
      if (profileRef.current && !profileRef.current.contains(e.target)) setProfileOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [profileOpen]);

  const userPhoto = user?.photoURL;
  const userName = user?.name || user?.displayName || 'User';
  const userEmail = user?.email;
  const initials = userName.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
  const [expandedFolders, setExpandedFolders] = useState(new Set());

  useEffect(() => {
    if (selectedFolder) {
      setExpandedFolders(prev => {
        const next = new Set(prev);
        let changed = false;
        const parts = selectedFolder.split('/');
        let accum = '';
        for (const part of parts) {
          accum = accum ? `${accum}/${part}` : part;
          if (!next.has(accum)) { next.add(accum); changed = true; }
        }
        return changed ? next : prev;
      });
    }
  }, [selectedFolder]);

  const [newFolderName, setNewFolderName] = useState('');
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuOpen, setMenuOpen] = useState(null);
  const [renamingFolder, setRenamingFolder] = useState(null);
  const [renameValue, setRenameValue] = useState('');
  const [notes, setNotes] = useState(() => {
    try { return JSON.parse(localStorage.getItem('md-folder-notes') || '{}'); }
    catch { return {}; }
  });
  const [editingNote, setEditingNote] = useState(null);
  const [noteValue, setNoteValue] = useState('');
  const [dragOver, setDragOver] = useState(null);
  const [dropIndicator, setDropIndicator] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [dragFile, setDragFile] = useState(null);
  const [dragFolderPath, setDragFolderPath] = useState(null);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedPaths, setSelectedPaths] = useState(new Set());
  const menuRef = useRef(null);
  const folderInputRef = useRef(null);

  useEffect(() => {
    const close = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(null);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, []);

  const toggleFolder = useCallback((path) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  }, []);

  const handleCreateFolder = useCallback(() => {
    if (newFolderName.trim()) {
      onCreateFolder(newFolderName.trim());
      setNewFolderName('');
      setShowNewFolder(false);
    }
  }, [newFolderName, onCreateFolder]);

  const handleRename = useCallback((oldPath) => {
    if (renameValue.trim() && onRenameFolder) {
      onRenameFolder(oldPath, renameValue.trim());
    }
    setRenamingFolder(null);
    setRenameValue('');
  }, [renameValue, onRenameFolder]);

  const handleSaveNote = useCallback((folderPath) => {
    const updated = { ...notes, [folderPath]: noteValue };
    if (!noteValue.trim()) delete updated[folderPath];
    setNotes(updated);
    localStorage.setItem('md-folder-notes', JSON.stringify(updated));
    setEditingNote(null);
  }, [noteValue, notes]);

  const handleDrop = useCallback(async (e, targetFolderPath) => {
    e.preventDefault();
    e.stopPropagation();
    setDragOver(null);
    setDropIndicator(null);

    if (dragFolderPath && dragFolderPath !== targetFolderPath) {
      if (!targetFolderPath) {
        if (dragFolderPath.includes('/')) {
          onMoveToRoot?.(dragFolderPath);
        }
      } else if (!targetFolderPath.startsWith(dragFolderPath + '/')) {
        onNestFolder(dragFolderPath, targetFolderPath);
      }
      setDragFolderPath(null);
      return;
    }
    setDragFolderPath(null);

    if (dragFile && targetFolderPath) {
      if (dragFile.folder !== targetFolderPath) {
        onMoveFile(dragFile.folder, dragFile.name, targetFolderPath);
      }
      setDragFile(null);
      return;
    }

    const items = e.dataTransfer.items;
    const files = [];

    if (items) {
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.webkitGetAsEntry) {
          const entry = item.webkitGetAsEntry();
          if (entry) {
            await traverseEntry(entry, files, '');
          }
        } else if (item.kind === 'file') {
          const f = item.getAsFile();
          if (f && isAccepted(f.name)) files.push({ file: f, folder: targetFolderPath || 'General' });
        }
      }
    } else {
      for (const f of e.dataTransfer.files) {
        if (isAccepted(f.name)) files.push({ file: f, folder: targetFolderPath || 'General' });
      }
    }

    if (files.length > 0) {
      setUploading(true);
      await onUploadFiles(files, targetFolderPath);
      setUploading(false);
    }
  }, [dragFile, dragFolderPath, onMoveFile, onNestFolder, onMoveToRoot, onUploadFiles]);

  const handleFolderUpload = useCallback(async (e) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files = [];
    for (const f of fileList) {
      if (isAccepted(f.name)) {
        const path = f.webkitRelativePath || f.name;
        const parts = path.split('/').filter(Boolean);
        const folderParts = parts.slice(0, -1);
        const folderName = folderParts.length > 0 ? folderParts.join('/') : 'General';
        files.push({ file: f, folder: folderName });
      }
    }
    if (files.length > 0) {
      setUploading(true);
      await onUploadFiles(files);
      setUploading(false);
    }
    e.target.value = '';
  }, [onUploadFiles]);

  const filterTree = useCallback((tree) => {
    if (!searchQuery) return tree;
    const q = searchQuery.toLowerCase();
    return tree.map(f => {
      const matchedFiles = f.files.filter(file => file.name.toLowerCase().includes(q));
      const matchedChildren = filterTree(f.children || []);
      const folderMatches = f.name.toLowerCase().includes(q);
      if (folderMatches || matchedFiles.length > 0 || matchedChildren.length > 0) {
        return { ...f, files: folderMatches ? f.files : matchedFiles, children: matchedChildren };
      }
      return null;
    }).filter(Boolean);
  }, [searchQuery]);

  const toggleSelect = useCallback((path) => {
    setSelectedPaths(prev => {
      const next = new Set(prev);
      if (next.has(path)) next.delete(path);
      else next.add(path);
      return next;
    });
  }, []);

  const collectAllPaths = useCallback((list) => {
    const paths = [];
    const walk = (items) => {
      for (const f of items) {
        paths.push(f.path);
        if (f.children?.length) walk(f.children);
      }
    };
    walk(list);
    return paths;
  }, []);

  const handleSelectAll = useCallback(() => {
    setSelectedPaths(new Set(collectAllPaths(folders)));
  }, [folders, collectAllPaths]);

  const handleDeleteSelected = useCallback(async () => {
    if (selectedPaths.size === 0) return;
    const paths = [...selectedPaths];
    paths.sort((a, b) => b.length - a.length);
    await onDeleteMultiple?.(paths);
    setSelectedPaths(new Set());
    setSelectMode(false);
  }, [selectedPaths, onDeleteMultiple]);

  const filteredFolders = filterTree(folders);

  const renderFolder = (folder, depth = 0, inheritedColor = null) => {
    const color = inheritedColor || folderColors?.[folder.path] || null;
    return (
    <div
      key={folder.path}
      className={`sidebar__folder ${dragOver === folder.path ? 'sidebar__folder--dragover' : ''} ${dropIndicator === folder.path ? 'sidebar__folder--drop-target' : ''}`}
      onDragOver={e => {
        e.preventDefault(); e.stopPropagation();
        setDragOver(folder.path);
        if (dragFolderPath && dragFolderPath !== folder.path) {
          setDropIndicator(folder.path);
        }
      }}
      onDragLeave={e => { e.stopPropagation(); setDragOver(null); setDropIndicator(null); }}
      onDrop={e => handleDrop(e, folder.path)}
    >
      {renamingFolder === folder.path ? (
        <div className="sidebar__rename">
          <input value={renameValue} onChange={e => setRenameValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleRename(folder.path); if (e.key === 'Escape') setRenamingFolder(null); }} autoFocus />
          <button onClick={() => handleRename(folder.path)} className="sidebar__new-folder-ok">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
          </button>
        </div>
      ) : (
        <button
          className={`sidebar__folder-btn ${selectedFolder === folder.path ? 'sidebar__folder-btn--active' : ''} ${dragFolderPath === folder.path ? 'sidebar__folder-btn--dragging' : ''} ${selectedPaths.has(folder.path) ? 'sidebar__folder-btn--selected' : ''}`}
          onClick={() => selectMode ? toggleSelect(folder.path) : toggleFolder(folder.path)}
          draggable={!selectMode}
          onDragStart={(e) => { if (selectMode) { e.preventDefault(); return; } e.stopPropagation(); setDragFolderPath(folder.path); e.dataTransfer.setData('text/plain', folder.path); e.dataTransfer.effectAllowed = 'move'; }}
          onDragEnd={() => { setDragFolderPath(null); setDragOver(null); setDropIndicator(null); }}
        >
          {selectMode ? (
            <span className={`sidebar__checkbox ${selectedPaths.has(folder.path) ? 'sidebar__checkbox--checked' : ''}`}>
              {selectedPaths.has(folder.path) && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12" /></svg>}
            </span>
          ) : (
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: expandedFolders.has(folder.path) ? 'rotate(90deg)' : 'rotate(0)', transition: 'transform 0.15s', flexShrink: 0 }}>
              <polyline points="9 18 15 12 9 6" />
            </svg>
          )}
          {color && <span className="sidebar__color-dot" style={{ background: color }} />}
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={color || 'currentColor'} strokeWidth="2" style={{ flexShrink: 0 }}>
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
          </svg>
          <span className="sidebar__folder-name">{folder.name}</span>
          <span className="sidebar__folder-count">{folder.fileCount}</span>
          {(folder.children?.length > 0) && (
            <span className="sidebar__subfolder-badge" title={`${folder.children.length} subfolder(s)`}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" opacity="0.5">
                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
              </svg>
            </span>
          )}
          <span role="button" tabIndex={0} className="sidebar__menu-btn" onClick={e => { e.stopPropagation(); setMenuOpen(menuOpen === folder.path ? null : folder.path); }} onKeyDown={e => { if (e.key === 'Enter') { e.stopPropagation(); setMenuOpen(menuOpen === folder.path ? null : folder.path); } }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="12" cy="5" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="12" cy="19" r="1.5" />
            </svg>
          </span>
        </button>
      )}

      {menuOpen === folder.path && (
        <div className="sidebar__dropdown" ref={menuRef}>
          <button onClick={() => { setRenamingFolder(folder.path); setRenameValue(folder.name); setMenuOpen(null); }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" /></svg>
            Rename
          </button>
          <button onClick={() => { onShare?.(folder.path, folder.name); setMenuOpen(null); }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></svg>
            Share
          </button>
          <button onClick={() => { setEditingNote(folder.path); setNoteValue(notes[folder.path] || ''); setMenuOpen(null); }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><line x1="16" y1="13" x2="8" y2="13" /><line x1="16" y1="17" x2="8" y2="17" /></svg>
            {notes[folder.path] ? 'Edit Note' : 'Add Note'}
          </button>
          {folder.path.includes('/') && (
            <button onClick={() => { onMoveToRoot?.(folder.path); setMenuOpen(null); }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="17 11 12 6 7 11" /><line x1="12" y1="6" x2="12" y2="18" /></svg>
              Move to Root
            </button>
          )}
          <button className="sidebar__dropdown-danger" onClick={() => { onDeleteFolder(folder.path); setMenuOpen(null); }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
            Delete
          </button>
        </div>
      )}

      {editingNote === folder.path ? (
        <div className="sidebar__note-edit">
          <textarea value={noteValue} onChange={e => setNoteValue(e.target.value)} placeholder="Add a note..." rows={2} autoFocus />
          <div className="sidebar__note-actions">
            <button onClick={() => handleSaveNote(folder.path)}>Save</button>
            <button onClick={() => setEditingNote(null)}>Cancel</button>
          </div>
        </div>
      ) : notes[folder.path] ? (
        <div className="sidebar__note" onClick={() => { setEditingNote(folder.path); setNoteValue(notes[folder.path]); }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /></svg>
          <span>{notes[folder.path]}</span>
        </div>
      ) : null}

      {expandedFolders.has(folder.path) && (
        <div className="sidebar__children" style={color ? { borderLeftColor: `${color}40` } : undefined}>
          {(folder.children || []).map(child => renderFolder(child, depth + 1, color))}
          {folder.files.length > 0 && (
            <div className="sidebar__files">
              {folder.files.map(file => (
                <button
                  key={file.name}
                  className={`sidebar__file-btn ${selectedFolder === folder.path && selectedFile === file.name ? 'sidebar__file-btn--active' : ''}`}
                  onClick={() => onSelectFile(folder.path, file.name)}
                  draggable
                  onDragStart={(e) => { e.stopPropagation(); setDragFile({ folder: folder.path, name: file.name }); e.dataTransfer.setData('text/plain', file.name); e.dataTransfer.effectAllowed = 'move'; }}
                  onDragEnd={() => { setDragFile(null); setDragOver(null); setDropIndicator(null); }}
                >
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" />
                  </svg>
                  <span className="sidebar__file-name">{file.title}</span>
                  <span role="button" tabIndex={0} className="sidebar__delete-btn" onClick={e => { e.stopPropagation(); onDeleteFile(folder.path, file.name); }} onKeyDown={e => { if (e.key === 'Enter') { e.stopPropagation(); onDeleteFile(folder.path, file.name); } }} title="Delete">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                    </svg>
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
  };

  return (
    <aside className={`sidebar ${isOpen ? 'sidebar--open' : ''}`}>
      <div className="sidebar__header">
        <button className="sidebar__logo" onClick={onHome}>
          <svg width="16" height="16" viewBox="0 0 100 100">
            <defs><linearGradient id="sideGrad" x1="0.15" y1="0.1" x2="0.85" y2="0.9"><stop offset="0%" stopColor="#6366F1" /><stop offset="100%" stopColor="#10B981" /></linearGradient></defs>
            <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#sideGrad)" />
            <rect x="35" y="49" width="30" height="3.5" rx="1.75" fill="white" opacity="0.92" />
            <rect x="35" y="59" width="22" height="3.5" rx="1.75" fill="white" opacity="0.65" />
          </svg>
          InkDrop
        </button>
        <div className="sidebar__header-icons">
          <button
            className={`sidebar__icon-btn ${chatOpen ? 'sidebar__icon-btn--active' : ''} ${!isPremium ? 'sidebar__icon-btn--locked' : ''}`}
            onClick={isPremium ? onChatToggle : onOpenPremium}
            title={isPremium ? 'AI Chat' : 'AI Chat (Premium)'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" /></svg>
            {!isPremium && <span className="sidebar__lock-badge">PRO</span>}
          </button>
          <button className="sidebar__icon-btn" onClick={onThemeToggle} title={theme === 'dark' ? 'Light mode' : 'Dark mode'}>
            {theme === 'dark' ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5" /><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" /></svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" /></svg>
            )}
          </button>
          <button className="sidebar__close" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>
      </div>

      {selectedFile && (() => {
        const rootFolder = selectedFolder?.split('/')[0];
        const backColor = folderColors?.[rootFolder] || folderColors?.[selectedFolder] || 'var(--accent)';
        return (
          <div className="sidebar__back">
            <button className="sidebar__back-btn" onClick={onHome}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6" />
              </svg>
              <span className="sidebar__back-dot" style={{ background: backColor }} />
              <span className="sidebar__back-label">{selectedFolder?.split('/').pop() || 'Home'}</span>
            </button>
          </div>
        );
      })()}

      <div className="sidebar__search">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input type="text" placeholder="Search files..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />
      </div>

      <div className="sidebar__actions">
        <button className="sidebar__action-btn sidebar__action-btn--primary" onClick={onUpload}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Upload
        </button>
        <button className="sidebar__action-btn" onClick={() => folderInputRef.current?.click()}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
          </svg>
          Folder
        </button>
        <button className="sidebar__action-btn" onClick={() => setShowNewFolder(true)}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
          </svg>
          New
        </button>
      </div>

      <input ref={folderInputRef} type="file" webkitdirectory="" directory="" multiple hidden onChange={handleFolderUpload} />

      <div className="sidebar__sections">
        <div className="sidebar__sections-label">Sections</div>
        {[
          { href: '/algorithms', label: 'Algorithms', icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12" /></svg> },
          { href: '/systemdesign', label: 'System Design', icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" /></svg> },
          { href: '/code', label: 'Code Editor', icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="4 17 10 11 4 5" /><line x1="12" y1="19" x2="20" y2="19" /></svg> },
          { href: '/canvas', label: 'Canvas', icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 19l7-7 3 3-7 7-3-3z" /><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" /><path d="M2 2l7.586 7.586" /><circle cx="11" cy="11" r="2" /></svg> },
          { href: '/notes', label: 'Notes', icon: <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="16" y1="13" x2="8" y2="13" /><line x1="16" y1="17" x2="8" y2="17" /></svg> },
        ].map(({ href, label, icon }) => {
          const isActive = window.location.pathname.startsWith(href);
          return (
            <button key={href} className={`sidebar__nav-link ${isActive ? 'sidebar__nav-link--active' : ''}`} onClick={() => { window.history.pushState(null, '', href); window.dispatchEvent(new PopStateEvent('popstate')); }}>
              {icon}
              {label}
              <svg className="sidebar__nav-link__arrow" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
            </button>
          );
        })}
      </div>

      {showNewFolder && (
        <div className="sidebar__new-folder">
          <input type="text" placeholder="Folder name..." value={newFolderName} onChange={e => setNewFolderName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleCreateFolder()} autoFocus />
          <button onClick={handleCreateFolder} className="sidebar__new-folder-ok">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12" /></svg>
          </button>
          <button onClick={() => setShowNewFolder(false)} className="sidebar__new-folder-cancel">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
          </button>
        </div>
      )}

      <nav
        className={`sidebar__nav ${dragOver === '__nav__' ? 'sidebar__nav--dragover' : ''}`}
        onDragOver={e => { e.preventDefault(); if (!dragOver || dragOver === '__nav__') setDragOver('__nav__'); }}
        onDragLeave={(e) => { if (e.currentTarget === e.target) { setDragOver(null); setDropIndicator(null); } }}
        onDrop={e => handleDrop(e, null)}
      >
        {selectMode && (
          <div className="sidebar__select-toolbar">
            <button className="sidebar__select-action" onClick={handleSelectAll}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><polyline points="16 8 10 16 8 13" /></svg>
              All
            </button>
            <button className="sidebar__select-action sidebar__select-action--danger" onClick={handleDeleteSelected} disabled={selectedPaths.size === 0}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
              Delete ({selectedPaths.size})
            </button>
            <button className="sidebar__select-action" onClick={() => { setSelectMode(false); setSelectedPaths(new Set()); }}>Cancel</button>
          </div>
        )}
        {dragFolderPath && dragOver === '__nav__' && dragFolderPath.includes('/') && (
          <div className="sidebar__root-drop-zone">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="17 11 12 6 7 11" /><line x1="12" y1="6" x2="12" y2="18" /></svg>
            Drop here to move to root
          </div>
        )}
        {foldersLoading ? (
          <div className="sidebar__skeletons">
            {[1,2,3,4].map(i => (
              <div key={i} className="sidebar__skeleton-item">
                <div className="skeleton-line" style={{ width: `${50 + i * 10}%`, height: '10px', marginBottom: '6px' }} />
              </div>
            ))}
          </div>
        ) : filteredFolders.length === 0 ? (
          <div className="sidebar__empty">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.3">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
            </svg>
            <p>No files yet</p>
            <p className="sidebar__empty-hint">Drag files here or click Upload</p>
          </div>
        ) : (
          filteredFolders.map(folder => renderFolder(folder, 0))
        )}

        {(uploading || uploadProgress?.active) && (
          <div className="sidebar__upload-progress">
            <div className="sidebar__upload-progress-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="17 8 12 3 7 8" /><line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            </div>
            <div className="sidebar__upload-progress-info">
              <span className="sidebar__upload-progress-text">
                {uploadProgress ? `Uploading ${uploadProgress.done}/${uploadProgress.total} files...` : 'Uploading...'}
              </span>
              <div className="sidebar__upload-progress-bar">
                <div
                  className="sidebar__upload-progress-fill"
                  style={{ width: uploadProgress ? `${Math.round((uploadProgress.done / uploadProgress.total) * 100)}%` : '50%' }}
                />
              </div>
            </div>
          </div>
        )}
        {uploadProgress && !uploadProgress.active && (
          <div className="sidebar__upload-done">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>
            <span>{uploadProgress.total} files uploaded</span>
          </div>
        )}

        {filteredFolders.length > 0 && !foldersLoading && !selectMode && (
          <div className="sidebar__bulk-actions">
            <button className="sidebar__bulk-btn" onClick={() => { setSelectMode(true); setSelectedPaths(new Set()); }}>
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><polyline points="16 8 10 16 8 13" /></svg>
              Select
            </button>
            {filteredFolders.length > 1 && (
              <>
                {!confirmDeleteAll ? (
                  <button className="sidebar__bulk-btn sidebar__bulk-btn--danger" onClick={() => setConfirmDeleteAll(true)}>
                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                    Remove All
                  </button>
                ) : (
                  <div className="sidebar__confirm-bar">
                    <span>Delete all {filteredFolders.length} folders?</span>
                    <button className="sidebar__confirm-yes" onClick={() => { onDeleteAll?.(); setConfirmDeleteAll(false); }}>Yes</button>
                    <button className="sidebar__confirm-no" onClick={() => setConfirmDeleteAll(false)}>No</button>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        <SidebarAd isPremium={false} />
      </nav>

      <div className="sidebar__footer" ref={profileRef}>
        <button className="sidebar__profile-btn" onClick={() => setProfileOpen(p => !p)}>
          <div className="sidebar__avatar">
            {userPhoto ? (
              <img src={userPhoto} alt={userName} referrerPolicy="no-referrer" />
            ) : (
              <span className="sidebar__avatar-fallback">{initials}</span>
            )}
          </div>
          <span className="sidebar__profile-name">{userName}</span>
          {isPremium && <span className="sidebar__pro-badge">PRO</span>}
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginLeft: 'auto', opacity: 0.4 }}>
            <polyline points="6 9 12 15 18 9" />
          </svg>
        </button>

        {profileOpen && (
          <div className="sidebar__profile-dropdown">
            {!isPremium && (
              <button className="sidebar__profile-item sidebar__profile-item--upgrade" onClick={() => { setProfileOpen(false); onOpenPremium?.(); }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                Upgrade to Pro
              </button>
            )}
            <button className="sidebar__profile-item" onClick={() => { setProfileOpen(false); onOpenReferral?.(); }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" /></svg>
              Refer & Earn
            </button>
            <div className="sidebar__profile-divider" />
            <button className="sidebar__profile-item sidebar__profile-item--danger" onClick={() => { setProfileOpen(false); firebaseLogout(); }}>
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>
              Sign out
            </button>
          </div>
        )}
      </div>
    </aside>
  );
});

function isAccepted(name) {
  return /\.(md|markdown|txt|mdx|zip)$/i.test(name);
}

async function traverseEntry(entry, files, parentPath) {
  if (entry.isFile) {
    const file = await new Promise(resolve => entry.file(resolve));
    if (isAccepted(file.name)) {
      const folder = parentPath || 'General';
      files.push({ file, folder });
    }
  } else if (entry.isDirectory) {
    const currentPath = parentPath ? `${parentPath}/${entry.name}` : entry.name;
    const reader = entry.createReader();
    let allEntries = [];
    const readBatch = () => new Promise(resolve => reader.readEntries(resolve));
    let batch = await readBatch();
    while (batch.length > 0) {
      allEntries = allEntries.concat(batch);
      batch = await readBatch();
    }
    for (const child of allEntries) {
      if (child.isFile) {
        const file = await new Promise(resolve => child.file(resolve));
        if (isAccepted(file.name)) {
          files.push({ file, folder: currentPath });
        }
      } else if (child.isDirectory) {
        await traverseEntry(child, files, currentPath);
      }
    }
  }
}

export default Sidebar;
