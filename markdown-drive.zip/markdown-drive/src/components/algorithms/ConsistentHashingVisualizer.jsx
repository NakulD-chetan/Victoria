import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const RingCanvas = forwardRef(function RingCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({ servers: [], keys: [], activeKey: null, arc: null });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function draw() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 320;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const cx = W / 2;
      const cy = H / 2;
      const R = Math.min(W, H) * 0.36;
      const { servers, keys, activeKey, arc } = stateRef.current;

      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.strokeStyle = '#57534e';
      ctx.lineWidth = 3;
      ctx.stroke();

      servers.forEach((s) => {
        const a = (s.pos / 360) * Math.PI * 2 - Math.PI / 2;
        const x = cx + Math.cos(a) * R;
        const y = cy + Math.sin(a) * R;
        ctx.beginPath();
        ctx.arc(x, y, 10, 0, Math.PI * 2);
        ctx.fillStyle = '#b2f2bb';
        ctx.fill();
        ctx.strokeStyle = '#14532d';
        ctx.stroke();
        ctx.fillStyle = '#14532d';
        ctx.font = 'bold 9px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(s.name, x, y + 24);
      });

      keys.forEach((k) => {
        const a = (k.pos / 360) * Math.PI * 2 - Math.PI / 2;
        const x = cx + Math.cos(a) * (R - 28);
        const y = cy + Math.sin(a) * (R - 28);
        ctx.beginPath();
        ctx.arc(x, y, 6, 0, Math.PI * 2);
        ctx.fillStyle = k.id === activeKey ? '#ffd43b' : '#a5d8ff';
        ctx.fill();
        ctx.strokeStyle = '#0c4a6e';
        ctx.stroke();
      });

      if (arc && arc.from != null && arc.to != null) {
        const a0 = (arc.from / 360) * Math.PI * 2 - Math.PI / 2;
        const a1 = (arc.to / 360) * Math.PI * 2 - Math.PI / 2;
        ctx.beginPath();
        ctx.arc(cx, cy, R - 6, a0, a1, arc.ccw);
        ctx.strokeStyle = '#e03131';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      raf = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function nextServer(sorted, pos) {
  return sorted.find((s) => s.pos >= pos) || sorted[0];
}

function generateSteps(servers, keyList) {
  const steps = [];
  const sorted = [...servers].sort((a, b) => a.pos - b.pos);
  steps.push({ type: 'ring', servers, keys: [], activeKey: null, arc: null, message: 'Servers placed on hash ring' });
  const placed = [];
  keyList.forEach((k) => {
    const target = nextServer(sorted, k.pos);
    steps.push({
      type: 'route',
      servers,
      keys: [...placed],
      activeKey: k.id,
      arc: { from: k.pos, to: target.pos, ccw: false },
      message: `Key ${k.label}@${k.pos}° routes clockwise to ${target.name}`,
    });
    placed.push({ ...k, server: target.name });
    steps.push({
      type: 'assign',
      servers,
      keys: [...placed],
      activeKey: null,
      arc: null,
      message: `${k.label} → ${target.name}`,
    });
  });
  steps.push({ type: 'done', servers, keys: [...placed], arc: null, message: '✓ Consistent hashing walk complete' });
  return steps;
}

export default function ConsistentHashingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const servers = [
      { name: 'S1', pos: 40 },
      { name: 'S2', pos: 140 },
      { name: 'S3', pos: 260 },
    ];
    const keyList = [
      { id: 'k1', label: 'K1', pos: 20 },
      { id: 'k2', label: 'K2', pos: 200 },
    ];
    const steps = generateSteps(servers, keyList);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Clockwise successor on ring' });
    canvasRef.current?.setState({ servers, keys: [], activeKey: null, arc: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.message) store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.message });
    canvasRef.current?.setState({
      servers: step.servers,
      keys: step.keys || [],
      activeKey: step.activeKey || null,
      arc: step.arc || null,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={RingCanvas} onInit={onInit} onStep={onStep} />;
}
