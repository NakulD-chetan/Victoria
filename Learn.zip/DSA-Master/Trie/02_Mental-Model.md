# Trie — Mental Model

> **Think of it as:** An autocomplete/dictionary where typing each letter narrows down choices. Shared prefixes = shared branches. One path = one string.

---

## Primary Analogy: Autocomplete

**You type "app" in a search bar.** The system doesn't scan every word — it follows a path: a → p → p, then lists all words under that node. That's a trie.

```
Type "app":
  root → a → p → p  [HERE: list all descendants]
  Words: "app", "apple", "application", "apply"...
```

---

## Shared Prefixes = Shared Paths

```mermaid
flowchart TD
    root["(root)"] --> c["c"]
    c --> a["a"]
    a --> t["t"]
    a --> r["r"]
    t --> t_end["*"]
    r --> d["d"]
    r --> e["e"]
    d --> d_end["*"]
    e --> e_end["*"]
    style root fill:#E3F2FD
    style t_end fill:#C8E6C9
    style d_end fill:#C8E6C9
    style e_end fill:#C8E6C9
```

* = end-of-word. Words: "cat", "car", "card", "care"

<details>
<summary>ASCII fallback</summary>

```
Words: "cat", "car", "card", "care"

        (root)
          |
          c
          |
          a
         / \
        t   r
       *   / \
          d   e
         *   *

* = end-of-word
```

</details>

- "cat": root → c → a → t ✓
- "car": root → c → a → r ✓
- "card": root → c → a → r → d ✓
- "care": root → c → a → r → e ✓

**"ca" is stored once**, not per word.

---

## Trie Structure (Full)

```mermaid
flowchart TD
    root["(root)"] --> t["t"]
    t --> h["h"]
    t --> e["e"]
    t --> o["o"]
    h --> e2["e"]
    e --> a["a"]
    e --> n["n"]
    e2 --> i["i"]
    e2 --> r["r"]
    i --> r2["r"]
    r --> e3["e"]
    o --> o_end["*"]
    a --> a_end["*"]
    n --> n_end["*"]
    r2 --> r2_end["*"]
    e3 --> e3_end["*"]
    style root fill:#E3F2FD
    style o_end fill:#C8E6C9
    style a_end fill:#C8E6C9
    style n_end fill:#C8E6C9
    style r2_end fill:#C8E6C9
    style e3_end fill:#C8E6C9
```

Words: "the", "their", "there", "tea", "ten", "to"

<details>
<summary>ASCII fallback</summary>

```
Words: "the", "their", "there", "tea", "ten", "to"

                    (root)
                      |
                      t
                    / | \
                   h  e  o
                   |  |  *
                   e  a
                  / \  *
                 i   r
                 r   e
                 *   *
```

</details>

| Path | Word? |
|------|-------|
| t→h→e | "the" ✓ |
| t→h→e→i→r | "their" ✓ |
| t→h→e→r→e | "there" ✓ |
| t→e→a | "tea" ✓ |
| t→e→n | "ten" ✓ |
| t→o | "to" ✓ |

---

## Traversal Mental Model

**Insert "cat":**
1. Start at root
2. For each char: go to child (create if missing)
3. At end: mark node as end-of-word

**Search "car":**
1. Start at root
2. For each char: follow child (return false if missing)
3. At end: return true only if end-of-word

**startsWith "ca":**
1. Same as search, but at end return true (don't need end-of-word)

---

## Why "Prefix Tree"?

```
Prefix "pre" matches:
  - "pre" (exact)
  - "prefix"
  - "prepare"
  - "present"
  ...

All share the path: p → r → e
To enumerate: DFS from node at "pre"
```

---

## Bitwise Trie (XOR Problems)

**Same idea, different "alphabet":** bits 0 and 1.

```mermaid
flowchart TD
    root["(root)"] --> b0["0"]
    root --> b1["1"]
    b0 --> b01["1"]
    b1 --> b10["0"]
    b1 --> b11["1"]
    b01 --> b011["1"]
    b10 --> b101["1"]
    b11 --> b110["0"]
    b011 --> end1["*"]
    b101 --> end2["*"]
    b110 --> end3["*"]
    style root fill:#E3F2FD
    style end1 fill:#C8E6C9
    style end2 fill:#C8E6C9
    style end3 fill:#C8E6C9
```

Numbers: 3 (011), 5 (101), 6 (110)

<details>
<summary>ASCII fallback</summary>

```
Numbers: 3 (011), 5 (101), 6 (110)

        (root)
       /      \
      0        1
      |        |
      1        0
      |        |
      1        1
     *         *
```

</details>

- Path 0→1→1 = 3
- Path 1→0→1 = 5
- Path 1→1→0 = 6

**Max XOR with 4 (100):** Greedily pick opposite bit at each step.

---

## FINAL MEMORY COMPRESSION BLOCK

```
ANALOGY:     Autocomplete — type letter, follow path, narrow choices
SHARED:      Common prefix = shared path (space efficient)
TRAVERSAL:   Insert: create path, mark end | Search: follow path, check end
PREFIX:      startsWith = search without end-of-word check
BITWISE:     Same structure, alphabet = {0, 1}, for XOR/max
```

---

## 30-SECOND REVISION BOX

```
AUTOCOMPLETE = type → follow path → list descendants
SHARED PREFIX = one path, multiple words
INSERT: create nodes, mark end
SEARCH: follow path, check end-of-word
STARTSWITH: follow path, no end check
BITWISE TRIE: bits as chars, for XOR
```
