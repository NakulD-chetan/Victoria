import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { SkeletonTableRow } from '../shared/Skeleton';

const API_BASE = '/api';
const DIFF_COLORS = { Easy: 'var(--accent)', Medium: 'var(--accent-warm)', Hard: 'var(--danger)' };
const SOLVED_KEY = 'inkdrop-solved-problems';
const SOLVED_ALGO_KEY = 'inkdrop-solved-algorithms';

function getSolved(key) {
  try { return JSON.parse(localStorage.getItem(key) || '[]'); } catch { return []; }
}
function toggleSolved(key, id) {
  const arr = getSolved(key);
  const next = arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id];
  localStorage.setItem(key, JSON.stringify(next));
  return next;
}

function InkDropLogo({ solvedCount, totalCount }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const stateRef = useRef({ mouseY: 0, ripple: 0, rippleX: 0.5 });
  const prevPctRef = useRef(0);
  const [hovered, setHovered] = useState(false);

  const pct = totalCount > 0 ? Math.min((solvedCount / totalCount) * 100, 100) : 0;

  const bubblesRef = useRef([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = 300, H = 420;
    canvas.width = W * 2; canvas.height = H * 2;
    ctx.scale(2, 2);

    const DROP_PATH = new Path2D();
    DROP_PATH.moveTo(150, 15);
    DROP_PATH.bezierCurveTo(150, 15, 45, 175, 45, 265);
    DROP_PATH.bezierCurveTo(45, 325, 90, 395, 150, 395);
    DROP_PATH.bezierCurveTo(210, 395, 255, 325, 255, 265);
    DROP_PATH.bezierCurveTo(255, 175, 150, 15, 150, 15);
    DROP_PATH.closePath();

    const HIGHLIGHT_PATH = new Path2D();
    HIGHLIGHT_PATH.moveTo(120, 90);
    HIGHLIGHT_PATH.bezierCurveTo(100, 140, 70, 200, 68, 240);
    HIGHLIGHT_PATH.bezierCurveTo(65, 260, 72, 230, 85, 190);
    HIGHLIGHT_PATH.bezierCurveTo(95, 160, 115, 110, 120, 90);

    if (bubblesRef.current.length === 0) {
      for (let i = 0; i < 12; i++) {
        bubblesRef.current.push({
          x: 80 + Math.random() * 140,
          y: 300 + Math.random() * 80,
          r: 1.5 + Math.random() * 4,
          speed: 0.15 + Math.random() * 0.35,
          wobble: Math.random() * Math.PI * 2,
          wobbleSpeed: 0.01 + Math.random() * 0.02,
          opacity: 0.15 + Math.random() * 0.35,
        });
      }
    }

    let currentFill = prevPctRef.current;
    let t = 0;

    function draw() {
      t += 0.016;
      const targetFill = pct;
      currentFill += (targetFill - currentFill) * 0.03;
      prevPctRef.current = currentFill;

      const fillRatio = currentFill / 100;
      const waterTop = 395 - fillRatio * 330;
      const st = stateRef.current;
      const rippleDecay = Math.max(0, st.ripple * 0.97);
      st.ripple = rippleDecay;

      ctx.clearRect(0, 0, W, H);

      const glowGrad = ctx.createRadialGradient(150, 250, 20, 150, 250, 180);
      glowGrad.addColorStop(0, `rgba(99,102,241,${0.08 + fillRatio * 0.12})`);
      glowGrad.addColorStop(0.5, `rgba(16,185,129,${0.04 + fillRatio * 0.06})`);
      glowGrad.addColorStop(1, 'transparent');
      ctx.fillStyle = glowGrad;
      ctx.fillRect(0, 0, W, H);

      ctx.save();
      ctx.beginPath();
      ctx.addPath(DROP_PATH);
      ctx.clip();

      const bgGrad = ctx.createLinearGradient(0, 0, 0, H);
      bgGrad.addColorStop(0, 'rgba(15,15,25,0.6)');
      bgGrad.addColorStop(1, 'rgba(10,10,20,0.8)');
      ctx.fillStyle = bgGrad;
      ctx.fill(DROP_PATH);

      if (fillRatio > 0.005) {
        ctx.save();
        ctx.beginPath();

        const waveAmp1 = 6 + st.ripple * 15;
        const waveAmp2 = 4 + st.ripple * 10;
        const waveAmp3 = 2.5;

        ctx.moveTo(0, waterTop);
        for (let x = 0; x <= W; x += 2) {
          const nx = x / W;
          const rippleFactor = 1 - Math.abs(nx - st.rippleX) * 2;
          const rippleBoost = Math.max(0, rippleFactor) * st.ripple * 12;
          const y = waterTop
            + Math.sin(x * 0.04 + t * 2.2) * waveAmp1
            + Math.sin(x * 0.07 - t * 1.8) * waveAmp2
            + Math.sin(x * 0.12 + t * 3.0) * waveAmp3
            - rippleBoost * Math.sin(nx * Math.PI);
          ctx.lineTo(x, y);
        }
        ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();

        const liqGrad = ctx.createLinearGradient(0, waterTop, 0, 400);
        liqGrad.addColorStop(0, `rgba(99,102,241,${0.55 + fillRatio * 0.25})`);
        liqGrad.addColorStop(0.3, `rgba(129,140,248,${0.6 + fillRatio * 0.2})`);
        liqGrad.addColorStop(0.6, `rgba(79,70,229,${0.7 + fillRatio * 0.15})`);
        liqGrad.addColorStop(1, `rgba(55,48,163,${0.85})`);
        ctx.fillStyle = liqGrad;
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(0, waterTop + 3);
        for (let x = 0; x <= W; x += 2) {
          const nx = x / W;
          const rippleFactor = 1 - Math.abs(nx - st.rippleX) * 2;
          const rippleBoost = Math.max(0, rippleFactor) * st.ripple * 8;
          const y = waterTop + 3
            + Math.sin(x * 0.05 + t * 2.8 + 1) * (waveAmp1 * 0.6)
            + Math.sin(x * 0.08 - t * 2.0 + 2) * (waveAmp2 * 0.5)
            - rippleBoost * Math.sin(nx * Math.PI);
          ctx.lineTo(x, y);
        }
        ctx.lineTo(W, H); ctx.lineTo(0, H); ctx.closePath();
        const liqGrad2 = ctx.createLinearGradient(0, waterTop, 0, 400);
        liqGrad2.addColorStop(0, 'rgba(16,185,129,0.15)');
        liqGrad2.addColorStop(0.4, 'rgba(52,211,153,0.1)');
        liqGrad2.addColorStop(1, 'rgba(16,185,129,0.05)');
        ctx.fillStyle = liqGrad2;
        ctx.fill();

        const causticCount = 5;
        for (let i = 0; i < causticCount; i++) {
          const cx = 70 + Math.sin(t * 0.5 + i * 1.3) * 60;
          const cy = waterTop + 40 + i * 50 + Math.cos(t * 0.7 + i) * 15;
          const cr = 15 + Math.sin(t * 0.8 + i * 2) * 8;
          const causticGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, cr);
          causticGrad.addColorStop(0, `rgba(165,180,252,${0.12 + Math.sin(t + i) * 0.06})`);
          causticGrad.addColorStop(1, 'transparent');
          ctx.fillStyle = causticGrad;
          ctx.beginPath();
          ctx.ellipse(cx, cy, cr, cr * 0.6, Math.sin(t * 0.3 + i) * 0.5, 0, Math.PI * 2);
          ctx.fill();
        }

        const surfaceGrad = ctx.createLinearGradient(0, waterTop - 5, 0, waterTop + 20);
        surfaceGrad.addColorStop(0, 'rgba(255,255,255,0.25)');
        surfaceGrad.addColorStop(0.3, 'rgba(255,255,255,0.08)');
        surfaceGrad.addColorStop(1, 'transparent');
        ctx.beginPath();
        ctx.moveTo(0, waterTop - 2);
        for (let x = 0; x <= W; x += 2) {
          const y = waterTop - 2
            + Math.sin(x * 0.04 + t * 2.2) * waveAmp1
            + Math.sin(x * 0.07 - t * 1.8) * waveAmp2;
          ctx.lineTo(x, y);
        }
        for (let x = W; x >= 0; x -= 2) {
          const y = waterTop + 18
            + Math.sin(x * 0.04 + t * 2.2) * waveAmp1 * 0.3;
          ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fillStyle = surfaceGrad;
        ctx.fill();

        const bubbles = bubblesRef.current;
        for (const b of bubbles) {
          b.y -= b.speed;
          b.wobble += b.wobbleSpeed;
          const bx = b.x + Math.sin(b.wobble) * 3;
          if (b.y < waterTop - 10) {
            b.y = 380 + Math.random() * 20;
            b.x = 80 + Math.random() * 140;
          }
          if (b.y > waterTop) {
            const bubbleGrad = ctx.createRadialGradient(bx - b.r * 0.3, b.y - b.r * 0.3, 0, bx, b.y, b.r);
            bubbleGrad.addColorStop(0, `rgba(200,210,255,${b.opacity * 0.8})`);
            bubbleGrad.addColorStop(0.7, `rgba(160,170,240,${b.opacity * 0.3})`);
            bubbleGrad.addColorStop(1, `rgba(130,140,220,0)`);
            ctx.beginPath();
            ctx.arc(bx, b.y, b.r, 0, Math.PI * 2);
            ctx.fillStyle = bubbleGrad;
            ctx.fill();
            ctx.beginPath();
            ctx.arc(bx - b.r * 0.25, b.y - b.r * 0.25, b.r * 0.3, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(255,255,255,${b.opacity * 0.6})`;
            ctx.fill();
          }
        }
        ctx.restore();
      }

      ctx.restore();

      ctx.save();
      ctx.lineWidth = 2;
      const outGrad = ctx.createLinearGradient(0, 0, 0, H);
      outGrad.addColorStop(0, 'rgba(165,180,252,0.5)');
      outGrad.addColorStop(0.5, 'rgba(129,140,248,0.35)');
      outGrad.addColorStop(1, 'rgba(16,185,129,0.45)');
      ctx.strokeStyle = outGrad;
      ctx.stroke(DROP_PATH);
      ctx.restore();

      ctx.save();
      ctx.lineWidth = 1;
      ctx.strokeStyle = 'rgba(255,255,255,0.08)';
      ctx.stroke(DROP_PATH);
      ctx.restore();

      ctx.save();
      ctx.globalAlpha = 0.25;
      const hlGrad = ctx.createLinearGradient(70, 80, 100, 280);
      hlGrad.addColorStop(0, 'rgba(255,255,255,0.5)');
      hlGrad.addColorStop(1, 'rgba(255,255,255,0)');
      ctx.strokeStyle = hlGrad;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.stroke(HIGHLIGHT_PATH);
      ctx.restore();

      const rimGrad = ctx.createLinearGradient(200, 100, 230, 350);
      rimGrad.addColorStop(0, 'rgba(255,255,255,0.05)');
      rimGrad.addColorStop(0.5, 'rgba(255,255,255,0.12)');
      rimGrad.addColorStop(1, 'rgba(255,255,255,0.03)');
      ctx.save();
      ctx.beginPath();
      ctx.arc(200, 240, 12, -0.8, 1.2);
      ctx.lineWidth = 2;
      ctx.strokeStyle = rimGrad;
      ctx.stroke();
      ctx.restore();

      const displayPct = Math.round(currentFill);
      ctx.save();
      ctx.font = '700 36px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.shadowBlur = 12;
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.fillText(`${displayPct}%`, 150, 280);
      ctx.shadowBlur = 0;
      ctx.font = '500 13px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif';
      ctx.fillStyle = 'rgba(255,255,255,0.5)';
      ctx.fillText('progress', 150, 305);
      ctx.restore();

      animRef.current = requestAnimationFrame(draw);
    }

    animRef.current = requestAnimationFrame(draw);
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [pct]);

  const handleMouseMove = useCallback((e) => {
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    stateRef.current.mouseY = (e.clientY - rect.top) / rect.height;
    stateRef.current.rippleX = (e.clientX - rect.left) / rect.width;
  }, []);

  const handleClick = useCallback(() => {
    stateRef.current.ripple = 1;
  }, []);

  return (
    <div className="ph-logo"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div className="ph-logo__glow" style={{ opacity: 0.25 + pct * 0.005 }} />
      <canvas
        ref={canvasRef}
        className={`ph-logo__canvas ${hovered ? 'ph-logo__canvas--hover' : ''}`}
        style={{ width: 150, height: 210 }}
        onMouseMove={handleMouseMove}
        onClick={handleClick}
      />
      <div className="ph-logo__label">
        Ink<span className="ph-logo__label-accent">Drop</span>
      </div>
      <div className="ph-logo__sub">{solvedCount} / {totalCount} solved</div>
      <div className="ph-logo__hint">click to ripple</div>
    </div>
  );
}

function MiniProblemList({ items, loading, solved, onToggleSolve, onNavigate, emptyText }) {
  return (
    <div className="ph-list">
      {loading ? (
        Array.from({ length: 6 }).map((_, i) => <SkeletonTableRow key={i} />)
      ) : items.length === 0 ? (
        <div className="ph-list__empty">{emptyText}</div>
      ) : (
        items.map((item) => {
          const id = item.slug || item.id;
          const isSolved = solved.includes(id);
          return (
            <div key={id} className={`ph-row ${isSolved ? 'ph-row--solved' : ''}`}>
              <button className={`ph-row__check ${isSolved ? 'ph-row__check--done' : ''}`}
                onClick={(e) => { e.stopPropagation(); onToggleSolve(id); }}
                title={isSolved ? 'Mark unsolved' : 'Mark solved'}>
                {isSolved ? (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                ) : (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity="0.3">
                    <circle cx="12" cy="12" r="10" />
                  </svg>
                )}
              </button>
              <button className="ph-row__body" onClick={() => onNavigate(id)}>
                <span className="ph-row__num">{item.number}.</span>
                <span className="ph-row__icon">{item.icon}</span>
                <span className="ph-row__title">{item.title}</span>
                <span className="ph-row__diff" style={{ color: DIFF_COLORS[item.difficulty] }}>
                  {item.difficulty}
                </span>
              </button>
            </div>
          );
        })
      )}
    </div>
  );
}

export default function PracticeHub() {
  const [dsaProblems, setDsaProblems] = useState([]);
  const [sdProblems, setSdProblems] = useState([]);
  const [dsaLoading, setDsaLoading] = useState(true);
  const [sdLoading, setSdLoading] = useState(true);
  const [dsaTotal, setDsaTotal] = useState(0);
  const [sdTotal, setSdTotal] = useState(0);
  const [dsaSearch, setDsaSearch] = useState('');
  const [sdSearch, setSdSearch] = useState('');
  const [dsaFilter, setDsaFilter] = useState('All');
  const [sdFilter, setSdFilter] = useState('All');
  const [dsaPage, setDsaPage] = useState(1);
  const [sdPage, setSdPage] = useState(1);
  const [solvedSD, setSolvedSD] = useState(() => getSolved(SOLVED_KEY));
  const [solvedDSA, setSolvedDSA] = useState(() => getSolved(SOLVED_ALGO_KEY));
  const dsaDebounce = useRef(null);
  const sdDebounce = useRef(null);
  const limit = 15;

  const fetchDSA = useCallback(async (pg, diff, q) => {
    setDsaLoading(true);
    const params = new URLSearchParams({ page: pg, limit });
    if (diff && diff !== 'All') params.set('category', diff);
    if (q) params.set('q', q);
    try {
      const res = await fetch(`${API_BASE}/algorithms?${params}`);
      if (res.ok) {
        const json = await res.json();
        setDsaProblems(json.data || []);
        setDsaTotal(json.total || 0);
      }
    } catch { setDsaProblems([]); }
    setDsaLoading(false);
  }, []);

  const fetchSD = useCallback(async (pg, diff, q) => {
    setSdLoading(true);
    const params = new URLSearchParams({ page: pg, limit });
    if (diff && diff !== 'All') params.set('difficulty', diff);
    if (q) params.set('q', q);
    try {
      const res = await fetch(`${API_BASE}/problems?${params}`);
      if (res.ok) {
        const json = await res.json();
        setSdProblems(json.data || []);
        setSdTotal(json.total || 0);
      }
    } catch { setSdProblems([]); }
    setSdLoading(false);
  }, []);

  useEffect(() => { fetchDSA(dsaPage, dsaFilter, dsaSearch); }, [dsaPage, dsaFilter, fetchDSA]);
  useEffect(() => { fetchSD(sdPage, sdFilter, sdSearch); }, [sdPage, sdFilter, fetchSD]);

  useEffect(() => {
    if (dsaDebounce.current) clearTimeout(dsaDebounce.current);
    dsaDebounce.current = setTimeout(() => { setDsaPage(1); fetchDSA(1, dsaFilter, dsaSearch); }, 400);
    return () => clearTimeout(dsaDebounce.current);
  }, [dsaSearch]);

  useEffect(() => {
    if (sdDebounce.current) clearTimeout(sdDebounce.current);
    sdDebounce.current = setTimeout(() => { setSdPage(1); fetchSD(1, sdFilter, sdSearch); }, 400);
    return () => clearTimeout(sdDebounce.current);
  }, [sdSearch]);

  const navigate = (href) => {
    window.history.pushState(null, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  const toggleSolveSD = useCallback((id) => {
    setSolvedSD(toggleSolved(SOLVED_KEY, id));
  }, []);

  const toggleSolveDSA = useCallback((id) => {
    setSolvedDSA(toggleSolved(SOLVED_ALGO_KEY, id));
  }, []);

  const totalSolved = solvedSD.length + solvedDSA.length;
  const grandTotal = dsaTotal + sdTotal;

  const dsaTotalPages = Math.ceil(dsaTotal / limit);
  const sdTotalPages = Math.ceil(sdTotal / limit);
  const difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  return (
    <div className="ph">
      <div className="ph__header">
        <h1 className="ph__title">Practice Arena</h1>
        <p className="ph__subtitle">Master algorithms and system design — one drop at a time</p>
      </div>

      <div className="ph__arena">
        {/* LEFT — DSA */}
        <div className="ph__panel ph__panel--left">
          <div className="ph__panel-header">
            <div className="ph__panel-badge ph__panel-badge--dsa">DSA</div>
            <h2 className="ph__panel-title">Algorithms</h2>
            <span className="ph__panel-count">{dsaTotal}</span>
          </div>
          <div className="ph__panel-toolbar">
            <div className="ph__search-wrap">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input type="text" placeholder="Search..." value={dsaSearch}
                onChange={(e) => setDsaSearch(e.target.value)} className="ph__search-input" />
            </div>
            <div className="ph__filters">
              {difficulties.map(d => (
                <button key={d} onClick={() => { setDsaFilter(d); setDsaPage(1); }}
                  className={`ph__filter-pill ${dsaFilter === d ? 'ph__filter-pill--active' : ''}`}>{d}</button>
              ))}
            </div>
          </div>
          <MiniProblemList
            items={dsaProblems}
            loading={dsaLoading}
            solved={solvedDSA}
            onToggleSolve={toggleSolveDSA}
            onNavigate={(id) => navigate(`/algorithms/${id}`)}
            emptyText="No algorithms found"
          />
          {dsaTotalPages > 1 && (
            <div className="ph__pager">
              <button disabled={dsaPage <= 1} onClick={() => setDsaPage(p => p - 1)}>&laquo;</button>
              <span>{dsaPage} / {dsaTotalPages}</span>
              <button disabled={dsaPage >= dsaTotalPages} onClick={() => setDsaPage(p => p + 1)}>&raquo;</button>
            </div>
          )}
        </div>

        {/* CENTER — InkDrop Logo */}
        <div className="ph__center">
          <InkDropLogo solvedCount={totalSolved} totalCount={grandTotal} />
        </div>

        {/* RIGHT — System Design */}
        <div className="ph__panel ph__panel--right">
          <div className="ph__panel-header">
            <div className="ph__panel-badge ph__panel-badge--sd">SD</div>
            <h2 className="ph__panel-title">System Design</h2>
            <span className="ph__panel-count">{sdTotal}</span>
          </div>
          <div className="ph__panel-toolbar">
            <div className="ph__search-wrap">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
              </svg>
              <input type="text" placeholder="Search..." value={sdSearch}
                onChange={(e) => setSdSearch(e.target.value)} className="ph__search-input" />
            </div>
            <div className="ph__filters">
              {difficulties.map(d => (
                <button key={d} onClick={() => { setSdFilter(d); setSdPage(1); }}
                  className={`ph__filter-pill ${sdFilter === d ? 'ph__filter-pill--active' : ''}`}>{d}</button>
              ))}
            </div>
          </div>
          <MiniProblemList
            items={sdProblems}
            loading={sdLoading}
            solved={solvedSD}
            onToggleSolve={toggleSolveSD}
            onNavigate={(id) => navigate(`/systemdesign/${id}`)}
            emptyText="No problems found"
          />
          {sdTotalPages > 1 && (
            <div className="ph__pager">
              <button disabled={sdPage <= 1} onClick={() => setSdPage(p => p - 1)}>&laquo;</button>
              <span>{sdPage} / {sdTotalPages}</span>
              <button disabled={sdPage >= sdTotalPages} onClick={() => setSdPage(p => p + 1)}>&raquo;</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
