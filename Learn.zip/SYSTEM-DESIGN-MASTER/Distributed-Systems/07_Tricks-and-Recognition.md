# Distributed Systems — Tricks and Recognition

> **Permanent Recall:** Distributed systems concepts apply to any multi-node system. Consensus shortcut: say "use Raft" for leader election. ZooKeeper as universal coordinator for config, locks, discovery. Distributed lock patterns: always fencing for critical. Time sync shortcuts: Lamport for order, NTP for approximate. Use these recognition triggers to quickly identify and apply the right approach in FAANG interviews.

---

## When Distributed Systems Concepts Apply

**Trigger:** Any system with **multiple nodes** that need to coordinate, replicate, or agree.

| Scenario | Concepts Apply |
|----------|-----------------|
| Database replication | Consensus, split brain, quorum |
| Job scheduler (one active) | Leader election |
| Mutex across services | Distributed lock + fencing |
| Config across instances | ZooKeeper, etcd, gossip |
| Service discovery | ZooKeeper, Consul, etcd |
| Multi-region deployment | CAP, partition, conflict resolution |

> **FAANG Tip:** If the design has 2+ nodes, think: coordination, failure, partition.

---

## Consensus Shortcuts — "Just Say Raft"

**When asked:** "How do we elect a leader?" / "How do we agree on state?"

**Shortcut:** "We'd use Raft—etcd or Consul. They handle leader election and log replication. Odd cluster size (3 or 5) for quorum. No need to implement from scratch."

| Need | Say |
|------|-----|
| Leader election | Raft (etcd, Consul) |
| Config store | etcd, ZooKeeper |
| Coordination | ZooKeeper |

---

## ZooKeeper as Universal Coordinator

**When to reach for ZooKeeper (or etcd):**

| Need | ZK pattern |
|------|------------|
| Config | `/config/key` + watchers |
| Leader | Ephemeral node, smallest wins |
| Lock | Ephemeral sequential |
| Discovery | `/services/foo` children |
| Barrier | All create node, wait for count |

**Recognition:** "We need one source of truth for X across nodes" → ZooKeeper/etcd.

---

## Distributed Lock Patterns

| Scenario | Pattern |
|----------|---------|
| Critical resource (DB, storage) | ZooKeeper + **fencing token** |
| Cache invalidation, non-critical | Redis RedLock (weaker OK) |
| Job single-run | Leader election (not lock) |

**Rule:** If wrong = data corruption or double-execution → fencing required.

---

## Time Synchronization Shortcuts

| Need | Use |
|------|-----|
| Display time to user | NTP, wall clock |
| Order events causally | Lamport timestamps |
| Detect concurrent writes | Vector clocks |
| LWW with skew risk | Hybrid Logical Clock |
| Distributed locking | Logical clock, not wall |

**Shortcut:** "For ordering we use Lamport—wall clocks can skew."

---

## Recognition: Keyword → Action

| Keyword | Think | Say |
|---------|-------|-----|
| "Single active instance" | Leader election | "Raft or ZooKeeper" |
| "Mutex across services" | Distributed lock | "ZK + fencing token" |
| "Config across nodes" | Coordination | "etcd or ZooKeeper" |
| "Split brain" | Quorum | "Odd N, only majority elects" |
| "Network partition" | CAP | "Quorum; minority blocks" |
| "Order events" | Clock | "Lamport or vector clocks" |
| "Eventually consistent" | Gossip | "O(log N) convergence" |

---

## Quick Decision Tree

```
Need coordination?
  ├─ One leader → Raft (etcd, Consul)
  ├─ Lock → ZK + fencing (critical) or RedLock (weaker)
  ├─ Config → etcd, ZooKeeper
  └─ Membership/discovery → ZK, Consul, gossip

Partition?
  └─ Odd N, quorum, minority blocks

Ordering?
  └─ Lamport (causal), vector (concurrent detect)
```

---

## Pattern: "Design X" → Distributed Angle

When designing any system, proactively ask:

1. **Multiple instances?** → Leader election or stateless
2. **Shared resource?** → Lock + fencing
3. **Shared config?** → etcd, ZooKeeper
4. **Replication?** → Consensus, quorum
5. **Multi-region?** → Partition, CAP, conflict resolution

---

## Anti-Patterns to Avoid

| Anti-pattern | Right approach |
|--------------|-----------------|
| Custom consensus | Use etcd, ZooKeeper |
| Lock without fencing (critical) | Add fencing token |
| Even N (2, 4) for quorum | Odd N (3, 5) |
| Wall clock for ordering | Lamport, vector |
| No partition discussion | Always address |

---

## One-Line Answers for Rapid-Fire

- **"Single active job?"** → Raft leader election (etcd)
- **"Distributed mutex?"** → ZooKeeper + fencing
- **"Config across 100 nodes?"** → etcd or ZooKeeper
- **"Prevent split brain?"** → Quorum, odd N
- **"Order events?"** → Lamport timestamps

---

## 30-SECOND REVISION BOX

```
MULTI-NODE → Coordination, failure, partition
CONSENSUS → Raft (etcd, Consul)
ZK → Config, leader, lock, discovery
LOCK → Fencing for critical
TIME → Lamport for order
KEYWORDS: Single active→Raft, Mutex→fencing, Partition→quorum
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
