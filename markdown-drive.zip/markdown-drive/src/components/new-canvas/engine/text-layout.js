let measurementCanvas = null;

function getContext() {
  if (typeof document === 'undefined') return null;
  if (!measurementCanvas) measurementCanvas = document.createElement('canvas');
  return measurementCanvas.getContext('2d');
}

export const HAND_FONT = "'Excalifont', 'Comic Shanns', 'Comic Sans MS', cursive";
export const TECH_FONT = "'JetBrains Mono', 'Fira Code', Menlo, Consolas, monospace";

export function wrapTextLines(text, {
  fontSize = 20,
  fontFamily = HAND_FONT,
  maxWidth = 420,
} = {}) {
  const paragraphs = String(text || '').split('\n');
  const context = getContext();
  if (context) context.font = `${fontSize}px ${fontFamily}`;
  const measure = (value) => (
    context?.measureText(value).width
    ?? value.length * fontSize * 0.58
  );
  const lines = [];

  paragraphs.forEach((paragraph) => {
    if (!paragraph.trim()) {
      lines.push('');
      return;
    }
    const words = paragraph.split(/\s+/);
    let current = '';
    words.forEach((word) => {
      const candidate = current ? `${current} ${word}` : word;
      if (current && measure(candidate) > maxWidth) {
        lines.push(current);
        current = word;
      } else {
        current = candidate;
      }
    });
    if (current) lines.push(current);
  });

  return lines.length ? lines : [''];
}

export function measureTextBlock(text, options = {}) {
  const fontSize = Number(options.fontSize) || 20;
  const fontFamily = options.fontFamily || HAND_FONT;
  const maxWidth = Math.max(80, Number(options.maxWidth) || 420);
  const lineHeight = Number(options.lineHeight) || 1.25;
  const padding = Number(options.padding) || 0;
  const lines = wrapTextLines(text, { fontSize, fontFamily, maxWidth });
  const context = getContext();
  if (context) context.font = `${fontSize}px ${fontFamily}`;
  const measuredWidth = Math.max(
    1,
    ...lines.map((line) => (
      context?.measureText(line).width
      ?? line.length * fontSize * 0.58
    )),
  );
  return {
    lines,
    width: Math.min(maxWidth, Math.ceil(measuredWidth)) + padding * 2,
    height: Math.ceil(lines.length * fontSize * lineHeight) + padding * 2,
    lineHeightPx: fontSize * lineHeight,
  };
}

export function createTextElement({
  id,
  text,
  x,
  y,
  maxWidth = 420,
  fontSize = 22,
  fontFamily = HAND_FONT,
  color = '#1f2937',
  semanticRole = 'annotation',
  containerId = null,
  textAlign = 'left',
  frameId = null,
  z = 1,
  customData = {},
}) {
  const metrics = measureTextBlock(text, {
    fontSize,
    fontFamily,
    maxWidth,
  });
  return {
    id,
    type: 'text',
    text,
    originalText: text,
    x,
    y,
    w: metrics.width,
    h: metrics.height,
    width: metrics.width,
    height: metrics.height,
    fontSize,
    fontFamily,
    lineHeight: metrics.lineHeightPx / fontSize,
    textAlign,
    verticalAlign: 'top',
    autoResize: true,
    containerId,
    frameId,
    z,
    isDeleted: false,
    style: {
      stroke: color,
      fill: 'transparent',
      strokeWidth: 1,
      opacity: 1,
      dash: 'solid',
    },
    createdAt: Date.now(),
    customData: {
      semanticRole,
      ...customData,
    },
  };
}
