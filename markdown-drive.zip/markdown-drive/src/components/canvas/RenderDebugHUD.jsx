import { useEffect, useRef, useState } from 'react';

/**
 * RenderDebugHUD — dev-only overlay that reports the canvas pipeline's
 * health at a glance. Not rendered in production.
 *
 * What it shows:
 *   tool       → appState.activeTool.type (what the user is currently using)
 *   down       → pointerDown refs (was pointer captured?)
 *   scene      → count of non-deleted elements in the Excalidraw scene
 *   deleted    → count of soft-deleted elements (still in array)
 *   zoom       → current viewport zoom
 *   scroll     → scrollX / scrollY
 *   fps        → rAF-based instantaneous FPS (useful to detect stutter)
 *   last onChange → timestamp since last handleChange call
 *
 * The single most important signal for "invisible strokes":
 *   - If `scene` count increments when you lift the pen, strokes ARE being
 *     committed and the bug is visual (z-index / background / CSS).
 *   - If `scene` count does NOT increment, updateScene is wiping newElement
 *     mid-gesture (safe-scene guard is failing) — check console for the
 *     "[safe-scene] dropped" warning.
 */
export default function RenderDebugHUD({ getApi, pointerDownRef, lastChangeRef, enabled = true }) {
  const [tick, setTick] = useState(0);
  const fpsRef = useRef({ last: performance.now(), frames: 0, fps: 0 });

  useEffect(() => {
    if (!enabled) return;
    let raf;
    const loop = () => {
      const now = performance.now();
      const t = fpsRef.current;
      t.frames += 1;
      const delta = now - t.last;
      if (delta >= 500) {
        t.fps = Math.round((t.frames * 1000) / delta);
        t.frames = 0;
        t.last = now;
      }
      setTick((x) => (x + 1) & 0xffff);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [enabled]);

  if (!enabled) return null;

  const api = getApi?.();
  let tool = '-';
  let sceneCount = 0;
  let deletedCount = 0;
  let zoom = 1;
  let scrollX = 0;
  let scrollY = 0;
  if (api) {
    try {
      const s = api.getAppState();
      tool = s.activeTool?.type ?? '-';
      zoom = Number((s.zoom?.value ?? 1).toFixed(3));
      scrollX = Math.round(s.scrollX ?? 0);
      scrollY = Math.round(s.scrollY ?? 0);
      const els = api.getSceneElements();
      for (const el of els) {
        if (el.isDeleted) deletedCount += 1; else sceneCount += 1;
      }
    } catch {
      /* Excalidraw may be briefly unmounted on canvas switch */
    }
  }

  const down = pointerDownRef?.current ? 'yes' : 'no';
  const sinceLastChange = lastChangeRef?.current
    ? Math.round(performance.now() - lastChangeRef.current)
    : '-';
  const fps = fpsRef.current.fps;

  return (
    <div
      role="status"
      aria-label="Canvas render debug"
      style={{
        position: 'fixed',
        right: 8,
        bottom: 8,
        zIndex: 99999,
        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace',
        fontSize: 11,
        lineHeight: 1.4,
        padding: '6px 8px',
        borderRadius: 6,
        background: 'rgba(20, 20, 28, 0.82)',
        color: '#e5e7eb',
        border: '1px solid rgba(255,255,255,0.08)',
        boxShadow: '0 2px 8px rgba(0,0,0,0.25)',
        pointerEvents: 'none',
        userSelect: 'none',
        backdropFilter: 'blur(4px)',
      }}
    >
      <div><b style={{ color: '#93c5fd' }}>canvas</b> tool={tool} down={down} fps={fps}</div>
      <div>scene={sceneCount} del={deletedCount} zoom={zoom}</div>
      <div>scroll=({scrollX}, {scrollY}) Δchg={sinceLastChange}ms</div>
    </div>
  );
}
