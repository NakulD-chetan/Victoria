# Indexes and Optimization — Problem List

> **20 problems. Mix of LeetCode SQL (query writing) + conceptual (interview oral). Focus: writing optimizable queries + knowing when to index.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Rising Temperature | Easy | 197 | Index on date | Self-join → index on recordDate critical |
| 2 | Department Top Three Salaries | Hard | 185 | Composite index | (dept, salary) index for partition rank |
| 3 | Trips and Users | Hard | 262 | Multi-index joins | Filter banned + group by day |
| 4 | Restaurant Growth | Medium | 1321 | Index on date + frame | Rolling sum needs sorted date |
| 5 | Human Traffic of Stadium | Hard | 601 | Index on id + people | Consecutive scan needs sorted id |
| 6 | Game Play Analysis IV | Medium | 550 | Composite (player, date) | First login + next day lookup |
| 7 | Last Person to Fit in Bus | Medium | 1204 | Index on turn | Running sum ordered by turn |
| 8 | Immediate Food Delivery II | Medium | 1174 | Index on (customer, date) | MIN(order_date) per customer |

---

## Complete 20-Problem List (Query + Optimization Thinking)

### Query Problems (write SQL + think about index)

| # | Problem | LC# | Index Thinking |
|---|---------|-----|----------------|
| 1 | Rising Temperature | 197 | Index on `recordDate` for self-join |
| 2 | Dept Top 3 Salaries | 185 | Composite `(departmentId, salary)` for DENSE_RANK |
| 3 | Trips and Users | 262 | Index on `client_id`, `driver_id`; filter banned via subquery |
| 4 | Restaurant Growth | 1321 | Index on `visited_on` for ordered frame scan |
| 5 | Human Traffic | 601 | Index on `id` (PK) + filter on `people >= 100` |
| 6 | Game Play Analysis IV | 550 | Composite `(player_id, event_date)` for MIN + lookup |
| 7 | Last Person Bus | 1204 | Index on `turn` for cumulative order |
| 8 | Immediate Food Delivery II | 1174 | `(customer_id, order_date)` for first-order CTE |
| 9 | Average Selling Price | 1251 | `(product_id, purchase_date)` for range join |
| 10 | Confirmation Rate | 1934 | `(user_id, action)` for conditional count |

### Conceptual / Oral Interview Questions

| # | Question | Key Answer |
|---|---------|------------|
| 11 | Clustered vs non-clustered — give example | Clustered = PK (data sorted); non-clustered = separate B-tree |
| 12 | When would you NOT create an index? | Low selectivity (boolean), write-heavy table, small table |
| 13 | Composite index (A, B) — does WHERE B=? use it? | No — leftmost prefix rule |
| 14 | Function on indexed column — what happens? | Index bypassed → full scan. Rewrite as range. |
| 15 | View vs materialized view | View = query alias; MV = stored snapshot, needs REFRESH |
| 16 | How to find slow queries? | EXPLAIN ANALYZE + pg_stat_statements / slow query log |
| 17 | Covering index — explain | All SELECT columns in index → index-only scan, no heap lookup |
| 18 | What does ANALYZE / UPDATE STATISTICS do? | Refreshes optimizer statistics for better plans |
| 19 | Index on foreign key — why? | Speeds up JOINs + ON DELETE CASCADE checks |
| 20 | Hash index vs B-tree | Hash = O(1) equality only; B-tree = range + sort + equality |

---

## Problem-by-Problem Optimization Notes

### Problem 1: Rising Temperature (LC 197)
```
Query: Self-join on DATEDIFF(w1.date, w2.date) = 1
Optimization: Index on recordDate → nested-loop uses index for date-1 lookup
Without index: O(n²) cross-product
```

### Problem 2: Dept Top Three Salaries (LC 185)
```
Query: DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC)
Optimization: Composite index (departmentId, salary DESC) → sorted scan per partition
Without: Sort per partition at runtime
```

### Problem 6: Game Play Analysis IV (LC 550)
```
Query: CTE first_login = MIN(event_date) per player; check event_date = first + 1
Optimization: Composite (player_id, event_date) → MIN is first row; lookup for day+1
Without: Full scan for both steps
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL:              20 (10 query + 10 conceptual)
MUST-DO QUERY:      LC 197, 185, 262, 1321, 601, 550, 1204, 1174
KEY CONCEPTS:       Clustered (1/table), Composite (leftmost prefix),
                    Covering (index-only), EXPLAIN (always run)
INTERVIEW LINE:     "I'd EXPLAIN the query, check for seq scans on large tables,
                     add composite index on (WHERE col, ORDER col),
                     and avoid functions on indexed columns."
```

---

## 30-SECOND REVISION BOX

```
CLUSTERED:      1 per table, data physically sorted (usually PK)
NON-CLUSTERED:  Separate B-tree, pointer to data, multiple allowed
COMPOSITE:      (A, B, C) → leftmost prefix: A, AB, ABC usable
COVERING:       Index has all SELECT cols → no table lookup
EXPLAIN:        Always run on slow queries — look for seq scan
AVOID:          Functions on indexed col, SELECT *, missing FK index
```
