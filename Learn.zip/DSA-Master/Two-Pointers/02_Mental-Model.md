# Two Pointers — Mental Model

> **How FAANG engineers actually think about this pattern—visual reasoning, decision triggers, and the internal monologue of a senior engineer solving two-pointer problems in real time.**

---

## How FAANG Engineers Think About Two Pointers

### The Converging Rulers Analogy (Opposite-Direction)

```
Imagine two rulers sliding toward each other on a sorted number line.

  L                    R
[1, 3, 4, 5, 7, 9, 11]
  ↑                    ↑
  "Too small"          "Too big"

If L + R > target → R is the culprit, move R left (need smaller)
If L + R < target → L is the culprit, move L right (need bigger)
If L + R == target → DONE

You NEVER need to backtrack. Each move is justified by the comparison.
```

**FAANG mindset:** "I don't check every pair. I eliminate half the space per step."

### The Hare and Tortoise (Same-Direction)

```
Linked list: A → B → C → D → E → C (cycle back to C)

  slow
  tortoise
  ↓
A → B → C → D → E ─┐
       ↑            │
       └────────────┘
  fast (hare) will eventually lap slow

If there's a cycle: fast and slow WILL meet (proof: modular arithmetic)
If no cycle: fast reaches null first
```

**FAANG mindset:** "Different speeds create phase difference. Cycle = they meet."

---

## The Internal Monologue

When a FAANG engineer reads a problem, their brain runs this checklist:

```
1. "Is the array/string SORTED?"
   → Yes? Opposite-direction two pointers is a candidate.

2. "Am I looking for PAIRS, TRIPLETS, or something else?"
   → Pairs in sorted array: two pointers
   → Triplets: fix one, two-pointer on rest (3Sum pattern)

3. "Is this a LINKED LIST problem?"
   → Cycle? Middle? Nth from end? Same-direction (fast/slow)

4. "Do I need IN-PLACE modification?"
   → Partition, remove duplicates: multi-pointer from same end

5. "Can I SORT the input?"
   → If yes, sort first → unlocks two-pointer for pair problems
   → If no (need indices): Hash Map
```

---

## Pointer Movement Logic by Variant

### Opposite-Direction (Converging)

```
INIT:  left = 0, right = n - 1

DECISION: Compare current state to target
  - If state > target  → move RIGHT left  (right--)
  - If state < target  → move LEFT right  (left++)
  - If state == target → record, then move EITHER (avoid infinite loop)

ASCII:
  left →                    ← right
  [1,  2,  4,  6,  8,  9]
   L               R
        L       R
            L   R
            L,R  (meet or cross)
```

### Same-Direction (Fast/Slow)

```
INIT:  slow = head, fast = head (or head.next for cycle)

MOVEMENT:  slow = slow.next
           fast = fast.next.next  (2x speed)

TERMINATION:  fast == null OR fast == slow

ASCII (cycle detection):
  slow →
  A → B → C → D → E → C
  fast →→
       slow →
       A → B → C → D → E → C
            fast →→
                 slow →
                 A → B → C → D → E → C
                      fast →→ (meets slow!)
```

### Partition (Dutch National Flag)

```
INIT:  low = 0, mid = 0, high = n - 1

REGIONS:  [0...low-1] = 0s
          [low...mid-1] = 1s  
          [mid...high] = unknown
          [high+1...n-1] = 2s

MOVEMENT:  if arr[mid]==0: swap(low,mid), low++, mid++
           if arr[mid]==1: mid++
           if arr[mid]==2: swap(mid,high), high--

ASCII:
  [0, 1, 2, 0, 1, 2]
   L
   M           H
   [0] 1  2  0  1 [2]   swap 0↔0, L++, M++
      L
      M        H
   [0][1] 2  0  1 [2]   M++ (1 stays)
         L
         M     H
   ...
```

---

## Decision Triggers

### When to Move LEFT (opposite-direction)?
- Sum/product **too small** → move left right (need larger value)
- Need to **increase** the left element's contribution

### When to Move RIGHT (opposite-direction)?
- Sum/product **too large** → move right left (need smaller value)
- Need to **decrease** the right element's contribution

### When to Move SLOW (same-direction)?
- **Always** one step per iteration
- Slow catches the "steady" state

### When to Move FAST (same-direction)?
- **Always** two steps per iteration (for cycle)
- Or: fast advances until condition, then slow catches up (partition)

### When to Move MID (partition)?
- `arr[mid]==0` → swap with low, both advance
- `arr[mid]==1` → mid advances (1s stay in middle)
- `arr[mid]==2` → swap with high, high-- (don't advance mid—re-check!)

---

## ASCII Visualizations

### Two Sum II (Sorted Array)

```
target = 9
[1, 2, 4, 6, 7, 9]

Step 1:  L=1, R=9  → 1+9=10 > 9  → R--
[1, 2, 4, 6, 7, 9]
 L           R

Step 2:  L=1, R=7  → 1+7=8 < 9   → L++
[1, 2, 4, 6, 7, 9]
    L        R

Step 3:  L=2, R=7  → 2+7=9 ✓
[1, 2, 4, 6, 7, 9]
    L     R
```

### Linked List Cycle

```
     ┌─────────────┐
     ↓             │
   A → B → C → D → E
   S
   F
        S
        F
             S
                F
                S,F  MEET! Cycle exists.
```

### Remove Duplicates In-Place

```
[1, 1, 2, 2, 2, 3, 4, 4]
 W
 R

[1, 1, 2, 2, 2, 3, 4, 4]
 W  R   (same, R++)
[1, 1, 2, 2, 2, 3, 4, 4]
 W     R  (different, W++, copy, R++)
[1, 2, 2, 2, 2, 3, 4, 4]
    W     R
...
[1, 2, 3, 4, 2, 3, 4, 4]
          W           R
```

---

## Pattern Recognition Signals

### Instant Two-Pointer Signals

| You See This | Your Brain Should Say |
|--------------|----------------------|
| "sorted array" | Opposite-direction |
| "pair with sum X" | Two pointers (if sorted) |
| "three numbers that sum to 0" | 3Sum: fix one, two-pointer |
| "linked list has cycle?" | Fast/slow |
| "find middle of linked list" | Fast/slow (fast at end → slow at middle) |
| "in-place", "O(1) space" | Partition or same-direction |
| "move zeros to end" | Partition |
| "remove duplicates in-place" | Read/write pointers |
| "palindrome" | Opposite-direction from ends |

### Hidden Two-Pointer Problems

| Problem Description | Hidden Pattern |
|--------------------|----------------|
| "Container with most water" | Opposite-direction (width vs height trade-off) |
| "Trapping rain water" | Two pointers from both ends (max-left, max-right) |
| "Square of sorted array" | Two pointers (largest abs at ends) |
| "Merge two sorted arrays" | Two pointers (one per array) |
| "Intersection of two arrays" | Two pointers if sorted |

---

## The FAANG Decision Flowchart

```mermaid
flowchart TD
    START([START: Read problem])
    A{Sorted array + pair/triplet?}
    B{Linked list? cycle/middle?}
    C{In-place partition/deduplicate?}
    D{Can sort?}
    E[OPPOSITE-DIRECTION<br/>L from left, R from right]
    F[SAME-DIRECTION<br/>fast/slow]
    G[PARTITION or READ/WRITE pointers]
    H[Sort first, then opposite-direction]
    I[Consider Hash Map, Sliding Window, etc.]

    START --> A
    A -- Yes --> E
    A -- No --> B
    B -- Yes --> F
    B -- No --> C
    C -- Yes --> G
    C -- No --> D
    D -- Yes --> H
    D -- No --> I

    style A fill:#ffd43b,color:#000
    style B fill:#ffd43b,color:#000
    style C fill:#ffd43b,color:#000
    style D fill:#ffd43b,color:#000
    style E fill:#51cf66,color:#fff
    style F fill:#51cf66,color:#fff
    style G fill:#51cf66,color:#fff
    style H fill:#51cf66,color:#fff
    style I fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
                    START: Read problem
                         │
                ┌────────▼────────┐
                │ Sorted array +  │──── Yes ──→ OPPOSITE-DIRECTION
                │ pair/triplet?   │             (L from left, R from right)
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ Linked list?    │──── Yes ──→ SAME-DIRECTION
                │ (cycle/middle)  │             (fast/slow)
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ In-place       │──── Yes ──→ PARTITION or
                │ partition/     │             READ/WRITE pointers
                │ deduplicate?   │
                └────────┬────────┘
                         │ No
                ┌────────▼────────┐
                │ Can sort?       │──── Yes ──→ Sort first, then
                │                 │             opposite-direction
                └────────┬────────┘
                         │ No
                         ▼
                   Consider Hash Map,
                   Sliding Window, etc.
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Two Pointers
OPPOSITE:           L←→R, move based on comparison vs target
SAME:               slow/fast, fast=2× for cycle
PARTITION:          low, mid, high — three regions
MOVE RULE:          Sum>target → R--; Sum<target → L++
CYCLE RULE:         fast=2×slow; meet ⇒ cycle
3SUM:               Fix i, two-pointer on [i+1..n]
INTERVIEW LINE:     "Given the sorted property, I'll use two pointers
                     to converge from both ends, moving based on
                     whether the current sum is too high or too low."
```
