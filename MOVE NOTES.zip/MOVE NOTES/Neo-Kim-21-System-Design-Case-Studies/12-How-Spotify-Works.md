# How Spotify Works - System Design

> Source: https://newsletter.systemdesign.one/p/spotify-system-design

## One-Line Summary
Spotify streams 30M+ songs to 500K+ users using blob storage (S3) for audio files with signed URLs, adaptive bitrate streaming (HLS/DASH), CDN for low-latency delivery, and a stateless API layer for metadata.

## Key Requirements

### Functional
- Artists upload songs
- Users search and play songs
- Users create and manage playlists
- User profiles and preferences
- Multiple audio quality levels (64, 128, 320 kbps)

### Non-Functional
- Fast playback start time
- Minimal rebuffering during playback
- Adaptive quality based on network conditions
- Scalable storage (90+ TB audio data)
- Cost-effective bandwidth management

## Capacity Planning

| Metric | Value |
|--------|-------|
| Songs | 30 million |
| Avg song size | 3 MB (128kbps) |
| Raw audio storage | ~90 TB |
| With replicas | 180-270 TB (2-3x) |
| Song metadata | ~3 GB (100 bytes × 30M) |
| User metadata | ~0.5 GB (1 KB × 500K) |
| Songs per user/day | 10-15 |

## High-Level Architecture

```
Mobile/Web Client
      |
  Load Balancer (health checks every 30s)
      |
  API Servers (stateless)
      ├── Auth (JWT validation)
      ├── Song Metadata (SQL DB)
      ├── Playlist Service
      ├── Search Service
      └── Analytics Service
              |
      +-------+-------+
      |               |
  SQL Database    Blob Storage (S3)
  (metadata)      (audio files)
                      |
                    CDN
                      |
                  Client Player
                  (adaptive streaming)
```

## Core Components Deep Dive

### 1. Audio Storage (Blob Storage / S3)
- All audio files stored in S3 (virtually unlimited scaling)
- Organized: `/artist/album/song.ogg`
- Each song stored in multiple bitrates: 64kbps, 128kbps, 320kbps
- Accessed via **signed URLs** (expire after a few hours for security)
- Replicated across multiple regions for durability
- Built-in 99.999999999% durability

### 2. Audio Streaming Flow
```
1. User hits play → app sends GET /songs/{id}
2. API server validates JWT token
3. API server queries SQL DB for song metadata
4. API server generates signed URL for S3/CDN
5. Client streams audio chunks (HTTP range requests)
6. Adaptive bitrate: HLS or DASH protocol
7. Client reports play event: POST /songs/{id}/play
```

### 3. Adaptive Bitrate Streaming
- Songs pre-encoded in multiple quality levels:
  - 64kbps (mobile data saving)
  - 128kbps (standard quality)
  - 320kbps (premium users)
- Client uses HTTP range requests for chunk-by-chunk streaming
- Automatically switches bitrate based on network speed
- Handles rebuffering by downgrading quality temporarily

### 4. API Layer (Stateless)
- Handles: authentication, metadata queries, signed URL generation, analytics
- **Circuit breakers** for DB connections (prevent cascading failures)
- **Connection pooling** for database efficiency
- **Fallback responses** for non-critical features when dependencies down
- Stateless design → easy horizontal scaling

### 5. Load Balancer
- Round-robin or least-connections algorithms
- Health checks every 30 seconds
- Removes unhealthy instances automatically
- Handles traffic spikes (album releases)
- Enables zero-downtime deployments

### 6. Song Upload Flow (Artist)
```
1. Artist uploads song file
2. Server validates format and metadata
3. Audio transcoded into multiple bitrate versions
4. All versions stored to S3
5. Metadata saved to SQL database
6. Song becomes searchable after indexing
```

### 7. Local Caching (Client-Side)
- Recently played songs cached locally on device
- Faster replay of same songs (no network needed)
- Offline playback for premium users (download feature)
- Cache eviction when storage is low

## Key Design Decisions

| Decision | Why |
|----------|-----|
| S3 for audio | Virtually unlimited, 11-nines durability, cost-effective |
| Signed URLs | Secure time-limited access, no auth per chunk |
| Multiple bitrate encodings | Adaptive streaming for varying networks |
| Stateless API servers | Easy horizontal scaling |
| SQL for metadata | Relational data (songs, artists, playlists), fast lookups |
| HTTP range requests | Stream chunks, don't download full file |
| Client-side caching | Faster replay, offline support |

## Data Model

```
Songs:
  song_id, title, artist_id, album_id, duration,
  genre, file_urls (JSON: {64kbps, 128kbps, 320kbps}),
  created_at

Artists:
  artist_id, name, bio, avatar_url

Playlists:
  playlist_id, user_id, name, created_at

Playlist_Songs:
  playlist_id, song_id, position, added_at

Users:
  user_id, name, email, plan (free/premium), preferences
```

## Spotify vs YouTube (Audio vs Video)

| Aspect | Spotify | YouTube |
|--------|---------|---------|
| File size | ~3 MB/song | 100s MB - GBs/video |
| Transcoding | Multiple bitrates | Multiple resolutions + bitrates |
| Streaming | HLS/DASH audio | HLS/DASH video |
| CDN importance | High | Critical (much larger files) |
| Upload complexity | Simple | Very complex (multipart, resume) |
| Storage | ~90 TB for 30M songs | Exabyte-level |

## Scaling Strategies

1. **CDN** for audio delivery (most listens are popular songs → high cache hit)
2. **S3 replication** across regions for global access
3. **Stateless API** servers scaled horizontally behind load balancer
4. **Client-side caching** reduces repeat stream bandwidth
5. **Multiple bitrate pre-encoding** enables adaptive quality
6. **Database read replicas** for metadata queries

## Interview Tips

- Start with capacity estimation (show the math: 3MB × 30M songs)
- Emphasize that **audio dominates** both storage and bandwidth (metadata is tiny)
- Explain the streaming flow: metadata API → signed URL → CDN → range requests
- Discuss **adaptive bitrate** switching for varying network conditions
- Mention **signed URLs** for security (time-limited, scoped)
- Compare with YouTube (audio is simpler but same patterns)
- Don't forget: circuit breakers, connection pooling, fallback responses

## Quick Revision (5 bullet points)

1. **Audio in S3** (~90 TB for 30M songs), pre-encoded at 3 bitrates (64/128/320 kbps); accessed via signed URLs through CDN
2. **Streaming flow**: GET metadata → generate signed URL → client streams chunks via HTTP range requests with adaptive bitrate (HLS/DASH)
3. **Stateless API servers** handle auth + metadata + analytics; circuit breakers prevent cascading failures
4. **Client-side caching** of recently played songs for instant replay and offline playback
5. **Key insight**: audio storage/bandwidth dominates costs; metadata (3 GB) is tiny compared to audio (90+ TB)
