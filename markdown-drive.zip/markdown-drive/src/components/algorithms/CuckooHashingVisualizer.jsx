import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function h1(k, m) {
  return k % m;
}
function h2(k, m) {
  if (m <= 1) return 0;
  return 1 + (Math.abs(Math.floor(k / 7)) % (m - 1));
}

function flatCells(t0, t1) {
  return [...t0.map((v) => (v == null ? '·' : String(v))), '|', ...t1.map((v) => (v == null ? '·' : String(v)))];
}

function generateSteps(keys, m) {
  const t0 = Array(m).fill(null);
  const t1 = Array(m).fill(null);
  const steps = [];

  for (const key of keys) {
    let k = key;
    let cur = 0;
    let placed = false;
    for (let hop = 0; hop < m * 4; hop++) {
      const slot = cur === 0 ? h1(k, m) : h2(k, m);
      steps.push({
        type: 'try',
        key: k,
        table: cur,
        slot,
        cells: flatCells(t0, t1),
      });
      const tbl = cur === 0 ? t0 : t1;
      const evicted = tbl[slot];
      if (evicted == null) {
        tbl[slot] = k;
        steps.push({
          type: 'place',
          key: k,
          table: cur,
          slot,
          cells: flatCells(t0, t1),
        });
        placed = true;
        break;
      }
      tbl[slot] = k;
      steps.push({
        type: 'evict',
        key: k,
        table: cur,
        slot,
        evicted,
        cells: flatCells(t0, t1),
      });
      k = evicted;
      cur = 1 - cur;
    }
    if (!placed) steps.push({ type: 'cycle', cells: flatCells(t0, t1), key: k });
  }

  steps.push({ type: 'done', cells: flatCells(t0, t1) });
  return steps;
}

export default function CuckooHashingVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const m = 5;
    const keys = [3, 8, 13, 18, 23, 28, 33];
    const steps = generateSteps(keys, m);
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({
      time: '0s',
      type: 'info',
      message: `Two tables ×${m}; h1(k)=k%${m}, h2(k)=1+(⌊k/7⌋ mod ${Math.max(1, m - 1)})`,
    });
    canvasRef.current?.setState({
      cells: steps[0].cells,
      colors: {},
      title: 'T0 slots | divider | T1 slots',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    const cells = step.cells || [];
    const sep = cells.indexOf('|');
    const paint = (table, slot, color) => {
      const offset = table === 0 ? 0 : sep + 1;
      const idx = offset + slot;
      if (idx >= 0 && idx < cells.length && cells[idx] !== '|') colors[idx] = color;
    };
    if (step.type === 'try' || step.type === 'place' || step.type === 'evict') {
      paint(step.table, step.slot, step.type === 'place' ? 'sorted' : 'active');
    }
    if (step.type === 'evict') store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Evict ${step.evicted}, carry to other table` });
    else if (step.type === 'try') store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Try ${step.key} in T${step.table}[${step.slot}]` });
    else if (step.type === 'place') store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Placed ${step.key} at T${step.table}[${step.slot}]` });
    else if (step.type === 'cycle') store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Rehash needed (cycle)' });
    else store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Cuckoo walk complete' });
    canvasRef.current?.setState({ cells, colors, title: 'T0 | T1' });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
