# Distributed Systems — Design Template

> **Permanent Recall:** Use Raft for consensus and leader election. RedLock for distributed locks (with fencing caveats). ZooKeeper for config, locks, leader election. Heartbeat systems need interval + timeout. Gossip for epidemic dissemination. Each template includes architecture diagram and pseudocode—reuse these in FAANG design discussions.

---

## Consensus Implementation Template (Raft-Based)

**When to use:** Need agreed-upon log or state across nodes (config, metadata).

```
ARCHITECTURE: Raft Cluster

         Client
            │
            ▼
    ┌───────────────┐
    │    Leader     │  ← Single writer
    │  (elected)    │
    └───────┬───────┘
            │ AppendEntries
     ┌──────┼──────┐
     ▼      ▼      ▼
  Follower Follower Follower
```

**Pseudocode:**
```
// Leader election
on timeout():
    become Candidate; increment term
    vote for self; request votes from all
    if majority votes: become Leader; start heartbeats

// Log replication (Leader)
on client_request(cmd):
    append to local log
    replicate to followers (AppendEntries)
    when majority ack: commit; apply to state machine; respond
```

---

## Leader Election Template

**When to use:** Single active instance for a service (job scheduler, write coordinator).

```
LEADER ELECTION FLOW:

  All nodes start as Followers
       │
       ▼ (election timeout, no leader seen)
  Become Candidate → RequestVote RPC
       │
       ▼ (majority grants vote)
  Become Leader → Send heartbeats
       │
       ▼ (another leader with higher term seen)
  Step down to Follower
```

**Config:**
```yaml
election_timeout: 150-300ms  # Randomize to avoid split vote
heartbeat_interval: 50ms
cluster_size: 3 or 5  # Odd for quorum
```

---

## Distributed Lock Template (RedLock)

**When to use:** Mutex across processes; Redis available. Use with caution—fencing recommended.

```
REDLOCK FLOW:

  1. Get current time T1
  2. Acquire lock on N/2+1 Redis instances (same key, same value, TTL)
  3. Get time T2; elapsed = T2-T1
  4. If elapsed < TTL and majority acquired: LOCK HELD
  5. Hold for (TTL - elapsed - clock_drift_buffer)
  6. Release on all instances
```

**Pseudocode:**
```
function acquire_lock(resource, ttl_ms):
    start = now()
    for instance in redis_instances:
        acquired += instance.set(key, token, nx=true, px=ttl_ms)
    elapsed = now() - start
    if acquired >= majority and elapsed < ttl_ms * 0.8:
        return token  # Include token for fencing!
    else:
        release_all(); return fail
```

> **FAANG Tip:** Mention "we'd add fencing tokens—monotonic counter from a CP store—to reject stale lock holders."

---

## ZooKeeper Usage Template

**When to use:** Config, leader election, locks, service discovery.

```
ZOOKEEPER PATTERNS:

  Config:        /config/key  → value (watchers for updates)
  Leader:        /election    → ephemeral node, smallest wins
  Lock:          /locks/resource  → create seq ephemeral, smallest holds
  Discovery:     /services/foo  → children = instances
```

**Pseudocode (Leader Election):**
```
try:
    zk.create("/election/n_", data, EPHEMERAL_SEQUENTIAL)
    children = zk.get_children("/election")
    if I am smallest: I am leader
    else: watch the node smaller than me; when it dies, recheck
```

---

## Heartbeat System Template

**When to use:** Failure detection, cluster membership.

```
HEARTBEAT ARCHITECTURE:

  Node A ──heartbeat every I ms──► Node B
       ◄──ack────────────────────
       
  B maintains: last_seen[A]
  if now() - last_seen[A] > T: mark A as dead
```

**Pseudocode:**
```
// Sender
every interval:
    send heartbeat to all peers
    reset local timer

// Receiver
on heartbeat(sender):
    last_seen[sender] = now()
    reply ack

// Checker
every check_interval:
    for peer in peers:
        if now() - last_seen[peer] > timeout:
            mark_dead(peer); trigger failover
```

**Parameters:**

| Param | Typical | Trade-off |
|-------|---------|-----------|
| Interval | 100-500ms | Lower = faster detection, more traffic |
| Timeout | 2-3× interval | Lower = more false positives |

---

## Gossip Protocol Template

**When to use:** Membership, config dissemination, eventually consistent state.

```
GOSSIP: Push or Pull

  Push:  I have state S → tell random peers
  Pull:  Ask random peer "what do you have?"
  Push-Pull: Both
```

**Pseudocode:**
```
on gossip_interval():
    peer = random_member(exclude=self)
    send state_digest to peer
    peer responds with its state
    merge(states)  # resolve conflicts
    update local state
```

**Convergence:** O(log N) rounds to reach all nodes with high probability.

---

## Template Summary Table

| Need | Template | Key Config |
|------|----------|------------|
| Consensus | Raft | Odd N, election timeout |
| Leader election | Raft or ZK ephemeral | Quorum |
| Distributed lock | RedLock + fencing | TTL, majority |
| Coordination | ZooKeeper | Path design |
| Failure detection | Heartbeat | Interval, timeout |
| Dissemination | Gossip | Fanout, merge fn |

---

## 30-SECOND REVISION BOX

```
RAFT: Leader + log replication, quorum
REDLOCK: N/2+1 instances, TTL, add fencing
ZK: Ephemeral for leader, seq for locks
HEARTBEAT: Interval + timeout, 2-3× ratio
GOSSIP: Push/pull, O(log N) convergence
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
