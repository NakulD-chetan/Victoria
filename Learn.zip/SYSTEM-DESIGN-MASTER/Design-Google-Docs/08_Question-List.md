# Design Google Docs — Question List

> **Permanent Recall:** Variations: "Add spreadsheet support," "Design Figma (collaborative design tool)," "Add comments and suggestions," "Handle 1000 concurrent editors," "Design offline-first editing." Related: Notion, Confluence, Miro. Master conflict resolution, then apply to variations.

---

## Core Variations

| Question | Focus | Difficulty |
|----------|-------|------------|
| Design Google Docs | Full: OT/CRDT, real-time, storage, presence, history | Hard |
| Add **spreadsheet support** | Cell model; formulas; references; different OT | Hard |
| Design **Figma** (collaborative design tool) | CRDT for vectors; objects, layers; real-time | Hard |
| Add **comments and suggestions** | Anchored to text; suggest mode (track changes); resolution | Medium |
| Handle **1000 concurrent editors** | Scale; throttle; batch; hotspot handling | Hard |
| Design **offline-first editing** | Queue; sync; CRDT favored (local merge) | Medium |
| Design **Notion** (blocks, databases) | Block-level CRDT; linked DBs; richer model | Hard |
| Design **Confluence** (wiki) | Similar to Docs; pages; permissions; comments | Medium |
| Design **Miro** (whiteboard) | Shapes, lines; CRDT/OT for non-text primitives | Hard |

---

## Follow-Up / Deep-Dive Questions

| Question | What They Test |
|----------|----------------|
| How does OT work? | Transform rules; convergence; example |
| OT vs CRDT? | Trade-offs; server vs P2P; offline |
| How handle 100 users on same paragraph? | Throttling; batching; scaling |
| Offline: what happens on reconnect? | Queue; transform against server ops; reconcile |
| Version history: how implement? | Operation log; replay; snapshots |
| How prevent document corruption? | Transform correctness; checksums; replay |
| Add spreadsheet: what changes? | Cell model; formula dependencies; references |
| Add comments: data model? | Anchor to block+offset; thread; resolve |
| How do you handle permission changes? | Reject new ops; client read-only mode |
| Very large document (100K words)? | Chunking; lazy load; virtualization |

---

## Related Designs

| Design | Overlap | Key Difference |
|--------|---------|-----------------|
| **Figma** | Real-time collaboration, CRDT | Vector graphics; layers; not text |
| **Notion** | Blocks, collaborative | Blocks + databases; different primitives |
| **Confluence** | Wiki, collaborative | Pages; hierarchy; similar sync |
| **Miro** | Real-time whiteboard | Shapes, lines; spatial |
| **Figma** | CRDT, presence | Design primitives vs text |
| **Dropbox** | Sync, conflict | File-level; different conflict model |
| **Chat (Slack)** | Real-time | Message ordering; no concurrent edit of same message |

---

## Full Question List (15+)

1. Design Google Docs
2. Design a real-time collaborative document editor
3. Add **spreadsheet support** to Google Docs
4. Design **Figma** (collaborative design tool)
5. Add **comments and suggestions** to collaborative docs
6. Handle **1000 concurrent editors** on one document
7. Design **offline-first** collaborative editing
8. Design **Notion** (block-based collaborative editor)
9. Design **Confluence** (collaborative wiki)
10. Design **Miro** (collaborative whiteboard)
11. How does Operational Transformation work?
12. Compare OT vs CRDT
13. How do you implement version history?
14. Design cursor presence (see where others are typing)
15. How handle offline user reconnecting with conflicts?
16. Design for very large documents (100K+ words)

---

## Difficulty Guide

| Difficulty | Questions |
|------------|-----------|
| **Hard** | Google Docs, Figma, spreadsheet support, 1000 editors, Notion, Miro |
| **Medium** | Comments/suggestions, offline-first, Confluence, version history, presence |
| **Foundation** | OT vs CRDT, conflict resolution, basic architecture |

> **FAANG Tip:** "Add spreadsheet support" = new data model (cells, formulas), formula dependency graph, cell references. OT/CRDT for cells is more complex than text.

---

## Prep Strategy

1. **Master conflict resolution** — OT and CRDT; when to use which
2. **Concrete OT example** — Insert + Delete; walk through transform
3. **Architecture** — Client → WebSocket → Collaboration Service → Storage
4. **Storage** — Snapshot + operation log
5. **Variations** — Spreadsheet = cell model; Figma = CRDT for vectors; comments = anchor + thread

---

## Quick Reference: What to Design per Question

| Question | Must Include |
|----------|--------------|
| Google Docs | OT or CRDT, WebSocket, snapshot+log, presence, version history, offline |
| + Spreadsheet | Cell model, formulas, references, dependency graph; different OT |
| + Figma | CRDT (Yjs-type), vectors, layers; real-time; presence |
| + Comments | Anchor (block, offset), thread, resolve; separate from content ops |
| + 1000 editors | Throttle, batch, scale by doc; consider CRDT P2P |
| + Offline-first | CRDT preferred; queue + merge; or OT with server transform on reconnect |
| + Notion | Block-level CRDT; databases; linked blocks |
| + Miro | Shape/layout primitives; CRDT or OT for non-text |

---

## Bonus Questions

17. Design **suggestions mode** (track changes, accept/reject)
18. Add **rich text** (bold, italic, links) to OT model
19. How would you **migrate** from OT to CRDT?
20. Design **real-time collaborative code editor** (like VS Code Live Share)
21. Handle **conflicting offline edits** from same user on two devices
22. Design **document templates** with collaborative editing

---

## Cross-Reference

- **Design Figma** → Same conflict resolution; different primitives (vectors vs text)
- **Design Notion** → Block model; similar; adds databases
- **Design WhatsApp** → Real-time messaging; different (no concurrent edit of same content)
- **Design Dropbox** → File sync; different conflict model (file-level)

---

## Summary

15+ question variations; core = conflict resolution (OT/CRDT) + WebSocket + snapshot+log + presence + version history. Variations: spreadsheet (cell model), Figma (CRDT, vectors), comments, scale, offline, Notion, Miro. Related: Confluence, Dropbox, chat.

---

## Last-Minute Prep

Before interview: Review 01_Concept (conflict resolution, scale), 02_Mental-Model (OT vs CRDT), 03_Design-Template (architecture, OT example), 05_Common-Mistakes (no last write wins, don't over-implement OT).
