# Lazy Evaluation in Spark

**Lazy Evaluation** means Spark does **not** execute transformations immediately. Instead, it records them in a logical plan (DAG) and waits until an **Action** is triggered.

---

## How It Works

### Transformations = Lazy (recorded but NOT executed)
```python
df_filtered = df.filter(col("age") > 30)     # Nothing happens
df_selected = df_filtered.select("name")      # Still nothing
df_joined = df_selected.join(df2, "id")       # Still just planning
```

### Actions = Trigger execution
```python
df_joined.show()     # NOW Spark executes everything
df_joined.count()    # This also triggers execution
df_joined.write.parquet("output/")  # This too
```

**Common Actions**: `show()`, `count()`, `collect()`, `take()`, `write()`, `foreach()`, `first()`

---

## Why is Lazy Evaluation Important?

### 1. Optimization Before Execution

Because Spark sees the **entire pipeline** before running anything, the **Catalyst Optimizer** can apply powerful optimizations:

| Optimization           | What It Does                                        | Example                                      |
|------------------------|-----------------------------------------------------|-----------------------------------------------|
| Predicate Pushdown     | Pushes filters to the data source (reads less data) | Filter applied at Parquet/CSV scan level      |
| Column Pruning         | Reads only the columns you actually use              | 50-column table but you `select("name")` → reads 1 |
| Constant Folding       | Evaluates constant math at compile time              | `col("qty") + (4 * 5)` → `col("qty") + 20`  |
| Join Reordering        | Picks the best join order based on table sizes       | Joins smallest table first                    |
| Combining Filters      | Merges multiple filters into one                     | Two `.filter()` calls become one              |

### 2. Pipelining Narrow Transformations

Multiple narrow transformations run in a **single pass** over the data:

```python
df.filter(...).select(...).withColumn(...)
```

All three run together on each partition — no intermediate data is written. This is only possible because Spark waits and plans first.

### 3. Reduced I/O and Faster Execution

Because Spark optimizes before running:
- Reads only required columns (less disk I/O)
- Applies filters early (less data to process)
- Avoids unnecessary recomputations
- Eliminates dead code/useless operations

---

## Step-by-Step Internal Flow

```
Step 1: You write transformations → Spark creates a DAG (no execution)
Step 2: You call an Action → Spark starts a Job
Step 3: Catalyst Optimizer generates the best logical & physical plan
Step 4: DAG Scheduler breaks the plan into Stages
Step 5: Task Scheduler assigns Tasks to executor cores
Step 6: Executors run the tasks and return results
```

---

## Common Mistake

Many beginners think each transformation line runs immediately (like Pandas). In Spark, nothing runs until an action. This means:

```python
df2 = df.filter(col("age") > 30)  # No computation yet
df3 = df2.select("name")          # Still no computation
# If you never call an action on df3, the above code does NOTHING at all
```

---

## Key Takeaway

> Lazy evaluation lets Spark build the entire DAG first, optimize it using the Catalyst Optimizer, and execute only the **most efficient physical plan** when an Action is called. This reduces I/O, avoids unnecessary computation, and enables powerful optimizations.
