/*
 * Geometry and binding behavior adapted from Excalidraw's MIT-licensed
 * element binding model. This implementation is intentionally small and
 * tailored to InkDrop's custom widget elements.
 */

const BINDING_GAP = 10;
const ROUTE_MARGIN = 18;
const GRID = 20;

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

export function elementBounds(element) {
  if (!element) return { x: 0, y: 0, w: 0, h: 0 };
  if (element.type === 'line' || element.type === 'arrow') {
    const points = worldPointsForLinear(element);
    const xs = points.map((point) => point.x);
    const ys = points.map((point) => point.y);
    const minX = Math.min(...xs);
    const minY = Math.min(...ys);
    return {
      x: minX,
      y: minY,
      w: Math.max(...xs) - minX,
      h: Math.max(...ys) - minY,
    };
  }
  return {
    x: Number(element.x) || 0,
    y: Number(element.y) || 0,
    w: Math.abs(Number(element.w ?? element.width) || 0),
    h: Math.abs(Number(element.h ?? element.height) || 0),
  };
}

export function worldPointsForLinear(element) {
  if (Array.isArray(element?.points) && element.points.length >= 2) {
    return element.points.map((point) => ({
      x: element.x + (Number(point?.[0]) || 0),
      y: element.y + (Number(point?.[1]) || 0),
    }));
  }
  return [
    { x: element?.x || 0, y: element?.y || 0 },
    { x: element?.x2 || element?.x || 0, y: element?.y2 || element?.y || 0 },
  ];
}

function centerOf(element) {
  const bounds = elementBounds(element);
  return { x: bounds.x + bounds.w / 2, y: bounds.y + bounds.h / 2 };
}

function fixedPointForSide(side) {
  if (side === 'left') return [0, 0.5];
  if (side === 'right') return [1, 0.5];
  if (side === 'top') return [0.5, 0];
  return [0.5, 1];
}

function namedPort(target, portId) {
  if (!portId) return null;
  const ports = target?.customData?.ports;
  if (!ports || typeof ports !== 'object') return null;
  const port = ports[portId];
  if (!port || !Array.isArray(port.fixedPoint)) return null;
  return port;
}

export function chooseBindingSide(target, toward) {
  const bounds = elementBounds(target);
  const center = centerOf(target);
  const dx = toward.x - center.x;
  const dy = toward.y - center.y;
  const horizontalWeight = Math.abs(dx) / Math.max(1, bounds.w);
  const verticalWeight = Math.abs(dy) / Math.max(1, bounds.h);
  if (horizontalWeight >= verticalWeight) return dx >= 0 ? 'right' : 'left';
  return dy >= 0 ? 'bottom' : 'top';
}

export function makeBinding(target, toward, options = 'orbit') {
  const normalized = typeof options === 'string' ? { mode: options } : (options || {});
  const port = namedPort(target, normalized.portId);
  const side = port?.side || normalized.side || chooseBindingSide(target, toward);
  return {
    elementId: target.id,
    fixedPoint: port?.fixedPoint || normalized.fixedPoint || fixedPointForSide(side),
    mode: port?.mode || normalized.mode || 'orbit',
    side,
    gap: Number(port?.gap ?? normalized.gap ?? BINDING_GAP),
    portId: port ? normalized.portId : null,
  };
}

export function pointForBinding(target, binding) {
  const bounds = elementBounds(target);
  const fixedPoint = Array.isArray(binding?.fixedPoint)
    ? binding.fixedPoint
    : fixedPointForSide(binding?.side || 'right');
  const side = binding?.side || (
    fixedPoint[0] <= 0 ? 'left'
      : fixedPoint[0] >= 1 ? 'right'
        : fixedPoint[1] <= 0 ? 'top'
          : 'bottom'
  );
  const gap = binding?.mode === 'inside' ? 0 : Number(binding?.gap ?? BINDING_GAP);
  const point = {
    x: bounds.x + bounds.w * clamp(fixedPoint[0], 0, 1),
    y: bounds.y + bounds.h * clamp(fixedPoint[1], 0, 1),
  };
  if (side === 'left') point.x -= gap;
  if (side === 'right') point.x += gap;
  if (side === 'top') point.y -= gap;
  if (side === 'bottom') point.y += gap;
  return point;
}

function expandedObstacle(element) {
  const bounds = elementBounds(element);
  return {
    x: bounds.x - ROUTE_MARGIN,
    y: bounds.y - ROUTE_MARGIN,
    w: bounds.w + ROUTE_MARGIN * 2,
    h: bounds.h + ROUTE_MARGIN * 2,
  };
}

function pointInsideRect(point, rect) {
  return point.x > rect.x
    && point.x < rect.x + rect.w
    && point.y > rect.y
    && point.y < rect.y + rect.h;
}

function segmentIntersectsRect(a, b, rect) {
  if (pointInsideRect(a, rect) || pointInsideRect(b, rect)) return true;
  if (a.x === b.x) {
    return a.x > rect.x
      && a.x < rect.x + rect.w
      && Math.max(a.y, b.y) > rect.y
      && Math.min(a.y, b.y) < rect.y + rect.h;
  }
  if (a.y === b.y) {
    return a.y > rect.y
      && a.y < rect.y + rect.h
      && Math.max(a.x, b.x) > rect.x
      && Math.min(a.x, b.x) < rect.x + rect.w;
  }
  return false;
}

function routeIsClear(points, obstacles) {
  for (let index = 1; index < points.length; index += 1) {
    if (obstacles.some((obstacle) => segmentIntersectsRect(points[index - 1], points[index], obstacle))) {
      return false;
    }
  }
  return true;
}

function routeLength(points) {
  let length = 0;
  for (let index = 1; index < points.length; index += 1) {
    length += Math.abs(points[index].x - points[index - 1].x);
    length += Math.abs(points[index].y - points[index - 1].y);
  }
  return length + Math.max(0, points.length - 2) * 16;
}

function dedupeCollinear(points) {
  return points.filter((point, index) => {
    if (index === 0 || index === points.length - 1) return true;
    const before = points[index - 1];
    const after = points[index + 1];
    return !(
      (before.x === point.x && point.x === after.x)
      || (before.y === point.y && point.y === after.y)
    );
  });
}

function routeWithAStar(start, end, obstacles) {
  const origin = {
    x: Math.round(start.x / GRID) * GRID,
    y: Math.round(start.y / GRID) * GRID,
  };
  const goal = {
    x: Math.round(end.x / GRID) * GRID,
    y: Math.round(end.y / GRID) * GRID,
  };
  const minX = Math.floor((Math.min(start.x, end.x) - 320) / GRID) * GRID;
  const maxX = Math.ceil((Math.max(start.x, end.x) + 320) / GRID) * GRID;
  const minY = Math.floor((Math.min(start.y, end.y) - 320) / GRID) * GRID;
  const maxY = Math.ceil((Math.max(start.y, end.y) + 320) / GRID) * GRID;
  const directions = [
    { x: GRID, y: 0, name: 'right' },
    { x: -GRID, y: 0, name: 'left' },
    { x: 0, y: GRID, name: 'down' },
    { x: 0, y: -GRID, name: 'up' },
  ];
  const keyFor = (point, direction = 'start') => `${point.x}:${point.y}:${direction}`;
  const heuristic = (point) => Math.abs(goal.x - point.x) + Math.abs(goal.y - point.y);
  const isBlocked = (point) => obstacles.some((obstacle) => pointInsideRect(point, obstacle));
  const open = [{
    point: origin,
    direction: 'start',
    cost: 0,
    score: heuristic(origin),
    key: keyFor(origin),
  }];
  const bestCost = new Map([[keyFor(origin), 0]]);
  const previous = new Map();
  let finalNode = null;
  let explored = 0;

  while (open.length && explored < 7000) {
    explored += 1;
    let bestIndex = 0;
    for (let index = 1; index < open.length; index += 1) {
      if (open[index].score < open[bestIndex].score) bestIndex = index;
    }
    const current = open.splice(bestIndex, 1)[0];
    if (current.point.x === goal.x && current.point.y === goal.y) {
      finalNode = current;
      break;
    }

    directions.forEach((direction) => {
      const nextPoint = {
        x: current.point.x + direction.x,
        y: current.point.y + direction.y,
      };
      if (nextPoint.x < minX || nextPoint.x > maxX || nextPoint.y < minY || nextPoint.y > maxY) return;
      if (isBlocked(nextPoint)) return;
      if (!routeIsClear([current.point, nextPoint], obstacles)) return;
      const bendCost = current.direction === 'start' || current.direction === direction.name ? 0 : GRID * 0.8;
      const cost = current.cost + GRID + bendCost;
      const key = keyFor(nextPoint, direction.name);
      if (cost >= (bestCost.get(key) ?? Infinity)) return;
      bestCost.set(key, cost);
      previous.set(key, current);
      open.push({
        point: nextPoint,
        direction: direction.name,
        cost,
        score: cost + heuristic(nextPoint),
        key,
      });
    });
  }

  if (!finalNode) return null;
  const gridPath = [];
  let cursor = finalNode;
  while (cursor) {
    gridPath.push(cursor.point);
    cursor = previous.get(cursor.key) || null;
  }
  gridPath.reverse();

  const approaches = [
    [start, { x: origin.x, y: start.y }, origin],
    [start, { x: start.x, y: origin.y }, origin],
  ];
  const departures = [
    [goal, { x: end.x, y: goal.y }, end],
    [goal, { x: goal.x, y: end.y }, end],
  ];
  for (const approach of approaches) {
    for (const departure of departures) {
      const route = dedupeCollinear([
        ...approach,
        ...gridPath.slice(1, -1),
        ...departure,
      ]);
      if (routeIsClear(route, obstacles)) return route;
    }
  }
  return null;
}

/**
 * Deterministic orthogonal router. Direct and single-bend candidates are
 * preferred; bounded A* handles crowded teaching layouts before a final
 * deterministic channel sweep fallback.
 */
export function routeOrthogonal(start, end, sceneElements, ignoredIds = []) {
  const ignored = new Set(ignoredIds);
  const obstacles = (sceneElements || [])
    .filter((element) => !element.isDeleted)
    .filter((element) => !ignored.has(element.id))
    .filter((element) => !['arrow', 'line', 'text'].includes(element.type))
    .map(expandedObstacle);

  const simpleCandidates = [
    [start, { x: end.x, y: start.y }, end],
    [start, { x: start.x, y: end.y }, end],
  ];
  const simple = simpleCandidates
    .map(dedupeCollinear)
    .filter((candidate) => routeIsClear(candidate, obstacles))
    .sort((a, b) => routeLength(a) - routeLength(b));
  if (simple.length) return simple[0];

  const aStarRoute = routeWithAStar(start, end, obstacles);
  if (aStarRoute) return aStarRoute;

  const candidates = [];
  const minX = Math.min(start.x, end.x) - 240;
  const maxX = Math.max(start.x, end.x) + 240;
  const minY = Math.min(start.y, end.y) - 240;
  const maxY = Math.max(start.y, end.y) + 240;

  for (let x = Math.floor(minX / GRID) * GRID; x <= maxX; x += GRID) {
    candidates.push([start, { x, y: start.y }, { x, y: end.y }, end]);
  }
  for (let y = Math.floor(minY / GRID) * GRID; y <= maxY; y += GRID) {
    candidates.push([start, { x: start.x, y }, { x: end.x, y }, end]);
  }

  const clear = candidates
    .map(dedupeCollinear)
    .filter((candidate) => routeIsClear(candidate, obstacles))
    .sort((a, b) => routeLength(a) - routeLength(b));

  return clear[0] || dedupeCollinear(simpleCandidates[0]);
}

function normalizeLinearFromWorld(element, points) {
  const origin = points[0];
  const localPoints = points.map((point) => [point.x - origin.x, point.y - origin.y]);
  const last = points[points.length - 1];
  return {
    ...element,
    x: origin.x,
    y: origin.y,
    x2: last.x,
    y2: last.y,
    w: last.x - origin.x,
    h: last.y - origin.y,
    width: Math.abs(last.x - origin.x),
    height: Math.abs(last.y - origin.y),
    points: localPoints,
  };
}

export function pointAlongPath(points, ratio = 0.5) {
  if (!points?.length) return { x: 0, y: 0 };
  if (points.length === 1) return points[0];
  const lengths = [];
  let total = 0;
  for (let index = 1; index < points.length; index += 1) {
    const length = Math.hypot(
      points[index].x - points[index - 1].x,
      points[index].y - points[index - 1].y,
    );
    lengths.push(length);
    total += length;
  }
  let target = total * clamp(ratio, 0, 1);
  for (let index = 0; index < lengths.length; index += 1) {
    if (target <= lengths[index]) {
      const amount = lengths[index] ? target / lengths[index] : 0;
      return {
        x: points[index].x + (points[index + 1].x - points[index].x) * amount,
        y: points[index].y + (points[index + 1].y - points[index].y) * amount,
      };
    }
    target -= lengths[index];
  }
  return points[points.length - 1];
}

export function resolveSceneBindings(elements) {
  const list = Array.isArray(elements) ? elements : [];
  const byId = new Map(list.map((element) => [element.id, element]));

  const resolved = list.map((element) => {
    if (element.isDeleted || element.type !== 'arrow') return element;
    const startTarget = element.startBinding ? byId.get(element.startBinding.elementId) : null;
    const endTarget = element.endBinding ? byId.get(element.endBinding.elementId) : null;
    const existing = worldPointsForLinear(element);
    const fallbackStart = existing[0];
    const fallbackEnd = existing[existing.length - 1];
    const start = startTarget ? pointForBinding(startTarget, element.startBinding) : fallbackStart;
    const end = endTarget ? pointForBinding(endTarget, element.endBinding) : fallbackEnd;
    const points = element.routing === 'straight' || element.elbowed === false
      ? [start, end]
      : routeOrthogonal(start, end, list, [
          element.id,
          startTarget?.id,
          endTarget?.id,
        ].filter(Boolean));
    return normalizeLinearFromWorld(element, points);
  });

  const resolvedById = new Map(resolved.map((element) => [element.id, element]));
  const withLabels = resolved.map((element) => {
    if (element.type !== 'text' || !element.containerId) return element;
    const container = resolvedById.get(element.containerId);
    if (!container) return element;
    const width = Number(element.w ?? element.width) || 0;
    const height = Number(element.h ?? element.height) || 0;
    const anchor = container.type === 'arrow'
      ? pointAlongPath(worldPointsForLinear(container), 0.5)
      : centerOf(container);
    return {
      ...element,
      x: anchor.x - width / 2,
      y: anchor.y - height / 2,
    };
  });

  const boundByTarget = new Map();
  withLabels.forEach((element) => {
    if (element.type === 'arrow') {
      [
        ['startBinding', 'arrow'],
        ['endBinding', 'arrow'],
      ].forEach(([key, type]) => {
        const targetId = element[key]?.elementId;
        if (!targetId) return;
        const entries = boundByTarget.get(targetId) || [];
        if (!entries.some((entry) => entry.id === element.id)) entries.push({ id: element.id, type });
        boundByTarget.set(targetId, entries);
      });
    }
    if (element.type === 'text' && element.containerId) {
      const entries = boundByTarget.get(element.containerId) || [];
      if (!entries.some((entry) => entry.id === element.id)) entries.push({ id: element.id, type: 'text' });
      boundByTarget.set(element.containerId, entries);
    }
  });

  return withLabels.map((element) => ({
    ...element,
    boundElements: boundByTarget.get(element.id) || element.boundElements || [],
  }));
}

export function createBoundArrow({
  id,
  from,
  to,
  fromPort = null,
  toPort = null,
  elements,
  labelId = null,
  style,
  customData,
}) {
  const startBinding = makeBinding(from, centerOf(to), { portId: fromPort });
  const endBinding = makeBinding(to, centerOf(from), { portId: toPort });
  const start = pointForBinding(from, startBinding);
  const end = pointForBinding(to, endBinding);
  const points = routeOrthogonal(start, end, elements, [from.id, to.id]);
  return normalizeLinearFromWorld({
    id,
    type: 'arrow',
    style,
    z: Math.max(from.z || 0, to.z || 0) + 1,
    isDeleted: false,
    createdAt: Date.now(),
    startBinding,
    endBinding,
    startArrowhead: null,
    endArrowhead: 'arrow',
    elbowed: true,
    routing: 'orthogonal',
    labelId,
    customData,
  }, points);
}
