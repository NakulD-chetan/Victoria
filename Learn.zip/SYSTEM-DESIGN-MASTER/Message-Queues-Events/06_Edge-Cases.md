# Message Queues and Events — Edge Cases

> **Permanent Recall:** Good messaging designs are easy in the happy path. The real system quality shows up in edge cases: **duplicates**, **lag**, **rebalances**, **ordering issues**, **poison messages**, **backlog growth**, **producer failures**, and **network partitions**.

---

## How To Use This File

For each edge case, train yourself to answer 3 questions:

1. What goes wrong?
2. Why does it happen?
3. What design choice fixes or limits the impact?

That structure works well in interviews too.

---

## Edge Case 1: Duplicate Delivery

### What goes wrong

The same message gets processed twice.

### Why it happens

- consumer crashes after processing but before ack/commit
- producer retries after timeout
- rebalance causes reprocessing

### Fix

- idempotent consumer
- message ID dedup
- natural-key upsert

```text
Process message -> crash before ack -> broker redelivers -> processed again
```

---

## Edge Case 2: Consumer Lag Keeps Growing

### What goes wrong

Messages are still being produced, but consumers are falling behind.

### Why it happens

- consumer is too slow
- not enough consumers
- too few partitions
- downstream DB or API is bottlenecking

### Fix

- scale consumers
- increase partitions if needed
- optimize consumer work
- batch writes
- add backpressure or rate limiting upstream

**Important metric:** `lag = latest offset - committed/processed offset`

---

## Edge Case 3: Kafka Rebalance Pause

### What goes wrong

Consumption pauses briefly while partitions are reassigned.

### Why it happens

- consumer joins
- consumer leaves
- consumer crashes
- long processing causes missed poll interval

### Fix

- keep poll loop healthy
- use cooperative rebalance when possible
- use static membership when appropriate
- make consumers idempotent

---

## Edge Case 4: Ordering Breaks

### What goes wrong

Updates for the same entity are processed in the wrong order.

### Why it happens

- messages are sent without a stable key
- same entity is spread across partitions
- multiple consumers process unordered events

### Fix

- use entity key such as `order_id`
- keep all events for that entity in the same partition
- do not promise global order unless absolutely necessary

```text
Wrong:
Create(order123) -> P0
Cancel(order123) -> P2

Right:
Both keyed by order123 -> same partition
```

---

## Edge Case 5: Poison Message

### What goes wrong

One bad message keeps failing and blocks healthy traffic behind it.

### Why it happens

- bad payload
- unexpected schema
- consumer bug
- unrecoverable business validation issue

### Fix

- bounded retries
- DLQ
- validation before deeper processing
- alerting on repeated failure

---

## Edge Case 6: Queue or Topic Backlog Explodes

### What goes wrong

Storage grows, processing gets delayed, and latency becomes unacceptable.

### Why it happens

- producers are faster than consumers
- traffic spike
- downstream outage
- not enough retention controls

### Fix

- monitor queue depth or lag
- scale consumers
- throttle producers if needed
- set retention or expiry policy
- accept degraded mode if business allows it

---

## Edge Case 7: Producer Cannot Send

### What goes wrong

Producer cannot publish due to timeout or broker unavailability.

### Why it happens

- broker outage
- network issue
- auth/config problem
- local buffer full

### Fix

- retry with backoff
- fail fast after retry budget
- local durable buffer only if needed and safe
- alerting
- circuit breaker if downstream is unstable

---

## Edge Case 8: Consumer Is Alive but Stuck

### What goes wrong

The process is up, but useful progress stops.

### Why it happens

- deadlock
- long GC pause
- slow dependency
- poison workload

### Fix

- heartbeat/session timeout
- max poll interval
- processing latency monitoring
- stuck-consumer alerts

This is why "service is running" is not enough as a health signal.

---

## Edge Case 9: Network Partition

### What goes wrong

Parts of the system lose communication with the broker cluster or with each other.

### Why it happens

- network split
- rack failure
- partial connectivity loss

### Fix

- broker replication
- leader election
- producer retry
- consumer reconnect
- careful handling of split-brain scenarios

For Kafka specifically, talk about ISR and leader election.

---

## Edge Case 10: Schema Change Breaks Consumers

### What goes wrong

New producer deploys fine, but older consumers fail.

### Why it happens

- breaking field change
- removed required field
- incompatible type change

### Fix

- backward-compatible evolution
- schema registry
- additive changes where possible
- tolerant consumers

---

## Edge Case 11: Replay Overloads Downstream Systems

### What goes wrong

Replaying old events floods downstream DBs or APIs.

### Why it happens

- replay is much faster than normal production rate
- downstream services were sized for normal traffic, not replay traffic

### Fix

- throttle replay
- isolate replay consumers
- write into separate projections
- avoid replaying directly into fragile side-effect systems

---

## Summary Table

| Edge Case | Main Risk | Default Fix |
|---|---|---|
| Duplicate delivery | Double processing | Idempotency |
| Consumer lag | Stale processing | Scale consumers and optimize |
| Rebalance | Short pause and reprocessing | Tune group settings, idempotency |
| Ordering issue | Wrong business state | Partition by entity key |
| Poison message | Queue blockage | Retry cap + DLQ |
| Backlog explosion | Latency and storage growth | Backpressure + monitoring |
| Producer failure | Lost publish attempt | Retry + alerting |
| Stuck consumer | Silent outage | Heartbeats + latency metrics |
| Network partition | Unavailability | Replication + failover |
| Schema break | Consumer crash | Compatibility discipline |
| Replay overload | Secondary outage | Controlled replay |

---

## 30-SECOND REVISION BOX

```text
DUPLICATES -> idempotent consumer
LAG -> scale consumers, optimize processing
REBALANCE -> expect pause, design for reprocessing
ORDERING -> key by entity ID
POISON MESSAGE -> bounded retry, then DLQ
BACKLOG GROWTH -> monitor lag/depth, apply backpressure
PRODUCER FAILURE -> retry with backoff
STUCK CONSUMER -> heartbeat and progress metrics
NETWORK PARTITION -> replication and failover
SCHEMA CHANGE -> backward compatibility
REPLAY -> throttle and isolate if needed
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
