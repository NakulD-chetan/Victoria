# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. WHAT ARE INCREMENTAL LOADS
==================================================

Key idea:
- Do NOT reload entire data every time
- Only load:
  → New data
  → Changed data

Meaning:
Incremental load = process only the difference (delta)


----------------------------------------
Real-world analogy
----------------------------------------

Supermarket:
- Do NOT count all items daily
- Only restock:
  → Sold items
  → New items

Same in data:
- Only process changed rows



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Incremental loads help:
- Reduce processing time
- Reduce cost
- Improve performance

BUT:
- Need correct logic to detect changes

Important:
Correctness > speed



==================================================
3. FULL LOAD vs INCREMENTAL LOAD
==================================================

----------------------------------------
FULL LOAD
----------------------------------------
- Load entire dataset every time

Pros:
- Simple logic
- Easy recovery

Cons:
- Slow
- Expensive


----------------------------------------
INCREMENTAL LOAD
----------------------------------------
- Load only new/changed rows

Pros:
- Fast
- Efficient

Cons:
- Complex logic
- Needs tracking


----------------------------------------
Important Insight
----------------------------------------
Full load:
- Good for small tables

Incremental:
- Needed for large tables



==================================================
4. CHANGE DETECTION METHODS
==================================================

----------------------------------------
1. Timestamp-Based
----------------------------------------
- Use last_modified column

Example:
SELECT *
FROM table
WHERE last_modified > last_run_time

Pros:
- Simple

Cons:
- Miss deletes
- Time issues


----------------------------------------
2. Trigger-Based
----------------------------------------
- Database tracks changes

Pros:
- Accurate

Cons:
- Slows OLTP system


----------------------------------------
3. CDC (Change Data Capture)
----------------------------------------
- Reads database logs

Pros:
- Very accurate

Cons:
- Complex setup


----------------------------------------
4. Log-Based / Event-Based
----------------------------------------
- Data comes as stream (Kafka)

Pros:
- Real-time

Cons:
- Needs offset tracking


----------------------------------------
Important Warning
----------------------------------------
Bad timestamps = wrong data



==================================================
5. WATERMARK STRATEGY
==================================================

Key concept:
- Track last processed point


----------------------------------------
Example Flow
----------------------------------------

T1:
- Process data up to time M1
- Save watermark = M1

T2:
- Process data after M1


----------------------------------------
Watermark Table Example
----------------------------------------

CREATE TABLE load_watermark (
  source_object,
  watermark_ts,
  last_run_id,
  rows_applied
);


----------------------------------------
Overlap Window
----------------------------------------
- Reprocess last few minutes

Why?
- Handle late data


----------------------------------------
Important Rule
----------------------------------------
Always:
- Use overlap
- Use idempotent logic



==================================================
6. INCREMENTAL LOAD FOR FACT vs DIMENSION
==================================================

----------------------------------------
FACT TABLE
----------------------------------------
- Stores transactions

Behavior:
- Mostly append
- Sometimes update

Risk:
- Duplicate rows → wrong metrics


----------------------------------------
DIMENSION TABLE
----------------------------------------
- Stores attributes

Behavior:
- Changes over time

Example:
- Product category change


----------------------------------------
SCD (Slowly Changing Dimension)
----------------------------------------
- Keeps history

Process:
- Close old record
- Insert new record


----------------------------------------
Important Insight
----------------------------------------
Facts:
- Focus on duplicates

Dimensions:
- Focus on history



==================================================
7. MERGE / UPSERT PATTERN
==================================================

Cases:

1. New row → INSERT
2. Duplicate → IGNORE
3. Changed row → UPDATE


----------------------------------------
Example
----------------------------------------

9001 → new → insert  
9002 → duplicate → ignore  
9003 → updated → update  


----------------------------------------
Idempotency
----------------------------------------
- Same data processed multiple times → no issue


----------------------------------------
How?
----------------------------------------
- Use hash of data



==================================================
8. PERFORMANCE COMPARISON
==================================================

Full Load:
- Time increases with data size

Incremental:
- Faster if small delta

CDC:
- Near constant performance


----------------------------------------
Important Warning
----------------------------------------
Bad partitioning:
- Makes incremental slow



==================================================
9. COMPLETE PIPELINE EXAMPLE
==================================================

----------------------------------------
Step 1: Start
----------------------------------------
Generate run_id


----------------------------------------
Step 2: Extract delta
----------------------------------------
Select data after watermark


----------------------------------------
Step 3: Stage
----------------------------------------
Store delta data


----------------------------------------
Step 4: Merge
----------------------------------------
Insert/update target table


----------------------------------------
Step 5: Update watermark
----------------------------------------
Move forward with overlap


----------------------------------------
Important Rule
----------------------------------------
Update watermark AFTER successful load



==================================================
10. RECONCILIATION (VERY IMPORTANT)
==================================================

Checks:

----------------------------------------
1. Row count
----------------------------------------
- Compare source vs target


----------------------------------------
2. Total amount
----------------------------------------
- Validate totals


----------------------------------------
3. Hash checks
----------------------------------------
- Ensure no missing data


----------------------------------------
Why?
----------------------------------------
- Ensure correctness



==================================================
11. COMMON MISTAKES
==================================================

----------------------------------------
1. Updating watermark early
----------------------------------------
Problem:
- Data loss

Fix:
- Update after success


----------------------------------------
2. No overlap
----------------------------------------
Problem:
- Miss late data

Fix:
- Add time window


----------------------------------------
3. No idempotency
----------------------------------------
Problem:
- Duplicate data

Fix:
- Use keys + hash


----------------------------------------
4. No dimension handling
----------------------------------------
Problem:
- Broken joins

Fix:
- Handle SCD


----------------------------------------
5. Wrong partitioning
----------------------------------------
Problem:
- Slow queries

Fix:
- Proper partition design



==================================================
12. FINAL TAKEAWAY
==================================================

Incremental loading is:

- NOT just optimization
- It is correctness problem

You must ensure:
- No data loss
- No duplicates
- Accurate results


----------------------------------------
Key Concepts
----------------------------------------

- Change detection
- Watermark
- Overlap window
- Idempotent merge
- Reconciliation


----------------------------------------
Golden Rule
----------------------------------------
FAST + WRONG = USELESS  
CORRECT + FAST = SUCCESS



==================================================
13. QUICK MEMORY SUMMARY
==================================================

Full Load:
- Simple
- Slow

Incremental:
- Fast
- Complex

Methods:
- Timestamp
- CDC
- Triggers
- Logs

Core components:
- Watermark
- Merge
- Validation

Goal:
- Process only what changed