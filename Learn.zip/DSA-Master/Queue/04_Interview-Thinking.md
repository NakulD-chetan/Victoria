# Queue — Interview Thinking

> **How to identify queue problems, justify BFS, explain monotonic deque, and communicate clearly in FAANG interviews.**

---

## How to Identify Queue Problems

### Signal Words → Data Structure

| Problem Phrase | Likely Structure | Why |
|----------------|------------------|-----|
| "Level order" | Queue (BFS) | Process nodes level by level |
| "Shortest path" (unweighted) | Queue (BFS) | BFS finds shortest in unweighted graphs |
| "Nearest" / "Closest" | Queue (BFS) | Expand outward from source |
| "Sliding window" + "max/min" | Monotonic deque | O(n) window extremum |
| "Process in order" / "FIFO" | Queue | Definition of queue |
| "Round robin" / "Task scheduler" | Queue | Order-based processing |
| "Implement queue using stacks" | Two stacks | Amortized O(1) |

### Red Flags (NOT Queue)V

| Phrase | Use Instead |
|--------|-------------|
| "Shortest path" (weighted) | Dijkstra / Bellman-Ford |
| "Topological order" | Kahn's (queue) or DFS |
| "Next greater element" (single array) | Monotonic stack |
| "Largest rectangle" | Monotonic stack |
| "Merge k sorted" | Heap (priority queue) |

---

## BFS Justification in Interviews

### What to Say

> "I'll use BFS with a queue. BFS explores nodes in order of their distance from the source. Since we process the first-discovered nodes first, we naturally get the shortest path in an unweighted graph. The queue ensures we handle level-by-level — all nodes at distance d are processed before any at distance d+1."

### Why BFS for Shortest Path (Unweighted)?

```
Unweighted graph: every edge has cost 1
BFS discovers nodes in order of distance
First time we reach a node = shortest path to it

     S
    /|\
   / | \
  A  B  C   ← All at dist 1
  |   \ |
  D    E    ← D, E at dist 2

Queue: [S] → [A,B,C] → [D,E]
S→A = 1, S→D = 2 (first discovery = shortest)
```

### When to Mention DFS Instead

> "If we only need to check reachability or find any path, DFS would also work. But for shortest path or level order, BFS is the right choice."

---

## Monotonic Deque Explanation

### What to Say

> "For sliding window max, I'll use a monotonic decreasing deque. We store indices in the deque such that their values are in decreasing order from front to back. The front is always the max of the current window. When a new element arrives, we pop from the back all elements smaller than it — they can never be the max in any future window containing this element. We also remove the front if its index falls outside the window. Each element is pushed and popped at most once, so it's O(n)."

### Key Points to Mention

1. **Store indices** — to check if element is still in window
2. **Decreasing for max** — front = max; new larger element invalidates smaller ones
3. **Increasing for min** — same logic, inverted
4. **Amortized O(n)** — each element enters and exits once

### ASCII for Whiteboard

```
Window [i-k+1, i], we want max:

Deque (indices):  front ... back
Values:           big  ... small  (decreasing)

arr[i] arrives:
  - If arr[i] > arr[back]: back is obsolete → pop
  - Repeat until deque empty or arr[back] >= arr[i]
  - Append i
  - If front < i-k+1: front is out of window → pop front
  - Result for this window: arr[front]
```

---

## Communication Framework

### Step 1: Clarify

- [ ] Graph: directed/undirected? Weighted?
- [ ] Multiple components? Return -1 if unreachable?
- [ ] Sliding window: k fixed? What if n < k?
- [ ] Tree: binary? N-ary?

### Step 2: Approach

> "I'll use [BFS / monotonic deque / ...] because [one-line reason]. The time complexity will be O(...) and space O(...)."

### Step 3: Walk Through Example

> "Let me trace through with [small example]. We start with [initial state]. Then we [step 1], [step 2], ... and get [result]."

### Step 4: Code

- Use `deque` in Python (not list for queue — `list.pop(0)` is O(n))
- Use `queue` or `deque` in C++
- Name variables clearly: `queue`, `visited`, `level`

### Step 5: Test & Edge Cases

> "Let me verify: empty input, single node, disconnected graph, k=1 for sliding window."

---

## Quick Reference: Interview Lines

| Scenario | One-Liner |
|----------|-----------|
| Why BFS? | "BFS processes nodes in order of discovery, so first reach = shortest path in unweighted graph." |
| Why queue for BFS? | "Queue gives FIFO — we process the frontier in the order we discovered it." |
| Why monotonic deque? | "Each element enters and exits at most once — O(n) instead of O(n·k) for brute force." |
| Why store indices? | "We need to check if the max is still inside the current window." |
| Why visited set? | "Graphs can have cycles; without visited we'd loop forever." |

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY:    Level order/shortest path → BFS | Window max/min → Monotonic deque
BFS LINE:    "First discovery = shortest path; queue = level order"
DEQUE LINE:  "Decreasing = max; each element push/pop once = O(n)"
FRAMEWORK:   Clarify → Approach → Example → Code → Edge cases
PYTHON:      from collections import deque (not list for queue)
```
