# Date Dimension Table — Practice

> "Time is the spine of the star—get the calendar wrong and every trend bends."

---

## Quick Recall

**Q: Why a date dimension instead of raw dates in facts?**  
A: Consistent attributes (fiscal week, season, holiday flags) and role-playing joins without duplicating logic in every query.

**Q: Typical surrogate key for `dim_date`?**  
A: Integer `YYYYMMDD` or a sequential surrogate—both work if documented; integer date key aids partitioning.

**Q: What is role-playing in date context?**  
A: Same physical `dim_date` joined multiple times as order date, ship date, and delivery date with aliases.

**Q: How far should a retail date dimension span?**  
A: Past source history plus several future years for forecasting and promotional calendars.

**Q: Fiscal vs calendar attributes?**  
A: Retail often needs both—merchandising calendars differ from GAAP fiscal periods; store both attribute sets.

---

## Interview Questions

**1. What columns belong on a retail `dim_date`?**  
Say: Calendar hierarchy (year, quarter, month, week), day-of-week, is_weekend, holiday_name, is_holiday, retail_season (e.g., BTS), fiscal year and period if corporate uses a 4-4-5 calendar.

**2. How do you handle time-of-day if facts are daily grain?**  
Say: Keep daily grain in `dim_date`; if needed, add `dim_time` or a timestamp on the fact with a separate time-of-day dimension for intraday clickstream.

**3. Why avoid storing month name alone as the key?**  
Say: Month name is not unique across years; keys must identify a specific day or period node in the hierarchy.

**4. How do you join a fact to date role-playing keys?**  
Say: Multiple foreign keys on the fact (`order_date_key`, `ship_date_key`) each referencing `dim_date`; BI models expose friendly role names.

**5. How are unknown or approximate dates modeled?**  
Say: Use an explicit unknown member in `dim_date` or a deferred-date bridge pattern; never null keys if your standard forbids it.

**6. Performance consideration for wide date dimensions?**  
Say: Columnar engines like narrow integer keys; row stores may index date keys—avoid excessive wide text if unused.

**7. How is timezone handled for global e-commerce?**  
Say: Store UTC timestamps in staging, convert to reporting timezone in ETL, and document the policy on `dim_date` for the primary market.

---

## Scenario-Based Exercises

**Scenario 1 — Promotional windows**  
Compare sales during Black Friday week year over year.  
**Solution:** Filter `dim_date.is_black_friday_week` or use `retail_week` aligned to promo calendar; join `fact_order_line.order_date_key` to `dim_date`.

**Scenario 2 — Fiscal reporting**  
Merchandising uses a 4-4-5 calendar.  
**Solution:** Add `merch_year`, `merch_period`, `merch_week` to `dim_date`; populate from corporate calendar feed; never compute fiscal labels only in BI if finance must reconcile.

**Scenario 3 — SQL: YoY same-store sales**  
Compare this year vs last year by calendar month.

```sql
SELECT
    d.calendar_month_name,
    SUM(CASE WHEN d.calendar_year = EXTRACT(YEAR FROM CURRENT_DATE)
        THEN f.net_sales ELSE 0 END) AS sales_ty,
    SUM(CASE WHEN d.calendar_year = EXTRACT(YEAR FROM CURRENT_DATE) - 1
        THEN f.net_sales ELSE 0 END) AS sales_ly
FROM dw.fact_order_line f
JOIN dw.dim_date d ON f.order_date_key = d.date_key
JOIN dw.dim_store s ON f.store_key = s.store_key
WHERE s.same_store_cohort = TRUE
GROUP BY 1
ORDER BY MIN(d.calendar_month_number);
```

**Scenario 4 — Diagram (textual)**  
Star fragment: `fact_order_line` connects to one `dim_date` via `order_date_key`; reporting views duplicate `dim_date` as `ship_dim` via `ship_date_key`.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Using varchar date keys | Sorting and join bugs | Prefer integer or true date type |
| One date column, many meanings | Ambiguous metrics | Role-playing keys with clear names |
| Computing holidays in every report | Drift and inconsistency | Centralize in `dim_date` |
| Ignoring fiscal vs calendar | Wrong executive numbers | Ask which calendar is authoritative |

---

## One-Liner Answers

- The date dimension centralizes calendar intelligence for every fact.
- Role-playing reuses one physical table with multiple foreign keys on facts.
- Retail needs retail calendars, holidays, and seasons—not only generic months.
- Date keys should be stable and join-friendly across subject areas.
- Document timezone and fiscal rules next to the dimension, not only in wiki pages.
- Unknown dates get explicit dimension members, not silent NULLs when policy requires.
