import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function toBits(n, width) {
  return Array.from({ length: width }, (_, i) => ((n >> (width - 1 - i)) & 1) ? '1' : '0');
}

function generateSteps(n0, width = 8) {
  const steps = [];
  let n = n0;
  steps.push({ type: 'show', n, prev: n, cells: toBits(n, width), title: `n=${n}` });
  while (n > 0) {
    const prev = n;
    const m = n - 1;
    steps.push({ type: 'sub1', n, prev, m, cells: toBits(m, width), title: `n-1 = ${m}` });
    const next = n & m;
    steps.push({ type: 'and', n, prev, m, next, cells: toBits(next, width), title: `n & (n-1) = ${next}` });
    n = next;
    steps.push({ type: 'cleared', n, cells: toBits(n, width), title: 'Lowest set bit cleared' });
  }
  steps.push({ type: 'done', n: 0, cells: toBits(0, width), title: '✓ Brian Kernighan iterations' });
  return steps;
}

export default function BrianKernighansVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const n0 = 45;
    const steps = generateSteps(n0);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Count/clear bits via n & (n-1)' });
    canvasRef.current?.setState({
      cells: steps[0].cells,
      colors: {},
      title: steps[0].title,
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'and' && step.prev != null && step.next != null) {
      for (let i = 0; i < step.cells.length; i++) {
        const pb = toBits(step.prev, step.cells.length)[i];
        const nb = toBits(step.next, step.cells.length)[i];
        if (pb !== nb) colors[i] = 'swap';
      }
    }
    if (step.type === 'done') for (let i = 0; i < step.cells.length; i++) colors[i] = 'sorted';
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.title || step.type });
    canvasRef.current?.setState({
      cells: step.cells,
      colors,
      title: step.title,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
