import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(coins, amount) {
  const steps = [];
  const dp = Array(amount + 1).fill(null);
  dp[0] = 0;
  const colLabels = Array.from({ length: amount + 1 }, (_, i) => i);

  const snap = (caption, arr, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [arr],
      rowLabels: ['ways'],
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('dp[0]=0 coins to make amount 0', [...dp], { '0-0': 'filled' }, [0, 0], []);

  for (let x = 1; x <= amount; x += 1) {
    let best = Infinity;
    coins.forEach((c, idx) => {
      if (x >= c && dp[x - c] != null) {
        const colors = { [`0-${x}`]: 'current', [`0-${x - c}`]: 'filling' };
        snap(`Try coin ${c} (${idx + 1}/${coins.length}) at amount ${x}`, [...dp], colors, [0, x], [{ from: [0, x - c], to: [0, x] }]);
        best = Math.min(best, dp[x - c] + 1);
      }
    });
    dp[x] = best === Infinity ? null : best;
    snap(`dp[${x}] = ${dp[x] == null ? '∞' : dp[x]}`, { [`0-${x}`]: dp[x] == null ? 'current' : 'optimal' }, [0, x], []);
  }

  snap('Coin change DP complete', [...dp], { [`0-${amount}`]: 'optimal' }, [0, amount], []);
  return steps;
}

export default function CoinChangeVisualizer({ config }) {
  const coins = [1, 3, 4];
  const amount = 10;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(coins, amount);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Coins [${coins.join(', ')}], amount ${amount}` });
    canvasRef.current?.setState({
      table: [[0]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      items: coins.map((c) => `${c}c`),
      caption: 'Coin change (min coins)',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      items: coins.map((c) => `${c}c`),
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
