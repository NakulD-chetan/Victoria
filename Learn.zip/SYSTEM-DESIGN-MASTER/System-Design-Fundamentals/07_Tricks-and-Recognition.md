# System Design Fundamentals — Tricks and Recognition

> **Permanent Recall:** Pattern recognition: Read-heavy vs Write-heavy vs Real-time vs Batch. For each: characteristics, typical components, examples. Decision tree. Quick heuristics. "Just use" shortcuts (Redis, Kafka, etc.) for common needs.

---

## Four System Archetypes

| Type | Characteristics | Typical Components | Examples |
|------|------------------|-------------------|----------|
| **Read-heavy** | Many reads, few writes; low latency reads critical | Cache, CDN, read replicas | Feed, profile, search results |
| **Write-heavy** | Many writes; durable, ordered | Sharding, queues, append-only log | Logging, metrics, chat messages |
| **Real-time** | Low latency; push; streaming | WebSocket, Kafka, streaming | Chat, notifications, live dashboard |
| **Batch** | Large data; delay OK; compute-intensive | Queue, workers, Spark/Flink | Reports, ML training, ETL |

---

## Read-Heavy Systems

**Characteristics:**
- Read:write >> 10:1
- Same data read many times
- Latency SLA for reads (e.g., <200ms p99)
- Consistency can be eventual for many use cases

**Typical Components:**

| Component | Role |
|-----------|------|
| **Redis** | In-memory cache; hot data; sub-ms latency |
| **CDN** | Edge cache for static; images, JS, video |
| **Read replicas** | DB reads offloaded from primary |
| **Denormalization** | Pre-join data to avoid read-time joins |

**Examples:** Twitter feed, Instagram feed, profile page, product catalog, news feed.

> **FAANG Tip:** "Read-heavy → cache first. Redis for hot data, CDN for static. Read replicas if DB is still the bottleneck."

---

## Write-Heavy Systems

**Characteristics:**
- Writes dominate or equal reads
- Durable, ordered, append-friendly
- May need high write throughput
- Often append-only (events, logs)

**Typical Components:**

| Component | Role |
|-----------|------|
| **Sharding** | Partition writes across DBs |
| **Kafka** | High-throughput write log; replay; consumers |
| **Append-only storage** | Log-structured; no in-place update |
| **Batching** | Batch writes to reduce DB round-trips |

**Examples:** Logging (Datadog, Splunk), metrics (Prometheus), chat messages, audit logs, event sourcing.

> **FAANG Tip:** "Write-heavy → sharding for DB, or Kafka for event log. Append-only simplifies scaling."

---

## Real-Time Systems

**Characteristics:**
- Low latency (<100ms often)
- Push to client (not poll)
- Streaming or near-instant updates
- Many concurrent connections

**Typical Components:**

| Component | Role |
|-----------|------|
| **WebSocket** | Persistent connection; push from server |
| **Kafka / streaming** | Event stream; real-time processing |
| **Redis Pub/Sub** | Lightweight pub/sub; presence |
| **Edge** | Reduce latency; push from edge |

**Examples:** Chat (WhatsApp, Slack), live dashboard, notifications, multiplayer games, collaborative editing.

> **FAANG Tip:** "Real-time → WebSocket for client push, Kafka for event pipeline, Redis for presence."

---

## Batch Systems

**Characteristics:**
- Large data volume
- Delay acceptable (minutes to hours)
- Compute-intensive
- Scheduled or event-triggered

**Typical Components:**

| Component | Role |
|-----------|------|
| **Queue (SQS, Kafka)** | Decouple; buffer work |
| **Workers** | Consume and process |
| **Spark / Flink** | Distributed compute |
| **Object storage (S3)** | Store raw and results |

**Examples:** Nightly reports, ML training, ETL, data pipeline, analytics aggregation.

> **FAANG Tip:** "Batch → queue + workers, or Spark for big data. Never block user request on batch job."

---

## Decision Tree: What Type of System?

```mermaid
flowchart TD
    A[System design problem] --> B{Latency requirement?}
    B -->|Must be <100ms| C[Real-time]
    B -->|Can be seconds+| D{Read vs Write?}
    D -->|Read >> Write| E[Read-heavy]
    D -->|Write heavy or even| F[Write-heavy]
    D -->|Large data, delay OK| G[Batch]
    C --> H[WebSocket, Kafka, Redis]
    E --> I[Cache, CDN, replicas]
    F --> J[Sharding, Kafka, queues]
    G --> K[Queue, workers, Spark]
```

---

## Quick Heuristics

| If you hear... | Think... |
|----------------|----------|
| "Feed" "timeline" "profile" | Read-heavy → cache, replicas |
| "Chat" "messaging" "notifications" | Write-heavy + real-time → Kafka, WebSocket |
| "Search" "discovery" | Read-heavy + maybe batch (indexing) |
| "Logging" "metrics" "events" | Write-heavy, append-only → Kafka |
| "Recommendations" | Batch (training) + read-heavy (serving) |
| "Video streaming" | CDN, read-heavy for playback |
| "Live" "real-time" | WebSocket, streaming |
| "Report" "analytics" | Batch |

---

## "Just Use" Shortcuts (Interview)

| Need | "Just use" | Why |
|------|------------|-----|
| **Cache** | Redis | Fast, in-memory, sorted sets, pub/sub |
| **Message queue** | Kafka (high throughput) or SQS (simpler) | Kafka: ordering, replay, partitions; SQS: simple, managed |
| **Search** | Elasticsearch | Full-text, faceted search |
| **Object storage** | S3 / GCS | Scalable, cheap, multipart upload |
| **CDN** | CloudFront / Cloudflare | Edge caching, DDoS |
| **Real-time push** | WebSocket | Persistent connection, low latency |
| **DB** | PostgreSQL (relational) or DynamoDB (key-value at scale) | Choose by query pattern |
| **Unique IDs** | Snowflake | Distributed, time-ordered, no coordination |
| **Rate limiting** | Redis + token bucket | Distributed, fast |

---

## Pattern Recognition Checklist

When given a problem:

| Step | Action |
|------|--------|
| 1 | **Classify:** Read-heavy, write-heavy, real-time, or batch? |
| 2 | **Components:** Which "just use" fits? Redis? Kafka? CDN? |
| 3 | **Scale:** Estimate QPS, storage; size the system |
| 4 | **Bottleneck:** Where will it break first? |
| 5 | **Edge cases:** Failure modes, consistency |

---

## Combined Patterns (Common)

Many systems combine archetypes:

| System | Primary | Secondary | Implication |
|--------|---------|-----------|-------------|
| Twitter feed | Read-heavy | Real-time (push) | Cache + fan-out + WebSocket for live |
| Chat | Write-heavy + real-time | Read-heavy (history) | Kafka for writes, cache for recent |
| Instagram | Read-heavy + batch | Real-time (stories) | CDN, async processing, ephemeral |
| Uber | Real-time (location) | Write-heavy (trips) | WebSocket, event log, DB for state |
| Netflix | Read-heavy | Batch (encoding) | CDN, async encoding pipeline |

---

## Anti-Pattern Recognition

| Wrong Choice | Right Choice | When |
|--------------|--------------|------|
| Polling for updates | WebSocket / push | Real-time |
| Sync for heavy work | Queue + async | Batch-like work |
| DB for blob storage | S3 / object storage | Images, video |
| Strong consistency everywhere | Eventual where OK | Feed, timeline |
| One big monolith | Logical separation | When scaling parts |

---

## 30-SECOND REVISION BOX

```
READ-HEAVY: Cache, CDN, replicas (Redis, CloudFront)
WRITE-HEAVY: Sharding, Kafka, append-only
REAL-TIME: WebSocket, Kafka stream, Redis pub/sub
BATCH: Queue, workers, Spark
JUST USE: Redis cache, Kafka queue, ES search, S3 storage
PATTERN: Classify → Components → Scale → Bottleneck
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
