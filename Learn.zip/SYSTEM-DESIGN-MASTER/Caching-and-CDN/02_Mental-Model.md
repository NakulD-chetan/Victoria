# Caching and CDN — Mental Model

> **Permanent Recall:** Think of cache as a library desk—frequently used books stay on your desk (cache) instead of walking to the shelf (database). CDN is like franchise stores: same inventory (content) replicated closer to each neighborhood. The "cache is a lie" principle: cached data can always be stale; design for it. Use hit ratio as your north star metric—aim for 80%+ on read-heavy systems.

---

## Library Desk Analogy

```
         LIBRARY = YOUR SYSTEM
        
    ┌─────────────────────────────────────────┐
    │  YOUR DESK (Cache)                       │
    │  - Frequently used books                 │
    │  - Limited space → evict old ones        │
    │  - Fast access (no walking)              │
    └────────────────┬────────────────────────┘
                     │
                     │  Book not on desk? (MISS)
                     ▼
    ┌─────────────────────────────────────────┐
    │  LIBRARY SHELF (Database)                │
    │  - All books, permanent                  │
    │  - Slow (walk, search, fetch)            │
    │  - Unlimited (but expensive to access)   │
    └─────────────────────────────────────────┘

Caching = Keep hot books on desk. Cold books = go to shelf.
Eviction = Desk full → remove least-used book to make space.
```

**Mapping:**

| Library | Cache/Database |
|---------|----------------|
| Desk | Application cache / Redis |
| Shelf | Database / origin |
| Frequently used books | Hot data |
| Walking to shelf | Database query |
| Desk full | Cache eviction |

> **FAANG Tip:** This analogy helps explain caching to non-technical stakeholders. "We're keeping the most-requested data closer to where it's needed."

---

## What to Cache: The Mental Checklist

| Cache If... | Example |
|-------------|---------|
| **Hot data** — accessed frequently | User profile, product details, trending posts |
| **Expensive computation** — costly to recompute | Aggregations, ML inference, search results |
| **Repeated queries** — same key, many requests | Session data, API responses |
| **Read-heavy, write-light** | Product catalog, static config |

| Don't Cache If... | Example |
|-------------------|---------|
| **Unique per request** | Real-time stock prices, personalized recommendations |
| **Frequently changing** | Live scores, auction bids |
| **Sensitive, must be fresh** | Payment status, security tokens |
| **Cheap to compute** | Simple arithmetic, constant lookups |

---

## Cache Hit Ratio Mental Model

```
Hit Ratio = Cache Hits / (Cache Hits + Cache Misses)

         GOAL: 80%+ for read-heavy systems
        
    ┌──────────────────────────────────────────┐
    │  100 requests                             │
    │  80 hits  → served from cache (~1ms)      │
    │  20 miss  → DB queries (~50ms each)      │
    │                                          │
    │  Without cache: 100 × 50ms = 5000ms DB   │
    │  With cache:     20 × 50ms = 1000ms DB   │
    │  DB load reduced 5×                       │
    └──────────────────────────────────────────┘
```

**Rule of thumb:** Every 10% hit ratio improvement ≈ 10% fewer DB hits. At 90% hit ratio, DB sees only 10% of reads.

---

## The "Cache Is a Lie" Principle

**Cached data can always be stale.** Design with this in mind:

```
TRUTH:  What's in the database
LIE:    What's in the cache (might be outdated)

Implications:
1. TTL is mandatory — don't cache forever
2. Invalidation must be planned — event-based or explicit delete
3. Critical reads may bypass cache (e.g., balance before payment)
4. Version/ETag for conditional revalidation
```

> **FAANG Tip:** When asked "What if cache and DB disagree?" — answer: "Cache is inherently eventually consistent. For strong consistency, bypass cache or use write-through with sync."

---

## CDN Mental Model: Franchise Stores

```
        CDN = FRANCHISE STORES
        
    ┌─────────┐  ┌─────────┐  ┌─────────┐
    │ Store   │  │ Store   │  │ Store   │
    │ Mumbai  │  │ Delhi   │  │ Tokyo   │
    │ (POP)   │  │ (POP)   │  │ (POP)   │
    └────┬────┘  └────┬────┘  └────┬────┘
         │            │            │
         │  Same inventory cached locally
         │  User gets from nearest store
         │
         └────────────┼────────────┘
                      ▼
              ┌──────────────┐
              │ Headquarters │  (Origin)
              │ (one source) │
              └──────────────┘
```

**Key idea:** Copies closer to users = lower latency, less traffic to origin.

---

## Decision Tree: Caching Strategy Selection

```mermaid
flowchart TD
    A[Need caching?] --> B{Read-heavy?}
    B -->|No| C[Consider write-optimized DB]
    B -->|Yes| D{Strong consistency required?}
    D -->|Yes| E[Write-Through]
    D -->|No| F{Write-heavy?}
    F -->|Yes| G{Tolerate data loss?}
    G -->|Yes| H[Write-Behind]
    G -->|No| I[Write-Around + Cache-Aside]
    F -->|No| J[Cache-Aside / Read-Through]
    J --> K[Add TTL + invalidation]
```

---

## Decision Tree (ASCII Fallback)

```
                    Need caching?
                         │
                    Read-heavy? ──No──► Consider write-optimized DB
                         │Yes
                         ▼
              Strong consistency required?
                    │Yes          │No
                    ▼             ▼
              Write-Through   Write-heavy?
                                   │Yes        │No
                                   ▼           ▼
                            Tolerate loss?   Cache-Aside
                              │Yes  │No      Read-Through
                              ▼     ▼
                         Write-Behind  Write-Around
```

---

## When to Use CDN vs App Cache

| Scenario | Use | Why |
|----------|-----|-----|
| Static assets (JS, CSS, images) | **CDN** | Same for everyone, global users |
| User-specific API response | **App cache** | Personalized, can't share at edge |
| Same API for all users | **CDN** | Cache at edge, low latency |
| Session / auth token | **App cache (Redis)** | Per-user, sensitive |
| Product catalog | **Both** | CDN for static pages, Redis for API |

---

## Cache Sizing Heuristic: 80/20 Rule

```
Roughly 80% of requests hit 20% of keys.

Implication: Cache size ~20% of "working set" can achieve 80%+ hit ratio.
If DB has 1M user profiles, ~200K hot keys may suffice.

Scale cache with hot set, not total data.
```

> **FAANG Tip:** "What cache size do you need?" → "Estimate working set (hot keys). 2–3× that for headroom. Monitor eviction rate."

---

## 30-SECOND REVISION BOX

```
LIBRARY DESK = cache, SHELF = database
CDN = franchise stores (copies near users)
CACHE IS A LIE = always design for staleness
HIT RATIO = north star, aim 80%+
CACHE IF: hot, expensive, repeated, read-heavy
80/20 RULE = 20% of keys get 80% of traffic
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
