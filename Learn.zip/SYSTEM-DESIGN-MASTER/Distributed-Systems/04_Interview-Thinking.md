# Distributed Systems — Interview Thinking

> **Permanent Recall:** Discuss distributed systems by explaining consensus simply (committee voting), when to use Raft vs Paxos (Raft for practicality), distributed locking with fencing, and handling network partitions explicitly. Demonstrate depth with split brain, clock skew, and CAP implications. Frame answers around partial failures and "maybe" semantics to show FAANG-level understanding.

---

## How to Discuss Distributed Systems in Interviews

**Opening frame:** "Distributed systems are about coordinating nodes that can fail independently. The key challenges are partial failures, no global clock, and network unreliability. We design for these from the start."

**Structure:**
1. **Identify** coordination need (leader, lock, config, consensus)
2. **Choose** approach (Raft, ZooKeeper, RedLock)
3. **Address** partition and failure cases
4. **Mention** edge cases (split brain, fencing)

---

## Explaining Consensus Simply

**Wrong:** "We use Paxos with proposer-acceptor phases and epoch numbers..."

**Right:** "Consensus is like committee voting. We need a majority to agree on a value. Raft makes this practical: we elect a leader, the leader proposes values, and a majority must acknowledge before we commit. If the leader fails, we hold a new election. Only one side of a partition can have a majority, so we avoid split brain."

> **FAANG Tip:** One sentence: "Raft = elect leader, leader replicates to quorum, majority ack = decided."

---

## When to Bring Up Raft vs Paxos

| Say Raft when | Say Paxos when |
|---------------|----------------|
| Leader election needed | Interviewer asks "what about Paxos?" |
| Practical implementation (etcd, Consul) | Historical context, Chubby |
| Need to explain mechanics | Proving correctness, academic |

**Default:** "For leader election and log replication, Raft is the practical choice. It's easier to implement and reason about. Paxos is equivalent in power but more complex."

---

## Distributed Locking Conversation

**Interviewer:** "How would you implement a distributed lock?"

**Strong answer:**
1. "We'd use ZooKeeper or etcd—they provide strong consistency."
2. "Create an ephemeral sequential node under /locks/resource. The lowest sequence number holds the lock."
3. "Critical: we need fencing tokens. When we acquire the lock, we get a monotonic token. Any storage or resource we access must reject operations with a lower token. This prevents a slow client that thinks it holds the lock from corrupting data after we've given the lock to someone else."
4. "Alternatively, Redis RedLock for weaker guarantees—but we'd still want fencing if it's protecting critical resources."

---

## Handling "What Happens During Network Partition?"

**Structure:**
1. **Identify** which side has quorum (majority)
2. **Leader/consensus:** Only quorum side can elect leader / make progress
3. **Minority side:** Blocks or rejects; cannot elect leader
4. **Result:** No split brain; minority unavailable until partition heals

**Line:** "With odd cluster size (3 or 5), a partition splits into majority and minority. Only the majority can form quorum. The minority can't elect a leader or commit writes. So we have at most one active leader—no split brain. The minority is unavailable until the partition heals."

---

## Demonstrating Distributed Systems Depth

| Topic | How to Show Depth |
|-------|-------------------|
| **Consensus** | "Raft: leader election + log replication. Term-based to detect stale leaders." |
| **Locks** | "Fencing tokens prevent stale lock holder from corrupting data." |
| **Split brain** | "Quorum ensures only one side can progress; odd N avoids 50-50 split." |
| **Clock** | "We use Lamport or vector clocks for ordering—wall clocks can skew." |
| **CAP** | "During partition, we choose C or A. For locks we need CP." |
| **Partial failure** | "We design for timeouts, retries, idempotency—assume messages can be lost." |

---

## Interview Flow Examples

```
Interviewer: "Design a job scheduler that runs one instance."
You: "We need leader election so only one instance is active. I'd use 
     Raft—etcd or Consul—or ZooKeeper. One node becomes leader, 
     others standby. Heartbeats detect failure; new election. 
     Odd cluster size prevents split brain during partition."

Interviewer: "How do you ensure only one process updates this resource?"
You: "Distributed lock via ZooKeeper. Ephemeral sequential node. 
     Lowest holds lock. Important: fencing tokens—monotonic counter 
     so we reject ops from a stale lock holder."
```

---

## What to Say When Stuck

| If asked | Fallback |
|----------|----------|
| "How does X work?" | "At a high level, it uses [consensus/heartbeats/quorum]. The key is..." |
| "What if the network partitions?" | "With quorum, only majority progresses. Minority blocks." |
| "How do you prevent split brain?" | "Quorum election. Odd number of nodes. Only majority can decide." |
| "What about clock skew?" | "Use logical clocks—Lamport or vector—for ordering, not wall clock." |

---

## Red Flags to Avoid

- "The network is reliable"
- "We'll have a single leader" (without failover)
- "Distributed lock" without fencing
- "We use NTP so clocks are fine"
- Ignoring partition scenario

---

## Structuring a Full Distributed Design Answer

1. **Scope:** "We have N nodes that need to..."
2. **Coordination:** "For leader/lock/config we use..."
3. **Failure:** "If a node fails, we..."
4. **Partition:** "During partition, quorum ensures..."
5. **Edge cases:** "We add fencing to handle slow clients."

---

## Bonus: Mentioning the Eight Fallacies

When asked "what's hard about distributed systems?": "The classic fallacies—assuming the network is reliable, latency is zero, etc. In practice we design for partitions, use timeouts, and never trust a single message. That mindset drives our choices."

---

## Closing the Loop

Always circle back to the requirement: "Given that we need [single leader / lock / config], we use [Raft / ZK / etcd] because it gives us [quorum / fencing / consistency]. We accept [minority unavailable / higher latency] during partitions."

---

## 30-SECOND REVISION BOX

```
CONSENSUS: Committee voting, Raft = leader + quorum
RAFT vs PAXOS: Raft practical, Paxos when asked
LOCKS: ZK/etcd + fencing token
PARTITION: Quorum, minority blocks, no split brain
DEPTH: Fencing, split brain, clock, CAP, partial failure
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
