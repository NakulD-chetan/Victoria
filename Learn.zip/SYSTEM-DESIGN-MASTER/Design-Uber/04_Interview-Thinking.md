# Design Uber — Interview Thinking

> **Permanent Recall:** Focus on **geospatial indexing** (the differentiator). Explain **Geohash** clearly; discuss matching algorithm; trip state machine is straightforward but mention it; surge pricing is a nice bonus. Time: 0–2 clarify, 2–7 requirements, 7–20 HLD + geo deep-dive, 20–35 matching/trip/surge, 35–45 wrap-up.

---

## Step-by-Step Interview Walkthrough (45 min)

### 0–2 min: Clarify Scope

**You:** "Before I dive in, a few clarifications:
- Is this ride-hailing only, or UberEats / UberPool in scope?
- Do we need real-time tracking during the trip?
- Surge pricing required?
- Scale: single city, one country, or global?
- Any specific constraints on matching latency or location update frequency?"

> **FAANG Tip:** UberEats adds restaurant and delivery flow; UberPool adds ride sharing. Both change the design. Always ask.

---

### 2–7 min: Requirements & Scale

**You:** "I'll assume:
- **Functional:** Rider requests ride, match with nearby driver, real-time tracking, ETA, surge pricing, trip history, payments, ratings
- **Scale:** 20M trips/day; 15M active drivers during peak; location updates every 4 seconds
- **NFRs:** <1s location propagation, <30s matching latency, 99.9% availability"

State capacity: "15M drivers × 0.25 Hz = 3.75M location updates per second. We need geospatial indexing—SQL with lat/lng won't scale."

---

### 7–20 min: High-Level Design + Geospatial Deep-Dive

**You:** "The core challenge is real-time geospatial matching. I'll start with the architecture, then go deep on how we index locations."

```
Rider → Matching → Location Service (geo index)
Driver → Location Service (GPS updates)
Trip Service (lifecycle) | Pricing (surge) | Payment (post-trip)
```

**Then:** "For geospatial indexing, we need to avoid scanning all drivers. **Geohash** encodes lat/lng into a string—nearby points share a prefix. For a rider at (37.7, -122.4), we compute geohash '9q8yy', then lookup drivers in that cell and 8 adjacent cells. Redis GEO implements this internally—GEOADD for updates, GEORADIUS for queries."

**If asked about alternatives:** "QuadTree gives variable density—dense urban areas get more splits. S2 cells are what Google uses—hierarchical, good for production. For interview scope, Geohash or Redis GEO is sufficient."

---

### 20–35 min: Deep Dive Topics

| Topic | What to Say |
|-------|-------------|
| **Location updates at scale** | "3.75M writes/s—we use in-memory store (Redis GEO or custom QuadTree). Persist async for analytics. Shard by region so NYC handles NYC drivers." |
| **Matching algorithm** | "Query nearest K available drivers. Send request to top 5. First-accept-wins—reduces rider wait. If no accept in 15–30s, expand radius and retry." |
| **Trip state machine** | "REQUESTED → MATCHED → DRIVER_EN_ROUTE → IN_PROGRESS → COMPLETED. Cancellations from REQUESTED or MATCHED." |
| **Surge pricing** | "Supply/demand per geohash region. Recalculate every few minutes. When demand > supply, multiplier (1.0–3.0×). Show rider before confirm." |
| **ETA** | "Graph-based routing (OSM or commercial) from A to B. Layer in historical travel time and real-time traffic for accuracy." |
| **Real-time tracking** | "WebSocket; push driver location every 4s to rider app. Fallback to long polling if needed." |

> **FAANG Tip:** Geospatial indexing is the differentiator. Spend 5–7 minutes on it. Trip state machine is quick—one sentence plus states.

---

## Minute-by-Minute Guide

| Min | Focus | Key Points |
|-----|-------|------------|
| 0–2 | Clarify | UberEats? UberPool? Surge? Scale? |
| 2–5 | Requirements | Functional + NFRs; 20M trips, 3.75M loc/s |
| 5–7 | Capacity | Location QPS, storage, why SQL won't work |
| 7–12 | HLD | Services: Location, Matching, Trip, Pricing, Payment |
| 12–20 | **Geospatial** | Geohash (prefix = region); Redis GEO; QuadTree/S2 |
| 20–25 | Matching | Nearest K, first-accept-wins, expand on no accept |
| 25–28 | Trip lifecycle | State machine; briefly |
| 28–33 | Surge + ETA | Supply/demand per region; graph + historical |
| 33–38 | Tracking + payment | WebSocket; post-trip charge |
| 38–45 | Wrap-up | Summarize; offer deep-dives; follow-ups |

---

## Time Allocation Priority

| Priority | Topic | Time |
|----------|-------|------|
| **Must** | Geospatial indexing (Geohash) | 5–7 min |
| **Must** | Matching algorithm | 3–5 min |
| **Should** | Location updates at scale | 2–3 min |
| **Should** | Trip state machine | 1–2 min |
| **Nice** | Surge pricing | 2–3 min |
| **Brief** | ETA, tracking, payment | 1–2 min each |

---

## Handling "Add UberPool"

**You:** "UberPool adds shared rides. We match multiple riders going the same direction. Changes: route optimization (pickup order), fare splitting, matching becomes 'find riders whose route overlaps with driver's current route'. Geospatial index still core; add route-matching logic."

---

## Handling "Design Surge Pricing Algorithm"

**You:** "Per geohash region: demand = #ride requests in last N minutes, supply = #available drivers. Ratio demand/supply → lookup table or function for multiplier. Recalculate every 5–10 min. Cap at 3× for fairness. A/B test multipliers in production."

---

## What to Draw First

1. **Rider → Matching → Location Service** (with "geo index" label)
2. **Driver → Location Service** (GPS stream)
3. **Geohash diagram:** "lat/lng → string; shared prefix = nearby"
4. **Trip state machine** (simple boxes)
5. **Surge:** "region → supply/demand → multiplier"

---

## Red Flags to Avoid

| Don't | Do |
|-------|-----|
| Say "find nearby" without explaining how | Geohash, QuadTree, or Redis GEO |
| Use SQL `WHERE lat BETWEEN` | Geospatial index |
| Ignore 3.75M location writes/s | In-memory store; shard by region |
| Synchronous matching (wait for all K) | First-accept-wins |
| Skip surge pricing | Supply/demand per region |
| Single region for global service | Multi-region; partition by geography |
| No real-time tracking discussion | WebSocket; 4s push |

---

## 30-SECOND REVISION BOX

```
FOCUS: Geospatial indexing — lead with this
GEOHASH: Encode lat/lng; shared prefix = nearby; 3×3 cell query
MATCHING: Nearest K, first-accept-wins
TRIP: State machine; quick mention
SURGE: Supply/demand per region; bonus discussion
TIME: 7–20 min on HLD + geo; 20–35 on matching/trip/surge
```

---

## Closing Strong

**You:** "To summarize: geospatial indexing is the core—Geohash or Redis GEO for efficient 'find nearest drivers.' We handle 3.75M location updates per second with an in-memory store. Matching uses first-accept-wins for low latency. Trip lifecycle is a straightforward state machine. Surge pricing uses supply/demand per region. Any area you'd like me to go deeper?"

**If time runs out:** Prioritize geospatial indexing and matching. Surge and payment can be "similar to standard e-commerce patterns."

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
