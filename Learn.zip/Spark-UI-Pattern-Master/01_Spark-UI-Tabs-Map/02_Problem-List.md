# Spark UI Tabs Map — Problem List

> **15 hands-on observations.** Open a real Spark UI in front of you, run each task, and **find the answer in the UI** — not from notes. Goal: build muscle memory for which tab answers which question.

---

## 8 MUST-DO Tasks

| # | Task                                                                  | Tab to Use     | Concept Tag           | Why Important                                  |
|---|-----------------------------------------------------------------------|----------------|------------------------|------------------------------------------------|
| 1 | Open the UI of a running script and identify all 6 tabs               | Tour all 6     | Tabs map               | First-day skill                                |
| 2 | Find which job took the longest in your run                            | Jobs           | Job ranking            | Always step 1 of debugging                     |
| 3 | Drill into that job and find the slowest stage                         | Stages         | Bottleneck isolation   | Step 2 of debugging                            |
| 4 | Open Task Summary (Min/Median/Max) for one stage                       | Stages         | Skew detection         | Most-asked interview metric                    |
| 5 | Verify `spark.sql.shuffle.partitions` is what you set                  | Environment    | Config sanity          | Real-world config debugging                    |
| 6 | Confirm a `df.cache()` actually materialized                           | Storage        | Cache verification     | Production caching mistakes                    |
| 7 | Identify if a join used Broadcast vs SortMerge                         | SQL            | Plan reading           | Most-asked plan-level interview question       |
| 8 | Find an executor with high GC time                                     | Executors      | Memory pressure        | OOM root-cause workflow                        |

---

## Complete 15-Task Progression

### Easy (1–6) — Tab Awareness

| # | Task                                                                  | Tab          | Key Skill                                               |
|---|-----------------------------------------------------------------------|--------------|---------------------------------------------------------|
| 1 | List all 6 top-tabs by name                                           | Header bar   | Map memorization                                        |
| 2 | Identify which job corresponds to a specific `df.show()` call         | Jobs         | Read `Description` column                               |
| 3 | Click into a job and count the stages                                 | Jobs→Stages  | Drill-down navigation                                   |
| 4 | Open Storage tab and read cached fraction                             | Storage      | Reading "X / Y partitions cached"                       |
| 5 | Find your Spark version and Java version                              | Environment  | Read JVM/system properties                              |
| 6 | Identify which executor is `driver`                                   | Executors    | Read executor table                                     |

### Medium (7–12) — Cross-Tab Reasoning

| # | Task                                                                  | Tab Combo            | Key Skill                                                 |
|---|-----------------------------------------------------------------------|----------------------|-----------------------------------------------------------|
| 7 | Match a "showString" job in Jobs tab to its physical plan            | Jobs ↔ SQL           | Job-to-Query linking via Description                      |
| 8 | Detect skew using Min vs Max task time                                | Stages → Task Summary| Reading distribution metrics                              |
| 9 | Spot disk spill on a stage, then verify executor memory               | Stages ↔ Executors   | Cross-tab cause/effect                                    |
| 10| Find a stage with `Shuffle Read > 0` but `Shuffle Write = 0`          | Stages               | Recognizing post-shuffle stages                           |
| 11| Identify which DataFrame in Storage tab maps to your code variable    | Storage              | Reading RDD names                                         |
| 12| Verify AQE made decisions by counting "AQE" labels in SQL tab          | SQL                  | Recognizing AQE-rewritten plans                           |

### Advanced (13–15) — Production Patterns

| # | Task                                                                  | Tab          | Key Skill                                                 |
|---|-----------------------------------------------------------------------|--------------|-----------------------------------------------------------|
| 13| Compare task duration histograms before vs after `repartition()`      | Stages       | Effect of partitioning on parallelism                     |
| 14| Find a query where `WholeStageCodegen` is missing and reason why      | SQL          | Tungsten codegen analysis                                 |
| 15| Replay an old run via History Server and reproduce the same analysis  | History UI   | Production debugging without rerunning the job            |

---

## Strategy Notes

### Task 2 — "Slowest Job" Drill

```
Approach:    Sort Jobs tab by Duration column (UI is already sorted by Job ID)
Eye-grep:    Look for outlier durations (one row >> others)
Cross-check: Click in to verify; some jobs are slow because of GC, not work
One-liner:   "Find the long row in Jobs, then click."
```

### Task 4 — Skew via Task Summary

```
Where:    Stage page → "Summary Metrics for Tasks" table
Read:     Min, 25th, Median, 75th, Max columns for "Duration"
Rule:     If Max > 10× Median → DATA SKEW (see Pattern 08)
Trap:     A single 50ms task with median 5ms is NOT skew — absolute
           values must be meaningful too.
```

### Task 6 — Cache Materialization Check

```python
df.cache()
# 1. Storage tab will be EMPTY here.
df.count()
# 2. Refresh Storage tab — DataFrame appears with X/X cached partitions.
```

```
Fix when partial:  Switch MEMORY_ONLY -> MEMORY_AND_DISK
Fix when missing:  Did you forget the action?
```

### Task 7 — Broadcast vs SortMerge Detection

```
Where:    SQL tab → click into a query
Look for: Operator names in the plan tree
  BroadcastHashJoin     -> small side broadcast (good if small enough)
  BroadcastExchange     -> the actual broadcast send
  SortMergeJoin         -> shuffle on both sides + sort (expensive)
  ShuffledHashJoin      -> rare; both shuffled but no sort
One-liner: "If you see Exchange on both children of the join, it's SortMerge."
```

### Task 9 — Spill ↔ Executor Memory

```
Stages tab:   Spill (Memory) > 0  AND  Spill (Disk) > 0
Executors tab: Storage Mem near max, GC time high
Conclusion:   Execution memory is starving cache or vice versa.
Fix:          Increase spark.executor.memory OR reduce shuffle.partitions OR uncache.
```

---

## Tab-to-Use Decision Cheat Sheet

```
QUESTION                                   FIRST TAB             THEN GO TO
----------------------------------------   ------------------    --------------------
"My pipeline is slow"                       Jobs                  Stages of slowest job
"This stage seems wrong"                    Stages                SQL (verify operator)
"Cache not working"                         Storage               Executors (memory)
"Memory issues"                             Executors             Stages (look at spill)
"Wrong join strategy"                       SQL                   Environment (configs)
"Config not applied"                        Environment           N/A (fix code)
"Schema mismatch"                           SQL → operator        Environment (jar versions)
"Some tasks much slower"                    Stages → Task Summary Pattern 08 (skew)
"How many actions did my code trigger?"     Jobs                  N/A (count rows)
"Why is X partition count different from Y" SQL → Exchange ops    Environment
```

---

## Study Plan

### Day 1 (Setup)
- Run a tiny PySpark script with `input("Press ENTER...")` to keep UI alive.
- Tour all 6 tabs without trying to debug anything.
- Bookmark `http://localhost:4040`.

### Day 2 (Basic Drill)
- Tasks 1–6.
- Practice clicking from Jobs → Stages → Tasks.

### Day 3 (Cross-Tab)
- Tasks 7–10.
- Same script, but flip `spark.sql.adaptive.enabled` and re-observe SQL tab.

### Day 4 (Production)
- Tasks 11–15.
- Enable History Server, re-open a finished run.

---

## Final Revision Box

```
JOBS         -> what action triggered work, and how long
STAGES       -> per-stage tasks, shuffle, spill, GC
STORAGE      -> cache fraction; empty = forgot action
ENVIRONMENT  -> config sanity; check before blaming Spark
EXECUTORS    -> memory + GC + dead executors
SQL          -> physical plan, Exchange, join strategy
RULE         -> Always start at Jobs, drill down to Stages.
                Cross-check with Executors / SQL when needed.
```
