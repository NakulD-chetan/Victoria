# System Design Fundamentals — Interview Thinking

> **Permanent Recall:** FAANG system design interviews run ~45 minutes and evaluate problem-solving, trade-off reasoning, communication, and depth. Four phases: Requirements (5 min), High-Level (10 min), Deep Dive (20 min), Wrap-up (5 min). Lead the conversation, state trade-offs, and demonstrate seniority by asking clarifying questions before solving. Avoid red flags: silence, jumping to solutions, ignoring scale, or dismissing failures.

---

## How FAANG Interviews Work (45 Min Format)

| Phase | Time | Goal |
|-------|------|------|
| **Requirements** | 0–5 min | Align on scope, scale, constraints |
| **High-Level Design** | 5–15 min | Draw main components, data flow |
| **Deep Dive** | 15–35 min | Go deep on 1–2 critical areas |
| **Wrap-up** | 35–45 min | Bottlenecks, failures, trade-offs, Q&A |

> **FAANG Tip:** You drive. Don't wait for the interviewer to tell you what to do. "Let me start by clarifying requirements..."

---

## What Interviewers Evaluate

| Dimension | What They Look For |
|-----------|-------------------|
| **Problem-solving** | Structured approach, decomposition, prioritization |
| **Trade-offs** | "I choose X because Y, accepting Z" |
| **Communication** | Clear explanations, diagrams, adapting to hints |
| **Depth** | Can go from high-level to implementation details |
| **Breadth** | Knows when to use cache, queue, sharding, etc. |

---

## The 4 Phases: What to Say

### Phase 1: Requirements (5 min)

**What to say:**

> "Before I draw anything, I'd like to clarify a few things. What's the scale we're designing for—DAU, requests per second? Is this read-heavy or write-heavy? Any latency or consistency requirements? And what's in scope—e.g., for a feed, do we need real-time, or is a few seconds delay acceptable?"

**Script:**
```
1. "Let me start by clarifying the scope..."
2. "What's the expected scale—users and QPS?"
3. "Is this read-heavy or write-heavy?"
4. "Any strict latency or consistency requirements?"
5. "What's in scope vs out of scope for this discussion?"
```

### Phase 2: High-Level Design (10 min)

**What to say:**

> "I'll start with a high-level design. We'll have clients hitting a load balancer, which distributes to app servers. For read-heavy workloads we'll add a cache in front of the database. The database will be sharded by user_id. For async processing we can add a message queue. Let me draw this..."

**Script:**
```
1. "Here's my high-level architecture..."
2. [Draw: Client → LB → App → Cache → DB]
3. "The main components are X, Y, Z because..."
4. "Does this direction make sense, or would you like me to adjust?"
```

### Phase 3: Deep Dive (20 min)

**What to say:**

> "The critical path is feed generation. Let me dive into that. We have two options: pull model vs push model. For a Twitter-scale read:write ratio, push (fan-out on write) would overwhelm the system, so we'd use pull (fan-out on read) with a hybrid for celebrities. I'll use a distributed cache for the timeline..."

**Script:**
```
1. "Let me deep dive into [critical component]..."
2. "There are a few approaches: A, B, C. I'd choose A because..."
3. "For the data model, we'd have..."
4. "The trade-off here is..."
```

### Phase 4: Wrap-up (5 min)

**What to say:**

> "Let me address failure modes. We'd want multiple replicas for the database, circuit breakers on downstream calls, and a fallback to degraded mode if the cache goes down. The main bottleneck could be hot partitions—we'd handle that with consistent hashing and perhaps local caching."

---

## How to Lead the Conversation

| Do | Don't |
|----|-------|
| Ask clarifying questions first | Jump straight to "we need Kafka" |
| State assumptions out loud | Assume scale or requirements |
| Draw as you talk | Write a wall of text |
| Check in: "Does this direction work?" | Monologue for 30 minutes |
| Prioritize: "Let me focus on the critical path" | Try to cover everything superficially |

---

## How to Handle "What If" Questions

| Question Type | Response Strategy |
|---------------|-------------------|
| **"What if we have 10x traffic?"** | "We'd scale horizontally—more app servers, add read replicas, consider sharding the DB" |
| **"What if the cache fails?"** | "Fail-through to DB; add circuit breaker; maybe multi-level cache" |
| **"What if we need strong consistency?"** | "We'd use a primary-replica model with synchronous replication, accepting higher latency" |
| **"What if we go global?"** | "Multi-region deployment, CDN, eventual consistency across regions" |

---

## Junior vs Mid vs Senior Expectations

| Level | Expectations |
|-------|---------------|
| **Junior** | Basic components (LB, cache, DB), can follow a template |
| **Mid** | Trade-offs, scale estimation, failure modes, 1–2 areas of depth |
| **Senior** | Leads design, considers ops, multiple approaches, mentors interviewer |
| **Staff+** | Multi-system, org impact, capacity planning, cross-team alignment |

> **FAANG Tip:** To demonstrate seniority: ask about ops, monitoring, rollout strategy, and cost. "How would we monitor this? What's the rollout plan? How do we handle a bad deployment?"

---

## Red Flags Interviewers Watch For

| Red Flag | Why It's Bad |
|----------|--------------|
| **Jumping to solution** | Shows lack of structured thinking |
| **Ignoring scale** | Single-server design for 1B users |
| **No trade-off discussion** | Suggests black-and-white thinking |
| **Single point of failure** | Doesn't think about production |
| **Silent for long periods** | Poor communication |
| **Dismissing failures** | "That won't happen" = overconfident |
| **Over-engineering** | Kafka for 100 QPS |
| **Under-engineering** | No cache for 100K QPS |
| **No data model** | Vague "we store stuff" |
| **Can't go deep** | Stays surface-level when probed |

---

## "What to Say" Example Scripts

### Opening
> "I'll start by clarifying requirements, then propose a high-level design, and we can deep dive into the areas you're most interested in. Sound good?"

### When Stuck
> "I'm thinking through the trade-offs here. On one hand we could X for lower latency, but that would increase Y. Let me consider Z..."

### When Corrected
> "Good point—I hadn't considered that. So we'd adjust by... Does that address it?"

### Closing
> "To summarize: we'd use X for Y, with Z as the main trade-off. The main failure modes we'd handle are A and B. Is there anything you'd like me to explore further?"

---

## Quick Memory Card

```
4 PHASES:    Requirements (5) → High-Level (10) → Deep Dive (20) → Wrap-up (5)
LEAD:        You drive; ask first, draw second
TRADE-OFFS:  Always state "X because Y, accepting Z"
WHAT-IF:     Scale → horizontal scaling; fail → redundancy/fallback
RED FLAGS:   No requirements, no scale, no failures, silent, over-engineering
```

---

**Next: [[05_Common-Mistakes]]**
