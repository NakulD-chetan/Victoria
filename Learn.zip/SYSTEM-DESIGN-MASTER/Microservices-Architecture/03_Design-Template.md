# Microservices Architecture — Design Template

> **Permanent Recall:** Reusable templates: microservices architecture, API gateway, service discovery, service mesh, database per service, BFF, and Strangler Fig migration. Each has "when to use" and architecture diagram. Use these as starting points in system design interviews.

---

## Template 1: Microservices Architecture

**When to use:** Multi-team, independent deploy, scale per service.

```
    ┌─────────────────────────────────────────────────────────────────┐
    │                         CLIENTS                                   │
    └────────────────────────────────┬────────────────────────────────┘
                                     │
                                     ▼
    ┌─────────────────────────────────────────────────────────────────┐
    │                     API GATEWAY                                   │
    └────────────────────────────────┬────────────────────────────────┘
                                     │
     ┌───────────┬───────────┬───────┴───────┬───────────┬───────────┐
     ▼           ▼           ▼               ▼           ▼           ▼
┌─────────┐ ┌─────────┐ ┌─────────┐     ┌─────────┐ ┌─────────┐ ┌─────────┐
│User Svc │ │Order Svc│ │Payment  │     │Search   │ │Notify   │ │Analytics│
│  + DB   │ │  + DB   │ │  + DB   │     │  + ES   │ │ + Queue │ │ + DB   │
└────┬────┘ └────┬────┘ └────┬────┘     └─────────┘ └─────────┘ └─────────┘
     │           │           │
     └───────────┴───────────┴──► Message Bus (Kafka/RabbitMQ)
```

---

## Template 2: API Gateway Setup

**When to use:** External clients; need central auth, rate limit, routing.

```
CONFIG (conceptual):
  routes:
    /api/users/*     → user-service:8080
    /api/orders/*    → order-service:8080
    /api/payments/*  → payment-service:8080
  auth: JWT validation at gateway
  rate_limit: 100 req/min per client
  aggregator: /api/dashboard → [user + order + payment] (BFF)
```

---

## Template 3: Service Discovery Template

**When to use:** Dynamic scaling; service instances change.

```
Client-side (Eureka):
  App → Eureka Server (get list of Order Service instances)
  App → Pick instance (round robin) → Call directly

Server-side (K8s):
  App → order-service (K8s Service DNS)
  K8s routes to pod (built-in load balancing)
```

---

## Template 4: Service Mesh Template

**When to use:** mTLS, retries, observability without app changes.

```
    ┌─────────────────────────────────────────────────────┐
    │              CONTROL PLANE (Istio)                   │
    │         Config, certs, policy                         │
    └────────────────────────────────┬────────────────────┘
                                     │
     ┌───────────────────────────────┼───────────────────────────────┐
     ▼                               ▼                               ▼
┌─────────────┐               ┌─────────────┐               ┌─────────────┐
│ [App][Proxy]│◄──mTLS───────►│ [App][Proxy]│◄──mTLS───────►│ [App][Proxy]│
│  Service A  │               │  Service B  │               │  Service C  │
└─────────────┘               └─────────────┘               └─────────────┘
```

---

## Template 5: Database per Service Template

**When to use:** Service ownership; independent schema evolution.

```
Service A              Service B              Service C
┌──────────┐          ┌──────────┐          ┌──────────┐
│ DB A     │          │ DB B     │          │ DB C     │
│ (Users)  │          │ (Orders) │          │ (Payments)│
└──────────┘          └──────────┘          └──────────┘
     │                      │                      │
     └──────────────────────┴──────────────────────┘
                            │
              Shared: user_id, order_id (foreign refs in app, not DB)
              Data sync: events (if needed)
```

---

## Template 6: BFF Template

**When to use:** Different clients need different data shapes.

```
    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
    │ Mobile App  │    │ Web App     │    │ Third-party │
    └──────┬──────┘    └──────┬──────┘    └──────┬──────┘
           │                  │                  │
           ▼                  ▼                  ▼
    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
    │ Mobile BFF  │    │ Web BFF     │    │ Public API  │
    │ (fewer calls│    │ (aggregated)│    │ (versioned) │
    │  batched)   │    │             │    │             │
    └──────┬──────┘    └──────┬──────┘    └──────┬──────┘
           │                  │                  │
           └──────────────────┼──────────────────┘
                              ▼
                    ┌─────────────────┐
                    │  Microservices  │
                    └─────────────────┘
```

---

## Template 7: Strangler Fig Migration Steps

**When to use:** Migrating monolith to microservices.

```
PHASE 1: Identify & extract
  - Pick low-risk, high-value module (e.g., notifications)
  - Create new service; route new features there

PHASE 2: Proxy at gateway
  - /api/notifications → New Notification Service
  - Other paths → Monolith

PHASE 3: Migrate traffic
  - Dual-write if data shared
  - Shift reads gradually
  - Deprecate monolith path

PHASE 4: Repeat
  - Extract next module
  - Eventually retire monolith
```

---

## 30-SECOND REVISION BOX

```
ARCHITECTURE:   Gateway → N services → Message bus
API GATEWAY:    Routes, auth, rate limit per path
DISCOVERY:      Client (Eureka) or server (K8s DNS)
MESH:           Control plane + sidecar per pod
DB PER SERVICE: No shared DB; share IDs; events for sync
BFF:            Per client type; aggregate backends
MIGRATION:      Identify → Proxy → Shift → Repeat
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
