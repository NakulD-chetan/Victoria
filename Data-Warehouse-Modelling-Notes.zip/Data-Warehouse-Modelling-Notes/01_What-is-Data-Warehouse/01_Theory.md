# What is a Data Warehouse

> *"A data warehouse is a subject-oriented, integrated, time-variant, and nonvolatile collection of data in support of management's decision-making process."* — W. H. Inmon

**Real-world analogy:** A data warehouse is like a **regional distribution center** for a large retailer: individual stores and suppliers ship boxes in many shapes and labels, but the center **sorts, standardizes, and shelves** inventory so planners can answer questions like *"Which regions sold the most organic produce last quarter?"* without rummaging through every store's back room.

---

## Core Idea (2 Lines)

A **data warehouse (DW)** is a **central, query-optimized store** built for analysis and reporting, not for day-to-day transaction entry. Data moves through a disciplined pipeline (**collect, clean, store, analyze**) so business questions can be answered with **consistent history** and **controlled definitions**.

---

## Definition: Central Store for Analysis

| Aspect | What it means in practice |
|--------|---------------------------|
| **Central** | One governed place (logical or physical) where analysts and BI tools look for "official" numbers |
| **For analysis** | Designed for **read-heavy** scans, joins, and aggregates across large time ranges |
| **Organized for querying** | Modeled for **facts and dimensions**, conformed keys, and predictable grain — not just third-normal-form OLTP convenience |

**Interview Tip:** Say *"A DW is not 'a big database'; it is a **purpose-built analytical store** with governance, history, and performance patterns tuned for reporting workloads."*

---

## The Flow: Collect, Clean, Store, Analyze

```
+-------------+     +-------------+     +----------------+     +----------------+
|  COLLECT    | --> |   CLEAN     | --> |     STORE      | --> |    ANALYZE     |
| (sources)   |     | (quality,   |     | (DW layers,    |     | (BI, SQL,      |
|             |     |  conform)   |     |  models)       |     |  notebooks)    |
+-------------+     +-------------+     +----------------+     +----------------+
```

| Stage | Retail example (nationwide grocery marketplace) |
|-------|--------------------------------------------------|
| **Collect** | Orders from web/mobile, POS from partner stores, payment events from processors, loyalty app clicks |
| **Clean** | Fix invalid ZIP codes, dedupe customers, map SKUs to a **golden product id**, currency normalization |
| **Store** | Load **staging** then **dimensional** models (sales facts, customer/product/date dimensions) |
| **Analyze** | Dashboards for category managers, cohort studies, finance close packs |

**Watch Out!** Teams sometimes skip **clean** and dump raw tables into a "warehouse." Without conformance, two dashboards will disagree on revenue — and nobody trusts either.

---

## Database vs Data Warehouse

| Dimension | Typical **Operational Database** | Typical **Data Warehouse** |
|-----------|----------------------------------|------------------------------|
| **Purpose** | Run the business (orders, inventory reservations, refunds) | **Measure** the business (trends, KPIs, forecasts) |
| **Usage pattern** | Many short **read/write** transactions | Fewer connections, **heavy reads**, bulk loads |
| **Speed goal** | Milliseconds for critical paths | Seconds to minutes for big aggregates (acceptable when planned) |
| **Data type** | Current state + minimal history for operations | **Historical** snapshots, slowly changing attributes, audit-friendly loads |
| **Optimization** | Indexes for point lookups, row-level locking, write throughput | Columnar or star-schema friendly layouts, partition pruning, aggregate awareness |

**Interview Tip:** Contrast **serving a checkout** (OLTP) vs **computing last year's revenue by region and category** (DW). Same company, different workload physics.

---

## OLTP vs OLAP

| Topic | **OLTP** (Online Transaction Processing) | **OLAP** (Online Analytical Processing) |
|-------|--------------------------------------------|----------------------------------------|
| **Question shape** | *"Reserve 2 units of SKU-4412 for customer 9081"* | *"Compare average basket size by month and fulfillment channel"* |
| **Transaction size** | Small (few rows) | Large scans (millions to billions of rows) |
| **Concurrency** | High | Moderate; often scheduled windows |
| **Schema style** | Normalized, many tables, tight integrity | Denormalized / dimensional, **facts + dimensions** |
| **Example system** | Store inventory DB, payment switch | Enterprise DW, semantic layer, BI cubes |

```sql
-- OLTP-shaped query (point lookup)
SELECT quantity_on_hand
FROM store_inventory
WHERE store_id = 1024
  AND sku_id = 'SKU-4412';

-- OLAP-shaped query (scan + aggregate)
SELECT d.month,
       f.fulfillment_channel,
       SUM(f.extended_price) AS revenue,
       AVG(f.line_items)     AS avg_lines_per_order
FROM fact_sales f
JOIN dim_date d ON f.order_date_sk = d.date_sk
WHERE d.calendar_year = 2025
GROUP BY d.month, f.fulfillment_channel
ORDER BY d.month, f.fulfillment_channel;
```

**Watch Out!** Running OLAP SQL against OLTP systems can **hurt production**: long-running scans compete for buffer pool and I/O, and missing indexes force table scans.

---

## Bill Inmon's Classic Definition (Expanded)

Inmon's phrase unpacks into four properties teams still interview on:

| Property | Meaning | Retail example |
|----------|---------|----------------|
| **Subject-oriented** | Organized around business subjects (customer, product, sales), not around source applications | *Sales* subject combines web, app, and partner POS feeds |
| **Integrated** | Naming, codes, and units are **conformed** across sources | One `customer_id`, one `currency_code` list |
| **Non-volatile** | Loads are **append/insert** oriented; corrections are controlled (often new rows / versioning) | You do not "lose" December numbers when January loads |
| **Time-variant** | History is explicit (dates, effective ranges, snapshots) | Price changes over time do not rewrite old facts blindly |

**Interview Tip:** Memorize the four words (**subject-oriented, integrated, non-volatile, time-variant**) and be ready to give **one sentence each** with a concrete example.

---

## ETL vs ELT (Brief Intro)

| Pattern | Order | Typical sweet spot |
|---------|-------|----------------------|
| **ETL** | **Extract** from sources, **Transform** in a dedicated engine, **Load** into DW | Strong schema-on-write, legacy sources, heavy cleansing before landing |
| **ELT** | **Extract**, **Load** raw-ish into a platform, **Transform** in-warehouse (SQL/Spark) | Cloud scale, many sources, reuse compute pool for transforms |

```sql
-- ELT flavor: land then transform inside the warehouse
-- (illustrative; real pipelines add orchestration, idempotency, and SLAs)

CREATE TABLE landing_orders AS
SELECT * FROM external_orders_raw;

CREATE TABLE dw_stg_orders AS
SELECT
  order_id,
  UPPER(TRIM(customer_email)) AS customer_email,
  TRY_TO_TIMESTAMP(order_ts)    AS order_ts_utc
FROM landing_orders;
```

**Watch Out!** **ELT** is not "no governance." It usually shifts **where** transforms happen, not **whether** definitions are owned.

---

## End-to-End Picture: Sources to Users

```
+----------------+   +----------------+   +----------------+
| Source Systems |   |  Payments /    |   |  Marketing /   |
| (Web, App POS) |   |  Fraud / PSP   |   |  Campaign tool |
+-------+--------+   +--------+-------+   +--------+-------+
        |                     |                    |
        v                     v                    v
   +---------------------------------------------------------+
   |                    ETL / ELT Platform                    |
   |  (ingest, cleanse, conform, dedupe, slowly-changing)     |
   +---------------------------+------------------------------+
                               v
                    +--------------------+
                    |   DATA WAREHOUSE   |
                    | (staging + curated |
                    |  star/snowflake)   |
                    +----------+---------+
                               v
                    +--------------------+
                    | BI / Semantic /   |
                    | Metrics layer     |
                    +----------+---------+
                               v
                    +--------------------+
                    | Users: Finance,    |
                    | Merch, Ops, Exec   |
                    +--------------------+
```

**Interview Tip:** Be able to narrate **why** each hop exists: sources are messy and siloed; the integration layer enforces rules; the DW holds **conformed history**; BI translates tables into **business metrics**.

---

## Retail Deep Dive: Orders, Customers, Payments

| Data domain | What operations capture | What the warehouse adds |
|-------------|-------------------------|-------------------------|
| **Orders** | Line items, promotions, fulfillment nodes | **Unified** order grain, handling splits/returns consistently |
| **Customer** | Accounts, addresses, consent flags | **Golden customer**, householding, privacy redaction patterns |
| **Payments** | Authorizations, captures, chargebacks | Reconciliation to **recognized revenue** rules used by finance |

---

## Governance and Trust (Why "Warehouse" Implies Process)

| Mechanism | Outcome |
|-----------|---------|
| **Data dictionary / metrics catalog** | Same definition of *Net Sales* everywhere |
| **SLAs on freshness** | Dashboards show *as-of* expectations |
| **Lineage** | When a number changes, you know which upstream feed moved |

**Watch Out!** A technically correct pipeline with **no metric ownership** still fails — users debate definitions instead of decisions.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Calling any large Postgres/MySQL instance a "warehouse" without modeling discipline | You get **slow reports** and **inconsistent KPIs** | Adopt **layered architecture**, conformed dimensions, documented grains |
| Running huge ad hoc joins on OLTP replicas "because it's easy" | **Replica lag**, timeouts, and angry operations teams | Route analytics to a **DW** or governed mart |
| Skipping history (only storing current snapshot) | Cannot answer *"What did we think last quarter?"* | Track **time variance** with facts + SCD strategy |
| Treating ETL as a one-time script | Breaks on schema drift and late-arriving facts | Add tests, monitoring, and **idempotent** loads |

---

## Key Takeaway

> A data warehouse is a **decision-support system backed by data**: it **integrates** messy operational reality into **subject areas**, preserves **time**, resists careless overwrites (**non-volatile** in the governance sense), and is **optimized for analytical querying** — with pipelines that **collect, clean, store, and analyze** so a retailer can trust revenue, inventory, and customer insights across channels.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| DW = central analytical store; NOT "just a big OLTP DB"          |
| Flow: COLLECT -> CLEAN -> STORE -> ANALYZE                       |
| OLTP vs OLAP: short writes vs heavy scans/aggregates             |
| Inmon: subject-oriented, integrated, non-volatile, time-variant  |
| ETL vs ELT: transform before vs after landing in warehouse compute |
| Architecture: sources -> ETL/ELT -> DW -> BI -> business users   |
+------------------------------------------------------------------+

```
