import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const S = 'banana';

function generateSteps() {
  const steps = [];
  const n = S.length;
  const suffixes = [];
  for (let i = 0; i < n; i++) suffixes.push({ start: i, str: S.slice(i) });
  steps.push({ type: 'list', msg: 'All suffixes', S, suffixes: suffixes.map((x) => ({ ...x })), phase: 'list' });
  for (let i = 0; i < suffixes.length; i++) {
    steps.push({
      type: 'show',
      msg: `Suffix ${i}: "${suffixes[i].str}"`,
      S,
      start: suffixes[i].start,
      suffix: suffixes[i].str,
      suffixes: suffixes.map((x) => ({ ...x })),
    });
  }
  steps.push({ type: 'sort', msg: 'Sort suffixes lexicographically', S, suffixes: suffixes.map((x) => ({ ...x })) });
  suffixes.sort((a, b) => a.str.localeCompare(b.str));
  const sortedSuffixes = suffixes.map((x) => ({ ...x }));
  for (let i = 0; i < sortedSuffixes.length; i++) {
    steps.push({
      type: 'rank',
      msg: `SA[${i}] = ${sortedSuffixes[i].start} ("${sortedSuffixes[i].str}")`,
      S,
      sa: sortedSuffixes.map((x) => x.start),
      highlight: i,
      suffixes: sortedSuffixes,
    });
  }
  steps.push({ type: 'done', msg: 'Suffix array built', S, sa: suffixes.map((x) => x.start) });
  return steps;
}

function paint(step) {
  const S = step.S;
  const textColors = {};
  const patternColors = {};
  if (step.type === 'list') {
    for (let k = 0; k < S.length; k++) textColors[k] = 'current';
  }
  if (step.start != null) {
    for (let k = 0; k < S.length; k++) textColors[k] = k < step.start ? 'default' : 'current';
    const suf = step.suffix || '';
    for (let k = 0; k < suf.length; k++) patternColors[k] = 'match';
  }
  if (step.type === 'rank' && step.sa) {
    step.sa.forEach((pos, idx) => {
      if (idx === step.highlight) textColors[pos] = 'found';
    });
  }
  const table = step.sa || step.suffixes?.map((_, i) => i) || null;
  const patStr = step.type === 'list' ? S : (step.suffix || S);
  return {
    text: S.split(''),
    pattern: patStr.split(''),
    textColors,
    patternColors,
    offset: step.start ?? 0,
    table,
    tableLabel: 'Suffix array (indices)',
    matchPositions:
      step.type === 'rank' && step.suffixes && step.highlight != null
        ? [step.suffixes[step.highlight]?.start].filter((x) => x != null)
        : [],
    comparePairs: null,
  };
}

export default function SuffixArrayVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Suffix array for "${S}"` });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
