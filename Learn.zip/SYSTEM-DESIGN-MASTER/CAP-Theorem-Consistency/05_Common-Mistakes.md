# CAP Theorem and Consistency — Common Mistakes

> **Permanent Recall:** Top CAP mistakes: saying "choose 2 of 3" literally, ignoring PACELC, thinking eventual = no consistency, not specifying consistency requirements, using strong consistency everywhere, ignoring network partitions in design, confusing ACID with CAP consistency, not discussing conflict resolution, and over-simplifying consensus. Avoid these to demonstrate FAANG-level understanding.

---

## Mistake 1: Saying "Choose 2 of 3" Literally

**What's wrong:** Implies you can have CA (no partition tolerance). In practice, P is mandatory.

| Wrong | Right |
|-------|-------|
| "We choose CA" | "We choose CP—during partition we favor consistency" |
| "You pick any 2" | "During partition, you choose C or A" |

> **FAANG Tip:** Say "During a partition, we sacrifice availability for consistency" (CP) or the reverse (AP).

---

## Mistake 2: Ignoring PACELC

**What's wrong:** CAP only covers the partition case. Normal operation also has trade-offs.

**Add:** "When there's no partition, we still choose between low latency (eventual reads) and strong consistency (quorum reads). PACELC captures that."

---

## Mistake 3: Thinking Eventual = No Consistency

**What's wrong:** Eventual consistency *is* a consistency model. Replicas converge.

| Wrong | Right |
|-------|-------|
| "Eventual means inconsistent" | "Eventual means replicas converge if writes stop" |
| "No guarantees" | "Guarantee: convergence; no guarantee on when" |

---

## Mistake 4: Not Specifying Consistency Requirements

**What's wrong:** Designing without asking "what happens if user sees stale data?"

**Fix:** For every data type, state: strong, eventual, or something in between. Document the choice.

---

## Mistake 5: Using Strong Consistency Everywhere

**What's wrong:** Overkill for many use cases. Adds latency, reduces availability.

| Use Strong | Use Eventual |
|------------|---------------|
| Balance, inventory, locks | Likes, feeds, analytics |
| Financial, medical | Social, non-critical counters |

---

## Mistake 6: Ignoring Network Partitions

**What's wrong:** Designing as if partitions never happen. They do.

**Fix:** "What happens when DC A and DC B can't communicate?" Have an answer for CP and AP.

---

## Mistake 7: Confusing ACID Consistency with CAP Consistency

**What's wrong:** ACID "C" = integrity (constraints, triggers). CAP "C" = all nodes see same data.

| ACID Consistency | CAP Consistency |
|-------------------|-----------------|
| Valid state (integrity) | Replication uniformity |
| DB constraints | Read-your-writes, linearizability |

---

## Mistake 8: Not Discussing Conflict Resolution

**What's wrong:** AP systems will have conflicts. Saying "we use Cassandra" without saying how conflicts are resolved is incomplete.

**Add:** "We use LWW for timestamps" or "We merge with CRDTs" or "Application logic decides."

---

## Mistake 9: Over-Simplifying Consensus

**What's wrong:** "We use Paxos" without knowing when it's used or what it does.

**Better:** "We use Raft for leader election. Writes go to the leader and replicate to a quorum. If the leader fails, we elect a new one."

---

## Mistake 10: Assuming "Default" Is Always Right

**What's wrong:** DynamoDB default is eventually consistent. Cassandra default is ONE. Don't assume—choose explicitly for critical operations.

---

## Summary: Mistake → Fix

| Mistake | Fix |
|---------|-----|
| "Choose 2 of 3" | "During partition, C or A" |
| Ignore PACELC | Mention normal-case trade-off |
| Eventual = no consistency | Eventual = converge over time |
| No requirements | Specify per data type |
| Strong everywhere | Strong only when harm possible |
| Ignore partitions | Design for them |
| ACID = CAP | Different concepts |
| No conflict plan | LWW, merge, or escalate |
| Consensus hand-wavy | Understand Raft/Paxos |
| Default = right | Choose explicitly |

---

## Interview Impact

**Making these mistakes:** Interviewer may conclude you don't understand distributed systems deeply.

**Avoiding them:** Shows you've worked with or studied real systems. Mention PACELC, conflict resolution, and partition behavior to stand out.

---

## Bonus: What Strong Candidates Say

- "During a partition, we choose C or A—P is given."
- "PACELC adds the normal-case trade-off: latency vs consistency."
- "Eventual consistency means convergence—it's a model, not 'no consistency'."
- "For conflicts we use LWW, but clock skew is a risk—we'd consider HLC."

---

## 30-SECOND REVISION BOX

```
1. "Choose 2" → "During partition, C or A"
2. Mention PACELC for normal case
3. Eventual ≠ no consistency
4. Specify requirements per data type
5. Don't over-use strong
6. Design for partitions
7. ACID C ≠ CAP C
8. Conflict resolution for AP
9. Understand consensus, don't name-drop
10. Choose consistency explicitly
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
