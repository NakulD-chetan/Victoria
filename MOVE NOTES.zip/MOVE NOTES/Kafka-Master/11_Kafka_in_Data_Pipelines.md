# 11. Kafka in Data Pipelines

> **Permanent Recall Note:** Kafka is often the **central nervous system** of modern data platforms: **CDC** events, **microservice** domain events, **streaming ETL** inputs, and **feature** pipelines. Data Engineers connect **Kafka → Spark/Flink → Lakehouse**, **Kafka → Connect → Warehouse**, and **MirrorMaker** for **DR**. Map this mentally to Spark’s role as **compute** — [../spark/00_Table_of_Contents.md](../spark/00_Table_of_Contents.md) — Kafka is **durable motion** of facts.

### The 10-Second Summary
- **Hub-and-spoke** — decouple **producers** from **many** consumers.
- **CDC:** Debezium → Kafka → processing — **ordering** per table partition key.
- **Event sourcing** — **topic as journal**; **KTable** materialization in Streams.
- **Lambda/Kappa:** Kafka often **feeds both** batch and stream paths — **Kappa** prefers stream-first.

---

# 11.1 Kafka as Central Nervous System

```
┌────────┐  ┌────────┐  ┌────────┐
│ OLTP   │  │ Mobile │  │ Logs   │
└───┬────┘  └───┬────┘  └───┬────┘
    │           │           │
    └───────────┼───────────┘
                ▼
         ┌──────────────┐
         │    KAFKA     │
         └──────┬───────┘
    ┌────────────┼────────────┐
    ▼            ▼            ▼
 Spark/Flink   Warehouse    RT serving
```

💡 **Key Insight:** **Ownership** of topics = **data product** boundaries — **governance** matters.

---

# 11.2 CDC Pipeline Patterns

```
DB ──WAL/binlog──► Debezium ──► Kafka topics ──► Flink/Spark ──► Iceberg/Delta
```

- **Ordering:** often **per primary key** within partition — **join** downstream carefully.
- **Late** updates — **upsert** semantics in sink.

📏 **Golden Rule:** **Primary keys** + **idempotent** sinks — same as Spark quality chapter [../spark/13_Data_Quality_Idempotency.md](../spark/13_Data_Quality_Idempotency.md).

---

# 11.3 Event Sourcing with Kafka

- **Append** domain events — **materialize** read models in **projectors**.
- **Compaction** topics for **latest** snapshot per **aggregate id**.

---

# 11.4 Kafka + Spark Streaming

- **Structured Streaming** `readStream` from Kafka — **checkpoint** offsets.
- **Batch** + **stream** unification — **same** SQL for **backfill** and **live**.

🔄 **Trade-off:** **Micro-batch** latency vs **operational** simplicity — Spark team choice.

---

# 11.5 Kafka + Flink

- **Native** Kafka source/sink — **lower latency** than micro-batch Spark.
- **Exactly-once** **two-phase commit** with **Kafka** versions supporting **transactions**.

---

# 11.6 Kafka + Airflow

- **Batch** consumers — **Kafka** as **source** for **DAG** tasks (Sensor/Operator patterns).
- **Not** a replacement for **Connect** for continuous **bulk** — different **cadence**.

---

# 11.7 Real-Time ETL Patterns

| Pattern | Sketch |
|---------|--------|
| **Enrich** | Stream join **KTable** / **Redis** |
| **Aggregate** | **Windows** in Flink/Streams |
| **Deduplicate** | **Keys** + state store |

---

# 11.8 Kafka as Buffer Between Microservices

- **Decouple** latency — **backpressure** via **consumer** speed.
- **SAGA** / **outbox** — **dual write** avoided via **outbox** table + Debezium.

---

# 11.9 Log Aggregation with Kafka

- **Agents** → Kafka → **sink** to ES/S3 — high **throughput**.
- **Retention** separate from **search** tier — **tiered** storage options.

---

# 11.10 Kafka for ML Feature Stores

- **Feature** events streamed — **online** vs **offline** consistency challenges.
- **Feast** / custom — Kafka as **transport**.

---

# 11.11 Multi-Datacenter Replication — MirrorMaker 2

```
DC1 Kafka ═════ MirrorMaker 2 (topics, offsets mapping) ═════► DC2 Kafka
```

- **Active-active** complexity — **conflict** resolution **not** Kafka’s job.

⚠️ **Warning:** **Ordering** and **offsets** differ across clusters — **design** consumers per DC.

---

# 11.12 Lambda vs Kappa Architecture

| Style | Kafka role |
|-------|--------------|
| **Lambda** | **Speed** layer + **batch** layer — Kafka feeds **both** |
| **Kappa** | **Stream-only** processing — **reprocess** from log |

---

# 11.13 Governance, ACLs & Multi-Tenant Topics

- **ACLs** (SASL/SSL): **who** can **Read/Write/Describe** topics — **least privilege** for Connect workers vs apps.
- **Topic naming:** `domain.entity.event.v1` — **ownership** tag in **catalog** (DataHub/OpenMetadata).
- **PII** in events ⇒ **masking** in **SMT** or **downstream** before **lake** — same **quality** mindset as Spark pipelines ([../spark/13_Data_Quality_Idempotency.md](../spark/13_Data_Quality_Idempotency.md)).

---

# 11.14 Interview Questions & Answers

**Q: CDC ordering guarantee?**  
**A:** **Per partition** — **global** table order **not** guaranteed across partitions.

**Q: Why outbox pattern?**  
**A:** **Atomic** DB commit + **event** emission without **dual-write** race.

**Q: Spark batch vs streaming for same topic?**  
**A:** **Different** offsets/checkpoints — **coordinate** **backfill** windows.

**Q: MM2 vs cluster link?**  
**A:** **MM2** = **Kafka-native** replication with **topic mapping** — know **offset translation**.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 11 — QUICK RECALL                                 │
├─────────────────────────────────────────────────────────────┤
│  🧠 Kafka = backbone for CDC, events, streaming ETL         │
│  🧠 Idempotent sinks + keys = practical EOS                 │
│  🧠 MM2 for DR — offset/topic mapping awareness             │
│  🧠 Lambda/Kappa = how batch+speed relate                 │
│  ⚠️  Active-active needs app-level conflict rules         │
│  🎯 Tie to Spark/Flink choice by latency + ops            │
└─────────────────────────────────────────────────────────────┘
```
