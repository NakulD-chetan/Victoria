import { useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import MemberRow from './MemberRow';
import InviteByLink from './InviteByLink';
import PermissionsTab from './PermissionsTab';
import './shareDialog.css';

/*
 * ShareDialog — single dialog parameterised by the resource being shared.
 *
 * Props:
 *   - open                — boolean
 *   - onClose             — () => void
 *   - resource            — { type: 'vault'|'folder'|'note', id: string,
 *                              vaultId: string, name?: string }
 *
 * Tabs:
 *   - People       — current members + invite-by-email
 *   - Link         — generate / list / revoke token-based invite links
 *   - Permissions  — only shown for folder/note; resource_acl overrides
 */

const TABS = [
  { id: 'people',      label: 'People' },
  { id: 'link',        label: 'Link' },
  { id: 'permissions', label: 'Permissions' },
];

export default function ShareDialog({ open, onClose, resource }) {
  const { user } = useAuth();
  const [tab, setTab] = useState('people');
  const [members, setMembers] = useState([]);
  const [invites, setInvites] = useState([]);
  const [loading, setLoading] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('viewer');
  const [inviting, setInviting] = useState(false);
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');

  const vaultId = resource?.vaultId;
  const isResourceLevel = resource?.type === 'folder' || resource?.type === 'note';

  const myMembership = useMemo(
    () => members.find((m) => m.user_id === user?.id) || null,
    [members, user?.id],
  );
  const isOwner = myMembership?.role === 'owner';

  useEffect(() => {
    if (!open || !vaultId) return;
    let cancelled = false;
    setLoading(true);
    setError('');
    (async () => {
      const [mRes, iRes] = await Promise.all([
        supabase
          .from('vault_members')
          .select('vault_id, user_id, role, added_at, profile:profiles!inner(id, email, display_name, avatar_url)')
          .eq('vault_id', vaultId),
        supabase
          .from('vault_invites')
          .select('*')
          .eq('vault_id', vaultId)
          .order('created_at', { ascending: false }),
      ]);
      if (cancelled) return;
      if (mRes.error) setError(mRes.error.message);
      setMembers(mRes.data || []);
      setInvites(iRes.data || []);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [open, vaultId]);

  /* Realtime: keep members/invites lists fresh while the dialog is open. */
  useEffect(() => {
    if (!open || !vaultId) return undefined;
    const channel = supabase
      .channel(`share-dialog:${vaultId}`)
      .on('postgres_changes',
          { event: '*', schema: 'public', table: 'vault_members', filter: `vault_id=eq.${vaultId}` },
          async () => {
            const { data } = await supabase
              .from('vault_members')
              .select('vault_id, user_id, role, added_at, profile:profiles!inner(id, email, display_name, avatar_url)')
              .eq('vault_id', vaultId);
            setMembers(data || []);
          })
      .on('postgres_changes',
          { event: '*', schema: 'public', table: 'vault_invites', filter: `vault_id=eq.${vaultId}` },
          async () => {
            const { data } = await supabase
              .from('vault_invites')
              .select('*')
              .eq('vault_id', vaultId)
              .order('created_at', { ascending: false });
            setInvites(data || []);
          })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [open, vaultId]);

  if (!open || !resource) return null;

  const inviteByEmail = async (e) => {
    e?.preventDefault?.();
    if (!inviteEmail.trim() || inviting) return;
    setInviting(true);
    setError('');
    setInfo('');
    /* Look up an existing user by email; if found, add directly to
     * vault_members (RLS lets owners do this). Otherwise create a
     * pending invite row that they can accept after signing up. */
    const email = inviteEmail.trim().toLowerCase();
    const { data: existing } = await supabase
      .from('profiles')
      .select('id, email')
      .eq('email', email)
      .maybeSingle();
    let opErr = null;
    if (existing) {
      const { error: e2 } = await supabase
        .from('vault_members')
        .upsert(
          { vault_id: vaultId, user_id: existing.id, role: inviteRole, added_by: user.id },
          { onConflict: 'vault_id,user_id' },
        );
      opErr = e2;
      if (!e2) setInfo(`Added ${email} as ${inviteRole}.`);
    } else {
      const { error: e2 } = await supabase
        .from('vault_invites')
        .insert({
          vault_id: vaultId,
          email,
          role: inviteRole,
          invited_by: user.id,
          expires_at: new Date(Date.now() + 14 * 24 * 3600 * 1000).toISOString(),
        });
      opErr = e2;
      if (!e2) setInfo(`Invite sent to ${email} (expires in 14 days).`);
    }
    if (opErr) setError(opErr.message);
    setInviting(false);
    if (!opErr) setInviteEmail('');
  };

  const updateRole = async (member, role) => {
    const { error: err } = await supabase
      .from('vault_members')
      .update({ role })
      .eq('vault_id', member.vault_id)
      .eq('user_id', member.user_id);
    if (err) setError(err.message);
  };
  const removeMember = async (member) => {
    if (!confirm(`Remove ${member.profile?.display_name || member.profile?.email || 'member'}?`)) return;
    const { error: err } = await supabase
      .from('vault_members')
      .delete()
      .eq('vault_id', member.vault_id)
      .eq('user_id', member.user_id);
    if (err) setError(err.message);
  };

  return createPortal(
    <div className="sd-backdrop" onClick={onClose}>
      <div className="sd-dialog" onClick={(e) => e.stopPropagation()} role="dialog" aria-modal>
        <header className="sd-header">
          <div>
            <span className="sd-eyebrow">{resource.type === 'vault' ? 'Vault' : resource.type === 'folder' ? 'Folder' : 'Note'}</span>
            <h2 className="sd-title">Share &ldquo;{resource.name || 'Untitled'}&rdquo;</h2>
          </div>
          <button className="sd-close" onClick={onClose} aria-label="Close">×</button>
        </header>

        <nav className="sd-tabs" role="tablist">
          {TABS.filter((t) => t.id !== 'permissions' || isResourceLevel).map((t) => (
            <button
              key={t.id}
              role="tab"
              aria-selected={tab === t.id}
              className={`sd-tab${tab === t.id ? ' sd-tab--active' : ''}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>

        <div className="sd-body">
          {tab === 'people' && (
            <div className="sd-people">
              {isOwner && (
                <form className="sd-invite-form" onSubmit={inviteByEmail}>
                  <input
                    type="email"
                    placeholder="name@company.com"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    disabled={inviting}
                    required
                  />
                  <select
                    value={inviteRole}
                    onChange={(e) => setInviteRole(e.target.value)}
                    disabled={inviting}
                  >
                    <option value="viewer">Viewer</option>
                    <option value="editor">Editor</option>
                  </select>
                  <button type="submit" disabled={inviting || !inviteEmail.trim()}>
                    {inviting ? 'Inviting…' : 'Invite'}
                  </button>
                </form>
              )}

              <h3 className="sd-section">Members ({members.length})</h3>
              <div className="sd-members">
                {loading && <p className="sd-muted">Loading…</p>}
                {!loading && members.map((m) => (
                  <MemberRow
                    key={m.user_id}
                    member={m}
                    canManage={isOwner && m.user_id !== user?.id}
                    onRoleChange={(role) => updateRole(m, role)}
                    onRemove={() => removeMember(m)}
                  />
                ))}
              </div>

              {invites.filter((i) => i.status === 'pending' && i.email).length > 0 && (
                <>
                  <h3 className="sd-section">Pending email invites</h3>
                  <div className="sd-members">
                    {invites.filter((i) => i.status === 'pending' && i.email).map((inv) => (
                      <div className="sd-pending" key={inv.id}>
                        <span>{inv.email}</span>
                        <span className="sd-role-pill">{inv.role}</span>
                        {isOwner && (
                          <button
                            className="sd-link-btn"
                            onClick={async () => {
                              await supabase.from('vault_invites').update({ status: 'revoked' }).eq('id', inv.id);
                            }}
                          >
                            Revoke
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}

          {tab === 'link' && (
            <InviteByLink
              vaultId={vaultId}
              invites={invites}
              isOwner={isOwner}
              onError={setError}
              onInfo={setInfo}
            />
          )}

          {tab === 'permissions' && isResourceLevel && (
            <PermissionsTab
              resource={resource}
              members={members}
              isOwner={isOwner}
              onError={setError}
              onInfo={setInfo}
            />
          )}

          {error && <p className="sd-error">{error}</p>}
          {info && <p className="sd-info">{info}</p>}
        </div>
      </div>
    </div>,
    document.body,
  );
}
