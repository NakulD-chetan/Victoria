import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  const max = Math.max(...a), min = Math.min(...a);
  const bucketCount = Math.max(3, Math.ceil(n / 3));
  const range = (max - min + 1) / bucketCount;
  const bkts = Array.from({ length: bucketCount }, () => []);
  for (let i = 0; i < n; i++) {
    const bi = Math.min(Math.floor((a[i] - min) / range), bucketCount - 1);
    bkts[bi].push(a[i]);
    steps.push({ type: 'distribute', idx: i, bucket: bi, array: [...a], buckets: Object.fromEntries(bkts.map((b, k) => [`B${k}`, [...b]])) });
  }
  bkts.forEach((b, bi) => {
    b.sort((x, y) => x - y);
    steps.push({ type: 'sort-bucket', bucket: bi, buckets: Object.fromEntries(bkts.map((b2, k) => [`B${k}`, [...b2]])), array: [...a] });
  });
  let idx = 0;
  for (const b of bkts) for (const v of b) a[idx++] = v;
  steps.push({ type: 'collect', array: [...a] });
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 18) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function BucketSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements (bucket sort)` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'distribute') {
      colors[step.idx] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.array[step.idx]} → Bucket ${step.bucket}` });
    } else if (step.type === 'sort-bucket') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: `Sort bucket ${step.bucket}` });
    } else if (step.type === 'collect') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Collected from all buckets' });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
