import { spawn, execSync } from 'child_process';
import { join, dirname } from 'path';
import { existsSync, createWriteStream } from 'fs';
import { mkdir, writeFile, rm, chmod, rename } from 'fs/promises';
import { tmpdir } from 'os';
import { randomUUID } from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

function findBinary(name) {
  const localBin = join(__dirname, 'bin', process.platform === 'win32' ? `${name}.exe` : name);
  if (existsSync(localBin)) return localBin;
  try {
    const cmd = process.platform === 'win32' ? 'where' : 'which';
    const result = execSync(`${cmd} ${name}`, { encoding: 'utf-8', stdio: ['pipe', 'pipe', 'ignore'] }).trim();
    return result.split('\n')[0].trim();
  } catch {
    return null;
  }
}

const CLANGD_VERSION = '19.1.2';
const CLANGD_URLS = {
  win32: `https://github.com/clangd/clangd/releases/download/${CLANGD_VERSION}/clangd-windows-${CLANGD_VERSION}.zip`,
  linux: `https://github.com/clangd/clangd/releases/download/${CLANGD_VERSION}/clangd-linux-${CLANGD_VERSION}.zip`,
  darwin: `https://github.com/clangd/clangd/releases/download/${CLANGD_VERSION}/clangd-mac-${CLANGD_VERSION}.zip`,
};

let _downloadingClangd = null;
export async function ensureClangd() {
  if (findBinary('clangd')) return true;
  if (_downloadingClangd) return _downloadingClangd;
  _downloadingClangd = _doDownloadClangd();
  const result = await _downloadingClangd;
  _downloadingClangd = null;
  return result;
}

async function _doDownloadClangd() {
  const url = CLANGD_URLS[process.platform];
  if (!url) {
    console.log(`  [LSP] No clangd download available for ${process.platform}. Install LLVM manually.`);
    return false;
  }

  const binDir = join(__dirname, 'bin');
  await mkdir(binDir, { recursive: true });
  const targetBin = join(binDir, process.platform === 'win32' ? 'clangd.exe' : 'clangd');
  if (existsSync(targetBin)) return true;

  console.log(`  [LSP] Downloading clangd ${CLANGD_VERSION} for ${process.platform}...`);

  try {
    const AdmZip = (await import('adm-zip')).default;
    const res = await fetch(url, { redirect: 'follow' });
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);

    const arrayBuf = await res.arrayBuffer();
    const zip = new AdmZip(Buffer.from(arrayBuf));
    const entries = zip.getEntries();

    const clangdEntry = entries.find(e =>
      e.entryName.endsWith('clangd.exe') || (e.entryName.endsWith('/clangd') && !e.isDirectory)
    );
    if (!clangdEntry) throw new Error('clangd binary not found in zip');

    const data = clangdEntry.getData();
    await writeFile(targetBin, data);
    if (process.platform !== 'win32') await chmod(targetBin, 0o755);

    console.log(`  [LSP] clangd installed to ${targetBin}`);
    resetLspCache();
    return true;
  } catch (e) {
    console.error(`  [LSP] Failed to download clangd: ${e.message}`);
    console.log(`  [LSP] Please install LLVM manually: https://releases.llvm.org/download.html`);
    return false;
  }
}

let _systemIncludes = null;
function detectSystemIncludes() {
  if (_systemIncludes !== null) return _systemIncludes;
  _systemIncludes = [];
  try {
    const gpp = findBinary('g++');
    if (!gpp) return _systemIncludes;
    const cmd = process.platform === 'win32'
      ? `echo. | "${gpp}" -E -x c++ - -v 2>&1`
      : `echo "" | "${gpp}" -E -x c++ - -v 2>&1`;
    const output = execSync(cmd, { encoding: 'utf-8', shell: true, timeout: 10000 });
    let capturing = false;
    for (const line of output.split('\n')) {
      if (line.includes('#include <...> search starts here')) { capturing = true; continue; }
      if (line.includes('End of search list')) break;
      if (capturing) {
        const p = line.trim();
        if (p && existsSync(p)) _systemIncludes.push(p);
      }
    }
  } catch { /* ignore */ }
  return _systemIncludes;
}

const LSP_CONFIGS = {
  cpp: () => {
    const bin = findBinary('clangd');
    if (!bin) return null;
    return {
      command: bin,
      args: (() => {
        const a = [
          '--background-index',
          '--header-insertion=iwyu',
          '--completion-style=detailed',
          '--all-scopes-completion',
          '--clang-tidy',
          '--pch-storage=memory',
          '--log=info',
          '--offset-encoding=utf-16',
          '--function-arg-placeholders',
        ];
        const gpp = findBinary('g++');
        if (gpp) a.push(`--query-driver=${gpp}`);
        return a;
      })(),
    };
  },
  python: () => {
    const localBin = join(__dirname, 'node_modules', '.bin', process.platform === 'win32' ? 'pyright-langserver.cmd' : 'pyright-langserver');
    if (existsSync(localBin)) return { command: localBin, args: ['--stdio'] };
    const bin = findBinary('pyright-langserver');
    if (bin) return { command: bin, args: ['--stdio'] };
    const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
    return { command: npx, args: ['pyright-langserver', '--stdio'] };
  },
};

const lspAvailability = {};
export function resetLspCache() { for (const k of Object.keys(lspAvailability)) delete lspAvailability[k]; }
export function checkLspAvailable(language) {
  if (lspAvailability[language] !== undefined) return lspAvailability[language];
  const config = LSP_CONFIGS[language];
  if (!config) { lspAvailability[language] = false; return false; }
  const result = config();
  lspAvailability[language] = result !== null;
  return lspAvailability[language];
}

function frameLspMessage(json) {
  const body = JSON.stringify(json);
  const len = Buffer.byteLength(body, 'utf-8');
  return `Content-Length: ${len}\r\n\r\n${body}`;
}

function createLspParser(callback) {
  let buffer = Buffer.alloc(0);
  let contentLength = -1;

  return (chunk) => {
    const incoming = typeof chunk === 'string' ? Buffer.from(chunk, 'utf-8') : chunk;
    buffer = Buffer.concat([buffer, incoming]);

    while (true) {
      if (contentLength === -1) {
        const headerEnd = buffer.indexOf('\r\n\r\n');
        if (headerEnd === -1) break;
        const headers = buffer.slice(0, headerEnd).toString('utf-8');
        const match = headers.match(/Content-Length:\s*(\d+)/i);
        if (!match) {
          buffer = buffer.slice(headerEnd + 4);
          continue;
        }
        contentLength = parseInt(match[1], 10);
        buffer = buffer.slice(headerEnd + 4);
      }

      if (buffer.length < contentLength) break;

      const body = buffer.slice(0, contentLength).toString('utf-8');
      buffer = buffer.slice(contentLength);
      contentLength = -1;

      try {
        callback(JSON.parse(body));
      } catch { /* ignore malformed */ }
    }
  };
}

export async function createLspSession(language) {
  const configFn = LSP_CONFIGS[language];
  if (!configFn) return null;
  const config = configFn();
  if (!config) return null;

  const sessionId = randomUUID();
  const workDir = join(tmpdir(), `inkdrop-lsp-${sessionId}`);
  await mkdir(workDir, { recursive: true });

  const trackedFiles = new Set();

  if (language === 'cpp') {
    const includes = detectSystemIncludes();
    const addFlags = ['-std=c++17', '-Wall', '-Wno-unused-variable'];
    for (const inc of includes) {
      addFlags.push(`--include-directory=${inc}`);
    }
    const clangdConfig = [
      'CompileFlags:',
      '  Add:',
      ...addFlags.map(f => `    - ${f}`),
      '  Compiler: g++',
      'Index:',
      '  Background: Build',
      'Diagnostics:',
      '  UnusedIncludes: None',
      '  ClangTidy:',
      '    Remove: [modernize-*, readability-*]',
      '',
    ].join('\n');
    await writeFile(join(workDir, '.clangd'), clangdConfig, 'utf-8');
    await writeFile(join(workDir, 'compile_commands.json'), '[]', 'utf-8');
  }

  if (language === 'python') {
    const pyrightConfig = JSON.stringify({
      "typeCheckingMode": "basic",
      "reportMissingImports": "warning",
      "reportMissingModuleSource": "none",
      "pythonVersion": "3.12",
      "executionEnvironments": [{ "root": "." }],
    }, null, 2);
    await writeFile(join(workDir, 'pyrightconfig.json'), pyrightConfig, 'utf-8');
  }

  const needsShell = process.platform === 'win32' && config.command.endsWith('.cmd');
  let proc;
  try {
    proc = spawn(config.command, [...config.args], {
      cwd: workDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env },
      shell: needsShell,
    });
  } catch (err) {
    console.error(`  [LSP:${language}] Failed to spawn: ${err.message}`);
    try { await rm(workDir, { recursive: true, force: true }); } catch {}
    return null;
  }

  let messageCallback = null;
  let alive = true;

  proc.on('error', (err) => {
    console.error(`  [LSP:${language}] Process error: ${err.message}`);
    alive = false;
  });

  proc.on('exit', (code, signal) => {
    if (alive) {
      console.log(`  [LSP:${language}] Exited: code=${code}, signal=${signal}`);
      alive = false;
    }
  });

  const stdoutParser = createLspParser((msg) => {
    if (messageCallback) messageCallback(msg);
  });
  proc.stdout.on('data', stdoutParser);
  proc.stderr.setEncoding('utf-8');
  proc.stderr.on('data', (d) => {
    const trimmed = d.trim();
    if (trimmed && !trimmed.includes('Background indexing')) {
      console.log(`  [LSP:${language}:stderr]`, trimmed.slice(0, 200));
    }
  });

  return {
    sessionId,
    workDir,
    proc,
    get alive() { return alive; },

    onMessage(cb) { messageCallback = cb; },

    send(json) {
      if (!alive || proc.stdin.destroyed) return;
      try {
        proc.stdin.write(frameLspMessage(json));
      } catch { /* ignore */ }
    },

    mapFileName(filePath) {
      const clean = filePath.replace(/^\//, '');
      if (language === 'cpp' && !/\.(cpp|cc|cxx|c|h|hpp)$/i.test(clean)) {
        const base = clean.replace(/\.[^.]+$/, '') || clean;
        return base + '.cpp';
      }
      if (language === 'python' && !/\.py$/i.test(clean)) {
        const base = clean.replace(/\.[^.]+$/, '') || clean;
        return base + '.py';
      }
      return clean;
    },

    async syncFile(filePath, content) {
      const cleanPath = this.mapFileName(filePath);
      const fullPath = join(workDir, cleanPath);
      const dir = dirname(fullPath);
      await mkdir(dir, { recursive: true });
      await writeFile(fullPath, content, 'utf-8');

      if (language === 'cpp' && /\.(cpp|cc|cxx|c|h|hpp)$/i.test(cleanPath) && !trackedFiles.has(cleanPath)) {
        trackedFiles.add(cleanPath);
        const cmds = [...trackedFiles].map(f => ({
          directory: workDir.replace(/\\/g, '/'),
          command: `g++ -std=c++17 -Wall ${f}`,
          file: f,
        }));
        await writeFile(join(workDir, 'compile_commands.json'), JSON.stringify(cmds, null, 2), 'utf-8');
      }
    },

    async destroy() {
      alive = false;
      messageCallback = null;
      try { proc.kill('SIGTERM'); } catch {}
      setTimeout(() => { try { proc.kill('SIGKILL'); } catch {} }, 3000);
      setTimeout(async () => {
        try { await rm(workDir, { recursive: true, force: true }); } catch {}
      }, 5000);
    },
  };
}
