# Queue — Concept

---

## Core Idea (2 Lines)

**Queue processes the oldest element first — like people standing in line. BFS uses a queue to explore nodes level-by-level. Monotonic deque maintains elements in sorted order at both ends for O(n) sliding window max/min.**

---

## FIFO Intuition

```
ENQUEUE:  A → B → C → D
       ┌─────────────────────┐
FRONT → │ A │ B │ C │ D │ ← REAR
       └─────────────────────┘

DEQUEUE order: A → B → C → D  (same as enqueue order)

Key: First person in line gets served first. No cutting in line.
```

---

## Queue Variants


| Variant                  | Description                                    | Use Case                               |
| ------------------------ | ---------------------------------------------- | -------------------------------------- |
| **Regular Queue**        | FIFO, enqueue at rear, dequeue from front      | BFS, task scheduling                   |
| **Deque (Double-ended)** | Add/remove from both ends                      | Sliding window, BFS with bidirectional |
| **Circular Queue**       | Fixed size, wrap-around; O(1) space            | Buffers, bounded queues                |
| **Priority Queue**       | Highest priority first (separate topic — heap) | Dijkstra, merge k sorted               |


---

## BFS Connection — Queue is the Engine

```
BFS = Level-by-level exploration
Queue = Guarantees we process nodes in order of discovery

    1 (level 0)
   / \
  2   3 (level 1)
 / \   \
4   5   6 (level 2)

Queue: [1] → [2,3] → [3,4,5] → [4,5,6] → ...
Process: 1, 2, 3, 4, 5, 6 (level order)
```

**Why queue for BFS?**

- First discovered = first explored = level order
- DFS uses stack (LIFO) = goes deep first
- BFS uses queue (FIFO) = goes wide first

---

## Monotonic Deque for Sliding Window Max/Min

**Problem:** For each window of size k, find max (or min) in O(n) total.

**Brute force:** O(n·k) — for each window, scan k elements.

**Monotonic deque:** O(n) — each element enters and exits deque at most once.

### Sliding Window Maximum — Monotonic Decreasing Deque

```
Array:  [1, 3, -1, -3, 5, 3, 6, 7]   k=3
Window: [1,3,-1] → max=3
        [3,-1,-3] → max=3
        [-1,-3,5] → max=5
        ...

Deque stores INDICES in decreasing value order (front = max of current window)
When arr[i] arrives: pop from back while arr[back] < arr[i] (they can never be max)
Front = max of current window (if still in window)
```

```
Deque invariant: indices in deque, values strictly decreasing (front → back)
Front = max of elements in current window
```

### Sliding Window Minimum — Monotonic Increasing Deque

```
Same logic, but: pop from back while arr[back] > arr[i]
Deque: values strictly increasing (front → back)
Front = min of current window
```

---

## When NOT to Use Queue


| Scenario                             | Why Not                      | Use Instead           |
| ------------------------------------ | ---------------------------- | --------------------- |
| Need LIFO (most recent first)        | Queue is FIFO                | Stack                 |
| Need priority ordering               | Queue is arrival order       | Priority Queue (Heap) |
| Need random access / middle          | Queue only has front/back    | Array, Deque          |
| "Next greater element" (single pass) | Queue doesn't maintain order | Monotonic Stack       |
| Sliding window max/min (naive)       | O(n·k) with simple queue     | Monotonic Deque       |
| Recursion / backtracking             | DFS pattern                  | Stack                 |
| Need sorted traversal                | Queue has no order           | Heap, Sorted Set      |


---

## Golden Rules

1. **"Level order" / "BFS" → queue** (FAANG #1 queue pattern)
2. **"Shortest path in unweighted graph" → BFS + queue**
3. **"Sliding window max/min" → monotonic deque** (O(n))
4. **Deque stores indices** for sliding window (to check if still in window)
5. **Monotonic decreasing → max; Monotonic increasing → min**
6. **BFS always track visited** — avoid infinite loops on cycles
7. **Level-by-level BFS** — process queue size at each level

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Queue (FIFO)
WHEN TO USE:        BFS, level order, shortest path (unweighted), sliding window max/min
CORE IDEA:          Process oldest first; BFS = queue; monotonic deque = O(n) window
BFS RULE:           Queue + visited set; level = process current queue size
MONOTONIC DEQUE:    Decreasing → max | Increasing → min | Store indices
TIME:               BFS O(V+E); Monotonic deque O(n)
INTERVIEW LINE:     "BFS uses a queue because we process nodes in order of discovery.
                     For sliding window max, I'll use a monotonic decreasing deque."
```

