# How Slack Works - System Design

> Source: https://systemdesign.one/slack-architecture/

## One-Line Summary
Slack is an enterprise messaging platform that uses WebSocket for real-time delivery, HTTP POST for sending messages, workspace snapshots for initial load, and channel-based fan-out with Kafka for reliable messaging at scale.

## Key Requirements

### Functional
- Real-time 1:1 and group (channel) messaging
- Channels with up to 10,000 users
- Workspaces with up to 200,000 users
- Typing indicators in real-time
- Online presence status
- Media file sharing
- Persistent chat history in chronological order
- Message received at-most-once (no duplicates)

### Non-Functional
- High availability and reliability
- Low latency for message delivery
- Support 7 million simultaneously connected users
- 10 million DAU, 10:1 read-write ratio
- Support mobile, desktop, and web clients
- Globally distributed user base

## High-Level Architecture

```
Slack Client (Web/Desktop/Mobile)
      |
      ├── HTTP POST (Web API) → Send messages, create channels, login
      |
      └── WebSocket (Real-Time API) → Receive messages, typing indicators, presence
              |
         Load Balancer
              |
         Gateway Service
              |
    +----+----+----+----+
    |    |    |    |    |
  Chat  Channel  Presence  Notification
 Service Service  Service   Service
    |    |    |
  Kafka Message Queue
    |
  Message Storage
    |
  MySQL (sharded by workspace)
```

## Core Components Deep Dive

### 1. Dual API Architecture
- **Web API (HTTP)**: Used for sending messages, creating channels, login, fetching history
  - Client sends `POST /chat/:channel-id` with message body
  - Server returns 200 OK with timestamp
- **Real-Time API (WebSocket)**: Used for receiving messages, typing indicators, presence
  - Persistent connection for push-based delivery
  - Dedicated endpoints for different services (typing, presence) for failure isolation

### 2. Initial Login & Workspace Snapshot
- On login, server sends a **snapshot** of the entire workspace
- Snapshot includes: user list, channels, profiles, memberships
- Also includes WebSocket URL for real-time connection
- **Lazy loading**: fetch snapshot partially to improve startup latency

### 3. Message Flow
```
Sending:
1. Client → HTTP POST → Web API → Chat Service
2. Chat Service → Kafka (message queue)
3. Chat Service → ACK back to sender

Delivery:
4. Kafka → Delivery Service
5. Delivery Service → find all channel members
6. For each online member: push via their WebSocket connection
7. For offline members: queue + push notification
```

### 4. Channel Fan-Out
- When message sent to channel with 10,000 users:
  - Delivery service identifies all online members
  - Pushes message through each member's WebSocket
  - For large channels, fan-out is the main scaling challenge
- **Optimization**: batch delivery, limit typing indicator broadcasts to smaller channels

### 5. Typing Indicators
- Sent via WebSocket real-time API
- `{ user: 42, type: "typing", channel: "FB23AVK456" }`
- Only broadcast to users currently viewing that channel
- NOT persisted -- transient event only

### 6. Presence Service
- Tracks online/offline/away status
- Uses heartbeat mechanism
- Separate service from chat for failure isolation
- Updates broadcast to relevant users (not all users globally)

### 7. Data Storage
- **MySQL** for messages (sharded by workspace/organization)
- Each workspace = separate shard → natural data isolation
- Messages ordered by timestamp within channels
- **File storage**: media uploaded to blob storage, referenced by URL

### 8. Search
- Full-text search across all messages in workspace
- Elasticsearch or similar search engine
- Index updated asynchronously as messages flow through Kafka

## Key Design Decisions

| Decision | Why |
|----------|-----|
| HTTP for sends, WebSocket for receives | Sends are request-response; receives need push |
| Shard by workspace | Natural tenant isolation, enterprise use case |
| Kafka for message queue | Reliable delivery, fan-out support, replay |
| Workspace snapshot on login | Fast initial load without multiple API calls |
| Separate presence service | Failure isolation from chat |
| Lazy loading | Faster perceived startup time |
| Channel-based fan-out | Natural messaging model for team communication |

## Slack vs WhatsApp

| Aspect | Slack | WhatsApp |
|--------|-------|----------|
| Model | Workspace + Channels | Phone number + contacts |
| Group size | Up to 10,000 | Up to 100 |
| Message send | HTTP POST | WebSocket |
| Message receive | WebSocket | WebSocket |
| Storage | Persistent (MySQL) | Minimal server storage |
| Primary DB | MySQL (sharded by workspace) | Cassandra |
| Target | Enterprise teams | Personal messaging |
| Search | Full-text (Elasticsearch) | Local device search |

## Scaling Strategies

1. **Shard MySQL by workspace**: each organization is a natural partition
2. **Kafka** for reliable message delivery and fan-out
3. **WebSocket connection pools**: distribute across many servers
4. **Lazy loading** workspace snapshots for fast startup
5. **Separate services** for chat, presence, typing, notifications (failure isolation)
6. **CDN** for media/file delivery
7. **Elasticsearch** cluster for search scaling

## Interview Tips

- Highlight the **dual API design**: HTTP for writes, WebSocket for real-time pushes
- Explain **workspace snapshot** -- it's unique to Slack's design
- Compare Slack with WhatsApp to show breadth (enterprise vs personal)
- Discuss **channel fan-out problem**: 10,000-member channels are the scaling challenge
- Know the **sharding strategy**: shard by workspace (natural tenant isolation)
- Mention **typing indicators** are transient (not persisted)
- Talk about search: async indexing via Kafka into Elasticsearch

## Quick Revision (5 bullet points)

1. **Dual API**: HTTP POST for sending messages, WebSocket for receiving messages + typing indicators + presence
2. **Workspace snapshot** sent on login with lazy loading for fast startup; includes WebSocket URL for real-time connection
3. **Sharded by workspace** (MySQL) for natural tenant isolation; Kafka queue for reliable fan-out delivery
4. **Channel fan-out** is the main scaling challenge -- large channels (10K users) need batched delivery
5. **Separate services** for chat, presence, typing, notifications ensure failure isolation and independent scaling
