# API Design — Tricks and Recognition

> **Permanent Recall:** API selection shortcuts: public API → REST, mobile app with varied data needs → GraphQL, internal microservices → gRPC, real-time → WebSocket/SSE. Quick REST URL patterns: plural nouns, no verbs, hierarchical. Common status code mappings: 200/201/204, 400/401/403/404/429, 500/502/503. Use these triggers to choose and design APIs fast in interviews.

---

## API Selection Shortcuts

| Scenario | Use | Why |
|----------|-----|-----|
| **Public API** | REST | Caching, simple, well-understood |
| **Mobile app, varied screens** | GraphQL | Each screen needs different fields, fewer round-trips |
| **Internal microservices** | gRPC | Binary, HTTP/2, low latency |
| **Real-time (chat, live feed)** | WebSocket, SSE | Push from server |
| **Third-party integrations** | REST + OAuth | Standard, interoperable |
| **BFF for multiple clients** | GraphQL | One backend, flexible queries |

> **FAANG Tip:** "Public → REST. Mobile with over-fetch pain → GraphQL. Internal high-throughput → gRPC."

---

## Quick REST URL Patterns

```
    Collection:      GET    /users
    Single:          GET    /users/{id}
    Create:          POST   /users
    Replace:         PUT    /users/{id}
    Update:          PATCH  /users/{id}
    Delete:          DELETE /users/{id}
    Nested:          GET    /users/{id}/orders
    Sub-resource:    POST   /users/{id}/orders
```

**Rules:**
- Plural nouns: `/users` not `/user`
- No verbs: `/users` not `/getUsers`
- IDs in path: `/users/123` not `/users?id=123`
- Hierarchical: `/users/123/orders` for user's orders

---

## Common Status Code Mappings

| Situation | Code | When |
|-----------|------|------|
| Success, body | 200 OK | GET, PATCH, PUT |
| Created | 201 Created | POST, include `Location` |
| Success, no body | 204 No Content | DELETE, sometimes PUT |
| Bad request | 400 Bad Request | Validation, malformed |
| Unauthenticated | 401 Unauthorized | Missing/invalid auth |
| Forbidden | 403 Forbidden | Auth OK, no permission |
| Not found | 404 Not Found | Resource doesn't exist |
| Rate limited | 429 Too Many Requests | Over limit |
| Server error | 500 Internal Server Error | Unexpected failure |
| Bad gateway | 502 Bad Gateway | Upstream error |
| Unavailable | 503 Service Unavailable | Overloaded, maintenance |

---

## Authentication Quick Guide

| Context | Use |
|---------|-----|
| Machine-to-machine, internal | API key |
| Third-party, user consent | OAuth 2.0 |
| Mobile/web, stateless | JWT |
| High security | OAuth + short-lived JWT + refresh |

---

## Pagination Quick Guide

| Need | Use |
|------|-----|
| Simple, small datasets | Offset (`?page=2&limit=20`) |
| Large lists, scalable | Cursor (`?cursor=xyz&limit=20`) |
| Sorted, efficient | Keyset (`?after_id=123&limit=20`) |

---

## Rate Limiting Quick Guide

| Algorithm | When |
|-----------|------|
| **Token bucket** | Allow bursts, simple |
| **Leaky bucket** | Smooth traffic, fixed output rate |
| **Sliding window** | Strict fairness |

---

## Versioning Quick Guide

| Preference | Use |
|------------|-----|
| Visible, simple | URL `/v1/users` |
| Clean URLs | Header `Accept-Version: 2` |
| Quick add | Query `?version=2` |

---

## Recognition: Interview Triggers

When interviewer says:

| Phrase | Think |
|--------|-------|
| "Design a public API" | REST, versioning, rate limit, auth |
| "Mobile app, many screens" | GraphQL |
| "Microservices talking" | gRPC |
| "Handle retries" | Idempotency-Key |
| "Scale to millions" | Cursor pagination, rate limit |
| "Third-party access" | OAuth 2.0 |

---

## Interview One-Liners

| Topic | One-liner |
|-------|-----------|
| **REST vs GraphQL** | "REST for public, caching. GraphQL when client needs vary." |
| **gRPC** | "gRPC for internal services—binary, HTTP/2, streaming." |
| **Versioning** | "Version from day one—URL /v1/ or header." |
| **Rate limiting** | "Token bucket per user, 429 with Retry-After." |
| **Pagination** | "Cursor-based for scale; offset for simple." |
| **Auth** | "OAuth for third-party; JWT for stateless; API key for simple." |
| **Idempotency** | "Idempotency-Key for POST to handle retries." |

---

## Anti-Patterns (When NOT to Use)

| Don't | Why |
|-------|-----|
| GraphQL for simple CRUD | Overkill; REST is simpler |
| gRPC for public browser API | Need gRPC-Web or REST gateway |
| No versioning | Will break clients |
| Verbs in URL | Not RESTful |
| GET for mutations | Caching, crawlers can trigger |

---

## 30-SECOND REVISION BOX

```
PUBLIC → REST | MOBILE VARIED → GraphQL | INTERNAL → gRPC
URL: Plural nouns, no verbs, hierarchical
STATUS: 200/201/204, 400/401/403/404/429, 500/502/503
AUTH: API key / OAuth / JWT by context
PAGINATION: Offset / cursor / keyset
VERSION: /v1/ or header
IDEMPOTENCY: Key for POST
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
