# How Kafka Works - System Design

> Source: https://newsletter.systemdesign.one/p/how-kafka-works

## One-Line Summary
Apache Kafka is a distributed, fault-tolerant pub/sub messaging system that acts as a central hub for moving data between services in real time.

## Key Requirements

### Functional
- Producers write messages to topics
- Consumers read messages from topics in order
- Messages are organized into topics (like database tables)
- Topics are split into partitions for parallel processing
- Support for exactly-once message delivery
- Stream processing (real-time computations on data)
- Integration with external systems (databases, data warehouses)

### Non-Functional
- High throughput (can handle GBs/second of writes)
- Low latency message delivery
- Durable storage (messages persist on disk for days/weeks)
- Fault tolerance (survives node failures)
- Horizontal scalability (add more nodes = more capacity)
- Data replay capability (re-read old messages)

## High-Level Architecture

```
Producers  -->  [Kafka Cluster]  -->  Consumers
                    |
          Broker 1 | Broker 2 | Broker 3
          (each holds partitions of topics)
                    |
              Controller Quorum
          (manages cluster metadata)
```

**How data flows:**
1. **Producers** send messages to a specific **topic**
2. Kafka stores the message in a **partition** (shard) of that topic
3. The message gets **replicated** across multiple brokers (default: 3 copies)
4. **Consumers** read messages from partitions in order
5. Multiple consumer groups can read the same data independently

## Core Components Deep Dive

### 1. The Log Data Structure
- Kafka's foundation is an **append-only log**
- New records are added at the end only (no updates, no deletes)
- Each record has a unique **offset** number (like an auto-increment ID)
- Sequential disk reads/writes = very fast on HDDs
- API is dead simple: `append(record)` and `read(offset)`

### 2. Topics & Partitions
- **Topic** = a category of messages (like a database table)
- **Partition** = a shard of a topic (for parallelism)
- Each partition is its own separate log
- A topic can have dozens of partitions across different brokers
- Messages within a partition are ordered; across partitions, no global order

### 3. Brokers
- A **broker** = one Kafka server node
- A typical cluster has 3+ brokers
- Each broker hosts some partitions
- Brokers are spread across availability zones for disaster recovery

### 4. Replication & Leaders
- Every partition has **3 replicas** (configurable) on different brokers
- One replica is the **Leader** (handles all writes)
- Other replicas are **Followers** (copy data from leader)
- If leader dies, a follower gets promoted automatically
- This gives fault tolerance -- one node dying = no data loss

### 5. Controllers & KRaft
- **Controllers** = special brokers that manage cluster metadata
- They track which broker leads which partition
- Use **KRaft** (Kafka Raft) consensus algorithm for leader election
- Cluster metadata stored in a special topic: `__cluster_metadata`
- All brokers subscribe to this topic to know the latest cluster state

### 6. Consumer Groups
- A **consumer group** = set of consumers working as a team
- Partitions are split among consumers in the group
- Each partition is read by only ONE consumer in a group (ensures order)
- Different groups read independently (great for fan-out use cases)
- Scale reads by adding more consumers or more groups

### 7. Kafka Streams
- Client-side Java library for real-time stream processing
- Reads from input topic -> processes -> writes to output topic
- Supports: map, filter, joins, windowed aggregations
- Exactly-once processing guarantee when reads/writes are Kafka-only

### 8. Kafka Connect
- Framework for connecting Kafka with external systems
- **Source Connectors**: pull data INTO Kafka (e.g., from MongoDB)
- **Sink Connectors**: push data OUT of Kafka (e.g., to Snowflake)
- Hundreds of ready-made connector plugins available

### 9. Schema Registry
- External service that stores message schemas
- Producers register schema, consumers download it
- Enables type safety (Kafka messages are raw bytes by default)
- Common formats: Avro, Protobuf, JSON Schema

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Append-only log | O(1) writes, lock-free, sequential disk I/O = fast |
| Single-leader replication | Simpler consistency, leader handles writes |
| KRaft (not ZooKeeper) | Removed external dependency, simpler operations |
| Topics + Partitions | Horizontal scaling of both writes and reads |
| Consumer groups | Fan-out reads without duplicating data |
| Tiered Storage (S3) | 10x cheaper storage for old data, brokers stay lean |
| Custom TCP protocol | More efficient than HTTP for streaming |

## Data Model

```
Record (Message):
  - key: byte[]      (optional, used for partitioning)
  - value: byte[]    (the actual message content)
  - offset: long     (unique position in partition)
  - timestamp: long
  - headers: Map     (custom metadata)

Topic:
  - name: string
  - partitions: int
  - replication_factor: int
  - retention_period: duration (default 7 days)
```

## Scaling Strategies

1. **More Brokers** = more partitions = more parallel throughput
2. **Tiered Storage**: hot data on broker SSDs, cold data offloaded to S3 (saves 10x cost)
3. **Consumer Groups**: add consumers to handle higher read volume
4. **Partition count tuning**: more partitions = more parallelism (but more overhead)
5. **Cross-AZ replication**: spread brokers across availability zones

## Interview Tips

- Start by explaining the **problem Kafka solves**: decoupling producers from consumers, avoiding N^2 point-to-point integrations
- Draw the log data structure first -- it's the foundation of everything
- Mention **replication factor of 3** and leader-follower model
- Know the difference between **consumer groups** (parallel processing) and **multiple groups** (fan-out)
- Mention **exactly-once semantics** via transactions
- If asked about alternatives: RabbitMQ (traditional queue), Pulsar, RedPanda

## Quick Revision (5 bullet points)

1. **Kafka = distributed append-only log** that decouples data producers from consumers via topics and partitions
2. **Replication factor of 3** with single-leader model ensures fault tolerance; KRaft handles consensus
3. **Consumer groups** split partitions among members for parallel reads; different groups read independently
4. **Tiered storage** offloads old data to S3, reducing broker storage costs by 10x
5. **Kafka ecosystem** includes Streams (real-time processing), Connect (integrations), and Schema Registry (type safety)
