import { useState, useEffect, useRef, useCallback, memo, useMemo } from 'react';
import { marked } from 'marked';
import hljs from 'highlight.js';
import mermaid from 'mermaid';
import 'highlight.js/styles/github-dark.min.css';

mermaid.initialize({ startOnLoad: false, theme: 'dark', securityLevel: 'loose' });

const LANG_MAP = { js: 'javascript', py: 'python', ts: 'javascript', jsx: 'javascript', tsx: 'javascript' };
const EXEC_LANGS = new Set(['javascript', 'python', 'cpp', 'java']);
const PAGE_SIZE = 6;

function CodeBlock({ code, lang, shareId }) {
  const [output, setOutput] = useState(null);
  const [running, setRunning] = useState(false);
  const [copied, setCopied] = useState(false);
  const execLang = LANG_MAP[lang] || lang;
  const canRun = EXEC_LANGS.has(execLang);

  const run = useCallback(async () => {
    setRunning(true); setOutput(null);
    try {
      const res = await fetch(`/api/notes/shared/${shareId}/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code: code, language: execLang }),
      });
      const data = await res.json();
      if (data.error) setOutput({ type: 'error', text: data.error });
      else if (data.compile_output && !data.stdout) setOutput({ type: 'error', text: data.compile_output });
      else setOutput({ type: 'ok', text: (data.stdout || '') + (data.stderr ? '\n' + data.stderr : '') });
    } catch (e) { setOutput({ type: 'error', text: e.message }); }
    finally { setRunning(false); }
  }, [code, execLang, shareId]);

  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const highlighted = lang && hljs.getLanguage(lang)
    ? hljs.highlight(code, { language: lang }).value
    : hljs.highlightAuto(code).value;

  return (
    <div className="sn-codeblock">
      <div className="sn-codeblock__header">
        <span className="sn-codeblock__lang">{lang || 'code'}</span>
        <div className="sn-codeblock__actions">
          <button
            className={`sn-codeblock__btn sn-codeblock__btn--icon${copied ? ' sn-codeblock__btn--success' : ''}`}
            onClick={copy}
            title={copied ? 'Copied' : 'Copy code'}
            aria-label={copied ? 'Copied' : 'Copy code'}
          >
            {copied ? (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
            ) : (
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="9" y="9" width="10" height="10" rx="2" />
                <path d="M15 9V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" />
              </svg>
            )}
          </button>
          {canRun && (
            <button className="sn-codeblock__btn sn-codeblock__btn--run" onClick={run} disabled={running} title="Run code">
              <span className="sn-codeblock__btn-icon">{running ? '\u27F3' : '\u25B6'}</span>
              <span>{running ? 'Running' : 'Run'}</span>
            </button>
          )}
        </div>
      </div>
      <pre><code dangerouslySetInnerHTML={{ __html: highlighted }} /></pre>
      {output && (
        <div className={`sn-codeblock__output ${output.type === 'error' ? 'sn-codeblock__output--error' : ''}`}>
          <div className="sn-codeblock__output-header">{output.type === 'error' ? 'Error' : 'Output'}</div>
          <pre>{output.text || '(no output)'}</pre>
        </div>
      )}
    </div>
  );
}

function MermaidBlock({ code }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    const id = `mermaid-${Math.random().toString(36).slice(2, 8)}`;
    mermaid.render(id, code).then(({ svg }) => {
      if (ref.current) ref.current.innerHTML = svg;
    }).catch(() => {
      if (ref.current) ref.current.innerHTML = `<pre class="sn-mermaid-err">Mermaid syntax error</pre>`;
    });
  }, [code]);
  return <div ref={ref} className="sn-mermaid" />;
}

const CODE_PLACEHOLDER = '<!--CODE_BLOCK_';
const CODE_PLACEHOLDER_END = '-->';

function buildRenderedSections(body, shareId) {
  if (!body) return [];

  const codeBlocks = [];
  let index = 0;

  const renderer = new marked.Renderer();
  renderer.code = function ({ text, lang }) {
    const id = index++;
    codeBlocks.push({ id, code: text, lang: lang || '' });
    return `${CODE_PLACEHOLDER}${id}${CODE_PLACEHOLDER_END}`;
  };

  renderer.table = function ({ header, body }) {
    return `<div class="sn-table-wrapper"><table><thead>${header}</thead><tbody>${body}</tbody></table></div>`;
  };

  const html = marked.parse(body, { gfm: true, breaks: true, renderer });
  const parts = html.split(new RegExp(`${CODE_PLACEHOLDER}(\\d+)${CODE_PLACEHOLDER_END}`));

  const sections = [];
  for (let i = 0; i < parts.length; i++) {
    if (i % 2 === 0) {
      const prose = parts[i].trim();
      if (prose) {
        sections.push({ type: 'html', html: prose });
      }
    } else {
      const block = codeBlocks[parseInt(parts[i], 10)];
      if (block) {
        if (block.lang === 'mermaid') {
          sections.push({ type: 'mermaid', code: block.code });
        } else {
          sections.push({ type: 'code', code: block.code, lang: block.lang, shareId });
        }
      }
    }
  }
  return sections;
}

function estimateReadTime(text) {
  if (!text) return 1;
  return Math.max(1, Math.round(text.trim().split(/\s+/).length / 200));
}

/* ── SVG Icons (minimal set) ─────────────────────────────────── */
const SunIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
);
const MoonIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
);
const ThumbUpIcon = ({ filled }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3H14zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
);
const ShareIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
);
const MessageIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
);
const SendIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
);
const ChevronDownIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="6 9 12 15 18 9"/></svg>
);
const ChevronUpIcon = () => (
  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><polyline points="18 15 12 9 6 15"/></svg>
);

/* ── InkDrop Logo (droplet) for branding ─────────────────────── */
const InkDropLogo = ({ size = 20 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
    <path
      d="M16 3C16 3 6 15 6 21a10 10 0 0020 0C26 15 16 3 16 3z"
      fill="url(#inkdrop-grad)"
      stroke="none"
    />
    <ellipse cx="13" cy="19" rx="2.5" ry="3" fill="rgba(255,255,255,0.25)" />
    <defs>
      <linearGradient id="inkdrop-grad" x1="6" y1="3" x2="26" y2="31" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#818cf8" />
        <stop offset="100%" stopColor="#6366f1" />
      </linearGradient>
    </defs>
  </svg>
);

/* ── InkDrop Loading Screen ──────────────────────────────────── */
function InkDropLoader() {
  return (
    <div className="sn-loading">
      <div className="sn-loading__scene">
        <div className="sn-loading__drop">
          <svg width="24" height="32" viewBox="0 0 24 32" fill="none">
            <path d="M12 0C12 0 0 14 0 20a12 12 0 0024 0C24 14 12 0 12 0z" fill="url(#ld-grad)" />
            <ellipse cx="8" cy="18" rx="2" ry="2.5" fill="rgba(255,255,255,0.3)" />
            <defs>
              <linearGradient id="ld-grad" x1="0" y1="0" x2="24" y2="32" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#a5b4fc" />
                <stop offset="100%" stopColor="#6366f1" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div className="sn-loading__ripple-wrap">
          <div className="sn-loading__ripple" />
          <div className="sn-loading__ripple sn-loading__ripple--2" />
          <div className="sn-loading__ripple sn-loading__ripple--3" />
        </div>
      </div>
      <span className="sn-loading__brand">InkDrop</span>
    </div>
  );
}

function SectionRenderer({ section }) {
  if (section.type === 'mermaid') return <MermaidBlock code={section.code} />;
  if (section.type === 'code') return <CodeBlock code={section.code} lang={section.lang} shareId={section.shareId} />;
  return <div className="sn-prose" dangerouslySetInnerHTML={{ __html: section.html }} />;
}

function PaginatedContent({ sections }) {
  const [page, setPage] = useState(1);
  const sentinelRef = useRef(null);
  const total = sections.length;
  const shown = Math.min(page * PAGE_SIZE, total);
  const hasMore = shown < total;

  useEffect(() => {
    if (!hasMore || !sentinelRef.current) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setPage((p) => p + 1);
      },
      { rootMargin: '200px' },
    );
    obs.observe(sentinelRef.current);
    return () => obs.disconnect();
  }, [hasMore, page]);

  return (
    <>
      {sections.slice(0, shown).map((sec, i) => (
        <div key={i} className="sn-section" style={{ animationDelay: `${Math.min(i * 30, 150)}ms` }}>
          <SectionRenderer section={sec} />
        </div>
      ))}
      {hasMore && (
        <div className="sn-load-more">
          <div ref={sentinelRef} className="sn-load-more__sentinel" />
        </div>
      )}
    </>
  );
}

/* ── Time formatting ─────────────────────────────────────────── */
function formatTime(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

/* ── Comments ────────────────────────────────────────────────── */
function SingleComment({ c, onLike, onReply, isReply }) {
  return (
    <div className={`sn-comment ${isReply ? 'sn-comment--reply' : ''}`}>
      <div className="sn-comment__avatar">{c.name.charAt(0).toUpperCase()}</div>
      <div className="sn-comment__body">
        <div className="sn-comment__header">
          <span className="sn-comment__name">{c.name}</span>
          <span className="sn-comment__time">{formatTime(c.time)}</span>
        </div>
        <p className="sn-comment__text">
          {c.replyToName && <span className="sn-comment__mention">@{c.replyToName}</span>}
          {c.text}
        </p>
        <div className="sn-comment__actions">
          <button className="sn-comment__action-btn" onClick={() => onLike(c.id)}>
            <ThumbUpIcon filled={false} />
            {c.likes > 0 && <span>{c.likes}</span>}
          </button>
          <button className="sn-comment__action-btn" onClick={() => onReply(c)}>Reply</button>
        </div>
      </div>
    </div>
  );
}

function CommentThread({ parent, replies, onLike, onReply }) {
  const [expanded, setExpanded] = useState(false);
  const replyCount = replies.length;
  return (
    <div className="sn-thread">
      <SingleComment c={parent} onLike={onLike} onReply={onReply} isReply={false} />
      {replyCount > 0 && (
        <div className="sn-thread__replies-section">
          <button className="sn-thread__toggle" onClick={() => setExpanded(!expanded)}>
            {expanded ? <ChevronUpIcon /> : <ChevronDownIcon />}
            <span>{expanded ? 'Hide' : 'View'} {replyCount} {replyCount === 1 ? 'reply' : 'replies'}</span>
          </button>
          {expanded && (
            <div className="sn-thread__replies">
              {replies.map((r) => <SingleComment key={r.id} c={r} onLike={onLike} onReply={onReply} isReply />)}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function CommentsSection({ shareId }) {
  const STORAGE_KEY = `sn-comments-${shareId}`;
  const [comments, setComments] = useState(() => {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; } catch { return []; }
  });
  const [name, setName] = useState(() => localStorage.getItem('sn-commenter-name') || '');
  const [text, setText] = useState('');
  const [replyCtx, setReplyCtx] = useState(null);
  const replyInputRef = useRef(null);

  useEffect(() => { localStorage.setItem(STORAGE_KEY, JSON.stringify(comments)); }, [comments, STORAGE_KEY]);

  const resolveTopParent = (commentId) => {
    const c = comments.find((x) => x.id === commentId);
    if (!c || !c.parentId) return commentId;
    return c.parentId;
  };

  const addComment = (parentId, mentionName) => {
    if (!text.trim()) return;
    const commenterName = name.trim() || 'Anonymous';
    localStorage.setItem('sn-commenter-name', commenterName);
    setComments((prev) => [...prev, {
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      name: commenterName, text: text.trim(), time: new Date().toISOString(),
      likes: 0, parentId: parentId || null, replyToName: mentionName || null,
    }]);
    setText(''); setReplyCtx(null);
  };

  const likeComment = useCallback((id) => {
    setComments((prev) => prev.map((c) => c.id === id ? { ...c, likes: c.likes + 1 } : c));
  }, []);

  const handleReply = useCallback((comment) => {
    const topParent = resolveTopParent(comment.id);
    setReplyCtx({ parentId: topParent, mentionName: comment.name });
    setText('');
    setTimeout(() => replyInputRef.current?.focus(), 50);
  }, [comments]);

  const cancelReply = () => { setReplyCtx(null); setText(''); };
  const topLevel = comments.filter((c) => !c.parentId);
  const getReplies = (parentId) => comments.filter((c) => c.parentId === parentId);

  return (
    <section className="sn-comments">
      <div className="sn-comments__header">
        <MessageIcon />
        <h3>{comments.length} {comments.length === 1 ? 'Comment' : 'Comments'}</h3>
      </div>

      <div className="sn-comments__form">
        <div className="sn-comments__form-row">
          <div className="sn-comment__avatar sn-comment__avatar--you">{(name.trim() || 'Y').charAt(0).toUpperCase()}</div>
          <div className="sn-comments__form-fields">
            <input className="sn-comment__input sn-comment__input--name" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
            <div className="sn-comments__input-row">
              <input
                className="sn-comment__input"
                placeholder="Add a comment..."
                value={!replyCtx ? text : ''}
                onChange={(e) => { if (!replyCtx) setText(e.target.value); }}
                onFocus={() => setReplyCtx(null)}
                onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey && !replyCtx) { e.preventDefault(); addComment(null, null); } }}
              />
              <button className="sn-comment__send" onClick={() => { if (!replyCtx) addComment(null, null); }} title="Post"><SendIcon /></button>
            </div>
          </div>
        </div>
      </div>

      {replyCtx && (
        <div className="sn-comments__reply-banner">
          <span>Replying to <strong>@{replyCtx.mentionName}</strong></span>
          <div className="sn-comments__reply-banner-input">
            <input ref={replyInputRef} className="sn-comment__input" placeholder={`Reply to @${replyCtx.mentionName}...`} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addComment(replyCtx.parentId, replyCtx.mentionName); } if (e.key === 'Escape') cancelReply(); }} autoFocus />
            <button className="sn-comment__send" onClick={() => addComment(replyCtx.parentId, replyCtx.mentionName)}><SendIcon /></button>
          </div>
          <button className="sn-comments__reply-cancel" onClick={cancelReply}>Cancel</button>
        </div>
      )}

      <div className="sn-comments__list">
        {topLevel.length === 0 && <p className="sn-comments__empty">No comments yet. Be the first to share your thoughts!</p>}
        {topLevel.map((c) => <CommentThread key={c.id} parent={c} replies={getReplies(c.id)} onLike={likeComment} onReply={handleReply} />)}
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════
   Main View — Clean, Paginated, Optimised
   ═══════════════════════════════════════════════════════════════ */
const SharedNoteView = memo(function SharedNoteView({ shareId }) {
  const [note, setNote] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState('dark');
  const [linkCopied, setLinkCopied] = useState(false);

  const sections = useMemo(() => {
    if (!note?.body) return [];
    return buildRenderedSections(note.body, shareId);
  }, [note?.body, shareId]);

  useEffect(() => {
    document.body.classList.add('sn-body-unlock');
    document.documentElement.classList.add('sn-html-unlock');
    return () => {
      document.body.classList.remove('sn-body-unlock');
      document.documentElement.classList.remove('sn-html-unlock');
    };
  }, []);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(`/api/notes/shared/${shareId}`);
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          setError(data.error || `Error ${res.status}`);
          return;
        }
        setNote(await res.json());
      } catch (e) { setError(e.message); }
      finally { setLoading(false); }
    }
    load();
  }, [shareId]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  if (loading) return (
    <div className="sn-page sn-page--dark">
      <InkDropLoader />
    </div>
  );

  if (error) return (
    <div className="sn-page sn-page--dark">
      <div className="sn-error">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="1.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <h2>{error}</h2>
        <p>This note may have been removed or the link has expired.</p>
        <a href="/" className="sn-error__home">Back to InkDrop</a>
      </div>
    </div>
  );

  const readMin = estimateReadTime(note?.body);
  const dateStr = note?.createdAt ? new Date(note.createdAt).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }) : '';

  return (
    <div className={`sn-page sn-page--${theme}`}>
      <nav className="sn-nav">
        <a href="/" className="sn-nav__brand">
          <InkDropLogo size={18} />
          <span>InkDrop</span>
        </a>
        <div className="sn-nav__right">
          <button className="sn-nav__icon-btn" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} title="Toggle theme">
            {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
          </button>
          <button className="sn-nav__icon-btn" onClick={handleShare} title="Copy link">
            {linkCopied ? '\u2713' : <ShareIcon />}
          </button>
        </div>
      </nav>
      <div className="sn-nav__spacer" />

      <div className="sn-content-wrap">
        {note?.coverImage && (
          <div className="sn-hero" style={{ backgroundImage: `url(${note.coverImage})` }}>
            <div className="sn-hero__overlay" />
          </div>
        )}

        <article className="sn-article">
          <h1 className="sn-article__title">{note?.title || 'Untitled'}</h1>
          <div className="sn-article__meta-sub">
            {(note?.sharedBy || 'Anonymous')}
            {dateStr && <> &middot; {dateStr}</>}
            {' '}&middot; {readMin} min read
          </div>
        </article>

        <div className="sn-content">
          <PaginatedContent sections={sections} />
        </div>

        <CommentsSection shareId={shareId} />

        <footer className="sn-footer">
          <div className="sn-footer__inner">
            Published via <a href="/">InkDrop</a>
          </div>
        </footer>
      </div>
    </div>
  );
});

export default SharedNoteView;
