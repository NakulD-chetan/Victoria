# Message Queues and Events — Design Template

> **Permanent Recall:** A good interview answer is not "use Kafka." A good answer is: **why async**, **which model**, **which broker**, **delivery guarantee**, **ordering strategy**, **retry + DLQ**, and **how consumers scale**. Use that structure every time.

---

## The Reusable Answer Structure

When the interview question involves messaging, answer in this order:

1. Define what becomes asynchronous
2. Choose queue or pub/sub
3. Pick Kafka, RabbitMQ, or SQS/SNS
4. Define message schema
5. Explain delivery guarantee
6. Explain ordering
7. Add retry, DLQ, and idempotency
8. Add scaling and monitoring

If you cover these 8 points, your answer will usually feel complete.

---

## Template 1: Basic Async Queue

### When to use

- background jobs
- load leveling
- slow downstream processing
- task distribution across workers

### Template answer

```text
Client -> Service A -> Queue -> Worker Service
```

### What to say

- Service A writes the job to a queue and returns quickly
- workers consume jobs asynchronously
- workers acknowledge only after successful processing
- failed jobs are retried
- poison jobs go to a DLQ

### Must-mention details

| Area | Default Answer |
|---|---|
| **Delivery** | At-least-once |
| **Idempotency** | Use job ID or business key |
| **Retry** | 3-5 attempts with backoff |
| **DLQ** | Required |
| **Monitoring** | Queue depth, retry count, processing latency |

---

## Template 2: Pub/Sub Event Bus

### When to use

- many downstream services react to the same event
- event-driven architecture
- notifications, analytics, audit, side effects

### Template answer

```text
Order Service -> order.created topic
              -> Billing consumes
              -> Inventory consumes
              -> Analytics consumes
              -> Notifications consumes
```

### What to say

- producer publishes domain event once
- many consumers subscribe independently
- consumers are loosely coupled from the producer
- new consumers can be added without changing producer logic

### Good event shape

```json
{
  "event_id": "uuid",
  "event_type": "order.created",
  "timestamp": "ISO8601",
  "entity_id": "order-123",
  "payload": {}
}
```

### Must-mention details

- schema versioning
- replay strategy if Kafka is used
- ordering key if one entity needs ordered handling

---

## Template 3: Kafka-Based Design

### Use when

- high throughput matters
- replay matters
- event history matters
- multiple consumer groups are expected

### Producer template

```yaml
acks: all
enable.idempotence: true
retries: 3
linger.ms: 5
compression.type: lz4
```

### Consumer template

```yaml
group.id: order-processors
enable.auto.commit: false
auto.offset.reset: earliest
max.poll.records: 500
```

### What to say

- partition by entity ID if order matters
- same key goes to same partition
- consumer group gives parallelism
- commit offset only after processing
- monitor consumer lag

### Interview line

"I would use Kafka here because we need replay, high throughput, and multiple independent consumers."

---

## Template 4: RabbitMQ-Based Design

### Use when

- routing rules are important
- it is more of a task/work queue problem
- you want exchange-based routing

### Template answer

```text
Producer -> topic exchange -> billing queue
                         -> shipping queue
                         -> fraud queue
```

### What to say

- exchange handles routing
- queues buffer work
- consumers ack after success
- configure prefetch to avoid overwhelming consumers
- use DLQ for poison messages

### Interview line

"I would choose RabbitMQ if the problem is routing-heavy and does not need Kafka-style replay."

---

## Template 5: SNS + SQS Fan-Out

### Use when

- system is AWS-native
- you want low ops overhead
- you need pub/sub plus separate consumer queues

### Template answer

```text
Producer -> SNS topic -> SQS queue A -> Service A
                     -> SQS queue B -> Service B
                     -> Lambda
```

### What to say

- SNS handles fan-out
- each downstream service gets its own queue
- each consumer can scale independently
- failures in one consumer path do not block others

---

## Template 6: CQRS

### Use when

- writes and reads have different scaling needs
- reads need denormalized views
- the read model is complex and query-heavy

### Template answer

```text
Command -> Write model -> Event -> Projection -> Read model
Query   -> Read model
```

### What to say

- writes go to the source of truth
- emitted events update one or more read projections
- reads use optimized denormalized storage
- reads are eventually consistent

### Must-mention details

- replay projections from event history if needed
- projection lag monitoring
- schema evolution

---

## Template 7: Event Sourcing

### Use when

- audit trail matters
- historical reconstruction matters
- replay matters

### Template answer

```text
Instead of storing only current state,
store all state-changing events.
Current state = replay(events)
```

### What to say

- every state change is captured as an immutable event
- state can be rebuilt later
- projections can be created from the event stream
- snapshots may be needed for long histories

### Risks to mention

- schema evolution
- replay cost
- eventual consistency on the read side

---

## Template 8: Saga

### Use when

- business flow spans multiple services
- one service cannot hold a global ACID transaction for all of them

### Choreography template

```text
OrderCreated -> Payment service
PaymentCompleted -> Inventory service
InventoryReserved -> Shipping service
Failure -> compensating event
```

### Orchestration template

```text
Orchestrator -> Order
             -> Payment
             -> Inventory
             -> Shipping

On failure -> trigger compensation
```

### What to say

- each step is a local transaction
- failures trigger compensating actions
- choreography is looser but harder to follow
- orchestration is clearer but centralizes control

---

## Template 9: Retry + DLQ

Every messaging design should include this.

```text
Message -> Consumer
        -> success -> ack
        -> failure -> retry with backoff
        -> repeated failure -> DLQ
```

### What to say

- retry only for transient failures
- cap retry attempts
- send poison messages to DLQ
- replay from DLQ only after root cause is fixed

### Must-mention fields

- retry count
- failure reason
- original timestamp
- message ID

---

## Template 10: Closing the Answer

A strong finishing paragraph sounds like this:

"So I would publish the event asynchronously, partition by `order_id` if ordering matters, use at-least-once delivery with idempotent consumers, add retries with DLQ, and monitor lag plus retry depth to keep the pipeline healthy."

---

## 30-SECOND REVISION BOX

```text
ANSWER ORDER:
1. Why async
2. Queue or pub/sub
3. Which broker
4. Schema
5. Delivery guarantee
6. Ordering
7. Retry + DLQ + idempotency
8. Scale + monitor

KAFKA: replay, throughput, consumer groups
RABBITMQ: routing-heavy broker
SQS/SNS: AWS-managed simplicity
CQRS: write model -> event -> read projection
SAGA: local transactions + compensation
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
