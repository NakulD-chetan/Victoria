import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: bellman-ford */
const GRAPH = {
  nodes: [
    { id: 'S', x: 100, y: 200, label: 'S' },
    { id: 'A', x: 240, y: 120, label: 'A' },
    { id: 'B', x: 240, y: 280, label: 'B' },
    { id: 'C', x: 400, y: 120, label: 'C' },
    { id: 'D', x: 400, y: 280, label: 'D' },
  ],
  edges: [
    { from: 'S', to: 'A', weight: 2, directed: true },
    { from: 'S', to: 'B', weight: 5, directed: true },
    { from: 'A', to: 'C', weight: 1, directed: true },
    { from: 'B', to: 'A', weight: -4, directed: true },
    { from: 'B', to: 'D', weight: 3, directed: true },
    { from: 'C', to: 'D', weight: 2, directed: true },
  ],
};

function generateSteps() {
  const ids = ['S', 'A', 'B', 'C', 'D'];
  const dist = Object.fromEntries(ids.map((i) => [i, Infinity]));
  dist.S = 0;
  const steps = [];
  steps.push({ type: 'init', nodeColors: { S: 'source' }, edgeColors: {}, distances: { ...dist }, round: 0 });
  const m = GRAPH.edges.length;
  for (let round = 1; round < ids.length; round += 1) {
    steps.push({ type: 'round', nodeColors: {}, edgeColors: {}, distances: { ...dist }, round });
    for (let ei = 0; ei < m; ei += 1) {
      const e = GRAPH.edges[ei];
      const nd = dist[e.from] + e.weight;
      steps.push({
        type: 'relax',
        edgeColors: { [`${e.from}-${e.to}`]: 'highlight' },
        nodeColors: { [e.from]: 'processing', [e.to]: 'processing' },
        distances: { ...dist },
        from: e.from,
        to: e.to,
        nd,
        ei,
      });
      if (dist[e.from] !== Infinity && nd < dist[e.to]) {
        dist[e.to] = nd;
        steps.push({
          type: 'improve',
          edgeColors: { [`${e.from}-${e.to}`]: 'tree' },
          nodeColors: { [e.to]: 'visited' },
          distances: { ...dist },
        });
      }
    }
  }
  steps.push({ type: 'done', nodeColors: Object.fromEntries(ids.map((id) => [id, 'visited'])), edgeColors: {}, distances: { ...dist } });
  return steps;
}

export default function BellmanFordVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Bellman–Ford edge relaxations from S' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { S: 'source' },
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'relax') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.type}${step.round != null ? ` r${step.round}` : ''}` });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: [],
      stack: [],
      distances: step.distances || {},
      visited: step.visited || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
