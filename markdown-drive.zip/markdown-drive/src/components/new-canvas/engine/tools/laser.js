import { LaserPointer } from '@excalidraw/laser-pointer';

/**
 * Laser pointer — same core as Excalidraw (`@excalidraw/laser-pointer` +
 * laser-trails sizeMapping), with:
 *   - Color from toolbar `toolOptions.stroke` (any swatch / custom picker).
 *   - Higher streamline than stock Excalidraw (0.4 → 0.62) for a silkier path.
 * Per-stroke color is frozen at pointerdown so fading tails keep their hue.
 */

const DECAY_TIME   = 1000;
const DECAY_LENGTH = 50;
/** Stronger interpolation = smoother curves (Excalidraw uses 0.4). */
const STREAMLINE   = 0.62;
const FALLBACK_COLOR = '#ef4444';

/** Reused for parsing any CSS color the browser accepts. */
let _colorProbe;
function normalizeCssColor(input) {
  if (!_colorProbe) _colorProbe = document.createElement('canvas').getContext('2d');
  _colorProbe.fillStyle = FALLBACK_COLOR;
  _colorProbe.fillStyle = input;
  const out = _colorProbe.fillStyle;
  return typeof out === 'string' && out ? out : FALLBACK_COLOR;
}

function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}

function makeOptions() {
  return {
    simplify: 0,
    streamline: STREAMLINE,
    sizeMapping: (c) => {
      const t = Math.max(0, 1 - (performance.now() - c.pressure) / DECAY_TIME);
      const l =
        (DECAY_LENGTH - Math.min(DECAY_LENGTH, c.totalLength - c.currentIndex))
        / DECAY_LENGTH;
      return Math.min(easeOut(l), easeOut(t));
    },
  };
}

function pickLaserColor(ctx) {
  const raw = ctx.store?.getState?.()?.toolOptions?.stroke;
  if (typeof raw !== 'string') return FALLBACK_COLOR;
  const c = raw.trim();
  if (!c) return FALLBACK_COLOR;
  return normalizeCssColor(c);
}

/**
 * Tool state (kept on the ctx object, not in the scene / history):
 *   ctx._laser = {
 *     current:    { ptr: LaserPointer, color } | null
 *     past:       { ptr: LaserPointer, color }[]
 *     rafId:      number
 *   }
 */
function ensureState(ctx) {
  if (!ctx._laser) ctx._laser = { current: null, past: [], rafId: 0 };
  return ctx._laser;
}

export const laserTool = {
  id: 'laser',
  cursor: 'crosshair',

  onPointerDown(ctx, ev) {
    if (ev.button !== 0) return false;
    ctx.canvasEl.setPointerCapture?.(ev.pointerId);
    const st = ensureState(ctx);
    // close any stale one-shot before starting a new path (safety net)
    if (st.current) {
      st.current.ptr.close();
      st.past.push(st.current);
      st.current = null;
    }
    const p = toWorld(ctx, ev);
    const ptr = new LaserPointer(makeOptions());
    ptr.addPoint([p.x, p.y, performance.now()]);
    st.current = { ptr, color: pickLaserColor(ctx) };
    startTicker(ctx);
    return true;
  },

  onPointerMove(ctx, ev) {
    const st = ctx._laser;
    if (!st?.current) return;
    const p = toWorld(ctx, ev);
    const { ptr } = st.current;
    const pts = ptr.originalPoints;
    const last = pts[pts.length - 1];
    if (!last || last[0] !== p.x || last[1] !== p.y) {
      ptr.addPoint([p.x, p.y, performance.now()]);
    }
  },

  onPointerUp(ctx, ev) {
    const st = ctx._laser;
    if (!st?.current) return;
    const { ptr } = st.current;
    const p = toWorld(ctx, ev);
    const pts = ptr.originalPoints;
    const last = pts[pts.length - 1];
    if (!last || last[0] !== p.x || last[1] !== p.y) {
      ptr.addPoint([p.x, p.y, performance.now()]);
    }
    ptr.close();
    st.past.push(st.current);
    st.current = null;
    // keep ticker running: pastTrails decay over ~DECAY_TIME ms
  },

  onCancel(ctx) {
    const st = ctx._laser;
    if (!st) return;
    if (st.current) {
      st.current.ptr.close();
      st.past.push(st.current);
      st.current = null;
    }
  },
};

function toWorld(ctx, ev) {
  const rect = ctx.canvasEl.getBoundingClientRect();
  const sx = ev.clientX - rect.left;
  const sy = ev.clientY - rect.top;
  const vp = ctx.getVp();
  // inverse of: screenX = (worldX + panX) * zoom
  return {
    x: sx / vp.zoom - vp.panX,
    y: sy / vp.zoom - vp.panY,
  };
}

function startTicker(ctx) {
  const st = ctx._laser;
  if (st.rafId) return;
  const tick = () => {
    const s = ctx._laser;
    if (!s) return;
    // drop past trails whose outline has fully decayed
    s.past = s.past.filter((item) => item.ptr.getStrokeOutline().length !== 0);
    ctx.markDirty(1);
    if (!s.current && s.past.length === 0) {
      s.rafId = 0;
      return;
    }
    s.rafId = requestAnimationFrame(tick);
  };
  st.rafId = requestAnimationFrame(tick);
}

/**
 * Renderer helper — paint the active stroke + all past (decaying) strokes.
 * `getLaser()` now returns the engine's `_laser` state bucket.
 */
export function paintLaserTrail(ctx2d, state, vp) {
  if (!state) return;
  const size = 2 / vp.zoom; // LaserPointer default size (2), div. by zoom
  const blur = 10 / vp.zoom;

  for (const item of state.past) {
    paintOneLaserStroke(ctx2d, item.ptr.getStrokeOutline(size), item.color, blur);
  }
  if (state.current) {
    paintOneLaserStroke(
      ctx2d,
      state.current.ptr.getStrokeOutline(size),
      state.current.color,
      blur,
    );
  }
}

function paintOneLaserStroke(ctx2d, outline, color, blur) {
  if (!outline || outline.length === 0) return;
  ctx2d.save();
  ctx2d.fillStyle = color;
  ctx2d.globalAlpha = 1;
  ctx2d.shadowColor = color;
  ctx2d.shadowBlur = blur;
  ctx2d.beginPath();
  ctx2d.moveTo(outline[0][0], outline[0][1]);
  for (let i = 1; i < outline.length; i++) ctx2d.lineTo(outline[i][0], outline[i][1]);
  ctx2d.closePath();
  ctx2d.fill();
  ctx2d.restore();
}
