# 04 — Snowflake Architecture Deep Dive

> **One-line:** Snowflake's **multi-cluster shared-data** architecture separates **storage, compute, and cloud services** — enabling independent scaling, zero-copy cloning, and near-zero maintenance.

---

## 1. Snowflake's Three-Layer Architecture

```
┌──────────────────────────────────────────────────┐
│             CLOUD SERVICES LAYER                  │
│  (Authentication, Metadata, Query Optimization,   │
│   Access Control, Infrastructure Management)      │
└──────────────────────┬───────────────────────────┘
                       │
┌──────────────────────┴───────────────────────────┐
│             COMPUTE LAYER                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐       │
│  │ Virtual  │  │ Virtual  │  │ Virtual  │       │
│  │ WH: ETL  │  │ WH: BI   │  │ WH: DS   │       │
│  │ (XL)     │  │ (Medium) │  │ (Large)  │       │
│  └──────────┘  └──────────┘  └──────────┘       │
└──────────────────────┬───────────────────────────┘
                       │
┌──────────────────────┴───────────────────────────┐
│             STORAGE LAYER                         │
│  (Centralized, compressed, columnar storage       │
│   on cloud object store — S3/ADLS/GCS)            │
│  ┌──────────────────────────────────────┐         │
│  │  Micro-partitions (50-500 MB each)   │         │
│  └──────────────────────────────────────┘         │
└──────────────────────────────────────────────────┘
```

| Layer | What It Does |
|-------|-------------|
| **Cloud Services** | Authentication, metadata management, query parsing & optimization, access control |
| **Compute (Virtual Warehouses)** | Independent clusters that execute queries — scale up/down/out independently |
| **Storage** | Centralized columnar micro-partitions on cloud object store |

**Interview line:** "Snowflake's key innovation is **separating storage from compute** — you can scale your ETL warehouse to XL without affecting your BI warehouse, and both read the **same data**."

---

## 2. Micro-Partitions — Storage Internals

| Feature | Detail |
|---------|--------|
| **What** | Contiguous units of storage, 50–500 MB compressed |
| **Format** | Columnar, compressed (automatically managed) |
| **Immutable** | Writes create **new** micro-partitions; old ones are marked for deletion |
| **Metadata** | Min/max values, distinct count, null count per column per partition |
| **Pruning** | Snowflake uses metadata to **skip** irrelevant partitions (up to 99% pruning) |

```
Table: orders (100M rows)
    │
    ├── Micro-partition 1: [order_date: 2024-01-01 to 2024-01-15]
    ├── Micro-partition 2: [order_date: 2024-01-16 to 2024-01-31]
    ├── Micro-partition 3: [order_date: 2024-02-01 to 2024-02-15]
    └── ...

Query: WHERE order_date = '2024-01-10'
→ Only reads partition 1, skips all others (partition pruning)
```

---

## 3. Clustering Keys

| Aspect | Detail |
|--------|--------|
| **Problem** | As data grows, micro-partitions may have overlapping value ranges → poor pruning |
| **Solution** | Define **clustering key** → Snowflake automatically reorganizes data |
| **When** | Large tables (multi-TB), queries filter on specific columns frequently |
| **Cost** | Automatic **reclustering** has compute cost — monitor with `SYSTEM$CLUSTERING_INFORMATION` |

```sql
ALTER TABLE orders CLUSTER BY (order_date, region);
```

**Interview tip:** "Clustering keys are Snowflake's equivalent of **sort keys** — they improve partition pruning for large tables. Unlike traditional indexes, Snowflake handles reorganization automatically."

---

## 4. Virtual Warehouses — Compute

| Feature | Detail |
|---------|--------|
| **What** | Independent compute clusters (XS to 6XL) |
| **Scaling Up** | Bigger warehouse = more nodes = faster individual query |
| **Scaling Out** | Multi-cluster warehouse = more concurrent queries |
| **Auto-suspend** | Warehouse shuts down after idle timeout → no cost when idle |
| **Auto-resume** | Starts automatically when query arrives |
| **Isolation** | ETL warehouse and BI warehouse don't compete for resources |

### Multi-Cluster Warehouse

```
Standard Mode:
  Query load increases → Snowflake adds clusters automatically
  Query load decreases → clusters shut down

  Min clusters: 1    Max clusters: 10
  
  Low load:   [Cluster 1]
  High load:  [Cluster 1] [Cluster 2] [Cluster 3] [Cluster 4]
```

---

## 5. Time Travel & Fail-Safe

| Feature | What It Does | Duration |
|---------|-------------|----------|
| **Time Travel** | Query/restore data at any point in past | 0–90 days (edition dependent) |
| **Fail-Safe** | Snowflake-internal recovery (last resort) | 7 days after Time Travel expires |
| **Undrop** | Recover dropped tables, schemas, databases | Within Time Travel window |

```sql
-- Query data as it was 1 hour ago
SELECT * FROM orders AT(OFFSET => -3600);

-- Query data at specific timestamp
SELECT * FROM orders AT(TIMESTAMP => '2024-01-15 10:00:00'::timestamp);

-- Restore a dropped table
UNDROP TABLE orders;
```

**Interview line:** "Time Travel uses micro-partition immutability — old partitions are retained for the configured window, so you can query **any historical state** without backups."

---

## 6. Zero-Copy Cloning

| Feature | Detail |
|---------|--------|
| **What** | Create instant copy of table/schema/database with no additional storage |
| **How** | Clone shares same micro-partitions; new writes create new partitions only for clone |
| **Use cases** | Dev/test environments, safe experimentation, pre-migration snapshots |
| **Cost** | No extra storage until clone diverges from source |

```sql
CREATE TABLE orders_dev CLONE orders;
-- Instant. No data copied. Dev can modify freely.
```

---

## 7. Snowpipe — Continuous Ingestion

| Feature | Detail |
|---------|--------|
| **What** | Serverless, auto-ingest service for continuous loading |
| **Trigger** | Cloud event notification (S3 SNS → SQS → Snowpipe) or REST API |
| **Latency** | Near-real-time (seconds to minutes) |
| **Cost** | Pay per file loaded (Snowflake-managed compute) |

```
S3 Bucket → SNS Notification → SQS Queue → Snowpipe → Snowflake Table
```

**vs Bulk COPY INTO:**

| Dimension | Snowpipe | COPY INTO |
|-----------|----------|-----------|
| **Trigger** | Event-driven, automatic | Manual / scheduled |
| **Latency** | Seconds-minutes | Depends on schedule |
| **Cost** | Per-file serverless compute | Uses virtual warehouse |
| **Best for** | Continuous micro-batch | Large batch loads |

---

## 8. Stages, File Formats & COPY INTO

| Concept | What |
|---------|------|
| **Internal Stage** | Snowflake-managed storage for files |
| **External Stage** | Points to S3/ADLS/GCS bucket |
| **File Format** | Named object defining CSV/JSON/Parquet/Avro settings |
| **COPY INTO** | Bulk load from stage to table |

```sql
-- Create external stage
CREATE STAGE my_s3_stage URL='s3://my-bucket/data/' CREDENTIALS=(AWS_KEY_ID='...');

-- Load data
COPY INTO orders FROM @my_s3_stage FILE_FORMAT=(TYPE='PARQUET');
```

---

## 9. Streams & Tasks — CDC in Snowflake

| Feature | What |
|---------|------|
| **Stream** | Captures DML changes (INSERT/UPDATE/DELETE) on a table — Snowflake's native CDC |
| **Task** | Scheduled SQL execution (like a mini-scheduler inside Snowflake) |
| **Together** | Stream detects changes → Task processes them → incremental pipeline inside Snowflake |

```sql
-- Create stream on source table
CREATE STREAM orders_stream ON TABLE raw_orders;

-- Create task to process changes every 5 minutes
CREATE TASK process_orders
  WAREHOUSE = etl_wh
  SCHEDULE = '5 MINUTE'
  WHEN SYSTEM$STREAM_HAS_DATA('orders_stream')
AS
  MERGE INTO clean_orders t
  USING orders_stream s ON t.id = s.id
  WHEN MATCHED THEN UPDATE SET ...
  WHEN NOT MATCHED THEN INSERT ...;
```

---

## 10. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "Explain Snowflake architecture" | Three layers: Cloud Services, Compute (VWs), Storage (micro-partitions) — all independent |
| "What are micro-partitions?" | 50-500MB immutable columnar units with metadata for pruning |
| "Clustering key vs partition?" | Clustering = how data is organized within micro-partitions for pruning; not user-managed partitions |
| "How does Time Travel work?" | Immutable micro-partitions retained for configured window; query with AT/BEFORE |
| "What is zero-copy cloning?" | Instant metadata copy sharing same micro-partitions; diverges on write |
| "Snowpipe vs COPY INTO?" | Snowpipe: event-driven, serverless, continuous. COPY: batch, warehouse-based |
| "How do you handle CDC in Snowflake?" | Streams capture changes, Tasks process them on schedule |
| "How do you optimize Snowflake costs?" | Right-size warehouses, auto-suspend, clustering for large tables, avoid SELECT * |

---

## Key Takeaways

- **Three-layer architecture** (Storage/Compute/Cloud Services) with **independent scaling** is the core innovation.
- **Micro-partitions** (50-500MB, immutable, columnar) with metadata enable **automatic partition pruning**.
- **Clustering keys** reorganize data for better pruning on large tables.
- **Virtual warehouses** are independent compute clusters — isolate ETL from BI workloads.
- **Time Travel** + **zero-copy cloning** leverage micro-partition immutability.
- **Snowpipe** = continuous serverless ingestion. **Streams + Tasks** = native CDC inside Snowflake.
- Cost optimization = right-size + auto-suspend + good clustering + avoid full scans.

---
