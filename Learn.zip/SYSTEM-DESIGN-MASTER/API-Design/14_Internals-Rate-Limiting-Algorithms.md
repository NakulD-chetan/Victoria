# Internals: Rate Limiting Algorithms

> **Permanent Recall:** Rate limiting protects APIs from abuse and overload. Token bucket: tokens refill at fixed rate, allows bursts up to capacity; CAS for lock-free atomic ops. Leaky bucket: FIFO queue, fixed drain rate, smooths traffic. Fixed window: simple counter per window, boundary burst = 2× limit. Sliding window log: store every timestamp, accurate but O(n) memory. Sliding window counter: hybrid formula, O(1) memory, good accuracy. Distributed: Redis + Lua for atomic ops. Layers: per-IP, per-user, per-endpoint. Headers: X-RateLimit-Limit, Remaining, Reset, Retry-After.

---

## 1. Token Bucket at Memory Level

```
TOKEN BUCKET — CONCEPTUAL MODEL:

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   Bucket capacity: 10 tokens                                        │
  │   Refill rate: 2 tokens/second                                      │
  │                                                                     │
  │   ┌─────────────────────────────────────┐                          │
  │   │ ██████████  ← 10 tokens (full)      │  Request arrives          │
  │   │                                     │  → consume 1 token        │
  │   │ █████████   ← 9 tokens remain      │  → ALLOW                  │
  │   └─────────────────────────────────────┘                          │
  │                                                                     │
  │   After 0.5 sec (no requests):                                      │
  │   ┌─────────────────────────────────────┐                          │
  │   │ ███████████  ← 9 + 1 = 10 (capped)  │  elapsed × rate = 1      │
  │   └─────────────────────────────────────┘                          │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Data Structure

```
TOKEN BUCKET — IN-MEMORY REPRESENTATION:

  struct TokenBucket {
      double tokens;           // Current token count (float for precision)
      double capacity;         // Max tokens (e.g., 100)
      double refill_rate;      // Tokens per second (e.g., 10.0)
      int64_t last_refill_ns;  // Last refill timestamp (nanoseconds)
  };

  MEMORY LAYOUT (64-bit system, typical):
  ┌────────────────────────────────────────────────────────────────────┐
  │ Offset │ Field          │ Size  │ Purpose                          │
  ├────────┼────────────────┼───────┼──────────────────────────────────┤
  │ 0      │ tokens         │ 8 B   │ double: 0.0 to capacity           │
  │ 8      │ capacity       │ 8 B   │ double: constant                 │
  │ 16     │ refill_rate    │ 8 B   │ double: tokens/sec               │
  │ 24     │ last_refill_ns │ 8 B   │ int64: monotonic clock           │
  └────────┴────────────────┴───────┴──────────────────────────────────┘
  Total: 32 bytes per bucket (cache-line friendly)
```

### Refill Calculation

```
REFILL FORMULA — LAZY EVALUATION (on each request):

  elapsed_sec = (now_ns - last_refill_ns) / 1e9
  new_tokens = elapsed_sec × refill_rate
  tokens = min(tokens + new_tokens, capacity)   // Cap at capacity
  last_refill_ns = now_ns

  EXAMPLE:
    capacity = 10, refill_rate = 2/sec
    tokens = 3, last_refill = T0

    At T0 + 2.5 sec:
      elapsed = 2.5
      new_tokens = 2.5 × 2 = 5
      tokens = min(3 + 5, 10) = 8
```

### CAS (Compare-and-Swap) for Lock-Free Implementation

```
ATOMIC OPERATIONS — AVOIDING LOCKS:

  Problem: Multiple threads may refill and consume simultaneously.
  Solution: CAS loop — read-modify-write atomically.

  PSEUDOCODE (lock-free try_consume):

    loop:
      old_tokens = atomic_load(tokens)
      now = monotonic_clock()
      elapsed = (now - last_refill_ns) / 1e9
      new_tokens = min(elapsed * refill_rate, capacity - old_tokens)
      expected = old_tokens + new_tokens

      if expected >= 1.0:           // Have at least 1 token
        desired = expected - 1.0    // Consume 1
        if atomic_compare_and_swap(tokens, expected, desired):
          last_refill_ns = now
          return ALLOW
      else:
        return DENY

  CAS: "If tokens still equals expected, set to desired; else retry."
  No mutex needed — wait-free under low contention.
```

### Thread Safety with Mutex (Simpler Alternative)

```
  With mutex (simpler, adequate for most APIs):

    mutex.lock()
    refill()           // Update tokens from elapsed time
    if tokens >= 1:
      tokens -= 1
      mutex.unlock()
      return ALLOW
    mutex.unlock()
    return DENY
```

---

## 2. Leaky Bucket

```
LEAKY BUCKET — QUEUE-BASED, SMOOTHS BURSTS:

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   Requests (variable rate)     Bucket (queue)        Output         │
  │   ████ ██ ████████ █          ┌──────────────┐      (fixed rate)   │
  │        │                      │ R1 R2 R3 R4  │      █ █ █ █ █ █   │
  │        └─────────────────────►│   (FIFO)     │─────►  drain_rate   │
  │                              └──────────────┘                      │
  │                                                                     │
  │   Bursty input → Smooth output (one request per 1/drain_rate sec)   │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Queue-Based Implementation

```
LEAKY BUCKET — DATA STRUCTURE:

  struct LeakyBucket {
      queue<timestamp> requests;   // FIFO: arrival times
      double drain_rate;           // Requests per second (e.g., 10)
      size_t max_queue_size;       // Drop if queue full
  };

  ON REQUEST:
    1. now = current_time()
    2. DRAIN: while queue not empty AND queue.front + 1/drain_rate <= now:
         pop front (request "processed")
    3. if queue.size < max_queue_size:
         queue.push(now)
         return ALLOW
       else:
         return DENY (queue full)
```

### Difference: Token Bucket vs Leaky Bucket

```
  ┌────────────────────┬─────────────────────────┬─────────────────────────┐
  │ Aspect             │ Token Bucket            │ Leaky Bucket            │
  ├────────────────────┼─────────────────────────┼─────────────────────────┤
  │ Bursts             │ ALLOWS bursts           │ SMOOTHS bursts          │
  │                    │ (up to capacity)        │ (queues, drains fixed)  │
  │ Output pattern     │ Variable (bursty)       │ Fixed (smooth)           │
  │ Memory             │ O(1) — just counters   │ O(n) — queue of times   │
  │ Use case           │ Allow short bursts      │ Strict rate (e.g., SMS) │
  │ Implementation     │ Refill + consume        │ Enqueue + drain         │
  └────────────────────┴─────────────────────────┴─────────────────────────┘

  Token bucket: "You can burst 100 requests, then 10/sec"
  Leaky bucket: "Requests leave at exactly 10/sec, no matter how they arrive"
```

### Implementation with Timestamps

```
  VARIANT: Token-based leaky bucket (single "last_drain" timestamp):

    last_drain_time = when last request was "released"
    min_interval = 1 / drain_rate

    ON REQUEST:
      now = current_time()
      if now >= last_drain_time + min_interval:
        last_drain_time = now
        return ALLOW
      else:
        return DENY  // Too soon

  This is a "leaky bucket" with capacity 1 — strict rate, no burst.
```

---

## 3. Fixed Window Counter

```
FIXED WINDOW — SIMPLEST ALGORITHM:

  Window: 1 minute, Limit: 10 requests

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   Window 1 (0:00-0:59)        Window 2 (1:00-1:59)                  │
  │   ┌─────────────────────┐    ┌─────────────────────┐                │
  │   │ count = 10          │    │ count = 0 (fresh!)  │                │
  │   │ 10 requests used    │    │                     │                │
  │   └─────────────────────┘    └─────────────────────┘                │
  │            │                            │                            │
  │            0:59    0:59.5   1:00       1:00.5                       │
  │                    ▲        ▲          ▲                            │
  │                    │        │          │                            │
  │              BURST: 10 at 0:59 + 10 at 1:00 = 20 in 1 second!        │
  │              (Boundary problem — 2× allowed rate)                   │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Hash Map Structure

```
  DATA STRUCTURE:

    HashMap<window_key, count>

    window_key = floor(now / window_sec)   // e.g., 1710345600 for 1-min window
    For key "user:123":
      "user:123:1710345600" → 7   // 7 requests in this window

  PSEUDOCODE:

    key = user_id + ":" + (current_time / 60)
    count = redis.INCR(key)
    if count == 1:
      redis.EXPIRE(key, 60)   // Expire after 60 sec (cleanup)
    if count > limit:
      return DENY
    return ALLOW
```

### Redis INCR + EXPIRE Implementation

```
  REDIS COMMANDS (atomic with Lua or pipeline):

    -- Lua script (atomic)
    local key = KEYS[1]
    local limit = tonumber(ARGV[1])
    local window = tonumber(ARGV[2])
    local count = redis.call('INCR', key)
    if count == 1 then
      redis.call('EXPIRE', key, window)
    end
    if count > limit then
      return {0, count}   -- DENY, current count
    else
      return {1, limit - count}   -- ALLOW, remaining
    end

  RACE: Two requests at same millisecond?
    INCR is atomic — both see correct count.
    EXPIRE race: if count==1 for both, EXPIRE called twice (harmless).
```

---

## 4. Sliding Window Log

```
SLIDING WINDOW LOG — STORE EVERY REQUEST TIMESTAMP:

  Window: 60 seconds, Limit: 10

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   Now = 1:00:45                                                     │
  │   Window = [1:00:45 - 60, 1:00:45] = [0:59:45, 1:00:45]            │
  │                                                                     │
  │   Stored timestamps:                                                │
  │   [0:59:50, 0:59:55, 1:00:00, 1:00:10, 1:00:20, 1:00:30, 1:00:40]  │
  │                                                                     │
  │   Count in window = 7  → ALLOW (under 10)                          │
  │   Add new timestamp 1:00:45                                        │
  │                                                                     │
  │   MEMORY: O(n) — one entry per request in window                   │
  │   At 1000 req/min: 1000 entries per key                            │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Redis Sorted Set Implementation

```
  REDIS SORTED SET — score = timestamp (Unix ms):

    Key: "ratelimit:user:123"
    Members: request IDs (or timestamps as strings)
    Score: timestamp in milliseconds

  ALGORITHM:

    1. now_ms = current_time_millis()
    2. window_start = now_ms - (window_sec * 1000)
    3. ZREMRANGEBYSCORE key -inf window_start   // Remove old entries
    4. count = ZCARD key
    5. if count >= limit: return DENY
    6. ZADD key now_ms now_ms   // Add current request (member=score for uniqueness)
    7. EXPIRE key window_sec + 1   // Cleanup
    8. return ALLOW

  LUA SCRIPT (atomic):

    local key = KEYS[1]
    local limit = tonumber(ARGV[1])
    local window = tonumber(ARGV[2])
    local now = tonumber(ARGV[3])
    local window_start = now - (window * 1000)

    redis.call('ZREMRANGEBYSCORE', key, '-inf', window_start)
    local count = redis.call('ZCARD', key)
    if count >= limit then
      return {0, count}
    end
    redis.call('ZADD', key, now, now)
    redis.call('EXPIRE', key, window + 1)
    return {1, limit - count - 1}
```

---

## 5. Sliding Window Counter

```
SLIDING WINDOW COUNTER — HYBRID, O(1) MEMORY:

  Formula: count = current_window_count + previous_window_count × overlap_fraction

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   Previous window    │    Current window                             │
  │   [--------60 sec--------]                                          │
  │                      [--------60 sec--------]                       │
  │                      ▲                                              │
  │                      now (e.g., 25 sec into current window)         │
  │                                                                     │
  │   overlap_fraction = (60 - 25) / 60 = 35/60 ≈ 0.583                │
  │   (How much of previous window overlaps with "sliding" window)       │
  │                                                                     │
  │   count = current_count + previous_count × 0.583                    │
  │                                                                     │
  │   Example: current=5, previous=8                                    │
  │   count = 5 + 8 × 0.583 = 5 + 4.67 ≈ 9.67 → 10 (ceiling) or 9      │
  │   If limit=10: 9.67 < 10 → ALLOW                                    │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Implementation

```
  STORED STATE:
    previous_window_key, previous_count
    current_window_key, current_count

  ON REQUEST:
    now = current_time()
    current_window = floor(now / window_sec)
    previous_window = current_window - 1

    // Get or init counts (Redis GET or 0)
    current_count = redis.GET("count:" + current_window) or 0
    previous_count = redis.GET("count:" + previous_window) or 0

    overlap = window_sec - (now % window_sec)   // Seconds left in current window
    overlap_fraction = overlap / window_sec

    estimated_count = current_count + previous_count * overlap_fraction

    if estimated_count >= limit:
      return DENY

    redis.INCR("count:" + current_window)
    redis.EXPIRE("count:" + current_window, 2 * window_sec)  // Keep 2 windows
    return ALLOW

  ACCURACY: Slight over-estimation at boundaries (conservative).
  MEMORY: O(1) — two counters per key.
```

---

## 6. Distributed Rate Limiting with Redis

```
DISTRIBUTED RATE LIMITING — MULTIPLE API SERVERS, ONE REDIS:

  ┌─────────┐  ┌─────────┐  ┌─────────┐
  │ API #1  │  │ API #2  │  │ API #3  │
  └────┬────┘  └────┬────┘  └────┬────┘
       │            │            │
       └────────────┼────────────┘
                    │
                    ▼
              ┌───────────┐
              │   Redis   │  ← Single source of truth
              └───────────┘
```

### Redis + Lua for Atomicity

```
  RACE CONDITION WITHOUT LUA:

    Server A: GET count → 9
    Server B: GET count → 9   (same value!)
    Server A: 9 < 10, INCR → 10, ALLOW
    Server B: 9 < 10, INCR → 11, ALLOW   ← Both allowed! Over limit.

  LUA SCRIPT: Entire logic runs atomically in Redis.
  No other command can interleave.

  FULL LUA SCRIPT — TOKEN BUCKET:

    local key = KEYS[1]
    local capacity = tonumber(ARGV[1])
    local rate = tonumber(ARGV[2])
    local now = tonumber(ARGV[3])
    local requested = tonumber(ARGV[4])   -- tokens to consume (usually 1)

    local data = redis.call('HMGET', key, 'tokens', 'last_refill')
    local tokens = tonumber(data[1]) or capacity
    local last_refill = tonumber(data[2]) or now

    local elapsed = now - last_refill
    tokens = math.min(capacity, tokens + elapsed * rate / 1000)  -- rate per ms

    if tokens >= requested then
      tokens = tokens - requested
      redis.call('HMSET', key, 'tokens', tokens, 'last_refill', now)
      redis.call('EXPIRE', key, 60)  -- Cleanup
      return {1, tokens}   -- ALLOW, remaining tokens
    else
      return {0, tokens}   -- DENY
    end
```

### Redis Cluster Considerations

```
  REDIS CLUSTER: Keys hashed to slots, slots to nodes.

    Key "ratelimit:user:123" → slot 12345 → Node B
    Key "ratelimit:user:456" → slot 67890 → Node C

  LUA CONSTRAINT: All keys in script must hash to SAME slot.
    Use hash tags: "ratelimit:{user:123}" → slot from "user:123"
    Ensures user's rate limit data stays on one node.

  CROSS-SLOT ERROR: If Lua touches keys on different nodes → error.
```

### Latency

```
  COST PER REQUEST:
    One Redis round-trip: ~0.5-2 ms (same datacenter)
    Lua execution: ~0.1 ms
    Total: ~1-3 ms added to every API request

  MITIGATION:
    - Redis on same network as API servers
    - Connection pooling to Redis
    - Consider local cache with sync (eventual consistency)
```

---

## 7. Rate Limiting at Different Layers

```
RATE LIMIT SCOPES:

  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Scope               │ Key / Identifier                                 │
  ├────────────────────┼──────────────────────────────────────────────────┤
  │ Per-IP              │ Client IP (X-Forwarded-For, or connection IP)   │
  │ Per-user            │ user_id from auth (JWT, session)                 │
  │ Per-API-key         │ API key from header/query                        │
  │ Per-endpoint        │ method + path (e.g., POST /api/orders)           │
  │ Global              │ Single counter for entire API                   │
  └────────────────────┴──────────────────────────────────────────────────┘

  COMBINED KEY: "ratelimit:ip:1.2.3.4:path:/api/orders"
  Multiple limits can apply: 100/min per IP, 1000/min per user.
```

### API Gateway Implementation

```
  KONG:
    plugins: rate-limiting (per consumer, per IP, per credential)
    Uses Redis or local storage
    Config: minute=100, hour=10000

  NGINX (limit_req module — leaky bucket):

    limit_req_zone $binary_remote_addr zone=api:10m rate=10r/s;
    # 10m = 10 MB shared memory for ~160k IPs
    # rate=10r/s = 10 requests per second (leaky bucket)

    location /api/ {
      limit_req zone=api burst=20 nodelay;
      # burst=20: queue up to 20 excess requests
      # nodelay: drain immediately (no delay), else queue adds latency
    }

  NGINX INTERNALS:
    Each $binary_remote_addr gets a leaky bucket
    Shared memory: key → (last_request_time, queue_size)
    On request: check if 1/rate seconds passed since last drain
```

### Response Headers

```
  STANDARD RATE LIMIT HEADERS (draft RFC):

    X-RateLimit-Limit: 100        # Max requests per window
    X-RateLimit-Remaining: 95     # Left in current window
    X-RateLimit-Reset: 1710345660 # Unix timestamp when window resets
    Retry-After: 42               # Seconds to wait (when 429)

  EXAMPLE 429 RESPONSE:

    HTTP/1.1 429 Too Many Requests
    X-RateLimit-Limit: 100
    X-RateLimit-Remaining: 0
    X-RateLimit-Reset: 1710345660
    Retry-After: 45
    Content-Type: application/json

    {"error": "rate_limit_exceeded", "retry_after": 45}
```

---

## 8. Rate Limiting in Distributed Systems

```
  LOCAL vs GLOBAL:

  ┌─────────────────────────────────────────────────────────────────────┐
  │                                                                     │
  │   LOCAL (per server):                                               │
  │   Each API server has its own counter                               │
  │   Limit 100/min with 10 servers → effectively 1000/min total        │
  │   Pro: No Redis, low latency                                        │
  │   Con: Inconsistent, user can hit each server for 100              │
  │                                                                     │
  │   GLOBAL (centralized):                                             │
  │   All servers share Redis (or similar)                              │
  │   Limit 100/min = true 100/min across all servers                  │
  │   Pro: Accurate, fair                                               │
  │   Con: Redis latency, single point of failure                       │
  │                                                                     │
  └─────────────────────────────────────────────────────────────────────┘
```

### Race Conditions with Multiple Servers

```
  RACE: Two servers process same user's request simultaneously.

  Without atomicity:
    Server A: read count=99, allow, write 100
    Server B: read count=99 (before A writes), allow, write 100
    Result: 101 requests allowed (over limit)

  With Redis + Lua: Atomic read-modify-write → no race.
```

### Eventual Consistency Approach

```
  LOCAL COUNTERS + PERIODIC SYNC:

    Each server: local counter, sync to Redis every N seconds
    Redis: aggregates, checks global limit
    If over limit: broadcast "throttle user X" to servers

  Trade-off: Window of inconsistency (sync interval).
  Use when: Slightly over limit is acceptable (e.g., 105 vs 100).
```

### Trade-offs Summary

```
  ┌────────────────────┬──────────────┬──────────────┬──────────────────┐
  │ Approach           │ Accuracy     │ Latency      │ Complexity       │
  ├────────────────────┼──────────────┼──────────────┼──────────────────┤
  │ Local only         │ Poor (N×limit)│ None        │ Low              │
  │ Redis + Lua        │ Exact        │ 1-3 ms       │ Medium           │
  │ Local + sync       │ Approximate  │ Low          │ High             │
  │ Consistent hash    │ Per-shard    │ Medium       │ Medium           │
  └────────────────────┴──────────────┴──────────────┴──────────────────┘
```

---

## 30-SECOND REVISION BOX

```
TOKEN BUCKET: tokens, capacity, refill_rate, last_refill; refill = elapsed×rate capped;
  CAS for lock-free; allows bursts.
LEAKY BUCKET: FIFO queue, fixed drain rate, smooths traffic; O(n) memory.
FIXED WINDOW: counter per window, hash map; boundary burst = 2× limit; Redis INCR+EXPIRE.
SLIDING LOG: store every timestamp; ZADD+ZRANGEBYSCORE+ZCARD; O(n) memory, exact.
SLIDING COUNTER: count = current + previous×overlap_fraction; O(1), good accuracy.
REDIS+LUA: atomic ops, no race; hash tags for cluster; ~1-3ms per request.
LAYERS: per-IP, per-user, per-key, per-endpoint, global; Kong, nginx limit_req.
HEADERS: X-RateLimit-Limit, Remaining, Reset, Retry-After.
DISTRIBUTED: local (fast, inaccurate) vs global (Redis, exact); Lua prevents races.
```

---

**Prev: [[13_Internals-gRPC-HTTP2-Streaming]] | Next: [[15_Internals-Auth-JWT-OAuth-Crypto]]**
