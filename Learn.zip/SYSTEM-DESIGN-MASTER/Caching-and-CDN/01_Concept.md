# Caching and CDN — Concept

> **Permanent Recall:** Caching stores a copy of data in a faster, closer location so future requests avoid expensive lookups. The cache hierarchy spans L1/L2 (CPU) → App Cache (Redis/Memcached) → Distributed Cache → CDN. Choose strategy by read/write pattern: Cache-Aside for reads, Write-Through for consistency, Write-Behind for write-heavy. CDNs replicate static/dynamic content at edge POPs to reduce latency and offload origin. Cache invalidation and eviction policies are the two hardest problems in caching.

---

## What Is Caching?

**Caching** is storing a copy of frequently accessed data in a faster storage layer so subsequent requests can be served without going to the slower source (database, API, disk). The trade-off: **stale data risk** vs **latency and load reduction**.

```
                    REQUEST FLOW
                         │
    ┌────────────────────┼────────────────────┐
    │                    ▼                    │
    │  ┌──────────────┐     ┌──────────────┐  │
    │  │ Cache (fast)  │ ──► │ Return data  │  │  HIT
    │  │ Redis/Memory  │     │ ~1ms         │  │
    │  └──────────────┘     └──────────────┘  │
    │         │                               │
    │         │ MISS                           │
    │         ▼                               │
    │  ┌──────────────┐     ┌──────────────┐  │
    │  │ Database     │ ──► │ Fetch, cache,│  │  MISS
    │  │ (slow)       │     │ return ~50ms │  │
    │  └──────────────┘     └──────────────┘  │
    │                                        │
    └────────────────────────────────────────┘
```

> **FAANG Tip:** "Cache is a lie" — cached data can be stale. Design with invalidation in mind from day one.

---

## Cache Hierarchy (L1 → L2 → App → Distributed → CDN)

| Level | Location | Latency | Typical Size | Example |
|-------|----------|---------|--------------|---------|
| **L1 Cache** | CPU core | ~1 ns | 32–64 KB | On-chip instruction/data cache |
| **L2 Cache** | CPU core/shared | ~3–10 ns | 256 KB–1 MB | Per-core cache |
| **L3 Cache** | CPU shared | ~40–75 ns | 8–64 MB | Shared across cores |
| **App Cache** | Application memory | ~100 ns–1 µs | MB–GB | In-process `HashMap`, local Redis |
| **Distributed Cache** | Network | ~1–5 ms | GB–TB | Redis cluster, Memcached pool |
| **CDN Edge** | Edge POPs | ~20–50 ms | Petabytes | CloudFront, Cloudflare, Akamai |
| **Database** | Disk/SSD | ~5–50 ms | Unlimited | PostgreSQL, MySQL |

```
                    SPEED vs SIZE
    Fast │ L1 ─ L2 ─ L3 ─ App ─ Distributed ─ CDN ─ DB
         │  ◄── Smaller  ────────────────► Larger
         │  ◄── Closer  ─────────────────► Farther
         ▼
    Slow
```

---

## Caching Strategies

### 1. Cache-Aside (Lazy Loading)

**App checks cache first. On miss: fetch from DB, populate cache, return.**

```
READ FLOW (Cache-Aside):
┌──────┐     GET key      ┌────────┐
│ App  │ ───────────────► │ Cache  │
└──────┘                  └────────┘
     │                          │
     │    MISS                   │
     │ ◄────────────────────────┘
     │
     │  SELECT * FROM ...
     ▼
┌──────────┐
│ Database │
└──────────┘
     │
     │  App: cache.set(key, value)
     ▼
┌────────┐
│ Cache  │  (populated for next request)
└────────┘
```

### 2. Read-Through

**Cache sits in front of DB. App talks only to cache. Cache loads from DB on miss.**

```
READ FLOW (Read-Through):
┌──────┐     GET key      ┌─────────────────┐
│ App  │ ───────────────► │ Cache + Loader   │
└──────┘                  │ (owns DB logic)  │
     │                    └────────┬────────┘
     │                             │ MISS
     │                             ▼
     │                    ┌──────────────┐
     │                    │ Database     │
     │                    └──────────────┘
     │                             │
     │ ◄───────────────────────────┘
```

### 3. Write-Through

**Every write goes to cache and DB synchronously. Cache always consistent.**

```
WRITE FLOW (Write-Through):
┌──────┐  SET key,val   ┌────────┐
│ App  │ ─────────────► │ Cache  │
└──────┘                └───┬────┘
                            │ (sync write)
                            ▼
                     ┌──────────────┐
                     │ Database     │
                     └──────────────┘
                            │
                            │ return after both complete
                            ▼
                     ┌────────┐
                     │  App   │ ◄─── Response
                     └────────┘
```

### 4. Write-Behind (Write-Back)

**Write goes to cache only. Async batch flush to DB. Fast writes, risk of data loss.**

```
WRITE FLOW (Write-Behind):
┌──────┐  SET key,val   ┌────────┐
│ App  │ ─────────────► │ Cache  │ ──► Return immediately
└──────┘                └───┬────┘
                            │ (async, batched)
                            ▼
                     ┌──────────────┐
                     │ Database     │  (eventual)
                     └──────────────┘
```

### 5. Write-Around

**Writes go directly to DB, bypass cache. Reads populate cache.**

```
WRITE FLOW (Write-Around):
┌──────┐  Write        ┌──────────────┐
│ App  │ ────────────► │ Database     │  (bypass cache)
└──────┘               └──────────────┘

READ FLOW: Cache-Aside (miss → DB → cache)
```

---

## Strategy Comparison Table

| Strategy | Read Miss | Write | Consistency | Use Case | Complexity |
|----------|-----------|-------|-------------|----------|------------|
| **Cache-Aside** | App loads from DB | App writes DB, invalidates cache | Eventual | Default, read-heavy | Low |
| **Read-Through** | Cache loads from DB | Usually write-through | Strong (if write-through) | Simplify app logic | Medium |
| **Write-Through** | Same as above | Sync to cache + DB | Strong | Strong consistency required | Medium |
| **Write-Behind** | Same | Async to DB | Eventual | Write-heavy, tolerant of loss | High |
| **Write-Around** | Populate on read | Direct to DB | Eventual | Write-heavy, rare reads | Low |

---

## Eviction Policies

| Policy | Description | Pros | Cons | Best For |
|--------|-------------|------|------|----------|
| **LRU** (Least Recently Used) | Evict least recently accessed | Hot data stays | Scan can evict hot | General purpose |
| **LFU** (Least Frequently Used) | Evict least frequently accessed | Popular items stay | Stale hot items linger | Skewed popularity |
| **FIFO** | Evict oldest inserted | Simple, O(1) | Poor hit ratio | Queues, logs |
| **TTL** (Time To Live) | Expire after duration | Freshness guarantee | May evict still-hot data | Time-sensitive data |
| **Random** | Evict random entry | No bias, simple | Unpredictable | Redis `maxmemory-policy` option |

> **FAANG Tip:** LRU is the default choice. LFU for "viral" content. TTL is mandatory for any cache—never cache forever.

---

## Redis vs Memcached

| Aspect | Redis | Memcached |
|--------|-------|-----------|
| **Data structures** | Strings, lists, sets, hashes, sorted sets | Key-value only |
| **Persistence** | Optional (RDB, AOF) | No persistence |
| **Replication** | Master-replica | None |
| **Transactions** | Lua, MULTI/EXEC | No |
| **Single-threaded** | Yes (except modules) | No (multi-threaded) |
| **Use case** | Sessions, leaderboards, pub/sub, queues | Simple caching only |
| **Memory** | More flexible | Simpler |

> **FAANG Tip:** Use Redis when you need structures, persistence, or pub/sub. Use Memcached for raw key-value cache at scale.

---

## Distributed Caching: Consistent Hashing

**Problem:** Adding/removing cache nodes invalidates many keys (modulo hashing).

**Solution:** Consistent hashing maps keys to a ring. Adding a node affects only adjacent keys.

```
        CONSISTENT HASH RING
              ┌─────┐
           N1 ╱       ╲ N3
             ╱    ●    ╲
            │  key K   │
             ╲    ●    ╱
           N2 ╲       ╱ N4
              └─────┘

Key hashes to position on ring → assigned to next node clockwise.
Adding N5 affects only keys between N4 and N5.
```

| Approach | Rehashing on node add | Key distribution |
|----------|------------------------|-------------------|
| Modulo hashing | ~K/N keys move | Poor (skew possible) |
| Consistent hashing | ~K/N keys move (only to new node) | Good with virtual nodes |

---

## Cache Invalidation Approaches

| Approach | When to Invalidate | Pros | Cons |
|----------|-------------------|------|------|
| **TTL only** | After expiry time | Simple, no logic | May serve stale data up to TTL |
| **Event-based** | On DB write / message | Fresh | Complex, must handle all write paths |
| **Version/ETag** | If version mismatch | Conditional revalidation | Extra round-trip on stale |
| **Explicit delete** | On known write | Precise | Easy to forget, bug-prone |
| **Write-through** | On every write | Always fresh | Write latency = DB latency |

> **FAANG Tip:** "There are only two hard things in CS: cache invalidation and naming things." Combine TTL (safety net) with event-based invalidation (freshness).

---

## What Is CDN?

**Content Delivery Network (CDN)** is a geographically distributed network of edge servers (POPs) that cache content closer to users. First request hits origin; subsequent requests served from edge.

```
    USER (Mumbai)                    USER (Tokyo)
         │                                │
         │  Request image.jpg             │  Request image.jpg
         ▼                                ▼
    ┌─────────┐                      ┌─────────┐
    │ POP Mumbai│                    │ POP Tokyo │
    │ (edge)   │                    │ (edge)   │
    └────┬────┘                     └────┬────┘
         │  HIT: serve from cache        │  HIT: serve from cache
         │  MISS: fetch from origin      │  MISS: fetch from origin
         │                                │
         └────────────┬──────────────────┘
                      ▼
               ┌──────────────┐
               │   ORIGIN     │
               │ (your server)│
               └──────────────┘
```

---

## Push vs Pull CDN

| Type | How It Works | Use Case |
|------|--------------|----------|
| **Pull (Origin-Pull)** | First request → origin → cache at edge | Default. Static assets, APIs |
| **Push (Origin-Push)** | You upload to CDN before requests | Pre-release content, large files |

```
PULL CDN:  User → Edge (miss) → Origin → Cache → User
PUSH CDN:  You → Upload to CDN → User → Edge (hit)
```

---

## CDN for Static vs Dynamic Content

| Content Type | Cached? | TTL | Example |
|--------------|---------|-----|---------|
| **Static** | Yes, long TTL | Hours–days | JS, CSS, images, fonts |
| **Dynamic** | Optional, short TTL | Seconds–minutes | API responses, personalized |
| **Semi-dynamic** | Yes, medium TTL | Minutes | Product catalog, CDN-cached APIs |

> **FAANG Tip:** "If the response is the same for most users → CDN." "If personalized but repeated → app cache."

---

## CDN Cache Invalidation

| Method | Use When |
|--------|----------|
| **Purge (invalidation)** | Emergency, fix bad content |
| **TTL expiry** | Normal refresh cycle |
| **Cache key versioning** | `styles.v2.css` — new URL = new cache |
| **Surrogate keys** | Tag objects; purge by tag (e.g., all product pages) |

---

## 30-SECOND REVISION BOX

```
CACHE HIERARCHY: L1→L2→App→Distributed→CDN→DB
STRATEGIES: Cache-Aside (default), Read-Through, Write-Through, Write-Behind, Write-Around
EVICTION: LRU (general), LFU (popularity), TTL (mandatory)
REDIS: structures, persistence, pub/sub | MEMCACHED: simple K-V
CONSISTENT HASHING: ring, minimizes rehash on node add/remove
CDN: edge POPs, pull (default) vs push, static (long TTL) vs dynamic (short)
```

---

**Next: [[02_Mental-Model]]**
