# Caching and CDN — Design Template

> **Permanent Recall:** Reusable caching patterns: application-level (in-process), distributed (Redis cluster), multi-layer (L1 + L2), CDN + origin, and cache warming. Cache-Aside is the default implementation; Write-Through when strong consistency is required. Each pattern has a clear architecture, config examples, and "when to use" criteria. Always include TTL, monitoring, and failure handling in your templates.

---

## Pattern 1: Application-Level Cache Template

**When to use:** Single-server or small deployment. Hot data per process. Low latency critical.

```
ARCHITECTURE:

┌─────────────────────────────────────────────────┐
│              Application Server                  │
│  ┌─────────────┐      ┌─────────────────────┐  │
│  │ In-Process  │      │   Business Logic     │  │
│  │ Cache       │◄────►│   (checks cache      │  │
│  │ (HashMap,   │      │    before DB)        │  │
│  │  Caffeine)  │      └──────────┬──────────┘  │
│  └─────────────┘                 │             │
└─────────────────────────────────┼─────────────┘
                                  ▼
                         ┌────────────────┐
                         │   Database      │
                         └────────────────┘
```

**Config example (conceptual):**
```yaml
cache:
  type: in-memory
  max_size: 10000
  ttl_seconds: 300
  eviction: LRU
```

**Pros:** No network hop, sub-millisecond. **Cons:** Not shared across instances, memory per process.

---

## Pattern 2: Distributed Cache Template (Redis Cluster)

**When to use:** Multiple app servers, shared state (sessions, API cache), horizontal scale.

```
ARCHITECTURE:

┌──────────┐ ┌──────────┐ ┌──────────┐
│ App Svr 1│ │ App Svr 2│ │ App Svr N│
└────┬─────┘ └────┬─────┘ └────┬─────┘
     │            │            │
     └────────────┼────────────┘
                  │
         ┌────────┴────────┐
         │  Redis Cluster   │
         │  (sharded)       │
         │  ┌───┐ ┌───┐ ┌───┐│
         │  │M1 │ │M2 │ │M3 ││
         │  └─┬─┘ └─┬─┘ └─┬─┘│
         │    │ R1  │ R2  │ R3
         │  ┌─┴─┐ ┌─┴─┐ ┌─┴─┐│
         │  │   │ │   │ │   ││
         │  └───┘ └───┘ └───┘│
         └────────┬─────────┘
                  │
         ┌────────┴────────┐
         │   Database      │
         └─────────────────┘
```

**Config example:**
```yaml
redis:
  cluster: true
  nodes: ["redis-1:6379", "redis-2:6379", "redis-3:6379"]
  password: ${REDIS_PASSWORD}
  ttl_default: 3600
  max_retries: 3
```

**When to use:** Sessions, shared API cache, rate limiting, pub/sub.

---

## Pattern 3: Multi-Layer Caching Template

**When to use:** Very high QPS, need to reduce both latency and Redis load.

```
ARCHITECTURE:

┌─────────────────────────────────────────────────────────┐
│                    Request                                │
└─────────────────────────┬───────────────────────────────┘
                          ▼
                 ┌────────────────┐
                 │ L1: Local Cache │  (in-process, ~1ms)
                 │ Caffeine/Guava  │
                 └────────┬────────┘
                          │ MISS
                          ▼
                 ┌────────────────┐
                 │ L2: Redis       │  (network, ~2ms)
                 │ Distributed    │
                 └────────┬────────┘
                          │ MISS
                          ▼
                 ┌────────────────┐
                 │ Database       │
                 └────────────────┘
```

**Config example:**
```yaml
cache_l1:
  max_size: 1000
  ttl_seconds: 60
cache_l2:
  redis_url: redis://cluster:6379
  ttl_seconds: 3600
# L1 << L2 in size. L1 = hottest of hot.
```

**When to use:** Read-heavy, single key hit by many requests (e.g., trending post).

---

## Pattern 4: CDN + Origin Server Template

**When to use:** Static assets, globally distributed users, reduce origin load.

```
ARCHITECTURE:

    User (Mumbai)     User (Tokyo)     User (NYC)
          │                │                │
          ▼                ▼                ▼
    ┌──────────┐     ┌──────────┐     ┌──────────┐
    │ POP      │     │ POP      │     │ POP      │
    │ Mumbai   │     │ Tokyo    │     │ NYC      │
    └────┬─────┘     └────┬─────┘     └────┬─────┘
         │  MISS          │  MISS          │  MISS
         └────────────────┼────────────────┘
                          ▼
                 ┌────────────────┐
                 │ Origin Server  │
                 │ / Load Balancer│
                 └────────┬───────┘
                          │
                 ┌────────┴────────┐
                 │ Object Storage  │  (S3, GCS)
                 │ or App Server   │
                 └─────────────────┘
```

**Config example (CloudFront-style):**
```
Cache behavior:
  Path: /static/*
  TTL: 86400 (24h)
  Compress: true
Origin: s3://my-bucket or https://api.example.com
```

**When to use:** Static assets, API responses same for all users.

---

## Pattern 5: Cache Warming Template

**When to use:** Cold start, predictable hot keys, avoid stampede after restart.

```
ARCHITECTURE:

┌────────────────────────────────────────────────────────┐
│  Startup / Scheduled Job                                │
│                                                         │
│  1. Fetch list of hot keys (e.g., top 10K products)     │
│  2. Preload from DB → write to cache                    │
│  3. Optional: background refresh before TTL             │
└────────────────────────────────────────────────────────┘
```

**Pseudocode:**
```python
def warm_cache():
    hot_keys = get_top_accessed_keys_from_analytics()  # or static list
    for key in hot_keys:
        value = db.get(key)
        cache.set(key, value, ttl=3600)
```

**When to use:** After deploy, after cache cluster restart, before known traffic spike.

---

## Pattern 6: Cache-Aside Implementation Example

```
FLOW:

1. GET key
2. cache.get(key)
   - HIT  → return value
   - MISS → db.get(key) → cache.set(key, value, ttl) → return value

3. PUT key, value
   - db.put(key, value)
   - cache.delete(key)  // or cache.set() for write-through
```

**Key points:**
- App owns cache logic
- Always set TTL on write
- Invalidate or update on write
- Handle DB failure (don't cache errors)

---

## Pattern 7: Write-Through Implementation Example

```
FLOW:

1. GET key
   - cache.get(key) → HIT return
   - MISS → (cache layer fetches from DB, stores, returns)

2. PUT key, value
   - cache.set(key, value)  // cache synchronously writes to DB
   - return after both complete
```

**When to use:** Strong consistency, cache provider supports it (e.g., read-through + write-through combo).

---

## Pattern Comparison

| Pattern | Latency | Consistency | Complexity | Scale |
|---------|---------|-------------|------------|-------|
| **App-level** | Lowest | Per-process | Low | Single/small |
| **Distributed** | Low | Eventual | Medium | Horizontal |
| **Multi-layer** | Lowest | Eventual | High | Very high QPS |
| **CDN + Origin** | Edge-dependent | TTL-based | Medium | Global |
| **Cache Warming** | N/A (auxiliary) | N/A | Low | Any |

> **FAANG Tip:** Start with Cache-Aside + Redis. Add L1 only when Redis becomes bottleneck. Add CDN for static/global content.

---

## 30-SECOND REVISION BOX

```
APP CACHE = in-process, single server
DISTRIBUTED = Redis cluster, shared across servers
MULTI-LAYER = L1 (local) + L2 (Redis) for hot keys
CDN + ORIGIN = edge POPs + origin for static/global
CACHE WARMING = preload hot keys on start/restart
CACHE-ASIDE = app checks cache, loads on miss
WRITE-THROUGH = sync write to cache + DB
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
