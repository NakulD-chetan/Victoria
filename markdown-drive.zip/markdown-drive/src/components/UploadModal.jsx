import { useState, useRef, useCallback, memo } from 'react';
import { getAuthHeaders } from './AuthGate';
import { storageService } from '../firebase';

function flattenFolders(tree, result = []) {
  for (const f of tree) {
    result.push({ name: f.name, path: f.path || f.name });
    if (f.children?.length) flattenFolders(f.children, result);
  }
  return result;
}

const UploadModal = memo(function UploadModal({ folders, onClose, onComplete, userId }) {
  const flatFolders = flattenFolders(folders);
  const [selectedFolder, setSelectedFolder] = useState(flatFolders[0]?.path || 'General');
  const [newFolderName, setNewFolderName] = useState('');
  const [useNewFolder, setUseNewFolder] = useState(folders.length === 0);
  const [files, setFiles] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadTarget, setUploadTarget] = useState('server');
  const [progress, setProgress] = useState({ done: 0, total: 0, current: '' });
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const handleFiles = useCallback((fileList) => {
    const accepted = Array.from(fileList).filter(f =>
      /\.(md|markdown|txt|mdx|zip)$/i.test(f.name)
    );
    if (accepted.length === 0 && fileList.length > 0) {
      setError('Only .md, .markdown, .txt, .mdx, .zip files are supported');
      setTimeout(() => setError(null), 3000);
      return;
    }
    setFiles(prev => [...prev, ...accepted]);
    setError(null);
  }, []);

  const handleDrop = useCallback((e) => {
    e.preventDefault();
    setDragOver(false);
    handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  const handleUploadToServer = useCallback(async (folder) => {
    const mdFiles = files.filter(f => !f.name.toLowerCase().endsWith('.zip'));
    const zipFiles = files.filter(f => f.name.toLowerCase().endsWith('.zip'));

    let done = 0;
    if (mdFiles.length > 0) {
      const formData = new FormData();
      formData.append('folder', folder);
      for (const file of mdFiles) formData.append('files', file);
      setProgress({ done, total: files.length, current: `Uploading ${mdFiles.length} files...` });
      await fetch('/api/upload', { method: 'POST', headers: getAuthHeaders(), body: formData });
      done += mdFiles.length;
      setProgress({ done, total: files.length, current: '' });
    }
    for (const zip of zipFiles) {
      setProgress({ done, total: files.length, current: `Extracting ${zip.name}...` });
      const formData = new FormData();
      formData.append('folder', folder);
      formData.append('file', zip);
      await fetch('/api/upload-zip', { method: 'POST', headers: getAuthHeaders(), body: formData });
      done++;
      setProgress({ done, total: files.length, current: '' });
    }
  }, [files]);

  const handleUploadToSupabase = useCallback(async (folder) => {
    const uid = userId;
    if (!uid) {
      setError('You must be logged in to upload to cloud storage');
      setUploading(false);
      return;
    }

    let done = 0;
    for (const file of files) {
      setProgress({ done, total: files.length, current: file.name });
      try {
        if (file.name.toLowerCase().endsWith('.zip')) {
          const formData = new FormData();
          formData.append('folder', folder);
          formData.append('file', file);
          await fetch('/api/upload-zip', { method: 'POST', headers: getAuthHeaders(), body: formData });
        } else {
          const text = await file.text();
          await storageService.uploadFile(uid, folder, file.name, text);
        }
      } catch (err) {
        console.error(`Failed to upload ${file.name}:`, err);
        setError(`Failed to upload ${file.name}`);
      }
      done++;
      setProgress({ done, total: files.length, current: '' });
    }
  }, [files, userId]);

  const handleUpload = useCallback(async () => {
    if (files.length === 0) return;
    setUploading(true);
    setError(null);
    setProgress({ done: 0, total: files.length, current: '' });

    const folder = useNewFolder ? (newFolderName.trim() || 'General') : selectedFolder;

    try {
      if (uploadTarget === 'supabase') {
        await handleUploadToSupabase(folder);
      } else {
        await handleUploadToServer(folder);
      }
      onComplete();
    } catch (err) {
      console.error('Upload failed:', err);
      setError('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  }, [files, useNewFolder, newFolderName, selectedFolder, uploadTarget, onComplete, handleUploadToServer, handleUploadToSupabase]);

  const removeFile = useCallback((index) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  }, []);

  const clearFiles = useCallback(() => setFiles([]), []);

  const pct = progress.total > 0 ? Math.round((progress.done / progress.total) * 100) : 0;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="upload-modal" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="upload-modal__header">
          <div className="upload-modal__header-left">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            <h2>Upload Files</h2>
          </div>
          <button className="upload-modal__close" onClick={onClose}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className="upload-modal__body">
          {/* Upload target toggle */}
          <div className="upload-modal__target">
            <span className="upload-modal__label">Upload to</span>
            <div className="upload-modal__target-btns">
              <button
                className={`upload-modal__target-btn ${uploadTarget === 'server' ? 'upload-modal__target-btn--active' : ''}`}
                onClick={() => setUploadTarget('server')}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
                  <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
                  <line x1="6" y1="6" x2="6.01" y2="6" />
                  <line x1="6" y1="18" x2="6.01" y2="18" />
                </svg>
                Server
              </button>
              <button
                className={`upload-modal__target-btn ${uploadTarget === 'supabase' ? 'upload-modal__target-btn--active' : ''}`}
                onClick={() => setUploadTarget('supabase')}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
                </svg>
                Cloud (Supabase)
              </button>
            </div>
          </div>

          {/* Folder selection */}
          <div className="upload-modal__section">
            <span className="upload-modal__label">Destination folder</span>
            <div className="upload-modal__folder-opts">
              {folders.length > 0 && (
                <label className="upload-modal__radio">
                  <input type="radio" checked={!useNewFolder} onChange={() => setUseNewFolder(false)} />
                  <select
                    value={selectedFolder}
                    onChange={e => setSelectedFolder(e.target.value)}
                    disabled={useNewFolder}
                    className="upload-modal__select"
                  >
                    {flatFolders.map(f => (
                      <option key={f.path} value={f.path}>{f.path}</option>
                    ))}
                  </select>
                </label>
              )}
              <label className="upload-modal__radio">
                <input type="radio" checked={useNewFolder} onChange={() => setUseNewFolder(true)} />
                <input
                  type="text"
                  placeholder="New folder name..."
                  value={newFolderName}
                  onChange={e => setNewFolderName(e.target.value)}
                  disabled={!useNewFolder}
                  className="upload-modal__input"
                />
              </label>
            </div>
          </div>

          {/* Dropzone */}
          <div
            className={`upload-modal__dropzone ${dragOver ? 'upload-modal__dropzone--active' : ''}`}
            onDragOver={e => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".md,.markdown,.txt,.mdx,.zip"
              onChange={e => handleFiles(e.target.files)}
              hidden
            />
            <div className="upload-modal__dropzone-icon">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="17 8 12 3 7 8" />
                <line x1="12" y1="3" x2="12" y2="15" />
              </svg>
            </div>
            <p className="upload-modal__dropzone-title">Drop files here or click to browse</p>
            <span className="upload-modal__dropzone-hint">.md, .markdown, .txt, .mdx, .zip</span>
          </div>

          {/* Error */}
          {error && (
            <div className="upload-modal__error">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="15" y1="9" x2="9" y2="15" /><line x1="9" y1="9" x2="15" y2="15" />
              </svg>
              {error}
            </div>
          )}

          {/* File list */}
          {files.length > 0 && (
            <div className="upload-modal__files">
              <div className="upload-modal__files-header">
                <span>{files.length} file{files.length !== 1 ? 's' : ''} selected</span>
                <button className="upload-modal__clear" onClick={clearFiles}>Clear all</button>
              </div>
              <div className="upload-modal__files-list">
                {files.map((file, i) => (
                  <div key={i} className="upload-modal__file">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <polyline points="14 2 14 8 20 8" />
                    </svg>
                    <span className="upload-modal__file-name">{file.name}</span>
                    <span className="upload-modal__file-size">{(file.size / 1024).toFixed(1)} KB</span>
                    <button className="upload-modal__file-remove" onClick={() => removeFile(i)}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Progress */}
          {uploading && (
            <div className="upload-modal__progress">
              <div className="upload-modal__progress-bar">
                <div className="upload-modal__progress-fill" style={{ width: `${pct}%` }} />
              </div>
              <div className="upload-modal__progress-info">
                <span>{progress.current || `${progress.done}/${progress.total} files`}</span>
                <span>{pct}%</span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="upload-modal__footer">
          <button className="upload-modal__btn upload-modal__btn--cancel" onClick={onClose} disabled={uploading}>
            Cancel
          </button>
          <button
            className="upload-modal__btn upload-modal__btn--upload"
            onClick={handleUpload}
            disabled={files.length === 0 || uploading}
          >
            {uploading ? (
              <><span className="upload-modal__spinner" /> Uploading...</>
            ) : (
              <>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                  <polyline points="17 8 12 3 7 8" />
                  <line x1="12" y1="3" x2="12" y2="15" />
                </svg>
                Upload {files.length} file{files.length !== 1 ? 's' : ''}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
});

export default UploadModal;
