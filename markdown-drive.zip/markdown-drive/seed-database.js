/**
 * Seed script: Reads hardcoded algorithm/problem data and inserts into Supabase PostgreSQL.
 * Run: node seed-database.js
 * Handles intermittent network issues with retries.
 */
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import { AlgorithmService } from './db-service.js';

async function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function withRetry(label, fn, maxRetries = 5) {
  for (let i = 1; i <= maxRetries; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === maxRetries) {
        console.log(`    FAILED after ${maxRetries} attempts: ${err.message}`);
        return null;
      }
      const delay = 1500 * i + Math.random() * 1000;
      console.log(`    Retry ${i}/${maxRetries} for ${label} (waiting ${Math.round(delay)}ms)...`);
      await sleep(delay);
    }
  }
}

async function seed() {
  const db = new AlgorithmService();
  console.log('Seeding database...\n');

  const { getAllAlgorithms, getAlgorithmBySlug } = await import('./src/lib/algorithms/registry.js');
  const { PROBLEMS } = await import('./src/lib/problems/problems-data.js');

  const allAlgos = getAllAlgorithms();
  console.log(`Found ${allAlgos.length} algorithms to seed.\n`);

  for (const meta of allAlgos) {
    const full = getAlgorithmBySlug(meta.slug);
    if (!full) { console.log(`  SKIP ${meta.slug} - not found in registry`); continue; }

    console.log(`  Seeding: ${meta.title} (${meta.slug})...`);

    const algoRow = await withRetry(`upsert ${meta.slug}`, () => db.upsertAlgorithm({
      slug: meta.slug,
      title: meta.title,
      category: meta.category,
      difficulty: meta.difficulty,
      short_description: meta.shortDescription,
      icon: meta.icon,
      color: meta.color || '#333',
      languages: meta.languages || [],
      tags: meta.tags || [],
      default_params: full.defaultParams || {},
      visualizer_key: meta.slug,
      sort_order: meta.id || 0,
      published: true,
    }));

    if (!algoRow) {
      console.log(`    Could not upsert algorithm ${meta.slug}, skipping content/code`);
      continue;
    }
    const algoId = algoRow.id;
    console.log(`    Algorithm id=${algoId}`);

    if (full.introEnglish) {
      const ok = await withRetry(`content-en ${meta.slug}`, () => db.upsertContent(algoId, 'en', full.introEnglish));
      console.log(`    English intro: ${ok ? 'OK' : 'FAILED'}`);
    }

    await sleep(500);

    if (full.introHinglish) {
      const ok = await withRetry(`content-hi ${meta.slug}`, () => db.upsertContent(algoId, 'hi', full.introHinglish));
      console.log(`    Hinglish intro: ${ok ? 'OK' : 'FAILED'}`);
    }

    for (const lang of (meta.languages || [])) {
      await sleep(500);
      const codeLines = full.code?.[lang] || [];
      const stepInfo = full.steps || {};
      const stepsAllow = full.stepsAllow || [];
      const stepsDeny = full.stepsDeny || full.stepsRelease || [];
      const ok = await withRetry(`code-${lang} ${meta.slug}`, () => db.upsertCode(algoId, lang, codeLines, stepInfo, stepsAllow, stepsDeny));
      console.log(`    Code (${lang}): ${ok ? 'OK' : 'FAILED'}`);
    }

    console.log(`    Done!\n`);
    await sleep(800);
  }

  console.log(`\nSeeding ${PROBLEMS.length} problems...\n`);
  for (const p of PROBLEMS) {
    console.log(`  Problem: ${p.title}...`);
    const result = await withRetry(`problem ${p.id}`, () => db.upsertProblem({
      slug: p.id,
      number: p.number,
      title: p.title,
      icon: p.icon,
      difficulty: p.difficulty,
      description: p.description,
      requirements: p.requirements || {},
      hints: p.hints || [],
      test_cases: p.testCases || [],
      constraints: p.constraints || [],
      requirement_checklist: p.requirementChecklist || {},
      expected_apis: p.expectedAPIs || [],
      chaos_scenarios: p.chaosScenarios || [],
      deep_dive_questions: p.deepDiveQuestions || [],
      scoring: p.scoring || { requirements: 20, api: 15, architecture: 40, deepDive: 25 },
      published: true,
    }));
    console.log(`    ${result ? 'OK (id=' + result.id + ')' : 'FAILED'}`);
    await sleep(500);
  }

  console.log('\n=== Seed complete! ===');

  console.log('\nVerifying data...');
  try {
    const algos = await db.listAlgorithms({ page: 1, limit: 200 });
    console.log(`  Algorithms in DB: ${algos.total || algos.data?.length || 0}`);
  } catch(e) { console.log(`  Could not verify algorithms: ${e.message}`); }

  try {
    const probs = await db.listProblems({ page: 1, limit: 200 });
    console.log(`  Problems in DB: ${probs.data?.length || 0}`);
  } catch(e) { console.log(`  Could not verify problems: ${e.message}`); }
}

seed().catch(err => { console.error('Seed failed:', err); process.exit(1); });
