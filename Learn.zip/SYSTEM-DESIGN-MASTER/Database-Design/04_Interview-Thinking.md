# Database Design — Interview Thinking (Deep Understanding)

> **Permanent Recall:** In system design interviews, database choice is a CRITICAL moment. Start with requirements (data model, consistency, scale, access patterns) before picking SQL vs NoSQL. Justify with trade-offs. Have ready answers for: SQL vs NoSQL, schema design, indexing, N+1, scaling, transactions, and isolation levels. Never say "it depends" without immediately saying HOW you'd decide.

---

## When to Bring Up Database Design (and What to Say)

### The Rule: Every System Needs a Database — Discuss It Proactively

| Interview Trigger | What to Say (with reasoning) |
|-------------------|------------------------------|
| "How do you store this data?" | *"We need to consider the data model — is it structured with relationships? Then PostgreSQL for ACID and JOINs. Is it flexible with varying fields? Then MongoDB. For caching hot data, we'd layer Redis in front."* |
| "How do you scale this?" | *"First, optimize queries with proper indexes. Then add read replicas for read scaling. Add Redis cache for hot data. Only if write volume exceeds one server's capacity do we shard — and we'd choose the shard key based on our primary access pattern."* |
| "Design a [URL shortener / chat / API]" | When you get to data storage: *"For the data layer, we need to choose the right database. The URL shortener needs fast key-value lookups — I'd use PostgreSQL as the source of truth with Redis as a read cache. The mapping is simple: short_code → original_url."* |
| "How do you ensure data consistency?" | *"We use PostgreSQL with ACID transactions. For the payment flow, we wrap the entire operation — debit, credit, order update — in a single transaction. If any step fails, everything rolls back."* |
| "This query is slow" | *"I'd run EXPLAIN ANALYZE to see the execution plan. Is it doing a sequential scan? Then we need an index on the WHERE columns. Is it a composite query? Then the index column order matters — equality columns first, then range, then sort."* |

---

## How Deep to Go — Read the Interviewer

| Depth | What to Cover | When to Use It |
|-------|---------------|----------------|
| **1-Line (Shallow)** | "We'd use PostgreSQL for structured data with ACID guarantees." | Quick mention; interviewer didn't ask for details |
| **3-Line (Medium)** | "PostgreSQL as the source of truth — it gives us ACID for the payment flow. Read replicas for scaling reads. Redis cache for session storage and hot data — sub-ms lookups." | Interviewer asks "what database and why?" |
| **Deep Dive** | Schema design, indexing strategy, replication setup, sharding approach, query optimization, connection pooling, isolation levels | Senior/architect roles; interviewer asks follow-up questions |

**Golden Rule:** Match the interviewer's interest. If they nod and move on after your 1-liner, don't go deeper. If they ask "how would you design the schema?", go to medium. If they keep asking, go deep.

---

## The Big Confusion: SQL vs NoSQL — How to Explain Clearly

### What Each One Does

```
SQL (RELATIONAL):
  - Tables with fixed schema (rows + columns)
  - Strong ACID guarantees (atomic transactions)
  - Native JOINs (combine data from multiple tables)
  - Scales vertically first; horizontal via sharding (complex)
  - Examples: PostgreSQL, MySQL, Oracle
  - Best for: Banking, e-commerce, any structured data with relationships

NoSQL (NON-RELATIONAL):
  - Multiple data models: key-value, document, column-family, graph
  - Flexible schema (each record can differ)
  - Horizontal scaling built-in (auto-partitioning)
  - Usually eventual consistency (BASE), some offer ACID per document
  - Examples: Redis, MongoDB, Cassandra, Neo4j
  - Best for: Caching, sessions, flexible data, massive write throughput
```

### The 10-Second Answer

*"SQL for structured data that needs ACID transactions and relationships — like payments, orders, and user accounts. NoSQL when you need horizontal scale, flexible schema, or specialized access patterns — like caching with Redis, IoT data with Cassandra, or social graphs with Neo4j. Most real systems use both."*

### The 30-Second Answer (with example)

*"I'd start with the access patterns. If the data is structured with clear relationships and we need transactions — like an e-commerce system with users, orders, and inventory — SQL is the default. PostgreSQL gives us ACID so we don't sell the same item twice.*

*For specific workloads, NoSQL makes sense: Redis for caching and sessions because it's sub-millisecond. Cassandra if we need massive write throughput like IoT sensor data. MongoDB if the schema varies widely — like a product catalog where phones have 'screen_size' but books have 'pages'.*

*In practice, most systems are polyglot — SQL as the source of truth, Redis for caching, maybe Elasticsearch for search."*

### The Whiteboard Table

| | SQL | NoSQL |
|---|------|-------|
| **Schema** | Fixed, enforced | Flexible, per-record |
| **Transactions** | Multi-table ACID | Single-document or limited |
| **JOINs** | Native, optimized | None (denormalize) |
| **Scaling** | Vertical → shard | Horizontal by design |
| **Consistency** | Strong (ACID) | Eventually consistent (BASE) |
| **Example** | PostgreSQL, MySQL | Redis, MongoDB, Cassandra |
| **Use** | Banking, e-commerce, ERP | Cache, sessions, IoT, feeds |

---

## How to Justify Your Database Choice

### The Framework: 4 Questions

```
1. "What's the data model?"
   Structured + relationships → SQL
   Flexible / varying → Document DB
   Key → value lookups → Key-Value
   Connected entities → Graph

2. "Do we need ACID?"
   Money, inventory, booking → YES → SQL
   Social feed, likes, views → NO → NoSQL acceptable

3. "What's the read/write ratio?"
   Read-heavy (100:1) → cache + denormalize
   Write-heavy (1:100) → column-family (Cassandra) or batching
   Balanced → standard SQL with indexes

4. "What's the scale?"
   <10K RPS → Single SQL is fine
   10K-100K RPS → SQL + replicas + cache
   >100K RPS writes → Sharding or NoSQL
```

### Justification Examples

| System | Choice | What to Say |
|--------|--------|-------------|
| **Payment system** | PostgreSQL | *"We need ACID for financial transactions. A payment must be atomic — debit and credit happen together or not at all. PostgreSQL gives us multi-row transactions with strong isolation."* |
| **User sessions** | Redis | *"Sessions are key-value lookups — 'give me the session for token abc123'. Redis does this in sub-millisecond. We set TTL for auto-expiry. No need for SQL's overhead here."* |
| **Product catalog** | MongoDB or PostgreSQL | *"If products have varying attributes — phones have screen_size, books have pages — MongoDB's flexible schema fits. If we need complex filtering and JOINs across categories, PostgreSQL with JSONB for flexible attributes."* |
| **Social feed** | SQL + Redis + Cassandra | *"PostgreSQL for user data (source of truth). Redis for caching the precomputed feed. If write volume for activity events is massive, Cassandra for the activity log."* |
| **Leaderboard** | Redis (ZADD) | *"Redis sorted sets give us O(log n) insert and O(1) rank lookup. ZADD to update score, ZRANK to get position, ZRANGE for top-N. Way faster than SQL ORDER BY on millions of rows."* |
| **Analytics dashboard** | BigQuery / Snowflake + SQL | *"Operational data in PostgreSQL. For analytics, we'd ETL to a columnar warehouse like BigQuery — optimized for aggregations on billions of rows."* |

---

## Common Database Interview Questions — Complete Answers

### Q1: "How would you design the schema for X?"

**Framework for answering:**

```
Step 1: Identify ENTITIES
  "The core entities are Users, Posts, Comments, and Likes"

Step 2: Identify RELATIONSHIPS
  "User has many Posts (1:N). Post has many Comments (1:N). User likes many Posts (M:N)."

Step 3: Choose SQL vs NoSQL
  "Structured data with relationships → PostgreSQL"

Step 4: Draft TABLES
  CREATE TABLE users (...)
  CREATE TABLE posts (...)
  CREATE TABLE comments (...)
  CREATE TABLE post_likes (...)

Step 5: Add INDEXES for top queries
  "The hot query is 'show user's feed (posts from followed users, newest first)'"
  "Index: (user_id, created_at DESC) on posts"

Step 6: Discuss SCALING if asked
  "Read replicas for read scaling. Redis cache for hot posts."
```

### Q2: "SQL vs NoSQL — when do you use which?"

**Complete Answer:**

*"I decide based on three axes: data structure, consistency requirements, and scale.*

*SQL when data is structured with clear relationships and we need ACID — payments, orders, user accounts. PostgreSQL is my default because it's the most capable open-source relational database — it has JSONB for semi-structured data, full-text search, and excellent performance.*

*NoSQL when we have specific access patterns that a specialized database handles better. Redis for anything key-value: caching, sessions, rate limiting, leaderboards. MongoDB when the schema varies per document. Cassandra when we need massive write throughput across data centers. Neo4j for graph traversals.*

*Most production systems use multiple databases — polyglot persistence. SQL as the source of truth, Redis for caching, maybe Elasticsearch for search. The key is matching the database to the workload."*

### Q3: "What's the N+1 problem?"

**Complete Answer:**

*"The N+1 problem is when you fetch a list of N items, then make a separate query for each item's related data — resulting in N+1 queries instead of 1 or 2.*

*Example: Fetch 100 orders, then loop through each order and query the user table for the user's name. That's 1 query for orders + 100 queries for users = 101 queries. At 100ms per query, that's 10 seconds.*

*Fix option 1: JOIN — `SELECT o.*, u.name FROM orders o JOIN users u ON o.user_id = u.id`. One query.*

*Fix option 2: Batch fetch — `SELECT * FROM users WHERE id IN (1, 2, 3, ...)`. Two queries total instead of 101.*

*ORMs like Django, Rails, SQLAlchemy often cause N+1 by default. The fix is eager loading (Rails: `includes`, Django: `select_related`, SQLAlchemy: `joinedload`)."*

### Q4: "How do you optimize a slow query?"

**Complete Answer:**

*"First, I'd run EXPLAIN ANALYZE to see the query execution plan.*

*Common findings and fixes:*

1. *Sequential Scan on a large table → Add an index on the WHERE/JOIN columns*
2. *Index exists but not used → Check if the query's column order matches the index's leftmost prefix. Or statistics are stale — run ANALYZE.*
3. *Fetching too many columns → SELECT only needed columns. Consider a covering index.*
4. *OFFSET pagination → Switch to cursor-based: `WHERE id > last_seen_id LIMIT 20`*
5. *N+1 queries → JOIN or batch fetch*
6. *Expensive aggregation → Pre-compute with materialized view or denormalize a counter column*
7. *Table too large → Partition by date or range. Archive old data.*

*After each change, re-run EXPLAIN ANALYZE to verify the improvement."*

### Q5: "How do you handle database scaling?"

**Complete Answer:**

*"I follow a progression — each step adds complexity, so I go as far as needed but no further:*

*Step 1: Optimize what you have — proper indexes, fix N+1 queries, connection pooling. This alone can give 10× improvement.*

*Step 2: Vertical scaling — bigger machine (more CPU, RAM, faster SSD). Simple, no code changes.*

*Step 3: Read replicas — offload read queries from primary to replicas. Works great for read-heavy apps (most apps are 90%+ reads).*

*Step 4: Caching — Redis for hot data. If 80% of reads hit the same 20% of data, caching eliminates most DB load.*

*Step 5: Sharding — only when writes exceed one server's capacity. Shard by user_id or tenant_id. Use Vitess (for MySQL) or Citus (for PostgreSQL) to manage shards. Cross-shard queries are expensive, so choose the shard key based on the most common query.*

*Most applications never need to go beyond step 4."*

### Q6: "Explain ACID with an example"

**Complete Answer:**

*"ACID guarantees database reliability. I'll use a bank transfer — move $100 from Account A to Account B:*

*Atomicity: The transfer has two steps — debit A, credit B. If credit B fails (network error, disk full), the debit is rolled back. Either both happen or neither. We wrap both in a transaction: BEGIN, UPDATE A, UPDATE B, COMMIT.*

*Consistency: Before the transfer, A+B = $800. After, A+B = $800. The total never changes. If a CHECK constraint says balance >= 0 and the debit would make A negative, the DB rejects the transaction.*

*Isolation: If two transfers from A happen simultaneously, they don't interfere. Transaction 1 reads A=$500, debits to $400. Transaction 2 waits (row locked). Then reads A=$400, debits to $300. Both transfers execute correctly without the 'lost update' problem.*

*Durability: After COMMIT, even if the server crashes, the transfer persists. The database uses a Write-Ahead Log — changes are logged before the commit returns. On restart, the log is replayed."*

### Q7: "What are isolation levels? When do you use Serializable?"

**Complete Answer:**

*"Isolation levels control what concurrent transactions can see of each other. Four levels, from weakest to strongest:*

*Read Uncommitted: Can see other transactions' uncommitted changes (dirty reads). Almost never used.*

*Read Committed (PostgreSQL default): Only sees committed data. But the same query might return different results within one transaction if another transaction commits in between.*

*Repeatable Read (MySQL InnoDB default): Once you read a value, it stays the same for the rest of your transaction — even if others commit changes. Uses snapshot isolation.*

*Serializable: Transactions behave as if they ran one at a time. No anomalies at all, but potential for more transaction aborts and lower throughput.*

*I'd use Read Committed for most web applications — it prevents dirty reads and is fast. Serializable only for critical operations where phantom reads could cause business logic errors — like booking the last airline seat or managing inventory counts where overselling is unacceptable."*

---

## Database Considerations for Different System Types

| System | Primary DB | Cache | Special Considerations | Why |
|--------|-----------|-------|----------------------|-----|
| **URL Shortener** | PostgreSQL | Redis | Key-value mapping, read-heavy | Store `short_code → url`. Cache in Redis. Read:write = 100:1. |
| **Chat (WhatsApp)** | Cassandra + PostgreSQL | Redis | Write-heavy messages, recent history | Cassandra for message storage (massive writes). PostgreSQL for user accounts. Redis for online status. |
| **E-commerce** | PostgreSQL | Redis | Transactions critical (orders, inventory) | ACID for checkout flow. Redis for cart (TTL), product cache. |
| **Twitter Feed** | PostgreSQL + Cassandra | Redis | Fan-out writes, read-heavy feed | PostgreSQL for users/tweets. Pre-compute feed in Redis (push model) or Cassandra (pull model). |
| **Uber/Lyft** | PostgreSQL + Redis | Redis | Real-time location, geo-queries | PostgreSQL + PostGIS for trip history. Redis for live driver locations. |
| **Analytics Dashboard** | PostgreSQL + BigQuery | Redis | Heavy aggregations | Operational in PostgreSQL. ETL to BigQuery for OLAP queries. Cache dashboard results in Redis. |
| **Gaming Leaderboard** | Redis (primary for leaderboard) | - | Sorted set, real-time ranking | `ZADD` for score updates, `ZRANK` for position. O(log n) per operation. |
| **IoT Sensor Data** | Cassandra or TimescaleDB | - | Billions of time-series data points | Cassandra: write-optimized, wide rows for time-series. TimescaleDB: PostgreSQL extension with time-series optimizations. |

---

## Red Flags to Avoid in Interviews

| What NOT to Say | Why It's Wrong | What to Say Instead |
|-----------------|----------------|---------------------|
| "We use MongoDB because it's web-scale" | No justification based on requirements | "We use MongoDB because our product attributes vary per category — flexible schema fits" |
| "SQL can't scale" | SQL scales well with replicas, sharding, optimization | "SQL scales vertically and with read replicas. For extreme write scale, we'd shard or use NoSQL" |
| "NoSQL is always faster" | Depends on workload, indexing, query pattern | "NoSQL is faster for specific patterns like key-value lookups. SQL with proper indexes is also very fast" |
| "We don't need indexes" | Every production DB needs indexes on hot queries | "We'd index columns in WHERE and ORDER BY for our top queries" |
| "We'll shard from day one" | Premature optimization; sharding is complex | "Start with single DB + replicas + cache. Shard only when writes exceed one server's capacity" |
| "Just use Redis for everything" | Redis is not a durable primary database | "Redis for cache and sessions. PostgreSQL as the durable source of truth" |
| "Normalize everything" | Over-normalization kills read performance | "Normalize by default, denormalize for read-heavy hot paths" |
| "It depends" (and stop) | Shows no decision-making ability | "It depends on X, Y, Z — and given our requirements, I'd choose..." |

---

## Interview Flow: How to Naturally Weave Database Design Into Your Design

```
Step 1: Understand the data
  "The core entities are Users, Products, Orders, and Payments"

Step 2: Identify relationships and access patterns
  "Users have many Orders. Orders have many Items.
   Main queries: user's recent orders, product search, checkout flow."

Step 3: Choose database with justification
  "PostgreSQL for the core data — we need ACID for the checkout flow.
   Redis for product cache and user sessions."

Step 4: Draft schema (show 2-3 key tables)
  "Users table, Orders table with user_id FK, Order_items with product_id FK"

Step 5: Specify indexes with reasoning
  "Index on orders(user_id, created_at DESC) for 'my recent orders' query"

Step 6: Mention scaling approach
  "Read replicas for the product catalog (read-heavy).
   Redis cache for hot products. Shard by user_id if we reach write limits."

Step 7: STOP. Don't over-explain unless asked.
  If interviewer asks more → go deeper on sharding, transactions, etc.
```

### Example Flow for URL Shortener Design

```
YOU: "For the data layer, the core mapping is short_code → original_url.
      This is a simple key-value relationship, but we need durability.
      
      I'd use PostgreSQL as the source of truth:
      CREATE TABLE urls (
        short_code VARCHAR(7) PRIMARY KEY,
        original_url TEXT NOT NULL,
        user_id BIGINT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      );
      
      Redis as a read cache — since reads are 100:1 vs writes.
      GET from Redis first; on miss, query PostgreSQL, cache result.
      
      Index on created_at for analytics.
      Index on user_id for 'my URLs' page."

INTERVIEWER: "What about at massive scale?"

YOU: "At billions of URLs, the table gets large.
      We'd partition by short_code (hash partitioning) so each partition is manageable.
      Read replicas handle read load — most queries are reads.
      Redis cache absorbs the hottest URLs (popular links).
      If write volume exceeds one server, we'd shard by short_code hash."
```

---

## Quick Memory Card

```
WHEN:          Every system needs a database — discuss proactively
DEPTH:         1-line → medium → deep; match interviewer's interest
SQL vs NoSQL:  "Structured + ACID → SQL. Flexible + scale → NoSQL. Most systems use both."
JUSTIFY:       Always explain WHY — "We chose PostgreSQL because we need ACID for payments"
FRAMEWORK:     Data model → Consistency needs → Scale → Access patterns → Choose DB
SCHEMA:        Entities → Relationships → Tables → Indexes → Scaling
INDEX:         WHERE, JOIN, ORDER BY columns. Composite: equality → range → sort.
N+1:           JOIN or batch fetch. Never loop + query.
SCALING:       Optimize → vertical → replicas → cache → shard (in order)
RED FLAGS:     Don't say "MongoDB is web-scale" or "SQL can't scale" or "it depends" (and stop)
NATURAL:       Identify data → choose DB → draft schema → add indexes → mention scaling
```

---

**Next:** [[05_Common-Mistakes]]
