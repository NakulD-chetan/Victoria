## 📦 What is a Data Warehouse?

A **data warehouse** is like a **central storage place for data**, where all company data is kept **clean, organized, and ready for analysis**.

👉 Think of it like this:

- Shops = different data sources
- Warehouse = one big place where everything is stored properly
- Manager = analyst asking questions

---

## 🧠 Core Idea (in very simple terms)

- It is **not for daily work (transactions)**
- It is used for **analysis and reports**

👉 Example:

- ❌ Not for: placing orders
- ✅ Yes for: “How much did we sell last year?”

---

## Core Idea (2 Lines)

A **data warehouse (DW)** is a **central, query-optimized store** built for analysis and reporting, not for day-to-day transaction entry. Data moves through a disciplined pipeline (**collect, clean, store, analyze**) so business questions can be answered with **consistent history** and **controlled definitions**.

## How Data Flows

Data goes through 4 steps:

1. **Collect** → Get data from apps, websites, systems
2. **Clean** → Fix errors, remove duplicates
3. **Store** → Save in structured format
4. **Analyze** → Use for reports & dashboards

👉 Example:

- Collect: Orders from website
- Clean: Fix wrong data
- Store: Save properly
- Analyze: Find sales trends

---

## Definition: Central Store for Analysis


| Aspect                     | What it means in practice                                                                                                 |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| **Central**                | One governed place (logical or physical) where analysts and BI tools look for "official" numbers                          |
| **For analysis**           | Designed for **read-heavy** scans, joins, and aggregates across large time ranges                                         |
| **Organized for querying** | Modeled for **facts and dimensions**, conformed keys, and predictable grain — not just third-normal-form OLTP convenience |


**Interview Tip:** Say *"A DW is not 'a big database'; it is a **purpose-built analytical store** with governance, history, and performance patterns tuned for reporting workloads."*

---

## The Flow: Collect, Clean, Store, Analyze

```
+-------------+     +-------------+     +----------------+     +----------------+
|  COLLECT    | --> |   CLEAN     | --> |     STORE      | --> |    ANALYZE     |
| (sources)   |     | (quality,   |     | (DW layers,    |     | (BI, SQL,      |
|             |     |  conform)   |     |  models)       |     |  notebooks)    |
+-------------+     +-------------+     +----------------+     +----------------+
```


|     |
| --- |


---

```
EXPLANATION (IN SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


===============================
1. DATABASE vs DATA WAREHOUSE
===============================

Think like this:

- Database (Operational DB) → used to RUN the business
- Data Warehouse → used to ANALYZE the business

Let’s break each point:

--------------------------------
Purpose
--------------------------------
Database:
- Handles daily operations
- Example: placing orders, updating inventory, processing refunds

Data Warehouse:
- Used for analysis and decision making
- Example: finding trends, KPIs, forecasting revenue


--------------------------------
Usage Pattern
--------------------------------
Database:
- Many users at same time
- Small read/write operations (insert/update/delete)

Data Warehouse:
- Fewer users
- Heavy read queries (big scans)
- Bulk data loads


--------------------------------
Speed Goal
--------------------------------
Database:
- Must be very fast (milliseconds)
- Because user is waiting (e.g., checkout)

Data Warehouse:
- Can take seconds or minutes
- Because queries are large (aggregations)


--------------------------------
Data Type
--------------------------------
Database:
- Stores current state
- Only limited history

Data Warehouse:
- Stores historical data
- Keeps track of changes over time


--------------------------------
Optimization
--------------------------------
Database:
- Optimized for fast lookups
- Uses indexes
- Focus on write performance

Data Warehouse:
- Optimized for analytics
- Uses column storage, star schema
- Focus on scanning large data efficiently


--------------------------------
Interview Tip
--------------------------------
Example:
- Database → checkout system
- Data Warehouse → calculate last year revenue by region

Same company, different purpose.



===============================
2. OLTP vs OLAP
===============================

--------------------------------
OLTP (Online Transaction Processing)
--------------------------------
- Used in databases
- Handles real-time operations

Example:
"Reserve 2 units of product for customer"


--------------------------------
OLAP (Online Analytical Processing)
--------------------------------
- Used in data warehouse
- Handles analysis queries

Example:
"Compare average basket size by month"


--------------------------------
Differences
--------------------------------

Transaction Size:
- OLTP → small (few rows)
- OLAP → large (millions of rows)

Concurrency:
- OLTP → very high (many users)
- OLAP → moderate

Schema:
- OLTP → normalized (many tables)
- OLAP → denormalized (fact + dimension)

Examples:
- OLTP → inventory system
- OLAP → data warehouse, BI tools


--------------------------------
SQL Examples Explained
--------------------------------

OLTP Query:
SELECT quantity_on_hand
FROM store_inventory
WHERE store_id = 1024
  AND sku_id = 'SKU-4412';

Explanation:
- Simple lookup
- Fetch stock for one item
- Very fast


OLAP Query:
SELECT d.month,
       f.fulfillment_channel,
       SUM(f.extended_price) AS revenue,
       AVG(f.line_items)     AS avg_lines_per_order
FROM fact_sales f
JOIN dim_date d ON f.order_date_sk = d.date_sk
WHERE d.calendar_year = 2025
GROUP BY d.month, f.fulfillment_channel
ORDER BY d.month, f.fulfillment_channel;

Explanation:
- Scans large dataset
- Joins tables
- Aggregates data
- Used for reporting


--------------------------------
Warning
--------------------------------
Running OLAP queries on OLTP system:
- Slows down production
- High I/O usage
- Can crash system



===============================
3. BILL INMON DEFINITION
===============================

A Data Warehouse has 4 key properties:

--------------------------------
1. Subject-Oriented
--------------------------------
- Organized by business areas (customer, sales, product)
- Not by application

Example:
Combine sales from web + app + POS


--------------------------------
2. Integrated
--------------------------------
- Data from different sources is standardized

Example:
- Same customer_id format
- Same currency format


--------------------------------
3. Non-Volatile
--------------------------------
- Data is not updated frequently
- Mostly insert-only

Example:
- December data is not changed when January data arrives


--------------------------------
4. Time-Variant
--------------------------------
- Stores history
- Tracks changes over time

Example:
- Price changes don’t overwrite old data


--------------------------------
Interview Tip
--------------------------------
Memorize:
- Subject-oriented
- Integrated
- Non-volatile
- Time-variant



===============================
4. ETL vs ELT
===============================

--------------------------------
ETL (Extract → Transform → Load)
--------------------------------
Steps:
1. Extract data
2. Transform outside warehouse
3. Load into warehouse

Use case:
- Legacy systems
- Heavy data cleaning needed


--------------------------------
ELT (Extract → Load → Transform)
--------------------------------
Steps:
1. Extract data
2. Load raw data into warehouse
3. Transform inside warehouse

Use case:
- Modern cloud systems
- Use warehouse compute power


--------------------------------
SQL Example Explained
--------------------------------

CREATE TABLE landing_orders AS
SELECT * FROM external_orders_raw;

Explanation:
- Load raw data


CREATE TABLE dw_stg_orders AS
SELECT
  order_id,
  UPPER(TRIM(customer_email)) AS customer_email,
  TRY_TO_TIMESTAMP(order_ts) AS order_ts_utc
FROM landing_orders;

Explanation:
- Clean and transform data inside warehouse


--------------------------------
Warning
--------------------------------
ELT ≠ no governance
- You still need rules and ownership



===============================
5. END-TO-END DATA FLOW
===============================

Flow:

Sources → ETL/ELT → Data Warehouse → BI → Users

Explanation:

--------------------------------
Sources
--------------------------------
- Web apps, mobile apps, POS systems


--------------------------------
ETL/ELT Layer
--------------------------------
- Cleans data
- Removes duplicates
- Applies business rules


--------------------------------
Data Warehouse
--------------------------------
- Stores clean + historical data
- Uses star/snowflake schema


--------------------------------
BI Layer
--------------------------------
- Converts data into dashboards


--------------------------------
Users
--------------------------------
- Finance, operations, executives


--------------------------------
Interview Tip
--------------------------------
Explain WHY each layer exists:
- Sources = messy
- ETL = cleaning
- DW = storage
- BI = visualization



===============================
6. RETAIL EXAMPLE
===============================

--------------------------------
Orders
--------------------------------
Operations:
- Line items, promotions

Warehouse:
- Unified format
- Handles returns properly


--------------------------------
Customer
--------------------------------
Operations:
- Accounts, addresses

Warehouse:
- Golden customer view
- Privacy handling


--------------------------------
Payments
--------------------------------
Operations:
- Transactions

Warehouse:
- Revenue reconciliation



===============================
7. GOVERNANCE
===============================

Why important:
Without governance → confusion

--------------------------------
Data Dictionary
--------------------------------
- Defines metrics

Example:
- What is "Net Sales"


--------------------------------
SLAs
--------------------------------
- Data freshness guarantee


--------------------------------
Lineage
--------------------------------
- Track data origin


--------------------------------
Warning
--------------------------------
Without ownership:
- Teams argue over numbers
- No decision-making



===============================
8. COMMON MISTAKES
===============================

--------------------------------
Mistake 1
--------------------------------
Using normal DB as warehouse

Problem:
- Slow queries
- Inconsistent data

Fix:
- Use proper modeling (star schema)


--------------------------------
Mistake 2
--------------------------------
Running analytics on OLTP

Problem:
- System slowdown

Fix:
- Use data warehouse


--------------------------------
Mistake 3
--------------------------------
No history tracking

Problem:
- Cannot analyze past

Fix:
- Use time-based storage (SCD)


--------------------------------
Mistake 4
--------------------------------
ETL as one-time script

Problem:
- Breaks on changes

Fix:
- Add monitoring, testing



===============================
9. FINAL TAKEAWAY
===============================

Data Warehouse is:
- Central system for analytics
- Integrates multiple sources
- Stores historical data
- Optimized for large queries

Pipeline flow:
COLLECT → CLEAN → STORE → ANALYZE

Key concepts:
- OLTP vs OLAP
- Inmon properties
- ETL vs ELT
- End-to-end architecture

Goal:
Provide trusted data for business decisions
```

