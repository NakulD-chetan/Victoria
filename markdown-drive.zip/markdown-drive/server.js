// Allow self-signed certs behind corporate proxies
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

import express from 'express';
import cors from 'cors';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import AdmZip from 'adm-zip';
import { join, resolve, dirname, extname, basename } from 'path';
import { fileURLToPath } from 'url';
import { existsSync } from 'fs';
import { mkdir } from 'fs/promises';
import { randomUUID } from 'crypto';
import { SupabaseStorageProvider } from './storage.js';
import { AuthManager, authMiddleware } from './auth.js';
import { supabaseAuthMiddleware } from './supabase-jwt.js';
import { AlgorithmService } from './db-service.js';
import { sanitizeInput, judgeRun, judgeChaos, scoreDeepDive, computeFullScore } from './server-judge.js';
import { executeSubmission, getAvailableLanguages, STATUS as J0_STATUS } from './judge0-engine.js';
import { executeSql } from './sql-engine.js';
import {
  cancelCanvasAgentRun,
  createCanvasAgentRun,
  getCanvasAgentMeta,
  getCanvasAgentRun,
  getCanvasAgentVoiceMeta,
  runCanvasTeacherAgent,
  streamCanvasAgentRunEvents,
  transcribeCanvasAgentAudio,
} from './canvas-agent-runtime.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = 3001;

const JUDGE0_ENDPOINT = process.env.JUDGE0_ENDPOINT || 'https://judge0-ce.p.rapidapi.com';
const JUDGE0_API_KEY = process.env.JUDGE0_API_KEY || '';
const JUDGE0_HOST = process.env.JUDGE0_HOST || 'judge0-ce.p.rapidapi.com';

// Auth still uses local meta dir (PIN users, shares)
const META_DIR = resolve(__dirname, 'uploads', '.inkdrop');
if (!existsSync(META_DIR)) await mkdir(META_DIR, { recursive: true });

const storage_provider = new SupabaseStorageProvider();
await storage_provider.init();

const algorithmService = new AlgorithmService();

const auth = new AuthManager(META_DIR);
await auth.init();

app.use(cors());
app.use(compression());
app.use(express.json({ limit: '10mb' }));

const limiter = rateLimit({ windowMs: 60 * 1000, max: 600, standardHeaders: true, legacyHeaders: false });
app.use('/api/', limiter);

// Public route: shared notes (no auth required)
const SUPA_URL_PUB = 'https://svuumfizxptnxaidishq.supabase.co/storage/v1';
const SUPA_KEY_PUB = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';
const SUPA_HDRS_PUB = { 'apikey': SUPA_KEY_PUB, 'Authorization': `Bearer ${SUPA_KEY_PUB}` };

app.get('/api/notes/shared/:shareId', asyncHandler(async (req, res) => {
  const { shareId } = req.params;
  const path = `inkdrop-files/_inkdrop_shared_notes/${shareId}.json`;
  try {
    const supa = await fetch(`${SUPA_URL_PUB}/object/${path}`, { headers: SUPA_HDRS_PUB });
    if (!supa.ok) return res.status(404).json({ error: 'Shared note not found or expired' });
    const data = await supa.json();
    if (data.expiresAt && new Date(data.expiresAt) < new Date()) {
      return res.status(410).json({ error: 'This shared note has expired' });
    }
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}));

const pubExecLimiter = rateLimit({ windowMs: 60 * 1000, max: 10, message: { error: 'Too many executions' } });
app.post('/api/notes/shared/:shareId/execute', pubExecLimiter, asyncHandler(async (req, res) => {
  const { source_code, language, stdin } = req.body;
  if (!source_code || !language) return res.status(400).json({ error: 'source_code and language required' });
  if (typeof source_code !== 'string' || source_code.length > 50000) return res.status(400).json({ error: 'Code too large' });
  const supported = ['cpp', 'python', 'java', 'javascript'];
  if (!supported.includes(language)) return res.status(400).json({ error: `Unsupported language: ${language}` });

  // Use local Judge0 engine first, then cloud fallbacks
  const localResult = await executeSubmission(source_code, language, stdin || '');
  if (localResult.status.id !== J0_STATUS.INTERNAL.id) {
    return res.json({ stdout: localResult.stdout, stderr: localResult.stderr, compile_output: localResult.compile_output, status: localResult.status.id === 3 ? 0 : localResult.status.id });
  }
  let result = null;
  if (JUDGE0_API_KEY) { try { result = await executeViaJudge0(source_code, language, stdin); } catch {} }
  if (!result) { try { result = await executeViaWandbox(source_code, language, stdin); } catch {} }
  if (!result) return res.status(502).json({ error: 'Execution service unavailable' });
  res.json({ stdout: result.stdout, stderr: result.stderr, compile_output: result.compile_output, status: result.status?.id === 3 ? 0 : result.status?.id || 1 });
}));



/* Auth: prefer real Supabase JWTs; fall back to the legacy PIN/firebase
 * middleware so users who have not yet migrated keep working. */
app.use('/api/', supabaseAuthMiddleware({ legacyFallback: authMiddleware(auth) }));

/* Deprecation banner for legacy blob-sync endpoints. They keep working
 * during the 30-day grace window so existing clients can migrate, but
 * every response carries a Deprecation header that the new client uses
 * to surface a "Migrate to v4" banner. */
const _deprecatedRoutes = new Set([
  '/api/notes/sync',
  '/api/vaults/sync',
  '/api/canvas/sync',
]);
app.use('/api/', (req, res, next) => {
  if (_deprecatedRoutes.has(req.path)) {
    res.setHeader('Deprecation', 'true');
    res.setHeader('Sunset', new Date(Date.now() + 30 * 24 * 3600 * 1000).toUTCString());
    res.setHeader('Link', '</api/migrate-legacy>; rel="successor-version"');
  }
  next();
});

/* ── /api/migrate-legacy ────────────────────────────────────────────────
 * One-shot migration. Caller must be authenticated as a Supabase user
 * (req.user.provider === 'supabase'); payload includes the legacy bearer
 * token so we can locate their old notes blob and import its rows. */
app.post('/api/migrate-legacy', asyncHandler(async (req, res) => {
  if (req.user?.provider !== 'supabase') {
    return res.status(401).json({ error: 'Sign in with Supabase first' });
  }
  const { legacyToken } = req.body || {};
  let legacyId = null;
  if (typeof legacyToken === 'string') {
    if (legacyToken.startsWith('firebase-')) {
      legacyId = legacyToken.slice('firebase-'.length);
    } else {
      const u = await auth.verifyToken(legacyToken);
      legacyId = u?.id || null;
    }
  }
  /* Even without a legacy token, surface the user's vault registry blob so
   * they can import notes into their new Supabase account. */
  const out = { migrated: { vaults: 0, folders: 0, notes: 0 }, legacyId };
  try {
    const regRes = await fetch(
      `${SUPA_URL_PUB}/object/inkdrop-files/_inkdrop_vaults/registry.json`,
      { headers: SUPA_HDRS_PUB },
    );
    if (regRes.ok) {
      const reg = await regRes.json();
      if (reg?.vaults?.length) {
        out.legacyVaults = reg.vaults.map((v) => ({ id: v.id, name: v.name }));
      }
    }
  } catch { /* no registry */ }
  /* The actual row-level import happens client-side after the user picks
   * which legacy vaults to bring over (so we can show them progress). The
   * client uses supabase-js with their JWT; RLS does the rest. */
  res.json(out);
}));

const distPath = join(__dirname, 'dist');
if (existsSync(distPath)) app.use(express.static(distPath));

function sanitizeName(name) {
  if (!name) return 'General';
  const cleaned = name.replace(/\.\./g, '');
  return cleaned.split('/').map(p => p.replace(/[^a-zA-Z0-9_\-\s.]/g, '').trim()).filter(Boolean).join('/') || 'General';
}

function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

// ── Multer: MEMORY ONLY (no local disk writes) ──────────────────
const memStorage = multer.memoryStorage();
const upload = multer({
  storage: memStorage,
  fileFilter: (_req, file, cb) => {
    const ext = extname(file.originalname).toLowerCase();
    if (['.md', '.markdown', '.txt', '.mdx', '.zip'].includes(ext)) cb(null, true);
    else cb(new Error('Only .md, .markdown, .txt, .mdx, .zip files allowed'));
  },
  limits: { fileSize: 50 * 1024 * 1024 },
});
const audioUpload = multer({
  storage: memStorage,
  limits: { fileSize: 25 * 1024 * 1024 },
});

// ── Auth API ─────────────────────────────────────────────────────
app.get('/api/auth/status', asyncHandler(async (_req, res) => {
  res.json({ hasUsers: auth.hasUsers() });
}));

app.post('/api/auth/setup', asyncHandler(async (req, res) => {
  const { name, pin } = req.body;
  if (!pin || pin.length < 4) return res.status(400).json({ error: 'PIN must be at least 4 characters' });
  const user = await auth.createUser(name || 'User', pin);
  res.json(user);
}));

app.post('/api/auth/verify', asyncHandler(async (req, res) => {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return res.status(401).json({ valid: false });
  const user = await auth.verifyToken(header.slice(7));
  if (!user) return res.status(401).json({ valid: false });
  res.json({ valid: true, user });
}));

app.post('/api/auth/login', asyncHandler(async (req, res) => {
  const { pin } = req.body;
  if (!pin) return res.status(400).json({ error: 'PIN required' });
  const result = await auth.loginWithPin(pin);
  if (!result) return res.status(401).json({ error: 'Invalid PIN' });
  res.json(result);
}));

// ── Share API ────────────────────────────────────────────────────
app.post('/api/shares', asyncHandler(async (req, res) => {
  const { folderPath, permissions, expiresInDays, expiresInHours, password, maxAccess, label, allowDownload } = req.body;
  if (!folderPath) return res.status(400).json({ error: 'folderPath required' });
  const userId = req.user?.id || 'anonymous';
  const share = await auth.createShare(folderPath, userId, {
    permissions, expiresInDays, expiresInHours, password, maxAccess, label, allowDownload,
  });
  res.json(share);
}));

app.get('/api/shares', asyncHandler(async (req, res) => {
  const userId = req.user?.id || 'anonymous';
  const { folder } = req.query;
  if (folder) {
    res.json(auth.getSharesForFolder(folder));
  } else {
    res.json(auth.getSharesByUser(userId));
  }
}));

app.patch('/api/shares/:id', asyncHandler(async (req, res) => {
  const userId = req.user?.id || 'anonymous';
  const updated = await auth.updateShare(req.params.id, userId, req.body);
  if (!updated) return res.status(404).json({ error: 'Share not found' });
  res.json(updated);
}));

app.patch('/api/shares/:id/toggle', asyncHandler(async (req, res) => {
  const userId = req.user?.id || 'anonymous';
  const share = await auth.toggleShareActive(req.params.id, userId);
  if (!share) return res.status(404).json({ error: 'Share not found' });
  res.json(share);
}));

app.delete('/api/shares/:id', asyncHandler(async (req, res) => {
  const userId = req.user?.id || 'anonymous';
  const deleted = await auth.deleteShare(req.params.id, userId);
  res.json({ deleted });
}));

app.get('/api/share/:token', asyncHandler(async (req, res) => {
  const share = await auth.accessShare(req.params.token);
  if (!share) return res.status(404).json({ error: 'Share link expired or not found' });
  if (share.requiresPassword) {
    return res.json({ requiresPassword: true, label: share.label, folderPath: share.folderPath });
  }
  await auth.recordShareAccess(req.params.token);
  const folders = await storage_provider.listFolders();
  const findFolder = (list, path) => {
    for (const f of list) {
      if (f.path === path) return f;
      if (f.children?.length) { const found = findFolder(f.children, path); if (found) return found; }
    }
    return null;
  };
  const folder = findFolder(folders, share.folderPath);
  if (!folder) return res.status(404).json({ error: 'Folder not found' });
  res.json({ share, folder });
}));

app.post('/api/share/:token/verify', asyncHandler(async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required' });
  const valid = await auth.verifySharePassword(req.params.token, password);
  if (!valid) return res.status(401).json({ error: 'Wrong password' });
  await auth.recordShareAccess(req.params.token);
  const share = await auth.accessShare(req.params.token);
  const folders = await storage_provider.listFolders();
  const findFolder = (list, path) => {
    for (const f of list) {
      if (f.path === path) return f;
      if (f.children?.length) { const found = findFolder(f.children, path); if (found) return found; }
    }
    return null;
  };
  const folder = findFolder(folders, share.folderPath);
  if (!folder) return res.status(404).json({ error: 'Folder not found' });
  res.json({ share, folder });
}));

app.get('/api/share/:token/file/:filename', asyncHandler(async (req, res) => {
  const share = await auth.accessShare(req.params.token);
  if (!share) return res.status(404).json({ error: 'Share link expired or not found' });
  if (!share.permissions.includes('view')) return res.status(403).json({ error: 'No view permission' });
  const data = await storage_provider.getFile(share.folderPath, req.params.filename);
  if (!data) return res.status(404).json({ error: 'File not found' });
  res.json({ ...data, allowDownload: share.allowDownload });
}));

// ── API: List folders ────────────────────────────────────────────
app.get('/api/folders', asyncHandler(async (_req, res) => {
  res.json(await storage_provider.listFolders());
}));

// ── API: Create folder ───────────────────────────────────────────
app.post('/api/folders', asyncHandler(async (req, res) => {
  const name = sanitizeName(req.body.name || '');
  if (!name) return res.status(400).json({ error: 'Folder name required' });
  const created = await storage_provider.createFolder(name);
  res.json({ name: created, created: true });
}));

// ── API: Rename folder ──────────────────────────────────────────
app.patch('/api/folders/:name', asyncHandler(async (req, res) => {
  const newName = sanitizeName(req.body.newName || '');
  if (!newName) return res.status(400).json({ error: 'New name required' });
  try {
    const result = await storage_provider.renameFolder(req.params.name, newName);
    res.json({ ...result, renamed: true });
  } catch (e) {
    res.status(e.message === 'Folder not found' ? 404 : 409).json({ error: e.message });
  }
}));

// ── API: Delete folder ──────────────────────────────────────────
app.delete('/api/folders/:name', asyncHandler(async (req, res) => {
  await storage_provider.deleteFolder(req.params.name);
  res.json({ deleted: true });
}));

// ── API: Upload files → Supabase (memory buffer, no local disk) ─
const uploadMiddleware = upload.array('files', 200);
app.post('/api/upload', (req, res, next) => {
  uploadMiddleware(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    next();
  });
}, asyncHandler(async (req, res) => {
  const folder = sanitizeName(req.body.folder || 'General');
  const uploaded = [];

  for (const file of (req.files || [])) {
    await storage_provider.uploadFile(folder, file.originalname, file.buffer);
    uploaded.push({ name: file.originalname, size: file.size, folder });
  }

  res.json({ uploaded, count: uploaded.length });
}));

// ── API: Upload ZIP → extract in memory → Supabase ──────────────
const uploadSingle = upload.single('file');
app.post('/api/upload-zip', (req, res, next) => {
  uploadSingle(req, res, (err) => {
    if (err) return res.status(400).json({ error: err.message });
    next();
  });
}, asyncHandler(async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  const ext = extname(req.file.originalname).toLowerCase();
  if (ext !== '.zip') return res.status(400).json({ error: 'Only .zip files' });

  const zip = new AdmZip(req.file.buffer);
  const entries = zip.getEntries();
  const extracted = [];

  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const fname = entry.name;
    const fext = extname(fname).toLowerCase();
    if (!['.md', '.markdown', '.txt', '.mdx'].includes(fext)) continue;

    const parts = entry.entryName.split('/').filter(Boolean);
    let folderName = req.body.folder || 'General';
    if (parts.length > 1) folderName = sanitizeName(parts[parts.length - 2]);

    const content = entry.getData();
    await storage_provider.uploadFile(sanitizeName(folderName), fname, content);
    extracted.push({ name: fname, folder: folderName });
  }

  res.json({ extracted, count: extracted.length });
}));

// ── API: Notes image upload (local disk) ─────────────────────────
const notesImgDir = resolve(__dirname, 'uploads', 'notes-images');
if (!existsSync(notesImgDir)) await mkdir(notesImgDir, { recursive: true });
app.use('/uploads/notes-images', express.static(notesImgDir));

const noteImgUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, notesImgDir),
    filename: (_req, file, cb) => cb(null, `${Date.now()}-${randomUUID().slice(0, 8)}${extname(file.originalname)}`),
  }),
  fileFilter: (_req, file, cb) => {
    const ext = extname(file.originalname).toLowerCase();
    if (['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.bmp'].includes(ext)) cb(null, true);
    else cb(new Error('Only image files allowed'));
  },
  limits: { fileSize: 10 * 1024 * 1024 },
});

app.post('/api/notes/upload-image', noteImgUpload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No image uploaded' });
  const url = `/uploads/notes-images/${req.file.filename}`;
  res.json({ url, filename: req.file.filename, size: req.file.size });
});

// ── API: Notes cloud sync (Supabase) ────────────────────────────
const SUPA_URL = 'https://svuumfizxptnxaidishq.supabase.co/storage/v1';
const SUPA_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';
const SUPA_HDRS = { 'apikey': SUPA_KEY, 'Authorization': `Bearer ${SUPA_KEY}` };
const NOTES_PATH = 'inkdrop-files/_inkdrop_notes/data.json';
const VAULTS_REGISTRY_PATH = 'inkdrop-files/_inkdrop_vaults/registry.json';

/* Vault-scoped path helpers.
 * - `default` vault keeps using the legacy paths so existing data is
 *   never orphaned on first upgrade.
 * - Any other vault gets a dedicated subfolder inside the same bucket. */
function notesPathForVault(vaultId) {
  const id = (vaultId || 'default').toString();
  if (id === 'default') return NOTES_PATH;
  return `inkdrop-files/_inkdrop_notes/${encodeURIComponent(id)}/data.json`;
}
function canvasPrefixForVault(vaultId) {
  const id = (vaultId || 'default').toString();
  if (id === 'default') return 'inkdrop-files/_inkdrop_canvas';
  return `inkdrop-files/_inkdrop_canvas/${encodeURIComponent(id)}`;
}
const SHARES_PREFIX = 'inkdrop-files/_inkdrop_shared_notes';

// ── API: Note Sharing (public links) ────────────────────────────
app.post('/api/notes/share', asyncHandler(async (req, res) => {
  const { noteId, title, body, coverImage, tags, expiresInDays } = req.body;
  if (!noteId || body === undefined) return res.status(400).json({ error: 'noteId and body required' });

  const shareId = randomUUID().replace(/-/g, '').slice(0, 12);
  const now = new Date().toISOString();
  const expiresAt = expiresInDays
    ? new Date(Date.now() + expiresInDays * 86400000).toISOString()
    : null;

  const shareData = {
    shareId, noteId, title: title || 'Untitled', body: body || '',
    coverImage: coverImage || null, tags: tags || [],
    createdAt: now, expiresAt,
    sharedBy: req.user?.name || 'Anonymous',
  };

  const path = `${SHARES_PREFIX}/${shareId}.json`;
  const buf = Buffer.from(JSON.stringify(shareData), 'utf-8');
  const supa = await fetch(`${SUPA_URL}/object/${path}`, {
    method: 'POST',
    headers: { ...SUPA_HDRS, 'Content-Type': 'application/json', 'x-upsert': 'true' },
    body: buf,
  });
  if (!supa.ok) {
    const errText = await supa.text();
    return res.status(500).json({ error: errText });
  }
  res.json({ shareId, url: `/shared/${shareId}` });
}));

app.put('/api/notes/share/:shareId', asyncHandler(async (req, res) => {
  const { shareId } = req.params;
  const path = `${SHARES_PREFIX}/${shareId}.json`;
  const existing = await fetch(`${SUPA_URL}/object/${path}`, { headers: SUPA_HDRS });
  if (!existing.ok) return res.status(404).json({ error: 'Share not found' });
  const old = await existing.json();
  const updated = { ...old, ...req.body, shareId, updatedAt: new Date().toISOString() };
  const buf = Buffer.from(JSON.stringify(updated), 'utf-8');
  await fetch(`${SUPA_URL}/object/${path}`, {
    method: 'POST',
    headers: { ...SUPA_HDRS, 'Content-Type': 'application/json', 'x-upsert': 'true' },
    body: buf,
  });
  res.json({ updated: true });
}));

app.delete('/api/notes/share/:shareId', asyncHandler(async (req, res) => {
  const { shareId } = req.params;
  await fetch(`${SUPA_URL}/object/inkdrop-files`, {
    method: 'DELETE',
    headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
    body: JSON.stringify({ prefixes: [`_inkdrop_shared_notes/${shareId}.json`] }),
  });
  res.json({ deleted: true });
}));

app.get('/api/notes/shares', asyncHandler(async (req, res) => {
  try {
    const supa = await fetch(`${SUPA_URL}/object/list/inkdrop-files`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefix: '_inkdrop_shared_notes', limit: 200, offset: 0 }),
    });
    if (!supa.ok) return res.json([]);
    const items = await supa.json();
    const shares = items.filter(i => i.id && i.name.endsWith('.json')).map(i => ({
      file: i.name, updatedAt: i.updated_at || i.created_at,
    }));
    res.json(shares);
  } catch { res.json([]); }
}));


app.get('/api/notes/sync', asyncHandler(async (req, res) => {
  try {
    const path = notesPathForVault(req.query.vault);
    const supa = await fetch(`${SUPA_URL}/object/${path}`, { headers: SUPA_HDRS });
    if (!supa.ok) {
      if (supa.status === 404 || supa.status === 400) return res.json({ exists: false });
      return res.status(supa.status).json({ error: 'Cloud fetch failed' });
    }
    const data = await supa.json();
    res.json({ exists: true, data, updatedAt: data._updatedAt || null });
  } catch (err) {
    console.error('[Notes Sync] GET error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

app.put('/api/notes/sync', asyncHandler(async (req, res) => {
  try {
    const path = notesPathForVault(req.query.vault);
    const payload = { ...req.body, _updatedAt: new Date().toISOString() };
    const buf = Buffer.from(JSON.stringify(payload), 'utf-8');
    const supa = await fetch(`${SUPA_URL}/object/${path}`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json', 'x-upsert': 'true' },
      body: buf,
    });
    if (!supa.ok) {
      const errText = await supa.text();
      console.error('[Notes Sync] PUT error:', errText);
      return res.status(supa.status).json({ error: errText });
    }
    res.json({ saved: true, updatedAt: payload._updatedAt });
  } catch (err) {
    console.error('[Notes Sync] PUT error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

/* --- Vault registry sync ------------------------------------------------
 * Stores the list of vaults + the active one in a single JSON blob.
 * Per-vault data still lives under /_inkdrop_notes/<id>/ and
 * /_inkdrop_canvas/<id>/ via the path helpers above. */
app.get('/api/vaults/sync', asyncHandler(async (req, res) => {
  try {
    const supa = await fetch(`${SUPA_URL}/object/${VAULTS_REGISTRY_PATH}`, { headers: SUPA_HDRS });
    if (!supa.ok) {
      if (supa.status === 404 || supa.status === 400) return res.json({ exists: false });
      return res.status(supa.status).json({ error: 'Cloud fetch failed' });
    }
    const data = await supa.json();
    res.json({ exists: true, data, updatedAt: data._updatedAt || null });
  } catch (err) {
    console.error('[Vaults Sync] GET error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

app.put('/api/vaults/sync', asyncHandler(async (req, res) => {
  try {
    const payload = { ...req.body, _updatedAt: new Date().toISOString() };
    const buf = Buffer.from(JSON.stringify(payload), 'utf-8');
    const supa = await fetch(`${SUPA_URL}/object/${VAULTS_REGISTRY_PATH}`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json', 'x-upsert': 'true' },
      body: buf,
    });
    if (!supa.ok) {
      const errText = await supa.text();
      console.error('[Vaults Sync] PUT error:', errText);
      return res.status(supa.status).json({ error: errText });
    }
    res.json({ saved: true, updatedAt: payload._updatedAt });
  } catch (err) {
    console.error('[Vaults Sync] PUT error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

/* Delete everything belonging to a vault (notes data + all canvas scenes
 * stored under that vault's prefix). Used by the Vault Manager when the
 * user removes a non-default vault. */
app.delete('/api/vaults/:vaultId', asyncHandler(async (req, res) => {
  const vaultId = req.params.vaultId;
  if (!vaultId || vaultId === 'default') {
    return res.status(400).json({ error: 'Cannot delete default vault via this endpoint.' });
  }
  const errors = [];
  try {
    const notesPath = notesPathForVault(vaultId);
    await fetch(`${SUPA_URL}/object/inkdrop-files`, {
      method: 'DELETE',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefixes: [notesPath.replace(/^inkdrop-files\//, '')] }),
    });
  } catch (e) { errors.push(`notes: ${e.message}`); }

  /* Canvas scenes are many small files under the prefix; list + delete. */
  try {
    const prefix = canvasPrefixForVault(vaultId).replace(/^inkdrop-files\//, '');
    const list = await fetch(`${SUPA_URL}/object/list/inkdrop-files`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefix, limit: 1000, offset: 0 }),
    });
    if (list.ok) {
      const items = await list.json();
      const paths = (items || [])
        .filter((i) => i.id && i.name)
        .map((i) => `${prefix}/${i.name}`);
      if (paths.length) {
        await fetch(`${SUPA_URL}/object/inkdrop-files`, {
          method: 'DELETE',
          headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
          body: JSON.stringify({ prefixes: paths }),
        });
      }
    }
  } catch (e) { errors.push(`canvas: ${e.message}`); }

  res.json({ deleted: true, vaultId, errors });
}));

// ── API: Canvas cloud sync (Supabase) ───────────────────────────
const CANVAS_PREFIX = 'inkdrop-files/_inkdrop_canvas';

app.get('/api/canvas/list', asyncHandler(async (req, res) => {
  try {
    /* Prefix is relative to the bucket root — the canvasPrefixForVault
     * helper returns an absolute path including the bucket, so strip it. */
    const absPrefix = canvasPrefixForVault(req.query.vault);
    const prefix = absPrefix.replace(/^inkdrop-files\//, '');
    const supa = await fetch(`${SUPA_URL}/object/list/inkdrop-files`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefix, limit: 100, offset: 0 }),
    });
    if (!supa.ok) return res.json([]);
    const items = await supa.json();
    const canvases = items.filter(i => i.id && i.name.endsWith('.json')).map(i => ({
      name: i.name.replace('.json', '').replace(/_/g, ' '),
      file: i.name,
      updatedAt: i.updated_at || i.created_at,
    }));
    res.json(canvases);
  } catch (err) {
    console.error('[Canvas List] error:', err.message);
    res.json([]);
  }
}));

app.get('/api/canvas/sync', asyncHandler(async (req, res) => {
  const name = (req.query.name || 'Untitled Canvas').replace(/\s+/g, '_');
  const prefix = canvasPrefixForVault(req.query.vault);
  const path = `${prefix}/${name}.json`;
  try {
    const supa = await fetch(`${SUPA_URL}/object/${path}`, { headers: SUPA_HDRS });
    if (!supa.ok) {
      if (supa.status === 404 || supa.status === 400) return res.json({ exists: false });
      return res.status(supa.status).json({ error: 'Cloud fetch failed' });
    }
    const data = await supa.json();
    res.json({ exists: true, data });
  } catch (err) {
    console.error('[Canvas Sync] GET error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

app.put('/api/canvas/sync', asyncHandler(async (req, res) => {
  const name = (req.body.name || 'Untitled Canvas').replace(/\s+/g, '_');
  const prefix = canvasPrefixForVault(req.query.vault || req.body.vault);
  const path = `${prefix}/${name}.json`;
  try {
    const payload = { ...req.body, _updatedAt: new Date().toISOString() };
    const buf = Buffer.from(JSON.stringify(payload), 'utf-8');
    const supa = await fetch(`${SUPA_URL}/object/${path}`, {
      method: 'POST',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json', 'x-upsert': 'true' },
      body: buf,
    });
    if (!supa.ok) {
      const errText = await supa.text();
      console.error('[Canvas Sync] PUT error:', errText);
      return res.status(supa.status).json({ error: errText });
    }
    res.json({ saved: true });
  } catch (err) {
    console.error('[Canvas Sync] PUT error:', err.message);
    res.status(500).json({ error: err.message });
  }
}));

app.delete('/api/canvas/delete', asyncHandler(async (req, res) => {
  const name = (req.query.name || '').replace(/\s+/g, '_');
  if (!name) return res.status(400).json({ error: 'name required' });
  const prefix = canvasPrefixForVault(req.query.vault);
  const relPath = `${prefix.replace(/^inkdrop-files\//, '')}/${name}.json`;
  try {
    await fetch(`${SUPA_URL}/object/inkdrop-files`, {
      method: 'DELETE',
      headers: { ...SUPA_HDRS, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefixes: [relPath] }),
    });
    res.json({ deleted: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}));

// ── API: Nest folder inside another folder ──────────────────────
app.patch('/api/folders/:name/nest', asyncHandler(async (req, res) => {
  const { targetFolder } = req.body;
  if (!targetFolder) return res.status(400).json({ error: 'targetFolder required' });
  try {
    const result = await storage_provider.nestFolder(req.params.name, targetFolder);
    res.json(result);
  } catch (e) {
    res.json({ error: e.message });
  }
}));

// ── API: Merge folder into another (flatten files) ──────────────
app.patch('/api/folders/:name/move', asyncHandler(async (req, res) => {
  const { targetFolder } = req.body;
  if (!targetFolder) return res.status(400).json({ error: 'targetFolder required' });
  try {
    const result = await storage_provider.moveFolder(req.params.name, targetFolder);
    res.json(result);
  } catch (e) {
    res.status(e.message === 'Source folder not found' ? 404 : 409).json({ error: e.message });
  }
}));

// ── API: Move file between folders ──────────────────────────────
app.patch('/api/files/:folder/:filename/move', asyncHandler(async (req, res) => {
  const { targetFolder } = req.body;
  if (!targetFolder) return res.status(400).json({ error: 'targetFolder required' });
  try {
    await storage_provider.moveFile(req.params.folder, req.params.filename, targetFolder);
    res.json({ moved: true });
  } catch (e) { res.status(404).json({ error: e.message }); }
}));

// ── API: Get file content ───────────────────────────────────────
app.get('/api/files/:folder/:filename', asyncHandler(async (req, res) => {
  const data = await storage_provider.getFile(req.params.folder, req.params.filename);
  if (!data) return res.status(404).json({ error: 'File not found' });
  res.json(data);
}));

// ── API: Get file sections (chunk loading) ──────────────────────
app.get('/api/files/:folder/:filename/sections', asyncHandler(async (req, res) => {
  const from = Math.max(0, parseInt(req.query.from) || 0);
  const limit = Math.min(8, Math.max(1, parseInt(req.query.limit) || 3));
  const data = await storage_provider.getFileSections(req.params.folder, req.params.filename, from, limit);
  if (!data) return res.status(404).json({ error: 'File not found' });
  res.json(data);
}));

// ── API: Delete file ────────────────────────────────────────────
app.delete('/api/files/:folder/:filename', asyncHandler(async (req, res) => {
  await storage_provider.deleteFile(req.params.folder, req.params.filename);
  res.json({ deleted: true });
}));

// ── API: Create file via paste ──────────────────────────────────
app.post('/api/files', asyncHandler(async (req, res) => {
  const { folder, filename, content } = req.body;
  if (!filename || !content) return res.status(400).json({ error: 'Filename and content required' });
  const result = await storage_provider.createFile(folder, filename, content);
  res.json({ ...result, created: true });
}));

// ── API: Chat with persistence ──────────────────────────────────
app.post('/api/chat', asyncHandler(async (req, res) => {
  const { question, folder, filename } = req.body;
  if (!question) return res.status(400).json({ error: 'Question is required' });

  const { searchContent, searchScope } = await storage_provider.searchContent(question, folder, filename);
  if (!searchContent) {
    return res.json({ answer: 'No markdown files found. Upload some files first.', sources: [] });
  }

  const answer = intelligentSearch(question, searchContent, searchScope);
  await storage_provider.saveChatMessages(folder || '__global__', filename || '__all__', question, answer);
  res.json(answer);
}));

// ── API: Chat history ───────────────────────────────────────────
app.get('/api/chat/:folder/:filename/history', asyncHandler(async (req, res) => {
  const offset = parseInt(req.query.offset) || 0;
  const limit = parseInt(req.query.limit) || 100;
  const data = await storage_provider.getChatHistory(req.params.folder, req.params.filename, offset, limit);
  res.json(data);
}));

app.delete('/api/chat/:folder/:filename/history', asyncHandler(async (req, res) => {
  await storage_provider.clearChatHistory(req.params.folder, req.params.filename);
  res.json({ cleared: true });
}));

// ── API: Canvas Agent (sessioned planner + executor runtime) ────────
app.get('/api/canvas-agent/meta', asyncHandler(async (_req, res) => {
  const meta = await getCanvasAgentMeta();
  res.json(meta);
}));

app.get('/api/canvas-agent/voice/meta', asyncHandler(async (_req, res) => {
  const meta = await getCanvasAgentVoiceMeta();
  res.json(meta);
}));

app.post('/api/canvas-agent/voice/transcriptions', audioUpload.single('audio'), asyncHandler(async (req, res) => {
  try {
    const result = await transcribeCanvasAgentAudio({
      file: req.file,
      prompt: typeof req.body?.prompt === 'string' ? req.body.prompt : '',
    });
    res.json(result);
  } catch (err) {
    res.status(err.statusCode || 500).json({ error: err.message });
  }
}));

app.post('/api/canvas-agent/runs', asyncHandler(async (req, res) => {
  const { messages, tools, sceneContext } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array required' });
  }

  const run = await createCanvasAgentRun({
    userId: req.user?.id || 'anonymous',
    messages,
    tools,
    sceneContext,
  });
  res.status(202).json(run);
}));

app.get('/api/canvas-agent/runs/:runId', asyncHandler(async (req, res) => {
  const run = await getCanvasAgentRun(req.params.runId);
  if (!run) return res.status(404).json({ error: 'Run not found' });
  res.json(run);
}));

app.get('/api/canvas-agent/runs/:runId/events', asyncHandler(async (req, res) => {
  const since = Number.parseInt(req.query.since, 10) || 0;
  await streamCanvasAgentRunEvents({
    runId: req.params.runId,
    res,
    since,
  });
}));

app.post('/api/canvas-agent/runs/:runId/cancel', asyncHandler(async (req, res) => {
  const run = await cancelCanvasAgentRun(req.params.runId);
  if (!run) return res.status(404).json({ error: 'Run not found' });
  res.json(run);
}));

app.post('/api/canvas-agent', asyncHandler(async (req, res) => {
  const { messages, tools, sceneContext } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Messages array required' });
  }

  try {
    const result = await runCanvasTeacherAgent({
      userId: req.user?.id || 'anonymous',
      messages,
      tools,
      sceneContext,
    });
    res.json(result);
  } catch (err) {
    console.error('[Canvas Agent] error:', err);
    res.status(500).json({ error: err.message });
  }
}));

// ── Intelligent search ──────────────────────────────────────────
function intelligentSearch(question, content, scope) {
  const lines = content.split('\n');
  const q = question.toLowerCase();
  const stopWords = new Set(['the','what','how','why','when','where','which','does','can','are','is','was','were','has','have','had','this','that','with','from','for','and','but','not','about','will','would','could','should']);
  const keywords = q.replace(/[?!.,;:'"]/g, '').split(/\s+/)
    .filter(w => w.length > 2 && !stopWords.has(w));

  if (keywords.length === 0) {
    return { answer: `Couldn't extract keywords from your question. Try more specific terms.`, sources: [] };
  }

  const paragraphs = [];
  let current = [], currentFile = '', currentHeading = '';
  for (const line of lines) {
    const fm = line.match(/^## File: (.+)$/);
    if (fm) {
      if (current.length) paragraphs.push({ text: current.join('\n'), file: currentFile, heading: currentHeading });
      currentFile = fm[1]; current = []; currentHeading = ''; continue;
    }
    const hm = line.match(/^(#{1,6})\s+(.+)/);
    if (hm) {
      if (current.length) paragraphs.push({ text: current.join('\n'), file: currentFile, heading: currentHeading });
      current = []; currentHeading = hm[2];
    }
    current.push(line);
    if (line.trim() === '' && current.length > 3) {
      paragraphs.push({ text: current.join('\n'), file: currentFile, heading: currentHeading });
      current = [];
    }
  }
  if (current.length) paragraphs.push({ text: current.join('\n'), file: currentFile, heading: currentHeading });

  const scored = paragraphs.map(p => {
    const lower = p.text.toLowerCase();
    let score = 0;
    for (const kw of keywords) {
      score += (lower.split(kw).length - 1) * (kw.length > 5 ? 3 : 1);
      if (p.heading && p.heading.toLowerCase().includes(kw)) score += 5;
    }
    return { ...p, score };
  }).filter(p => p.score > 0).sort((a, b) => b.score - a.score);

  if (!scored.length) {
    return { answer: `Searched **${scope}** for "${keywords.join(', ')}" — no relevant content found.`, sources: [] };
  }

  const top = scored.slice(0, 5);
  const sources = [...new Set(top.map(r => r.file).filter(Boolean))];
  let answer = `### Results from ${scope}\n\nFound **${scored.length}** relevant sections.\n\n`;
  for (const r of top) {
    answer += '---\n\n';
    if (r.heading) answer += `**${r.heading}**\n`;
    if (r.file) answer += `*From: ${r.file}*\n\n`;
    answer += `${r.text.trim().slice(0, 600)}${r.text.length > 600 ? '...' : ''}\n\n`;
  }
  return { answer, sources };
}

// ── Local fallback data (when Supabase is unreachable) ───────────
let _localAlgos = null;
let _localProblems = null;

async function getLocalAlgorithms() {
  if (!_localAlgos) {
    try {
      const { getAllAlgorithms, getAlgorithmBySlug, getAlgorithmCategories, getAlgorithmTags } = await import('./src/lib/algorithms/registry.js');
      _localAlgos = { getAllAlgorithms, getAlgorithmBySlug, getAlgorithmCategories, getAlgorithmTags };
    } catch (e) { console.error('Failed to load local algorithms:', e.message); }
  }
  return _localAlgos;
}

async function getLocalProblems() {
  if (!_localProblems) {
    try {
      const { PROBLEMS } = await import('./src/lib/problems/problems-data.js');
      _localProblems = PROBLEMS;
    } catch (e) { console.error('Failed to load local problems:', e.message); }
  }
  return _localProblems;
}

function getLocalProblemBySlug(slug, problems) {
  if (!problems) return null;
  return problems.find(p => p.id === slug) || null;
}

function mergeWithLocalProblem(dbProblem, localProblem) {
  if (!localProblem) return dbProblem;
  return {
    ...dbProblem,
    requirementChecklist: dbProblem.requirementChecklist && Object.keys(dbProblem.requirementChecklist).length > 0
      ? dbProblem.requirementChecklist : (localProblem.requirementChecklist || {}),
    expectedAPIs: dbProblem.expectedAPIs?.length ? dbProblem.expectedAPIs : (localProblem.expectedAPIs || []),
    chaosScenarios: dbProblem.chaosScenarios?.length ? dbProblem.chaosScenarios : (localProblem.chaosScenarios || []),
    deepDiveQuestions: dbProblem.deepDiveQuestions?.length ? dbProblem.deepDiveQuestions : (localProblem.deepDiveQuestions || []),
    scoring: dbProblem.scoring && Object.keys(dbProblem.scoring).length > 0
      ? dbProblem.scoring : (localProblem.scoring || { requirements: 20, api: 15, architecture: 40, deepDive: 25 }),
  };
}

// ── Algorithm & Problem API ──────────────────────────────────────

app.get('/api/algorithms', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, category, tag, difficulty, q } = req.query;
  try {
    const result = await algorithmService.listAlgorithms({
      page: parseInt(page), limit: parseInt(limit), category, tag, difficulty, q,
    });
    if (result.data && result.data.length > 0) return res.json(result);
  } catch {}
  const local = await getLocalAlgorithms();
  if (!local) return res.json({ data: [], total: 0, page: 1, limit: 20 });
  let all = local.getAllAlgorithms();
  if (category && category !== 'All') all = all.filter(a => a.category === category);
  if (difficulty) all = all.filter(a => a.difficulty === difficulty);
  if (tag) all = all.filter(a => (a.tags || []).includes(tag));
  if (q) { const ql = q.toLowerCase(); all = all.filter(a => a.title.toLowerCase().includes(ql) || (a.shortDescription || '').toLowerCase().includes(ql)); }
  const pg = parseInt(page), lim = parseInt(limit), offset = (pg - 1) * lim;
  res.json({ data: all.slice(offset, offset + lim), total: all.length, page: pg, limit: lim });
}));

app.get('/api/algorithms/categories', asyncHandler(async (_req, res) => {
  try {
    const categories = await algorithmService.getCategories();
    if (categories && categories.length > 0) return res.json(categories);
  } catch {}
  const local = await getLocalAlgorithms();
  if (!local) return res.json([]);
  const cats = {};
  local.getAllAlgorithms().forEach(a => { cats[a.category] = (cats[a.category] || 0) + 1; });
  res.json(Object.entries(cats).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count));
}));

app.get('/api/algorithms/tags', asyncHandler(async (_req, res) => {
  try {
    const tags = await algorithmService.getTags();
    if (tags && tags.length > 0) return res.json(tags);
  } catch {}
  const local = await getLocalAlgorithms();
  if (!local) return res.json([]);
  const tagMap = {};
  local.getAllAlgorithms().forEach(a => { (a.tags || []).forEach(t => { tagMap[t] = (tagMap[t] || 0) + 1; }); });
  res.json(Object.entries(tagMap).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count));
}));

app.get('/api/algorithms/:slug', asyncHandler(async (req, res) => {
  try {
    const algo = await algorithmService.getAlgorithmBySlug(req.params.slug);
    if (algo) return res.json(algo);
  } catch {}
  const local = await getLocalAlgorithms();
  if (!local) return res.status(404).json({ error: 'Algorithm not found' });
  const algo = local.getAlgorithmBySlug(req.params.slug);
  if (!algo) return res.status(404).json({ error: 'Algorithm not found' });
  res.json(algo);
}));

app.get('/api/problems', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, difficulty, q } = req.query;
  try {
    const result = await algorithmService.listProblems({
      page: parseInt(page), limit: parseInt(limit), difficulty, q,
    });
    if (result.data && result.data.length > 0) return res.json(result);
  } catch {}
  const problems = await getLocalProblems();
  if (!problems) return res.json({ data: [], total: 0, page: 1, limit: 20 });
  let filtered = [...problems];
  if (difficulty) filtered = filtered.filter(p => p.difficulty === difficulty);
  if (q) { const ql = q.toLowerCase(); filtered = filtered.filter(p => p.title.toLowerCase().includes(ql) || (p.description || '').toLowerCase().includes(ql)); }
  const pg = parseInt(page), lim = parseInt(limit), offset = (pg - 1) * lim;
  res.json({ data: filtered.slice(offset, offset + lim).map(p => ({ id: p.id, slug: p.id, number: p.number, title: p.title, icon: p.icon, difficulty: p.difficulty })), total: filtered.length, page: pg, limit: lim });
}));

app.get('/api/problems/:slug', asyncHandler(async (req, res) => {
  const localProblems = await getLocalProblems();
  const localP = getLocalProblemBySlug(req.params.slug, localProblems);

  try {
    const problem = await algorithmService.getProblemForClient(req.params.slug);
    if (problem) {
      const merged = mergeWithLocalProblem(problem, localP);
      const safeDeepDive = (merged.deepDiveQuestions || []).map(q => ({ question: q.question, options: q.options }));
      const safeChaos = (merged.chaosScenarios || []).map(s => ({ label: s.label, type: s.type }));
      return res.json({ ...merged, deepDiveQuestions: safeDeepDive, chaosScenarios: safeChaos });
    }
  } catch {}

  if (!localP) return res.status(404).json({ error: 'Problem not found' });
  const safeDeepDive = (localP.deepDiveQuestions || []).map(q => ({ question: q.question, options: q.options }));
  const safeChaos = (localP.chaosScenarios || []).map(s => ({ label: s.label, type: s.type }));
  const safeTests = (localP.testCases || []).map(tc => ({ name: tc.name, type: tc.type, ...(tc.rps ? { rps: tc.rps } : {}) }));
  res.json({ id: localP.id, slug: localP.id, number: localP.number, icon: localP.icon, title: localP.title, difficulty: localP.difficulty, description: localP.description, requirements: localP.requirements, constraints: localP.constraints, hints: localP.hints, testCases: safeTests, requirementChecklist: localP.requirementChecklist, expectedAPIs: localP.expectedAPIs, chaosScenarios: safeChaos, deepDiveQuestions: safeDeepDive });
}));

const submitLimiter = rateLimit({ windowMs: 60 * 1000, max: 30, message: { error: 'Too many submissions, try again later' } });

app.post('/api/problems/:slug/run', asyncHandler(async (req, res) => {
  let problem = null;
  try { problem = await algorithmService.getProblemFull(req.params.slug); } catch {}
  const localProblems = await getLocalProblems();
  const localP = getLocalProblemBySlug(req.params.slug, localProblems);
  if (problem && localP) problem = mergeWithLocalProblem(problem, localP);
  else if (!problem && localP) problem = localP;
  if (!problem) return res.status(404).json({ error: 'Problem not found' });

  const { components: rawComps, connections: rawConns } = req.body;
  const input = sanitizeInput(rawComps, rawConns);
  if (input.error) return res.status(400).json({ error: input.error });

  const testResults = judgeRun(problem, input.components, input.connections);
  res.json({ testResults });
}));

app.post('/api/problems/:slug/submit', submitLimiter, asyncHandler(async (req, res) => {
  let problem = null;
  try { problem = await algorithmService.getProblemFull(req.params.slug); } catch {}
  const localProblems = await getLocalProblems();
  const localP = getLocalProblemBySlug(req.params.slug, localProblems);
  if (problem && localP) problem = mergeWithLocalProblem(problem, localP);
  else if (!problem && localP) problem = localP;
  if (!problem) return res.status(404).json({ error: 'Problem not found' });

  const { components: rawComps, connections: rawConns, hintsUsed, deepDiveAnswers } = req.body;
  const input = sanitizeInput(rawComps, rawConns);
  if (input.error) return res.status(400).json({ error: input.error });

  const testResults = judgeRun(problem, input.components, input.connections);
  const chaosResults = judgeChaos(problem, input.components, input.connections);
  const deepDiveResult = scoreDeepDive(problem, deepDiveAnswers || {});
  const scoring = computeFullScore(testResults, chaosResults, deepDiveResult, hintsUsed || 0);

  let submissionId = null;
  try {
    submissionId = await algorithmService.saveSubmission({
      problem_slug: req.params.slug,
      components: input.components,
      connections: input.connections,
      test_results: testResults,
      chaos_results: chaosResults,
      arch_score: scoring.archScore,
      deep_dive_score: scoring.deepDiveScore,
      hints_used: hintsUsed || 0,
      total_score: scoring.totalScore,
      verdict: scoring.verdict,
    });
  } catch (e) {
    console.error('Failed to save submission:', e.message);
  }

  res.json({
    testResults,
    chaosResults,
    deepDive: deepDiveResult,
    ...scoring,
    submissionId,
  });
}));

// ── Code Execution: Judge0 CE (primary) → Wandbox (fallback) ────
const JUDGE0_LANG_IDS = { cpp: 54, python: 92, java: 91, javascript: 93 };

const WANDBOX_COMPILERS = {
  cpp: 'gcc-13.2.0',
  python: 'cpython-3.12.7',
  java: 'openjdk-jdk-22+36',
  javascript: 'nodejs-20.17.0',
};

const JUDGE0_STATUS = {
  1: { label: 'In Queue', type: 'pending' },
  2: { label: 'Processing', type: 'pending' },
  3: { label: 'Accepted', type: 'success' },
  4: { label: 'Wrong Answer', type: 'error' },
  5: { label: 'Time Limit Exceeded', type: 'warning' },
  6: { label: 'Compilation Error', type: 'error' },
  7: { label: 'Runtime Error (SIGSEGV)', type: 'error' },
  8: { label: 'Runtime Error (SIGXFSZ)', type: 'error' },
  9: { label: 'Runtime Error (SIGFPE)', type: 'error' },
  10: { label: 'Runtime Error (SIGABRT)', type: 'error' },
  11: { label: 'Runtime Error (NZEC)', type: 'error' },
  12: { label: 'Runtime Error (Other)', type: 'error' },
  13: { label: 'Internal Error', type: 'error' },
  14: { label: 'Exec Format Error', type: 'error' },
};

function decode64(s) {
  if (!s) return '';
  try { return Buffer.from(s, 'base64').toString('utf-8'); } catch { return s; }
}

async function executeViaJudge0(source_code, language, stdin) {
  const langId = JUDGE0_LANG_IDS[language];
  if (!langId) return null;

  const headers = { 'Content-Type': 'application/json' };
  if (JUDGE0_API_KEY) {
    headers['X-RapidAPI-Key'] = JUDGE0_API_KEY;
    headers['X-RapidAPI-Host'] = JUDGE0_HOST;
  }

  const body = {
    source_code: Buffer.from(source_code).toString('base64'),
    language_id: langId,
    stdin: stdin ? Buffer.from(stdin).toString('base64') : '',
    base64_encoded: true,
    cpu_time_limit: 10,
    wall_time_limit: 15,
    memory_limit: 256000,
    compiler_options: language === 'cpp' ? '-O2 -std=c++17' : '',
  };

  const startTime = Date.now();
  const submitRes = await fetch(`${JUDGE0_ENDPOINT}/submissions?base64_encoded=true&wait=true&fields=*`, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(20000),
  });

  if (!submitRes.ok) return null;
  const result = await submitRes.json();
  const elapsed = result.time || ((Date.now() - startTime) / 1000).toFixed(3);

  return {
    stdout: decode64(result.stdout),
    stderr: decode64(result.stderr),
    compile_output: decode64(result.compile_output),
    message: decode64(result.message),
    status: {
      id: result.status?.id || 13,
      description: result.status?.description || 'Unknown',
    },
    time: String(elapsed),
    memory: result.memory ? `${(result.memory / 1024).toFixed(1)} MB` : null,
    engine: 'judge0',
  };
}

async function executeViaWandbox(source_code, language, stdin) {
  const compiler = WANDBOX_COMPILERS[language];
  if (!compiler) return null;

  const startTime = Date.now();
  const wbRes = await fetch('https://wandbox.org/api/compile.json', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      code: source_code,
      compiler,
      stdin: stdin || '',
      'compiler-option-raw': language === 'cpp' ? '-O2\n-std=c++17' : '',
    }),
    signal: AbortSignal.timeout(30000),
  });

  if (!wbRes.ok) return null;
  const result = await wbRes.json();
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(3);

  const hasCompileError = result.compiler_error && result.status !== '0' && !result.program_output;
  const hasRuntimeError = result.signal && result.signal !== '';
  const exitCode = parseInt(result.status || '0', 10);

  let statusId = 3, statusDesc = 'Accepted';
  if (hasCompileError) { statusId = 6; statusDesc = 'Compilation Error'; }
  else if (hasRuntimeError) { statusId = 7; statusDesc = `Runtime Error (${result.signal})`; }
  else if (exitCode !== 0) { statusId = 11; statusDesc = `Runtime Error (exit code ${exitCode})`; }

  return {
    stdout: result.program_output || '',
    stderr: result.program_error || '',
    compile_output: result.compiler_error || result.compiler_output || '',
    message: result.compiler_message || '',
    status: { id: statusId, description: statusDesc },
    time: elapsed,
    memory: null,
    engine: 'wandbox',
  };
}

const executeLimiter = rateLimit({ windowMs: 60 * 1000, max: 30, message: { error: 'Too many executions, slow down' } });

app.post('/api/sql/execute', executeLimiter, asyncHandler(async (req, res) => {
  const { source_code, language } = req.body;
  if (!source_code || !language) {
    return res.status(400).json({ error: 'source_code and language are required' });
  }
  if (typeof source_code !== 'string' || source_code.length > 100000) {
    return res.status(400).json({ error: 'source_code must be a string under 100KB' });
  }
  const supported = ['sqlite', 'mysql', 'oracle', 'sql'];
  if (!supported.includes(language)) {
    return res.status(400).json({ error: `Unsupported language. Use: ${supported.join(', ')}` });
  }
  
  const result = await executeSql(source_code, language === 'sql' ? 'sqlite' : language);
  res.json(result);
}));

app.post('/api/execute', executeLimiter, asyncHandler(async (req, res) => {
  const { source_code, language, stdin } = req.body;
  if (!source_code || !language) {
    return res.status(400).json({ error: 'source_code and language are required' });
  }
  if (typeof source_code !== 'string' || source_code.length > 100000) {
    return res.status(400).json({ error: 'source_code must be a string under 100KB' });
  }
  const supported = ['cpp', 'python', 'java', 'javascript'];
  if (!supported.includes(language)) {
    return res.status(400).json({ error: `Unsupported language. Use: ${supported.join(', ')}` });
  }

  // Primary: self-hosted Judge0 engine (local compilers)
  const localResult = await executeSubmission(source_code, language, stdin || '');
  if (localResult.status.id !== J0_STATUS.INTERNAL.id) {
    return res.json(localResult);
  }

  // Fallback 1: Judge0 Cloud API
  if (JUDGE0_API_KEY) {
    try {
      const j0 = await executeViaJudge0(source_code, language, stdin);
      if (j0) return res.json(j0);
    } catch (e) {
      console.warn('[Execute] Judge0 API failed:', e.message);
    }
  }

  // Fallback 2: Wandbox
  try {
    const wb = await executeViaWandbox(source_code, language, stdin);
    if (wb) return res.json(wb);
  } catch (e) {
    console.warn('[Execute] Wandbox failed:', e.message);
  }

  res.status(502).json({ error: 'All execution backends unavailable.' });
}));

// ── Error handler ───────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error('Server error:', err.message);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

// ── SPA fallback ────────────────────────────────────────────────
if (existsSync(distPath)) {
  app.get('*', (_req, res) => res.sendFile(join(distPath, 'index.html')));
}

// ── Start Server ─────────────────────────────────────────────────
const j0Langs = getAvailableLanguages();

app.listen(PORT, () => {
  console.log(`\n  InkDrop API running at http://localhost:${PORT}`);
  console.log(`  Execution Engine (local): ${Object.entries(j0Langs).map(([k, v]) => `${k}=${v ? 'OK' : 'MISSING'}`).join(', ')}`);
  if (JUDGE0_API_KEY) console.log(`  Judge0 Cloud API: configured`);
  console.log(`  Storage: Supabase (cloud)\n`);
});
