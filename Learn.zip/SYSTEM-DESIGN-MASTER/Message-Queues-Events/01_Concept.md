# Message Queues and Events — Concept

> **Permanent Recall:** Use message queues when you want **asynchronous work**, **service decoupling**, **buffering during spikes**, or **one event to trigger many downstream actions**. Core building blocks are **producer**, **broker**, and **consumer**. The main split is **queue vs pub/sub topic**. The main tool split is **Kafka vs RabbitMQ vs SQS/SNS**.

---

## Why This Topic Matters

Message queues show up whenever a system needs to:

- avoid blocking on slow downstream work
- survive traffic spikes
- let multiple services react independently
- process work reliably even if consumers restart
- support event-driven design patterns like CQRS, Event Sourcing, and Saga

In interviews, this topic is often the bridge between:

- microservices
- scalability
- reliability
- eventual consistency

---

## Core Components


| Component    | What It Does                                       |
| ------------ | -------------------------------------------------- |
| **Producer** | Sends a message or event                           |
| **Broker**   | Stores, routes, and delivers messages              |
| **Consumer** | Reads and processes messages                       |
| **Queue**    | One message is handled by one consumer             |
| **Topic**    | One event can be seen by many consumers            |
| **Offset**   | Position of a message in a Kafka partition         |
| **DLQ**      | Stores failed messages after retries are exhausted |


```text
Basic flow:

Producer -> Broker -> Consumer
```

---

## Queue vs Pub/Sub

This is the first distinction to make in any messaging discussion.


| Model                      | Meaning                                              | Best For                                       |
| -------------------------- | ---------------------------------------------------- | ---------------------------------------------- |
| **Queue / Point-to-Point** | One message is processed by one consumer             | Jobs, background tasks, work distribution      |
| **Pub/Sub / Topic**        | One event is delivered to many independent consumers | Notifications, analytics, event-driven systems |


```text
POINT-TO-POINT

Producer -> [Queue] -> Consumer A
                   -> Consumer B

Each message is handled once.

PUB/SUB

Producer -> [Topic] -> Billing
                   -> Inventory
                   -> Analytics

Each event fans out to many consumers.
```

**Interview rule:**  
If only one worker should do the job, think queue.  
If many services should react, think pub/sub.

---

## Sync vs Async

Messaging is mainly about replacing direct waiting with delayed processing.


| Sync                       | Async                                  |
| -------------------------- | -------------------------------------- |
| Caller waits for response  | Caller returns quickly                 |
| Tight coupling             | Loose coupling                         |
| Failure propagates quickly | Failure can be retried later           |
| Good for immediate answers | Good for background or multi-step work |


```text
SYNC:
Service A -> Service B -> response

ASYNC:
Service A -> Broker -> return now
                    -> Service B processes later
```

Use async when the caller does **not** need the final result immediately.

---

## Kafka at a High Level

Kafka is best thought of as a **distributed commit log**.


| Term               | Meaning                                |
| ------------------ | -------------------------------------- |
| **Topic**          | Logical stream of events               |
| **Partition**      | Ordered append-only log inside a topic |
| **Broker**         | Kafka server that stores partitions    |
| **Consumer Group** | Group of consumers sharing partitions  |
| **Offset**         | Position of a record in a partition    |


```text
Topic: orders

Partition 0: [0][1][2][3]...
Partition 1: [0][1][2][3]...
Partition 2: [0][1][2][3]...

Consumer group:
  C1 reads P0
  C2 reads P1
  C3 reads P2
```

Kafka is strong when you need:

- very high throughput
- replay from old offsets
- event streaming
- per-key ordering
- event sourcing or analytics pipelines

**Key idea:** Kafka usually retains data even after consumers read it.

---

## RabbitMQ at a High Level

RabbitMQ is a traditional message broker built around **exchanges** and **queues**.


| Term            | Meaning                                     |
| --------------- | ------------------------------------------- |
| **Exchange**    | Receives published messages and routes them |
| **Queue**       | Stores messages for consumers               |
| **Binding**     | Rule connecting exchange to queue           |
| **Routing Key** | Value used for routing decisions            |


```text
Producer -> Exchange -> Queue -> Consumer

Example:
Producer -> [topic exchange]
                  -> billing queue
                  -> analytics queue
                  -> notifications queue
```

RabbitMQ is strong when you need:

- flexible routing
- traditional task queues
- request/work distribution
- simpler messaging than Kafka

**Key idea:** RabbitMQ usually deletes a message after it is acknowledged.

---

## SQS and SNS at a High Level

AWS splits managed messaging into two simple services.


| Service | Model   | Use Case                           |
| ------- | ------- | ---------------------------------- |
| **SQS** | Queue   | Background jobs, decoupling, retry |
| **SNS** | Pub/Sub | Fan-out to multiple destinations   |


```text
Producer -> SNS topic -> SQS queue A -> Consumer A
                      -> SQS queue B -> Consumer B
                      -> Lambda
```

Use SQS/SNS when:

- you are already in AWS
- you want low operational overhead
- you do not need Kafka-style replay or RabbitMQ-style rich routing

---

## Delivery Guarantees

This is one of the most important interview sections.


| Guarantee         | Meaning                                    | Practical Trade-Off               |
| ----------------- | ------------------------------------------ | --------------------------------- |
| **At-most-once**  | No duplicates, but messages may be lost    | Fast, but risky                   |
| **At-least-once** | Messages are retried until processed       | Reliable, but duplicates possible |
| **Exactly-once**  | No loss and no duplicates in defined scope | Complex and expensive             |


For most real systems:

- use **at-least-once**
- make consumers **idempotent**

That is the standard production answer.

---

## Ordering Guarantees

Ordering is never free.


| Type                    | Meaning                                     | Cost                                        |
| ----------------------- | ------------------------------------------- | ------------------------------------------- |
| **Per-partition order** | Kafka guarantees order inside one partition | Good throughput                             |
| **Per-key order**       | Same key goes to same partition             | Common practical choice                     |
| **Global order**        | Entire topic is ordered                     | Usually requires one partition, hurts scale |


**Rule:** If order matters for an entity like `order_id`, use that entity as the partition key.

---

## Dead Letter Queue

Some messages will keep failing no matter how many times you retry.

```text
Main queue -> Consumer fails -> Retry -> Retry -> Retry -> DLQ
```

A DLQ exists so:

- poison messages do not block the whole system
- failures can be inspected later
- fixed messages can be replayed

**Interview rule:** Always mention retry policy + DLQ together.

---

## Event-Driven Patterns Built on Messaging

### Event-Driven Architecture

Services communicate by publishing events instead of directly calling each other.

```text
Order Service -> order.created event
               -> Billing reacts
               -> Inventory reacts
               -> Analytics reacts
```

### CQRS

Separate the write path from the read path.

```text
Command -> Write model -> Event -> Read model projection
Query   -> Read model
```

# What is an Event?

### 👉 Simple definition:

**An event is a fact that something already happened in the past.**

---

### 🧠 Key idea:

- Immutable (cannot change)
- Represents a **state change**
- Timestamped
- Named in **past tense**  
Event Sourcing

Store the sequence of events, not just the latest state.

```text
Instead of:
balance = 100

Store:
Deposit +50
Withdraw -20
Deposit +70
```

### Saga

Coordinate multi-service business workflows without a global distributed transaction.

Two styles:

- **Choreography**: services react to each other's events
- **Orchestration**: a central coordinator drives the workflow

---

## Kafka vs RabbitMQ vs SQS


| Factor                     | Kafka                              | RabbitMQ                         | SQS                         |
| -------------------------- | ---------------------------------- | -------------------------------- | --------------------------- |
| **Core model**             | Distributed log                    | Broker with queues/exchanges     | Managed queue               |
| **Replay**                 | Yes                                | Usually no                       | No                          |
| **Routing flexibility**    | Moderate                           | High                             | Low                         |
| **Throughput**             | Very high                          | High                             | High enough for many apps   |
| **Operational complexity** | Higher                             | Medium                           | Lowest                      |
| **Best fit**               | Event streaming, analytics, replay | Task queues, routing-heavy flows | AWS-native async processing |


Quick pick:

- need replay or streaming -> Kafka
- need routing-heavy broker -> RabbitMQ
- need managed simple queue on AWS -> SQS/SNS

---

## Interview Answer Template

When messaging appears in a design question, structure your answer like this:

1. Why async is needed
2. Queue or pub/sub
3. Which broker and why
4. Delivery guarantee
5. Ordering requirement
6. Retry + DLQ
7. Consumer scaling and lag monitoring

---

## 30-SECOND REVISION BOX

```text
USE MQ FOR: async work, decoupling, buffering, event fan-out
QUEUE: one consumer handles a message
PUB/SUB: many consumers react to one event
KAFKA: distributed log, replay, high throughput
RABBITMQ: exchanges + queues, flexible routing
SQS/SNS: managed AWS queue + pub/sub
DELIVERY: at-least-once + idempotent consumer is the practical default
ORDERING: Kafka guarantees order within a partition, not globally
DLQ: always mention retries + DLQ together
PATTERNS: Event-driven, CQRS, Event Sourcing, Saga
```

---

**Next: [[02_Mental-Model]]**