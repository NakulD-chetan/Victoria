import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function layoutLinear(parent) {
  const n = parent.length;
  const nodes = Array.from({ length: n }, (_, i) => ({
    id: String(i),
    label: String(i),
    nx: (i + 0.5) / n * 0.82 + 0.09,
    ny: 0.52,
  }));
  const edges = [];
  for (let i = 0; i < n; i++) if (parent[i] !== i) edges.push([String(i), String(parent[i])]);
  return { nodes, edges };
}

function generateSteps() {
  const parent = [0, 0, 1, 2, 3, 5, 5, 6];
  const steps = [];
  steps.push({ type: 'init', parent: [...parent], highlight: [], note: 'Start forest' });
  const x = 7;
  steps.push({ type: 'find', parent: [...parent], cur: x, highlight: [x], note: `Find(${x})` });
  [7, 6, 5].forEach((node) => {
    steps.push({ type: 'hop', parent: [...parent], cur: node, next: parent[node], highlight: [node], note: `Jump ${node}→${parent[node]}` });
  });
  const root = 5;
  steps.push({ type: 'root-found', parent: [...parent], root, highlight: [root], note: `Root ${root}` });
  const p2 = [...parent];
  p2[7] = root;
  steps.push({ type: 'compress', parent: p2, target: 7, root, highlight: [7, root], note: 'Point 7 directly to root' });
  const p3 = [...p2];
  p3[6] = root;
  steps.push({ type: 'compress', parent: p3, target: 6, root, highlight: [6, root], note: 'Point 6 directly to root' });
  steps.push({ type: 'done', parent: p3, highlight: [], note: '✓ Path compressed' });
  return steps;
}

export default function PathCompressionVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Path compression on find' });
    const { nodes, edges } = layoutLinear(steps[0].parent);
    canvasRef.current?.setState({ nodes, edges, colors: {}, labels: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const { nodes, edges } = layoutLinear(step.parent);
    const colors = {};
    (step.highlight || []).forEach((id) => {
      colors[String(id)] = 'compare';
    });
    if (step.type === 'compress') colors[String(step.root)] = 'active';
    if (step.note) store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.note });
    canvasRef.current?.setState({ nodes, edges, colors, labels: {} });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
