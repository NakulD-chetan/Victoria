# How URL Shortener Works - System Design

> Source: https://systemdesign.one/url-shortening-system-design/

## One-Line Summary
A URL shortener converts long URLs into short, readable links using a Token Range service with base62 encoding, backed by NoSQL storage and multi-layer caching for a read-heavy system (100:1 read-write ratio).

## Key Requirements

### Functional
- User enters a long URL, system returns a short URL (max 9 chars)
- Short URL redirects to the original long URL
- 1-to-1 mapping between long and short URLs
- Short URLs are collision-free and non-predictable
- Optional custom short URLs
- Optional expiry time
- Analytics on redirection counts (not real-time)
- SEO-friendly (301 redirects)

### Non-Functional
- High availability and fault tolerance
- Low latency (especially for reads/redirects)
- High scalability (100M DAU for writes)
- Durable (persist for 5 years by default)
- Read-heavy system (100:1 read-write ratio)

## Capacity Planning (Back of Envelope)

| Metric | Value |
|--------|-------|
| DAU (writes) | 100 million |
| Write QPS | ~1,200/sec |
| Read QPS | ~100,000/sec (100x writes) |
| Record size | ~2.5 KB |
| Total storage (5 years) | ~456 TB |
| Cache needed (80/20 rule) | ~50 GB/day |

## High-Level Architecture

```
WRITE PATH:
Client --> Load Balancer --> KGS (Key Generation Service)
                                |
                    Token Range Service (Zookeeper)
                                |
                    Token Service (generates short URL)
                                |
                    Encoding Service (base62)
                                |
                    NoSQL DB (DynamoDB) + Bloom Filter

READ PATH:
Client --> DNS --> CDN --> Reverse Proxy --> Load Balancer
                                               |
                                          Cache (Redis)
                                               |
                                          NoSQL DB
                                               |
                                     301 Redirect to long URL
```

## Core Components Deep Dive

### 1. Short URL Generation (3 Approaches Compared)

#### Approach A: Random ID Generator (NOT recommended)
- Generate random IDs using UUID
- Problems: high collision probability, breaks 1-to-1 mapping, requires DB lookups to check duplicates

#### Approach B: Hashing (MD5/SHA256) (NOT recommended)
- Hash the long URL, take first 7 chars of base62 output
- Problems: collisions from truncation, predictable output

#### Approach C: Token Range (RECOMMENDED)
- Token service has an internal counter (monotonically increasing)
- **Token Range Service** (Zookeeper/DynamoDB) assigns non-overlapping ranges to each token service instance
- When a range is exhausted, token service requests a fresh range
- Collision-free by design!
- O(1) time complexity for generation
- Randomize output range to reduce predictability

### 2. Encoding (Base62)
- Characters: `[a-zA-Z0-9]` = 62 characters
- 7 characters → 62^7 = **3.5 trillion** unique short URLs
- That lasts 100+ years at 1000 URLs/second
- Base58 variant avoids confusing chars: O/0, I/l
- Time complexity: O(1) since length is fixed

### 3. Database Design
- **URL Table** (NoSQL - DynamoDB/MongoDB): short_url → long_url, created_at, expires, user_id
- **Users Table** (SQL - Postgres): user_id, name, email, api_key
- **Inverted Index** (Key-Value): long_url → short_url (for 1-to-1 mapping)
- Partition key: short_url (optimized for read path)

### 4. Read Path (URL Redirection)
- **Multi-layer caching** to handle 100:1 read-heavy ratio:
  - Client cache
  - CDN (closest to user)
  - Reverse proxy
  - Dedicated cache servers (Redis/Memcached)
- **Cache-aside pattern**: check cache first → if miss, query DB → populate cache
- **LRU eviction** when cache is full
- **Bloom filter** prevents cache thrashing (most URLs accessed only once)
- HTTP 301 (Moved Permanently) with `cache-control: public`

### 5. Bloom Filters (Used Twice)
1. **Write path**: Check if long URL already exists before generating new short URL (avoids expensive DB lookup)
2. **Read path**: Check if short URL exists before querying cache/DB (return 404 immediately if not found)
- O(1) lookups, memory-efficient, but can have false positives

### 6. Concurrency Handling
- **Distributed lock** (Redis/Chubby) on the long URL when same URL submitted simultaneously
- Mutex/semaphore on token service atomic data structures
- Reverse proxy collapsed forwarding for identical requests

## API Design

```
# Shorten URL
PUT /url
Body: { long_url, tags[], expires, custom (optional) }
Response: { short_url, long_url, created_at, is_active }

# Redirect
GET /:short_url
Response: 301 Moved Permanently, Location: <long_url>

# Error cases:
# 401 Unauthorized (no/invalid credentials)
# 403 Forbidden (insufficient privileges)
# 404 Not Found (short URL doesn't exist)
```

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Token Range (not hash/random) | Collision-free, O(1), scalable |
| Base62 encoding, 7 chars | 3.5T URLs, readable, no confusing chars |
| NoSQL for URLs | Read-heavy, high throughput, no joins needed |
| SQL for Users | ACID, relational data, complex queries |
| Bloom filter | Avoid expensive DB lookups, O(1) |
| Multi-layer cache | 100:1 read ratio needs aggressive caching |
| 301 redirect (not 302) | SEO friendly, cacheable |
| Distributed lock | Maintain 1-to-1 mapping under concurrency |

## Scaling Strategies

1. **Token service**: scale via consistent hashing + non-overlapping ranges from Zookeeper
2. **Cache**: partition by short_url key, leader-follower replication
3. **Database**: sharding by short_url as partition key
4. **Read path**: CDN + reverse proxy + collapsed forwarding
5. **Write path**: separate from read path for independent scaling
6. **Cleanup**: dedicated service during non-peak hours + lazy deletion on access

## Interview Tips

- This is one of the MOST COMMON system design questions -- know it cold
- Start with requirements and capacity estimation (show the math)
- Explain all 3 URL generation approaches, then justify Token Range
- Draw the read and write paths SEPARATELY (they scale differently)
- Mention **Bloom filter** -- it shows depth of knowledge
- Discuss **301 vs 302 redirect** tradeoff (SEO vs analytics)
- Talk about **concurrency** with distributed locks for 1-to-1 mapping
- Don't forget **analytics pipeline**: Kafka → HDFS → Hadoop → Redshift

## Quick Revision (5 bullet points)

1. **Token Range + Base62 encoding** = collision-free short URL generation with O(1) time; 7 chars gives 3.5 trillion unique URLs
2. **Read path dominates** (100:1 ratio) → multi-layer caching: CDN → Reverse Proxy → Redis → NoSQL DB
3. **Bloom filters** prevent expensive DB lookups on both write path (does long URL exist?) and read path (does short URL exist?)
4. **NoSQL (DynamoDB)** for URL table + **SQL (Postgres)** for Users + **inverted index** for long→short mapping
5. **Distributed lock** on long URL ensures 1-to-1 mapping under concurrent requests; token range service (Zookeeper) prevents range collisions
