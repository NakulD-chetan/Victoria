# Internals: RabbitMQ Deep Dive

> **Permanent Recall:** RabbitMQ is built on **Erlang/OTP** (lightweight processes, actor model, hot code reload). Uses **AMQP 0-9-1** wire protocol: Connection → Channel (multiplexed) → Exchange → Binding → Queue. Messages are **pushed** to consumers (vs Kafka pull). Queue is the unit of storage: messages in memory + disk (lazy queues: disk-first). Flow control: **credit-based** back-pressure from queue to channel to connection to TCP. Quorum queues (Raft-based) replace classic mirrored queues for HA.

---

## Why This Matters

RabbitMQ and Kafka are often grouped together as "message brokers," but their internal models are very different.

RabbitMQ is the better study case for understanding:

- broker-side routing
- push-based delivery
- exchange and queue separation
- flow control in a classic message broker

This file helps you explain not just what RabbitMQ does, but why it feels different from Kafka.

---

## Erlang/OTP — Why RabbitMQ Chose It

```
ERLANG RUNTIME (BEAM VM):

RabbitMQ is written in Erlang, running on the BEAM virtual machine.
This choice fundamentally shapes RabbitMQ's architecture.

ERLANG PROCESSES (not OS processes!):
  ┌──────────────────────────────────────────────────────────┐
  │ BEAM VM (single OS process)                               │
  │                                                          │
  │  Erlang Process    Erlang Process    Erlang Process       │
  │  ┌────────────┐    ┌────────────┐    ┌────────────┐      │
  │  │ Connection │    │ Channel    │    │ Queue      │      │
  │  │ handler    │    │ handler    │    │ process    │      │
  │  │            │    │            │    │            │      │
  │  │ ~2 KB heap │    │ ~2 KB heap │    │ ~2 KB heap │      │
  │  │ Own mailbox│    │ Own mailbox│    │ Own mailbox│      │
  │  │ Own GC     │    │ Own GC     │    │ Own GC     │      │
  │  └────────────┘    └────────────┘    └────────────┘      │
  │  ... thousands of lightweight processes ...               │
  │                                                          │
  │  Scheduler threads (1 per CPU core):                      │
  │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐                       │
  │  │ S0  │ │ S1  │ │ S2  │ │ S3  │  (4-core machine)     │
  │  │     │ │     │ │     │ │     │                        │
  │  │runs │ │runs │ │runs │ │runs │                        │
  │  │procs│ │procs│ │procs│ │procs│                        │
  │  └─────┘ └─────┘ └─────┘ └─────┘                       │
  └──────────────────────────────────────────────────────────┘

KEY ERLANG FEATURES FOR RABBITMQ:

  1. LIGHTWEIGHT PROCESSES:
     - ~2 KB initial heap (vs OS thread: ~1 MB stack)
     - Can have millions of processes (one per queue, channel, etc.)
     - Preemptively scheduled by BEAM (fair, no starvation)
     - No shared memory: communicate via message passing (actor model)

  2. ISOLATED GARBAGE COLLECTION:
     - Each process has its OWN heap and GC
     - GC of one process doesn't affect others
     - No "stop-the-world" GC pauses (unlike JVM)
     - A queue GC doesn't pause other queues

  3. FAULT TOLERANCE (Let It Crash):
     - Process crashes → supervisor restarts it
     - "Supervision tree" hierarchy
     - A bad message crashing a channel → just that channel restarts
     - Other connections/channels unaffected

  4. DISTRIBUTION:
     - Erlang nodes connect and communicate natively
     - RabbitMQ cluster = Erlang distributed node cluster
     - Process on Node A sends message to process on Node B
     - Same API for local and remote communication

  5. HOT CODE RELOAD:
     - Can upgrade code without stopping the node
     - Used for RabbitMQ plugin loading
```

---

## AMQP 0-9-1 Protocol — Wire Level

```
AMQP CONNECTION LIFECYCLE:

┌───────────────────────────────────────────────────────────────┐
│                                                               │
│ 1. TCP CONNECTION:                                            │
│    Client connects to RabbitMQ port 5672                      │
│                                                               │
│ 2. PROTOCOL HEADER:                                           │
│    Client sends: "AMQP" + 0x00 + 0x00 + 0x09 + 0x01          │
│    (8 bytes: protocol identifier + version 0-9-1)             │
│                                                               │
│ 3. CONNECTION NEGOTIATION:                                    │
│    Server → Connection.Start (capabilities, mechanisms)       │
│    Client → Connection.Start-Ok (auth mechanism, credentials) │
│    Server → Connection.Tune (channel-max, frame-max, heartbeat)
│    Client → Connection.Tune-Ok (agreed values)                │
│    Client → Connection.Open (vhost)                           │
│    Server → Connection.Open-Ok                                │
│                                                               │
│ 4. CHANNEL CREATION (multiplexing):                           │
│    Client → Channel.Open (channel-id=1)                       │
│    Server → Channel.Open-Ok                                   │
│    Client → Channel.Open (channel-id=2)                       │
│    Server → Channel.Open-Ok                                   │
│    ... multiple channels on ONE TCP connection                │
│                                                               │
│ 5. OPERATIONS (on a channel):                                 │
│    Declare exchange, declare queue, bind, publish, consume     │
│                                                               │
│ 6. CLOSE:                                                     │
│    Channel.Close → Channel.Close-Ok                           │
│    Connection.Close → Connection.Close-Ok                     │
│    TCP FIN                                                    │
└───────────────────────────────────────────────────────────────┘
```

### AMQP Frame Format (Binary Wire Protocol)

```
AMQP FRAME FORMAT:

Every AMQP communication is wrapped in frames:

  ┌──────────────────────────────────────────────────────┐
  │ AMQP FRAME (on the wire):                            │
  │                                                      │
  │ Byte 0:       Frame type (1 byte)                    │
  │                 1 = Method frame                      │
  │                 2 = Content header frame              │
  │                 3 = Content body frame                │
  │                 8 = Heartbeat frame                   │
  │ Bytes 1-2:    Channel number (2 bytes, uint16)       │
  │ Bytes 3-6:    Payload size (4 bytes, uint32)         │
  │ Bytes 7..N:   Payload                                │
  │ Byte N+1:     Frame-end marker: 0xCE                 │
  └──────────────────────────────────────────────────────┘

  Max frame size: negotiated during Connection.Tune
  Default: 131072 bytes (128 KB)
  Large messages: split across multiple body frames

PUBLISHING A MESSAGE — FRAME SEQUENCE:

  To publish a 50 KB message:

  Frame 1: Method frame (channel=1)
    Basic.Publish {exchange="orders", routing_key="order.created"}

  Frame 2: Content header frame (channel=1)
    {content-type: "application/json",
     delivery-mode: 2 (persistent),
     content-length: 51200,
     timestamp: 1710000000,
     message-id: "uuid-123"}

  Frame 3: Content body frame (channel=1)
    [first 128KB of message body]  (or less if msg < frame-max)

  (Frame 4: more body frames if message > frame-max)

CHANNEL MULTIPLEXING:
  ┌──────────────────────────────────────────────────────┐
  │ Single TCP Connection, frames interleaved by channel: │
  │                                                      │
  │ [Ch1:Method] [Ch2:Method] [Ch1:Header] [Ch1:Body]   │
  │ [Ch2:Header] [Ch2:Body] [Ch3:Method] ...             │
  │                                                      │
  │ Each channel: independent sequence of operations      │
  │ One channel blocked → others still flow               │
  │ Typical: 1 channel per thread                         │
  │ Channel is the unit of concurrency in AMQP            │
  └──────────────────────────────────────────────────────┘
```

---

## Exchange Internals — Routing Messages

```
EXCHANGE TYPES AND ROUTING ALGORITHMS:

When a message is published to an exchange, the exchange
decides which queue(s) receive it based on bindings.

1. DIRECT EXCHANGE:
   ┌────────────────────────────────────────────────────────┐
   │ Routing: exact match of routing_key to binding key     │
   │                                                        │
   │ Algorithm (internally):                                │
   │   bindings = map<routing_key, list<queue>>             │
   │   queues = bindings[message.routing_key]               │
   │   for each queue in queues: enqueue(message)           │
   │                                                        │
   │ O(1) lookup (hash map)                                 │
   │                                                        │
   │ Example:                                               │
   │   Binding: routing_key="order.created" → Queue:billing │
   │   Publish: routing_key="order.created" → goes to billing│
   │   Publish: routing_key="order.shipped" → no match, drop │
   └────────────────────────────────────────────────────────┘

2. FANOUT EXCHANGE:
   ┌────────────────────────────────────────────────────────┐
   │ Routing: IGNORE routing_key, send to ALL bound queues  │
   │                                                        │
   │ Algorithm:                                             │
   │   for each bound_queue: enqueue(message)               │
   │                                                        │
   │ O(n) where n = number of bound queues                  │
   │ Fastest exchange type (no routing logic)               │
   │                                                        │
   │ Example:                                               │
   │   3 queues bound → message copied to all 3             │
   │   Like Kafka fan-out / pub-sub                         │
   └────────────────────────────────────────────────────────┘

3. TOPIC EXCHANGE:
   ┌────────────────────────────────────────────────────────┐
   │ Routing: pattern match with wildcards                  │
   │   * = exactly one word                                 │
   │   # = zero or more words                               │
   │   Words separated by dots: "order.created.urgent"      │
   │                                                        │
   │ Algorithm (internally — trie/tree-based):              │
   │   Binding patterns stored in a TRIE structure          │
   │   Each dot-separated word is a node                    │
   │   Wildcards create branches                            │
   │                                                        │
   │   Pattern tree:                                        │
   │     root                                               │
   │     ├── "order"                                        │
   │     │   ├── "created" → [billing-queue]                │
   │     │   ├── "*" → [analytics-queue]  (any second word) │
   │     │   └── "#" → [audit-queue]  (any remaining words) │
   │     └── "#" → [catch-all-queue]                        │
   │                                                        │
   │   Routing "order.created":                             │
   │     Matches: "order.created", "order.*", "order.#", "#"│
   │     → billing, analytics, audit, catch-all queues      │
   │                                                        │
   │ More CPU than direct/fanout (trie traversal)           │
   │ But very flexible routing                              │
   └────────────────────────────────────────────────────────┘

4. HEADERS EXCHANGE:
   ┌────────────────────────────────────────────────────────┐
   │ Routing: match message headers against binding headers │
   │   x-match = "all" (AND) or "any" (OR)                 │
   │                                                        │
   │ Binding: headers={format:"pdf", type:"report"}, all   │
   │ Message: headers={format:"pdf", type:"report", x:1}   │
   │ → Match! (all required headers present)                │
   │                                                        │
   │ Slowest exchange (header comparison per binding)       │
   │ Rarely used in practice                                │
   └────────────────────────────────────────────────────────┘

DEFAULT EXCHANGE (""):
  Every queue is automatically bound to the default exchange
  with routing_key = queue name.
  Publish to "" with routing_key="my-queue" → goes to my-queue.
  Convenient for direct point-to-point messaging.
```

---

## Queue Internals — Message Storage

```
QUEUE PROCESS ARCHITECTURE:

Each queue in RabbitMQ is an Erlang process with its own state:

┌────────────────────────────────────────────────────────────────┐
│            QUEUE PROCESS (Erlang process)                       │
│                                                                │
│  State:                                                        │
│  ┌────────────────────────────────────────────────────────┐    │
│  │ messages_ready: count of messages available to deliver  │    │
│  │ messages_unacked: count of delivered but not acked      │    │
│  │ consumers: list of consuming channels                   │    │
│  │                                                        │    │
│  │ Message storage (depends on queue type):                │    │
│  │                                                        │    │
│  │ CLASSIC QUEUE:                                         │    │
│  │   In-memory index + message store                       │    │
│  │   Messages flow through states:                        │    │
│  │     alpha → beta → gamma → delta                       │    │
│  │                                                        │    │
│  │ QUORUM QUEUE (recommended for HA):                     │    │
│  │   Raft-based replicated log                            │    │
│  │   WAL (write-ahead log) on disk                        │    │
│  │                                                        │    │
│  │ STREAM QUEUE (Kafka-like):                             │    │
│  │   Append-only log with offset-based consumption        │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                │
│  Mailbox: receives commands from channels (publish, ack, etc.) │
│  Single process = serialization point for queue operations     │
└────────────────────────────────────────────────────────────────┘

CLASSIC QUEUE MESSAGE STATES:

  Messages transition through states based on memory pressure:

  ALPHA (α): message in memory, index in memory
    → fastest delivery (everything in RAM)

  BETA (β): message on disk, index in memory
    → need disk read for message body

  GAMMA (γ): message on disk, index in memory AND on disk
    → transitional state during paging

  DELTA (δ): message on disk, index on disk
    → everything on disk (slowest, but handles large queues)

  ┌──────────────────────────────────────────────────────┐
  │ Memory pressure flow:                                 │
  │                                                      │
  │ Low memory:                                           │
  │   α (RAM) ──► β (msg to disk) ──► δ (index to disk) │
  │                                                      │
  │ High memory available:                                │
  │   δ ──► β ──► α  (page back to memory)              │
  │                                                      │
  │ Lazy queue mode (queue-mode=lazy):                    │
  │   Skip α entirely. Messages go to DISK immediately.  │
  │   Only paged to memory when consumer needs them.     │
  │   Best for large queues where consumers are slow.     │
  └──────────────────────────────────────────────────────┘

MESSAGE STORE (on disk):
  ┌──────────────────────────────────────────────────────┐
  │ Two stores:                                           │
  │                                                      │
  │ 1. Message Store (msg_store_persistent):              │
  │    - Persistent messages (delivery-mode=2)            │
  │    - Written to .rdq files (segment files, 16 MB)     │
  │    - Reference-counted (for fan-out: msg in 1 place)  │
  │    - Garbage collected when ref count → 0             │
  │                                                      │
  │ 2. Transient Store (msg_store_transient):             │
  │    - Non-persistent messages paged to disk            │
  │    - Lost on broker restart                           │
  │                                                      │
  │ File format (.rdq):                                   │
  │    [msg_id (16B)] [msg_body_size (4B)] [msg_body]     │
  │    [msg_id] [size] [body] ...                         │
  │    Append-only within segment                         │
  │    Segment closed at 16 MB → new segment              │
  │                                                      │
  │ Queue Index:                                          │
  │    .idx files: maps seq_id → msg_id + delivery info  │
  │    Segment-based, one index segment per N messages    │
  └──────────────────────────────────────────────────────┘
```

---

## Message Delivery — Push Model

```
RABBITMQ PUSH MODEL (vs Kafka's pull):

Kafka: consumers PULL (poll) messages
RabbitMQ: broker PUSHES messages to consumers

CONSUMER REGISTRATION:
  Channel → Basic.Consume(queue="orders", consumer_tag="c1",
                          no_ack=false, prefetch_count=10)

  Broker creates consumer record:
    {tag: "c1", channel: ch1, queue: "orders",
     ack_required: true, prefetch: 10}

DELIVERY FLOW:
  ┌────────────────────────────────────────────────────────────┐
  │                                                            │
  │ 1. Message arrives at queue (from exchange):               │
  │    Queue process receives message in its mailbox           │
  │                                                            │
  │ 2. Queue checks: any consumers ready?                      │
  │    Ready = consumer has available prefetch credits          │
  │    (unacked messages < prefetch_count)                     │
  │                                                            │
  │ 3. If consumer ready:                                      │
  │    Queue → Basic.Deliver frame → Channel → TCP → Consumer  │
  │    Message skips disk if consumer is ready! (fast path)    │
  │    Message marked as "unacked" for this consumer           │
  │                                                            │
  │ 4. If NO consumer ready:                                   │
  │    Message stored in queue (memory or disk)                │
  │    Queue waits for consumer to ack → frees prefetch slot   │
  │                                                            │
  │ 5. Consumer processes message:                             │
  │    Consumer → Basic.Ack(delivery_tag=42) → Broker          │
  │    Queue removes message (permanently deleted!)            │
  │    Consumer's prefetch credit restored                     │
  │    Queue can push next message                             │
  │                                                            │
  └────────────────────────────────────────────────────────────┘

PREFETCH (QoS — Quality of Service):
  ┌──────────────────────────────────────────────────────────┐
  │ Basic.Qos(prefetch_count=10):                            │
  │                                                          │
  │ "Don't send me more than 10 unacked messages"            │
  │                                                          │
  │ This is RabbitMQ's FLOW CONTROL at consumer level:       │
  │                                                          │
  │ Consumer:                                                │
  │   In-flight (unacked): [m1][m2][m3][m4]...[m10]         │
  │   Broker stops pushing (prefetch limit reached)          │
  │   Consumer acks m1 → broker pushes m11                   │
  │   Consumer acks m2 → broker pushes m12                   │
  │                                                          │
  │ Without prefetch (prefetch=0 = unlimited):               │
  │   Broker floods consumer with ALL messages               │
  │   Consumer OOM, can't process fast enough                │
  │   BAD in production — always set prefetch!               │
  │                                                          │
  │ Recommended: prefetch_count = 10-50                      │
  │ Too low: consumer idle between acks (underutilized)      │
  │ Too high: messages buffered in consumer memory            │
  └──────────────────────────────────────────────────────────┘

MESSAGE ACKNOWLEDGMENT MODES:
  ┌──────────────────────────────────────────────────────────┐
  │ no_ack=true (auto-ack):                                  │
  │   Message considered delivered as soon as sent            │
  │   Consumer crash → message LOST                          │
  │   Fastest, no reliability                                │
  │                                                          │
  │ no_ack=false (manual ack, default):                      │
  │   Consumer must Basic.Ack(delivery_tag) after processing │
  │   If consumer crashes: message REQUEUED                  │
  │   delivery_tag: per-channel sequence number (1, 2, 3...) │
  │                                                          │
  │ Basic.Nack(delivery_tag, requeue=true):                  │
  │   Negative ack: "I can't process this"                   │
  │   requeue=true: put back in queue (for another consumer) │
  │   requeue=false: discard or go to DLX                    │
  │                                                          │
  │ Basic.Reject(delivery_tag, requeue):                     │
  │   Like Nack but for single message                       │
  └──────────────────────────────────────────────────────────┘
```

---

## Flow Control — Credit-Based Back-Pressure

```
RABBITMQ FLOW CONTROL — MULTI-LAYER:

Flow control prevents fast producers from overwhelming the broker.

LAYER 1: TCP BACKPRESSURE (kernel level)
  ┌──────────────────────────────────────────────────────────┐
  │ Broker stops reading from socket → recv buffer fills     │
  │ → TCP window goes to 0 → producer's send() blocks       │
  │ This is the last resort; ideally caught earlier          │
  └──────────────────────────────────────────────────────────┘

LAYER 2: INTERNAL CREDIT FLOW (Erlang process level)
  ┌──────────────────────────────────────────────────────────┐
  │ Erlang credit-based flow control between processes:      │
  │                                                          │
  │ Connection → Channel → Queue                             │
  │   Each link has a credit counter                         │
  │                                                          │
  │ Connection process grants credits to Channel:            │
  │   "You can send me 200 messages"                         │
  │ Channel grants credits to Queue:                         │
  │   "You can send me 200 messages"                         │
  │                                                          │
  │ When credits exhausted:                                  │
  │   Process BLOCKS (stops accepting new messages)           │
  │   Backpressure propagates upstream                       │
  │                                                          │
  │ Credits restored when downstream processes catch up      │
  │                                                          │
  │ CONNECTION STATE: when blocked by flow control            │
  │   Connection shows "flow" state in management UI         │
  │   rabbitmqctl list_connections shows "blocking" status    │
  └──────────────────────────────────────────────────────────┘

LAYER 3: MEMORY ALARM
  ┌──────────────────────────────────────────────────────────┐
  │ vm_memory_high_watermark = 0.4 (40% of system RAM)       │
  │                                                          │
  │ When RabbitMQ memory > 40% of RAM:                       │
  │   MEMORY ALARM triggers                                  │
  │   ALL publishing connections BLOCKED                     │
  │   Consumers can still ack and drain queues               │
  │                                                          │
  │ Paging threshold = vm_memory_high_watermark × 0.5        │
  │   At 50% of watermark: start paging messages to disk     │
  │   Reduces memory but adds latency                        │
  └──────────────────────────────────────────────────────────┘

LAYER 4: DISK ALARM
  ┌──────────────────────────────────────────────────────────┐
  │ disk_free_limit = 50MB (default)                         │
  │                                                          │
  │ When free disk < 50 MB:                                  │
  │   DISK ALARM triggers                                    │
  │   ALL publishing blocked                                 │
  │   Prevents broker from filling disk completely           │
  └──────────────────────────────────────────────────────────┘

FLOW CONTROL CHAIN:
  Producer → TCP → [Connection proc] → [Channel proc] → [Queue proc]
                         ↑                  ↑                ↑
                    Credit flow         Credit flow      Memory/Disk
                    (process level)     (process level)     alarms
```

---

## Quorum Queues — Raft-Based Replication

```
QUORUM QUEUES (RabbitMQ 3.8+):

Classic mirrored queues had problems:
  - Synchronization blocking
  - Split-brain scenarios
  - Performance issues during sync

Quorum queues use RAFT consensus (like KRaft in Kafka):

┌────────────────────────────────────────────────────────────────┐
│              QUORUM QUEUE ARCHITECTURE                          │
│                                                                │
│  Queue "orders" with quorum of 3:                              │
│                                                                │
│  Node 1              Node 2              Node 3                │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐     │
│  │ Leader       │    │ Follower     │    │ Follower     │     │
│  │              │    │              │    │              │     │
│  │ Raft log:    │    │ Raft log:    │    │ Raft log:    │     │
│  │ [e1][e2][e3] │    │ [e1][e2][e3] │    │ [e1][e2]     │     │
│  │              │    │              │    │              │     │
│  │ WAL on disk  │    │ WAL on disk  │    │ WAL on disk  │     │
│  │ (append-only)│    │ (append-only)│    │ (append-only)│     │
│  └──────────────┘    └──────────────┘    └──────────────┘     │
│                                                                │
│  PUBLISH FLOW:                                                 │
│  1. Publisher → Leader: "enqueue message M"                    │
│  2. Leader appends to Raft log: entry = {enqueue, M}           │
│  3. Leader replicates entry to followers                       │
│  4. Majority (2 of 3) acknowledge → entry COMMITTED            │
│  5. Leader applies: message is now in queue                    │
│  6. Leader acks publisher (Basic.Ack / publisher confirm)      │
│                                                                │
│  CONSUME FLOW:                                                 │
│  1. Consumer connected to leader                               │
│  2. Leader delivers message (push)                             │
│  3. Consumer acks → Leader appends {ack, delivery_id}          │
│  4. Raft replicates ack → majority commit → message removed   │
│                                                                │
│  LEADER FAILURE:                                               │
│  1. Followers detect leader timeout                            │
│  2. Raft election: one follower becomes new leader             │
│  3. Only committed entries survive (majority had them)         │
│  4. Consumers reconnect to new leader                          │
│  5. NO data loss for committed messages                        │
│                                                                │
└────────────────────────────────────────────────────────────────┘

QUORUM QUEUE WAL (Write-Ahead Log):
  ┌──────────────────────────────────────────────────────────┐
  │ Each quorum queue member writes to a WAL on disk:        │
  │                                                          │
  │ WAL segment files:                                       │
  │   00000001.wal (16 MB)                                   │
  │   00000002.wal (16 MB)                                   │
  │   ...                                                    │
  │                                                          │
  │ Each entry:                                              │
  │   [term (8B)] [index (8B)] [type (1B)] [data (varlen)]  │
  │                                                          │
  │ Types:                                                   │
  │   enqueue: message data + metadata                       │
  │   ack: delivery tag reference                            │
  │   checkout: message delivered to consumer                 │
  │   return: message requeued (nack with requeue)           │
  │                                                          │
  │ fsync behavior:                                          │
  │   WAL fsynced after EVERY write (configurable)           │
  │   ra_log_wal_sync = true (default)                       │
  │   Ensures durability before acking publisher              │
  │                                                          │
  │ Snapshot:                                                │
  │   Periodically snapshot queue state to disk               │
  │   Truncate old WAL entries (like Raft log compaction)    │
  │   Reduces recovery time on restart                       │
  └──────────────────────────────────────────────────────────┘

QUORUM vs CLASSIC vs STREAM:
  ┌──────────────┬──────────────┬──────────────┬──────────┐
  │              │ Classic      │ Quorum       │ Stream   │
  ├──────────────┼──────────────┼──────────────┼──────────┤
  │ Replication  │ Mirror       │ Raft         │ Raft     │
  │ Consistency  │ Weak         │ Strong       │ Strong   │
  │ Persistence  │ Optional     │ Always       │ Always   │
  │ Non-durable  │ Supported    │ No           │ No       │
  │ Priority     │ Yes          │ No           │ No       │
  │ Replay       │ No           │ No           │ Yes      │
  │ Performance  │ Highest      │ High         │ Highest  │
  │ Recommended  │ Legacy       │ YES (HA)     │ Streaming│
  └──────────────┴──────────────┴──────────────┴──────────┘
```

---

## Publisher Confirms — Durability Protocol

```
PUBLISHER CONFIRMS (RabbitMQ's ack for producers):

Problem: Basic.Publish is fire-and-forget (no broker ack!)
Solution: Publisher Confirms (RabbitMQ extension to AMQP)

ENABLE:
  Channel → Confirm.Select
  Server → Confirm.Select-Ok
  Channel is now in "confirm mode"

FLOW:
  ┌────────────────────────────────────────────────────────────┐
  │ Publisher publishes messages, each gets a sequence number:  │
  │   Publish(seq=1, msg=A)                                    │
  │   Publish(seq=2, msg=B)                                    │
  │   Publish(seq=3, msg=C)                                    │
  │                                                            │
  │ Broker processes and confirms:                             │
  │                                                            │
  │ For non-persistent OR no queue bound:                      │
  │   Confirm immediately: Basic.Ack(delivery_tag=1)           │
  │                                                            │
  │ For persistent + durable queue:                            │
  │   Write to disk → fsync → then Basic.Ack                   │
  │                                                            │
  │ For quorum queue:                                          │
  │   Replicate to majority → then Basic.Ack                   │
  │                                                            │
  │ Batch confirm (multiple=true):                             │
  │   Basic.Ack(delivery_tag=3, multiple=true)                 │
  │   → Confirms seq 1, 2, AND 3 in one ack                   │
  │                                                            │
  │ Negative confirm (message couldn't be routed):             │
  │   Basic.Nack(delivery_tag=2)                               │
  │   → Publisher should retry or handle                       │
  └────────────────────────────────────────────────────────────┘

MANDATORY FLAG:
  Publish(mandatory=true):
    If message can't be routed to ANY queue:
      Broker returns Basic.Return (message sent back to publisher)
    Without mandatory:
      Unroutable message is SILENTLY DROPPED
```

---

## Clustering and Distribution

```
RABBITMQ CLUSTER ARCHITECTURE:

┌──────────────────────────────────────────────────────────────┐
│                  RABBITMQ CLUSTER                             │
│                                                              │
│  Node 1 (disc)        Node 2 (disc)        Node 3 (ram)     │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐   │
│  │              │    │              │    │              │   │
│  │ Queues:      │    │ Queues:      │    │ Queues:      │   │
│  │  orders-q    │    │  payments-q  │    │  notify-q    │   │
│  │  billing-q   │    │  audit-q     │    │              │   │
│  │              │    │              │    │              │   │
│  │ Exchanges:   │    │ Exchanges:   │    │ Exchanges:   │   │
│  │  (replicated │    │  (replicated │    │  (replicated │   │
│  │   on all     │    │   on all     │    │   on all     │   │
│  │   nodes)     │    │   nodes)     │    │   nodes)     │   │
│  │              │    │              │    │              │   │
│  └──────────────┘    └──────────────┘    └──────────────┘   │
│       ▲ ▲ ▲               ▲ ▲ ▲               ▲ ▲ ▲        │
│       │ │ │               │ │ │               │ │ │        │
│       Erlang distribution protocol (port 25672)             │
│       (mesh network: every node connected to every node)    │
│                                                              │
└──────────────────────────────────────────────────────────────┘

WHAT IS REPLICATED vs WHAT IS LOCAL:
  ┌──────────────────────────────────────────────────────────┐
  │ REPLICATED TO ALL NODES:                                 │
  │   - Exchange definitions + bindings                      │
  │   - Queue metadata (name, properties)                    │
  │   - Users, vhosts, permissions                           │
  │   - Runtime parameters, policies                         │
  │                                                          │
  │ LOCAL TO ONE NODE (classic queues):                       │
  │   - Queue contents (messages)                            │
  │   - Queue process                                        │
  │   - Message store files                                  │
  │                                                          │
  │ REPLICATED BY RAFT (quorum queues):                      │
  │   - Queue contents replicated to quorum members          │
  └──────────────────────────────────────────────────────────┘

CROSS-NODE MESSAGE ROUTING:
  Client connected to Node 3 publishes to exchange "orders-ex"
  Exchange bound to queue "orders-q" which lives on Node 1
  
  Flow:
    Client → Node 3 → (exchange routing) → "queue on Node 1"
    Node 3 → Erlang distribution → Node 1 → queue process
    Message delivered to queue on Node 1
    
  This adds latency (inter-node hop)
  Best practice: connect to node where queue lives
  Or use quorum queues for HA
```

---

## Dead Letter Exchange (DLX)

```
DEAD LETTER EXCHANGE INTERNALS:

Messages are "dead-lettered" when:
  1. Consumer nacks/rejects with requeue=false
  2. Message TTL expires (per-message or per-queue)
  3. Queue max-length exceeded (oldest messages dropped)

CONFIGURATION:
  Queue declares:
    x-dead-letter-exchange: "dlx-exchange"
    x-dead-letter-routing-key: "failed.orders" (optional override)

FLOW:
  ┌──────────────────────────────────────────────────────┐
  │ [Main Queue] ──► Consumer rejects ──► [DLX Exchange] │
  │                                            │          │
  │                                            ▼          │
  │                                     [DLQ Queue]       │
  │                                     (inspect, fix,    │
  │                                      replay)          │
  └──────────────────────────────────────────────────────┘

  Dead-lettered message gets extra headers:
    x-death: [{queue, reason, count, time, exchange, routing-keys}]
    Tracks: which queue, why dead-lettered, how many times
    Useful for debugging and automated retry logic
```

---

## 30-SECOND REVISION BOX

```
ERLANG: lightweight processes (2KB), per-process GC, actor model, supervision
AMQP: Connection → Channel (multiplexed) → frames (method/header/body)
EXCHANGE: direct (hash), fanout (broadcast), topic (trie), headers (match)
QUEUE: Erlang process, classic (α/β/γ/δ states) or quorum (Raft)
DELIVERY: push model + prefetch (QoS) for flow control
FLOW CONTROL: credit-based (process level) + memory/disk alarms
QUORUM QUEUE: Raft consensus, WAL, fsync, majority commit, strong consistency
PUBLISHER CONFIRMS: broker acks after disk/replication (like Kafka acks)
CLUSTER: exchanges replicated, classic queues local, quorum queues replicated
DLX: rejected/expired/overflow messages → dead letter exchange → DLQ
```

---

**Prev: [[12_Internals-Kafka-Producer-Consumer-Protocol]] | Next: [[14_Internals-Serialization-Wire-Format]]**
