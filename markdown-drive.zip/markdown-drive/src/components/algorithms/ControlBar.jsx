import { useAlgorithmStore } from '../../stores/algorithm-store';

export default function ControlBar({ onSendRequest, onBurst, onReset }) {
  const {
    capacity, setCapacity,
    refillRate, setRefillRate,
    cost, setCost,
    autoRate, setAutoRate,
    autoActive, toggleAuto,
  } = useAlgorithmStore();

  return (
    <div className="dc-control-bar">
      <button className="dc-btn dc-btn--primary" onClick={onSendRequest}>Send Request</button>
      <button className="dc-btn dc-btn--secondary" onClick={onBurst}>Burst x5</button>
      <button className={`dc-btn ${autoActive ? 'dc-btn--success' : 'dc-btn--outline'}`} onClick={toggleAuto}>
        {autoActive ? 'Stop Auto' : 'Auto Send'}
      </button>

      <div className="dc-control-bar__sep" />

      <div className="dc-slider-group">
        <label>Capacity</label>
        <input type="range" min={3} max={25} value={capacity} onChange={(e) => setCapacity(+e.target.value)} />
        <span className="dc-slider-val">{capacity}</span>
      </div>
      <div className="dc-slider-group">
        <label>Rate</label>
        <input type="range" min={0.5} max={12} step={0.5} value={refillRate} onChange={(e) => setRefillRate(+e.target.value)} />
        <span className="dc-slider-val">{refillRate}/s</span>
      </div>
      <div className="dc-slider-group">
        <label>Cost</label>
        <input type="range" min={1} max={8} value={cost} onChange={(e) => setCost(+e.target.value)} />
        <span className="dc-slider-val">{cost}</span>
      </div>
      <div className="dc-slider-group">
        <label>Auto</label>
        <input type="range" min={1} max={25} value={autoRate} onChange={(e) => setAutoRate(+e.target.value)} />
        <span className="dc-slider-val">{autoRate}/s</span>
      </div>

      <div className="dc-control-bar__sep" />
      <button className="dc-btn dc-btn--danger" onClick={onReset}>Reset</button>
    </div>
  );
}
