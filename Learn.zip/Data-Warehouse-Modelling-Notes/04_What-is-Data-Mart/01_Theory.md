# EXPLANATION (IN SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}

========================================

1. WHAT IS A DATA MART

========================================

Quote:
"Divide and conquer — but do not divide without a map."

Meaning:

- Breaking data into parts is good
- But must be done in a planned way

---

## Real-world analogy

Data Warehouse:

- Like a big wholesaler
- Collects everything from many suppliers

Data Mart:

- Like a specific section in a store
- Example:
  - Wine section
  - Organic section
  - Holiday items section

Key idea:

- Data mart is NOT separate
- It comes from the warehouse
- But focused for specific users

========================================
2. CORE IDEA (VERY IMPORTANT)
========================================

Data Mart:

- Small, focused part of data warehouse
- Designed for:
  - Department
  - Region
  - Business use case

Goal:

- Faster queries
- Simpler structure
- Secure access

Important:

- Users don’t need full warehouse complexity

========================================
3. DEFINITION BREAKDOWN
========================================

Subset:

- Smaller data
- Less joins
- Often pre-aggregated

Subject Area:

- Example:
  - Sales
  - Inventory
  - Finance

Department:

- Example:
  - Marketing team
  - Finance team

---

## Interview Tip

Say:
"A data mart is a curated view of warehouse data, aligned with enterprise definitions"

========================================
4. DATA FLOW (PIPELINE)
========================================

Flow:

Data Warehouse → ETL/ELT → Data Mart → BI → Users

Explanation:

1. Data Warehouse

- Stores full enterprise data

1. ETL/ELT

- Filters and aggregates data

1. Data Mart

- Simplified version for specific team

1. BI Layer

- Dashboards

1. Users

- Business teams

---

## Warning

If marts don’t follow warehouse rules:

- Data inconsistency happens

========================================
5. EXAMPLES OF DATA MARTS
========================================

---

## Sales Mart

- Used by sales team
- Contains:
  - Orders
  - Revenue
  - Returns

---

## Finance Mart

- Used by finance team
- Contains:
  - Revenue
  - Profit
  - Accounting data

---

## HR Mart

- Used by HR
- Contains:
  - Employee data
  - Sensitive info

---

## Inventory Mart

- Used by supply chain
- Contains:
  - Stock levels
  - Inventory metrics

---

## SQL Example Explained

CREATE TABLE mart_sales_daily AS
SELECT
  d.calendar_date,
  s.store_id,
  p.category,
  SUM(f.gross_sales)   AS gross_sales,
  SUM(f.net_sales)     AS net_sales,
  SUM(f.units_sold)    AS units_sold
FROM fact_sales f
JOIN dim_date d ON f.order_date_sk = d.date_sk
JOIN dim_store s ON f.store_sk = s.store_sk
JOIN dim_product p ON f.product_sk = p.product_sk
GROUP BY 1, 2, 3;

Explanation:

- Creates simplified table
- Aggregates data
- Easier for dashboards

========================================
6. CHARACTERISTICS OF DATA MART
========================================

---

1. Subject-Specific

---

- Focus on one area

---

1. Summarized

---

- Pre-aggregated data

---

1. Fast

---

- Smaller datasets

---

1. Secure

---

- Controlled access

---

## Trade-off

- Too much aggregation → lose detail

========================================
7. DISADVANTAGES
========================================

---

1. Extra Pipelines

---

- More jobs to maintain

---

1. Data Redundancy

---

- Same data stored multiple times

---

1. Drift Risk

---

- Definitions may change

---

## Why still used?

- Faster business access
- Simpler queries

========================================
8. SUPPLY CHAIN ANALOGY
========================================

Supplier → Warehouse → Store → Customer

Mapping:

Supplier → Source systems  
Warehouse → Data warehouse  
Store → Data mart  
Customer → Business user  

Meaning:

- Warehouse stores everything
- Mart makes it usable

========================================
9. TYPES OF DATA MARTS
========================================

---

1. Dependent Data Mart

---

- Built from data warehouse

Pros:

- Consistent data
- Proper governance

Cons:

- Depends on warehouse

---

1. Independent Data Mart

---

- Built directly from source systems

Pros:

- Fast to build

Cons:

- Data inconsistency
- Duplicate logic

---

## Important

Dependent mart = preferred

========================================
10. DATA WAREHOUSE vs DATA MART
========================================

Scope:

- DW → entire company
- Mart → specific department

Complexity:

- DW → complex
- Mart → simple

Users:

- DW → technical + business
- Mart → mostly business

Security:

- DW → broad control
- Mart → focused control

========================================
11. MODELING INSIDE MART
========================================

---

1. Star Schema

---

- Flexible queries

---

1. Flat Table

---

- Very simple and fast

---

1. Semantic Layer

---

- No physical table
- Only logical view

---

## SQL Example

CREATE VIEW mart_promotion.vw_campaign_performance AS
SELECT
  campaign_name,
  campaign_start_date,
  SUM(attributed_net_sales) AS attributed_net_sales,
  SUM(attributed_orders)    AS attributed_orders
FROM dw_curated.fact_promo_attribution
GROUP BY 1, 2;

Explanation:

- Creates user-friendly view

========================================
12. GOVERNANCE
========================================

---

1. Conformed Keys

---

- Same IDs across system

---

1. Metric Definitions

---

- Same meaning everywhere

---

1. Lineage

---

- Track data source

---

## Warning

Excel files = dangerous (no control)

========================================
13. COMMON MISTAKES
========================================

---

1. No conformed dimensions

---

Problem:

- Different answers

Fix:

- Use standard keys

---

1. Confusing mart with ODS

---

Problem:

- Wrong usage

Fix:

- Understand purpose

---

1. Over-aggregation

---

Problem:

- No detail analysis

Fix:

- Keep proper granularity

---

1. Too many independent marts

---

Problem:

- Data silos

Fix:

- Use central warehouse

---

1. No security

---

Problem:

- Data leak

Fix:

- Apply access control

========================================
14. FINAL TAKEAWAY
========================================

Data Mart:

- Focused subset of data warehouse
- Designed for specific users

Benefits:

- Faster queries
- Simpler structure
- Better security

Trade-off:

- Extra maintenance
- Data duplication

Best Practice:

- Use dependent data marts
- Maintain governance

# ========================================
QUICK MEMORY SUMMARY

Data Mart:

- Subset of warehouse
- Built for departments

Pipeline:
DW → Mart → BI → Users

Types:

- Dependent (good)
- Independent (risky)

Goal:

- Fast, simple, secure access

