import { memo, useEffect, useRef, useState, useCallback } from 'react';

const COLORS = ['#f59e0b', '#ef4444', '#3b82f6', '#22c55e', '#a855f7', '#ffffff'];

const AnnotationOverlay = memo(function AnnotationOverlay({ containerRef, folder, filename, userId, onClose }) {
  const canvasRef = useRef(null);
  const ctxRef = useRef(null);
  const drawing = useRef(false);
  const [tool, setTool] = useState('pen');
  const [color, setColor] = useState('#f59e0b');
  const [showColors, setShowColors] = useState(false);
  const historyRef = useRef([]);
  const [historyLen, setHistoryLen] = useState(0);

  const storageKey = `annot_${userId || 'anon'}_${folder}_${filename}`;

  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const rect = container.getBoundingClientRect();
    const scrollH = container.scrollHeight;
    const dpr = window.devicePixelRatio || 1;

    canvas.style.width = rect.width + 'px';
    canvas.style.height = scrollH + 'px';
    canvas.width = rect.width * dpr;
    canvas.height = scrollH * dpr;

    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctxRef.current = ctx;

    const saved = localStorage.getItem(storageKey);
    if (saved) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, 0, 0, rect.width, scrollH);
        saveSnapshot();
      };
      img.src = saved;
    } else {
      saveSnapshot();
    }
  }, [containerRef, storageKey]);

  useEffect(() => {
    setupCanvas();
    const ro = new ResizeObserver(() => setupCanvas());
    if (containerRef.current) ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, [setupCanvas, containerRef]);

  const saveSnapshot = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const data = canvas.toDataURL('image/png');
    historyRef.current.push(data);
    if (historyRef.current.length > 30) historyRef.current.shift();
    setHistoryLen(historyRef.current.length);
  }, []);

  const persist = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      localStorage.setItem(storageKey, canvas.toDataURL('image/png'));
    } catch { /* storage full */ }
  }, [storageKey]);

  const getPos = useCallback((e) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const scaleX = parseFloat(canvas.style.width) / rect.width;
    const scaleY = parseFloat(canvas.style.height) / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY,
    };
  }, []);

  const startDraw = useCallback((e) => {
    drawing.current = true;
    const ctx = ctxRef.current;
    if (!ctx) return;
    const pos = getPos(e);
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);

    if (tool === 'highlighter') {
      ctx.globalCompositeOperation = 'multiply';
      ctx.strokeStyle = color;
      ctx.lineWidth = 18;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = 0.3;
    } else if (tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.lineWidth = 20;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = 1;
    } else {
      ctx.globalCompositeOperation = 'source-over';
      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.globalAlpha = 1;
    }
  }, [tool, color, getPos]);

  const draw = useCallback((e) => {
    if (!drawing.current || !ctxRef.current) return;
    const pos = getPos(e);
    ctxRef.current.lineTo(pos.x, pos.y);
    ctxRef.current.stroke();
  }, [getPos]);

  const endDraw = useCallback(() => {
    if (!drawing.current) return;
    drawing.current = false;
    const ctx = ctxRef.current;
    if (ctx) {
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    }
    saveSnapshot();
    persist();
  }, [saveSnapshot, persist]);

  const handleUndo = useCallback(() => {
    if (historyRef.current.length <= 1) return;
    historyRef.current.pop();
    setHistoryLen(historyRef.current.length);
    const prev = historyRef.current[historyRef.current.length - 1];
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx || !prev) return;
    const w = parseFloat(canvas.style.width);
    const h = parseFloat(canvas.style.height);
    ctx.clearRect(0, 0, w, h);
    const img = new Image();
    img.onload = () => { ctx.drawImage(img, 0, 0, w, h); persist(); };
    img.src = prev;
  }, [persist]);

  const handleClear = useCallback(() => {
    const canvas = canvasRef.current;
    const ctx = ctxRef.current;
    if (!canvas || !ctx) return;
    ctx.clearRect(0, 0, parseFloat(canvas.style.width), parseFloat(canvas.style.height));
    saveSnapshot();
    persist();
  }, [saveSnapshot, persist]);

  useEffect(() => {
    const handler = (e) => {
      if (e.ctrlKey && e.key === 'z') { e.preventDefault(); handleUndo(); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleUndo]);

  return (
    <>
      <canvas
        ref={canvasRef}
        className="annotation-canvas"
        onMouseDown={startDraw}
        onMouseMove={draw}
        onMouseUp={endDraw}
        onMouseLeave={endDraw}
      />
      <div className="annot-toolbar">
        <button
          className={`annot-toolbar__btn ${tool === 'pen' ? 'annot-toolbar__btn--active' : ''}`}
          onClick={() => setTool('pen')}
          title="Pen"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M12 19l7-7 3 3-7 7-3-3z" />
            <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z" />
            <path d="M2 2l7.586 7.586" />
            <circle cx="11" cy="11" r="2" />
          </svg>
        </button>
        <button
          className={`annot-toolbar__btn ${tool === 'highlighter' ? 'annot-toolbar__btn--active' : ''}`}
          onClick={() => setTool('highlighter')}
          title="Highlighter"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M12 20h9" />
            <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
          </svg>
        </button>
        <button
          className={`annot-toolbar__btn ${tool === 'eraser' ? 'annot-toolbar__btn--active' : ''}`}
          onClick={() => setTool('eraser')}
          title="Eraser"
        >
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M20 20H7L3 16l9-9 8 8-4 4" />
            <path d="M6.5 13.5l5-5" />
          </svg>
        </button>

        <div className="annot-toolbar__sep" />

        <div className="annot-toolbar__color-wrap">
          <button
            className="annot-toolbar__color-btn"
            style={{ background: color }}
            onClick={() => setShowColors(c => !c)}
            title="Color"
          />
          {showColors && (
            <div className="annot-toolbar__colors">
              {COLORS.map(c => (
                <button
                  key={c}
                  className={`annot-toolbar__color-dot ${c === color ? 'annot-toolbar__color-dot--active' : ''}`}
                  style={{ background: c }}
                  onClick={() => { setColor(c); setShowColors(false); }}
                />
              ))}
            </div>
          )}
        </div>

        <div className="annot-toolbar__sep" />

        <button className="annot-toolbar__btn" onClick={handleUndo} title="Undo (Ctrl+Z)" disabled={historyLen <= 1}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
        </button>
        <button className="annot-toolbar__btn" onClick={handleClear} title="Clear all">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>

        <div className="annot-toolbar__sep" />

        <button className="annot-toolbar__btn annot-toolbar__btn--close" onClick={onClose} title="Exit annotation mode">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
    </>
  );
});

export default AnnotationOverlay;
