import { useEffect, useRef } from 'react';
import { useAlgorithmStore } from '../../stores/algorithm-store';

export default function EventLog({ storeFn }) {
  const useStore = storeFn || useAlgorithmStore;
  const logs = useStore((s) => s.logs);
  const logRef = useRef(null);

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [logs]);

  return (
    <div>
      <div className="dc-section-label">Event Log</div>
      <div ref={logRef} className="dc-event-log">
        {logs.length === 0 && <div className="dc-event-log__empty">No events yet</div>}
        {logs.map((log, i) => (
          <div key={i} className="dc-event-log__row">
            <span className="dc-event-log__time">{log.time}</span>
            <span className={`dc-event-log__msg dc-event-log__msg--${log.type}`}>{log.message}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
