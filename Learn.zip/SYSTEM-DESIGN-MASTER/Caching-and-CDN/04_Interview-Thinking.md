# Caching and CDN — Interview Thinking

> **Permanent Recall:** Introduce caching only after identifying a read bottleneck—don't lead with it. Explain cache invalidation strategies clearly (TTL + event-based). When asked "what if cache goes down?", show circuit breaker, fallback to DB, and cache rebuild. Demonstrate depth by discussing stampede, penetration, and consistency. Structure: Problem → Solution → Trade-offs → Edge cases.

---

## How to Discuss Caching in Interviews

### Step 1: Identify the Need

**Don't say:** "Let me add a cache."

**Do say:** "We're seeing read-heavy traffic / repeated queries / expensive computation. A cache would reduce latency and DB load. Let me quantify: X reads/sec, Y ms DB latency → cache could cut DB load by Z%."

> **FAANG Tip:** Always tie caching to a measurable problem. "Read latency is 50ms, target is 10ms" or "DB is at 80% CPU from reads."

---

### Step 2: Choose the Right Layer

| Question to ask yourself | Answer |
|--------------------------|--------|
| Same data for all users? | CDN |
| Per-user, repeated? | App / Distributed cache |
| Expensive to compute? | Distributed cache |
| Static assets? | CDN |

**Interview line:** "Since this is [static / personalized / computed], I'd use [CDN / Redis / both]."

---

### Step 3: Explain Cache Invalidation

**Structure:**
1. **TTL** — "We'll set a TTL of X seconds as a safety net."
2. **Event-based** — "On write, we'll invalidate the cache key (or publish an event)."
3. **Trade-off** — "TTL alone can serve stale data; event-based requires covering all write paths."

> **FAANG Tip:** "We'll use TTL as a fallback and explicit invalidation on writes. For critical freshness, we might bypass cache for that specific read."

---

### Step 4: Discuss Cache Consistency

**When asked "How do you keep cache and DB in sync?"**

| Approach | When |
|----------|------|
| **Write-through** | Strong consistency needed |
| **Cache-aside + invalidate** | Eventual consistency OK |
| **Version/ETag** | Conditional revalidation |
| **Bypass cache** | Critical reads (e.g., payment) |

**Interview line:** "We accept eventual consistency for [most reads]. For [payment/balance], we'd bypass cache and read from DB."

---

## When to Introduce Caching

**Right moment:** After you've drawn the basic architecture and identified:
- Read:write ratio (e.g., 100:1)
- Latency requirements
- DB as bottleneck

**Wrong moment:** As the first component. Show you understand the problem first.

---

## "What If Cache Goes Down?"

**Structured answer:**

1. **Impact:** "Reads would fall through to DB. Latency would increase, DB load would spike."
2. **Mitigation:**
   - **Circuit breaker:** After N consecutive failures, stop trying cache, go directly to DB.
   - **Fallback:** App continues to work; slower but functional.
   - **Cache cluster:** Use Redis Cluster / replicas so single node failure doesn't take down cache.
3. **Recovery:** "On cache restart, we'd have cold cache. Optionally warm from DB or accept higher latency until TTLs repopulate."

> **FAANG Tip:** "Cache is a performance optimization, not source of truth. System should work without it, just slower."

---

## Demonstrating Deep Caching Knowledge

**Topics to mention when relevant:**

| Topic | One-liner |
|-------|-----------|
| **Cache stampede** | "Many requests miss same key → all hit DB. We'd use locking or probabilistic early expiry." |
| **Cache penetration** | "Queries for non-existent keys hit DB every time. We'd cache empty/negative results or use Bloom filter." |
| **Cache avalanche** | "Many keys expire at once → DB spike. We'd add jitter to TTL." |
| **Hot key** | "One key gets massive traffic. We'd use local cache (L1) or replicate that key." |
| **Consistent hashing** | "Adding cache nodes with modulo would invalidate many keys. Consistent hashing minimizes rehashing." |

---

## Interview Flow: Caching Discussion

```mermaid
flowchart LR
    A[Identify read bottleneck] --> B[Propose cache layer]
    B --> C[Choose strategy]
    C --> D[TTL + invalidation]
    D --> E[Handle failure]
    E --> F[Edge cases]
```

---

## Sample Interview Dialogue

**Interviewer:** "How would you design a feed like Twitter's?"

**You:** "I'd start with the read path. If it's read-heavy, I'd add a cache. User feed could be precomputed and cached per user—Redis with a user ID key. On new post, we'd invalidate or update that user's cache. We'd use TTL as backup. If cache goes down, we fall back to DB—slower but still working. For trending/popular content, we might add a CDN or edge cache since it's same for many users."

**Interviewer:** "What about cache stampede when a celebrity tweets?"

**You:** "Good point. Many users would miss cache for that feed and hit DB. I'd use a distributed lock—first request acquires lock and loads; others wait or get stale. Or probabilistic early expiry so not all keys expire at once. We could also warm cache for top accounts."

---

## Handling "Scale It" Follow-ups

**When asked to scale the cache:**

1. **Vertical:** Larger Redis instance (until single-node limit).
2. **Horizontal:** Redis Cluster, sharding by key.
3. **Multi-layer:** Add L1 (local) for hottest keys.
4. **CDN:** Move static/same-for-all to edge.
5. **Read replicas:** Redis replicas for read scaling (Redis supports this).

**Interview line:** "We'd start with a single Redis. At 10K QPS we'd cluster. At 100K we'd add L1 for hot keys and possibly CDN for shared content."

---

## Red Flags to Avoid

| Don't Say | Do Say |
|-----------|--------|
| "We'll cache everything" | "We'll cache the working set—hot keys we've identified" |
| "Cache and DB will always match" | "We'll use eventual consistency with TTL; critical reads bypass cache" |
| "We don't need TTL" | "We'll set TTL as a safety net for invalidation bugs" |
| "One Redis is enough" | "We'll use Redis Cluster for HA and horizontal scale" |
| "CDN for everything" | "CDN for static/same-for-all; app cache for personalized" |

---

## 30-SECOND REVISION BOX

```
INTRODUCE CACHE: After identifying read bottleneck
INVALIDATION: TTL + event-based, trade-off freshness vs complexity
CONSISTENCY: Eventual OK for most; bypass for critical
CACHE DOWN: Circuit breaker, fallback to DB, cluster for HA
DEEP KNOWLEDGE: Stampede, penetration, avalanche, hot key
SCALE: Vertical → Cluster → L1 → CDN
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
