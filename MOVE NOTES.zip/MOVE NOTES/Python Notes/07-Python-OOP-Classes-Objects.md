# Python OOP — Classes and Objects

> *"Explicit self — first parameter of an instance method"* — Python convention

In Python, OOP has a **simple surface, deep model** — `class`, `__init__`, `self`, method types, `property`. There are no C++-style `public/private` keywords; convention with `_` / `__` gives hints. After [[06-Python-Strings-Collections]] you add structure on top of objects.

---

## 1. Class and object — minimal example

> **Definition:** A **class** is a blueprint that defines attributes and methods for a kind of object; an **object** (instance) is a concrete value created from that class with its own state.

**Why we need it:** Grouping data with the operations that use it keeps programs organized and reusable, which is why Python (like most OOP languages) lets you define types with `class` instead of only using loose functions and dicts.

**Syntax:**
```python
class ClassName:
    def __init__(self, ...):
        self.<attribute> = ...
    def <method>(self, ...):
        ...
<object> = ClassName(...)
```

```python
class Student:                      # Creates a blueprint called "Student"
    def __init__(self, name, roll): # Runs AUTOMATICALLY when you create a new Student
        self.name = name            # Stores name inside this specific object
        self.roll = roll            # Stores roll number inside this specific object

    def show(self):                 # A method (function) that belongs to Student
        return f"{self.roll}: {self.name}"

s = Student("Neha", 101)   # Creates a new Student object — __init__ runs automatically
print(s.show())             # Calls the show method → "101: Neha"
```

- `class` = creates a **blueprint** (template) for objects
- `__init__` = **initializer** — runs automatically when you create a new object (sets up its data)
- `self` = refers to **this specific object** — every instance method gets it as first parameter

**Watch Out!** `__init__` must not return anything — it should be `None`.

---

## 2. Instance vs class variables

> **Definition:** **Instance variables** live on each object (`self.name`); **class variables** are attributes defined on the class body and shared by all instances unless shadowed.

**Why we need it:** Shared defaults and metadata belong on the class (one copy); per-object state belongs on the instance so each object can differ without extra machinery.

**Syntax:**
```python
class ClassName:
    <class_attr> = <default_shared_value>

    def __init__(self, ...):
        self.<instance_attr> = ...
```

```python
class Dog:
    species = "Canis"          # CLASS variable — shared by ALL Dog objects (one copy)

    def __init__(self, name):
        self.name = name       # INSTANCE variable — each Dog gets its own name

d1 = Dog("Tommy")   # d1.name = "Tommy", d1.species = "Canis"
d2 = Dog("Bruno")   # d2.name = "Bruno", d2.species = "Canis"
Dog.species = "Doggo"  # Changes for ALL dogs (shared)
```


| Variable               | What it is                                          | Shared?                          |
| ---------------------- | --------------------------------------------------- | -------------------------------- |
| Class attr (`species`) | Belongs to the CLASS itself — one copy for everyone | Yes — all objects see same value |
| Instance attr (`name`) | Belongs to ONE specific object                      | No — each object has its own     |


**Interview Tip:** `d1.species = "X"` — you can set a **new** attribute on the instance that **shadows** the class one.

---

## 3. Instance, class, static methods

> **Definition:** **Instance methods** take `self` and operate on one object; **class methods** take `cls` and operate on the class; **static methods** are plain functions namespaced inside the class with no automatic `self` or `cls`.

**Why we need it:** Different code needs different binding—per-object logic, factory/alternate constructors on the class, or utility routines that do not need instance or class state—so Python offers three method kinds instead of overloading one form.

**Syntax:**
```python
class ClassName:
    def <instance_method>(self, ...):
        ...

    @classmethod
    def <class_method>(cls, ...):
        ...

    @staticmethod
    def <static_method>(...):
        ...
```

```python
class MyClass:
    class_var = 10

    def instance_method(self):
        return self.class_var

    @classmethod
    def class_method(cls):
        return cls.class_var

    @staticmethod
    def static_method(x, y):
        return x + y
```


| Decorator       | First param | What it does                                                                                   |
| --------------- | ----------- | ---------------------------------------------------------------------------------------------- |
| (none)          | `self`      | **Instance method** — works with ONE specific object's data                                    |
| `@classmethod`  | `cls`       | **Class method** — works with the class itself, not a specific object                          |
| `@staticmethod` | none        | **Static method** — just a regular function living inside the class (no access to self or cls) |


```python
class Person:
    def __init__(self, name):
        self.name = name

    @classmethod
    def from_parts(cls, first, last):
        return cls(f"{first} {last}")
```

**Interview Tip:** `@classmethod` for alternative constructors — common in FAANG-style libraries.

---

## 4. `__str__` vs `__repr__`

> **Definition:** `__repr__` returns an official, unambiguous string for developers (and ideally valid Python); `__str__` returns an informal, user-facing string for display.

**Why we need it:** One representation is not enough for debugging versus everyday printing, so Python calls different hooks—`repr()` / interactive display versus `print()` / `str()`.

**Syntax:**
```python
class ClassName:
    def __repr__(self):
        return f"{ClassName}(...)"

    def __str__(self):
        return "..."
```

```python
class Point:
    def __init__(self, x, y):
        self.x, self.y = x, y

    def __repr__(self):
        return f"Point({self.x}, {self.y})"

    def __str__(self):
        return f"({self.x}, {self.y})"
```

- `__repr__` — for **developers**: detailed, unambiguous (used in debugger/console)
- `__str__` — for **users**: clean, readable (used by `print()` and `str()`)

**Watch Out!** If you only define `__repr__`, it can also be used as a fallback for `str`.

---

## 5. `@property` — getters/setters the Pythonic way

> **Definition:** `@property` turns a method into a **computed attribute** you read like `obj.x`; a matching `@x.setter` lets assignments run validation while keeping dot syntax.

**Why we need it:** You can start with a simple public attribute and later add logic (validation, derived values) without breaking callers who already use attribute access.

**Syntax:**
```python
class ClassName:
    @property
    def <name>(self):
        return ...

    @<name>.setter
    def <name>(self, value):
        ...
        self._<backing> = value
```

```python
class Temperature:
    def __init__(self, c):
        self._c = c

    @property
    def celsius(self):
        return self._c

    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            raise ValueError("Too cold")
        self._c = value

    @property
    def fahrenheit(self):
        return self._c * 9 / 5 + 32
```

**Interview Tip:** Start with a public attribute; when you need validation later — add `@property` without breaking the API.

---

## 6. Object identity — `is` vs `==` (OOP context)

> **Definition:** `is` checks whether two references point to the **same object** in memory; `==` calls `__eq__` and checks **value equality** as defined by the class.

**Why we need it:** You often care whether two names alias one mutable object or merely compare equal—identity versus equality—so Python exposes both operators with different meaning.

**Syntax:**
```python
a is b
a == b
```

```python
class Box:
    pass
a = Box()
b = Box()
a is b   # False — different objects
a == b   # True only if __eq__ defined; default is object identity
```

Detail: [[notes]] and [[17-Python-FAANG-Interview-Must-Know]].

---

## 7. Dataclass shortcut (preview)

> **Definition:** A **dataclass** is a class decorated with `@dataclass` that auto-generates boilerplate like `__init__`, `__repr__`, and comparisons from field annotations.

**Why we need it:** Plain classes used mainly to hold data required repetitive `__init__` and `__repr__` code; dataclasses reduce that noise so you focus on the fields and behavior.

**Syntax:**
```python
from dataclasses import dataclass

@dataclass
class ClassName:
    <field_name>: <type>
    ...
```

```python
from dataclasses import dataclass

@dataclass
class User:
    id: int
    name: str
```

Full depth: [[16-Python-Advanced-Topics]].

---

## 8. Magic methods preview

> **Definition:** **Magic (dunder) methods** are special names like `__len__` and `__getitem__` that Python calls automatically so your objects behave like built-in types for `len()`, indexing, and more.

**Why we need them:** Without these hooks, users would have to call awkward custom functions for every operation; dunder methods let your types plug into familiar syntax and built-in functions.

**Syntax:**
```python
class ClassName:
    def __len__(self):
        ...

    def __getitem__(self, key):
        ...
```

`__len__`, `__getitem__` — [[09-Python-Encapsulation-Special-Methods]].

---

## 9. `__dict__` introspection (debug)

> **Definition:** `__dict__` on an instance is a mapping of that object’s writable attributes; on a class it holds the namespace of methods and class attributes (plus metaclass details).

**Why we need it:** Introspection and frameworks need a standard place to see “what lives on this object” without hard-coding every type, which is why instances and classes expose `__dict__` (unless `__slots__` replaces it).

**Syntax:**
```python
<object>.__dict__
<ClassName>.__dict__
```

```python
class A:
    def __init__(self):
        self.x = 1

a = A()
print(a.__dict__)          # Shows all instance attributes as a dict → {'x': 1}
print(A.__dict__.keys())   # Shows all class-level attributes and methods
```

**Interview Tip:** Metaclass / descriptors — attribute resolution follows the `__dict__` chain.

---

## 10. Class body execution — subtle point

> **Definition:** The **class body** is the indented block under `class Name:`; it runs once when the class is defined, and names assigned there become class-level attributes unless bound inside methods.

**Why we need to know this:** Understanding that the class body executes at definition time explains shared mutable defaults, import-time side effects, and why class variables behave differently from instance attributes.

**Syntax:**
```python
class ClassName:
    <class_level_name> = <value>  # runs once; shared by default

    def method(self):
        ...
```

The class body runs at **runtime** — assignments there become class variables.

```python
class C:
    nums = [1, 2, 3]   # shared if you mutate carefully
```

**Watch Out!** Mutable class attributes — all instances can share them if you don't rebind.

---

## Quick Memory Card

```
+------------------------------------------+
| CLASS / __init__ / self                 |
| - self explicit                          |
+------------------------------------------+
| INSTANCE vs CLASS ATTR                    |
| - class attr shared, shadowing careful   |
+------------------------------------------+
| METHOD TYPES                              |
| - instance / classmethod / staticmethod  |
+------------------------------------------+
| __str__ __repr__                          |
| - user vs dev representation             |
+------------------------------------------+
| @property                                 |
| - computed attrs + validation            |
+------------------------------------------+
```

---

*Next: [[08-Python-Inheritance-Polymorphism]]*
