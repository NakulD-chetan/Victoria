# Design WhatsApp — Mental Model

> **Permanent Recall:** Core challenge: **real-time bidirectional communication at massive scale**. WebSocket for real-time (not HTTP polling). "Mailbox" model: each user has a message queue—deliver when online, store when offline. Decomposition: Chat Service, Presence Service, Notification Service, Media Service, Message Storage. Group = fan-out to member queues.

---

## Core Challenge

**Real-time bidirectional communication at massive scale:** Delivering messages in <100ms while handling 1B+ concurrent connections and 100B messages/day.

```
    SENDER                    SERVER                     RECIPIENT
       |                          |                           |
       |---- message ------------>|                           |
       |                          |---- lookup: online? ----->|
       |                          |      YES: push via WS    |
       |                          |      NO: store + push    |
       |<--- sent receipt --------|                           |
       |                          |<--- delivered/read ------|
```

---

## WebSocket vs HTTP Long Polling vs SSE

| Approach | Direction | Latency | Scale | Use Case |
|----------|-----------|---------|-------|----------|
| **WebSocket** | Bidirectional | Low | High (persistent conn) | Real-time chat, presence |
| **HTTP Long Polling** | Client polls | Higher (poll interval) | Medium | Fallback when WS blocked |
| **Server-Sent Events (SSE)** | Server→Client only | Low | Medium | Notifications, feeds |

> **FAANG Tip:** WebSocket is **essential** for chat. Long polling is a fallback when firewalls block WebSocket. Don't use simple short polling—too slow and wasteful.

**Why not HTTP polling?** 2–5s poll interval feels sluggish; 1B users × 1 req/2s = 500M QPS of mostly empty polls; drains battery. WebSocket gives bidirectional push.

---

## The "Mailbox" Mental Model

Each user has a logical **message queue** (mailbox):

| State | Action |
|-------|--------|
| **Recipient online** | Push immediately via WebSocket; mark delivered |
| **Recipient offline** | Store in DB; send push notification; deliver on reconnect |
| **Multiple devices** | Each device has connection; fan-out to all online devices |

```
User A's mailbox: [msg1, msg2, msg3]  →  when A connects, deliver in order
User B's mailbox: [msg4, msg5]       →  B gets msg4, msg5 when online
```

---

## Connection Management Challenge

**Maintaining millions of persistent WebSocket connections:**
- Load balancer must support WebSocket (sticky sessions or connection-based routing)
- Each server handles 10K–100K connections (OS limits)
- Need many servers: 1B connections ÷ 50K per server ≈ 20,000 connection servers
- Heartbeat to detect dead connections; cleanup on disconnect

---

## Message Ordering Challenge

Messages must appear in **correct order** per conversation:
- Use **sequence numbers** or **Lamport timestamps** per conversation
- Client displays in order; handle out-of-order delivery with local reordering
- For groups: each member gets messages in same order (consistent ordering)

---

## Group Messaging Fan-Out

One message to group of 256 → up to **256 deliveries**:
- Don't send 256 separate DB writes synchronously
- Write message once; fan-out to member queues (Kafka, or per-user queues)
- Each member's Chat Service consumes and delivers when they're online

---

## Decomposition into Services

| Service | Responsibility |
|---------|----------------|
| **Chat Service** | Message routing, delivery, storage, receipts |
| **Presence Service** | Track online/offline; last-seen; heartbeat |
| **Notification Service** | Push notifications (FCM, APNs) when offline |
| **Media Service** | Upload to S3/Blob; return URL; CDN for download |
| **Message Storage** | Cassandra/DynamoDB for messages; sharded by conversation |

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│  Chat Service   │  │ Presence Service│  │Notification Svc │
│  (routing,      │  │ (online,        │  │ (push when       │
│   delivery)     │  │  last-seen)     │  │  offline)        │
└────────┬────────┘  └────────┬────────┘  └────────┬────────┘
         │                    │                     │
         └────────────────────┼─────────────────────┘
                              │
                    ┌─────────▼─────────┐
                    │   Message Queue   │
                    │ (Kafka / per-user)│
                    └─────────┬─────────┘
                              │
                    ┌─────────▼─────────┐
                    │  Message Storage  │
                    │  Media Service    │
                    └──────────────────┘
```

---

## At-Least-Once vs Exactly-Once

| Guarantee | How | Trade-off |
|-----------|-----|-----------|
| **At-least-once** | Retry until ack; client dedup by message_id | Duplicates possible; simpler |
| **Exactly-once** | Idempotency keys; distributed transaction | Complex; often overkill for chat |

**Practical choice:** At-least-once + client deduplication. Sufficient for messaging.

---

## 30-SECOND REVISION BOX

```
CORE: Real-time bidirectional at scale; WebSocket essential
MAILBOX: Per-user queue; deliver when online, store when offline
CONNECTIONS: 1B concurrent; LB sticky, heartbeat, cleanup
ORDERING: Sequence numbers per conversation
GROUP: Fan-out to 256 member queues; write once, deliver many
SERVICES: Chat, Presence, Notification, Media, Storage
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
