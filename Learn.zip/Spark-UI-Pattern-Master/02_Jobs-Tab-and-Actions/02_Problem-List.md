# Jobs Tab & Actions — Problem List

> **15 prediction tasks.** Goal: looking at *only the code*, predict the exact number of rows you will see in the Jobs tab. Then run it and verify in the UI.

---

## 8 MUST-DO Tasks

| # | Task                                                                            | Predicted Jobs | Concept Tag             | Why Important                                  |
|---|---------------------------------------------------------------------------------|----------------|-------------------------|------------------------------------------------|
| 1 | `df.count()` only                                                               | 1              | Pure action             | Baseline                                       |
| 2 | `df.collect()` only                                                             | 1              | Pure action             | Same family as count                           |
| 3 | `df.show()` (default 20 rows, 8 partitions, 2 actual rows)                       | 3              | executeTake loop        | THE classic interview question                 |
| 4 | `df.cache(); df.count()`                                                         | 1              | Cache materialization   | Cache is lazy, count triggers it               |
| 5 | `df.cache(); df.count(); df.count()`                                             | 2              | Cache reuse             | Storage tab fills after first count            |
| 6 | `df.write.parquet("out/")`                                                       | 1 (or 2 with AQE) | Write action          | Production ETL                                 |
| 7 | `df.toPandas()`                                                                  | 1              | Hidden collect          | Pyspark-specific gotcha                        |
| 8 | `df1.union(df2).count()` (df2 has lazy lineage)                                  | 1              | Union is narrow         | DataFrame union is NOT a shuffle               |

---

## Complete 15-Task Progression

### Easy (1–6) — Single Action

| # | Code                                          | Predicted Jobs | Notes                                                      |
|---|-----------------------------------------------|----------------|------------------------------------------------------------|
| 1 | `df.count()`                                  | 1              | Final aggregate is 1 task on 1 partition                   |
| 2 | `df.collect()`                                | 1              | All partitions to driver                                   |
| 3 | `df.first()`                                  | 1              | One job; reads only enough partitions                      |
| 4 | `df.write.parquet(p)`                         | 1              | Sometimes 2 with AQE                                       |
| 5 | `df.foreach(lambda r: None)`                  | 1              | Side-effect action                                         |
| 6 | `df.rdd.count()`                              | 1              | Falls back to RDD.count → still 1 job                      |

### Medium (7–11) — Multi-Action / Hidden Triggers

| # | Code                                                                | Predicted Jobs | Notes                                                       |
|---|---------------------------------------------------------------------|----------------|-------------------------------------------------------------|
| 7 | `df.show()` with N partitions, all 20 rows in partition 0           | 1              | executeTake exits after 1 iteration                         |
| 8 | `df.show()` with 8 partitions, only 2 rows total                     | 3              | Iter 1: 1 part, Iter 2: 4 parts, Iter 3: 3 parts           |
| 9 | `df.take(100)` on 200-partition df where rows spread evenly          | 2–3            | Depends on `initialNumPartitions` and `scaleUpFactor`       |
| 10| `df.toPandas()` on 1M row df                                         | 1              | Internally `collect()`                                      |
| 11| `spark.createDataFrame(python_list).count()`                          | 1 or 2         | Python `parallelize` may submit a setup job                 |

### Hard (12–15) — AQE / Caching / Side Effects

| # | Code                                                                  | Predicted Jobs    | Notes                                                       |
|---|-----------------------------------------------------------------------|--------------------|-------------------------------------------------------------|
| 12| `df.cache(); df.count(); df.show(); df.collect()`                     | 1 + 3 + 1 = 5     | Reference run from Index                                    |
| 13| AQE on, `df.groupBy("k").count().write.parquet(...)`                  | 1 + ~1 hidden     | AQE adds a stats-collection runJob                          |
| 14| `for i in range(3): df.count()`                                        | 3                | Each iter = 1 job (no caching)                              |
| 15| `df.checkpoint(); df.count()`                                          | 2                | Checkpoint = job to write to FS, then count                 |

---

## Strategy Notes

### Task 3 / Task 8 — `show()` Job Count

```
Approach:    Estimate based on data layout
             - Total partitions P
             - Default initialNumPartitions = 1
             - scaleUpFactor = 4
             - n = 21 (head(n+1) for show(20))

If first partition has >= 21 rows  -> 1 job
Else loop expands:  1 -> 4 -> 16 -> 64 ...
Job count = number of iterations until rows >= n OR all partitions scanned

Key insight: Spark UI ka job count is *probabilistic* on data layout.
```

### Task 4 vs Task 5 — Cache Behavior

```
Task 4: cache() + count()
        - cache() lazy
        - count() materializes -> 1 job
Task 5: cache() + count() + count()
        - 1st count -> 1 job, fills Storage tab
        - 2nd count -> 1 job, but stages mostly skipped (Pattern 05)

Always: count is 1 job, not 0 even if data is cached.
```

### Task 9 — `take(100)` Estimation

```
With initialNumPartitions=1, scaleUpFactor=4:
  Iter 1: 1 partition  -> if rows uniform, 100/200 ~ 0.5 rows. Not enough.
  Iter 2: 4 partitions -> ~2 rows.
  Iter 3: 16 partitions -> ~8 rows.
  Iter 4: 64 partitions -> ~32 rows.
  Iter 5: 200 partitions (capped) -> 100+ rows.

Predicted: 5 jobs.
Override: .config("spark.sql.limit.initialNumPartitions", "200") -> 1 job.
```

### Task 13 — AQE Hidden Jobs

```
Symptom:  Plain pipeline shows 5 jobs but with AQE on you see 7-8.
Cause:    AQE runs a planning job after each shuffle to collect map stats.
Where:    UI Description says "runJob at ThreadPoolExecutor.java:..."
Verify:   Toggle spark.sql.adaptive.enabled and rerun.
```

### Task 15 — Checkpoint Submits Its Own Job

```
df.checkpoint()           # submits ONE job that materializes RDD to FS
df.count()                # second job reads checkpoint files

Total: 2 jobs.
Difference vs cache: checkpoint is *eager* (writes immediately), cache is lazy.
```

---

## "How Many Jobs?" Cheat Table

```
ACTION                        TYPICAL JOBS    EXTRA JOBS WHEN...
----------------------------- --------------- ----------------------------
.count()                      1               -
.collect()                    1               +1 if AQE re-optimizes shuffle
.show() / .take() / .head()   1..log4(P)+1    fewer with limit.initialNumPartitions
.write.<format>(...)          1               +1 with AQE on shuffles
.toPandas()                   1 (collect)     same as collect
.checkpoint()                 1 (eager write) +1 if followed by another action
.foreach() / .foreachPartition() 1            -
spark.createDataFrame(python) 0..2            depends on parallelize path
.cache() / .persist()         0 (lazy)        next action triggers
```

---

## Cross-Reference

| If You're Studying...        | Also See                                           |
|------------------------------|----------------------------------------------------|
| Why show creates 3 jobs      | Pattern 03 — executeTake & Show Jobs               |
| Why some stages are skipped  | Pattern 05 — Skipped Stages & Reuse                |
| Why count has 3 stages       | Pattern 04 — Stages, Tasks & Shuffle Boundaries    |
| What AQE adds to UI          | Pattern 06 — SQL Tab & Physical Plans              |

---

## Study Plan

### Day 1 — Single-Action Predictions
- Tasks 1–6.
- Run each, verify exactly 1 job in Jobs tab.

### Day 2 — `show()` Mystery
- Task 7 vs Task 8 — change the data shape, observe job count change.
- Set `spark.sql.limit.initialNumPartitions` to `P` and watch jobs collapse to 1.

### Day 3 — Toggle AQE
- Run Task 13 with AQE off, then on.
- Compare Jobs tab side-by-side.

### Day 4 — Production-style
- Task 12 (the 5-job reference run).
- Tasks 14, 15 — production ETL flavor.

---

## Final Revision Box

```
ACTION = JOB         ->  the basic rule
SHOW / TAKE / LIMIT  ->  multiple jobs via executeTake loop
AQE on              ->  +1 hidden job per shuffle re-optimization
CACHE                ->  lazy; needs an action to materialize
CHECKPOINT          ->  eager; submits its own job
COLLECT / TO_PANDAS ->  same family
WRITE                ->  1 job (sometimes +1 with AQE)
FOREACH              ->  1 job (side-effect)
RULE                 ->  Always read Description + (skipped) stages.
                          Job count alone is misleading.
```
