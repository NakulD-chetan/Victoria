# How Amazon Lambda Works - In Depth (Easy Language)

> Companion to: [03-How-Amazon-Lambda-Works.md](03-How-Amazon-Lambda-Works.md)

---

## What Problem Does Lambda Solve?

### The "Paying for Empty Servers" Problem

Imagine you run a pizza delivery website. On weekdays, you get 10 orders/hour. On Friday nights, you get 500 orders/hour. On Super Bowl Sunday, you get 5,000 orders/hour.

**Traditional approach (EC2/servers):**

```
You must provision for peak load:
  → 10 servers running 24/7 for Super Bowl capacity
  → Monday morning: 9 servers sitting IDLE, burning money
  → You pay ~$3,000/month even when traffic is near zero
```

**Lambda approach (serverless):**

```
  → Friday night: Lambda spins up 50 instances automatically
  → Monday morning: Lambda scales to 1 instance
  → 3 AM: Lambda scales to ZERO instances (no cost!)
  → You pay only for the actual 200ms each function runs
```

**Analogy**: Traditional servers are like renting an entire restaurant 24/7. Lambda is like using a food truck that appears only when customers show up and disappears when they leave. You only pay per meal served.

---

## How Lambda Actually Runs Your Code

### The Three Core Services

Think of Lambda as a delivery company with three departments:

```
┌─────────────────────────────────────────────────────┐
│                    INVOKE SERVICE                     │
│        (The receptionist - routes your call)          │
│                                                       │
│   "Hello! You want to run function X?                │
│    Let me find someone who can handle that..."        │
└───────────────────────┬─────────────────────────────┘
                        │
┌───────────────────────▼─────────────────────────────┐
│                  ASSIGNMENT SERVICE                    │
│         (The manager - knows who's available)         │
│                                                       │
│   "Function X? Let me check... Worker 7 already has  │
│    function X loaded. Send it there!"                 │
│                                                       │
│   OR: "Nobody has function X. Spin up a new one."    │
└───────────────────────┬─────────────────────────────┘
                        │
┌───────────────────────▼─────────────────────────────┐
│                    WORKER POOL                        │
│        (The actual workers doing the job)             │
│                                                       │
│   Worker 1: [microVM-a] [microVM-b] [microVM-c]     │
│   Worker 2: [microVM-d] [microVM-e]                  │
│   Worker 3: [microVM-f] [microVM-g] [microVM-h]     │
└─────────────────────────────────────────────────────┘
```

---

## Firecracker - The Magic Behind Lambda

### Why Not Just Use Docker Containers?

You might think: "Just run each function in a Docker container!" But there's a security problem.

```
Docker containers share the HOST OS kernel:
  ┌──────────────────────────────┐
  │       HOST OS KERNEL          │  ← shared by all containers!
  ├─────────┬──────────┬─────────┤
  │ Your    │ Hacker's │ Bank's  │
  │ function│ function │ function│
  └─────────┴──────────┴─────────┘
  
  If someone finds a kernel exploit, they can escape
  their container and access YOUR data! BAD!
```

### Firecracker microVMs - The Best of Both Worlds

```
  ┌──────────────────────────────────────┐
  │           HOST OS KERNEL              │
  ├──────────────────────────────────────┤
  │          Firecracker VMM              │
  ├────────────┬────────────┬────────────┤
  │  microVM 1 │  microVM 2 │  microVM 3 │
  │ ┌────────┐ │ ┌────────┐ │ ┌────────┐ │
  │ │ Guest  │ │ │ Guest  │ │ │ Guest  │ │
  │ │ Kernel │ │ │ Kernel │ │ │ Kernel │ │
  │ ├────────┤ │ ├────────┤ │ ├────────┤ │
  │ │ Your   │ │ │Hacker's│ │ │ Bank's │ │
  │ │function│ │ │function│ │ │function│ │
  │ └────────┘ │ └────────┘ │ └────────┘ │
  └────────────┴────────────┴────────────┘
  
  Each function has its OWN kernel!
  One function can't see another's data.
```

Each microVM has:

- Its own **mini kernel** (complete isolation)
- Its own **memory** (can't read neighbor's RAM)
- Its own **virtual CPU** (can't steal neighbor's CPU time)

**But microVMs are MUCH lighter than full VMs:**

- Full VM (VMware/VirtualBox): boots in 30-60 seconds, uses 512MB+ RAM
- Firecracker microVM: boots in **~125 milliseconds**, uses just **5MB** RAM minimum

This means one physical server (worker) can run **thousands** of microVMs simultaneously!

---

## Warm Start vs Cold Start - The Key Concept

### What Is a Warm Start? (99% of requests)

```
Your function was invoked 5 seconds ago.The microVM is still running, code is loaded, runtime is ready.

New request arrives:
  → Route to existing microVM
  → Function executes immediately
  → Response in ~2-5 milliseconds
  → This is FAST!
```

Think of it like a car that's already running. You just press the gas pedal and GO.

### What Is a Cold Start? (Occasional)

```
Your function hasn't been invoked for a while.
No microVM exists for it.

New request arrives:
  → Create new microVM (~125ms)
  → Download your code from S3 (~200ms)
  → Load the runtime (Node.js/Python/Java) (~100ms)
  → Initialize your code (import libraries, etc.) (~500ms+)
  → NOW execute your function
  → Response in ~1-2 seconds
  → This is SLOW!
```

Think of it like starting a car that's been sitting in the cold. Turn key, engine cranks, warming up... then you can drive.

### Why Do Cold Starts Happen?

1. **First invocation ever** -- no microVM exists yet
2. **Hasn't been called for ~15 minutes** -- AWS recycles idle microVMs to save resources
3. **Traffic spike** -- all existing microVMs are busy, new ones must be created
4. **Code updated** -- new version needs a fresh microVM

---

## Three Tricks to Fix Cold Starts

### Trick 1: microVM Snapshots (90% Faster Cold Starts)

Instead of building a microVM from scratch every time:

```
WITHOUT snapshots:
  Create microVM → Download code → Load runtime → Init code → Execute
  [====125ms====] [===200ms====] [==100ms===] [==500ms==] [run]
  Total cold start: ~925ms

WITH snapshots:
  1. First time: do all the steps above
  2. SAVE the entire microVM state to disk (like a "screenshot")
  3. Next cold start: RESTORE from snapshot
  
  Restore snapshot → Execute
  [===50ms======] [run]
  Total cold start: ~50ms (90% faster!)
```

**Analogy**: Instead of reinstalling Windows every time you turn on your computer, you just wake it up from hibernate. Everything is exactly where you left it.

### Trick 2: Container Image Lazy Loading

If your function uses a container image (e.g., 500MB):

```
WITHOUT lazy loading:
  Download entire 500MB image → then start
  [====takes 10 seconds====]

WITH lazy loading:
  Only download the parts needed to START (maybe 50MB)
  [===1 second===] → function starts!
  Download the rest in the background while function runs
```

**Analogy**: Instead of downloading an entire movie before watching, you start streaming immediately and buffer as you go.

### Trick 3: Provisioned Concurrency (Pay to Stay Warm)

```
You tell AWS: "Keep 10 microVMs ALWAYS warm for my function"
  → AWS keeps 10 microVMs running and ready
  → First 10 concurrent requests = zero cold start
  → Request 11+ may get a cold start
  → You PAY for this (even when idle)
```

This is for latency-sensitive functions where even occasional cold starts are unacceptable (e.g., payment processing).

---

## The Assignment Service - How Lambda Tracks Everything

### Leader-Follower Pattern

The Assignment Service knows which workers are running which functions. It uses a leader-follower pattern:

```
  Assignment Service Leader → makes all decisions
        │
        ├── writes to Journal Log (durable storage)
        │
  Assignment Service Follower 1 → reads from Journal Log (backup)
  Assignment Service Follower 2 → reads from Journal Log (backup)
```

**What's the Journal Log?**

Think of it as a shared diary. The leader writes every decision in the diary:

```
"10:01 - Assigned function X to Worker 7, microVM-12"
"10:02 - Worker 3 is unhealthy, marking unavailable"
"10:03 - Assigned function Y to Worker 5, microVM-8"
```

If the leader dies, a follower reads the diary and knows exactly what the previous leader was doing. It can take over immediately without losing track of anything.

**Why not just keep this in the leader's memory?**

```
If leader dies and state is only in memory:
  → All information about which worker runs what is LOST
  → Must rediscover everything (slow, error-prone)
  → Some workers might become "orphaned" (running but forgotten)

With Journal Log:
  → New leader reads the log
  → Knows exactly which workers are running which functions
  → Seamless takeover in seconds
```

---

## The Placement Service - Managing Workers

The Placement Service is like a real estate agent for Lambda:

```
High traffic:
  → "We need more workers!"
  → Placement Service leases new EC2 instances
  → Firecracker starts microVMs on them
  → More capacity available

Low traffic:
  → "Workers are mostly idle"
  → Placement Service releases EC2 instances back to AWS
  → Saves money
  
Health monitoring:
  → "Worker 5 isn't responding to health checks"
  → Mark it unavailable
  → Reassign its functions to healthy workers
```

---

## Lambda Execution Limits (Good to Know)


| Limit                     | Value                                |
| ------------------------- | ------------------------------------ |
| Max execution time        | 15 minutes                           |
| Max memory                | 10 GB                                |
| Max package size (zip)    | 50 MB (250 MB unzipped)              |
| Max container image       | 10 GB                                |
| Max concurrent executions | 1,000 per account (can be increased) |
| Ephemeral storage (/tmp)  | 512 MB - 10 GB                       |


If your task takes longer than 15 minutes, Lambda is NOT the right tool. Use ECS/EKS (containers) or EC2 (VMs) instead.

---

## When Lambda vs Containers vs VMs?


| Aspect             | Lambda (Serverless)       | ECS/EKS (Containers)  | EC2 (VMs)                      |
| ------------------ | ------------------------- | --------------------- | ------------------------------ |
| **You manage**     | Just code                 | Container configs     | Everything (OS, networking...) |
| **Scales to zero** | Yes (no cost when idle)   | No (min 1 container)  | No (server always running)     |
| **Cold start**     | Yes (occasional)          | Fast (container pull) | No (always on)                 |
| **Max runtime**    | 15 minutes                | Unlimited             | Unlimited                      |
| **Best for**       | Short, event-driven tasks | Long-running services | Full control needed            |
| **Cost model**     | Per ms of execution       | Per hour of container | Per hour of instance           |


**Choose Lambda when**: Your code runs in < 15 min, traffic is unpredictable/spiky, you want zero operational overhead.

**Choose Containers when**: You need long-running processes, custom networking, or specific OS configurations.

**Choose EC2 when**: You need full control, GPU access, persistent state, or compliance requirements.

---

## Complete Request Flow

```
1. S3 file uploaded → triggers Lambda function "processImage"

2. INVOKE SERVICE receives the event
   → "Someone wants to run processImage"
   → Calls Assignment Service

3. ASSIGNMENT SERVICE checks:
   → "Is there a warm microVM for processImage?"
   → YES: Worker 7, microVM-12 is warm!
   → Routes request to Worker 7

4. WORKER 7 receives the request
   → microVM-12 is already running
   → Passes the S3 event to your function code
   → Your code: reads image, resizes it, saves thumbnail
   → Returns result

5. INVOKE SERVICE returns result to S3 trigger
   → Total time: 200ms (warm start!)

--- If it was a COLD START instead: ---

3. ASSIGNMENT SERVICE checks:
   → "Is there a warm microVM for processImage?"
   → NO: No warm microVM available
   → Asks Placement Service for a worker with capacity

4. PLACEMENT SERVICE:
   → Worker 3 has capacity
   → Firecracker creates new microVM on Worker 3
   → Downloads code from S3
   → Initializes runtime (Node.js)
   → microVM ready!

5. Request processed (same as step 4 above)
   → Total time: 1.2 seconds (cold start!)
   → Next request will be a warm start (fast!)
```

---

## Revision Flashcards

**Q: What is the main advantage of Lambda over EC2?**
A: No server management, auto-scaling (including to zero), and pay-per-execution. You don't pay for idle time.

**Q: Why does Lambda use Firecracker microVMs instead of Docker containers?**
A: Stronger security isolation. Each microVM has its own kernel, so one customer's code can't access another's data. Containers share the host kernel, which is a security risk in multi-tenant environments.

**Q: What's the difference between a warm start and cold start?**
A: Warm start reuses an existing microVM (milliseconds). Cold start creates a new microVM, downloads code, initializes runtime (can take seconds). 99% of requests are warm starts.

**Q: How do microVM snapshots reduce cold start time by 90%?**
A: Instead of creating a new microVM and initializing everything from scratch, Lambda restores a previously saved snapshot of a fully initialized microVM. It's like resuming from hibernate instead of rebooting.

**Q: What is the Journal Log for?**
A: It durably stores the Assignment Service's decisions (which worker runs which function). If the Assignment Service leader dies, the new leader reads the journal to know exactly what's happening and takes over seamlessly.

**Q: When should you NOT use Lambda?**
A: When your task takes > 15 minutes, needs persistent state, requires GPU, needs custom networking, or must run continuously. Use containers (ECS) or VMs (EC2) instead.