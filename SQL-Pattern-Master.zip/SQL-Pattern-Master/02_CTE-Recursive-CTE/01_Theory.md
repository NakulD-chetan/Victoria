# CTE / Recursive CTE

A Common Table Expression (CTE) is a temporary named result set that exists only within a single query. A Recursive CTE calls itself repeatedly to traverse hierarchies — org charts, category trees, graph paths.

**DSA Analogy**: Recursion / DFS in trees — a base case starts the traversal, the recursive step walks deeper into the tree, and the call stack unwinds to produce the full result.

---

## Core Idea (2 Lines)

A **CTE** gives a name to a subquery so you can reference it multiple times in the same statement — cleaner than nested subqueries. A **Recursive CTE** adds a self-referencing UNION ALL that repeatedly expands rows until no new rows are produced — perfect for tree/graph traversal.

---

## Part 1: Regular CTE

### Syntax Template

```sql
WITH cte_name AS (
    SELECT ...
    FROM ...
    WHERE ...
)
SELECT *
FROM cte_name
WHERE ...;
```

### Multiple CTEs (Chained)

```sql
WITH
  cte1 AS (SELECT ... FROM ...),
  cte2 AS (SELECT ... FROM cte1),      -- cte2 can reference cte1
  cte3 AS (SELECT ... FROM cte1 JOIN cte2 ON ...)
SELECT *
FROM cte3;
```

### Why CTE Over Subquery?

| Feature | CTE | Subquery |
|---------|-----|----------|
| Readability | Named, top-to-bottom flow | Nested, inside-out reading |
| Reuse | Reference multiple times | Must duplicate the query |
| Recursion | Supported | Not supported |
| Performance | Usually same as subquery | Usually same as CTE |
| Materialization | Engine decides (not forced) | Engine decides |

### Example: Clean Multi-Step Query

```sql
-- Find departments where average salary exceeds company average
WITH dept_avg AS (
    SELECT dept, AVG(salary) AS avg_sal
    FROM employees
    GROUP BY dept
),
company_avg AS (
    SELECT AVG(salary) AS avg_sal
    FROM employees
)
SELECT d.dept, d.avg_sal, c.avg_sal AS company_avg
FROM dept_avg d
CROSS JOIN company_avg c
WHERE d.avg_sal > c.avg_sal;
```

Without CTE, this would be a deeply nested subquery — hard to read and maintain.

---

## Part 2: Recursive CTE

### Syntax Template

```sql
WITH RECURSIVE cte_name AS (
    -- ANCHOR: base case (non-recursive query)
    SELECT base_columns
    FROM base_table
    WHERE starting_condition

    UNION ALL

    -- RECURSIVE STEP: references cte_name itself
    SELECT derived_columns
    FROM base_table t
    JOIN cte_name c ON t.parent = c.id     -- the self-reference
)
SELECT * FROM cte_name;
```

**Three parts, exactly like recursion in code:**

```
function traverse(node):          WITH RECURSIVE cte AS (
    if node is root:                  SELECT ... WHERE parent IS NULL   ← anchor
        return [node]
    return node +                     UNION ALL
        traverse(node.parent)         SELECT ... JOIN cte ON ...        ← recursive step
                                  )
```

### How It Executes (Step by Step)

```
Iteration 0:  Run ANCHOR query → produces initial rows
Iteration 1:  Run RECURSIVE step using Iteration 0 rows → new rows
Iteration 2:  Run RECURSIVE step using Iteration 1 rows → new rows
...
Iteration N:  RECURSIVE step produces 0 new rows → STOP
Final:        UNION ALL of all iterations = complete result
```

```
  Anchor:     [CEO]
                |
  Iter 1:     [VP1, VP2]
                |       |
  Iter 2:     [Mgr1]  [Mgr2, Mgr3]
                |
  Iter 3:     [Emp1, Emp2]
                |
  Iter 4:     (empty) → STOP
  
  Result:     CEO + VP1 + VP2 + Mgr1 + Mgr2 + Mgr3 + Emp1 + Emp2
```

---

## Classic Examples

### 1. Org Chart — Find All Reports Under a Manager

```sql
WITH RECURSIVE org AS (
    -- Anchor: start with the target manager
    SELECT id, name, manager_id, 1 AS level
    FROM employees
    WHERE name = 'Alice'

    UNION ALL

    -- Recursive: find direct reports of current level
    SELECT e.id, e.name, e.manager_id, o.level + 1
    FROM employees e
    JOIN org o ON e.manager_id = o.id
)
SELECT * FROM org ORDER BY level;
```

### 2. Category Path — Build Full Category Breadcrumb

```sql
WITH RECURSIVE cat_path AS (
    SELECT id, name, parent_id, name AS full_path
    FROM categories
    WHERE parent_id IS NULL

    UNION ALL

    SELECT c.id, c.name, c.parent_id,
           cp.full_path || ' > ' || c.name
    FROM categories c
    JOIN cat_path cp ON c.parent_id = cp.id
)
SELECT * FROM cat_path;

-- Result: "Electronics > Phones > Smartphones"
```

### 3. Generate a Number Series

```sql
WITH RECURSIVE nums AS (
    SELECT 1 AS n
    UNION ALL
    SELECT n + 1 FROM nums WHERE n < 100
)
SELECT n FROM nums;

-- Produces: 1, 2, 3, ..., 100
```

### 4. Bill of Materials — Explode Nested Components

```sql
WITH RECURSIVE bom AS (
    SELECT part_id, component_id, quantity, 1 AS depth
    FROM parts_tree
    WHERE part_id = 'BIKE-001'

    UNION ALL

    SELECT p.part_id, p.component_id, p.quantity * b.quantity, b.depth + 1
    FROM parts_tree p
    JOIN bom b ON p.part_id = b.component_id
)
SELECT * FROM bom;
```

---

## Recursion Safeguards

| Problem | Solution |
|---------|----------|
| Infinite loop (cycle in data) | Add a `depth` counter, filter WHERE depth < 100 |
| Runaway query | PostgreSQL: `SET statement_timeout`; MySQL: `cte_max_recursion_depth` |
| Duplicate visits | Track visited IDs in an array: `WHERE id != ALL(visited_array)` |
| No termination | Ensure recursive step eventually produces 0 rows |

```sql
-- MySQL: increase recursion limit
SET cte_max_recursion_depth = 1000;

-- PostgreSQL: cycle detection (v14+)
WITH RECURSIVE cte AS (...)
CYCLE id SET is_cycle USING path;
```

---

## CTE vs Temp Table vs Subquery

| Feature | CTE | Temp Table | Subquery |
|---------|-----|------------|----------|
| Scope | Single statement | Session | Single statement |
| Indexed | No | Yes | No |
| Materialized | Engine decides | Always | Engine decides |
| Recursive | Yes | No | No |
| Reusable | Within same query | Across queries | No |
| Best for | Readability, recursion | Large intermediate sets | Simple one-off filters |

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Forgetting RECURSIVE keyword | CTE won't self-reference | `WITH RECURSIVE` (PostgreSQL/MySQL); SQL Server doesn't need it |
| Using UNION instead of UNION ALL | Dedup kills performance, may remove valid rows | Always use UNION ALL in recursive CTEs |
| No termination condition | Infinite recursion | Add WHERE depth < N or ensure join shrinks result |
| Referencing CTE in wrong scope | CTE only exists in the statement it's defined in | If you need it elsewhere, use a temp table |

---

## Database Syntax Differences

| Feature | PostgreSQL | MySQL 8+ | SQL Server |
|---------|-----------|----------|------------|
| Keyword | `WITH RECURSIVE` | `WITH RECURSIVE` | `WITH` (no RECURSIVE keyword needed) |
| Max depth | No default limit | 1000 (configurable) | 100 (configurable via OPTION MAXRECURSION) |
| Cycle detect | `CYCLE ... SET ... USING` (v14) | Manual | Manual |

---

## Key Takeaway

> **Regular CTEs** are named subqueries for readability and reuse. **Recursive CTEs** are SQL's recursion — an anchor (base case) plus a recursive step that self-references, exactly like DFS on a tree. Use them for org charts, category paths, number generation, and any hierarchy traversal. Always add a depth guard to prevent infinite loops.
