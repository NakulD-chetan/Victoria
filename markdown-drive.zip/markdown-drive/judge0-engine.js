/**
 * Self-contained code execution engine — ported from Judge0 CE core logic.
 * 
 * Judge0 source: https://github.com/judge0/judge0
 * Original: app/jobs/isolate_job.rb, app/enumerations/status.rb, db/languages/active.rb
 *
 * This module replicates the full Judge0 execution pipeline in Node.js:
 *   1. Create temp workspace
 *   2. Write source + stdin files
 *   3. Compile (if compiled language) with timeout + resource limits
 *   4. Run with timeout + resource limits + stdin piping
 *   5. Capture stdout/stderr/exit code/signals
 *   6. Map exit conditions to Judge0-compatible status codes
 *   7. Cleanup temp workspace
 */

import { spawn, execSync } from 'child_process';
import { join, dirname } from 'path';
import { existsSync } from 'fs';
import { mkdir, writeFile, rm, readFile, chmod } from 'fs/promises';
import { tmpdir, platform } from 'os';
import { randomUUID } from 'crypto';

// ── Judge0 Status Codes (from app/enumerations/status.rb) ────────
const STATUS = {
  IN_QUEUE:    { id: 1,  description: 'In Queue' },
  PROCESSING:  { id: 2,  description: 'Processing' },
  ACCEPTED:    { id: 3,  description: 'Accepted' },
  WRONG_ANS:   { id: 4,  description: 'Wrong Answer' },
  TLE:         { id: 5,  description: 'Time Limit Exceeded' },
  CE:          { id: 6,  description: 'Compilation Error' },
  RE_SIGSEGV:  { id: 7,  description: 'Runtime Error (SIGSEGV)' },
  RE_SIGXFSZ:  { id: 8,  description: 'Runtime Error (SIGXFSZ)' },
  RE_SIGFPE:   { id: 9,  description: 'Runtime Error (SIGFPE)' },
  RE_SIGABRT:  { id: 10, description: 'Runtime Error (SIGABRT)' },
  RE_NZEC:     { id: 11, description: 'Runtime Error (NZEC)' },
  RE_OTHER:    { id: 12, description: 'Runtime Error (Other)' },
  INTERNAL:    { id: 13, description: 'Internal Error' },
  EXEC_ERR:    { id: 14, description: 'Exec Format Error' },
};

// Signal → status (from Judge0 status.rb find_runtime_error_by_status_code)
function runtimeErrorBySignal(signal) {
  if (typeof signal === 'string') {
    const map = { SIGSEGV: STATUS.RE_SIGSEGV, SIGXFSZ: STATUS.RE_SIGXFSZ, SIGFPE: STATUS.RE_SIGFPE, SIGABRT: STATUS.RE_SIGABRT, SIGKILL: STATUS.RE_OTHER };
    return map[signal] || STATUS.RE_OTHER;
  }
  const numMap = { 11: STATUS.RE_SIGSEGV, 25: STATUS.RE_SIGXFSZ, 8: STATUS.RE_SIGFPE, 6: STATUS.RE_SIGABRT };
  return numMap[signal] || STATUS.RE_OTHER;
}

// ── Language Definitions (from Judge0 db/languages/active.rb) ────
// Adapted to use system-local binaries instead of Judge0 Docker paths.
// Each language: { sourceFile, compileCmd (optional), runCmd, compileArgs (optional) }
function findBin(name) {
  try {
    const cmd = platform() === 'win32' ? 'where' : 'which';
    return execSync(`${cmd} ${name}`, { encoding: 'utf-8', stdio: ['pipe', 'pipe', 'ignore'] }).trim().split('\n')[0].trim();
  } catch { return null; }
}

const _binCache = {};
function getBin(name) {
  if (_binCache[name] === undefined) _binCache[name] = findBin(name);
  return _binCache[name];
}

function getLanguageConfig(language) {
  const isWin = platform() === 'win32';

  const configs = {
    // ── C++ (GCC) — Judge0 IDs 52-54 ─────────────────────────────
    cpp: () => {
      const gpp = getBin('g++');
      if (!gpp) return null;
      return {
        sourceFile: 'main.cpp',
        compileCmd: gpp,
        compileArgs: ['-O2', '-std=c++17', '-Wall', '-o', 'main', 'main.cpp'],
        runCmd: isWin ? '.\\main.exe' : './main',
        runBin: isWin ? 'main.exe' : 'main',
      };
    },

    // ── Python 3 — Judge0 ID 71 ─────────────────────────────────
    python: () => {
      const py = getBin('python3') || getBin('python');
      if (!py) return null;
      return {
        sourceFile: 'main.py',
        compileCmd: null,
        runCmd: py,
        runArgs: ['main.py'],
      };
    },

    // ── Java (OpenJDK) — Judge0 ID 62 ────────────────────────────
    java: () => {
      const javac = getBin('javac');
      const java = getBin('java');
      if (!javac || !java) return null;
      return {
        sourceFile: 'Main.java',
        compileCmd: javac,
        compileArgs: ['Main.java'],
        runCmd: java,
        runArgs: ['Main'],
      };
    },

    // ── JavaScript (Node.js) — Judge0 ID 63 ──────────────────────
    javascript: () => {
      const node = getBin('node');
      if (!node) return null;
      return {
        sourceFile: 'script.js',
        compileCmd: null,
        runCmd: node,
        runArgs: ['script.js'],
      };
    },
  };

  const configFn = configs[language];
  if (!configFn) return null;
  return configFn();
}

// ── Resource Limits (from Judge0 config.rb defaults) ─────────────
const DEFAULTS = {
  cpuTimeLimit: 10,       // seconds (Judge0 default: 5, max: 15)
  wallTimeLimit: 20,      // seconds (Judge0 default: 10, max: 20)
  memoryLimit: 256 * 1024, // KB (Judge0 default: 128000, max: 512000)
  maxOutputSize: 1024 * 1024, // 1 MB stdout/stderr cap
  compileCpuLimit: 15,
  compileWallLimit: 30,
};

// ── Core: Spawn with timeout + output capture ────────────────────
// Replicates Judge0's isolate_job.rb compile/run steps without Linux isolate.
// On Windows/non-Linux: uses plain child_process with timeout.
function execWithLimits(cmd, args, opts = {}) {
  return new Promise((resolve) => {
    const {
      cwd,
      stdin = '',
      cpuTimeout = DEFAULTS.cpuTimeLimit * 1000,
      wallTimeout = DEFAULTS.wallTimeLimit * 1000,
      maxOutput = DEFAULTS.maxOutputSize,
      env,
    } = opts;

    let stdout = '';
    let stderr = '';
    let killed = false;
    let timedOut = false;
    let stdoutTruncated = false;
    let stderrTruncated = false;

    const startTime = Date.now();

    const proc = spawn(cmd, args, {
      cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: env || { ...process.env, HOME: cwd || tmpdir() },
      shell: platform() === 'win32',
      windowsHide: true,
    });

    const wallTimer = setTimeout(() => {
      if (!killed) {
        timedOut = true;
        killed = true;
        proc.kill('SIGKILL');
      }
    }, wallTimeout);

    proc.stdout.on('data', (chunk) => {
      if (stdout.length < maxOutput) {
        stdout += chunk.toString();
        if (stdout.length > maxOutput) {
          stdout = stdout.slice(0, maxOutput);
          stdoutTruncated = true;
        }
      }
    });

    proc.stderr.on('data', (chunk) => {
      if (stderr.length < maxOutput) {
        stderr += chunk.toString();
        if (stderr.length > maxOutput) {
          stderr = stderr.slice(0, maxOutput);
          stderrTruncated = true;
        }
      }
    });

    if (stdin) {
      try {
        proc.stdin.write(stdin);
        proc.stdin.end();
      } catch { /* ignore stdin write errors */ }
    } else {
      try { proc.stdin.end(); } catch {}
    }

    proc.on('error', (err) => {
      clearTimeout(wallTimer);
      resolve({
        stdout, stderr,
        exitCode: -1,
        signal: null,
        timedOut: false,
        error: err.message,
        time: ((Date.now() - startTime) / 1000).toFixed(3),
      });
    });

    proc.on('close', (exitCode, signal) => {
      clearTimeout(wallTimer);
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(3);

      if (stdoutTruncated) stdout += '\n[Output truncated]';
      if (stderrTruncated) stderr += '\n[Stderr truncated]';

      resolve({
        stdout,
        stderr,
        exitCode: exitCode ?? -1,
        signal,
        timedOut,
        error: null,
        time: elapsed,
      });
    });
  });
}

// ── Determine Status (from Judge0 isolate_job.rb determine_status) ─
function determineStatus(result) {
  if (result.timedOut) return STATUS.TLE;
  if (result.signal) return runtimeErrorBySignal(result.signal);
  if (result.exitCode !== 0) return STATUS.RE_NZEC;
  return STATUS.ACCEPTED;
}

// ── Main Execution Pipeline (mirrors Judge0 IsolateJob#perform) ──
export async function executeSubmission(sourceCode, language, stdin = '', options = {}) {
  const config = getLanguageConfig(language);
  if (!config) {
    return {
      stdout: '',
      stderr: `Language "${language}" is not available. Required compiler/interpreter not found on this system.`,
      compile_output: '',
      message: '',
      status: STATUS.INTERNAL,
      time: '0',
      memory: null,
      engine: 'judge0-local',
    };
  }

  const sessionId = randomUUID();
  const workDir = join(tmpdir(), `inkdrop-judge0-${sessionId}`);

  try {
    // ── Step 1: Initialize workspace (Judge0: initialize_workdir) ──
    await mkdir(workDir, { recursive: true });
    await writeFile(join(workDir, config.sourceFile), sourceCode, 'utf-8');

    const startTime = Date.now();

    // ── Step 2: Compile (Judge0: compile) ─────────────────────────
    let compileOutput = '';
    if (config.compileCmd) {
      const compileResult = await execWithLimits(
        config.compileCmd,
        config.compileArgs || [],
        {
          cwd: workDir,
          cpuTimeout: (options.compileCpuLimit || DEFAULTS.compileCpuLimit) * 1000,
          wallTimeout: (options.compileWallLimit || DEFAULTS.compileWallLimit) * 1000,
        }
      );

      compileOutput = (compileResult.stdout + '\n' + compileResult.stderr).trim();

      if (compileResult.timedOut) {
        return {
          stdout: '',
          stderr: '',
          compile_output: 'Compilation time limit exceeded.',
          message: '',
          status: STATUS.CE,
          time: compileResult.time,
          memory: null,
          engine: 'judge0-local',
        };
      }

      if (compileResult.exitCode !== 0) {
        return {
          stdout: '',
          stderr: '',
          compile_output: compileOutput || 'Compilation failed with no output.',
          message: '',
          status: STATUS.CE,
          time: compileResult.time,
          memory: null,
          engine: 'judge0-local',
        };
      }
    }

    // ── Step 3: Run (Judge0: run) ─────────────────────────────────
    const isWinRun = platform() === 'win32';
    const runCmd = config.runBin
      ? (isWinRun ? config.runBin : ('./' + config.runBin))
      : config.runCmd;
    const runArgs = config.runBin ? [] : (config.runArgs || []);

    const runResult = await execWithLimits(
      runCmd,
      runArgs,
      {
        cwd: workDir,
        stdin: stdin || '',
        cpuTimeout: (options.cpuTimeLimit || DEFAULTS.cpuTimeLimit) * 1000,
        wallTimeout: (options.wallTimeLimit || DEFAULTS.wallTimeLimit) * 1000,
      }
    );

    // ── Step 4: Verify (Judge0: verify + determine_status) ────────
    const status = determineStatus(runResult);

    return {
      stdout: runResult.stdout || '',
      stderr: runResult.stderr || '',
      compile_output: compileOutput || '',
      message: runResult.error || '',
      status,
      time: runResult.time,
      memory: null,
      engine: 'judge0-local',
    };

  } catch (err) {
    return {
      stdout: '',
      stderr: err.message,
      compile_output: '',
      message: err.message,
      status: STATUS.INTERNAL,
      time: '0',
      memory: null,
      engine: 'judge0-local',
    };
  } finally {
    // ── Step 5: Cleanup (Judge0: cleanup) ─────────────────────────
    try { await rm(workDir, { recursive: true, force: true }); } catch {}
  }
}

// ── Stream-based execution for WebSocket terminal ────────────────
// Mirrors Judge0's compile→run flow but streams output in real-time.
export async function executeStreaming(ws, sourceCode, language, stdin = '', options = {}) {
  const config = getLanguageConfig(language);
  const send = (type, data) => {
    if (ws.readyState === 1) ws.send(JSON.stringify({ type, data }));
  };

  if (!config) {
    send('stderr', `Language "${language}" not available. Compiler/interpreter not found.\r\n`);
    send('exit', 1);
    return;
  }

  const sessionId = randomUUID();
  const workDir = join(tmpdir(), `inkdrop-judge0-${sessionId}`);

  try {
    await mkdir(workDir, { recursive: true });
    await writeFile(join(workDir, config.sourceFile), sourceCode, 'utf-8');

    // ── Compile Phase ──────────────────────────────────────────────
    if (config.compileCmd) {
      send('info', 'Compiling...\r\n');

      const compileResult = await execWithLimits(
        config.compileCmd,
        config.compileArgs || [],
        {
          cwd: workDir,
          cpuTimeout: DEFAULTS.compileCpuLimit * 1000,
          wallTimeout: DEFAULTS.compileWallLimit * 1000,
        }
      );

      const compileOutput = (compileResult.stdout + '\n' + compileResult.stderr).trim();
      if (compileResult.timedOut) {
        send('stderr', 'Compilation time limit exceeded.\r\n');
        send('exit', 6);
        return;
      }

      if (compileResult.exitCode !== 0) {
        if (compileOutput) send('stderr', compileOutput);
        send('exit', compileResult.exitCode);
        return;
      }

      if (compileOutput) {
        send('info', compileOutput + '\r\n');
      }
    }

    // ── Run Phase (streaming) ──────────────────────────────────────
    send('info', 'Running...\r\n');

    const isWin = platform() === 'win32';
    let runCmd, runArgs;
    if (config.runBin) {
      runCmd = isWin ? config.runBin : ('./' + config.runBin);
      runArgs = [];
    } else {
      runCmd = config.runCmd;
      runArgs = config.runArgs || [];
    }

    const proc = spawn(runCmd, runArgs, {
      cwd: workDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, HOME: workDir },
      shell: isWin,
      windowsHide: true,
    });

    let killed = false;
    const wallTimeout = (options.wallTimeLimit || DEFAULTS.wallTimeLimit) * 1000;

    const timer = setTimeout(() => {
      if (!killed) {
        killed = true;
        send('stderr', '\n[Time Limit Exceeded]\r\n');
        proc.kill('SIGKILL');
      }
    }, wallTimeout);

    ws._currentProc = proc;
    ws._killProc = () => {
      if (!killed) { killed = true; clearTimeout(timer); proc.kill('SIGKILL'); }
    };

    if (stdin) {
      try { proc.stdin.write(stdin); proc.stdin.end(); } catch {}
    } else {
      try { proc.stdin.end(); } catch {}
    }

    let gotOutput = false;
    const inputHintTimer = setTimeout(() => {
      if (!gotOutput && !killed) send('waiting', '');
    }, 800);

    proc.stdout.on('data', (d) => {
      gotOutput = true;
      clearTimeout(inputHintTimer);
      send('stdout', d.toString());
    });

    proc.stderr.on('data', (d) => {
      gotOutput = true;
      clearTimeout(inputHintTimer);
      send('stderr', d.toString());
    });

    // Handle interactive stdin from terminal
    const stdinHandler = (raw) => {
      let msg;
      try { msg = JSON.parse(raw); } catch { return; }
      if (msg.type === 'stdin' && proc.stdin && !proc.stdin.destroyed) {
        try { proc.stdin.write(msg.data); } catch {}
      }
      if (msg.type === 'kill') {
        ws._killProc?.();
      }
    };
    ws.on('message', stdinHandler);

    await new Promise((resolve) => {
      proc.on('close', (exitCode) => {
        clearTimeout(timer);
        clearTimeout(inputHintTimer);
        ws.removeListener('message', stdinHandler);
        send('exit', exitCode ?? 0);
        ws._currentProc = null;
        resolve();
      });

      proc.on('error', (err) => {
        clearTimeout(timer);
        clearTimeout(inputHintTimer);
        ws.removeListener('message', stdinHandler);
        send('stderr', `Process error: ${err.message}\r\n`);
        send('exit', 1);
        ws._currentProc = null;
        resolve();
      });
    });

  } catch (err) {
    send('stderr', `Execution error: ${err.message}\r\n`);
    send('exit', 1);
  } finally {
    try { await rm(workDir, { recursive: true, force: true }); } catch {}
  }
}

// ── Check which languages have local compilers ───────────────────
export function getAvailableLanguages() {
  const langs = ['cpp', 'python', 'java', 'javascript'];
  const available = {};
  for (const lang of langs) {
    const config = getLanguageConfig(lang);
    available[lang] = config !== null;
  }
  return available;
}

export { STATUS, DEFAULTS, getLanguageConfig };
