# Distributed Systems — Multiple Machines Ko Ek Jaisa Kaam Karwao

> **Distributed System = Bahut saare computers milke ek kaam karein jaise ek hi computer ho**
> Challenge: Network unreliable, machines fail hoti hain, clock sync nahi hota — phir bhi sahi kaam karna hai!

---

## Table of Contents
1. [Distributed Systems Kya Hai?](#1-distributed-systems-kya-hai)
2. [Why Distributed?](#2-why-distributed)
3. [Challenges](#3-challenges)
4. [Consensus Basics](#4-consensus-basics)
5. [Leader Election](#5-leader-election)
6. [Distributed Locking](#6-distributed-locking)
7. [Heartbeat Mechanism](#7-heartbeat-mechanism)
8. [Failure Handling](#8-failure-handling)
9. [Retry Mechanism](#9-retry-mechanism)
10. [Backoff Strategy](#10-backoff-strategy)
11. [Distributed Transactions](#11-distributed-transactions)
12. [Clock Synchronization](#12-clock-synchronization)
13. [Split Brain Problem](#13-split-brain-problem)
14. [Interview Questions](#14-interview-questions)

---

## 1. Distributed Systems Kya Hai?

### Core Concept
**Distributed System** = Multiple computers (nodes) milke ek coordinated system banate hain. User ko lagta hai ek hi system hai.

### Real World Analogy — Orchestra
Socho ek orchestra hai:
- Har musician = ek node (computer)
- Conductor = coordination
- Sab milke ek music produce karte hain
- Koi ek fail ho = baaki adjust karke chalate hain

### How It Works
```
    Single Machine:          Distributed:
    
    [User] --> [One Server]   [User] --> [LB] --> [Server 1]
                                    --> [Server 2]
                                    --> [Server 3]
                                    --> [DB Cluster]
```

### Key Characteristics
- **No shared memory** — nodes communicate via network
- **Concurrent** — parallel execution
- **Independent failures** — ek fail, doosra chal sakta hai
- **No global clock** — sync mushkil

### 1 Minute Recall Block
- Distributed = multiple machines, one logical system
- Network se communicate
- Independent failures

### 5 Bullet Memory Hooks
1. Multiple computers = one system
2. Network communication
3. No shared memory
4. Independent failures
5. User ko transparent

---

## 2. Why Distributed?

### Reasons
| Reason | Explanation | Example |
|--------|-------------|---------|
| **Scale** | Single machine limit | 1M requests/sec |
| **Fault Tolerance** | One fail = others work | High availability |
| **Geography** | Users globally | Low latency |
| **Cost** | Cheap machines > 1 expensive | Horizontal scaling |

### Real World Analogy — Restaurant Chain
- Ek restaurant = limited capacity
- Multiple branches = more customers
- Ek branch band = others open
- Customer ke paas wala branch = less travel

### 1 Minute Recall Block
- Scale beyond single machine
- Fault tolerance
- Geographic distribution
- Cost effective

### 5 Bullet Memory Hooks
1. Scale = horizontal add machines
2. Fault tolerance = redundancy
3. Geography = latency
4. Cost = commodity hardware
5. CAP theorem applies

---

## 3. Challenges

### Network Unreliable
```
Node A -------X------- Node B
         (message lost)
         
- Messages can be lost
- Messages can be delayed
- Messages can be duplicated
- Order can change
```

### Clock Drift
```
Node A: 10:00:00.000
Node B: 10:00:00.050  (50ms ahead)
Node C: 09:59:59.900  (100ms behind)

"Which event happened first?" — unclear!
```

### Partial Failures
```
[Node 1] [Node 2] [Node 3] [Node 4]
    OK      OK      FAIL     OK
    
Some nodes work, some don't — hardest to handle!
```

### Real World Analogy — Group Project
- Network = unreliable communication (messages lost)
- Clock = "maine pehle kiya" — kisne pehle? unclear
- Partial failure = 1 member absent, baaki kaise proceed?

### 1 Minute Recall Block
- Network: loss, delay, reorder
- Clocks: not synchronized
- Partial failures: some nodes down

### 5 Bullet Memory Hooks
1. Network unreliable
2. No global clock
3. Partial failures tricky
4. Messages can duplicate
5. Order not guaranteed

---

## 4. Consensus Basics

### What is Consensus?
**Consensus** = Sab nodes ek decision pe agree karein. Sab ko same value pata ho.

```
Node 1: value = 5
Node 2: value = 5
Node 3: value = 5
Node 4: value = 5

Consensus achieved! Sab agree.
```

### Why Hard?
- Nodes fail
- Network partitions
- Messages delayed
- Byzantine failures (malicious nodes)

### Paxos (Simplified)
```
Paxos = Complex but foundational
- Proposer proposes value
- Acceptor accepts/rejects
- Learner learns chosen value
- Multiple rounds, quorum based

Interview: "Paxos kya hai?" — "Consensus algorithm, 
complex, Raft easier to understand"
```

### Raft (More Understandable)
```
Raft = Leader-based consensus
- One leader, rest followers
- Leader receives requests, replicates to followers
- Majority (quorum) agree = committed
- Leader election if leader fails
```

### How Raft Works

#### 1. Leader Election
```
[Follower] [Follower] [Follower]
     |          |          |
     +----------+----------+
     No leader! Election timeout
     
[Follower] [Candidate] [Follower]
     |          |          |
     +-- Request votes --->+
     
[Follower] [Leader] [Follower]
     |          |          |
     +<-- Append entries --+
```

#### 2. Log Replication
```
Client --> Leader: "Write X"
Leader --> Followers: "Append X to log"
Majority ack --> Leader: "Committed"
Leader --> Client: "OK"
```

#### 3. Safety
- Election safety: at most one leader per term
- Log matching: same index = same entry
- Leader completeness: committed = in future leaders

### 1 Minute Recall Block
- Consensus = all agree on value
- Paxos = complex, original
- Raft = leader-based, understandable
- Quorum = majority

### 5 Bullet Memory Hooks
1. Consensus = agreement
2. Paxos = complex
3. Raft = leader-based
4. Quorum = N/2 + 1
5. Used in etcd, Consul

### Common Interview Trap
**"Paxos vs Raft?"** — Raft designed to be understandable. Paxos correct but hard. Raft = same guarantees, easier.

---

## 5. Leader Election

### Why We Need a Leader?
- Single point for writes (consistency)
- Avoid split decisions
- Simplify coordination
- Ordering guarantee

### Bully Algorithm (Simplified)
```
Nodes: 1, 2, 3, 4, 5 (ID = priority)
Leader 5 fails.

Node 4: "Election!" sends to 5 (no response)
Node 3: "Election!" sends to 4, 5
Node 4: "I'm higher" — wins
Node 4 becomes leader (highest ID among alive)
```

### Raft Leader Election
```
1. Follower doesn't hear from leader (timeout)
2. Becomes Candidate, increments term
3. Requests votes from all
4. Majority votes = Leader
5. Leader sends heartbeats
6. No heartbeats = new election
```

### ZooKeeper for Leader Election
```
1. Create ephemeral sequential node: /election/node_
2. Smallest number = leader
3. Others watch previous node
4. Leader dies = node deleted = next becomes leader
```

### Comparison
| Method | Use Case | Complexity |
|--------|----------|------------|
| Bully | Simple systems | Low |
| Raft | Consensus systems | Medium |
| ZooKeeper | External coordination | Medium |

### 1 Minute Recall Block
- Leader = single coordinator
- Bully = highest ID wins
- Raft = votes, term
- ZooKeeper = ephemeral nodes

### 5 Bullet Memory Hooks
1. Leader = coordination point
2. Bully = ID based
3. Raft = vote based
4. ZooKeeper = sequential nodes
5. Ephemeral = dies with session

---

## 6. Distributed Locking

### Why Needed?
Multiple services same resource pe kaam karein — race condition avoid.

```
Service A: "I'll update balance"
Service B: "I'll update balance" (same time!)
→ Conflict! Lock chahiye
```

### Redis-Based Lock (SETNX + TTL)
```
SET lock:resource user123 NX EX 30
- NX = only if not exists
- EX 30 = expire in 30 seconds
- Got lock? Do work. Release with DEL.
```

### Problem: Lock Expiry
```
Timeline:
T1: A gets lock (30 sec)
T2: A slow... 30 sec pass
T3: Lock expires!
T4: B gets lock
T5: A finishes, DEL lock (deletes B's lock!)
T6: C gets lock — A and B both think they have it!
```

### Solution: Fencing Tokens
```
Server gives monotonically increasing token with each lock.
A gets lock, token=33
B gets lock, token=34
A's request (token=33) arrives at resource — REJECTED (34 > 33)
```

### Redlock Algorithm (Multiple Redis)
```
5 Redis instances (independent)
1. Get current time
2. Try lock on all 5 (same key, same value, same TTL)
3. Lock acquired when: majority got it AND time < TTL
4. Release on all
```

### ZooKeeper Locks
```
Create sequential ephemeral: /lock/lock_
Smallest = holds lock
Others watch previous
Previous deleted = your turn
```

### Comparison
| Method | Consistency | Complexity | Use Case |
|--------|-------------|------------|----------|
| Redis SETNX | Weak | Low | Cache, non-critical |
| Redlock | Better | Medium | Medium critical |
| ZooKeeper | Strong | High | Critical |
| etcd | Strong | Medium | K8s, critical |

### 1 Minute Recall Block
- Lock = mutual exclusion
- Redis = SETNX + TTL
- Fencing token = stale lock prevent
- ZooKeeper = strong consistency

### 5 Bullet Memory Hooks
1. Lock = one at a time
2. Redis = simple, weak
3. Redlock = multiple Redis
4. Fencing = token prevent stale
5. ZooKeeper = sequential nodes

### Common Interview Trap
**"Redis lock enough?"** — No for critical! Lock expiry problem. Use fencing or ZooKeeper for critical.

---

## 7. Heartbeat Mechanism

### Core Concept
Nodes periodically "I'm alive" signal bhejte hain. No signal = dead assume.

### How It Works
```
Leader: ping... ping... ping...
Follower: pong... pong... (no pong) 
Leader: "Follower dead, remove from cluster"
```

### Heartbeat Interval vs Timeout
```
Interval: How often send (e.g., 100ms)
Timeout: How long wait for response (e.g., 500ms)

Short interval = fast detection, more traffic
Long timeout = slow detection, fewer false positives
```

### Failure Detection — Gossip Protocol
```
Each node tells others: "I think X is dead"
Spread like gossip
Eventually all know
Used in Cassandra, etc.
```

### Real World Analogy — WhatsApp
- "Last seen" = heartbeat
- No "last seen" update = maybe offline
- "Typing..." = frequent heartbeat

### 1 Minute Recall Block
- Heartbeat = I'm alive signal
- Timeout = no response = dead
- Gossip = spread failure info

### 5 Bullet Memory Hooks
1. Heartbeat = periodic alive signal
2. Timeout = failure detection
3. Interval vs timeout tradeoff
4. Gossip = decentralized detection
5. Too aggressive = false positives

---

## 8. Failure Handling

### Types of Failures

#### Crash Failure
```
Node stops. No response. Simple.
Detect: Heartbeat timeout
```

#### Byzantine Failure
```
Node sends wrong/arbitrary responses. Malicious or buggy.
Detect: Hard! Need redundancy, voting
```

#### Network Partition
```
    [A] [B] | [C] [D]
    Group 1 | Group 2
    Can't communicate
    Split brain risk!
```

### Detection
| Method | How | Pros | Cons |
|--------|-----|------|------|
| Heartbeat | Periodic ping | Simple | Network delay = false positive |
| Timeout | No response | Simple | Timeout value tricky |
| Gossip | Spread suspicion | Scalable | Eventually consistent |

### Recovery
| Strategy | How |
|----------|-----|
| Checkpoint | Save state, restore from checkpoint |
| Replay | Replay log from last good state |
| Failover | Switch to replica |
| Retry | Maybe transient, retry |

### 1 Minute Recall Block
- Crash = stop
- Byzantine = wrong
- Partition = split
- Heartbeat = detection

### 5 Bullet Memory Hooks
1. Crash = simple stop
2. Byzantine = wrong response
3. Partition = network split
4. Heartbeat = detect crash
5. Quorum = partition handling

---

## 9. Retry Mechanism

### Simple Retry
```
Request fails → Retry immediately
Problem: Overload the failing service!
```

### Exponential Backoff
```
Attempt 1: Wait 1 sec
Attempt 2: Wait 2 sec
Attempt 3: Wait 4 sec
Attempt 4: Wait 8 sec
...
```

### Jitter (Add Randomness)
```
Without jitter: All clients retry at same time = thundering herd
With jitter: Random delay = spread load

wait = base * 2^attempt + random(0, 1000)
```

### Circuit Breaker + Retry
```
Closed: Normal, requests pass
Open: Failures > threshold, reject immediately (fail fast)
Half-Open: Try one request, success = Closed, fail = Open

Retry when closed. Don't retry when open!
```

**Real World Analogy — Electrical Circuit Breaker**
Ghar mein short circuit = circuit breaker trip = current band
Retry mat karo jab system down hai — fail fast, system ko recover karne do
Half-Open = "ek baar try karke dekho, theek hai kya?"

### State Diagram
```
    [Closed] --too many failures--> [Open]
         ^                              |
         |                              | timeout
         |                              v
         +------- success ------------- [Half-Open]
                         failure
```

### 1 Minute Recall Block
- Simple retry = overload risk
- Exponential backoff = wait longer each time
- Jitter = randomness, avoid thundering herd
- Circuit breaker = fail fast when down

### 5 Bullet Memory Hooks
1. Retry = transient failure handle
2. Backoff = exponential wait
3. Jitter = add randomness
4. Circuit breaker = stop retrying when down
5. Thundering herd = jitter prevents

---

## 10. Backoff Strategy Deep Dive

### Linear Backoff
```
1s, 2s, 3s, 4s, 5s...
Simple but slow for many retries
```

### Exponential Backoff
```
1s, 2s, 4s, 8s, 16s...
cap = 60s (max wait)
Common: base * 2^attempt
```

### Exponential with Jitter
```
Full jitter: sleep(random(0, base * 2^attempt))
Equal jitter: sleep(base * 2^attempt / 2 + random(0, base * 2^attempt / 2))
Decorr jitter: sleep(min(cap, base * 2^attempt + random(0, base)))
```

### AWS/Google Recommended
```
wait = min(cap, base * 2^attempt) + random(0, 1000ms)
```

### Comparison
| Strategy | Aggressiveness | Use Case |
|----------|----------------|----------|
| No backoff | Very high | Never! |
| Linear | Medium | Low contention |
| Exponential | Good | Default choice |
| Exponential + Jitter | Best | Production |

### 1 Minute Recall Block
- Exponential = 2^attempt
- Jitter = random component
- Cap = max wait
- AWS: min(cap, base*2^n) + random

### 5 Bullet Memory Hooks
1. Exponential = double each time
2. Jitter = randomness
3. Cap = don't wait forever
4. Full jitter = 0 to max
5. Production = exponential + jitter

---

## 11. Distributed Transactions

### The Problem
```
Bank A (Mumbai) --transfer 100--> Bank B (Delhi)
Both must succeed or both fail. How?
```

### 2-Phase Commit (2PC)

#### Phase 1: Prepare
```
Coordinator --> All: "Can you commit?"
All --> Coordinator: "Yes" or "No"
```

#### Phase 2: Commit/Abort
```
All said Yes --> Coordinator: "Commit"
Coordinator --> All: "Commit"
Any said No --> Coordinator: "Abort"
Coordinator --> All: "Abort"
```

```
    Coordinator     Participant A    Participant B
         |                |                |
         |--- Prepare --->|                |
         |--- Prepare ------------------>|
         |<-- Yes ------------------------|
         |<-- Yes ------------------------|
         |--- Commit ---->|                |
         |--- Commit -------------------->|
```

### 2PC Problems
- **Blocking**: Coordinator fails after Prepare = participants stuck
- **Single point of failure**: Coordinator
- **Lock holding**: Long locks during prepare

### 3-Phase Commit
Adds "Pre-commit" phase to reduce blocking. Complex, rarely used.

### Saga Pattern (Alternative)
```
Instead of distributed transaction:
Each service has local transaction + compensation

T1: Order Service - Create order
T2: Payment Service - Charge (fails!)
C2: Payment Service - Refund (compensation)
C1: Order Service - Cancel order (compensation)

Choreography: Each service knows next + compensation
Orchestration: Central orchestrator coordinates
```

### Saga vs 2PC
| Aspect | 2PC | Saga |
|--------|-----|------|
| Consistency | Strong | Eventually |
| Blocking | Yes | No |
| Complexity | Medium | High (compensations) |
| Use case | ACID needed | Microservices |

### Saga Types
**Choreography**: No central coordinator. Each service publishes events. Others react.
```
Order Service → OrderCreated event
Payment Service (subscribes) → Charge, publish PaymentDone
Inventory Service (subscribes) → Reserve, publish InventoryReserved
```

**Orchestration**: Central orchestrator tells each service what to do.
```
Orchestrator → Order: Create
Orchestrator → Payment: Charge
Orchestrator → Inventory: Reserve
(If any fails → Orchestrator triggers compensations)
```

### 1 Minute Recall Block
- 2PC = Prepare + Commit/Abort
- 2PC blocking problem
- Saga = local tx + compensation
- Saga = eventual consistency

### 5 Bullet Memory Hooks
1. 2PC = two phases
2. Coordinator = single point
3. Saga = compensation
4. 2PC = blocking
5. Microservices = Saga preferred

### Common Interview Trap
**"2PC vs Saga?"** — 2PC strong consistency but blocking. Saga eventual consistency, non-blocking. Choose based on requirements.

---

## 12. Clock Synchronization

### The Problem
```
Node A: Event at 10:00:00.001
Node B: Event at 10:00:00.002
But A's clock 100ms fast, B's 50ms slow!
Actual order unclear.
```

### NTP (Network Time Protocol)
```
Sync with time servers
Accuracy: milliseconds
Good for: logging, approximate ordering
Not for: distributed consensus, strict ordering
```

### Logical Clocks (Lamport)
```
No physical time. Just sequence numbers.
Event happens → increment counter
Send message → include counter
Receive message → max(local, received) + 1

If A happened before B → timestamp(A) < timestamp(B)
Reverse not true! Same timestamp = concurrent
```

### Vector Clocks
```
Each node has vector: [node1: 2, node2: 1, node3: 3]
Event → increment own counter
Send → include full vector
Receive → merge (max each component)

Can detect: concurrent events (neither before nor after)
```

### Comparison
| Type | Use Case | Ordering |
|------|----------|----------|
| NTP | Real time | Approximate |
| Lamport | Causal order | Before/after |
| Vector | Concurrent detect | Full causal |

### 1 Minute Recall Block
- NTP = physical time sync
- Lamport = logical, causal
- Vector = detect concurrent
- Distributed = don't rely on physical time

### 5 Bullet Memory Hooks
1. NTP = real time
2. Lamport = logical clock
3. Vector = concurrent detection
4. Physical time unreliable
5. Causal ordering possible

---

## 13. Split Brain Problem

### What is Split Brain?
```
    [Partition 1]     |     [Partition 2]
    A, B think       |     C, D think
    they have        |     they have
    leader           |     leader
    
    Two leaders! Both accept writes!
    Data divergence = BAD
```

### How It Happens
- Network partition
- Both sides can't communicate
- Both hold election
- Both get majority (in their partition)
- Two leaders!

### Solutions

#### 1. Quorum
```
5 nodes, need 3 for quorum
Partition: 3-2
Only 3 side can form quorum
2 side cannot = no leader = no writes
```

#### 2. Fencing
```
Leader gets token. Resource checks token.
Stale leader (old token) = rejected
```

#### 3. Odd Number of Nodes
```
3, 5, 7 — never 2-2 split
4 nodes: 2-2 split = both think majority!
5 nodes: 3-2 split = only one has majority
```

#### 4. Witness/Arbiter
```
Third party breaks tie
Cloud witness, etc.
```

### Real World Example
- **Elasticsearch**: Minimum master nodes = (N/2)+1
- **Kafka**: In-sync replicas, unclean leader election
- **MongoDB**: Elections with majority

### 1 Minute Recall Block
- Split brain = two leaders
- Quorum = prevent
- Odd nodes = 3, 5, 7
- Fencing = stale reject

### 5 Bullet Memory Hooks
1. Split brain = two leaders
2. Quorum prevents
3. Odd nodes (3, 5, 7)
4. Fencing token
5. 4 nodes = 2-2 bad

### Common Interview Trap
**"Why odd number of nodes?"** — Even (4) = 2-2 partition, both can claim majority. Odd (5) = 3-2, only one side has majority.

---

## 14. Interview Questions

### Quick Recall
1. **Distributed system challenge?** — Network, clock, partial failure
2. **Consensus?** — All agree. Paxos/Raft.
3. **Raft?** — Leader, log replication, quorum
4. **Lock expiry problem?** — Fencing token
5. **2PC vs Saga?** — Strong vs eventual, blocking vs not
6. **Split brain?** — Quorum, odd nodes
7. **Heartbeat?** — Alive signal, timeout = dead
8. **Backoff?** — Exponential + jitter

### Common Questions
- Design distributed lock
- How does Raft work?
- What is split brain? How prevent?
- 2PC vs Saga when to use?
- Why exponential backoff with jitter?
- How does ZooKeeper leader election work?

### 5 Bullet Memory Hooks (Full Topic)
1. Distributed = multiple machines, one system
2. Consensus = Raft, Paxos
3. Lock = Redis weak, ZooKeeper strong
4. 2PC blocking, Saga compensation
5. Split brain = quorum + odd nodes

---

## Appendix: Quick Reference Tables

### Consensus Algorithms Comparison
| Algorithm | Leader? | Complexity | Used In |
|-----------|---------|------------|---------|
| Paxos | No (multi-leader) | High | Chubby, early systems |
| Raft | Yes | Medium | etcd, Consul, TiKV |
| Zab | Yes | Medium | ZooKeeper |
| Viewstamped | Yes | Medium | Research |

### Lock Implementation Comparison
| Implementation | Consistency | Latency | When to Use |
|----------------|-------------|---------|-------------|
| Redis SETNX | Weak | Low | Cache, non-critical |
| Redlock | Medium | Low | Medium critical |
| etcd | Strong | Medium | K8s, distributed |
| ZooKeeper | Strong | Medium | Coordination |

### Failure Type Handling
| Failure Type | Detection | Recovery |
|--------------|------------|----------|
| Crash | Heartbeat timeout | Failover, restart |
| Network partition | Quorum loss | Wait, don't split |
| Byzantine | Voting, redundancy | Isolate, replace |
| Slow | Timeout | Circuit breaker |

### Common Interview Patterns
- **Distributed lock** → Redis SETNX, Redlock, ZooKeeper
- **Leader election** → Raft, ZooKeeper ephemeral
- **Consensus** → Raft (explain), Paxos (mention)
- **Transactions** → 2PC (blocking), Saga (compensation)
- **Split brain** → Quorum, odd nodes, fencing
