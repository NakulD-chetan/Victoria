# Jobs Tab & Actions — The "Action → Job" Rule

Spark UI ka entry point Jobs tab hai. Aur Jobs tab ka pehla concept ek hi line ka hai: **"Ek action ek job banata hai"**. But sirf yeh aadhi sachayi hai. Kuch actions multiple jobs banate hain (jaise `show()`), aur kuch silently extra jobs add kar dete hain (jaise AQE-on `groupBy`). Yeh pattern us pure rulebook ko fix karta hai.

**DSA Analogy**: Lazy iterator + materialize call. Tum jab tak `.next()` (action) nahi calote, kuch nahi chalta. Jaise ek call hua, ek "execution unit" submit ho gaya.

---

## Core Idea (2 Lines)

Spark **lazy** hai — transformations sirf logical plan banate hain. Ek **action** call karte hi DAGScheduler `runJob()` invoke karta hai, jo Jobs tab mein ek naya row banata hai. **Most actions create exactly 1 job; show/take/limit can create multiple.**

---

## Syntax / Mental Template

```
df = read(...).select(...).filter(...).groupBy(...).agg(...)
#  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#  Pure transformations -> ZERO jobs in UI so far.

df.count()       # action -> 1 job
df.write.parquet(...)   # action -> 1 job
df.show()        # action -> 1..K jobs (Pattern 03)
```

---

## The Action Catalog (What Triggers a Job)

Spark mein actions ko 3 buckets mein samjho:

### 1. "Pure" Actions — always 1 job

| Action                  | Job Count | Notes                                                |
|-------------------------|-----------|------------------------------------------------------|
| `count()`               | 1         | Final aggregate (1 task in last stage)               |
| `collect()`             | 1         | Pulls all partitions to driver                       |
| `first()` / `head()`    | 1*        | *but `head(n)` ≥ 2 may use executeTake → multi-job   |
| `reduce(...)`           | 1         | Tree-reduce to driver                                |
| `aggregate(...)`        | 1         | Custom seq+combine                                   |
| `foreach(...)` / `foreachPartition(...)` | 1 | Side-effect only                              |
| `write.<fmt>(...)`      | 1         | Distributed write                                    |
| `saveAsTable(...)`      | 1         | Same as write                                        |
| `toLocalIterator()`     | 1 per partition iterated | Streams partitions one by one         |

### 2. "Iterative" Actions — 1 to log4(P)+1 jobs

| Action               | Why Multiple?                                                       |
|----------------------|---------------------------------------------------------------------|
| `show()` / `show(n)`  | Calls `head(n+1)` → `executeTake(n+1)` loop                         |
| `take(n)`             | Same `executeTake` loop                                             |
| `head(n)` (n > 1)    | Same                                                                |
| `tail(n)`             | Reverse `executeTake`                                               |
| `limit(n).collect()` | `CollectLimitExec` → `executeTake`                                  |

> Pattern 03 covers exactly *why* these create multiple jobs.

### 3. "Hidden" Actions — sneaky jobs you didn't ask for

| Source                                | Hidden Job                                          |
|---------------------------------------|-----------------------------------------------------|
| `createDataFrame(big_python_list)`    | Schema inference may scan rows → 1 extra job        |
| `toPandas()`                          | Triggers `collect()` internally → 1 job             |
| `printSchema()` on streaming DF       | None (metadata only)                                 |
| `df.rdd` access                       | None — but next RDD action triggers a job           |
| `df.repartition(K)` *with AQE on*     | AQE may submit extra job to inspect map output      |
| `df.join(...)` *with AQE on*          | AQE re-optimizes after each shuffle → +1 job each   |
| `df.write` with `partitionBy`         | May add a sort job if file-level ordering kicks in  |

**Rule of thumb:** `df.show()` mein 3 jobs, `df.collect()` mein 1, but `groupBy + show` AQE-on mein 4–5? — that's AQE.

---

## What Each Column in the Jobs Tab Tells You

```
+----+-------------------------------+-----------+--------+----------------------+
| Id | Description                   | Duration  | Stages | Tasks (succ/total)   |
+----+-------------------------------+-----------+--------+----------------------+
|  0 | count at app.py:30            |    44 s   |  3 / 3 |       23 / 23        |
|  1 | showString at app.py:51 (i=1) |   2.0 s   |  2 / 2 (1 skipped) |  7 / 23 (16 skipped) |
|  2 | showString at app.py:51 (i=2) |    25 ms  |  1 / 3 (2 skipped) |  4 / 26 (22 skipped) |
|  3 | showString at app.py:51 (i=3) |    33 ms  |  1 / 3 (2 skipped) |  3 / 25 (22 skipped) |
|  4 | collect at app.py:54          |   1.0 s   |  2 / 3 (1 skipped) | 14 / 30 (16 skipped) |
+----+-------------------------------+-----------+--------+----------------------+
```

| Column      | Read As                                                       | Pitfall                                               |
|-------------|---------------------------------------------------------------|-------------------------------------------------------|
| Job Id      | "Submit order"                                                | Not the *finish* order; jobs can overlap              |
| Description | `<scala_action_name> at <file>:<line>` (`saveAsTable`, `count`, `showString`, `runJob`) | Multiple jobs from the same line are normal (Pattern 03) |
| Duration    | Wall-clock from submit to last task done                      | Includes scheduling delay, not just compute           |
| Stages      | `active / total (skipped)`                                    | "skipped" stages are *reused* (Pattern 05), not failed |
| Tasks       | `succeeded / total (skipped)`                                 | Failed retried tasks count once each                  |

> **Always read the parentheses.** A job with `2 / 3 (1 skipped)` is doing 2 stages of work — the 3rd already had its output cached/reused.

---

## The Mental Trace — Code → Jobs

```python
# Line 1
df = spark.read.parquet("s3://...")          # transformation
# Line 2
df2 = df.filter(col("amount") > 100)          # transformation
# Line 3
df3 = df2.groupBy("country").sum("amount")    # transformation
# Line 4
df3.cache()                                   # transformation (lazy!)
# Line 5
df3.count()                                   # ACTION -> Job 0
# Line 6
df3.show(20)                                  # ACTION -> Jobs 1..K (executeTake)
# Line 7
df3.write.parquet("out/")                     # ACTION -> Job K+1
```

UI shows:
```
Job 0  count at line:5
Job 1  showString at line:6 (iter 1)
Job 2  showString at line:6 (iter 2)
...
Job K  parquet at line:7
```

---

## "Description" — How to Read the Action Label

| Label in UI                         | Maps to Code                                  |
|-------------------------------------|-----------------------------------------------|
| `count at <file>:<line>`            | `df.count()`                                  |
| `collect at <file>:<line>`          | `df.collect()`                                |
| `showString at <file>:<line>`       | `df.show()` (any iteration of executeTake)    |
| `take at <file>:<line>`             | `df.take(n)`                                  |
| `parquet at <file>:<line>`          | `df.write.parquet(...)`                       |
| `save at <file>:<line>`             | `df.write.format(...).save(...)`              |
| `runJob at ThreadPoolExecutor.java` | A driver-side internal job (e.g. AQE planning)|
| `Listing leaf files at ...`         | File listing for `read` (catalog op)          |

> The label always references the *Scala* action method (e.g. `showString`, not `show`) because the UI is rendered by the JVM driver.

---

## How Spark Schedules a Job (One-Page Mental Model)

```
df.count()
   |
   v
[ DataFrame API ]                        Python side (Py4J calls)
   |
   v
[ Logical Plan -> Optimized Plan ]       Catalyst
   |
   v
[ Physical Plan ]                        Code-gen + chosen operators
   |
   v
[ DAGScheduler.runJob(rdd, partitions) ] Job created -> Jobs tab row
   |
   v
[ DAGScheduler splits into Stages ]       At every shuffle boundary
   |
   v
[ TaskScheduler launches Tasks ]          One task per output partition per stage
   |
   v
[ Executors run tasks ]                   Reports progress -> UI updates live
```

> **"Jobs tab" is the very top of this funnel.** Pattern 04 explains the stage split.

---

## Why "Description" Sometimes Says `runJob at ThreadPoolExecutor.java`

When AQE re-optimizes mid-execution, it submits internal jobs to read map output statistics from already-finished stages. The Description points to a JVM thread-pool, not your script. These look like:

```
Job 5  runJob at ThreadPoolExecutor.java:1149
       Tasks: 8/8     Skipped: 8/8
```

Treat them as bookkeeping — they show 0 work done because all stages are skipped.

---

## Common "How Many Jobs Will This Code Make?" Mistakes

| Code                                                     | Naive Guess | Actual                                            |
|----------------------------------------------------------|-------------|---------------------------------------------------|
| `df.count() + df.show()`                                 | 2           | 2 to 4 (show may create up to log4(P)+1 jobs)    |
| `df.write.parquet("out/")`                               | 1           | 1 (sometimes 2 if AQE inspects map output)       |
| `df.cache(); df.count(); df.count()`                     | 2           | 2 — 2nd count reads cache (same job count, faster)|
| `df.toPandas()`                                          | 0           | 1 (collect is hidden inside)                     |
| `spark.createDataFrame(python_list).count()`             | 1           | 1 or 2 (Python parallelize may submit pre-job)   |
| `df.select(...)` (no action)                             | 0           | 0 — pure transformation                          |
| `df.cache()` (no action after)                           | 0           | 0 — cache is lazy                                |

---

## Common Mistakes (Reading Jobs Tab)

| Mistake                                                | Why It Misleads                                                | Fix                                                                  |
|--------------------------------------------------------|----------------------------------------------------------------|----------------------------------------------------------------------|
| Counting "Jobs" = "actions in code"                    | `show()` makes ≥1 jobs; AQE adds extras                        | Read the *Description* — multiple lines for one show is normal       |
| Comparing job durations to estimate cost               | Skipped stages make Job 2 finish in 25ms                       | Look at *active* stages/tasks, not total                             |
| Treating "Stage 2 of Job 1" same as "Stage 2 of Job 2" | Stage IDs are *application-wide*, but reused outputs skip      | Always pair (Job, Stage) when discussing                             |
| Optimizing by reducing job count blindly               | Sometimes 5 small jobs are faster than 1 huge one (e.g. show)  | Optimize *total stage time*, not job count                           |
| Killing app right after action returns in Python        | Driver may still be flushing UI events                         | Add `input("Press ENTER...")` while debugging                        |

---

## When To Look at Jobs Tab vs Skip It

| Situation                                | Look at Jobs Tab? |
|------------------------------------------|-------------------|
| First-time debugging                     | Yes, always       |
| Already know slow line of code           | Skip — go directly to Stages of that job |
| Validating action count for unit tests   | Yes               |
| Memory/GC issue                          | No — Executors tab |
| Plan-level optimization                  | No — SQL tab      |

---

## Real-World Use Cases

```
1. "Why is my notebook slow?"
   -> Jobs tab: spot the long row.

2. "I removed a .show() and pipeline is 10s faster"
   -> Confirm in Jobs tab: 3 showString rows are gone.

3. "Spark UI shows jobs from a line I deleted"
   -> Stale History Server entry; refresh.

4. "Production ETL has 2x jobs after upgrade"
   -> Likely AQE got enabled by default in Spark 3.2+.

5. "I called .count() once but see 4 count entries"
   -> Caching/persist may add validation jobs;
      check if .checkpoint() is in the lineage.
```

---

## Worked Example — The 5-Job Reference Run

For the script in `00_Index.md`:

```python
df_filtered.cache()
df_filtered.count()                # Job 0  -- 1 job (count)
df_final.show()                    # Jobs 1, 2, 3  -- 3 jobs (executeTake loop)
df_final.collect()                 # Job 4  -- 1 job (collect)
```

Total **5 jobs**. Memorize this baseline — every later pattern explains a piece of it:

| Job | Trigger     | Why That Many       | Pattern Reference |
|-----|-------------|---------------------|--------------------|
| 0   | `count()`   | 1 (full agg)        | This pattern        |
| 1   | `show()`    | iter 1 of executeTake | Pattern 03        |
| 2   | `show()`    | iter 2              | Pattern 03         |
| 3   | `show()`    | iter 3              | Pattern 03         |
| 4   | `collect()` | 1 (full scan)       | This pattern        |

---

## Key Takeaway

> Jobs tab ka rule simple hai: **action submitted = job created**. Lekin `show / take / limit` ka executeTake loop multiple jobs bana sakta hai, aur AQE silently bookkeeping jobs add karta hai. Jab tak yeh exception list yaad hai, tum kabhi UI dekhke confused nahi hoge.
