# Window Functions

Window functions let you compute a value for every row using a "window" of related rows — without collapsing the result set like GROUP BY does. You keep all rows AND get aggregate/ranking/offset values.

**DSA Analogy**: Sliding Window on arrays — you slide a frame across sorted data and compute something for each position.

---

## Core Idea (2 Lines)

A window function applies a calculation **across a set of rows related to the current row**. Unlike GROUP BY, it does NOT reduce the number of rows — every original row stays, with the computed column added alongside.

---

## Syntax Template

```sql
function_name(args) OVER (
    [PARTITION BY col1, col2]      -- split into groups (like GROUP BY, but rows stay)
    [ORDER BY col3 [ASC|DESC]]     -- define row ordering within each partition
    [frame_clause]                 -- which rows in the partition to include
)
```

**Three parts of the OVER clause:**

| Part          | Purpose                              | Optional? |
|---------------|--------------------------------------|-----------|
| PARTITION BY  | Divide rows into independent groups  | Yes — omit = entire table is one partition |
| ORDER BY      | Order rows within each partition     | Required for ranking/offset functions |
| Frame clause  | Define the "window" of rows          | Yes — defaults depend on function |

---

## The 4 Families of Window Functions

### 1. Ranking Functions

```
ROW_NUMBER()    → 1, 2, 3, 4, 5        (always unique, no gaps)
RANK()          → 1, 2, 2, 4, 5        (ties get same rank, gaps after)
DENSE_RANK()    → 1, 2, 2, 3, 4        (ties get same rank, NO gaps)
NTILE(n)        → 1, 1, 2, 2, 3        (divide into n buckets)
```

```sql
SELECT name, dept, salary,
       ROW_NUMBER() OVER (PARTITION BY dept ORDER BY salary DESC) AS rn,
       RANK()       OVER (PARTITION BY dept ORDER BY salary DESC) AS rnk,
       DENSE_RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS drnk
FROM employees;
```

**Result for Engineering dept (salaries: 120k, 100k, 100k, 80k):**

```
name     | dept | salary | rn | rnk | drnk
─────────┼──────┼────────┼────┼─────┼──────
Alice    | Eng  | 120000 |  1 |   1 |    1
Bob      | Eng  | 100000 |  2 |   2 |    2
Charlie  | Eng  | 100000 |  3 |   2 |    2    ← tie handling differs
Diana    | Eng  |  80000 |  4 |   4 |    3    ← RANK skips 3, DENSE_RANK doesn't
```

### 2. Aggregate Window Functions

Same functions you know from GROUP BY, but applied over the window frame:

```sql
SELECT name, dept, salary,
       SUM(salary)   OVER (PARTITION BY dept) AS dept_total,
       AVG(salary)   OVER (PARTITION BY dept) AS dept_avg,
       COUNT(*)      OVER (PARTITION BY dept) AS dept_count,
       MAX(salary)   OVER (PARTITION BY dept) AS dept_max
FROM employees;
```

Every row keeps its own data AND gets the aggregate values. No GROUP BY needed.

### 3. Offset Functions (LAG / LEAD)

Access the **previous row** or **next row** without a self-join:

```sql
LAG(column, offset, default)      -- look BACK by `offset` rows
LEAD(column, offset, default)     -- look AHEAD by `offset` rows
FIRST_VALUE(column)               -- first row in the window frame
LAST_VALUE(column)                -- last row in the window frame
NTH_VALUE(column, n)              -- nth row in the window frame
```

```sql
SELECT order_date, amount,
       LAG(amount, 1, 0)  OVER (ORDER BY order_date) AS prev_amount,
       LEAD(amount, 1, 0) OVER (ORDER BY order_date) AS next_amount,
       amount - LAG(amount, 1, 0) OVER (ORDER BY order_date) AS day_over_day_change
FROM orders;
```

### 4. Distribution Functions

```sql
PERCENT_RANK()    -- relative rank as a percentage (0 to 1)
CUME_DIST()       -- cumulative distribution (fraction of rows <= current)
```

---

## How Window Functions Execute (Mental Model)

```
Step 1:  FROM / JOIN / WHERE execute first → produces a result set
Step 2:  PARTITION BY splits result set into independent groups
Step 3:  ORDER BY sorts rows within each partition
Step 4:  Frame clause defines which rows the function "sees"
Step 5:  Function computes once PER ROW using its visible frame
Step 6:  Result is added as a new column — original rows untouched
```

```
  Full Result Set
  ┌────────────────────────────────────────┐
  │  Partition: dept = 'Engineering'       │
  │  ┌──────┬────────┬─────────────────┐   │
  │  │ row1 │ row2   │ row3            │   │
  │  │      │ ← current row            │   │
  │  │      │ window: [row1..row2]      │   │
  │  └──────┴────────┴─────────────────┘   │
  │                                        │
  │  Partition: dept = 'Sales'             │
  │  ┌──────┬────────┬─────────────────┐   │
  │  │ row1 │ row2   │ row3            │   │
  │  └──────┴────────┴─────────────────┘   │
  └────────────────────────────────────────┘
```

---

## Window Frame Clause (Advanced)

The frame clause controls exactly which rows the function sees around the current row.

```sql
{ ROWS | RANGE | GROUPS } BETWEEN
    { UNBOUNDED PRECEDING | n PRECEDING | CURRENT ROW }
    AND
    { UNBOUNDED FOLLOWING | n FOLLOWING | CURRENT ROW }
```

| Frame Type | Unit        | What It Means                              |
|------------|-------------|--------------------------------------------|
| ROWS       | Physical    | Exact row count before/after current        |
| RANGE      | Logical     | All rows with values within a range         |
| GROUPS     | Group count | Count of distinct ORDER BY value groups     |

**Default frame rules (critical to know):**

| Scenario                    | Default Frame                                    |
|-----------------------------|--------------------------------------------------|
| ORDER BY specified          | RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW |
| No ORDER BY                 | RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING |

```sql
-- Rolling 3-day average
SELECT order_date, amount,
       AVG(amount) OVER (
           ORDER BY order_date
           ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
       ) AS rolling_3day_avg
FROM orders;

-- Expanding window (running total)
SELECT order_date, amount,
       SUM(amount) OVER (
           ORDER BY order_date
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS running_total
FROM orders;
```

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Using window function in WHERE | Window functions run AFTER WHERE | Wrap in a subquery/CTE, filter on the outer query |
| Forgetting ORDER BY in RANK | Results are nondeterministic | Always add ORDER BY for ranking functions |
| LAST_VALUE with default frame | Default frame ends at CURRENT ROW, not the end | Add `ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING` |
| Not handling ties in ROW_NUMBER | Arbitrary tiebreaker | Add a secondary ORDER BY column for determinism |
| Confusing ROWS vs RANGE | RANGE includes ties, ROWS is physical | Use ROWS for exact rolling calculations |

---

## When to Use vs When NOT to Use

| Use Window Functions When | Use GROUP BY Instead When |
|---------------------------|---------------------------|
| You need per-row detail + aggregate | You only need the aggregate summary |
| Rankings, row numbers, percentiles | Simple counts, sums per group |
| Comparing current row to previous/next | No row-to-row comparison needed |
| Running totals, moving averages | Single total per group |

---

## Real-World Use Cases

```
Ranking employees by salary within each department
Calculating month-over-month revenue growth (LAG)
Finding the 2nd highest salary per department
Running total of sales over time
Identifying consecutive login streaks (combined with Gaps & Islands)
Percentile ranking for exam scores
Rolling 7-day average of daily active users
```

---

## Key Takeaway

> Window functions are GROUP BY without the collapse. You keep every row and get aggregate/ranking/offset values as new columns. The OVER clause defines the partition (group), order (sort), and frame (which rows the function sees). Master ROW_NUMBER, RANK, LAG/LEAD, and SUM() OVER() — they cover 90% of interview problems.
