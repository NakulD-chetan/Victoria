# SQL Tab & Physical Plans — Reading What Catalyst Did

SQL tab tumhe Catalyst optimizer ka **final output** dikhata hai — yaani jo plan actually executors pe chala. Yeh wahi tab hai jaha tum verify karte ho ki tumhe broadcast join mila ya nahi, predicate pushdown hua ya nahi, AQE ne kya rewrite kiya.

**DSA Analogy**: Compiler explorer (godbolt.org) for Spark queries. Source code → optimized AST → physical operators → executors.

---

## Core Idea (2 Lines)

SQL tab har triggered query ka **operator-level DAG** dikhata hai with row counts and timings at each node. Reading this tab = reading Catalyst's homework.

---

## Where to Find It

```
http://<driver>:4040/SQL/
```

Each entry is one **query execution** (similar to a job, but linked to SQL/DataFrame APIs).
RDD-only operations don't appear here — only DataFrame/Dataset/SQL queries do.

```
| ID | Description                | Submitted     | Duration | Jobs       | Stages     |
| 0  | count at app.py:30         | 14:12:01      |   44s    | [0]         | [S0,S1,S2] |
| 1  | showString at app.py:51 (1)| 14:12:46      |    2s    | [1]         | [S3,S4]    |
| 2  | showString at app.py:51 (2)| 14:12:48      |   25ms   | [2]         | [S5]       |
```

> Click any row to open its **physical plan tree** with metrics inline.

---

## Layered View: Logical → Optimized → Physical

```
+----------------------+     Catalyst optimizes      +----------------------+
| Parsed Logical Plan  |  ---------------------->    | Optimized Logical    |
| (your code as AST)   |                              | Plan (rules applied)|
+----------------------+                              +----------------------+
                                                                |
                                                                v
+----------------------+   choose physical operators +----------------------+
| Physical Plan        |  <----------------------    | Spark Strategies     |
| (tree of nodes UI    |                              | (e.g. join strategy)|
| renders)             |                              +----------------------+
+----------------------+
```

You can dump these via:
```python
df.explain(mode="formatted")
df.explain(mode="extended")     # all 4 layers (parsed/analyzed/optimized/physical)
df.explain(mode="cost")         # with cost-based stats
df.explain(mode="codegen")      # the generated Java code
```

But the **SQL tab gives the same info visually** + per-operator metrics that `explain()` cannot show (rows produced at runtime, time, shuffle bytes).

---

## The 12 Operators You'll See 90% of the Time

### Source / Scan

| Operator                | Meaning                                           | What to Watch                                       |
|-------------------------|---------------------------------------------------|-----------------------------------------------------|
| `Scan parquet/csv/orc/json` | Reads files from disk                          | Row count vs file row count → predicate pushdown hint |
| `Scan ExistingRDD`       | createDataFrame parallelize                       | Common in tests / `range`                           |
| `InMemoryTableScan`      | Reads from cache                                  | Confirms cache hit                                  |

### Projection / Filter

| Operator         | Meaning                                  | Watch For                                     |
|------------------|------------------------------------------|-----------------------------------------------|
| `Project`        | SELECT columns                           | Column pruning happening?                     |
| `Filter`         | WHERE clause                             | Pushed below Scan? (look at `PushedFilters`)  |
| `WholeStageCodegen` | Fused operator block (Tungsten)        | Good — means JIT-friendly                     |

### Aggregation

| Operator              | Meaning                                  | Watch For                                       |
|-----------------------|------------------------------------------|-------------------------------------------------|
| `HashAggregate (partial)` | Partial aggregate per partition       | Always paired with a final aggregate            |
| `HashAggregate (final)`   | Final aggregate after shuffle         | Single instance per group key                   |
| `ObjectHashAggregate`     | When agg state isn't fixed-size       | Slower than HashAggregate                       |
| `SortAggregate`           | Falls back when codegen disabled      | Avoid by enabling codegen                       |

### Joins

| Operator                | Meaning                                              | Speed                |
|-------------------------|------------------------------------------------------|----------------------|
| `BroadcastHashJoin`     | Small side broadcast; no shuffle                     | Fastest              |
| `BroadcastNestedLoopJoin` | Cartesian / non-equi-join with broadcast           | Slow but unavoidable |
| `ShuffledHashJoin`      | Both shuffled; no sort (needs hash table on one side)| Medium               |
| `SortMergeJoin`         | Both shuffled, sorted, merged                        | Default for big-big  |
| `CartesianProduct`      | Full cross-join                                      | Very expensive       |

### Shuffle / Exchange

| Operator         | Meaning                                                       |
|------------------|---------------------------------------------------------------|
| `Exchange`       | A shuffle (the bytes-moving step). Always = stage boundary.  |
| `ReusedExchange` | A shuffle whose output was already produced by another query  |
| `BroadcastExchange` | Broadcasts a small side to all executors                  |
| `AQEShuffleRead` | AQE-coalesced shuffle read (post-AQE)                          |

### Sort / Limit

| Operator         | Meaning                                  |
|------------------|------------------------------------------|
| `Sort`           | Full sort (ORDER BY)                     |
| `LocalLimit`     | Limit per partition (cheap)              |
| `GlobalLimit`    | Final limit after shuffle                |
| `CollectLimit`   | The op behind `executeTake`              |

---

## Reading a Plan Tree Top-Down

```
+--------------------------------------------+
| HashAggregate(final, sum(value))    rows: 1 |
|     time: 50 ms                              |
+----------------+---------------------------+
                 |
+----------------v---------------------------+
| Exchange (single partition)         rows: 8|
|     output rows: 8    data size: 256 B      |
|     time: 2.5 s                             |  <-- shuffle, expensive bit
+----------------+---------------------------+
                 |
+----------------v---------------------------+
| HashAggregate(partial, sum(value))  rows: 8|
|     time: 100 ms                             |
+----------------+---------------------------+
                 |
+----------------v---------------------------+
| Project [value]                     rows: 1.6M
+----------------+---------------------------+
                 |
+----------------v---------------------------+
| Filter (value > 200)                 rows: 1.6M
|     PushedFilters: [GreaterThan(value,200)] |
+----------------+---------------------------+
                 |
+----------------v---------------------------+
| InMemoryTableScan (df_filtered)     rows: 1.6M
+--------------------------------------------+
```

**Read top-down or bottom-up — both work. Most engineers prefer bottom-up to follow data flow.**

### What to Read at Each Node

1. **Operator name** — what's happening
2. **Output rows** — how many rows leaving this node
3. **Time** — how long this op took (cumulative for fused codegen blocks)
4. **Data size** (for Exchange) — bytes moved
5. **PushedFilters / OutputAttributes** — pruning evidence

---

## What "WholeStageCodegen (n)" Means

A *box* in the plan tree containing several operators is a **WholeStageCodegen** group — Spark fuses them into one Java function via Tungsten. Inside the group, no per-operator overhead.

```
+-- WholeStageCodegen (1) ----------------------+
|   HashAggregate(partial)                       |
|   |                                            |
|   Filter                                       |
|   |                                            |
|   Scan parquet                                 |
+-----------------------------------------------+
```

> If a node is *outside* any WholeStageCodegen box, it's slower (interpreted). Common reasons:
> - UDFs not codegen-friendly (Python UDFs especially)
> - Large number of expressions hits the codegen size limit
> - Explicitly disabled via config

---

## Detecting Common Optimizations in the SQL Tab

### Predicate Pushdown ✓

```
Scan parquet [a, b, c]
  PushedFilters: [GreaterThan(a, 100)]
  ReadSchema: ...
```
> The filter ran *inside* the Parquet reader. Skip rows never even loaded into Spark.

### Column Pruning ✓

```
ReadSchema: struct<a:int,b:string>     -- only 2 of 10 columns selected
```
> Only the columns actually needed reach Spark.

### Broadcast Join Chosen ✓

```
BroadcastHashJoin
+-- BroadcastExchange [HashedRelation(...)]
|   +-- Project [k, v]
|       +-- Scan parquet (small_table)
+-- Project [k, ...]
    +-- Scan parquet (big_table)
```

### AQE Coalesce ✓

```
AQEShuffleRead [coalesced, 8 -> 4]
```
> AQE merged 8 shuffle output partitions into 4 because each was small.

### AQE Skew Handling ✓

```
AQEShuffleRead [skewed]
```
> AQE detected a skewed partition and split it.

### Cache Hit ✓

```
InMemoryTableScan(df_filtered)
```

### Reused Shuffle ✓

```
ReusedExchange (Exchange hashpartitioning(k, 8))
```

---

## How `Exchange` Reveals the Shuffle Type

```
Exchange hashpartitioning(k#10, 8)         -- groupBy / join (default)
Exchange rangepartitioning(score#11, 8)    -- orderBy
Exchange RoundRobinPartitioning(8)         -- df.repartition(8) without column
Exchange singlePartition                   -- final reduce step
BroadcastExchange HashedRelationBroadcastMode -- broadcast join
```

---

## SQL Tab vs Stages Tab — When to Use Each

| Question                                  | Best Tab     |
|-------------------------------------------|---------------|
| "Did Catalyst pick broadcast join?"       | SQL          |
| "Why is one task very slow?"              | Stages       |
| "Is filter pushed to Parquet?"            | SQL          |
| "Which executor failed?"                  | Executors    |
| "How big was the shuffle?"                | Stages (header) or SQL (Exchange node) |
| "Did AQE rewrite my plan?"                | SQL          |

---

## Worked Example — `count()` on Cached + Repartitioned df

For Job 0 of the reference run (count after cache + repartition + filter):

```
Plan (bottom-up):
1. Scan ExistingRDD                 -> 1.6M rows (createDataFrame parallelize)
2. Project (withColumns)             -> 1.6M
3. Exchange hashpartitioning(category, 6)   <-- Stage boundary 1
4. Filter (value > 200)              -> 800K
5. InMemoryRelation (cache materialize on this side)
6. HashAggregate(partial, count(*))  -> 6 rows
7. Exchange singlePartition          <-- Stage boundary 2
8. HashAggregate(final, count(*))    -> 1 row
```

→ 2 Exchanges → 3 stages → matches the (16, 6, 1) task split from Pattern 04.

---

## Reading SQL Tab Numbers Correctly

| Metric on Operator | What It Counts                                                        |
|---------------------|-----------------------------------------------------------------------|
| number of output rows | Rows produced after this operator                                   |
| spill size          | Bytes spilled to disk during this operator's processing                |
| time total          | Sum of time across all tasks for this operator                        |
| data size           | Bytes processed (for shuffle / scan)                                   |
| peak memory         | Max memory used by any task at this operator                          |

> The **input** rows of an operator = its child's *output* rows.

---

## Common Mistakes

| Mistake                                                | Why                                                           | Fix                                                                  |
|--------------------------------------------------------|---------------------------------------------------------------|----------------------------------------------------------------------|
| Reading the plan top-down expecting source first       | Plans are rendered top-down (action at top, scan at bottom)   | Read bottom-up to follow data flow                                   |
| Believing operator order = run order                   | Inside WholeStageCodegen, all operators fuse                  | Treat the codegen box as one unit                                    |
| Ignoring `PushedFilters: []`                          | Means no predicate pushdown happened                          | Investigate — maybe non-pushdown-able function or wrong format       |
| Counting "data size" of `Exchange` as input            | It's the *shuffle* size, not source size                      | Check the Scan operator for source size                              |
| Treating `BroadcastExchange` as a cost-free shuffle    | Driver memory pressure: large broadcast = bad                 | Watch broadcast threshold (`autoBroadcastJoinThreshold`)             |
| Expecting cache to show as `InMemoryTableScan`         | Yes, but only when cached at *that* level of the plan         | If cache is mid-plan, only that subtree is `InMemoryTableScan`       |

---

## Configs That Affect SQL Tab Plan Selection

| Config                                            | Effect                                                            |
|---------------------------------------------------|-------------------------------------------------------------------|
| `spark.sql.autoBroadcastJoinThreshold`            | Tables ≤ this size become BroadcastHashJoin (default 10 MB)      |
| `spark.sql.adaptive.enabled`                      | Turns AQE on; you'll see AQE* operators                          |
| `spark.sql.adaptive.coalescePartitions.enabled`   | AQE coalesces small post-shuffle partitions                      |
| `spark.sql.adaptive.skewJoin.enabled`             | AQE splits skewed partitions in joins                            |
| `spark.sql.codegen.wholeStage`                    | Default true; enables WholeStageCodegen                          |
| `spark.sql.cbo.enabled`                           | Cost-based optimizer (uses table stats for join reorder)         |
| `spark.sql.statistics.histogram.enabled`           | More accurate row-count estimates                                |

---

## "Plan Looks Bad" — Red Flags Checklist

```
[ ] SortMergeJoin where one side is < 10 MB
        -> Should be BroadcastHashJoin. Add hint or increase threshold.
[ ] Exchange with rows == source rows
        -> Whole input being reshuffled. Check repartition() calls.
[ ] PushedFilters: [] on a filter you wrote
        -> Filter not pushed; rewrite (e.g. avoid UDFs in filter).
[ ] No WholeStageCodegen anywhere
        -> Codegen disabled or hit size limit.
[ ] Multiple back-to-back Exchanges
        -> Catalyst couldn't combine them. Investigate.
[ ] BroadcastExchange with size > 100 MB
        -> Risky; driver may OOM. Lower threshold or rewrite.
[ ] CartesianProduct
        -> You wrote a non-equi join or forgot the join condition.
```

---

## Real-World Use Cases

```
1. "My groupBy is slow"
   - SQL tab -> Exchange node shows huge data size + time
   - Fix: pre-aggregate with map-side combine, or use approx_count_distinct

2. "Join is using SortMerge but my dim table is small"
   - Add broadcast(dim) hint or raise autoBroadcastJoinThreshold

3. "I added .filter but UI scans full file"
   - PushedFilters empty; rewrite filter to use pushdown-able predicates

4. "AQE seems to add jobs but no actual rewrite"
   - Plan still shows Exchange instead of AQEShuffleRead
   - Check spark.sql.adaptive.coalescePartitions.enabled

5. "df.count() is slower than expected"
   - SQL tab shows full Project + Filter + Aggregate, not pushed
   - Use df.select(lit(1)).count() to skip projection cost
```

---

## Cross-References

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| Stage boundaries and Exchange operators            | 04      |
| ReusedExchange and skipped stages                   | 05      |
| Why broadcast joins skip shuffle                    | 04      |
| Detecting AQE in jobs                               | 02      |

---

## Key Takeaway

> SQL tab is your **plan inspector**. Read it bottom-up: Scan → Filter → Project → Aggregate → Exchange → Final.
> Exchange = shuffle = stage boundary. BroadcastHashJoin > SortMergeJoin (when applicable). PushedFilters tell you predicate pushdown works.
> Once you can sketch the plan from the code (and predict whether it will be Broadcast or SortMerge), debugging Spark feels like reading compiled assembly.
