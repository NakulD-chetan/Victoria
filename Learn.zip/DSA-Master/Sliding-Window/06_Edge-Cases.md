# Sliding Window — Edge Cases

> **The difference between "Almost Hired" and "Hired" at FAANG is edge case handling. These are the cases that break naive implementations.**

---

## Edge Case 1: Empty Input

### Scenario
```
arr = [], k = 3
```

### What Breaks
- `sum(arr[:k])` returns 0 (misleading, not error)
- Sliding logic never executes but may return uninitialized values
- String version: `s = ""` — any window operation on empty string

### How to Handle
```python
if not arr or len(arr) == 0:
    return 0  # or "", or [], depending on problem

# For string problems
if not s:
    return ""
```

### FAANG Tip
> Always ask: "Can the input be empty?" If yes, handle it on line 1.

---

## Edge Case 2: Single Element

### Scenario
```
arr = [5], k = 1
arr = [5], find longest subarray with sum ≤ 10
```

### What Breaks
- Fixed window with k=1 should just scan for max element
- Variable window might skip the single element if logic isn't careful
- `right - left + 1 = 1` — make sure initialization handles this

### How to Handle
```python
if len(arr) == 1:
    return arr[0]  # or check if single element satisfies constraint

# Better: just let the general logic handle it — but verify it does!
```

### FAANG Tip
> Trace your algorithm with a single-element array. If it works, good. If not, add a guard.

---

## Edge Case 3: k Equals Array Length

### Scenario
```
arr = [1, 2, 3], k = 3  → Only ONE window exists (the entire array)
```

### What Breaks
- Sliding loop may never execute (window never slides)
- Answer must be the only window's value

### How to Handle
```python
# The initial window IS the answer
if k == len(arr):
    return sum(arr)  # or whatever the metric is

# Or just verify your loop handles this naturally
```

---

## Edge Case 4: k Larger Than Array Length

### Scenario
```
arr = [1, 2], k = 5  → Impossible to form a window of size 5
```

### What Breaks
- `sum(arr[:k])` sums the entire array (no error, but wrong answer)
- May index out of bounds in some languages

### How to Handle
```python
if len(arr) < k:
    return -1  # or 0, or "not possible"
```

### FAANG Tip
> Always clarify: "Is k guaranteed to be ≤ n?" If not, handle it.

---

## Edge Case 5: All Elements Are the Same

### Scenario
```
arr = [3, 3, 3, 3, 3], find longest subarray with at most k distinct
```

### What Breaks
- Nothing breaks, but the answer is the ENTIRE array (1 distinct element)
- Make sure your logic returns `n` when valid

### Scenario 2
```
s = "aaaaa", find longest substring without repeating characters
```

### Result
- Answer is 1 (only 'a' repeats immediately)
- The window never grows beyond size 1

---

## Edge Case 6: All Elements Are Distinct

### Scenario
```
arr = [1, 2, 3, 4, 5], find subarray with at most 2 distinct
```

### What Breaks
- Window shrinks aggressively — left races to catch up
- Maximum valid window size is always 2

### Scenario 2
```
s = "abcde", find longest substring without repeating chars
```

### Result
- Answer is 5 (entire string, no repeats)
- Window grows to full length without shrinking

---

## Edge Case 7: Target Is Zero

### Scenario
```
arr = [1, 2, 3], find smallest subarray with sum ≥ 0
```

### What Breaks
- Every single element satisfies the constraint
- Answer is 1 (any single element works)
- Variable window logic might overcomplicate this

### Scenario 2
```
arr = [0, 0, 0], find smallest subarray with sum ≥ 0
```

### Result
- Answer is 1 (the single element [0] has sum 0 ≥ 0)

---

## Edge Case 8: Target Is Unreachable

### Scenario
```
arr = [1, 1, 1, 1], find smallest subarray with sum ≥ 100
```

### What Breaks
- No valid window exists
- If `best` is initialized to `float('inf')`, return appropriately

### How to Handle
```python
return best if best != float('inf') else 0  # or -1
```

---

## Edge Case 9: Negative Values

### Scenario
```
arr = [-1, 2, -3, 4, -5], find max sum subarray of size 2
```

### For Fixed Window
- Works fine — just add/subtract elements
- Max might be negative (all elements negative)

### For Variable Window with Sum Constraint
- **BREAKS** sliding window approach
- Shrinking left may increase sum (removing negative number)

### How to Handle
```python
# Fixed window: works with negatives ✓
# Variable window for sum: DO NOT USE with negatives
# Instead: prefix sum + hash map, or deque-based approach
```

---

## Edge Case 10: Large Constraints (10^5 to 10^9)

### Scenario
```
arr has 10^5 elements, each up to 10^9
Sum of subarray might exceed int range
```

### What Breaks
- Integer overflow in C++ (int max ≈ 2.1 × 10^9)
- Sum of 10^5 elements of value 10^9 = 10^14 → exceeds int

### How to Handle
```cpp
// C++: Use long long
long long windowSum = 0;

// Python: No overflow (arbitrary precision integers)
```

### FAANG Tip
> In C++, always use `long long` for sum-based sliding window problems. Ask: "What's the range of values?"

---

## Edge Case 11: Window of Size 0 or 1

### Scenario
```
k = 0 → Should we return 0 or error?
k = 1 → Window is each individual element
```

### How to Handle
```python
if k == 0:
    return 0  # No window possible
if k == 1:
    return max(arr)  # Each element is its own window
```

---

## Edge Case 12: String with Special Characters

### Scenario
```
s = "a b c" → Does space count as a character?
s = "aA" → Is it case-sensitive?
```

### FAANG Tip
> Always ask: "Is the input lowercase English only? Or can it contain uppercase, spaces, special characters?"

This affects:
- Frequency array size (26 vs 128 vs 256)
- Character comparison logic
- Hash map key type

---

## Edge Case Checklist

| # | Edge Case | Check | Impact |
|---|-----------|-------|--------|
| 1 | Empty input | `len(arr) == 0` | Return default |
| 2 | Single element | `len(arr) == 1` | May be the answer |
| 3 | k == n | Only one window | Initial window is answer |
| 4 | k > n | Can't form window | Return impossible |
| 5 | All same | 1 distinct element | Window may be entire array |
| 6 | All distinct | Max distinct | Window shrinks aggressively |
| 7 | Target is 0 | Trivially satisfied | Any single element works |
| 8 | Target unreachable | No valid window | Return appropriate default |
| 9 | Negative values | Breaks variable sum window | Use different approach |
| 10 | Large values | Integer overflow | Use `long long` in C++ |
| 11 | k=0 or k=1 | Degenerate cases | Handle explicitly |
| 12 | Special chars | Character set matters | Clarify with interviewer |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Sliding Window Edge Cases
ALWAYS CHECK:       Empty input, single element, k > n, k = n
NEGATIVE VALUES:    Break variable window for sum constraints
OVERFLOW:           Use long long in C++ for sum-based windows
ALL SAME:           Window might be entire array (1 distinct)
UNREACHABLE:        Handle "no valid window found" gracefully
CLARIFY IN INTERVIEW: "Can values be negative? Is k ≤ n guaranteed?
                       What character set? Can input be empty?"
INTERVIEW LINE:     "Before I code, let me consider edge cases:
                     empty array, single element, k exceeding array size,
                     and whether negative values are possible."
```

---

## 30-SECOND REVISION BOX

```
ALWAYS CHECK: empty, single, k>n, k=n, all same, all distinct
NEGATIVES:    break variable sum window
OVERFLOW:     long long in C++, arbitrary in Python, i64 in Rust
UNREACHABLE:  return 0/-1/empty when no valid window
ASK:          "Can values be negative? Is k ≤ n? Character set?"
```
