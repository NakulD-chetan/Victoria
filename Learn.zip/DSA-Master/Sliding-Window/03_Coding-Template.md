# Sliding Window — Coding Templates (Python + C++ + Rust)

> **Learn 3 languages WHILE learning the pattern. Every template teaches DSA + syntax simultaneously.**

---

## Template 1: Fixed-Size Window

### Python

```python
# KEY SYNTAX: sum() for quick init, range() for iteration
# COLLECTIONS: None needed for basic fixed window

def fixed_window(arr: list[int], k: int) -> int:
    n = len(arr)
    if n < k:
        return -1

    window_sum = sum(arr[:k])       # Pythonic: slice + sum()
    best = window_sum

    for right in range(k, n):       # enumerate not needed here
        window_sum += arr[right]
        window_sum -= arr[right - k]
        best = max(best, window_sum) # built-in max()

    return best
```

**Python Syntax Learned:**
- `sum(arr[:k])` — slice + aggregate in one line
- `range(k, n)` — start iteration from index k
- `max(a, b)` — built-in comparison
- Type hints: `list[int]`, `-> int`

---

### C++ (with STL Deep Dive)

```cpp
#include <vector>
#include <algorithm>  // for std::max
#include <numeric>    // for std::accumulate
using namespace std;

int fixedWindow(vector<int>& arr, int k) {
    int n = arr.size();          // .size() returns size_t (unsigned)
    if (n < k) return -1;

    // std::accumulate → sum of range [begin, begin+k)
    int windowSum = accumulate(arr.begin(), arr.begin() + k, 0);
    int best = windowSum;

    for (int right = k; right < n; right++) {
        windowSum += arr[right];        // O(1) random access
        windowSum -= arr[right - k];    // vector supports []
        best = max(best, windowSum);    // std::max from <algorithm>
    }

    return best;
}
```

**STL Complexity Note:**
| Operation | Complexity |
|-----------|-----------|
| `vector::size()` | O(1) |
| `vector::operator[]` | O(1) |
| `accumulate()` | O(n) |
| `max()` | O(1) |

**C++ Syntax Learned:**
- `vector<int>&` — pass by reference (avoid copy!)
- `arr.size()` — returns `size_t` (careful with signed/unsigned comparison)
- `accumulate(begin, end, init)` — STL range sum
- `arr.begin() + k` — iterator arithmetic
- `max()` from `<algorithm>`

---

### Rust

```rust
use std::cmp;

fn fixed_window(arr: &[i32], k: usize) -> Option<i32> {
    let n = arr.len();
    if n < k {
        return None;    // Rust uses Option instead of -1
    }

    // iter().sum() — zero-cost iterator chain
    let mut window_sum: i32 = arr[..k].iter().sum();
    let mut best = window_sum;

    for right in k..n {                          // k..n = Range
        window_sum += arr[right];                // indexing with usize
        window_sum -= arr[right - k];
        best = cmp::max(best, window_sum);       // std::cmp::max
    }

    Some(best)                                   // Return wrapped in Some
}
```

**Rust Syntax Learned:**
- `&[i32]` — slice reference (borrowed, no ownership transfer)
- `arr.len()` — length method
- `arr[..k]` — slice syntax (like Python's arr[:k])
- `.iter().sum()` — iterator chain for aggregation
- `k..n` — Range literal (exclusive end, like Python's range)
- `Option<i32>` — Rust's null-safety (Some/None instead of -1)
- `mut` — explicit mutability declaration
- `cmp::max()` — comparison from std::cmp

**Rust Performance Note:**
- `&[i32]` borrows data — zero-copy, no allocation
- `.iter().sum()` compiles to the same loop as manual iteration
- No bounds checking overhead with `--release` (optimized out)

---

## Template 2: Variable Window — Find Longest

### Python

```python
from collections import defaultdict  # O(1) auto-init dict

def longest_window(s: str, k: int) -> int:
    """Longest substring with at most k distinct characters."""
    freq = defaultdict(int)   # auto-initializes missing keys to 0
    left = 0
    best = 0

    for right, ch in enumerate(s):    # enumerate gives (index, value)
        freq[ch] += 1

        while len(freq) > k:          # len() on dict = distinct count
            freq[s[left]] -= 1
            if freq[s[left]] == 0:
                del freq[s[left]]     # MUST delete zero-count keys!
            left += 1

        best = max(best, right - left + 1)

    return best
```

**Python Syntax Learned:**
- `defaultdict(int)` — auto-init dict (from collections)
- `enumerate(s)` — iterate with index + value
- `del freq[key]` — delete dict key
- `len(freq)` — number of keys in dict

---

### C++

```cpp
#include <string>
#include <unordered_map>
#include <algorithm>
using namespace std;

int longestWindow(const string& s, int k) {
    unordered_map<char, int> freq;   // Hash map: O(1) avg insert/lookup
    int left = 0, best = 0;

    for (int right = 0; right < (int)s.size(); right++) {
        freq[s[right]]++;            // [] auto-inserts with default 0

        while ((int)freq.size() > k) {  // .size() = distinct count
            freq[s[left]]--;
            if (freq[s[left]] == 0)
                freq.erase(s[left]); // MUST erase zero-count keys!
            left++;
        }

        best = max(best, right - left + 1);
    }

    return best;
}
```

**STL Complexity Note:**
| Operation | Average | Worst |
|-----------|---------|-------|
| `unordered_map::operator[]` | O(1) | O(n) |
| `unordered_map::erase()` | O(1) | O(n) |
| `unordered_map::size()` | O(1) | O(1) |

**C++ Syntax Learned:**
- `unordered_map<char, int>` — hash map (O(1) average)
- `freq[key]++` — auto-inserts default 0, then increments
- `freq.erase(key)` — remove key entirely
- `freq.size()` — number of entries
- `const string&` — pass string by const reference
- `(int)s.size()` — cast to avoid signed/unsigned warning

---

### Rust

```rust
use std::collections::HashMap;
use std::cmp;

fn longest_window(s: &str, k: usize) -> usize {
    let chars: Vec<char> = s.chars().collect();  // String → Vec<char>
    let mut freq: HashMap<char, usize> = HashMap::new();
    let mut left = 0usize;
    let mut best = 0usize;

    for right in 0..chars.len() {
        // entry API: get-or-insert, then modify
        *freq.entry(chars[right]).or_insert(0) += 1;

        while freq.len() > k {
            let left_ch = chars[left];
            if let Some(count) = freq.get_mut(&left_ch) {
                *count -= 1;
                if *count == 0 {
                    freq.remove(&left_ch);  // Remove zero-count
                }
            }
            left += 1;
        }

        best = cmp::max(best, right - left + 1);
    }

    best
}
```

**Rust Syntax Learned:**
- `s.chars().collect()` — convert &str to Vec<char> (strings are UTF-8!)
- `HashMap::new()` — create empty hash map
- `.entry(key).or_insert(0)` — Rust's Entry API (insert if missing)
- `*freq.entry(k).or_insert(0) += 1` — dereference + modify
- `freq.get_mut(&key)` — get mutable reference to value
- `if let Some(count) = ...` — pattern matching on Option
- `freq.remove(&key)` — remove key from map
- `freq.len()` — number of entries
- Ownership: `left_ch` is a `char` (Copy type, no ownership issue)

**Rust Performance Note:**
- `HashMap` uses SipHash by default (DoS-resistant but slower)
- For competitive programming: consider `FxHashMap` from `rustc-hash` crate
- `entry()` API does ONE lookup instead of get+insert (two lookups)

---

## Template 3: Variable Window — Find Shortest

### Python

```python
import math  # for math.inf

def shortest_window(arr: list[int], target: int) -> int:
    left = 0
    best = math.inf            # Python: use math.inf for infinity
    current_sum = 0

    for right in range(len(arr)):
        current_sum += arr[right]

        while current_sum >= target:     # Shrink WHILE VALID
            best = min(best, right - left + 1)
            current_sum -= arr[left]
            left += 1

    return best if best != math.inf else 0
```

---

### C++

```cpp
#include <vector>
#include <climits>     // for INT_MAX
#include <algorithm>
using namespace std;

int shortestWindow(vector<int>& arr, int target) {
    int left = 0, best = INT_MAX;
    int currentSum = 0;

    for (int right = 0; right < (int)arr.size(); right++) {
        currentSum += arr[right];

        while (currentSum >= target) {
            best = min(best, right - left + 1);
            currentSum -= arr[left];
            left++;
        }
    }

    return best == INT_MAX ? 0 : best;   // Ternary operator
}
```

**C++ Syntax Learned:**
- `INT_MAX` from `<climits>` — max int value
- Ternary: `condition ? true_val : false_val`
- `min()` from `<algorithm>`

---

### Rust

```rust
fn shortest_window(arr: &[i32], target: i32) -> usize {
    let mut left = 0usize;
    let mut best = usize::MAX;       // Rust: type::MAX for infinity
    let mut current_sum: i32 = 0;

    for right in 0..arr.len() {
        current_sum += arr[right];

        while current_sum >= target {
            best = best.min(right - left + 1);  // Method syntax
            current_sum -= arr[left];
            left += 1;
        }
    }

    if best == usize::MAX { 0 } else { best }  // Expression-based return
}
```

**Rust Syntax Learned:**
- `usize::MAX` — maximum value for usize type
- `.min()` — method on numeric types (no import needed)
- `if ... { } else { }` — is an EXPRESSION (returns value)
- No semicolon on last line = implicit return

---

## Template 4: Variable Window with HashMap (K Distinct)

### Python

```python
from collections import defaultdict

def at_most_k_distinct(arr: list[int], k: int) -> int:
    freq = defaultdict(int)
    left = 0
    best = 0

    for right in range(len(arr)):
        freq[arr[right]] += 1

        while len(freq) > k:
            freq[arr[left]] -= 1
            if freq[arr[left]] == 0:
                del freq[arr[left]]
            left += 1

        best = max(best, right - left + 1)

    return best

# TRICK: exactly_k = at_most_k(k) - at_most_k(k-1)
def exactly_k_distinct(arr: list[int], k: int) -> int:
    return at_most_k_distinct(arr, k) - at_most_k_distinct(arr, k - 1)
```

---

### C++

```cpp
#include <vector>
#include <unordered_map>
using namespace std;

int atMostKDistinct(vector<int>& arr, int k) {
    unordered_map<int, int> freq;
    int left = 0, best = 0;

    for (int right = 0; right < (int)arr.size(); right++) {
        freq[arr[right]]++;

        while ((int)freq.size() > k) {
            if (--freq[arr[left]] == 0)    // Pre-decrement + check
                freq.erase(arr[left]);
            left++;
        }

        best = max(best, right - left + 1);
    }

    return best;
}

int exactlyKDistinct(vector<int>& arr, int k) {
    return atMostKDistinct(arr, k) - atMostKDistinct(arr, k - 1);
}
```

**C++ Syntax Learned:**
- `--freq[arr[left]]` — pre-decrement operator
- Combining decrement + comparison in one line
- `freq.erase()` only when count reaches 0

---

### Rust

```rust
use std::collections::HashMap;
use std::cmp;

fn at_most_k_distinct(arr: &[i32], k: usize) -> usize {
    let mut freq: HashMap<i32, usize> = HashMap::new();
    let mut left = 0;
    let mut best = 0;

    for right in 0..arr.len() {
        *freq.entry(arr[right]).or_insert(0) += 1;

        while freq.len() > k {
            let val = arr[left];
            let count = freq.get_mut(&val).unwrap();  // unwrap: we know it exists
            *count -= 1;
            if *count == 0 {
                freq.remove(&val);
            }
            left += 1;
        }

        best = cmp::max(best, right - left + 1);
    }

    best
}

fn exactly_k_distinct(arr: &[i32], k: usize) -> usize {
    at_most_k_distinct(arr, k) - at_most_k_distinct(arr, k - 1)
}
```

**Rust Syntax Learned:**
- `.unwrap()` — extract value from Option (panics if None)
- `.get_mut(&key)` — returns `Option<&mut V>`
- Borrowing: `&val` — pass reference to HashMap methods
- Functions as expressions: last line without `;` = return value

---

## Template 5: Frequency Match Window (Minimum Window Substring)

### Python

```python
from collections import Counter

def min_window(s: str, t: str) -> str:
    need = Counter(t)           # Counter: instant frequency map
    have = {}
    formed = 0
    required = len(need)        # Number of UNIQUE chars needed

    left = 0
    best = (float('inf'), 0, 0)  # (length, left, right) tuple

    for right, ch in enumerate(s):
        have[ch] = have.get(ch, 0) + 1    # .get with default

        if ch in need and have[ch] == need[ch]:
            formed += 1

        while formed == required:
            if right - left + 1 < best[0]:
                best = (right - left + 1, left, right)

            out = s[left]
            have[out] -= 1
            if out in need and have[out] < need[out]:
                formed -= 1
            left += 1

    return "" if best[0] == float('inf') else s[best[1]:best[2] + 1]
```

**Python Syntax Learned:**
- `Counter(t)` — instant frequency count (from collections)
- `dict.get(key, default)` — safe access with fallback
- Tuple unpacking: `(length, left, right)`
- `float('inf')` — Python's infinity
- `s[l:r+1]` — string slicing (inclusive both ends)

---

### C++

```cpp
#include <string>
#include <unordered_map>
#include <climits>
using namespace std;

string minWindow(string s, string t) {
    unordered_map<char, int> need, have;
    for (char c : t) need[c]++;         // Range-based for loop

    int formed = 0, required = need.size();
    int left = 0, bestLen = INT_MAX, bestL = 0;

    for (int right = 0; right < (int)s.size(); right++) {
        char ch = s[right];
        have[ch]++;

        if (need.count(ch) && have[ch] == need[ch])  // .count() = exists?
            formed++;

        while (formed == required) {
            if (right - left + 1 < bestLen) {
                bestLen = right - left + 1;
                bestL = left;
            }
            char out = s[left];
            have[out]--;
            if (need.count(out) && have[out] < need[out])
                formed--;
            left++;
        }
    }

    return bestLen == INT_MAX ? "" : s.substr(bestL, bestLen);
}
```

**C++ Syntax Learned:**
- `for (char c : t)` — range-based for loop (C++11)
- `need.count(ch)` — returns 0 or 1 (key existence check)
- `s.substr(pos, len)` — extract substring
- `auto` keyword can replace explicit types

---

### Rust

```rust
use std::collections::HashMap;

fn min_window(s: &str, t: &str) -> String {
    let s_chars: Vec<char> = s.chars().collect();
    let mut need: HashMap<char, i32> = HashMap::new();
    let mut have: HashMap<char, i32> = HashMap::new();

    for ch in t.chars() {
        *need.entry(ch).or_insert(0) += 1;
    }

    let required = need.len();
    let mut formed = 0usize;
    let mut left = 0usize;
    let mut best: (usize, usize, usize) = (usize::MAX, 0, 0); // (len, l, r)

    for right in 0..s_chars.len() {
        let ch = s_chars[right];
        *have.entry(ch).or_insert(0) += 1;

        if need.contains_key(&ch) && have[&ch] == need[&ch] {
            formed += 1;
        }

        while formed == required {
            let window_len = right - left + 1;
            if window_len < best.0 {
                best = (window_len, left, right);
            }

            let out = s_chars[left];
            *have.get_mut(&out).unwrap() -= 1;
            if need.contains_key(&out) && have[&out] < need[&out] {
                formed -= 1;
            }
            left += 1;
        }
    }

    if best.0 == usize::MAX {
        String::new()
    } else {
        s_chars[best.1..=best.2].iter().collect()  // Inclusive range ..=
    }
}
```

**Rust Syntax Learned:**
- `HashMap::contains_key(&key)` — existence check
- `have[&ch]` — Index trait (panics if missing, use carefully)
- `best.0`, `best.1` — tuple field access by position
- `..=` — inclusive range (both ends included)
- `.iter().collect()` — convert iterator back to collection
- `String::new()` — create empty String
- `s_chars[a..=b].iter().collect::<String>()` — slice → String

**Rust Performance Note:**
- `String` is heap-allocated (like C++ std::string)
- Returning `String` transfers ownership (no copy with move semantics)
- For hot paths, consider returning indices instead of String

---

## Template 6: Sliding Window Maximum (Monotonic Deque)

### Python

```python
from collections import deque  # Double-ended queue: O(1) both ends

def sliding_window_maximum(nums: list[int], k: int) -> list[int]:
    dq = deque()    # Stores INDICES, front = max element index
    result = []

    for right in range(len(nums)):
        while dq and dq[0] < right - k + 1:   # Remove out-of-window
            dq.popleft()                        # O(1) from front

        while dq and nums[dq[-1]] < nums[right]:  # Maintain decreasing
            dq.pop()                                # O(1) from back

        dq.append(right)                        # O(1) to back

        if right >= k - 1:                      # Window fully formed
            result.append(nums[dq[0]])          # Front = current max

    return result
```

---

### C++

```cpp
#include <vector>
#include <deque>     // std::deque: O(1) push/pop both ends
using namespace std;

vector<int> slidingWindowMaximum(vector<int>& nums, int k) {
    deque<int> dq;              // Stores indices
    vector<int> result;
    result.reserve(nums.size() - k + 1);  // Pre-allocate output

    for (int right = 0; right < (int)nums.size(); right++) {
        while (!dq.empty() && dq.front() < right - k + 1)
            dq.pop_front();     // O(1)

        while (!dq.empty() && nums[dq.back()] < nums[right])
            dq.pop_back();      // O(1)

        dq.push_back(right);    // O(1)

        if (right >= k - 1)
            result.push_back(nums[dq.front()]);
    }

    return result;
}
```

**STL Complexity Note:**
| `deque` Operation | Complexity |
|-------------------|-----------|
| `push_back` / `push_front` | O(1) amortized |
| `pop_back` / `pop_front` | O(1) |
| `front` / `back` | O(1) |
| `reserve` (vector) | Pre-allocates, avoids realloc |

---

### Rust

```rust
use std::collections::VecDeque;   // Rust's double-ended queue

fn sliding_window_maximum(nums: &[i32], k: usize) -> Vec<i32> {
    let mut dq: VecDeque<usize> = VecDeque::new();
    let mut result: Vec<i32> = Vec::with_capacity(nums.len() - k + 1);

    for right in 0..nums.len() {
        // Remove out-of-window from front
        while !dq.is_empty() && *dq.front().unwrap() < right + 1 - k.min(right + 1) {
            dq.pop_front();
        }
        // Simpler bounds check:
        while let Some(&front) = dq.front() {
            if front + k <= right { dq.pop_front(); } else { break; }
        }

        // Maintain decreasing order from back
        while let Some(&back) = dq.back() {
            if nums[back] < nums[right] { dq.pop_back(); } else { break; }
        }

        dq.push_back(right);

        if right >= k - 1 {
            result.push(nums[*dq.front().unwrap()]);
        }
    }

    result
}
```

**Rust Syntax Learned:**
- `VecDeque<T>` — Rust's deque (from std::collections)
- `VecDeque::new()` — create empty deque
- `.front()` / `.back()` — returns `Option<&T>`
- `while let Some(&val) = dq.front()` — pattern match + loop
- `Vec::with_capacity(n)` — pre-allocate (like C++ reserve)
- `.push()` / `.pop_front()` / `.pop_back()` / `.push_back()`

---

## Language Comparison Quick Reference

| Concept | Python | C++ | Rust |
|---------|--------|-----|------|
| Dynamic array | `list` | `vector<T>` | `Vec<T>` |
| Hash map | `dict` / `defaultdict` | `unordered_map<K,V>` | `HashMap<K,V>` |
| Hash set | `set` | `unordered_set<T>` | `HashSet<T>` |
| Deque | `collections.deque` | `deque<T>` | `VecDeque<T>` |
| Infinity | `float('inf')` | `INT_MAX` | `usize::MAX` / `i32::MAX` |
| Pass by ref | default (objects) | `vector<int>&` | `&[i32]` (slice) |
| String chars | `for ch in s:` | `for (char c : s)` | `s.chars()` |
| Null safety | None check | nullptr / -1 | `Option<T>` |
| Dict insert | `d[k] = v` | `m[k] = v` | `m.insert(k, v)` |
| Dict get-or-default | `d.get(k, 0)` | `m[k]` (auto-0) | `.entry(k).or_insert(0)` |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN:          Sliding Window Templates
FIXED:            Build first window → slide (add right, remove left)
VARIABLE LONG:    Expand right → shrink while INVALID → update max
VARIABLE SHORT:   Expand right → shrink while VALID → update min
K DISTINCT:       HashMap freq + shrink when len(map) > k
CHAR MATCH:       Two maps (need/have) + formed counter
WINDOW MAX:       Monotonic deque (decreasing) storing indices
KEY RULE:         Template structure is IDENTICAL across all 3 languages —
                  only syntax changes
```

---

## 30-SECOND REVISION BOX

```
FIXED:    sum(arr[:k]) → slide: +right, -left
LONGEST:  expand right, shrink while INVALID, track max
SHORTEST: expand right, shrink while VALID, track min
HASHMAP:  entry/defaultdict for freq, delete at zero
DEQUE:    pop_front (expired), pop_back (smaller), front = max
PYTHON:   defaultdict, Counter, deque, enumerate
C++:      unordered_map, deque, accumulate, .erase()
RUST:     HashMap entry API, VecDeque, .chars().collect()
```
