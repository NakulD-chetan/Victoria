import { elementBounds, worldPointsForLinear } from './binding-engine.js';

const MIN_GAP = 12;

function right(rect) {
  return rect.x + rect.w;
}

function bottom(rect) {
  return rect.y + rect.h;
}

function intersects(a, b, gap = 0) {
  return a.x < right(b) + gap
    && right(a) + gap > b.x
    && a.y < bottom(b) + gap
    && bottom(a) + gap > b.y;
}

function isLayoutNode(element) {
  return !element.isDeleted
    && !['arrow', 'line', 'pen', 'highlighter'].includes(element.type)
    && !(element.type === 'text' && element.containerId);
}

export function validateScene(elements) {
  const active = (elements || []).filter((element) => !element.isDeleted);
  const byId = new Map(active.map((element) => [element.id, element]));
  const errors = [];
  const nodes = active.filter(isLayoutNode);

  for (let first = 0; first < nodes.length; first += 1) {
    for (let second = first + 1; second < nodes.length; second += 1) {
      const a = nodes[first];
      const b = nodes[second];
      if (a.frameId && a.frameId === b.id) continue;
      if (b.frameId && b.frameId === a.id) continue;
      if (intersects(elementBounds(a), elementBounds(b), MIN_GAP)) {
        errors.push({
          type: 'overlap',
          elementIds: [a.id, b.id],
          message: `${a.id} overlaps ${b.id}`,
        });
      }
    }
  }

  active.forEach((element) => {
    if (element.type === 'arrow') {
      if (element.startBinding && !byId.has(element.startBinding.elementId)) {
        errors.push({ type: 'invalid-binding', elementIds: [element.id], message: 'Missing arrow start target.' });
      }
      if (element.endBinding && !byId.has(element.endBinding.elementId)) {
        errors.push({ type: 'invalid-binding', elementIds: [element.id], message: 'Missing arrow end target.' });
      }
      const points = worldPointsForLinear(element);
      if (points.length < 2) {
        errors.push({ type: 'invalid-connector', elementIds: [element.id], message: 'Arrow has fewer than two points.' });
      }
    }
    if (element.type === 'text' && element.containerId && !byId.has(element.containerId)) {
      errors.push({ type: 'invalid-container', elementIds: [element.id], message: 'Text container does not exist.' });
    }
  });

  return {
    valid: errors.length === 0,
    errors,
  };
}

function moveElement(element, dx, dy) {
  if (element.type === 'pen' || element.type === 'highlighter') {
    return {
      ...element,
      x: element.x + dx,
      y: element.y + dy,
      points: (element.points || []).map((point) => [
        point[0] + dx,
        point[1] + dy,
        point[2] ?? 0.5,
      ]),
    };
  }
  if (element.type === 'arrow' || element.type === 'line') {
    if (element.startBinding || element.endBinding) return element;
    return {
      ...element,
      x: element.x + dx,
      y: element.y + dy,
      x2: element.x2 + dx,
      y2: element.y2 + dy,
    };
  }
  return { ...element, x: element.x + dx, y: element.y + dy };
}

/**
 * Constraint repair pass. It may move all unbound top-level content, matching
 * the selected full-autonomy policy, but keeps semantic clusters together.
 */
export function repairSceneOverlaps(elements, {
  iterations = 90,
  gap = 28,
} = {}) {
  let result = (elements || []).map((element) => ({ ...element }));

  for (let iteration = 0; iteration < iterations; iteration += 1) {
    let changed = false;
    const nodes = result.filter(isLayoutNode);
    const shifts = new Map();

    for (let first = 0; first < nodes.length; first += 1) {
      for (let second = first + 1; second < nodes.length; second += 1) {
        const a = nodes[first];
        const b = nodes[second];
        const ab = elementBounds(a);
        const bb = elementBounds(b);
        if (!intersects(ab, bb, gap)) continue;

        const overlapX = Math.min(right(ab), right(bb)) - Math.max(ab.x, bb.x) + gap;
        const overlapY = Math.min(bottom(ab), bottom(bb)) - Math.max(ab.y, bb.y) + gap;
        const aCenter = { x: ab.x + ab.w / 2, y: ab.y + ab.h / 2 };
        const bCenter = { x: bb.x + bb.w / 2, y: bb.y + bb.h / 2 };
        const shift = shifts.get(b.id) || { x: 0, y: 0 };
        if (overlapX < overlapY) {
          shift.x += bCenter.x >= aCenter.x ? overlapX : -overlapX;
        } else {
          shift.y += bCenter.y >= aCenter.y ? overlapY : -overlapY;
        }
        shifts.set(b.id, shift);
        changed = true;
      }
    }

    if (!changed) break;
    result = result.map((element) => {
      const shift = shifts.get(element.id);
      if (!shift) return element;
      return moveElement(element, shift.x, shift.y);
    });
  }

  return result;
}
