import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const SAMPLE_TEXT = 'ABABDABACDABABCABAB';
const SAMPLE_PATTERN = 'ABABCABAB';

function buildLps(p) {
  const m = p.length;
  const lps = Array(m).fill(0);
  let len = 0;
  let i = 1;
  const steps = [];
  steps.push({
    type: 'lps',
    msg: 'Build failure (LPS) table',
    i: 0,
    j: 0,
    lps: [...lps],
    text: p,
    pattern: p,
    offset: 0,
    comparePairs: [],
  });
  while (i < m) {
    steps.push({
      type: 'lps-compare',
      msg: `LPS: compare P[${len}] vs P[${i}]`,
      i,
      len,
      lps: [...lps],
      text: p,
      pattern: p,
      offset: 0,
      comparePairs: [[len, i]],
    });
    if (p[len] === p[i]) {
      len += 1;
      lps[i] = len;
      steps.push({
        type: 'lps-match',
        msg: `Match → lps[${i}]=${len}`,
        i,
        len,
        lps: [...lps],
        text: p,
        pattern: p,
        offset: 0,
        comparePairs: [[len - 1, i]],
      });
      i += 1;
    } else if (len > 0) {
      steps.push({
        type: 'lps-fallback',
        msg: `Mismatch → len = lps[${len - 1}]`,
        i,
        len,
        lps: [...lps],
        text: p,
        pattern: p,
        offset: 0,
      });
      len = lps[len - 1];
    } else {
      lps[i] = 0;
      steps.push({
        type: 'lps-zero',
        msg: `No prefix → lps[${i}]=0`,
        i,
        len: 0,
        lps: [...lps],
        text: p,
        pattern: p,
        offset: 0,
      });
      i += 1;
    }
  }
  return { lps, steps };
}

function matchSteps(T, p, lps) {
  const steps = [];
  const n = T.length;
  const m = p.length;
  let i = 0;
  let j = 0;
  steps.push({ type: 'start', msg: 'Align pattern at start', i: 0, j: 0, lps: [...lps], text: T, pattern: p, offset: 0 });
  while (i < n) {
    if (j >= m) j = m - 1;
    steps.push({
      type: 'cmp',
      msg: `Compare T[${i}] vs P[${j}]`,
      i,
      j,
      lps: [...lps],
      text: T,
      pattern: p,
      offset: i - j,
    });
    if (j < m && T[i] === p[j]) {
      if (j === m - 1) {
        steps.push({
          type: 'found',
          msg: `Match at index ${i - m + 1}`,
          i,
          j,
          lps: [...lps],
          text: T,
          pattern: p,
          offset: i - j,
          matchStart: i - m + 1,
        });
        j = lps[j];
        i += 1;
      } else {
        i += 1;
        j += 1;
      }
    } else {
      steps.push({
        type: 'mis',
        msg: j > 0 ? `Mismatch → j = lps[${j - 1}]` : 'Mismatch → shift pattern',
        i,
        j,
        lps: [...lps],
        text: T,
        pattern: p,
        offset: i - j,
      });
      if (j > 0) j = lps[j - 1];
      else i += 1;
    }
  }
  steps.push({ type: 'done', msg: 'Search complete', i, j, lps: [...lps], text: T, pattern: p, offset: Math.max(0, i - j) });
  return steps;
}

function generateSteps() {
  const p = SAMPLE_PATTERN;
  const { lps, steps: lpsSteps } = buildLps(p);
  return [...lpsSteps, ...matchSteps(SAMPLE_TEXT, p, lps)];
}

function paintStep(step) {
  const T = step.text;
  const P = step.pattern;
  const textColors = {};
  const patternColors = {};
  const offset = step.offset ?? 0;
  const comparePairs = [];
  if (step.comparePairs) {
    step.comparePairs.forEach(([ti, pi]) => {
      if (ti < T.length) textColors[ti] = 'current';
      if (pi < P.length) patternColors[pi] = 'current';
      comparePairs.push([ti, pi]);
    });
  }
  if (step.type === 'cmp' || step.type === 'mis') {
    const ti = step.i;
    const pi = step.j;
    if (ti < T.length) textColors[ti] = step.type === 'mis' ? 'mismatch' : 'match';
    if (pi < P.length) patternColors[pi] = step.type === 'mis' ? 'mismatch' : 'match';
    comparePairs.push([ti, pi]);
  }
  if (step.type === 'lps-match' && step.comparePairs) {
    step.comparePairs.forEach(([ti, pi]) => {
      if (ti < T.length) textColors[ti] = 'match';
      if (pi < P.length) patternColors[pi] = 'match';
      comparePairs.push([ti, pi]);
    });
  }
  if (step.type === 'found') {
    for (let k = 0; k < P.length; k++) {
      textColors[step.matchStart + k] = 'found';
      patternColors[k] = 'found';
    }
  }
  const matchPositions = [];
  if (step.type === 'found' && step.matchStart != null) matchPositions.push(step.matchStart);

  return {
    text: T.split(''),
    pattern: P.split(''),
    textColors,
    patternColors,
    offset,
    table: step.lps,
    tableLabel: 'LPS / failure',
    matchPositions,
    comparePairs: comparePairs.length ? comparePairs : null,
  };
}

export default function KMPVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'KMP: build LPS, then search' });
    const first = steps[0];
    canvasRef.current?.setState(paintStep(first));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'cmp') store.incComparisons();
    if (step.type === 'mis') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'mis') canvasRef.current?.addAnim('flashPat', { i: step.j }, 280);
    canvasRef.current?.setState(paintStep(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
