# Aggregates and GROUP BY — Edge Cases

---

## NULL in AVG/SUM

- `AVG` ignores NULLs; count of values may differ from `COUNT(*)`.

---

## Empty groups

`WHERE` filters first — some buckets may never form; **no row** for empty groups (use **conditional aggregation** or **left join** to dimension).

---

## GROUP BY on expressions

```sql
GROUP BY DATE(ts), user_id
```

---

*Next: [[07_Tricks-and-Recognition]]*
