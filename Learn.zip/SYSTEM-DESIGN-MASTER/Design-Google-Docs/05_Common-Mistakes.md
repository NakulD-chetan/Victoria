# Design Google Docs — Common Mistakes

> **Permanent Recall:** Top mistakes = ignoring conflict resolution, using "last write wins," not explaining OT or CRDT, over-implementing OT, ignoring offline mode, no version history. The conflict resolution problem is the **core** — address it first.

---

## Top 6 Common Mistakes

| # | Mistake | Why It's Wrong | Correct Approach |
|---|---------|----------------|------------------|
| 1 | **Ignoring conflict resolution** | Two users typing same place = corruption or lost edits | OT or CRDT; explain transform/merge |
| 2 | **Last write wins** | Loses one user's edit; unacceptable for collaboration | OT/CRDT preserve all edits |
| 3 | **Not explaining OT or CRDT** | Interviewer expects you to know the approaches | Name one; give high-level; example |
| 4 | **Implementing full OT** | OT is complex; time sink; not expected | Explain concept; sketch transform; move on |
| 5 | **Ignoring offline mode** | Real product requirement; shows completeness | Queue ops; sync on reconnect; transform on server |
| 6 | **No version history** | Standard feature; easy to add to design | Snapshot + operation log; replay for history |

---

## Detailed Callouts

### Mistake 1: Ignoring Conflict Resolution

```
❌ "We'll use a database and WebSockets to sync..."
    (Never addresses: what happens when two people type at once?)

✅ "The core challenge is conflict resolution. We need OT or CRDT.
    With OT, the server transforms concurrent operations so they
    converge. Let me walk through an example..."
```

### Mistake 2: Last Write Wins

```
❌ "We'll just overwrite with the latest version."
    Doc: "Hi" → A types "!" → "Hi!" → B types "?" → "Hi?"
    Last write: "Hi?" — A's "!" is LOST.

✅ OT/CRDT: "Hi!" + "Hi?" → merge → "Hi!?" or "Hi?!"
    Both edits preserved; order determined by algorithm.
```

> **FAANG Tip:** Saying "last write wins" is an instant red flag for collaborative editing. Never suggest it.

### Mistake 4: Implementing Full OT

```
❌ Spending 20 minutes writing transform(Insert, Delete) for every case
    (Complex; easy to get wrong; interviewer doesn't want code)

✅ "The transform function takes two operations and produces transformed
    versions so they can be applied in any order. For Insert vs Delete,
    we adjust positions based on how they affect each other. The exact
    rules are in papers like OT for text editing. In production we'd
    use a library like ShareDB or implement from spec."
```

---

## Anti-Pattern Diagram

```
❌ BAD:
Client A ──op──► Server ──► DB (overwrite)
Client B ──op──► Server ──► DB (overwrite)
            Last write wins → one edit lost

✅ GOOD:
Client A ──op──► Server ──► Transform against B's op
Client B ──op──► Server ──► Transform against A's op
            Apply both (transformed) → Broadcast to all
            Both edits preserved
```

---

## What Interviewers Listen For

- **"The core challenge is conflict resolution — OT or CRDT"**
- **"Last write wins doesn't work; we'd lose edits"**
- **"With OT, we transform operations so they converge"**
- **"WebSocket for real-time; snapshot + operation log for storage"**
- **"Offline: queue ops, sync on reconnect, server transforms"**
- **"Version history from the operation log"**

---

## Red Flags to Avoid

- "We'll use a lock so only one person edits at a time" — kills collaboration
- "Last write wins" — loses data
- "We'll merge with diff/patch" — doesn't handle concurrent edits correctly
- "Conflict resolution? We'll figure it out" — core of the problem
- Spending 30 minutes on OT implementation details — scope creep
- No mention of presence, offline, or version history — incomplete

---

## Mistake Severity

| Severity | Mistakes | Impact |
|----------|----------|--------|
| **Critical** | No conflict resolution, last write wins | Design is wrong; won't work |
| **Major** | Not explaining OT/CRDT | Shows lack of knowledge |
| **Moderate** | Over-implementing OT | Time waste; wrong focus |
| **Minor** | No offline, no version history | Incomplete; fixable |

---

## Correct Architecture Checklist

- [ ] Conflict resolution: OT or CRDT
- [ ] No last write wins
- [ ] Explain transform/merge with example
- [ ] WebSocket for real-time sync
- [ ] Collaboration Service (server authority for OT)
- [ ] Snapshot + operation log for storage
- [ ] Version history (replay from log)
- [ ] Presence (cursor positions)
- [ ] Offline: queue + sync
- [ ] Permissions (view/edit)
