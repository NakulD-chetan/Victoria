# Union-Find — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Organized for systematic FAANG prep.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Key Skill | Why Important |
|---|---------|-----------|-----|-----------|---------------|
| 1 | Number of Connected Components | Medium | 323 | Basic UF | Foundation — count after union |
| 2 | Redundant Connection | Medium | 684 | Cycle detection | Classic cycle-in-undirected |
| 3 | Number of Provinces | Medium | 547 | Adjacency matrix | Matrix → edges, then UF |
| 4 | Accounts Merge | Medium | 721 | Group merging | Email→ID map, union by account |
| 5 | Graph Valid Tree | Medium | 261 | Tree = no cycle + n-1 edges | UF for both checks |
| 6 | Number of Islands II | Hard | 305 | Dynamic grid | Add cells one by one |
| 7 | Longest Consecutive Sequence | Medium | 128 | UF + hash | Union adjacent numbers |
| 8 | Satisfiability of Equality Equations | Medium | 990 | Union equals, check unequals | Two-pass UF |
| 9 | Smallest String With Swaps | Medium | 1202 | UF + sort per component | Group indices, sort each |
| 10 | Remove Max Edges to Keep Graph Traversable | Hard | 1579 | Two UFs (Alice + Bob) | Type-specific edges |

---

## Complete 30-Problem Progression

### Foundation (Problems 1-8) — Basic UF

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Number of Connected Components | 323 | Component count | UF, return count |
| 2 | Redundant Connection | 684 | Cycle detection | First find(u)==find(v) |
| 3 | Number of Provinces | 547 | Matrix to edges | Convert adj matrix to edge list |
| 4 | Graph Valid Tree | 261 | Tree validation | n-1 edges + no cycle |
| 5 | Redundant Connection II | 685 | Directed cycle | Harder — in/out degree |
| 6 | Find the Town Judge | 997 | Trust graph | Not UF, but know when not to use |
| 7 | Longest Consecutive Sequence | 128 | UF + hash | Union (x, x+1) for x in nums |
| 8 | Satisfiability of Equality Equations | 990 | Equals union, unequals check | Union a==b, then check a!=b |

### Group Merging (Problems 9-14)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 9 | Accounts Merge | 721 | Email grouping | Map email→id, union same account |
| 10 | Smallest String With Swaps | 1202 | Indices in same component | UF indices, sort each group |
| 11 | Similar String Groups | 839 | Group similar strings | Union if 0 or 1 char diff |
| 12 | Evaluate Division | 399 | Weighted UF | UF with ratio tracking |
| 13 | Regions Cut By Slashes | 959 | Grid split into 4 subcells | 4 parts per cell, union |
| 14 | Sentence Similarity II | 737 | Transitive similarity | Union similar pairs |

### Grid & Dynamic (Problems 15-22)

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 15 | Number of Islands | 200 | Grid UF/DFS | Union adjacent 1s |
| 16 | Number of Islands II | 305 | Dynamic grid | Add positions, union neighbors |
| 17 | Max Area of Island | 695 | Component size | Track size[] in UF |
| 18 | Surrounded Regions | 130 | Boundary connection | Union with virtual boundary |
| 19 | Number of Enclaves | 1020 | Boundary escape | UF or DFS from boundary |
| 20 | Most Stones Removed | 947 | Row/col connection | Union (row, col+offset) |
| 21 | The Earliest Moment | 1101 | Timestamp order | Sort by time, union |
| 22 | Path With Minimum Effort | 1631 | Binary search + UF | Union by threshold |

### Advanced (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Remove Max Edges to Keep Graph Traversable | 1579 | Two UFs | Alice UF, Bob UF |
| 24 | Checking Existence of Edge Length Limits | 1697 | Offline queries | Sort edges, process in order |
| 25 | Process Restricted Friend Requests | 1722 | Restrictions check | Union if no restriction violated |
| 26 | Rank Transform of a Matrix | 1632 | Row+col constraints | Union by value, assign rank |
| 27 | Minimize Malware Spread | 924 | Component size + initial | UF + size, remove max spread |
| 28 | Minimize Malware Spread II | 928 | Per-node removal impact | Try removing each, count |
| 29 | Bricks Falling When Hit | 803 | Reverse time | Process hits backward |
| 30 | Swim in Rising Water | 778 | Binary search + UF | Union when threshold allows |

---

## Pattern Distribution

```
Basic UF / Cycle:       8 problems  (1-8)
Group Merging:          6 problems  (9-14)
Grid & Dynamic:         8 problems  (15-22)
Advanced:               8 problems  (23-30)
```

---

## 4-Week Study Plan

### Week 1: Foundation
- Day 1-2: LC 323, 684, 547 (component count, cycle, provinces)
- Day 3-4: LC 261, 128, 990 (tree, consecutive, equations)
- Day 5: LC 685 (redundant II — directed)
- Practice: Python for speed

### Week 2: Group Merging
- Day 1-2: LC 721, 1202 (accounts, swaps)
- Day 3-4: LC 839, 737 (similar strings, sentence)
- Day 5: LC 959, 399 (regions, division)
- Practice: C++ for STL

### Week 3: Grid & Dynamic
- Day 1-2: LC 200, 305, 695 (islands, dynamic, max area)
- Day 3-4: LC 130, 1020, 947 (surrounded, enclaves, stones)
- Day 5: LC 1101, 1631 (earliest moment, min effort)
- Practice: Rust for ownership

### Week 4: Advanced + Review
- Day 1-2: LC 1579, 1697, 1722 (multi-UF, offline, restrictions)
- Day 3-4: LC 1632, 924, 928 (matrix rank, malware)
- Day 5: LC 803, 778 (bricks, swim)
- Practice: All 3 languages, weak areas

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (8 Easy-ish, 18 Medium, 4 Hard)
MUST-DO:            LC 323, 684, 547, 721, 261, 305, 128, 990, 1202, 1579
TOP 5 MOST ASKED:  LC 547 (Provinces), LC 721 (Accounts), LC 684 (Redundant),
                   LC 323 (Components), LC 261 (Valid Tree)
CATEGORIES:        Basic → Group Merge → Grid → Advanced
STUDY ORDER:       Foundation → Merging → Grid → Advanced
KEY INSIGHT:       UF = connectivity; path compression + union by rank always
```

---

## 30-SECOND REVISION BOX

```
BASIC:       Count, cycle (find before union), provinces (matrix→edges)
MERGE:       Accounts (email→id), swaps (indices→sort per component)
GRID:        idx=r*cols+c, union 4 neighbors, dynamic = add one by one
ADVANCED:    Two UFs, offline queries, reverse time
MUST-DO:     323, 684, 547, 721, 261, 305, 128, 990, 1202, 1579
```
