# Stack — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.** Python + C++ + Rust for FAANG interviews.

---

## Template 1: Monotonic Increasing Stack

**Use when:** Finding next smaller element (to the right) or previous smaller (to the left).

### Python

```python
def monotonic_increasing_stack(arr):
    n = len(arr)
    stack = []  # stores indices
    
    for i in range(n):
        # Pop while current is smaller than stack top (current is "answer" for them)
        while stack and arr[i] < arr[stack[-1]]:
            idx = stack.pop()
            # Process: arr[i] is next smaller for arr[idx]
            # result[idx] = arr[i] or i, etc.
            pass
        
        stack.append(i)
    
    # Remaining in stack: no next smaller found (assign -1 or n)
    while stack:
        idx = stack.pop()
        # result[idx] = -1 or n
        pass
```

### C++

```cpp
vector<int> monotonicIncreasingStack(vector<int>& arr) {
    int n = arr.size();
    vector<int> stack;  // stores indices
    
    for (int i = 0; i < n; i++) {
        while (!stack.empty() && arr[i] < arr[stack.back()]) {
            int idx = stack.back();
            stack.pop_back();
            // Process: arr[i] is next smaller for arr[idx]
        }
        stack.push_back(i);
    }
    
    // Remaining: no next smaller
    while (!stack.empty()) {
        int idx = stack.back();
        stack.pop_back();
        // result[idx] = -1 or n
    }
    
    return {};  // return result
}
```

### Rust

```rust
/// Vec<T> as stack: push(), pop(), last() for peek. No separate Stack type — Vec IS the stack.
fn monotonic_increasing_stack(arr: &[i32]) -> Vec<usize> {
    let n = arr.len();
    let mut stack: Vec<usize> = Vec::new();  // stores indices

    for i in 0..n {
        while stack.last().map_or(false, |&idx| arr[i] < arr[idx]) {
            let idx = stack.pop().unwrap();
            // Process: arr[i] is next smaller for arr[idx]
        }
        stack.push(i);
    }

    while let Some(idx) = stack.pop() {
        // result[idx] = -1 or n
    }

    vec![]  // return result
}
```

**Rust Note:** `Vec::push()` / `pop()` — stack ops. `stack.last()` returns `Option<&T>` (peek without consuming). Pattern match `while let Some(x) = stack.pop()` for drain.

---

## Template 2: Monotonic Decreasing Stack

**Use when:** Finding next greater element (to the right) or previous greater (to the left).

### Python

```python
def monotonic_decreasing_stack(arr):
    n = len(arr)
    stack = []  # stores indices
    
    for i in range(n):
        # Pop while current is greater than stack top (current is "answer" for them)
        while stack and arr[i] > arr[stack[-1]]:
            idx = stack.pop()
            # Process: arr[i] is next greater for arr[idx]
            # result[idx] = arr[i] or i, etc.
            pass
        
        stack.append(i)
    
    # Remaining in stack: no next greater found (assign -1)
    while stack:
        idx = stack.pop()
        # result[idx] = -1
        pass
```

### C++

```cpp
vector<int> monotonicDecreasingStack(vector<int>& arr) {
    int n = arr.size();
    vector<int> stack;  // stores indices
    
    for (int i = 0; i < n; i++) {
        while (!stack.empty() && arr[i] > arr[stack.back()]) {
            int idx = stack.back();
            stack.pop_back();
            // Process: arr[i] is next greater for arr[idx]
        }
        stack.push_back(i);
    }
    
    while (!stack.empty()) {
        int idx = stack.back();
        stack.pop_back();
        // result[idx] = -1
    }
    
    return {};
}
```

### Rust

```rust
/// Monotonic decreasing: pop while current > stack top (next greater).
fn monotonic_decreasing_stack(arr: &[i32]) -> Vec<i32> {
    let n = arr.len();
    let mut stack: Vec<usize> = Vec::new();
    let mut result = vec![-1i32; n];

    for i in 0..n {
        while stack.last().map_or(false, |&idx| arr[i] > arr[idx]) {
            let idx = stack.pop().unwrap();
            result[idx] = arr[i];
        }
        stack.push(i);
    }
    result
}
```

**Rust Note:** `stack.last().map_or(false, |&idx| ...)` — peek: None → false, Some → run closure. `vec![-1i32; n]` — init result array.

---

## Template 3: Next Greater Element (Right)

### Python

```python
def next_greater_element_right(arr):
    n = len(arr)
    result = [-1] * n
    stack = []  # indices
    
    for i in range(n):
        while stack and arr[i] > arr[stack[-1]]:
            idx = stack.pop()
            result[idx] = arr[i]  # or i if index needed
        stack.append(i)
    
    return result
```

### C++

```cpp
vector<int> nextGreaterElementRight(vector<int>& arr) {
    int n = arr.size();
    vector<int> result(n, -1);
    vector<int> stack;
    
    for (int i = 0; i < n; i++) {
        while (!stack.empty() && arr[i] > arr[stack.back()]) {
            int idx = stack.back();
            stack.pop_back();
            result[idx] = arr[i];
        }
        stack.push_back(i);
    }
    
    return result;
}
```

### Rust

```rust
/// Next greater to the right. Vec as stack: push/pop, last() for peek.
fn next_greater_element_right(arr: &[i32]) -> Vec<i32> {
    let n = arr.len();
    let mut result = vec![-1i32; n];
    let mut stack: Vec<usize> = Vec::new();

    for i in 0..n {
        while let Some(&idx) = stack.last() {
            if arr[i] <= arr[idx] { break; }
            stack.pop();
            result[idx] = arr[i];
        }
        stack.push(i);
    }
    result
}
```

**Rust Note:** `while let Some(&idx) = stack.last()` — pattern match on Option. `last()` borrows, doesn't consume. Use `pop()` when removing.

---

## Template 4: Next Smaller Element (Left)

**Scan right-to-left** — "next smaller to the left" = "previous smaller element."

### Python

```python
def next_smaller_element_left(arr):
    n = len(arr)
    result = [-1] * n  # -1 means no smaller to left
    stack = []  # indices
    
    for i in range(n):
        while stack and arr[i] < arr[stack[-1]]:
            stack.pop()  # current is smaller, discard those
        if stack:
            result[i] = arr[stack[-1]]  # stack top is prev smaller
        stack.append(i)
    
    return result
```

**Alternative: Previous Smaller Element (index version for histogram)**

```python
def previous_smaller_index(arr):
    n = len(arr)
    left = [-1] * n  # left[i] = index of prev smaller, -1 if none
    stack = []
    
    for i in range(n):
        while stack and arr[stack[-1]] >= arr[i]:
            stack.pop()
        if stack:
            left[i] = stack[-1]
        stack.append(i)
    
    return left
```

### C++

```cpp
vector<int> previousSmallerIndex(vector<int>& arr) {
    int n = arr.size();
    vector<int> left(n, -1);
    vector<int> stack;
    
    for (int i = 0; i < n; i++) {
        while (!stack.empty() && arr[stack.back()] >= arr[i])
            stack.pop_back();
        if (!stack.empty())
            left[i] = stack.back();
        stack.push_back(i);
    }
    
    return left;
}
```

### Rust

```rust
/// Previous smaller index. Pop while stack top >= current; then stack.last() is prev smaller.
fn previous_smaller_index(arr: &[i32]) -> Vec<i32> {
    let n = arr.len();
    let mut left = vec![-1i32; n];
    let mut stack: Vec<usize> = Vec::new();

    for i in 0..n {
        while stack.last().map_or(false, |&idx| arr[idx] >= arr[i]) {
            stack.pop();
        }
        if let Some(&idx) = stack.last() {
            left[i] = idx as i32;
        }
        stack.push(i);
    }
    left
}
```

**Rust Note:** `if let Some(&idx) = stack.last()` — pattern matching for peek. Store index as i32 for -1 sentinel (or use `Option<usize>`).

---

## Template 5: Valid Parentheses

### Python

```python
def valid_parentheses(s):
    stack = []
    pairs = {')': '(', ']': '[', '}': '{'}
    
    for c in s:
        if c in '([{':
            stack.append(c)
        else:
            if not stack or stack[-1] != pairs[c]:
                return False
            stack.pop()
    
    return len(stack) == 0
```

### C++

```cpp
bool validParentheses(string s) {
    vector<char> stack;
    unordered_map<char, char> pairs = {{')', '('}, {']', '['}, {'}', '{'}};
    
    for (char c : s) {
        if (c == '(' || c == '[' || c == '{')
            stack.push_back(c);
        else {
            if (stack.empty() || stack.back() != pairs[c])
                return false;
            stack.pop_back();
        }
    }
    
    return stack.empty();
}
```

### Rust

```rust
/// Vec<char> as stack. Pattern matching: stack.last() == pairs[&c].
use std::collections::HashMap;

fn valid_parentheses(s: &str) -> bool {
    let pairs: HashMap<char, char> = [(')', '('), (']', '['), ('}', '{')].into();
    let mut stack: Vec<char> = Vec::new();

    for c in s.chars() {
        if matches!(c, '(' | '[' | '{') {
            stack.push(c);
        } else if let Some(&open) = pairs.get(&c) {
            if stack.last() != Some(&open) {
                return false;
            }
            stack.pop();
        }
    }
    stack.is_empty()
}
```

**Rust Note:** `matches!(c, '(' | '[' | '{')` — macro for multi-pattern. `stack.last() != Some(&open)` — compare Option with value. `stack.pop()` returns `Option<T>`.

---

## Template 6: Expression Evaluation (Infix to Postfix)

### Python

```python
def infix_to_postfix(expr):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}
    stack = []
    output = []
    
    for c in expr:
        if c.isalnum():
            output.append(c)
        elif c == '(':
            stack.append(c)
        elif c == ')':
            while stack and stack[-1] != '(':
                output.append(stack.pop())
            stack.pop()  # discard '('
        elif c in precedence:
            while stack and stack[-1] != '(' and precedence.get(stack[-1], 0) >= precedence[c]:
                output.append(stack.pop())
            stack.append(c)
    
    while stack:
        output.append(stack.pop())
    
    return ''.join(output)
```

### C++

```cpp
string infixToPostfix(string expr) {
    unordered_map<char, int> prec = {{'+', 1}, {'-', 1}, {'*', 2}, {'/', 2}, {'^', 3}};
    vector<char> stack;
    string output;
    
    for (char c : expr) {
        if (isalnum(c))
            output += c;
        else if (c == '(')
            stack.push_back(c);
        else if (c == ')') {
            while (!stack.empty() && stack.back() != '(') {
                output += stack.back();
                stack.pop_back();
            }
            stack.pop_back();
        } else if (prec.count(c)) {
            while (!stack.empty() && stack.back() != '(' && 
                   prec[stack.back()] >= prec[c]) {
                output += stack.back();
                stack.pop_back();
            }
            stack.push_back(c);
        }
    }
    
    while (!stack.empty()) {
        output += stack.back();
        stack.pop_back();
    }
    
    return output;
}
```

### Rust

```rust
/// Infix to postfix. Vec<char> for operator stack. Precedence map.
use std::collections::HashMap;

fn infix_to_postfix(expr: &str) -> String {
    let precedence: HashMap<char, i32> = [('+', 1), ('-', 1), ('*', 2), ('/', 2), ('^', 3)].into();
    let mut stack: Vec<char> = Vec::new();
    let mut output = String::new();

    for c in expr.chars() {
        if c.is_ascii_alphanumeric() {
            output.push(c);
        } else if c == '(' {
            stack.push(c);
        } else if c == ')' {
            while stack.last() != Some(&'(') {
                output.push(stack.pop().unwrap());
            }
            stack.pop();  // discard '('
        } else if let Some(&prec) = precedence.get(&c) {
            while stack.last().map_or(false, |&top| top != '(' && precedence[&top] >= prec) {
                output.push(stack.pop().unwrap());
            }
            stack.push(c);
        }
    }
    while let Some(c) = stack.pop() {
        output.push(c);
    }
    output
}
```

**Rust Note:** `stack.last() != Some(&'(')` — peek and compare. `String::push(char)` for output. No separate Stack type — `Vec` is the stack.

### Postfix Evaluation

```python
def eval_postfix(postfix):
    stack = []
    for c in postfix:
        if c.isdigit():
            stack.append(int(c))
        else:
            b, a = stack.pop(), stack.pop()
            if c == '+': stack.append(a + b)
            elif c == '-': stack.append(a - b)
            elif c == '*': stack.append(a * b)
            elif c == '/': stack.append(a // b)
    return stack[0]
```

```rust
fn eval_postfix(postfix: &str) -> i32 {
    let mut stack: Vec<i32> = Vec::new();
    for c in postfix.chars() {
        if c.is_ascii_digit() {
            stack.push(c.to_digit(10).unwrap() as i32);
        } else {
            let b = stack.pop().unwrap();
            let a = stack.pop().unwrap();
            stack.push(match c {
                '+' => a + b,
                '-' => a - b,
                '*' => a * b,
                '/' => a / b,
                _ => 0,
            });
        }
    }
    stack[0]
}
```

---

## Template 7: Min Stack (O(1) getMin)

### Python

```python
class MinStack:
    def __init__(self):
        self.stack = []
        self.min_stack = []  # parallel stack for min at each level
    
    def push(self, val):
        self.stack.append(val)
        if not self.min_stack or val <= self.min_stack[-1]:
            self.min_stack.append(val)
    
    def pop(self):
        if self.stack.pop() == self.min_stack[-1]:
            self.min_stack.pop()
    
    def top(self):
        return self.stack[-1]
    
    def getMin(self):
        return self.min_stack[-1]
```

### C++

```cpp
class MinStack {
    vector<int> stack;
    vector<int> minStack;
    
public:
    void push(int val) {
        stack.push_back(val);
        if (minStack.empty() || val <= minStack.back())
            minStack.push_back(val);
    }
    
    void pop() {
        if (stack.back() == minStack.back())
            minStack.pop_back();
        stack.pop_back();
    }
    
    int top() { return stack.back(); }
    int getMin() { return minStack.back(); }
};
```

### Rust

```rust
/// MinStack: parallel min_stack. last() for O(1) peek — pattern matching.
struct MinStack {
    stack: Vec<i32>,
    min_stack: Vec<i32>,
}

impl MinStack {
    fn new() -> Self {
        Self { stack: Vec::new(), min_stack: Vec::new() }
    }
    fn push(&mut self, val: i32) {
        self.stack.push(val);
        if self.min_stack.last().map_or(true, |&m| val <= m) {
            self.min_stack.push(val);
        }
    }
    fn pop(&mut self) {
        if self.stack.pop() == self.min_stack.last().copied() {
            self.min_stack.pop();
        }
    }
    fn top(&self) -> i32 {
        *self.stack.last().unwrap()
    }
    fn get_min(&self) -> i32 {
        *self.min_stack.last().unwrap()
    }
}
```

**Rust Note:** `Vec` IS the stack — no separate type. `last().map_or(true, |&m| val <= m)` — None (empty) → push; Some → compare. `last().copied()` to get `Option<i32>` for comparison.

---

## Template 8: Largest Rectangle (Histogram) — Monotonic Stack

```python
def largest_rectangle_histogram(heights):
    n = len(heights)
    left = [-1] * n   # prev smaller index
    right = [n] * n   # next smaller index
    stack = []
    
    # Next smaller to the right
    for i in range(n):
        while stack and heights[i] < heights[stack[-1]]:
            right[stack.pop()] = i
        stack.append(i)
    
    stack.clear()
    
    # Previous smaller to the left
    for i in range(n):
        while stack and heights[stack[-1]] >= heights[i]:
            stack.pop()
        if stack:
            left[i] = stack[-1]
        stack.append(i)
    
    ans = 0
    for i in range(n):
        width = right[i] - left[i] - 1
        ans = max(ans, heights[i] * width)
    
    return ans
```

### Rust

```rust
/// Largest rectangle: prev/next smaller via monotonic stack. Vec as stack.
fn largest_rectangle_histogram(heights: &[i32]) -> i32 {
    let n = heights.len();
    let mut left = vec![-1i32; n];
    let mut right = vec![n as i32; n];
    let mut stack: Vec<usize> = Vec::new();

    for i in 0..n {
        while stack.last().map_or(false, |&idx| heights[i] < heights[idx]) {
            let idx = stack.pop().unwrap();
            right[idx] = i as i32;
        }
        stack.push(i);
    }
    stack.clear();

    for i in 0..n {
        while stack.last().map_or(false, |&idx| heights[idx] >= heights[i]) {
            stack.pop();
        }
        if let Some(&idx) = stack.last() {
            left[i] = idx as i32;
        }
        stack.push(i);
    }

    (0..n)
        .map(|i| heights[i] * (right[i] - left[i] - 1))
        .max()
        .unwrap_or(0)
}
```

**Rust Note:** `stack.clear()` — reuse stack. Iterator `.map().max()` for final pass. `Vec` = stack; `push`/`pop`/`last()`.

---

## FINAL MEMORY COMPRESSION BLOCK

```
MONOTONIC INCREASING:  arr[i] < arr[top] → pop (next smaller)
MONOTONIC DECREASING:  arr[i] > arr[top] → pop (next greater)
STORE:                 Indices in stack
LOOP:                  for i in range(n): while pop condition: process; append(i)
END:                   Process remaining stack (no answer)
PARENTHESES:           push open, pop on close if match
MIN STACK:             Parallel min_stack, push when val <= min_stack[-1]
```

---

## Language Comparison Quick Reference


| Concept           | Python        | C++             | Rust                          |
| ----------------- | ------------- | --------------- | ----------------------------- |
| Stack type        | `list`        | `vector<T>`     | `Vec<T>` (Vec IS the stack)   |
| Push              | `append(x)`   | `push_back(x)`  | `push(x)`                     |
| Pop               | `pop()`       | `pop_back()`    | `pop()`                       |
| Peek              | `stack[-1]`   | `stack.back()`  | `stack.last()` → `Option<&T>` |
| Empty check       | `not stack`   | `stack.empty()` | `stack.is_empty()`            |
| No separate Stack | list as stack | vector as stack | Vec as stack                  |


---

## 30-SECOND REVISION BOX

```
INC STACK:  arr[i] < arr[top] → pop (next smaller)
DEC STACK:  arr[i] > arr[top] → pop (next greater)
STORE:      Indices
PARENS:     push open; pop on close if match
MIN STACK:  parallel min_stack, push when val <= min
HISTOGRAM:  prev/next smaller → width = right-left-1
RUST:       Vec=stack, push/pop, last() for peek
```

