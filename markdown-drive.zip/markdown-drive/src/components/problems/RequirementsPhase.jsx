import { useCallback } from 'react';
import { useProblemSessionStore } from '../../stores/problem-session-store';

export default function RequirementsPhase({ problem }) {
  const checked = useProblemSessionStore((s) => s.phases.requirements.checked);
  const score = useProblemSessionStore((s) => s.phases.requirements.score);
  const completed = useProblemSessionStore((s) => s.phases.requirements.completed);
  const toggleRequirement = useProblemSessionStore((s) => s.toggleRequirement);
  const scoreRequirements = useProblemSessionStore((s) => s.scoreRequirements);
  const nextPhase = useProblemSessionStore((s) => s.nextPhase);

  const checklist = problem.requirementChecklist;
  if (!checklist) return <div className="dc-phase-empty">No requirements checklist available for this problem.</div>;

  const handleSubmit = useCallback(() => {
    scoreRequirements(problem);
  }, [problem, scoreRequirements]);

  const handleNext = useCallback(() => {
    if (!completed) scoreRequirements(problem);
    nextPhase();
  }, [completed, scoreRequirements, problem, nextPhase]);

  const renderSection = (title, category, items) => (
    <div className="dc-req-phase__section">
      <h4 className="dc-req-phase__subtitle">{title}</h4>
      <p className="dc-req-phase__hint">Check the requirements you think are needed for this system.</p>
      <div className="dc-req-phase__list">
        {items.map((item, idx) => {
          const isChecked = checked[category]?.includes(idx);
          return (
            <label key={idx} className={`dc-req-phase__item ${isChecked ? 'dc-req-phase__item--checked' : ''}`}>
              <input
                type="checkbox"
                checked={isChecked || false}
                onChange={() => toggleRequirement(category, idx)}
                className="dc-req-phase__checkbox"
                disabled={completed}
              />
              <span className="dc-req-phase__text">{item.text}</span>
              {completed && (
                <span className={`dc-req-phase__tag ${item.required ? 'dc-req-phase__tag--required' : 'dc-req-phase__tag--bonus'}`}>
                  {item.required ? 'Required' : 'Bonus'}
                </span>
              )}
            </label>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="dc-req-phase">
      <div className="dc-req-phase__header">
        <h3 className="dc-req-phase__title">Phase 1: Gather Requirements</h3>
        <p className="dc-req-phase__desc">
          In a real interview, always clarify requirements before designing. Identify which functional and
          non-functional requirements are essential for this system.
        </p>
      </div>

      {renderSection('Functional Requirements', 'functional', checklist.functional)}
      {renderSection('Non-Functional Requirements', 'nonFunctional', checklist.nonFunctional)}

      <div className="dc-req-phase__actions">
        {!completed ? (
          <button onClick={handleSubmit} className="dc-btn dc-btn--primary">
            Check My Requirements
          </button>
        ) : (
          <div className="dc-req-phase__result">
            <div className={`dc-req-phase__score ${score >= 70 ? 'dc-req-phase__score--good' : 'dc-req-phase__score--low'}`}>
              Score: {score}%
            </div>
            <button onClick={handleNext} className="dc-btn dc-btn--primary">
              Next: API Design &rarr;
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
