function boundsOf(element) {
  return {
    x: Number(element?.x) || 0,
    y: Number(element?.y) || 0,
    width: Math.abs(Number(element?.width) || 0),
    height: Math.abs(Number(element?.height) || 0),
  };
}

function intersects(a, b, gap = 0) {
  return a.x < b.x + b.width + gap
    && a.x + a.width + gap > b.x
    && a.y < b.y + b.height + gap
    && a.y + a.height + gap > b.y;
}

export function validateTeachingDocumentV3(document) {
  const errors = [];
  const warnings = [];
  const elements = (document?.elements || []).filter((element) => !element.isDeleted);
  const ids = new Set(elements.map((element) => element.id));
  const frames = document?.lessonDeck?.frames || [];

  for (const element of elements) {
    if (!element.id || !element.type) {
      errors.push({ type: 'invalid-element', elementId: element.id || null });
      continue;
    }

    if (element.frameId && !ids.has(element.frameId)) {
      errors.push({
        type: 'invalid-frame-reference',
        elementId: element.id,
        frameId: element.frameId,
      });
    }

    if (element.type === 'arrow') {
      if (element.startBinding?.elementId && !ids.has(element.startBinding.elementId)) {
        errors.push({ type: 'invalid-start-binding', elementId: element.id });
      }
      if (element.endBinding?.elementId && !ids.has(element.endBinding.elementId)) {
        errors.push({ type: 'invalid-end-binding', elementId: element.id });
      }
      if (!element.endBinding?.elementId) {
        warnings.push({ type: 'unbound-arrow', elementId: element.id });
      }
    }
  }

  for (const frame of frames) {
    const frameBounds = frame.bounds;
    const children = elements.filter((element) => element.frameId === frame.frameElementId);
    for (const child of children) {
      const bounds = boundsOf(child);
      const inside = bounds.x >= frameBounds.x
        && bounds.y >= frameBounds.y
        && bounds.x + bounds.width <= frameBounds.x + frameBounds.width
        && bounds.y + bounds.height <= frameBounds.y + frameBounds.height;
      if (!inside) {
        errors.push({
          type: 'element-outside-frame',
          elementId: child.id,
          frameId: frame.id,
        });
      }
    }

    const content = children.filter((element) => {
      const role = element.customData?.semanticRole;
      return !['lesson-background', 'connector', 'highlight'].includes(role)
        && !['arrow', 'frame'].includes(element.type);
    });
    for (let left = 0; left < content.length; left += 1) {
      for (let right = left + 1; right < content.length; right += 1) {
        const a = content[left];
        const b = content[right];
        if (a.groupIds?.some((groupId) => b.groupIds?.includes(groupId))) continue;
        if (a.containerId === b.id || b.containerId === a.id) continue;
        if (intersects(boundsOf(a), boundsOf(b), -4)) {
          warnings.push({
            type: 'content-overlap',
            elementIds: [a.id, b.id],
            frameId: frame.id,
          });
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

