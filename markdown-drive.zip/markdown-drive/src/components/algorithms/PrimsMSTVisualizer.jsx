import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: prims-mst */
const GRAPH = {
  nodes: [
    { id: 'A', x: 120, y: 200, label: 'A' },
    { id: 'B', x: 240, y: 120, label: 'B' },
    { id: 'C', x: 380, y: 140, label: 'C' },
    { id: 'D', x: 500, y: 220, label: 'D' },
    { id: 'E', x: 360, y: 300, label: 'E' },
    { id: 'F', x: 220, y: 300, label: 'F' },
  ],
  edges: [
    { from: 'A', to: 'B', weight: 4, directed: false },
    { from: 'A', to: 'F', weight: 6, directed: false },
    { from: 'B', to: 'C', weight: 3, directed: false },
    { from: 'B', to: 'F', weight: 2, directed: false },
    { from: 'C', to: 'D', weight: 5, directed: false },
    { from: 'C', to: 'E', weight: 4, directed: false },
    { from: 'D', to: 'E', weight: 2, directed: false },
    { from: 'E', to: 'F', weight: 3, directed: false },
  ],
};

function edgeKey(u, v) {
  return u < v ? `${u}-${v}` : `${v}-${u}`;
}

function generateSteps() {
  const nodes = GRAPH.nodes.map((n) => n.id);
  const inMst = new Set(['A']);
  const steps = [];
  steps.push({ type: 'start', nodeColors: { A: 'source' }, edgeColors: {} });
  while (inMst.size < nodes.length) {
    let best = null;
    let bestW = Infinity;
    GRAPH.edges.forEach((e) => {
      const a = inMst.has(e.from);
      const b = inMst.has(e.to);
      if (a === b) return;
      const u = a ? e.from : e.to;
      const v = a ? e.to : e.from;
      if (e.weight < bestW) {
        bestW = e.weight;
        best = { u, v, e };
      }
    });
    if (!best) break;
    steps.push({
      type: 'pick',
      nodeColors: { [best.u]: 'processing', [best.v]: 'processing' },
      edgeColors: { [edgeKey(best.e.from, best.e.to)]: 'highlight' },
    });
    inMst.add(best.v);
    steps.push({
      type: 'add',
      nodeColors: Object.fromEntries([...inMst].map((id) => [id, 'visited'])),
      edgeColors: { [edgeKey(best.e.from, best.e.to)]: 'mst' },
    });
  }
  steps.push({ type: 'done', nodeColors: Object.fromEntries(nodes.map((id) => [id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function PrimsMSTVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: "Prim's MST from A" });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { A: 'source' },
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: [],
      stack: [],
      distances: step.distances || {},
      visited: step.visited || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
