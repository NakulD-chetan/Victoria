# Serialization — Java vs Kryo

Serialization converts objects into bytes so they can be sent over the network (during shuffle) or stored to disk. The choice of serializer has a **big impact** on Spark performance.

---

## What Is Serialization?

When Spark shuffles data between executors, it needs to:
1. Convert objects to bytes (**serialize**) → write to disk / send over network
2. Convert bytes back to objects (**deserialize**) → read and process

This happens during every shuffle, broadcast, and persist operation.

---

## Java Serialization (Default — Slow)

Spark uses Java serialization by default (`java.io.Serializable`).

### How It Works
Java uses **reflection** at runtime to inspect each object:
- Reads the class structure (field names, types, access modifiers)
- Discovers all fields including private ones
- Writes class metadata + field data into the output

### Why It's Slow
- **Runtime inspection** — Java must analyze each object's structure every time
- **Large payload** — class metadata, field names, and type info all included
- **High CPU usage** — reflection is computationally expensive
- **Heavy GC pressure** — creates many temporary objects during serialization

### Result
- Serialized output is **large** (wastes network bandwidth)
- Serialization/deserialization is **slow** (wastes CPU)
- More **garbage collection** pauses

---

## Kryo Serialization (Faster — Recommended)

Kryo is a high-performance binary serializer.

### How It Works
If you **register your classes**, Kryo already knows their structure at startup:
- Assigns each class a numeric ID
- Writes only the ID + field values (no class metadata)
- Produces compact binary output

### Why It's Faster
- **No runtime reflection** — structure is pre-registered
- **Compact output** — 2–10x smaller than Java serialization
- **Lower CPU** — direct byte writing without inspection
- **Less GC** — fewer temporary objects

### Performance Difference
```
Java:  Object → Reflect → metadata + data → ~500 bytes
Kryo:  Object → ID + data → ~80 bytes

Speed: Kryo is 5–10x faster than Java serialization
```

---

## How to Enable Kryo

### In Code
```python
spark.conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
spark.conf.set("spark.kryo.registrationRequired", "true")
spark.conf.set("spark.kryo.classesToRegister",
    "com.example.MyClass1,com.example.MyClass2")
```

### In spark-submit
```bash
--conf spark.serializer=org.apache.spark.serializer.KryoSerializer
--conf spark.kryo.registrationRequired=true
--conf spark.kryo.classesToRegister=com.example.MyClass1,com.example.MyClass2
```

### Why Register Classes?
When you register classes, Kryo assigns them fixed IDs:
```
MyClass1 → ID: 1
MyClass2 → ID: 2
```

During serialization, Kryo writes just `[1][field_values]` instead of the full class name. This removes reflection completely and produces the smallest possible output.

If `registrationRequired` is `false`, Kryo will still work for unregistered classes but will fall back to writing the full class name (slower, larger output).

---

## When to Use Kryo

- Shuffle-heavy jobs (groupBy, join) — smaller serialized data = faster shuffle
- Jobs with custom classes / case classes
- Broadcast variables (sent to all executors)
- Any job where network transfer is a bottleneck

---

## Quick Comparison

| Feature             | Java Serialization      | Kryo Serialization         |
|---------------------|--------------------------|----------------------------|
| Speed               | Slow                     | 5–10x faster               |
| Output size         | Large (includes metadata)| Compact (ID + values)      |
| Reflection          | Yes (at every call)      | No (if classes registered) |
| Setup               | None (default)           | Need to enable + register  |
| GC impact           | Heavy                    | Light                      |
| CPU usage           | High                     | Low                        |

---

## Key Takeaway

> Java serialization uses **reflection** to inspect objects at runtime — it's slow and produces large output.
> Kryo serialization avoids reflection, uses compact binary format, and is **5–10x faster**.
> Enable Kryo with `spark.serializer=KryoSerializer` and register your classes for maximum performance.
