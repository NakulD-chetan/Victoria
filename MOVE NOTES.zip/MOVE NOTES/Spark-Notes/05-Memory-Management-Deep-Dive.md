# Spark Memory Management — Deep Dive

This is one of the most important topics in Spark. Understanding how memory works helps you debug OOM errors, tune performance, and answer interview questions confidently.

---

## Overview: Two Processes, Two Memory Models

Spark has two main processes:
1. **Driver** — plans and coordinates (runs on one machine)
2. **Executors** — do the actual work (run on multiple machines)

Each has its own memory model. Let's go deep into both.

---

## Part 1: Driver Memory

The Driver doesn't process your data. It only **plans, schedules, and coordinates**. But it still needs memory.

### Driver JVM Heap Memory

**Config**: `spark.driver.memory` (default: 1g)

This memory stores:
- DAG metadata (the plan of your job)
- RDD lineage information
- Stage and task metadata
- Broadcast variables (small datasets sent to all executors)
- Accumulators (counters shared across the cluster)
- Serialization buffers
- Results from `collect()` — **this is a common OOM cause!**

### Driver Memory Overhead

**Config**: `spark.driver.memoryOverhead`

**Default**: `max(384 MB, 10% of spark.driver.memory)`

This is **off-heap memory** used for:
- Network buffers (Netty)
- Native OS libraries
- Python worker memory (when using PySpark)

### Total Driver Memory Formula

```
Total Driver Memory = spark.driver.memory + spark.driver.memoryOverhead

Example:
  spark.driver.memory = 10 GB
  memoryOverhead = max(384 MB, 10% of 10 GB) = 1 GB
  Total = 11 GB
```

### Common Driver OOM Causes
1. Calling `collect()` on a large DataFrame — pulls all data to Driver
2. Too many broadcast variables
3. Very complex DAGs with thousands of stages
4. Large accumulator values

---

## Part 2: Executor Memory (Where the Magic Happens)

Each executor gets its own JVM. The memory inside this JVM is carefully divided.

### The Four Memory Components of an Executor

```
┌─────────────────────────────────────────────────┐
│           TOTAL EXECUTOR CONTAINER               │
│                                                   │
│  ┌───────────────────────────────────────────┐   │
│  │     JVM Heap (spark.executor.memory)       │   │
│  │                                             │   │
│  │  ┌─────────────────────────────────────┐   │   │
│  │  │  Reserved Memory (~300 MB)           │   │   │
│  │  └─────────────────────────────────────┘   │   │
│  │                                             │   │
│  │  ┌─────────────────────────────────────┐   │   │
│  │  │  Usable Memory (heap - 300 MB)       │   │   │
│  │  │                                       │   │   │
│  │  │  ┌──────────┐  ┌──────────────────┐  │   │   │
│  │  │  │  Spark    │  │  User Memory     │  │   │   │
│  │  │  │  Memory   │  │  (40%)           │  │   │   │
│  │  │  │  (60%)    │  │                  │  │   │   │
│  │  │  │           │  │  - UDF objects   │  │   │   │
│  │  │  │ ┌───────┐ │  │  - Custom data   │  │   │   │
│  │  │  │ │Exec   │ │  │    structures   │  │   │   │
│  │  │  │ │Memory │ │  │  - Broadcast     │  │   │   │
│  │  │  │ │(50%)  │ │  │    hash tables  │  │   │   │
│  │  │  │ ├───────┤ │  │                  │  │   │   │
│  │  │  │ │Storage│ │  │                  │  │   │   │
│  │  │  │ │Memory │ │  │                  │  │   │   │
│  │  │  │ │(50%)  │ │  │                  │  │   │   │
│  │  │  │ └───────┘ │  │                  │  │   │   │
│  │  │  └──────────┘  └──────────────────┘  │   │   │
│  │  └─────────────────────────────────────┘   │   │
│  └───────────────────────────────────────────┘   │
│                                                   │
│  ┌───────────────────────────────────────────┐   │
│  │  Overhead Memory (spark.executor.          │   │
│  │  memoryOverhead) - Off-heap                │   │
│  └───────────────────────────────────────────┘   │
│                                                   │
│  ┌───────────────────────────────────────────┐   │
│  │  Off-Heap Memory (optional)                │   │
│  │  spark.memory.offHeap.size                 │   │
│  └───────────────────────────────────────────┘   │
│                                                   │
│  ┌───────────────────────────────────────────┐   │
│  │  PySpark Worker Memory (optional)          │   │
│  │  spark.executor.pyspark.memory             │   │
│  └───────────────────────────────────────────┘   │
│                                                   │
└─────────────────────────────────────────────────┘
```

---

## Part 3: JVM Heap Breakdown (Most Important)

Let's break down what happens inside the JVM heap with a real example.

**Settings**: `spark.executor.memory = 10 GB`

### Step 1: Reserved Memory (300 MB — fixed)

Spark reserves 300 MB for internal objects. You cannot use this.

```
Usable Memory = 10 GB - 300 MB = 9.7 GB
```

### Step 2: Spark Memory vs User Memory

The usable memory is split using `spark.memory.fraction` (default = **0.6**):

```
Spark Memory = 0.6 × 9.7 GB = 5.82 GB
User Memory  = 0.4 × 9.7 GB = 3.88 GB
```

### Step 3: Inside Spark Memory — Execution vs Storage

Spark Memory is further split using `spark.memory.storageFraction` (default = **0.5**):

```
Execution Memory = 0.5 × 5.82 GB = 2.91 GB
Storage Memory   = 0.5 × 5.82 GB = 2.91 GB
```

---

## Part 4: What Each Memory Region Does

### Execution Memory (for active computation)

Used for operations that are **actively running**:
- **Joins** — building hash tables, sorting merge buffers
- **Aggregations** — `groupBy`, `reduceByKey` intermediate results
- **Sorts** — `orderBy` operations
- **Shuffles** — shuffle write buffers before data goes to disk

**When execution memory fills up**: Spark **spills to disk**. This means it writes intermediate data to the executor's local disk (configured via `spark.local.dir`). Spilling is slow but prevents OOM.

### Storage Memory (for cached data)

Used for data you explicitly choose to keep:
- `cache()` results
- `persist()` results
- Broadcast variables received by executors

**When storage memory fills up**: Spark uses **LRU (Least Recently Used) eviction** — it drops the oldest cached blocks. If those blocks are needed later, Spark recomputes them from the DAG lineage.

### User Memory (for your code's objects)

Used for:
- Your UDF (User Defined Function) objects and variables
- Custom data structures you create inside transformations
- Broadcast join hash tables built on the executor side
- RDD conversion buffers
- Any temporary objects created by your code

---

## Part 5: Unified Memory Manager — The Flexible Boundary

This is **the most important concept** to understand about Spark memory.

Before Spark 1.6, execution and storage memory had **fixed** boundaries. If execution needed more memory but storage was empty, tough luck — it couldn't use it.

Since Spark 1.6, Spark uses a **Unified Memory Manager** with flexible boundaries:

### The Rules

```
Rule 1: Execution memory CAN borrow from Storage memory
         → If storage has unused space, execution can take it
         → Execution can even EVICT cached data to free space

Rule 2: Storage memory CANNOT evict Execution memory
         → Active computation always has priority
         → You can never kill a running task to make room for cache

Rule 3: If evicted cached data is needed later
         → Spark recomputes it from the DAG lineage
         → This is safe because of Spark's immutable transformation model
```

### Why Execution Has Priority

Think about it this way:
- **Execution** = a task that is actively running right now. If you kill it, the task fails.
- **Storage** = cached data that can always be recomputed from source. Losing it is slow but not fatal.

So it makes sense that execution always wins.

### Visual: How Memory Borrowing Works

```
Initial State (both 50%):
|████ Execution ████|████ Storage ████|

Scenario 1: Execution needs more, Storage is partially empty:
|████████ Execution ████████|██ Stor ██|
  ← Execution borrows from Storage

Scenario 2: Storage needs more, Execution is partially empty:
|██ Exec ██|████████ Storage ████████|
  ← Storage borrows from Execution

Scenario 3: Both full, Execution needs more:
|████████ Execution ████████|██ Stor ██|
  ← Execution EVICTS storage blocks (LRU)
  ← Evicted cached data will be recomputed if needed

Scenario 4: Both full, Storage needs more:
|████ Execution ████|████ Storage ████|
  ← Storage CANNOT evict execution (task would fail)
  ← Storage request waits or cached data is dropped via LRU
```

---

## Part 6: Executor Overhead Memory

**Config**: `spark.executor.memoryOverhead`

**Default**: `max(384 MB, 10% of spark.executor.memory)`

This is **off-heap memory** (outside the JVM heap) used for:
- Netty network buffers (for shuffle data transfer)
- Native OS libraries
- Thread stacks
- Memory-mapped files

### Total Executor Container Size

```
Total = spark.executor.memory + spark.executor.memoryOverhead
       + spark.memory.offHeap.size (if enabled)
       + spark.executor.pyspark.memory (if using PySpark UDFs)

Example:
  spark.executor.memory = 10 GB
  memoryOverhead = 1 GB (10% of 10 GB)
  Total container = 11 GB (minimum)
```

---

## Part 7: Off-Heap Memory (Optional but Powerful)

**Configs**:
- `spark.memory.offHeap.enabled = true`
- `spark.memory.offHeap.size = 2g`

This is memory managed **outside the JVM heap**, used by Spark's **Tungsten** engine:
- Stores data in compact binary format (UnsafeRow)
- Avoids JVM garbage collection overhead
- Faster serialization/deserialization
- Used for sort and shuffle operations

### When to Enable Off-Heap
- Large-scale jobs with heavy GC pauses
- Jobs that shuffle large amounts of data
- When you want more predictable memory behavior

---

## Part 8: PySpark Memory

**Config**: `spark.executor.pyspark.memory`

When you use Python UDFs in PySpark, Spark spins up Python worker processes alongside the JVM. These Python workers need their own memory.

```
JVM Executor ──────────> Python Worker Process
  (runs Spark engine)      (runs your Python UDF code)
```

If your Python UDFs are memory-heavy (e.g., using pandas, numpy inside UDFs), you need to allocate enough PySpark memory to avoid OOM in the Python worker.

---

## Part 9: Complete Memory Calculation Example

**Cluster Setup**:
- 5 executors
- `spark.executor.memory = 10 GB`
- `spark.executor.memoryOverhead = 1 GB`
- `spark.memory.fraction = 0.6`
- `spark.memory.storageFraction = 0.5`
- `spark.executor.cores = 4`

**Per Executor Breakdown**:

```
Total Container        = 10 + 1 = 11 GB

JVM Heap              = 10 GB
  Reserved            = 300 MB
  Usable              = 9.7 GB

  Spark Memory (60%)  = 5.82 GB
    Execution (50%)   = 2.91 GB   ← joins, sorts, shuffles
    Storage (50%)     = 2.91 GB   ← cache, persist

  User Memory (40%)   = 3.88 GB   ← UDFs, data structures

Overhead (off-heap)   = 1 GB      ← network buffers, native libs
```

**Total cluster memory** = 5 executors × 11 GB = **55 GB**

---

## Part 10: Common Memory Problems and Solutions

### Problem 1: OOM on Executor

**Symptoms**: `java.lang.OutOfMemoryError: Java heap space`

**Causes**:
- Partitions too large (each task processing too much data)
- Too many cached DataFrames filling storage memory
- Skewed data causing one executor to get most records
- UDFs creating too many objects

**Solutions**:
- Increase `spark.executor.memory`
- Repartition data into more partitions (smaller chunks per task)
- Fix data skew with salting
- Use `unpersist()` to free cached data
- Use fewer, more efficient UDFs

### Problem 2: OOM on Driver

**Symptoms**: Driver process crashes

**Causes**:
- Calling `collect()` on large DataFrames
- Too many broadcast variables
- Extremely complex DAG (thousands of stages)

**Solutions**:
- Avoid `collect()` — use `take()` or `show()` instead
- Increase `spark.driver.memory`
- Reduce complexity of the job

### Problem 3: Excessive GC (Garbage Collection)

**Symptoms**: Tasks take long, Spark UI shows high GC time

**Causes**:
- Too many Java objects in memory
- JVM heap too small for the workload

**Solutions**:
- Enable off-heap memory (Tungsten)
- Use `MEMORY_ONLY_SER` storage level (less objects, more compact)
- Increase executor memory
- Use Kryo serialization (smaller objects)

### Problem 4: Shuffle Spill to Disk

**Symptoms**: Spark UI shows "Spill (Disk)" in stage details

**Causes**:
- Execution memory not enough for shuffle/sort operations
- Partitions too large

**Solutions**:
- Increase `spark.executor.memory`
- Increase shuffle partitions (`spark.sql.shuffle.partitions`)
- Use broadcast joins to avoid shuffle entirely

---

## Part 11: Memory Configuration Properties (Quick Reference)

| Property | Default | Purpose |
|----------|---------|---------|
| `spark.driver.memory` | 1g | Driver JVM heap |
| `spark.driver.memoryOverhead` | max(384MB, 10%) | Driver off-heap |
| `spark.executor.memory` | 1g | Executor JVM heap |
| `spark.executor.memoryOverhead` | max(384MB, 10%) | Executor off-heap |
| `spark.memory.fraction` | 0.6 | % of usable heap for Spark (exec + storage) |
| `spark.memory.storageFraction` | 0.5 | % of Spark memory reserved for storage |
| `spark.memory.offHeap.enabled` | false | Enable off-heap memory |
| `spark.memory.offHeap.size` | 0 | Off-heap memory size |
| `spark.executor.pyspark.memory` | 0 | Python worker memory |
| `spark.executor.cores` | 1 | Cores per executor |

---

## Part 12: How Memory Flows During a Shuffle (Real Example)

Let's trace what happens in memory during a `groupBy().count()`:

```
1. Task reads partition data into EXECUTION MEMORY
2. For each row, Spark computes hash(groupBy_key) % shuffle_partitions
3. Rows are sorted by target partition ID in execution memory
4. If execution memory fills up → SPILL to local disk
5. Sorted data is written to shuffle files on local disk (SHUFFLE WRITE)
6. Next stage tasks start (SHUFFLE READ)
7. Each task fetches its partition data from ALL executors over network
8. Fetched data goes into EXECUTION MEMORY
9. Aggregation (count) runs in execution memory
10. Results returned to Driver
```

At step 4, if execution needs more memory:
- First: tries to borrow from storage memory
- If storage has cached data: evicts LRU cached blocks
- If still not enough: spills to disk
- Spilled data is later merged during shuffle write

---

## Key Takeaway

> Spark's Unified Memory Manager splits executor memory into **Execution** (for active computation) and **Storage** (for cached data), with a **flexible boundary** where execution can borrow from storage but not vice versa.
>
> The formula: `Usable = Heap - 300MB`, then `Spark Memory = 60%`, split 50-50 between Execution and Storage.
>
> Execution always has priority because a running task cannot be killed, while cached data can always be recomputed.
