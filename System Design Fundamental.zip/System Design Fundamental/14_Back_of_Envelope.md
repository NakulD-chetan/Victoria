# Back of the Envelope Estimation — Numbers Jo Yaad Rakhne Hain

> **Estimation = Interview mein quickly calculate karo ki system feasible hai ya nahi**
> "100M users × 1KB = 100GB" — aise numbers turant nikaal sako toh interviewer impress hoga!

---

## Kyu Zaroori Hai? (Interview Mein Numbers Batane Padte Hain)

| Reason | Explanation |
|--------|-------------|
| **Feasibility Check** | System build karne se pehle pata chal jata hai — yeh scale pe possible hai ya nahi |
| **Resource Planning** | Kitne servers, kitna storage, kitna bandwidth — sab estimate ho jata hai |
| **Interviewer Impression** | Numbers turant bolo = structured thinking = hire signal |
| **Trade-off Discussion** | "100M users = 100GB" bolke aage scaling discussion start kar sakte ho |
| **Reality Check** | Over-engineering rokta hai — simple numbers se pata chal jata hai kya chahiye |

**Interview Tip:** Agar interviewer "scale" puche toh turant DAU → QPS → Storage nikaal ke bolo. Silence mat karo!

---

## Power of 2 Table — Yaad Kar Lo!

| Power | Value | Approx | Use Case |
|-------|-------|--------|----------|
| 2^10 | 1,024 | 1K | Small data, config |
| 2^20 | 1,048,576 | 1M | Medium data, 1M users |
| 2^30 | 1,073,741,824 | 1G | Large data, 1B bytes |
| 2^40 | 1,099,511,627,776 | 1T | Very large, petabytes |
| 2^50 | ~1.1 × 10^15 | 1P | Petabyte scale |

**Memory Trick:** 10→K, 20→M, 30→G, 40→T — har 10 power = next unit!

```
2^10 ≈ 10^3  (1K)
2^20 ≈ 10^6  (1M)
2^30 ≈ 10^9  (1G)
2^40 ≈ 10^12 (1T)
```

---

## Latency Numbers Every Programmer Should Know

> **Jeff Dean's famous numbers — interview mein yeh reference de sakte ho!**

| Operation | Latency | Human Scale |
|-----------|---------|-------------|
| L1 cache reference | 0.5 ns | — |
| L2 cache reference | 7 ns | — |
| Main memory (RAM) | 100 ns | — |
| SSD random read | 100 μs (0.1 ms) | — |
| HDD seek | 10 ms | — |
| Network, same datacenter | 0.5 ms | — |
| Network, cross-country | 50 ms | — |
| Network, round-trip world | 150 ms | — |

**Simplified for Interview:**

| Tier | Latency | When to mention |
|------|---------|-----------------|
| **Memory** | ~100 ns | Cache vs DB discussion |
| **SSD** | ~100 μs | Disk I/O bottleneck |
| **HDD** | ~10 ms | Legacy systems |
| **Same DC** | ~0.5 ms | Microservices latency |
| **Cross-country** | ~50 ms | CDN, geo-distribution |
| **Round-world** | ~150 ms | Global systems |

**Key Insight:** RAM se SSD = 1000x slower. SSD se network = 5x slower. **Network is often the bottleneck!**

---

## Common Data Sizes

| Data Type | Size | Notes |
|-----------|------|-------|
| Text message (SMS) | ~100 bytes | Short text |
| Tweet | ~250 bytes | 280 chars + metadata |
| Email (text) | ~10 KB | With headers |
| User profile record | ~1 KB | Name, email, etc. |
| Image (thumbnail) | ~50 KB | Compressed |
| Image (full, compressed) | ~300 KB | JPEG |
| Image (full, raw) | ~3 MB | Uncompressed |
| Video (1 min, 720p) | ~50 MB | Compressed |
| Video (1 min, 1080p) | ~100 MB | Compressed |
| Audio (1 min, MP3) | ~1 MB | Compressed |

**Memory Tricks:**
- Tweet ≈ 250 bytes (280 chars limit)
- Image ≈ 300KB (3 × 10^5)
- 1 min video ≈ 50MB (5 × 10^7)
- User record ≈ 1KB

---

## QPS Calculation — Step by Step

### Formula Tree

```
DAU (Daily Active Users)
    ↓
× requests_per_user_per_day
    ↓
÷ 86400 (seconds in a day)
    ↓
= Average QPS

Average QPS × 2 to 5 = Peak QPS
```

### Main Formula

```
Average QPS = DAU × requests_per_user / 86400
Peak QPS = Average QPS × 2 to 5 (typically 3)
```

### Why 86400?

- 1 day = 24 × 60 × 60 = 86,400 seconds
- DAU = users per day
- Requests per user = har user kitna request karta hai

### Example

| Scenario | DAU | Req/User | Avg QPS | Peak QPS (×3) |
|----------|-----|----------|---------|---------------|
| Light | 1M | 10 | 116 | 350 |
| Medium | 10M | 50 | 5,787 | 17,361 |
| Heavy | 100M | 100 | 115,740 | 347,222 |
| Extreme | 1B | 200 | 2.3M | 6.9M |

**Interview Tip:** 86400 ≈ 10^5. So DAU × req / 10^5 = rough QPS. 100M × 10 / 10^5 = 10,000 QPS.

---

## Storage Estimation

### Formula

```
Total Storage = Users × data_per_user × retention_factor
```

**Retention:** 1 year = 365 days, 5 years = 1825 days

### Per-User Data Examples

| System | Data per user | Unit |
|--------|---------------|------|
| URL Shortener | ~100 bytes | per link |
| Twitter | ~500 bytes | per tweet |
| Instagram | ~500 KB | per photo |
| YouTube | ~50 MB | per min video |
| Chat | ~100 bytes | per message |

### Storage Calculation Tree

```
Daily new data = DAU × new_data_per_user_per_day
    ↓
Total storage = Daily new data × retention_days
    ↓
Add replication factor (×2 or ×3 for redundancy)
```

---

## Bandwidth Estimation

### Formula

```
Bandwidth = QPS × average_response_size
```

**Units:** 
- QPS in requests/second
- Response size in bytes
- Bandwidth = bytes/second = B/s (or MB/s, GB/s)

### Conversion

```
1 Gbps = 125 MB/s (approx)
1 MB/s = 8 Mbps
```

### Example

| QPS | Response Size | Bandwidth |
|-----|---------------|-----------|
| 10,000 | 10 KB | 100 MB/s |
| 100,000 | 1 KB | 100 MB/s |
| 1,000 | 1 MB | 1 GB/s |

---

## Server Estimation

### Rule of Thumb

| Workload Type | QPS per server | Notes |
|---------------|----------------|-------|
| Simple API (stateless) | 1,000 - 10,000 | Depends on logic |
| Heavy computation | 100 - 1,000 | CPU bound |
| DB read-heavy | 500 - 2,000 | Connection pool limit |
| DB write-heavy | 100 - 500 | Write bottleneck |
| Video streaming | 50 - 200 | Bandwidth bound |

### Formula

```
Servers needed = Peak QPS / QPS_per_server
```

**Always add 20-30% for:**
- Failover capacity
- Traffic spikes
- Maintenance

---

## Practice Problems — Solve Karo!

### Problem 1: Twitter

**Given:** 300M DAU, 5 tweets per user per day

**Calculate:**
1. **QPS (writes):** 300M × 5 / 86400 = 17,361 writes/sec
2. **Storage (1 year):** 300M × 5 × 365 × 500 bytes = 273.75 TB
3. **Read QPS:** Assume 10× writes = 173,610 reads/sec

**Interview Answer:** "Roughly 20K write QPS, 200K read QPS, ~300TB storage per year for tweets."

---

### Problem 2: Instagram

**Given:** 500M DAU, 2 photos per user per day

**Calculate:**
1. **Storage (1 year):** 500M × 2 × 365 × 500KB = 182.5 PB
2. **Bandwidth (if 100M views/day):** 100M × 500KB / 86400 = 578 MB/s
3. **Write QPS:** 500M × 2 / 86400 = 11,574/sec

**Interview Answer:** "~180 PB storage per year, ~12K photo uploads per second. Bandwidth depends on view distribution."

---

### Problem 3: YouTube

**Given:** 2B DAU, 5 videos watched per user per day (avg 5 min each)

**Calculate:**
1. **Video views:** 2B × 5 = 10B views/day
2. **Data per view:** 5 min × 50 MB/min = 250 MB
3. **Bandwidth:** 10B × 250 MB / 86400 = 28.9 PB/day = 335 TB/s (peak)

**Simplified:** Peak bandwidth ~300-400 TB/s (with caching/CDN, actual origin much less)

**Interview Answer:** "10B video views daily, ~250MB per view. CDN handles most; origin serves cache misses."

---

### Problem 4: Chat (WhatsApp-style)

**Given:** 1B users, 50 messages per user per day

**Calculate:**
1. **Message QPS:** 1B × 50 / 86400 = 578,704 messages/sec
2. **Storage (1 year):** 1B × 50 × 365 × 100 bytes = 1.825 PB
3. **With metadata (500 bytes):** 1B × 50 × 365 × 500 = 9.125 PB

**Interview Answer:** "~600K messages per second, ~10 PB storage per year with metadata."

---

## Quick Reference Card

| What | Formula |
|------|---------|
| **Average QPS** | DAU × req_per_user / 86400 |
| **Peak QPS** | Avg QPS × 2 to 5 |
| **Storage** | Users × data_per_user × days × replication |
| **Bandwidth** | QPS × response_size |
| **Servers** | Peak QPS / QPS_per_server × 1.3 |

### Round Numbers to Use

| Number | Use |
|--------|-----|
| 86400 | Seconds per day |
| 10^5 | Approx seconds per day (quick calc) |
| 2.5 × 10^7 | Seconds per year |
| 3 × 10^8 | Approx world population |
| 1 KB | User record |
| 300 KB | Image |
| 50 MB | 1 min video |

---

## Common Mistakes in Estimation

| Mistake | Why Bad | Fix |
|---------|---------|-----|
| **No assumptions stated** | Interviewer confused | "Let me assume 100M DAU, 10 requests/user..." |
| **Exact numbers** | Unrealistic | Use round numbers: 100M not 97,432,891 |
| **Forgetting peak** | Under-provision | Peak = 3-5× average |
| **Ignoring replication** | Single point failure | Storage × 2 or 3 |
| **Wrong units** | 1TB vs 1PB confusion | Double-check: KB, MB, GB, TB, PB |
| **No retention** | Storage underestimate | "1 year" or "5 years" specify karo |
| **Read:Write ratio** | Wrong QPS | Reads usually 10-100× writes |
| **Bytes vs bits** | Bandwidth wrong | 1 byte = 8 bits |

---

## Interview Tips for Estimation

### Do's

1. **State assumptions loudly:** "Assuming 50M DAU, 20 requests per user..."
2. **Round numbers:** 100M, 1B — easy to calculate
3. **Show steps:** DAU → QPS → Storage — step by step
4. **Sanity check:** "100M users × 1KB = 100GB — reasonable for user DB"
5. **Add buffer:** "Plus 30% for spikes and failover"

### Don'ts

1. **Don't freeze:** Agar exact number na aaye, approximate bolo
2. **Don't over-precision:** "17,361.23 QPS" — no! "~20K QPS" — yes!
3. **Don't skip:** Estimation skip mat karo — interviewer expect karta hai
4. **Don't argue:** Agar interviewer different number bole, accept and move on

### Phrase Templates

- "Let me do a quick back-of-envelope..."
- "Assuming X users and Y requests per day..."
- "That gives us roughly Z QPS, which means..."
- "For storage, we're looking at approximately..."
- "Does this scale seem reasonable for our use case?"

---

## Final Checklist — Interview Se Pehle

- [ ] Power of 2 (2^10 to 2^40) yaad hai?
- [ ] Latency numbers (L1, RAM, SSD, Network) yaad hai?
- [ ] Data sizes (tweet, image, video) yaad hai?
- [ ] QPS formula: DAU × req / 86400
- [ ] Peak = Avg × 3
- [ ] Storage = Users × data × days
- [ ] Bandwidth = QPS × size
- [ ] 86400 ≈ 10^5 for quick calc

**Yaad rakhna:** Estimation perfect nahi hona chahiye — **structured approach** dikhana chahiye!

---

## Extra Practice — Mental Math Drills

**Interview mein calculator nahi — mental math!**

| Drill | Trick | Example |
|-------|-------|---------|
| 100M / 86400 | 100M ≈ 10^8, 86400 ≈ 10^5 → 10^3 = 1000 | 100M users, 1 req/day = 1K QPS |
| 1B × 1KB | 1B = 10^9, 1KB = 10^3 → 10^12 = 1TB | 1B user records = 1TB |
| 500M × 2 × 365 | 500M × 730 ≈ 365B | 500M users, 2 items/day, 1 year |
| Peak multiplier | Avg × 3 = safe, × 5 = conservative | 10K avg → 30K-50K peak |

---

## Data Size Quick Reference (Copy-Paste for Mind)

```
Tweet      = 250 B
SMS        = 100 B
User       = 1 KB
Image      = 300 KB
1min Video = 50 MB
1min Audio = 1 MB
```

---

## Seconds Conversion Table

| Period | Seconds | Use |
|--------|---------|-----|
| 1 minute | 60 | — |
| 1 hour | 3,600 | — |
| 1 day | 86,400 | QPS calc |
| 1 month | ~2.6M | Monthly estimates |
| 1 year | ~31.5M | Yearly storage |
