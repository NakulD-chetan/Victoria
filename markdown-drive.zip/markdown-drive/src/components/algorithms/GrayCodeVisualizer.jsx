import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function gray(n) {
  return n ^ (n >> 1);
}

function toBits(val, width) {
  return Array.from({ length: width }, (_, i) => ((val >> (width - 1 - i)) & 1 ? '1' : '0'));
}

function diffBit(prev, cur, width) {
  for (let i = 0; i < width; i++) {
    const a = (prev >> (width - 1 - i)) & 1;
    const b = (cur >> (width - 1 - i)) & 1;
    if (a !== b) return i;
  }
  return -1;
}

function generateSteps(width = 4) {
  const steps = [];
  const total = 2 ** width;
  let prev = 0;
  steps.push({ type: 'code', i: 0, val: gray(0), cells: toBits(gray(0), width), flip: -1, title: 'G(0)' });
  for (let i = 1; i < total; i++) {
    const cur = gray(i);
    const flip = diffBit(prev, cur, width);
    steps.push({
      type: 'code',
      i,
      val: cur,
      cells: toBits(cur, width),
      flip,
      title: `G(${i})=${cur}, flip bit ${flip}`,
    });
    prev = cur;
  }
  steps.push({
    type: 'done',
    i: total,
    val: gray(total - 1),
    cells: toBits(gray(total - 1), width),
    flip: -1,
    title: '✓ Gray code sequence',
  });
  return steps;
}

export default function GrayCodeVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(4);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Reflective Gray code: i ^ (i>>1)' });
    canvasRef.current?.setState({
      cells: steps[0].cells,
      colors: {},
      title: steps[0].title,
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.flip >= 0) colors[step.flip] = 'swap';
    if (step.type === 'done') for (let i = 0; i < step.cells.length; i++) colors[i] = 'sorted';
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.title || step.type });
    canvasRef.current?.setState({
      cells: step.cells,
      colors,
      title: step.title,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
