import { useRef, useEffect, useCallback, useState } from 'react';
import { TokenBucket } from '../../lib/algorithms/token-bucket';
import { useAlgorithmStore } from '../../stores/algorithm-store';
import TokenBucketCanvas from './TokenBucketCanvas';
import ControlBar from './ControlBar';
import CodePanel from './CodePanel';
import StatsPanel from './StatsPanel';
import EventLog from './EventLog';

export default function TokenBucketVisualizer({ config }) {
  const bucketRef = useRef(new TokenBucket(10, 2));
  const canvasRef = useRef(null);
  const autoIntervalRef = useRef(null);
  const codeStepTimeoutRef = useRef(null);

  const {
    capacity, refillRate, cost, autoRate, autoActive,
    allowed, denied, total, currentStep,
    addLog, recordAllow, recordDeny, setStep, reset, startTime,
  } = useAlgorithmStore();

  const [codeOpen, setCodeOpen] = useState(false);

  useEffect(() => { bucketRef.current.capacity = capacity; bucketRef.current.tokens = Math.min(bucketRef.current.tokens, capacity); }, [capacity]);
  useEffect(() => { bucketRef.current.rate = refillRate; }, [refillRate]);

  const highlightCodeSteps = useCallback((isAllowed, result) => {
    if (codeStepTimeoutRef.current) clearTimeout(codeStepTimeoutRef.current);
    const seq = isAllowed ? config.stepsAllow : config.stepsDeny;
    let i = 0;
    function next() {
      if (i >= seq.length) { setTimeout(() => { setStep(null); }, 800); return; }
      const sid = seq[i];
      setStep(sid);
      i++;
      codeStepTimeoutRef.current = setTimeout(next, 170);
    }
    next();
  }, [config, setStep]);

  const sendRequest = useCallback(() => {
    const result = bucketRef.current.tryConsume(cost, performance.now());
    const t = ((performance.now() - startTime) / 1000).toFixed(1);
    if (result.allowed) {
      recordAllow();
      addLog({ time: t + 's', type: 'allow', message: `\u2713 ALLOW cost=${cost} (${result.before.toFixed(1)}\u2192${result.after.toFixed(1)})` });
      canvasRef.current?.addAnim('req-allow', 900);
    } else {
      recordDeny();
      addLog({ time: t + 's', type: 'deny', message: `\u2717 DENY need ${cost}, have ${result.before.toFixed(1)}` });
      canvasRef.current?.addAnim('req-deny', 800);
    }
    highlightCodeSteps(result.allowed, result);
  }, [cost, startTime, recordAllow, recordDeny, addLog, highlightCodeSteps]);

  const handleBurst = useCallback(() => { let i = 0; const iv = setInterval(() => { if (i++ >= 5) { clearInterval(iv); return; } sendRequest(); }, 80); }, [sendRequest]);

  const handleReset = useCallback(() => {
    bucketRef.current.capacity = capacity; bucketRef.current.rate = refillRate; bucketRef.current.reset();
    reset(); addLog({ time: '0.0s', type: 'refill', message: 'Bucket reset to full' });
  }, [capacity, refillRate, reset, addLog]);

  useEffect(() => {
    if (autoActive) { autoIntervalRef.current = setInterval(sendRequest, 1000 / autoRate); }
    else if (autoIntervalRef.current) { clearInterval(autoIntervalRef.current); autoIntervalRef.current = null; }
    return () => { if (autoIntervalRef.current) clearInterval(autoIntervalRef.current); };
  }, [autoActive, autoRate, sendRequest]);

  useEffect(() => {
    function handleKeyDown(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'Space') { e.preventDefault(); sendRequest(); }
      if (e.key === 'b' || e.key === 'B') handleBurst();
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [sendRequest, handleBurst, handleReset]);

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <StatsPanel tokens={bucketRef.current.tokens} capacity={capacity} allowed={allowed} denied={denied} total={total} />
      </div>

      <TokenBucketCanvas ref={canvasRef} bucketRef={bucketRef} />
      <ControlBar onSendRequest={sendRequest} onBurst={handleBurst} onReset={handleReset} />

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" />
              <polyline points="8 6 2 12 8 18" />
            </svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ transform: codeOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
              <polyline points="6 9 12 15 18 9" />
            </svg>
          </button>
          {codeOpen && (
            <div className="dc-visualizer__code-wrap">
              <CodePanel code={config.code} activeStep={currentStep} languages={config.meta.languages} />
            </div>
          )}
        </div>
        <div className="dc-visualizer__log-col">
          <EventLog />
        </div>
      </div>

      <div className="dc-visualizer__shortcuts">
        <kbd>Space</kbd> Send <kbd>B</kbd> Burst <kbd>R</kbd> Reset
      </div>
    </div>
  );
}
