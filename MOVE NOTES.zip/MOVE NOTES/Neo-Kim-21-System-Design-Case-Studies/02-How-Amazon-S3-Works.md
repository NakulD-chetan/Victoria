# How Amazon S3 Works - System Design

> Source: [https://newsletter.systemdesign.one/p/s3-architecture](https://newsletter.systemdesign.one/p/s3-architecture)

## One-Line Summary

Amazon S3 is an object storage service that handles 100 million requests/second by separating metadata from file content and using parallel reads with erasure coding.

## Key Requirements

### Functional

- Store and retrieve unstructured data (files, images, logs, backups)
- Each object identified by a unique key
- REST API for upload, download, delete, list operations
- Support for very large objects (up to 5 TB)
- Versioning and lifecycle policies

### Non-Functional

- Extreme durability (99.999999999% -- eleven 9s)
- High availability across regions
- Handle 100 million+ requests per second
- Cost-effective storage at massive scale
- Low latency for data retrieval

## High-Level Architecture

```
Client (REST API)
       |
   Web Server Layer
       |
  +---------+-----------+
  |                     |
Metadata Store      File Storage
(Key-Value DB       (Hard Disks with
 + Cache)            ShardStore)
```

**Key insight:** Metadata and file content are stored **separately** -- this allows each to scale independently.

### How It Works:

1. Client sends request via **REST API** to web servers
2. Web servers look up **metadata** (key-value DB) to find where data lives
3. Metadata is **cached** for fast repeated access
4.  
5. Each component is built from many **microservices** communicating via API contracts

## Core Components Deep Dive

### 1. Web Server Layer

- Receives REST API requests (PUT, GET, DELETE)
- Routes to appropriate backend services
- Handles authentication and authorization

### 2. Metadata Store

- **Key-value database** mapping object keys to storage locations
- Heavy caching layer for high availability
- Stored separately from actual data for independent scaling

### 3. ShardStore (File Storage Engine)

- Variant of **LSM (Log-Structured Merge) tree** data structure
- Optimized for hard disk performance
- Organizes data efficiently on mechanical drives



## **ShardStore & LSM Trees - Deep Explanation**

### **The Problem First**

Amazon S3 stores files on **mechanical hard disks** (HDDs) because they're cheap at massive scale. But HDDs have a fundamental problem:

HDD has a spinning platter + moving read/write head

To read/write data:

  1. HEAD moves to correct track    → "Seek time" (~5-10ms)

  2. Platter ROTATES to correct spot → "Rotation time" (~2-5ms)

  3. Data is read/written            → "Transfer time" (fast for sequential)

Random reads/writes = SLOW (head jumps around)

Sequential reads/writes = FAST (head stays in place, data flows)

So the challenge is: **how do you make an HDD-based storage engine fast when you have billions of random read/write requests?**

---

### **What is an LSM Tree?**

LSM stands for **Log-Structured Merge tree**. It's a data structure designed to make **writes extremely fast** by converting random writes into sequential writes.

#### **Step-by-step: How LSM Tree Works**

WRITE PATH (fast):

Step 1: Write comes in → goes to IN-MEMORY buffer (called "MemTable")

        - MemTable is a sorted tree (like Red-Black tree) in RAM

        - RAM writes are instant (microseconds)

        - This is why writes are fast!

Step 2: When MemTable is full → FLUSH it to disk as a sorted file

        - This file is called an "SSTable" (Sorted String Table)

        - Writing a sorted file = SEQUENTIAL write = fast on HDD

        - Each SSTable is immutable (never modified after creation)

Step 3: Over time, many SSTables accumulate on disk

        - They are organized in "levels" (Level 0, Level 1, Level 2...)

        - Level 0 = newest data, Level N = oldest data

Step 4: COMPACTION (background merge)

        - Periodically merge smaller SSTables into larger ones

        - Remove duplicates and deleted entries

        - Like merging two sorted lists → still sequential I/O!

Visual:

WRITES:

  ┌─────────────────┐

  │   MemTable (RAM) │  ← All writes go here first (fast!)

  │   [sorted tree]  │

  └────────┬─────────┘

           │ flush when full

           ▼

  ┌─────────────────┐

  │ Level 0 (Disk)  │  SSTable_1, SSTable_2, SSTable_3...

  └────────┬─────────┘

           │ compact (merge)

           ▼

  ┌─────────────────┐

  │ Level 1 (Disk)  │  Larger merged SSTables

  └────────┬─────────┘

           │ compact (merge)

           ▼

  ┌─────────────────┐

  │ Level 2 (Disk)  │  Even larger merged SSTables

  └─────────────────┘

#### **Read Path**

READ PATH (slightly slower):

Step 1: Check MemTable (RAM) → if found, return immediately

Step 2: Check Level 0 SSTables (newest files on disk)

Step 3: Check Level 1, Level 2... (older files)

Optimization: Each SSTable has a BLOOM FILTER

  - A tiny in-memory structure that says:

    "This key is DEFINITELY NOT in this file" (skip it!)

    or "This key MIGHT be in this file" (check it)

  - Avoids reading unnecessary SSTables from disk

---

### **Why LSM is Perfect for HDDs**


| **Operation**       | **Traditional B-Tree (like Postgres)** | **LSM Tree**                                 |
| ------------------- | -------------------------------------- | -------------------------------------------- |
| **Write**           | Random I/O (update page in-place)      | Sequential I/O (append to log, flush sorted) |
| **Read**            | 1 lookup (B-tree index)                | May check multiple levels                    |
| **HDD performance** | Bad (random seeks)                     | Great (sequential writes)                    |
| **Best for**        | Read-heavy workloads                   | Write-heavy workloads                        |


S3 gets **billions of writes** (object uploads) daily. LSM's sequential write pattern aligns perfectly with HDD physics.

  


### 4. Parallel Reads Across Disks

- **Problem**: Larger hard disk ≠ faster reads (seek + rotation time stays constant)
- **Solution**: Replicate data across many disks, read in parallel
- This gives **higher throughput** (more MB/s)
- Also prevents **hot spots** (load spread across disks)

### 5. Erasure Coding

- Full replication is expensive (3x storage = 3x cost)
- **Erasure coding** = replicate data with much smaller storage overhead
- Splits data into fragments, adds parity (recovery) fragments
- Can reconstruct original data even if some fragments are lost
- Provides same durability as full replication at a fraction of the cost

## Key Design Decisions


| Decision                    | Why                                              |
| --------------------------- | ------------------------------------------------ |
| Separate metadata from data | Scale independently, different access patterns   |
| REST API                    | Universal, simple, works with any HTTP client    |
| Hard disks (not SSDs)       | Cost effective at massive scale                  |
| ShardStore (LSM tree)       | Better performance on HDDs for sequential writes |
| Erasure coding              | Same durability as 3x replication at lower cost  |
| Parallel reads across disks | Higher throughput, no hot spots                  |
| Heavy caching of metadata   | Most requests are reads, cache hits are fast     |


## Data Model

```
Object:
  - bucket: string       (container for objects)
  - key: string          (unique identifier within bucket)
  - value: bytes         (actual file content, up to 5 TB)
  - metadata: map        (content-type, custom headers, etc.)
  - version_id: string   (if versioning enabled)
  - storage_class: enum  (Standard, Infrequent, Glacier, etc.)

Metadata Index:
  - key -> {disk_locations[], fragment_info, size, checksum}
```

## Scaling Strategies

1. **Separate metadata and data paths** -- each scales independently
2. **Distribute data across many disks** with erasure coding
3. **Parallel reads** from multiple disks for high throughput
4. **Caching layer** for frequently accessed metadata
5. **Storage classes** (Standard, Infrequent Access, Glacier) for cost optimization
6. **Microservices architecture** -- each component scales independently

## Interview Tips

- Emphasize the **separation of metadata and data** -- this is the core architecture insight
- Explain why **hard disk throughput doesn't scale with size** (seek + rotation time constant)
- Know **erasure coding** vs full replication (cost vs durability tradeoff)
- Mention the **eleven 9s durability** number
- S3 is the backbone of most cloud architectures -- mention how other services (Lambda, EMR, Athena) depend on it
- If asked about consistency: S3 now provides **strong read-after-write consistency**

## Quick Revision (5 bullet points)

1. **S3 separates metadata from file data** -- metadata in key-value DB with cache, files on hard disks with ShardStore
2. **Hard disk size doesn't improve throughput** -- seek/rotation time stays constant; solution is parallel reads across many disks
3. **Erasure coding** provides same durability as full replication but at much lower storage cost
4. **100M+ requests/second** handled through microservices architecture with independent scaling
5. **REST API** interface with storage classes (Standard, IA, Glacier) for cost optimization at different access patterns

