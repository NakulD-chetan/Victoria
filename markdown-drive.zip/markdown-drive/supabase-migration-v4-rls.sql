-- ─────────────────────────────────────────────────────────────────────────
-- v4 RLS — apply AFTER v4-collab. All multi-user access is gated through
-- public.effective_role(); the anon key alone never grants anything beyond
-- public lookup endpoints.
-- ─────────────────────────────────────────────────────────────────────────

-- ── PROFILES ─────────────────────────────────────────────────────────────
alter table public.profiles enable row level security;

drop policy if exists profiles_self_read   on public.profiles;
drop policy if exists profiles_co_read     on public.profiles;
drop policy if exists profiles_self_update on public.profiles;

-- Users can always read their own profile.
create policy profiles_self_read on public.profiles
  for select using (id = auth.uid());

-- Co-members of any shared vault can read each other's display info.
create policy profiles_co_read on public.profiles
  for select using (
    exists (
      select 1
        from public.vault_members vm_self
        join public.vault_members vm_other on vm_other.vault_id = vm_self.vault_id
       where vm_self.user_id  = auth.uid()
         and vm_other.user_id = profiles.id
    )
  );

create policy profiles_self_update on public.profiles
  for update using (id = auth.uid()) with check (id = auth.uid());

-- ── VAULTS ───────────────────────────────────────────────────────────────
alter table public.vaults enable row level security;

drop policy if exists vaults_select on public.vaults;
drop policy if exists vaults_insert on public.vaults;
drop policy if exists vaults_update on public.vaults;
drop policy if exists vaults_delete on public.vaults;

create policy vaults_select on public.vaults
  for select using (
    exists (select 1 from public.vault_members vm
              where vm.vault_id = vaults.id and vm.user_id = auth.uid())
  );

create policy vaults_insert on public.vaults
  for insert with check (owner_id = auth.uid());

create policy vaults_update on public.vaults
  for update using (
    exists (select 1 from public.vault_members vm
              where vm.vault_id = vaults.id and vm.user_id = auth.uid() and vm.role = 'owner')
  );

create policy vaults_delete on public.vaults
  for delete using (owner_id = auth.uid());

-- ── VAULT MEMBERS ────────────────────────────────────────────────────────
alter table public.vault_members enable row level security;

drop policy if exists vm_select on public.vault_members;
drop policy if exists vm_insert on public.vault_members;
drop policy if exists vm_update on public.vault_members;
drop policy if exists vm_delete on public.vault_members;

-- Any vault member can see the member list.
create policy vm_select on public.vault_members
  for select using (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_members.vault_id and me.user_id = auth.uid())
  );

-- Only owners (or the auto-insert trigger via security definer) add members.
create policy vm_insert on public.vault_members
  for insert with check (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_members.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

create policy vm_update on public.vault_members
  for update using (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_members.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

-- A user can remove themselves; owners can remove anyone (but not the last owner).
create policy vm_delete on public.vault_members
  for delete using (
    user_id = auth.uid()
    or exists (select 1 from public.vault_members me
                 where me.vault_id = vault_members.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

-- ── VAULT INVITES ────────────────────────────────────────────────────────
alter table public.vault_invites enable row level security;

drop policy if exists vi_select on public.vault_invites;
drop policy if exists vi_insert on public.vault_invites;
drop policy if exists vi_update on public.vault_invites;
drop policy if exists vi_delete on public.vault_invites;

-- Vault members see their vault's invites.
create policy vi_select on public.vault_invites
  for select using (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_invites.vault_id and me.user_id = auth.uid())
  );

-- Only owners create invites.
create policy vi_insert on public.vault_invites
  for insert with check (
    invited_by = auth.uid()
    and exists (select 1 from public.vault_members me
                  where me.vault_id = vault_invites.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

-- Owners can revoke / extend.
create policy vi_update on public.vault_invites
  for update using (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_invites.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

create policy vi_delete on public.vault_invites
  for delete using (
    exists (select 1 from public.vault_members me
              where me.vault_id = vault_invites.vault_id and me.user_id = auth.uid() and me.role = 'owner')
  );

-- ── FOLDERS ──────────────────────────────────────────────────────────────
alter table public.folders enable row level security;

drop policy if exists folders_select on public.folders;
drop policy if exists folders_insert on public.folders;
drop policy if exists folders_update on public.folders;
drop policy if exists folders_delete on public.folders;

create policy folders_select on public.folders
  for select using (public.effective_role(vault_id, 'folder', id) is not null);

create policy folders_insert on public.folders
  for insert with check (
    public.effective_role(vault_id, 'folder', coalesce(parent_id, vault_id)) in ('owner','editor')
  );

create policy folders_update on public.folders
  for update using (public.effective_role(vault_id, 'folder', id) in ('owner','editor'));

create policy folders_delete on public.folders
  for delete using (public.effective_role(vault_id, 'folder', id) in ('owner','editor'));

-- ── NOTES ────────────────────────────────────────────────────────────────
alter table public.notes enable row level security;

drop policy if exists notes_select on public.notes;
drop policy if exists notes_insert on public.notes;
drop policy if exists notes_update on public.notes;
drop policy if exists notes_delete on public.notes;

create policy notes_select on public.notes
  for select using (public.effective_role(vault_id, 'note', id) is not null);

create policy notes_insert on public.notes
  for insert with check (
    -- Permission to create lives at the folder/vault level.
    public.effective_role(vault_id, 'folder', coalesce(folder_id, vault_id)) in ('owner','editor')
  );

create policy notes_update on public.notes
  for update using (public.effective_role(vault_id, 'note', id) in ('owner','editor'));

create policy notes_delete on public.notes
  for delete using (public.effective_role(vault_id, 'note', id) in ('owner','editor'));

-- ── RESOURCE ACL ─────────────────────────────────────────────────────────
alter table public.resource_acl enable row level security;

drop policy if exists racl_select on public.resource_acl;
drop policy if exists racl_write  on public.resource_acl;

-- A user sees ACL rows that target them, and owners see all rows on their resources.
create policy racl_select on public.resource_acl
  for select using (
    user_id = auth.uid()
    or exists (
      select 1 from public.vault_members me
        join public.notes n on n.id = resource_acl.resource_id and resource_acl.resource_type = 'note'
       where me.user_id = auth.uid() and me.vault_id = n.vault_id and me.role = 'owner'
    )
    or exists (
      select 1 from public.vault_members me
        join public.folders f on f.id = resource_acl.resource_id and resource_acl.resource_type = 'folder'
       where me.user_id = auth.uid() and me.vault_id = f.vault_id and me.role = 'owner'
    )
  );

create policy racl_write on public.resource_acl
  for all
  using (
    exists (
      select 1 from public.vault_members me
        join public.notes n on n.id = resource_acl.resource_id and resource_acl.resource_type = 'note'
       where me.user_id = auth.uid() and me.vault_id = n.vault_id and me.role = 'owner'
    )
    or exists (
      select 1 from public.vault_members me
        join public.folders f on f.id = resource_acl.resource_id and resource_acl.resource_type = 'folder'
       where me.user_id = auth.uid() and me.vault_id = f.vault_id and me.role = 'owner'
    )
  )
  with check (granted_by = auth.uid());

-- ── AUDIT EVENTS ─────────────────────────────────────────────────────────
alter table public.audit_events enable row level security;

drop policy if exists audit_select on public.audit_events;
drop policy if exists audit_insert on public.audit_events;

create policy audit_select on public.audit_events
  for select using (
    vault_id is null and actor_id = auth.uid()
    or exists (select 1 from public.vault_members me
                 where me.vault_id = audit_events.vault_id and me.user_id = auth.uid())
  );

create policy audit_insert on public.audit_events
  for insert with check (actor_id = auth.uid());
