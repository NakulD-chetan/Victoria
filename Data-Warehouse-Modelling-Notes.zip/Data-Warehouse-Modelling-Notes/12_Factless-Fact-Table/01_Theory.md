# Factless Fact Table

> "Sometimes the most important number is who was present, not how much they spent."

**Real-world analogy:** A grocer runs free Saturday tastings and records which loyalty members showed up at which store demo, even when no purchase occurs. The attendance sheet is valuable without a dollar column: it is a matrix of people, places, times, and events captured as relationships, not as totals.

---

## Core Idea (2 Lines)

A factless fact table records that a relationship or event occurred using foreign keys alone, without numeric measures suitable for summation. Retail analytics uses these tables for coverage questions, attendance, eligibility, and bridge-style many-to-many relationships where counting rows is the analysis.

---

## Definition

| Element | Factless fact behavior |
|---------|------------------------|
| Measures | None or only dummy markers; analysis uses `COUNT(*)` or distinct logic |
| Primary content | Foreign keys to dimensions that define the event or relationship |
| Grain | Explicit: one row means one instance of the relationship |

```
Traditional fact row
--------------------
FKs + sale_amount + quantity

Factless fact row
-----------------
FKs only (plus optional degenerate identifiers)
```

**Interview Tip:** Say plainly: "The measure is the existence of the row."

**Watch Out!** Confusing factless facts with wide bridge tables that also carry weights; bridges can carry allocation factors, factless coverage tables usually should not.

---

## Event-Based Factless (Attendance)

Retail example: training attendance, vendor demo visits, loyalty member check-ins.

```sql
CREATE TABLE retail_core.fact_training_attendance (
  training_session_sk INT64,
  employee_sk INT64,
  store_sk INT64,
  date_sk INT64
);
```

| Question | SQL shape |
|----------|-----------|
| How many employees attended dairy training in March? | `COUNT(*)` with filters |
| Which stores had zero attendance sessions? | Anti-join against planned sessions |

**Watch Out!** Duplicate natural keys from double scan-ins inflate counts; enforce uniqueness on `(session, employee)` in staging merges.

---

## Coverage and Relationship Factless (Product-Store Availability)

Retail example: which SKUs are authorized to sell in which stores this month, regardless of whether any sale happened.

```sql
CREATE TABLE retail_core.fact_product_store_assortment (
  product_sk INT64,
  store_sk INT64,
  month_sk INT64
);
```

| Business question | How factless helps |
|-------------------|-------------------|
| Which high-priority SKUs are missing from a store's assortment file? | Compare assortment fact to planogram dimension |
| Coverage rate by banner | `COUNT` rows grouped by banner via `dim_store` |

```
Assortment coverage (conceptual)
--------------------------------
SKU A --authorized--> Store 1,2,3
SKU B --authorized--> Store 1,4
```

**Interview Tip:** Position coverage facts as prerequisites for fair sales comparisons: you cannot blame a store for low sales on a SKU it was not allowed to stock.

---

## SQL with COUNT

```sql
-- Stores stocking SKU 778812 in April 2026
SELECT COUNT(*) AS store_count
FROM retail_core.fact_product_store_assortment a
JOIN retail_core.dim_product p ON a.product_sk = p.product_sk
JOIN retail_core.dim_date m ON a.month_sk = m.date_sk
WHERE p.sku = '778812'
  AND m.fiscal_year = 2026
  AND m.fiscal_month = 4;
```

```sql
-- Stores with assortment but zero sales in April (simplified)
SELECT
  a.store_sk
FROM retail_core.fact_product_store_assortment a
JOIN retail_core.dim_product p ON a.product_sk = p.product_sk
JOIN retail_core.dim_date m ON a.month_sk = m.date_sk
LEFT JOIN retail_core.fact_pos_sale_line s
  ON s.store_sk = a.store_sk
 AND s.product_sk = a.product_sk
 AND s.date_sk BETWEEN m.month_start_sk AND m.month_end_sk
WHERE p.sku = '778812'
  AND m.fiscal_month = 4
GROUP BY 1
HAVING SUM(COALESCE(s.sale_amount, 0)) = 0;
```

**Watch Out!** Joining factless coverage to transaction facts without respecting time alignment creates false positives.

---

## Characteristics Table (Kimball Pattern)

A characteristics table is a specialized factless structure that lists mutually exclusive attributes for an entity, often with a `attribute_type` dimension instead of many sparse columns.

| Use in retail | Example |
|---------------|---------|
| Product tags | `organic`, `gluten-free`, `seasonal` as rows not columns |
| Customer segments | Segment membership as rows with effective dates |

```sql
CREATE TABLE retail_core.fact_product_characteristic (
  product_sk INT64,
  characteristic_sk INT64,
  effective_date_sk INT64
);
```

**Interview Tip:** Contrast with wide `dim_product` flags: characteristics tables scale when tag cardinality grows.

---

## Anti-Join for "Who Did NOT Attend"

```
Planned roster                    Actual attendance
-------------                     -----------------
(session, employee)               (session, employee)

Anti-join result
----------------
Rows in planned NOT IN actual == no-shows
```

```sql
-- Employees scheduled but missing check-in
SELECT
  r.training_session_sk,
  r.employee_sk
FROM retail_staging.training_roster r
LEFT JOIN retail_core.fact_training_attendance a
  ON r.training_session_sk = a.training_session_sk
 AND r.employee_sk = a.employee_sk
WHERE a.employee_sk IS NULL;
```

**Watch Out!** Anti-joins are expensive at scale; pre-deduplicate and index keys; consider materialized no-show lists for recurring reporting.

---

## Kimball Reference (Conceptual, Not Verbatim)

Ralph Kimball's team popularized factless fact tables as first-class stars for events and coverage. The actionable lesson for interviews: treat them as facts for joinability and conformed dimensions, not as second-class oddities.

**Interview Tip:** Mention bridge tables when many-to-many is heavy (promotion to product), and factless coverage when the analytic is presence or eligibility.

---

## When to Use Factless Tables

| Scenario | Prefer factless | Prefer alternative |
|----------|----------------|--------------------|
| Attendance without purchase | Yes | Do not fake a zero-amount sales fact |
| Authorized assortment | Yes | Avoid inventing pseudo sales |
| Many-to-many with weights | Sometimes bridge with allocation | If weights are measures, not factless |
| Pure dimensional description | No | Keep in `dim_product` |

---

## Integrity and Modeling Rules

| Rule | Rationale |
|------|-----------|
| Declare grain | `COUNT` semantics depend on it |
| Enforce uniqueness on natural composite | Prevents duplicate relationship rows |
| Include time dimension when relationships change | Assortment is time-varying |
| Document anti-patterns | Stops analysts from `SUM` nonexistent measures |

```sql
-- Example uniqueness test pattern (pseudo)
SELECT training_session_sk, employee_sk, COUNT(*) c
FROM retail_core.fact_training_attendance
GROUP BY 1, 2
HAVING c > 1;
```

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Adding fake zero measures | Invites incorrect `SUM` | Keep factless or add explicit flags with training |
| Omitting time on coverage facts | Cannot model assortment churn | Include `month_sk` or `date_sk` |
| Using factless for monetary accruals | Wrong abstraction | Use transaction or accumulating facts with measures |
| Not indexing join keys | Slow `COUNT` dashboards | Cluster or partition by common filters |
| Confusing duplicates with demand | Inflated attendance | Merge and monitor uniqueness |

---

## Key Takeaway

> Factless fact tables capture meaningful zeros and relationships in retail analytics by storing who, what, and where showed up, letting `COUNT` and set logic answer questions that dollar totals never could.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Factless = FKs without measures; existence is the signal.        |
| Event factless: attendance, demos, check-ins.                     |
| Coverage factless: assortment, shelf authorization, eligibility.|
| Use COUNT and anti-joins; avoid fake currency measures.          |
| Kimball: treat as first-class facts with conformed dimensions.   |
+------------------------------------------------------------------+
```
