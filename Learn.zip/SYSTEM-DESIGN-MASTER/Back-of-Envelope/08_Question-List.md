# Back-of-Envelope Estimation — Question List

> **Permanent Recall:** Practice estimation standalone and within system design. 10 MUST-DO questions cover core patterns. 25+ questions span QPS, storage, bandwidth, capacity. Show work, state assumptions, round aggressively. Difficulty: E=Easy, M=Medium, H=Hard.

---

## 10 MUST-DO Estimation Questions

| # | Question | Difficulty | Expected Answer |
|---|----------|------------|-----------------|
| 1 | Estimate QPS for Twitter with 300M DAU, 5 tweets/user/day, 100:1 read:write | M | ~17K writes, ~1.7M reads, ~5M peak |
| 2 | How much storage for 1B tweets/day for 5 years? | M | ~1.5 PB (1B×365×5×300B×3) |
| 3 | Estimate WhatsApp message QPS for 2B DAU, 50 msgs/user/day | E | ~1.2M msg/sec |
| 4 | Bandwidth for 10M concurrent Netflix viewers (1080p)? | M | 50 Tbps (10M × 5 Mbps) |
| 5 | How many web servers for 100K peak QPS? | E | ~100 (100K/1000) |
| 6 | QPS for Google Search with 8.5B searches/day | E | ~100K avg, ~300K peak |
| 7 | Storage for 200M users, 100 photos each, 2MB/photo | M | ~40 PB (200M×100×2MB×3) |
| 8 | Estimate read QPS for Instagram feed, 500M DAU, 20 views/user/day | M | ~100K avg, ~300K peak |
| 9 | How many DB read replicas for 500K read QPS? | E | ~100 (500K/5000) |
| 10 | Bandwidth for 1M concurrent video call users, 1 Mbps each | M | 1 Tbps egress |

---

## QPS Estimation Questions

| # | Question | Diff | Expected |
|---|----------|------|----------|
| 11 | 50M DAU, 10 actions/day. QPS? | E | ~6K avg |
| 12 | 1B DAU, 3 searches/day. Search QPS? | E | ~35K avg |
| 13 | 100M DAU, 30 messages/day, 1:1 read:write | M | ~35K msg/sec each direction |
| 14 | E-commerce: 200M DAU, 15 page views/day, 10:1 read:write | M | ~35K read, ~3.5K write |
| 15 | News app: 50M DAU, 20 articles/day. Read QPS? | E | ~12K |
| 16 | Uber: 100M DAU, 2 rides/day. Write QPS for rides? | M | ~2.3K |
| 17 | YouTube: 2B DAU, 1 upload/1000 users/day. Upload QPS? | M | ~23 uploads/sec |

---

## Storage Estimation Questions

| # | Question | Diff | Expected |
|---|----------|------|----------|
| 18 | 100M users, 1000 tweets each, 300B/tweet | M | ~30 TB raw, ~90 TB with 3× |
| 19 | 1B messages/day, 1KB each, 1 year | E | ~365 TB raw, ~1 PB with replica |
| 20 | 10K videos, 2GB each, 3 copies | E | 60 TB |
| 21 | Logs: 1M events/sec, 500B/event, 30 days | M | ~1.3 PB |
| 22 | 500M users, 50 contacts each, 100B/contact | M | ~2.5 TB |
| 23 | E-commerce: 10M orders/day, 1KB/order, 7 years | M | ~25 TB |

---

## Bandwidth Estimation Questions

| # | Question | Diff | Expected |
|---|----------|------|----------|
| 24 | 100K QPS, 10KB response. Egress bandwidth? | E | 8 Gbps |
| 25 | 1M QPS, 1KB request, 5KB response | M | 48 Gbps (egress dominant) |
| 26 | Video: 5M concurrent, 4K at 25 Mbps | H | 125 Tbps |
| 27 | Audio streaming: 10M users, 320 kbps | M | 3.2 Tbps |
| 28 | Image CDN: 500K QPS, 200KB/image | M | 800 Gbps |

---

## Capacity Planning Questions

| # | Question | Diff | Expected |
|---|----------|------|----------|
| 29 | 50K read QPS, 80% cache hit. DB replicas? | M | 10K to DB → 2 replicas |
| 30 | 200K QPS total. Web + DB + Redis layout? | M | ~200 web, 40 DB read, 2 Redis |
| 31 | 10M writes/day. Kafka partitions? | M | ~1–2 for 120 writes/sec |
| 32 | 500K QPS, need 99.9% uptime. Servers? | M | N+1 or 2N, so 2× base count |
| 33 | 1M QPS, 20% to DB. DB capacity? | M | 200K reads → 40 DB read replicas |

---

## Mixed / System-Level Questions

| # | Question | Diff | Expected |
|---|----------|------|----------|
| 34 | Design Twitter: estimate all (QPS, storage, bandwidth) | H | See 01_Concept standard refs |
| 35 | Design Uber: rides, drivers, location updates | H | Rides ~2K/s, locations 10–100× |
| 36 | Design Dropbox: sync, storage, bandwidth | H | Storage PB-scale, sync bandwidth 2× upload |
| 37 | Design Netflix: catalog storage, stream bandwidth | M | Catalog TB, stream Tbps |
| 38 | Design WhatsApp: messages, group chats, media | H | 100B msg/day, media 10× text |

---

## Model Answer Template

For any estimation question:

```
1. State assumptions: "Assume X DAU, Y actions/user, Z read:write"
2. Calculate: "X × Y = total. Total / 86400 = avg QPS. × 3 = peak"
3. Sanity check: "Twitter is ~millions, we're ~100K, so smaller scale"
4. Implications: "Need ~100 web servers, read replicas, cache"
```

> **FAANG Tip:** Always end with "So we need..." (servers, storage, bandwidth) to show you connect numbers to design.

---

## Quick Drill: One-Minute Estimations

Time yourself. For each, state assumptions, calculate, give one-line implication.

1. **50M DAU, 5 views/day** → ~3K QPS → ~3 web servers
2. **1B messages/day, 500B each** → ~12K msg/sec → ~12 web servers for API
3. **10M users, 10 photos, 1MB each** → 100 TB → Need sharding
4. **100K QPS, 5KB response** → 4 Gbps → Single region egress
5. **500K read QPS, 90% cache hit** → 50K to DB → 10 read replicas

---

## Practice Schedule Suggestion

| Week | Focus | Questions |
|------|-------|-----------|
| 1 | QPS only | 1, 5, 6, 11, 12, 15 |
| 2 | Storage | 2, 7, 18, 19, 20 |
| 3 | Bandwidth + Capacity | 4, 10, 24, 29, 30 |
| 4 | Full system | 34, 35, 36, 37, 38 |

---

## 30-SECOND REVISION BOX

```
MUST-DO: Twitter QPS, tweet storage, WhatsApp, Netflix BW, server count
QPS: DAU×actions/86400, peak 2–10×
STORAGE: items×bytes×replication×years
BANDWIDTH: QPS×size×8, or concurrent×Mbps
CAPACITY: Web 1K, DB 5K, Redis 100K
```

---

**Prev: [[07_Tricks-and-Recognition]]** | **Topic: [[01_Concept]]**
