# Caching and CDN — Edge Cases

> **Permanent Recall:** The critical edge cases in caching: cache stampede (thundering herd when key expires), cache penetration (querying non-existent keys), cache avalanche (mass expiry), hot key problem, cache warming on cold start, stale data serving, split brain in cache cluster, memory pressure evictions, CDN inconsistency across POPs, and cache serialization failures. Each has a cause, symptom, and mitigation. Know these to handle "what if" questions in FAANG interviews.

---

## Edge Case 1: Cache Stampede (Thundering Herd)

**Cause:** Popular key expires. Many requests miss simultaneously → all trigger DB load.

**Symptom:** DB CPU spikes, latency spikes, timeout cascade.

```
Timeline:
  T=0:   key:trending expires
  T=1:   Req 1, 2, ... N all GET key:trending → MISS
  T=2:   Req 1, 2, ... N all SELECT ... FROM ... (N parallel queries)
  T=3:   DB overload
```

**Mitigation:**

| Approach | How | Trade-off |
|----------|-----|-----------|
| **Distributed lock** | First request acquires lock, loads; others wait | Adds latency for waiters |
| **Probabilistic early expiry** | Expire 1–5 min early with jitter | Slightly stale |
| **Background refresh** | Refresh before TTL; serve stale until done | More logic |
| **Single-flight** | Deduplicate in-flight requests (e.g., `getOrLoad`) | App-level coordination |

---

## Edge Case 2: Cache Penetration

**Cause:** Requests for non-existent keys (e.g., invalid IDs) → cache always miss → every request hits DB.

**Symptom:** DB hammered by 404-like queries. Attacker can enumerate IDs.

```
Request GET user:999999 (doesn't exist)
  → Cache MISS (always)
  → DB query (every time)
  → Return 404
```

**Mitigation:**
- **Cache negative results:** Store `user:999999 → null` with short TTL (e.g., 60s).
- **Bloom filter:** Quick check if key might exist; if not, skip DB.
- **Rate limit** per key pattern for unknown IDs.

---

## Edge Case 3: Cache Avalanche

**Cause:** Many keys expire at the same time (e.g., all cached at 00:00 with 1h TTL → all expire at 01:00).

**Symptom:** Periodic DB spikes at expiry time.

**Mitigation:**
- **TTL jitter:** Add random offset (e.g., `ttl = base_ttl + rand(0, 300)`).
- **Stagger TTLs** when populating cache.
- **Never use fixed batch expiry** for large key sets.

---

## Edge Case 4: Hot Key Problem

**Cause:** One key (e.g., `trending:1`) gets massive traffic → single cache node or single key overloaded.

**Symptom:** One Redis node at 100% CPU, others idle. High latency for that key.

```
Traffic:  key:trending → 100K QPS to one shard
```

**Mitigation:**
- **Local cache (L1):** App-level cache for that key; reduces Redis load.
- **Replicate hot key:** Copy to multiple keys (`trending:1:a`, `trending:1:b`) and round-robin.
- **Split reads:** If key is a list, split into sub-keys.
- **Different topology:** Some systems use "hot key" nodes.

---

## Edge Case 5: Cache Warming on Cold Start

**Cause:** New deploy or cache restart → empty cache → all requests miss.

**Symptom:** DB load 10–50× normal, latency spike for minutes.

**Mitigation:**
- **Warm on startup:** Preload top N keys from DB before accepting traffic.
- **Lazy warming:** Load on first request; prioritize known hot keys.
- **Gradual traffic:** Canary deployment to limit initial load.
- **Accept temporary pain:** Size DB to absorb burst if warming not feasible.

---

## Edge Case 6: Stale Data Serving

**Cause:** Invalidation missed, TTL too long, or write to replica before cache invalidate.

**Symptom:** Users see old data (e.g., old profile after update).

**Mitigation:**
- **TTL:** Cap staleness.
- **Event-based invalidation:** Cover all write paths.
- **Version/ETag:** Client can revalidate.
- **Critical reads bypass cache:** For payment, balance, etc.

---

## Edge Case 7: Split Brain in Cache Cluster

**Cause:** Network partition → subset of nodes can't talk → each partition serves different data.

**Symptom:** Inconsistent reads across clients; possible data loss in write-behind.

**Mitigation:**
- **Quorum writes/reads:** Redis Cluster uses hash slots; partition may make some keys unavailable (fail, not serve stale).
- **Avoid write-behind** in split-brain scenarios; prefer write-through.
- **Consensus (Raft/Paxos):** For strongly consistent caches (rare).

---

## Edge Case 8: Memory Pressure Causing Evictions

**Cause:** Cache size exceeds `maxmemory` → evictions → hit ratio drops.

**Symptom:** Eviction rate high, hit ratio falling.

**Mitigation:**
- **Increase memory** or **reduce working set**.
- **Eviction policy:** LRU/LFU; avoid `noeviction` if memory-bound.
- **Monitor evictions:** Alert when eviction rate spikes.
- **Sizing:** Cache ≥ 2–3× working set for headroom.

---

## Edge Case 9: CDN Cache Inconsistency Across POPs

**Cause:** User switches region or purge only hit some POPs → different edge serves different content.

**Symptom:** User sees old version after update; A/B test pollution.

**Mitigation:**
- **Purge all POPs** (full invalidation) or use provider's global purge.
- **Cache key versioning:** `style.v2.css` — new content = new URL.
- **Surrogate keys:** Purge by tag so all POPs invalidate same objects.
- **Short TTL** for dynamic content to limit inconsistency window.

---

## Edge Case 10: Cache Serialization Failures

**Cause:** Schema change, code deploy with different serialization → cached bytes unreadable.

**Symptom:** Deserialization errors, fallback to DB or 500.

**Mitigation:**
- **Version in cache key:** `user:v2:123` so old format keys expire.
- **Backward-compatible serialization** (e.g., add optional fields only).
- **Graceful degradation:** On deserialize error, treat as miss and reload.

---

## Edge Cases Summary Table

| Edge Case | Cause | Mitigation |
|-----------|-------|------------|
| Stampede | Key expiry + concurrent misses | Lock, early expiry, single-flight |
| Penetration | Non-existent keys | Cache negative, Bloom filter |
| Avalanche | Mass expiry | TTL jitter |
| Hot key | One key, high traffic | L1 cache, replicate key |
| Cold start | Empty cache | Warming, canary |
| Stale data | Missed invalidation | TTL, events, bypass for critical |
| Split brain | Network partition | Quorum, avoid write-behind |
| Memory pressure | Full cache | Eviction policy, sizing |
| CDN inconsistency | Partial purge | Full purge, versioned URLs |
| Serialization | Schema/code change | Versioned keys, compatibility |

---

## 30-SECOND REVISION BOX

```
STAMPEDE:    Lock or early expiry
PENETRATION: Cache negative, Bloom filter
AVALANCHE:   TTL jitter
HOT KEY:     L1, replicate key
COLD START:  Warming
STALE:       TTL, invalidation, bypass
SPLIT BRAIN: Quorum, no write-behind
MEMORY:      Eviction, sizing
CDN:         Full purge, versioned URLs
SERIAL:      Versioned keys
```

---

**Prev: [[05_Common-Mistakes]] | Next: [[07_Tricks-and-Recognition]]**
