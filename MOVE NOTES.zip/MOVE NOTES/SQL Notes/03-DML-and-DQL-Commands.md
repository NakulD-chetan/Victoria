# DML & DQL Commands — INSERT, UPDATE, DELETE, SELECT

> **DML = Data Manipulation Language** → Data ko add, change, ya remove karo
> **DQL = Data Query Language** → Data ko query/fetch karo (SELECT)
> Yeh commands daily SQL likhne mein sabse zyada use hote hain!

---

## Sample Table (Reference)

> Is puri file mein yeh table use karenge:

```sql
CREATE TABLE employees (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    name        VARCHAR(100) NOT NULL,
    department  VARCHAR(50),
    salary      DECIMAL(10,2),
    city        VARCHAR(50),
    join_date   DATE
);
```

```
+----+----------+------------+----------+--------+------------+
| id | name     | department | salary   | city   | join_date  |
+----+----------+------------+----------+--------+------------+
| 1  | Rahul    | IT         | 75000.00 | Mumbai | 2022-01-15 |
| 2  | Priya    | HR         | 65000.00 | Delhi  | 2022-03-20 |
| 3  | Amit     | IT         | 80000.00 | Pune   | 2021-06-10 |
| 4  | Sneha    | Finance    | 70000.00 | Mumbai | 2023-01-05 |
| 5  | Karan    | HR         | 55000.00 | Delhi  | 2023-07-18 |
| 6  | Neha     | IT         | 90000.00 | Pune   | 2020-11-22 |
+----+----------+------------+----------+--------+------------+
```

---

## 1. INSERT — Naya Data Add Karo

> **Definition:** INSERT statement adds new rows to a table.

### Method 1: All Columns (Order matter karta hai)

```sql
INSERT INTO employees
VALUES (7, 'Rohan', 'Finance', 72000.00, 'Mumbai', '2024-02-01');
```

> Yahan **sab columns** ki values deni padegi, **same order** mein jaise table mein hain.

---

### Method 2: Specific Columns (Best Practice)

```sql
INSERT INTO employees (name, department, salary, city, join_date)
VALUES ('Rohan', 'Finance', 72000.00, 'Mumbai', '2024-02-01');
```

> **id AUTO_INCREMENT** hai, toh skip kar diya — automatically 7 assign hoga.
> **Yeh method better hai** — column order change ho toh bhi kaam karega.

---

### Method 3: Multiple Rows at Once

```sql
INSERT INTO employees (name, department, salary, city, join_date)
VALUES
    ('Rohan', 'Finance', 72000.00, 'Mumbai', '2024-02-01'),
    ('Divya', 'IT', 85000.00, 'Delhi', '2024-03-15'),
    ('Arjun', 'HR', 58000.00, 'Pune', '2024-04-10');
```

> Ek query mein multiple rows — **performance better** hota hai compared to 3 alag INSERT statements.

---

### Method 4: INSERT from Another Table

```sql
INSERT INTO it_employees (name, salary, city)
SELECT name, salary, city
FROM employees
WHERE department = 'IT';
```

> **Ek table se data nikal ke doosre table mein daalo** — bahut useful for data migration.

---

### INSERT — Common Mistakes

| Mistake | Kya Hoga |
|---------|----------|
| PRIMARY KEY duplicate value | ERROR: Duplicate entry |
| NOT NULL column skip karo | ERROR: Column cannot be null |
| Wrong data type | ERROR: Incorrect value type |
| Extra/fewer values than columns | ERROR: Column count mismatch |

---

## 2. UPDATE — Existing Data Change Karo

> **Definition:** UPDATE statement modifies existing rows in a table.

### Basic Syntax:

```sql
UPDATE table_name
SET column1 = value1, column2 = value2
WHERE condition;
```

> **WARNING:** WHERE clause bhool gaye toh **SARI ROWS** update ho jayengi!

---

### Example 1: Single Column Update

```sql
UPDATE employees
SET salary = 80000
WHERE id = 2;
```

> Priya ki salary 65000 se → 80000 ho jayegi.

---

### Example 2: Multiple Columns Update

```sql
UPDATE employees
SET salary = 95000, department = 'Management'
WHERE name = 'Neha';
```

---

### Example 3: Update with Calculation

```sql
-- Sabko 10% raise do
UPDATE employees
SET salary = salary * 1.10;

-- Sirf IT department ko 15% raise
UPDATE employees
SET salary = salary * 1.15
WHERE department = 'IT';
```

---

### Example 4: Update using Another Table (Subquery)

```sql
UPDATE employees
SET salary = (SELECT AVG(salary) FROM employees WHERE department = 'IT')
WHERE name = 'Karan';
```

> Karan ki salary IT department ke average ke equal set kar do.

---

### UPDATE — Dangerous Scenarios

```sql
-- DANGER: WHERE nahi likha → SAB ROWS update!
UPDATE employees SET salary = 0;  -- ❌ Sab ki salary 0!

-- SAFE: WHERE ke saath
UPDATE employees SET salary = 0 WHERE id = 999;  -- ✅ Specific row
```

> **Interview Tip:** Hamesha pehle SELECT run karo WHERE clause test karne ke liye, phir UPDATE likho.

---

## 3. DELETE — Data Hatao

> **Definition:** DELETE statement removes rows from a table based on a condition.

### Basic Syntax:

```sql
DELETE FROM table_name
WHERE condition;
```

> **WARNING:** WHERE bhool gaye toh **SARA DATA** delete ho jayega!

---

### Example 1: Specific Row Delete

```sql
DELETE FROM employees
WHERE id = 5;
```

---

### Example 2: Condition-based Delete

```sql
-- 60000 se kam salary wale hatao
DELETE FROM employees
WHERE salary < 60000;

-- Specific department ke sab employees hatao
DELETE FROM employees
WHERE department = 'HR';
```

---

### Example 3: Delete All Rows (Careful!)

```sql
-- Method 1: DELETE (slow, logged, can ROLLBACK)
DELETE FROM employees;

-- Method 2: TRUNCATE (fast, minimal logging, CANNOT ROLLBACK)
TRUNCATE TABLE employees;
```

---

### DELETE vs TRUNCATE vs DROP — MUST KNOW!

| Feature | DELETE | TRUNCATE | DROP |
|---------|--------|----------|------|
| **Kya karta hai** | Specific rows hatao | Sab rows hatao | Pura table hatao |
| **WHERE clause** | ✅ Supports | ❌ Not supported | ❌ N/A |
| **ROLLBACK** | ✅ Can rollback | ❌ Cannot (DDL) | ❌ Cannot (DDL) |
| **Speed** | Slow (row by row) | Fast (page dealloc) | Fastest |
| **Auto Increment** | Reset nahi hota | Reset ho jaata hai | Table hi nahi rahega |
| **Triggers** | Fire hote hain | Nahi fire hote | N/A |
| **Space** | Free nahi hota turant | Free hota hai | Fully freed |
| **Type** | DML | DDL | DDL |

> **Interview mein 100% puchha jaata hai:** "DELETE vs TRUNCATE vs DROP kya difference hai?"

---

## 4. SELECT — Data Query Karo (DQL)

> **Definition:** SELECT statement retrieves data from one or more tables. This is the most used SQL command.

### Basic Syntax:

```sql
SELECT column1, column2, ...
FROM table_name
WHERE condition;
```

---

### Example 1: Select All Columns

```sql
SELECT * FROM employees;
```

> `*` = sab columns. **Production mein avoid karo** — specifically columns name likho.

---

### Example 2: Select Specific Columns

```sql
SELECT name, salary, department
FROM employees;
```

```
+----------+----------+------------+
| name     | salary   | department |
+----------+----------+------------+
| Rahul    | 75000.00 | IT         |
| Priya    | 65000.00 | HR         |
| Amit     | 80000.00 | IT         |
| ...      | ...      | ...        |
+----------+----------+------------+
```

---

### Example 3: SELECT with WHERE

```sql
-- IT department ke employees
SELECT name, salary
FROM employees
WHERE department = 'IT';

-- Salary 70000 se zyada
SELECT * FROM employees
WHERE salary > 70000;
```

---

## 5. Aliases — Columns/Tables Ko Naam Do

> **Definition:** Alias gives a temporary name to a column or table, making output readable.

### Column Alias:

```sql
SELECT
    name AS employee_name,
    salary AS monthly_salary,
    salary * 12 AS annual_salary
FROM employees;
```

```
+---------------+----------------+---------------+
| employee_name | monthly_salary | annual_salary |
+---------------+----------------+---------------+
| Rahul         | 75000.00       | 900000.00     |
| Priya         | 65000.00       | 780000.00     |
+---------------+----------------+---------------+
```

> **AS** keyword optional hai — `SELECT name employee_name` bhi chalega. But **AS likhna better practice** hai.

### Table Alias:

```sql
SELECT e.name, e.salary
FROM employees e
WHERE e.department = 'IT';
```

> Table alias **Joins mein bahut important** hai — short naam se columns refer karo.

---

## 6. DISTINCT — Duplicates Hatao

> **Definition:** DISTINCT removes duplicate rows from the result set.

```sql
-- Saari unique departments
SELECT DISTINCT department FROM employees;
```

```
+------------+
| department |
+------------+
| IT         |
| HR         |
| Finance    |
+------------+
```

```sql
-- Multiple columns ke saath DISTINCT
SELECT DISTINCT department, city FROM employees;
```

> Yeh **combination** of department + city unique return karega.

---

## 7. LIMIT / TOP — Rows Ki Sankhya Control Karo

### MySQL / PostgreSQL:

```sql
-- Pehle 3 rows
SELECT * FROM employees LIMIT 3;

-- Skip 2, next 3 lo (pagination)
SELECT * FROM employees LIMIT 3 OFFSET 2;
```

### SQL Server:

```sql
-- Pehle 3 rows
SELECT TOP 3 * FROM employees;

-- Top 10%
SELECT TOP 10 PERCENT * FROM employees;
```

> **Pagination Formula:** Page N ke liye → `LIMIT page_size OFFSET (N-1) * page_size`

```sql
-- Page 1 (rows 1-5):  LIMIT 5 OFFSET 0
-- Page 2 (rows 6-10): LIMIT 5 OFFSET 5
-- Page 3 (rows 11-15): LIMIT 5 OFFSET 10
```

---

## 8. CASE WHEN — SQL mein IF-ELSE

> **Definition:** CASE expression adds conditional logic to SQL queries, like if-else in programming.

### Syntax:

```sql
SELECT name, salary,
    CASE
        WHEN salary >= 90000 THEN 'Senior'
        WHEN salary >= 70000 THEN 'Mid-Level'
        WHEN salary >= 55000 THEN 'Junior'
        ELSE 'Intern'
    END AS level
FROM employees;
```

```
+----------+----------+-----------+
| name     | salary   | level     |
+----------+----------+-----------+
| Rahul    | 75000.00 | Mid-Level |
| Priya    | 65000.00 | Junior    |
| Amit     | 80000.00 | Mid-Level |
| Sneha    | 70000.00 | Mid-Level |
| Karan    | 55000.00 | Junior    |
| Neha     | 90000.00 | Senior    |
+----------+----------+-----------+
```

### CASE in UPDATE:

```sql
UPDATE employees
SET salary = CASE
    WHEN department = 'IT' THEN salary * 1.15
    WHEN department = 'HR' THEN salary * 1.10
    ELSE salary * 1.05
END;
```

### CASE in ORDER BY:

```sql
SELECT * FROM employees
ORDER BY
    CASE department
        WHEN 'IT' THEN 1
        WHEN 'Finance' THEN 2
        WHEN 'HR' THEN 3
        ELSE 4
    END;
```

> **Interview Tip:** CASE WHEN bahut versatile hai — SELECT, WHERE, ORDER BY, UPDATE, INSERT sab mein use kar sakte ho.

---

## 9. NULL Handling

> **Definition:** NULL means "unknown" or "missing value" — it is NOT zero, NOT empty string.

### Check for NULL:

```sql
-- ✅ Correct way
SELECT * FROM employees WHERE department IS NULL;
SELECT * FROM employees WHERE department IS NOT NULL;

-- ❌ Wrong way (yeh KAAM NAHI KAREGA)
SELECT * FROM employees WHERE department = NULL;    -- WRONG!
SELECT * FROM employees WHERE department != NULL;   -- WRONG!
```

> **VERY IMPORTANT:** `NULL = NULL` → returns **NULL** (not TRUE!). Isliye `IS NULL` use karo.

### COALESCE — NULL ko Replace Karo:

```sql
SELECT name, COALESCE(department, 'Not Assigned') AS department
FROM employees;
```

> `COALESCE` pehli non-NULL value return karta hai list mein se.

### IFNULL (MySQL) / ISNULL (SQL Server):

```sql
-- MySQL
SELECT name, IFNULL(department, 'N/A') FROM employees;

-- SQL Server
SELECT name, ISNULL(department, 'N/A') FROM employees;
```

---

## Quick Memory Card

| Command | Type | Kya Karta Hai | Rollback? |
|---------|------|---------------|-----------|
| INSERT | DML | Naya row add karo | ✅ Yes |
| UPDATE | DML | Existing data change karo | ✅ Yes |
| DELETE | DML | Rows hatao (conditional) | ✅ Yes |
| SELECT | DQL | Data fetch/query karo | N/A |
| TRUNCATE | DDL | Sab rows hatao (fast) | ❌ No |
| DROP | DDL | Pura table/object hatao | ❌ No |

> **Yaad Rakho:**
> - **INSERT** → Add
> - **UPDATE** → Modify (WHERE mat bhoolna!)
> - **DELETE** → Remove (WHERE mat bhoolna!)
> - **SELECT** → Read/Fetch
> - **CASE WHEN** → SQL ka IF-ELSE
> - **NULL** → IS NULL use karo, `= NULL` nahi!

---

*Notes Source: SQL DML/DQL fundamentals + Interview preparation material*
