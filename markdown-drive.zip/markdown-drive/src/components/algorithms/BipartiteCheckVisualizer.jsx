import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: bipartite-check */
const GRAPH = {
  nodes: [
    { id: 'A', x: 140, y: 120, label: 'A' },
    { id: 'B', x: 340, y: 120, label: 'B' },
    { id: 'C', x: 140, y: 260, label: 'C' },
    { id: 'D', x: 340, y: 260, label: 'D' },
    { id: 'E', x: 480, y: 190, label: 'E' },
  ],
  edges: [
    { from: 'A', to: 'B', directed: false },
    { from: 'A', to: 'D', directed: false },
    { from: 'C', to: 'B', directed: false },
    { from: 'C', to: 'D', directed: false },
    { from: 'B', to: 'E', directed: false },
    { from: 'D', to: 'E', directed: false },
  ],
};

function generateSteps() {
  const adj = {};
  GRAPH.nodes.forEach((n) => { adj[n.id] = []; });
  GRAPH.edges.forEach((e) => {
    adj[e.from].push(e.to);
    adj[e.to].push(e.from);
  });
  const color = {};
  const steps = [];
  const q = [];
  const start = 'A';
  color[start] = 0;
  q.push(start);
  steps.push({ type: 'seed', nodeColors: { [start]: 'source' }, edgeColors: {}, nodeLabels: { [start]: 'c0' }, queue: [...q] });
  while (q.length) {
    const u = q.shift();
    steps.push({ type: 'poll', nodeColors: { [u]: 'current' }, edgeColors: {}, queue: [...q] });
    for (const v of adj[u]) {
      steps.push({
        type: 'check',
        nodeColors: { [u]: 'processing', [v]: 'processing' },
        edgeColors: { [`${u}-${v}`]: 'highlight' },
        queue: [...q],
      });
      if (color[v] == null) {
        color[v] = 1 - color[u];
        q.push(v);
        steps.push({
          type: 'color',
          nodeColors: { [u]: 'processing', [v]: 'visited' },
          edgeColors: { [`${u}-${v}`]: 'tree' },
          nodeLabels: { [v]: `c${color[v]}` },
          queue: [...q],
        });
      } else if (color[v] === color[u]) {
        steps.push({
          type: 'conflict',
          nodeColors: { [u]: 'current', [v]: 'current' },
          edgeColors: { [`${u}-${v}`]: 'back' },
        });
        steps.push({ type: 'not-bipartite', nodeColors: {}, edgeColors: {} });
        return steps;
      }
    }
    steps.push({ type: 'settle', nodeColors: { [u]: 'visited' }, edgeColors: {}, queue: [...q] });
  }
  steps.push({ type: 'bipartite', nodeColors: Object.fromEntries(Object.keys(color).map((id) => [id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function BipartiteCheckVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Bipartite check via BFS coloring' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'check') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: step.queue || [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
