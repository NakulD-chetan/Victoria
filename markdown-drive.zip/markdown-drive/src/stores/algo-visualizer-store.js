import { create } from 'zustand';

export const useVisualizerStore = create((set, get) => ({
  array: [],
  colors: {},
  pointers: {},
  labels: {},
  buckets: null,
  treeView: null,
  stepIndex: -1,
  steps: [],
  playing: false,
  speed: 400,
  logs: [],
  currentStep: null,
  currentLang: 'python',
  comparisons: 0,
  swaps: 0,
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setArray: (arr) => set({ array: [...arr] }),
  setColors: (c) => set({ colors: { ...c } }),
  setPointers: (p) => set({ pointers: { ...p } }),
  setLabels: (l) => set({ labels: { ...l } }),
  setBuckets: (b) => set({ buckets: b }),
  setTreeView: (tv) => set({ treeView: tv }),
  setSteps: (s) => set({ steps: s, stepIndex: -1 }),
  setPlaying: (v) => set({ playing: v }),
  setSpeed: (v) => set({ speed: v }),
  setStep: (step) => set({ currentStep: step }),
  setLang: (lang) => set({ currentLang: lang }),
  incComparisons: () => set((s) => ({ comparisons: s.comparisons + 1 })),
  incSwaps: () => set((s) => ({ swaps: s.swaps + 1 })),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),

  nextStep: () => {
    const { stepIndex, steps } = get();
    if (stepIndex < steps.length - 1) {
      const next = stepIndex + 1;
      set({ stepIndex: next });
      return steps[next];
    }
    set({ playing: false });
    return null;
  },

  prevStep: () => {
    const { stepIndex, steps } = get();
    if (stepIndex > 0) {
      const prev = stepIndex - 1;
      set({ stepIndex: prev });
      return steps[prev];
    }
    return null;
  },

  reset: () => set({
    array: [], colors: {}, pointers: {}, labels: {},
    buckets: null, treeView: null,
    stepIndex: -1, steps: [], playing: false,
    logs: [], currentStep: null, comparisons: 0, swaps: 0,
    startTime: performance.now(),
  }),
}));
