# Internals: Kafka Producer and Consumer Protocol

> **Permanent Recall:** Producer batches messages by (topic, partition) in `RecordAccumulator`, sends when `batch.size` or `linger.ms` hit. Partitioner: `hash(key) % numPartitions` for keyed, sticky for unkeyed. Consumer group protocol: JoinGroup → SyncGroup → Heartbeat → commit offsets. Rebalance: coordinator reassigns partitions; causes brief pause. Static membership and cooperative rebalancing reduce disruption. Offset storage: `__consumer_offsets` internal topic (50 partitions, compacted).

---

## Why This Matters

When people say "Kafka producer sends" or "consumer polls," they usually hide a lot of internal machinery.

This file explains the operational core of Kafka clients:

- how records are batched
- how partitions are chosen
- how consumer groups form
- how rebalances happen
- how offset commits control progress

This is the most interview-relevant internals file after storage and replication.

---

## Producer Internals — From send() to Wire

```
PRODUCER ARCHITECTURE (inside KafkaProducer):

┌─────────────────────────────────────────────────────────────────┐
│                      KafkaProducer                               │
│                                                                 │
│  Application Thread(s):                                          │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │ producer.send(ProducerRecord(topic, key, value))          │   │
│  │                                                           │   │
│  │ 1. SERIALIZE:                                             │   │
│  │    keyBytes = keySerializer.serialize(topic, key)         │   │
│  │    valueBytes = valueSerializer.serialize(topic, value)   │   │
│  │                                                           │   │
│  │ 2. PARTITION:                                             │   │
│  │    partition = partitioner.partition(topic, key, value,    │   │
│  │                                     cluster metadata)     │   │
│  │                                                           │   │
│  │ 3. ACCUMULATE:                                            │   │
│  │    recordAccumulator.append(topic, partition, key, value)  │   │
│  │    → Returns FutureRecordMetadata (async handle)          │   │
│  │                                                           │   │
│  │ 4. WAKE SENDER (if batch ready or linger.ms expired):     │   │
│  │    sender.wakeup()                                        │   │
│  └───────────────────────────────────────────────────────────┘   │
│                            │                                     │
│                            ▼                                     │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │              RecordAccumulator                             │   │
│  │                                                           │   │
│  │  Batches organized by TopicPartition:                     │   │
│  │                                                           │   │
│  │  orders-0: [Batch(full)] → [Batch(filling...)]           │   │
│  │  orders-1: [Batch(filling...)]                            │   │
│  │  orders-2: [Batch(full)] → [Batch(full)] → [Batch(...)]  │   │
│  │  payments-0: [Batch(filling...)]                          │   │
│  │                                                           │   │
│  │  Each batch:                                              │   │
│  │    - MemoryRecordsBuilder (ByteBuffer, off-heap or heap)  │   │
│  │    - batch.size = 16384 (16 KB default)                   │   │
│  │    - Compression applied per batch                         │   │
│  │    - Created from BufferPool (pre-allocated memory)       │   │
│  │                                                           │   │
│  │  BufferPool:                                              │   │
│  │    buffer.memory = 33554432 (32 MB total)                 │   │
│  │    Pre-allocates ByteBuffers of batch.size                │   │
│  │    If pool exhausted: send() BLOCKS for max.block.ms      │   │
│  │    This is the BACKPRESSURE mechanism                      │   │
│  └───────────────────────────────────────────────────────────┘   │
│                            │                                     │
│                            ▼                                     │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │              Sender Thread (single thread)                │   │
│  │                                                           │   │
│  │  while (running):                                         │   │
│  │    // 1. Get ready batches (full OR linger.ms expired)    │   │
│  │    readyNodes = accumulator.ready(cluster, now)            │   │
│  │                                                           │   │
│  │    // 2. Group batches by destination broker               │   │
│  │    // Each broker request contains batches for ALL         │   │
│  │    // partitions led by that broker                        │   │
│  │    batches = accumulator.drain(readyNodes, maxRequestSize)│   │
│  │                                                           │   │
│  │    // 3. Create ProduceRequest per broker                  │   │
│  │    for each broker:                                        │   │
│  │      request = ProduceRequest(acks, timeout, batches)     │   │
│  │      networkClient.send(broker, request)                  │   │
│  │                                                           │   │
│  │    // 4. Poll network (NIO selector under the hood)       │   │
│  │    networkClient.poll(timeout)                            │   │
│  │      // This does epoll_wait(), reads responses,          │   │
│  │      // writes pending requests                           │   │
│  │                                                           │   │
│  │    // 5. Handle responses                                  │   │
│  │    for each completed response:                           │   │
│  │      if success: complete Future, call callback            │   │
│  │      if retriable error: re-enqueue batch for retry       │   │
│  │      if fatal error: fail Future, call callback            │   │
│  └───────────────────────────────────────────────────────────┘   │
│                                                                 │
│  NetworkClient (NIO):                                            │
│  ┌───────────────────────────────────────────────────────────┐   │
│  │ Java NIO Selector wrapping epoll:                         │   │
│  │   One TCP connection per broker (multiplexed)              │   │
│  │   max.in.flight.requests.per.connection = 5 (default)     │   │
│  │   Pipelining: send up to 5 requests before waiting        │   │
│  │   for responses                                           │   │
│  └───────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

### Batching: Why and How

```
BATCHING MECHANICS:

send() is non-blocking — it just appends to the accumulator.
Actual network send happens in the Sender thread.

TWO TRIGGERS FOR SENDING A BATCH:
  1. batch.size = 16384 (16 KB):
     When a batch for a partition fills up → ready to send
     
  2. linger.ms = 0 (default) or 5-100ms (tuned):
     Even if batch isn't full, send after this delay
     Default 0: send almost immediately (no waiting)
     Set to 5-50ms: accumulate more messages → better batching

THROUGHPUT vs LATENCY TRADE-OFF:
  ┌──────────────────────────────────────────────────────────┐
  │ linger.ms=0, batch.size=16KB:                            │
  │   Each send() → almost immediate network send            │
  │   Many small requests → low latency, lower throughput    │
  │                                                          │
  │ linger.ms=50, batch.size=64KB:                           │
  │   Wait up to 50ms for more messages                      │
  │   Bigger batches → higher throughput, 50ms added latency │
  │   Better compression ratio (more data to compress)       │
  │                                                          │
  │ Production recommendation:                               │
  │   High throughput: linger.ms=5-20, batch.size=64KB       │
  │   Low latency: linger.ms=0, batch.size=16KB              │
  └──────────────────────────────────────────────────────────┘

BUFFER POOL MEMORY MANAGEMENT:
  buffer.memory = 32 MB (total producer memory for batches)

  ┌──────────────────────────────────────────────────────────┐
  │ BufferPool (32 MB):                                      │
  │                                                          │
  │ Free list of 16KB ByteBuffers:                           │
  │   [buf] [buf] [buf] [buf] ... (pre-allocated)            │
  │                                                          │
  │ When send() needs a batch buffer:                        │
  │   1. Try to get from free list (fast, no allocation)     │
  │   2. If free list empty: allocate new ByteBuffer          │
  │   3. If total memory used ≥ 32MB:                        │
  │      BLOCK send() until a buffer is freed                 │
  │      Block for max.block.ms (60s default)                │
  │      If timeout → throw TimeoutException                  │
  │                                                          │
  │ When batch is sent and acked:                            │
  │   ByteBuffer returned to free list (recycled)            │
  │   No GC pressure (reuse buffers)                         │
  └──────────────────────────────────────────────────────────┘
```

### Partitioner: How Messages Map to Partitions

```
PARTITIONING STRATEGIES:

1. KEYED MESSAGES (key != null):
   partition = murmur2(key) % numPartitions

   murmur2 hash:
     Non-cryptographic, fast, good distribution
     Same key → same hash → same partition → ORDER GUARANTEED
     Important for: order-per-customer, updates-per-entity

   Example:
     key = "order-123"
     murmur2("order-123") = 0x7A3B2C1D
     0x7A3B2C1D % 6 = 3 → partition 3
     ALL messages for "order-123" go to partition 3

   GOTCHA: if numPartitions changes (add partitions):
     hash("order-123") % 6 ≠ hash("order-123") % 8
     Same key → DIFFERENT partition! Order broken!
     Solution: don't add partitions to ordered topics
              (or use custom partitioner with consistent hashing)

2. UNKEYED MESSAGES (key == null):
   Old behavior: round-robin (each message → next partition)
     Problem: many small batches (1 message each)
     Each partition gets 1 message → 6 partitions = 6 tiny batches

   New behavior (Kafka 2.4+): STICKY PARTITIONER
     Pick a partition, stick with it until batch is full
     Then pick next partition
     Result: fewer, fuller batches → better batching + compression

   ┌──────────────────────────────────────────────────────┐
   │ ROUND-ROBIN (old):                                   │
   │   msg1 → P0, msg2 → P1, msg3 → P2, msg4 → P0...    │
   │   6 messages → 6 batches (1 per partition)           │
   │                                                     │
   │ STICKY (new):                                        │
   │   msg1 → P0, msg2 → P0, msg3 → P0 (batch full)     │
   │   msg4 → P2, msg5 → P2, msg6 → P2 (batch full)     │
   │   6 messages → 2 batches (3 per partition)           │
   │   Better compression, fewer requests                 │
   └──────────────────────────────────────────────────────┘

3. CUSTOM PARTITIONER:
   Implement Partitioner interface:
     int partition(String topic, Object key, byte[] keyBytes,
                   Object value, byte[] valueBytes, Cluster cluster)

   Use cases:
     - Consistent hashing (resilient to partition count changes)
     - Priority-based: VIP customers → specific partition
     - Geographic: region-based routing
```

---

## Consumer Group Protocol — Deep Internals

```
CONSUMER GROUP LIFECYCLE:

A consumer group is a set of consumers that cooperatively
consume partitions of topics. Each partition → exactly one
consumer in the group.

GROUP COORDINATOR:
  One broker is the "Group Coordinator" for each consumer group.
  Which broker? hash(group.id) % __consumer_offsets partition count
  The leader of that partition is the coordinator.

  __consumer_offsets: 50 partitions (default)
  Groups are distributed across coordinators by hash.
```

### Join and Sync Protocol

```
CONSUMER GROUP JOIN PROTOCOL:

When a consumer starts, it goes through this protocol:

1. FIND COORDINATOR:
   ┌────────────────────────────────────────────────────────────┐
   │ Consumer → ANY broker: FindCoordinatorRequest(group.id)    │
   │ Broker → Consumer: FindCoordinatorResponse(coordinatorId)  │
   │                                                            │
   │ Now consumer knows which broker is its group coordinator   │
   └────────────────────────────────────────────────────────────┘

2. JOIN GROUP (two-phase protocol):

   Phase 1: JoinGroup
   ┌────────────────────────────────────────────────────────────┐
   │ ALL consumers in group send JoinGroupRequest:              │
   │   {groupId, memberId, protocolType: "consumer",            │
   │    protocols: [{name: "range", metadata: subscriptions}]}  │
   │                                                            │
   │ Coordinator:                                               │
   │   - Waits for all members (max.poll.interval.ms timeout)   │
   │   - Selects ONE consumer as the GROUP LEADER               │
   │     (usually first to join)                                │
   │   - Selects assignment strategy (range, roundrobin, etc.)  │
   │                                                            │
   │ JoinGroupResponse to LEADER:                               │
   │   {leaderId: "consumer-1", members: [all member metadata]} │
   │   Leader gets list of ALL members and their subscriptions  │
   │                                                            │
   │ JoinGroupResponse to FOLLOWERS:                            │
   │   {leaderId: "consumer-1", members: []}                    │
   │   Followers get empty member list                          │
   └────────────────────────────────────────────────────────────┘

   Phase 2: SyncGroup
   ┌────────────────────────────────────────────────────────────┐
   │ GROUP LEADER computes partition assignment:                │
   │   (this runs on the consumer, NOT the broker!)             │
   │                                                            │
   │   assignments = assignor.assign(cluster, members)          │
   │   Example (range assignor, 6 partitions, 3 consumers):    │
   │     consumer-1: [P0, P1]                                  │
   │     consumer-2: [P2, P3]                                  │
   │     consumer-3: [P4, P5]                                  │
   │                                                            │
   │ LEADER sends SyncGroupRequest with assignments:            │
   │   {memberId, assignments: {consumer-1:[P0,P1], ...}}      │
   │                                                            │
   │ FOLLOWERS send SyncGroupRequest with empty assignments:    │
   │   {memberId, assignments: {}}                              │
   │                                                            │
   │ Coordinator:                                               │
   │   - Stores assignments from leader                         │
   │   - Responds to ALL members with their specific assignment │
   │                                                            │
   │ SyncGroupResponse to each consumer:                        │
   │   {assignment: [P0, P1]}  (their partitions)               │
   └────────────────────────────────────────────────────────────┘

WHY CLIENT-SIDE ASSIGNMENT?
  - Broker doesn't need to know assignment logic
  - Pluggable: different strategies without broker changes
  - Custom assignors: priority, rack-aware, etc.
  - Broker just coordinates; client decides assignment
```

### Heartbeat and Session Management

```
HEARTBEAT PROTOCOL:

After joining, consumers must continuously prove they're alive:

┌────────────────────────────────────────────────────────────────┐
│ HEARTBEAT THREAD (dedicated thread in consumer):               │
│                                                                │
│ while (member of group):                                       │
│   sleep(heartbeat.interval.ms)  // default 3000ms (3s)        │
│   HeartbeatRequest → Coordinator                               │
│   HeartbeatResponse ← Coordinator                              │
│     response.errorCode:                                        │
│       NONE → all good                                          │
│       REBALANCE_IN_PROGRESS → must rejoin (start JoinGroup)   │
│       UNKNOWN_MEMBER_ID → kicked out, must rejoin              │
│                                                                │
│ COORDINATOR side:                                              │
│   Tracks lastHeartbeat timestamp per member                    │
│   If now - lastHeartbeat > session.timeout.ms (45s default):   │
│     Remove member from group                                   │
│     Trigger rebalance for remaining members                    │
└────────────────────────────────────────────────────────────────┘

THREE TIMEOUT KNOBS:
  ┌──────────────────────────────────────────────────────────┐
  │ heartbeat.interval.ms = 3000 (3s)                        │
  │   How often consumer sends heartbeat                     │
  │   Must be < session.timeout.ms / 3                       │
  │                                                          │
  │ session.timeout.ms = 45000 (45s)                         │
  │   How long coordinator waits before declaring dead        │
  │   Lower = faster detection, but risk of false positives  │
  │   (GC pauses, network blips)                             │
  │                                                          │
  │ max.poll.interval.ms = 300000 (5 min)                    │
  │   Max time between poll() calls                          │
  │   If consumer takes >5 min to process a batch:           │
  │     Coordinator kicks it out (even if heartbeat is fine!) │
  │   Protects against stuck consumers                       │
  └──────────────────────────────────────────────────────────┘

IMPORTANT DISTINCTION:
  Heartbeat thread ≠ Processing thread
  Heartbeat can be fine (consumer process alive)
  But poll() not called (processing stuck)
  max.poll.interval.ms catches this case
```

---

## Rebalancing — The Disruptive Event

```
WHAT TRIGGERS A REBALANCE:

1. Consumer JOINS group (new consumer starts)
2. Consumer LEAVES group (graceful shutdown → LeaveGroup request)
3. Consumer DIES (heartbeat timeout → coordinator removes)
4. Consumer exceeds max.poll.interval.ms (kicked out)
5. Topic partition count changes (new partitions added)
6. Consumer subscription changes (subscribe to new topic)

REBALANCE PROCESS (Eager Protocol — old default):
  ┌────────────────────────────────────────────────────────────┐
  │                                                            │
  │ 1. Coordinator detects change (new member, death, etc.)    │
  │                                                            │
  │ 2. Coordinator sets group state to REBALANCING             │
  │    Next heartbeat response to ALL members:                 │
  │      errorCode = REBALANCE_IN_PROGRESS                     │
  │                                                            │
  │ 3. ALL consumers:                                          │
  │    *** REVOKE ALL PARTITIONS ***                            │
  │    onPartitionsRevoked(allCurrentPartitions)                │
  │    Commit current offsets                                   │
  │    Stop processing                                         │
  │                                                            │
  │ 4. ALL consumers send JoinGroupRequest                     │
  │    (same protocol as initial join)                         │
  │                                                            │
  │ 5. Leader computes new assignment                          │
  │    SyncGroup → everyone gets new partitions                │
  │                                                            │
  │ 6. Consumers start processing new partitions               │
  │    onPartitionsAssigned(newPartitions)                      │
  │                                                            │
  │ PROBLEM: "Stop-the-world" rebalance!                       │
  │ ALL consumers stop processing during rebalance             │
  │ Duration: seconds to minutes depending on group size       │
  │ During this time: ZERO message processing                  │
  └────────────────────────────────────────────────────────────┘

COOPERATIVE (INCREMENTAL) REBALANCE (Kafka 2.4+):
  ┌────────────────────────────────────────────────────────────┐
  │ Key idea: only revoke MOVING partitions, not all           │
  │                                                            │
  │ Before: 3 consumers, adding 4th                            │
  │   C1: [P0, P1]  C2: [P2, P3]  C3: [P4, P5]              │
  │   C4: (joining)                                            │
  │                                                            │
  │ Eager: ALL stop, reassign everything                       │
  │ Cooperative:                                               │
  │                                                            │
  │ Round 1 (JoinGroup):                                       │
  │   Leader computes new assignment:                          │
  │     C1: [P0]  C2: [P2, P3]  C3: [P4, P5]  C4: [P1]      │
  │   Diff: only P1 needs to move (C1 → C4)                   │
  │                                                            │
  │   SyncGroup tells C1: "your new assignment is [P0]"        │
  │   C1: revoke ONLY P1, keep processing P0                  │
  │   C2, C3: keep ALL their partitions, keep processing       │
  │                                                            │
  │ Round 2 (another JoinGroup, triggered by revocation):      │
  │   C4 gets P1 assigned                                      │
  │   C4 starts processing P1                                  │
  │                                                            │
  │ Result:                                                    │
  │   Only P1 had a brief processing gap                       │
  │   P0, P2, P3, P4, P5 were processed CONTINUOUSLY          │
  │   Minimal disruption!                                      │
  └────────────────────────────────────────────────────────────┘

STATIC GROUP MEMBERSHIP (Kafka 2.3+):
  group.instance.id = "consumer-host-1" (per consumer)
  
  Without static membership:
    Consumer restarts → new memberId → REBALANCE
    Rolling restart of 10 consumers → 10 rebalances!

  With static membership:
    Consumer restarts with same group.instance.id
    Coordinator recognizes it: "oh, you're back"
    Waits session.timeout.ms before rebalancing
    If consumer comes back within timeout: NO rebalance
    Partitions stay assigned to the instance.id

    Rolling restart: consumers come back quickly
    → zero rebalances if restart < session.timeout.ms
```

---

## Offset Management — Where Consumer Progress is Stored

```
OFFSET STORAGE INTERNALS:

Consumer tracks: for each (group, topic, partition) → last committed offset

STORAGE: __consumer_offsets internal topic
  - 50 partitions (offsets.topic.num.partitions)
  - Replication factor 3
  - Log compacted (keep latest offset per key)

  Key: (group_id, topic, partition)
  Value: (offset, metadata, commit_timestamp, expire_timestamp)

  Partition assignment:
    target_partition = abs(hash(group_id)) % 50

COMMIT PROTOCOLS:

  AUTO COMMIT (enable.auto.commit = true):
  ┌──────────────────────────────────────────────────────┐
  │ Every auto.commit.interval.ms (5000ms default):      │
  │   Automatically commit offsets of last poll() batch   │
  │                                                      │
  │ RISK: Process crash after commit but before process   │
  │ → messages skipped (at-most-once semantics)           │
  │                                                      │
  │ RISK: Process crash after process but before commit   │
  │ → messages reprocessed (at-least-once semantics)      │
  └──────────────────────────────────────────────────────┘

  MANUAL COMMIT (enable.auto.commit = false):
  ┌──────────────────────────────────────────────────────┐
  │ Synchronous:                                         │
  │   records = consumer.poll(100)                        │
  │   processRecords(records)                            │
  │   consumer.commitSync()  // blocks until broker ack  │
  │   // At-least-once: commit after process              │
  │                                                      │
  │ Asynchronous:                                        │
  │   records = consumer.poll(100)                        │
  │   processRecords(records)                            │
  │   consumer.commitAsync(callback)  // non-blocking    │
  │   // Faster but no retry on failure                   │
  │                                                      │
  │ Per-partition commit:                                  │
  │   for each partition in records.partitions():         │
  │     process(records.records(partition))               │
  │     consumer.commitSync(                              │
  │       {partition: new OffsetAndMetadata(lastOffset+1)}│
  │     )                                                 │
  └──────────────────────────────────────────────────────┘

OFFSET COMMIT REQUEST (wire format):
  OffsetCommitRequest {
    groupId: "order-processors"
    memberId: "consumer-1-uuid"
    generationId: 5
    topics: [{
      topic: "orders"
      partitions: [{
        partition: 0
        committedOffset: 42
        committedMetadata: ""  // optional string
      }]
    }]
  }

  Coordinator writes this to __consumer_offsets topic
  Log compaction keeps only latest offset per (group, topic, partition)

WHAT HAPPENS ON CONSUMER RESTART:
  1. Find coordinator
  2. JoinGroup + SyncGroup → get partition assignment
  3. For each assigned partition:
     OffsetFetchRequest → coordinator
     Response: last committed offset for (group, topic, partition)
  4. Start consuming from committed offset + 1
  5. Or from auto.offset.reset if no committed offset:
     "earliest" → start from beginning
     "latest" → start from end (miss old messages)
```

---

## The Poll Loop — Consumer's Main Processing Loop

```
CONSUMER POLL LOOP INTERNALS:

consumer.poll(Duration.ofMillis(100)):

┌────────────────────────────────────────────────────────────────┐
│ KafkaConsumer.poll(timeout):                                    │
│                                                                │
│ 1. CHECK COORDINATOR:                                          │
│    if not connected to coordinator: findCoordinator()          │
│    if group needs rejoin: joinGroup() + syncGroup()            │
│                                                                │
│ 2. FETCH DATA:                                                 │
│    // Send FetchRequest for each assigned partition             │
│    // to the leader broker for that partition                   │
│    for each assigned partition:                                │
│      if no pending fetch:                                      │
│        request = FetchRequest(                                 │
│          partition, offset=nextFetchOffset,                    │
│          maxBytes=max.partition.fetch.bytes (1MB),             │
│          minBytes=fetch.min.bytes (1 byte),                    │
│          maxWait=fetch.max.wait.ms (500ms)                     │
│        )                                                       │
│        networkClient.send(leader, request)                     │
│                                                                │
│ 3. NETWORK POLL:                                               │
│    networkClient.poll(timeout)                                 │
│    // epoll_wait() for responses and heartbeat                 │
│    // Sends pending requests, receives responses               │
│                                                                │
│ 4. PROCESS FETCH RESPONSES:                                    │
│    for each FetchResponse:                                     │
│      decompress if needed                                      │
│      deserialize keys and values                               │
│      add to internal fetch buffer (completedFetches)           │
│                                                                │
│ 5. RETURN RECORDS:                                             │
│    return records up to max.poll.records (500 default)          │
│    remaining stay in fetch buffer for next poll()              │
│                                                                │
│ 6. UPDATE POSITION:                                            │
│    nextFetchOffset = lastReturnedOffset + 1                    │
│                                                                │
└────────────────────────────────────────────────────────────────┘

FETCH REQUEST OPTIMIZATION — LONG POLLING:
  FetchRequest has:
    fetch.min.bytes = 1 (default): return when any data available
    fetch.max.wait.ms = 500: max time broker waits for min.bytes

  If partition has data: broker responds immediately
  If partition has no data: broker waits up to 500ms for new data
    Then responds (empty if still no data)

  This is LONG POLLING: reduces request frequency when idle
  Instead of: poll every 100ms → 10 requests/sec with empty responses
  With long poll: one request → wait up to 500ms → 2 requests/sec when idle
```

---

## Assignment Strategies

```
PARTITION ASSIGNMENT STRATEGIES:

1. RANGE ASSIGNOR (default):
   Assign partitions of each topic in ranges:

   Topic: orders (6 partitions), 3 consumers:
     C1: [orders-0, orders-1]  (6/3 = 2 each)
     C2: [orders-2, orders-3]
     C3: [orders-4, orders-5]

   Topic: payments (5 partitions), 3 consumers:
     C1: [payments-0, payments-1]  (5/3 = 1.67, C1 gets extra)
     C2: [payments-2, payments-3]
     C3: [payments-4]

   Problem: C1 always gets the extra partition → UNBALANCED
   With 10 topics: C1 has 10 extra partitions!

2. ROUND-ROBIN ASSIGNOR:
   All partitions across all topics in one list, round-robin:

   All partitions: [o-0, o-1, o-2, o-3, o-4, o-5, p-0, p-1, p-2, p-3, p-4]
     C1: [o-0, o-3, p-1, p-4]  (4 partitions)
     C2: [o-1, o-4, p-2]       (3 partitions)
     C3: [o-2, o-5, p-3]       (3 partitions)

   Better balance across consumers!
   But: no concept of "co-location" (related partitions together)

3. STICKY ASSIGNOR:
   Like round-robin but minimizes partition movement during rebalance.

   Initial: same as round-robin
   On rebalance (C3 dies):
     Keep existing assignments as much as possible
     Only reassign C3's partitions to C1 and C2
     
     Before: C1:[o-0,o-3,p-1,p-4] C2:[o-1,o-4,p-2] C3:[o-2,o-5,p-3]
     After:  C1:[o-0,o-3,p-1,p-4,o-2] C2:[o-1,o-4,p-2,o-5,p-3]
     
     C1 and C2 keep their existing partitions + get C3's

4. COOPERATIVE STICKY ASSIGNOR (recommended):
   Same as sticky but supports cooperative (incremental) rebalance.
   partition.assignment.strategy = CooperativeStickyAssignor
```

---

## Kafka Protocol: Wire-Level Request/Response

```
KAFKA PROTOCOL — BINARY REQUEST/RESPONSE FORMAT:

Every Kafka request/response follows this structure:

REQUEST:
  ┌──────────────────────────────────────────────────────┐
  │ Size (4 bytes, int32): total request size             │
  ├──────────────────────────────────────────────────────┤
  │ Request Header:                                      │
  │   api_key (2 bytes): identifies request type          │
  │     0 = Produce                                       │
  │     1 = Fetch                                         │
  │     3 = Metadata                                      │
  │     10 = FindCoordinator                              │
  │     11 = JoinGroup                                    │
  │     14 = SyncGroup                                    │
  │     8 = OffsetCommit                                  │
  │   api_version (2 bytes): protocol version             │
  │   correlation_id (4 bytes): matches request↔response  │
  │   client_id (string): identifying the client          │
  ├──────────────────────────────────────────────────────┤
  │ Request Body: (varies by api_key)                     │
  └──────────────────────────────────────────────────────┘

RESPONSE:
  ┌──────────────────────────────────────────────────────┐
  │ Size (4 bytes, int32): total response size            │
  ├──────────────────────────────────────────────────────┤
  │ Response Header:                                     │
  │   correlation_id (4 bytes): matches request           │
  ├──────────────────────────────────────────────────────┤
  │ Response Body: (varies by api_key)                    │
  └──────────────────────────────────────────────────────┘

MULTIPLEXING:
  Multiple requests in-flight on same TCP connection
  correlation_id links response back to request
  max.in.flight.requests.per.connection = 5

  Client sends: req(corr=1), req(corr=2), req(corr=3)
  Broker responds: resp(corr=2), resp(corr=1), resp(corr=3)
    (not necessarily in order!)
  Client matches by correlation_id

METADATA REFRESH:
  metadata.max.age.ms = 300000 (5 min)
  Consumer/Producer periodically refresh cluster metadata:
    - Which brokers are alive
    - Which broker leads which partition
    - How many partitions per topic
  Also refreshes on: UNKNOWN_TOPIC, NOT_LEADER errors
```

---

## Consumer Lag and Monitoring

```
CONSUMER LAG — THE KEY HEALTH METRIC:

Lag = latest offset in partition - consumer's committed offset

  Partition orders-0:
    Log End Offset (LEO): 10000
    Consumer committed offset: 9500
    Lag = 500 messages

  If producer sends 100 msg/sec and consumer processes 80 msg/sec:
    Lag grows by 20 msg/sec
    After 1 hour: lag = 72,000 messages
    Consumer falls further behind → stale data

MONITORING TOOLS:
  kafka-consumer-groups.sh --describe --group order-processors
  ┌──────────┬───────┬────────┬──────┬─────┬──────────┐
  │ TOPIC    │ PART  │ OFFSET │ LEO  │ LAG │ CONSUMER │
  ├──────────┼───────┼────────┼──────┼─────┼──────────┤
  │ orders   │ 0     │ 9500   │ 10000│ 500 │ C1       │
  │ orders   │ 1     │ 8200   │ 8200 │ 0   │ C2       │
  │ orders   │ 2     │ 7100   │ 9900 │ 2800│ C3       │
  └──────────┴───────┴────────┴──────┴─────┴──────────┘

  Partition 2: lag of 2800 → C3 is slow or stuck!

FIXING HIGH LAG:
  1. Add more consumers (up to partition count)
  2. Increase partitions (requires topic reconfiguration)
  3. Optimize consumer processing (batch DB writes, async)
  4. Increase max.poll.records (process more per poll)
  5. Check for poison messages blocking progress
  6. Check consumer for GC pauses, slow dependencies
```

---

## 30-SECOND REVISION BOX

```
PRODUCER: send()→serialize→partition→accumulate→batch→Sender thread→wire
BATCHING: batch.size + linger.ms, BufferPool for memory management
PARTITIONER: hash(key)%N for keyed, sticky for unkeyed
CONSUMER GROUP: coordinator → JoinGroup → SyncGroup → Heartbeat
REBALANCE: eager (stop-the-world) vs cooperative (incremental)
STATIC MEMBERSHIP: group.instance.id → no rebalance on restart
OFFSETS: __consumer_offsets (compacted topic, 50 partitions)
COMMIT: auto (5s interval) vs manual (commitSync/commitAsync)
POLL LOOP: fetch data, network poll, deserialize, return records
ASSIGNMENT: range, round-robin, sticky, cooperative-sticky
LAG: LEO - committed offset; key health metric
```

---

**Prev: [[11_Internals-Kafka-Replication-Consensus]] | Next: [[13_Internals-RabbitMQ-Deep-Dive]]**
