# Back-of-Envelope Estimation — Common Mistakes  


---

## Mistake 1: Being Too Precise


| Wrong                | Right                                |
| -------------------- | ------------------------------------ |
| "We need 47,382 QPS" | "~50K QPS" or "order of 50 thousand" |
| "Storage is 12.7 PB" | "~10–15 PB"                          |


## Mistake 2: Forgetting Read vs Write Ratio


| System | Typical Ratio | Impact if Ignored                          |
| ------ | ------------- | ------------------------------------------ |
| Feed   | 100:1         | Overprovision writes, underprovision reads |
| Chat   | 1:1           | May get right by accident                  |
| Video  | 1000:1        | Massively wrong—reads dominate             |


**Fix:** Always ask or assume read:write. Default 100:1 for feed, 10:1 for e-commerce.

---

## Mistake 3: Underestimating Storage Growth


| Wrong            | Right                   |
| ---------------- | ----------------------- |
| "1 year of data" | "5 years + growth rate" |
| Linear growth    | Compound (rule of 72)   |


**Fix:** Multiply by retention years. Add 20–50% for growth if system evolves.

---

## Mistake 4: Ignoring Peak vs Average


| Wrong                        | Right                       |
| ---------------------------- | --------------------------- |
| Use average QPS for capacity | Use peak (2–10× average)    |
| "17K QPS" for servers        | "50K peak → 50 web servers" |


**Fix:** Always apply peak factor (2–3× typical, up to 10× for viral).

---

## Mistake 5: Wrong Unit Conversions


| Conversion   | Wrong        | Right                   |
| ------------ | ------------ | ----------------------- |
| Seconds/day  | 86400        | 86400 ≈ 10^5            |
| Bytes → bits | × 1          | × 8                     |
| KB vs KB     | 1000 vs 1024 | Use 1000 for estimation |
| Mbps vs MB/s | Confused     | 8 Mbps = 1 MB/s         |


```
    BANDWIDTH: bytes × 8 = bits
    TIME: 86400 sec/day, 2.5M sec/month
```

---

## Mistake 6: Not Stating Assumptions


| Wrong         | Right                                        |
| ------------- | -------------------------------------------- |
| "QPS is 50K"  | "Assuming 100M DAU, 5 actions/day → 50K QPS" |
| Silent inputs | "Let me assume read:write is 100:1"          |


**Fix:** Say "Assume X" for every input. Interviewer can correct if wrong.

---

## Mistake 7: Spending Too Long


| Wrong                 | Right                |
| --------------------- | -------------------- |
| 10+ min on estimation | 2–3 min max          |
| Perfect numbers       | Good enough, move on |


**Fix:** Set a mental timer. After QPS, storage, bandwidth—proceed to design.

---

## Mistake 8: Forgetting Metadata Overhead


| Raw Data        | With Metadata                         |
| --------------- | ------------------------------------- |
| 140 bytes/tweet | ~300 bytes (IDs, timestamps, indexes) |
| 1KB message     | ~1.2KB (headers, metadata)            |


**Fix:** Add 20–30% for metadata, or use "bytes per item" that includes it.

---

## Mistake 9: Ignoring Replication Factor


| Wrong         | Right                      |
| ------------- | -------------------------- |
| 1 copy = 1 TB | 3 copies = 3 TB (typical)  |
| Single region | Multi-region = more copies |


**Fix:** Multiply storage by replication (3× common for durability).

---

## Mistake 10: Not Considering Cache Hit Ratio


| Without cache          | With 80% hit  | Impact              |
| ---------------------- | ------------- | ------------------- |
| 100K read QPS to DB    | 20K to DB     | 5× fewer DB servers |
| All requests to origin | 20% to origin | Bandwidth savings   |


**Fix:** If caching is in design, apply hit ratio to reduce DB/origin load.

---

## Summary Table


| #   | Mistake        | One-Line Fix                    |
| --- | -------------- | ------------------------------- |
| 1   | Too precise    | Round to powers of 10           |
| 2   | No read:write  | Assume 100:1 or 10:1            |
| 3   | Storage growth | 5-year retention, growth factor |
| 4   | Peak vs avg    | Use 2–10× peak factor           |
| 5   | Unit errors    | 86400, ×8 for bits              |
| 6   | No assumptions | State "Assume X"                |
| 7   | Too long       | 2–3 min cap                     |
| 8   | No metadata    | +20–30% overhead                |
| 9   | No replication | ×3 for storage                  |
| 10  | No cache ratio | Apply hit % to DB load          |


---

## 30-SECOND REVISION BOX

```
PRECISION: Round, don't over-specify
READ:WRITE: Always factor in
PEAK: 2–10× average
UNITS: 86400, ×8 for bps
ASSUMPTIONS: State them
TIME: 2–3 min
METADATA: +20–30%
REPLICATION: ×3
CACHE: Hit ratio reduces DB load
```

---

**Next: [[06_Edge-Cases]]**