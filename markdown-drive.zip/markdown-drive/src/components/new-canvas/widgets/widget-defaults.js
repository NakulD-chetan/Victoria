/**
 * Per-widget-type "last used" defaults.
 *
 * Stored in localStorage under `nc:defaults:<widgetType>`. When a user
 * tweaks a widget via the right-side properties panel, we mirror the
 * change here so the next widget of the same type spawns with the same
 * configuration.
 *
 * Storage shape (loose JSON; missing keys fall back to hardcoded
 * defaults from widget-registry):
 *
 *   nc:defaults:code  → { language, fontFamily, fontSize, chromeBg,
 *                         strokeColor, strokeWidth }
 *   nc:defaults:note  → { color, textColor, fontFamily, fontSize,
 *                         strokeColor, strokeWidth }
 *   nc:defaults:array → { chromeBg, valueFontSize, valueColor,
 *                         strokeColor, strokeWidth }
 *   nc:defaults:agent → { chromeBg, accentColor,
 *                         strokeColor, strokeWidth }
 */

const KEY = (type) => `nc:defaults:${type}`;

const SUPPORTED = new Set([
  'code',
  'note',
  'array',
  'json',
  'csv',
  'linked-list',
  'stack',
  'queue',
  'tree',
  'hash-map',
  'agent',
]);

export function loadDefaults(widgetType) {
  if (!SUPPORTED.has(widgetType)) return {};
  if (typeof localStorage === 'undefined') return {};
  try {
    const raw = localStorage.getItem(KEY(widgetType));
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function saveDefaults(widgetType, patch) {
  if (!SUPPORTED.has(widgetType)) return;
  if (typeof localStorage === 'undefined') return;
  if (!patch || typeof patch !== 'object') return;
  try {
    const current = loadDefaults(widgetType);
    const next = { ...current, ...patch };
    localStorage.setItem(KEY(widgetType), JSON.stringify(next));
  } catch {
    // localStorage might be full or blocked; treat as best-effort.
  }
}

/**
 * Pull only the fields relevant to a given widget type. Used by
 * createWidgetElement so we can apply defaults selectively without
 * leaking unrelated keys into widgetData/style.
 */
export function pickDefaultsFor(widgetType) {
  return loadDefaults(widgetType) || {};
}
