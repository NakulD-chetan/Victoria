# System-Patterns — Interview Thinking

> **Permanent Recall:** The complete FAANG interview flow in 45 minutes. Time management, when to ask for hints, how to recover from being stuck. Communication script for each phase.

---

## 45-Minute Breakdown

| Phase | Time | Cumulative | Focus |
|-------|------|------------|-------|
| **Read & Clarify** | 3–4 min | 4 min | Understand problem, ask 2–3 clarifying Qs |
| **Brute Force** | 4–5 min | 9 min | State naive solution, get buy-in |
| **Optimize** | 8–12 min | 21 min | Identify pattern, explain approach |
| **Code** | 18–22 min | 43 min | Write clean, modular code |
| **Test & Fix** | 5–7 min | 50 min | Walk through examples, fix bugs |

**Buffer:** 5 min for discussion or follow-up. Aim to finish main solution by 40 min.

---

## Phase 1: Read & Clarify (3–4 min)

### Actions
- Read problem **twice**
- Note: inputs, outputs, constraints
- Ask 2–3 clarifying questions

### Communication Script

| Situation | Script |
|-----------|--------|
| **Starting** | "Let me read through this carefully..." |
| **Clarify duplicates** | "Can the array contain duplicates?" |
| **Clarify empty** | "Can the input be empty? What should we return?" |
| **Clarify negatives** | "Are all numbers non-negative, or can we have negatives?" |
| **Clarify overflow** | "Should I worry about integer overflow?" |
| **Clarify format** | "Is the graph given as adjacency list or matrix?" |
| **Confirm understanding** | "So we need to find the minimum X such that condition Y holds — is that right?" |

### Red Flags to Avoid
- Jumping to code before clarifying
- Assuming constraints (e.g., "I'll assume no duplicates")
- Skipping the read — missing a key detail

---

## Phase 2: Brute Force (4–5 min)

### Actions
- State the naive O(n²) or worse solution
- Get interviewer buy-in
- Identify the bottleneck

### Communication Script

| Situation | Script |
|-----------|--------|
| **Brute force** | "A brute force would be to try all pairs / enumerate all subsets — that would be O(n²) / O(2^n)." |
| **Bottleneck** | "The bottleneck is [repeated work / redundant computation]. We can optimize by..." |
| **Transition** | "We can do better. I'm thinking we could use [pattern] because..." |

### Why Brute First?
- Shows you can solve the problem
- Gives a fallback if optimization fails
- Interviewer may accept brute for easy problems

---

## Phase 3: Optimize (8–12 min)

### Actions
- Identify the right pattern (use constraint → algorithm mapping)
- Explain approach before coding
- Draw if helpful (arrays, trees, intervals)

### Communication Script

| Situation | Script |
|-----------|--------|
| **Pattern recognition** | "This looks like a binary search on the answer problem — we search for the minimum X and check feasibility." |
| **Complexity** | "That would give us O(n log V) where V is the range of possible answers." |
| **Ask before coding** | "Does this approach sound good before I start coding?" |
| **Alternative** | "We could also use a heap here, but I think [chosen approach] is cleaner." |

---

## Phase 4: Code (18–22 min)

### Actions
- Write clean, readable code
- Use meaningful variable names
- Modularize (helper functions)
- Think out loud for tricky parts

### Communication Script

| Situation | Script |
|-----------|--------|
| **Starting** | "I'll implement the binary search first, then the feasibility check." |
| **Stuck on syntax** | "Let me think — in Python we'd use..." |
| **Edge case** | "I need to handle the empty case here." |
| **Refactor** | "I'll extract this into a helper for clarity." |
| **Progress** | "The main logic is done; now I need to handle the base case." |

### Coding Discipline
- **Don't** write one giant function
- **Do** use `check(mid)` or `feasible(k)` for BS on answer
- **Do** add a comment for non-obvious logic

---

## Phase 5: Test & Fix (5–7 min)

### Actions
- Walk through 1–2 examples
- Test edge cases: empty, single, boundary
- Fix any bugs found

### Communication Script

| Situation | Script |
|-----------|--------|
| **Testing** | "Let me trace through with [example]. For n=5, we get..." |
| **Edge case** | "For empty input, we return 0 — that's correct." |
| **Bug found** | "I see the issue — we need to handle when lo == hi. Let me fix that." |
| **Done** | "I think that covers the main cases. Any edge cases you'd like me to consider?" |

---

## When to Ask for Hints

| Time Elapsed | Situation | Script |
|--------------|-----------|--------|
| 5–8 min | No approach yet | "I'm considering a few directions — could you point me toward whether [X] or [Y] is more promising?" |
| 12–15 min | Stuck on optimization | "I have the brute force — would binary search on the answer be a good direction here?" |
| 25–30 min | Stuck on implementation | "I'm hitting an edge case with the loop condition — any hint on the invariant?" |
| 35+ min | Major blocker | "I think I'm overcomplicating this. Is there a simpler pattern I'm missing?" |

### Hint Etiquette
- **Ask specific questions** — "Should we use a heap?" not "What's the solution?"
- **Show your thinking** — "I tried X but it doesn't work because Y"
- **One hint at a time** — Process it before asking for more

---

## How to Recover When Stuck

| Step | Action |
|------|--------|
| 1 | **Re-read** — Did you miss a constraint? |
| 2 | **Brute force** — Can you solve it slowly? |
| 3 | **Small n** — What would you do for n=3? |
| 4 | **Similar problem** — "This reminds me of Two Sum / Merge Intervals..." |
| 5 | **Ask hint** — "Would [pattern] work here?" |
| 6 | **Simplify** — Solve a smaller version (e.g., 1D instead of 2D) |

### Recovery Script
"I'm a bit stuck. Let me try a different angle — for a small example like n=3, we could... Does that generalize? Or would [pattern] be better?"

---

## Time Management Alerts

| Time | Alert | Action |
|------|-------|--------|
| 10 min | Still clarifying / no approach | Speed up; state brute force quickly |
| 20 min | No code yet | Start coding even if not fully optimized |
| 35 min | Code not done | Simplify; get working solution first |
| 42 min | No testing | At least trace one example verbally |
| 48 min | Over time | "I'd fix [X] with one more minute — should I continue?" |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PHASES:       Read(4) → Brute(5) → Optimize(12) → Code(22) → Test(7)
CLARIFY:      Duplicates? Empty? Negatives? Overflow?
BRUTE:        State naive, get buy-in, find bottleneck
OPTIMIZE:     Pattern + complexity, ask before coding
CODE:         Modular, think aloud, handle edges
TEST:         Trace example, empty/single, fix bugs
HINTS:        Ask specific; show thinking; one at a time
RECOVERY:     Re-read, brute, small n, similar, ask
```

---

## 30-SECOND REVISION BOX

```
□ 45 min: 4 clarify, 5 brute, 12 optimize, 22 code, 7 test
□ Clarify: duplicates, empty, negatives
□ Brute first — always state naive
□ Ask "does this approach sound good?" before coding
□ Stuck: re-read, brute, small n, ask hint
□ Hint: specific question, show thinking
□ Time alert: 20 min no code → start coding
```
