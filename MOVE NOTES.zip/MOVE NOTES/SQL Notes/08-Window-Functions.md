# Window Functions — Complete Guide

> **Window Functions = Aggregate jaise calculation karo, but rows collapse mat karo!**
> Yeh FAANG interviews ka **favorite topic** hai — ROW_NUMBER, RANK, LAG, LEAD sab yahan se aate hain.
> GROUP BY mein rows merge ho jaati hain, Window Functions mein **har row apni jagah** rehti hai.

---

## GROUP BY vs Window Function — Kya Fark Hai?

```
GROUP BY:                              Window Function:
┌─────────────────┐                    ┌─────────────────────────────┐
│ IT  → AVG=82500 │ ← Rows merged     │ Rahul  IT  75000  AVG=82500│ ← Row intact!
│ HR  → AVG=60000 │                    │ Amit   IT  80000  AVG=82500│
│ Fin → AVG=71000 │                    │ Neha   IT  90000  AVG=82500│
└─────────────────┘                    │ Priya  HR  65000  AVG=60000│
  3 rows only                          │ Karan  HR  55000  AVG=60000│
                                       │ Sneha  Fin 70000  AVG=71000│
                                       └─────────────────────────────┘
                                         6 rows (sab original rows + extra column)
```

> **Key Difference:** GROUP BY rows collapse kar deta hai (1 row per group). Window Function **har row ke saath** aggregate result add karta hai.

---

## Basic Syntax

```sql
function_name(column) OVER (
    [PARTITION BY column(s)]
    [ORDER BY column(s)]
    [ROWS/RANGE frame_clause]
)
```


| Part              | Kya Karta Hai                                       |
| ----------------- | --------------------------------------------------- |
| **function_name** | ROW_NUMBER, RANK, SUM, AVG, etc.                    |
| **OVER()**        | Window function ka signal — yeh bata ke rakhte hain |
| **PARTITION BY**  | Groups banao (like GROUP BY, but rows intact)       |
| **ORDER BY**      | Group ke andar sorting                              |
| **Frame Clause**  | Kitne rows consider karne hain (advanced)           |


---

## Sample Table

```
Table: employees
+----+--------+------------+--------+
| id | name   | department | salary |
+----+--------+------------+--------+
| 1  | Rahul  | IT         | 75000  |
| 2  | Priya  | HR         | 65000  |
| 3  | Amit   | IT         | 80000  |
| 4  | Sneha  | Finance    | 70000  |
| 5  | Karan  | HR         | 55000  |
| 6  | Neha   | IT         | 90000  |
| 7  | Rohan  | Finance    | 72000  |
| 8  | Divya  | IT         | 85000  |
+----+--------+------------+--------+
```

---

## 1. ROW_NUMBER() — Har Row Ko Number Do

> **Definition:** Assigns a unique sequential number to each row within a partition.

```sql
SELECT
    name, department, salary,
    ROW_NUMBER() OVER (ORDER BY salary DESC) AS row_num
FROM employees;
```

```
+--------+------------+--------+---------+
| name   | department | salary | row_num |
+--------+------------+--------+---------+
| Neha   | IT         | 90000  | 1       |
| Divya  | IT         | 85000  | 2       |
| Amit   | IT         | 80000  | 3       |
| Rahul  | IT         | 75000  | 4       |
| Rohan  | Finance    | 72000  | 5       |
| Sneha  | Finance    | 70000  | 6       |
| Priya  | HR         | 65000  | 7       |
| Karan  | HR         | 55000  | 8       |
+--------+------------+--------+---------+
```

### ROW_NUMBER with PARTITION BY:

```sql
SELECT
    name, department, salary,
    ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS dept_rank
FROM employees;

```

```
+--------+------------+--------+-----------+
| name   | department | salary | dept_rank |
+--------+------------+--------+-----------+
| Rohan  | Finance    | 72000  | 1         |  ← Finance group
| Sneha  | Finance    | 70000  | 2         |
| Priya  | HR         | 65000  | 1         |  ← HR group (reset!)
| Karan  | HR         | 55000  | 2         |
| Neha   | IT         | 90000  | 1         |  ← IT group (reset!)
| Divya  | IT         | 85000  | 2         |
| Amit   | IT         | 80000  | 3         |
| Rahul  | IT         | 75000  | 4         |
+--------+------------+--------+-----------+
```

> **PARTITION BY** se har group mein numbering **1 se restart** hoti hai.

---

## 2. RANK() vs DENSE_RANK() vs ROW_NUMBER() — MUST KNOW!

> **Interview mein TOP 3 question hai yeh difference!**

### Salary data with ties (same values):

```
Salaries: 90000, 85000, 85000, 75000, 72000
```

```sql
SELECT
    name, salary,
    ROW_NUMBER() OVER (ORDER BY salary DESC) AS row_num,
    RANK()       OVER (ORDER BY salary DESC) AS rank_val,
    DENSE_RANK() OVER (ORDER BY salary DESC) AS dense_rank_val
FROM employees;
```

```
+--------+--------+---------+----------+----------------+
| name   | salary | row_num | rank_val | dense_rank_val |
+--------+--------+---------+----------+----------------+
| Neha   | 90000  | 1       | 1        | 1              |
| Amit   | 85000  | 2       | 2        | 2              |  ← Same salary
| Divya  | 85000  | 3       | 2        | 2              |  ← Same salary
| Rahul  | 75000  | 4       | 4        | 3              |  ← RANK skips 3!
| Rohan  | 72000  | 5       | 5        | 4              |
| Sneha  | 70000  | 6       | 6        | 5              |
+--------+--------+---------+----------+----------------+
```

### Comparison:


| Function       | Ties (Same Value)             | Gaps?             | Example           |
| -------------- | ----------------------------- | ----------------- | ----------------- |
| **ROW_NUMBER** | Different numbers (arbitrary) | No gaps           | 1, 2, 3, 4, 5     |
| **RANK**       | Same rank                     | ✅ Gaps after ties | 1, 2, 2, **4**, 5 |
| **DENSE_RANK** | Same rank                     | ❌ No gaps         | 1, 2, 2, **3**, 4 |


> **Yaad kaise rakhen?**
>
> - **ROW_NUMBER** = Unique number, chahe value same ho
> - **RANK** = Same value → same rank, phir **skip** (like 1, 2, 2, 4)
> - **DENSE_RANK** = Same value → same rank, **no skip** (like 1, 2, 2, 3)

---

## 3. NTILE(n) — Groups Mein Baanto

> **Definition:** Divides the result set into N approximately equal groups.

```sql
SELECT
    name, salary,
    NTILE(4) OVER (ORDER BY salary DESC) AS quartile
FROM employees;
```

```
+--------+--------+----------+
| name   | salary | quartile |
+--------+--------+----------+
| Neha   | 90000  | 1        |  ← Top 25%
| Divya  | 85000  | 1        |
| Amit   | 80000  | 2        |  ← 25-50%
| Rahul  | 75000  | 2        |
| Rohan  | 72000  | 3        |  ← 50-75%
| Sneha  | 70000  | 3        |
| Priya  | 65000  | 4        |  ← Bottom 25%
| Karan  | 55000  | 4        |
+--------+--------+----------+
```

> **Use Case:** Percentile calculate karna, Top N% identify karna.

---

## 4. LAG() and LEAD() — Previous/Next Row Ka Value

> **Definition:** LAG looks at previous row, LEAD looks at next row in the result.

### LAG — Previous Row:

```sql
SELECT
    name, salary,
    LAG(salary, 1) OVER (ORDER BY salary DESC) AS prev_salary,
    salary - LAG(salary, 1) OVER (ORDER BY salary DESC) AS diff
FROM employees;
```

```
+--------+--------+-------------+-------+
| name   | salary | prev_salary | diff  |
+--------+--------+-------------+-------+
| Neha   | 90000  | NULL        | NULL  |  ← Pehle koi nahi
| Divya  | 85000  | 90000       | -5000 |
| Amit   | 80000  | 85000       | -5000 |
| Rahul  | 75000  | 80000       | -5000 |
| Rohan  | 72000  | 75000       | -3000 |
| Sneha  | 70000  | 72000       | -2000 |
| Priya  | 65000  | 70000       | -5000 |
| Karan  | 55000  | 65000       | -10000|
+--------+--------+-------------+-------+
```

### LEAD — Next Row:

```sql
SELECT
    name, salary,
    LEAD(salary, 1) OVER (ORDER BY salary DESC) AS next_salary
FROM employees;
```

### LAG/LEAD with Default Value:

```sql
-- NULL ki jagah 0 daalo
LAG(salary, 1, 0) OVER (ORDER BY salary DESC)
--                  ↑ default value when no previous row
```

> **LAG/LEAD bahut useful hai:**
>
> - Month-over-month comparison
> - Running difference
> - Finding consecutive records
> - Year-over-year growth

---

## 5. FIRST_VALUE() and LAST_VALUE()

```sql
SELECT
    name, department, salary,
    FIRST_VALUE(name) OVER (
        PARTITION BY department ORDER BY salary DESC
    ) AS highest_earner,
    LAST_VALUE(name) OVER (
        PARTITION BY department ORDER BY salary DESC
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
    ) AS lowest_earner
FROM employees;
```

> **LAST_VALUE warning:** By default, window frame sirf current row tak hota hai. Pura group chahiye toh `ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING` likhna padega.

---

## 6. Aggregate Functions as Window Functions

> SUM, AVG, COUNT, MIN, MAX — sab window function ke taur pe bhi use ho sakte hain!

### Running Total:

```sql
SELECT
    name, salary,
    SUM(salary) OVER (ORDER BY id) AS running_total
FROM employees;
```

```
+--------+--------+---------------+
| name   | salary | running_total |
+--------+--------+---------------+
| Rahul  | 75000  | 75000         |
| Priya  | 65000  | 140000        |
| Amit   | 80000  | 220000        |
| Sneha  | 70000  | 290000        |
| Karan  | 55000  | 345000        |
| Neha   | 90000  | 435000        |
| Rohan  | 72000  | 507000        |
| Divya  | 85000  | 592000        |
+--------+--------+---------------+
```

### Partition-wise Average:

```sql
SELECT
    name, department, salary,
    AVG(salary) OVER (PARTITION BY department) AS dept_avg,
    salary - AVG(salary) OVER (PARTITION BY department) AS diff_from_avg
FROM employees;
```

---

## 7. Frame Clause — ROWS and RANGE

> **Definition:** Frame clause defines which rows within the partition are included in the calculation for each row.

### Syntax:

```sql
ROWS BETWEEN start AND end
```


| Frame Boundary        | Meaning                   |
| --------------------- | ------------------------- |
| `UNBOUNDED PRECEDING` | Partition ki pehli row se |
| `N PRECEDING`         | Current se N rows pehle   |
| `CURRENT ROW`         | Current row               |
| `N FOLLOWING`         | Current se N rows baad    |
| `UNBOUNDED FOLLOWING` | Partition ki last row tak |


### Examples:

```sql
-- Last 3 rows ka moving average (current + 2 preceding)
SELECT
    name, salary,
    AVG(salary) OVER (
        ORDER BY id
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS moving_avg_3
FROM employees;

-- Running total (start se current tak)
SELECT
    name, salary,
    SUM(salary) OVER (
        ORDER BY id
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS running_total
FROM employees;
```

### ROWS vs RANGE:


| Feature    | ROWS                  | RANGE                      |
| ---------- | --------------------- | -------------------------- |
| **Basis**  | Physical row position | Logical value              |
| **Ties**   | Each row separately   | Same-value rows together   |
| **Common** | More predictable      | Less predictable with ties |


> **Tip:** Usually **ROWS** use karo — zyada predictable hai.

---

## 8. Common Interview Patterns with Window Functions

### Pattern 1: Top N per Group

```sql
-- Top 2 salary earners per department
WITH ranked AS (
    SELECT
        name, department, salary,
        ROW_NUMBER() OVER (PARTITION BY department ORDER BY salary DESC) AS rn
    FROM employees
)
SELECT name, department, salary
FROM ranked
WHERE rn <= 2;
```

### Pattern 2: Running Total / Cumulative Sum

```sql
SELECT
    sale_date, amount,
    SUM(amount) OVER (ORDER BY sale_date) AS cumulative_sales
FROM sales;
```

### Pattern 3: Month-over-Month Growth

```sql
WITH monthly AS (
    SELECT
        DATE_FORMAT(sale_date, '%Y-%m') AS month,
        SUM(amount) AS total
    FROM sales
    GROUP BY DATE_FORMAT(sale_date, '%Y-%m')
)
SELECT
    month, total,
    LAG(total) OVER (ORDER BY month) AS prev_month,
    ROUND((total - LAG(total) OVER (ORDER BY month)) * 100.0
          / LAG(total) OVER (ORDER BY month), 2) AS growth_pct
FROM monthly;
```

### Pattern 4: Find Consecutive Records

```sql
-- Employees who joined on consecutive days
SELECT
    name, join_date,
    LAG(join_date) OVER (ORDER BY join_date) AS prev_date,
    DATEDIFF(join_date, LAG(join_date) OVER (ORDER BY join_date)) AS days_gap
FROM employees
HAVING days_gap = 1;
```

### Pattern 5: Median Salary

```sql
WITH ranked AS (
    SELECT
        salary,
        ROW_NUMBER() OVER (ORDER BY salary) AS rn,
        COUNT(*) OVER () AS total
    FROM employees
)
SELECT AVG(salary) AS median
FROM ranked
WHERE rn IN (FLOOR((total + 1) / 2), CEIL((total + 1) / 2));
```

---

## Quick Memory Card


| Function     | Kya Karta Hai         | Ties Mein          | Example Output     |
| ------------ | --------------------- | ------------------ | ------------------ |
| ROW_NUMBER   | Unique number         | Alag number        | 1, 2, 3, 4, 5      |
| RANK         | Ranking with gaps     | Same rank, skip    | 1, 2, 2, 4, 5      |
| DENSE_RANK   | Ranking without gaps  | Same rank, no skip | 1, 2, 2, 3, 4      |
| NTILE(n)     | N groups mein baanto  | Approx equal       | 1,1, 2,2, 3,3, 4,4 |
| LAG(col, n)  | N rows pehle ka value | N/A                | Previous row value |
| LEAD(col, n) | N rows baad ka value  | N/A                | Next row value     |
| FIRST_VALUE  | Group ki pehli value  | N/A                | First in partition |
| LAST_VALUE   | Group ki last value   | Need full frame    | Last in partition  |
| SUM() OVER   | Running/partition sum | N/A                | Cumulative total   |
| AVG() OVER   | Running/partition avg | N/A                | Moving average     |


> **Yaad Rakho:**
>
> - **PARTITION BY** = GROUP BY jaisa but rows intact
> - **ORDER BY** = Window ke andar sorting
> - **ROW_NUMBER** = Pagination, dedup, Top-N
> - **RANK/DENSE_RANK** = Ranking problems
> - **LAG/LEAD** = Comparison with previous/next row
> - **Frame Clause** = Running total, moving average

---

*Notes Source: SQL Window Functions + FAANG Interview preparation material*