// ═══════════════════════════════════════════════════════════════════
//  Smart IDE Autocomplete Engine — Tier 1
//  Symbol Knowledge Base + Auto-Include + Context Detection
// ═══════════════════════════════════════════════════════════════════

// ── SYMBOL → HEADER Knowledge Base (200+ mappings) ───────────────
const SYMBOL_HEADERS = {
  // <iostream>
  cout: 'iostream', cin: 'iostream', cerr: 'iostream', clog: 'iostream',
  endl: 'iostream', getline: 'iostream', ws: 'iostream',
  // <string>
  string: 'string', stoi: 'string', stol: 'string', stoll: 'string',
  stof: 'string', stod: 'string', to_string: 'string', string_view: 'string_view',
  // <vector>
  vector: 'vector',
  // <array>
  array: 'array',
  // <map> / <unordered_map>
  map: 'map', multimap: 'map', unordered_map: 'unordered_map', unordered_multimap: 'unordered_map',
  // <set> / <unordered_set>
  set: 'set', multiset: 'set', unordered_set: 'unordered_set', unordered_multiset: 'unordered_set',
  // <queue>
  queue: 'queue', priority_queue: 'queue',
  // <stack>
  stack: 'stack',
  // <deque>
  deque: 'deque',
  // <list>
  list: 'list', forward_list: 'forward_list',
  // <bitset>
  bitset: 'bitset',
  // <algorithm>
  sort: 'algorithm', stable_sort: 'algorithm', reverse: 'algorithm',
  find: 'algorithm', find_if: 'algorithm', find_if_not: 'algorithm',
  count: 'algorithm', count_if: 'algorithm',
  min_element: 'algorithm', max_element: 'algorithm',
  lower_bound: 'algorithm', upper_bound: 'algorithm', binary_search: 'algorithm',
  unique: 'algorithm', next_permutation: 'algorithm', prev_permutation: 'algorithm',
  fill: 'algorithm', transform: 'algorithm', for_each: 'algorithm',
  copy: 'algorithm', copy_if: 'algorithm', remove: 'algorithm', remove_if: 'algorithm',
  replace: 'algorithm', replace_if: 'algorithm', swap_ranges: 'algorithm',
  rotate: 'algorithm', shuffle: 'algorithm', merge: 'algorithm',
  includes: 'algorithm', set_union: 'algorithm', set_intersection: 'algorithm',
  set_difference: 'algorithm', is_sorted: 'algorithm', nth_element: 'algorithm',
  partial_sort: 'algorithm', partition: 'algorithm', all_of: 'algorithm',
  any_of: 'algorithm', none_of: 'algorithm', clamp: 'algorithm',
  // <numeric>
  accumulate: 'numeric', iota: 'numeric', inner_product: 'numeric',
  partial_sum: 'numeric', adjacent_difference: 'numeric', gcd: 'numeric', lcm: 'numeric',
  reduce: 'numeric', transform_reduce: 'numeric',
  // <utility>
  pair: 'utility', make_pair: 'utility', swap: 'utility', move: 'utility', forward: 'utility',
  // <tuple>
  tuple: 'tuple', make_tuple: 'tuple', get: 'tuple', tie: 'tuple',
  // <memory>
  unique_ptr: 'memory', shared_ptr: 'memory', weak_ptr: 'memory',
  make_unique: 'memory', make_shared: 'memory',
  // <functional>
  function: 'functional', bind: 'functional', ref: 'functional',
  // <iterator>
  distance: 'iterator', advance: 'iterator', next: 'iterator', prev: 'iterator',
  back_inserter: 'iterator', front_inserter: 'iterator', inserter: 'iterator',
  // <cmath>
  sqrt: 'cmath', pow: 'cmath', abs: 'cmath', ceil: 'cmath', floor: 'cmath',
  round: 'cmath', log: 'cmath', log2: 'cmath', log10: 'cmath',
  sin: 'cmath', cos: 'cmath', tan: 'cmath', asin: 'cmath', acos: 'cmath', atan: 'cmath',
  atan2: 'cmath', exp: 'cmath', fmod: 'cmath', hypot: 'cmath',
  // <climits>
  INT_MAX: 'climits', INT_MIN: 'climits', LONG_MAX: 'climits', LONG_MIN: 'climits',
  LLONG_MAX: 'climits', LLONG_MIN: 'climits', UINT_MAX: 'climits', CHAR_MAX: 'climits',
  // <limits>
  numeric_limits: 'limits',
  // <cstdlib>
  rand: 'cstdlib', srand: 'cstdlib', atoi: 'cstdlib', atof: 'cstdlib',
  malloc: 'cstdlib', free: 'cstdlib', exit: 'cstdlib', system: 'cstdlib',
  // <cstdio>
  printf: 'cstdio', scanf: 'cstdio', fprintf: 'cstdio', sprintf: 'cstdio',
  sscanf: 'cstdio', puts: 'cstdio', getchar: 'cstdio', putchar: 'cstdio',
  // <cstring>
  strlen: 'cstring', strcmp: 'cstring', strcpy: 'cstring', strcat: 'cstring',
  memcpy: 'cstring', memset: 'cstring', memcmp: 'cstring',
  // <cctype>
  isalpha: 'cctype', isdigit: 'cctype', isalnum: 'cctype', isspace: 'cctype',
  isupper: 'cctype', islower: 'cctype', toupper: 'cctype', tolower: 'cctype',
  // <sstream>
  stringstream: 'sstream', istringstream: 'sstream', ostringstream: 'sstream',
  // <fstream>
  ifstream: 'fstream', ofstream: 'fstream', fstream: 'fstream',
  // <iomanip>
  setw: 'iomanip', setprecision: 'iomanip', setfill: 'iomanip', fixed: 'iomanip',
  // <random>
  mt19937: 'random', uniform_int_distribution: 'random', uniform_real_distribution: 'random',
  // <chrono>
  chrono: 'chrono',
  // <thread>
  thread: 'thread', this_thread: 'thread',
  // <mutex>
  mutex: 'mutex', lock_guard: 'mutex', unique_lock: 'mutex',
  // <atomic>
  atomic: 'atomic',
  // <optional>
  optional: 'optional', nullopt: 'optional',
  // <variant>
  variant: 'variant', visit: 'variant',
  // <any>
  any: 'any', any_cast: 'any',
  // <regex>
  regex: 'regex', smatch: 'regex', regex_match: 'regex', regex_search: 'regex',
  // <cassert>
  assert: 'cassert',
  // <stdexcept>
  runtime_error: 'stdexcept', logic_error: 'stdexcept', invalid_argument: 'stdexcept',
  out_of_range: 'stdexcept', overflow_error: 'stdexcept',
  // <exception>
  exception: 'exception',
  // <type_traits>
  is_same: 'type_traits', is_integral: 'type_traits', enable_if: 'type_traits',
  decay: 'type_traits', remove_reference: 'type_traits',
  // <filesystem>
  filesystem: 'filesystem',
};

// ── AUTO-INCLUDE ENGINE ──────────────────────────────────────────
function buildAutoIncludeEdit(monaco, model, headerName) {
  const fullText = model.getValue();
  const includeStr = `#include <${headerName}>`;
  if (fullText.includes(includeStr)) return null;
  if (fullText.includes('#include <bits/stdc++.h>')) return null;

  const lines = fullText.split('\n');
  let lastIncludeLine = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().startsWith('#include')) lastIncludeLine = i;
  }
  const insertLine = lastIncludeLine + 1;

  return {
    range: new monaco.Range(insertLine + 1, 1, insertLine + 1, 1),
    text: includeStr + '\n',
  };
}

function getAutoIncludeEdits(monaco, model, symbolName) {
  const header = SYMBOL_HEADERS[symbolName];
  if (!header) return undefined;
  const edit = buildAutoIncludeEdit(monaco, model, header);
  return edit ? [edit] : undefined;
}

// ── CONTEXT DETECTION ENGINE ─────────────────────────────────────
function detectContext(model, position) {
  const fullText = model.getValue();
  const lines = fullText.split('\n');
  const cursorLine = position.lineNumber;
  const textBefore = model.getLineContent(cursorLine).substring(0, position.column - 1);

  const ctx = {
    hasUsingStd: /using\s+namespace\s+std\s*;/.test(fullText),
    hasBitsStdcpp: fullText.includes('#include <bits/stdc++.h>'),
    existingIncludes: new Set(),
    scope: 'file',
    insideFunction: false,
    insideClass: false,
    insideLoop: false,
    insideSwitch: false,
    returnType: null,
    lineIsEmpty: textBefore.trim() === '',
    lineStartsWithHash: textBefore.trim().startsWith('#'),
  };

  for (const line of lines) {
    const m = line.match(/#include\s*<([^>]+)>/);
    if (m) ctx.existingIncludes.add(m[1]);
    const m2 = line.match(/#include\s*"([^"]+)"/);
    if (m2) ctx.existingIncludes.add(m2[1]);
  }

  let braceDepth = 0;
  let parenDepth = 0;
  const scopeStack = [];

  for (let i = 0; i < cursorLine - 1 && i < lines.length; i++) {
    const line = lines[i].trim();

    if (/^(class|struct)\s+\w+/.test(line) && (line.includes('{') || (i + 1 < lines.length && lines[i + 1].trim() === '{'))) {
      scopeStack.push('class');
    }
    if (/^(for|while|do)\s*[\({]/.test(line) || /^for\s*\(/.test(line)) {
      scopeStack.push('loop');
    }
    if (/^switch\s*\(/.test(line)) {
      scopeStack.push('switch');
    }
    const funcMatch = line.match(/^(?:(?:static|inline|virtual|const|constexpr|auto|void|int|long|float|double|char|bool|string|vector|unsigned|signed)\s+)*(\w+)\s*\([^)]*\)\s*(?:const\s*)?(?:override\s*)?(?:->.*?)?\s*\{?\s*$/);
    if (funcMatch && !line.startsWith('if') && !line.startsWith('for') && !line.startsWith('while') && !line.startsWith('switch')) {
      const retMatch = line.match(/^([\w:<>,\s*&]+?)\s+\w+\s*\(/);
      if (retMatch) {
        ctx.returnType = retMatch[1].trim();
      }
      scopeStack.push('function');
    }

    for (const ch of line) {
      if (ch === '{') braceDepth++;
      if (ch === '}') {
        braceDepth--;
        if (scopeStack.length > 0 && braceDepth <= scopeStack.length - 1) {
          scopeStack.pop();
        }
      }
    }
  }

  if (braceDepth === 0) {
    ctx.scope = 'file';
  } else {
    ctx.scope = 'block';
    for (const s of scopeStack) {
      if (s === 'function') ctx.insideFunction = true;
      if (s === 'class') ctx.insideClass = true;
      if (s === 'loop') ctx.insideLoop = true;
      if (s === 'switch') ctx.insideSwitch = true;
    }
  }

  return ctx;
}

// ── C++ Standard Headers ─────────────────────────────────────────
const CPP_HEADERS = [
  { name: 'iostream', desc: 'Standard I/O streams (cin, cout, cerr)' },
  { name: 'vector', desc: 'Dynamic array container' },
  { name: 'string', desc: 'String class and operations' },
  { name: 'algorithm', desc: 'STL algorithms (sort, find, etc.)' },
  { name: 'map', desc: 'Ordered key-value container' },
  { name: 'unordered_map', desc: 'Hash-based key-value container' },
  { name: 'set', desc: 'Ordered unique elements' },
  { name: 'unordered_set', desc: 'Hash-based unique elements' },
  { name: 'queue', desc: 'FIFO queue & priority_queue' },
  { name: 'stack', desc: 'LIFO stack container' },
  { name: 'deque', desc: 'Double-ended queue' },
  { name: 'list', desc: 'Doubly-linked list' },
  { name: 'array', desc: 'Fixed-size array container' },
  { name: 'bitset', desc: 'Fixed-size bit sequence' },
  { name: 'numeric', desc: 'Numeric algorithms (accumulate, iota)' },
  { name: 'functional', desc: 'Function objects & utilities' },
  { name: 'utility', desc: 'pair, move, swap, forward' },
  { name: 'tuple', desc: 'Fixed-size heterogeneous container' },
  { name: 'memory', desc: 'Smart pointers (unique_ptr, shared_ptr)' },
  { name: 'iterator', desc: 'Iterator utilities' },
  { name: 'cmath', desc: 'Math functions (sqrt, pow, abs)' },
  { name: 'climits', desc: 'Integer type limits (INT_MAX, etc.)' },
  { name: 'cfloat', desc: 'Floating-point type limits' },
  { name: 'cstdlib', desc: 'General utilities (rand, malloc, atoi)' },
  { name: 'cstdio', desc: 'C I/O (printf, scanf, FILE)' },
  { name: 'cstring', desc: 'C string functions (strlen, memcpy)' },
  { name: 'cctype', desc: 'Character classification (isalpha, isdigit)' },
  { name: 'cstdint', desc: 'Fixed-width integer types (int32_t)' },
  { name: 'cstddef', desc: 'size_t, ptrdiff_t, nullptr_t' },
  { name: 'cassert', desc: 'assert() macro' },
  { name: 'cerrno', desc: 'C error handling (errno)' },
  { name: 'ctime', desc: 'C time functions (time, clock)' },
  { name: 'chrono', desc: 'Time utilities & durations' },
  { name: 'string_view', desc: 'Non-owning string reference' },
  { name: 'optional', desc: 'Optional value container' },
  { name: 'variant', desc: 'Type-safe union' },
  { name: 'any', desc: 'Type-safe container for any value' },
  { name: 'sstream', desc: 'String streams (stringstream)' },
  { name: 'fstream', desc: 'File streams (ifstream, ofstream)' },
  { name: 'iomanip', desc: 'I/O manipulators (setw, setprecision)' },
  { name: 'ios', desc: 'I/O stream base classes' },
  { name: 'istream', desc: 'Input stream class' },
  { name: 'ostream', desc: 'Output stream class' },
  { name: 'complex', desc: 'Complex number class' },
  { name: 'regex', desc: 'Regular expressions' },
  { name: 'random', desc: 'Random number generation' },
  { name: 'thread', desc: 'Thread support' },
  { name: 'mutex', desc: 'Mutual exclusion primitives' },
  { name: 'condition_variable', desc: 'Thread synchronization' },
  { name: 'atomic', desc: 'Atomic operations' },
  { name: 'future', desc: 'Asynchronous operations' },
  { name: 'filesystem', desc: 'Filesystem operations' },
  { name: 'ranges', desc: 'Ranges library (C++20)' },
  { name: 'span', desc: 'Non-owning view over array (C++20)' },
  { name: 'concepts', desc: 'Concepts library (C++20)' },
  { name: 'format', desc: 'Text formatting (C++20)' },
  { name: 'stdexcept', desc: 'Exception classes' },
  { name: 'exception', desc: 'Base exception class' },
  { name: 'type_traits', desc: 'Type traits & compile-time checks' },
  { name: 'typeinfo', desc: 'Runtime type identification' },
  { name: 'limits', desc: 'numeric_limits class' },
  { name: 'initializer_list', desc: 'Initializer list support' },
];

// ── C++ Keywords ─────────────────────────────────────────────────
const CPP_KEYWORDS = [
  'alignas', 'alignof', 'and', 'and_eq', 'asm', 'auto', 'bitand', 'bitor',
  'bool', 'break', 'case', 'catch', 'char', 'char8_t', 'char16_t', 'char32_t',
  'class', 'compl', 'concept', 'const', 'consteval', 'constexpr', 'constinit',
  'const_cast', 'continue', 'co_await', 'co_return', 'co_yield', 'decltype',
  'default', 'delete', 'do', 'double', 'dynamic_cast', 'else', 'enum',
  'explicit', 'export', 'extern', 'false', 'float', 'for', 'friend', 'goto',
  'if', 'inline', 'int', 'long', 'mutable', 'namespace', 'new', 'noexcept',
  'not', 'not_eq', 'nullptr', 'operator', 'or', 'or_eq', 'private',
  'protected', 'public', 'register', 'reinterpret_cast', 'requires', 'return',
  'short', 'signed', 'sizeof', 'static', 'static_assert', 'static_cast',
  'struct', 'switch', 'template', 'this', 'thread_local', 'throw', 'true',
  'try', 'typedef', 'typeid', 'typename', 'union', 'unsigned', 'using',
  'virtual', 'void', 'volatile', 'wchar_t', 'while', 'xor', 'xor_eq',
];

// ── C++ std:: members with auto-include ──────────────────────────
const CPP_STD_MEMBERS = [
  // I/O
  { label: 'cout', insert: 'cout', detail: 'Standard output stream', kind: 'var', header: 'iostream' },
  { label: 'cin', insert: 'cin', detail: 'Standard input stream', kind: 'var', header: 'iostream' },
  { label: 'cerr', insert: 'cerr', detail: 'Standard error stream', kind: 'var', header: 'iostream' },
  { label: 'clog', insert: 'clog', detail: 'Standard log stream', kind: 'var', header: 'iostream' },
  { label: 'endl', insert: 'endl', detail: 'End-of-line + flush', kind: 'var', header: 'iostream' },
  { label: 'getline', insert: 'getline(${1:stream}, ${2:str})', detail: 'Read line from stream', kind: 'fn', header: 'iostream' },
  // Containers
  { label: 'string', insert: 'string', detail: 'String class', kind: 'class', header: 'string' },
  { label: 'vector', insert: 'vector<${1:int}>', detail: 'Dynamic array', kind: 'class', header: 'vector' },
  { label: 'array', insert: 'array<${1:int}, ${2:N}>', detail: 'Fixed-size array', kind: 'class', header: 'array' },
  { label: 'map', insert: 'map<${1:string}, ${2:int}>', detail: 'Ordered map', kind: 'class', header: 'map' },
  { label: 'unordered_map', insert: 'unordered_map<${1:string}, ${2:int}>', detail: 'Hash map', kind: 'class', header: 'unordered_map' },
  { label: 'set', insert: 'set<${1:int}>', detail: 'Ordered set', kind: 'class', header: 'set' },
  { label: 'unordered_set', insert: 'unordered_set<${1:int}>', detail: 'Hash set', kind: 'class', header: 'unordered_set' },
  { label: 'pair', insert: 'pair<${1:int}, ${2:int}>', detail: 'Pair of values', kind: 'class', header: 'utility' },
  { label: 'tuple', insert: 'tuple<${1:int}, ${2:string}>', detail: 'Tuple', kind: 'class', header: 'tuple' },
  { label: 'queue', insert: 'queue<${1:int}>', detail: 'FIFO queue', kind: 'class', header: 'queue' },
  { label: 'stack', insert: 'stack<${1:int}>', detail: 'LIFO stack', kind: 'class', header: 'stack' },
  { label: 'deque', insert: 'deque<${1:int}>', detail: 'Double-ended queue', kind: 'class', header: 'deque' },
  { label: 'priority_queue', insert: 'priority_queue<${1:int}>', detail: 'Max-heap', kind: 'class', header: 'queue' },
  { label: 'list', insert: 'list<${1:int}>', detail: 'Doubly-linked list', kind: 'class', header: 'list' },
  { label: 'bitset', insert: 'bitset<${1:N}>', detail: 'Fixed-size bit set', kind: 'class', header: 'bitset' },
  { label: 'optional', insert: 'optional<${1:int}>', detail: 'Optional value', kind: 'class', header: 'optional' },
  { label: 'string_view', insert: 'string_view', detail: 'Non-owning string reference', kind: 'class', header: 'string_view' },
  // Smart pointers
  { label: 'unique_ptr', insert: 'unique_ptr<${1:T}>', detail: 'Unique ownership pointer', kind: 'class', header: 'memory' },
  { label: 'shared_ptr', insert: 'shared_ptr<${1:T}>', detail: 'Shared ownership pointer', kind: 'class', header: 'memory' },
  { label: 'make_unique', insert: 'make_unique<${1:T}>(${2:args})', detail: 'Create unique_ptr', kind: 'fn', header: 'memory' },
  { label: 'make_shared', insert: 'make_shared<${1:T}>(${2:args})', detail: 'Create shared_ptr', kind: 'fn', header: 'memory' },
  { label: 'make_pair', insert: 'make_pair(${1:a}, ${2:b})', detail: 'Create pair', kind: 'fn', header: 'utility' },
  { label: 'make_tuple', insert: 'make_tuple(${1:a}, ${2:b})', detail: 'Create tuple', kind: 'fn', header: 'tuple' },
  // Algorithms
  { label: 'sort', insert: 'sort(${1:v.begin()}, ${2:v.end()})', detail: 'Sort range', kind: 'fn', header: 'algorithm' },
  { label: 'reverse', insert: 'reverse(${1:v.begin()}, ${2:v.end()})', detail: 'Reverse range', kind: 'fn', header: 'algorithm' },
  { label: 'find', insert: 'find(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Find value in range', kind: 'fn', header: 'algorithm' },
  { label: 'find_if', insert: 'find_if(${1:v.begin()}, ${2:v.end()}, ${3:pred})', detail: 'Find by predicate', kind: 'fn', header: 'algorithm' },
  { label: 'count', insert: 'count(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Count occurrences', kind: 'fn', header: 'algorithm' },
  { label: 'accumulate', insert: 'accumulate(${1:v.begin()}, ${2:v.end()}, ${3:0})', detail: 'Sum/fold range', kind: 'fn', header: 'numeric' },
  { label: 'iota', insert: 'iota(${1:v.begin()}, ${2:v.end()}, ${3:0})', detail: 'Fill with incrementing values', kind: 'fn', header: 'numeric' },
  { label: 'lower_bound', insert: 'lower_bound(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Binary search (lower)', kind: 'fn', header: 'algorithm' },
  { label: 'upper_bound', insert: 'upper_bound(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Binary search (upper)', kind: 'fn', header: 'algorithm' },
  { label: 'binary_search', insert: 'binary_search(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Check if value exists', kind: 'fn', header: 'algorithm' },
  { label: 'max_element', insert: 'max_element(${1:v.begin()}, ${2:v.end()})', detail: 'Iterator to maximum', kind: 'fn', header: 'algorithm' },
  { label: 'min_element', insert: 'min_element(${1:v.begin()}, ${2:v.end()})', detail: 'Iterator to minimum', kind: 'fn', header: 'algorithm' },
  { label: 'next_permutation', insert: 'next_permutation(${1:v.begin()}, ${2:v.end()})', detail: 'Next permutation', kind: 'fn', header: 'algorithm' },
  { label: 'unique', insert: 'unique(${1:v.begin()}, ${2:v.end()})', detail: 'Remove consecutive dupes', kind: 'fn', header: 'algorithm' },
  { label: 'fill', insert: 'fill(${1:v.begin()}, ${2:v.end()}, ${3:val})', detail: 'Fill range', kind: 'fn', header: 'algorithm' },
  { label: 'transform', insert: 'transform(${1:v.begin()}, ${2:v.end()}, ${3:out.begin()}, ${4:fn})', detail: 'Apply function', kind: 'fn', header: 'algorithm' },
  { label: 'for_each', insert: 'for_each(${1:v.begin()}, ${2:v.end()}, ${3:fn})', detail: 'Apply to each', kind: 'fn', header: 'algorithm' },
  // Utility functions
  { label: 'swap', insert: 'swap(${1:a}, ${2:b})', detail: 'Swap two values', kind: 'fn', header: 'utility' },
  { label: 'min', insert: 'min(${1:a}, ${2:b})', detail: 'Minimum of two', kind: 'fn' },
  { label: 'max', insert: 'max(${1:a}, ${2:b})', detail: 'Maximum of two', kind: 'fn' },
  { label: 'abs', insert: 'abs(${1:x})', detail: 'Absolute value', kind: 'fn', header: 'cmath' },
  { label: 'gcd', insert: 'gcd(${1:a}, ${2:b})', detail: 'Greatest common divisor', kind: 'fn', header: 'numeric' },
  { label: 'lcm', insert: 'lcm(${1:a}, ${2:b})', detail: 'Least common multiple', kind: 'fn', header: 'numeric' },
  { label: 'move', insert: 'move(${1:x})', detail: 'Cast to rvalue', kind: 'fn', header: 'utility' },
  { label: 'to_string', insert: 'to_string(${1:val})', detail: 'Convert to string', kind: 'fn', header: 'string' },
  { label: 'stoi', insert: 'stoi(${1:str})', detail: 'String to int', kind: 'fn', header: 'string' },
  { label: 'stoll', insert: 'stoll(${1:str})', detail: 'String to long long', kind: 'fn', header: 'string' },
  { label: 'stod', insert: 'stod(${1:str})', detail: 'String to double', kind: 'fn', header: 'string' },
  { label: 'sqrt', insert: 'sqrt(${1:x})', detail: 'Square root', kind: 'fn', header: 'cmath' },
  { label: 'pow', insert: 'pow(${1:base}, ${2:exp})', detail: 'Power', kind: 'fn', header: 'cmath' },
  { label: 'ceil', insert: 'ceil(${1:x})', detail: 'Ceiling', kind: 'fn', header: 'cmath' },
  { label: 'floor', insert: 'floor(${1:x})', detail: 'Floor', kind: 'fn', header: 'cmath' },
  { label: 'log', insert: 'log(${1:x})', detail: 'Natural logarithm', kind: 'fn', header: 'cmath' },
  { label: 'log2', insert: 'log2(${1:x})', detail: 'Base-2 logarithm', kind: 'fn', header: 'cmath' },
  { label: 'numeric_limits', insert: 'numeric_limits<${1:int}>::${2:max}()', detail: 'Type numeric limits', kind: 'class', header: 'limits' },
  { label: 'distance', insert: 'distance(${1:first}, ${2:last})', detail: 'Iterator distance', kind: 'fn', header: 'iterator' },
  // Streams
  { label: 'stringstream', insert: 'stringstream ${1:ss}', detail: 'String stream', kind: 'class', header: 'sstream' },
  { label: 'ifstream', insert: 'ifstream ${1:fin}(${2:"file.txt"})', detail: 'Input file stream', kind: 'class', header: 'fstream' },
  { label: 'ofstream', insert: 'ofstream ${1:fout}(${2:"file.txt"})', detail: 'Output file stream', kind: 'class', header: 'fstream' },
  { label: 'setw', insert: 'setw(${1:n})', detail: 'Set output width', kind: 'fn', header: 'iomanip' },
  { label: 'setprecision', insert: 'setprecision(${1:n})', detail: 'Set decimal precision', kind: 'fn', header: 'iomanip' },
  { label: 'fixed', insert: 'fixed', detail: 'Fixed-point notation', kind: 'var', header: 'iomanip' },
];

// ── Container method completions ─────────────────────────────────
const CONTAINER_METHODS = [
  { label: 'push_back', insert: 'push_back(${1:val})', detail: 'Add element to end' },
  { label: 'pop_back', insert: 'pop_back()', detail: 'Remove last element' },
  { label: 'push_front', insert: 'push_front(${1:val})', detail: 'Add element to front' },
  { label: 'pop_front', insert: 'pop_front()', detail: 'Remove first element' },
  { label: 'push', insert: 'push(${1:val})', detail: 'Push element' },
  { label: 'pop', insert: 'pop()', detail: 'Pop element' },
  { label: 'top', insert: 'top()', detail: 'Access top element' },
  { label: 'front', insert: 'front()', detail: 'Access first element' },
  { label: 'back', insert: 'back()', detail: 'Access last element' },
  { label: 'size', insert: 'size()', detail: 'Number of elements' },
  { label: 'empty', insert: 'empty()', detail: 'Check if empty' },
  { label: 'clear', insert: 'clear()', detail: 'Remove all elements' },
  { label: 'begin', insert: 'begin()', detail: 'Iterator to first' },
  { label: 'end', insert: 'end()', detail: 'Iterator past last' },
  { label: 'rbegin', insert: 'rbegin()', detail: 'Reverse iterator' },
  { label: 'rend', insert: 'rend()', detail: 'Reverse iterator end' },
  { label: 'insert', insert: 'insert(${1:pos}, ${2:val})', detail: 'Insert element' },
  { label: 'erase', insert: 'erase(${1:pos})', detail: 'Remove element' },
  { label: 'find', insert: 'find(${1:key})', detail: 'Find element' },
  { label: 'count', insert: 'count(${1:key})', detail: 'Count elements' },
  { label: 'contains', insert: 'contains(${1:key})', detail: 'Contains key (C++20)' },
  { label: 'at', insert: 'at(${1:index})', detail: 'Access with bounds check' },
  { label: 'resize', insert: 'resize(${1:n})', detail: 'Resize container' },
  { label: 'reserve', insert: 'reserve(${1:n})', detail: 'Reserve capacity' },
  { label: 'capacity', insert: 'capacity()', detail: 'Current capacity' },
  { label: 'data', insert: 'data()', detail: 'Pointer to data' },
  { label: 'emplace_back', insert: 'emplace_back(${1:args})', detail: 'Construct in-place at end' },
  { label: 'emplace', insert: 'emplace(${1:args})', detail: 'Construct in-place' },
  { label: 'swap', insert: 'swap(${1:other})', detail: 'Swap contents' },
  { label: 'length', insert: 'length()', detail: 'String length' },
  { label: 'substr', insert: 'substr(${1:pos}, ${2:len})', detail: 'Extract substring' },
  { label: 'append', insert: 'append(${1:str})', detail: 'Append string' },
  { label: 'c_str', insert: 'c_str()', detail: 'Get C-style string' },
  { label: 'replace', insert: 'replace(${1:pos}, ${2:len}, ${3:str})', detail: 'Replace portion' },
  { label: 'rfind', insert: 'rfind(${1:str})', detail: 'Find last occurrence' },
  { label: 'starts_with', insert: 'starts_with(${1:str})', detail: 'Check prefix (C++20)' },
  { label: 'ends_with', insert: 'ends_with(${1:str})', detail: 'Check suffix (C++20)' },
  { label: 'first', insert: 'first', detail: 'First of pair' },
  { label: 'second', insert: 'second', detail: 'Second of pair' },
  { label: 'value', insert: 'value()', detail: 'Get optional value' },
  { label: 'has_value', insert: 'has_value()', detail: 'Check if has value' },
  { label: 'shrink_to_fit', insert: 'shrink_to_fit()', detail: 'Release unused memory' },
  { label: 'npos', insert: 'npos', detail: 'Not-found position' },
];

// ── Preprocessor Directives ──────────────────────────────────────
const CPP_PREPROCESSOR = [
  { label: '#include <>', insert: '#include <${1:iostream}>', detail: 'Include system header', filter: '#include' },
  { label: '#include ""', insert: '#include "${1:file.h}"', detail: 'Include local header', filter: '#include' },
  { label: '#define', insert: '#define ${1:NAME} ${2:value}', detail: 'Define macro' },
  { label: '#ifdef', insert: '#ifdef ${1:MACRO}\n$0\n#endif', detail: 'Conditional compilation' },
  { label: '#ifndef', insert: '#ifndef ${1:MACRO}\n#define ${1:MACRO}\n$0\n#endif', detail: 'Include guard' },
  { label: '#if', insert: '#if ${1:condition}\n$0\n#endif', detail: 'Conditional compilation' },
  { label: '#else', insert: '#else', detail: 'Else branch' },
  { label: '#elif', insert: '#elif ${1:condition}', detail: 'Else-if branch' },
  { label: '#endif', insert: '#endif', detail: 'End conditional' },
  { label: '#pragma once', insert: '#pragma once', detail: 'Include guard (modern)' },
  { label: '#pragma', insert: '#pragma ${1:once}', detail: 'Compiler directive' },
  { label: '#undef', insert: '#undef ${1:MACRO}', detail: 'Undefine macro' },
  { label: '#error', insert: '#error "${1:message}"', detail: 'Compilation error' },
];

// ── Context-aware C++ Snippets ───────────────────────────────────
const CPP_SNIPPETS_FILE_SCOPE = [
  { label: 'main', insert: 'int main() {\n\t$0\n\treturn 0;\n}', detail: 'Main function', kw: 'main int' },
  { label: 'main(argc, argv)', insert: 'int main(int argc, char* argv[]) {\n\t$0\n\treturn 0;\n}', detail: 'Main with arguments', kw: 'main argc argv' },
  { label: 'class', insert: 'class ${1:Name} {\npublic:\n\t${1:Name}() {}\n\t~${1:Name}() {}\n\nprivate:\n\t$0\n};', detail: 'Class definition', kw: 'class' },
  { label: 'struct', insert: 'struct ${1:Name} {\n\t$0\n};', detail: 'Struct definition', kw: 'struct' },
  { label: 'enum class', insert: 'enum class ${1:Name} {\n\t${2:Value1},\n\t${3:Value2},\n};', detail: 'Scoped enum', kw: 'enum class' },
  { label: 'template function', insert: 'template <typename ${1:T}>\n${2:T} ${3:func}(${4:T param}) {\n\t$0\n}', detail: 'Template function', kw: 'template typename function' },
  { label: 'template class', insert: 'template <typename ${1:T}>\nclass ${2:Name} {\npublic:\n\t$0\n};', detail: 'Template class', kw: 'template typename class' },
  { label: 'namespace', insert: 'namespace ${1:name} {\n\t$0\n}', detail: 'Namespace block', kw: 'namespace' },
  { label: 'using namespace std', insert: 'using namespace std;', detail: 'Use std namespace', kw: 'using namespace std' },
  { label: '#include <>', insert: '#include <${1:iostream}>', detail: 'Include system header', kw: 'include header' },
  { label: 'cp-template', insert: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n\tios_base::sync_with_stdio(false);\n\tcin.tie(NULL);\n\t\n\t$0\n\t\n\treturn 0;\n}', detail: 'Competitive programming template', kw: 'competitive template fast cp' },
  { label: 'void function', insert: 'void ${1:func}(${2:}) {\n\t$0\n}', detail: 'Void function', kw: 'void function' },
  { label: 'int function', insert: 'int ${1:func}(${2:}) {\n\t$0\n\treturn ${3:0};\n}', detail: 'Int function', kw: 'int function return' },
  { label: 'typedef', insert: 'typedef ${1:type} ${2:alias};', detail: 'Type alias (old style)', kw: 'typedef alias' },
  { label: 'using (alias)', insert: 'using ${1:alias} = ${2:type};', detail: 'Type alias (modern)', kw: 'using alias' },
];

const CPP_SNIPPETS_FUNCTION_BODY = [
  { label: 'for', insert: 'for (int ${1:i} = 0; ${1:i} < ${2:n}; ${1:i}++) {\n\t$0\n}', detail: 'For loop', kw: 'for loop' },
  { label: 'for (range)', insert: 'for (auto& ${1:item} : ${2:container}) {\n\t$0\n}', detail: 'Range-based for loop', kw: 'for range auto' },
  { label: 'for (const range)', insert: 'for (const auto& ${1:item} : ${2:container}) {\n\t$0\n}', detail: 'Const range-based for loop', kw: 'for range const auto' },
  { label: 'for (reverse)', insert: 'for (int ${1:i} = ${2:n} - 1; ${1:i} >= 0; ${1:i}--) {\n\t$0\n}', detail: 'Reverse for loop', kw: 'for reverse loop' },
  { label: 'while', insert: 'while (${1:condition}) {\n\t$0\n}', detail: 'While loop', kw: 'while loop' },
  { label: 'do-while', insert: 'do {\n\t$0\n} while (${1:condition});', detail: 'Do-while loop', kw: 'do while loop' },
  { label: 'if', insert: 'if (${1:condition}) {\n\t$0\n}', detail: 'If statement', kw: 'if condition' },
  { label: 'if-else', insert: 'if (${1:condition}) {\n\t$2\n} else {\n\t$0\n}', detail: 'If-else statement', kw: 'if else condition' },
  { label: 'switch', insert: 'switch (${1:expr}) {\n\tcase ${2:val}:\n\t\t$0\n\t\tbreak;\n\tdefault:\n\t\tbreak;\n}', detail: 'Switch statement', kw: 'switch case' },
  { label: 'try-catch', insert: 'try {\n\t$0\n} catch (const ${1:exception}& e) {\n\t${2:cerr << e.what();}\n}', detail: 'Try-catch block', kw: 'try catch exception' },
  { label: 'lambda', insert: '[${1:}](${2:auto x}) {\n\t$0\n}', detail: 'Lambda expression', kw: 'lambda capture' },
  { label: 'cout <<', insert: 'cout << ${1:expr} << endl;', detail: 'Print to stdout', kw: 'cout print output' },
  { label: 'cin >>', insert: 'cin >> ${1:var};', detail: 'Read from stdin', kw: 'cin read input' },
  { label: 'return', insert: 'return ${1:};', detail: 'Return statement', kw: 'return' },
  { label: 'vector<int>', insert: 'vector<${1:int}> ${2:v}(${3:n});', detail: 'Declare vector', kw: 'vector declare' },
  { label: 'map<string, int>', insert: 'map<${1:string}, ${2:int}> ${3:m};', detail: 'Declare map', kw: 'map declare' },
  { label: 'pair<int, int>', insert: 'pair<${1:int}, ${2:int}> ${3:p};', detail: 'Declare pair', kw: 'pair declare' },
  { label: 'fast-io', insert: 'ios_base::sync_with_stdio(false);\ncin.tie(NULL);', detail: 'Fast I/O setup', kw: 'fast io sync' },
];

const CPP_SNIPPETS_LOOP = [
  { label: 'break', insert: 'break;', detail: 'Break out of loop', kw: 'break' },
  { label: 'continue', insert: 'continue;', detail: 'Skip to next iteration', kw: 'continue' },
];

const CPP_SNIPPETS_SWITCH = [
  { label: 'case', insert: 'case ${1:value}:\n\t$0\n\tbreak;', detail: 'Switch case', kw: 'case' },
  { label: 'default', insert: 'default:\n\t$0\n\tbreak;', detail: 'Default case', kw: 'default' },
];

const CPP_SNIPPETS_CLASS = [
  { label: 'public:', insert: 'public:', detail: 'Public section', kw: 'public' },
  { label: 'private:', insert: 'private:', detail: 'Private section', kw: 'private' },
  { label: 'protected:', insert: 'protected:', detail: 'Protected section', kw: 'protected' },
  { label: 'virtual', insert: 'virtual ${1:void} ${2:method}(${3:}) ${4:= 0};', detail: 'Virtual method', kw: 'virtual method' },
  { label: 'constructor', insert: '${1:ClassName}(${2:}) {\n\t$0\n}', detail: 'Constructor', kw: 'constructor' },
  { label: 'destructor', insert: '~${1:ClassName}() {\n\t$0\n}', detail: 'Destructor', kw: 'destructor' },
  { label: 'friend', insert: 'friend ${1:class} ${2:Name};', detail: 'Friend declaration', kw: 'friend' },
];

// ── Python data (unchanged from before) ──────────────────────────
const PYTHON_BUILTINS = [
  { label: 'print', insert: 'print(${1:})', detail: 'Print to stdout' },
  { label: 'input', insert: 'input(${1:""})', detail: 'Read from stdin' },
  { label: 'len', insert: 'len(${1:obj})', detail: 'Length of object' },
  { label: 'range', insert: 'range(${1:n})', detail: 'Range of numbers' },
  { label: 'int', insert: 'int(${1:x})', detail: 'Convert to integer' },
  { label: 'float', insert: 'float(${1:x})', detail: 'Convert to float' },
  { label: 'str', insert: 'str(${1:x})', detail: 'Convert to string' },
  { label: 'list', insert: 'list(${1:iterable})', detail: 'Create list' },
  { label: 'dict', insert: 'dict(${1:})', detail: 'Create dictionary' },
  { label: 'set', insert: 'set(${1:iterable})', detail: 'Create set' },
  { label: 'tuple', insert: 'tuple(${1:iterable})', detail: 'Create tuple' },
  { label: 'bool', insert: 'bool(${1:x})', detail: 'Convert to boolean' },
  { label: 'type', insert: 'type(${1:obj})', detail: 'Get type of object' },
  { label: 'isinstance', insert: 'isinstance(${1:obj}, ${2:type})', detail: 'Check instance type' },
  { label: 'enumerate', insert: 'enumerate(${1:iterable})', detail: 'Index + value iterator' },
  { label: 'zip', insert: 'zip(${1:iter1}, ${2:iter2})', detail: 'Parallel iteration' },
  { label: 'map', insert: 'map(${1:func}, ${2:iterable})', detail: 'Apply function to each' },
  { label: 'filter', insert: 'filter(${1:func}, ${2:iterable})', detail: 'Filter elements' },
  { label: 'sorted', insert: 'sorted(${1:iterable}${2:, key=lambda x: x})', detail: 'Return sorted list' },
  { label: 'reversed', insert: 'reversed(${1:seq})', detail: 'Reverse iterator' },
  { label: 'abs', insert: 'abs(${1:x})', detail: 'Absolute value' },
  { label: 'min', insert: 'min(${1:iterable})', detail: 'Minimum value' },
  { label: 'max', insert: 'max(${1:iterable})', detail: 'Maximum value' },
  { label: 'sum', insert: 'sum(${1:iterable})', detail: 'Sum of elements' },
  { label: 'all', insert: 'all(${1:iterable})', detail: 'All truthy?' },
  { label: 'any', insert: 'any(${1:iterable})', detail: 'Any truthy?' },
  { label: 'open', insert: 'open(${1:"file"}, ${2:"r"})', detail: 'Open file' },
  { label: 'iter', insert: 'iter(${1:obj})', detail: 'Get iterator' },
  { label: 'next', insert: 'next(${1:iterator})', detail: 'Next from iterator' },
  { label: 'chr', insert: 'chr(${1:code})', detail: 'Character from code' },
  { label: 'ord', insert: 'ord(${1:char})', detail: 'Code from character' },
  { label: 'hex', insert: 'hex(${1:n})', detail: 'Integer to hex string' },
  { label: 'bin', insert: 'bin(${1:n})', detail: 'Integer to binary string' },
  { label: 'format', insert: 'format(${1:val}, ${2:"spec"})', detail: 'Format value' },
  { label: 'repr', insert: 'repr(${1:obj})', detail: 'Repr string' },
  { label: 'pow', insert: 'pow(${1:base}, ${2:exp})', detail: 'Power' },
  { label: 'round', insert: 'round(${1:x}, ${2:digits})', detail: 'Round number' },
  { label: 'divmod', insert: 'divmod(${1:a}, ${2:b})', detail: 'Quotient and remainder' },
  { label: 'super', insert: 'super()', detail: 'Parent class reference' },
  { label: 'hash', insert: 'hash(${1:obj})', detail: 'Hash of object' },
  { label: 'id', insert: 'id(${1:obj})', detail: 'Object identity' },
  { label: 'dir', insert: 'dir(${1:obj})', detail: 'List attributes' },
  { label: 'getattr', insert: 'getattr(${1:obj}, ${2:"attr"})', detail: 'Get attribute' },
  { label: 'setattr', insert: 'setattr(${1:obj}, ${2:"attr"}, ${3:val})', detail: 'Set attribute' },
  { label: 'hasattr', insert: 'hasattr(${1:obj}, ${2:"attr"})', detail: 'Has attribute?' },
  { label: 'globals', insert: 'globals()', detail: 'Global symbol table' },
  { label: 'locals', insert: 'locals()', detail: 'Local symbol table' },
  { label: 'breakpoint', insert: 'breakpoint()', detail: 'Set breakpoint' },
  { label: 'eval', insert: 'eval(${1:expr})', detail: 'Evaluate expression' },
  { label: 'exec', insert: 'exec(${1:code})', detail: 'Execute code string' },
];

const PYTHON_KEYWORDS = [
  'False', 'None', 'True', 'and', 'as', 'assert', 'async', 'await',
  'break', 'class', 'continue', 'def', 'del', 'elif', 'else', 'except',
  'finally', 'for', 'from', 'global', 'if', 'import', 'in', 'is',
  'lambda', 'nonlocal', 'not', 'or', 'pass', 'raise', 'return', 'try',
  'while', 'with', 'yield',
];

const PYTHON_MODULES = [
  { name: 'os', desc: 'Operating system interface' },
  { name: 'sys', desc: 'System-specific parameters' },
  { name: 'math', desc: 'Mathematical functions' },
  { name: 'random', desc: 'Random number generation' },
  { name: 'datetime', desc: 'Date and time types' },
  { name: 'json', desc: 'JSON encoder/decoder' },
  { name: 'collections', desc: 'Specialized containers' },
  { name: 'itertools', desc: 'Iterator building blocks' },
  { name: 'functools', desc: 'Higher-order functions' },
  { name: 'typing', desc: 'Type hints support' },
  { name: 'pathlib', desc: 'Filesystem paths' },
  { name: 're', desc: 'Regular expressions' },
  { name: 'io', desc: 'Core I/O tools' },
  { name: 'string', desc: 'String operations' },
  { name: 'heapq', desc: 'Heap queue' },
  { name: 'bisect', desc: 'Binary search' },
  { name: 'copy', desc: 'Shallow and deep copy' },
  { name: 'time', desc: 'Time functions' },
  { name: 'logging', desc: 'Logging facility' },
  { name: 'dataclasses', desc: 'Data class decorator' },
  { name: 'abc', desc: 'Abstract base classes' },
  { name: 'enum', desc: 'Enum type support' },
  { name: 'csv', desc: 'CSV reader/writer' },
  { name: 'argparse', desc: 'Argument parser' },
  { name: 'subprocess', desc: 'Subprocess management' },
  { name: 'threading', desc: 'Thread-based parallelism' },
  { name: 'asyncio', desc: 'Asynchronous I/O' },
  { name: 'sqlite3', desc: 'SQLite interface' },
  { name: 'hashlib', desc: 'Secure hashes' },
  { name: 'struct', desc: 'Binary data packing' },
  { name: 'statistics', desc: 'Statistical functions' },
  { name: 'decimal', desc: 'Decimal arithmetic' },
  { name: 'shutil', desc: 'File operations' },
  { name: 'glob', desc: 'Pathname matching' },
  { name: 'tempfile', desc: 'Temporary files' },
  { name: 'pickle', desc: 'Object serialization' },
  { name: 'pprint', desc: 'Pretty printer' },
  { name: 'unittest', desc: 'Unit testing' },
  { name: 'operator', desc: 'Operators as functions' },
  { name: 'contextlib', desc: 'Context managers' },
  { name: 'socket', desc: 'Low-level networking' },
  { name: 'http', desc: 'HTTP modules' },
  { name: 'urllib', desc: 'URL handling' },
  { name: 'xml', desc: 'XML processing' },
  { name: 'html', desc: 'HTML processing' },
  { name: 'traceback', desc: 'Stack trace formatting' },
  { name: 'inspect', desc: 'Runtime inspection' },
  { name: 'queue', desc: 'Thread-safe queue' },
  { name: 'multiprocessing', desc: 'Process parallelism' },
];

const PYTHON_SNIPPETS = [
  { label: 'def', insert: 'def ${1:func}(${2:}):\n\t${3:pass}', detail: 'Function definition' },
  { label: 'class', insert: 'class ${1:Name}:\n\tdef __init__(self${2:}):\n\t\t${3:pass}', detail: 'Class definition' },
  { label: 'if', insert: 'if ${1:condition}:\n\t${2:pass}', detail: 'If statement' },
  { label: 'if-else', insert: 'if ${1:condition}:\n\t${2:pass}\nelse:\n\t${3:pass}', detail: 'If-else' },
  { label: 'for', insert: 'for ${1:item} in ${2:iterable}:\n\t${3:pass}', detail: 'For loop' },
  { label: 'for range', insert: 'for ${1:i} in range(${2:n}):\n\t${3:pass}', detail: 'For with range' },
  { label: 'for enumerate', insert: 'for ${1:i}, ${2:item} in enumerate(${3:iterable}):\n\t${4:pass}', detail: 'Enumerate loop' },
  { label: 'while', insert: 'while ${1:condition}:\n\t${2:pass}', detail: 'While loop' },
  { label: 'try-except', insert: 'try:\n\t${1:pass}\nexcept ${2:Exception} as e:\n\t${3:print(e)}', detail: 'Try-except' },
  { label: 'with open', insert: 'with open(${1:"file"}, ${2:"r"}) as ${3:f}:\n\t${4:content = f.read()}', detail: 'Open file' },
  { label: 'list comprehension', insert: '[${1:expr} for ${2:x} in ${3:iterable}]', detail: 'List comprehension' },
  { label: 'dict comprehension', insert: '{${1:k}: ${2:v} for ${1:k}, ${2:v} in ${3:iterable}}', detail: 'Dict comprehension' },
  { label: 'lambda', insert: 'lambda ${1:x}: ${2:x}', detail: 'Lambda' },
  { label: 'main block', insert: 'if __name__ == "__main__":\n\t${1:main()}', detail: 'Main guard' },
  { label: '@property', insert: '@property\ndef ${1:name}(self):\n\treturn self._${1:name}', detail: 'Property' },
  { label: 'dataclass', insert: '@dataclass\nclass ${1:Name}:\n\t${2:field}: ${3:str}', detail: 'Dataclass' },
  { label: 'async def', insert: 'async def ${1:func}(${2:}):\n\t${3:pass}', detail: 'Async function' },
  { label: 'print f-string', insert: 'print(f"${1:{var}}")', detail: 'Print f-string' },
];

const PYTHON_DOT_METHODS = [
  { label: 'strip', insert: 'strip()', detail: 'Remove whitespace' },
  { label: 'lstrip', insert: 'lstrip()', detail: 'Remove left whitespace' },
  { label: 'rstrip', insert: 'rstrip()', detail: 'Remove right whitespace' },
  { label: 'split', insert: 'split(${1:sep})', detail: 'Split string' },
  { label: 'join', insert: 'join(${1:iterable})', detail: 'Join iterable' },
  { label: 'replace', insert: 'replace(${1:old}, ${2:new})', detail: 'Replace substring' },
  { label: 'find', insert: 'find(${1:sub})', detail: 'Find substring' },
  { label: 'count', insert: 'count(${1:sub})', detail: 'Count occurrences' },
  { label: 'startswith', insert: 'startswith(${1:prefix})', detail: 'Check prefix' },
  { label: 'endswith', insert: 'endswith(${1:suffix})', detail: 'Check suffix' },
  { label: 'upper', insert: 'upper()', detail: 'To uppercase' },
  { label: 'lower', insert: 'lower()', detail: 'To lowercase' },
  { label: 'title', insert: 'title()', detail: 'To title case' },
  { label: 'capitalize', insert: 'capitalize()', detail: 'Capitalize first' },
  { label: 'isdigit', insert: 'isdigit()', detail: 'All digits?' },
  { label: 'isalpha', insert: 'isalpha()', detail: 'All letters?' },
  { label: 'format', insert: 'format(${1:args})', detail: 'Format string' },
  { label: 'encode', insert: 'encode(${1:"utf-8"})', detail: 'Encode to bytes' },
  { label: 'append', insert: 'append(${1:item})', detail: 'Add to end' },
  { label: 'extend', insert: 'extend(${1:iterable})', detail: 'Extend with iterable' },
  { label: 'insert', insert: 'insert(${1:index}, ${2:item})', detail: 'Insert at index' },
  { label: 'remove', insert: 'remove(${1:item})', detail: 'Remove first match' },
  { label: 'pop', insert: 'pop(${1:index})', detail: 'Remove and return' },
  { label: 'clear', insert: 'clear()', detail: 'Remove all items' },
  { label: 'index', insert: 'index(${1:item})', detail: 'Find index' },
  { label: 'sort', insert: 'sort(${1:key=None})', detail: 'Sort in place' },
  { label: 'reverse', insert: 'reverse()', detail: 'Reverse in place' },
  { label: 'copy', insert: 'copy()', detail: 'Shallow copy' },
  { label: 'keys', insert: 'keys()', detail: 'Dict keys' },
  { label: 'values', insert: 'values()', detail: 'Dict values' },
  { label: 'items', insert: 'items()', detail: 'Dict items' },
  { label: 'get', insert: 'get(${1:key}, ${2:default})', detail: 'Get with default' },
  { label: 'setdefault', insert: 'setdefault(${1:key}, ${2:default})', detail: 'Get or set' },
  { label: 'update', insert: 'update(${1:other})', detail: 'Update dict' },
  { label: 'add', insert: 'add(${1:item})', detail: 'Add to set' },
  { label: 'discard', insert: 'discard(${1:item})', detail: 'Discard from set' },
  { label: 'union', insert: 'union(${1:other})', detail: 'Set union' },
  { label: 'intersection', insert: 'intersection(${1:other})', detail: 'Set intersection' },
  { label: 'difference', insert: 'difference(${1:other})', detail: 'Set difference' },
];

// ═══════════════════════════════════════════════════════════════════
//  REGISTRATION
// ═══════════════════════════════════════════════════════════════════
const _disposables = [];

function kindFor(monaco, type) {
  const k = monaco.languages.CompletionItemKind;
  return { fn: k.Function, var: k.Variable, class: k.Class, kw: k.Keyword, snippet: k.Snippet, file: k.File, module: k.Module, field: k.Field, prop: k.Property, method: k.Method }[type] || k.Text;
}

function makeSuggestion(monaco, model, m, range, sortPrefix, ctx) {
  const isSnippet = m.insert.includes('$');
  const autoInclude = (m.header && ctx && !ctx.hasBitsStdcpp && !ctx.existingIncludes.has(m.header))
    ? [buildAutoIncludeEdit(monaco, model, m.header)].filter(Boolean)
    : undefined;

  return {
    label: { label: m.label, description: m.detail },
    kind: kindFor(monaco, m.kind || (isSnippet ? 'fn' : 'var')),
    insertText: m.insert,
    insertTextRules: isSnippet ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : undefined,
    range,
    detail: m.header ? `${m.detail}  ← <${m.header}>` : m.detail,
    documentation: m.header ? { value: `**Auto-includes** \`#include <${m.header}>\` when accepted` } : undefined,
    sortText: sortPrefix + m.label,
    additionalTextEdits: autoInclude?.length ? autoInclude : undefined,
  };
}

export function registerFallbackCompletions(monaco, smartEngine) {
  disposeFallbackCompletions();

  function getAstContext(position) {
    if (!smartEngine?.isReady()) return null;
    try {
      return smartEngine.getContext(position.lineNumber - 1, position.column - 1);
    } catch { return null; }
  }

  function getAstVariables(position) {
    if (!smartEngine?.isReady()) return [];
    try {
      return smartEngine.getVisibleVariables(position.lineNumber - 1, position.column - 1);
    } catch { return []; }
  }

  function addVariableSuggestions(suggestions, monaco, range, position) {
    const vars = getAstVariables(position);
    for (const v of vars) {
      suggestions.push({
        label: { label: v.name, description: v.type || 'variable' },
        kind: monaco.languages.CompletionItemKind.Variable,
        insertText: v.name,
        range,
        detail: v.type ? `${v.type} ${v.name}` : v.name,
        sortText: '00' + v.name,
      });
    }
  }

  // ── C++ COMPLETION PROVIDER ───────────────────────────────────
  const cppProvider = monaco.languages.registerCompletionItemProvider('cpp', {
    triggerCharacters: ['<', ':', '.', '#', '>', '"', '/'],
    provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position);
      const range = new monaco.Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn);
      const lineContent = model.getLineContent(position.lineNumber);
      const textBefore = lineContent.substring(0, position.column - 1);
      const ctx = detectContext(model, position);
      const astCtx = getAstContext(position);
      const suggestions = [];

      if (astCtx) {
        if (astCtx.inFunction) { ctx.insideFunction = true; ctx.scope = 'block'; }
        if (astCtx.inClass) ctx.insideClass = true;
        if (astCtx.inLoop) ctx.insideLoop = true;
        if (astCtx.inSwitch) ctx.insideSwitch = true;
        if (astCtx.returnType) ctx.returnType = astCtx.returnType;
        if (astCtx.scopeType === 'file') ctx.scope = 'file';
      }

      // ── #include <...> → header completions ────────────────
      if (textBefore.match(/#include\s*<[^>]*$/)) {
        const angleBracketCol = lineContent.indexOf('<', lineContent.indexOf('#include')) + 2;
        const headerRange = new monaco.Range(position.lineNumber, angleBracketCol, position.lineNumber, position.column);
        for (const h of CPP_HEADERS) {
          suggestions.push({
            label: { label: h.name, description: h.desc },
            kind: monaco.languages.CompletionItemKind.File,
            insertText: h.name + '>',
            range: headerRange,
            detail: `<${h.name}>`,
            documentation: h.desc,
            sortText: '0' + h.name,
            filterText: h.name,
          });
        }
        suggestions.push({
          label: { label: 'bits/stdc++.h', description: 'All standard headers (GCC)' },
          kind: monaco.languages.CompletionItemKind.File,
          insertText: 'bits/stdc++.h>',
          range: headerRange,
          detail: '<bits/stdc++.h>',
          documentation: 'Includes everything — competitive programming',
          sortText: '0!bits',
          filterText: 'bits stdc++',
        });
        return { suggestions };
      }

      if (textBefore.match(/#include\s*"[^"]*$/)) return { suggestions: [] };

      // ── # preprocessor ─────────────────────────────────────
      if (textBefore.match(/^\s*#\w*$/)) {
        const hashIdx = lineContent.indexOf('#');
        const ppRange = new monaco.Range(position.lineNumber, hashIdx + 1, position.lineNumber, position.column);
        for (const pp of CPP_PREPROCESSOR) {
          suggestions.push({
            label: { label: pp.label, description: pp.detail },
            kind: monaco.languages.CompletionItemKind.Keyword,
            insertText: pp.insert,
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            range: ppRange,
            detail: pp.detail,
            sortText: '0' + pp.label,
            filterText: (pp.filter || pp.label).replace('#', ''),
          });
        }
        return { suggestions };
      }

      // ── std:: members with auto-include ─────────────────────
      if (textBefore.match(/std::\w*$/)) {
        for (const m of CPP_STD_MEMBERS) {
          suggestions.push(makeSuggestion(monaco, model, m, range, '0', ctx));
        }
        return { suggestions };
      }

      // ── using namespace ... ─────────────────────────────────
      if (textBefore.match(/using\s+namespace\s+\w*$/)) {
        for (const ns of ['std', 'std::chrono', 'std::filesystem', 'std::ranges', 'std::this_thread']) {
          suggestions.push({ label: ns, kind: monaco.languages.CompletionItemKind.Module, insertText: ns, range, detail: 'Namespace', sortText: '0' + ns });
        }
        return { suggestions };
      }

      // ── . (dot) / -> (arrow) → TYPE-AWARE methods ──────────
      if ((textBefore.match(/\.\w*$/) || textBefore.match(/->\w*$/)) && !textBefore.match(/^\s*#/) && !textBefore.match(/\d+\.\w*$/)) {
        const varMatch = textBefore.match(/(\w+)\s*(?:\.|->)\w*$/);
        let typeMethods = null;

        if (varMatch && smartEngine?.isReady()) {
          const varName = varMatch[1];
          const typeName = smartEngine.inferType(varName, position.lineNumber - 1, position.column - 1);
          if (typeName) {
            typeMethods = smartEngine.getMethodsForType(typeName);
          }
        }

        const methods = (typeMethods && typeMethods.length > 0) ? typeMethods : CONTAINER_METHODS;
        const typeLabel = (typeMethods && typeMethods.length > 0 && varMatch) ? ` (${varMatch[1]})` : '';

        for (const m of methods) {
          const isSnippet = m.insert.includes('$');
          suggestions.push({
            label: { label: m.label, description: m.detail },
            kind: isSnippet ? monaco.languages.CompletionItemKind.Method : monaco.languages.CompletionItemKind.Property,
            insertText: m.insert,
            insertTextRules: isSnippet ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : undefined,
            range, detail: m.detail + typeLabel, sortText: '0' + m.label,
          });
        }
        return { suggestions };
      }

      // ── GENERAL CONTEXT: scope-aware suggestions ────────────

      addVariableSuggestions(suggestions, monaco, range, position);

      if (ctx.hasUsingStd) {
        for (const m of CPP_STD_MEMBERS) {
          suggestions.push(makeSuggestion(monaco, model, m, range, '0', ctx));
        }
      }

      for (const kw of CPP_KEYWORDS) {
        suggestions.push({ label: kw, kind: monaco.languages.CompletionItemKind.Keyword, insertText: kw, range, sortText: '3' + kw });
      }

      suggestions.push({
        label: { label: 'std', description: 'Standard library namespace' },
        kind: monaco.languages.CompletionItemKind.Module, insertText: 'std', range,
        detail: 'Standard library namespace', sortText: '2std', commitCharacters: [':'],
      });

      // ── CONTEXT-AWARE SNIPPETS ──────────────────────────────
      const snippetSets = [];

      if (ctx.scope === 'file') {
        snippetSets.push(CPP_SNIPPETS_FILE_SCOPE);
      }
      if (ctx.insideFunction || ctx.scope === 'block') {
        snippetSets.push(CPP_SNIPPETS_FUNCTION_BODY);
      }
      if (ctx.insideLoop) {
        snippetSets.push(CPP_SNIPPETS_LOOP);
      }
      if (ctx.insideSwitch) {
        snippetSets.push(CPP_SNIPPETS_SWITCH);
      }
      if (ctx.insideClass) {
        snippetSets.push(CPP_SNIPPETS_CLASS);
      }

      if (snippetSets.length === 0) {
        snippetSets.push(CPP_SNIPPETS_FILE_SCOPE);
        snippetSets.push(CPP_SNIPPETS_FUNCTION_BODY);
      }

      const seen = new Set();
      for (const snippets of snippetSets) {
        for (const s of snippets) {
          if (seen.has(s.label)) continue;
          seen.add(s.label);
          suggestions.push({
            label: { label: s.label, description: s.detail },
            kind: monaco.languages.CompletionItemKind.Snippet,
            insertText: s.insert,
            insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            range, detail: s.detail,
            sortText: (ctx.scope === 'file' && (s.label === 'main' || s.label === 'cp-template')) ? '0' + s.label : '4' + s.label,
            filterText: s.kw || s.label,
          });
        }
      }

      return { suggestions };
    },
  });
  _disposables.push(cppProvider);

  // ── PYTHON COMPLETION PROVIDER ─────────────────────────────────
  const pyProvider = monaco.languages.registerCompletionItemProvider('python', {
    triggerCharacters: ['.', ' ', '@'],
    provideCompletionItems(model, position) {
      const word = model.getWordUntilPosition(position);
      const range = new monaco.Range(position.lineNumber, word.startColumn, position.lineNumber, word.endColumn);
      const lineContent = model.getLineContent(position.lineNumber);
      const textBefore = lineContent.substring(0, position.column - 1);
      const suggestions = [];

      if (textBefore.match(/^\s*(import|from)\s+\w*$/)) {
        for (const mod of PYTHON_MODULES) {
          suggestions.push({
            label: { label: mod.name, description: mod.desc },
            kind: monaco.languages.CompletionItemKind.Module,
            insertText: mod.name, range, detail: mod.desc, sortText: '0' + mod.name,
          });
        }
        return { suggestions };
      }

      // ── . (dot) → TYPE-AWARE Python methods ─────────────────
      if (textBefore.match(/\.\w*$/) && !textBefore.match(/^\s*(import|from)/)) {
        const varMatch = textBefore.match(/(\w+)\.\w*$/);
        let typeMethods = null;

        if (varMatch && smartEngine?.isReady()) {
          const varName = varMatch[1];
          const typeName = smartEngine.inferType(varName, position.lineNumber - 1, position.column - 1);
          if (typeName) {
            typeMethods = smartEngine.getMethodsForType(typeName);
          }
        }

        const methods = (typeMethods && typeMethods.length > 0) ? typeMethods : PYTHON_DOT_METHODS;
        for (const m of methods) {
          const isSnippet = m.insert.includes('$');
          suggestions.push({
            label: { label: m.label, description: m.detail },
            kind: monaco.languages.CompletionItemKind.Method,
            insertText: m.insert,
            insertTextRules: isSnippet ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : undefined,
            range, detail: m.detail, sortText: '0' + m.label,
          });
        }
        return { suggestions };
      }

      addVariableSuggestions(suggestions, monaco, range, position);

      for (const b of PYTHON_BUILTINS) {
        const isSnippet = b.insert.includes('$');
        suggestions.push({
          label: { label: b.label, description: b.detail },
          kind: monaco.languages.CompletionItemKind.Function,
          insertText: b.insert,
          insertTextRules: isSnippet ? monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet : undefined,
          range, detail: b.detail, sortText: '1' + b.label,
        });
      }

      for (const kw of PYTHON_KEYWORDS) {
        suggestions.push({ label: kw, kind: monaco.languages.CompletionItemKind.Keyword, insertText: kw, range, sortText: '2' + kw });
      }

      for (const s of PYTHON_SNIPPETS) {
        suggestions.push({
          label: { label: s.label, description: s.detail },
          kind: monaco.languages.CompletionItemKind.Snippet,
          insertText: s.insert,
          insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
          range, detail: s.detail, sortText: '3' + s.label,
        });
      }

      return { suggestions };
    },
  });
  _disposables.push(pyProvider);
}

export function disposeFallbackCompletions() {
  while (_disposables.length) {
    try { _disposables.pop().dispose(); } catch {}
  }
}
