import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useMorrisStore } from '../../stores/morris-traversal-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9', dotGrid: '#e7e5e4', stroke: '#1c1917', textPrimary: '#1c1917',
    textSecondary: '#78716c', nodeFill: '#dbeafe', nodeStroke: '#1971c2',
    visitedFill: '#d1fae5', visitedStroke: '#059669', currentFill: '#fef08a',
    currentStroke: '#ca8a04', threadStroke: '#e11d48', predFill: '#fce7f3',
    predStroke: '#db2777', edgeStroke: '#78716c', resultBg: '#f0fdf4',
  },
  dark: {
    bg: '#1c1917', dotGrid: 'rgba(255,255,255,0.06)', stroke: 'rgba(255,255,255,0.6)',
    textPrimary: '#e7e5e4', textSecondary: '#a8a29e', nodeFill: '#1e3a5f',
    nodeStroke: '#74c0fc', visitedFill: '#14532d', visitedStroke: '#4ade80',
    currentFill: '#422006', currentStroke: '#facc15', threadStroke: '#fb7185',
    predFill: '#4a0e23', predStroke: '#f472b6', edgeStroke: '#a8a29e', resultBg: '#14532d',
  },
};

function getPal() {
  return (document.documentElement.getAttribute('data-theme') === 'light') ? PALETTE.light : PALETTE.dark;
}

function layoutTree(treeNodes, W, H) {
  if (!treeNodes.length) return [];
  const maxDepth = Math.max(...treeNodes.map(n => n.depth));
  const topPad = 50;
  const botPad = 30;
  const levelH = maxDepth > 0 ? (H - topPad - botPad) / maxDepth : 0;
  const positions = {};

  const byDepth = {};
  treeNodes.forEach(n => {
    if (!byDepth[n.depth]) byDepth[n.depth] = [];
    byDepth[n.depth].push(n);
  });

  const leafCount = treeNodes.filter(n => !n.hasLeft && !n.hasRight).length;
  const sidePad = 40;

  function assignX(node, minX, maxX) {
    const x = (minX + maxX) / 2;
    const y = topPad + node.depth * levelH;
    positions[node.val] = { x, y, ...node };
    const children = treeNodes.filter(n => n.parentVal === node.val);
    const leftChild = children.find(n => n.pos % 2 === 0);
    const rightChild = children.find(n => n.pos % 2 === 1);
    if (leftChild) assignX(leftChild, minX, x);
    if (rightChild) assignX(rightChild, x, maxX);
  }

  const root = treeNodes.find(n => n.depth === 0);
  if (root) assignX(root, sidePad, W - sidePad);

  return positions;
}

const MorrisTraversalCanvas = forwardRef(function MorrisTraversalCanvas({ morrisRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const stateRef = useRef({
    currentVal: null,
    predVal: null,
    visitedSet: new Set(),
    threads: [],
    resultList: [],
  });

  const addAnim = useCallback((type, extra = {}) => {
    animsRef.current.push({ type, t0: performance.now(), dur: extra.dur || 600, ...extra });
  }, []);

  const updateState = useCallback((update) => {
    Object.assign(stateRef.current, update);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, updateState }), [addAnim, updateState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let rafId;
    let lastTheme = '';

    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const w = Math.floor(rect.width);
      const h = Math.max(280, Math.floor(rect.height));
      canvas.width = w * DPR;
      canvas.height = h * DPR;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      wRef.current = w;
      hRef.current = h;
    }
    resize();

    const ro = new ResizeObserver(resize);
    ro.observe(canvas.parentElement);

    function draw() {
      const W = wRef.current;
      const H = hRef.current;
      const pal = getPal();
      const now = performance.now();
      const state = stateRef.current;

      ctx.clearRect(0, 0, W, H);

      for (let x = 20; x < W; x += 20) {
        for (let y = 20; y < H; y += 20) {
          ctx.fillStyle = pal.dotGrid;
          ctx.fillRect(x, y, 1.5, 1.5);
        }
      }

      const morris = morrisRef.current;
      if (!morris) { rafId = requestAnimationFrame(draw); return; }

      const treeNodes = morris.getTreeNodes();
      const positions = layoutTree(treeNodes, W, H);
      const R = 20;

      treeNodes.forEach(n => {
        if (n.parentVal !== null && positions[n.parentVal] && positions[n.val]) {
          const parent = positions[n.parentVal];
          const child = positions[n.val];
          ctx.beginPath();
          ctx.strokeStyle = pal.edgeStroke;
          ctx.lineWidth = 1.5;
          ctx.moveTo(parent.x, parent.y + R);
          ctx.lineTo(child.x, child.y - R);
          ctx.stroke();
        }
      });

      const threads = state.threads || [];
      threads.forEach(t => {
        const from = positions[t.from];
        const to = positions[t.to];
        if (!from || !to) return;
        ctx.save();
        ctx.setLineDash([6, 4]);
        ctx.strokeStyle = pal.threadStroke;
        ctx.lineWidth = 2;
        ctx.beginPath();
        const cx = (from.x + to.x) / 2 + 30;
        const cy = (from.y + to.y) / 2;
        ctx.moveTo(from.x + R, from.y);
        ctx.quadraticCurveTo(cx, cy, to.x, to.y - R);
        ctx.stroke();
        ctx.setLineDash([]);

        const angle = Math.atan2(to.y - R - cy, to.x - cx);
        const ax = to.x - 1;
        const ay = to.y - R + 1;
        ctx.fillStyle = pal.threadStroke;
        ctx.beginPath();
        ctx.moveTo(ax, ay);
        ctx.lineTo(ax - 8 * Math.cos(angle - 0.4), ay - 8 * Math.sin(angle - 0.4));
        ctx.lineTo(ax - 8 * Math.cos(angle + 0.4), ay - 8 * Math.sin(angle + 0.4));
        ctx.fill();
        ctx.restore();
      });

      Object.values(positions).forEach(p => {
        let fill = pal.nodeFill;
        let stroke = pal.nodeStroke;

        if (state.visitedSet.has(p.val)) {
          fill = pal.visitedFill;
          stroke = pal.visitedStroke;
        }
        if (p.val === state.predVal) {
          fill = pal.predFill;
          stroke = pal.predStroke;
        }
        if (p.val === state.currentVal) {
          fill = pal.currentFill;
          stroke = pal.currentStroke;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, R, 0, Math.PI * 2);
        ctx.fillStyle = fill;
        ctx.fill();
        ctx.strokeStyle = stroke;
        ctx.lineWidth = 2.5;
        ctx.stroke();

        ctx.fillStyle = pal.textPrimary;
        ctx.font = `bold 14px 'Inter', 'Segoe UI', sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(p.val), p.x, p.y);
      });

      if (state.currentVal !== null && positions[state.currentVal]) {
        const cp = positions[state.currentVal];
        const pulse = 0.5 + 0.5 * Math.sin(now / 300);
        ctx.beginPath();
        ctx.arc(cp.x, cp.y, R + 5 + pulse * 3, 0, Math.PI * 2);
        ctx.strokeStyle = pal.currentStroke;
        ctx.lineWidth = 1.5;
        ctx.globalAlpha = 0.4 + pulse * 0.3;
        ctx.stroke();
        ctx.globalAlpha = 1;

        ctx.fillStyle = pal.currentStroke;
        ctx.font = `bold 10px 'Inter', sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText('current', cp.x, cp.y - R - 12);
      }

      if (state.predVal !== null && positions[state.predVal]) {
        const pp = positions[state.predVal];
        ctx.fillStyle = pal.predStroke;
        ctx.font = `bold 10px 'Inter', sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText('pred', pp.x, pp.y + R + 14);
      }

      animsRef.current = animsRef.current.filter(a => {
        const elapsed = now - a.t0;
        const t = Math.min(elapsed / a.dur, 1);
        if (t >= 1) return false;

        if (a.type === 'visit' && positions[a.node]) {
          const np = positions[a.node];
          const scale = 1 + 0.3 * Math.sin(t * Math.PI);
          ctx.save();
          ctx.translate(np.x, np.y);
          ctx.scale(scale, scale);
          ctx.beginPath();
          ctx.arc(0, 0, R + 3, 0, Math.PI * 2);
          ctx.strokeStyle = pal.visitedStroke;
          ctx.lineWidth = 3;
          ctx.globalAlpha = 1 - t;
          ctx.stroke();
          ctx.globalAlpha = 1;
          ctx.restore();
        }

        if (a.type === 'thread' && positions[a.from] && positions[a.to]) {
          const fp = positions[a.from];
          const tp = positions[a.to];
          ctx.save();
          ctx.globalAlpha = (1 - t) * 0.6;
          ctx.strokeStyle = pal.threadStroke;
          ctx.lineWidth = 4;
          ctx.setLineDash([]);
          ctx.beginPath();
          const cx = (fp.x + tp.x) / 2 + 30;
          const cy = (fp.y + tp.y) / 2;
          ctx.moveTo(fp.x + R, fp.y);
          ctx.quadraticCurveTo(cx, cy, tp.x, tp.y - R);
          ctx.stroke();
          ctx.restore();
        }

        return true;
      });

      if (state.resultList.length > 0) {
        const resY = H - 28;
        const resText = 'Inorder: [' + state.resultList.join(', ') + ']';
        ctx.fillStyle = pal.resultBg;
        const tw = ctx.measureText(resText).width;
        const rx = W / 2 - tw / 2 - 12;
        ctx.fillRect(rx, resY - 12, tw + 24, 24);
        ctx.strokeStyle = pal.visitedStroke;
        ctx.lineWidth = 1;
        ctx.strokeRect(rx, resY - 12, tw + 24, 24);
        ctx.fillStyle = pal.textPrimary;
        ctx.font = `bold 13px 'JetBrains Mono', 'Fira Code', monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(resText, W / 2, resY);
      }

      const legendY = 14;
      ctx.font = `11px 'Inter', sans-serif`;
      ctx.textAlign = 'left';
      const items = [
        { color: pal.currentFill, border: pal.currentStroke, label: 'Current' },
        { color: pal.predFill, border: pal.predStroke, label: 'Predecessor' },
        { color: pal.visitedFill, border: pal.visitedStroke, label: 'Visited' },
        { color: pal.threadStroke, border: null, label: 'Thread', isDash: true },
      ];
      let lx = 10;
      items.forEach(it => {
        if (it.isDash) {
          ctx.save();
          ctx.setLineDash([4, 3]);
          ctx.strokeStyle = it.color;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(lx, legendY);
          ctx.lineTo(lx + 16, legendY);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.restore();
        } else {
          ctx.fillStyle = it.color;
          ctx.fillRect(lx, legendY - 5, 10, 10);
          ctx.strokeStyle = it.border;
          ctx.lineWidth = 1;
          ctx.strokeRect(lx, legendY - 5, 10, 10);
        }
        ctx.fillStyle = pal.textSecondary;
        ctx.fillText(it.label, lx + 18, legendY + 3);
        lx += ctx.measureText(it.label).width + 30;
      });

      rafId = requestAnimationFrame(draw);
    }

    rafId = requestAnimationFrame(draw);
    return () => {
      cancelAnimationFrame(rafId);
      ro.disconnect();
    };
  }, [morrisRef]);

  return (
    <div className="dc-canvas-wrap" style={{ height: 340 }}>
      <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%' }} />
    </div>
  );
});

export default MorrisTraversalCanvas;
