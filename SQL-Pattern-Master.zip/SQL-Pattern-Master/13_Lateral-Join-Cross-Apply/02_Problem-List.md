# LATERAL JOIN / CROSS APPLY — Problem List

> **15 problems in progressive difficulty. 8 MUST-DO highlighted. Covers top-N per group, dependent LIMIT, array/JSON unnesting, and table-valued functions. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Top 3 Orders Per Customer | Common | Medium | LATERAL + LIMIT | Purest LATERAL use case |
| 2 | Most Recent Login Per User | Common | Easy | LATERAL LIMIT 1 | Top-1 via LATERAL (vs ROW_NUMBER) |
| 3 | Department Top 3 Salaries | LC 185 | Hard | LATERAL alternative | LATERAL approach to classic problem |
| 4 | Unnest JSON Array | Common | Medium | LATERAL + jsonb_elements | Expand JSON into rows |
| 5 | Expand Array Column | Common | Easy | LATERAL + unnest | Normalize array to rows |
| 6 | Closest Store Per Customer | Common | Medium | LATERAL + ORDER + LIMIT | Nearest neighbor per row |
| 7 | Monthly Revenue Per Product (last 3) | Common | Medium | LATERAL + date filter | Dependent subquery with date range |
| 8 | Generate Date Range Per Project | Common | Medium | LATERAL + generate_series | Per-row series generation |

---

## Complete 15-Problem Progression

### Easy (Problems 1-4) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Most Recent Login Per User | Common | LATERAL LIMIT 1 | Equivalent to ROW_NUMBER=1 |
| 2 | Expand Array Column | Common | LATERAL unnest | Array → rows |
| 3 | Top 1 Order Per Customer | Common | LEFT JOIN LATERAL | Keep customers with no orders (NULL) |
| 4 | Latest Price Per Product | Common | LATERAL + ORDER DESC | Most recent price change |

### Medium (Problems 5-11) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 5 | Top 3 Orders Per Customer | Common | LATERAL + LIMIT 3 | Multi-row per outer row |
| 6 | Unnest JSON Array | Common | jsonb_array_elements | JSON expansion |
| 7 | Closest Store Per Customer | Common | LATERAL + distance calc | Nearest neighbor with LIMIT 1 |
| 8 | Monthly Revenue Last 3 Months | Common | LATERAL + date range | Dependent filter on date |
| 9 | Generate Date Range Per Project | Common | LATERAL + generate_series | Per-row series |
| 10 | First N Events Per Session | Common | LATERAL + LIMIT N | Top-N per session |
| 11 | Salary Band Lookup | Common | LATERAL + function | Table-valued function call |

### Hard (Problems 12-15) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 12 | Department Top 3 Salaries | LC 185 | LATERAL alternative | Compare with ROW_NUMBER solution |
| 13 | Dynamic LIMIT Per Category | Advanced | LATERAL + variable N | Different N per group |
| 14 | Recursive Expansion Per Row | Advanced | LATERAL + recursive | Per-row recursion |
| 15 | Multi-Table Dependent Join | Advanced | Chained LATERAL | LATERAL referencing prior LATERAL |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Most Recent Login Per User

```
Pattern:     LEFT JOIN LATERAL + LIMIT 1
Approach:    FROM users u LEFT JOIN LATERAL (
               SELECT * FROM logins WHERE user_id = u.id ORDER BY date DESC LIMIT 1
             ) l ON TRUE
Key Insight: LIMIT 1 in LATERAL = top-1 per group (like ROW_NUMBER=1 but more readable)
One-liner:   LEFT JOIN LATERAL with ORDER DESC LIMIT 1 = most recent per user.
```

### Problem 5: Top 3 Orders Per Customer

```
Pattern:     CROSS JOIN LATERAL + LIMIT 3
Approach:    FROM customers c CROSS JOIN LATERAL (
               SELECT * FROM orders WHERE customer_id = c.id ORDER BY amount DESC LIMIT 3
             ) top3
Key Insight: CROSS JOIN drops customers with no orders; use LEFT JOIN LATERAL to keep them
One-liner:   LATERAL subquery returns top 3 orders per customer via LIMIT 3.
```

### Problem 12: Department Top 3 Salaries (LATERAL approach)

```
Pattern:     LATERAL alternative to DENSE_RANK
Approach:    FROM departments d CROSS JOIN LATERAL (
               SELECT DISTINCT salary FROM employees
               WHERE dept_id = d.id ORDER BY salary DESC LIMIT 3
             ) top_salaries
             JOIN employees e ON e.dept_id = d.id AND e.salary = top_salaries.salary
Key Insight: LATERAL with DISTINCT + LIMIT 3 gets top 3 distinct salaries per dept
One-liner:   LATERAL for top 3 distinct salaries; join back for employee details.
```

### Problem 13: Dynamic LIMIT Per Category

```
Pattern:     LATERAL with variable N
Approach:    Categories table has a column 'top_n'
             FROM categories c CROSS JOIN LATERAL (
               SELECT * FROM products WHERE cat = c.id ORDER BY sales DESC LIMIT c.top_n
             ) p
Key Insight: LIMIT can reference outer column — impossible with ROW_NUMBER approach
One-liner:   LATERAL lets LIMIT vary per row — use outer column as the limit value.
```

---

## Pattern Distribution

```
TOP-N VIA LATERAL (LIMIT per row):      6 problems  (1, 3-5, 10, 12)
UNNEST / JSON EXPANSION:               3 problems  (2, 6, 9)
DEPENDENT FILTER (correlated range):    3 problems  (7, 8, 11)
DYNAMIC / ADVANCED:                     3 problems  (13-15)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Most recent login, expand array (basic LATERAL)
- Day 2: Top 3 orders, LEFT vs CROSS JOIN LATERAL
- Day 3: JSON unnest, generate_series per row

### Week 2: Applied Patterns (Days 4-6)
- Day 4: Closest store, monthly revenue (dependent filter)
- Day 5: LC 185 LATERAL approach vs ROW_NUMBER approach
- Day 6: Dynamic LIMIT, chained LATERAL

### Week 3: Review (Day 7)
- Day 7: Re-solve comparing LATERAL vs ROW_NUMBER solutions

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Top-N (all databases) | Pattern 09 (Top-N Per Group) — ROW_NUMBER works everywhere |
| Scalar correlated value | Pattern 05 (Subquery/EXISTS) — scalar in SELECT |
| Expand JSON/arrays | LATERAL is the primary technique |
| Date series per entity | Pattern 11 (Date Series Fill) — CROSS JOIN approach alternative |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     15 (4 Easy, 7 Medium, 4 Hard)
MUST-DO:            Top-3 per customer, most recent login, JSON unnest, LC 185 alt
TOP 3 MOST ASKED:   Top-N per group via LATERAL, JSON expansion, dependent LIMIT
PATTERN SPLIT:      Top-N (6), Unnest (3), Dependent filter (3), Advanced (3)
STUDY ORDER:        LIMIT 1 → LIMIT N → Unnest → Dependent → Dynamic
KEY INSIGHT:        LATERAL = correlated subquery in FROM that returns rows
INTERVIEW LINE:     "LATERAL JOIN lets me run a dependent subquery per outer row
                     — great for Top-N with LIMIT, JSON unnesting, and
                     per-row series generation."
```

---

## 30-SECOND REVISION BOX

```
LATERAL:       FROM a CROSS JOIN LATERAL (SELECT ... WHERE ref = a.col LIMIT N) b
LEFT LATERAL:  FROM a LEFT JOIN LATERAL (...) b ON TRUE  (keep unmatched)
CROSS APPLY:   SQL Server equivalent of CROSS JOIN LATERAL
OUTER APPLY:   SQL Server equivalent of LEFT JOIN LATERAL
RETURNS:       Multiple rows AND columns (unlike scalar subquery)
PERFORMANCE:   Index on correlated column → O(N log M) per row
VS ROW_NUMBER: LATERAL is more readable, supports dynamic LIMIT
PORTABILITY:   PostgreSQL 9.3+, MySQL 8.0.14+, SQL Server (as APPLY)
RULE:          Use LATERAL when you need LIMIT per row or multi-column returns
```
