# System-Patterns — Tricks and Recognition

> **Permanent Recall:** THE MASTER DECISION TABLE maps constraints and keywords to patterns. Use this for instant pattern recognition in FAANG interviews.

---

## THE MASTER DECISION TABLE: Constraint → Algorithm

| Constraint | Allowed Complexity | Algorithm / Pattern |
|------------|--------------------|--------------------|
| n ≤ 10 | O(n!) | Brute force, backtrack, permutations |
| n ≤ 15 | O(2^n · n) | Bitmask DP, subset enumeration |
| n ≤ 20 | O(2^n) | Bitmask, backtrack, subsets |
| n ≤ 25 | O(2^n) | Same; consider meet in middle |
| n ≤ 40 | O(2^(n/2)) | **Meet in the Middle** |
| n ≤ 100 | O(n^4) | 4 nested loops (rare) |
| n ≤ 200 | O(n³) | Floyd-Warshall, 3 nested loops |
| n ≤ 500 | O(n³) | DP with 3 dimensions, all pairs |
| n ≤ 1000 | O(n²) | DP, two pointers, nested loops |
| n ≤ 2000 | O(n²) | Same |
| n ≤ 10^4 | O(n²) | DP, BFS/DFS, graph |
| n ≤ 10^5 | O(n log n) | Sort, heap, BIT, segment tree, D&C |
| n ≤ 5·10^5 | O(n log n) | Same |
| n ≤ 10^6 | O(n) or O(n log n) | Linear scan, two pointers, monotonic stack |
| n ≤ 10^7 | O(n) | Single pass, no nested loops |
| n ≤ 10^8 | O(n) or O(log n) | Math, formula, binary search |
| n ≤ 10^9 | O(log n) or O(1) | Binary search, math |
| Stream / unknown | O(n) single pass | Reservoir, sliding window, two pointers |

---

## THE MASTER DECISION TABLE: Keyword → Pattern

| Keyword / Phrase | Pattern | Example Problem |
|------------------|---------|-----------------|
| "minimum/maximum X such that Y" | **Binary Search on Answer** | Koko Eating Bananas, Split Array |
| "smallest/largest possible" | BS on Answer or Greedy | Capacity to Ship |
| "intervals", "meetings", "overlap" | **Sweep Line** | Meeting Rooms II, Merge Intervals |
| "range sum", "range query", "update" | **BIT / Segment Tree** | Range Sum Mutable, Inversions |
| "next greater", "next smaller" | **Monotonic Stack** | Next Greater Element, Daily Temperatures |
| "histogram", "rectangle" | Monotonic Stack + DP | Largest Rectangle |
| "trapping water" | Monotonic Stack or Two Pointers | Trapping Rain Water |
| "product except self" | **Two-Pass** | Product of Array Except Self |
| "left and right" | Two-Pass | Candy, Trapping Water |
| "shortest path" (unweighted) | **BFS** | Word Ladder, Knight |
| "shortest path" (weighted) | Dijkstra / Bellman-Ford | Network Delay |
| "word ladder", "transform" | BFS | Word Ladder I/II |
| "word search", "prefix" | **Trie + Backtrack** | Word Search II |
| "autocomplete" | Trie | Design Search Autocomplete |
| "subset sum", "partition" (n~40) | **Meet in the Middle** | Partition to K Equal Sums |
| "closest pair", "merge" | **Divide and Conquer** | Closest Pair, Merge Sort |
| "random from stream" | **Reservoir Sampling** | Random Pick Index |
| "shuffle" | **Fisher-Yates** | Shuffle an Array |
| "kth largest/smallest" | Heap or QuickSelect | Kth Largest Element |
| "top K" | Heap | Top K Frequent |
| "sliding window" | Sliding Window / Two Pointers | Max Sliding Window |
| "two sum", "three sum" | Hash / Two Pointers | Two Sum, 3Sum |
| "palindrome" | Two Pointers or DP | Longest Palindromic Substring |
| "subsequence" | DP | LIS, LCS |
| "connected components" | Union-Find or DFS | Number of Islands |
| "cycle" | Union-Find or DFS | Redundant Connection |
| "topological order" | Topological Sort | Course Schedule |
| "memoization" | DP | Climbing Stairs |

---

## THE MASTER Flowchart: Given a Problem → Which Algorithm?

```mermaid
flowchart TD
    READ["Read problem"] --> CONSTRAINT["Check constraint n"]
    READ --> KEYWORD["Check keywords"]
    CONSTRAINT --> C1["n ≤ 10"]
    CONSTRAINT --> C2["n ≤ 20"]
    CONSTRAINT --> C3["n ≤ 40"]
    CONSTRAINT --> C4["n ≤ 10^5"]
    CONSTRAINT --> C5["n ≤ 10^6"]
    CONSTRAINT --> C6["n ≤ 10^8"]
    C1 --> A1["Brute, Backtrack, O(n!)"]
    C2 --> A2["Bitmask, Subsets, O(2^n)"]
    C3 --> A3["Meet in the Middle, O(2^(n/2))"]
    C4 --> A4["Sort, Heap, BIT, O(n log n)"]
    C5 --> A5["Two pointers, Mono stack, O(n)"]
    C6 --> A6["Binary search, Math, O(log n)"]
    KEYWORD --> K1["Min/max X s.t. Y"]
    KEYWORD --> K2["Intervals/meetings"]
    KEYWORD --> K3["Range query + update"]
    KEYWORD --> K4["Next greater/smaller"]
    KEYWORD --> K5["Product except self"]
    KEYWORD --> K6["Shortest path"]
    KEYWORD --> K7["Word search/prefix"]
    KEYWORD --> K8["Random from stream"]
    KEYWORD --> K9["Shuffle"]
    K1 --> B1["BS on Answer"]
    K2 --> B2["Sweep Line"]
    K3 --> B3["BIT / Segment Tree"]
    K4 --> B4["Monotonic Stack"]
    K5 --> B5["Two-Pass"]
    K6 --> B6["BFS / Dijkstra"]
    K7 --> B7["Trie + Backtrack"]
    K8 --> B8["Reservoir Sampling"]
    K9 --> B9["Fisher-Yates"]
    style A2 fill:#90EE90
    style A3 fill:#87CEEB
    style A4 fill:#DDA0DD
    style B1 fill:#FFE4B5
    style B3 fill:#F0E68C
```

<details>
<summary>ASCII fallback</summary>

```
Read problem
    │
    ├─ "Min/max X s.t. Y" ──────────────────→ BS on Answer
    ├─ "Intervals/meetings/overlap" ────────→ Sweep Line
    ├─ "Range query + update" ───────────────→ BIT / Segment Tree
    ├─ "Next greater/smaller" ───────────────→ Monotonic Stack
    ├─ "Product except self" / "both sides" ──→ Two-Pass
    ├─ "Shortest path" (unweighted) ─────────→ BFS
    ├─ "Word search" / "prefix" ─────────────→ Trie + Backtrack
    ├─ "Subset sum" (n≤40) ─────────────────→ Meet in the Middle
    ├─ "Random from stream" ─────────────────→ Reservoir Sampling
    ├─ "Shuffle" ───────────────────────────→ Fisher-Yates
    │
    └─ Check n:
          n≤20 → Bitmask/Backtrack
          n≤40 → Meet in Middle
          n≤10^5 → O(n log n): Sort, Heap, BIT
          n≤10^6 → O(n): Two pointers, Monotonic stack
```

</details>

---

## Quick Recognition Cheat Sheet

| If You See... | Think... |
|---------------|----------|
| n ≤ 20 | Bitmask, backtrack |
| n ≤ 40 | Meet in the middle |
| "minimum X such that" | Binary search on answer |
| Intervals, events | Sweep line |
| Range query | BIT, segment tree |
| Next greater | Monotonic stack |
| Both directions | Two-pass |
| Stream + random | Reservoir sampling |
| Shuffle | Fisher-Yates |
| Word + grid | Trie + backtrack |
| Shortest (unweighted) | BFS |
| Subsequence | DP |
| Connected | Union-Find, DFS |
| Top K | Heap |
| Two sum variant | Hash, two pointers |

---

## Combination Patterns (System-Patterns)

| Combination | When | Example |
|-------------|------|---------|
| **Monotonic Stack + DP** | Next greater + optimal subproblem | Largest Rectangle, Trapping Water |
| **BFS + DP** | Shortest path + state (keys, visited) | Word Ladder, Knight, Shortest Path in Grid |
| **BS + Greedy** | Search value, check feasibility | Koko, Split Array, Capacity |
| **BS + DP** | Search threshold, DP for count | Kth Smallest in Matrix |
| **Trie + Backtrack** | Prefix lookup during search | Word Search II, Word Squares |
| **BIT + Inversions** | Count inversions in O(n log n) | Count Inversions |
| **Sweep + Heap** | Events + track max/min active | Skyline, Meeting Rooms II (alt) |
| **Two-Pass + O(1) space** | Product except self | Product of Array Except Self |
| **D&C + Merge** | Split, solve, merge | Merge Sort, Closest Pair |
| **Meet in Middle + Hash** | Enumerate halves, match | 4Sum II, Subset Sum |

---

## Anti-Patterns (What NOT to Use)

| Wrong Choice | Why | Use Instead |
|--------------|-----|-------------|
| Dijkstra for unweighted | Overkill; BFS is simpler | BFS |
| Full brute for n=40 | O(2^40) too slow | Meet in the Middle |
| O(n²) for n=10^6 | TLE | O(n) or O(n log n) |
| Segment tree for static array | Overkill | Prefix sum |
| DP for "min X such that Y" | Often BS is simpler | Binary Search on Answer |
| BFS for weighted graph | Wrong; BFS assumes unit weight | Dijkstra |
| Hash for range query | O(n) per query | BIT, Segment Tree |

---

## FINAL MEMORY COMPRESSION BLOCK

```
CONSTRAINT:   n≤20→bitmask, n≤40→meet-in-middle, n≤10^5→O(nlogn), n≤10^6→O(n)
KEYWORD:      min X s.t. Y→BS; intervals→sweep; range query→BIT; next greater→mono stack
KEYWORD:      both sides→two-pass; stream random→reservoir; shuffle→Fisher-Yates
KEYWORD:      word+grid→trie+backtrack; shortest unweighted→BFS
COMBOS:       Mono+DP, BFS+DP, BS+Greedy, Trie+Backtrack
ANTI:         Dijkstra for unweighted; O(n²) for n=10^6
```

---

## 30-SECOND REVISION BOX

```
□ n≤20: bitmask; n≤40: meet in middle
□ "min X s.t. Y" → BS on answer
□ Intervals → sweep line
□ Range query → BIT/SegTree
□ Next greater → monotonic stack
□ Both sides → two-pass
□ Word+grid → trie+backtrack
□ Stream random → reservoir; shuffle → Fisher-Yates
```
