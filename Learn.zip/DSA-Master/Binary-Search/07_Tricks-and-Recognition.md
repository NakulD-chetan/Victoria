# Binary Search — Tricks & Recognition

> **Quick recall rules for instantly recognizing binary search problems, hidden signals, constraint clues, and comparison with two pointers.**

---

## Pattern Triggers — Instant Recognition

### Tier 1: Obvious Signals (100% Binary Search)

| Keyword in Problem | Pattern Type | Example |
|--------------------|-------------|---------|
| "sorted array" | Standard BS | Binary Search (LC 704) |
| "find target in sorted array" | Standard BS | Search Insert Position (LC 35) |
| "first/last position of element" | bisect_left + bisect_right | Find First and Last (LC 34) |
| "search in rotated sorted array" | Rotated BS | Search in Rotated (LC 33) |
| "search a 2D matrix" | Matrix BS | Search a 2D Matrix (LC 74) |

### Tier 2: Strong Signals (90% Binary Search)

| Keyword / Constraint | Why Binary Search |
|---------------------|-------------------|
| "minimum X such that..." | BS on answer |
| "maximum X such that..." | BS on answer |
| "minimum capacity/speed/limit" | BS on answer |
| "smallest/largest value that works" | BS on answer |
| "can you do it in K operations?" | BS on K |
| "minimum maximum" or "maximum minimum" | BS on answer (agg min-max) |

### Tier 3: Hidden Signals (Tricky — Need to Decode)

| Problem Description | Hidden Binary Search |
|--------------------|----------------------|
| "Koko eating bananas" | BS on eating speed (hours) |
| "Capacity to ship packages" | BS on capacity |
| "Minimum number of days" | BS on days |
| "Split array largest sum" | BS on maximum subarray sum |
| "Kth smallest in matrix" | BS on value + count |
| "Median of two sorted arrays" | BS on partition |
| "Minimum in rotated array" | BS (find pivot) |
| "Peak element" | BS (compare with neighbors) |

---

## The "Sorted" Keyword Trigger

**When you see "sorted" or "non-decreasing" or "ascending order":**

```
→ Standard binary search is in play
→ Exact match, or lower/upper bound
→ O(log n) is achievable
```

**Variants:**
- Sorted array → exact, bisect_left, bisect_right
- Sorted matrix (row + col) → 2D binary search
- Sorted + rotated → modified BS
- Two sorted arrays → BS on one, derive other

---

## Hidden Binary Search: "Minimum Maximum" / "Maximum Minimum"

**Classic pattern that catches candidates off guard.**

```
"Split array into K subarrays — minimize the LARGEST sum"

Interpretation:
- We're not binary searching the array
- We're binary searching the ANSWER (the largest sum)
- For candidate X: can we split so each part ≤ X?
- If X works, X+1 works. Monotonic!
```

**Recognition:**
- "Minimize the maximum" → BS on the maximum value
- "Maximize the minimum" → BS on the minimum value
- The inner "max/min" is what we're optimizing
- The outer "min/max" is the objective

```
Examples:
- Min max sum of subarray     → BS on max sum
- Max min distance between   → BS on distance
- Min max capacity           → BS on capacity
```

---

## Binary Search on Answer Recognition

**The 3-Question Test:**

1. **Can we phrase as "Find min/max X such that condition(X)"?**
   - Yes → candidate for BS on answer

2. **Is condition(X) a yes/no check?**
   - Yes → we can evaluate at each candidate

3. **Is it monotonic?**
   - If works(X) then works(X+1) [or reverse]
   - Yes → binary search on X

**Example:**
```
"Minimum speed to finish in H hours"
→ Find minimum speed S such that hours_needed(S) ≤ H
→ condition(S) = (hours_needed(S) <= H)
→ If S works, S+1 works (faster = fewer hours)
→ BS on speed
```

---

## Constraint Clues

### Array Size vs Expected Complexity

| Constraint | Time Expected | Binary Search? |
|-----------|---------------|----------------|
| n ≤ 10^5, answer 10^9 | O(n log 10^9) ≈ O(30n) | Strong signal for BS on answer |
| n ≤ 10^6 | O(n log n) or O(n) | Sorted → BS. Else consider |
| n ≤ 10^3 | O(n²) OK | Maybe, but brute force might pass |
| Values up to 10^9 | Answer in that range | BS on answer likely |

### The "n ≤ 10^5 with O(log n) expected" Signal

When problem says n ≤ 10^5 but you need sublinear time:
- Not O(n) — that would be linear scan
- O(log n) suggests binary search
- Often: BS on answer with O(n) check per iteration → O(n log R)

---

## Comparison: Binary Search vs Two Pointers

| Aspect | Binary Search | Two Pointers |
|--------|---------------|--------------|
| **Requirement** | Sorted or monotonic answer | Often sorted (or specific structure) |
| **Movement** | Jump to middle, discard half | Move left/right incrementally |
| **Complexity** | O(log n) or O(n log R) | O(n) |
| **Use when** | "Find X" or "min/max X such that" | "Find pair" or "two sum" |
| **Search space** | Index or answer value | Two positions in array |

**When both could work:**
- "Two sum in sorted array" → Two pointers O(n) is simpler
- "Find target" → Binary search O(log n) is better
- "Triplet sum" → Two pointers + linear scan

**Rule of thumb:** If you need to "find a value" and data is sorted → binary search. If you need "find pair/triplet" → two pointers.

---

## The "Count Elements" Trick

**"How many elements are < X?" or "≤ X"?**

```
Count < X:   bisect_left(arr, X)
Count ≤ X:   bisect_right(arr, X)
Count == X:  bisect_right(arr, X) - bisect_left(arr, X)
Count > X:   len(arr) - bisect_right(arr, X)
Count ≥ X:   len(arr) - bisect_left(arr, X)
```

---

## The "Insert Position" Trick

**"Where would X go to maintain sorted order?"**

```
Insert position (even if X exists): bisect_left(arr, X)
```

---

## The "Range Query" Trick

**"Find first and last occurrence of X"**

```python
left = bisect_left(arr, X)
right = bisect_right(arr, X) - 1
if left <= right:
    return [left, right]
return [-1, -1]
```

---

## Quick Decision Flowchart

```mermaid
flowchart TD
    START([READ PROBLEM])
    A{"Sorted array" mentioned?}
    B{"Minimum X such that..."?}
    C{"Maximum X such that..."?}
    D{"Minimum maximum" or "Maximum minimum"?}
    E{n ≤ 10^5, answer range 10^9?}
    F{"Rotated" + "sorted"?}
    G{"Matrix" + "sorted"?}
    H[Standard BS]
    I[BS on answer]
    J[BS on answer]
    K[BS on answer]
    L[BS on answer]
    M[Rotated BS]
    N[Matrix BS]
    O[Consider other patterns]

    START --> A
    A -- Yes --> H
    A -- No --> B
    B -- Yes --> I
    B -- No --> C
    C -- Yes --> J
    C -- No --> D
    D -- Yes --> K
    D -- No --> E
    E -- Yes --> L
    E -- No --> F
    F -- Yes --> M
    F -- No --> G
    G -- Yes --> N
    G -- No --> O

    style A fill:#ffd43b,color:#000
    style B fill:#ffd43b,color:#000
    style C fill:#ffd43b,color:#000
    style D fill:#ffd43b,color:#000
    style E fill:#ffd43b,color:#000
    style F fill:#ffd43b,color:#000
    style G fill:#ffd43b,color:#000
    style H fill:#51cf66,color:#fff
    style I fill:#51cf66,color:#fff
    style J fill:#51cf66,color:#fff
    style K fill:#51cf66,color:#fff
    style L fill:#51cf66,color:#fff
    style M fill:#51cf66,color:#fff
    style N fill:#51cf66,color:#fff
    style O fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
READ PROBLEM
    │
    ├── "Sorted array" mentioned? ──── Yes ──→ Standard BS
    │
    ├── "Minimum X such that..."? ──── Yes ──→ BS on answer
    │
    ├── "Maximum X such that..."? ──── Yes ──→ BS on answer
    │
    ├── "Minimum maximum" or "Maximum minimum"? ── Yes ──→ BS on answer
    │
    ├── n ≤ 10^5, answer range 10^9? ── Yes ──→ BS on answer
    │
    ├── "Rotated" + "sorted"? ──── Yes ──→ Rotated BS
    │
    ├── "Matrix" + "sorted"? ──── Yes ──→ Matrix BS
    │
    └── None of above ──→ Consider other patterns
```

</details>

---

## 10-Second Recognition Guide

```
SEE "SORTED"           → Binary Search
SEE "MINIMUM X SUCH"   → BS on answer
SEE "MAXIMUM X SUCH"   → BS on answer
SEE "MIN MAX" / "MAX MIN" → BS on answer
SEE "CAPACITY/SPEED/LIMIT" → BS on answer
SEE "ROTATED"          → Modified BS
SEE "MATRIX" + sorted   → 2D BS
SEE n≤10^5, ans 10^9   → BS on answer
SEE "TWO SUM" sorted    → Two pointers (simpler)
SEE "FIND PAIR"        → Maybe two pointers, not BS
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Binary Search Recognition
INSTANT TRIGGERS:   sorted, first/last position, rotated, matrix
HIDDEN TRIGGERS:    minimum X such that, capacity, speed, days
MIN MAX / MAX MIN:  BS on the inner value
CONSTRAINT CLUE:    n≤10^5 + answer 10^9 → BS on answer
VS TWO POINTERS:    Find value → BS; Find pair → two pointers
COUNT TRICK:        < X: bisect_left; ≤ X: bisect_right
INSERT:             bisect_left = insert position
INTERVIEW LINE:     "I see [min X such that] — the answer space is
                     monotonic. I'll binary search on X."
```
