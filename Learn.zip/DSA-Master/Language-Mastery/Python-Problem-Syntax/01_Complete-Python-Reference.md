# Python Complete Reference — DSA Interview Cheatsheet

> **The go-to reference for Python DSA & FAANG interviews**

---

## 1. list

| Operation | Syntax | Complexity |
|-----------|--------|------------|
| append | `lst.append(x)` | O(1) |
| pop | `lst.pop()` or `lst.pop(i)` | O(1) end, O(n) mid |
| extend | `lst.extend(other)` | O(k) |
| sort | `lst.sort(key=fn, reverse=True)` | O(n log n) |
| sorted | `sorted(lst, key=fn)` | O(n log n) |
| Slicing | `lst[start:end:step]` | O(k) |
| List comp | `[x*2 for x in lst if x>0]` | — |

```python
lst = [3, 1, 4, 1, 5]
lst.append(9)
lst.pop()           # remove last
lst.pop(0)          # O(n)! Use deque for queue
lst.extend([6, 7])
lst.sort()          # in-place
lst.sort(key=lambda x: -x)  # descending
lst.sort(key=lambda x: (x[1], x[0]))  # sort by second, then first

# sorted returns new list
new_lst = sorted(lst, reverse=True)
new_lst = sorted(lst, key=lambda x: abs(x))

# Slicing tricks
lst[::-1]           # reverse
lst[1:4]            # indices 1,2,3
lst[::2]            # every 2nd element
lst[-1]             # last
lst[-2:]            # last 2

# 2D list init
grid = [[0] * m for _ in range(n)]  # NOT [[0]*m]*n (shared refs!)
adj = [[] for _ in range(n)]
```

---

## 2. dict

| Operation | Syntax |
|-----------|--------|
| get | `d.get(key, default)` — no KeyError |
| setdefault | `d.setdefault(key, default)` — insert if missing |
| items | `d.items()` — (k, v) pairs |
| keys | `d.keys()` |
| values | `d.values()` |
| del | `del d[key]` |
| pop | `d.pop(key, default)` |
| Comprehension | `{k: v for k, v in items}` |

```python
d = {}
d[5] = d.get(5, 0) + 1   # frequency count
d.setdefault(5, 0)
d[5] = d.get(5, 0) + 1

for k, v in d.items():
    pass
for k in d:
    pass

d.pop(5)
d.pop(5, None)  # no KeyError if missing

# Dict comprehension
freq = {x: arr.count(x) for x in set(arr)}  # slow, use Counter
```

---

## 3. set

| Operation | Syntax |
|-----------|--------|
| add | `s.add(x)` |
| remove | `s.remove(x)` — KeyError if missing |
| discard | `s.discard(x)` — no error |
| union | `a | b` or `a.union(b)` |
| intersection | `a & b` or `a.intersection(b)` |
| difference | `a - b` or `a.difference(b)` |
| in | `x in s` — O(1) |

```python
s = set()
s.add(5)
if 5 in s:  # O(1)
    s.remove(5)
s.discard(99)  # safe

a | b   # union
a & b   # intersection
a - b   # difference
```

---

## 4. collections module

| Type | Usage |
|------|-------|
| defaultdict | `defaultdict(int)` — auto 0 for missing keys |
| Counter | `Counter(arr)` — frequency dict |
| deque | `deque()` — O(1) append/popleft |
| OrderedDict | Maintains insertion order (dict does in 3.7+) |

```python
from collections import defaultdict, Counter, deque

# defaultdict — no KeyError
freq = defaultdict(int)
for x in arr:
    freq[x] += 1

# Counter — frequency in one line
from collections import Counter
freq = Counter(arr)
freq.most_common(k)   # top k
freq.elements()       # iterator

# deque — use for queue! pop(0) is O(n)
from collections import deque
dq = deque([1, 2, 3])
dq.append(4)
dq.appendleft(0)
dq.pop()
dq.popleft()   # O(1) — use for BFS!
```

---

## 5. heapq

**MIN-heap only!** Negate for max-heap.

| Operation | Syntax |
|-----------|--------|
| heappush | `heapq.heappush(h, x)` |
| heappop | `heapq.heappop(h)` |
| heapify | `heapq.heapify(lst)` — in-place |
| nlargest | `heapq.nlargest(k, lst)` |
| nsmallest | `heapq.nsmallest(k, lst)` |

```python
import heapq

# Min-heap (default)
h = []
heapq.heappush(h, 3)
heapq.heappush(h, 1)
heapq.heappush(h, 4)
heapq.heappop(h)   # 1

# Max-heap: negate values
heapq.heappush(h, -x)
mx = -heapq.heappop(h)

# Heapify existing list
lst = [3, 1, 4, 1, 5]
heapq.heapify(lst)

# k largest/smallest
top_k = heapq.nlargest(k, lst)
bottom_k = heapq.nsmallest(k, lst)

# (priority, item) — sorts by first element
heapq.heappush(h, (dist, node))
d, node = heapq.heappop(h)
```

---

## 6. string

| Operation | Syntax |
|-----------|--------|
| join | `''.join(lst)` |
| split | `s.split()` or `s.split(',')` |
| strip | `s.strip()`, `s.lstrip()`, `s.rstrip()` |
| replace | `s.replace('a', 'b')` |
| isalpha | `s.isalpha()` |
| isdigit | `s.isdigit()` |
| ord/chr | `ord('a')` → 97, `chr(97)` → 'a' |
| f-strings | `f"{x} and {y}"` |

```python
''.join(['a', 'b', 'c'])   # "abc"
'hello world'.split()       # ['hello', 'world']
'  hi  '.strip()            # 'hi'
'a'.replace('a', 'b')

'a'.isalpha()
'5'.isdigit()
ord('a')   # 97
chr(97)    # 'a'

f"Value: {x}, Double: {x*2}"
```

---

## 7. itertools

| Function | Usage |
|----------|-------|
| product | `product(A, B)` — cartesian product |
| combinations | `combinations(lst, k)` |
| permutations | `permutations(lst, k)` |
| accumulate | `accumulate(lst)` — prefix sums |

```python
from itertools import product, combinations, permutations, accumulate

list(product([1,2], ['a','b']))  # [(1,'a'), (1,'b'), (2,'a'), (2,'b')]
list(combinations([1,2,3], 2)) # [(1,2), (1,3), (2,3)]
list(permutations([1,2,3], 2)) # [(1,2), (1,3), (2,1), ...]

# Prefix sum
from itertools import accumulate
list(accumulate([1, 2, 3, 4]))  # [1, 3, 6, 10]
```

---

## 8. bisect

| Function | Usage |
|----------|-------|
| bisect_left | First index where x can be inserted (>= x) |
| bisect_right | First index where x can be inserted (> x) |
| insort | `insort(lst, x)` — insert maintaining sort |

```python
import bisect

lst = [1, 2, 2, 3, 4]
bisect.bisect_left(lst, 2)   # 1 — first >= 2
bisect.bisect_right(lst, 2)  # 3 — first > 2
bisect.insort(lst, 2)       # insert 2, keep sorted
```

---

## 9. functools

| Function | Usage |
|----------|-------|
| lru_cache | Memoization for DP/recursion! |
| reduce | `reduce(fn, lst, init)` |
| cmp_to_key | Custom comparator for sorted |

```python
from functools import lru_cache, reduce, cmp_to_key

# Memoization — use for DP!
@lru_cache(maxsize=None)
def fib(n):
    if n < 2: return n
    return fib(n-1) + fib(n-2)

# With parameters that aren't hashable? Use cache with tuple of hashables
@lru_cache(maxsize=None)
def dp(i, j):
    ...

# reduce
from functools import reduce
reduce(lambda a, b: a + b, [1, 2, 3], 0)  # 6

# cmp_to_key for custom sort (Python 3)
def cmp(a, b):
    return (a > b) - (a < b)
sorted(lst, key=cmp_to_key(cmp))
```

---

## 10. math

| Constant/Function | Usage |
|-------------------|-------|
| inf | `math.inf` — float infinity |
| ceil | `math.ceil(x)` |
| floor | `math.floor(x)` |
| gcd | `math.gcd(a, b)` |
| log2 | `math.log2(x)` |
| sqrt | `math.sqrt(x)` |

```python
import math
float('inf')   # or math.inf
math.ceil(3.2)   # 4
math.floor(3.8)  # 3
math.gcd(12, 8)  # 4
math.log2(8)     # 3.0
math.sqrt(16)     # 4.0
```

---

## 11. Common Tricks

| Pattern | Syntax |
|---------|--------|
| enumerate | `for i, x in enumerate(lst):` |
| zip | `for a, b in zip(lst1, lst2):` |
| reversed | `for x in reversed(lst):` |
| any | `any(x > 5 for x in lst)` |
| all | `all(x > 0 for x in lst)` |
| map | `list(map(int, input().split()))` |
| filter | `list(filter(lambda x: x > 0, lst))` |

```python
for i, x in enumerate(lst):
    print(i, x)

for a, b in zip([1,2], [3,4]):
    print(a, b)  # (1,3), (2,4)

any(x > 5 for x in lst)
all(x > 0 for x in lst)
```

---

## 12. Performance Gotchas

| Gotcha | Fix |
|--------|-----|
| `list.pop(0)` is O(n) | Use `collections.deque` + `popleft()` |
| `x in list` is O(n) | Use `set` for O(1) lookup |
| String concat in loop is O(n²) | Use `''.join(parts)` or list append + join |
| Repeated `lst += [x]` | Use `lst.append(x)` |
| `dict.get` in loop | Use `defaultdict` or `Counter` |

```python
# BAD: O(n) per pop
q = [1, 2, 3]
while q:
    x = q.pop(0)  # O(n)!

# GOOD: O(1)
from collections import deque
q = deque([1, 2, 3])
while q:
    x = q.popleft()  # O(1)

# BAD: O(n²) string building
s = ""
for c in lst:
    s += c

# GOOD: O(n)
s = ''.join(lst)
```

---

## 13. Fast I/O

```python
import sys
input = sys.stdin.readline  # faster than input()
# For interactive, use regular input()

# Read int
n = int(input())

# Read list of ints
arr = list(map(int, input().split()))

# Read multiple lines
lines = sys.stdin.readlines()

# Write — print is slow for many lines
# Use sys.stdout.write or collect and print once
```

---

## 30-SECOND REVISION BOX

```
LIST: append, pop, sort(key=, reverse=), sorted(), [::-1], [[0]*m for _ in range(n)]
DICT: get(k, default), setdefault, items(), pop(k, default)
SET: add, remove, discard, | & -, in O(1)
COLLECTIONS: defaultdict(int), Counter(arr), deque (popleft O(1)!)
HEAPQ: MIN-heap only! heappush/pop, negate for max, (priority, item)
STRING: join, split, strip, ord/chr, f"{x}"
ITERTOOLS: product, combinations, permutations, accumulate
BISECT: bisect_left, bisect_right, insort
FUNCTOOLS: @lru_cache (memo!), reduce, cmp_to_key
MATH: inf, ceil, floor, gcd, log2, sqrt
GOTCHAS: pop(0)=O(n) use deque, 'in' list=O(n) use set, concat use join
FAST IO: sys.stdin.readline, map(int, input().split())
```
