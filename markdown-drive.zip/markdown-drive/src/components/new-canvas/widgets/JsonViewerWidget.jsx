import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNewCanvasStore } from '../state/store';

const MAX_JSON_BYTES = 2 * 1024 * 1024;

function JsonNode({ name, value, depth = 0, expandAll }) {
  const isObject = value !== null && typeof value === 'object';
  if (!isObject) {
    const type = value === null ? 'null' : typeof value;
    return (
      <div className="nc-json__leaf" style={{ paddingLeft: `${depth * 14}px` }}>
        {name != null ? <span className="nc-json__key">{name}: </span> : null}
        <span className={`nc-json__value nc-json__value--${type}`}>
          {typeof value === 'string' ? `"${value}"` : String(value)}
        </span>
      </div>
    );
  }

  const entries = Array.isArray(value)
    ? value.map((item, index) => [index, item])
    : Object.entries(value);
  const opener = Array.isArray(value) ? '[' : '{';
  const closer = Array.isArray(value) ? ']' : '}';

  return (
    <details className="nc-json__branch" open={expandAll || depth < 1}>
      <summary style={{ paddingLeft: `${depth * 14}px` }}>
        {name != null ? <span className="nc-json__key">{name}: </span> : null}
        <span>{opener}</span>
        <span className="nc-json__count">{entries.length} items</span>
      </summary>
      {entries.map(([key, item]) => (
        <JsonNode key={`${depth}-${key}`} name={key} value={item} depth={depth + 1} expandAll={expandAll} />
      ))}
      <div className="nc-json__closer" style={{ paddingLeft: `${depth * 14}px` }}>{closer}</div>
    </details>
  );
}

function JsonViewerWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [source, setSource] = useState(data.source || '');
  const [mode, setMode] = useState(data.mode || 'tree');
  const [expandAll, setExpandAll] = useState(false);
  const saveTimerRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => setSource(data.source || ''), [data.source]);

  const parsed = useMemo(() => {
    if (!source.trim()) return { value: null, error: '' };
    try {
      return { value: JSON.parse(source), error: '' };
    } catch (error) {
      return { value: null, error: error.message };
    }
  }, [source]);

  const update = useCallback((patch) => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id
        ? { ...candidate, widgetData: { ...candidate.widgetData, ...patch } }
        : candidate
    )));
  }, [commitElements, element.id]);

  const updateSource = useCallback((next) => {
    setSource(next);
    window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(() => update({ source: next, fileError: '' }), 300);
  }, [update]);

  useEffect(() => () => window.clearTimeout(saveTimerRef.current), []);

  const loadFile = useCallback(async (file) => {
    if (!file) return;
    if (file.size > MAX_JSON_BYTES) {
      setSource('');
      update({ source: '', fileError: 'JSON files are limited to 2 MB' });
      return;
    }
    const text = await file.text();
    updateSource(text);
    update({ fileName: file.name, fileError: '' });
  }, [update, updateSource]);

  const setViewMode = (nextMode) => {
    setMode(nextMode);
    update({ mode: nextMode });
  };

  const deleteWidget = () => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id ? { ...candidate, isDeleted: true } : candidate
    )));
  };

  return (
    <div
      className="nc-data-widget nc-json"
      style={{
        borderColor: element.style?.stroke || '#475569',
        borderWidth: element.style?.strokeWidth ?? 1,
      }}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        loadFile(event.dataTransfer.files?.[0]);
      }}
    >
      <div className="nc-widget-header nc-data-widget__header" data-nc-drag-handle="1">
        <span className="nc-data-widget__title">JSON Viewer</span>
        <div className="nc-data-widget__actions">
          <button type="button" className={mode === 'tree' ? 'is-active' : ''} onClick={() => setViewMode('tree')}>Tree</button>
          <button type="button" className={mode === 'text' ? 'is-active' : ''} onClick={() => setViewMode('text')}>Text</button>
          <button type="button" onClick={() => fileRef.current?.click()}>Open</button>
          <button
            type="button"
            disabled={!!parsed.error || !source.trim()}
            onClick={() => updateSource(JSON.stringify(parsed.value, null, 2))}
          >
            Format
          </button>
          {mode === 'tree' ? (
            <button type="button" onClick={() => setExpandAll((value) => !value)}>
              {expandAll ? 'Fold' : 'Expand'}
            </button>
          ) : null}
          <button type="button" className="nc-data-widget__close" onClick={deleteWidget} aria-label="Delete JSON viewer">×</button>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept=".json,application/json"
          hidden
          onChange={(event) => loadFile(event.target.files?.[0])}
        />
      </div>
      <div className="nc-data-widget__meta">
        <span>{data.fileName || 'Paste JSON or drop a .json file'}</span>
        <span>{source.length.toLocaleString()} chars</span>
      </div>
      <div className="nc-data-widget__body nc-json__body">
        {mode === 'text' ? (
          <textarea
            className="nc-data-widget__source"
            value={source}
            onChange={(event) => updateSource(event.target.value)}
            placeholder={'{\n  "name": "InkDrop"\n}'}
            aria-label="JSON source"
            spellCheck={false}
          />
        ) : parsed.error || data.fileError ? (
          <div className="nc-data-widget__error">{data.fileError || parsed.error}</div>
        ) : source.trim() ? (
          <div className="nc-json__tree">
            <JsonNode value={parsed.value} expandAll={expandAll} />
          </div>
        ) : (
          <button type="button" className="nc-data-widget__empty" onClick={() => setViewMode('text')}>
            Paste JSON or drop a file here
          </button>
        )}
      </div>
    </div>
  );
}

export default memo(JsonViewerWidgetImpl);
