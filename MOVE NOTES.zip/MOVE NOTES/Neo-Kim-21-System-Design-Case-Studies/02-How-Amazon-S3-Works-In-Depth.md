# How Amazon S3 Works - In Depth (Easy Language)

> Companion to: [02-How-Amazon-S3-Works.md](02-How-Amazon-S3-Works.md)

---

## What Problem Does S3 Solve?

### The "Where Do I Keep All My Stuff?" Problem

Imagine you're running Netflix, and you have:
- 15,000+ movies and shows (each in 6 resolutions)
- Billions of log files
- Millions of user profile images
- Database backups from 50 regions

You need a place to store all this that is:
1. **Never loses data** (11 nines = 99.999999999% durability)
2. **Always available** (you can always access your files)
3. **Infinitely scalable** (no "disk full" errors ever)
4. **Cheap** (petabytes of storage won't bankrupt you)

That's S3. It's the "hard drive of the internet."

**Analogy**: S3 is like a magical storage warehouse that never runs out of space, never loses your packages, and lets you grab anything within milliseconds.

---

## The Big Idea: Metadata and Data Are Separate

This is the #1 architecture insight of S3.

### Think of It Like a Library

```
Library Card Catalog (METADATA):
  "Harry Potter" → Shelf 14, Row 3, Position 7
  "Lord of the Rings" → Shelf 22, Row 1, Position 2

Actual Books on Shelves (DATA):
  Shelf 14, Row 3: [Harry Potter physical book]
  Shelf 22, Row 1: [Lord of the Rings physical book]
```

The card catalog (metadata) tells you WHERE to find things. The actual books (data) sit on shelves. You can upgrade the catalog system without moving any books, and you can add more shelves without changing the catalog structure.

**In S3:**
```
Metadata Store (Key-Value DB + Cache):
  "photos/vacation.jpg" → { disk_42, fragment_7, size: 3.2MB, checksum: abc123 }
  "logs/2024-01-15.gz"  → { disk_99, fragment_3, size: 500MB, checksum: def456 }

Data Store (ShardStore on Hard Disks):
  disk_42, fragment_7: [actual bytes of vacation.jpg]
  disk_99, fragment_3: [actual bytes of log file]
```

**Why separate them?**
- Metadata is **small** and needs **fast lookups** → cache it aggressively in RAM
- Data is **huge** and needs **cheap storage** → store it on hard disks
- Each can **scale independently** -- add more cache servers OR more disks as needed

---

## Why Hard Disks (Not SSDs)?

### The Cost Math

At Amazon's scale (exabytes of data):
- SSD: ~$0.10/GB/month = **$100,000/PB/month**
- HDD: ~$0.02/GB/month = **$20,000/PB/month**

S3 stores hundreds of exabytes. Saving $80,000 per petabyte per month is BILLIONS of dollars per year.

### The HDD Speed Problem

Hard disks have a spinning platter (like a vinyl record) and a moving read/write head (like a record player needle).

```
To read data from an HDD:
  Step 1: HEAD moves to correct track → "Seek time" (5-10ms)
  Step 2: PLATTER rotates to correct spot → "Rotation time" (2-5ms)
  Step 3: Data is read → "Transfer time" (fast if sequential)
  
  Total for one RANDOM read: ~10-15ms
  Total for SEQUENTIAL read: fast (head doesn't need to move)
```

**The problem**: If you have billions of small files being read randomly, the disk head is constantly jumping around. This is SLOW.

**Buying a bigger HDD doesn't help!** A 10TB disk isn't faster than a 1TB disk -- the seek and rotation time is the same. More capacity ≠ more speed.

---

## ShardStore & LSM Trees - How S3 Makes HDDs Fast

### The Core Idea

Since random writes are slow on HDDs, **convert all random writes into sequential writes**. That's what an LSM (Log-Structured Merge) tree does.

### How It Works - Step by Step

**Step 1: Write to RAM first (MemTable)**
```
New file arrives → stored in RAM (MemTable)
  ┌────────────────────┐
  │ MemTable (in RAM)  │
  │ file_a → data      │  ← Writes are INSTANT (microseconds)
  │ file_b → data      │
  │ file_c → data      │
  └────────────────────┘
```

RAM is fast. No disk seeking needed. This is why writes feel instant.

**Step 2: When RAM is full, flush to disk as a sorted file (SSTable)**
```
MemTable is full → write it as a sorted file to disk

  ┌────────────────────┐
  │ SSTable_1 on disk  │
  │ file_a → data      │  ← Written SEQUENTIALLY (fast on HDD!)
  │ file_b → data      │
  │ file_c → data      │
  └────────────────────┘
```

The key insight: writing a sorted file is a SEQUENTIAL operation. The disk head moves in a straight line. This is fast even on HDDs!

**Step 3: Over time, many SSTables accumulate**
```
Level 0 (newest): SSTable_5, SSTable_4, SSTable_3
Level 1:          SSTable_merged_1
Level 2:          SSTable_big_merged_1
```

**Step 4: Compaction (background cleanup)**
```
Periodically, merge smaller SSTables into bigger ones:
  SSTable_1 (file_a, file_c, file_e)
  + 
  SSTable_2 (file_b, file_d, file_f)
  =
  SSTable_merged (file_a, file_b, file_c, file_d, file_e, file_f)
```

Merging two sorted lists = sequential read + sequential write = FAST on HDD.

### How Reads Work

```
Reading file_x:
  1. Check MemTable (RAM)     → found? return it!
  2. Check Level 0 SSTables  → found? return it!
  3. Check Level 1            → found? return it!
  4. Check Level 2            → found? return it!
```

**Problem**: Checking many SSTables sounds slow...

**Solution: Bloom Filters!**

A Bloom filter is a tiny data structure (a few KB) that can tell you:
- "file_x is DEFINITELY NOT in this SSTable" → skip it! (100% sure)
- "file_x MIGHT be in this SSTable" → go check (could be wrong)

```
Before Bloom filters: check 20 SSTables = 20 disk reads = slow
After Bloom filters: check 2-3 SSTables = 2-3 disk reads = fast
```

Bloom filters save massive amounts of unnecessary disk reads.

---

## Parallel Reads - The Speed Multiplier

### The Problem

One HDD can read at ~100 MB/s. If you need to read a 1GB file, that takes 10 seconds. Unacceptable!

### The Solution

Store the file across 10 disks, read from all 10 at the same time:

```
1 GB file split across 10 disks:
  Disk 1: reads 100 MB  ─┐
  Disk 2: reads 100 MB   │
  Disk 3: reads 100 MB   │
  Disk 4: reads 100 MB   │
  Disk 5: reads 100 MB   ├──→ combine all = 1 GB in ~1 second!
  Disk 6: reads 100 MB   │
  Disk 7: reads 100 MB   │
  Disk 8: reads 100 MB   │
  Disk 9: reads 100 MB   │
  Disk 10: reads 100 MB ─┘
```

10 disks reading in parallel = 10x throughput = 1000 MB/s = file read in 1 second.

This also prevents **hot spots**: if one file is very popular, the reads are spread across many disks, so no single disk gets overwhelmed.

---

## Erasure Coding - Smart Replication

### The Problem with Full Replication

If you make 3 copies of everything (like Kafka does):
- 1 PB of data → needs 3 PB of storage
- 3x the cost!

### The Smarter Way: Erasure Coding

Instead of making full copies, split the data into pieces and add "recovery" pieces:

```
Full Replication (3 copies):
  Copy 1: [ABCDEFGH]  ← full copy
  Copy 2: [ABCDEFGH]  ← full copy
  Copy 3: [ABCDEFGH]  ← full copy
  Storage cost: 3x

Erasure Coding (e.g., 8+4 scheme):
  Fragment 1: [AB]  ← data
  Fragment 2: [CD]  ← data
  Fragment 3: [EF]  ← data
  Fragment 4: [GH]  ← data
  Fragment 5: [P1]  ← parity (mathematical recovery data)
  Fragment 6: [P2]  ← parity
  Fragment 7: [P3]  ← parity
  Fragment 8: [P4]  ← parity
  Storage cost: 1.5x (not 3x!)
```

**How recovery works**: If fragments 2 and 5 are lost (disk died), the remaining 6 fragments contain enough mathematical information to **reconstruct** the missing data. This is similar to how RAID works.

**The tradeoff**: Erasure coding uses more CPU (to compute parity and reconstruct), but saves 50% or more on storage costs. At Amazon's scale, this saves billions of dollars.

---

## 11 Nines of Durability - What Does It Mean?

**99.999999999% durability** means:

```
If you store 10 million objects in S3:
  → You can expect to lose 1 object every 10,000 YEARS

In other words:
  → Your files are basically immortal
```

How do they achieve this?
1. **Erasure coding** across many disks in many buildings
2. **Continuous integrity checking** (checksums detect corruption)
3. **Automatic repair** when corruption or disk failure is detected
4. **Cross-AZ replication** (data stored in multiple data centers)

---

## REST API - How You Talk to S3

S3 uses a simple HTTP-based API. Any device that can make web requests can use S3.

```
Upload (PUT):
  PUT /my-bucket/photos/vacation.jpg
  Body: [file bytes]
  → Response: 200 OK

Download (GET):
  GET /my-bucket/photos/vacation.jpg
  → Response: 200 OK + [file bytes]

List files (GET):
  GET /my-bucket?prefix=photos/
  → Response: ["photos/vacation.jpg", "photos/birthday.jpg", ...]

Delete (DELETE):
  DELETE /my-bucket/photos/vacation.jpg
  → Response: 204 No Content
```

### Pre-Signed URLs

Instead of giving someone your AWS credentials, you can generate a temporary URL that works for a limited time:

```
"Anyone with this URL can download vacation.jpg for the next 1 hour"
→ https://my-bucket.s3.amazonaws.com/photos/vacation.jpg?token=abc&expires=3600

After 1 hour: URL stops working
```

This is how YouTube, Spotify, and WhatsApp let users upload/download files without exposing server credentials.

---

## Storage Classes - Pay Less for Old Data

| Storage Class | Use Case | Cost | Access Time |
|--------------|----------|------|-------------|
| **Standard** | Frequently accessed files | $$$ | Milliseconds |
| **Infrequent Access (IA)** | Accessed monthly | $$ | Milliseconds |
| **Glacier Instant** | Accessed quarterly | $ | Milliseconds |
| **Glacier Flexible** | Archives, accessed yearly | ¢ | Minutes to hours |
| **Glacier Deep Archive** | Compliance data, rarely accessed | ¢¢ | 12-48 hours |

**Lifecycle policies** can automatically move data between classes:
```
Day 1-30:   Standard (frequently accessed)
Day 31-90:  Infrequent Access (less accessed)
Day 91-365: Glacier Instant (rarely accessed)
Day 365+:   Glacier Deep Archive (almost never accessed)
```

---

## The Complete Request Flow

```
1. Client sends PUT /bucket/key (upload request)

2. Web Server receives the request
   → Authenticates the client (checks AWS credentials/signature)
   → Validates the request (file size, bucket permissions)

3. Metadata Service creates entry:
   "bucket/key → preparing upload, timestamp, size"

4. File data goes to ShardStore:
   → Written to MemTable (RAM) first
   → Split into fragments using erasure coding
   → Fragments distributed across multiple disks in multiple AZs

5. Metadata Service updates entry:
   "bucket/key → { disk_locations: [d1, d5, d12, d7], 
                    fragments: 8+4, checksum: sha256:abc123 }"

6. Client gets 200 OK (upload successful)

7. Later, when client reads the file:
   → Metadata cache returns disk locations (fast!)
   → Parallel read from multiple disks
   → Fragments reassembled → file returned to client
```

---

## Revision Flashcards

**Q: Why does S3 store metadata separately from file data?**
A: They have different access patterns. Metadata is small and needs fast lookups (→ cache in RAM). File data is huge and needs cheap storage (→ HDDs). Separating them lets each scale independently.

**Q: What is an LSM tree and why does S3 use it?**
A: LSM tree converts random writes into sequential writes by buffering in RAM first, then flushing sorted files to disk. This is perfect for HDDs where sequential I/O is fast and random I/O is slow.

**Q: Why doesn't a bigger hard disk give faster reads?**
A: The seek time (head moving) and rotation time (platter spinning) stay the same regardless of disk size. More capacity just means more data, not faster access.

**Q: What is erasure coding?**
A: Instead of making 3 full copies of data, split it into fragments and add mathematical "parity" fragments. Any subset of fragments can reconstruct the original. Gives same durability at ~1.5x storage instead of 3x.

**Q: What does 11 nines of durability mean?**
A: 99.999999999% chance your data survives. If you store 10 million files, you'd expect to lose ONE file every 10,000 years.

**Q: What is a Bloom filter and how does it help S3?**
A: A tiny memory structure that quickly tells you "this data is DEFINITELY NOT in this file" or "this data MIGHT be in this file." It avoids unnecessary disk reads during lookups, making reads much faster.
