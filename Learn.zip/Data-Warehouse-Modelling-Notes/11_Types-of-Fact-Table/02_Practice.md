# Types of Fact Tables — Practice

> "The grain you choose is the truth you keep."

---

## Quick Recall

**Q: What is a transaction fact table?**  
A: One row per atomic business event (e.g., one line item on an order) with additive measures.

**Q: What is a periodic snapshot fact table?**  
A: One row per entity per reporting period (e.g., daily inventory position per SKU per warehouse).

**Q: What is an accumulating snapshot fact table?**  
A: One row per pipeline instance (e.g., one shipment) with dates and measures updated as milestones occur.

**Q: Why does grain matter for fact table type?**  
A: Grain defines uniqueness; mixing grains breaks additivity and confuses BI rollups.

**Q: Can one subject area use more than one fact table type?**  
A: Yes—e-commerce often has order line facts, daily inventory snapshots, and order fulfillment accumulating snapshots.

---

## Interview Questions

**1. Explain transaction vs periodic snapshot vs accumulating snapshot in retail terms.**  
Say: Transaction facts capture discrete events like `order_line_sold` with quantity and revenue. Periodic snapshots capture state at intervals, such as `inventory_daily` by SKU and location. Accumulating snapshots model processes with known stages—`shipment` rows that gain `picked_at`, `shipped_at`, and `delivered_at` dates as the journey completes.

**2. How do you choose the grain for an order fact in e-commerce?**  
Say: Default to order line grain because promotions, returns, and shipping often apply per line. If the business only reports order totals, order-level grain is valid but you lose line-level analysis; document the trade-off.

**3. Why might daily inventory be a snapshot instead of summing stock movements?**  
Say: Stock on hand is a balance, not a simple sum of all movements when timing, adjustments, and shrink exist. A periodic snapshot aligns with how finance and merchandising read inventory.

**4. What measures belong on an accumulating snapshot for fulfillment?**  
Say: Lag days between milestones, counts of exceptions, and possibly dollar impact of delays—plus degenerate keys like `tracking_number`. Avoid duplicating line-level revenue; link to transaction facts.

**5. How do you load accumulating snapshots incrementally?**  
Say: Upsert on the natural pipeline key; update milestone dates and measures when source systems report new statuses; use late-arriving fact handling if events post out of order.

**6. What is a common mistake when modeling returns?**  
Say: Treating returns as negative rows on the sales fact without a consistent grain or return reason dimension, which breaks margin analysis—often model returns as separate facts or aligned adjustments.

**7. How do you test that a snapshot fact is correct?**  
Say: Reconcile end-of-day balances to source inventory tables, spot-check high-velocity SKUs, and verify no duplicate (date, SKU, location) keys.

---

## Scenario-Based Exercises

**Scenario 1 — Classify the fact**  
You have one row per `order_id` with `order_total` and `order_date`. Is this transaction or snapshot?  
**Solution:** Transaction-style event at order grain, but not order-line grain. If the business needs SKU-level metrics, redesign to `fact_order_line` with `product_key` and `quantity`.

**Scenario 2 — Daily inventory**  
Build a logical model for `fact_inventory_daily` for a multi-warehouse retailer.  
**Solution:** Grain: `(date_key, warehouse_key, product_key)`. Measures: `units_on_hand`, `units_available`, `inventory_value`. Dimensions: date, warehouse, product, possibly `stock_status`.

**Scenario 3 — SQL sketch for snapshot load**  
Load yesterday’s inventory from a staging table.

```sql
INSERT INTO dw.fact_inventory_daily (
    date_key, warehouse_key, product_key, units_on_hand, inventory_value
)
SELECT
    TO_CHAR(s.snapshot_date, 'YYYYMMDD')::INT AS date_key,
    w.warehouse_key,
    p.product_key,
    s.qty_on_hand,
    s.qty_on_hand * COALESCE(p.unit_cost, 0) AS inventory_value
FROM stg.inventory_daily s
JOIN dw.dim_warehouse w ON s.warehouse_code = w.warehouse_code
JOIN dw.dim_product p ON s.sku = p.sku
WHERE s.snapshot_date = CURRENT_DATE - 1;
```

**Scenario 4 — Accumulating snapshot**  
Model `fact_shipment` from pick to delivery.  
**Solution:** Grain: `shipment_id`. Role-playing date keys: `order_date_key`, `pick_date_key`, `ship_date_key`, `delivery_date_key`. Measures: `pick_to_ship_hours`, `ship_to_delivery_hours`. Conformed `dim_customer` and `dim_warehouse`.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Calling any large table a "fact" | Confuses header/detail with events | State grain and business process explicitly |
| Putting balances on transaction facts | Double-counting when summing | Use snapshots or semi-additive logic |
| One mega-fact for orders + inventory | Mixed grains break reports | Separate facts, conformed dimensions |
| Ignoring late-arriving shipments | Wrong dwell times | Type 2 dates or bridge patterns as needed |

---

## One-Liner Answers

- Transaction facts: one row per business event at the declared grain.
- Periodic snapshots: one row per entity per time bucket for balances or levels.
- Accumulating snapshots: one row per pipeline with evolving milestone dates.
- Grain is the definition of a single fact row—never ambiguous in design reviews.
- Choose fact types from how the business measures the process, not from source table shapes.
- Test snapshots against source-of-truth balances, not only row counts.
