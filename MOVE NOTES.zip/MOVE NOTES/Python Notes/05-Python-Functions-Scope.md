# Python Functions, Scope, and Decorator Basics

> *"LEGB — Local, Enclosing, Global, Built-in"* — Name resolution order

Functions are the soul of Python — first-class objects, `*args`/`**kwargs`, closures, and decorators. This file is the bridge after [[04-Python-Loops-Comprehensions]]; deeper decorator internals are in [[16-Python-Advanced-Topics]].

---

## 1. Function definition — `def`

> **Definition:** A function is a named callable block: parameters receive arguments from the caller, the body runs, and `return` optionally sends a value back (otherwise `None`).

**Why we need it:** Reuse, abstraction, and testing—one place to fix behavior; `def` keeps callable logic first-class in the language.

**Syntax:**
```python
def <name>(<parameters>):
    """<docstring>."""
    <body>
    return <expression>  # optional
```

```python
def greet(name: str) -> str:   # Defines a function called "greet" that takes a name
    return f"Hello, {name}"    # Returns a greeting string back to the caller

print(greet("Anita"))  # Calls the function → prints "Hello, Anita"
```

- `def` = keyword to **create** a function
- `return` = sends a value back to whoever called the function (optional — default `None`)
- Docstring recommended — triple quotes as the first statement

---

## 2. Default arguments

> **Definition:** Default arguments give parameters a value that is used when the caller omits that argument at call time.

**Why we need it:** APIs stay backward compatible and ergonomic—optional knobs do not require extra functions or sentinels at every call site.

**Syntax:**
```python
def <name>(<required>, <param>=<default_expr>, ...):
    ...
```

```python
def power(base, exp=2):   # exp has a DEFAULT value of 2
    return base ** exp

power(3)      # 9  → uses default exp=2, so 3² = 9
power(3, 3)   # 27 → overrides default, so 3³ = 27
```

**Watch Out!** **Never** use a mutable default — classic gotcha:

```python
# WRONG
def add_item(x, items=[]):
    items.append(x)
    return items

# RIGHT
def add_item(x, items=None):
    if items is None:
        items = []
    items.append(x)
    return items
```

**Interview Tip:** Default args are evaluated **once** at **function definition** time — shared list trap. Detail in [[17-Python-FAANG-Interview-Must-Know]].

---

## 3. `*args` and `**kwargs`

> **Definition:** In a definition, `*args` gathers extra positional arguments into a tuple and `**kwargs` gathers extra keyword arguments into a dict; at the call site, `*` / `**` unpack sequences and mappings into arguments.

**Why we need it:** Wrappers, decorators, and variadic APIs can forward arbitrary arguments without fixing arity or keyword names in advance.

**Syntax:**
```python
def <name>(<fixed>, *args, **kwargs):
    ...

<callable>(*<positional_iterable>, **<keyword_mapping>)
```

```python
def summation(*args):       # *args collects ANY NUMBER of values into a tuple
    return sum(args)

summation(1, 2, 3)  # 6 → args = (1, 2, 3), sum gives 6

def profile(**kwargs):      # **kwargs collects keyword arguments into a dictionary
    return kwargs

profile(name="A", city="Mumbai")  # → {"name": "A", "city": "Mumbai"}

def everything(a, *args, k=1, **kwargs):
    return a, args, k, kwargs
# everything(1, 2, 3, k=5, x=10) → (1, (2,3), 5, {"x":10})
```

| Parameter | What it does |
|-----------|----------|
| `*args` | Collects extra positional arguments as a **tuple** (any number of values) |
| `**kwargs` | Collects extra keyword arguments as a **dict** (name=value pairs) |

Unpacking at the call site:

```python
def f(a, b, c):
    return a + b + c

f(*[1, 2, 3])                     # * UNPACKS list → f(1, 2, 3) → 6
f(**{"a": 1, "b": 2, "c": 3})    # ** UNPACKS dict → f(a=1, b=2, c=3) → 6
```

---

## 4. Lambda — anonymous function

> **Definition:** A lambda expression builds a small anonymous function object whose body must be a single expression evaluated and returned.

**Why we need it:** Throwaway one-liners (e.g. `key=` for `sorted`) stay inline without a full `def` when the logic is truly trivial.

**Syntax:**
```python
lambda <parameters>: <expression>
```

```python
square = lambda x: x * x         # Creates a small unnamed function: takes x, returns x*x
square(5)                         # 25

sorted(names, key=lambda s: len(s))  # Sorts names by their LENGTH (shortest first)
# lambda = quick throwaway function for simple one-line operations
```

**Watch Out!** For complex logic prefer `def` — lambdas are **single expression** only.

---

## 5. Scope — `global` and `nonlocal`

> **Definition:** Scope determines where a name resolves; Python searches **L**ocal, then **E**nclosing functions, then **G**lobal module, then **B**uilt-ins (LEGB). `global` and `nonlocal` mark which outer binding an assignment should update.

**Why we need it:** Nested functions and modules stay predictable; explicit keywords avoid accidentally creating a new local when you meant to mutate outer state.

**Syntax:**
```python
global <name>
nonlocal <name>
```

### LEGB order

1. **L**ocal — inside the function
2. **E**nclosing — outer functions
3. **G**lobal — module level
4. **B**uilt-in — `len`, `print`, etc.

```python
count = 0  # Global variable — lives outside any function

def inc():
    global count   # Tells Python: "I want to CHANGE the global count, not make a local one"
    count += 1     # Now modifies the global count
```

```python
def outer():
    x = 10             # x belongs to outer function
    def inner():
        nonlocal x     # Tells Python: "I want to change x from the outer function"
        x += 1         # Changes outer's x from 10 to 11
    inner()
    return x           # Returns 11
```

**Interview Tip:** Assign before read → **local** unless you use `global`/`nonlocal`.

---

## 6. Closures

> **Definition:** A closure is a function that remembers bindings from the enclosing lexical scope that existed when the function object was created, even after the outer call returns.

**Why we need it:** Factories, callbacks, and decorators can carry configuration and state without globals or bulky classes for simple cases.

**Syntax:**
```python
def <outer>(<captured>):
    def <inner>(<args>):
        return <expr_using_captured>
    return <inner>
```

An inner function can **capture** variables from the outer scope:

```python
def make_multiplier(n):   # Outer function takes n
    def mul(x):           # Inner function "remembers" n even after outer finishes
        return x * n
    return mul            # Returns the inner function

double = make_multiplier(2)  # double now "remembers" n=2
double(5)  # 10 → 5 * 2 = 10 (n is captured/remembered from when it was created)
```

**Watch Out!** Loop variable closure bug:

```python
funcs = [lambda: i for i in range(3)]  # all return i=2 (late binding)
funcs_fixed = [lambda i=i: i for i in range(3)]
```

---

## 7. Decorators — basics

> **Definition:** A decorator is a callable that accepts another callable (usually a function) and returns a replacement—often a wrapper—so callers keep the same name but get extra behavior.

**Why we need it:** Cross-cutting concerns (logging, timing, access control) attach in one place instead of duplicating boilerplate at every definition.

**Syntax:**
```python
@<decorator_callable>
def <name>(...):
    ...

# Desugars to: <name> = <decorator_callable>(<name>)
```

**Wrapping** a function — same name, enhanced behavior:

```python
def log_calls(fn):                  # Decorator: takes a function as input
    def wrapper(*args, **kwargs):   # Creates a new function that wraps the original
        print("calling", fn.__name__)   # Adds extra behavior (prints function name)
        return fn(*args, **kwargs)      # Then calls the original function
    return wrapper                  # Returns the enhanced version

@log_calls          # @ syntax = "wrap add with log_calls"
def add(a, b):
    return a + b

# Now calling add(1, 2) first prints "calling add", then returns 3
```

Equivalent: `add = log_calls(add)` — the decorator is just a shortcut for this

**Interview Tip:** `@wraps(fn)` from `functools` — preserves metadata; [[14-Python-Functional-Programming]].

---

## 8. Inner functions + return

```python
def choose(mode):
    if mode == "add":
        def op(a, b): return a + b
    else:
        def op(a, b): return a * b
    return op
```

---

## 9. Keyword-only and positional-only (3.8+ preview)

```python
def f(a, /, b, *, c):
    return a, b, c

# f(1, 2, c=3)  OK
# f(a=1, ...)   Error — a positional-only
```

**Interview Tip:** API design — lock internal params, keep kwargs clean.

---

## 10. Annotated signatures — runtime behavior

```python
def add(a: int, b: int) -> int:
    return a + b

add("x", "y")  # runs! — hints are not enforced by default
```

Type checking — `mypy` / IDE. Detail [[16-Python-Advanced-Topics]].

---

## 11. First-class functions — higher order

```python
def apply_twice(f, x):
    return f(f(x))

apply_twice(lambda z: z + 1, 0)  # 2
```

Decorators stand on this idea.

---

## Quick Memory Card

```
+------------------------------------------+
| DEF / RETURN                              |
| - return optional → None                 |
+------------------------------------------+
| *args **kwargs                            |
| - extra pos / kw collected               |
| - call: f(*lst, **dct)                  |
+------------------------------------------+
| DEFAULT ARGS                              |
| - don't use mutable default              |
+------------------------------------------+
| SCOPE                                     |
| - LEGB                                   |
| - global / nonlocal for assignment       |
+------------------------------------------+
| CLOSURE                                   |
| - outer vars captured                    |
| - loop + lambda → default arg trick      |
+------------------------------------------+
| DECORATOR                                 |
| - @decorator syntactic sugar             |
+------------------------------------------+
```

---

*Next: [[06-Python-Strings-Collections]]*
