# Dynamic Programming — Interview Thinking

> **Permanent Recall:** FAANG interviewers want to hear: "I define dp[i] as... The recurrence is... Base case is..." State → Transition → Base Case. Communicate clearly. Default to bottom-up. Space optimization is the #1 follow-up.

---

## How FAANG Interviewers Expect You to Reason

### The Verbal Framework (Say This Out Loud)

```
1. "I'll define dp[i] as [precise meaning]."
2. "At each step, I can [choice 1] or [choice 2]."
3. "So the recurrence is dp[i] = [formula]."
4. "Base case: dp[0] = [value] because [reason]."
5. "I'll fill the table [direction] so dependencies are ready."
```

**Why this works:** Shows structured thinking. Interviewer can correct you early if state is wrong.

---

## State → Transition → Base Case Framework

| Step | What to Do | Example (House Robber) |
|------|------------|-------------------------|
| **State** | Define minimal info to identify subproblem | `dp[i] = max money from houses 0..i` |
| **Transition** | How does state evolve from choices? | `dp[i] = max(rob i, skip i)` → `max(nums[i]+dp[i-2], dp[i-1])` |
| **Base Case** | Trivial subproblems; no recurrence needed | `dp[0]=nums[0]`, `dp[1]=max(nums[0],nums[1])` |

```
INTERVIEW FLOW:
  State definition  →  "What does dp[i] mean?"
  Transition       →  "What choices? What changes?"
  Base case        →  "What's the smallest problem?"
  Fill order       →  "Left-to-right? Diagonal?"
```

---

## How to Communicate: "I Define dp[i] As..."

### Good State Descriptions (Say These)

| Problem | Good Phrasing |
|---------|---------------|
| Climbing Stairs | "dp[i] = number of distinct ways to reach step i" |
| House Robber | "dp[i] = maximum money from first i houses, considering we can't rob adjacent" |
| 0/1 Knapsack | "dp[i][w] = max value using items 0..i with capacity w" |
| LCS | "dp[i][j] = length of LCS of s1[0..i-1] and s2[0..j-1]" |
| Edit Distance | "dp[i][j] = min operations to transform s1[0..i-1] into s2[0..j-1]" |

### Bad State Descriptions (Avoid)

- "dp[i] is the answer" — too vague
- "dp[i][j][k] for everything" — over-dimensioned
- Skipping the definition and jumping to code — interviewer gets lost

---

## Top-Down vs Bottom-Up: Which in Interview?

| Approach | When to Use | Pros | Cons |
|----------|-------------|------|------|
| **Bottom-Up** | **Default choice** | No stack overflow, space-optimizable, interviewer expects it | Slightly less intuitive for some |
| **Top-Down** | Natural recurrence, sparse table | Easier to derive from recurrence | Stack depth risk, harder to space-optimize |

```
INTERVIEW STRATEGY:
  Start: "I'll use bottom-up tabulation — it's more space-efficient and avoids recursion depth."
  If stuck: "Alternatively, I could do top-down with memoization — same recurrence, different fill order."
```

**Rule:** Unless the problem screams "memoization" (e.g., tree DP, sparse states), go bottom-up.

---

## "Can You Optimize Space?" Follow-Up Strategy

### Recognition: When Space Optimization Applies

```
dp[i] depends ONLY on dp[i-1] (or dp[i-2], etc.)
  → Use 2–3 variables or a small rolling array

2D dp[i][j] depends ONLY on row i-1
  → Use 2 rows: prev and curr; swap each iteration

Knapsack: dp[i][w] depends on dp[i-1][*]
  → Use 1D array; fill w in REVERSE (W down to 0)
```

### Verbal Response Template

1. "Currently we use O(n×W) space for the full table."
2. "Since dp[i] only depends on dp[i-1], we only need the previous row."
3. "We can use a single 1D array and fill right-to-left so we don't overwrite values we still need."
4. "That reduces space to O(W)."

---

## Common Follow-Up Questions and Answers

| Follow-Up | Answer (Concise) |
|-----------|------------------|
| **"Can you optimize space?"** | "Yes. dp[i] depends only on dp[i-1]. Use rolling array / 2 variables. For knapsack, fill capacity in reverse." |
| **"What if we need to reconstruct the solution?"** | "Store parent/choice at each state. Backtrack from dp[n][W] following choices." |
| **"What's the time/space complexity?"** | "Time O(n×W), space O(n×W). With optimization, space O(W)." |
| **"Why not greedy?"** | "Greedy fails — e.g., knapsack: taking max value/weight ratio doesn't guarantee optimal. We need to try all subsets." |
| **"Can you do it with recursion?"** | "Yes, top-down with memoization. Same recurrence, lazy evaluation. O(n) stack depth risk for large n." |
| **"What about negative values?"** | "Knapsack: need offset or different formulation. Coin change: -1 for impossible; handle overflow." |

---

## ASCII: Interview Communication Flow

```
INTERVIEWER: "Solve [problem]"
     |
     v
YOU: "I'll use DP. State: dp[i] = [meaning]"
     |
     v
YOU: "Transition: at each step I [choices] → dp[i] = [formula]"
     |
     v
YOU: "Base: dp[0]=X, dp[1]=Y"
     |
     v
YOU: "Fill order: left to right. Code: [implement]"
     |
     v
INTERVIEWER: "Optimize space?"
     |
     v
YOU: "dp[i] depends on dp[i-1] only → 2 variables / reverse fill"
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
VERBAL FRAMEWORK:  "dp[i] = ..." → "Transition: ..." → "Base: ..."
STATE FIRST:       Define before recurrence; be precise
DEFAULT:           Bottom-up tabulation in interview
SPACE OPT:         Rolling array when row i needs only row i-1
KNAPSACK OPT:      Reverse fill (W→0) to avoid overwrite
FOLLOW-UPS:        Space opt, reconstruct, complexity, why not greedy
```

---

## 30-SECOND REVISION BOX

```
□ State: "dp[i] = [exact meaning]"
□ Transition: choices → formula
□ Base case: trivial subproblems
□ Bottom-up default; top-down if sparse
□ Space opt: rolling array, reverse fill for knapsack
□ Rehearse: "Can you optimize space?" → "Yes, dp[i] depends only on dp[i-1]"
```
