# Data Warehouse Internals — Practice

> "Internals are the difference between guessing why a query is slow and fixing it with intent."

---

## Quick Recall

**Q:** What is columnar storage and why does it help retail fact tables?  
**A:** Data is stored by column; analytical queries that sum few columns scan less I/O than row-oriented layouts.

**Q:** What is partitioning in a `fact_sales` context?  
**A:** Physically grouping rows (often by `order_date`) so queries prune irrelevant time ranges.

**Q:** What is clustering or sorting on a dimension key?  
**A:** Co-locating rows with the same `product_key` to speed filters and joins on large facts.

**Q:** What is a massively parallel processing (MPP) architecture?  
**A:** Query work is split across nodes that scan local slices of data in parallel.

**Q:** What is a result cache or warehouse cache?  
**A:** Engine-level reuse of recent query results or compiled plans to reduce repeated BI traffic cost.

---

## Interview Questions

**1. Explain how a columnar warehouse executes `SUM(amount) WHERE order_date = today`.**  
**Model answer:** The engine reads only the `amount` and `order_date` column stripes for relevant partitions, skipping other columns. Nodes scan in parallel, partial aggregates are combined, and the result returns with minimal I/O compared to reading full rows. Retail dashboards that sum dollars benefit enormously from this pattern.

**2. Why do small dimension tables not need the same physical tuning as huge facts?**  
**Model answer:** Dimensions are often broadcast or cached in joins because they fit in memory; the bottleneck is usually the billion-row fact scan, not the million-row product table. Still, very wide dimensions can cause shuffle pressure if misused.

**3. What is micro-partitioning (conceptually)?**  
**Model answer:** Automatic fine-grained physical groups (vendor-specific) that improve pruning when predicates align with load order—useful for daily retail loads. I explain it as many small files behind the scenes with metadata for skipping.

**4. How do you think about compression?**  
**Model answer:** Columnar storage compresses well when values repeat—category codes and dates compress strongly, which lowers storage cost and speeds scans. High-cardinality UUID keys compress poorly; surrogate integers help indirectly.

**5. What is spilling to disk during a query?**  
**Model answer:** When memory is insufficient for sorts or joins, intermediate results write to temp storage, slowing the query—signals to adjust warehouse size, rewrite SQL, or pre-aggregate. During peak reporting, spill events are a leading indicator of undersized warehouses.

**6. How does clustering interact with incremental loads?**  
**Model answer:** New daily partitions may be unsorted until a maintenance merge or auto-clustering job runs; I monitor join performance after large loads. For marketplaces with bursty sellers, skew checks matter after backfills.

**7. What is Z-ordering in simple terms?**  
**Model answer:** A multi-dimensional sort strategy so queries filtering on combinations like `order_date` and `warehouse_id` both benefit from locality. Useful when retail queries rarely filter on only one dimension.

**8. How do you diagnose a query that regressed after a model change?**  
**Model answer:** Compare plans for partition pruning, join order, spill, and broadcast vs shuffle. Validate that predicates remain sargable and that a new dimension join did not explode cardinality for marketplace line items.

---

## Scenario-Based Exercises

**Scenario 1 — Black Friday dashboard timeouts**  
`fact_sales_line` has billions of rows; filters on `order_date` and `sku`.  
**Solution:** Partition by `order_date`; cluster or sort by `product_key` (or `sku` surrogate); ensure BI queries avoid functions on partitioned columns. Add a pre-aggregated daily SKU table if the same slice is queried thousands of times per hour.

**Scenario 2 — Join explosion**  
Analyst joins `fact_sales` to a slowly changing `dim_customer` incorrectly and doubles revenue.  
**Solution:** Join on surrogate key and correct effective dates, or use the fact's `customer_key` as loaded historically—not current customer attributes without intent. Train analysts on role-playing date joins.

**Scenario 3 — Explain plan shows full table scan**  
Predicate is `WHERE UPPER(channel) = 'WEB'`.  
**Solution:** Push normalization upstream; store a clean `channel_code`; avoid non-sargable functions on filtered columns. Fix in staging, not only in BI.

```sql
SELECT warehouse_id, SUM(shipped_units) AS units
FROM dw.fact_shipments
WHERE ship_date BETWEEN DATE '2025-11-20' AND DATE '2025-11-30'
GROUP BY warehouse_id;
```

**Scenario 4 — Warehouse credit burn and small files**  
Repeated identical BI queries: enable result caching where supported and materialized views for hot aggregates like daily GMV by channel; coordinate with BI teams to reduce per-dashboard query fan-out. If frequent micro-batches create small files, schedule compaction or use merge features and align batch size with partition strategy so metadata does not explode.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| "More nodes always faster" | Amdahl's law and skew | Mention data skew and broadcast vs shuffle |
| Partition = index from OLTP | Different semantics | Explain partition pruning and maintenance |
| Ignoring small file problem | Lake-adjacent loads | Describe compaction and merge strategies |
| Clustering every column | No locality benefit | Pick 1-2 high-selectivity join/filter keys |
| Blindly widening dimensions | Memory pressure | Keep facts narrow; resist dumping text blobs |
| Tuning without measuring | Wastes time | Name specific plan artifacts you inspect |

---

## One-Liner Answers

- Columnar engines read only the columns your query needs, which speeds typical retail aggregations.
- Partitioning limits scans to relevant date ranges for order and shipment facts.
- MPP splits work across nodes; skewed keys can bottleneck one hot partition.
- Compression reduces cost and I/O because retail keys and codes repeat often.
- Spilling indicates the query needs more memory, fewer rows, or a better plan.
- Avoid wrapping partitioned columns in functions so the optimizer can prune.
