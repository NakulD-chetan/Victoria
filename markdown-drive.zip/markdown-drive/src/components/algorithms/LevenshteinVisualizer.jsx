import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const A = 'kitten';
const B = 'sitting';

function generateSteps() {
  const steps = [];
  const m = A.length;
  const n = B.length;
  const dp = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  steps.push({
    type: 'init',
    msg: 'Base cases: row 0 and column 0',
    dp: dp.map((r) => [...r]),
    path: [],
    ci: -1,
    cj: -1,
  });
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      steps.push({
        type: 'cell',
        msg: `Compute dp[${i}][${j}] (${A[i - 1]} vs ${B[j - 1]})`,
        dp: dp.map((r) => [...r]),
        ci: i,
        cj: j,
        path: [[i, j]],
      });
      const cost = A[i - 1] === B[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
      steps.push({
        type: 'set',
        msg: `dp[${i}][${j}] = ${dp[i][j]}`,
        dp: dp.map((r) => [...r]),
        ci: i,
        cj: j,
        path: [[i, j]],
      });
    }
  }
  steps.push({
    type: 'done',
    msg: `Edit distance = ${dp[m][n]}`,
    dp: dp.map((r) => [...r]),
    ci: m,
    cj: n,
    path: [],
  });
  return steps;
}

function paintGrid(step) {
  const rows = A.length + 1;
  const cols = B.length + 1;
  const dp = step.dp;
  const cellValues = {};
  const cellColors = {};
  cellValues['0-0'] = '∅';
  for (let j = 1; j < cols; j++) cellValues[`0-${j}`] = B[j - 1];
  for (let i = 1; i < rows; i++) cellValues[`${i}-0`] = A[i - 1];
  for (let i = 0; i < rows; i++) {
    for (let j = 0; j < cols; j++) {
      const key = `${i}-${j}`;
      if (i > 0 && j > 0) cellValues[key] = String(dp[i][j]);
      else if (i === 0 && j > 0) cellValues[key] = `${B[j - 1]}\n${dp[i][j]}`;
      else if (j === 0 && i > 0) cellValues[key] = `${A[i - 1]}\n${dp[i][j]}`;
      else cellValues[key] = String(dp[i][j]);
      if (step.ci === i && step.cj === j) cellColors[key] = 'exploring';
      else if (i === 0 || j === 0) cellColors[key] = 'path';
      else cellColors[key] = 'empty';
    }
  }
  return {
    size: rows,
    cols,
    grid: Array.from({ length: rows }, () => Array(cols).fill('empty')),
    cellColors,
    cellValues,
    path: step.path || [],
  };
}

export default function LevenshteinVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `"${A}" → "${B}"` });
    canvasRef.current?.setState(paintGrid(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'cell') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paintGrid(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
