import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const S = 'ABACABA';

function computeZSteps(str) {
  const steps = [];
  const n = str.length;
  const Z = Array(n).fill(0);
  steps.push({ type: 'init', msg: 'Z[0] = n (implicit)', str, i: 0, l: 0, r: -1, Z: [...Z] });
  let l = 0;
  let r = -1;
  for (let i = 1; i < n; i++) {
    steps.push({ type: 'box', msg: `Compute Z[${i}]`, str, i, l, r, Z: [...Z], inBox: i <= r });
    if (i <= r) {
      const k = i - l;
      steps.push({
        type: 'copy',
        msg: `Inside Z-box [${l},${r}] → start from Z[${k}]`,
        str,
        i,
        l,
        r,
        k,
        Z: [...Z],
      });
      Z[i] = Math.min(r - i + 1, Z[k]);
    }
    let j = Z[i];
    steps.push({ type: 'expand', msg: `Compare S[${j}] vs S[${i + j}]`, str, i, j, l, r, Z: [...Z] });
    while (i + j < n && str[j] === str[i + j]) {
      steps.push({
        type: 'eq',
        msg: `S[${j}] == S[${i + j}]`,
        str,
        i,
        j,
        l,
        r,
        Z: [...Z],
      });
      j += 1;
    }
    Z[i] = j;
    steps.push({ type: 'setz', msg: `Z[${i}] = ${j}`, str, i, j, l, r, Z: [...Z] });
    if (i + j - 1 > r) {
      l = i;
      r = i + j - 1;
      steps.push({ type: 'newbox', msg: `Extend Z-box → [${l}, ${r}]`, str, i, j, l, r, Z: [...Z] });
    }
  }
  steps.push({ type: 'done', msg: 'Z-array complete', str, i: n - 1, l, r, Z: [...Z] });
  return steps;
}

function paint(step) {
  const str = step.str;
  const Z = step.Z || [];
  const i0 = step.i ?? 0;
  const patArr = i0 < str.length ? str.slice(i0).split('') : str.split('');
  const textColors = {};
  const patternColors = {};
  const comparePairs = [];
  if (step.type === 'expand' || step.type === 'eq') {
    const i = step.i;
    const j = step.j ?? 0;
    if (j < str.length) textColors[j] = 'current';
    if (j < patArr.length) patternColors[j] = str[j] === str[i + j] ? 'match' : 'mismatch';
    comparePairs.push([j, j]);
  }
  if (step.type === 'box' || step.type === 'copy' || step.type === 'newbox') {
    if (step.l != null && step.r != null) {
      for (let t = step.l; t <= Math.min(step.r, str.length - 1); t++) textColors[t] = 'found';
    }
    if (step.i != null) textColors[step.i] = 'current';
  }
  if (step.type === 'setz' && step.i != null) textColors[step.i] = 'match';
  return {
    text: str.split(''),
    pattern: patArr,
    textColors,
    patternColors,
    offset: i0,
    table: Z,
    tableLabel: 'Z values',
    matchPositions: [],
    comparePairs: comparePairs.length ? comparePairs : null,
  };
}

export default function ZAlgorithmVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = computeZSteps(S);
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Z-algorithm on "${S}"` });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'expand' || step.type === 'eq') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
