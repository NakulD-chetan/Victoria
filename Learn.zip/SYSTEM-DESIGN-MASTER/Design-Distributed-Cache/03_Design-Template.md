# Design Distributed Cache — Design Template

> **Permanent Recall:** Architecture = **Client** (with consistent hashing) → **Cache nodes** (in-memory hash tables + eviction). Ring for distribution, primary-replica for HA, LRU = hash map + doubly-linked list for O(1) eviction. Persistence: RDB (snapshot) / AOF (log). Data structures: skip list for sorted sets. Redis is the reference implementation.

---

## High-Level Architecture (ASCII)

```
                         ┌─────────────────────────────────────┐
                         │         Client Library               │
                         │  • Consistent hashing ring           │
                         │  • Route by key → node               │
                         │  • Connection pooling                │
                         └──────────────────┬──────────────────┘
                                            │
                    ┌───────────────────────┼───────────────────────┐
                    │                       │                       │
                    ▼                       ▼                       ▼
          ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
          │   Cache Node 1   │    │   Cache Node 2   │    │   Cache Node 3   │
          │  ┌─────────────┐ │    │  ┌─────────────┐ │    │  ┌─────────────┐ │
          │  │ Hash Table  │ │    │  │ Hash Table  │ │    │  │ Hash Table  │ │
          │  │ key → value │ │    │  │ key → value │ │    │  │ key → value │ │
          │  └─────────────┘ │    │  └─────────────┘ │    │  └─────────────┘ │
          │  ┌─────────────┐ │    │  ┌─────────────┐ │    │  ┌─────────────┐ │
          │  │ LRU list    │ │    │  │ LRU list    │ │    │  │ LRU list    │ │
          │  │ (eviction)  │ │    │  │ (eviction)  │ │    │  │ (eviction)  │ │
          │  └─────────────┘ │    │  └─────────────┘ │    │  └─────────────┘ │
          │  Replica 1a      │    │  Replica 2a      │    │  Replica 3a      │
          └────────┬────────┘    └────────┬────────┘    └────────┬────────┘
                   │                      │                      │
                   └──────────────────────┼──────────────────────┘
                                          │
                              ┌───────────┴───────────┐
                              │   Consistent Hashing  │
                              │   Ring (0 .. 2^32)    │
                              │   Virtual nodes per   │
                              │   physical node       │
                              └───────────────────────┘
```

---

## Consistent Hashing — Deep Dive

```
                    Ring (hash space 0 .. 2^32-1)
                              0
                         ╭─────────╮
                    V1b  │         │  V1a
                    ●───┤   N1    ├───●
                        │         │
                   V3a  │         │  V2a
                    ●───┤   N3    │   ●─── N2
                        │         │
                    V3b ●         ● V2b
                         ╰─────────╯

  • Each physical node has multiple "virtual nodes" (V1a, V1b, ...)
  • hash(key) → point on ring → walk clockwise → first node wins
  • Virtual nodes → more even distribution (avoid hot spots)
  • Node failure: only keys in [failed_node, next_node) move
```

**Virtual nodes:** 100–200 per physical node typical. More = smoother distribution, more metadata.

---

## Replication Model

```
Primary                    Replica(s)
   │                           │
   │  SET k1 v1  ───────────►  │  (async replication)
   │  SET k2 v2  ───────────►  │
   │  (write)                  │  (read scaling possible)
   │                           │
   │  FAIL  ─────────────────► │  Promote to primary
   │  (node down)               │  Clients redirect
```

| Aspect | Choice |
|--------|--------|
| **Topology** | Primary-replica; replica holds full copy of primary's shard |
| **Replication** | Async (primary responds before replica ack) for low latency |
| **Failover** | Sentinel/controller detects failure; promotes replica; clients get new topology |
| **Split-brain** | Quorum or leader election; prevent two primaries |

---

## Eviction: LRU Implementation (O(1))

```
Hash Map:  key → (value, list_node_ptr)
Doubly-Linked List:  [MRU] ←→ [x] ←→ [y] ←→ [LRU]  (most recently used at head)

GET(k):  lookup hash → move node to MRU head → return value
SET(k,v):  if exists, update + move to head; else add to head; if over capacity, evict tail
EVICT:  remove tail (LRU), remove from hash map
```

| Operation | Complexity |
|-----------|------------|
| GET | O(1) |
| SET | O(1) |
| Evict | O(1) |

> **FAANG Tip:** LRU with hash map + doubly-linked list is a classic interview data structure. Know it cold.

---

## Eviction: LFU (Alternative)

```
Structure:  freq_bucket[1], freq_bucket[2], freq_bucket[3], ...
            Each bucket = doubly-linked list of (key, value) with that frequency

GET(k):  increment freq; move from bucket[f] to bucket[f+1]
SET(k,v):  add to freq_bucket[1] or update and move
EVICT:  remove from smallest non-empty freq bucket (e.g., freq=1)
```

LFU avoids "scan burst" evicting everything in one bucket; better for stable access patterns.

---

## TTL Support

| Approach | Pros | Cons |
|----------|------|------|
| **Lazy** | Expire on GET; no extra work | Dead keys linger until accessed |
| **Background** | Periodic scan; remove expired | Extra CPU; may miss under load |
| **Timer heap** | Heap of (expiry_time, key); pop min | O(log n) per key; memory |
| **Redis hybrid** | Lazy + periodic sampling | Practical; balances cost |

---

## Data Structures (Redis-Style)

| Type | Internal | Operations |
|------|----------|------------|
| **String** | `char*` or `sds` | GET, SET, INCR |
| **Hash** | Hash table (field → value) | HGET, HSET, HGETALL |
| **List** | Doubly-linked or ziplist (small) | LPUSH, RPOP, LRANGE |
| **Set** | Hash table (member → 1) or intset | SADD, SMEMBERS, SISMEMBER |
| **Sorted Set** | Skip list + hash (member → score) | ZADD, ZRANGE, ZRANGEBYSCORE |

### Sorted Set: Skip List

```
Level 3:  1 ────────────────────────────────► 50
Level 2:  1 ───────► 10 ───────► 30 ────────► 50
Level 1:  1 → 3 → 5 → 10 → 12 → 20 → 30 → 40 → 50
          (sorted by score; levels for O(log n) search)

ZADD:  Insert into skip list by score; O(log n)
ZRANGE 0 9:  Walk bottom level; O(log n + k)
ZRANGEBYSCORE 10 30:  Find start by score; walk; O(log n + k)
```

---

## Persistence Options

| Mode | Mechanism | Use Case |
|------|-----------|----------|
| **None** | Pure cache; lose on restart | Cache-only |
| **RDB** | Snapshot at interval; fork, write dump | Point-in-time backup; fast restore |
| **AOF** | Append-only log of write commands | Durability; replay on startup |
| **Hybrid** | RDB + AOF since last RDB | Redis 4+; best of both |

---

## Cluster Management (Gossip)

```
Nodes exchange:  (node_id, ip, port, slots_owned, state)
Gossip:  Each node periodically sends to random peers
Join:  New node contacts seed; gets full membership; announces itself
Failure:  Node missed in N rounds → mark failed; trigger rebalance/failover
```

---

## API Design

| Command | Args | Semantics |
|---------|------|-----------|
| GET | key | Return value or null |
| SET | key, value, [TTL] | Store; overwrite |
| DEL | key | Remove |
| EXPIRE | key, seconds | Set TTL |
| HGET | key, field | Hash get |
| HSET | key, field, value | Hash set |
| LPUSH | key, value | List left push |
| ZADD | key, score, member | Sorted set add |
| ZRANGE | key, start, stop | Range by rank |

---

## Protocol

- **Redis:** RESP (Redis Serialization Protocol); text-based, `\r\n` delimited
- **Memcached:** Binary protocol; key-value only
- **Custom:** Thrift, gRPC, or simple TCP with length-prefix

---

## Scaling Numbers

| Metric | Per Node | Cluster (100 nodes) |
|--------|----------|----------------------|
| Ops/s | 100K–500K | 10M–50M |
| Memory | 64–256 GB | 6–25 TB |
| Latency (hit) | < 1 ms | < 2 ms (1 hop) |
| Keys | 10M–100M | 1B–10B |
