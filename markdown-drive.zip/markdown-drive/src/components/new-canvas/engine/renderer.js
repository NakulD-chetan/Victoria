import { getStroke } from 'perfect-freehand';
import rough from 'roughjs';
import { paintLaserTrail } from './tools/laser';
import { paintEraserTrail } from './tools/eraser';
import { worldPointsForLinear } from './binding-engine';
import { HAND_FONT, wrapTextLines } from './text-layout';

/**
 * Triple-buffered Canvas2D renderer.
 *
 * Layers (all are `<canvas>` elements stacked via absolute position; see
 * `new-canvas.css` for z-indices):
 *   - static (z=1):      ONLY widget placeholder dashed frames (debug
 *                        fallback so a misaligned widget is still visible)
 *   - interactive (z=2): selection outlines/handles, marquee rect,
 *                        eraser/laser overlays
 *   - ink (z=4, ABOVE widgets): EVERYTHING the user draws — committed
 *                        strokes, shapes, lines, arrows, text + the
 *                        in-progress draft (any tool)
 *
 * Why is everything-the-user-draws above widgets? So a sketched arrow,
 * highlighted region, or rectangle drawn over a code/note/array block
 * stays visible — Excalidraw-style. Widgets are HTML, so they paint
 * between static and ink at z=3.
 *
 * Rules:
 *   - `paint(dirty)` is the ONLY function that clears/draws.
 *   - All layers share the same viewport transform applied on the canvas ctx.
 *   - Device pixel ratio is handled by resizing the backing store; the ctx is
 *     reset each frame with `setTransform`, then scaled by DPR, then by zoom
 *     and translated by pan. This is what makes lines crisp at any DPR.
 *
 * Why three canvases? During a freehand stroke we need to repaint the
 * growing stroke every pointermove (~60-120Hz). Repainting the static
 * layer at that rate is wasteful when only the ink layer changed.
 */

const isWidgetType = (t) => t === 'widget';

export function createRenderer({
  staticEl, interactiveEl, inkEl,
  getScene, getDraft, getSelection, getMarquee,
  getLaser, getEraserTrail,
  getTheme,
}) {
  const state = {
    dpr: Math.max(1, Math.min(3, window.devicePixelRatio || 1)),
    cssW: 0,
    cssH: 0,
  };
  const roughLayers = {
    static: rough.canvas(staticEl),
    interactive: rough.canvas(interactiveEl),
    ink: inkEl ? rough.canvas(inkEl) : null,
  };

  function resize(cssW, cssH) {
    const dpr = Math.max(1, Math.min(3, window.devicePixelRatio || 1));
    state.dpr = dpr;
    state.cssW = cssW;
    state.cssH = cssH;
    const els = inkEl ? [staticEl, interactiveEl, inkEl] : [staticEl, interactiveEl];
    for (const el of els) {
      el.width = Math.max(1, Math.floor(cssW * dpr));
      el.height = Math.max(1, Math.floor(cssH * dpr));
      el.style.width = `${cssW}px`;
      el.style.height = `${cssH}px`;
    }
  }

  function applyTransform(ctx, vp) {
    const { dpr } = state;
    // reset, scale to DPR, then apply viewport (zoom + pan). Pan is in world
    // space so we apply zoom first: screen = (world + pan) * zoom.
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.scale(vp.zoom, vp.zoom);
    ctx.translate(vp.panX, vp.panY);
  }

  function clear(ctx) {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.restore();
  }

  /* ── element painters (world-space) ───────────────────────── */

  function paintStroke(ctx, el, { smoothing = 0.5, thinning = 0.6, streamline = 0.5 } = {}) {
    const pts = el.points;
    if (!pts || pts.length === 0) return;
    const stroke = getStroke(pts, {
      size: el.style.strokeWidth,
      thinning,
      smoothing,
      streamline,
      simulatePressure: pts[0].length < 3,
      last: el._final !== false,
    });
    if (stroke.length === 0) return;
    ctx.beginPath();
    ctx.moveTo(stroke[0][0], stroke[0][1]);
    for (let i = 1; i < stroke.length; i++) ctx.lineTo(stroke[i][0], stroke[i][1]);
    ctx.closePath();
    ctx.globalAlpha = el.style.opacity ?? 1;
    ctx.fillStyle = el.style.stroke;
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  function paintHighlighter(ctx, el) {
    paintStroke(ctx, { ...el, style: { ...el.style } }, { thinning: 0, smoothing: 0.3, streamline: 0.3 });
  }

  function applyDash(ctx, dash, w) {
    if (dash === 'dashed') ctx.setLineDash([w * 3, w * 2]);
    else if (dash === 'dotted') ctx.setLineDash([w, w * 1.5]);
    else ctx.setLineDash([]);
  }

  function elementStroke(el) {
    if (el.customData?.themeInk) {
      return getTheme() === 'dark' ? '#f8fafc' : '#25201f';
    }
    return el.style?.stroke || '#1f2937';
  }

  function roughOptions(el) {
    const style = el.style || {};
    return {
      seed: el.seed || 1,
      roughness: Number.isFinite(el.roughness) ? el.roughness : 1,
      bowing: Math.max(0.5, (Number.isFinite(el.roughness) ? el.roughness : 1) * 0.9),
      stroke: elementStroke(el),
      strokeWidth: style.strokeWidth || 2,
      fill: style.fill && style.fill !== 'transparent' ? style.fill : undefined,
      fillStyle: 'solid',
      strokeLineDash: style.dash === 'dashed'
        ? [8, 6]
        : style.dash === 'dotted'
          ? [2, 5]
          : undefined,
    };
  }

  function paintRect(ctx, el, rc) {
    ctx.save();
    ctx.globalAlpha = el.style.opacity ?? 1;
    rc.rectangle(el.x, el.y, el.w, el.h, roughOptions(el));
    ctx.restore();
  }

  function paintEllipse(ctx, el, rc) {
    ctx.save();
    ctx.globalAlpha = el.style.opacity ?? 1;
    rc.ellipse(
      el.x + el.w / 2,
      el.y + el.h / 2,
      Math.abs(el.w),
      Math.abs(el.h),
      roughOptions(el),
    );
    ctx.restore();
  }

  function paintLine(ctx, el, rc) {
    const points = worldPointsForLinear(el).map((point) => [point.x, point.y]);
    ctx.save();
    ctx.globalAlpha = el.style.opacity ?? 1;
    rc.linearPath(points, roughOptions(el));
    ctx.restore();
  }

  function paintArrow(ctx, el, rc) {
    const points = worldPointsForLinear(el);
    paintLine(ctx, el, rc);
    const end = points[points.length - 1];
    const previous = points[points.length - 2] || points[0];
    const ang = Math.atan2(end.y - previous.y, end.x - previous.x);
    const size = 8 + el.style.strokeWidth * 2;
    const left = [
      end.x - size * Math.cos(ang - 0.5),
      end.y - size * Math.sin(ang - 0.5),
    ];
    const right = [
      end.x - size * Math.cos(ang + 0.5),
      end.y - size * Math.sin(ang + 0.5),
    ];
    ctx.save();
    ctx.globalAlpha = el.style.opacity ?? 1;
    rc.linearPath([
      left,
      [end.x, end.y],
      right,
    ], {
      ...roughOptions(el),
      seed: (el.seed || 1) + 11,
      roughness: Math.min(1.2, el.roughness ?? 1),
    });
    ctx.restore();
  }

  function paintText(ctx, el) {
    if (!el.text) return;
    ctx.globalAlpha = el.style.opacity ?? 1;
    ctx.fillStyle = elementStroke(el);
    const fontSize = el.fontSize || 20;
    const fontFamily = el.fontFamily || HAND_FONT;
    ctx.font = `${fontSize}px ${fontFamily}`;
    ctx.textBaseline = 'top';
    const lines = wrapTextLines(el.text, {
      fontSize,
      fontFamily,
      maxWidth: Math.max(80, el.w || el.width || 480),
    });
    const lh = fontSize * (el.lineHeight || 1.25);
    for (let i = 0; i < lines.length; i++) {
      const lineWidth = ctx.measureText(lines[i]).width;
      const x = el.textAlign === 'center'
        ? el.x + ((el.w || el.width || lineWidth) - lineWidth) / 2
        : el.textAlign === 'right'
          ? el.x + (el.w || el.width || lineWidth) - lineWidth
          : el.x;
      ctx.fillText(lines[i], x, el.y + i * lh);
    }
    ctx.globalAlpha = 1;
  }

  function paintCallout(ctx, el, rc) {
    paintRect(ctx, el, rc);
    ctx.save();
    ctx.fillStyle = el.style?.stroke || '#1f2937';
    const fontSize = el.fontSize || 18;
    const fontFamily = el.fontFamily || HAND_FONT;
    ctx.font = `${fontSize}px ${fontFamily}`;
    ctx.textBaseline = 'top';
    const padding = 14;
    const lines = wrapTextLines(el.text, {
      fontSize,
      fontFamily,
      maxWidth: Math.max(80, el.w - padding * 2),
    });
    lines.forEach((line, index) => {
      ctx.fillText(line, el.x + padding, el.y + padding + index * fontSize * 1.25);
    });
    ctx.restore();
  }

  function paintWidgetPlaceholder(ctx, el) {
    // Widgets render as DOM overlays, but we paint a subtle dashed frame
    // on the canvas so alignment is obvious during debug and so the element
    // is visible even if a React mount fails.
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.strokeStyle = getTheme() === 'dark' ? '#475569' : '#94a3b8';
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(el.x, el.y, el.w, el.h);
    ctx.restore();
  }

  function paintElement(ctx, el, rc) {
    if (el.isDeleted) return;
    switch (el.type) {
      case 'pen':         paintStroke(ctx, el); break;
      case 'highlighter': paintHighlighter(ctx, el); break;
      case 'rect':        paintRect(ctx, el, rc); break;
      case 'ellipse':     paintEllipse(ctx, el, rc); break;
      case 'line':        paintLine(ctx, el, rc); break;
      case 'arrow':       paintArrow(ctx, el, rc); break;
      case 'text':        paintText(ctx, el); break;
      case 'callout':     paintCallout(ctx, el, rc); break;
      case 'widget':      paintWidgetPlaceholder(ctx, el); break;
      default: break;
    }
  }

  /* ── selection / marquee (interactive layer) ──────────────── */

  function paintSelection(ctx, scene, selection, vp) {
    if (!selection || selection.size === 0) return;
    const color = getTheme() === 'dark' ? '#60a5fa' : '#2563eb';
    const fill  = getTheme() === 'dark' ? 'rgba(96,165,250,0.12)' : 'rgba(37,99,235,0.10)';
    const handlePx = 8;
    for (const el of scene.elements) {
      if (!selection.has(el.id) || el.isDeleted) continue;
      const [bx, by, bw, bh] = aabbOf(el);
      const isWidget = el.type === 'widget';
      const selectionColor = isWidget ? '#6366f1' : color;
      const handleWorld = (isWidget ? 10 : handlePx) / vp.zoom;
      ctx.save();
      ctx.lineWidth = (isWidget ? 2 : 1) / vp.zoom;
      ctx.strokeStyle = selectionColor;
      ctx.fillStyle = fill;
      ctx.setLineDash(isWidget ? [] : [4 / vp.zoom, 3 / vp.zoom]);
      ctx.strokeRect(bx, by, bw, bh);
      ctx.setLineDash([]);
      if (!isWidget) ctx.fillRect(bx, by, bw, bh);

      // resize handles at corners and midpoints — we draw 8 of them.
      const handles = handlePositions(bx, by, bw, bh);
      ctx.fillStyle = selectionColor;
      for (const h of handles) {
        ctx.fillRect(h.x - handleWorld / 2, h.y - handleWorld / 2, handleWorld, handleWorld);
      }
      ctx.restore();
    }
  }

  function paintMarquee(ctx, marquee, vp) {
    if (!marquee) return;
    const color = getTheme() === 'dark' ? '#60a5fa' : '#2563eb';
    ctx.save();
    ctx.lineWidth = 1 / vp.zoom;
    ctx.strokeStyle = color;
    ctx.fillStyle = 'rgba(96,165,250,0.10)';
    ctx.setLineDash([4 / vp.zoom, 3 / vp.zoom]);
    const x = Math.min(marquee.x0, marquee.x1);
    const y = Math.min(marquee.y0, marquee.y1);
    const w = Math.abs(marquee.x1 - marquee.x0);
    const h = Math.abs(marquee.y1 - marquee.y0);
    ctx.strokeRect(x, y, w, h);
    ctx.fillRect(x, y, w, h);
    ctx.restore();
  }

  /* ── public paint entry ───────────────────────────────────── */

  function paint(dirtyLevel) {
    const scene = getScene();
    if (!scene) return;
    const vp = scene.viewport;
    const draft = getDraft();

    // STATIC layer — widget placeholder dashed frames only.
    if (dirtyLevel >= 2) {
      const ctx = staticEl.getContext('2d');
      clear(ctx);
      applyTransform(ctx, vp);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      for (const el of scene.elements) {
        if (!isWidgetType(el.type)) continue;
        paintElement(ctx, el, roughLayers.static);
      }
    }

    // INK layer — every drawn element + draft + all overlays, ABOVE widgets.
    // Selection handles, marquee, and eraser/laser trails belong here too so
    // they remain visible when a widget covers them.
    if (inkEl) {
      const ctx = inkEl.getContext('2d');
      clear(ctx);
      applyTransform(ctx, vp);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      for (const el of scene.elements) {
        if (isWidgetType(el.type)) continue;
        paintElement(ctx, el, roughLayers.ink);
      }
      if (draft) paintElement(ctx, draft, roughLayers.ink);
      const selection = getSelection();
      paintSelection(ctx, scene, selection, vp);
      const marquee = getMarquee();
      paintMarquee(ctx, marquee, vp);
      if (getEraserTrail) paintEraserTrail(ctx, getEraserTrail(), vp);
      if (getLaser) paintLaserTrail(ctx, getLaser(), vp);
    }

    // INTERACTIVE layer — defensive fallback (only used if no inkEl wired).
    {
      const ctx = interactiveEl.getContext('2d');
      clear(ctx);
      if (inkEl) return;
      applyTransform(ctx, vp);
      ctx.lineJoin = 'round';
      ctx.lineCap = 'round';
      if (draft) paintElement(ctx, draft, roughLayers.interactive);
      const selection = getSelection();
      paintSelection(ctx, scene, selection, vp);
      const marquee = getMarquee();
      paintMarquee(ctx, marquee, vp);
      if (getEraserTrail) paintEraserTrail(ctx, getEraserTrail(), vp);
      if (getLaser) paintLaserTrail(ctx, getLaser(), vp);
    }
  }

  return { resize, paint, getState: () => state };
}

/* ── geometry helpers shared by renderer + hit test ─────────── */

export function aabbOf(el) {
  if (el.type === 'pen' || el.type === 'highlighter') {
    const pts = el.points || [];
    if (pts.length === 0) return [el.x, el.y, 0, 0];
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of pts) {
      if (p[0] < minX) minX = p[0];
      if (p[0] > maxX) maxX = p[0];
      if (p[1] < minY) minY = p[1];
      if (p[1] > maxY) maxY = p[1];
    }
    const pad = (el.style?.strokeWidth || 2) / 2 + 2;
    return [minX - pad, minY - pad, (maxX - minX) + pad * 2, (maxY - minY) + pad * 2];
  }
  if (el.type === 'line' || el.type === 'arrow') {
    const points = worldPointsForLinear(el);
    const minX = Math.min(...points.map((point) => point.x));
    const minY = Math.min(...points.map((point) => point.y));
    const maxX = Math.max(...points.map((point) => point.x));
    const maxY = Math.max(...points.map((point) => point.y));
    return [minX, minY, maxX - minX, maxY - minY];
  }
  return [el.x, el.y, el.w, el.h];
}

export function handlePositions(x, y, w, h) {
  return [
    { x, y, role: 'nw' },
    { x: x + w / 2, y, role: 'n' },
    { x: x + w, y, role: 'ne' },
    { x: x + w, y: y + h / 2, role: 'e' },
    { x: x + w, y: y + h, role: 'se' },
    { x: x + w / 2, y: y + h, role: 's' },
    { x, y: y + h, role: 'sw' },
    { x, y: y + h / 2, role: 'w' },
  ];
}
