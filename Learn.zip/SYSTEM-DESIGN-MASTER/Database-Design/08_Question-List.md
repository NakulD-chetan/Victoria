# Database Design — Question List (With Complete Answers)

> **Permanent Recall:** 10 MUST-DO questions cover SQL vs NoSQL, schema design, indexing, N+1, transactions, ACID, scaling, sessions, leaderboards, and URL shortener. Every question below has a complete model answer — practice speaking these out loud. The full list has 30+ questions across selection, schema, optimization, transactions, and scaling.

---

## 10 MUST-DO Questions (With Full Answers)

### Q1: SQL vs NoSQL — when would you use each?

**Difficulty:** Easy | **Expected time:** 2-3 minutes

**Model Answer:**

*"I decide based on three factors: data structure, consistency requirements, and scale.*

*SQL (PostgreSQL, MySQL) when the data is structured with clear relationships and we need ACID transactions. For example, a payment system — the debit and credit must happen atomically. PostgreSQL gives us multi-row transactions, JOINs, and strong consistency. It's my default for any system where data integrity matters.*

*NoSQL when we have specific access patterns that a specialized database handles better:*
- *Redis for key-value: caching, sessions, rate limiting, leaderboards. Sub-millisecond, O(1) operations.*
- *MongoDB for flexible documents: product catalogs where phones have 'screen_size' but books have 'pages'. Schema evolves without migrations.*
- *Cassandra for massive write throughput: IoT sensor data, activity logs. Write-optimized, multi-datacenter.*
- *Neo4j for graph traversals: social networks, recommendations. 6-hop queries are milliseconds vs impossible in SQL.*

*In practice, most production systems use both — polyglot persistence. PostgreSQL as the source of truth, Redis for caching, maybe Elasticsearch for search. The key is matching each workload to the right tool."*

---

### Q2: Explain ACID properties with a real example.

**Difficulty:** Easy | **Expected time:** 2 minutes

**Model Answer:**

*"ACID guarantees database reliability. I'll use a bank transfer — move $100 from Account A to Account B.*

*Atomicity: The transfer has two steps — debit A and credit B. If crediting B fails (disk error, network issue), the debit is rolled back. Either both happen or neither. We wrap them in a transaction: BEGIN, UPDATE A, UPDATE B, COMMIT.*

*Consistency: Before the transfer, A+B = $800. After, A+B = $800. The total is invariant. If a CHECK constraint says balance >= 0 and the debit would make A negative ($500 - $600 = -$100), the database rejects the entire transaction.*

*Isolation: If two transfers from A run simultaneously — T1 transfers $100 to B, T2 transfers $50 to C — they don't interfere. T1 reads A=$500, debits to $400. T2 waits for T1's lock, then reads A=$400, debits to $350. Without isolation, both might read A=$500 and we'd lose $100 (the 'lost update' problem).*

*Durability: After COMMIT, even if the server crashes, the transfer persists. PostgreSQL uses a Write-Ahead Log — changes are written to the log before COMMIT returns. On restart, the log is replayed and data is consistent."*

---

### Q3: Design a database schema for Twitter (users, tweets, followers, timeline).

**Difficulty:** Medium | **Expected time:** 3-5 minutes

**Model Answer:**

```
Architecture:
  PostgreSQL (users, tweets, followers) → Source of truth
  Redis (timeline cache, session) → Speed
  Elasticsearch (tweet search) → Full-text search
```

*"Core tables:*

```sql
-- Users
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100),
    email VARCHAR(255) UNIQUE NOT NULL,
    follower_count INT DEFAULT 0,
    following_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tweets
CREATE TABLE tweets (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id),
    content VARCHAR(280) NOT NULL,
    like_count INT DEFAULT 0,
    retweet_count INT DEFAULT 0,
    reply_to_id BIGINT REFERENCES tweets(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Followers (directed: follower follows followed)
CREATE TABLE followers (
    follower_id BIGINT REFERENCES users(id),
    followed_id BIGINT REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (follower_id, followed_id)
);

-- Indexes
CREATE INDEX idx_tweets_user_created ON tweets(user_id, created_at DESC);
CREATE INDEX idx_followers_followed ON followers(followed_id);
CREATE INDEX idx_tweets_created ON tweets(created_at DESC);
```

*Timeline approach: When a user opens their feed, we need tweets from all people they follow, sorted by time. Two approaches:*

*Fan-out on write (push model): When User A tweets, push the tweet ID to the timeline list of ALL followers. Each user's timeline is pre-computed in Redis: `LPUSH timeline:user_123 tweet_id`. Reading the feed is a single Redis read.*

*Fan-out on read (pull model): When User B opens their feed, query: tweets from followed users, sorted by time. More work at read time, but simpler architecture.*

*I'd use fan-out on write for most users (pre-compute) with fan-out on read for celebrities (too many followers to push to — do it on read instead). This is what Twitter actually does.*

*Scaling: Read replicas for tweet/user reads. Redis for timeline cache and hot tweets. Shard by user_id if write volume exceeds one server."*

---

### Q4: How would you optimize a slow query on a 100M row table?

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"I'd follow a systematic debugging approach:*

*Step 1: Run EXPLAIN ANALYZE on the query to see the execution plan.*

```sql
EXPLAIN ANALYZE SELECT * FROM orders 
WHERE user_id = 123 AND status = 'pending' 
ORDER BY created_at DESC LIMIT 20;
```

*Step 2: Check the plan output. Common findings:*

*Finding: 'Seq Scan on orders' — full table scan on 100M rows.*
*Fix: Create an index on the query's filter and sort columns.*

```sql
CREATE INDEX idx_orders_user_status_created 
ON orders(user_id, status, created_at DESC);
```

*This composite index matches the WHERE (user_id = ?, status = ?) and ORDER BY (created_at DESC). The equality columns go first, then the sort column.*

*Step 3: Re-run EXPLAIN ANALYZE. Should now show 'Index Scan' with sub-millisecond execution.*

*Other common optimizations on large tables:*
- *SELECT only needed columns (not SELECT *) — allows covering index*
- *Cursor-based pagination instead of OFFSET — `WHERE created_at < ? LIMIT 20`*
- *Table partitioning by date if queries are time-scoped — each partition is smaller*
- *Materialized view for expensive aggregations that don't need to be real-time*
- *Archive old data — move records older than 1 year to cold storage*"

---

### Q5: Explain the N+1 query problem and how to fix it.

**Difficulty:** Easy | **Expected time:** 1-2 minutes

**Model Answer:**

*"The N+1 problem is when you fetch a list of N items, then make a separate database query for each item's related data — resulting in N+1 total queries instead of 1 or 2.*

*Example: Show 100 orders with user names.*

```
# N+1 approach (101 queries):
orders = SELECT * FROM orders LIMIT 100           # 1 query
for each order:
    user = SELECT name FROM users WHERE id = order.user_id  # 100 queries!
```

*That's 101 queries. At 2ms each, that's 200ms. Scale to 1000 orders: 2 seconds.*

*Fix option 1 — JOIN (1 query):*

```sql
SELECT o.*, u.name FROM orders o 
JOIN users u ON o.user_id = u.id 
LIMIT 100;
```

*Fix option 2 — Batch fetch (2 queries):*

```sql
SELECT * FROM orders LIMIT 100;                     # 1 query
SELECT * FROM users WHERE id IN (1, 5, 12, ...);     # 1 query
```

*Two queries instead of 101. Time: 4ms instead of 200ms.*

*ORMs are the biggest culprit — they make N+1 look natural. The fix is eager loading: Django's `select_related`, Rails' `includes`, SQLAlchemy's `joinedload`."*

---

### Q6: Design a session storage system for 10M concurrent users.

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"Sessions are a classic key-value workload: given a session token, return the user's session data. The requirements are: fast lookups (sub-ms), auto-expiry (TTL), and horizontal scaling.*

*I'd use Redis.*

```
Data model:
  Key: session:{token}
  Value: {user_id: 123, role: "admin", created_at: "...", last_active: "..."}
  TTL: 86400 seconds (24 hours)

Operations:
  Login:   SET session:abc123 {user_data} EX 86400
  Request: GET session:abc123 → returns user data (or nil if expired)
  Logout:  DEL session:abc123
  Extend:  EXPIRE session:abc123 86400 (reset TTL on activity)
```

*Why Redis:*
- *GET is O(1), sub-millisecond — perfect for every-request auth check*
- *Built-in TTL — sessions auto-expire, no cleanup job needed*
- *In-memory — 10M sessions × 1KB each = 10GB RAM (one Redis server)*
- *Redis Cluster for horizontal scaling if needed*

*Why not PostgreSQL:*
- *SQL parsing overhead for a simple key-value lookup*
- *Need to build TTL cleanup (cron job to delete expired sessions)*
- *10M concurrent sessions = 10M rows polled on every request*

*Architecture:*

```
Client → API Server → Redis: GET session:token
  → HIT: user is authenticated, proceed
  → MISS: redirect to login

Redis Cluster (3 primary + 3 replica nodes):
  Node 1: sessions a-h (hash slots 0-5461)
  Node 2: sessions i-p (hash slots 5462-10922)
  Node 3: sessions q-z (hash slots 10923-16383)
  
  10M sessions distributed across 3 nodes
  Each node: ~3.3M sessions, ~3.3GB RAM
```

*For durability (sessions survive Redis restart): Enable AOF persistence. If Redis crashes, sessions are restored from the append-only file. Alternatively, accept that sessions are lost on crash — users just re-login."*

---

### Q7: How do you handle database scaling from 10K to 10M users?

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"I'd follow a progression, each step adding complexity only when needed:*

*At 10K users (current): Single PostgreSQL instance handles everything. Maybe 100 reads/sec, 10 writes/sec. No problems.*

*At 100K users:*
1. *Optimize queries — add indexes on hot paths, fix N+1 queries.*
2. *Add connection pooling (pgBouncer) — handle more concurrent connections.*
3. *Vertical scaling — upgrade to bigger instance (more CPU, RAM).*
4. *These three changes alone handle 10× the load.*

*At 1M users:*
5. *Add Redis cache — cache user profiles, product data, session tokens. 80% of reads served from cache.*
6. *Add 2-3 read replicas — offload remaining reads from primary.*
7. *Primary handles only writes now. Writes at 1M users: maybe 1K/sec. One server handles this easily.*

*At 10M users:*
8. *More read replicas (5-10) behind a load balancer.*
9. *Redis cluster for the cache layer (multiple nodes).*
10. *If write volume exceeds one primary (unlikely at 10M unless extremely write-heavy): shard by user_id.*
11. *But honestly, PostgreSQL on a 32-core machine with NVMe SSDs handles 20K+ writes/sec, which covers most 10M-user apps.*

*Key insight: Most applications at 10M users still DON'T need sharding. Optimization + replicas + cache cover 95% of cases."*

---

### Q8: Design a database for a real-time leaderboard.

**Difficulty:** Medium | **Expected time:** 2-3 minutes

**Model Answer:**

*"A leaderboard needs two operations: update a player's score and get their rank. Both must be fast — ideally O(log n) or better.*

*I'd use Redis sorted sets. Here's why:*

```
Data structure: Redis ZSET (sorted set)
  Key: leaderboard:game_1
  Members: player IDs
  Scores: player scores

Operations:
  Update score:  ZADD leaderboard:game_1 1500 player:42
  Get rank:      ZREVRANK leaderboard:game_1 player:42 → 7 (8th place, 0-indexed)
  Get score:     ZSCORE leaderboard:game_1 player:42 → 1500
  Top 10:        ZREVRANGE leaderboard:game_1 0 9 WITHSCORES
  Around me:     ZREVRANGE leaderboard:game_1 5 15 WITHSCORES (ranks 6-16)
```

*Performance:*
- *ZADD: O(log n) — update one player's score in a 10M-player leaderboard: microseconds*
- *ZREVRANK: O(log n) — get rank: microseconds*
- *ZREVRANGE: O(log n + k) — get top-k: microseconds*

*Why not SQL?*

```sql
-- SQL approach:
SELECT user_id, score, 
       RANK() OVER (ORDER BY score DESC) as rank
FROM scores
WHERE game_id = 1;

-- For 10M rows: builds window function over entire table = SLOW
-- Every rank query is O(n) or requires complex indexing tricks
-- Redis sorted set: O(log n) for all operations. 100× faster.
```

*Architecture:*

```
Player scores event → API Server → Redis: ZADD leaderboard score player_id
                                   → PostgreSQL: INSERT INTO score_history (async, for audit)

User views leaderboard → API Server → Redis: ZREVRANGE leaderboard 0 49
                                      → Return top 50 with scores
```

*PostgreSQL stores the permanent history (for analytics, audit). Redis serves the real-time leaderboard. They can be slightly out of sync (eventual consistency is fine for a leaderboard)."*

---

### Q9: What's the difference between normalization and denormalization? When do you use each?

**Difficulty:** Easy | **Expected time:** 2 minutes

**Model Answer:**

*"Normalization organizes data to eliminate redundancy — each piece of information is stored exactly once. This prevents update anomalies: if Alice changes her email, you update one row in the users table, not 100 rows across multiple tables.*

*Denormalization deliberately introduces redundancy for read performance — duplicating data so a query can be served from one table instead of joining five.*

*Example:*

*Normalized (3 tables, JOINs needed):*
- *posts(id, user_id, content, created_at)*
- *users(id, name, avatar_url)*
- *Feed query: SELECT p.*, u.name, u.avatar_url FROM posts p JOIN users u ...*

*Denormalized (1 table, no JOINs):*
- *feed_posts(id, content, author_name, author_avatar, created_at)*
- *Feed query: SELECT * FROM feed_posts ORDER BY created_at DESC LIMIT 20*

*When to normalize: Writes are frequent, data integrity is critical, storage matters. Banking systems, inventory management, core user data.*

*When to denormalize: Reads dominate (100:1 ratio), JOINs are expensive, latency is critical. Feed displays, dashboards, search results, cached views.*

*My approach: Start normalized (3NF) for the source of truth. Profile query performance. Denormalize only the proven hot read paths — not everything. Measure before and after."*

---

### Q10: Design a database schema for a URL shortener with analytics.

**Difficulty:** Medium | **Expected time:** 3-5 minutes

**Model Answer:**

```
Architecture:
  PostgreSQL (URL mappings, analytics) → Source of truth
  Redis (hot URL cache) → Speed for redirects
```

*"The URL shortener has two main flows: create a short URL and resolve (redirect).*

```sql
-- URL mappings
CREATE TABLE urls (
    id BIGSERIAL,
    short_code VARCHAR(7) PRIMARY KEY,  -- e.g., "abc1234"
    original_url TEXT NOT NULL,
    user_id BIGINT REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ  -- optional expiry
);

-- Click analytics
CREATE TABLE clicks (
    id BIGSERIAL PRIMARY KEY,
    short_code VARCHAR(7) NOT NULL,
    clicked_at TIMESTAMPTZ DEFAULT NOW(),
    ip_address INET,
    user_agent TEXT,
    referrer TEXT,
    country VARCHAR(2)
);

-- Indexes
CREATE INDEX idx_clicks_code_time ON clicks(short_code, clicked_at DESC);
  -- "Analytics for this URL" — clicks over time

CREATE INDEX idx_urls_user ON urls(user_id, created_at DESC);
  -- "My URLs" page
```

*Write flow (create short URL):*
1. *Generate unique short_code (base62 encoding of auto-increment ID, or random)*
2. *INSERT INTO urls (short_code, original_url, user_id)*
3. *Cache in Redis: SET url:abc1234 https://original.com EX 86400*
4. *Return: https://short.ly/abc1234*

*Read flow (redirect — happens 100× more than writes):*
1. *User clicks https://short.ly/abc1234*
2. *Redis: GET url:abc1234 → cache HIT → redirect instantly (sub-ms)*
3. *If cache MISS → PostgreSQL: SELECT original_url FROM urls WHERE short_code = 'abc1234'*
4. *Cache result in Redis for next time*
5. *Async: INSERT click event into clicks table (don't block the redirect)*

*Analytics flow:*

```sql
-- Clicks in last 24 hours for a URL
SELECT COUNT(*) FROM clicks 
WHERE short_code = 'abc1234' AND clicked_at > NOW() - INTERVAL '24 hours';

-- Clicks by country
SELECT country, COUNT(*) FROM clicks 
WHERE short_code = 'abc1234' 
GROUP BY country ORDER BY count DESC;

-- Daily click trend
SELECT DATE(clicked_at) as day, COUNT(*) 
FROM clicks WHERE short_code = 'abc1234' 
GROUP BY day ORDER BY day;
```

*Scaling: The clicks table will grow fast — partition by month. Archive old partitions. Redis cache handles 90%+ of redirect reads. Read replicas for analytics queries."*

---

## Complete Question List (30+) with Brief Answers

### Fundamentals

| # | Question | Brief Answer |
|---|----------|-------------|
| 1 | SQL vs NoSQL — when to use which? | SQL: ACID + relationships. NoSQL: scale + flexibility + specialized access. Most systems use both. |
| 2 | Explain ACID with bank transfer | Atomic (all-or-nothing), Consistent (valid state), Isolated (no interference), Durable (crash-safe) |
| 3 | What is CAP theorem? | Distributed systems: during partition, choose Consistency (reject) or Availability (serve stale). Real choice is CP or AP. |
| 4 | Compare Redis, MongoDB, Cassandra | Redis: in-memory key-value, sub-ms. MongoDB: flexible documents. Cassandra: write-heavy, multi-DC. |
| 5 | When would you use a Graph database? | Social connections, recommendations, fraud detection — when multi-hop traversals ARE the query. |

### Schema Design

| # | Question | Brief Answer |
|---|----------|-------------|
| 6 | Design Twitter schema | users, tweets, followers tables. Pre-computed feed in Redis. Fan-out on write for normal users, fan-out on read for celebrities. |
| 7 | Design e-commerce schema | users, products, orders, order_items, payments. Transaction wraps checkout. Index on (user_id, created_at) for "my orders." |
| 8 | Design URL shortener schema | urls(short_code PK, original_url). clicks(short_code, clicked_at). Redis cache for hot redirects. |
| 9 | Normalization vs denormalization | Normalize for integrity (source of truth). Denormalize for read performance (hot paths). Start normalized, optimize later. |
| 10 | Design ride-sharing schema | users, drivers, trips(driver_id, rider_id, status). Redis for live driver locations. PostGIS for geo-queries. |

### Indexing & Query Optimization

| # | Question | Brief Answer |
|---|----------|-------------|
| 11 | How to decide which columns to index? | Index columns in WHERE, JOIN, ORDER BY of hot queries. Composite: equality first, then range, then sort. |
| 12 | B-Tree vs Hash index? | B-Tree: range queries, sorting, prefix matching. Hash: exact match only, O(1). Default to B-Tree. |
| 13 | What is a covering index? | Index includes all columns needed by the query. Query answered from index alone — no table access. Faster. |
| 14 | Debug a slow query | EXPLAIN ANALYZE → check for Seq Scan → add index. Check N+1 → JOIN. Check OFFSET → cursor pagination. |
| 15 | Composite index column order? | Leftmost prefix rule: (A, B, C) helps (A), (A,B), (A,B,C). Not (B) or (C) alone. Equality before range. |

### Transactions & Consistency

| # | Question | Brief Answer |
|---|----------|-------------|
| 16 | Explain isolation levels | Read Uncommitted (dirty reads) → Read Committed (no dirty reads, default PG) → Repeatable Read (snapshot, default MySQL) → Serializable (full isolation, slowest). |
| 17 | How to handle deadlocks? | Lock in consistent order, keep transactions short, retry with backoff, or use optimistic concurrency (version column). |
| 18 | Eventual vs strong consistency? | Strong: every read sees latest write (SQL default). Eventual: reads may be stale briefly (NoSQL). Strong for money, eventual for social. |
| 19 | Design double-entry bookkeeping | Two entries per transaction (debit + credit). Sum of all entries = 0. ACID transaction wraps both entries. Immutable ledger (append-only). |

### Scaling & Performance

| # | Question | Brief Answer |
|---|----------|-------------|
| 20 | Database scaling progression? | Optimize → vertical → read replicas → cache → shard. Most apps never need sharding. |
| 21 | How does sharding work? | Split data by shard key (e.g., user_id) across independent DBs. Each shard handles a subset. Cross-shard queries are expensive. |
| 22 | Read replicas — how and when? | Primary handles writes. WAL streamed to replicas. Replicas handle read queries. Use when read:write > 10:1. |
| 23 | Connection pooling — why and how? | Reuse connections instead of open/close per request. HikariCP (Java), pgBouncer (PostgreSQL). 10-20 connections serve 1000s of requests. |
| 24 | Design for 1B daily writes | Cassandra or ClickHouse for high write throughput. Batch inserts, minimal indexes, time-based partitioning, LSM-tree storage. |

### NoSQL & Specialized

| # | Question | Brief Answer |
|---|----------|-------------|
| 25 | Design session storage for 10M users | Redis: `session:{token} → {user_data}` with TTL. O(1) GET, sub-ms. Redis Cluster for scale. |
| 26 | Design real-time leaderboard | Redis ZADD for score updates (O(log n)). ZREVRANK for rank. ZREVRANGE for top-N. Way faster than SQL ORDER BY. |
| 27 | When to use Redis vs Memcached? | Redis: data structures (sorted sets, lists), persistence, pub/sub. Memcached: simpler, multi-threaded, pure cache. Redis is more versatile. |
| 28 | MongoDB vs PostgreSQL JSONB? | MongoDB: native document model, flexible schema, horizontal scaling. PG JSONB: JSON in relational DB with ACID + JOINs. Choose PG if you need transactions. |

### Edge Cases & Operations

| # | Question | Brief Answer |
|---|----------|-------------|
| 29 | Auto-increment ID overflow? | INT max: 2.1B. Use BIGINT (9.2 × 10^18) from the start. Monitor max(id). UUID as alternative. |
| 30 | Handle timezones globally? | TIMESTAMPTZ always. Store UTC. Convert at display. Set server TZ to UTC. |
| 31 | Database backup strategy? | pg_dump for logical. WAL archiving for PITR. Test restores regularly. Keep 7-30 days. Offsite copy. |
| 32 | Detect and fix index bloat? | pg_stat_user_indexes for usage. REINDEX to rebuild. VACUUM for table bloat. Schedule during low traffic. |
| 33 | Replication lag — how to handle? | Read from primary after write. Causal consistency tokens. Accept lag for non-critical reads. Synchronous replication for critical data. |
| 34 | What is a hot partition? | One shard/partition gets disproportionate traffic. Fix: hash-based sharding, cache hot keys, add replicas for hot shard. |
| 35 | N+1 queries in ORMs? | ORMs lazy-load related data. Fix: eager loading (Django select_related, Rails includes, SQLAlchemy joinedload). |

---

## Study Plan

**Week 1: Fundamentals (Q1-5)**
- SQL vs NoSQL, ACID, CAP theorem, database types
- Practice explaining each concept out loud in 1-2 minutes

**Week 2: Schema Design (Q6-10)**
- Design schemas for Twitter, e-commerce, URL shortener
- Practice drawing tables, relationships, and indexes on whiteboard

**Week 3: Indexing & Optimization (Q11-15)**
- B-Tree internals, composite indexes, covering indexes, EXPLAIN
- Practice the instant index selection framework (equality → range → sort)

**Week 4: Transactions & Consistency (Q16-19)**
- Isolation levels, deadlocks, eventual vs strong consistency
- Practice the bank transfer ACID example

**Week 5: Scaling & NoSQL (Q20-28)**
- Scaling progression, sharding, Redis for sessions/leaderboards
- Practice explaining the scaling progression (optimize → vertical → replicas → cache → shard)

**Week 6: Edge Cases & Operations (Q29-35)**
- ID overflow, timezones, replication lag, backups
- These show senior-level production awareness

---

## How to Practice

1. **Read the question** — cover the answer
2. **Speak your answer out loud** (not just in your head — interview is verbal)
3. **Draw the schema** on paper/whiteboard while explaining
4. **Compare with model answer** — did you miss anything?
5. **Time yourself** — aim for 1-2 minutes (easy), 2-3 minutes (medium), 3-5 minutes (hard)
6. **Repeat next day** for questions you struggled with

---

## Quick Memory Card

```
MUST-DO:        Q1-10 cover all fundamentals
FUNDAMENTALS:   SQL vs NoSQL, ACID, CAP, database types
SCHEMA:         Twitter, e-commerce, URL shortener, leaderboard, sessions
INDEXING:        B-Tree vs Hash, composite order, covering index, EXPLAIN
TRANSACTIONS:   Isolation levels, deadlocks, eventual vs strong consistency
SCALING:        Optimize → vertical → replicas → cache → shard
NoSQL:          Redis (sessions, leaderboard), MongoDB (docs), Cassandra (writes), Neo4j (graph)
EDGE CASES:     ID overflow, timezones, replication lag, N+1, hot partitions
ORDER:          Fundamentals → Schema → Indexing → Transactions → Scaling → Edge Cases
PRACTICE:       Speak out loud, draw schemas, time yourself
```

---

**Next:** [[01_Concept]] (cycle back to start for revision)
