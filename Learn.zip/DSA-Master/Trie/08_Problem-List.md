# Trie — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO problems highlighted. Every problem builds pattern recognition for FAANG interviews.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Implement Trie (Prefix Tree) | Medium | 208 | Basic trie | Foundation — implement insert, search, startsWith |
| 2 | Design Add and Search Words Data Structure | Medium | 211 | Wildcard search | Trie + DFS for '.' |
| 3 | Word Search II | Hard | 212 | Trie + backtracking | Trie stores words, DFS on board |
| 4 | Word Break | Medium | 139 | Trie + DP | Classic trie+DP combo |
| 5 | Word Break II | Hard | 140 | Trie + DP + backtracking | Return all segmentations |
| 6 | Maximum XOR of Two Numbers in Array | Medium | 421 | Bitwise trie | Bitwise trie template |
| 7 | Longest Word in Dictionary | Medium | 720 | Trie + DFS | Build from prefixes |
| 8 | Replace Words | Medium | 648 | Shortest prefix | First is_end on path |
| 9 | Map Sum Pairs | Medium | 677 | Trie + value field | Prefix sum in trie |
| 10 | Prefix and Suffix Search | Hard | 745 | Trie variant | Combined prefix-suffix |

---

## Complete 30-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Implement Trie (Prefix Tree) | 208 | Basic trie | insert, search, startsWith |
| 2 | Longest Common Prefix | 14 | Trie or scan | Path until branch |
| 3 | Design HashSet (Trie variant) | 705 | Trie as set | Simpler trie |
| 4 | First Unique Character | 387 | Off-topic but warm-up | — |
| 5 | Valid Anagram | 242 | Off-topic | — |
| 6 | Ransom Note | 383 | Off-topic | — |

### Medium (Problems 7-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 7 | Design Add and Search Words Data Structure | 211 | Wildcard | Trie + DFS |
| 8 | Word Break | 139 | Trie + DP | Prefix check |
| 9 | Replace Words | 648 | Shortest prefix | First is_end |
| 10 | Longest Word in Dictionary | 720 | Trie + DFS | Build from prefixes |
| 11 | Map Sum Pairs | 677 | Trie + value | Prefix sum |
| 12 | Maximum XOR of Two Numbers in Array | 421 | Bitwise trie | Greedy opposite bit |
| 13 | Maximum XOR With an Element From Array | 1707 | Bitwise trie + sort | Offline queries |
| 14 | Count Pairs With Given XOR | — | Bitwise trie | Count pairs |
| 15 | Shortest Word Distance II | 244 | HashMap (trie alt) | — |
| 16 | Palindrome Pairs | 336 | Trie or HashMap | Reverse trie |
| 17 | Word Squares | 425 | Trie + backtracking | Prefix lookup |
| 18 | Add and Search Word - Data structure design | 211 | Same as #7 | — |
| 19 | Stream of Characters | 1032 | Trie + active nodes | Suffix in dict |
| 20 | Index Pairs of a String | 1065 | Trie + scan | Find all prefixes |
| 21 | Search Suggestions System | 1268 | Trie + DFS | Autocomplete |
| 22 | Count Words After Adding a Letter | 2135 | Trie/bitmask | — |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Word Search II | 212 | Trie + backtracking | Trie of words, DFS board |
| 24 | Word Break II | 140 | Trie + DP + backtrack | All segmentations |
| 25 | Prefix and Suffix Search | 745 | Trie variant | Combined trie |
| 26 | Palindrome Pairs | 336 | Trie | Reverse + trie |
| 27 | Word Squares | 425 | Trie | Prefix constraint |
| 28 | Maximum XOR of Two Numbers in Array | 421 | Bitwise trie | — |
| 29 | Count Substrings That Differ by One Character | 1638 | Trie variant | — |
| 30 | Word Search II (optimized) | 212 | Trie + prune | Remove found words |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Implement Trie (LC 208)
```
Type: Basic trie
Key: TrieNode with children + is_end
Template: Template 1 (all 3 languages)
One-liner: Map-based or array-based children, mark is_end on insert.
```

### Problem 7: Design Add and Search Words (LC 211)
```
Type: Wildcard search
Key: '.' → try all children via DFS
Template: Template 2 (Wildcard)
One-liner: search: if '.' then recurse on all children; else follow one child.
```

### Problem 8: Word Break (LC 139)
```
Type: Trie + DP
Key: dp[i] = can form s[0:i]; trie checks prefix from i
Template: Template 3 (Word Break)
One-liner: For each i with dp[i]=true, traverse trie from s[i], set dp[j+1]=true at is_end.
```

### Problem 12: Maximum XOR of Two Numbers (LC 421)
```
Type: Bitwise trie
Key: Insert numbers as 31-bit paths; query: greedy opposite bit
Template: Bitwise Trie
One-liner: For each num, insert into trie; for each num, query max XOR by picking opposite bit.
```

### Problem 23: Word Search II (LC 212)
```
Type: Trie + backtracking
Key: Build trie from words; DFS board, follow trie path
Template: Trie + DFS
One-liner: Trie of words; DFS each cell, prune when trie path ends, collect at is_end.
```

### Problem 25: Prefix and Suffix Search (LC 745)
```
Type: Combined trie
Key: Store "suffix#prefix" in trie; query "suffix#prefix"
Template: Trie variant
One-liner: Insert word as "word#word", "ord#word", ...; query "suffix#prefix".
```

---

## Pattern Distribution

```
BASIC TRIE:           5 problems  (208, 211, 720, 677, 14)
TRIE + DP:            3 problems  (139, 140)
TRIE + BACKTRACK:     4 problems  (212, 425, 336)
BITWISE TRIE:         3 problems  (421, 1707)
WILDCARD:             1 problem   (211)
PREFIX/SUFFIX:         2 problems  (745, 648)
AUTOCOMPLETE:         1 problem   (1268)
STREAM:               1 problem   (1032)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 208 (Implement Trie), LC 14 (LCP)
- Day 2: LC 211 (Add and Search Word), LC 648 (Replace Words)
- Day 3: LC 720 (Longest Word), LC 677 (Map Sum)

### Week 2: Core (Days 4-7)
- Day 4: LC 139 (Word Break), LC 140 (Word Break II)
- Day 5: LC 421 (Max XOR), LC 1707 (Max XOR With Element)
- Day 6: LC 212 (Word Search II)
- Day 7: LC 745 (Prefix and Suffix Search)

### Week 3: Advanced (Days 8-10)
- Day 8: LC 425 (Word Squares), LC 336 (Palindrome Pairs)
- Day 9: LC 1032 (Stream of Characters), LC 1268 (Search Suggestions)
- Day 10: Review MUST-DO, mock interview

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (6 Easy, 16 Medium, 8 Hard)
MUST-DO:            LC 208, 211, 212, 139, 140, 421, 720, 648, 677, 745
TOP 3 MOST ASKED:   LC 208 (Implement Trie), LC 211 (Wildcard), LC 212 (Word Search II)
PATTERN SPLIT:      Basic (5), Trie+DP (3), Trie+Backtrack (4), Bitwise (3), Other (5)
STUDY ORDER:        Basic Trie → Wildcard → Word Break → Bitwise → Word Search II
INTERVIEW LINE:     "I've practiced trie variants including wildcard search,
                     word break with DP, and bitwise trie for XOR problems."
```

---

## 30-SECOND REVISION BOX

```
MUST-DO TOP 3:  LC 208 (Trie), LC 211 (Wildcard), LC 212 (Word Search II)
EASY START:     LC 208, LC 14
MEDIUM CORE:    LC 211, LC 139, LC 421, LC 648, LC 720, LC 677
HARD BOSS:      LC 212, LC 140, LC 745
BITWISE:        LC 421, LC 1707
PRACTICE IN:    Python first → C++ for STL → Rust for ownership
```
