# 07 — Data Pipeline System Design

> **One-line:** System design for DE means designing an **end-to-end data platform** — from ingestion to serving — with clear **trade-offs** at every decision point. This is the **most important skill** for senior DE interviews.

---

## 1. System Design Answer Framework

**Use this structure for EVERY system design question:**

```
Step 1: CLARIFY (3-5 min)
    │  → Data volume, velocity, variety
    │  → Latency requirements (real-time vs batch?)
    │  → Consumers (BI, ML, APIs?)
    │  → Retention, compliance
    │
Step 2: HIGH-LEVEL DESIGN (5-7 min)
    │  → Draw ingestion → processing → storage → serving
    │  → Name technologies at each layer
    │
Step 3: DEEP DIVE (10-15 min)
    │  → Scaling bottlenecks
    │  → Failure handling
    │  → Data quality
    │  → Schema evolution
    │
Step 4: TRADE-OFFS & ALTERNATIVES (3-5 min)
       → Why this vs that?
       → Cost, complexity, latency trade-offs
```

**Interview tip:** "Spend 3-5 minutes asking clarifying questions BEFORE drawing anything. Interviewers evaluate your **problem-framing** as much as your solution."

---

## 2. Universal Data Platform Architecture

```
┌─────────┐   ┌──────────────┐   ┌─────────────┐   ┌──────────┐   ┌──────────┐
│ SOURCES │──►│  INGESTION   │──►│ PROCESSING  │──►│ STORAGE  │──►│ SERVING  │
│         │   │              │   │             │   │          │   │          │
│ DBs     │   │ Kafka        │   │ Spark       │   │ Lake     │   │ DW (SQL) │
│ APIs    │   │ Debezium     │   │ Flink       │   │ (Bronze  │   │ API      │
│ Files   │   │ Fivetran     │   │ dbt         │   │  Silver  │   │ Dashboard│
│ Streams │   │ Airbyte      │   │ Python      │   │  Gold)   │   │ ML Model │
│ Logs    │   │ Auto Loader  │   │             │   │ DW       │   │          │
└─────────┘   └──────────────┘   └─────────────┘   └──────────┘   └──────────┘
                                                         │
                                                    ┌────┴─────┐
                                                    │MONITORING│
                                                    │ Lineage  │
                                                    │ Quality  │
                                                    │ Alerts   │
                                                    └──────────┘
```

---

## 3. Common System Design Questions & Approaches

### Q1: Design a Real-Time Analytics Dashboard

**Requirements:** 1M events/sec, sub-second dashboard refresh

```
Sources (clickstream, app events)
    │
    ▼
Kafka (ingestion buffer, partitioned by user_id)
    │
    ├──► Flink/Spark Streaming (real-time aggregation)
    │       │
    │       ▼
    │    Redis / Druid (pre-computed metrics, sub-second queries)
    │       │
    │       ▼
    │    Dashboard (Grafana / custom UI)
    │
    └──► Spark Batch (hourly/daily recompute for accuracy)
            │
            ▼
         Data Lake (historical, full-fidelity backup)
```

**Key decisions:**
- **Lambda** (batch + stream) vs **Kappa** (stream-only) → Lambda for accuracy guarantee
- **Pre-aggregation** in streaming → OLAP engine just serves, doesn't compute
- **Kafka** as buffer → handles backpressure, replay

---

### Q2: Design a Data Warehouse for E-Commerce

**Requirements:** 500GB/day, analysts use SQL, daily reports

```
Sources                      Processing              Serving
┌──────────┐                ┌──────────┐            ┌──────────┐
│ Orders DB│──Debezium/CDC──►│ Spark/dbt│──────────►│ Snowflake│
│ Products │                │ (Bronze  │            │ (Star    │
│ Users    │──Airbyte──────►│  Silver  │            │  Schema) │
│ Payments │                │  Gold)   │            │          │
│ Clickstrm│──Kafka────────►│          │            │ Fact:    │
└──────────┘                └──────────┘            │  orders  │
                                                    │ Dims:    │
    Airflow (orchestration)                         │  customer│
    Great Expectations (DQ)                         │  product │
    Unity Catalog (governance)                      │  date    │
                                                    └──────────┘
```

**Key decisions:**
- **CDC** for OLTP sources → near-real-time without impacting production
- **Medallion architecture** → Bronze (raw) → Silver (clean) → Gold (marts)
- **Star schema** in Gold layer → optimized for analyst SQL queries
- **SCD Type 2** for customer/product dimensions
- **Incremental processing** → process only new/changed data

---

### Q3: Design a Log Processing Pipeline

**Requirements:** 10TB logs/day, search within 5 min, retain 90 days

```
App Servers (millions of log lines/sec)
    │
    ▼
Fluentd/Filebeat (agent on each server)
    │
    ▼
Kafka (buffer, log topic partitioned by service)
    │
    ├──► Spark Streaming → Elasticsearch (searchable within 5 min)
    │
    └──► Spark Batch (hourly) → S3 Parquet (90-day retention, cheap)
                                    │
                                    ▼
                              Athena/Presto (ad-hoc historical queries)
```

---

## 4. Key Design Patterns

| Pattern | When to Use | Implementation |
|---------|-------------|----------------|
| **Event sourcing** | Need complete audit trail | Kafka as immutable log, materialize views |
| **CQRS** | Different read/write patterns | Write to OLTP, read from OLAP (separate models) |
| **Lambda** | Need both real-time and accurate batch | Stream + batch layers, merge at serving |
| **Kappa** | Stream processing sufficient | Single Kafka + stream processor, replay for backfill |
| **Medallion** | Data lake organization | Bronze → Silver → Gold |
| **Fan-out** | One event, many consumers | Kafka topic → multiple consumer groups |
| **Dead letter queue** | Handle bad records | Route unparseable records to separate topic/table |
| **Backpressure** | Producer faster than consumer | Kafka buffers, consumer rate limiting |

---

## 5. Scaling Considerations (Interview Must-Know)

| Bottleneck | Solution |
|-----------|----------|
| **Ingestion overwhelmed** | Kafka partitions (parallelize), increase producer batch size |
| **Processing slow** | More Spark executors, optimize joins (broadcast), partition data |
| **Storage growing fast** | Compression (Zstd/Snappy), lifecycle policies (archive/delete), partitioning |
| **Query slow** | Clustering keys, materialized views, pre-aggregation, caching |
| **Single point of failure** | HA for NameNode/scheduler, multi-AZ deployment, Kafka replication |

---

## 6. Back-of-Envelope Calculations

| What | How to Estimate |
|------|----------------|
| **Daily data volume** | Events/day × avg event size |
| **Storage per year** | Daily × 365 × compression ratio (typically 5-10x) |
| **Kafka throughput** | Partitions × per-partition throughput (1-10 MB/s each) |
| **Spark cluster size** | Data volume / processing time target / per-node throughput |

### Example Calculation

```
Requirement: 100M events/day, avg 1KB each

Daily raw:     100M × 1KB = 100 GB/day
Monthly raw:   100 GB × 30 = 3 TB/month
With Parquet:  3 TB / 5 (compression) = 600 GB/month
Yearly:        600 GB × 12 = 7.2 TB/year

Kafka: 100M events / 86400 sec = ~1,157 events/sec
       With 1KB each = ~1.1 MB/sec → 4 partitions easily handle this
```

---

## 7. Failure Handling Patterns

| Failure | Strategy |
|---------|----------|
| **Pipeline job fails mid-run** | Idempotent writes (INSERT OVERWRITE or MERGE), checkpoint/restart |
| **Bad data arrives** | Schema validation → dead letter queue → alert → manual review |
| **Source system down** | Kafka buffers events; retry with exponential backoff |
| **Downstream consumer behind** | Kafka retention allows catch-up; backpressure mechanisms |
| **Schema changes upstream** | Schema Registry enforcement; backward compatibility; versioned topics |
| **Duplicate events** | Idempotent consumers (dedup by event ID + timestamp) |

---

## 8. Technology Selection Cheat Sheet

| Need | Choose |
|------|--------|
| **Event streaming** | Kafka (self-managed) or Confluent/MSK (managed) |
| **Batch processing** | Spark (Databricks or EMR) |
| **Stream processing** | Flink (complex event processing) or Spark Structured Streaming (simpler) |
| **Orchestration** | Airflow (standard) or Dagster/Prefect (modern) |
| **Data warehouse** | Snowflake (SQL-first) or BigQuery (serverless) or Redshift |
| **Data lake** | S3/ADLS + Delta Lake/Iceberg |
| **Data ingestion** | Fivetran/Airbyte (managed) or custom Kafka producers |
| **Data quality** | Great Expectations, dbt tests, Soda |
| **Governance** | Unity Catalog, Apache Atlas, OpenMetadata |
| **BI/Visualization** | Looker, Tableau, Power BI, Superset |

---

## 9. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "Design a data pipeline for X" | Follow the framework: Clarify → High-level → Deep dive → Trade-offs |
| "How do you handle late-arriving data?" | Watermarks in streaming, reprocessing partitions in batch, SCD handling |
| "How do you ensure data quality?" | Validation at ingestion, expectations in Silver, reconciliation checks |
| "How do you handle schema evolution?" | Schema Registry, backward compatibility, versioned tables |
| "Batch vs streaming — when?" | Batch: cost-effective, simple, latency OK. Stream: real-time needs, event-driven |
| "How do you handle 10x traffic spike?" | Kafka absorbs burst, auto-scaling compute, pre-aggregation |

---

## Key Takeaways

- Always follow: **Clarify → Design → Deep Dive → Trade-offs**.
- **Back-of-envelope calculations** show you think at scale.
- **Kafka** is almost always the ingestion layer for real-time. **Spark/dbt** for processing.
- **Medallion** (Bronze→Silver→Gold) is the standard lake organization.
- **Idempotency** and **dead letter queues** are non-negotiable for production pipelines.
- Know when to choose **batch vs stream**, **Lambda vs Kappa**, and articulate **why**.
- **Failure handling** and **scaling** discussions separate senior from junior candidates.

---
