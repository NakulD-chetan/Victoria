import { useDroppable } from '@dnd-kit/core';
import { useWorkspaceStore } from '../../stores/workspace-store';
import NoteEditor from './NoteEditor';
import TabStrip from './TabStrip';

/*
 * EditorPane — one leaf in the workspace tree. Tab strip + edge drop
 * zones (so a tab dropped on the left/right/top/bottom edge causes a
 * split) + the active note's editor.
 */

const ZONES = [
  { dir: 'left',  style: { left: 0,   top: 0, bottom: 0, width: '14%' } },
  { dir: 'right', style: { right: 0,  top: 0, bottom: 0, width: '14%' } },
  { dir: 'up',    style: { left: 0,   right: 0, top: 0, height: '14%' } },
  { dir: 'down',  style: { left: 0,   right: 0, bottom: 0, height: '14%' } },
];

function EdgeZone({ paneId, dir, style }) {
  const drop = useDroppable({
    id: `pane-edge:${paneId}:${dir}`,
    data: { type: 'pane-edge', paneId, direction: dir },
  });
  return (
    <div
      ref={drop.setNodeRef}
      className={`obs-pane__edge${drop.isOver ? ' obs-pane__edge--over' : ''}`}
      style={style}
      data-edge={dir}
    />
  );
}

export default function EditorPane({ pane, isFocused, canClose }) {
  const splitPane = useWorkspaceStore((s) => s.splitFocusedPane);
  const focusPane = useWorkspaceStore((s) => s.focusPane);
  const closePane = useWorkspaceStore((s) => s.closePane);
  const reportPointerPane = useWorkspaceStore((s) => s.reportPointerPane);

  const drop = useDroppable({ id: `pane-body:${pane.id}`, data: { type: 'pane-body', paneId: pane.id } });

  return (
    <div
      className={`obs-pane${isFocused ? ' obs-pane--focused' : ''}`}
      onPointerDownCapture={() => focusPane(pane.id)}
      onPointerEnter={() => reportPointerPane(pane.id)}
      onMouseDown={() => focusPane(pane.id)}
    >
      <TabStrip
        pane={pane}
        isFocused={isFocused}
        onSplit={() => splitPane('right')}
        onClose={canClose ? () => closePane(pane.id) : null}
      />
      <div ref={drop.setNodeRef} className="obs-pane__body">
        {pane.activeTabId ? (
          <NoteEditor key={pane.activeTabId} noteId={pane.activeTabId} />
        ) : (
          <div className="obs-pane__empty">
            <p>Drop a tab here, or open a note from the sidebar.</p>
          </div>
        )}
        {/* Edge drop zones must sit on top of the editor; rendered last so
            they win the stacking order. They are pointer-inert until the
            workspace flips data-dragging="true" (see workspace.css). */}
        {ZONES.map((z) => (
          <EdgeZone key={z.dir} paneId={pane.id} dir={z.dir} style={z.style} />
        ))}
      </div>
    </div>
  );
}
