# Trie — Edge Cases

> **FAANG interviewers love edge cases. Handle these explicitly.**

---

## Edge Case 1: Empty String

| Operation | Behavior | Handling |
|-----------|----------|----------|
| insert("") | Root = end of word | `if not word: self.root.is_end = True; return` |
| search("") | Is "" in trie? | Return `root.is_end` |
| startsWith("") | All words have prefix "" | Return `True` (or per problem) |

```
Trie with "a", "ab":
  search("")  → false (root.is_end is false)
  startsWith("") → true (prefix exists trivially)
```

---

## Edge Case 2: Word is Prefix of Another

```
Words: "car", "card"
  search("car")  → true  (must have is_end at 'r')
  search("card") → true  (must have is_end at 'd')
```

**Mistake:** Forgetting is_end at intermediate node → "car" returns false.

---

## Edge Case 3: Prefix is Word (Reverse)

```
Words: "car", "card"
  startsWith("car")  → true  (path exists)
  startsWith("card") → true  (path exists, "card" is full word)
```

**startsWith** only checks path existence, not is_end.

---

## Edge Case 4: Single Character Words

```
Words: "a", "ab"
  search("a")  → true
  search("ab") → true
```

Ensure root's child 'a' has is_end=true for "a", and 'b' has is_end for "ab".

---

## Edge Case 5: Duplicate Insert

```
insert("cat")
insert("cat")  // Again
```

**Options:**
- Idempotent: no change (typical)
- Count: increment count at node (for frequency trie)

---

## Edge Case 6: Large Alphabet / Unicode

| Scenario | Issue | Fix |
|----------|-------|-----|
| Array[26] for "café" | 'é' out of range | Use HashMap |
| Array[26] for "Cat" | 'C' - 'a' negative | Normalize: `c.lower()` or validate |
| Emoji, CJK | Multi-byte chars | Use `str.chars()` / `string.chars()` |

---

## Edge Case 7: Wildcard — Multiple Dots

```
Pattern: "c.."  matches "cat", "car", "cod"
```

DFS must try all children at each '.'. No early exit.

---

## Edge Case 8: Word Break — Empty Dictionary

```
s = "leetcode", wordDict = []
→ false
```

Trie is empty; dp[0]=true, but no valid break.

---

## Edge Case 9: Word Break — String Shorter Than All Words

```
s = "a", wordDict = ["abc", "def"]
→ false
```

---

## Edge Case 10: Count Prefix — Zero Matches

```
Words: ["apple", "app"]
countPrefix("app")  → 2
countPrefix("apx")  → 0  (path doesn't exist)
```

Return 0 when path doesn't exist (don't throw).

---

## Edge Case Summary Table

| # | Edge Case | Check |
|---|-----------|-------|
| 1 | Empty string | Handle insert/search/startsWith |
| 2 | Word = prefix of another | is_end at intermediate nodes |
| 3 | Prefix = full word | startsWith ignores is_end |
| 4 | Single char words | is_end at depth 1 |
| 5 | Duplicate insert | Idempotent or count |
| 6 | Unicode / large alphabet | HashMap, .chars() |
| 7 | Multiple wildcards | DFS tries all at each '.' |
| 8 | Empty dict (word break) | Return false |
| 9 | Short string (word break) | No match |
| 10 | Prefix not in trie | Return 0 / false |

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:       insert "" → root.is_end; search "" → root.is_end
PREFIX:      "car" in "card" → is_end at 'r'
STARTSWITH:  Never check is_end
SINGLE CHAR: is_end at depth 1
UNICODE:     HashMap, .chars()
WILDCARD:    Each '.' tries all children
WORD BREAK:  Empty dict → false; short s → false
```

---

## 30-SECOND REVISION BOX

```
"" → root.is_end
"car" vs "card" → both need is_end
startsWith = path exists only
Single char → mark is_end
Unicode → HashMap + chars()
Empty dict → false
```
