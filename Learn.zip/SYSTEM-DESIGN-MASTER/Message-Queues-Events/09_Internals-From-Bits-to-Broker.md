# Internals: From Bits on the Wire to the Broker

> **Permanent Recall:** A message's journey: Application `write()` → userspace buffer → kernel socket buffer (`sk_buff`) → TCP segmentation → IP packet → Ethernet frame → NIC DMA → electrical/optical signal on wire → destination NIC → kernel → epoll wakes broker thread → broker reads bytes → deserializes → stores. Every step matters for throughput and latency.

---

## Why This Matters

Most engineers say "producer sends to broker" as if that were one step.

At interview depth, that answer is too shallow.

This file explains what actually sits inside that sentence:

- user space to kernel transition
- TCP and socket behavior
- NIC and DMA
- epoll wake-up
- broker thread model

If you understand this path, later files on Kafka storage, replication, and zero-copy become much easier to reason about.

---

## The Full Journey of a Single Message (Producer → Broker)

```
APPLICATION LAYER (Producer)
  │
  │  serialize(message) → byte[]
  │  socket.write(byte[])
  │
  ▼
USER SPACE → KERNEL BOUNDARY  (syscall: write / send / sendmsg)
  │
  │  copy bytes to kernel socket send buffer (sk_buff)
  │
  ▼
KERNEL: TCP STACK
  │
  │  TCP segmentation (split into MSS-sized chunks ~1460 bytes)
  │  Add TCP header (src port, dst port, seq#, ack#, flags, window)
  │  Manage congestion window (cwnd), slow start, flow control
  │
  ▼
KERNEL: IP LAYER
  │
  │  Add IP header (src IP, dst IP, TTL, protocol=TCP)
  │  Routing table lookup → which NIC, which gateway
  │
  ▼
KERNEL: DATA LINK LAYER
  │
  │  ARP lookup → destination MAC address
  │  Add Ethernet frame header (src MAC, dst MAC, EtherType)
  │  Compute FCS (Frame Check Sequence / CRC-32)
  │
  ▼
KERNEL: DRIVER → NIC
  │
  │  Place frame in TX ring buffer (DMA descriptor ring)
  │  NIC DMA engine reads frame from host memory
  │
  ▼
NIC HARDWARE
  │
  │  Encode bits → electrical signals (copper) or light pulses (fiber)
  │  Preamble + SFD → Frame bytes → Inter-frame gap
  │  At 10 Gbps: each bit = 0.1 nanoseconds
  │
  ▼
═══════════════════════════════════════════════════════════
PHYSICAL MEDIUM (wire / fiber / airwaves)
═══════════════════════════════════════════════════════════
  │
  ▼
DESTINATION NIC
  │
  │  Signal → bits (clock recovery, 8b/10b or PAM4 decoding)
  │  FCS check → drop if corrupt
  │  DMA write frame to host memory (RX ring buffer)
  │  Raise interrupt (or coalesce interrupts)
  │
  ▼
KERNEL: INTERRUPT / NAPI
  │
  │  Hard IRQ → schedule softirq (NAPI polling)
  │  NAPI poll: batch-process frames from RX ring
  │  Parse Ethernet → IP → TCP headers
  │  Reassemble TCP stream in socket receive buffer
  │
  ▼
KERNEL: SOCKET LAYER
  │
  │  Data ready in socket recv buffer
  │  Wake up process blocked on epoll_wait / select / io_uring
  │
  ▼
USER SPACE (Broker)
  │
  │  read(fd, buf, len) → copy from kernel recv buffer to userspace
  │  Deserialize bytes → Message object
  │  Write to storage (log segment on disk)
  │
  ▼
BROKER: MESSAGE STORED
```

---

## Step 1: The NIC — Network Interface Card

The NIC is the boundary between software and the physical network.

### What the NIC Actually Does

```
NIC INTERNALS:

┌──────────────────────────────────────────────────────────┐
│                        NIC CARD                          │
│                                                          │
│  ┌──────────┐   ┌──────────┐   ┌──────────────────────┐ │
│  │ PHY      │   │ MAC      │   │ DMA Engine           │ │
│  │ (Physical│◄─►│ (Media   │◄─►│ (Direct Memory       │ │
│  │  Layer)  │   │  Access  │   │  Access to host RAM) │ │
│  │          │   │  Control)│   │                      │ │
│  │ Signal ↔ │   │ Frame    │   │ Ring buffers:        │ │
│  │ Bits     │   │ parsing  │   │  TX ring (send)      │ │
│  │          │   │ FCS      │   │  RX ring (receive)   │ │
│  └──────────┘   └──────────┘   └──────────────────────┘ │
│       ▲                              ▲                   │
│       │                              │                   │
│   Cable/Fiber                    PCIe Bus                │
│   (physical medium)             (to CPU/RAM)             │
└──────────────────────────────────────────────────────────┘
```

### PHY Layer: Bits ↔ Signals

```
COPPER ETHERNET (Cat6, 1 Gbps):
  Bit "1" → positive voltage pulse (+1V)
  Bit "0" → negative voltage pulse (-1V)
  Encoding: MLT-3 or PAM-5(singal encoding schema)
  4 twisted pairs, each carries portion of data

FIBER OPTIC (10 Gbps+):
  Bit "1" → light pulse ON (laser diode)
  Bit "0" → light pulse OFF (or different phase)
  Single-mode: long distance, one light path
  Multi-mode: short distance, multiple light paths

10 Gbps:
  1 bit = 0.1 nanoseconds
  1 byte = 0.8 nanoseconds
  1 KB = ~819 nanoseconds ≈ 0.8 microseconds
  1 MB = ~0.8 milliseconds
```

### DMA Ring Buffers: How NIC Talks to Kernel

A **NIC (Network Card)** and the **Kernel (OS)** need to exchange network data **very fast**.

Instead of copying data back and forth using CPU, they use:  
👉 **DMA (Direct Memory Access)**  
👉 **Ring Buffers (circular queues in RAM)**

NIC and Kernel share a circular list of slots in memory and pass messages by updating pointers — no copying needed.

Descriptor = metadata (where data is, how big it is, status)

```
DMA RING BUFFER STRUCTURE:

The NIC and kernel share ring buffers in host RAM.
No CPU copy needed — NIC reads/writes directly via PCIe DMA.

TX RING (sending):
  ┌────┬────┬────┬────┬────┬────┬────┬────┐
  │ D0 │ D1 │ D2 │ D3 │ D4 │ D5 │ D6 │ D7 │   Descriptors
  └─┬──┴─┬──┴─┬──┴────┴────┴────┴────┴────┘
    │    │    │
    ▼    ▼    ▼
  [buf0][buf1][buf2]...  Data buffers in host RAM

  Driver writes descriptor:
    descriptor.addr = physical address of buffer
    descriptor.len  = number of bytes
    descriptor.flags = READY

  Driver rings doorbell (writes to NIC register via MMIO)
  NIC DMA engine reads descriptor → reads buffer → sends on wire

RX RING (receiving):
  NIC DMA-writes incoming frame to pre-allocated buffer
  Updates descriptor: length, status, checksum offload result
  Raises interrupt (or coalesces: "wait for N frames or T microseconds")
```

# Now the Important Part

# 🔸 TX Ring (Sending Data)

### Step-by-step (simple):

1. **Kernel prepares data**
  - Example: packet to send
2. **Kernel puts info in descriptor**
  - Where data is in memory
  - How big it is

```
Descriptor:
  addr → memory location of packet
  len  → size
  flag → READY
```

1. **Kernel notifies NIC (doorbell 🔔)**
  - 
  "Hey, new data is ready!"
2. **NIC reads descriptor using DMA**
  - 
  Goes to that memory address  
  - 
  Reads the packet
3. **NIC sends packet to network**

---

### 🧠 Simple analogy:

# 🔸 RX Ring (Receiving Data)

### Step-by-step:

1. **Kernel pre-allocates empty buffers**
  - "NIC, you can write data here"
2. **NIC receives packet from network**
3. **NIC writes data directly to RAM (DMA)**
  - No CPU copy
4. **NIC updates descriptor**
  - Length
  - Status (valid / checksum OK)
5. **NIC notifies CPU**
  - Interrupt OR batch notification
6. **Kernel reads data and processes it**

### Interrupt Coalescing

Instead of interrupting the CPU for every packet, the NIC groups multiple packets and interrupts once.

```
WITHOUT COALESCING:
  Frame arrives → interrupt → CPU handles → frame arrives → interrupt → ...
  At 1M packets/sec = 1M interrupts/sec = CPU overwhelmed

WITH COALESCING:
  Frames arrive → NIC buffers → after 64 frames OR 50µs:
    → single interrupt → kernel processes batch of 64 frames
  Reduces CPU overhead dramatically

SETTINGS (ethtool):
  rx-usecs: 50        # max wait time before interrupt (microseconds)
  rx-frames: 64       # max frames before interrupt
  adaptive-rx: on     # auto-tune based on load
```

---

## Step 2: Kernel Network Stack — From Frame to Socket

### What is **IRQ (Interrupt Request)** — simple explanation

Think of IRQ as a **“doorbell from hardware to CPU.”**

When something important happens in hardware (like a network packet arriving), the device doesn’t wait quietly — it **interrupts the CPU** to say:

👉 “Hey! I need attention right now.”

That signal is called an **IRQ (Interrupt Request).**

---

## 🔧 Real-world analogy

Imagine you’re working (CPU running programs):

- If no IRQ → you would have to **keep checking** the door every second (wasteful)
- With IRQ → someone **rings the bell**, and you respond immediately

So IRQ = **event-driven notification**

### The Kernel Receive Path (Ingress)

```
NAPI (New API) — MODERN LINUX RECEIVE PATH:

1. NIC raises hard IRQ
   └─► IRQ handler (very short):
       - Disable further IRQs from this NIC
       - Schedule NAPI softirq (NET_RX_SOFTIRQ)

2. Softirq runs NAPI poll loop:
   ┌─────────────────────────────────────────┐
   │ while (budget > 0 && ring has frames):  │
   │   frame = read_from_rx_ring()           │
   │   skb = build_skb(frame)               │
   │   // skb = socket buffer (sk_buff)     │
   │   napi_gro_receive(skb)                │
   │   budget--                              │
   │ if ring empty:                          │
   │   napi_complete()                       │
   │   re-enable NIC IRQs                   │
   └─────────────────────────────────────────┘

3. GRO (Generic Receive Offload):
   - Merge multiple small TCP segments into one large skb
   - Reduces per-packet processing overhead
   - E.g., 10 × 1460-byte segments → 1 × 14600-byte skb

4. Protocol processing:
   skb → netfilter (iptables) → ip_rcv() → tcp_v4_rcv()
   TCP: check seq#, reassemble, place in socket recv buffer

5. Wake up process:
   sock_def_readable() → wake_up(sk->sk_wq)
   If process is blocked on epoll_wait → it wakes up
```

### sk_buff: The Kernel's Packet Structure

```
sk_buff (skb) — KERNEL'S CENTRAL NETWORK DATA STRUCTURE:

struct sk_buff {
    // Pointers into the data buffer:
    unsigned char *head;     // start of allocated buffer
    unsigned char *data;     // start of current protocol header
    unsigned char *tail;     // end of data
    unsigned char *end;      // end of allocated buffer

    // As packet moves up the stack, 'data' pointer advances:
    // After Ethernet: data points to IP header
    // After IP:       data points to TCP header
    // After TCP:      data points to payload

    struct sock *sk;          // associated socket
    unsigned int len;         // total data length
    // ... timestamps, checksums, flags, etc.
};

MEMORY LAYOUT:
┌──────────┬───────────┬──────────┬─────────┬──────────┐
│ headroom │ Eth hdr   │ IP hdr   │ TCP hdr │ Payload  │
│          │ (14 bytes)│ (20 bytes│ (20-60  │ (message │
│          │           │  + opts) │  bytes) │  data)   │
└──────────┴───────────┴──────────┴─────────┴──────────┘
^head      ^data (moves right as headers are consumed)  ^tail
```

---

## Step 3: TCP — The Reliable Transport Under Every Message Queue

### TCP Connection Setup (Before Any Messages Flow)

```
THREE-WAY HANDSHAKE AT KERNEL LEVEL:

Producer (Client)                        Broker (Server)
     │                                        │
     │  1. SYN (seq=x)                        │
     │  ────────────────────────────────────►  │
     │  Kernel: tcp_connect()                  │  Kernel: tcp_v4_rcv()
     │  State: SYN_SENT                        │  State: SYN_RECEIVED
     │                                        │
     │  2. SYN+ACK (seq=y, ack=x+1)          │
     │  ◄────────────────────────────────────  │
     │  Kernel: tcp_rcv_synsent_state_process │  Kernel: tcp_v4_send_synack()
     │  State: ESTABLISHED                     │
     │                                        │
     │  3. ACK (ack=y+1)                      │
     │  ────────────────────────────────────►  │
     │                                        │  State: ESTABLISHED
     │                                        │
     │  Connection ESTABLISHED                 │

KERNEL DATA STRUCTURES CREATED:

  struct sock {
      // Per-connection state:
      __u32 snd_una;      // oldest unACKed seq number
      __u32 snd_nxt;      // next seq to send
      __u32 rcv_nxt;      // next expected seq to receive

      // Buffers:
      struct sk_buff_head sk_receive_queue;  // received data
      struct sk_buff_head sk_write_queue;    // data to send

      // Congestion control:
      __u32 snd_cwnd;     // congestion window (in segments)
      __u32 snd_ssthresh; // slow-start threshold

      // Socket options:
      int sk_sndbuf;      // send buffer size (default ~128KB)
      int sk_rcvbuf;      // receive buffer size (default ~128KB)
  };
```

### TCP Congestion Control — How It Affects Throughput

```
CONGESTION WINDOW (cwnd) — CONTROLS SEND RATE:

Slow Start:
  cwnd starts at 10 segments (Linux default: initcwnd=10)
  Each ACK: cwnd += 1 segment (exponential growth)

  cwnd: 10 → 20 → 40 → 80 → 160 → ...
  Until: hit ssthresh or packet loss

Congestion Avoidance (after ssthresh):
  Each RTT: cwnd += 1 segment (linear growth)
  cwnd: 160 → 161 → 162 → ...

Packet Loss → Congestion Signal:
  CUBIC (Linux default):
    cwnd = C(t - K)³ + Wmax
    Wmax = cwnd at loss
    Rapid recovery then cautious growth

Bandwidth-Delay Product (BDP):
  Max data in flight = bandwidth × RTT
  Example: 10 Gbps, 1ms RTT
    BDP = 10 Gbps × 1ms = 10 Mbit = 1.25 MB
    Need cwnd ≥ 1.25 MB / 1460 bytes ≈ 893 segments
    Socket buffers must be ≥ BDP for full utilization

WHY THIS MATTERS FOR MESSAGE QUEUES:
  - Small messages over high-latency links: TCP takes time to ramp up
  - Persistent connections: cwnd stays warm (Kafka uses long-lived connections)
  - Nagle's algorithm: delays small writes to batch them (Kafka disables: TCP_NODELAY)
```

### Nagle's Algorithm vs TCP_NODELAY

```
NAGLE'S ALGORITHM:
  If there's unACKed data AND current write < MSS:
    Buffer the write; don't send yet
    Wait until: previous data is ACKed OR buffer fills to MSS

  Problem for message queues:
    Small messages (100 bytes) → Nagle delays them 40-200ms
    Waiting for ACK before sending next small message

TCP_NODELAY:
  Disable Nagle: send immediately regardless of size
  Kafka, RabbitMQ, Redis — ALL set TCP_NODELAY
  Trade-off: more small packets, but lower latency

  setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
```

---

## Step 4: Socket API — How Broker Handles Connections

### Server Socket Setup (Broker Startup)

```
BROKER STARTUP — WHAT HAPPENS INSIDE:

1. socket(AF_INET, SOCK_STREAM, 0)
   Kernel: allocates struct sock, file descriptor
   Returns: fd (e.g., fd=3)

2. setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, ...)
   Allows restarting broker without TIME_WAIT issues

3. setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, ...)
   Multiple threads can bind to same port (kernel load-balances)
   Kafka uses this for acceptor threads

4. bind(fd, {INADDR_ANY, port 9092}, ...)
   Kernel: associates socket with IP:port
   For Kafka: port 9092
   For RabbitMQ: port 5672 (AMQP)

5. listen(fd, backlog=1024)
   Kernel creates TWO queues:
   ┌──────────────────────────────────────────┐
   │ SYN queue (incomplete connections)        │
   │   Half-open connections (SYN received,    │
   │   SYN+ACK sent, waiting for ACK)          │
   │   Size: net.ipv4.tcp_max_syn_backlog      │
   │                                           │
   │ Accept queue (complete connections)        │
   │   Fully established, waiting for accept() │
   │   Size: backlog parameter (1024)           │
   │   net.core.somaxconn = 65535              │
   └──────────────────────────────────────────┘

6. accept(listen_fd, ...)
   Kernel: dequeues from accept queue
   Returns: new fd for this specific connection
   Each producer/consumer gets its own fd
```

### Connection-Per-Producer Model

```
BROKER CONNECTION MANAGEMENT:

Kafka Broker (port 9092):
  ┌──────────────────────────────────────────────────┐
  │                 BROKER PROCESS                    │
  │                                                  │
  │  Listen socket (fd=3)  ←── accept() loop         │
  │       │                                          │
  │       ├── Producer 1 (fd=4) ─── TCP connection   │
  │       ├── Producer 2 (fd=5) ─── TCP connection   │
  │       ├── Consumer 1 (fd=6) ─── TCP connection   │
  │       ├── Consumer 2 (fd=7) ─── TCP connection   │
  │       ├── Replica broker (fd=8) ─── TCP conn     │
  │       └── ... thousands of connections           │
  │                                                  │
  │  Each connection = one file descriptor            │
  │  Linux default: ulimit -n = 1024 (MUST increase) │
  │  Production: 100,000+ file descriptors           │
  └──────────────────────────────────────────────────┘

KERNEL RESOURCES PER CONNECTION:
  - struct sock:           ~1.5 KB
  - Socket buffers:        ~256 KB (send + recv)
  - File descriptor:       ~64 bytes
  - TCP timer entries:     ~128 bytes

  10,000 connections ≈ 2.5 GB kernel memory for buffers alone
  This is why tuning net.core.rmem_max, wmem_max matters
```

---

## Step 5: I/O Multiplexing — How Broker Handles Thousands of Connections

### Why We Need epoll (Not select/poll)

```
THE PROBLEM:
  Broker has 10,000 connections (file descriptors)
  Need to know: which FDs have data ready to read?

SELECT (old, broken for scale):
  fd_set readfds;
  FD_ZERO(&readfds);
  for each connection: FD_SET(fd, &readfds);
  select(max_fd+1, &readfds, NULL, NULL, timeout);
  // Problems:
  //   1. Copies ENTIRE fd_set to kernel and back every call
  //   2. Kernel scans ALL fds linearly: O(n)
  //   3. Limited to FD_SETSIZE = 1024
  //   4. At 10K fds: ~100µs per call just for scanning

POLL (better, still O(n)):
  struct pollfd fds[10000];
  poll(fds, 10000, timeout);
  // No FD_SETSIZE limit
  // Still copies array to kernel every time
  // Still O(n) scan

EPOLL (Linux, what Kafka/RabbitMQ use):
  O(1) for monitoring, returns only READY fds
```

### epoll Internals: How It Really Works

```
EPOLL KERNEL DATA STRUCTURES:

1. epoll_create1(0) → returns epoll_fd
   Kernel allocates:
   ┌──────────────────────────────────────────┐
   │            struct eventpoll               │
   │                                          │
   │  Red-black tree (rbr):                    │
   │    Stores ALL monitored fds               │
   │    O(log n) insert/delete                 │
   │    Each node = struct epitem              │
   │    ┌──────┐                              │
   │    │ fd=4 │──┐                           │
   │    └──────┘  │  ┌──────┐                 │
   │              └──│ fd=7 │                 │
   │    ┌──────┐     └──────┘                 │
   │    │ fd=5 │──┐                           │
   │    └──────┘  │  ┌──────┐                 │
   │              └──│ fd=9 │                 │
   │                 └──────┘                 │
   │                                          │
   │  Ready list (rdllist):                    │
   │    Linked list of fds that have events    │
   │    ┌──────┐ → ┌──────┐ → ┌──────┐       │
   │    │ fd=4 │   │ fd=7 │   │ fd=9 │       │
   │    └──────┘   └──────┘   └──────┘       │
   │                                          │
   └──────────────────────────────────────────┘

2. epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &event)
   Kernel:
   - Creates epitem for this fd
   - Inserts into red-black tree: O(log n)
   - Registers CALLBACK on the fd's wait queue:
     When data arrives on this fd, the callback
     moves the epitem to the ready list
   - This callback is the KEY innovation:
     No scanning needed! Kernel tells epoll when fd is ready.

3. epoll_wait(epfd, events, maxevents, timeout)
   Kernel:
   - Check ready list
   - If empty: sleep (block) until callback fires or timeout
   - If not empty: copy ready events to userspace
   - Returns ONLY the ready fds (not all 10,000)
   - O(number of ready fds), NOT O(total fds)

THE MAGIC: CALLBACK-DRIVEN READINESS

  When TCP data arrives for fd=7:
  tcp_v4_rcv() → sock_def_readable() → ep_poll_callback()
                                          │
                                          ▼
                                    Move fd=7's epitem
                                    to ready list
                                          │
                                          ▼
                                    Wake up thread
                                    blocked on epoll_wait()
```

### Kafka's Network Thread Model (NIO / epoll)

```
KAFKA BROKER THREAD ARCHITECTURE:

┌──────────────────────────────────────────────────────────────┐
│                     KAFKA BROKER                              │
│                                                              │
│  ACCEPTOR THREAD (1 per listener)                            │
│  ┌─────────────────────────────────────────────────────┐     │
│  │ epoll on listen socket (fd=3)                        │     │
│  │ On new connection: accept() → get new_fd              │     │
│  │ Round-robin assign new_fd to a Processor thread      │     │
│  └─────────────────────────────────────────────────────┘     │
│       │              │              │                        │
│       ▼              ▼              ▼                        │
│  PROCESSOR THREADS (num.network.threads, default=3)          │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐                  │
│  │Processor 0│ │Processor 1│ │Processor 2│                  │
│  │           │ │           │ │           │                  │
│  │ epoll:    │ │ epoll:    │ │ epoll:    │                  │
│  │  fd=4,7,10│ │  fd=5,8,11│ │  fd=6,9,12│                  │
│  │           │ │           │ │           │                  │
│  │ Read req  │ │ Read req  │ │ Read req  │                  │
│  │ from fds  │ │ from fds  │ │ from fds  │                  │
│  │ → Request │ │ → Request │ │ → Request │                  │
│  │   Queue   │ │   Queue   │ │   Queue   │                  │
│  └─────┬─────┘ └─────┬─────┘ └─────┬─────┘                  │
│        │              │              │                        │
│        └──────────────┼──────────────┘                        │
│                       ▼                                      │
│  REQUEST QUEUE (shared, bounded: queued.max.requests)         │
│  ┌─────────────────────────────────────────────────────┐     │
│  │ [Req1] [Req2] [Req3] [Req4] [Req5] ...              │     │
│  └─────────────────────────────────────────────────────┘     │
│                       │                                      │
│        ┌──────────────┼──────────────┐                        │
│        ▼              ▼              ▼                        │
│  I/O THREADS (num.io.threads, default=8)                     │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐                  │
│  │ IO Thread │ │ IO Thread │ │ IO Thread │                  │
│  │           │ │           │ │           │                  │
│  │ Dequeue   │ │ Dequeue   │ │ Dequeue   │                  │
│  │ request   │ │ request   │ │ request   │                  │
│  │ Process:  │ │ Process:  │ │ Process:  │                  │
│  │  - Write  │ │  - Fetch  │ │  - Meta   │                  │
│  │    to log │ │    from   │ │  - Offsets│                  │
│  │  - Fetch  │ │    log    │ │           │                  │
│  │    from   │ │           │ │           │                  │
│  │    log    │ │           │ │           │                  │
│  └───────────┘ └───────────┘ └───────────┘                  │
│                                                              │
│  PURGATORY (delayed operations)                              │
│  ┌─────────────────────────────────────────────────────┐     │
│  │ Produce with acks=all: wait for replicas             │     │
│  │ Fetch with min.bytes: wait for enough data           │     │
│  │ Uses timing wheel + watcher for completion           │     │
│  └─────────────────────────────────────────────────────┘     │
└──────────────────────────────────────────────────────────────┘
```

---

## Step 6: TCP Keepalive and Connection Health

```
TCP KEEPALIVE — DETECTING DEAD CONNECTIONS:

Problem:
  Producer opens TCP connection to broker
  Producer's machine crashes (hard reboot / power loss)
  Broker doesn't know — TCP has no "heartbeat" by default
  Connection stays open forever (zombie connection)

TCP Keepalive (kernel level):
  After idle time, kernel sends keepalive probes:

  net.ipv4.tcp_keepalive_time  = 7200  (seconds before first probe, default 2 hours!)
  net.ipv4.tcp_keepalive_intvl = 75    (seconds between probes)
  net.ipv4.tcp_keepalive_probes = 9    (probes before giving up)

  Default: 2 hours + 9×75s = ~2 hours 11 minutes to detect dead connection!

  For message queues, we set:
    tcp_keepalive_time  = 60    (start probing after 60s idle)
    tcp_keepalive_intvl = 10    (probe every 10s)
    tcp_keepalive_probes = 6    (give up after 6 probes)
    Detection time: 60 + 6×10 = 120 seconds

APPLICATION-LEVEL HEARTBEAT (more common):
  Kafka:
    - session.timeout.ms = 45000 (consumer considered dead if no heartbeat)
    - heartbeat.interval.ms = 3000 (send heartbeat every 3s)
    - Consumer sends Heartbeat request to group coordinator
    - If missed: coordinator triggers rebalance

  RabbitMQ:
    - heartbeat = 60 (seconds; negotiated during connection setup)
    - Both sides send heartbeat frames
    - 2 missed heartbeats → connection closed

WHY BOTH?
  TCP keepalive: catches dead machines (kernel level)
  App heartbeat: catches stuck processes (application level)
    - Process might be alive but frozen (GC pause, deadlock)
    - TCP would still ACK keepalive probes!
    - App heartbeat detects this
```

---

## Step 7: What Happens in the Kernel During send()

```
DETAILED SEND PATH:

Application calls: send(fd, buffer, length, 0)

1. SYSCALL ENTRY:
   User → Kernel transition (syscall instruction on x86_64)
   Save user registers, switch to kernel stack
   Cost: ~100-200 nanoseconds

2. SOCKET LAYER:
   sock_sendmsg() → tcp_sendmsg()

3. TCP SENDMSG:
   ┌─────────────────────────────────────────────────────┐
   │ tcp_sendmsg(sk, msg, size):                         │
   │                                                     │
   │   while (data to send):                             │
   │     // Check: is send buffer full?                   │
   │     if (sk->sk_wmem_queued >= sk->sk_sndbuf):       │
   │       // BACKPRESSURE: block or return EAGAIN        │
   │       // This is how the kernel applies flow control │
   │       wait_for_memory(sk, &timeo)                   │
   │                                                     │
   │     // Allocate or reuse skb                         │
   │     skb = tcp_send_skb(sk)                          │
   │                                                     │
   │     // Copy data from userspace to kernel skb        │
   │     skb_add_data(skb, user_buffer, copy_len)        │
   │     // This is the main copy: user→kernel            │
   │                                                     │
   │     // Try to push data out                          │
   │     tcp_push(sk)                                    │
   │       → tcp_write_xmit()                            │
   │         → check cwnd (congestion window)            │
   │         → if cwnd allows: ip_queue_xmit(skb)        │
   │         → if cwnd full: data stays in write queue   │
   └─────────────────────────────────────────────────────┘

4. IP LAYER:
   ip_queue_xmit():
     - Add IP header
     - Route lookup (routing table / FIB)
     - Netfilter (iptables / nftables) traversal
     - ip_output() → ip_finish_output()

5. NEIGHBOR / ARP:
   neigh_output():
     - Look up destination MAC (ARP cache / NDP for IPv6)
     - If not cached: send ARP request, queue packet

6. DEVICE LAYER:
   dev_queue_xmit():
     - Queueing discipline (qdisc): pfifo_fast, fq, fq_codel
     - Traffic control / shaping
     - dev_hard_start_xmit() → NIC driver

7. NIC DRIVER:
   driver->ndo_start_xmit():
     - Map skb data to DMA-able memory
     - Write TX descriptor to TX ring
     - Ring doorbell (MMIO write to NIC register)
     - NIC DMA-reads data from host RAM
     - Sends on wire

8. COMPLETION:
   NIC raises TX completion interrupt
   Kernel frees skb
   Updates TCP: data is "in flight" (not yet ACKed)

TOTAL LATENCY (same datacenter):
  Application send() to wire: ~5-15 µs
  Wire propagation: ~1-5 µs
  Destination kernel processing: ~5-15 µs
  Total one-way: ~15-35 µs (within same datacenter)
```

---

## Step 8: What Happens When Broker recv() Reads Data

```
DETAILED RECEIVE PATH:

1. DATA ARRIVES AT NIC:
   NIC DMA-writes frame to RX ring buffer
   NIC coalesces interrupts (batches)
   NIC raises hard IRQ

2. HARD IRQ (very fast, ~1µs):
   disable NIC IRQ, schedule softirq

3. NAPI SOFTIRQ:
   napi_poll() → driver->poll()
     Read frames from RX ring
     Build skb for each frame
     napi_gro_receive(skb) — merge TCP segments

4. NETWORK STACK:
   ip_rcv() → tcp_v4_rcv() → tcp_rcv_established()
   ┌─────────────────────────────────────────────────────┐
   │ tcp_rcv_established(sk, skb):                       │
   │                                                     │
   │   // Fast path (most common case):                   │
   │   if (expected seq == skb->seq):                    │
   │     // In-order segment! Fast path.                  │
   │     tcp_queue_rcv(sk, skb)  // add to receive queue │
   │     tcp_send_ack()          // send ACK              │
   │                                                     │
   │   // Slow path (out-of-order, retransmit):           │
   │   else:                                             │
   │     tcp_data_queue_ofo(sk, skb)  // OOO queue       │
   │     tcp_send_dupack()            // duplicate ACK    │
   │                                                     │
   │   // Wake up application if blocked on read:         │
   │   sk->sk_data_ready(sk)                             │
   │     → ep_poll_callback()  // epoll callback         │
   │     → moves epitem to ready list                    │
   │     → wakes epoll_wait() thread                     │
   └─────────────────────────────────────────────────────┘

5. BROKER READS DATA:
   epoll_wait() returns: fd=4 is readable

   read(fd=4, userspace_buffer, 4096)
     → copy_to_user(): kernel recv buffer → userspace
     → syscall overhead: ~100-200ns for transition
     → memcpy: depends on size

   Broker now has raw bytes in userspace_buffer
   Needs to parse Kafka protocol / AMQP frames
```

---

## Step 9: Broker TCP Tuning for High Throughput

```
KERNEL PARAMETERS THAT MATTER FOR MESSAGE BROKERS:

# Socket buffer sizes (per connection)
net.core.rmem_max = 16777216        # max recv buffer: 16 MB
net.core.wmem_max = 16777216        # max send buffer: 16 MB
net.core.rmem_default = 1048576     # default recv buffer: 1 MB
net.core.wmem_default = 1048576     # default send buffer: 1 MB

# TCP autotuning (min, default, max per connection)
net.ipv4.tcp_rmem = 4096 1048576 16777216
net.ipv4.tcp_wmem = 4096 1048576 16777216

# Connection handling
net.core.somaxconn = 65535          # listen() backlog max
net.ipv4.tcp_max_syn_backlog = 65535  # SYN queue size
net.core.netdev_max_backlog = 65535   # NIC → kernel queue

# File descriptors
fs.file-max = 1000000               # system-wide FD limit
# Per-process: ulimit -n 1000000

# TIME_WAIT (broker restart)
net.ipv4.tcp_tw_reuse = 1           # reuse TIME_WAIT sockets
net.ipv4.tcp_fin_timeout = 15       # faster FIN cleanup

# Congestion control
net.ipv4.tcp_congestion_control = bbr  # Google BBR for datacenter
net.core.default_qdisc = fq           # Fair Queue for BBR

# Memory pressure
net.ipv4.tcp_mem = 786432 1048576 1572864  # pages (3GB/4GB/6GB)
  low:     below this, TCP is happy
  pressure: start pushing back on apps
  high:    refuse new connections

KAFKA-SPECIFIC SETTINGS:
  socket.send.buffer.bytes = 1048576    # broker's SO_SNDBUF
  socket.receive.buffer.bytes = 1048576 # broker's SO_RCVBUF
  socket.request.max.bytes = 104857600  # max request size (100 MB)
```

---

## Step 10: Putting It All Together — A Single Produce Request

```
END-TO-END: Producer sends "Order #12345" to Kafka

PRODUCER SIDE:
  1. Serialize: ProduceRequest → bytes (Kafka binary protocol)
     Header: API_KEY=0 (Produce), version, correlation_id, client_id
     Body: topic="orders", partition=2, records=[{key, value, timestamp}]
     Total: ~200 bytes for this message

  2. Batch: producer buffers for linger.ms (default 0) or batch.size (16KB)
     May combine with other messages to same partition

  3. send(socket_fd, request_bytes, len, 0)
     User→kernel: copy 200 bytes to kernel send buffer
     TCP: wrap in segment (seq=1000, ack=X, payload=200 bytes)
     IP: add header (src=10.0.1.5, dst=10.0.1.10, proto=TCP)
     Ethernet: add frame (src MAC, dst MAC)
     NIC: DMA read, encode to signal, send on wire

NETWORK:
  4. 200-byte frame travels at speed of light in copper/fiber
     Same rack: ~1 µs
     Cross-datacenter: ~0.5-5 ms

BROKER SIDE:
  5. NIC: receive signal → bits → frame → DMA to RX ring
  6. Kernel: NAPI poll → skb → TCP reassembly → socket recv buffer
  7. epoll_wait(): Processor thread wakes up for this fd
  8. read(): copy from kernel to userspace (200 bytes)
  9. Parse Kafka protocol: API_KEY=0 → ProduceRequest handler
  10. Validate: topic exists, partition valid, authorized
  11. Write to log: append to partition 2's active log segment
      (covered in next file: Storage Engine)
  12. If acks=all: wait for replicas (Purgatory)
  13. Build ProduceResponse: {partition=2, offset=42, error=NONE}
  14. send(fd, response_bytes, ...)
  15. Response travels back same path to producer

TOTAL LATENCY BREAKDOWN (same datacenter, acks=1):
  Producer serialize + batch:    ~0.1 ms
  Syscall + kernel send:         ~0.01 ms
  Network transfer:              ~0.05 ms
  Kernel receive + epoll:        ~0.01 ms
  Broker parse + validate:       ~0.05 ms
  Disk append (page cache):      ~0.01 ms
  Response path:                 ~0.1 ms
  ─────────────────────────────────────
  Total:                         ~0.5 - 2 ms (p50)
```

---

## 30-SECOND REVISION BOX

```
NIC: DMA ring buffers, interrupt coalescing, signal↔bits
KERNEL: sk_buff, NAPI poll, GRO, TCP reassembly
TCP: 3-way handshake, cwnd, congestion control, Nagle vs NODELAY
SOCKET: listen → accept → per-connection fd, backlog queues
EPOLL: red-black tree + ready list + callbacks = O(ready) not O(total)
BROKER THREADS: Acceptor → Processor (epoll) → IO threads → Purgatory
TUNING: buffer sizes, somaxconn, file descriptors, BBR, tcp_mem
LATENCY: produce round-trip ~0.5-2ms same DC
```

---

**Prev: [[08_Question-List]] | Next: [[10_Internals-Kafka-Storage-Engine]]**