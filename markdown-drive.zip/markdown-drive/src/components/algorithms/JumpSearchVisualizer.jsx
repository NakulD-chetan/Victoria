import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: jump-search */
function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  const n = a.length;
  const stepSize = Math.max(1, Math.floor(Math.sqrt(n)));
  steps.push({ type: 'init', array: [...a], pointers: { jump: 0, hi: n - 1 }, target, stepSize });
  let prev = 0;
  let jump = 0;
  while (jump < n && a[Math.min(jump, n - 1)] < target) {
    steps.push({ type: 'jump', array: [...a], pointers: { jump: Math.min(jump, n - 1), hi: n - 1 }, target, stepSize });
    prev = jump;
    jump += stepSize;
    if (jump >= n) break;
  }
  const right = Math.min(jump, n - 1);
  steps.push({ type: 'block', array: [...a], pointers: { jump: prev, hi: right }, target, prev, right });
  let j = prev;
  while (j <= right && a[j] <= target) {
    steps.push({ type: 'scan', array: [...a], pointers: { jump: prev, hi: right, j }, target });
    if (a[j] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { j }, target, idx: j });
      return steps;
    }
    j += 1;
  }
  steps.push({ type: 'notfound', array: [...a], pointers: { jump: prev, hi: right }, target });
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

export default function JumpSearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Jump search for ${target} (√n jumps)` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    if (step.type === 'init') {
      for (let i = 0; i < n; i++) colors[i] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Jump step ≈ ${step.stepSize}` });
    } else if (step.type === 'jump') {
      for (let i = 0; i < n; i++) {
        colors[i] = i <= pointers.jump ? 'active' : 'eliminated';
      }
      colors[pointers.jump] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Jump land at index ${pointers.jump}` });
    } else if (step.type === 'block') {
      for (let i = 0; i < n; i++) {
        colors[i] = i >= step.prev && i <= step.right ? 'active' : 'eliminated';
      }
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: `Linear scan block [${step.prev}, ${step.right}]` });
    } else if (step.type === 'scan') {
      for (let i = 0; i < n; i++) {
        colors[i] = i >= pointers.jump && i <= pointers.hi ? 'active' : 'eliminated';
      }
      colors[pointers.j] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Scan index ${pointers.j}` });
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.idx] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at ${step.idx}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Not found' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      ...(found != null ? { found } : {}),
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
