# Design Rate Limiter — Mental Model

> **Permanent Recall:** Rate limiting is fundamentally **"counting requests in a time window."** Five algorithms = five ways to count. **Token bucket** and **sliding window counter** are the most practical. "Water faucet" analogy: faucet = request source; bucket = allowance. Place at **API gateway** or **middleware**—never rely solely on client-side.

---

## Core Insight: Counting in a Time Window

```
Request arrives → Count it (or consume token) → Within limit? → Allow : Reject(429)
```

Every algorithm answers: **How many requests have we seen for this identity in the relevant time window?**

---

## Water Faucet Analogy

| Analogy | Rate Limiter |
|---------|--------------|
| **Faucet** (water source) | Client making requests |
| **Bucket** | Allowance / capacity |
| **Water drops** | Individual requests |
| **Bucket fills** | Token bucket: tokens refill over time |
| **Bucket drains** | Leaky bucket: constant drain rate |
| **Bucket capacity** | Max burst size |

**Token bucket:** Faucet fills bucket at fixed rate; each request takes water out. No water = reject.

**Leaky bucket:** Bucket has hole at bottom; water drains at constant rate. Incoming water (requests) can overflow = reject.

---

## The Five Algorithms

### 1. Token Bucket

**Mechanism:** Bucket holds tokens (max capacity). Tokens refill at fixed **refill rate** per second. Each request consumes 1 token. No token = reject.

| Pros | Cons |
|-----|------|
| Allows bursts up to bucket size | Slightly more complex than fixed window |
| Smooth refill; no boundary spike | Need to track last refill time + tokens |
| Industry standard (Twitter, Stripe) | |

```
Time 0:  bucket = 10 tokens, rate = 2/sec
Request 1–10: allowed (10 → 0)
Request 11: rejected
+0.5 sec: 1 token refilled → request allowed
+1 sec:   2 more tokens → 3 total
```

> **FAANG Tip:** Token bucket is the most commonly cited in interviews. Know refill rate vs capacity.

---

### 2. Leaky Bucket

**Mechanism:** Requests enter a queue; processed (leak) at fixed **drain rate**. Queue full = reject. Output rate is constant (smooth traffic).

| Pros | Cons |
|-----|------|
| Smooth output; no bursts | Burst requests may be queued or rejected |
| Predictable downstream load | Doesn't allow intentional bursts |
| Good for pacing | Less common in modern APIs |

```
Drain rate = 5 req/sec, queue size = 10
10 requests at t=0 → 5 go through, 5 queued
Next second: 5 more drain; queue empties
```

---

### 3. Fixed Window Counter

**Mechanism:** Count requests in fixed windows (e.g., minute 1, minute 2). If count &lt; limit, allow.

| Pros | Cons |
|-----|------|
| Simple: one counter + window boundary | **Boundary spike:** 100 at :59 + 100 at :01 = 200 in 2 sec |
| Easy to implement (Redis INCR) | Not accurate for sliding semantics |
| Memory efficient | |

```
Limit 100/min:
Window 10:00–10:01 → 100 requests at 10:00:59 → all allowed
Window 10:01–10:02 → 100 requests at 10:01:01 → all allowed
= 200 requests in 2 seconds!
```

---

### 4. Sliding Window Log

**Mechanism:** Store timestamp of each request. Count requests with `timestamp > now - window`. If count &lt; limit, allow.

| Pros | Cons |
|-----|------|
| Accurate; no boundary spike | **Memory heavy:** O(requests) per identity |
| True sliding window | Redis sorted set grows unbounded |
| | Expensive to trim old entries |

---

### 5. Sliding Window Counter (Hybrid)

**Mechanism:** Combine fixed window + sliding:  
`count = prev_window_count * (1 - elapsed/period) + current_window_count`  
Or: approximate with two fixed windows and interpolate.

| Pros | Cons |
|-----|------|
| **Best practical trade-off** | Slightly less accurate than log |
| O(1) memory | Small boundary edge cases remain |
| Accurate enough for most APIs | |
| No unbounded storage | |

> **FAANG Tip:** For "design a rate limiter," sliding window counter is the answer when interviewer asks for accuracy without the memory cost of sliding log.

---

## Algorithm Comparison

| Algorithm | Memory | Accuracy | Boundary spike | Burst support | Complexity |
|-----------|--------|----------|----------------|---------------|------------|
| Fixed window | O(1) | Low | Yes | No | Low |
| Sliding window log | O(n) | High | No | No | Medium |
| Sliding window counter | O(1) | Medium-high | Minor | Yes (if designed) | Medium |
| Token bucket | O(1) | High | No | Yes | Medium |
| Leaky bucket | O(n) or O(1) | High | No | No (smooths) | Medium |

---

## Where to Place the Rate Limiter

```
                    ┌─────────────────────────────────────────┐
                    │            Client / Browser               │
                    └─────────────────────┬─────────────────────┘
                                          │
    ┌─────────────────────────────────────┼─────────────────────────────────────┐
    │                                     │                                     │
    ▼                                     ▼                                     ▼
┌─────────┐                        ┌─────────────────┐                    ┌─────────────┐
│ Client  │   (soft limit only)    │  API Gateway /   │   (preferred)      │ Middleware  │
│ side    │   Can be bypassed      │  Load Balancer  │   Centralized       │ in app      │
└─────────┘                        └────────┬────────┘                    └──────┬──────┘
                                           │                                      │
                                           └──────────────────┬───────────────────┘
                                                              │
                                                              ▼
                                                    ┌─────────────────┐
                                                    │ Dedicated Rate  │
                                                    │ Limiter Service │
                                                    │ (high scale)    │
                                                    └─────────────────┘
```

| Placement | Pros | Cons |
|-----------|------|------|
| **Client-side** | Reduces unnecessary calls | Bypassable; soft limit only |
| **API gateway** | Centralized; single enforcement point | Gateway becomes critical path |
| **Middleware (app)** | Flexible; per-service rules | Every service must run it |
| **Dedicated service** | Isolated; can scale independently | Extra network hop; latency |

---

## Decomposition

| Component | Responsibility |
|-----------|-----------------|
| **Identifier extraction** | User ID, IP, API key from request |
| **Rule engine** | Match endpoint + identity → limit config (e.g., 100/min) |
| **Counter store** | Redis (or similar) for distributed state |
| **Algorithm logic** | Token bucket / sliding window / etc. |
| **Response** | 429 + Retry-After when limited |

---

## Decision Flow

```
Request → Extract identity (user/IP/key)
       → Lookup rule (endpoint + identity → limit, window)
       → Execute algorithm (get count / consume token)
       → count <= limit? → 200 + pass through
       → count > limit?  → 429 + Retry-After + reject
```
