import { uid } from '../state/types.js';
import { CODE_TEMPLATES } from './code-templates.js';
import { idealArrayWidth, idealArrayHeight } from './array-layout.js';
import { pickDefaultsFor } from './widget-defaults.js';

/**
 * Default shapes for each widget type. Kept here (not in the components)
 * so the drag-drop code can ask for a sane initial size without importing
 * three React components.
 */
/** Smallest box when drawing a widget (drag smaller sizes clamp up). */
export const WIDGET_MIN_SIZE = {
  code: { w: 280, h: 200 },
  'sql-pad': { w: 280, h: 200 },
  note: { w: 160, h: 120 },
  array: { w: 200, h: 72 },
  json: { w: 320, h: 220 },
  csv: { w: 360, h: 220 },
  'linked-list': { w: 280, h: 130 },
  stack: { w: 180, h: 220 },
  queue: { w: 280, h: 130 },
  tree: { w: 320, h: 240 },
  'hash-map': { w: 300, h: 220 },
  agent: { w: 320, h: 320 },
  'mermaid-diagram': { w: 400, h: 300 },
  calculator: { w: 260, h: 340 },
  'file-converter': { w: 400, h: 280 },
  progress: { w: 320, h: 240 },
};

export const WIDGET_DEFAULTS = {
  code: {
    w: 520, h: 340,
    data: {
      language: 'cpp',
      code: CODE_TEMPLATES.cpp,
      output: '',
      /** Panel + editor base tone; Monaco theme is derived in CodeWidget */
      chromeBg: '#1f1f1f',
    },
  },
  'sql-pad': {
    w: 520, h: 340,
    data: {
      language: 'sqlite',
      code: CODE_TEMPLATES.sqlite,
      output: '',
      chromeBg: '#1f1f1f',
    },
  },
  note: {
    w: 260, h: 180,
    data: { text: '', color: '#fefce8' },
  },
  array: {
    w: 440, h: 140,
    data: { values: [0, 1, 2, 3, 4], highlights: {}, title: 'Array' },
  },
  json: {
    w: 500, h: 360,
    data: {
      mode: 'tree',
      source: '{\n  "name": "InkDrop",\n  "ready": true,\n  "features": ["canvas", "code", "data"]\n}',
      fileName: '',
      fileError: '',
    },
  },
  csv: {
    w: 560, h: 360,
    data: {
      mode: 'table',
      delimiter: 'auto',
      source: 'name,score,status\nAda,100,complete\nLinus,98,complete\nGrace,97,in progress',
      fileName: '',
      fileError: '',
    },
  },
  'linked-list': {
    w: 520, h: 150,
    data: { title: 'Linked List', values: [10, 20, 30, 40] },
  },
  stack: {
    w: 240, h: 300,
    data: { title: 'Stack', values: ['A', 'B', 'C'] },
  },
  queue: {
    w: 500, h: 150,
    data: { title: 'Queue', values: ['A', 'B', 'C', 'D'] },
  },
  tree: {
    w: 520, h: 330,
    data: { title: 'Binary Tree', values: [1, 2, 3, 4, 5, 6, 7] },
  },
  'hash-map': {
    w: 420, h: 310,
    data: {
      title: 'Hash Map',
      entries: [
        { key: 'name', value: 'Ada' },
        { key: 'language', value: 'C++' },
        { key: 'level', value: 'advanced' },
      ],
    },
  },
  agent: {
    w: 430, h: 500,
    data: {
      chromeBg: '#12141b',
      accentColor: '#7c83ff',
      composer: '',
      status: 'idle',
      workspaceReady: false,
      linkedWidgetIds: [],
      suggestions: [
        'I want to do coding practice',
        'Help me revise graphs',
        'Start a system design session',
      ],
      messages: [],
      planItems: [],
    },
  },
  'mermaid-diagram': {
    w: 500, h: 400,
    data: { title: 'Flowchart', code: 'graph TD;\n  A-->B;', theme: 'dark' },
  },
  calculator: {
    w: 300, h: 400,
    data: { title: 'Calculator' },
  },
  'file-converter': {
    w: 480, h: 320,
    data: { title: 'File Converter', conversionType: 'PDF to PPT' },
  },
  progress: {
    w: 360, h: 280,
    data: { title: 'Processing', steps: ['Step 1', 'Step 2'], currentStepIndex: 0 },
  },
};

const DEFAULT_WIDGET_STYLE = {
  stroke: '#94a3b8',
  fill: 'transparent',
  strokeWidth: 1,
  opacity: 1,
  dash: 'solid',
};

/**
 * @param {string} widgetType
 * @param {number} x
 * @param {number} y
 * @param {number} [w]  drawn width (optional — uses type default)
 * @param {number} [h]  drawn height (optional)
 * @param {{ style?: object }} [opts] optional style from active tool options
 */
export function createWidgetElement(widgetType, x, y, w, h, opts = {}) {
  const d = WIDGET_DEFAULTS[widgetType];
  if (!d) throw new Error('Unknown widget: ' + widgetType);
  const mins = WIDGET_MIN_SIZE[widgetType] || { w: 120, h: 80 };
  const fw = w != null ? Math.max(mins.w, w) : d.w;
  const fh = h != null ? Math.max(mins.h, h) : d.h;

  const persisted = pickDefaultsFor(widgetType);
  const widgetData = applyDefaults(widgetType, JSON.parse(JSON.stringify(d.data)), persisted);
  const style = {
    ...DEFAULT_WIDGET_STYLE,
    ...(persisted.strokeColor ? { stroke: persisted.strokeColor } : {}),
    ...(persisted.strokeWidth ? { strokeWidth: persisted.strokeWidth } : {}),
    ...(opts.style || {}),
  };

  const el = {
    id: uid('widget'),
    type: 'widget',
    widgetType,
    widgetData,
    x,
    y,
    w: fw,
    h: fh,
    z: 0,
    isDeleted: false,
    style,
    createdAt: Date.now(),
  };
  if (widgetType === 'array') {
    const vals = el.widgetData?.values || [];
    el.w = Math.max(fw, idealArrayWidth(vals.length));
    el.h = Math.max(fh, idealArrayHeight());
  }
  return el;
}

function applyDefaults(widgetType, base, persisted) {
  const out = { ...base };
  if (widgetType === 'code') {
    if (persisted.language && CODE_TEMPLATES[persisted.language]) {
      out.language = persisted.language;
      out.code = CODE_TEMPLATES[persisted.language];
    }
    if (persisted.fontFamily) out.fontFamily = persisted.fontFamily;
    if (persisted.fontSize) out.fontSize = persisted.fontSize;
    if (persisted.chromeBg) out.chromeBg = persisted.chromeBg;
  } else if (widgetType === 'note') {
    if (persisted.color) out.color = persisted.color;
    if (persisted.textColor) out.textColor = persisted.textColor;
    if (persisted.fontFamily) out.fontFamily = persisted.fontFamily;
    if (persisted.fontSize) out.fontSize = persisted.fontSize;
  } else if (widgetType === 'array') {
    if (persisted.chromeBg) out.chromeBg = persisted.chromeBg;
    if (persisted.valueFontSize) out.valueFontSize = persisted.valueFontSize;
    if (persisted.valueColor) out.valueColor = persisted.valueColor;
  } else if (widgetType === 'agent') {
    if (persisted.chromeBg) out.chromeBg = persisted.chromeBg;
    if (persisted.accentColor) out.accentColor = persisted.accentColor;
  } else {
    if (persisted.chromeBg) out.chromeBg = persisted.chromeBg;
    if (persisted.accentColor) out.accentColor = persisted.accentColor;
  }
  return out;
}

export const CODE_LANGS = [
  { id: 'cpp',        label: 'C++ 17' },
  { id: 'python',     label: 'Python 3' },
  { id: 'java',       label: 'Java' },
  { id: 'javascript', label: 'JavaScript' },
];

export const CODE_MONACO_LANG = {
  cpp: 'cpp', python: 'python', java: 'java', javascript: 'javascript',
};

export const SQL_LANGS = [
  { id: 'sqlite', label: 'SQLite (Local)' },
  { id: 'mysql', label: 'MySQL' },
  { id: 'oracle', label: 'Oracle' },
];

export const SQL_MONACO_LANG = {
  sqlite: 'sql', mysql: 'mysql', oracle: 'sql',
};
