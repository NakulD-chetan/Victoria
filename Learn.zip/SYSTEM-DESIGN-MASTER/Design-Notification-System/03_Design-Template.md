# Design Notification System — Design Template

> **Permanent Recall:** Architecture = Event source → Notification Service → User Preference Check → Rate Limiter → Priority Queue → Channel-specific workers (Push, SMS, Email) → Third-party providers (APNS/FCM/Twilio/SendGrid) → Delivery tracking. Device token management, template engine, scheduling service are critical components.

---

## High-Level Architecture (ASCII)

```
┌─────────────────┐     ┌──────────────────────────────────────────────────┐
│  Event Sources  │     │           Notification Service API               │
│ (Order, Auth,   │────►│  POST /notify {user_id, type, channel?, payload}  │
│  Marketing)     │     └─────────────────────┬────────────────────────────┘
└─────────────────┘                           │
                                              ▼
                    ┌─────────────────────────────────────────┐
                    │         Idempotency Check (Redis)       │
                    │         Dedupe by (user_id + event_id)  │
                    └─────────────────────┬───────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────────────────────────┐
                    │      User Preference Service (DB)       │
                    │  Opt-in: push/SMS/email per type        │
                    └─────────────────────┬───────────────────┘
                                          │
                                          ▼
                    ┌─────────────────────────────────────────┐
                    │      Rate Limiter (Redis / Token Bucket)│
                    │  Per-user, per-channel, global          │
                    └─────────────────────┬───────────────────┘
                                          │
              ┌───────────────────────────┼───────────────────────────┐
              ▼                           ▼                           ▼
    ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
    │   Push Queue    │       │    SMS Queue    │       │   Email Queue   │
    │   (Kafka/SQS)   │       │   (Kafka/SQS)   │       │   (Kafka/SQS)   │
    └────────┬────────┘       └────────┬────────┘       └────────┬────────┘
             │                          │                          │
             ▼                          ▼                          ▼
    ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
    │  Push Worker    │       │   SMS Worker     │       │  Email Worker   │
    │  Template +     │       │  Template +     │       │  Template +     │
    │  Token Resolver │       │  Phone Resolver │       │  Email Resolver │
    └────────┬────────┘       └────────┬────────┘       └────────┬────────┘
             │                          │                          │
             ▼                          ▼                          ▼
    ┌─────────┴─────────┐     ┌─────────────────┐     ┌─────────────────┐
    │ APNS    │   FCM   │     │     Twilio       │     │    SendGrid      │
    │ (iOS)   │(Android)│     │  (SMS Provider)  │     │  (Email Provider)│
    └─────────┴─────────┘     └─────────────────┘     └─────────────────┘
             │                          │                          │
             └──────────────────────────┼──────────────────────────┘
                                        ▼
                    ┌─────────────────────────────────────────┐
                    │     Delivery Tracking (DB + Analytics)   │
                    │  delivered, opened, clicked, failed      │
                    └─────────────────────────────────────────┘
```

---

## Scheduling Service

```
┌─────────────────┐     ┌─────────────────────┐     ┌─────────────────┐
│  Scheduled Jobs │────►│  Delay Queue /      │────►│  Notification   │
│  (e.g., 24h     │     │  Timer (Redis,      │     │  Service        │
│   reminder)     │     │  SQS delayed, etc.) │     │  (same pipeline) │
└─────────────────┘     └─────────────────────┘     └─────────────────┘
```

- **Immediate:** Event → API → Queue → Worker → Provider
- **Delayed:** Event → API → Scheduling Service → Store (scheduled_at) → Timer fires → Enqueue → same pipeline

---

## Device Token Management

| Operation | Flow |
|-----------|------|
| **Register** | Client (iOS/Android) gets token from APNS/FCM → POST to backend → Store `user_id, device_id, token, platform` |
| **Update** | Token can change (app reinstall); upsert on each app launch |
| **Invalidate** | Provider returns invalid → remove token; stop sending to that device |
| **Multi-device** | User may have N devices; send to all valid tokens for push |

---

## API Design

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/notify` | Send notification; `{user_id, event_type, payload, idempotency_key?, channel?, scheduled_at?}` |
| GET | `/notifications/{id}/status` | Delivery status (sent, delivered, opened, failed) |
| POST | `/users/{id}/preferences` | Update opt-in/out per channel and type |
| POST | `/users/{id}/devices` | Register device token (push) |
| DELETE | `/users/{id}/devices/{device_id}` | Remove device token |

---

## Template Engine

- **Storage:** Templates in DB (e.g., `order_shipped_push`, `order_shipped_email`)
- **Format:** `"Hi {{user_name}}, your order {{order_id}} has shipped!"`
- **Rendering:** Worker fetches template, substitutes `payload` keys, localizes if needed
- **Per-channel:** Same event → different templates for push (short) vs email (long)

---

## Data Model

| Table | Key Fields |
|-------|------------|
| **notifications** | id, user_id, event_type, channel, status, provider_id, created_at, idempotency_key |
| **user_preferences** | user_id, channel, notification_type, opted_in |
| **device_tokens** | user_id, device_id, token, platform (ios/android), updated_at |
| **templates** | id, event_type, channel, body, subject (email), locale |
| **delivery_events** | notification_id, event (delivered/opened/clicked), timestamp |

---

## Rate Limiting Strategy

| Scope | Limit | Storage |
|-------|-------|---------|
| **Per-user, per-channel** | e.g., 5 marketing emails/day | Redis: `user:{id}:email:day` → count |
| **Per-user, global** | e.g., 50 notifications/day total | Redis: `user:{id}:notif:day` |
| **Global** | Provider limits (Twilio 100 req/sec) | Token bucket per provider |

---

## Mermaid: End-to-End Flow

```mermaid
flowchart LR
    A[Event] --> B[API]
    B --> C[Idempotency]
    C --> D[Preferences]
    D --> E[Rate Limit]
    E --> F{Priority}
    F --> G[Push Queue]
    F --> H[SMS Queue]
    F --> I[Email Queue]
    G --> J[APNS/FCM]
    H --> K[Twilio]
    I --> L[SendGrid]
    J --> M[Tracking]
    K --> M
    L --> M
```

---

## Retry and Dead-Letter

| Attempt | Action |
|---------|--------|
| 1–3 | Exponential backoff; retry same provider |
| 4+ | Move to dead-letter queue; alert; manual review |
| Invalid token | Remove token; no retry |
| Provider down | Circuit breaker; queue backs up; retry when healthy |

---

## Sharding and Scaling

- **Queues:** Partition by `user_id % N` for even distribution
- **Workers:** Stateless; scale horizontally with queue depth
- **Device tokens:** Shard by `user_id`
- **Preferences:** Cache in Redis; invalidate on update
