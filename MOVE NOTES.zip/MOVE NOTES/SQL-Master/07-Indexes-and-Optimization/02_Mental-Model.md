# Indexes and Optimization — Mental Model

---

## Book index analogy

```
Table = book pages (data)
Index = alphabetical index at back

WITHOUT index: read every page to find "SQL"
WITH index:    look up "SQL" → page 42 → go directly
```

---

## Clustered vs non-clustered

```
CLUSTERED (1 per table):
  Data rows ARE the leaf nodes of the B-tree.
  PK usually → data physically sorted by PK.

NON-CLUSTERED:
  Separate B-tree → leaf contains pointer (row locator) → follow to data.
  Multiple allowed.
```

---

## Composite index + leftmost prefix

```
INDEX on (A, B, C)

Can serve:      WHERE A = ?
                WHERE A = ? AND B = ?
                WHERE A = ? AND B = ? AND C = ?

Cannot serve:   WHERE B = ?          ← skips A
                WHERE C = ?          ← skips A, B
```

**Hinglish:** Composite index = phone book sorted by **last name, first name**. You can search by last name alone, but not first name alone.

---

## EXPLAIN decision tree (simplified)

```
Is there an index on WHERE col?
  YES → Index scan (or index-only if covering)
  NO  → Seq scan (full table)

Are rows sorted for ORDER BY?
  YES → No extra sort
  NO  → Filesort (extra pass)
```

---

*Next: [[03_Coding-Template]]*
