# Monitoring and Observability — Concept

> **Permanent Recall:** **Monitoring** = known questions, dashboards, alerts. **Observability** = ability to answer unknown questions from telemetry. The **three pillars**: **Logs** (ELK: Elasticsearch, Logstash, Kibana; structured vs unstructured), **Metrics** (Prometheus, Grafana; RED/USE methods), **Traces** (Jaeger, Zipkin, OpenTelemetry). **Four golden signals**: latency, traffic, errors, saturation. **SLI/SLO/SLA** = measure, target, contract. **Health checks**: liveness vs readiness probes. **APM** (New Relic, Datadog) for application performance.

---

## Monitoring vs Observability

| Aspect | Monitoring | Observability |
|--------|------------|---------------|
| **Focus** | Known questions, predefined dashboards | Unknown unknowns, ad-hoc discovery |
| **Approach** | Alert when threshold breached | Explore data to find root cause |
| **Data** | Pre-selected metrics | Rich telemetry: logs, metrics, traces |
| **Mindset** | "Is it broken?" | "Why is it broken?" |

> **FAANG Tip:** "Monitoring tells you something is wrong. Observability helps you understand *why*."

---

## The Four Golden Signals

| Signal | What to Measure | Examples |
|--------|----------------|----------|
| **Latency** | Request duration (p50, p95, p99) | API response time, DB query time |
| **Traffic** | Requests per second, throughput | RPS, bytes/sec |
| **Errors** | Error rate, failure count | 5xx rate, failed transactions |
| **Saturation** | Resource utilization (CPU, memory, disk) | CPU %, queue depth |

```mermaid
flowchart LR
    subgraph Signals
        L[Latency]
        T[Traffic]
        E[Errors]
        S[Saturation]
    end
    L --> D[Dashboard]
    T --> D
    E --> D
    S --> D
```

---

## Three Pillars of Observability

### 1. Logs

**Structured vs Unstructured:**

| Type | Example | Pros | Cons |
|------|---------|------|------|
| **Structured** | `{"level":"error","msg":"DB timeout","service":"api","duration_ms":5000}` | Queryable, aggregatable | Requires discipline |
| **Unstructured** | `ERROR: Database connection timed out` | Easy to emit | Hard to search, parse |

**ELK Stack:**

```
[Apps] → Logstash (parse, enrich) → Elasticsearch (store, index) → Kibana (visualize)
```

| Component | Role |
|-----------|------|
| **Elasticsearch** | Search engine for log storage and indexing |
| **Logstash** | Log pipeline: parse, transform, ship |
| **Kibana** | Visualization, dashboards, discovery |

---

### 2. Metrics

| Metric Type | Description | Example |
|-------------|-------------|---------|
| **Counter** | Monotonically increasing | Total requests, errors |
| **Gauge** | Point-in-time value | CPU %, active connections |
| **Histogram** | Distribution of values | Latency percentiles (p50, p95, p99) |

**Prometheus + Grafana:** Prometheus scrapes metrics; Grafana visualizes.

**RED Method (Services/APIs):**

| Metric | What | Example |
|--------|------|---------|
| **Rate** | Requests per second | `http_requests_total` rate |
| **Errors** | Error count/rate | 5xx, exceptions |
| **Duration** | Request latency | p95, p99 latency |

**USE Method (Infrastructure):**

| Metric | What | Example |
|--------|------|---------|
| **Utilization** | % time busy | CPU %, disk I/O % |
| **Saturation** | Degree of queuing | Queue depth, swap |
| **Errors** | Error count | Disk errors, failed I/O |

---

### 3. Traces (Distributed Tracing)

**Purpose:** Follow a request across services to find latency bottlenecks.

```
Request: [API] → [Auth] → [DB] → [Cache]
         |        |        |        |
         span1    span2    span3   span4
         └──────── trace_id ────────┘
```

| Tool | Role |
|------|------|
| **Jaeger** | Trace collection, query, visualization |
| **Zipkin** | Lightweight tracing |
| **OpenTelemetry** | Vendor-neutral instrumentation, trace ID propagation |

**Trace ID propagation:** Each span carries `trace_id`; propagated via HTTP headers (e.g., `X-Trace-Id`, W3C Trace Context).

---

## Alerting

| Concept | Description |
|---------|-------------|
| **Threshold-based** | Alert when metric > X (e.g., CPU > 90%) |
| **Anomaly detection** | ML-based; alert on unexpected patterns |
| **PagerDuty** | On-call management, escalation, incident response |

> **FAANG Tip:** "Alert on *causes* (e.g., DB connection pool exhausted) not just *symptoms* (high latency)."

---

## SLI / SLO / SLA

| Term | Definition | Example |
|------|------------|--------|
| **SLI** (Service Level Indicator) | Measurable metric | Error rate = 0.1% |
| **SLO** (Service Level Objective) | Target for SLI | Error rate < 0.5% |
| **SLA** (Service Level Agreement) | Contract with consequences | 99.9% uptime or credits |

---

## Health Checks (Kubernetes)

| Probe Type | Purpose | Fails When |
|------------|---------|------------|
| **Liveness** | Is the process alive? | Restart container if failing |
| **Readiness** | Ready to receive traffic? | Remove from load balancer |

---

## APM (Application Performance Monitoring)

**Tools:** New Relic, Datadog, Dynatrace.

**Capabilities:** Auto-instrumentation, real-user monitoring (RUM), traces, metrics, logs in one platform.

---

## Log Aggregation at Scale

- **Sharding** by time, tenant, or service
- **Retention policies** (e.g., 7 days hot, 30 days warm)
- **Sampling** at high volume (e.g., 1% of debug logs)

---

## Metrics Cardinality

**Cardinality** = unique label combinations. High cardinality (e.g., `user_id` per metric) → storage explosion.

> **FAANG Tip:** "Avoid high-cardinality labels (user_id, request_id). Use for logs/traces, not metrics."

---

## 30-SECOND REVISION BOX

```
MONITORING vs OBSERVABILITY: known vs unknown questions
PILLARS: Logs (ELK), Metrics (Prometheus, RED/USE), Traces (Jaeger, OTel)
GOLDEN SIGNALS: latency, traffic, errors, saturation
SLI/SLO/SLA: measure, target, contract
HEALTH: liveness (alive?) readiness (traffic?)
APM: New Relic, Datadog
CARDINALITY: avoid user_id in metrics
```

---

**Next: [[02_Mental-Model]]**
