# Design Uber — Concept

> **Permanent Recall:** Uber is a ride-sharing platform connecting riders with drivers. Core flows: **rider requests ride** → **match with nearby driver** → **real-time tracking** → **ETA calculation** → **surge pricing** → **trip history** → **payments** → **ratings**. Key challenges: real-time location updates (<1s), low-latency matching (<30s), high availability. Scale: 20M trips/day.

---

## Problem Statement

Design a ride-sharing platform like **Uber** that:
- Allows riders to request rides and get matched with nearby drivers
- Provides real-time driver location tracking during trips
- Calculates accurate ETAs for driver arrival and trip completion
- Implements dynamic surge pricing based on demand
- Stores trip history and processes payments
- Supports mutual ratings between riders and drivers

---

## Functional Requirements

| Requirement | Description |
|-------------|-------------|
| **Request Ride** | Rider specifies pickup/dropoff; system finds available nearby drivers |
| **Driver Matching** | Match rider with nearest available driver; notify both parties |
| **Real-time Tracking** | Rider sees driver location; driver sees rider location; updates <1s |
| **ETA Calculation** | Estimated time for driver to reach rider and for trip completion |
| **Surge Pricing** | Dynamic pricing based on supply/demand ratio in geographic area |
| **Trip History** | Store completed trips; riders and drivers can view past trips |
| **Payments** | Process payment after trip; support multiple payment methods |
| **Ratings** | Riders rate drivers; drivers rate riders; 1–5 stars |

---

## Non-Functional Requirements

| Requirement | Target | Rationale |
|-------------|--------|-----------|
| **Real-time location** | <1s update latency | Users expect live map updates |
| **Matching latency** | <30s from request to match | Rider waits; poor UX if slower |
| **High availability** | 99.9%+ uptime | People depend on it for transport |
| **Scale** | 20M trips/day | Major cities; peak hours spike |
| **Geospatial accuracy** | Sub-kilometer precision | Matching and ETA depend on location |

> **FAANG Tip:** Location update frequency is critical. "Real-time" is vague; "GPS updates every 4 seconds, <1s propagation to rider app" shows precision.

---

## Capacity Estimation

**Assumptions:**
- 20M trips/day globally
- ~15M active drivers during peak (drivers who are online/available)
- Location update every 4 seconds from active drivers
- Peak traffic 2× average (rush hour, events)

**Location Update QPS:**

| Metric | Calculation | Value |
|--------|-------------|-------|
| **Active drivers** | 15M during peak | — |
| **Updates per driver** | 1 per 4 seconds | 0.25 Hz |
| **Total location updates** | 15M × 0.25 | **3.75M updates/s** |

**Trip Data:**

| Metric | Calculation | Value |
|--------|-------------|-------|
| **Trips/day** | — | 20M |
| **Trip record size** | ~1–2 KB (metadata, route, timestamps) | — |
| **Storage/day** | 20M × 2 KB | ~40 GB/day |
| **5 years retention** | 40 GB × 365 × 5 | ~73 TB |

**Ride requests:** ~20M/day → ~230 requests/s average; peak ~460/s.

---

## Key Constraints

| Constraint | Implication |
|------------|-------------|
| **Geospatial** | Need efficient lat/lng storage and "find nearest K" queries |
| **Real-time** | WebSocket or long-poll for location push; not batch processing |
| **High write rate** | 3.75M location writes/s; in-memory + eventual persistence |
| **Low matching latency** | Sub-second geospatial query; pre-indexed by region |

---

## Traffic Patterns

| Pattern | Characteristic |
|---------|-----------------|
| **Location updates** | Continuous stream; 4s interval per driver; write-heavy |
| **Ride requests** | Bursty; concentrated in cities, peak hours |
| **Trip lifecycle** | Request → Match → En route → In progress → Complete; state machine |
| **Surge pricing** | Recalculated periodically per region; read-heavy during request flow |

```mermaid
flowchart LR
    A[Rider requests] --> B[Matching Service]
    B --> C[Find nearby drivers]
    C --> D[Send request to K drivers]
    D --> E{First accept?}
    E -->|Yes| F[Trip created]
    E -->|No| G[Expand search / retry]
```

---

## 30-SECOND REVISION BOX

**Out of Scope (base design):** UberEats, UberPool, scheduled rides, driver incentives. Can be added as extensions.

**Success metrics:** Match latency, ETA accuracy, surge fairness, payment success rate, availability.

**Key dependencies:** Geospatial indexing (Geohash/QuadTree/S2), Redis GEO or custom store, WebSocket for tracking, payment gateway.

**Design scope:** Focus on matching and real-time tracking first; pricing and payment are layered.

**Comparison:** Similar to Lyft, Grab, Ola; differs in specific matching algorithms and surge logic.

**Interview tip:** Lead with "3.75M location updates per second" and "geospatial indexing" to signal production thinking.

---

```
PROBLEM: Ride-sharing; match rider with nearby driver; real-time tracking
FUNCTIONAL: Request, match, track, ETA, surge, history, payments, ratings
NFRs: <1s location latency, <30s match, 99.9% availability, 20M trips/day
LOCATION UPDATES: 3.75M/s (15M drivers × 0.25 Hz)
STORAGE: ~40 GB/day trip data; PB-scale for history
KEY DEPS: Geospatial index, Redis GEO, WebSocket
```

---

**Next: [[02_Mental-Model]]**
