# What is a Data Warehouse — Practice

> "Practice turns definitions into decisions you can defend in a room full of stakeholders."

---

## Quick Recall

**Q:** What is a data warehouse in one sentence?  
**A:** A subject-oriented, integrated, time-variant, non-volatile collection of data used for decision support.

**Q:** How does a DW differ from an operational database for an e-commerce order system?  
**A:** OLTP systems optimize for fast, consistent transactions; a DW optimizes for analytical reads across history and many entities.

**Q:** What does "non-volatile" mean for retail sales history?  
**A:** Data is loaded and retained for analysis; corrections append or version rather than overwrite facts as if they never happened.

**Q:** Why is "integrated" important when merging web, store, and marketplace orders?  
**A:** Conformed keys and consistent attributes let you compare channels on the same grain and definitions.

**Q:** What is "time-variant" in the context of daily revenue reporting?  
**A:** The warehouse preserves how measures and dimensions change over time so trends and point-in-time views are meaningful.

---

## Interview Questions

**1. Define a data warehouse without buzzwords.**  
**Model answer:** I describe it as the analytics-facing store where we land cleaned, historical business data—like orders, customers, and inventory snapshots—modeled so analysts and applications can run heavy aggregations without hurting transactional systems. For our retail platform, that means separating reporting workloads from checkout and inventory reservation. The goal is trustworthy answers at scale, not faster shopping carts.

**2. Is a data warehouse always a separate physical system?**  
**Model answer:** Not necessarily. It is logically separate: different schemas, SLAs, and access patterns. It might share infrastructure with a lake or lakehouse, but the workload isolation and modeling conventions are what matter for e-commerce scale. What we avoid is letting exploratory analytics compete with payment authorization on the same narrow operational service tier.

**3. How do you explain OLTP vs OLAP to a product manager?**  
**Model answer:** OLTP answers "can this customer complete this purchase right now?" OLAP answers "which product categories drove margin last quarter by region?" Same business, different questions, different indexing and table design. I also mention cost: OLTP is priced for reliability under bursts; OLAP is priced for scan-heavy history.

**4. What business problems does a warehouse solve first for retail?**  
**Model answer:** Unified reporting across channels, cohort and basket analysis, supply chain visibility, and finance-grade revenue recognition when definitions differ between systems. Practically, I start with the metrics that executives already fight about because that is where integration pays off fastest.

**5. Can a spreadsheet be a data warehouse?**  
**Model answer:** Not in the architectural sense. A warehouse implies governed ingestion, scalable storage, and repeatable pipelines. Spreadsheets are useful for ad hoc work but lack lineage, concurrency, and operational rigor. If a spreadsheet is the system of record for revenue, you will eventually hit reconciliation pain at month end.

**6. Who are the primary consumers of a data warehouse?**  
**Model answer:** BI tools, data science notebooks, finance close processes, and operational analytics apps—any consumer that needs trusted aggregates and historical context. For omnichannel retail, store ops tablets and partner portals sometimes read curated warehouse views rather than raw OLTP.

**7. What is the relationship between a warehouse and "a single source of truth"?**  
**Model answer:** The warehouse is often positioned as the curated analytical source of truth, but truth is defined by governance: conformed dimensions, documented metrics, and reconciliation to finance—not the label on the database. I am explicit that political alignment matters as much as technology.

**8. How is a warehouse different from an operational data store (ODS)?**  
**Model answer:** An ODS integrates near-current operational data for cross-system workflows. A warehouse emphasizes historical depth, analytical modeling, and BI performance. Retailers may run both: ODS for order orchestration visibility, warehouse for quarterly category reviews.

---

## Scenario-Based Exercises

**Scenario 1 — Channel reporting conflict**  
Store POS and the e-commerce OMS both report "revenue" but returns are netted differently. Design how the warehouse resolves this.  
**Solution:** Treat source-specific revenue as staging facts; publish a conformed `fact_sales` with documented business rules (gross, returns, shipping revenue flags). Document the mapping in a metric dictionary. Implementation uses ETL with explicit transformation steps and sign conventions for returns.

```sql
-- Illustrative reconciliation view: align channel rules before publishing
SELECT channel_code,
       SUM(CASE WHEN line_type = 'SALE' THEN line_amount ELSE 0 END) AS gross_sales,
       SUM(CASE WHEN line_type = 'RETURN' THEN -line_amount ELSE 0 END) AS returns,
       SUM(CASE WHEN line_type = 'SALE' THEN line_amount ELSE 0 END)
         - SUM(CASE WHEN line_type = 'RETURN' THEN line_amount ELSE 0 END) AS net_sales
FROM staging.orders_unified
GROUP BY channel_code;
```

**Scenario 2 — Historical marketing spend**  
Marketing wants year-over-year ad spend by campaign. Operational tools only retain 90 days.  
**Solution:** Land daily campaign spend into a warehouse fact at campaign-day grain with slowly changing campaign attributes in a dimension. Example grain check:

```sql
SELECT campaign_id, spend_date, SUM(spend_amount) AS daily_spend
FROM dw.fact_marketing_spend
GROUP BY campaign_id, spend_date;
```

**Scenario 3 — Executives ask for "real-time DW"**  
**Solution:** Clarify latency needs. Near-real-time micro-batches into a serving layer may suffice for operational dashboards; true real-time often belongs to streaming or OLTP replicas. Position the warehouse for minutes-to-hours freshness for most retail KPIs while routing sub-minute needs to the right tier.

**Scenario 4 — Prove value in 30 days**  
**Solution:** Pick one high-visibility metric (for example, gross merchandise value by channel) with a single governed definition, reconcile to finance, and serve it through one dashboard. Capture before-and-after manual effort to quantify value. Sketch the flow as OMS (OLTP) → extract or CDC → staging → curated `fact_sales` and dimensions → semantic layer → dashboards, keeping payment PII out of wide analyst tables.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Equating "big database" with "warehouse" | Volume alone does not imply modeling or governance | Emphasize subject areas, conformed data, and analytical workloads |
| Claiming warehouses replace OLTP | Interviewers probe operational knowledge | Position as complementary: OLTP for transactions, DW for analytics |
| Ignoring non-volatility nuance | Corrections happen in retail constantly | Explain Type 2 dimensions, reversals, and audit trails |
| Overpromising real-time everything | Latency trade-offs are real | Tie freshness to use case: finance vs ops tiles |
| Confusing reporting replica with DW | A mirror still reflects OLTP design | Call out modeling, metrics, and integration as differentiators |
| Saying "we load everything daily so it is a DW" | Ingest frequency is not the definition | Anchor on Inmon characteristics and analytical consumption |

---

## One-Liner Answers

- A data warehouse is an integrated, historical store optimized for analytical queries across the business.
- OLTP serves transactions; OLAP serves aggregation and exploration at scale.
- Non-volatile means we keep history for analysis rather than deleting facts when systems change.
- Integration means one set of conformed customer and product keys across channels.
- Time-variant means we can report how KPIs and attributes evolved, not only today's snapshot.
- The warehouse is governed analytics infrastructure, not a copy-paste of every OLTP table.
