# Transactions & ACID Properties — Complete Guide

> **Transaction = Ek group of SQL operations jo ek unit ke taur pe execute hone chahiye.**
> Ya toh SARI operations succeed karein, ya KUCH BHI nahi ho (all or nothing).
> Banking systems, e-commerce — har jagah transactions critical hain!

---

## What is a Transaction?

> **Definition:** A transaction is a sequence of one or more SQL operations that are treated as a single logical unit of work. Either ALL operations succeed (COMMIT), or NONE of them take effect (ROLLBACK).

### Classic Example: Bank Transfer

```
Rahul se Priya ko ₹5000 transfer karo:

Step 1: Rahul ke account se ₹5000 minus karo
Step 2: Priya ke account mein ₹5000 plus karo

Kya hoga agar Step 1 ke baad system crash ho jaye?
→ Rahul ke paise kat gaye but Priya ko mile nahi! ← DISASTER!
```

```sql
-- Transaction ensures both steps happen together
START TRANSACTION;
    UPDATE accounts SET balance = balance - 5000 WHERE name = 'Rahul';
    UPDATE accounts SET balance = balance + 5000 WHERE name = 'Priya';
COMMIT;

-- Agar kuch galat ho:
START TRANSACTION;
    UPDATE accounts SET balance = balance - 5000 WHERE name = 'Rahul';
    -- Error occurs here!
ROLLBACK;  -- Rahul ke paise wapas!
```

---

## ACID Properties — Interview MUST KNOW!

> **Definition:** ACID is a set of 4 properties that guarantee database transactions are processed reliably.

```
A = Atomicity      → All or Nothing
C = Consistency    → Valid state to valid state
I = Isolation      → Transactions don't interfere
D = Durability     → Once committed, permanent
```

---

### A — Atomicity (All or Nothing)

> **Definition:** Either ALL operations in a transaction complete successfully, or NONE of them take effect. No partial execution.

```
Transaction: Transfer ₹5000
  Step 1: Debit Rahul  ← Done
  Step 2: Credit Priya ← FAILS!

  Atomicity → Step 1 bhi UNDO ho jayega!
  Result: Dono accounts same state mein jaise pehle the.
```

> **Analogy:** ATM se paise nikalo — ya toh paise niklenge AUR balance katega, ya KUCH nahi hoga.

---

### C — Consistency

> **Definition:** A transaction takes the database from one VALID state to another VALID state. All constraints (PK, FK, CHECK, etc.) must be satisfied before and after the transaction.

```
Before: Rahul = ₹10000, Priya = ₹5000  (Total = ₹15000)
After:  Rahul = ₹5000,  Priya = ₹10000 (Total = ₹15000) ✅

Invalid: Rahul = ₹5000,  Priya = ₹5000 (Total = ₹10000) ❌
→ ₹5000 gayab! Consistency violated!
```

> **Consistency ensures:** Business rules aur constraints hamesha maintained rahein.

---

### I — Isolation

> **Definition:** Multiple transactions executing concurrently should not interfere with each other. Each transaction should feel like it's the ONLY one running.

```
Transaction 1: Rahul → Priya ₹5000 transfer
Transaction 2: Rahul ka balance check karo

Without Isolation:
  T1: Debit Rahul (balance = ₹5000)
  T2: Read Rahul balance → ₹5000 (WRONG! Transfer abhi complete nahi hua)
  T1: ROLLBACK → Rahul wapas ₹10000
  → T2 ne galat value read kar li!

With Isolation:
  T2 waits until T1 completes → correct value read hota hai
```

---

### D — Durability

> **Definition:** Once a transaction is committed, the changes are PERMANENT — even if system crashes, power goes off, or server restarts.

```
COMMIT executed → Data disk pe write ho gaya
→ Server crash ho jaye, reboot ke baad bhi data safe rahega.
```

> **How?** Transaction logs (Write-Ahead Logging — WAL). Changes pehle log mein likhte hain, phir disk pe.

---

## TCL Commands — Transaction Control

### 1. START TRANSACTION / BEGIN

```sql
START TRANSACTION;
-- or
BEGIN;
```

### 2. COMMIT — Changes Save Karo

```sql
START TRANSACTION;
    UPDATE accounts SET balance = balance - 5000 WHERE name = 'Rahul';
    UPDATE accounts SET balance = balance + 5000 WHERE name = 'Priya';
COMMIT;  -- Done! Changes permanent.
```

### 3. ROLLBACK — Changes Undo Karo

```sql
START TRANSACTION;
    UPDATE accounts SET balance = balance - 5000 WHERE name = 'Rahul';
    -- Oops, wrong amount!
ROLLBACK;  -- Sab undo! Rahul ka balance wapas original.
```

### 4. SAVEPOINT — Checkpoint Banao

```sql
START TRANSACTION;
    UPDATE accounts SET balance = balance - 5000 WHERE name = 'Rahul';
    SAVEPOINT sp1;  -- Checkpoint!

    UPDATE accounts SET balance = balance + 5000 WHERE name = 'Priya';
    -- Priya ka update galat ho gaya!

    ROLLBACK TO sp1;  -- Sirf Priya ka update undo, Rahul ka intact!

    UPDATE accounts SET balance = balance + 5000 WHERE name = 'Amit';  -- Correct person
COMMIT;
```

> **SAVEPOINT** = Partial rollback allowed! Poori transaction rollback karne ki zaroorat nahi.

---

## Transaction States

```
┌──────────┐     ┌──────────┐     ┌───────────────┐
│  Active   │────→│ Partially │────→│   Committed   │
│          │     │ Committed│     │  (Success!)   │
└──────────┘     └──────────┘     └───────────────┘
     │                │
     │ (Error)        │ (Error)
     ↓                ↓
┌──────────┐     ┌───────────────┐
│  Failed   │────→│   Aborted     │
│          │     │ (Rolled Back) │
└──────────┘     └───────────────┘
```

| State | Meaning |
|-------|---------|
| **Active** | Transaction chal raha hai |
| **Partially Committed** | Last operation done, commit pending |
| **Committed** | Sab save ho gaya — permanent |
| **Failed** | Error aaya — continue nahi kar sakta |
| **Aborted** | Rollback ho gaya — sab undo |

---

## Isolation Levels — VERY Important for Interviews!

> **Definition:** Isolation levels define how much transactions can see each other's uncommitted changes. Higher isolation = more protection but slower performance.

### Concurrency Problems:

| Problem | Kya Hota Hai |
|---------|-------------|
| **Dirty Read** | Uncommitted data read kar liya (doosre transaction ka) |
| **Non-Repeatable Read** | Same row do baar read kiya, value change ho gayi |
| **Phantom Read** | Same query do baar run kiya, extra rows aa gayi |

---

### Dirty Read Example:

```
T1: UPDATE salary SET amount = 50000 WHERE id = 1;  (NOT COMMITTED yet)
T2: SELECT amount FROM salary WHERE id = 1;  → Reads 50000 (DIRTY!)
T1: ROLLBACK;  → Amount wapas purana ho gaya
T2: Used 50000 which NEVER existed in committed state! ← WRONG!
```

### Non-Repeatable Read Example:

```
T1: SELECT salary FROM emp WHERE id = 1;  → Reads 40000
T2: UPDATE emp SET salary = 50000 WHERE id = 1; COMMIT;
T1: SELECT salary FROM emp WHERE id = 1;  → Reads 50000 (DIFFERENT!)
→ Same query, different result within same transaction!
```

### Phantom Read Example:

```
T1: SELECT * FROM emp WHERE dept = 'IT';  → 5 rows
T2: INSERT INTO emp (name, dept) VALUES ('New Guy', 'IT'); COMMIT;
T1: SELECT * FROM emp WHERE dept = 'IT';  → 6 rows (PHANTOM ROW!)
→ Extra row appeared like a ghost!
```

---

### 4 Isolation Levels:

```sql
-- Set isolation level
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
```

| Level | Dirty Read | Non-Repeatable Read | Phantom Read | Performance |
|-------|-----------|-------------------|-------------|-------------|
| **READ UNCOMMITTED** | ✅ Possible | ✅ Possible | ✅ Possible | Fastest |
| **READ COMMITTED** | ❌ Prevented | ✅ Possible | ✅ Possible | Fast |
| **REPEATABLE READ** | ❌ Prevented | ❌ Prevented | ✅ Possible | Medium |
| **SERIALIZABLE** | ❌ Prevented | ❌ Prevented | ❌ Prevented | Slowest |

> **Yaad kaise rakhen (Lowest → Highest protection):**
> 1. **READ UNCOMMITTED** — Sab kuch dikhega (no protection)
> 2. **READ COMMITTED** — Sirf committed data dikhega (default in PostgreSQL, Oracle)
> 3. **REPEATABLE READ** — Same row wahi value degi baar baar (default in MySQL InnoDB)
> 4. **SERIALIZABLE** — Full protection, jaise serial execution (slowest)

---

### Isolation Levels — Trade-off:

```
READ UNCOMMITTED ←→ SERIALIZABLE
    ↑                     ↑
    │                     │
  Fast                  Slow
  Less Safe           Most Safe
  More Concurrency    Less Concurrency
```

> **Interview Answer:** "Higher isolation level means better data consistency but lower concurrency and performance. The choice depends on the application requirements — banking needs SERIALIZABLE, social media feed can use READ COMMITTED."

---

## Deadlock

> **Definition:** Two or more transactions are waiting for each other to release locks, creating a cycle where no one can proceed.

```
T1: Lock Row A → Wants to lock Row B (waiting for T2)
T2: Lock Row B → Wants to lock Row A (waiting for T1)

→ Both waiting forever! DEADLOCK!

    T1 ──wants B──→ T2
    ↑                │
    └──wants A───────┘
```

### How to Handle Deadlocks:

| Method | Kya Karo |
|--------|---------|
| **Detection** | Database automatically detect karta hai, ek transaction abort karta hai |
| **Timeout** | Agar lock zyada der lage → abort |
| **Prevention** | Always lock in SAME ORDER (A before B) |
| **Keep transactions short** | Jitna chhota transaction, utna kam deadlock chance |

```sql
-- MySQL: Deadlock detected automatically
-- One transaction gets rolled back with error:
-- ERROR 1213: Deadlock found when trying to get lock
```

---

## Locking Mechanisms (Bonus)

### Types of Locks:

| Lock Type | Kya Karta Hai | Symbol |
|-----------|---------------|--------|
| **Shared Lock (S)** | Read allowed, write blocked | Multiple readers OK |
| **Exclusive Lock (X)** | No read, no write by others | Single writer only |

### Lock Compatibility:

```
         Shared(S)  Exclusive(X)
Shared     ✅         ❌
Exclusive  ❌         ❌
```

> Shared + Shared = OK (multiple readers)
> Shared + Exclusive = BLOCKED
> Exclusive + Exclusive = BLOCKED

### Row-Level vs Table-Level Lock:

| Feature | Row-Level Lock | Table-Level Lock |
|---------|---------------|-----------------|
| **Scope** | Single row | Entire table |
| **Concurrency** | High (others can access other rows) | Low (nobody can access table) |
| **Overhead** | More (lock per row) | Less |
| **Use case** | OLTP (many small transactions) | DDL operations, bulk updates |

---

## Auto-Commit

```sql
-- MySQL: Auto-commit ON by default (har statement auto-commit hota hai)
SET autocommit = 0;  -- Turn off auto-commit (manual transaction control)
SET autocommit = 1;  -- Turn on auto-commit (default)
```

> **Jab autocommit ON hai:**
> Har `INSERT`, `UPDATE`, `DELETE` automatically committed ho jaata hai.
> Rollback nahi kar sakte unless explicitly `START TRANSACTION` likho.

---

## Quick Memory Card

| Concept | One Line | Interview Hint |
|---------|----------|----------------|
| Transaction | Group of SQL as one unit | All or Nothing |
| Atomicity | Sab ho ya kuch na ho | Bank transfer analogy |
| Consistency | Valid state → Valid state | Constraints maintained |
| Isolation | Transactions don't interfere | Concurrent execution safe |
| Durability | Committed = Permanent | Survives crashes |
| COMMIT | Save changes permanently | Point of no return |
| ROLLBACK | Undo all changes | Sab wapas |
| SAVEPOINT | Partial rollback point | Checkpoint |
| Dirty Read | Read uncommitted data | READ UNCOMMITTED |
| Phantom Read | New rows appear | REPEATABLE READ can't prevent |
| Deadlock | Circular wait for locks | Keep transactions short |
| SERIALIZABLE | Strongest isolation | Safest but slowest |
| READ COMMITTED | Default in PostgreSQL/Oracle | Most common in production |
| Shared Lock | Multiple readers OK | Read lock |
| Exclusive Lock | Single writer only | Write lock |

> **ACID Trick:** "**A**ll or nothing, **C**onstraints met, **I**solated execution, **D**isk-permanent"

---

*Notes Source: Database Transactions & ACID Properties + Interview preparation material*
