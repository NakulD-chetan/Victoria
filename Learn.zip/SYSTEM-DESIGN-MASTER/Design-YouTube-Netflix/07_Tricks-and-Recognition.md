# Design YouTube/Netflix — Tricks and Recognition

> **Permanent Recall:** Video streaming = **two systems** (upload + stream), **transcoding = DAG**, **CDN handles 90%+ reads**, **adaptive bitrate = HLS/DASH**, **metadata is small** (NoSQL), **video storage is massive** (object store + CDN). This is the go-to question for testing **media handling** and **CDN knowledge**.

---

## Key Insights (Tricks)

| # | Insight | Why It Matters |
|---|---------|----------------|
| 1 | **Video = two systems** | Upload path (write) and streaming path (read) are completely different; never conflate |
| 2 | **Transcoding = DAG** | Multiple resolutions encoded in parallel; not a single black box |
| 3 | **CDN handles 90%+ of reads** | Origin should rarely serve end users; design for cache hit |
| 4 | **Adaptive bitrate = HLS/DASH** | Chunks at multiple qualities; client selects; reduces buffering |
| 5 | **Metadata is small** | NoSQL (Cassandra); videos in object store; never store video in DB |
| 6 | **Video storage is massive** | Object store + CDN; 5× multiplier for resolutions; PB-scale |
| 7 | **Go-to for media + CDN** | Interviewers use this to test if you understand video systems |

---

## Recognition: What Problem Is This?

```
If they say: "Design YouTube" / "Design Netflix"
They mean:  Video streaming platform — upload, transcode, stream
They test:  Upload pipeline, transcoding, CDN, adaptive bitrate, metadata
```

---

## One-Liner Answers

| Question | One-Liner |
|----------|-----------|
| Where to store video? | Object store (S3/GCS); never DB |
| How to deliver fast? | CDN; 90%+ cache hit; push popular |
| How to handle transcoding? | Async queue + workers; FFmpeg DAG; multiple resolutions |
| Adaptive bitrate? | HLS/DASH; chunks at 240p–4K; client selects |
| Metadata? | Cassandra or similar; small records |
| Search? | Elasticsearch; sync from metadata |

---

## Pattern Recognition

```
YouTube/Netflix ≈ Video pipeline (transcode + CDN) + Metadata + Recommendations
                ≠ Simple file hosting (no transcoding)
                ≠ Live streaming only (different architecture)
```

---

## Mermaid: System Recognition

```mermaid
flowchart TD
    A[Design YouTube/Netflix] --> B[Upload Pipeline]
    A --> C[Streaming Pipeline]
    B --> D[Transcoding = DAG]
    B --> E[Object Store]
    C --> F[CDN]
    C --> G[Adaptive Bitrate]
    A --> H[Metadata + Search]
```

---

## Interview Shortcuts

1. **First sentence:** "Video has two pipelines — upload and streaming. Upload is slow and compute-heavy due to transcoding. Streaming is fast and CDN-heavy."
2. **Transcoding:** "FFmpeg produces multiple resolutions in parallel, segments into HLS chunks, stores in object store."
3. **CDN:** "90%+ of requests from CDN; push popular content; pull long-tail."
4. **Adaptive bitrate:** "HLS or DASH — client picks quality based on network; reduces buffering."
5. **Metadata:** "Cassandra for metadata; Elasticsearch for search; video stays in object store."

---

## When to Mention Each Trick

| Context | Trick to Emphasize |
|---------|-------------------|
| "How does upload work?" | Two paths; transcoding DAG; async |
| "How do you deliver globally?" | CDN; 90%+ hit; push vs pull |
| "Avoid buffering?" | Adaptive bitrate; HLS/DASH |
| "Where is video stored?" | Object store; metadata in DB |
| "Add live streaming" | Different pipeline; real-time transcode |

---

## Combined Test Recognition

YouTube/Netflix = **Media system** (upload, transcode, storage, delivery) + **CDN** (global, edge) + **Metadata** (search, recommendations). Interviewers want to see you handle media and CDN; metadata is secondary unless they ask.

---

## Quick Wins to Mention

- **Resumable upload** — Multipart for large files
- **Content ID** — Copyright detection in pipeline
- **Pre-push** — Viral content to all POPs
- **Eventual vs strong** — Metadata eventual; payments strong

---

## Differentiation from Other Designs

| vs Instagram | vs TikTok | vs Twitch |
|--------------|-----------|------------|
| Video = transcoding (heavy) | Short-form; different chunk profile | Live-first; real-time |
| Photos = resize (lighter) | Similar CDN + adaptive | VOD similar |
| Both need CDN | Both need recommendations | Both need low latency |

---

## Recap: 7 Tricks

1. Two systems — upload + stream
2. Transcoding = DAG
3. CDN 90%+
4. Adaptive bitrate = HLS/DASH
5. Metadata small (NoSQL)
6. Video storage massive (object + CDN)
7. Go-to for media + CDN testing

---

## Final Recognition

When you hear "Design YouTube" or "Design Netflix," immediately think: **two pipelines**, **transcoding is the expensive part**, **CDN for delivery**, **adaptive bitrate**. Lead with the upload pipeline and transcoding — that's the differentiator.

---

## Memory Hook

"**TAC CDN** — Two paths, Async transcoding, Chunks (HLS/DASH), CDN 90%." Or: "**Upload = produce, Stream = broadcast.**"

---

## One-Slide Summary

Upload: Raw → Transcode (DAG) → Processed → CDN. Stream: CDN → Chunks (adaptive). Metadata: Cassandra + Elasticsearch.
