# How Payment System Works - In Depth (Easy Language)

> Companion to: [06-How-Payment-System-Works.md](06-How-Payment-System-Works.md)

---

## What Problem Does a Payment System Solve?

When you take an Uber ride, the payment seems simple: ride ends, you get charged. But behind the scenes, it's incredibly complex:

1. Your card details must be **secure** (hackers shouldn't get them)
2. You must be charged **exactly once** (not zero, not twice)
3. The money must be **split** correctly (driver, Uber, taxes)
4. If anything **fails** midway, everything must be handled gracefully
5. Every penny must be **trackable** for auditing

---

## Tokenization - Why Uber Never Sees Your Card Number

### The Problem

If Uber stores your credit card number on their servers:
- A hacker who breaches Uber gets millions of credit card numbers
- Uber must comply with PCI-DSS (expensive security audits)
- A disgruntled employee could steal card data

### The Solution: Tokenization

```
What happens when you add a card to Uber:

Step 1: You enter card number in the app
  Card: 4111-1111-1111-1111

Step 2: Card info goes DIRECTLY to Stripe (payment provider)
  ⚠️ Your card number NEVER touches Uber's servers!
  Uber app → Stripe SDK → Stripe servers

Step 3: Stripe returns a TOKEN
  Token: "tok_1KqZ4j2eZvKYlo2C3nBqFH8b"
  
Step 4: Uber stores only the TOKEN
  Uber's database: {user: "you", payment_token: "tok_1KqZ..."}
```

**The token is:**
- Useless if stolen (only works with Uber's Stripe account)
- Reusable (Uber can charge you again with the same token)
- Safe (not a real card number)

**Analogy**: Instead of giving the valet your house key, you give them a special parking token that only works in that specific parking lot. If someone steals the token, they can't break into your house.

---

## The Payment Flow - What Happens When Your Ride Ends

### Step-by-Step (The Money Journey)

```
1. RIDE ENDS → Uber calculates fare: $25.00

2. UBER → STRIPE: "Charge token tok_1KqZ... for $25.00"
   (includes idempotency key: "ride_abc123_payment_1")

3. STRIPE → VISA NETWORK: "Charge card ending 1111 for $25.00"

4. VISA → YOUR BANK (Issuing Bank): "User wants to pay $25.00"

5. YOUR BANK checks:
   - Is there $25.00 in the account? YES
   - Is the card blocked? NO
   - Is this suspicious? NO
   → Approves the charge

6. APPROVAL flows back:
   Your Bank → Visa → Stripe → Uber

7. UBER updates payment status: "COMPLETED"

8. DISBURSEMENT ENGINE kicks in:
   $25.00 split:
   - Driver: $18.75 (75%)
   - Uber:   $5.00  (20%)
   - Taxes:  $1.25  (5%)
```

### Two-Step Charging: Authorization vs Capture

```
Authorization (HOLD):
  "Hey bank, hold $25 for Uber"
  → Money reserved but NOT transferred yet
  → Like a hotel putting a hold on your card at check-in

Capture (CHARGE):
  "OK bank, actually take the $25 now"
  → Money actually moves
  → Like the hotel charging you at checkout
```

Why two steps? Sometimes the final amount changes (tip added, route changed). The authorization holds the money; the capture finalizes the actual amount.

---

## Idempotency - The #1 Rule of Payment Systems

### The Nightmare Scenario

```
Your phone sends payment request to Uber:
  "Charge $25 for ride abc123"

Network is slow... phone shows spinner... you wait...

After 10 seconds, your phone thinks: "Request must have failed!"
  → Automatically RETRIES: "Charge $25 for ride abc123"

But the FIRST request actually went through!
Now you're charged TWICE: $25 + $25 = $50 for one ride!
```

### How Idempotency Fixes This

Every payment request includes a unique **idempotency key**:

```
First request:
  "Charge $25, idempotency_key = ride_abc123_pay_1"
  → Stripe processes it, saves the key
  → Returns: "SUCCESS, charge_id = ch_001"

Retry (same key!):
  "Charge $25, idempotency_key = ride_abc123_pay_1"
  → Stripe sees: "I already processed ride_abc123_pay_1!"
  → Returns the ORIGINAL result: "SUCCESS, charge_id = ch_001"
  → Does NOT charge again!
```

**Idempotent means**: doing the same thing twice gives the same result as doing it once.

**Real-world analogy**: Pressing an elevator button. Press it once = elevator comes. Press it 10 more times = elevator still comes once. The extra presses have no additional effect.

---

## The Disbursement Engine - Splitting the Money

### Why Is This Complex?

A single Uber payment involves multiple parties:

```
You pay: $25.00

Where does it go?
  ┌─────────────────────────────────────┐
  │ Driver payout:    $18.75 (75%)      │ → Sent to driver's bank
  │ Uber platform:    $5.00  (20%)      │ → Uber's revenue
  │ Government taxes: $1.25  (5%)       │ → Tax authorities
  └─────────────────────────────────────┘
```

### Driver Payouts Are Batched

Uber doesn't send $18.75 to the driver immediately after each ride. Instead:

```
Monday: 20 rides → $350 accumulated
Tuesday: 15 rides → $250 accumulated
Wednesday: 18 rides → $310 accumulated
...
Weekly settlement: Bank transfer $2,100 to driver's account
```

**Why batch?** Each bank transfer costs Uber a fee (~$0.25). If a driver does 100 rides/week, that's 100 × $0.25 = $25 in fees. One weekly transfer = $0.25. Batching saves massive costs at scale.

---

## Double-Entry Ledger - The Financial Audit Trail

### What Is Double-Entry Bookkeeping?

Every transaction has TWO entries: a **debit** and a **credit**. They must always balance.

```
Ride payment of $25:

Entry 1 (DEBIT):  Rider Account    -$25.00  (money leaves rider)
Entry 2 (CREDIT): Uber Holding     +$25.00  (money enters Uber's holding)

Disbursement:
Entry 3 (DEBIT):  Uber Holding     -$18.75  (money leaves holding)
Entry 4 (CREDIT): Driver Account   +$18.75  (money enters driver)

Entry 5 (DEBIT):  Uber Holding     -$5.00
Entry 6 (CREDIT): Uber Revenue     +$5.00

Entry 7 (DEBIT):  Uber Holding     -$1.25
Entry 8 (CREDIT): Tax Liability    +$1.25

Balance check: -$25 + $25 - $18.75 + $18.75 - $5 + $5 - $1.25 + $1.25 = $0 ✓
```

**Why is this important?**
- **Auditing**: Accountants can trace every penny
- **Reconciliation**: Compare your records with bank statements
- **Dispute resolution**: "Where did my money go?" → check the ledger
- **Regulatory compliance**: Required by law for financial systems
- **Immutable**: Entries are NEVER deleted or modified (append-only)

---

## Risk Engine - Catching Fraud

### What Does the Risk Engine Do?

Before processing a payment, the risk engine scores it:

```
Payment request: $500 ride in NYC

Risk checks:
  ✓ Location: NYC (matches user's usual city)
  ✓ Amount: $500 (high but not unusual for long ride)
  ✗ Time: 3 AM (unusual for this user)
  ✗ Device: new phone (never seen before)
  
  Risk score: 72/100 (medium-high)
  
  Action: Require additional verification (3D Secure/OTP)
```

### Common Fraud Patterns

```
Velocity attack: 50 transactions in 5 minutes from same card → BLOCK
Stolen card: Card reported stolen, transaction attempted → BLOCK
Geographic anomaly: Card used in India and US within 1 hour → FLAG
First-use pattern: Brand new account, immediately large purchase → FLAG
```

---

## Error Handling - When Things Go Wrong

### Transient Errors (Temporary Problems)

```
Network timeout after sending charge request:
  → Did the charge go through? We don't know!
  → RETRY with same idempotency key
  → If charge went through: get original result back (no double charge)
  → If charge didn't go through: charge processes now

Retry strategy (exponential backoff):
  Attempt 1: wait 1 second
  Attempt 2: wait 2 seconds
  Attempt 3: wait 4 seconds
  Attempt 4: wait 8 seconds
  Max retries: 5 → then send to Dead Letter Queue
```

### Permanent Errors (Give Up Immediately)

```
"Insufficient funds" → Don't retry (user needs to add money)
"Card expired" → Don't retry (user needs to update card)
"Invalid card number" → Don't retry (wrong card info)
```

### Circuit Breaker Pattern

```
Normal state: all requests go to Stripe
  ↓ (Stripe starts failing 50% of the time)

Circuit OPENS: stop sending requests to Stripe!
  → Return error immediately to users
  → Don't waste time on requests that will fail
  → Prevents Stripe from being overwhelmed further
  ↓ (wait 30 seconds)

Half-open: send ONE test request to Stripe
  → If it succeeds: circuit CLOSES (back to normal)
  → If it fails: circuit stays OPEN (wait more)
```

**Analogy**: When a road is flooded, you put up a "road closed" sign instead of letting 1000 cars drive in and get stuck. Periodically, you send one car to check if the road is clear.

### Dead Letter Queue

```
After 5 retries, payment still failing:
  → Don't lose it!
  → Put it in a "Dead Letter Queue"
  → Human operator reviews it later
  → Either manually processes or refunds the user
```

---

## The Complete Architecture Flow

```
1. USER adds card in app
   → Card info → Stripe SDK (NOT Uber servers) → Token returned
   → Token stored in Uber's DB

2. RIDE ends, fare calculated: $25.00

3. RISK ENGINE evaluates:
   → Risk score: LOW → proceed
   → (if HIGH → require OTP/3D Secure)

4. PAYMENT SERVICE sends charge:
   → POST to Stripe with token + idempotency key
   → Stripe → Visa → Bank → approval
   → Response: APPROVED

5. LEDGER SERVICE records:
   → DEBIT rider $25, CREDIT holding $25

6. DISBURSEMENT ENGINE (async, via Kafka):
   → Split: driver $18.75, platform $5.00, tax $1.25
   → Record each split in ledger
   → Queue driver payout for weekly settlement

7. NOTIFICATION SERVICE:
   → Push notification: "Trip ended. $25.00 charged."
   → Email receipt
```

---

## Revision Flashcards

**Q: Why does Uber never store credit card numbers?**
A: Card data goes directly to the payment provider (Stripe) via their SDK. Uber only stores a token (safe reference). This avoids PCI-DSS compliance burden and prevents card data theft in a breach.

**Q: What is idempotency and why is it critical for payments?**
A: Idempotency means doing the same operation multiple times gives the same result as once. Every payment request has a unique idempotency key. If retried with the same key, the payment provider returns the original result without charging again.

**Q: What is double-entry bookkeeping?**
A: Every transaction has a debit and credit entry that must balance. It's an append-only, immutable ledger that enables auditing, reconciliation, and regulatory compliance.

**Q: What is a circuit breaker?**
A: When an external service keeps failing, stop sending requests (circuit opens). Periodically test with one request. If it works, resume (circuit closes). Prevents cascading failures.

**Q: Why are driver payouts batched?**
A: Each bank transfer has a fixed fee. Doing 100 transfers/week costs 100x the fees. One weekly batch transfer costs just one fee. At scale, this saves millions of dollars.
