import { memo } from 'react';
import { useNewCanvasStore } from '../state/store';

function ProgressWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  
  const steps = data.steps || ['Initialize', 'Process', 'Complete'];
  const currentStepIndex = data.currentStepIndex || 0;
  const title = data.title || 'Task Progress';

  const onDelete = () => {
    commitElements((els) => els.map((e) => (e.id === element.id ? { ...e, isDeleted: true } : e)));
  };

  return (
    <div
      className="nc-widget"
      style={{
        background: data.chromeBg || '#18181b',
        borderColor: element.style?.stroke || '#52525b',
        borderWidth: element.style?.strokeWidth ?? 1,
        borderStyle: 'solid',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div className="nc-widget-header" data-nc-drag-handle="1">
        <div className="nc-widget-header__label">{title}</div>
        <div className="nc-widget-header__actions">
          <button type="button" className="nc-widget-header__btn" onClick={onDelete}>×</button>
        </div>
      </div>
      <div className="nc-widget-body" style={{ padding: '16px', flex: 1 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {steps.map((step, idx) => {
            const isActive = idx === currentStepIndex;
            const isDone = idx < currentStepIndex;
            return (
              <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '12px', opacity: isDone || isActive ? 1 : 0.5 }}>
                <div style={{
                  width: '24px', height: '24px', borderRadius: '50%',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: isDone ? '#22c55e' : isActive ? '#3b82f6' : '#3f3f46',
                  color: '#fff', fontSize: '12px'
                }}>
                  {isDone ? '✓' : idx + 1}
                </div>
                <div style={{ 
                  color: isDone ? '#a1a1aa' : isActive ? '#f4f4f5' : '#71717a',
                  fontWeight: isActive ? 'bold' : 'normal'
                }}>
                  {step}
                  {isActive && <span className="nc-agentbar__feedback-dot" style={{marginLeft: '8px'}} />}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default memo(ProgressWidgetImpl);
