# Window Functions — Concept

> **Permanent recall:** `FUNCTION(...) OVER (PARTITION BY … ORDER BY … [frame])` computes **per-row** results **without collapsing** the table (unlike `GROUP BY`).

---

## Definition

**Window Function** = a function that performs a calculation across a set of rows (a "window") related to the current row. Unlike GROUP BY, it does NOT collapse rows — every row keeps its identity and gets an additional computed column.

---

## Parts of OVER

| Clause | Role | Required? |
|----------|------|-----------|
| **PARTITION BY** | Divides rows into separate windows (like GROUP BY but keeps rows) | Optional (entire table = one window) |
| **ORDER BY** | Orders rows **inside** partition | Required for ranking/offset functions |
| **Frame** (`ROWS`/`RANGE`/`GROUPS`) | Which rows in the partition feed the calculation | Optional (has defaults) |

---

## Complete Window Function Catalog

### Ranking Functions

| Function | Behavior with ties | Example: values [100, 100, 90, 80] |
|----------|-------------------|------|
| **ROW_NUMBER()** | Unique 1..n (ties get different numbers, non-deterministic) | 1, 2, 3, 4 |
| **RANK()** | Ties share rank; **gaps** after ties | 1, 1, 3, 4 |
| **DENSE_RANK()** | Ties share rank; **no gaps** | 1, 1, 2, 3 |
| **NTILE(n)** | Divides rows into n roughly equal buckets | NTILE(2) → 1,1,2,2 |

### Offset / Value Functions

| Function | What it returns |
|----------|----------------|
| **LAG(col, n, default)** | Value from n rows BEFORE current (default if no such row) |
| **LEAD(col, n, default)** | Value from n rows AFTER current |
| **FIRST_VALUE(col)** | First value in the window frame |
| **LAST_VALUE(col)** | Last value in the window frame (watch frame default!) |
| **NTH_VALUE(col, n)** | Nth value in the window frame |

### Aggregate Window Functions

Any aggregate can be used as a window function:
- `SUM(col) OVER (...)` — running/cumulative sum
- `AVG(col) OVER (...)` — moving average
- `COUNT(*) OVER (...)` — running count
- `MIN/MAX(col) OVER (...)` — running min/max

### Statistical Functions

| Function | What it returns |
|----------|----------------|
| **PERCENT_RANK()** | Relative rank as fraction: (rank - 1) / (total_rows - 1). Range: 0 to 1 |
| **CUME_DIST()** | Cumulative distribution: rows with value ≤ current / total rows. Range: > 0 to 1 |

---

## Window Frame (ROWS vs RANGE vs GROUPS)

The frame determines which rows within the partition are included in the calculation.

### Frame types

| Type | Unit | Meaning |
|------|------|---------|
| **ROWS** | Physical row count | Exact N rows before/after current |
| **RANGE** | Value range | All rows with values within range of current |
| **GROUPS** | Peer groups | Groups of rows with same ORDER BY value |

### Frame boundaries

| Boundary | Meaning |
|----------|---------|
| `UNBOUNDED PRECEDING` | Start of partition |
| `N PRECEDING` | N rows/values before current |
| `CURRENT ROW` | Current row |
| `N FOLLOWING` | N rows/values after current |
| `UNBOUNDED FOLLOWING` | End of partition |

### Default frame

**With ORDER BY:** `RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` (running total)
**Without ORDER BY:** `RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING` (entire partition)

### Common frame examples

```sql
-- Running total (default with ORDER BY)
SUM(amount) OVER (ORDER BY date)

-- 7-day moving average
AVG(amount) OVER (ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)

-- Entire partition (explicit)
SUM(amount) OVER (PARTITION BY dept_id ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
```

---

## LAST_VALUE trap

Default frame with ORDER BY = `RANGE UNBOUNDED PRECEDING TO CURRENT ROW` → `LAST_VALUE` only sees up to current row, NOT end of partition!

**Fix:** Specify full frame explicitly:
```sql
LAST_VALUE(col) OVER (ORDER BY x ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)
```

---

## Window Functions vs GROUP BY

| Feature | GROUP BY | Window Functions |
|---------|----------|-----------------|
| **Output rows** | One per group (collapses) | Same number as input (preserves) |
| **Access to individual rows** | Lost after grouping | Kept — see both row and aggregate |
| **Multiple aggregations** | One level at a time | Multiple windows in same SELECT |
| **Ranking** | Not possible | ROW_NUMBER, RANK, DENSE_RANK |
| **Previous/next row** | Not possible | LAG, LEAD |

---

*Next: [[02_Mental-Model]]*
