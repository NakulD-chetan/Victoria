import { memo } from 'react';
import { CANVAS_Z } from './stacking';

const EDGE_COLOR = '#f03e3e';
const CENTER_COLOR = '#4263eb';
const GAP_COLOR = '#2f9e44';
const DIST_COLOR = '#7048e8';
const CANVAS_CENTER_COLOR = '#e8590c';

const SnapGuidesOverlay = memo(function SnapGuidesOverlay({
  guides, gapGuides, distances, zoom, scrollX, scrollY,
}) {
  const hasContent =
    (guides && guides.length > 0) ||
    (gapGuides && gapGuides.length > 0) ||
    (distances && distances.length > 0);

  if (!hasContent) return null;

  const z = zoom || 1;
  const sx = scrollX || 0;
  const sy = scrollY || 0;

  const toScreen = (wx, wy) => ({
    x: (wx + sx) * z,
    y: (wy + sy) * z,
  });

  return (
    <svg
      className="snap-guides-overlay"
      style={{
        position: 'absolute',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        /* Below Excalidraw's layer-ui (z:10). Above widget shells so guides are visible
         * through them. Never put a background / opacity here. */
        zIndex: CANVAS_Z.SNAP_GUIDES,
        overflow: 'hidden',
      }}
    >
      {/* ─── BOUNDS SNAP GUIDES (edge + center alignment) ─── */}
      {(guides || []).map((g, i) => {
        const color = g.type === 'canvas-center' ? CANVAS_CENTER_COLOR
                    : g.isCenter ? CENTER_COLOR
                    : EDGE_COLOR;

        if (g.axis === 'x') {
          const p1 = toScreen(g.pos, g.from);
          const p2 = toScreen(g.pos, g.to);
          return (
            <g key={`bx-${i}`}>
              <line
                x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                stroke={color} strokeWidth={1} strokeDasharray={g.isCenter ? '6 3' : '4 3'}
                opacity={0.95}
              />
              <Diamond x={p1.x} y={p1.y} size={3} color={color} />
              <Diamond x={p2.x} y={p2.y} size={3} color={color} />
            </g>
          );
        }
        const p1 = toScreen(g.from, g.pos);
        const p2 = toScreen(g.to, g.pos);
        return (
          <g key={`by-${i}`}>
            <line
              x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
              stroke={color} strokeWidth={1} strokeDasharray={g.isCenter ? '6 3' : '4 3'}
              opacity={0.95}
            />
            <Diamond x={p1.x} y={p1.y} size={3} color={color} />
            <Diamond x={p2.x} y={p2.y} size={3} color={color} />
          </g>
        );
      })}

      {/* ─── GAP SNAP GUIDES (equal spacing) ─── */}
      {(gapGuides || []).map((gg, gi) => (
        <g key={`gap-${gi}`}>
          {gg.gaps.map((seg, si) => {
            if (gg.axis === 'x') {
              const p1 = toScreen(seg.x1, seg.y);
              const p2 = toScreen(seg.x2, seg.y);
              const midX = (p1.x + p2.x) / 2;
              return (
                <g key={`gs-${si}`}>
                  <line
                    x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                    stroke={GAP_COLOR} strokeWidth={1.2} strokeDasharray="3 2" opacity={0.85}
                  />
                  {/* end ticks */}
                  <line x1={p1.x} y1={p1.y - 5} x2={p1.x} y2={p1.y + 5} stroke={GAP_COLOR} strokeWidth={1} opacity={0.85} />
                  <line x1={p2.x} y1={p2.y - 5} x2={p2.x} y2={p2.y + 5} stroke={GAP_COLOR} strokeWidth={1} opacity={0.85} />
                  {/* label */}
                  <rect
                    x={midX - 14} y={p1.y - 18} width={28} height={14} rx={3}
                    fill="rgba(47,158,68,0.9)"
                  />
                  <text
                    x={midX} y={p1.y - 9}
                    fill="#fff" fontSize={9} fontWeight={700} textAnchor="middle"
                    dominantBaseline="middle" fontFamily="system-ui, -apple-system, sans-serif"
                  >
                    {gg.gap}
                  </text>
                </g>
              );
            }
            const p1 = toScreen(seg.x, seg.y1);
            const p2 = toScreen(seg.x, seg.y2);
            const midY = (p1.y + p2.y) / 2;
            return (
              <g key={`gs-${si}`}>
                <line
                  x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                  stroke={GAP_COLOR} strokeWidth={1.2} strokeDasharray="3 2" opacity={0.85}
                />
                <line x1={p1.x - 5} y1={p1.y} x2={p1.x + 5} y2={p1.y} stroke={GAP_COLOR} strokeWidth={1} opacity={0.85} />
                <line x1={p2.x - 5} y1={p2.y} x2={p2.x + 5} y2={p2.y} stroke={GAP_COLOR} strokeWidth={1} opacity={0.85} />
                <rect
                  x={p1.x - 30} y={midY - 7} width={24} height={14} rx={3}
                  fill="rgba(47,158,68,0.9)"
                />
                <text
                  x={p1.x - 18} y={midY}
                  fill="#fff" fontSize={9} fontWeight={700} textAnchor="middle"
                  dominantBaseline="middle" fontFamily="system-ui, -apple-system, sans-serif"
                >
                  {gg.gap}
                </text>
              </g>
            );
          })}
        </g>
      ))}

      {/* ─── DISTANCE MEASUREMENT INDICATORS ─── */}
      {(distances || []).map((d, i) => {
        if (d.axis === 'x') {
          const p1 = toScreen(d.x1, d.y);
          const p2 = toScreen(d.x2, d.y);
          const midX = (p1.x + p2.x) / 2;
          const labelW = Math.max(24, String(d.gap).length * 8 + 8);
          return (
            <g key={`dx-${i}`}>
              <line
                x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
                stroke={DIST_COLOR} strokeWidth={0.8} strokeDasharray="3 2" opacity={0.65}
              />
              <line x1={p1.x} y1={p1.y - 4} x2={p1.x} y2={p1.y + 4} stroke={DIST_COLOR} strokeWidth={0.8} opacity={0.65} />
              <line x1={p2.x} y1={p2.y - 4} x2={p2.x} y2={p2.y + 4} stroke={DIST_COLOR} strokeWidth={0.8} opacity={0.65} />
              <rect
                x={midX - labelW / 2} y={p1.y - 17} width={labelW} height={13} rx={3}
                fill="rgba(112,72,232,0.82)"
              />
              <text
                x={midX} y={p1.y - 9}
                fill="#fff" fontSize={8.5} fontWeight={600} textAnchor="middle"
                dominantBaseline="middle" fontFamily="system-ui, -apple-system, sans-serif"
              >
                {d.gap}px
              </text>
            </g>
          );
        }
        const p1 = toScreen(d.x, d.y1);
        const p2 = toScreen(d.x, d.y2);
        const midY = (p1.y + p2.y) / 2;
        const labelW = Math.max(24, String(d.gap).length * 8 + 12);
        return (
          <g key={`dy-${i}`}>
            <line
              x1={p1.x} y1={p1.y} x2={p2.x} y2={p2.y}
              stroke={DIST_COLOR} strokeWidth={0.8} strokeDasharray="3 2" opacity={0.65}
            />
            <line x1={p1.x - 4} y1={p1.y} x2={p1.x + 4} y2={p1.y} stroke={DIST_COLOR} strokeWidth={0.8} opacity={0.65} />
            <line x1={p2.x - 4} y1={p2.y} x2={p2.x + 4} y2={p2.y} stroke={DIST_COLOR} strokeWidth={0.8} opacity={0.65} />
            <rect
              x={p1.x - labelW - 4} y={midY - 6.5} width={labelW} height={13} rx={3}
              fill="rgba(112,72,232,0.82)"
            />
            <text
              x={p1.x - labelW / 2 - 4} y={midY}
              fill="#fff" fontSize={8.5} fontWeight={600} textAnchor="middle"
              dominantBaseline="middle" fontFamily="system-ui, -apple-system, sans-serif"
            >
              {d.gap}px
            </text>
          </g>
        );
      })}
    </svg>
  );
});

function Diamond({ x, y, size, color }) {
  const s = size || 3;
  return (
    <polygon
      points={`${x},${y - s} ${x + s},${y} ${x},${y + s} ${x - s},${y}`}
      fill={color} opacity={0.95}
    />
  );
}

export default SnapGuidesOverlay;
