# Window Functions — Edge Cases

---

## Ties

Multiple rows can be “top” — `RANK`/`DENSE_RANK` vs **dedup** need `ROW_NUMBER` with tie-breaker column.

---

## NULLS in ORDER BY

`NULLS FIRST`/`LAST` affects ranking order.

---

## Distinct + window

`COUNT(DISTINCT)` over window — not allowed in all dialects the same way — may need subquery.

---

*Next: [[07_Tricks-and-Recognition]]*
