import { create } from 'zustand';
import { getActiveVaultId, onVaultChange } from './vault-store';

/*
 * Workspace store — recursive split tree of editor panes.
 *
 * The tree is a binary tree of split nodes; leaves are panes that own a
 * list of open tab ids and one active tab. This replaces the legacy
 * `splitMode` / `splitTabId` booleans on useNotesStore so we can support
 * 2/3/4-way splits and cross-pane tab dragging.
 *
 *   type SplitNode =
 *     | { type: 'pane',  pane: { id, tabs: NoteId[], activeTabId } }
 *     | { type: 'split', direction: 'row'|'col', ratio: number, a: SplitNode, b: SplitNode }
 *
 * One Workspace lives per vault; the active vault id selects which slot
 * is exposed via `useWorkspaceStore`. Switching vaults (via vault-store)
 * emits onVaultChange which we use to swap slots without losing layout.
 */

const STORAGE_KEY = 'inkdrop-workspaces';
const MAX_PANES = 4;

/** Last `.obs-pane` the pointer entered — used so sidebar opens land in the pane the user is working in (TipTap may swallow focus). */
let _pointerWithinPaneId = null;

let _nextPaneId = 1;
const newPaneId = () => `p${Date.now().toString(36)}_${_nextPaneId++}`;
let _nextSplitId = 1;
const newSplitId = () => `s${Date.now().toString(36)}_${_nextSplitId++}`;

function newPane(tabs = [], activeTabId = null) {
  return { type: 'pane', pane: { id: newPaneId(), tabs: [...tabs], activeTabId } };
}

/** Ensure every `split` node has an `__id` (in-place tag for persistence). */
function tagSplitIds(node) {
  if (!node) return node;
  if (node.type === 'pane') return node;
  if (!node.__id) node.__id = newSplitId();
  return { ...node, __id: node.__id, a: tagSplitIds(node.a), b: tagSplitIds(node.b) };
}

function emptyWorkspace() {
  return { root: newPane(), focusedPaneId: null };
}

function loadAll() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch { return {}; }
}

function saveAll(map) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(map)); } catch { /* quota */ }
}

const _stores = loadAll();
let _persistTimer = null;
function debouncedPersist() {
  if (_persistTimer) clearTimeout(_persistTimer);
  _persistTimer = setTimeout(() => saveAll(_stores), 250);
}

/* ── Tree helpers ─────────────────────────────────────────────────────── */

function clonePane(pane) {
  return { ...pane.pane, tabs: [...pane.pane.tabs] };
}
function clonePaneNode(node) {
  return { type: 'pane', pane: clonePane(node) };
}

function findPane(node, paneId) {
  if (!node) return null;
  if (node.type === 'pane') return node.pane.id === paneId ? node : null;
  return findPane(node.a, paneId) || findPane(node.b, paneId);
}
function firstPane(node) {
  if (!node) return null;
  if (node.type === 'pane') return node;
  return firstPane(node.a) || firstPane(node.b);
}
function countPanes(node) {
  if (!node) return 0;
  if (node.type === 'pane') return 1;
  return countPanes(node.a) + countPanes(node.b);
}
function mapTree(node, fn) {
  const next = fn(node);
  if (next.type === 'pane') return next;
  return { ...next, a: mapTree(next.a, fn), b: mapTree(next.b, fn) };
}
function replacePane(node, paneId, replacer) {
  if (!node) return node;
  if (node.type === 'pane') {
    if (node.pane.id !== paneId) return node;
    return replacer(node);
  }
  return {
    ...node,
    a: replacePane(node.a, paneId, replacer),
    b: replacePane(node.b, paneId, replacer),
  };
}
function removePaneById(node, paneId) {
  if (!node) return null;
  if (node.type === 'pane') return node.pane.id === paneId ? null : node;
  if (node.a.type === 'pane' && node.a.pane.id === paneId) return node.b;
  if (node.b.type === 'pane' && node.b.pane.id === paneId) return node.a;
  const a = removePaneById(node.a, paneId);
  const b = removePaneById(node.b, paneId);
  if (!a) return b;
  if (!b) return a;
  return { ...node, a, b };
}

function applyDefaults(ws) {
  if (!ws || !ws.root) return emptyWorkspace();
  const root = tagSplitIds(ws.root);
  const focused = ws.focusedPaneId && findPane(root, ws.focusedPaneId)
    ? ws.focusedPaneId
    : firstPane(root)?.pane.id || null;
  return { root, focusedPaneId: focused };
}

/* ── Per-vault snapshot ──────────────────────────────────────────────── */

function snapshotForVault(vaultId) {
  if (!vaultId) return emptyWorkspace();
  if (!_stores[vaultId]) _stores[vaultId] = emptyWorkspace();
  return applyDefaults(_stores[vaultId]);
}

const initialVaultId = getActiveVaultId();
const initial = snapshotForVault(initialVaultId);

export const useWorkspaceStore = create((set, get) => ({
  vaultId: initialVaultId,
  root: initial.root,
  focusedPaneId: initial.focusedPaneId,

  _commit(next) {
    const { vaultId } = get();
    const tagged = { ...next, root: tagSplitIds(next.root) };
    _stores[vaultId] = { root: tagged.root, focusedPaneId: tagged.focusedPaneId };
    debouncedPersist();
    set(tagged);
    queueMicrotask(() => {
      import('./notes-store.js')
        .then((m) => m.useNotesStore.getState().reconcileOpenTabsFromWorkspace?.())
        .catch(() => {});
    });
  },

  /** Called from `EditorPane` on pointer enter so tree opens target the pane under the cursor. */
  reportPointerPane(paneId) {
    _pointerWithinPaneId = paneId || null;
  },

  /* Called by the vault-store listener below. */
  switchVault(nextVaultId) {
    const ws = snapshotForVault(nextVaultId);
    set({ vaultId: nextVaultId, root: ws.root, focusedPaneId: ws.focusedPaneId });
  },

  paneCount() { return countPanes(get().root); },

  focusPane(paneId) {
    if (!findPane(get().root, paneId)) return;
    get()._commit({ root: get().root, focusedPaneId: paneId });
  },

  openTabInFocusedPane(noteId) {
    const { root, focusedPaneId } = get();
    const pointerOk = _pointerWithinPaneId && findPane(root, _pointerWithinPaneId);
    const targetId = (pointerOk ? _pointerWithinPaneId : null)
      || focusedPaneId
      || firstPane(root)?.pane.id;
    if (!targetId) return;
    get().openTabInPane(targetId, noteId);
  },

  openTabInPane(paneId, noteId) {
    const next = replacePane(get().root, paneId, (node) => {
      const p = clonePane(node);
      if (!p.tabs.includes(noteId)) p.tabs.push(noteId);
      p.activeTabId = noteId;
      return { type: 'pane', pane: p };
    });
    get()._commit({ root: next, focusedPaneId: paneId });
  },

  closeTabInPane(paneId, noteId) {
    const root0 = get().root;
    /* Remove the tab from its pane. */
    let updated = replacePane(root0, paneId, (node) => {
      const p = clonePane(node);
      const idx = p.tabs.indexOf(noteId);
      if (idx === -1) return node;
      p.tabs.splice(idx, 1);
      if (p.activeTabId === noteId) {
        p.activeTabId = p.tabs[idx] || p.tabs[idx - 1] || null;
      }
      return { type: 'pane', pane: p };
    });

    /* Normalize: if the source pane is now empty AND there are other panes,
       drop it; otherwise keep it as a true single-pane fullscreen. */
    if (countPanes(updated) > 1) {
      updated = pruneEmptyPanes(updated);
    }
    if (!updated) updated = newPane();

    const stillExists = !!findPane(updated, paneId);
    const focused = stillExists ? paneId : (firstPane(updated)?.pane.id || null);
    get()._commit({ root: updated, focusedPaneId: focused });
  },

  closeOthersInPane(paneId, keepNoteId) {
    const next = replacePane(get().root, paneId, (node) => {
      const p = clonePane(node);
      p.tabs = p.tabs.filter((t) => t === keepNoteId);
      p.activeTabId = p.tabs.includes(keepNoteId) ? keepNoteId : (p.tabs[0] || null);
      return { type: 'pane', pane: p };
    });
    get()._commit({ root: next, focusedPaneId: paneId });
  },

  closeAllInPane(paneId) {
    /* Wipe the pane's tabs; if other panes exist, drop this pane. */
    const root0 = get().root;
    let updated = replacePane(root0, paneId, (node) => {
      const p = clonePane(node);
      p.tabs = [];
      p.activeTabId = null;
      return { type: 'pane', pane: p };
    });
    if (countPanes(updated) > 1) {
      updated = pruneEmptyPanes(updated);
    }
    if (!updated) updated = newPane();
    const stillExists = !!findPane(updated, paneId);
    const focused = stillExists ? paneId : (firstPane(updated)?.pane.id || null);
    get()._commit({ root: updated, focusedPaneId: focused });
  },

  splitPaneById(paneId, direction = 'right') {
    const { root } = get();
    if (!findPane(root, paneId)) return;
    if (countPanes(root) >= MAX_PANES) return;
    const focused = findPane(root, paneId);
    const carryTab = focused?.pane.activeTabId || null;

    let createdId = null;
    const splitDirection = direction === 'left' || direction === 'right' ? 'row' : 'col';
    const newOnSecond = direction === 'right' || direction === 'down';
    /* replacePane (not mapTree) — the new split contains a clone of the
       target pane (same id); mapTree would recurse into it and split it
       again forever. */
    const next = replacePane(root, paneId, (node) => {
      const newP = newPane(carryTab ? [carryTab] : [], carryTab);
      createdId = newP.pane.id;
      return newOnSecond
        ? { type: 'split', direction: splitDirection, ratio: 0.5, a: clonePaneNode(node), b: newP }
        : { type: 'split', direction: splitDirection, ratio: 0.5, a: newP, b: clonePaneNode(node) };
    });
    get()._commit({ root: next, focusedPaneId: createdId || paneId });
  },

  /** Move the active tab from `paneId` to the *other* visible pane (if any). */
  moveTabToOtherPane(paneId, noteId) {
    const root0 = get().root;
    const otherPane = (function find(n) {
      if (!n) return null;
      if (n.type === 'pane') return n.pane.id === paneId ? null : n;
      return find(n.a) || find(n.b);
    })(root0);
    if (!otherPane) return;
    get().moveTab(noteId, paneId, otherPane.pane.id);
  },

  setActiveTab(paneId, noteId) {
    const next = replacePane(get().root, paneId, (node) => {
      const p = clonePane(node);
      if (!p.tabs.includes(noteId)) p.tabs.push(noteId);
      p.activeTabId = noteId;
      return { type: 'pane', pane: p };
    });
    get()._commit({ root: next, focusedPaneId: paneId });
  },

  /* Move a tab from one pane to another. If `targetPaneId` is the same
   * pane, this becomes a reorder. If it is a special string 'split:row' /
   * 'split:col' applied to the source pane, we split the source pane. */
  moveTab(noteId, sourcePaneId, targetPaneId, opts = {}) {
    const { direction, before } = opts;

    const root0 = get().root;
    /* Step 1: remove the tab from its source pane. */
    const removed = mapTree(root0, (node) => {
      if (node.type !== 'pane' || node.pane.id !== sourcePaneId) return node;
      const p = clonePane(node);
      const idx = p.tabs.indexOf(noteId);
      if (idx !== -1) {
        p.tabs.splice(idx, 1);
        if (p.activeTabId === noteId) p.activeTabId = p.tabs[idx] || p.tabs[idx - 1] || null;
      }
      return { type: 'pane', pane: p };
    });

    /* Step 2: if the target pane is the same and we're just reordering. */
    if (sourcePaneId === targetPaneId && !direction) {
      const next = mapTree(removed, (node) => {
        if (node.type !== 'pane' || node.pane.id !== targetPaneId) return node;
        const p = clonePane(node);
        const insertAt = typeof before === 'number' ? before : p.tabs.length;
        p.tabs.splice(insertAt, 0, noteId);
        p.activeTabId = noteId;
        return { type: 'pane', pane: p };
      });
      get()._commit({ root: next, focusedPaneId: targetPaneId });
      return;
    }

    /* Step 3: drop into existing pane. */
    if (!direction) {
      const next = mapTree(removed, (node) => {
        if (node.type !== 'pane' || node.pane.id !== targetPaneId) return node;
        const p = clonePane(node);
        if (!p.tabs.includes(noteId)) {
          const insertAt = typeof before === 'number' ? before : p.tabs.length;
          p.tabs.splice(insertAt, 0, noteId);
        }
        p.activeTabId = noteId;
        return { type: 'pane', pane: p };
      });
      /* If the source pane is now empty and there are other panes, drop it. */
      const cleanup = pruneEmptyPanes(next);
      get()._commit({ root: cleanup, focusedPaneId: targetPaneId });
      return;
    }

    /* Step 4: split request. Split the *target* pane into a new layout
     * with the source pane's tab as the new pane on the requested side. */
    if (countPanes(root0) >= MAX_PANES) {
      /* Too many panes — fall back to a simple in-pane drop. */
      const next = mapTree(removed, (node) => {
        if (node.type !== 'pane' || node.pane.id !== targetPaneId) return node;
        const p = clonePane(node);
        if (!p.tabs.includes(noteId)) p.tabs.push(noteId);
        p.activeTabId = noteId;
        return { type: 'pane', pane: p };
      });
      get()._commit({ root: pruneEmptyPanes(next), focusedPaneId: targetPaneId });
      return;
    }

    /* If the source pane is also the target AND this was its only tab,
       removing first would leave both sides of the new split empty (the
       source side gets pruned) and the visible split collapses. Skip the
       removal so the source side keeps the tab — Obsidian-style "open in
       new pane" where both panes initially show the same note. */
    const sourcePaneNode = findPane(root0, sourcePaneId);
    const sourceWouldBeEmpty = sourcePaneNode
      && sourcePaneNode.pane.tabs.length === 1
      && sourcePaneNode.pane.tabs[0] === noteId;
    const baseTree = (sourcePaneId === targetPaneId && sourceWouldBeEmpty) ? root0 : removed;

    let newPaneNode = null;
    const splitDirection = direction === 'left' || direction === 'right' ? 'row' : 'col';
    const newOnSecond = direction === 'right' || direction === 'down';
    /* Use replacePane (not mapTree) here: it does NOT recurse into the
       replacer's return value, so the cloned target pane in the new
       split won't be re-matched and re-split forever. */
    const next = replacePane(baseTree, targetPaneId, (node) => {
      newPaneNode = newPane([noteId], noteId);
      return newOnSecond
        ? { type: 'split', direction: splitDirection, ratio: 0.5, a: clonePaneNode(node), b: newPaneNode }
        : { type: 'split', direction: splitDirection, ratio: 0.5, a: newPaneNode, b: clonePaneNode(node) };
    });
    /* Only prune if we did the removal (cross-pane split). For the
       same-pane case we kept both sides intentionally. */
    const cleanup = baseTree === removed ? pruneEmptyPanes(next) : next;
    get()._commit({
      root: cleanup || newPane(),
      focusedPaneId: newPaneNode?.pane.id || targetPaneId,
    });
  },

  setRatio(splitId, ratio) {
    const r = Math.max(0.05, Math.min(0.95, ratio));
    const next = mapTree(get().root, (node) => {
      if (node.type === 'split' && node.__id === splitId) {
        return { ...node, ratio: r };
      }
      return node;
    });
    /* Persist ratio without re-running tab reconciliation or re-rendering panels.
       We mutate the persisted snapshot + set state directly. */
    const { vaultId, focusedPaneId } = get();
    _stores[vaultId] = { root: next, focusedPaneId };
    debouncedPersist();
    set({ root: next });
  },

  splitFocusedPane(direction = 'right') {
    const { focusedPaneId, root } = get();
    const paneId = focusedPaneId || firstPane(root)?.pane.id;
    if (!paneId) return;
    if (countPanes(root) >= MAX_PANES) return;
    const focused = findPane(root, paneId);
    const carryTab = focused?.pane.activeTabId || null;

    let createdId = null;
    const splitDirection = direction === 'left' || direction === 'right' ? 'row' : 'col';
    const newOnSecond = direction === 'right' || direction === 'down';
    const next = replacePane(root, paneId, (node) => {
      const newP = newPane(carryTab ? [carryTab] : [], carryTab);
      createdId = newP.pane.id;
      return newOnSecond
        ? { type: 'split', direction: splitDirection, ratio: 0.5, a: clonePaneNode(node), b: newP }
        : { type: 'split', direction: splitDirection, ratio: 0.5, a: newP, b: clonePaneNode(node) };
    });
    get()._commit({ root: next, focusedPaneId: createdId || paneId });
  },

  closePane(paneId) {
    if (countPanes(get().root) <= 1) return;
    const next = removePaneById(get().root, paneId);
    if (!next) return;
    const focused = get().focusedPaneId === paneId
      ? firstPane(next)?.pane.id || null
      : get().focusedPaneId;
    get()._commit({ root: next, focusedPaneId: focused });
  },
}));

function pruneEmptyPanes(node) {
  if (!node) return null;
  if (node.type === 'pane') {
    return node.pane.tabs.length === 0 ? null : node;
  }
  const a = pruneEmptyPanes(node.a);
  const b = pruneEmptyPanes(node.b);
  if (!a && !b) return null;
  if (!a) return b;
  if (!b) return a;
  return { ...node, a, b };
}

/* React to vault switches: swap the entire workspace tree to whatever
 * snapshot we have for the new vault (or a fresh empty one). */
onVaultChange((nextId) => {
  useWorkspaceStore.getState().switchVault(nextId);
});
