import { useCallback } from 'react';
import { useProblemSessionStore } from '../../stores/problem-session-store';
import { usePlaygroundStore } from '../../stores/playground-store';
import { injectChaos, clearChaosEffects } from '../../lib/problems/simulation';

export default function ChaosToolbar({ problem }) {
  const chaosActive = useProblemSessionStore((s) => s.chaosActive);
  const setChaosActive = useProblemSessionStore((s) => s.setChaosActive);
  const clearChaos = useProblemSessionStore((s) => s.clearChaos);

  const scenarios = problem.chaosScenarios || [];
  if (!scenarios.length) return null;

  const handleInject = useCallback((scenario) => {
    const store = usePlaygroundStore.getState();
    injectChaos(scenario, store.components, store.connections);
    setChaosActive(scenario);
  }, [setChaosActive]);

  const handleClear = useCallback(() => {
    const store = usePlaygroundStore.getState();
    clearChaosEffects(store.components);
    clearChaos();
  }, [clearChaos]);

  return (
    <div className="dc-chaos-toolbar">
      <span className="dc-chaos-toolbar__label">Chaos:</span>
      {scenarios.map((s, i) => (
        <button
          key={i}
          className={`dc-chaos-toolbar__btn ${chaosActive === s ? 'dc-chaos-toolbar__btn--active' : ''}`}
          onClick={() => handleInject(s)}
          disabled={chaosActive && chaosActive !== s}
          title={s.label}
        >
          {s.type === 'kill_node' ? '\uD83D\uDC80' : s.type === 'spike_traffic' ? '\uD83D\uDCC8' : '\uD83D\uDD0C'}
          {' '}{s.label}
        </button>
      ))}
      {chaosActive && (
        <button className="dc-chaos-toolbar__btn dc-chaos-toolbar__btn--clear" onClick={handleClear}>
          Clear
        </button>
      )}
    </div>
  );
}
