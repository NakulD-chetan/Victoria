# 21. How Google Search Works

## One-Line Summary
Google Search combines a web crawler (URL frontier, deduplication, fetcher, processor) with a search engine; crawls ~10B pages (~20 PB), serves ~100K queries/sec, using orchestration, Bloom filters, and Simhash for scale and politeness.

## Key Requirements
- **Scale**: ~200M active websites × ~50 pages = ~10 billion pages; ~20 PB storage
- **Search volume**: ~8.5 billion searches/day; ~100K queries/second
- **Freshness**: Continuously discover and re-crawl pages
- **Politeness**: Respect robots.txt; avoid overwhelming hosts
- **Deduplication**: Avoid crawling duplicate/similar content

## High-Level Architecture
```
[URL Frontier] → [Fetcher] → [Processor] → [Storage]
       ↑              |            |
       |              |            +--→ [Index Builder] → [Search Engine]
       +--------------+ (new URLs)
```

## Core Components Deep Dive

### 1. Web Crawler Components

#### URL Frontier
- **Two-stage queue**: Front queues (priority) + back queues (politeness per host)
- **Mercator-inspired**: Weighted round-robin across hosts
- **Adaptive politeness**: Adjust crawl rate based on HTTP response codes (429, 503 → back off)

#### URL Deduplication
- **Bloom filter**: Space-efficient, probabilistic; prevents re-adding already-seen URLs
- Trade-off: small false positive rate vs huge memory savings

#### Content Deduplication
- **Simhash algorithm**: Fingerprints similar/near-duplicate pages
- Avoids storing and indexing duplicate content (e.g., same article on multiple sites)

#### Webpage Fetcher
- Downloads HTML (and assets as needed)
- May use headless browser for JavaScript-rendered content
- DNS caching for performance

#### Webpage Processor
- Extracts links from pages
- Filters by blocklists, patterns (e.g., login, admin)
- Canonical URL resolution for intentional duplicates
- Feedback loop: new URLs pushed back to URL Frontier

#### Robots.txt
- Compliance required; respect Crawl-delay, Disallow directives

### 2. Storage
- **Object store (S3-like)**: Raw web page content
- **Key-value store**: Metadata (URL, crawl timestamp, links, etc.)

### 3. Orchestration
- **Orchestration** (central coordinator) preferred over sync or choreography
- Benefits: better monitoring, retry logic, scheduling, backpressure

### 4. Search Engine
- Builds indexes (inverted index, etc.) from crawled content
- Serves user queries; ranking, relevance, etc.

## Key Design Decisions
1. **Two-stage URL Frontier** — balances priority (important pages first) with politeness (don't hammer a single host)
2. **Bloom filter for URLs** — O(1) membership check; minimal memory for billions of URLs
3. **Simhash for content** — detect near-duplicates without full comparison
4. **Orchestration over choreography** — centralized control for crawler reliability
5. **Canonical URLs** — handle intentional duplicates (same content, different URLs)

## Scaling Strategies
- Shard URL Frontier by host/domain; parallel fetchers
- Distributed object store for 20 PB; sharded metadata store
- Batch processing; async pipelines for link extraction and indexing
- DNS caching; connection pooling; CDN for static assets

## Interview Tips
- Start with the two main parts: Crawler + Search Engine
- URL Frontier is often the focus: explain front/back queues and politeness
- Bloom filter vs hash set: trade-off (false positives vs memory)
- Mention Simhash for content dedup — shows depth beyond URL dedup
- Orchestration vs choreography: crawlers need retries and scheduling

## Quick Revision
- Scale: ~10B pages, ~20 PB; ~100K queries/sec
- URL Frontier: front (priority) + back (politeness per host); Mercator-style
- URL dedup: Bloom filter; content dedup: Simhash
- Fetcher → Processor → Storage; feedback loop for new URLs
- Orchestration, robots.txt, canonical URLs, DNS caching
