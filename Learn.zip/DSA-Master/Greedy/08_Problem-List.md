# Greedy — Problem List

> **Permanent Recall:** 30 problems, 10 MUST-DO. Focus: intervals, jump games, gas station, task scheduling. Study plan: Easy → Medium → Hard. FAANG favorites marked.

---

## MUST-DO (10 Problems) — Do These First


| #   | Problem                                         | Pattern               | Difficulty | Notes                          |
| --- | ----------------------------------------------- | --------------------- | ---------- | ------------------------------ |
| 1   | **Meeting Rooms II** (LC 253)                   | Interval partitioning | Medium     | Min rooms = max concurrent     |
| 2   | **Merge Intervals** (LC 56)                     | Interval merge        | Medium     | Sort by start                  |
| 3   | **Non-overlapping Intervals** (LC 435)          | Interval scheduling   | Medium     | Sort by end, max count         |
| 4   | **Jump Game** (LC 55)                           | Reachability          | Medium     | max_reach                      |
| 5   | **Jump Game II** (LC 45)                        | Min jumps             | Medium     | cur_end, max_reach             |
| 6   | **Gas Station** (LC 134)                        | Circular greedy       | Medium     | Running sum                    |
| 7   | **Task Scheduler** (LC 621)                     | Task scheduling       | Medium     | (max_count-1)*(n+1) + same_max |
| 8   | **Partition Labels** (LC 763)                   | Greedy partition      | Medium     | Last occurrence                |
| 9   | **Minimum Number of Arrows** (LC 452)           | Interval (balloons)   | Medium     | Sort by end                    |
| 10  | **Best Time to Buy and Sell Stock II** (LC 122) | Simple greedy         | Easy       | Buy low, sell high             |


---

## Easy (8 Problems)


| #   | Problem                              | Pattern          | Key Idea                |
| --- | ------------------------------------ | ---------------- | ----------------------- |
| 11  | Assign Cookies (LC 455)              | Sort + match     | Sort both, two pointers |
| 12  | Lemonade Change (LC 860)             | Greedy change    | Prefer $10 over $5      |
| 13  | Valid Parentheses String (LC 678)    | Balance          | Low/high range          |
| 14  | Maximum 69 Number (LC 1323)          | Single change    | Change first 6 to 9     |
| 15  | Can Place Flowers (LC 605)           | Greedy placement | Check 0,0,0             |
| 16  | Maximum Units on Truck (LC 1710)     | Fractional-like  | Sort by units/box       |
| 17  | Minimum Cost to Move Chips (LC 1217) | Parity           | Odd vs even             |
| 18  | Two City Scheduling (LC 1029)        | Sort by diff     | Sort by (costA - costB) |


---

## Medium (10 Problems)


| #   | Problem                                                         | Pattern         | Key Idea                     |
| --- | --------------------------------------------------------------- | --------------- | ---------------------------- |
| 19  | **Insert Interval** (LC 57)                                     | Interval insert | Find position, merge         |
| 20  | **Remove Covered Intervals** (LC 1288)                          | Interval        | Sort by start asc, end desc  |
| 21  | **Minimum Deletions to Make Char Frequencies Unique** (LC 1647) | Frequency       | Decrement until unique       |
| 22  | **Boats to Save People** (LC 881)                               | Two pointers    | Lightest + heaviest          |
| 23  | **Hand of Straights** (LC 846)                                  | Greedy groups   | Sort, use min for each group |
| 24  | **Queue Reconstruction by Height** (LC 406)                     | Sort + insert   | Sort by h desc, k asc        |
| 25  | **Candy** (LC 135)                                              | Two passes      | Left-to-right, right-to-left |
| 26  | **Reorganize String** (LC 767)                                  | Heap greedy     | Most frequent first          |
| 27  | **Minimum Domino Rotations** (LC 1007)                          | Greedy try      | Fix top or bottom            |
| 28  | **Minimum Cost to Cut a Stick** (LC 1547)                       | Reverse greedy  | Cut largest gaps first       |


---

## Hard (2 Problems)


| #   | Problem                                     | Pattern     | Key Idea                           |
| --- | ------------------------------------------- | ----------- | ---------------------------------- |
| 29  | **Minimum Cost to Hire K Workers** (LC 857) | Sort + heap | Sort by ratio, maintain k smallest |
| 30  | **IPO** (LC 502)                            | Heap greedy | Capital heap → profit heap         |


---

## By Pattern

### Interval Scheduling

- Non-overlapping Intervals (LC 435)
- Meeting Rooms II (LC 253)
- Minimum Number of Arrows (LC 452)
- Merge Intervals (LC 56)
- Insert Interval (LC 57)
- Remove Covered Intervals (LC 1288)

### Jump / Reach

- Jump Game (LC 55)
- Jump Game II (LC 45)

### Gas / Circular

- Gas Station (LC 134)

### Task Scheduling

- Task Scheduler (LC 621)

### Sort + Process

- Partition Labels (LC 763)
- Two City Scheduling (LC 1029)
- Queue Reconstruction by Height (LC 406)
- Boats to Save People (LC 881)

### Heap Greedy

- Reorganize String (LC 767)
- IPO (LC 502)

---

## Study Plan

### Week 1: Foundations

- Day 1–2: Concept.md, Mental-Model.md, Coding-Template.md
- Day 3: Jump Game I & II, Gas Station
- Day 4: Merge Intervals, Non-overlapping Intervals
- Day 5: Meeting Rooms II, Partition Labels

### Week 2: Patterns

- Day 1: Task Scheduler, Minimum Arrows
- Day 2: Best Time Buy Sell II, Assign Cookies, Lemonade Change
- Day 3: Insert Interval, Remove Covered Intervals
- Day 4: Two City Scheduling, Boats to Save People
- Day 5: Queue Reconstruction, Candy

### Week 3: Advanced

- Day 1–2: Remaining Medium problems
- Day 3–4: Hard problems (IPO, Min Cost Hire K Workers)
- Day 5: Revision, mock interviews

---

## ASCII: Problem Difficulty Distribution

```
Easy:    ████████ (8)
Medium:  ██████████ (14)  ← FAANG focus
Hard:    ████ (2)
```

---

## LeetCode Quick Links (Pattern)


| Problem                   | LC # |
| ------------------------- | ---- |
| Meeting Rooms II          | 253  |
| Merge Intervals           | 56   |
| Non-overlapping Intervals | 435  |
| Jump Game                 | 55   |
| Jump Game II              | 45   |
| Gas Station               | 134  |
| Task Scheduler            | 621  |
| Partition Labels          | 763  |
| Minimum Arrows            | 452  |
| Best Time Buy Sell II     | 122  |


---

## FINAL MEMORY COMPRESSION BLOCK

```
MUST-DO: Meeting Rooms II, Merge/Non-overlap Intervals, Jump I/II,
         Gas Station, Task Scheduler, Partition Labels, Min Arrows,
         Best Time Buy Sell II
PATTERNS: Intervals (sort by end), Jump (max_reach), Gas (running sum),
          Task (formula), Sort+process
STUDY: Week1 foundations, Week2 patterns, Week3 advanced
```

