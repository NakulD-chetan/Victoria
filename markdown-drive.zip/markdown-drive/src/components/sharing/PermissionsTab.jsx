import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

/*
 * PermissionsTab — per-resource ACL overrides for a folder or note.
 * Lets owners pin specific users to a different role than they would
 * inherit from the vault (e.g. an editor on the vault who should be
 * read-only on a private folder).
 */

export default function PermissionsTab({ resource, members, isOwner, onError, onInfo }) {
  const { user } = useAuth();
  const [overrides, setOverrides] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!resource?.id) return;
    let cancelled = false;
    setLoading(true);
    (async () => {
      const { data, error } = await supabase
        .from('resource_acl')
        .select('id, user_id, role, granted_by, created_at')
        .eq('resource_type', resource.type)
        .eq('resource_id', resource.id);
      if (cancelled) return;
      if (error) onError(error.message);
      setOverrides(data || []);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [resource?.id, resource?.type, onError]);

  /* Realtime subscription for ACL changes on this resource. */
  useEffect(() => {
    if (!resource?.id) return undefined;
    const channel = supabase
      .channel(`acl:${resource.type}:${resource.id}`)
      .on('postgres_changes',
          { event: '*', schema: 'public', table: 'resource_acl', filter: `resource_id=eq.${resource.id}` },
          async () => {
            const { data } = await supabase
              .from('resource_acl')
              .select('id, user_id, role, granted_by, created_at')
              .eq('resource_type', resource.type)
              .eq('resource_id', resource.id);
            setOverrides(data || []);
          })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [resource?.id, resource?.type]);

  const setOverride = async (memberId, role) => {
    onError('');
    onInfo('');
    const existing = overrides.find((o) => o.user_id === memberId);
    if (role === 'inherit') {
      if (!existing) return;
      const { error } = await supabase.from('resource_acl').delete().eq('id', existing.id);
      if (error) onError(error.message); else onInfo('Override removed.');
      return;
    }
    if (existing) {
      const { error } = await supabase
        .from('resource_acl')
        .update({ role })
        .eq('id', existing.id);
      if (error) onError(error.message); else onInfo('Override updated.');
    } else {
      const { error } = await supabase
        .from('resource_acl')
        .insert({
          resource_type: resource.type,
          resource_id: resource.id,
          user_id: memberId,
          role,
          granted_by: user.id,
        });
      if (error) onError(error.message); else onInfo('Override added.');
    }
  };

  return (
    <div className="sd-perms">
      <p className="sd-muted" style={{ marginTop: 0 }}>
        Override the vault role for this {resource.type} on a per-member basis.
        Leaving a member set to <em>Inherit</em> uses their vault role.
      </p>
      {loading && <p className="sd-muted">Loading…</p>}
      <div className="sd-members">
        {members.filter((m) => m.role !== 'owner').map((m) => {
          const ov = overrides.find((o) => o.user_id === m.user_id);
          const value = ov?.role || 'inherit';
          const p = m.profile || {};
          return (
            <div className="sd-member" key={m.user_id}>
              <div className="sd-member__id">
                <span className="sd-member__name">{p.display_name || p.email || '(unknown)'}</span>
                <span className="sd-member__email">Vault role: {m.role}</span>
              </div>
              {isOwner ? (
                <select
                  className="sd-role-select"
                  value={value}
                  onChange={(e) => setOverride(m.user_id, e.target.value)}
                >
                  <option value="inherit">Inherit ({m.role})</option>
                  <option value="viewer">Viewer (override)</option>
                  <option value="editor">Editor (override)</option>
                </select>
              ) : (
                <span className="sd-role-pill">{value === 'inherit' ? `Inherit (${m.role})` : value}</span>
              )}
            </div>
          );
        })}
        {members.filter((m) => m.role !== 'owner').length === 0 && (
          <p className="sd-muted">No other members yet.</p>
        )}
      </div>
    </div>
  );
}
