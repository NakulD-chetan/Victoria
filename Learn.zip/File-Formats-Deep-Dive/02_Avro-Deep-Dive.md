# 02 — Avro Deep Dive

> Avro is a **row-based binary** serialization format with the **schema embedded in every file** and the best **schema evolution** support — making it the standard for **Kafka**, **CDC**, and **data exchange** between services.  
>
> Serialization converts language-specific in-memory objects into transferable formats like JSON, Avro, or binary bytes.
>
> - Deserialization converts that transferable data back into objects of another language/runtime.
> - Neutral formats allow Python, Java, Go, Spark, Kafka, and other systems to communicate safely.

It means the Apache Avro file stores:

1. the actual data
2. AND the structure/definition of that data (schema)

inside the same file.

---

## 1. What Is Avro and Why It Exists

Avro solves a **different problem** than Parquet. Understanding this distinction is critical.


| Parquet Solves                                      | Avro Solves                                                 |
| --------------------------------------------------- | ----------------------------------------------------------- |
| "Read a few columns from a wide table fast"         | "Serialize entire records fast for streaming and messaging" |
| Analytical queries (SELECT, GROUP BY, aggregations) | Row-level ingestion, Kafka messages, CDC events             |
| Read-heavy workloads                                | Write-heavy workloads                                       |
| Column pruning, predicate pushdown                  | Schema evolution, compatibility guarantees                  |



| Property             | Detail                                                             |
| -------------------- | ------------------------------------------------------------------ |
| **Type**             | Row-based, binary                                                  |
| **Created by**       | Doug Cutting (Hadoop creator), now Apache project                  |
| **Schema**           | JSON-defined, embedded in file header                              |
| **Schema evolution** | Best among all formats — backward, forward, and full compatibility |
| **Used by**          | Kafka (standard), Debezium CDC, data exchange, Hadoop ecosystem    |


**How to explain it:** "Parquet is optimized for **reading columns**. Avro is optimized for **writing rows** with schema evolution — that's why Kafka uses Avro and data lakes use Parquet."  
  
  
File already contains schema.

Reader automatically understands structure.  
  
  
.avro files

---

## 2. Avro File Internal Structure (Object Container File)  
  
  
This is the beginning part of file.

Contains metadata about how to read the file.

```
┌──────────────────────────────────────────────────┐
│              AVRO FILE (.avro)                     │
│                                                    │
│  ┌──────────── FILE HEADER ──────────────────┐    │
│  │  Magic bytes: "Obj" + 0x01                 │    │
│  │  File metadata:                            │    │
│  │    - "avro.schema" → full JSON schema      │    │
│  │    - "avro.codec" → compression codec      │    │
│  │  Sync marker (16 random bytes)             │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────── DATA BLOCK 1 ─────────────────┐    │
│  │  Record count (long)                       │    │
│  │  Block size in bytes (long)                │    │
│  │  Serialized records (compressed together)  │    │
│  │    Record 1: {name: "Alice", age: 30}      │    │
│  │    Record 2: {name: "Bob", age: 25}        │    │
│  │  Sync marker (same 16 bytes)               │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
│  ┌──────────── DATA BLOCK 2 ─────────────────┐    │
│  │  (same structure)                          │    │
│  │  Sync marker                               │    │
│  └────────────────────────────────────────────┘    │
│                                                    │
└────────────────────────────────────────────────────┘
```

### Key Structural Differences from Parquet


| Aspect                     | Avro                               | Parquet                                     |
| -------------------------- | ---------------------------------- | ------------------------------------------- |
| **Schema location**        | Header (beginning of file)         | Footer (end of file)                        |
| **Data layout**            | Row-based (entire record together) | Columnar (column values together)           |
| **Block boundary markers** | Sync markers (16 random bytes)     | Row group boundaries in footer              |
| **Statistics**             | None — no min/max per block        | Min/max/null count per column per row group |


### Why Sync Markers Matter

When a distributed engine like Spark needs to split an Avro file across tasks, each task finds the nearest sync marker and starts reading from there. Without sync markers, the file would be unsplittable and only one task could read it.

```
File: [Header] [Block1] [sync] [Block2] [sync] [Block3] [sync]
                                  ↑
                          Task 2 starts here
```

**Deep concept — Schema in Header vs Footer:**
Avro puts the schema at the **beginning** because it's designed for streaming writes — the writer declares the schema once, then appends records. The reader reads the schema first, then can deserialize every record. Parquet puts the schema at the **end** because it needs to write all data first to compute statistics (min/max), which are part of the footer.

---

## 3. Avro Schema — JSON Definition

Avro schemas are written in JSON. The schema is both the contract between producer and consumer, and the instructions for binary serialization.

### Primitive Types


| Type    | Avro Name   | Size                       |
| ------- | ----------- | -------------------------- |
| Null    | `"null"`    | 0 bytes                    |
| Boolean | `"boolean"` | 1 byte                     |
| Int     | `"int"`     | Variable (zigzag encoding) |
| Long    | `"long"`    | Variable (zigzag encoding) |
| Float   | `"float"`   | 4 bytes                    |
| Double  | `"double"`  | 8 bytes                    |
| String  | `"string"`  | Length-prefixed UTF-8      |
| Bytes   | `"bytes"`   | Length-prefixed raw bytes  |


### Complex Types


| Type       | Syntax                                 | Purpose                               |
| ---------- | -------------------------------------- | ------------------------------------- |
| **Record** | `{"type": "record", "fields": [...]}`  | Structured object with named fields   |
| **Array**  | `{"type": "array", "items": "string"}` | Ordered list of values                |
| **Map**    | `{"type": "map", "values": "int"}`     | Key-value pairs (keys always strings) |
| **Enum**   | `{"type": "enum", "symbols": [...]}`   | Fixed set of named values             |
| **Union**  | `["null", "string"]`                   | Value can be one of multiple types    |
| **Fixed**  | `{"type": "fixed", "size": 16}`        | Fixed-length byte array               |


### Complete Record Schema Example

```json
{
  "type": "record",
  "name": "Customer",
  "namespace": "com.company.events",
  "fields": [
    {"name": "id", "type": "long"},
    {"name": "name", "type": "string"},
    {"name": "email", "type": ["null", "string"], "default": null},
    {"name": "age", "type": "int"},
    {"name": "created_at", "type": {"type": "long", "logicalType": "timestamp-millis"}},
    {"name": "tags", "type": {"type": "array", "items": "string"}, "default": []},
    {"name": "address", "type": {
      "type": "record",
      "name": "Address",
      "fields": [
        {"name": "city", "type": "string"},
        {"name": "state", "type": "string"},
        {"name": "zip", "type": "string"}
      ]
    }}
  ]
}
```

### Logical Types

Logical types add semantic meaning to primitive types. The underlying storage is a primitive, but the logical type tells the reader how to interpret it.


| Logical Type       | Underlying Type | Meaning                            |
| ------------------ | --------------- | ---------------------------------- |
| `date`             | int             | Days since Unix epoch (1970-01-01) |
| `time-millis`      | int             | Milliseconds since midnight        |
| `timestamp-millis` | long            | Milliseconds since Unix epoch      |
| `timestamp-micros` | long            | Microseconds since Unix epoch      |
| `decimal`          | bytes or fixed  | Arbitrary precision decimal number |
| `uuid`             | string          | UUID string                        |


---

## 4. Schema Evolution — Avro's Superpower

This is the **#1 reason** Avro is used in Kafka and data exchange. Schema evolution means changing the schema over time without breaking existing producers or consumers.

### Compatibility Modes


| Mode         | Definition                   | Rule                                      | Use Case                                                                   |
| ------------ | ---------------------------- | ----------------------------------------- | -------------------------------------------------------------------------- |
| **BACKWARD** | New schema can read old data | New fields must have defaults             | "I updated my consumer — can it still read old Kafka messages?" → Yes      |
| **FORWARD**  | Old schema can read new data | Removed fields must have had defaults     | "I updated my producer — can old consumers still read new messages?" → Yes |
| **FULL**     | Both directions work         | Only add/remove fields that have defaults | Safest — both producers and consumers can evolve independently             |
| **NONE**     | No compatibility guarantees  | Anything goes                             | Dangerous — can break consumers at any time                                |


### Evolution Rules


| Change                           | Backward?              | Forward? | Full?   |
| -------------------------------- | ---------------------- | -------- | ------- |
| **Add field WITH default**       | Yes                    | Yes      | Yes     |
| **Remove field WITH default**    | Yes                    | Yes      | Yes     |
| **Add field WITHOUT default**    | No                     | Yes      | No      |
| **Remove field WITHOUT default** | Yes                    | No       | No      |
| **Rename field**                 | No (use aliases)       | No       | No      |
| **Change type (compatible)**     | int→long, float→double | Yes      | Depends |
| **Change type (incompatible)**   | No                     | No       | No      |


### Evolution Example — How It Works in Practice

```
V1 Schema (original):
  fields: [
    {"name": "id",   "type": "long"},
    {"name": "name", "type": "string"}
  ]

V2 Schema (new field with default — BACKWARD + FORWARD compatible):
  fields: [
    {"name": "id",    "type": "long"},
    {"name": "name",  "type": "string"},
    {"name": "email", "type": ["null", "string"], "default": null}   ← NEW
  ]

V2 consumer reads V1 data → "email" missing → uses default (null)     ✓ BACKWARD
V1 consumer reads V2 data → ignores unknown "email" field             ✓ FORWARD
```

**The golden rule:** Always add new fields with a **default value** and use **union with null** (`["null", "string"]`). This ensures both backward and forward compatibility — FULL compatibility.

---

## 5. Schema Registry (Confluent)

### What It Is

The Schema Registry is a centralized service that stores and validates schemas. It sits alongside Kafka and enforces compatibility rules **before** producers can publish new schemas.


| Feature      | Detail                                                                    |
| ------------ | ------------------------------------------------------------------------- |
| **What**     | Central repository for Avro, Protobuf, and JSON schemas                   |
| **Why**      | Enforces compatibility rules — prevents producers from breaking consumers |
| **Where**    | Runs as a separate service alongside Kafka                                |
| **Storage**  | Stores schemas in a Kafka topic (`_schemas`)                              |
| **Supports** | Avro, Protobuf, JSON Schema                                               |


### How It Works — The Full Flow

```
Producer                          Schema Registry                    Consumer
   │                                    │                                │
   │  1. Register schema v2 ──────────►│                                │
   │                                    │  2. Check compatibility       │
   │                                    │     (v2 vs v1)                │
   │  3. Get schema ID (42) ◄──────────│                                │
   │                                    │                                │
   │  4. Send to Kafka:                 │                                │
   │     [0x00][schema_id=42]           │                                │
   │     [avro binary payload]          │                                │
   │         │                          │                                │
   │         └──────── Kafka ──────────────────────────────────────────►│
   │                                    │  5. Consumer reads schema_id  │
   │                                    │  6. Fetches schema ◄──────────│
   │                                    │  7. Deserializes ────────────►│
```

### Wire Format (Kafka + Schema Registry)

```
┌──────┬────────────┬──────────────────────┐
│ 0x00 │ Schema ID  │ Avro binary payload  │
│ (1B) │ (4 bytes)  │ (variable length)    │
└──────┴────────────┴──────────────────────┘
```

The message does **not** carry the full schema — just a 4-byte schema ID. The consumer fetches the schema from the registry and caches it. This keeps messages tiny while maintaining schema governance.

**Deep concept — What happens when a producer tries to register an incompatible schema:**
The Schema Registry **rejects** the registration. The producer gets an error and **cannot publish** messages with the new schema. This is the enforcement mechanism — it prevents breaking changes from reaching consumers. This is why Schema Registry is critical in production Kafka pipelines.

---

## 6. Size Comparison — Why Avro Beats JSON on the Wire

```
Same record: {"id": 12345, "name": "Alice", "age": 30, "city": "Mumbai"}

JSON:     ~60 bytes  (field names + text values + delimiters)
Avro:     ~20 bytes  (no field names, binary encoding, schema separate)
Protobuf: ~18 bytes  (field numbers + varint encoding)

At 1M messages/sec on Kafka:
  JSON:     ~60 MB/sec network bandwidth
  Avro:     ~20 MB/sec network bandwidth → 3x less
```

Avro is compact because field names are **not** in the payload — they're in the schema (stored once in the registry). Only values are serialized, using efficient binary encoding.

---

## 7. Avro in Spark

```python
# Read Avro file
df = spark.read.format("avro").load("data/customers.avro")

# Write as Avro
df.write.format("avro").save("output/customers.avro")

# Write with specific Avro compression
df.write.format("avro") \
    .option("avroSchema", avro_schema_json_string) \
    .option("compression", "snappy") \
    .save("output/customers.avro")

# Read from Kafka with Avro deserialization
from pyspark.sql.avro.functions import from_avro, to_avro

kafka_df = spark.readStream \
    .format("kafka") \
    .option("subscribe", "customers") \
    .load()

# Deserialize Avro payload using schema string
parsed_df = kafka_df.select(
    from_avro("value", schema_json_string).alias("data")
).select("data.*")
```

**Important Avro Spark options:**


| Option            | Purpose                                                       |
| ----------------- | ------------------------------------------------------------- |
| `avroSchema`      | Provide explicit Avro schema JSON string (avoids inference)   |
| `compression`     | Compression codec: `uncompressed`, `snappy`, `deflate`        |
| `mode`            | Write mode: `errorifexists`, `overwrite`, `append`, `ignore`  |
| `ignoreExtension` | Read files without `.avro` extension (useful for Kafka dumps) |
| `recordName`      | Set the Avro record name in the output schema                 |
| `recordNamespace` | Set the Avro namespace in the output schema                   |


**Important note:** Spark requires the `spark-avro` package. In Spark 3.x, it's built-in under `org.apache.spark.sql.avro`. In older versions, add it as a dependency: `--packages org.apache.spark:spark-avro_2.12:3.x.x`.

---

## 8. Interview Questions & How to Answer

**Q: "Why is Avro used with Kafka?"**

> Three reasons: (1) row-based — fast to serialize/deserialize individual records, (2) compact binary — 3x smaller than JSON on the wire, (3) schema evolution — producers and consumers can evolve schemas independently with backward/forward compatibility guarantees.

**Q: "How does Avro schema evolution work?"**

> Avro supports backward, forward, and full compatibility. The key rule: always add new fields with a default value. Old consumers ignore unknown fields (forward compatible). New consumers use the default for missing fields (backward compatible). The Schema Registry enforces these rules.

**Q: "What is the Schema Registry?"**

> A centralized service that stores Avro/Protobuf/JSON schemas and enforces compatibility rules. Producers register new schemas — if a schema is incompatible, the registry rejects it. Consumers fetch schemas by ID to deserialize messages. This prevents breaking changes in Kafka pipelines.

**Q: "Avro vs Parquet?"**

> Avro is row-based — fast writes, schema evolution, used for streaming (Kafka, CDC). Parquet is columnar — fast reads, column pruning, predicate pushdown, used for analytics. In a typical pipeline: Avro on the wire (Kafka), Parquet on disk (data lake).

**Q: "Avro vs JSON?"**

> Avro is binary, 3x smaller, with enforced schema and evolution support. JSON is text-based, human-readable, with no schema enforcement. For machine-to-machine communication at scale, Avro wins. For APIs and human debugging, JSON wins.

**Q: "What is backward compatibility?"**

> A new consumer with the v2 schema can read data written by an old producer with the v1 schema. This works because new fields have default values — if missing from old data, the default fills in.

**Q: "How are Avro messages stored in Kafka?"**

> Each message has: 1 magic byte (0x00) + 4-byte schema ID + Avro binary payload. The full schema is not in the message — the consumer fetches it from the Schema Registry using the schema ID and caches it locally.

---

---

