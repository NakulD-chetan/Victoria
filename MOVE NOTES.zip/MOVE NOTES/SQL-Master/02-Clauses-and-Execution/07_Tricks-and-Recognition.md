# Clauses and Execution — Tricks and Recognition

| Signal | Think |
|--------|--------|
| “Filter before group” | `WHERE` |
| “Filter on SUM/COUNT/AVG” | `HAVING` or window + outer filter |
| “Top N per group” | Window (`ROW_NUMBER`) or lateral join — not only `GROUP BY` |
| “Dedupe rows” | `DISTINCT` or `GROUP BY` keys — know grain |

---

*Next: [[08_Problem-List]]*
