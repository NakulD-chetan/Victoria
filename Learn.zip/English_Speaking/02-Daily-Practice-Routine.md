# Daily Practice Routine

> *"30 minutes a day, every day — yeh hi fluency ka shortcut hai"*

Yeh chapter tumhara daily schedule hai. Isko follow karo religiously. English seekhne ka sabse bada secret hai: **consistency beats intensity**. 1 din 3 ghanta padhne se kuch nahi hoga. Roz 30 minute padhne se sab hoga.

---

## 1. Daily 30-Minute Routine

### Morning — INPUT Phase (15 min)

| Time | Activity | Kaise Karein |
|------|----------|-------------|
| **5 min** | **Listen** | Ek English podcast/YouTube video chalao (BBC Learning English, TED-Ed). Dhyaan se suno |
| **5 min** | **Shadow** | Jo suna woh repeat karo — same tone, same speed. Parrot ki tarah copy karo |
| **5 min** | **Read aloud** | Koi bhi English article/paragraph zor se padho. Newspaper, blog, ya phone pe kuch bhi |

[TIP] Morning mein karo kyunki dimag fresh hota hai. Chai/coffee peete waqt bhi kar sakte ho.

### Afternoon — THINK Phase (5 min)

| Time | Activity | Kaise Karein |
|------|----------|-------------|
| **2 min** | **Name things** | Apne aas-paas ki cheezein English mein bolo: "This is my desk. That's a water bottle." |
| **3 min** | **Self-talk** | Jo kar rahe ho woh English mein describe karo: "I am eating lunch. The food is tasty." |

[TIP] Yeh kaam mein break ke time karo. Kisi ko bolne ki zaroorat nahi — apne mann mein karo.

### Evening — OUTPUT Phase (10 min)

| Time | Activity | Kaise Karein |
|------|----------|-------------|
| **3 min** | **Write** | 5 sentences likho apne din ke baare mein. Simple ho — "I went to office. I had a meeting." |
| **3 min** | **Speak** | Mirror ke saamne ya phone mein record karo — koi bhi topic 1-2 minute bolo |
| **2 min** | **New words** | 3 new words seekho with meaning + ek sentence banao har word ka |
| **2 min** | **Review** | Kal ke 3 words yaad karo. Sentence bolo unka. |

---

## 2. Weekly Focus Areas

| Day | Special Focus | Extra Activity (5-10 min) |
|-----|--------------|--------------------------|
| **Monday** | Grammar | Ek tense practice karo (Chapter 03 se) |
| **Tuesday** | Vocabulary | 5 new words seekho with sentences |
| **Wednesday** | Speaking | 3 minute non-stop bolo kisi topic pe |
| **Thursday** | Listening | Ek English song suno, lyrics padho, samjho |
| **Friday** | Reading | 1 short article padho, summary English mein likho |
| **Saturday** | Conversation | Kisi dost se English mein baat karo (ya AI chatbot se) |
| **Sunday** | Review | Puri week ki words, sentences, recordings review karo |

---

## 3. The 30-Day Progressive Plan

### Week 1 — Foundation (Din 1-7)

> **Goal:** English mein sochna start karo, basic sentences bolo

| Activity | Daily Time | Target |
|----------|-----------|--------|
| Phone language English mein change | 1 min | Done on Day 1 |
| Apne room ki cheezein English mein bolo | 5 min | 20+ objects |
| Self-introduction practice | 5 min | Smooth 30-second intro |
| 1 YouTube video dekho + shadow | 10 min | Har din ek naya video |
| 3 new words seekho | 5 min | 21 words by end of week |
| Mirror ke saamne bolo | 5 min | 1 minute non-stop |

**Week 1 Milestone:** Apna introduction confidently de pao. 21 new words yaad ho.

---

### Week 2 — Building Blocks (Din 8-14)

> **Goal:** Simple conversations kar pao, basic grammar samjho

| Activity | Daily Time | Target |
|----------|-----------|--------|
| Present tense master karo | 10 min | Simple, Continuous, Perfect |
| Daily routine English mein describe karo | 5 min | Full morning-to-night description |
| Common phrases practice (Chapter 07) | 5 min | 10 phrases per day |
| Ek paragraph likho | 5 min | 5-7 sentences |
| Record and listen | 5 min | Compare with Day 1 |

**Week 2 Milestone:** Apna poora din English mein describe kar pao. 50+ phrases yaad ho.

---

### Week 3 — Conversation Ready (Din 15-21)

> **Goal:** Real conversations mein participate kar pao

| Activity | Daily Time | Target |
|----------|-----------|--------|
| Past + Future tense practice | 10 min | All 12 tenses ka basic idea |
| Role-play conversations | 5 min | Shopping, restaurant, phone call |
| 1 English article padho + summarize | 10 min | Summary zor se bolo |
| Kisi se English mein baat karo | 5 min | Dost, colleague, ya AI chatbot |

**Week 3 Milestone:** Kisi se 2-3 minute English mein baat kar pao without freezing.

---

### Week 4 — Fluency Building (Din 22-30)

> **Goal:** Confidence aur speed improve karo

| Activity | Daily Time | Target |
|----------|-----------|--------|
| 3 minute non-stop speaking | 5 min | Bina atkein bolo |
| English movie/show dekho (subtitles ON) | 15 min | Phrases note karo |
| Debate with yourself | 5 min | Ek topic pe for + against bolo |
| Week 1 ki recording suno + compare | 5 min | Progress dekho |

**Week 4 Milestone:** 3 minute bina atkein kisi bhi topic pe bol pao. Noticeable improvement recording mein dikhe.

---

## 4. Habit Tracking Checklist

Har din tick karo:

```
Week: ___

         Mon  Tue  Wed  Thu  Fri  Sat  Sun
Listen   [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Shadow   [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Read     [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Speak    [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Write    [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Words    [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
Record   [ ]  [ ]  [ ]  [ ]  [ ]  [ ]  [ ]
```

[TIP] Yeh checklist print karke wall pe lagao ya phone ke notes mein rakho. Har din tick karna ek chhoti achievement hai.

---

## 5. Golden Rules of Daily Practice

| # | Rule | Kyun |
|---|------|------|
| 1 | **Same time, same place** | Habit ban jaati hai — dimag automatically English mode mein aata hai |
| 2 | **30 min minimum, no maximum** | Kam se kam 30 min. Zyada karo toh aur achha |
| 3 | **Never skip 2 days in a row** | 1 din miss hua? Chalega. 2 din? Chain toot jati hai |
| 4 | **Speak out loud** | Mann mein padhna enough nahi hai. Zor se bolo — mouth muscles ko train karo |
| 5 | **Track your progress** | Checklist + weekly recording = motivation booster |
| 6 | **Mix activities** | Sirf grammar mat padho. Listen + Speak + Read + Write — sab karo |
| 7 | **Enjoy the process** | English songs, movies, memes — fun cheezein bhi English mein consume karo |

---

## 6. Time Nahi Hai? Micro-Practice Ideas

| Situation | Kya Karein | Time |
|-----------|-----------|------|
| **Commute mein** | English podcast suno | 10-20 min |
| **Waiting mein** | Phone pe English article padho | 5 min |
| **Bathroom mein** | Apne aap se English mein baat karo | 5 min |
| **Khana khaate waqt** | English YouTube video dekho | 10 min |
| **Sone se pehle** | 5 sentences likho din ke baare mein | 5 min |
| **Office break** | Colleague se English mein chhoti baat karo | 5 min |

> *"Waqt nahi milta" — yeh bahana hai. Waqt nikalte hain."*

---

*Agle chapter mein: Grammar — Tenses. English grammar ka backbone. All 12 tenses ek jagah.*
