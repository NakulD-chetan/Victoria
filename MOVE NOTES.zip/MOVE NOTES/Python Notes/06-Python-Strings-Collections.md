# Python Strings and Collections (List, Tuple, Set, Dict)

> *"Strings are immutable — you can slice, but you can't change the same object in place"* — Core rule

Text processing and data structures — almost every real program stands on these. After [[05-Python-Functions-Scope]], this file gives you the full toolbox to organize data.

---

## 1. Strings — basics and immutability

> **Definition:** A string (`str`) is an immutable ordered sequence of Unicode code points representing text.

**Why we need it:** Immutability makes strings safe to share, hash, and use as dict keys; rich methods cover searching, splitting, and formatting without manual character buffers.

**Syntax:**
```python
"<text>" | '<text>' | """<multiline>"""
<str>[<index>]
<str>.<method>(...)
```

```python
s = "Python"
s[0]          # 'P'
# s[0] = 'p'  # TypeError — immutable
```

### Common methods


| Method                            | What it does (easy English)                                           |
| --------------------------------- | --------------------------------------------------------------------- |
| `lower()`, `upper()`              | Converts string to all lowercase or all uppercase letters             |
| `strip()`, `lstrip()`, `rstrip()` | Removes extra spaces from both sides / left side / right side         |
| `split(sep)`                      | Breaks a string into a list by splitting at the separator             |
| `join(iter)`                      | Joins a list of strings into one string with a separator between them |
| `replace(old, new)`               | Finds a piece of text and swaps it with new text (returns new string) |
| `startswith(x)`, `endswith(x)`    | Checks if string begins with / ends with a given text → True/False    |
| `find(x)`                         | Searches for text, returns position (or -1 if not found)              |
| `index(x)`                        | Same as find but **raises error** if not found                        |


```python
"Hello".lower()              # "hello"  → all letters become small
"Hello".upper()              # "HELLO"  → all letters become capital
"  hello  ".strip()          # "hello"  → removes spaces from both sides
"  hello  ".lstrip()         # "hello  " → removes spaces from left only
"a-b-c".split("-")           # ["a", "b", "c"] → breaks string at every "-"
",".join(["a", "b", "c"])    # "a,b,c"  → glues list items with "," between them
"hello".replace("l", "r")    # "herro"  → swaps every "l" with "r"
"hello".startswith("he")     # True → string starts with "he"
"hello".find("ll")           # 2 → "ll" found at position 2
"hello".find("xyz")          # -1 → not found, returns -1
```

**Watch Out!** `str` methods return a **new object** — the original does not change.

---

## 2. Slicing — common sequence pattern

> **Definition:** Slicing selects a sub-range of a sequence (string, list, etc.) using optional start, stop, and step indices, producing a new sequence of the same type.

**Why we need it:** You can express “from here to there,” strides, and reversal compactly without manual loops or repeated indexing.

**Syntax:**
```python
<sequence>[<start>:<stop>:<step>]
```

```python
s = "abcdefghij"
s[2:7]    # "cdefg"  → picks characters from position 2 up to (not including) 7
s[:5]     # "abcde"  → picks first 5 characters (start to position 5)
s[5:]     # "fghij"  → picks from position 5 to the end
s[::2]    # "acegi"  → picks every 2nd character (skip one each time)
s[::-1]   # "jihgfedcba" → reverses the whole string
```

The same slicing works on **lists** — practice with iterators in [[04-Python-Loops-Comprehensions]].

**Interview Tip:** `s[n:m]` — `m` is exclusive; negative index counts from the end.

---

## 3. List — ordered, mutable

> **Definition:** A list is an ordered, mutable sequence that can hold references to any objects and supports in-place growth, shrinkage, and reordering.

**Why we need it:** It is the default “many items in order” type when you need indexing, iteration, and methods like `append` without fixed size.

**Syntax:**
```python
[<item0>, <item1>, ...]
<list>.append(<x>) / .extend(<iterable>) / .insert(<i>, <x>) / ...
```

```python
nums = [1, 2, 3]
nums.append(4)       # Adds 4 at the END → [1, 2, 3, 4]
nums.extend([5, 6])  # Adds MULTIPLE items at the end → [1, 2, 3, 4, 5, 6]
nums.insert(0, 0)    # Puts 0 at position 0 (beginning) → [0, 1, 2, 3, 4, 5, 6]
nums.pop()           # Removes and returns the LAST item (6) → [0, 1, 2, 3, 4, 5]
nums.pop(0)          # Removes and returns item at position 0 → [1, 2, 3, 4, 5]
nums.remove(2)       # Finds FIRST 2 in the list and removes it → [1, 3, 4, 5]
nums.sort()          # Sorts the list in place (low to high) → [1, 3, 4, 5]
nums.reverse()       # Flips the list order in place → [5, 4, 3, 1]
nums.index(4)        # Finds where 4 is → returns position 1
len(nums)            # Tells how many items are in the list → 4
nums.clear()         # Removes ALL items → []
```

**Quick summary:**

- **append** = add ONE item at the end
- **extend** = add MANY items at the end (from another list)
- **insert** = put an item at a SPECIFIC position
- **pop** = take out the last item (or item at given position)
- **remove** = find a value and delete its first occurrence
- **sort** = arrange items in order (changes the list itself)
- **reverse** = flip the list order (changes the list itself)
- **index** = tell me WHERE this value is
- **clear** = empty the whole list


| Op           | Complexity     | What it means                                |
| ------------ | -------------- | -------------------------------------------- |
| append       | O(1) amortized | Very fast — just adds to end                 |
| insert(0, x) | O(n)           | Slow for big lists — shifts everything right |
| `x in lst`   | O(n)           | Checks one by one — slow for big lists       |
| pop()        | O(1)           | Fast — removes from end                      |
| pop(0)       | O(n)           | Slow — shifts everything left                |


```python
stack = []
stack.append(1)   # push onto stack → [1]
stack.pop()       # pop from stack → [] (returns 1)
```

---

## 4. Tuple — ordered, immutable

> **Definition:** A tuple is an ordered, immutable sequence; once created, you cannot change which objects it refers to (though mutable objects inside may still change).

**Why we need it:** Immutability signals fixed records, works as dict keys when contents are hashable, and gives a light-weight way to return multiple values.

**Syntax:**
```python
(<a>, <b>, ...)     # single element: (<x>,)
tuple(<iterable>)
```

```python
t = (1, 2, 3)
single = (42,)   # comma required — otherwise you get an int
a, b, c = t      # unpacking — a=1, b=2, c=3 (assigns each value to a variable)
t[0]             # 1 → access item by position (same as list)
len(t)           # 3 → count of items
t.count(2)       # 1 → how many times 2 appears in tuple
t.index(3)       # 2 → position where 3 is found
# t[0] = 99     # ERROR — tuples cannot be changed after creation
```

**Quick summary:**

- **Tuple** = like a list but you CANNOT change it after making it
- **Use when:** fixed records, dict keys (if contents are hashable), returning multiple values from a function
- **Indexing** works same as list: `t[0]`, `t[-1]`
- **count** = how many times a value appears
- **index** = where a value is located

**Watch Out!** A `tuple` with **mutable** items inside — the outer tuple is immutable but the inner contents can still change:

```python
t = ([1],)
t[0].append(2)   # allowed
```

---

## 5. Set — unordered unique elements

> **Definition:** A set is an unordered collection of unique hashable elements with operations for membership and set algebra (union, intersection, difference).

**Why we need it:** Fast average-time membership and automatic deduplication beat scanning lists for many lookup- and uniqueness-heavy tasks.

**Syntax:**
```python
{<a>, <b>, ...}     # non-empty literal; empty set: set()
<set>.add(<x>) / .remove(<x>) / .discard(<x>) / ...
```

```python
s = {1, 2, 3}
s.add(4)             # Adds 4 to the set → {1, 2, 3, 4}
s.add(3)             # 3 already exists — set ignores duplicates, no change
s.remove(4)          # Removes 4 — raises error if not found
s.discard(99)        # Tries to remove 99 — does nothing if not found (safe)
s.pop()              # Removes and returns any random item
s2 = set("hello")   # Makes set from letters → {'h','e','l','o'} (no duplicates)
len(s)               # How many items in the set
2 in s               # True → checks if 2 is in the set (very fast!)
s.clear()            # Removes everything → empty set
```

**Quick summary:**

- **add** = put one item in (ignores if already there)
- **remove** = delete an item (error if not found)
- **discard** = delete an item (NO error if not found — safer)
- **pop** = take out a random item
- **clear** = empty the whole set
- **in** = check if something exists (very fast — O(1))


| Op  | What it does                                             | Example                     |
| --- | -------------------------------------------------------- | --------------------------- |
| `|` | **Union** — combines everything from both sets           | `{1,2} | {2,3}` → `{1,2,3}` |
| `&` | **Intersection** — only items in BOTH sets               | `{1,2} & {2,3}` → `{2}`     |
| `-` | **Difference** — items in first but NOT in second        | `{1,2} - {2,3}` → `{1}`     |
| `^` | **Symmetric diff** — items in one OR other, but NOT both | `{1,2} ^ {2,3}` → `{1,3}`   |


**Interview Tip:** Membership `x in set` is average **O(1)** — dedup / fast lookup.

**Watch Out!** `{}` is an empty **dict** — empty set is `set()`.

---

## 6. Dictionary — key → value mapping

> **Definition:** A dictionary maps unique keys to values for O(1) average lookups by key; from Python 3.7+ insertion order is preserved as a language guarantee.

**Why we need it:** Records, indexes, caches, and frequency maps are naturally “look up by key”; the type is optimized for that access pattern.

**Syntax:**
```python
{<key>: <value>, ...}
<dict>[<key>]              # get / set
<dict>.get(<key>, <default>)
<dict>.items() / .keys() / .values()
```

```python
d = {"name": "Ravi", "age": 30}
d["city"] = "Pune"         # Adds new key "city" with value "Pune"
d["name"]                  # "Ravi" → get value by key
d.get("x", "NA")           # "NA" → tries to get "x", returns "NA" if key not found (safe)
d.pop("age")               # Removes "age" key and returns its value (30)
d.update({"a": 1, "b": 2}) # Adds/updates multiple key-value pairs at once
d.keys()                   # All keys → dict_keys(["name", "city", "a", "b"])
d.values()                 # All values → dict_values(["Ravi", "Pune", 1, 2])
d.items()                  # All pairs → dict_items([("name","Ravi"), ...])
len(d)                     # How many key-value pairs
"name" in d                # True → checks if key exists (fast!)
d.clear()                  # Removes everything → {}

for k, v in d.items():     # Loop through all key-value pairs
    print(k, v)
```

**Quick summary:**

- **d[key]** = get value (error if key missing)
- **d.get(key, default)** = get value (returns default if key missing — safer)
- **d[key] = value** = add or update a key-value pair
- **pop(key)** = remove a key and get its value back
- **update(dict2)** = merge another dict into this one
- **keys/values/items** = get all keys / all values / all pairs
- **in** = check if a key exists (fast)
- **clear** = empty the whole dict

Python 3.7+ — **insertion order** is preserved (language guarantee 3.7+).


| Method                          | What it does                                                 |
| ------------------------------- | ------------------------------------------------------------ |
| `keys()`, `values()`, `items()` | Returns all keys / all values / all (key, value) pairs       |
| `get(k, default)`               | Safe way to get value — returns default if key not found     |
| `pop(k)`                        | Removes key and returns its value                            |
| `popitem()`                     | Removes and returns the last inserted (key, value) pair      |
| `setdefault(k, v)`              | Returns value if key exists, else sets it to v and returns v |
| `update(dict2)`                 | Adds all key-value pairs from dict2 into this dict           |


```python
from collections import Counter  # better for counts — [[17-Python-FAANG-Interview-Must-Know]]
```

---

## 7. When to use what — comparison


| Structure | Order                    | Duplicate           | Mutable              | When to use                              |
| --------- | ------------------------ | ------------------- | -------------------- | ---------------------------------------- |
| list      | Yes (keeps order)        | Yes (allows)        | Yes (can change)     | General purpose — storing items in order |
| tuple     | Yes (keeps order)        | Yes (allows)        | No (cannot change)   | Fixed data, dict keys, function returns  |
| set       | No (no guaranteed order) | No (auto removes)   | Yes (can add/remove) | Remove duplicates, fast membership check |
| dict      | Insert order (3.7+)      | Keys must be unique | Yes (can change)     | Key-value lookups, counting, caching     |


 Conceptually unordered comparison; iteration order defined in CPython 3.7+.

---

## 8. Copy — shallow vs deep

> **Definition:** A shallow copy duplicates the outer container but leaves inner objects shared; a deep copy recursively copies nested containers so no nested object is shared with the original.

**Why we need it:** Assignment only shares references; choosing shallow vs deep avoids accidental mutation of “copied” data when structures nest lists or dicts.

**Syntax:**
```python
<new_list> = <old_list>.copy()   # or list(<old>), <old>[:], etc.
import copy
copy.deepcopy(<nested_structure>)
```

```python
import copy
a = [[1], [2]]
b = list(a)          # Shallow copy — makes new outer list, but inner lists are SHARED
c = copy.deepcopy(a) # Deep copy — makes new everything, nothing is shared
b[0].append(99)      # a[0] also changes! (because shallow copy shares inner lists)
c[0].append(88)      # a[0] NOT affected (deep copy is fully independent)
```

**Quick summary:**

- **Shallow copy** (`list(a)` or `a.copy()`) = new list, but items inside still point to same objects
- **Deep copy** (`copy.deepcopy(a)`) = completely independent copy, nothing shared

**Interview Tip:** Nested structures are a common **deep** interview topic — [[17-Python-FAANG-Interview-Must-Know]].

---

## 9. `collections` preview — Counter

> **Definition:** `Counter` is a `dict` subclass that counts hashable objects—keys are items, values are tallies—and supports convenient frequency queries.

**Why we need it:** Histograms and “how many of each?” problems avoid manual initialization and increment loops over a plain dict.

**Syntax:**
```python
from collections import Counter
Counter(<iterable_or_mapping>)
<counter>[<element>]
<counter>.most_common(<n>)
```

```python
from collections import Counter
c = Counter("mississippi")  # Counts each letter → {'i':4, 's':4, 'p':2, 'm':1}
c.most_common(2)            # Top 2 most frequent → [('i',4), ('s',4)]
c["i"]                      # 4 → how many times 'i' appears
```

Interview depth: [[17-Python-FAANG-Interview-Must-Know]].

---

## 10. List methods cheat sheet


| Method             | What it does (easy English)                                 |
| ------------------ | ----------------------------------------------------------- |
| `append(x)`        | Adds ONE item at the end of the list                        |
| `extend(iter)`     | Adds ALL items from another list/iterable at the end        |
| `insert(i, x)`     | Puts item at position `i`, pushes others right              |
| `remove(x)`        | Finds first `x` and deletes it — ValueError if not found    |
| `pop()` / `pop(i)` | Takes out and returns the last item (or item at position i) |
| `clear()`          | Removes everything — list becomes empty                     |
| `sort()`           | Arranges items in order inside the same list (returns None) |
| `sorted(lst)`      | Returns a NEW sorted list — original stays the same         |
| `reverse()`        | Flips list order inside the same list (returns None)        |
| `index(x)`         | Finds position of first `x` — ValueError if not found       |
| `count(x)`         | Counts how many times `x` appears in the list               |
| `copy()`           | Makes a shallow copy (new list, same items)                 |


**Watch Out!** `sort()` vs `sorted(lst)` — the first returns `None`, the second returns a **new list**.

---

## 11. Dict iteration patterns

```python
for k in d:              # Loop through all KEYS only
    print(k)

for k, v in d.items():   # Loop through all KEY-VALUE pairs together
    print(k, v)

for v in d.values():     # Loop through all VALUES only
    print(v)

# Safe way to delete items while looping — make a snapshot of keys first
for k in list(d.keys()):
    if cond:
        del d[k]         # del removes a key-value pair by key
```

---

## 12. Set operations — oral exam table


| Op  | What it does                                         | Example                   |
| --- | ---------------------------------------------------- | ------------------------- |
| `|` | **Union** — gives all unique items from both sets    | `{1,2} | {3}` → `{1,2,3}` |
| `&` | **Intersection** — gives only items present in BOTH  | `{1,2} & {2,3}` → `{2}`   |
| `-` | **Difference** — items in left set but NOT in right  | `{1,2,3} - {2}` → `{1,3}` |
| `^` | **Symmetric diff** — items in either but NOT in both | `{1,2} ^ {2,3}` → `{1,3}` |


---

## Quick Memory Card

```
+------------------------------------------+
| STR                                       |
| - immutable, slicing, many methods       |
| - join/split/strip                       |
+------------------------------------------+
| LIST                                      |
| - mutable, ordered                       |
| - append O(1), insert front O(n)         |
+------------------------------------------+
| TUPLE                                     |
| - immutable, packing/unpacking           |
| - (x,) singleton                         |
+------------------------------------------+
| SET                                       |
| - unique, fast in                        |
| - empty: set()                           |
+------------------------------------------+
| DICT                                      |
| - key-value, 3.7+ order                |
| - items() iteration                     |
+------------------------------------------+
| COPY                                      |
| - shallow vs deepcopy                    |
+------------------------------------------+
```

---

*Next: [[07-Python-OOP-Classes-Objects]]*
