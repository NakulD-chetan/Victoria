# Recursion-Backtracking — Common Mistakes

> **Permanent Recall:** Top 5: (1) Forgetting base case → stack overflow. (2) Not undoing state → corrupted backtrack. (3) Duplicates in output → missing sort+skip. (4) Modifying input without restoring. (5) Shallow copy of path → shared reference bug.

---

## 1. Forgetting Base Case (Stack Overflow)

### What Happens

- Recursion never stops
- Stack overflow / infinite recursion

### Wrong

```python
def backtrack(path, i):
    path.append(nums[i])
    backtrack(path, i + 1)  # No base case!
    path.pop()
```

### Right

```python
def backtrack(path, i):
    if i == len(nums):      # BASE CASE
        result.append(path[:])
        return
    path.append(nums[i])
    backtrack(path, i + 1)
    path.pop()
```

### Checklist

- [ ] Every recursive function has a base case
- [ ] Base case is reachable (no infinite path to it)
- [ ] Base case does the right thing (record solution, return)

---

## 2. Not Undoing State (Corrupted Backtrack)

### What Happens

- Choices "leak" into sibling branches
- Wrong solutions, duplicate/missing results

### Wrong

```python
def backtrack(r, c):
    board[r][c] = 'Q'
    backtrack(r + 1, 0)
    # Forgot: board[r][c] = '.'  ← UNCHOOSE!
```

### Right

```python
def backtrack(r, c):
    board[r][c] = 'Q'
    backtrack(r + 1, 0)
    board[r][c] = '.'   # UNCHOOSE — restore state
```

### Rule

**Every CHOOSE must have a matching UNCHOOSE before the loop continues or function returns.**

### Common Unchoose Locations

| State | Choose | Unchoose |
|-------|--------|----------|
| `path` | `path.append(x)` | `path.pop()` |
| `used[i]` | `used[i] = True` | `used[i] = False` |
| `board[r][c]` | `board[r][c] = 'Q'` | `board[r][c] = '.'` |
| `cols.add(c)` | `cols.add(c)` | `cols.remove(c)` |

---

## 3. Duplicates in Output (Not Handling Sorted + Skip)

### What Happens

- Input `[1, 2, 2]` → subsets include both `{2}` and `{2}` (duplicate)
- Permutations of `[1, 1, 2]` → `[1,1,2]` and `[1,1,2]` (same ordering, duplicate)

### Root Cause

- Not sorting before backtracking
- Not skipping duplicate elements with the right condition

### Subsets with Duplicates — Wrong

```python
def backtrack(start):
    result.append(path[:])
    for i in range(start, len(nums)):
        path.append(nums[i])
        backtrack(i + 1)
        path.pop()
# nums = [1,2,2] → {2} appears twice
```

### Subsets with Duplicates — Right

```python
nums.sort()
def backtrack(start):
    result.append(path[:])
    for i in range(start, len(nums)):
        if i > start and nums[i] == nums[i-1]:
            continue   # skip duplicate
        path.append(nums[i])
        backtrack(i + 1)
        path.pop()
```

### Permutations with Duplicates — Right

```python
nums.sort()
# In loop:
if i > 0 and nums[i] == nums[i-1] and not used[i-1]:
    continue
```

**Why `not used[i-1]`?** Ensures we use identical elements in order — only one canonical ordering.

---

## 4. Modifying Input Without Restoring

### What Happens

- Input array/board is mutated
- Fails if input is reused or multiple calls expected

### Wrong (Word Search)

```python
def backtrack(r, c, idx):
    # ...
    board[r][c] = '#'   # Mutates input
    backtrack(r+1, c, idx+1)
    # Forgot to restore! board[r][c] = word[idx]
```

### Right

```python
board[r][c] = '#'
backtrack(r+1, c, idx+1)
board[r][c] = word[idx]   # Restore
```

### When It's OK

- Problem says "modify in place" (e.g., Sudoku)
- You're building the result in the input structure and that's expected

### When It's NOT OK

- Need to try multiple starting points (Word Search from each cell)
- Input might be reused

---

## 5. Deep Copy vs Shallow Copy of Path

### What Happens

- `result.append(path)` → path is a reference
- Later `path.pop()` mutates the same list that's in result
- All "solutions" in result end up the same (empty or last state)

### Wrong

```python
result.append(path)   # Shallow — path is reference
# ... later path.pop() mutates what's in result!
```

### Right

```python
result.append(path[:])      # Python: copy
result.append(list(path))   # Python: explicit copy
result.push_back(path);     # C++: vector copies by value (OK)
```

### C++ Note

- `result.push_back(path)` in C++ is fine — `vector` copies by value
- But if `path` contains pointers/references, ensure deep copy

### Python Rule

**Always `result.append(path[:])` or `path.copy()` when storing the current path.**

---

## 6. Off-by-One in Index / Base Case

### Subsets

- Base case: add at every node (before loop) OR at leaf?
- Subsets: add at every node (each prefix is a subset)
- Combinations: add only when `len(path) == k`

### Combinations

```python
# Wrong: backtrack(0) when n=4, k=2 and elements are 1..4
# Right: start from 1, range(1, n+1)
```

### Permutations

- Base case: `len(path) == len(nums)` (all positions filled)

---

## 7. Pruning Condition Wrong Way Around

### Wrong

```python
if candidates[i] < remain:   # Include when SMALLER
    path.append(candidates[i])
```

- Should be: include when `candidates[i] <= remain` (can still add if equal)

### Wrong

```python
if i > start and nums[i] == nums[i-1]:
    path.append(nums[i])   # Skip means DON'T add — we're in the skip branch!
```

- The `continue` should skip the duplicate, not add it.

---

## 8. Forgetting to Sort for Duplicate Handling

- **Subsets with dup, Permutations with dup, Combination Sum II** — all need `sort()` first
- Without sort, the "skip when nums[i]==nums[i-1]" logic doesn't group duplicates

---

## Quick Debug Checklist

| Symptom | Likely Cause |
|---------|--------------|
| Stack overflow | No base case / base case never reached |
| Wrong/missing solutions | Forgot to unchoose / wrong unchoose |
| Duplicate solutions | No sort + skip for duplicates |
| Empty results | Base case never triggered / wrong condition |
| All results same | Shallow copy of path |
| Input corrupted | Modifying input without restore |

---

## FINAL MEMORY COMPRESSION BLOCK

```
1. BASE CASE:     Must exist, must be reachable
2. UNCHOOSE:      Every choose → matching unchoose
3. DUPLICATES:    Sort + skip (i>start && nums[i]==nums[i-1])
4. RESTORE INPUT: If mutating (e.g. board), restore on backtrack
5. DEEP COPY:     result.append(path[:]) not result.append(path)
6. PRUNING:       Check logic (<= not <, continue = skip)
7. SORT:          Required for duplicate handling
```
