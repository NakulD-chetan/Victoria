import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  for (let i = 0; i < n; i++) {
    let swapped = false;
    for (let j = 0; j < n - 1 - i; j++) {
      steps.push({ type: 'compare', i: j, j: j + 1, array: [...a] });
      if (a[j] > a[j + 1]) {
        [a[j], a[j + 1]] = [a[j + 1], a[j]];
        steps.push({ type: 'swap', i: j, j: j + 1, array: [...a] });
        swapped = true;
      }
    }
    steps.push({ type: 'pass-done', sorted: n - 1 - i, array: [...a] });
    if (!swapped) break;
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 20) {
  return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5);
}

export default function BubbleSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    const steps = generateSteps(arr);
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements generated` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'compare') {
      colors[step.i] = 'compare'; colors[step.j] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Compare [${step.i}]=${step.array[step.i]} vs [${step.j}]=${step.array[step.j]}` });
    } else if (step.type === 'swap') {
      colors[step.i] = 'swap'; colors[step.j] = 'swap';
      store.incSwaps();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Swap [${step.i}] ↔ [${step.j}]` });
      canvasRef.current?.addAnim('swap', { i: step.i, j: step.j }, 300);
    } else if (step.type === 'pass-done') {
      for (let k = step.sorted; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: `Pass complete, position ${step.sorted} sorted` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors, pointers: {} });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
