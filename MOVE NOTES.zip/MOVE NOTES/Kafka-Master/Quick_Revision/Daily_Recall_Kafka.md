# Apache Kafka — Daily Recall (Data Engineer)

> **Read 10 minutes daily.** Tie each bullet to **one incident** or **one metric dashboard** you actually use.

---

## Chapter 1 — Architecture DNA

```
🧠 Kafka = distributed commit log (not a queue DB)
🧠 Partition = parallelism + ordering boundary
🧠 Pull consumers; KRaft > ZK (modern)
⚠️  Global ordering = design fiction at scale
```

---

## Chapter 2 — Topics / Partitions / Offsets

```
🧠 Offset = per-partition cursor
🧠 Key → same partition → per-key order
🧠 RF + ISR; leader serves clients
⚠️  Auto-commit ≠ processed
```

---

## Chapter 3 — Producers

```
🧠 linger + batch.size = throughput vs latency
🧠 acks=all + min.insync = durability pair
🧠 enable.idempotence = retry dedupe
🧠 transactions = EOS publish + offsets
⚠️  buffer.memory exhaustion = backpressure
```

---

## Chapter 4 — Consumers / Groups

```
🧠 Group = load balance; many groups = fan-out
🧠 Lag = LEO − position (per partition)
🧠 max.poll.interval vs processing time
⚠️  Rebalance storm = GC / slow poll / heartbeats
```

---

## Chapter 5 — Brokers / ISR

```
🧠 Leader + followers; ISR = caught-up set
🧠 HW vs LEO — visibility story
🧠 unclean leader election = loss risk
🧠 Segments + .index + .timeindex
```

---

## Chapter 6 — Exactly-Once

```
🧠 At-most / at-least / exactly-once definitions
🧠 read_committed for transactional reads
🧠 End-to-end EOS needs idempotent sink
⚠️  transactional.id fencing story
```

---

## Chapter 7 — Connect

```
🧠 Source vs Sink; tasks.max parallelism
🧠 Converters + Schema Registry
🧠 SMTs = light transforms; DLQ for poison
🎯 Debezium = CDC standard
```

---

## Chapter 8 — Streams / ksqlDB

```
🧠 Library model; RocksDB state; changelog restore
🧠 KStream vs KTable vs GlobalKTable
🧠 Joins need co-partitioning
🔄 Compare Spark / Flink for heavy ETL
```

---

## Chapter 9 — Schema Registry

```
🧠 Backward / Forward / Full compatibility
🧠 Subject naming = evolution scope
⚠️  Breaking rename without Avro aliases
```

---

## Chapter 10 — Performance / Monitoring

```
🧠 Producer batch + compression
🧠 Broker threads + segment bytes
🧠 URP, ISR, RequestHandler idle, bytes in/out
🧠 Page cache > giant heap
```

---

## Chapter 11 — Pipelines

```
🧠 CDC: Debezium → Kafka → Flink/Spark → lake
🧠 Outbox pattern for atomic emit
🧠 MM2 for multi-DC — offset mapping
```

---

## Chapter 12 — Mistakes

```
⚠️  Too many partitions; RF=1 prod
⚠️  No keys but need order
⚠️  Kafka as primary database
🔥 Monitor lag max + growth rate
```

---

## Chapter 13 — Interviews

```
🎯 Draw: producer → leader → ISR → consumer group
🎯 Debug lag: process vs broker vs rebalance
🎯 Spark link: checkpoint + idempotent sink
```

---

## Spark Cross-Track (30 seconds)

```
🧠 Spark Structured Streaming + Kafka = checkpointed offsets
🧠 Spark shuffle ≠ Kafka partition — both parallelism lenses
🧠 Idempotent MERGE in lake = EOS partner pattern
```

See [../spark/Quick_Revision/Daily_Recall_Spark.md](../spark/Quick_Revision/Daily_Recall_Spark.md).

---

## One-Page Boxes — Ultra Recall

```
┌─────────────────────────────────────────────────────────────┐
│ ORDERING     │ Single partition only │ key = route           │
├─────────────────────────────────────────────────────────────┤
│ DURABILITY   │ acks=all + min.insync + RF≥3                  │
├─────────────────────────────────────────────────────────────┤
│ SCALE OUT    │ partitions ≈ max group parallelism            │
├─────────────────────────────────────────────────────────────┤
│ HEALTH       │ consumer lag, URP, ISR, GC                    │
├─────────────────────────────────────────────────────────────┤
│ EOS          │ idempotent + txn + read_committed + sink      │
└─────────────────────────────────────────────────────────────┘
```
