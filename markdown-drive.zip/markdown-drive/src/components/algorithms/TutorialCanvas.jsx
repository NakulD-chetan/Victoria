import { useEffect, useRef, useCallback, useState, memo } from 'react';
import { DPR } from '../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9', dotGrid: '#e7e5e4', stroke: '#1c1917',
    barDefault: '#a5d8ff', barCompare: '#ffd43b', barSwap: '#ff6b6b',
    barSorted: '#b2f2bb', barPivot: '#d0bfff', barActive: '#74c0fc',
    barMerge: '#ffa94d', textPrimary: '#1c1917', textSecondary: '#78716c',
    nodeDefault: '#a5d8ff', nodeVisited: '#b2f2bb', nodeCurrent: '#ffd43b',
    nodeSource: '#d0bfff', edgeDefault: '#78716c', edgeHighlight: '#6366f1',
    cellDefault: '#e7e5e4', cellMatch: '#b2f2bb', cellMismatch: '#fecdd3',
    cellCurrent: '#ffd43b', cellFound: '#d0bfff', cellEliminated: '#fecdd3',
    cellFilling: '#ffd43b', cellFilled: '#a5d8ff', cellOptimal: '#b2f2bb',
  },
  dark: {
    bg: 'transparent', dotGrid: 'rgba(255,255,255,0.04)', stroke: 'rgba(255,255,255,0.6)',
    barDefault: '#1c4a6e', barCompare: '#805b10', barSwap: '#7c1d1d',
    barSorted: '#1e5631', barPivot: '#3b2e6e', barActive: '#1864ab',
    barMerge: '#7c4a0e', textPrimary: '#e7e5e4', textSecondary: '#a8a29e',
    nodeDefault: '#1c4a6e', nodeVisited: '#1e5631', nodeCurrent: '#805b10',
    nodeSource: '#3b2e6e', edgeDefault: '#a8a29e', edgeHighlight: '#818cf8',
    cellDefault: 'rgba(255,255,255,0.06)', cellMatch: '#1e5631', cellMismatch: '#4c1d1d',
    cellCurrent: '#805b10', cellFound: '#3b2e6e', cellEliminated: '#4c1d1d',
    cellFilling: '#805b10', cellFilled: '#1c4a6e', cellOptimal: '#1e5631',
  },
};

let _cachedPalette = null;
let _paletteTheme = null;
function getPalette() {
  const theme = document.documentElement.getAttribute('data-theme');
  if (theme !== _paletteTheme) {
    _paletteTheme = theme;
    _cachedPalette = theme === 'light' ? PALETTE.light : PALETTE.dark;
  }
  return _cachedPalette;
}

function easeOut(t) { return 1 - (1 - t) * (1 - t) * (1 - t); }

function colorFor(p, prefix, colorName) {
  if (!colorName || colorName === 'default') return p[prefix + 'Default'];
  return p[prefix + colorName.charAt(0).toUpperCase() + colorName.slice(1)] || p[prefix + 'Default'];
}

const TutorialCanvas = memo(function TutorialCanvas({ animConfig, visible }) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const visibleRef = useRef(visible);
  const stepRef = useRef(-1);
  const playingRef = useRef(false);
  const lastStepTimeRef = useRef(0);
  const dotGridCacheRef = useRef(null);
  const stateRef = useRef({ array: [], colors: {}, pointers: {}, annotation: '' });
  const animsRef = useRef([]);
  const mountedRef = useRef(true);
  const sizeRef = useRef({ W: 0, H: 0 });
  const initDoneRef = useRef(false);

  const [uiStep, setUiStep] = useState(-1);
  const [uiPlaying, setUiPlaying] = useState(false);

  const steps = animConfig?.steps || [];
  const type = animConfig?.type || 'bars';
  const speed = animConfig?.speed || 600;

  visibleRef.current = visible;

  const applyStep = useCallback((idx) => {
    if (idx < 0 || idx >= steps.length) return;
    const step = steps[idx];
    const prev = stateRef.current;
    stateRef.current = {
      array: step.array || prev.array,
      colors: step.colors || {},
      pointers: step.pointers || {},
      annotation: step.annotation || '',
      nodes: step.nodes || prev.nodes,
      edges: step.edges || prev.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      table: step.table || prev.table,
      cellColors: step.cellColors || {},
      text: step.text || prev.text,
      pattern: step.pattern || prev.pattern,
      textColors: step.textColors || {},
      patternColors: step.patternColors || {},
      offset: step.offset ?? prev.offset ?? 0,
    };
    if (step.anim) {
      animsRef.current.push({ ...step.anim, t0: performance.now() });
    }
    stepRef.current = idx;
  }, [steps]);

  const doStep = useCallback(() => {
    const next = stepRef.current + 1;
    if (next < steps.length) {
      applyStep(next);
      setUiStep(next);
    } else {
      playingRef.current = false;
      setUiPlaying(false);
    }
  }, [steps, applyStep]);

  const handleRestart = useCallback(() => {
    playingRef.current = false;
    setUiPlaying(false);
    stepRef.current = -1;
    setUiStep(-1);
    lastStepTimeRef.current = 0;
    animsRef.current = [];
    if (animConfig?.init) {
      stateRef.current = { ...stateRef.current, ...animConfig.init };
    }
  }, [animConfig]);

  const togglePlay = useCallback(() => {
    const next = !playingRef.current;
    playingRef.current = next;
    setUiPlaying(next);
    if (next) lastStepTimeRef.current = performance.now();
  }, []);

  // Auto-play when scrolled into view
  useEffect(() => {
    if (visible && !initDoneRef.current && steps.length > 0) {
      initDoneRef.current = true;
      handleRestart();
      const id = setTimeout(() => {
        playingRef.current = true;
        setUiPlaying(true);
        lastStepTimeRef.current = performance.now();
      }, 300);
      return () => clearTimeout(id);
    }
  }, [visible, steps.length, handleRestart]);

  // Init state from config
  useEffect(() => {
    if (animConfig?.init) {
      stateRef.current = { ...stateRef.current, ...animConfig.init };
    }
  }, [animConfig]);

  // Main canvas render loop - only runs when visible
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    mountedRef.current = true;

    const container = canvas.parentElement;
    const W = container.clientWidth || 320;
    const H = animConfig?.height || 200;
    sizeRef.current = { W, H };
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = W + 'px';
    canvas.style.height = H + 'px';
    const ctx = canvas.getContext('2d', { alpha: true });
    ctx.scale(DPR, DPR);

    // Pre-render dot grid to offscreen canvas
    const dotCanvas = document.createElement('canvas');
    dotCanvas.width = W * DPR;
    dotCanvas.height = H * DPR;
    const dotCtx = dotCanvas.getContext('2d');
    dotCtx.scale(DPR, DPR);
    dotGridCacheRef.current = { canvas: dotCanvas, theme: null };

    function buildDotGrid() {
      const theme = document.documentElement.getAttribute('data-theme');
      const cache = dotGridCacheRef.current;
      if (cache.theme === theme) return;
      cache.theme = theme;
      const p = getPalette();
      dotCtx.clearRect(0, 0, W, H);
      dotCtx.fillStyle = p.dotGrid;
      for (let gx = 12; gx < W; gx += 16)
        for (let gy = 12; gy < H; gy += 16)
          dotCtx.fillRect(gx, gy, 1, 1);
    }

    let lastFrameTime = 0;
    const TARGET_INTERVAL = 1000 / 30; // Cap at 30fps for tutorial mini canvases

    function render(timestamp) {
      if (!mountedRef.current) return;

      // Only render when visible
      if (!visibleRef.current) {
        rafRef.current = requestAnimationFrame(render);
        return;
      }

      // Throttle to 30fps
      if (timestamp - lastFrameTime < TARGET_INTERVAL) {
        rafRef.current = requestAnimationFrame(render);
        return;
      }
      lastFrameTime = timestamp;

      const now = performance.now();

      // Step progression via RAF timing (no setInterval)
      if (playingRef.current && stepRef.current < steps.length - 1) {
        if (now - lastStepTimeRef.current >= speed) {
          lastStepTimeRef.current = now;
          const next = stepRef.current + 1;
          applyStep(next);
          setUiStep(next);
          if (next >= steps.length - 1) {
            playingRef.current = false;
            setUiPlaying(false);
          }
        }
      }

      const p = getPalette();
      ctx.clearRect(0, 0, W, H);

      // Blit cached dot grid
      buildDotGrid();
      ctx.drawImage(dotGridCacheRef.current.canvas, 0, 0, W, H);

      const s = stateRef.current;

      if (type === 'bars' && s.array?.length) drawBars(ctx, W, H, p, s, animsRef.current, now);
      else if (type === 'graph' && s.nodes?.length) drawGraph(ctx, W, H, p, s);
      else if (type === 'table' && s.table) drawTable(ctx, W, H, p, s);
      else if (type === 'string' && s.text?.length) drawString(ctx, W, H, p, s);
      else if (type === 'cells' && s.array?.length) drawCells(ctx, W, H, p, s);

      if (s.annotation) {
        ctx.fillStyle = p.textPrimary;
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(s.annotation, W / 2, H - 8);
      }

      // Clean expired animations
      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        if (now - anims[i].t0 >= (anims[i].dur || 400)) anims.splice(i, 1);
      }

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);

    return () => {
      mountedRef.current = false;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [type, animConfig, speed, steps, applyStep]);

  const progress = steps.length > 0 ? (uiStep + 1) / steps.length : 0;

  return (
    <div className="dc-tutorial__anim">
      <canvas ref={canvasRef} className="dc-tutorial__anim-canvas" />
      <div className="dc-tutorial__anim-controls">
        <button className="dc-tutorial__anim-btn" onClick={handleRestart} title="Restart">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="1 4 1 10 7 10" /><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
          </svg>
        </button>
        <button className="dc-tutorial__anim-btn dc-tutorial__anim-btn--play" onClick={togglePlay} title={uiPlaying ? 'Pause' : 'Play'}>
          {uiPlaying ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1" /><rect x="14" y="4" width="4" height="16" rx="1" /></svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3" /></svg>
          )}
        </button>
        <button className="dc-tutorial__anim-btn" onClick={doStep} title="Step" disabled={uiStep >= steps.length - 1}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <polyline points="9 18 15 12 9 6" />
          </svg>
        </button>
        <div className="dc-tutorial__progress-bar">
          <div className="dc-tutorial__progress-fill" style={{ width: `${progress * 100}%` }} />
        </div>
        <span className="dc-tutorial__step-label">{uiStep + 1}/{steps.length}</span>
      </div>
    </div>
  );
});

export default TutorialCanvas;

function drawBars(ctx, W, H, p, s, anims, now) {
  const { array, colors, pointers } = s;
  const n = array.length;
  if (!n) return;
  const maxVal = Math.max(...array, 1);
  const pad = 20;
  const gap = Math.max(1, Math.min(4, (W - pad * 2) / n * 0.1));
  const barW = Math.max(3, ((W - pad * 2) - gap * (n - 1)) / n);
  const barAreaH = H - 50;

  const animOffsets = {};
  for (let a = 0; a < anims.length; a++) {
    const an = anims[a];
    const t = Math.min((now - an.t0) / (an.dur || 400), 1);
    const e = easeOut(t);
    if (an.type === 'swap') {
      const dist = (an.j - an.i) * (barW + gap);
      animOffsets[an.i] = (animOffsets[an.i] || 0) + dist * e;
      animOffsets[an.j] = (animOffsets[an.j] || 0) - dist * e;
    }
  }

  for (let i = 0; i < n; i++) {
    const val = array[i];
    const barH = (val / maxVal) * barAreaH;
    const x = pad + i * (barW + gap) + (animOffsets[i] || 0);
    const y = H - 26 - barH;
    ctx.fillStyle = colorFor(p, 'bar', colors[i]);
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.roundRect(x, y, barW, barH, [2, 2, 0, 0]);
    ctx.fill();
    ctx.stroke();
    if (barW > 10) {
      ctx.fillStyle = p.textPrimary;
      ctx.font = `600 ${Math.min(9, barW * 0.5)}px sans-serif`;
      ctx.textAlign = 'center';
      ctx.fillText(val, x + barW / 2, y - 3);
    }
  }

  if (pointers) {
    const pColors = { lo: '#2f9e44', hi: '#e03131', mid: '#1971c2', pivot: '#7c3aed', i: '#f08c00', j: '#1098ad', min: '#c2255c' };
    const entries = Object.entries(pointers);
    for (let e = 0; e < entries.length; e++) {
      const [name, idx] = entries[e];
      if (idx < 0 || idx >= n) continue;
      const x = pad + idx * (barW + gap) + barW / 2;
      ctx.fillStyle = pColors[name] || '#6366f1';
      ctx.beginPath();
      ctx.moveTo(x, H - 12);
      ctx.lineTo(x - 4, H - 6);
      ctx.lineTo(x + 4, H - 6);
      ctx.fill();
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(name, x, H - 2);
    }
  }
}

function drawCells(ctx, W, H, p, s) {
  const { array, colors, pointers } = s;
  const n = array.length;
  if (!n) return;
  const cellW = Math.min(36, (W - 30) / n);
  const startX = (W - n * cellW) / 2;
  const cy = H / 2 - 10;

  for (let i = 0; i < n; i++) {
    const x = startX + i * cellW;
    ctx.fillStyle = colorFor(p, 'cell', colors[i]);
    ctx.fillRect(x, cy, cellW - 1, 28);
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 0.8;
    ctx.strokeRect(x, cy, cellW - 1, 28);
    ctx.fillStyle = p.textPrimary;
    ctx.font = '600 10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(array[i], x + (cellW - 1) / 2, cy + 18);
    ctx.fillStyle = p.textSecondary;
    ctx.font = '500 7px sans-serif';
    ctx.fillText(i, x + (cellW - 1) / 2, cy - 3);
  }

  if (pointers) {
    const pColors = { lo: '#2f9e44', hi: '#e03131', mid: '#1971c2', probe: '#7c3aed', i: '#f08c00' };
    const entries = Object.entries(pointers);
    for (let e = 0; e < entries.length; e++) {
      const [name, idx] = entries[e];
      if (idx < 0 || idx >= n) continue;
      const x = startX + idx * cellW + (cellW - 1) / 2;
      ctx.fillStyle = pColors[name] || '#6366f1';
      ctx.beginPath();
      ctx.moveTo(x, cy + 34);
      ctx.lineTo(x - 4, cy + 40);
      ctx.lineTo(x + 4, cy + 40);
      ctx.fill();
      ctx.font = 'bold 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(name, x, cy + 50);
    }
  }
}

function drawGraph(ctx, W, H, p, s) {
  const { nodes, edges, nodeColors, edgeColors } = s;
  if (!nodes) return;
  const sc = Math.min(W, H) / 300;

  if (edges) {
    for (let i = 0; i < edges.length; i++) {
      const e = edges[i];
      const from = nodes.find(n => n.id === e.from);
      const to = nodes.find(n => n.id === e.to);
      if (!from || !to) continue;
      const eKey = `${e.from}-${e.to}`;
      const isHL = edgeColors?.[eKey] === 'highlight';
      ctx.beginPath();
      ctx.moveTo(from.x * sc + W * 0.1, from.y * sc + 20);
      ctx.lineTo(to.x * sc + W * 0.1, to.y * sc + 20);
      ctx.strokeStyle = isHL ? p.edgeHighlight : p.edgeDefault;
      ctx.lineWidth = isHL ? 2.5 : 1.2;
      ctx.stroke();
      if (e.weight != null) {
        const mx = (from.x + to.x) / 2 * sc + W * 0.1;
        const my = (from.y + to.y) / 2 * sc + 20;
        ctx.fillStyle = p.textSecondary;
        ctx.font = '500 8px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(e.weight, mx, my - 4);
      }
    }
  }

  for (let i = 0; i < nodes.length; i++) {
    const n = nodes[i];
    const x = n.x * sc + W * 0.1;
    const y = n.y * sc + 20;
    const r = 14 * sc;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = colorFor(p, 'node', nodeColors?.[n.id]);
    ctx.fill();
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 1.2;
    ctx.stroke();
    ctx.fillStyle = p.textPrimary;
    ctx.font = `bold ${10 * sc}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(n.label || n.id, x, y);
  }
  ctx.textBaseline = 'alphabetic';
}

function drawTable(ctx, W, H, p, s) {
  const { table, cellColors } = s;
  if (!table || !table.length) return;
  const rows = table.length;
  const cols = table[0].length;
  const cellW = Math.min(36, (W - 40) / cols);
  const cellH = Math.min(24, (H - 40) / rows);
  const startX = (W - cols * cellW) / 2;
  const startY = (H - rows * cellH) / 2;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = startX + c * cellW;
      const y = startY + r * cellH;
      const key = `${r}-${c}`;
      ctx.fillStyle = colorFor(p, 'cell', cellColors?.[key]);
      ctx.fillRect(x, y, cellW - 1, cellH - 1);
      ctx.strokeStyle = p.stroke;
      ctx.lineWidth = 0.5;
      ctx.strokeRect(x, y, cellW - 1, cellH - 1);
      if (table[r][c] != null) {
        ctx.fillStyle = p.textPrimary;
        ctx.font = '500 9px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(table[r][c], x + (cellW - 1) / 2, y + (cellH - 1) / 2 + 3);
      }
    }
  }
}

function drawString(ctx, W, H, p, s) {
  const { text, pattern, textColors, patternColors, offset } = s;
  if (!text) return;
  const cellW = Math.min(28, (W - 30) / Math.max(text.length, 1));
  const startX = (W - text.length * cellW) / 2;
  const textY = H / 2 - 24;
  const patY = H / 2 + 8;

  ctx.fillStyle = p.textSecondary;
  ctx.font = '600 9px sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText('Text:', 4, textY + 14);
  if (pattern) ctx.fillText('Pattern:', 4, patY + 14);

  for (let i = 0; i < text.length; i++) {
    const x = startX + i * cellW;
    ctx.fillStyle = colorFor(p, 'cell', textColors?.[i]);
    ctx.fillRect(x, textY, cellW - 1, 22);
    ctx.strokeStyle = p.stroke;
    ctx.lineWidth = 0.5;
    ctx.strokeRect(x, textY, cellW - 1, 22);
    ctx.fillStyle = p.textPrimary;
    ctx.font = '600 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(text[i], x + (cellW - 1) / 2, textY + 15);
  }

  if (pattern) {
    const off = offset || 0;
    for (let i = 0; i < pattern.length; i++) {
      const x = startX + (i + off) * cellW;
      ctx.fillStyle = colorFor(p, 'cell', patternColors?.[i]);
      ctx.fillRect(x, patY, cellW - 1, 22);
      ctx.strokeStyle = p.stroke;
      ctx.lineWidth = 0.5;
      ctx.strokeRect(x, patY, cellW - 1, 22);
      ctx.fillStyle = p.textPrimary;
      ctx.font = '600 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(pattern[i], x + (cellW - 1) / 2, patY + 15);
    }
  }
}
