import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr, k) {
  const a = [...arr];
  const steps = [];
  function partition(lo, hi) {
    const pivotVal = a[hi];
    steps.push({ type: 'pivot', lo, hi, pivot: hi, k, array: [...a] });
    let i = lo;
    for (let j = lo; j < hi; j++) {
      steps.push({ type: 'compare', lo, hi, i, j, pivot: hi, k, array: [...a] });
      if (a[j] < pivotVal) {
        [a[i], a[j]] = [a[j], a[i]];
        steps.push({ type: 'swap', i, j, lo, hi, k, array: [...a] });
        i++;
      }
    }
    [a[i], a[hi]] = [a[hi], a[i]];
    steps.push({ type: 'pivot-placed', p: i, lo, hi, k, array: [...a] });
    return i;
  }
  function go(lo, hi) {
    if (lo > hi) return;
    steps.push({ type: 'range', lo, hi, k, array: [...a] });
    const p = partition(lo, hi);
    if (p === k) {
      steps.push({ type: 'found', p, k, array: [...a] });
      return;
    }
    if (k < p) {
      steps.push({ type: 'recurse', side: 'left', p, k, lo, hi, array: [...a] });
      go(lo, p - 1);
    } else {
      steps.push({ type: 'recurse', side: 'right', p, k, lo, hi, array: [...a] });
      go(p + 1, hi);
    }
  }
  go(0, a.length - 1);
  steps.push({ type: 'done', k, array: [...a] });
  return steps;
}

function randomArray(n = 14) {
  return Array.from({ length: n }, () => Math.floor(Math.random() * 85) + 5);
}

export default function QuickSelectVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    const k = Math.floor(Math.random() * arr.length);
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr, k));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `k = ${k} (0-based order statistic)` });
    canvasRef.current?.setState({
      array: arr,
      colors: {},
      pointers: { k },
      labels: Object.fromEntries(arr.map((_, i) => [i, i === k ? 'k' : ''])),
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    const labels = {};
    const k = step.k;
    if (k != null) labels[k] = 'k';

    if (step.type === 'range') {
      for (let i = 0; i < step.array.length; i++) {
        if (i < step.lo || i > step.hi) colors[i] = 'sorted';
        else colors[i] = 'default';
      }
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Search in [${step.lo}..${step.hi}] for rank ${step.k}` });
    } else if (step.type === 'pivot') {
      for (let i = step.lo; i <= step.hi; i++) colors[i] = 'active';
      colors[step.pivot] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Partition with pivot index ${step.pivot}` });
    } else if (step.type === 'compare') {
      colors[step.pivot] = 'pivot';
      colors[step.j] = 'compare';
      store.incComparisons();
    } else if (step.type === 'swap') {
      colors[step.i] = 'swap';
      colors[step.j] = 'swap';
      store.incSwaps();
      canvasRef.current?.addAnim('swap', { i: step.i, j: step.j }, 280);
    } else if (step.type === 'pivot-placed') {
      colors[step.p] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Pivot placed at ${step.p}` });
    } else if (step.type === 'recurse') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `${step.k} ${step.k < step.p ? '<' : '>'} ${step.p} → recurse ${step.side}` });
      for (let i = 0; i < step.array.length; i++) {
        if (step.side === 'left' && i > step.p) colors[i] = 'sorted';
        if (step.side === 'right' && i < step.p) colors[i] = 'sorted';
      }
    } else if (step.type === 'found') {
      colors[step.p] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `k-th smallest at index ${step.p} → value ${step.array[step.p]}` });
    } else if (step.type === 'done') {
      for (let i = 0; i < step.array.length; i++) colors[i] = i === step.k ? 'pivot' : 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Quickselect complete' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({
      array: step.array,
      colors,
      labels,
      pointers: { k: step.k },
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
