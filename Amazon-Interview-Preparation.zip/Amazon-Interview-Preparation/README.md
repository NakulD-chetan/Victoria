# Amazon Interview Preparation - Data Engineer 2

This folder is a beginner-friendly Amazon DE2 study set written in **interview speaking format**.

The goal is not only to understand the concepts, but to help you **explain them clearly in interviews**.

Most system design notes now follow the same answer flow:

1. Clarify requirements
2. Give the high-level design
3. Deep dive into 2-3 areas
4. Explain scaling
5. Close with trade-offs

---

## Study Order

1. `00-How-to-Prepare-for-Amazon-DE2.md`
2. `01-Design-Batch-ETL-Pipeline.md`
3. `02-Design-Real-Time-Streaming-Pipeline.md`
4. `03-Design-CDC-Pipeline.md`
5. `04-Design-Data-Lake-on-S3-and-Iceberg.md`
6. `05-Design-Redshift-Data-Warehouse.md`
7. `06-Design-Orchestration-Data-Quality-and-Backfills.md`
8. `07-Common-Amazon-DE2-System-Design-Questions.md`
9. `08-Top-SQL-Questions-for-Amazon-DE2.md`
10. `09-Top-Python-Questions-for-Amazon-DE2.md`
11. `10-Design-Clickstream-Analytics-Pipeline.md`

---

## What This Folder Helps You Practice

- structured system design speaking
- AWS data engineering fundamentals
- SQL problem-solving
- Python ETL-style coding
- trade-off thinking
- operational maturity

---

## What Amazon Usually Looks For

- strong data modeling basics
- clear understanding of batch vs streaming
- scalable ETL/ELT thinking
- AWS familiarity:
  - S3
  - Glue
  - EMR / Spark
  - Lambda
  - Kinesis / Kafka / MSK
  - Redshift
  - Step Functions / Airflow
  - IAM / encryption / monitoring
- trade-off thinking:
  - cost vs latency
  - correctness vs speed
  - simplicity vs flexibility
- operational thinking:
  - retries
  - idempotency
  - backfills
  - schema evolution
  - data quality
  - alerting

---

## Suggested 2-Week Plan

### Week 1

- Day 1: answer framework + Amazon interview style
- Day 2: batch ETL
- Day 3: streaming
- Day 4: CDC
- Day 5: data lake
- Day 6: Redshift warehouse
- Day 7: revise architectures from memory

### Week 2

- Day 8: orchestration, quality, and backfills
- Day 9: SQL practice
- Day 10: Python practice
- Day 11: batch mock interview
- Day 12: streaming mock interview
- Day 13: Leadership Principles + STAR stories
- Day 14: full mock interview with timer

---

## Important Reminder

Do not explain only the happy path.

In most DE2 answers, you should also mention:

- retries
- duplicates
- late-arriving data
- schema changes
- partitioning
- data quality checks
- observability
- cost control
- security

---

## Final Goal

By the end of this folder, you should be able to explain clearly:

- how to design a batch ETL pipeline
- how to design a real-time pipeline
- how CDC works
- how to design a lake on S3
- how to design a Redshift warehouse
- how to handle orchestration, validation, and backfills
- how to answer common SQL and Python interview questions
