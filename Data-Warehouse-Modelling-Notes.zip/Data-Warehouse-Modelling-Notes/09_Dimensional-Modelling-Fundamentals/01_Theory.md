# Dimensional Modelling Fundamentals

> "Grain is a promise. Break the promise and every dashboard becomes a rumor."

**Real-world analogy:** A grocer can track inventory by individual barcode scan, by case shipped to a store, or by weekly category totals. Finer tracking answers more questions but costs more shelf sensors and reconciliation work. Choosing grain is choosing which operational reality you can faithfully replay later.

---

## Core Idea (2 Lines)

Dimensional modelling organizes data around business processes so analysts can filter, group, and sum facts along intuitive hierarchies without repeating complex joins every time. The four-step method forces explicit agreement on grain before dimensions and facts are locked, which prevents silent metric drift.

---

## Kimball Four Steps (Retail Framed)

| Step | Question | Example |
|------|----------|---------|
| 1. Choose business process | What decision are we supporting? | Store-level replenishment from POS sell-through |
| 2. Declare grain | Exactly one row means what? | One POS sale line for one SKU on one receipt |
| 3. Choose dimensions | What context labels exist at that moment? | product, store, date, promotion, tender type |
| 4. Identify facts | What numbers can be summed at that grain? | `sale_amount`, `quantity`, `discount_amount` |

```
Step 1: business process "POS sales"
          |
          v
Step 2: grain "line-level"
          |
          v
Step 3: dimensions attach to each line
          |
          v
Step 4: numeric facts live on the line
```

**Interview Tip:** Recite the four steps in order; interviewers listen for whether grain is stated before naming dimensions.

**Watch Out!** Skipping grain produces "one row per day per store" tables that cannot answer basket composition questions later.

---

## Grain Deep Dive

Grain is the atomicity of a fact row: the smallest unit of measurement you preserve.

| Grain example | One row represents | Typical retail use |
|---------------|--------------------|--------------------|
| POS line | One SKU line on one receipt | Category mix, promotion lift |
| Basket | One receipt totals only | Fast CFO view, loses SKU detail |
| Daily store SKU | Aggregated sales for a day | Forecasting inputs |
| Hourly store department | Aggregated by hour | Labor scheduling |

### Atomic versus coarse

| Atomic grain | Coarse grain |
|--------------|--------------|
| Preserves maximum flexibility | Optimizes storage and scan speed |
| Supports detailed return analysis | Supports high-level KPIs only |
| Larger fact tables | Smaller tables, fewer joins in rollups |

**Watch Out!** "We can always roll up later" is true, but "we can drill down later" is false if grain was aggregated away at load time.

---

## Trade-Offs When Choosing Grain

| Driver | Pushes finer grain | Pushes coarser grain |
|--------|-------------------|----------------------|
| Analytical questions | Need SKU-level coupon attribution | Only need banner-level revenue |
| Cost | More rows, more storage | Fewer rows |
| Latency | More transformation work | Simpler nightly jobs |
| Privacy | Finer may expose individuals | Coarse can mask shoppers |

```sql
-- Atomic: one row per receipt line
SELECT transaction_id, line_no, sku, quantity, extended_amount
FROM retail_core.fact_pos_sale_line;

-- Coarse: one row per store per day (cannot recover line composition)
SELECT store_sk, date_sk, SUM(extended_amount) AS daily_sales
FROM retail_core.fact_pos_sale_line
GROUP BY 1, 2;
```

**Interview Tip:** When asked about grain, answer with a sentence, then give one business question that requires that grain and one that would be impossible if grain were coarser.

---

## Pitfalls Around Grain

| Pitfall | Symptom | Mitigation |
|---------|---------|------------|
| Mixed grains in one fact | Double counting when summing | Split into two fact tables at different grains |
| Snapshot facts pretending to be transactional | Averages look wrong | Separate periodic snapshot design |
| Drill-across without conformed dimensions | Inconsistent totals | Conform `dim_date`, `dim_product` across facts |

**Watch Out!** A single table with both line-level and receipt-level totals as columns invites analysts to sum incompatible fields.

---

## Finer versus Coarser Grain Comparison

| Evaluation | Finer (line-level) | Coarser (daily store totals) |
|------------|--------------------|------------------------------|
| Storage | Higher | Lower |
| Basket analysis | Possible | Impossible without another source |
| Return to simple KPI | Requires aggregation query | Native |
| Incremental complexity | Many small inserts | Fewer merges |
| Conformed dimensions | More powerful drill-across | Still needed, fewer keys per row |

---

## Derived Measures: Store versus Compute

| Approach | Example | When it fits retail |
|----------|---------|---------------------|
| Store derived | `gross_margin_amount` on fact | Stable definition, heavy reuse in finance |
| Compute in view | `sale_amount - cost_amount` | Definitions change often with policy |
| BI calculation | Margin percent in dashboard | Exploratory only, not governed |

```sql
-- Stored derived column during transform
SELECT
  sale_amount,
  cost_amount,
  sale_amount - cost_amount AS gross_margin_amount
FROM retail_staging.pos_line_enriched;
```

**Interview Tip:** Mention governance: stored facts should have documented definitions and tests; ad hoc BI calcs should not feed regulatory reporting.

**Watch Out!** Storing margin percent at line level can be non-additive; storing numerator and denominator facts is safer for rollups.

---

## Missing Unit Count Pitfall

Analysts sum `sale_amount` and assume they can average price as `SUM(amount)/SUM(qty)`. If some rows have zero quantity (fees, deposits) or null handling differs, averages drift.

| Scenario | Risk | Fix |
|----------|------|-----|
| Service fees with `quantity = 0` | Distorted average unit price | Separate non-unit facts or flags |
| Returns as negative lines | Correct totals, odd averages | Document sign conventions |
| Mixing weight-based and each-based SKUs | Meaningless unit sums | Use separate measures or UOM dimension |

```sql
-- Safer pattern: explicit unit price only for rows with quantity > 0
SELECT
  SUM(sale_amount) AS total_sales,
  SAFE_DIVIDE(SUM(sale_amount), NULLIF(SUM(quantity), 0)) AS avg_implied_unit_price
FROM retail_core.fact_pos_sale_line
WHERE quantity > 0;
```

---

## Multiple Fact Tables at Different Grains

```
+------------------------+       +------------------------+
| fact_pos_sale_line     |       | fact_store_inventory   |
| grain: line per receipt|       | grain: daily per SKU   |
+-----------+------------+       +-----------+------------+
            \                               /
             \                             /
              v                           v
           +--------------------------------+
           | conformed dim_product, dim_store|
           +--------------------------------+
```

Retail commonly needs:

| Fact | Grain | Why separate |
|------|-------|--------------|
| POS sales | Line | Promotion effectiveness |
| Inventory snapshot | Daily SKU location | On-hand and shrink |
| Shipments | ASN line | Supply chain fill rate |

**Watch Out!** Joining facts of different grains without aggregation produces a Cartesian explosion.

---

## Interview Questions Around Grain

| Question | Strong answer skeleton |
|----------|------------------------|
| Define grain | "One row equals ..." |
| Why not aggregate early | "We would lose ability to answer ..." |
| How to document | Model YAML, dbt docs, data catalog fields |
| How to test | Unique keys on natural grain, reconciliation to control totals |

**Interview Tip:** Offer a concrete retail scenario, such as separating e-commerce shipment facts from store pickup facts because event times and fees differ.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Declaring grain only in a slide deck | Engineers implement a different grain | Enforce uniqueness tests on natural keys |
| Mixing returns and sales without sign rules | Revenue spikes or dips | Standardize transaction type dimension |
| Storing percentages as additive facts | Summing produces nonsense | Store components or mark non-additive |
| One catch-all fact table for every process | Unrelated nulls and wide sparse rows | Split by business process |
| Ignoring role-playing dates | Same `date_sk` used for order and ship | Role-play with views or aliases |

---

## Key Takeaway

> Dimensional modelling succeeds when the warehouse team agrees on grain first, then builds conformed dimensions and honest facts that make every total explainable as a sum of the same kind of row.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Four steps: process, grain, dimensions, facts—in that order.     |
| Grain is atomicity; coarser saves space but loses questions.     |
| Mixed grains in one table cause double-count traps.              |
| Derived measures: store when stable; compute when volatile.        |
| Multiple facts share conformed dimensions for drill-across.      |
+------------------------------------------------------------------+
```
