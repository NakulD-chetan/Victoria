import { useEffect, useRef, useCallback, useState } from 'react';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import CodePanel from './CodePanel';
import EventLog from './EventLog';

function AlgoStatsBar({ stats }) {
  return (
    <div className="dc-stats-inline">
      {stats.map((s, i) => (
        <div key={i} className="dc-stat-chip">
          <span className="dc-stat-chip__value" style={{ color: s.color || 'var(--accent-secondary)' }}>{s.value}</span>
          <span className="dc-stat-chip__label">{s.label}</span>
        </div>
      ))}
    </div>
  );
}

export default function AlgoVisualizer({ config, canvas: CanvasComponent, onInit, onStep, onReset, statsBuilder, controls: CustomControls }) {
  const canvasRef = useRef(null);
  const playRef = useRef(null);
  const {
    array, stepIndex, steps, playing, speed,
    comparisons, swaps, setSpeed, setPlaying, reset, nextStep,
  } = useVisualizerStore();

  const [codeOpen, setCodeOpen] = useState(false);

  useEffect(() => {
    reset();
    if (onInit) onInit(canvasRef);
    return () => { if (playRef.current) clearInterval(playRef.current); };
  }, []);

  const doStep = useCallback(() => {
    const step = nextStep();
    if (step && onStep) onStep(step, canvasRef);
  }, [nextStep, onStep]);

  const handlePlay = useCallback(() => {
    if (playing) {
      setPlaying(false);
      if (playRef.current) clearInterval(playRef.current);
      playRef.current = null;
    } else {
      setPlaying(true);
    }
  }, [playing, setPlaying]);

  useEffect(() => {
    if (playing) {
      playRef.current = setInterval(() => {
        const step = useVisualizerStore.getState().nextStep();
        if (step && onStep) onStep(step, canvasRef);
        else {
          clearInterval(playRef.current);
          playRef.current = null;
          useVisualizerStore.getState().setPlaying(false);
        }
      }, speed);
    } else {
      if (playRef.current) { clearInterval(playRef.current); playRef.current = null; }
    }
    return () => { if (playRef.current) clearInterval(playRef.current); };
  }, [playing, speed, onStep]);

  const handleReset = useCallback(() => {
    if (playRef.current) clearInterval(playRef.current);
    playRef.current = null;
    reset();
    if (onReset) onReset(canvasRef);
    else if (onInit) onInit(canvasRef);
  }, [reset, onReset, onInit]);

  useEffect(() => {
    function handleKey(e) {
      if (e.target.tagName === 'INPUT') return;
      if (e.code === 'ArrowRight') { e.preventDefault(); doStep(); }
      if (e.code === 'Space') { e.preventDefault(); handlePlay(); }
      if (e.key === 'r' || e.key === 'R') handleReset();
    }
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [doStep, handlePlay, handleReset]);

  const stats = statsBuilder
    ? statsBuilder({ comparisons, swaps, stepIndex, steps, array })
    : [
        { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
        { label: 'Comparisons', value: comparisons, color: 'var(--accent)' },
        { label: 'Swaps', value: swaps, color: 'var(--accent-warm)' },
      ];

  return (
    <div className="dc-visualizer">
      <div className="dc-visualizer__stats-bar">
        <AlgoStatsBar stats={stats} />
      </div>

      <CanvasComponent ref={canvasRef} />

      <div className="dc-control-bar">
        <button className="dc-btn dc-btn--primary" onClick={doStep} disabled={stepIndex >= steps.length - 1}>
          Step &rarr;
        </button>
        <button className={`dc-btn ${playing ? 'dc-btn--success' : 'dc-btn--secondary'}`} onClick={handlePlay}>
          {playing ? 'Pause' : 'Play'}
        </button>
        <div className="dc-control-bar__sep" />
        <div className="dc-slider-group">
          <label>Speed</label>
          <input type="range" min={50} max={1000} step={50} value={1050 - speed} onChange={(e) => setSpeed(1050 - +e.target.value)} />
          <span className="dc-slider-val">{speed}ms</span>
        </div>
        {CustomControls && <CustomControls canvasRef={canvasRef} />}
        <div className="dc-control-bar__sep" />
        <button className="dc-btn dc-btn--danger" onClick={handleReset}>Reset</button>
      </div>

      <div className="dc-visualizer__bottom">
        <div className="dc-visualizer__explain-col">
          <button className="dc-code-toggle" onClick={() => setCodeOpen(!codeOpen)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="16 18 22 12 16 6" /><polyline points="8 6 2 12 8 18" />
            </svg>
            {codeOpen ? 'Hide Code' : 'Show Code'}
          </button>
          {codeOpen && config.code && (
            <div className="dc-visualizer__code-wrap">
              <CodePanel code={config.code} activeStep={useVisualizerStore.getState().currentStep} languages={config.meta.languages} storeFn={useVisualizerStore} />
            </div>
          )}
        </div>
        <div className="dc-visualizer__log-col">
          <EventLog storeFn={useVisualizerStore} />
        </div>
      </div>

      <div className="dc-visualizer__shortcuts">
        <kbd>&rarr;</kbd> Step <kbd>Space</kbd> Play/Pause <kbd>R</kbd> Reset
      </div>
    </div>
  );
}
