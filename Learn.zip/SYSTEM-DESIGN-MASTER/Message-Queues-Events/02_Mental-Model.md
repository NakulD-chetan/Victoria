# Message Queues and Events — Mental Model

> **Permanent Recall:** Queue = **post office**. Pub/sub = **newspaper**. Kafka = **ledger**. Event sourcing = **bank statement**. CQRS = **one write model, one read model**. The core interview question is always: **Do I need sync, or is eventual consistency acceptable?**

---

## The 5 Mental Models That Matter

If you remember only 5 images, remember these:

1. Queue = post office
2. Pub/sub = newspaper subscription
3. Kafka = append-only ledger
4. Event sourcing = bank statement
5. CQRS = separate write desk and read desk

---

## Queue = Post Office

```text
Producer -> post office -> recipient

You drop the letter.
The post office stores it.
One recipient eventually handles it.
```

Why this analogy works:

- producer and consumer do not need to be online together
- work can wait in the broker
- one message is handled by one worker

Think queue when the question sounds like:

- "process this later"
- "run this background job"
- "multiple workers can share the workload"

---

## Pub/Sub = Newspaper

```text
Publisher -> newspaper -> many subscribers

Same edition goes to many readers.
```

Why this analogy works:

- one event can trigger many downstream actions
- the publisher does not know all subscribers
- adding a new consumer does not require changing the producer

Think pub/sub when the question sounds like:

- "many services react to one event"
- "broadcast"
- "fan-out"

---

## Sync = Phone Call, Async = Voicemail

```text
SYNC:
You call and wait.

ASYNC:
You leave a message and move on.
```

| If You Need | Better Model |
|---|---|
| Immediate answer | Sync |
| Background processing | Async |
| Low coupling | Async |
| Strong immediate consistency | Sync |

**Interview shortcut:**  
If the user does not need the final work result immediately, async is usually a strong option.

---

## Kafka = Ledger

Kafka is not best understood as a normal queue.  
It is better understood as a **distributed append-only log**.

```text
Partition:
[offset0][offset1][offset2][offset3]...

Consumer remembers:
"I have read until offset 2"
```

Why the ledger analogy matters:

- records are appended in order
- consumers track position using offsets
- old data can be replayed
- many consumers can read the same history independently

This is why Kafka is strong for:

- event streaming
- analytics
- event sourcing
- audit trails
- replay

---

## RabbitMQ = Smart Mailroom

RabbitMQ is a better fit when you want a broker that actively routes messages.

```text
Producer -> Exchange -> Queue A
                     -> Queue B
                     -> Queue C
```

Mental model:

- Kafka is a log you read from
- RabbitMQ is a router that decides where messages go

Use this mental split:

- Kafka = storage + replay + throughput
- RabbitMQ = routing + work queue + broker-style delivery

---

## Event Sourcing = Bank Statement

```text
Do not store only:
balance = 100

Store:
Deposit +50
Withdraw -20
Deposit +70
```

Meaning:

- state is derived from the event history
- you can rebuild the state
- you can audit what happened
- you can create new read models later by replaying events

Use event sourcing when history itself matters.

---

## CQRS = Separate Write Desk and Read Desk

```text
Commands -> write model -> events -> read projections
Queries  -> read model
```

Mental model:

- writes optimize for correctness
- reads optimize for speed and query shape
- the two models do not need the same schema

Use CQRS when:

- reads are heavy
- queries are complex
- write and read scaling are very different

---

## Saga = Business Workflow Without Global Transaction

When many services must coordinate, do not assume one ACID transaction across them.

```text
Order -> Payment -> Inventory -> Shipping

If one step fails, run compensating action.
```

Two ways to think about Saga:

- **Choreography**: each service reacts to events
- **Orchestration**: one coordinator drives the steps

Mental shortcut:

- simple flow -> choreography can work
- complex flow -> orchestration is easier to reason about

---

## The Decision Tree

```mermaid
flowchart TD
    needAsync[Need async or decoupling?] -->|No| useSync[Use sync RPC]
    needAsync -->|Yes| fanout{One consumer or many?}
    fanout -->|One| useQueue[Use queue model]
    fanout -->|Many| usePubSub[Use pub/sub model]
    useQueue --> replay{Need replay?}
    usePubSub --> streamNeed{Need high throughput or replay?}
    replay -->|Yes| kafkaQueue[Kafka]
    replay -->|No| routeNeed{Need flexible routing?}
    routeNeed -->|Yes| rabbitQueue[RabbitMQ]
    routeNeed -->|No| sqsQueue[SQS]
    streamNeed -->|Yes| kafkaPubSub[Kafka]
    streamNeed -->|No| snsFanout[SNS plus SQS]
```

---

## Fast Decision Rules

| Situation | Default Thought |
|---|---|
| One worker should process the task | Queue |
| Many services should react | Pub/Sub |
| Need replay or event history | Kafka |
| Need routing flexibility | RabbitMQ |
| Need simple managed AWS messaging | SQS/SNS |
| Need immediate result | Sync |
| Eventual consistency is acceptable | Async |

---

## Common Confusions To Fix Early

| Confusion | Correct View |
|---|---|
| Queue and topic are the same | No, one is one-consumer work, the other is fan-out |
| Kafka is just a queue | No, Kafka is primarily a distributed log |
| Exactly-once is default | No, at-least-once + idempotency is more common |
| Ordering is global by default | No, ordering is usually only per partition or per key |

---

## 30-SECOND REVISION BOX

```text
QUEUE = post office
PUB/SUB = newspaper
SYNC = phone call
ASYNC = voicemail
KAFKA = ledger / append-only log / replay
RABBITMQ = smart broker / routing mailroom
EVENT SOURCING = bank statement
CQRS = separate write and read paths
SAGA = multi-service workflow with compensation
DECISION: one consumer -> queue, many -> pub/sub, replay -> Kafka
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
