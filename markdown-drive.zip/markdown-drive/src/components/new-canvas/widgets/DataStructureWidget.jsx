import { memo, useCallback } from 'react';
import { useNewCanvasStore } from '../state/store';

const CONFIG = {
  'linked-list': { label: 'Linked List', max: 15, nextValue: (length) => (length + 1) * 10 },
  stack: { label: 'Stack', max: 12, nextValue: (length) => `item ${length + 1}` },
  queue: { label: 'Queue', max: 12, nextValue: (length) => `item ${length + 1}` },
  tree: { label: 'Binary Tree', max: 31, nextValue: (length) => length + 1 },
  'hash-map': { label: 'Hash Map', max: 12 },
};

function coerceValue(value) {
  const trimmed = String(value).trim();
  return /^-?\d+(?:\.\d+)?$/.test(trimmed) ? Number(trimmed) : value;
}

function LinearNodes({ type, values, onChange }) {
  if (type === 'stack') {
    return (
      <div className="nc-ds__stack">
        <span className="nc-ds__marker">TOP</span>
        {values.slice().reverse().map((value, reverseIndex) => {
          const index = values.length - reverseIndex - 1;
          return (
            <input
              key={`stack-${index}`}
              value={value}
              onChange={(event) => onChange(index, event.target.value)}
              aria-label={`Stack value ${index + 1}`}
            />
          );
        })}
        {!values.length ? <span className="nc-ds__empty-copy">Empty stack</span> : null}
      </div>
    );
  }

  return (
    <div className={`nc-ds__linear nc-ds__linear--${type}`}>
      {type === 'queue' ? <span className="nc-ds__marker">FRONT</span> : null}
      {values.map((value, index) => (
        <div className="nc-ds__linear-item" key={`${type}-${index}`}>
          <input
            value={value}
            onChange={(event) => onChange(index, event.target.value)}
            aria-label={`${type} value ${index + 1}`}
          />
          {type === 'linked-list' && index < values.length - 1 ? <span className="nc-ds__arrow">→</span> : null}
        </div>
      ))}
      {type === 'linked-list' ? <span className="nc-ds__null">null</span> : null}
      {type === 'queue' ? <span className="nc-ds__marker">REAR</span> : null}
      {!values.length ? <span className="nc-ds__empty-copy">No values</span> : null}
    </div>
  );
}

function TreeNodes({ values, onChange }) {
  const levels = [];
  let offset = 0;
  let levelSize = 1;
  while (offset < values.length) {
    levels.push(values.slice(offset, offset + levelSize).map((value, index) => ({
      value,
      index: offset + index,
    })));
    offset += levelSize;
    levelSize *= 2;
  }

  const numLevels = levels.length;
  const totalHeight = numLevels > 0 ? numLevels * 44 + (numLevels - 1) * 24 : 0;

  const getCenter = (l, iInLevel) => {
    const n = Math.pow(2, l);
    const x = ((iInLevel + 0.5) / n) * 100;
    const y = ((l * 68 + 22) / totalHeight) * 100;
    return { x, y };
  };

  const edges = [];
  for (let l = 0; l < numLevels - 1; l++) {
    const currentLevel = levels[l];
    const nextLevel = levels[l + 1];
    currentLevel.forEach((node, i) => {
      const p1 = getCenter(l, i);
      if (2 * i < nextLevel.length) {
        const p2 = getCenter(l + 1, 2 * i);
        edges.push({ id: `e-${node.index}-left`, x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y });
      }
      if (2 * i + 1 < nextLevel.length) {
        const p2 = getCenter(l + 1, 2 * i + 1);
        edges.push({ id: `e-${node.index}-right`, x1: p1.x, y1: p1.y, x2: p2.x, y2: p2.y });
      }
    });
  }

  return (
    <div className="nc-ds__tree" style={{ position: 'relative' }}>
      {numLevels > 1 && (
        <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0, pointerEvents: 'none' }}>
          {edges.map((edge) => (
            <line
              key={edge.id}
              x1={`${edge.x1}%`}
              y1={`${edge.y1}%`}
              x2={`${edge.x2}%`}
              y2={`${edge.y2}%`}
              stroke="rgba(99, 102, 241, 0.4)"
              strokeWidth="2"
            />
          ))}
        </svg>
      )}
      {levels.map((level, levelIndex) => (
        <div className="nc-ds__tree-level" key={`level-${levelIndex}`} style={{ zIndex: 1, position: 'relative' }}>
          {level.map((node) => (
            <input
              key={`node-${node.index}`}
              value={node.value}
              onChange={(event) => onChange(node.index, event.target.value)}
              aria-label={`Tree node ${node.index + 1}`}
            />
          ))}
        </div>
      ))}
      {!values.length ? <span className="nc-ds__empty-copy">Empty tree</span> : null}
    </div>
  );
}

function HashMapRows({ entries, onChange }) {
  return (
    <div className="nc-ds__hash">
      <div className="nc-ds__hash-head"><span>Bucket</span><span>Key</span><span>Value</span></div>
      {entries.map((entry, index) => (
        <div className="nc-ds__hash-row" key={`entry-${index}`}>
          <span>{index}</span>
          <input
            value={entry.key}
            onChange={(event) => onChange(index, { ...entry, key: event.target.value })}
            aria-label={`Hash key ${index + 1}`}
          />
          <input
            value={entry.value}
            onChange={(event) => onChange(index, { ...entry, value: event.target.value })}
            aria-label={`Hash value ${index + 1}`}
          />
        </div>
      ))}
      {!entries.length ? <span className="nc-ds__empty-copy">Empty map</span> : null}
    </div>
  );
}

function computeDsIdealSize(type, length) {
  const baseW = 48; // 28px padding + 20px extra buffer
  const baseH = 92; // 72px (header+padding) + 20px extra buffer

  if (type === 'linked-list' || type === 'queue') {
    return { w: baseW + length * 85 + 60, h: baseH + 40 };
  }
  if (type === 'stack') {
    return { w: baseW + 120, h: baseH + length * 42 + 20 };
  }
  if (type === 'hash-map') {
    return { w: 360 + baseW, h: baseH + (length + 1) * 38 };
  }
  if (type === 'tree') {
    if (length === 0) return { w: 150, h: baseH + 40 };
    const numLevels = Math.floor(Math.log2(length)) + 1;
    const h = numLevels * 44 + Math.max(0, numLevels - 1) * 24;
    const bottomNodes = Math.pow(2, numLevels - 1);
    const w = bottomNodes * 44 + Math.max(0, bottomNodes - 1) * 20;
    return { w: baseW + w + 40, h: baseH + h };
  }
  return { w: 300, h: 200 };
}

function DataStructureWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const type = element.widgetType;
  const config = CONFIG[type] || CONFIG['linked-list'];
  const data = element.widgetData || {};
  const values = Array.isArray(data.values) ? data.values : [];
  const entries = Array.isArray(data.entries) ? data.entries : [];

  const update = useCallback((patch) => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id
        ? { ...candidate, widgetData: { ...candidate.widgetData, ...patch } }
        : candidate
    )));
  }, [commitElements, element.id]);

  const updateValue = (index, value) => {
    const next = values.slice();
    next[index] = coerceValue(value);
    update({ values: next });
  };

  const add = () => {
    let nextEntries = entries;
    let nextValues = values;

    if (type === 'hash-map') {
      if (entries.length >= config.max) return;
      nextEntries = entries.concat([{ key: `key${entries.length + 1}`, value: '' }]);
    } else {
      if (values.length >= config.max) return;
      nextValues = values.concat([config.nextValue(values.length)]);
    }

    const len = type === 'hash-map' ? nextEntries.length : nextValues.length;
    const ideal = computeDsIdealSize(type, len);

    commitElements((els) => els.map((e) => {
      if (e.id !== element.id) return e;
      return {
        ...e,
        w: Math.max(e.w, ideal.w),
        h: Math.max(e.h, ideal.h),
        widgetData: { ...e.widgetData, entries: nextEntries, values: nextValues },
      };
    }));
  };

  const remove = () => {
    let nextEntries = entries;
    let nextValues = values;

    if (type === 'hash-map') {
      if (entries.length === 0) return;
      nextEntries = entries.slice(0, -1);
    } else {
      if (values.length === 0) return;
      nextValues = values.slice(0, -1);
    }

    const len = type === 'hash-map' ? nextEntries.length : nextValues.length;
    const ideal = computeDsIdealSize(type, len);
    const slack = 40;

    commitElements((els) => els.map((e) => {
      if (e.id !== element.id) return e;
      
      let nextW = e.w;
      let nextH = e.h;

      // Shrink if they haven't manually resized it way bigger than needed
      if (e.w > ideal.w + slack) {
        nextW = Math.max(ideal.w, 150); // min width
      }
      if (e.h > ideal.h + slack) {
        nextH = Math.max(ideal.h, 100); // min height
      }

      return {
        ...e,
        w: nextW,
        h: nextH,
        widgetData: { ...e.widgetData, entries: nextEntries, values: nextValues },
      };
    }));
  };

  const deleteWidget = () => {
    commitElements((elements) => elements.map((candidate) => (
      candidate.id === element.id ? { ...candidate, isDeleted: true } : candidate
    )));
  };

  return (
    <div
      className={`nc-data-widget nc-ds nc-ds--${type}`}
      style={{
        borderColor: element.style?.stroke || '#475569',
        borderWidth: element.style?.strokeWidth ?? 1,
      }}
    >
      <div className="nc-widget-header nc-data-widget__header" data-nc-drag-handle="1">
        <input
          className="nc-data-widget__title-input"
          value={data.title || config.label}
          onChange={(event) => update({ title: event.target.value })}
          aria-label={`${config.label} title`}
        />
        <div className="nc-data-widget__actions">
          <button
            type="button"
            onClick={remove}
            disabled={type === 'hash-map' ? !entries.length : !values.length}
            aria-label={`Remove ${config.label} item`}
          >
            −
          </button>
          <button
            type="button"
            onClick={add}
            disabled={type === 'hash-map' ? entries.length >= config.max : values.length >= config.max}
            aria-label={`Add ${config.label} item`}
          >
            +
          </button>
          <button type="button" className="nc-data-widget__close" onClick={deleteWidget} aria-label={`Delete ${config.label}`}>×</button>
        </div>
      </div>
      <div className="nc-data-widget__body nc-ds__body">
        {type === 'tree' ? <TreeNodes values={values} onChange={updateValue} /> : null}
        {type === 'hash-map' ? (
          <HashMapRows
            entries={entries}
            onChange={(index, entry) => {
              const next = entries.slice();
              next[index] = entry;
              update({ entries: next });
            }}
          />
        ) : null}
        {type !== 'tree' && type !== 'hash-map' ? (
          <LinearNodes type={type} values={values} onChange={updateValue} />
        ) : null}
      </div>
    </div>
  );
}

export default memo(DataStructureWidgetImpl);
