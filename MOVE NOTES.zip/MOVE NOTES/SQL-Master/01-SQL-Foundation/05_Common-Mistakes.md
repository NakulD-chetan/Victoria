# SQL Foundation — Common Mistakes

| Mistake | Correct mental model |
|---------|----------------------|
| Calling `SELECT` “DDL” | `SELECT` is **DQL** (querying). |
| “Foreign key = same value as PK” | FK must reference **PK or unique** parent key; **types** must match. |
| Using `DELETE` without `WHERE` in production | Deletes **all rows** — use transactions + preview. |
| Assuming `TRUNCATE` always works like `DELETE` | FKs / permissions may block; behavior varies by engine. |
| Confusing **unique** with **primary** | PK implies **NOT NULL** + unique; multiple unique cols allowed. |

---

*Next: [[06_Edge-Cases]]*
