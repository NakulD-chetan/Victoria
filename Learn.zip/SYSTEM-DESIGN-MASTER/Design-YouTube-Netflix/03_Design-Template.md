# Design YouTube/Netflix — Design Template

> **Permanent Recall:** Architecture = **Upload Pipeline** (raw → transcoding → processed → CDN) + **Streaming Pipeline** (CDN edge → origin on miss). Transcoding uses **FFmpeg** in a **DAG**; CDN handles 90%+ reads; metadata in **Cassandra** or similar; search in **Elasticsearch**.

---

## High-Level Architecture (ASCII)

```
                              ┌──────────────────────────────────────────────────────────┐
                              │                      CLIENTS                              │
                              │              (Web, Mobile, TV, Console)                   │
                              └──────────────────────────┬───────────────────────────────┘
                                                         │
                    ┌────────────────────────────────────┼────────────────────────────────────┐
                    │                                    │                                    │
                    ▼                                    ▼                                    ▼
            ┌──────────────┐                    ┌──────────────┐                    ┌──────────────┐
            │  Upload API  │                    │  Stream API  │                    │ Metadata API │
            │ (resumable)  │                    │  (manifest)  │                    │ (search,rec) │
            └──────┬───────┘                    └──────┬───────┘                    └──────┬───────┘
                   │                                    │                                    │
    ═══════════════╪══════════ UPLOAD PATH (Write) ════╪═════════════════════════════════════╪══════
                   │                                    │                                    │
                   ▼                                    │                                    ▼
            ┌──────────────┐                            │                            ┌──────────────┐
            │ Object Store │                            │                            │  Cassandra   │
            │  (raw video) │                            │                            │  (metadata)  │
            └──────┬───────┘                            │                            └──────┬───────┘
                   │                                    │                                    │
                   ▼                                    │                                    ▼
            ┌──────────────┐                            │                            ┌──────────────┐
            │    Queue     │                            │                            │ Elasticsearch│
            │ (SQS/Kafka)  │                            │                            │  (search)    │
            └──────┬───────┘                            │                            └──────────────┘
                   │                                    │
                   ▼                                    │
            ┌──────────────┐                            │
            │ Transcoding  │                            │
            │   Workers    │                            │
            │ (FFmpeg DAG) │                            │
            └──────┬───────┘                            │
                   │                                    │
                   ▼                                    │
            ┌──────────────┐                            │
            │ Object Store │                            │
            │ (processed)  │                            │
            │ 240p-4K      │                            │
            └──────┬───────┘                            │
                   │                                    │
                   ▼                                    │
            ┌──────────────┐      ══════════════════════╪══════ STREAMING PATH (Read) ═══════════
            │  CDN Push    │                            │
            │  (popular)   │                            │
            └──────┬───────┘                            │
                   │                                    │
                   └────────────────────────────────────┼────────────────────────────────────┐
                                                        ▼                                    │
                                                 ┌──────────────┐                            │
                                                 │  CDN Edge    │◄───────────────────────────┘
                                                 │  (CloudFront)│
                                                 └──────┬───────┘
                                                        │ miss
                                                        ▼
                                                 ┌──────────────┐
                                                 │   Origin     │
                                                 │ (Object Store)│
                                                 └──────────────┘
```

---

## Upload Pipeline (Detailed)

```
Step 1: Client initiates upload
        POST /upload/init → { upload_id, chunk_size }
        (Resumable: multipart upload)

Step 2: Client uploads chunks to Upload Service
        PUT /upload/chunk { upload_id, chunk_index, data }
        → Upload Service stores in Object Store (raw)

Step 3: On complete, Upload Service publishes to Queue
        Message: { video_id, s3_raw_key, metadata }

Step 4: Transcoding worker picks up job
        • Download raw from S3
        • FFmpeg: transcode to 240p, 360p, 480p, 720p, 1080p, 4K
        • Segment into chunks (e.g., 6-sec .ts segments)
        • Generate manifest (master.m3u8, variant playlists)
        • Upload processed files to Object Store
        • Optionally: CDN invalidation or pre-push for popular

Step 5: Metadata service updates DB
        video_id, channel_id, title, description, manifest_url, thumbnail_url, status=READY
```

> **FAANG Tip:** Never block upload on transcoding. Return immediately; processing is async.

---

## Transcoding Service (DAG)

```
                    ┌─────────────┐
                    │  Raw Video  │
                    │  (1 input)  │
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
   ┌─────────┐       ┌─────────┐       ┌─────────┐
   │ 240p    │       │ 480p    │       │ 1080p   │  ... (parallel encodes)
   │ encode  │       │ encode  │       │ encode  │
   └────┬────┘       └────┬────┘       └────┬────┘
        │                 │                 │
        └─────────────────┼─────────────────┘
                          ▼
                   ┌─────────────┐
                   │  Segment    │  (e.g., 6-sec chunks)
                   │  (fragmentation)│
                   └──────┬──────┘
                          ▼
                   ┌─────────────┐
                   │  Manifest   │  (HLS: .m3u8)
                   │  generation │
                   └──────┬──────┘
                          ▼
                   ┌─────────────┐
                   │  Upload to  │
                   │  S3 + CDN   │
                   └─────────────┘
```

- **FFmpeg** command example (conceptual):
  `ffmpeg -i input.mp4 -vf scale=1280:720 -c:v libx264 -hls_time 6 -hls_playlist_type vod output_720p.m3u8`
- Each resolution = separate encode; run in parallel on worker pool

---

## Streaming Pipeline (Detailed)

```
Step 1: User clicks play
        GET /videos/{video_id}/manifest
        → Returns master.m3u8 URL (or embedded CDN URLs)

Step 2: Client fetches manifest from CDN
        GET https://cdn.example.com/videos/{video_id}/master.m3u8

Step 3: Client selects quality (e.g., 720p) based on:
        • Network bandwidth (estimated)
        • Buffer level
        • Device capability

Step 4: Client fetches chunks
        GET https://cdn.example.com/videos/{video_id}/720p/segment_0.ts
        GET .../segment_1.ts, ...

Step 5: CDN edge serves chunks (cache hit ~90%+)
        On miss: origin (Object Store) → cache at edge → respond
```

---

## CDN Strategy

| Content Type | Strategy | Reason |
|--------------|----------|--------|
| **Viral / trending** | Pre-push to all POPs | Avoid thundering herd on origin |
| **New uploads** | Push to region of uploader | Likely early viewers nearby |
| **Long-tail** | Pull on first request | Don't waste edge storage |
| **Live (if added)** | Real-time ingestion to CDN | Different pipeline |

---

## Metadata Service

| Field | Store | Example |
|-------|-------|---------|
| video_id, channel_id, title, description, tags | Cassandra/DynamoDB | Partition by video_id |
| manifest_url, thumbnail_url | Same | CDN URLs |
| view_count, like_count | Same (eventual) | Increment async |
| created_at, status | Same | Processing/Ready |

- **Cassandra** (or DynamoDB): Wide rows for comments; good for write scaling
- **Search:** Elasticsearch — title, description, tags; sync from Cassandra via CDC or batch

---

## Search (Elasticsearch)

- **Index:** video_id, title, description, tags, channel_id, view_count, published_at
- **Query:** Full-text search; filters (duration, upload date, channel)
- **Ranking:** Relevance + engagement (views, likes) + recency

---

## Recommendations

| Approach | Description |
|----------|-------------|
| **Collaborative filtering** | "Users who watched X also watched Y" |
| **Content-based** | Same channel, same tags, similar title |
| **Trending** | Time-weighted views, likes |
| **Hybrid** | Combine signals; ML model for ranking |

- Pre-compute candidate set; serve from cache
- Real-time signals (recent views) can adjust ranking

---

## API Design

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/upload/init` | Init resumable upload; returns `upload_id` |
| PUT | `/upload/chunk` | Upload chunk; `upload_id`, `chunk_index`, `data` |
| POST | `/upload/complete` | Finalize; triggers transcoding |
| GET | `/videos/{id}` | Video metadata |
| GET | `/videos/{id}/manifest` | HLS/DASH manifest URL |
| GET | `/search` | Search videos; query, filters |
| GET | `/recommendations` | Personalized "watch next" |
| POST | `/videos/{id}/like` | Like video |
| POST | `/videos/{id}/comments` | Add comment |
| GET | `/channels/{id}/videos` | Channel video list |
| POST | `/channels/{id}/subscribe` | Subscribe to channel |

---

## Data Model (Key Tables)

| Table | Key Fields |
|-------|-------------|
| **videos** | video_id, channel_id, title, description, manifest_url, thumbnail_url, status, created_at |
| **channels** | channel_id, name, subscriber_count |
| **comments** | comment_id, video_id, user_id, parent_id, text, created_at |
| **likes** | user_id, video_id |
| **subscriptions** | user_id, channel_id |

---

## Resolution / Quality Ladder

| Resolution | Bitrate (approx) | Use Case |
|------------|------------------|----------|
| 240p | 0.5 Mbps | Low bandwidth |
| 360p | 1 Mbps | Mobile, poor network |
| 480p | 2 Mbps | Standard |
| 720p | 4 Mbps | HD |
| 1080p | 8 Mbps | Full HD |
| 4K | 20+ Mbps | Premium |

---

## Mermaid: Upload Flow

```mermaid
flowchart TD
    A[Client] --> B[Upload Service]
    B --> C[Object Store Raw]
    C --> D[Queue]
    D --> E[Transcoding Worker]
    E --> F[FFmpeg: Multi-resolution]
    F --> G[Object Store Processed]
    G --> H[CDN Push]
    H --> I[Metadata DB]
```

---

## Mermaid: Streaming Flow

```mermaid
flowchart LR
    A[Client] --> B[Manifest API]
    B --> C[CDN Edge]
    C --> D{Cache Hit?}
    D -->|Yes| E[Serve Chunks]
    D -->|No| F[Origin]
    F --> G[Cache at Edge]
    G --> E
```

---

## Sharding Strategy

| Data | Shard Key | Reason |
|------|-----------|--------|
| Videos | video_id | Uniform distribution |
| Comments | video_id | Comments fetched per video |
| Likes | video_id | Aggregation per video |
| Subscriptions | user_id | "My subscriptions" query |

---

## Caching Layers

| Layer | What | TTL |
|-------|------|-----|
| CDN | Video chunks, manifest, thumbnails | Days (immutable) |
| Redis | Video metadata (hot) | Minutes |
| Redis | Recommendations per user | Minutes |
| DB | Source of truth | N/A |

---

## Failure Handling

| Failure | Handling |
|---------|----------|
| Transcoding job fails | Retry (3x); dead-letter queue; alert; fallback to lower quality if partial |
| CDN miss | Origin serves; populate cache |
| Upload chunk lost | Client retries; idempotent chunk index |
| Metadata DB down | Read replica; eventual consistency acceptable |
