# Load Balancing — Concept (Deep Understanding)

> **Permanent Recall:** Load balancing distributes incoming traffic across multiple backend servers to achieve high availability, scalability, and fault tolerance. Choose **L4** for raw throughput and simplicity (TCP/UDP); choose **L7** when you need HTTP-aware routing, SSL termination, or content-based rules. Algorithm selection depends on workload: stateless APIs → round robin; session affinity needed → IP hash or sticky sessions; caching/memcached → consistent hashing.

---

## What is Load Balancing?

**Load balancing** is the practice of distributing incoming network requests across multiple servers so that no single server is overwhelmed.

### Real-World Analogy

Imagine a **McDonald's with 5 billing counters**. Without load balancing, everyone lines up at counter 1 — counter 1 is crushed, counters 2-5 sit idle. With load balancing, a **manager at the entrance** directs each customer to the least busy counter. That manager IS the load balancer.

### How it Works Step-by-Step

```
1. Client sends request (e.g., GET https://api.example.com/users)
2. DNS resolves api.example.com → IP of the Load Balancer (NOT the backend servers)
3. Request hits the Load Balancer
4. LB picks a backend server using an algorithm (round robin, least connections, etc.)
5. LB forwards the request to that backend server
6. Backend server processes the request and sends response back to LB
7. LB forwards the response back to the client
8. Client never knows which backend server handled the request
```

```
Client ──► Load Balancer ──► [Server 1, Server 2, ..., Server N]
                 ▲                        │
                 └────── response ◄───────┘
```

**Key insight:** The client talks to the LB's IP address, not the server's IP. The LB acts as a middleman.

### Why is Load Balancing Needed?

| Problem Without LB | How LB Solves It |
|---------------------|------------------|
| **One server can't handle millions of requests** | Splits traffic across N servers → N× capacity |
| **Server crash = entire service down** | LB detects failure, stops routing to dead server; users don't notice |
| **Deploying new code = downtime** | LB drains old servers, routes to new ones; zero-downtime deploy |
| **Users far from server = high latency** | GSLB routes to nearest datacenter |
| **Uneven traffic spikes** | LB + auto-scaling: add servers when busy, remove when idle |

---

## Reverse Proxy vs Load Balancer — What's the Difference?

This is one of the **most confusing** topics. Let's clear it up completely.

### What is a Reverse Proxy?

A **reverse proxy** sits between clients and servers. The client sends requests to the proxy, and the proxy forwards them to backend servers. The client never talks directly to the backend.

```
WITHOUT Reverse Proxy:
  Client ──────────────► Backend Server
  (Client knows server's IP)

WITH Reverse Proxy:
  Client ──► Reverse Proxy ──► Backend Server
  (Client only knows proxy's IP; server is hidden)
```

### What is a Load Balancer?

A **load balancer** distributes traffic across **multiple** backend servers.

### So What's the Difference?

| Aspect | Reverse Proxy | Load Balancer |
|--------|---------------|---------------|
| **Primary purpose** | Hide backend servers, add security, caching, SSL | Distribute traffic across multiple servers |
| **Number of backends** | Can work with even 1 server | Needs 2+ servers to make sense |
| **Key feature** | Security, anonymity, caching, compression | Traffic distribution, failover |
| **Example** | Nginx in front of 1 app server for SSL & caching | Nginx in front of 5 app servers distributing requests |

### The Truth: They Overlap!

**Every load balancer is a reverse proxy** (it sits between client and servers, hides backends). But **not every reverse proxy is a load balancer** (a reverse proxy with 1 backend isn't "balancing" anything).

```
Reverse Proxy with 1 backend = just a reverse proxy
  Client → [Nginx] → [1 Server]
  Purpose: SSL, caching, security

Reverse Proxy with N backends + distribution = load balancer
  Client → [Nginx] → [Server 1, Server 2, Server 3]
  Purpose: SSL + caching + distribute traffic
```

**Why Nginx, HAProxy, etc. are called both:** Because they CAN do both. When you configure Nginx with an `upstream` block containing multiple servers, it's acting as a load balancer. When it's in front of one server doing SSL termination, it's acting as a reverse proxy.

### Forward Proxy vs Reverse Proxy (Bonus Clarity)

```
FORWARD PROXY (like a VPN or corporate proxy):
  Clients ──► [Forward Proxy] ──► Internet/Servers
  Purpose: Client wants to hide identity or bypass restrictions
  Who's hidden: CLIENT is hidden from the server

REVERSE PROXY (like Nginx, LB):
  Clients ──► [Reverse Proxy] ──► Backend Servers
  Purpose: Server wants to hide infrastructure
  Who's hidden: SERVER is hidden from the client
```

| | Forward Proxy | Reverse Proxy |
|---|---------------|---------------|
| **Sits near** | Client side | Server side |
| **Hides** | Client identity | Server identity |
| **Example** | VPN, corporate proxy | Nginx, HAProxy, ALB |
| **Who configures it** | Client/user | Server/admin |

---

## How Hardware Load Balancers Work (Deep Dive)

### What Are They?

Hardware load balancers are **dedicated physical appliances** — actual metal boxes you rack in a data center. Companies like **F5 (BIG-IP)**, **Citrix (NetScaler)**, and **A10 Networks** make them.

### How They Work Internally

```
┌─────────────────────────────────────────────────┐
│           HARDWARE LOAD BALANCER (F5 BIG-IP)    │
│                                                 │
│  ┌──────────────┐    ┌────────────────────────┐ │
│  │  Network      │    │  ASIC / FPGA Chip     │ │
│  │  Interface    │───►│  (Custom silicon for   │ │
│  │  Cards (NICs) │    │   packet processing)  │ │
│  └──────────────┘    └──────────┬─────────────┘ │
│                                 │               │
│                    ┌────────────▼────────────┐   │
│                    │   Proprietary OS         │   │
│                    │   (TMOS for F5)          │   │
│                    │   - Connection table     │   │
│                    │   - Health check engine  │   │
│                    │   - SSL offload engine   │   │
│                    │   - Algorithm engine     │   │
│                    └────────────┬────────────┘   │
│                                 │               │
│                    ┌────────────▼────────────┐   │
│                    │   Configuration / GUI    │   │
│                    │   (admin interface)      │   │
│                    └─────────────────────────┘   │
└─────────────────────────────────────────────────┘
```

**Step-by-step what happens when a request arrives at a hardware LB:**

1. **Packet arrives** at the NIC (network interface card)
2. **ASIC/FPGA chip** processes the packet at hardware speed (not CPU — this is why it's fast)
3. The chip reads source IP, destination IP, port number
4. The **algorithm engine** decides which backend server should handle it
5. The chip **rewrites the packet header** (changes destination IP to the chosen backend)
6. Packet is forwarded to the backend at wire speed
7. Response comes back, chip rewrites source IP back to the LB's VIP (Virtual IP)
8. Client sees response from the LB's IP — never knows about the backend

**Why ASICs matter:** An ASIC (Application-Specific Integrated Circuit) is a chip designed ONLY for packet processing. It doesn't run a general OS. It processes packets in **hardware** at line rate (millions of packets per second). A CPU-based solution would be 10-100x slower for the same task.

### Pros and Cons of Hardware LB

| Pros | Cons |
|------|------|
| Extremely fast (ASIC-based, nanosecond latency) | Very expensive ($50K–$500K+ per unit) |
| Handles millions of connections | Vendor lock-in (F5, Citrix proprietary) |
| Built-in SSL acceleration chip | Hard to scale (buy more boxes) |
| Dedicated support from vendor | Limited programmability |
| Battle-tested for decades | Physical hardware = data center only |

### When Hardware LBs Are Used

- **Banks & financial trading** — need nanosecond latency
- **Telecom companies** — handle millions of TCP connections
- **Legacy enterprise** — already invested, hard to migrate
- **Compliance-heavy industries** — need certified, audited hardware

---

## How Software Load Balancers Work (Deep Dive)

### What Are They?

Software load balancers are **programs that run on regular servers** (commodity hardware or VMs). Examples: **Nginx**, **HAProxy**, **Envoy**, **Traefik**, **AWS ALB/NLB** (cloud-managed software LBs running on AWS infrastructure).

### How They Work Internally

```
┌──────────────────────────────────────────────────┐
│           SOFTWARE LOAD BALANCER (e.g., Nginx)   │
│                                                  │
│  ┌────────────────────────────────────────────┐  │
│  │  Regular Linux Server (commodity hardware) │  │
│  │  CPU: Intel/AMD    RAM: 16-64GB            │  │
│  │  NIC: Standard 10Gbps                      │  │
│  └──────────────────────┬─────────────────────┘  │
│                         │                        │
│  ┌──────────────────────▼─────────────────────┐  │
│  │  Operating System (Linux)                  │  │
│  │  - TCP/IP stack (kernel handles networking)│  │
│  │  - epoll / kqueue (event-driven I/O)       │  │
│  └──────────────────────┬─────────────────────┘  │
│                         │                        │
│  ┌──────────────────────▼─────────────────────┐  │
│  │  LB Software (Nginx / HAProxy / Envoy)     │  │
│  │                                            │  │
│  │  1. LISTENER: Binds to port 80/443         │  │
│  │     - Accepts incoming TCP connections     │  │
│  │     - Uses epoll for thousands of conns    │  │
│  │                                            │  │
│  │  2. PARSER (L7 only):                      │  │
│  │     - Reads HTTP request (method, path,    │  │
│  │       headers, cookies)                    │  │
│  │     - Matches routing rules                │  │
│  │                                            │  │
│  │  3. ALGORITHM ENGINE:                      │  │
│  │     - Picks backend using configured algo  │  │
│  │     - Maintains server list + health state │  │
│  │                                            │  │
│  │  4. CONNECTION POOL:                       │  │
│  │     - Opens/reuses TCP connections to      │  │
│  │       backend servers                      │  │
│  │     - Keep-alive connections save overhead  │  │
│  │                                            │  │
│  │  5. HEALTH CHECKER:                        │  │
│  │     - Periodically pings backends          │  │
│  │     - Removes unhealthy servers from pool  │  │
│  └────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────┘
```

**Step-by-step what happens when a request arrives at a software LB (Nginx L7 example):**

1. **Client opens TCP connection** to Nginx's IP:port (e.g., 10.0.0.1:443)
2. **Nginx accepts the connection** using `epoll` (Linux's efficient I/O multiplexer — can handle 100K+ connections with one thread)
3. **SSL handshake** happens if HTTPS — Nginx decrypts using the SSL certificate
4. **Nginx reads the HTTP request** — parses method (GET), path (/api/users), headers, cookies
5. **Routing rules matched** — e.g., `/api/*` goes to backend pool "api-servers"
6. **Algorithm picks a server** — e.g., round robin picks Server 2
7. **Nginx opens (or reuses) a TCP connection** to Server 2 (e.g., 10.0.1.2:8080)
8. **Nginx forwards the HTTP request** to Server 2 (can modify headers, add X-Forwarded-For)
9. **Server 2 processes** and sends response back to Nginx
10. **Nginx forwards response to client** (can compress, cache, add headers)
11. Client sees response — never knows Server 2 existed

### The Event-Driven Architecture (Why Nginx is Fast)

```
TRADITIONAL (Apache):
  1 request = 1 thread/process
  10,000 requests = 10,000 threads = HUGE memory, context switching

NGINX (Event-Driven):
  1 worker process handles THOUSANDS of connections
  Uses epoll: "tell me when ANY of my 10,000 sockets has data"
  Non-blocking I/O: while waiting for Server 2's response,
    Nginx handles other requests
  
  Result: handles 100K+ concurrent connections on one server
```

This is why Nginx/HAProxy can be load balancers — they're designed to handle massive concurrency with minimal resources.

### Pros and Cons of Software LB

| Pros | Cons |
|------|------|
| Cheap (runs on any server, many are open-source) | Slightly higher latency than ASIC-based hardware |
| Flexible (configure anything, customize, script) | Needs proper tuning (ulimits, kernel params) |
| Scales horizontally (add more LB instances) | CPU-bound for SSL at very high scale |
| Cloud-native (works in VMs, containers, K8s) | No dedicated vendor support (for open-source) |
| Rapid updates (software deploy vs hardware swap) | Shares CPU/RAM with other processes |

### Cloud-Managed Software LBs (AWS ALB, NLB, GCP LB)

These are **software LBs that the cloud provider runs for you**. You don't manage the underlying servers.

```
YOU manage:                    CLOUD manages:
- Routing rules                - The actual servers running the LB
- Health check config          - Scaling the LB itself
- SSL certificates             - High availability (multi-AZ)
- Target groups                - DDoS protection
```

| Cloud LB | Type | Layer | Key Feature |
|----------|------|-------|-------------|
| AWS ALB (Application LB) | Software, managed | L7 | Path routing, host routing, WebSocket |
| AWS NLB (Network LB) | Software, managed | L4 | Ultra-low latency, static IP, millions of connections |
| AWS CLB (Classic LB) | Legacy | L4/L7 | Old, avoid for new designs |
| GCP HTTP(S) LB | Software, managed | L7 | Global, anycast, auto-scaling |
| Azure App Gateway | Software, managed | L7 | WAF, SSL, path routing |

---

## Hardware vs Software LB — Complete Comparison

| Aspect | Hardware LB (F5, Citrix) | Software LB (Nginx, HAProxy, Envoy) | Cloud-Managed (ALB, NLB) |
|--------|--------------------------|--------------------------------------|--------------------------|
| **Cost** | $50K–$500K per box | Free (open-source) to low | Pay per use |
| **Speed** | ASIC: nanosecond | CPU: microsecond | Microsecond (optimized) |
| **Flexibility** | Limited, vendor GUI | Full control, scriptable | Console/API, moderate |
| **Scaling** | Buy more boxes | Add more VM instances | Auto-scales |
| **SSL offload** | Dedicated SSL chip | CPU-based (can be bottleneck) | Managed, scales |
| **Where it runs** | Physical data center | Any server, VM, container | Cloud only |
| **Typical user** | Banks, telecom, enterprise | Startups, cloud-native, microservices | Anyone on cloud |
| **HA** | Active-passive pair | Multiple instances + VIP | Built-in HA |
| **Updates** | Firmware upgrade (slow) | Software deploy (fast) | Provider handles |

> **Interview Answer:** *"For most modern systems, we'd use a software or cloud-managed load balancer like Nginx, HAProxy, or AWS ALB — they're cost-effective, flexible, and scale with the system. Hardware LBs like F5 are used in specific scenarios like financial trading where nanosecond latency matters or in legacy enterprise environments."*

---

## Types of Load Balancers by OSI Layer

### L4 vs L7 Load Balancing — Deep Explanation

**To understand L4 vs L7, you need to understand what the LB "sees" at each layer.**

### What L4 Load Balancer Sees

```
When a TCP packet arrives at L4 LB, it sees:

┌─────────────────────────────────────────┐
│  IP Header:                             │
│    Source IP:  203.0.113.50              │  ← Client's IP
│    Dest IP:   10.0.0.1                  │  ← LB's VIP
│                                         │
│  TCP Header:                            │
│    Source Port: 52481                    │  ← Client's random port
│    Dest Port:   443                     │  ← Service port
│                                         │
│  Payload: [encrypted blob / raw bytes]  │  ← L4 CANNOT read this
└─────────────────────────────────────────┘

L4 decision: Based ONLY on IP + port
  "Client 203.0.113.50:52481 → send to Server 2 (10.0.1.2:8080)"
```

**L4 doesn't open the envelope — it just reads the address on the outside.**

### What L7 Load Balancer Sees

```
When an HTTP request arrives at L7 LB, it sees EVERYTHING:

┌─────────────────────────────────────────┐
│  IP Header:     Same as L4              │
│  TCP Header:    Same as L4              │
│                                         │
│  HTTP Request (after SSL decrypt):      │
│    GET /api/users HTTP/1.1              │  ← Method + Path
│    Host: api.example.com                │  ← Hostname
│    Cookie: session=abc123               │  ← Session cookie
│    Authorization: Bearer eyJ...         │  ← Auth token
│    User-Agent: Mozilla/5.0             │  ← Browser info
│    Accept: application/json             │
│    X-Custom-Header: value               │  ← Any custom header
│                                         │
│    Body: {"name": "John"}               │  ← Request body
└─────────────────────────────────────────┘

L7 decision: Based on ANY of the above
  "Path is /api/users → route to user-service pool"
  "Cookie session=abc123 → route to Server 3 (sticky)"
  "Host is admin.example.com → route to admin pool"
```

**L7 opens the envelope, reads the letter, and decides based on content.**

### Complete L4 vs L7 Comparison

| Aspect | Layer 4 (L4) | Layer 7 (L7) |
|--------|--------------|---------------|
| **OSI Layer** | Transport (TCP/UDP) | Application (HTTP, gRPC, WebSocket) |
| **What it sees** | IP address + port number only | Full HTTP request: path, headers, cookies, body |
| **What it CANNOT see** | URL path, headers, cookies, body | (It can see everything) |
| **How it routes** | `hash(IP:port) → server` | `/api/users → user-service`, `/api/orders → order-service` |
| **SSL/TLS** | Pass-through (doesn't decrypt) | Terminates SSL (decrypts at LB, re-encrypts or sends HTTP to backend) |
| **Speed** | Faster (no HTTP parsing) | Slower (must parse HTTP) |
| **Connection handling** | Opens 1 TCP connection to backend per client connection | Can reuse backend connections (connection multiplexing) |
| **Content modification** | Cannot modify request/response | Can add/remove headers, rewrite URLs, compress, cache |
| **Use cases** | TCP/UDP apps, database proxy, raw throughput | HTTP APIs, microservices, path-based routing, SSL termination |
| **Examples** | AWS NLB, HAProxy (tcp mode), LVS | AWS ALB, Nginx, HAProxy (http mode), Envoy |

### When to Use Which — Decision Guide

```
USE L4 when:
  ✅ You don't need to inspect HTTP content
  ✅ You need maximum throughput (millions of packets/sec)
  ✅ Backend is not HTTP (database, Redis, custom TCP protocol)
  ✅ You want SSL pass-through (backend handles SSL)
  ✅ Simple distribution is enough (don't need path routing)

USE L7 when:
  ✅ You need path-based routing (/api/users → Service A, /api/orders → Service B)
  ✅ You need SSL termination at the LB (offload crypto from backends)
  ✅ You need header/cookie-based routing
  ✅ You need to add/modify headers (X-Forwarded-For, etc.)
  ✅ You need request/response caching at the LB
  ✅ You need rate limiting per URL or per user
  ✅ You're running HTTP microservices
```

---

## Load Balancing Algorithms — Deep Explanation

### Why Do Different Algorithms Exist?

Because different workloads have different characteristics:
- Some requests take 1ms, others take 10 seconds
- Some need the same client to always hit the same server
- Some servers are more powerful than others
- Some workloads benefit from cache locality

**There is no "best" algorithm — only the right one for your workload.**

### 1. Round Robin

**How it works:** Cycle through servers in order: S1, S2, S3, S1, S2, S3, ...

```
Request 1 → Server 1
Request 2 → Server 2
Request 3 → Server 3
Request 4 → Server 1  (cycle repeats)
Request 5 → Server 2
...
```

**Why it exists:** Simplest possible algorithm. If all requests are similar and all servers are equal, this is perfectly fair.

**When it fails:** If some requests are heavy (3 second DB query) and some are light (1ms health check), one server can get stuck with all the heavy ones while others finish their light ones.

| Good For | Bad For |
|----------|---------|
| Stateless APIs with similar request times | Long-running requests (file uploads, video) |
| Equal-capacity servers | Servers with different CPU/RAM |

### 2. Weighted Round Robin

**How it works:** Same as round robin, but servers get more or fewer turns based on weight.

```
Server 1 (weight 3) → gets 3 out of every 5 requests
Server 2 (weight 1) → gets 1 out of every 5
Server 3 (weight 1) → gets 1 out of every 5

Sequence: S1, S1, S1, S2, S3, S1, S1, S1, S2, S3, ...
```

**Why it exists:** Not all servers are equal. A 4-core server should handle more traffic than a 1-core server.

### 3. Least Connections

**How it works:** Send new request to the server with the **fewest currently active connections**.

```
Server 1: 5 active connections
Server 2: 2 active connections  ← new request goes HERE
Server 3: 8 active connections

Next request → Server 2 (has fewest)
```

**Why it exists:** When requests take different amounts of time, round robin fails because it doesn't know Server 3 is busy processing a giant upload. Least connections **adapts in real time**.

**How the LB tracks this:** The LB maintains a counter for each server. When it forwards a request, counter++. When the response comes back, counter--. New request → pick the server with the lowest counter.

| Good For | Bad For |
|----------|---------|
| Variable-duration requests | Adds slight overhead (tracking connections) |
| Chat, WebSocket, uploads | Overkill for uniform short requests |

### 4. IP Hash

**How it works:** `hash(client_IP) % number_of_servers = server_index`

```
Client 1 (IP: 203.0.113.50):  hash(203.0.113.50) % 3 = 1  → Server 1
Client 2 (IP: 198.51.100.23): hash(198.51.100.23) % 3 = 0  → Server 0
Client 1 again:                hash(203.0.113.50) % 3 = 1  → Server 1 (SAME!)
```

**Why it exists:** Sometimes you need the **same client to always reach the same server** (session affinity). IP hash guarantees this without cookies.

**When it fails:**
- **NAT/proxy:** 10,000 users behind one corporate proxy all have the same public IP → all hit one server
- **Adding/removing servers:** `hash % 3` vs `hash % 4` → almost ALL clients get remapped to different servers

### 5. Consistent Hashing

**How it works:** Imagine a **circle (ring) numbered 0 to 2^32**. Both servers and keys are hashed onto this ring. Each key goes to the next server clockwise.

```
The Hash Ring:

            0
           /|\
          / | \
    S1 ●  |  ● S3
        \  |  /
         \ | /
          \|/
           ● S2
           
Key "user123" hashes to position 42 → walk clockwise → hit S2
Key "user456" hashes to position 87 → walk clockwise → hit S3

If S2 is removed:
  Only keys that were going to S2 get redistributed (to S3)
  Keys going to S1 and S3 are UNAFFECTED!
```

**Why it exists:** When servers are added/removed, only ~1/N keys need to move (vs ALL keys with simple hash). Critical for caching where remapping = cache miss = thundering herd.

**Virtual nodes:** Each physical server is placed at multiple positions on the ring (e.g., 150 virtual nodes per server) for more even distribution.

| Good For | Bad For |
|----------|---------|
| Cache pools (memcached, Redis) | Overkill for simple stateless APIs |
| Systems where servers scale in/out frequently | More complex to implement/debug |

### 6. Random

**How it works:** Pick a random server for each request.

**Why it exists:** Statistically approaches even distribution with large numbers. No state to track. Simple.

### Algorithm Summary — When to Use What

| Your Situation | Use This Algorithm | Why |
|----------------|-------------------|-----|
| Stateless API, all servers equal | Round Robin | Simplest, fair enough |
| Servers have different capacity | Weighted Round Robin | Bigger server = more traffic |
| Requests take varying time (uploads, long queries) | Least Connections | Adapts to real-time load |
| Need same client → same server (sessions) | IP Hash or Sticky Sessions | Client affinity |
| Cache pool (memcached, Redis cluster) | Consistent Hashing | Minimize cache invalidation on scale |
| Don't care, want simplicity | Random or Round Robin | Both work for uniform loads |

---

## Health Checks — Deep Explanation

### Why Health Checks Exist

Without health checks, the LB has no idea if a server is alive or dead. It would keep sending traffic to a crashed server → users get errors.

### Active Health Checks (LB Probes the Server)

```
Every 5 seconds, the LB does this:

LB → "GET /health" → Server 1 → Response: 200 OK     ✅ Healthy
LB → "GET /health" → Server 2 → Response: 200 OK     ✅ Healthy
LB → "GET /health" → Server 3 → No response (timeout) ❌ Count: 1/3
                                                        
5 seconds later:
LB → "GET /health" → Server 3 → No response           ❌ Count: 2/3

5 seconds later:
LB → "GET /health" → Server 3 → No response           ❌ Count: 3/3
                                                        🚫 REMOVED from pool!
```

**Settings you configure:**
- **Interval:** How often to check (e.g., every 5 seconds)
- **Timeout:** How long to wait for response (e.g., 3 seconds)
- **Unhealthy threshold:** How many failures before removing (e.g., 3)
- **Healthy threshold:** How many successes before re-adding (e.g., 2)
- **Endpoint:** What URL to check (e.g., `/health`)

### Passive Health Checks (LB Learns from Real Traffic)

```
LB forwards real user request to Server 3
Server 3 responds with 502 Bad Gateway ← LB notes: failure count++
                                          
More real requests fail on Server 3...
After N failures → LB removes Server 3 from pool
```

**No extra probe traffic — but slower to detect** (relies on real users hitting the bad server).

### Active vs Passive — Comparison

| | Active | Passive |
|---|--------|---------|
| **How** | LB sends probe requests | LB watches real traffic responses |
| **Speed** | Detects quickly (every few seconds) | Slower (waits for real traffic to fail) |
| **Extra traffic** | Yes (probe requests) | No |
| **Can detect** | Server down, app crashed, dependencies dead | Server returning errors on real requests |
| **Best for** | Catching server crashes | Catching application-level issues |

**Best practice:** Use BOTH together. Active catches crashes; passive catches subtle issues.

---

## Session Persistence (Sticky Sessions) — Deep Explanation

### The Problem

```
WITHOUT sticky sessions:
  Request 1 from User A → Server 1 (logs in, session stored in Server 1's memory)
  Request 2 from User A → Server 2 (no session here! → "Please log in again")
  Request 3 from User A → Server 3 (no session here! → "Please log in again")
  
  User is furious.
```

### Solution 1: Sticky Sessions

```
WITH sticky sessions (cookie-based):
  Request 1 from User A → LB → Server 1 (logs in)
    Response includes: Set-Cookie: SERVERID=server1
  
  Request 2 from User A → LB reads cookie SERVERID=server1 → Server 1 ✅
  Request 3 from User A → LB reads cookie SERVERID=server1 → Server 1 ✅
  
  User stays on same server. Session works.
```

### Solution 2: External Session Store (Better!)

```
WITH external session store (Redis):
  Request 1 from User A → Server 1 (logs in, stores session in Redis)
  Request 2 from User A → Server 2 (reads session from Redis) ✅
  Request 3 from User A → Server 3 (reads session from Redis) ✅
  
  ANY server can serve ANY user. LB uses simple round robin.
  If Server 1 dies, session is still in Redis. No data loss.
```

| Approach | Pros | Cons |
|----------|------|------|
| Sticky Sessions | Simple, no external store needed | Server dies = session lost; uneven load |
| External Store (Redis) | Any server can serve any user; server failure doesn't lose session | Adds Redis dependency; slightly more latency |

> **Interview Answer:** *"We prefer stateless backends with session stored in Redis. This lets us use simple round robin and makes scaling trivial. Sticky sessions are a fallback when we can't externalize state."*

---

## DNS Load Balancing — Deep Explanation

### How it Works

Instead of using a dedicated LB appliance, the **DNS server itself** returns different IPs for the same domain name.

```
User 1 asks DNS: "What's the IP of api.example.com?"
  DNS responds: 10.0.1.1 (Server 1)

User 2 asks DNS: "What's the IP of api.example.com?"
  DNS responds: 10.0.1.2 (Server 2)

User 3 asks DNS: "What's the IP of api.example.com?"
  DNS responds: 10.0.1.3 (Server 3)
```

### Why It's Limited

| Problem | Explanation |
|---------|-------------|
| **No health checks** | DNS doesn't know if Server 2 is dead — keeps returning its IP |
| **Client caching** | Browser/OS caches the IP for hours; ignores DNS rotation |
| **No smart routing** | Can't do least connections, path routing, etc. |
| **Slow failover** | Even with low TTL, cached entries take time to expire |

### When It's Useful

DNS LB is used as the **first layer** of a multi-tier LB setup:

```
DNS returns IP of a LOAD BALANCER (not a backend server directly)

User → DNS → returns LB's IP → LB → Backend servers

For global: DNS returns nearest REGION's LB IP
User (India) → DNS → Mumbai LB IP → Mumbai backends
User (US)    → DNS → Virginia LB IP → Virginia backends
```

---

## Global Server Load Balancing (GSLB) — Deep Explanation

### What It Does

Routes users to the **nearest or healthiest datacenter** worldwide.

### How It Works

```
User in Mumbai types api.example.com

1. DNS query reaches GSLB-aware DNS (e.g., Route53, Cloudflare)
2. GSLB checks:
   - Where is the user? (GeoIP lookup → Mumbai, India)
   - Which datacenters are healthy? (Mumbai DC ✅, Virginia DC ✅, London DC ❌)
   - Which is closest/fastest? (Mumbai DC: 20ms, Virginia DC: 200ms)
3. GSLB returns Mumbai LB's IP address
4. User connects to Mumbai datacenter

User in New York:
1. Same domain → GSLB → Virginia DC is closest → returns Virginia LB's IP
```

### GSLB Routing Methods

| Method | How it decides | Best for |
|--------|---------------|----------|
| **Geo-based** | Client's geographic location | Simple regional routing |
| **Latency-based** | Measured latency to each DC | Lowest latency for users |
| **Health-based** | Route away from unhealthy DCs | Disaster recovery |
| **Weighted** | Send X% to DC-A, Y% to DC-B | Gradual migration, canary deploys |

---

## LB Placement in Architecture

```
                    ┌─────────────────────────────────────────────────┐
                    │                   INTERNET                      │
                    └─────────────────────────┬───────────────────────┘
                                              │
                    ┌─────────────────────────▼───────────────────────┐
                    │         GSLB / DNS (Global routing)             │
                    │    Routes to nearest datacenter's LB            │
                    └─────────────────────────┬───────────────────────┘
                                              │
                    ┌─────────────────────────▼───────────────────────┐
                    │         L4 LOAD BALANCER (NLB / LVS)            │
                    │    Raw TCP distribution, high throughput         │
                    └─────────────────────────┬───────────────────────┘
                                              │
                    ┌─────────────────────────▼───────────────────────┐
                    │         L7 LOAD BALANCER (ALB / Nginx)          │
                    │    Path routing, SSL term, header routing        │
                    └─────────────────────────┬───────────────────────┘
                              ┌───────────────┼───────────────┐
                              │               │               │
                              ▼               ▼               ▼
                        ┌──────────┐    ┌──────────┐    ┌──────────┐
                        │ /api/    │    │ /web/    │    │ /static/ │
                        │ users    │    │ frontend │    │ files    │
                        │ service  │    │ service  │    │ CDN      │
                        └──────────┘    └──────────┘    └──────────┘
```

**Where LBs sit in a typical system:**

| Position | What LB Does | Type |
|----------|-------------|------|
| **Edge (internet-facing)** | First contact, SSL termination, DDoS protection | L7 (ALB, Nginx) |
| **Between web tier and app tier** | Distribute to app servers | L4 or L7 |
| **Between app tier and DB** | Distribute reads to replicas | L4 |
| **Service mesh (internal)** | Service-to-service routing | L7 sidecar (Envoy) |

---

## Quick Memory Card

```
WHAT:           LB = middleman that distributes traffic to multiple servers
WHY:            Scale, availability, zero-downtime deploy, geo-routing
REVERSE PROXY:  Sits between client & server; LB IS a reverse proxy (with multiple backends)
HARDWARE LB:    Physical box with ASIC chip; fast but expensive (F5, Citrix)
SOFTWARE LB:    Program on regular server; flexible & cheap (Nginx, HAProxy, Envoy)
CLOUD LB:       Provider-managed software LB (ALB, NLB, GCP LB)
L4:             Sees IP+port only; fast; for TCP/UDP/DB
L7:             Sees HTTP path/headers/cookies; for APIs/microservices/SSL term
ALGORITHMS:     RR (stateless), Least Conn (varying load), IP Hash (affinity),
                Consistent Hash (cache), Weighted RR (unequal servers)
HEALTH:         Active probe (LB checks) vs Passive (LB watches real traffic)
STICKY:         Cookie or IP hash when backend has session state; prefer Redis instead
DNS LB:         DNS returns different IPs; no health checks; first-layer only
GSLB:           Global routing to nearest/healthiest datacenter
```

---

**Next:** [[02_Mental-Model]]
