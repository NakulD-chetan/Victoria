# Design URL Shortener — Common Mistakes

> **Permanent Recall:** Top 10 mistakes: no scale estimation, sequential/predictable IDs, hash without collision handling, no cache, wrong 301/302 choice, ignoring expiry/cleanup, no custom alias validation, no rate limiting, single DB, not separating analytics. Avoid these to ace the URL shortener design interview.

---

## Mistake 1: Not Estimating Scale

**What happens:** You jump to "we'll use a database" without sizing. Interviewer wonders if you can translate business scale to tech.

| Wrong | Right |
|-------|-------|
| "We need a DB" | "100M URLs/day → ~1.2K write QPS, 12K read QPS; Redis for cache, DB for persistence" |
| Vague "high scale" | "5 years retention, ~500B/record → ~100TB storage" |

> **FAANG Tip:** Always do back-of-envelope: QPS, storage, bandwidth. It's the first thing interviewers expect.

---

## Mistake 2: Using Sequential/Predictable IDs

**What happens:** Auto-increment IDs are guessable. `short.io/1`, `short.io/2` → users enumerate, abuse, or discover private links.

| Wrong | Right |
|-------|-------|
| short_url = id (1, 2, 3...) | Base62 encode; 7 chars = 3.5T combinations, unguessable |
| UUID as short code | UUID is 36 chars; too long for "short" URL |

**Fix:** Use base62-encoded counter, hash, or KGS pool. Never expose raw sequence.

---

## Mistake 3: Hash Approach Without Collision Handling

**What happens:** MD5(long_url) → base62 can collide. Two different long URLs → same short code → wrong redirect.

| Wrong | Right |
|-------|-------|
| "Hash is unique" | "Collisions possible; on insert conflict, retry with salt or append random" |
| Ignore collision | Check DB for existing; if collision, rehash with salt |

**Fix:** `short = base62(hash(url)[:43])`; on `INSERT` unique constraint violation, retry with `hash(url + random())`.

---

## Mistake 4: No Cache for Redirect

**What happens:** Every redirect hits DB. At 12K QPS, DB becomes bottleneck. Latency >100ms.

| Wrong | Right |
|-------|-------|
| Redirect → DB only | Redirect → Redis first, DB on cache miss |
| Cache everything | Cache hot URLs (~20% get 80% traffic); enough to absorb reads |

**Fix:** Cache-aside: Redis for `short_url → long_url`. TTL 24h. DB for cold and persistence.

---

## Mistake 5: Wrong 301 vs 302 Choice

**What happens:** 301 = browser caches forever; you never see redirects again → no analytics, can't change destination. 302 = every request hits server → analytics, flexibility.

| Use Case | Choice |
|----------|--------|
| Analytics needed, destination may change | **302** |
| Permanent redirect, reduce server load | **301** |

> **FAANG Tip:** Most shorteners need analytics → 302. State the tradeoff explicitly.

---

## Mistake 6: Not Considering Expiry/Cleanup

**What happens:** Expired URLs stay in DB; cache serves stale; or no TTL support at all.

| Wrong | Right |
|-------|-------|
| All URLs permanent | Schema: `expires_at`; redirect checks it; return 404 if expired |
| No cleanup job | Background job deletes/archives expired URLs periodically |

**Fix:** Store `expires_at`; on lookup, if `now > expires_at` → 404. Batch cleanup for storage reclaim.

---

## Mistake 7: Ignoring Custom Alias Validation

**What happens:** User chooses `short.io/admin` or `short.io/login` → conflict with reserved paths or existing routes.

| Wrong | Right |
|-------|-------|
| Accept any custom alias | Blocklist: reserved words (api, admin, login, shorten) |
| No conflict check | DB unique constraint; return 409 if taken |

**Fix:** Validate against blocklist; check DB for existence; return 409 Conflict if alias taken.

---

## Mistake 8: No Rate Limiting

**What happens:** Single user floods shorten API; creates millions of URLs; DoS or abuse.

| Wrong | Right |
|-------|-------|
| Unlimited shorten | Token bucket: 100/min anonymous, 1000/min authenticated |
| No protection | Redis-based rate limiter; 429 + Retry-After |

**Fix:** Rate limit shorten by IP/user. Redirect less strict (cache absorbs).

---

## Mistake 9: Single Database

**What happens:** DB dies → entire service down. No read replicas → write load blocks reads.

| Wrong | Right |
|-------|-------|
| One DB instance | Primary + read replicas; redirect reads from replica |
| No replication | Replication for HA; failover for primary |

**Fix:** Primary for writes; replicas for redirect reads. Or NoSQL with built-in replication.

---

## Mistake 10: Not Discussing Analytics Separately

**What happens:** You add analytics to the redirect path → latency blows up, DB overload.

| Wrong | Right |
|-------|-------|
| Sync write to DB on each redirect | Async: emit event to Kafka, analytics service consumes |
| Block redirect for analytics | Fire-and-forget or message queue; redirect stays fast |

**Fix:** Async pipeline. Redirect → publish event → analytics worker → data warehouse.

---

## 30-SECOND REVISION BOX

```
1. ESTIMATE: QPS, storage, always
2. PREDICTABLE IDs: Use base62, not 1,2,3
3. HASH COLLISIONS: Retry with salt
4. CACHE: Redis for redirect path
5. 301 vs 302: 302 for analytics
6. EXPIRY: expires_at, 404, cleanup job
7. CUSTOM ALIAS: Blocklist, 409 conflict
8. RATE LIMIT: Token bucket on shorten
9. SINGLE DB: Replicas, failover
10. ANALYTICS: Async, don't block
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
