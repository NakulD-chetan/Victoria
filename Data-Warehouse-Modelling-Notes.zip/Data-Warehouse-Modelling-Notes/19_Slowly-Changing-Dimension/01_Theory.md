# Slowly Changing Dimension (SCD)

> "Slowly changing does not mean unimportant—it means the warehouse must decide which past truths you are allowed to remember."

**Real-world analogy:** SCD policies are like the personnel records at a retail headquarters: some edits simply correct a typo in today’s directory (overwrite), while others must preserve the old job title for legal wage disputes (full history)—the warehouse encodes which kind of story each attribute tells.

---

## Core Idea (2 Lines)

A **slowly changing dimension** is a dimension whose descriptive attributes evolve over time at a pace far slower than fact transactions, requiring explicit warehouse rules for whether history is overwritten, versioned, or partially retained. The dominant retail implementation combines **surrogate keys** with **effective dating** so facts join to the correct dimension version for point-in-time reporting.

---

## What “Slowly + Changing + Dimension” Means

| Word | Meaning in practice |
|------|---------------------|
| Slowly | Changes are episodic (reorgs, rebrands), not every sale line |
| Changing | Attributes are not immutable |
| Dimension | Context table (`dim_customer`, `dim_store`, `dim_product`) |

Contrast with facts: `fact_store_sales` changes constantly; `dim_product` changes when merchandising updates descriptions or categories.

**Interview Tip:** SCD is about **attributes**, not measures—though degenerate dimensions can carry transactional ids that rarely use SCD patterns.

**Watch Out!** Labeling every nightly batch change as “SCD” without attribute-level policy creates inconsistent history.

---

## Customer Dimension Baseline with Surrogate Key

Retail `dim_customer` example (simplified):

```sql
CREATE TABLE dim_customer (
    customer_key      BIGINT      NOT NULL PRIMARY KEY,
    loyalty_card_id   VARCHAR(32) NOT NULL,
    customer_name     VARCHAR(120) NOT NULL,
    home_store_key    INT         NOT NULL,
    effective_date    DATE        NOT NULL,
    end_date          DATE        NULL,
    current_flag      CHAR(1)     NOT NULL
);
```

Facts store `customer_key`, not only `loyalty_card_id`, so Type 2 history remains addressable.

ASCII anchor:

```
fact_store_sales.customer_key ---> dim_customer.customer_key
                                         |
                                         +-- business attrs
                                         +-- effective dating (SCD)
```

---

## SCD Type 0: Retain Original, Never Change

Type 0 **freezes** the attribute forever—useful for audit fields that must never reflect corrections.

| Example column | Policy |
|----------------|--------|
| `original_signup_date` | Never update after first insert |
| `first_store_key_visited` | Immutable milestone |

Retail: loyalty program “date of joining” used for tenure benefits should not shift when data quality fixes reprocess onboarding.

**Interview Tip:** Type 0 is less common in textbooks but appears for legal and promotional lock-in fields.

**Watch Out!** Applying Type 0 too widely prevents legitimate corrections—scope it narrowly.

---

## SCD Type 1: Overwrite

Type 1 **replaces** values in place; **no history** is kept beyond backups.

| Operation | Result |
|-----------|--------|
| Customer corrects email typo | Same `customer_key`, new email |
| Product description cleanup | Same `product_key`, new text |

```sql
UPDATE dim_customer
SET customer_name = 'Jane Q. Shopper'
WHERE customer_key = 501;
```

| Pros | Cons |
|------|------|
| Simple ETL | Past reports “drift” to new values |
| Single row per entity | Cannot answer “what was name on 2022 tax mailer?” |

Retail reporting drift example: district realignment overwrites `district_name` on `dim_store`; last year’s district performance chart suddenly shows new boundaries unless facts snapshot geography separately.

**Watch Out!** Regulatory or finance audits may forbid Type 1 for certain attributes.

---

## SCD Type 2: New Row + Effective Dates + Current Flag

Type 2 **inserts a new dimension row** with a new surrogate when tracked attributes change, closes the prior row with `end_date`, and marks current row.

| customer_key | loyalty_card_id | home_store_key | effective_date | end_date | current_flag |
|--------------|-----------------|----------------|----------------|----------|--------------|
| 501 | CARD-AAA | 120 | 2020-01-01 | 2023-09-30 | N |
| 612 | CARD-AAA | 455 | 2023-10-01 | NULL | Y |

Facts on 2023-08-15 must reference `customer_key = 501` (old home store), while facts after move reference `612`.

**Interview Tip:** Type 2 is the interview favorite—state the trio: new surrogate, `effective_date`/`end_date`, `current_flag`.

**Watch Out!** Overlapping or gap date ranges for the same natural key break point-in-time joins.

---

## ASCII Timeline for Type 2

```
TIME axis ---------------------------------------------------------->

loyalty_card_id = CARD-AAA (same business identity)

customer_key 501 [========attributes A========)
                              \
                               \ close end_date
                                \
customer_key 612               [========attributes B===========> current
                 ^effective_date
```

---

## SCD Type 3: Extra Columns for Limited History

Type 3 keeps **one row** but adds “prior” columns—typically one step of history only.

| customer_key | current_region | previous_region |
|--------------|----------------|-----------------|
| 501 | West | East |

| Pros | Cons |
|------|------|
| Simple row count | Only one historical hop |
| Easy current-state reporting | Awkward for many changes |

Retail rarity: quick marketing split comparing “current vs immediately prior” category placement.

**Watch Out!** Third change overwrites the only preserved prior value unless additional columns are added (degenerates toward wide mess).

---

## Hybrid Types (4–7 Overview)

Textbooks extend SCD beyond 1–3; implementations vary by vendor and team jargon.

| Type | Common meaning | Retail note |
|------|----------------|-------------|
| 4 | History in a separate mini-dimension / outrigger | Frequent profile changes isolated |
| 5 | Type 1 + embedded micro-history | Practical compromise |
| 6 | “Hybrid” combining 1 and 2 techniques | Hotfixes with audit |
| 7 | Specialized patterns (rare naming) | Consult org standards |

**Interview Tip:** If asked beyond 1–3, acknowledge variability and steer to **which business questions** must be answerable.

**Watch Out!** Numeric type labels without written definitions cause team mismatches—document policies per attribute.

---

## Decision Guide Table

| Business question | Likely SCD |
|-------------------|-----------|
| Only latest truth matters | Type 1 |
| Must reconstruct past as-of sale date | Type 2 |
| Immutable legal anchor | Type 0 |
| Compare current vs one previous only | Type 3 |
| Rapidly changing profile cluster | Type 4-style outrigger |

---

## Connection to Surrogate Keys and Point-in-Time Joins

Point-in-time join logic matches facts to the dimension row valid on the fact’s date:

```sql
SELECT
    f.sale_line_key,
    c.customer_name,
    c.home_store_key
FROM fact_store_sales AS f
JOIN dim_customer AS c
  ON f.customer_key = c.customer_key;
```

If facts were wrongly loaded with only `loyalty_card_id`, analysts might join to **current** Type 2 row and misattribute historical store visits.

Alternative temporal join when fact only has business key (discouraged pattern):

```sql
SELECT
    f.sale_line_key,
    c.customer_name
FROM fact_store_sales_business AS f
JOIN dim_customer AS c
  ON f.loyalty_card_id = c.loyalty_card_id
 AND f.sale_date BETWEEN c.effective_date AND COALESCE(c.end_date, '9999-12-31');
```

Retail warehouses usually **resolve surrogate during ETL** to avoid runtime range joins on huge facts.

**Watch Out!** Open-ended `end_date` NULL handling must be consistent (`COALESCE` vs sentinel max date).

---

## Product and Store SCD Examples

| Dimension | Typical Type 2 triggers |
|-----------|-------------------------|
| `dim_product` | Category move, brand change, pack size change |
| `dim_store` | Format change (express → supercenter), closure |
| `dim_promotion` | Rare Type 2 if promotion metadata corrected historically |

---

## ETL Sketch: Type 2 Row Versioning

```
1) Detect changed attributes by comparing natural key hash
2) Close prior row: set end_date = change_date - 1 day, current_flag = 'N'
3) Insert new row: new customer_key, effective_date = change_date, current_flag = 'Y'
4) Route new facts to new surrogate via effective dating lookup
```

**Interview Tip:** Mention late-arriving facts that need **retroactive** Type 2 splits—advanced scenario with careful reprocessing.

---

## Comparison Table of Core SCD Types

| Type | History depth | Row count | Surrogate behavior | Retail risk |
|------|---------------|-----------|--------------------|-------------|
| 0 | None (frozen) | Stable | Same | Wrong attribute frozen incorrectly |
| 1 | None | Stable | Same | Reporting drift |
| 2 | Full | Grows | New per version | Date gaps / overlaps |
| 3 | One prior | Stable | Same | Limited audit |

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Type 1 on attributes finance must audit | Compliance failure | Type 2 or legal snapshot fact |
| Type 2 without current_flag | Harder BI filters | Add `current_flag` or `is_current` |
| Facts store business key only | Wrong historical joins | Resolve surrogate in ETL |
| Overlapping effective ranges | Double joins / duplicates | Constraint + ETL tests |
| Versioning every column | Dimension explosion | Split hot attributes to mini-dim |
| Ignoring store closure dates | Open ghost stores in reports | Close-out dates + status |

---

## Key Takeaway

> SCD is the contract for how retail dimensions evolve: Type 1 for latest truth, Type 2 for faithful history with new surrogates and dates, Type 0 for frozen facts, and Type 3 only when a single prior snapshot suffices—always tie facts to the surrogate that represents the world on the transaction’s day.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) SCD governs dimension attribute change, not measures.        |
| 2) Type 0 = never change (e.g., original signup date).         |
| 3) Type 1 = overwrite; simplest, no history.                   |
| 4) Type 2 = new row + dates + current_flag; interview classic. |
| 5) Type 3 = prior/current columns; one-step history only.      |
| 6) Types 4–7 = hybrids/outriggers; definitions vary by org.    |
| 7) Facts should carry surrogate for correct point-in-time.     |
+------------------------------------------------------------------+
```
