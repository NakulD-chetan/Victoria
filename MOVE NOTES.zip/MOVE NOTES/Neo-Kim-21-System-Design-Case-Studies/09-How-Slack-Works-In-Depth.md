# How Slack Works - In Depth (Easy Language)

> Companion to: [09-How-Slack-Works.md](09-How-Slack-Works.md)

---

## What Makes Slack Different from WhatsApp?

| Aspect | WhatsApp | Slack |
|--------|----------|-------|
| **Target** | Personal messaging (friends, family) | Enterprise teams (work) |
| **Identity** | Phone number | Email + workspace |
| **Groups** | Max ~100 people | Channels up to 10,000 people |
| **History** | Minimal on server | Full history stored forever |
| **Search** | Local device only | Full-text server search |
| **Message Send** | WebSocket | HTTP POST |
| **Message Receive** | WebSocket | WebSocket |

The key architectural difference: **Slack uses HTTP for sending and WebSocket for receiving.** WhatsApp uses WebSocket for both.

---

## Dual API Design - The Clever Split

### Why Two Different Protocols?

**Sending a message** is like mailing a letter:
```
You: "Send this message to #general channel"
Server: "Got it! Here's your receipt (timestamp)"

This is a simple REQUEST → RESPONSE pattern
→ HTTP POST is perfect for this
→ Easy error handling, retries, load balancing
```

**Receiving messages** is like getting a phone notification:
```
You're just sitting there, and BOOM:
  "New message in #general from Alice"
  "Bob is typing in #design..."
  "Charlie joined #engineering"
  
This is a PUSH pattern — server sends data to YOU
→ WebSocket is perfect for this
→ Server pushes instantly without you asking
```

### Why Not Use WebSocket for Both (Like WhatsApp)?

Slack chose HTTP for sends because:
1. **Simpler error handling**: HTTP has built-in status codes (200 OK, 500 Error)
2. **Better load balancing**: HTTP requests can go to any server; WebSocket connections are sticky
3. **Easier debugging**: HTTP requests are stateless, easier to trace and log
4. **Failure isolation**: If WebSocket connection drops, you can still SEND via HTTP

---

## The Workspace Snapshot - Slack's Unique Trick

### What Happens When You Open Slack?

```
Step 1: You log in to Slack
Step 2: Server sends a MASSIVE JSON blob called "workspace snapshot":
  {
    users: [all 500 people in your company],
    channels: [#general, #engineering, #random, ...],
    your_channels: [channels you've joined],
    profiles: [everyone's name, avatar, title],
    memberships: [who's in which channel],
    websocket_url: "wss://slack-rt.com/ws?token=abc123"
  }

Step 3: Your Slack client stores this locally
Step 4: Connects to the WebSocket URL for real-time updates
```

### Why Send Everything at Once?

**Without snapshot (bad):**
```
Client opens → API call 1: "Get my channels" (200ms)
             → API call 2: "Get user list" (200ms)
             → API call 3: "Get channel members" (200ms)
             → API call 4: "Get my preferences" (200ms)
             → API call 5: "Get recent messages" (200ms)
             → Total: 1 second of sequential API calls
```

**With snapshot (good):**
```
Client opens → 1 API call: "Give me everything" (300ms)
             → Total: 300ms
             → Slack appears ready almost instantly!
```

### Lazy Loading

For large workspaces (200,000 users), sending ALL data at once would be too much. So Slack uses **lazy loading**:

```
Immediate (in snapshot):
  → Your channels, recent messages, online teammates
  
Lazy loaded (on demand):
  → Channel you haven't opened in weeks → load when you click it
  → User profile details → load when you hover over their name
  → Old message history → load when you scroll up
```

---

## Message Flow - From Send to Delivery

```
Alice sends "Hello team!" in #general:

SEND PATH (HTTP):
  1. Alice's client: POST /chat/C123456 { text: "Hello team!" }
  2. Gateway receives → routes to Chat Service
  3. Chat Service:
     → Validates message (not too long, not spam)
     → Writes to Kafka message queue
     → Returns 200 OK with timestamp to Alice
  4. Alice sees her message appear (local echo)

DELIVERY PATH (Kafka → WebSocket):
  5. Kafka → Delivery Service
  6. Delivery Service: "Who's in #general?" → queries channel membership
  7. For each online member (e.g., 500 people):
     → Find their WebSocket connection
     → Push: { channel: "#general", user: "Alice", text: "Hello team!" }
  8. Each member's Slack client shows the new message
  
  For offline members:
  9. Queue message + send push notification
```

---

## Channel Fan-Out - The Scaling Challenge

### Why Large Channels Are Hard

```
#general channel with 10,000 members:
  1 message = 10,000 WebSocket pushes
  
  If #general gets 10 messages per minute:
    = 100,000 WebSocket pushes per minute FOR ONE CHANNEL
    
  If 100 active channels each get 10 messages/minute:
    = 10,000,000 WebSocket pushes per minute!
```

### How Slack Handles This

**Optimization 1: Batch delivery**
```
Instead of: push message to user 1, then user 2, then user 3...
Do: push message to users [1, 2, 3, 4, 5] on same server at once
(Group recipients by which WebSocket server they're on)
```

**Optimization 2: Limit typing indicators**
```
Typing indicators ("Alice is typing...") are VERY frequent:
  → Each keystroke triggers an event
  → In a 10,000-person channel, this would be insane
  
Solution: Only send typing indicators in small channels (< ~100 members)
  → Large channels: "Alice is typing..." NOT shown
  → DMs and small groups: typing indicators shown
```

**Optimization 3: Don't notify inactive viewers**
```
Only push to users who are currently VIEWING the channel
  → 10,000 members in #general
  → Only 200 are currently looking at it
  → Push to those 200 only
  → Others get badge count update (much lighter)
```

---

## Sharding by Workspace - Natural Tenant Isolation

### Why Workspace = Shard?

```
Company A (workspace_a): 500 users, 100 channels
Company B (workspace_b): 2000 users, 300 channels
Company C (workspace_c): 50 users, 20 channels

MySQL Shard 1: workspace_a data
MySQL Shard 2: workspace_b data  
MySQL Shard 3: workspace_c data
```

**Why this works perfectly:**
1. **Data isolation**: Company A's messages are NEVER on the same shard as Company B's (security!)
2. **No cross-shard queries**: A user only queries their own workspace
3. **Natural partitioning**: Workspaces are independent by nature
4. **Easy compliance**: Some companies require data in specific regions → put their shard there

---

## Typing Indicators - Transient Events

### How They Work

```
Alice starts typing in #design:
  1. Alice's client: WebSocket → { type: "typing", user: "Alice", channel: "#design" }
  2. Server receives typing event
  3. Server pushes to all users currently VIEWING #design:
     { type: "typing", user: "Alice", channel: "#design" }
  4. Their clients show: "Alice is typing..."
  5. After 5 seconds with no new typing event → indicator disappears
```

**Key points:**
- Typing indicators are **NOT stored in the database** (they're transient, ephemeral)
- They only go to users **currently viewing** that channel
- They have a **TTL** (time-to-live): disappear after a few seconds
- In large channels, they're **suppressed** entirely (too expensive to fan out)

---

## Presence Service - Separate for a Reason

### Why a Separate Service?

```
If presence was part of the Chat Service:
  Chat Service crashes → you can't see who's online AND can't send messages
  Two features fail at once!

With separate Presence Service:
  Chat Service crashes → messages stop, BUT you can still see who's online
  Presence Service crashes → online/offline broken, BUT messages still work
  
  = Failure isolation!
```

### How Presence Works

```
Bob opens Slack:
  → Heartbeat: "I'm online" (every few seconds)
  → Presence Service: marks Bob online
  → Publishes to Bob's teammates: "Bob is now online"

Bob goes idle (no mouse/keyboard for 5 min):
  → Client sends: "I'm away"
  → Presence Service: marks Bob as "away" (yellow dot)

Bob closes Slack:
  → No heartbeat
  → After timeout: mark Bob as "offline" (gray dot)
```

---

## Search - How Slack Finds Messages from 3 Years Ago

```
Message flow for search:
  1. Alice sends message → Kafka → Chat Service → MySQL
  2. SAME message also flows: Kafka → Search Indexer → Elasticsearch
  3. Indexing is ASYNC (slight delay, but search is eventually up-to-date)

When Bob searches "project deadline":
  1. Query → Elasticsearch
  2. Elasticsearch returns matching message IDs
  3. Full message content fetched from MySQL
  4. Results returned with context (channel, user, timestamp)
```

**Why Elasticsearch?**
- Full-text search (finds "deadline" even in "The project deadline is Friday")
- Handles complex queries ("project" AND "deadline" in #engineering)
- Fast even across millions of messages
- Supports fuzzy matching (finds "dealdine" when you typo)

---

## Slack vs WhatsApp - Architecture Comparison

| Aspect | Slack | WhatsApp |
|--------|-------|----------|
| **Send messages** | HTTP POST (request-response) | WebSocket (persistent) |
| **Receive messages** | WebSocket (push) | WebSocket (push) |
| **Initial load** | Workspace snapshot (big JSON blob) | No snapshot needed |
| **Primary DB** | MySQL (sharded by workspace) | Cassandra (NoSQL) |
| **Search** | Server-side Elasticsearch | Client-side only |
| **Sharding** | By workspace (enterprise isolation) | By conversation/user |
| **Max group** | 10,000 in a channel | ~100 in a group |
| **Message storage** | Permanent (full history) | Minimal on server |
| **Typing indicators** | Suppressed in large channels | Always shown |

---

## Revision Flashcards

**Q: Why does Slack use HTTP for sending but WebSocket for receiving?**
A: Sending is request-response (fits HTTP naturally with error codes and load balancing). Receiving needs server-push (WebSocket is efficient for this). This separation also provides failure isolation.

**Q: What is the workspace snapshot?**
A: A large JSON blob sent on login containing users, channels, memberships, and a WebSocket URL. It avoids multiple sequential API calls and makes Slack appear ready almost instantly. Large workspaces use lazy loading.

**Q: Why does Slack shard by workspace?**
A: Natural tenant isolation (companies can't see each other's data), no cross-shard queries needed, easy regional compliance, and simple partitioning since workspaces are independent.

**Q: Why are typing indicators not stored in the database?**
A: They're transient events with a short TTL. Storing billions of "Alice is typing" events would waste storage for data nobody needs later. They're fire-and-forget.

**Q: How does Slack handle 10,000-member channel fan-out?**
A: Batch delivery (group by server), suppress typing indicators in large channels, only push to active viewers, and badge-count updates for inactive users.
