const CANDIDATE_DELIMITERS = [',', '\t', ';', '|'];

function countDelimiter(line, delimiter) {
  let count = 0;
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') i += 1;
      else quoted = !quoted;
    } else if (!quoted && char === delimiter) {
      count += 1;
    }
  }
  return count;
}

export function detectDelimiter(source) {
  const lines = String(source || '').split(/\r?\n/).filter((line) => line.trim()).slice(0, 5);
  if (!lines.length) return ',';

  let best = ',';
  let bestScore = -1;
  for (const delimiter of CANDIDATE_DELIMITERS) {
    const counts = lines.map((line) => countDelimiter(line, delimiter));
    const positive = counts.filter((count) => count > 0);
    if (!positive.length) continue;
    const consistency = positive.every((count) => count === positive[0]) ? 5 : 0;
    const score = positive.reduce((sum, count) => sum + count, 0) + consistency;
    if (score > bestScore) {
      best = delimiter;
      bestScore = score;
    }
  }
  return best;
}

export function parseCSV(source, requestedDelimiter = 'auto', options = {}) {
  const text = String(source || '');
  const delimiter = requestedDelimiter === 'auto'
    ? detectDelimiter(text)
    : requestedDelimiter;
  const maxRows = options.maxRows || 10000;
  const maxColumns = options.maxColumns || 200;
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;

  const pushField = () => {
    row.push(field);
    field = '';
    if (row.length > maxColumns) throw new Error(`CSV exceeds ${maxColumns} columns`);
  };

  const pushRow = () => {
    pushField();
    rows.push(row);
    row = [];
    if (rows.length > maxRows) throw new Error(`CSV exceeds ${maxRows} rows`);
  };

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        field += char;
      }
      continue;
    }

    if (char === '"') {
      quoted = true;
    } else if (char === delimiter) {
      pushField();
    } else if (char === '\n') {
      pushRow();
    } else if (char !== '\r') {
      field += char;
    }
  }

  if (quoted) throw new Error('CSV has an unclosed quoted field');
  if (field.length || row.length || !text.endsWith('\n')) pushRow();
  if (rows.length === 1 && rows[0].length === 1 && rows[0][0] === '') rows.length = 0;

  return { delimiter, rows };
}
