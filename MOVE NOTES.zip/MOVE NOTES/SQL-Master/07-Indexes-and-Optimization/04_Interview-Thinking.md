# Indexes and Optimization — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is an Index?
**A:** A separate data structure (usually B-tree) that speeds up data retrieval. Like a book's index — instead of scanning every page, jump directly to the relevant page.

### Q: What is a Clustered Index?
**A:** Index where data rows are physically sorted by the index key. Only ONE per table. Usually on PK. Leaf nodes = actual data rows.

### Q: What is a Non-Clustered Index?
**A:** Separate B-tree structure with pointers to actual data rows. Multiple allowed per table. Leaf nodes = pointers/row locators.

### Q: Can you have two Clustered Indexes on one table?
**A:** No. Only one — data can only be physically sorted one way. But you can have multiple non-clustered indexes.

### Q: What is a Composite Index?
**A:** Index on multiple columns `(A, B, C)`. Follows leftmost prefix rule — can serve queries on A, (A,B), (A,B,C) but NOT B alone or C alone.

### Q: What is the Leftmost Prefix Rule?
**A:** For composite index (A,B,C): the index can help with WHERE A=?, WHERE A=? AND B=?, WHERE A=? AND B=? AND C=?. But NOT WHERE B=? (skips leftmost column A).

### Q: What is a Covering Index?
**A:** An index that contains ALL columns needed by a query. DB can answer entirely from index without accessing table data (index-only scan). Fastest possible read.

### Q: When should you NOT create an index?
**A:** Small tables (full scan is fast), low-selectivity columns (boolean/gender), write-heavy tables (INSERT/UPDATE/DELETE slow down), columns rarely used in WHERE/JOIN.

### Q: What is a View?
**A:** Virtual table defined by a stored SQL query. Does NOT store data. Re-executes underlying query every time. Used for abstraction, security, simplifying complex queries.

### Q: What is a Materialized View?
**A:** A view that stores results physically on disk (precomputed snapshot). Must be refreshed to stay current. Fast reads but stale data between refreshes.

### Q: View vs Materialized View?
**A:** View = virtual, always current, no storage, re-executes every time. Materialized View = physical, fast reads, uses storage, stale until refreshed. Use MV for dashboards/reports; View for abstraction/security.

### Q: Materialized View — Pros?
**A:** Fast reads (precomputed), can be indexed, reduces load on base tables, great for reporting dashboards.

### Q: Materialized View — Cons?
**A:** Stale data (needs refresh), storage cost, refresh can be expensive, not real-time.

### Q: What is a Stored Procedure?
**A:** Precompiled collection of SQL statements stored in DB. Called with CALL/EXEC. Can have parameters, variables, control flow (IF/ELSE, loops).

### Q: Stored Procedure vs Function?
**A:** SP: called with CALL, can do DML, can return multiple result sets, can't be used in SELECT. Function: returns single value/table, can be used in SELECT/WHERE, usually can't do DML.

### Q: What is a Trigger?
**A:** Special procedure that auto-fires on INSERT/UPDATE/DELETE on a table. Types: BEFORE, AFTER, INSTEAD OF. Used for auditing, enforcing rules, cascading changes.

### Q: Why avoid Triggers?
**A:** Hidden logic (hard to debug), performance impact (fires on every row), can cause cascading loops, makes system harder to understand and maintain.

### Q: What is a Cursor?
**A:** Row-by-row processing of a result set. Slow and resource-heavy. Anti-pattern — almost always replaceable with set-based SQL. Use only for truly complex row-level logic.

### Q: What is EXPLAIN?
**A:** Shows the query execution plan — how the DB will execute your query. Reveals: access method (seq scan vs index scan), join type, estimated rows, sort operations. `EXPLAIN ANALYZE` shows actual execution time.

### Q: How to optimize a slow query?
**A:** 1) Run EXPLAIN to identify bottleneck. 2) Add index on WHERE/JOIN columns. 3) Avoid SELECT *. 4) Check for missing indexes. 5) Avoid functions on indexed columns. 6) Consider materialized views for complex aggregations.

### Q: What is Table Partitioning?
**A:** Splitting a large table into smaller physical pieces (partitions) while appearing as one logical table. Types: Range (dates), List (categories), Hash (even distribution). Faster queries on partition key.

### Q: OLTP vs OLAP?
**A:** OLTP = day-to-day transactions (normalized, many writes). OLAP = analytics/reporting (denormalized, complex reads). Different workloads need different schema designs and optimization strategies.

### Q: What is a Full-Text Index?
**A:** Specialized index for searching text content (words, phrases). Supports word matching, stemming, ranking. MySQL: FULLTEXT INDEX. Postgres: tsvector + GIN index.

### Q: What is Query Optimization?
**A:** Process of choosing the most efficient execution plan for a query. DB optimizer considers indexes, table sizes, statistics, join order. We help by creating proper indexes, writing efficient queries, updating statistics.

---

## Follow-up traps

- "Can you have two clustered indexes?" → **No**, one per table (data can only be sorted one way).
- "View vs materialized view?" → View = alias for query (no storage); materialized = precomputed snapshot (needs refresh).
- "When is a full table scan better than index?" → Small tables, low selectivity, or when fetching most rows (> 10-20% of table).

---

*Next: [[05_Common-Mistakes]]*
