# SQL Tab & Physical Plans — Problem List

> **18 plan-reading tasks.** For each: open SQL tab, find the listed evidence in the operator tree.

---

## 10 MUST-DO Tasks

| # | Task                                                                         | Where to Look                            | Concept                       |
|---|------------------------------------------------------------------------------|-------------------------------------------|-------------------------------|
| 1 | Identify Scan operator and verify column pruning                              | Bottom of plan, `ReadSchema`              | Source scan                   |
| 2 | Verify predicate pushdown happened                                            | `Scan` operator → `PushedFilters` line    | Predicate pushdown            |
| 3 | Find an `Exchange` operator and read its data size                            | Mid-plan                                   | Shuffle inspection            |
| 4 | Identify whether a join is BroadcastHashJoin or SortMergeJoin                 | Join operator name                         | Join strategy                 |
| 5 | Spot a `WholeStageCodegen` group                                              | Boxed area in the tree                     | Tungsten fusion               |
| 6 | Detect AQE applied                                                            | `AQEShuffleRead` operators                 | AQE                           |
| 7 | Find a `ReusedExchange` proving shuffle reuse                                  | Subtree under join/agg                     | Shuffle reuse                 |
| 8 | Confirm cache is being used                                                    | `InMemoryTableScan` operator              | Cache hit                     |
| 9 | Read partial vs final HashAggregate                                            | Tree levels                                | Two-step aggregation          |
|10 | Identify CollectLimit (the executeTake operator)                              | Top of plan in show queries                | executeTake confirmation      |

---

## Complete 18-Task Progression

### Easy (1–6) — Operator Spotting

| # | Task                                                                  | Code Snippet to Run                                       | Expected Operator                |
|---|-----------------------------------------------------------------------|-----------------------------------------------------------|----------------------------------|
| 1 | Find the source Scan in `df.select("a","b").filter("a>0").count()`     | `df.select(...).filter(...).count()`                       | `Scan parquet`                   |
| 2 | Confirm `Filter` shows `PushedFilters`                                 | Same                                                      | Pushed filter list               |
| 3 | Spot `Project` for column pruning                                      | `df.select("a")`                                           | `Project` with `[a]`             |
| 4 | Find `Exchange hashpartitioning(...)`                                  | `df.groupBy("k").count()`                                  | `Exchange hashpartitioning(k,P)`|
| 5 | Find `singlePartition` exchange in count                               | `df.count()`                                               | `Exchange singlePartition`       |
| 6 | Find `BroadcastExchange` when broadcast                                | `df.join(broadcast(small),"k")`                            | `BroadcastExchange`              |

### Medium (7–12) — Mixed Operators

| # | Task                                                                    | Code Snippet                                                | Expected                          |
|---|-------------------------------------------------------------------------|-------------------------------------------------------------|-----------------------------------|
| 7 | Identify HashAggregate (partial) + (final) pair                          | `df.groupBy("k").sum("v").count()`                           | Two HashAggregate nodes           |
| 8 | Find `SortMergeJoin` for big-big join                                    | `df1.join(df2, "k").count()`                                 | `SortMergeJoin`                   |
| 9 | Distinguish `Sort` operator vs `OrderBy`                                  | `df.orderBy("v").count()`                                    | `Sort + Exchange rangepartitioning`|
|10 | Spot `LocalLimit` and `GlobalLimit` for `df.limit(n)`                    | `df.limit(5).collect()`                                      | LocalLimit then GlobalLimit       |
|11 | Find AQE coalesce annotation                                              | `df.groupBy("k").count().collect()` AQE on, small data       | `AQEShuffleRead [coalesced]`      |
|12 | Identify `InMemoryTableScan` after cache                                  | `df.cache(); df.count(); df.count()`                         | `InMemoryTableScan(df)`           |

### Hard (13–18) — Optimization Detection

| # | Task                                                                      | Code Snippet                                                 | Expected                                          |
|---|---------------------------------------------------------------------------|--------------------------------------------------------------|---------------------------------------------------|
|13 | Verify codegen disabled drops WholeStageCodegen boxes                     | `spark.conf.set("spark.sql.codegen.wholeStage", "false")`    | No `WholeStageCodegen (n)` boxes                  |
|14 | Detect skew handling in AQE                                               | join with skewed key + AQE skewJoin enabled                   | `AQEShuffleRead [skewed]`                         |
|15 | Force broadcast via hint                                                   | `df.join(broadcast(big), "k")` (forced)                       | `BroadcastHashJoin` despite size                  |
|16 | Identify `ReusedExchange` after running same join twice                   | `df1.join(df2, "k").count()` then `.show()`                  | `ReusedExchange`                                  |
|17 | Find UDF inhibiting WholeStageCodegen                                      | `.withColumn("y", py_udf(col("x")))`                          | UDF op outside any codegen box                    |
|18 | Spot `Window` operator and verify `Sort + Exchange` partner                | `df.withColumn("rn", row_number().over(w)).count()`           | `Window + Sort + Exchange`                        |

---

## Strategy Notes

### Task 2 — Predicate Pushdown Verification

```
Scan parquet
  PushedFilters: [GreaterThan(value, 100)]    <-- presence = pushdown OK
  ReadSchema: struct<value:int,...>
```

> If `PushedFilters: []` while you wrote a filter, pushdown failed. Common reasons:
> - Filter uses a UDF
> - Filter uses non-deterministic functions (`rand()`)
> - File format doesn't support pushdown (e.g. plain text)

### Task 4 — Join Strategy Detection

```
SCENARIO                        SQL TAB SHOWS
small df + broadcast hint       BroadcastHashJoin + BroadcastExchange
both big, equi-join              SortMergeJoin + 2 Exchange (hash) + 2 Sort
both big, hash join             ShuffledHashJoin + 2 Exchange (hash)
non-equi join                   BroadcastNestedLoopJoin or CartesianProduct
```

### Task 7 — Two-Stage Aggregation

```
HashAggregate(final, sum(value))
+- Exchange singlePartition          <-- shuffle to one partition
   +- HashAggregate(partial, sum(value))   <-- partial agg per partition
      +- Project ...
```
> The "two-step" pattern is what makes aggregation fast: each partition computes a partial result; only those partials shuffle.

### Task 11 — AQE Coalesce

```
Without AQE:
  Exchange hashpartitioning(k, 200)
  -> 200 post-shuffle tasks, even for small data

With AQE:
  AQEShuffleRead [coalesced, 200 -> 8]
  -> 8 post-shuffle tasks; AQE merged tiny partitions
```

### Task 14 — AQE Skew Handling

```
Without skew handling:
  SortMergeJoin
  +-- Exchange ... (k)
       <-- one partition has 80% of rows; one task takes 25 s

With skewJoin enabled:
  AQEShuffleRead [skewed, partition i split into 5]
  -> skew partition split into multiple tasks
```

### Task 17 — Why Python UDF Hurts

```
Plan with Python UDF:
   PythonUDF [py_udf]                   <-- not codegen-friendly
      <-- breaks WholeStageCodegen group; rows serialize Python <-> JVM
```

> Replace with native function or pandas_udf (Arrow-based) for huge speedup.

---

## Operator Cheat Card

```
SCAN ............................. read source
  Scan parquet/csv/orc/json
  Scan ExistingRDD                  (createDataFrame parallelize)
  InMemoryTableScan                 (cache hit)

PROJECTION & FILTER .............. narrow ops
  Project
  Filter
  WholeStageCodegen (n)             <-- fused block

AGGREGATION ......................
  HashAggregate(partial)
  HashAggregate(final)
  ObjectHashAggregate
  SortAggregate

JOIN .............................
  BroadcastHashJoin                  (small side broadcast, fastest)
  ShuffledHashJoin                   (medium)
  SortMergeJoin                      (default for big-big)
  BroadcastNestedLoopJoin / Cartesian (avoid)

SHUFFLE ..........................
  Exchange hashpartitioning(...)     (groupBy / join)
  Exchange rangepartitioning(...)    (orderBy)
  Exchange singlePartition           (final reduce)
  BroadcastExchange                  (broadcast send)
  ReusedExchange                     (shuffle reuse)
  AQEShuffleRead [coalesced/skewed]  (AQE rewriting)

LIMIT / SORT .....................
  LocalLimit                         (per-partition)
  GlobalLimit                         (final)
  CollectLimit                        (executeTake)
  Sort

WINDOW ...........................
  Window                              (with Sort + Exchange children)
```

---

## Cross-Reference

| Topic                                            | Pattern |
|--------------------------------------------------|---------|
| Why Exchange creates a stage boundary            | 04      |
| What ReusedExchange means in jobs tab            | 05      |
| Why BroadcastHashJoin doesn't add a stage        | 04      |
| AQE-induced extra jobs                            | 02      |
| executeTake's CollectLimit operator              | 03      |

---

## Study Plan

### Day 1 — Tabs & Operators
- Tasks 1–6.
- Make sure you can identify Scan / Filter / Project / Exchange.

### Day 2 — Joins
- Tasks 4, 8, 15, 16.
- Build small + big df; toggle broadcast threshold; observe operator change.

### Day 3 — Aggregation Patterns
- Tasks 7, 11, 12.
- Compare with AQE on/off.

### Day 4 — Performance Detective
- Tasks 13, 14, 17.
- Add a Python UDF; see how plan visibly degrades.

---

## Final Revision Box

```
SQL TAB           -> physical plan tree with row counts + time
READ ORDER        -> bottom-up = data flow
EXCHANGE           -> shuffle = stage boundary
BROADCAST          -> small side; no shuffle for that side
WHOLESTAGECODEGEN  -> good; fused operators
PUSHEDFILTERS      -> non-empty = predicate pushdown working
INMEMORYTABLESCAN  -> cache hit confirmed
REUSEDEXCHANGE     -> shuffle output reuse
AQESHUFFLEREAD     -> AQE rewrote the post-shuffle stage
COLLECTLIMIT       -> executeTake (the show / take operator)
RULE              -> "If a plan node has no metrics, it didn't run.
                       If it has rows: 0, it produced nothing."
```
