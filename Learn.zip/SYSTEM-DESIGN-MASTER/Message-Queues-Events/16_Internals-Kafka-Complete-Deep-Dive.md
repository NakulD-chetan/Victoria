# Internals: Kafka Complete Deep Dive — End-to-End Low-Level Architecture

> **Permanent Recall:** Kafka is a **distributed append-only log** built for **sequential disk I/O**, **replication-based durability**, **batched network protocol**, and **consumer-controlled replay**. Producer sends batches to the partition leader. Leader appends to the log, followers fetch and replicate, high watermark advances, producer gets ack, and consumers fetch by offset. Kafka's speed comes from **batching + page cache + zero-copy + sequential writes**. Kafka's safety comes from **ISR + leader election + high watermark + idempotent / transactional protocol**.

---

## Why This File Exists

Kafka is usually explained in fragments:

- producer
- broker
- storage
- replication
- consumer groups

But at low level, all of these are one connected machine.

This file gives you a **single complete view**:

- what Kafka is
- how a message travels through it
- what data structures it uses
- what algorithms it relies on
- how it stays fast
- how it stays fault tolerant
- how exactly-once works
- what breaks under failure

If you can explain this file well, you can explain Kafka at system design and internals level.

---

## 1. The Core Mental Model

Kafka is **not primarily a queue**.

Kafka is best understood as:

- a distributed log
- split into partitions
- with one leader per partition
- many followers replicating that partition
- producers appending data
- consumers reading by offset

```text
Topic: orders

Partition 0: [0][1][2][3][4]...
Partition 1: [0][1][2][3][4]...
Partition 2: [0][1][2][3][4]...

Each partition is:
- ordered
- append-only
- replicated
```

The most important consequences are:

- ordering is per partition, not global
- consumers control their own read position
- messages are usually retained after consumption
- replay is built in

---

## 2. Full Kafka Architecture

```text
                        ┌─────────────────────────────────────┐
                        │              PRODUCERS              │
                        │  serialize -> partition -> batch    │
                        └────────────────┬────────────────────┘
                                         │
                                         ▼
                     ┌─────────────────────────────────────────────┐
                     │            KAFKA CLUSTER                    │
                     │                                             │
                     │  Broker 1        Broker 2        Broker 3   │
                     │  ┌──────────┐    ┌──────────┐    ┌──────────┐
                     │  │P0 leader │    │P1 leader │    │P2 leader │
                     │  │P1 follwr │    │P2 follwr │    │P0 follwr │
                     │  │P2 follwr │    │P0 follwr │    │P1 follwr │
                     │  └──────────┘    └──────────┘    └──────────┘
                     │                                             │
                     │  Metadata quorum (KRaft / controller)       │
                     └────────────────┬────────────────────────────┘
                                      │
                                      ▼
                        ┌─────────────────────────────────────┐
                        │             CONSUMERS               │
                        │ fetch by offset, commit progress    │
                        └─────────────────────────────────────┘
```

Kafka architecture has 4 major planes:

| Plane | Responsibility |
|---|---|
| **Data plane** | Produce, fetch, replication |
| **Storage plane** | Log segments, indexes, page cache |
| **Control plane** | Leader election, metadata, ISR |
| **Consumer plane** | Group membership, assignment, offset commit |

---

## 3. End-to-End Write Path

Here is the full lifecycle of one produced message.

```text
Application -> Producer API -> Serializer -> Partitioner -> Batch
           -> TCP -> Broker network thread -> request queue
           -> IO thread -> partition append -> page cache
           -> replication to followers -> HW advance -> ack
```

### Step-by-step

1. Application calls `producer.send(record)`.
2. Producer serializes key and value.
3. Partitioner chooses partition.
4. Record is appended to `RecordAccumulator`.
5. Sender thread drains ready batches.
6. Produce request goes over TCP to the leader broker.
7. Broker network thread parses request.
8. IO thread validates and appends to partition log.
9. Leader assigns offsets.
10. Followers fetch the new data.
11. Once ISR has replicated enough, high watermark advances.
12. Broker sends produce response.

This path is the heart of Kafka.

---

## 4. Producer Internals

Kafka producer is built around **batching**.

### Internal pipeline

```text
send()
  -> serialize
  -> partition
  -> append to RecordAccumulator
  -> Sender thread drains batches
  -> build ProduceRequest
  -> network send
```

### Core producer components

| Component | Job |
|---|---|
| **Serializer** | Converts objects to bytes |
| **Partitioner** | Chooses target partition |
| **RecordAccumulator** | Buffers batches in memory |
| **BufferPool** | Reuses memory for batches |
| **Sender thread** | Sends ready batches to brokers |
| **NetworkClient** | Manages TCP connections and responses |

### Important producer algorithms

#### 1. Murmur2 partitioning

For keyed records:

```text
partition = murmur2(keyBytes) % numPartitions
```

Why:

- fast non-cryptographic hash
- good enough distribution
- same key always maps to same partition

This is how Kafka gives **per-key ordering**.

#### 2. Sticky partitioner

For unkeyed records:

- old behavior was round-robin
- new behavior sticks to one partition until batch is full

Why it exists:

- bigger batches
- better compression
- fewer requests

#### 3. Batch trigger logic

A batch is sent when:

- `batch.size` is reached
- `linger.ms` expires
- producer is forced to flush

This is a throughput vs latency trade-off.

---

## 5. Kafka Wire Protocol

Kafka uses its own binary protocol over TCP.

### Request structure

```text
[size][api_key][api_version][correlation_id][client_id][body]
```

### Important API keys

| API | Purpose |
|---|---|
| `Produce` | Send records |
| `Fetch` | Read records |
| `Metadata` | Discover leaders and partitions |
| `FindCoordinator` | Locate group coordinator |
| `JoinGroup` | Group membership |
| `SyncGroup` | Assignment |
| `Heartbeat` | Liveness |
| `OffsetCommit` | Save progress |
| `InitProducerId` | Idempotent / transactional producer |

### Why binary protocol matters

- smaller than text protocols
- faster parsing
- easier multiplexing over one TCP connection
- correlation IDs allow out-of-order responses

---

## 6. Serialization and Record Format

Kafka itself transports bytes. The application chooses the schema format.

### Common formats

| Format | Best For | Trade-Off |
|---|---|---|
| **JSON** | Human readability | Large and slow |
| **Avro** | Kafka ecosystem + schema evolution | Needs schema registry |
| **Protobuf** | Cross-language services | Slightly more rigid than Avro for some data workflows |

### Kafka on-disk / on-wire record batching

Kafka stores messages inside **Record Batches**, not as isolated tiny records.

Main batch fields:

- `baseOffset`
- `batchLength`
- `crc`
- `attributes`
- `firstTimestamp`
- `producerId`
- `baseSequence`
- compressed record payload

### Important algorithms here

#### 1. Varint encoding

Small integers use fewer bytes.

Why Kafka uses it:

- saves space for offsets, lengths, timestamp deltas
- reduces network and disk overhead

#### 2. CRC-32C

Every batch carries a CRC checksum.

Why:

- detects corruption in transit or storage

---

## 7. Network Path: From Producer to Broker

A Kafka message does not jump magically from app to broker.

```text
Userspace -> syscall -> kernel socket buffer -> TCP stack
         -> IP -> NIC DMA -> wire
         -> destination NIC -> kernel -> epoll wakeup
         -> broker read -> request parsing
```

### Low-level OS pieces involved

| Layer | What Happens |
|---|---|
| **Userspace** | Producer prepares request bytes |
| **Kernel socket layer** | Copies bytes into send buffers |
| **TCP** | Segmentation, retransmission, ordering |
| **NIC** | DMA and wire transmission |
| **epoll** | Wakes broker thread when socket is readable |

### Important algorithms / mechanisms

#### 1. TCP congestion control

Usually CUBIC or BBR depending on system tuning.

Why it matters:

- controls in-flight data
- impacts throughput on long links

#### 2. epoll readiness model

`epoll` internally uses:

- red-black tree for tracked FDs
- ready list for active FDs

Why it matters:

- Kafka can manage thousands of connections efficiently

#### 3. NAPI and interrupt coalescing

Linux batches packet handling instead of interrupting CPU for every packet.

Why:

- lowers per-packet overhead
- increases throughput

---

## 8. Broker Threading Model

Kafka brokers separate network handling from storage handling.

```text
Acceptor thread
  -> Processor threads (network / epoll)
  -> Shared request queue
  -> IO threads
  -> Purgatory for delayed ops
```

### Core broker components

| Component | Responsibility |
|---|---|
| **Acceptor** | Accept new TCP connections |
| **Processor thread** | Read requests and write responses |
| **Request queue** | Buffer between network and IO |
| **IO thread** | Execute produce/fetch/metadata work |
| **Purgatory** | Hold delayed produce/fetch operations |

### Important algorithm

#### Hierarchical timing wheel

Kafka uses a timing wheel in purgatory.

Why:

- efficient timeout management for huge numbers of delayed operations
- much cheaper than large priority queues for timeout-heavy workloads

Used for:

- `acks=all` produce waiting
- long-poll fetch waiting

---

## 9. Storage Engine: Why Kafka Is Fast on Disk

Kafka's most misunderstood property:

Kafka is fast **because it writes sequentially to disk**, not because it avoids disk.

### Partition storage layout

Each partition is a directory of segment files:

```text
orders-0/
  00000000000000000000.log
  00000000000000000000.index
  00000000000000000000.timeindex
  00000000000005242880.log
  ...
```

### Segment model

| File | Purpose |
|---|---|
| `.log` | Actual record batches |
| `.index` | Sparse offset-to-position index |
| `.timeindex` | Timestamp-to-offset index |

Only one segment is active and writable.  
Older segments are immutable.

### Important algorithms and data structures

#### 1. Append-only log

Why it matters:

- no random update
- pure sequential write path
- excellent disk behavior

#### 2. Sparse index + binary search + linear scan

Kafka does **not** index every record.

Lookup algorithm:

1. binary search the sparse `.index`
2. jump near the right byte position
3. scan forward a small amount

Why:

- much smaller index files
- fast enough in practice

#### 3. `mmap` for indexes

Kafka memory-maps index files.

Why:

- near-memory-speed lookups after page fault
- no syscall per read
- kernel manages cache

#### 4. `sendfile()` zero-copy

For consumer fetches:

- broker uses `sendfile()` / `transferTo()`
- data moves from page cache to NIC without userspace copy

Why:

- less CPU
- fewer copies
- better throughput

#### 5. Page cache

Kafka relies heavily on OS page cache.

Why:

- just-written records are still hot in memory
- caught-up consumers often read from RAM, not disk
- JVM heap stays small, reducing GC pain

---

## 10. How Reads Work

Consumer fetch is fundamentally:

```text
Fetch(offset X)
  -> find segment
  -> use sparse index
  -> seek near location
  -> scan to exact offset
  -> return record batch
```

### Read path details

1. Broker identifies the correct segment using base offsets.
2. `.index` is binary searched.
3. Broker jumps into `.log`.
4. Record batches are scanned until target offset.
5. Data is sent using `sendfile()` when possible.

### Why Kafka read path is efficient

- sequential access patterns
- OS read-ahead
- sparse indexes stay small
- zero-copy avoids heap copying

---

## 11. Compression

Kafka compresses **batches**, not individual records.

### Why batch compression is powerful

- similar records share repeated structure
- better compression ratio
- broker stores compressed bytes as-is
- less network + less disk + less IO

### Common codecs

| Codec | Strength |
|---|---|
| **LZ4** | Fast |
| **ZSTD** | Strong ratio with good speed |
| **Snappy** | Older but still common |
| **Gzip** | High ratio but CPU heavy |

### Important algorithm family

- LZ-based dictionary/match finding
- Huffman / FSE in stronger codecs like ZSTD

---

## 12. Replication Model

Each partition has:

- one leader
- zero or more followers

Producers and consumers talk to the **leader**.  
Followers pull data from the leader using the same fetch protocol.

```text
Leader append
  -> followers fetch
  -> followers append
  -> leader updates replicated state
  -> high watermark moves
```

### Important low-level concepts

| Term | Meaning |
|---|---|
| **LEO** | Log End Offset, the next offset to be written |
| **HW** | High Watermark, highest offset replicated on all ISR |
| **ISR** | In-Sync Replicas |

### Core safety rule

Consumers read only up to **HW**, not up to leader LEO.

That is how Kafka hides uncommitted tail data from consumers.

---

## 13. ISR and Durability

ISR is central to Kafka fault tolerance.

### How replicas enter or leave ISR

A follower stays in ISR if it keeps fetching in time.  
If it stops fetching for too long, it is removed.

Kafka now uses **time-based lag**, not raw offset lag.

Why:

- burst traffic can increase offset lag without meaning the follower is dead
- time lag better captures real failure or stall

### Important durability rule

`acks=all` means:

- leader waits until all ISR replicas have the message
- only then does producer receive success

This is Kafka's practical durability contract.

---

## 14. Leader Election and Fault Tolerance

When a leader fails:

1. controller detects failure
2. chooses new leader from ISR
3. informs all replicas
4. followers switch to new leader

### Why picking from ISR matters

Only ISR replicas are safe candidates because they are caught up enough to preserve committed data.

### Important failure mechanism

#### Log truncation

After leader change, some followers may have extra uncommitted tail records.

Kafka uses:

- leader epoch checkpoints
- `OffsetsForLeaderEpoch`

to find the correct truncation point.

Why:

- prevents divergence
- ensures all replicas converge to leader history

---

## 15. Unclean Leader Election

This is the classic availability vs safety trade-off.

### If unclean election is disabled

- partition goes offline when no ISR leader candidate exists
- safer, but temporarily unavailable

### If unclean election is enabled

- Kafka may pick an out-of-sync replica as leader
- data loss becomes possible

For critical systems:

- keep unclean leader election disabled

---

## 16. KRaft and Metadata Consensus

Modern Kafka no longer depends on ZooKeeper.

KRaft uses **Raft consensus** for cluster metadata.

### What KRaft manages

- broker registration
- topic creation
- partition assignment
- ISR changes
- leader changes
- ACL and cluster metadata

### Important algorithm: Raft

Raft gives:

- leader election
- replicated metadata log
- majority commit

Why it matters:

- consistent metadata
- simpler operations than ZooKeeper
- faster controller failover

---

## 17. `acks=0`, `acks=1`, `acks=all`

This is one of the most important operational choices in Kafka.

| Mode | Meaning | Risk |
|---|---|---|
| `acks=0` | producer does not wait | silent loss possible |
| `acks=1` | wait for leader append only | leader may die before replication |
| `acks=all` | wait for ISR replication | highest safety, higher latency |

### Important related setting

`min.insync.replicas`

Why it matters:

- prevents Kafka from acknowledging data that is stored on too few replicas

---

## 18. Exactly-Once Semantics

Kafka exactly-once is not one feature. It is a stack of mechanisms.

### Pillar 1: Idempotent producer

Producer gets:

- `producerId`
- `producerEpoch`
- sequence numbers

Broker deduplicates repeated retries.

Important algorithm:

- per `(producerId, partition)` sequence tracking

### Pillar 2: Transactions

Producer can atomically write to multiple partitions.

Coordinator tracks transaction state in `__transaction_state`.

### Pillar 3: Read committed

Consumers with `read_committed` avoid seeing aborted transactional data.

### Important caveat

Exactly-once in Kafka is:

- real
- useful
- complex

It is not the default design answer for every business workflow.

---

## 19. Consumer Groups

Kafka scales consumption using consumer groups.

### Core rule

Within one group:

- one partition is actively consumed by one consumer

### Group flow

1. consumer finds coordinator
2. joins group
3. group leader computes assignment
4. sync group
5. heartbeat continuously
6. commit offsets as progress changes

### Important algorithms and mechanisms

#### 1. Coordinator hashing

Group coordinator is determined by hashing `group.id` into `__consumer_offsets`.

#### 2. Assignment strategies

- range
- round robin
- sticky
- cooperative sticky

#### 3. Heartbeat protocol

Detects dead consumers.

#### 4. Rebalance protocol

Redistributes partitions after membership change.

---

## 20. Rebalancing

Rebalancing is a major source of pause and duplicate risk.

### Eager rebalance

- everyone stops
- partitions revoked
- assignment recomputed
- everyone resumes

Problem:

- stop-the-world pause

### Cooperative rebalance

- only partitions that must move are revoked
- less disruption

### Static membership

If instance identity is stable, restarts do not always trigger full rebalance.

---

## 21. Offset Management

Consumers control progress using offsets.

Important distinction:

- **record position** is in the partition log
- **committed progress** is stored in `__consumer_offsets`

### Commit strategies

| Strategy | Trade-Off |
|---|---|
| **Auto commit** | simple but less control |
| **Manual sync commit** | safer, blocking |
| **Manual async commit** | faster, more care needed |

### Important design rule

If you want at-least-once:

- process first
- commit after success

---

## 22. Fault Tolerance Summary

Kafka fault tolerance is not one mechanism. It is a stack:

| Layer | Fault-Tolerance Mechanism |
|---|---|
| **Storage** | append-only log, immutable segments |
| **Replication** | leader + followers |
| **Commit safety** | high watermark |
| **Membership** | ISR tracking |
| **Election** | controller + ISR-based leadership |
| **Metadata** | Raft in KRaft |
| **Producer safety** | idempotence + transactions |
| **Consumer recovery** | committed offsets |

### What failures Kafka handles well

- single broker crash
- consumer crash
- producer retry
- follower lag
- leader failure with healthy ISR

### What still hurts

- badly configured ISR / replication
- unclean leader election
- schema incompatibility
- overloaded consumers causing lag
- multi-node catastrophic failure

---

## 23. Operating-System Primitives Kafka Depends On

Kafka performance depends heavily on Linux behavior.

### Key OS primitives

| Primitive | Why Kafka Uses It |
|---|---|
| **Page cache** | cache hot log data |
| **mmap** | fast index lookups |
| **sendfile** | zero-copy fetch path |
| **epoll** | scalable network readiness |
| **fallocate** | contiguous segment allocation |
| **fsync / fdatasync** | optional forced durability |

### Why Kafka avoids some alternatives

- does not keep main data in JVM heap
- does not use direct I/O because it would break the page-cache + sendfile model
- does not fsync every message because replication gives a better latency/safety trade

---

## 24. Important Algorithms and Data Structures Used by Kafka

This is the low-level list most people miss.

| Algorithm / Structure | Where Kafka Uses It | Why |
|---|---|---|
| **Murmur2 hash** | partitioner | stable per-key mapping |
| **Sticky partitioner** | unkeyed producer flow | fuller batches |
| **Varint encoding** | record format | smaller integers |
| **CRC-32C** | record batch integrity | corruption detection |
| **Sparse index** | `.index` files | low memory overhead |
| **Binary search** | offset lookup in index | fast seek |
| **Linear scan after index hit** | final record lookup | cheap local scan |
| **LRU-like page cache policies** | kernel file caching | hot data stays in RAM |
| **Hierarchical timing wheel** | purgatory timeouts | efficient delayed operations |
| **Raft** | KRaft metadata consensus | correct leader election + metadata log |
| **Sequence-number dedup** | idempotent producer | retry safety |
| **Red-black tree + ready list** | epoll internals | scalable socket readiness |

---

## 25. One Complete Message Walkthrough

Let us trace one record:

```text
OrderCreated(order123)
```

### Producer side

1. App creates record.
2. Serializer turns it into bytes.
3. Key `order123` is hashed with Murmur2.
4. Partitioner picks partition 3.
5. Record enters batch for topic-partition `orders-3`.
6. Batch gets compressed with LZ4.
7. Sender thread builds ProduceRequest.
8. Request is written to TCP socket.

### Broker leader side

9. Network thread wakes via epoll.
10. Request is parsed.
11. IO thread validates topic, ACL, sizes, producer state.
12. Leader assigns new offsets.
13. Batch is appended to active `.log` segment.
14. Indexes are updated.
15. Data lands in page cache.

### Replication side

16. Followers fetch from the leader.
17. Followers append to their own logs.
18. Leader sees ISR has caught up.
19. High watermark advances.

### Ack side

20. If `acks=all`, producer gets success only now.

### Consumer side

21. Consumer fetches from its last offset.
22. Broker finds segment and lookup position.
23. Broker serves bytes, often through zero-copy.
24. Consumer deserializes record.
25. Business logic runs.
26. Offset is committed after success.

That is Kafka end-to-end.

---

## 26. What Makes Kafka Fast

Kafka performance comes from the combination of:

1. append-only disk writes
2. batch compression
3. producer batching
4. page cache
5. sparse indexes
6. zero-copy fetch
7. long-lived TCP connections
8. efficient broker threading model

Kafka is fast because it minimizes:

- random IO
- per-message syscalls
- userspace copies
- heap pressure

---

## 27. What Makes Kafka Fault Tolerant

Kafka reliability comes from:

1. replicated partitions
2. ISR membership rules
3. high watermark commit boundary
4. safe leader election
5. follower truncation on divergence
6. producer idempotence
7. transactions for multi-partition atomicity
8. committed offsets for consumer recovery

Kafka is safe because it separates:

- appended tail
- committed tail

That distinction is the key.

---

## 28. Common Misunderstandings

| Misunderstanding | Correct View |
|---|---|
| Kafka is just a queue | Kafka is a distributed log |
| Kafka is fast because it is in memory | Kafka is fast because of sequential IO + page cache + zero-copy |
| Kafka preserves global order | Order is only within a partition |
| `acks=1` is fully safe | leader can crash before follower replication |
| Exactly-once is easy | it is multi-layer and non-trivial |
| Consumer offset equals latest record | offset is consumer progress, not topic end |
| Replay is free | replay can stress downstream systems |

---

## 29. What Interviewers Usually Want To Hear

If asked "how Kafka works internally", cover these in order:

1. distributed log, not queue
2. topic -> partition -> leader/follower
3. producer batching and partitioning
4. append-only segments and sparse indexes
5. page cache and zero-copy
6. followers fetch, ISR, HW
7. leader election and KRaft
8. consumer groups, offsets, rebalances
9. idempotence / transactions if asked about exactly-once

That answer shape is usually ideal.

---

## 30-SECOND REVISION BOX

```text
KAFKA = distributed append-only log
TOPIC -> PARTITIONS -> leader + followers
PRODUCER = serialize -> partition -> batch -> send
PARTITIONER = murmur2(key) % N, sticky for unkeyed
STORAGE = .log + sparse .index + .timeindex
LOOKUP = binary search index -> linear scan in log
SPEED = sequential IO + page cache + compression + zero-copy
REPLICATION = followers fetch from leader
SAFETY = ISR + HW + leader election + truncation on divergence
ACKS = 0, 1, all
EOS = idempotent producer + transactions + read_committed
CONSUMERS = group coordinator -> JoinGroup -> SyncGroup -> Heartbeat -> commit
ORDER = per partition only
KRAFT = Raft for metadata consensus
```

---

**Prev: [[15_Internals-OS-Kernel-Interactions]]**
