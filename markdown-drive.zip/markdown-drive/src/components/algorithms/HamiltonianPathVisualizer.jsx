import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: hamiltonian-path */
const GRAPH = {
  nodes: [
    { id: 'A', x: 140, y: 200, label: 'A' },
    { id: 'B', x: 300, y: 120, label: 'B' },
    { id: 'C', x: 460, y: 200, label: 'C' },
    { id: 'D', x: 300, y: 280, label: 'D' },
  ],
  edges: [
    { from: 'A', to: 'B', directed: false },
    { from: 'B', to: 'C', directed: false },
    { from: 'C', to: 'D', directed: false },
    { from: 'D', to: 'A', directed: false },
    { from: 'A', to: 'C', directed: false },
  ],
};

const ADJ = {
  A: ['B', 'D', 'C'],
  B: ['A', 'C'],
  C: ['B', 'D', 'A'],
  D: ['C', 'A'],
};

function pairKey(u, v) {
  return u < v ? `${u}-${v}` : `${v}-${u}`;
}

function generateSteps() {
  const steps = [];
  const target = ['A', 'B', 'C', 'D'];
  const path = [];
  function bt() {
    if (path.length === target.length) {
      steps.push({
        type: 'success',
        nodeColors: Object.fromEntries(path.map((id) => [id, 'visited'])),
        edgeColors: {},
        path: [...path],
      });
      return true;
    }
    const last = path.length ? path[path.length - 1] : null;
    const candidates = last == null ? ['A'] : ADJ[last].filter((x) => !path.includes(x));
    for (const v of candidates) {
      steps.push({
        type: 'try',
        nodeColors: Object.fromEntries(path.map((id) => [id, 'processing']).concat([[v, 'current']])),
        edgeColors: last ? { [pairKey(last, v)]: 'highlight' } : {},
        path: [...path, v],
      });
      path.push(v);
      if (bt()) return true;
      path.pop();
      steps.push({
        type: 'backtrack',
        nodeColors: Object.fromEntries(path.map((id) => [id, 'processing'])),
        edgeColors: {},
        path: [...path],
      });
    }
    return false;
  }
  bt();
  steps.push({ type: 'done', nodeColors: {}, edgeColors: {} });
  return steps;
}

export default function HamiltonianPathVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Hamiltonian path via backtracking (4 nodes)' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: {},
      queue: [],
      stack: step.path || [],
      distances: {},
      visited: step.path || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
