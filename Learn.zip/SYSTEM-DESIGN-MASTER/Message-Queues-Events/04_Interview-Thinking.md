# Message Queues and Events — Interview Thinking

> **Permanent Recall:** In interviews, do not introduce messaging just because it sounds advanced. Introduce it when you need **async processing**, **decoupling**, **fan-out**, **buffering**, or **replay**. Then immediately cover **delivery**, **ordering**, **retries**, **DLQ**, and **idempotency**.

---

## What The Interviewer Is Testing

When messaging appears in a system design interview, the interviewer is usually checking whether you understand:

- when async is actually useful
- how to reduce coupling between services
- how to handle spikes and backlog
- how to think about duplicates and retries
- how to choose Kafka vs RabbitMQ vs SQS/SNS
- how to talk about eventual consistency without sounding vague

---

## When To Introduce Messaging

Use messaging when the problem naturally includes one of these triggers:

| Trigger | Good Interview Direction |
|---|---|
| Slow downstream processing | Queue for async handling |
| Traffic spikes | Queue as a buffer |
| Multiple services react to one event | Pub/sub |
| Need replay or audit trail | Kafka |
| Multi-service workflow | Saga |
| Event-driven system | Topic/event bus |

Do **not** force messaging into a design that really needs a direct synchronous response.

---

## The Strong 20-Second Explanation

If asked why you want a queue, a clean answer is:

"I want to decouple the producer from the consumer, avoid blocking the caller, absorb spikes with a durable buffer, and let workers process at their own pace."

If asked why pub/sub, say:

"One event should trigger many independent downstream actions, so a topic is a better fit than a single queue."

---

## How To Explain Async Correctly

A strong explanation has 3 parts:

1. What becomes asynchronous
2. Why waiting is unnecessary
3. What trade-off you accept

### Example

"Order placement returns immediately after persisting the order and publishing `order.created`. Inventory, billing, and notifications process asynchronously. That reduces latency for the user, but the system becomes eventually consistent."

That is much stronger than just saying "we use Kafka."

---

## Delivery Guarantees: What To Say

| Interview Question | Strong Default Answer |
|---|---|
| What if the message is lost? | Use durable broker storage and at-least-once delivery |
| What if the consumer crashes? | Redeliver after timeout / missing ack |
| What if processing happens twice? | Make consumer idempotent |
| What about exactly-once? | Possible in limited systems like Kafka, but complex |

### Best default line

"I would use at-least-once delivery and make the consumer idempotent. That is simpler and more realistic than claiming end-to-end exactly-once."

---

## Ordering: The Follow-Up Many People Miss

If the interviewer mentions payments, orders, carts, rides, or account updates, check whether ordering matters.

What to say:

- if ordering does not matter, keep partitions wide for throughput
- if ordering matters per entity, partition by entity ID
- if they ask for global order, explain the throughput trade-off

### Strong line

"I only enforce ordering where the business actually needs it, usually per entity like `order_id`, not globally."

---

## Idempotency: Your Safety Net

The interviewer wants to know whether retries will break the business.

Use one of these answers:

- store a processed `message_id`
- do `UPSERT` by natural key such as `order_id`
- make state transitions idempotent

### Strong line

"Because retries can cause duplicates, I would make consumers idempotent using either a message ID table or natural-key upserts."

---

## How To Talk About Kafka

Good reasons to choose Kafka:

- replay matters
- many consumer groups need the same data
- throughput is high
- event history is valuable

Weak reason:

- "Kafka is modern"

Strong line:

"I would choose Kafka because this looks like an event stream rather than just a task queue. We need replay, retention, and independent consumer groups."

---

## How To Talk About RabbitMQ

Good reasons to choose RabbitMQ:

- rich routing is needed
- this is a task queue problem
- replay is not the main requirement
- exchange and binding model fits well

Strong line:

"I would choose RabbitMQ because the main need is broker-side routing and worker delivery, not long-term replay."

---

## How To Talk About SQS and SNS

Good reasons:

- AWS-native environment
- low operational overhead
- relatively standard async requirements

Strong line:

"If we are already fully in AWS and do not need Kafka-style replay, SNS plus SQS gives simpler managed fan-out."

---

## If The Interviewer Asks: "What If The Queue Goes Down?"

This is a classic reliability follow-up.

Answer in this order:

1. Broker replication / HA
2. Producer retry behavior
3. Consumer resume behavior
4. Backlog catch-up plan

### Strong answer

"I would run the broker in a replicated setup. Producers retry on transient failures. Consumers resume from the last acknowledged point or committed offset. After recovery, I would watch lag and scale consumers if the backlog is large."

---

## If The Interviewer Asks: "Why Not Just Use the Database?"

Strong answer:

"A database table can work at low scale, but it adds polling overhead, increases DB load, and gives poor backpressure behavior. Message brokers are designed for delivery, retries, fan-out, and consumer scaling."

---

## If The Interviewer Brings Up CQRS or Event Sourcing

Always lead with the **why**, not the buzzword.

### CQRS

"I would use CQRS because the read path is much heavier than the write path, and the read queries need a denormalized model."

### Event Sourcing

"I would use event sourcing if the event history itself is valuable for audit, replay, or rebuilding projections."

Then add the warning:

- more complexity
- eventual consistency
- schema evolution concerns

---

## Red Flags That Hurt Interview Answers

| Weak Answer | Better Answer |
|---|---|
| "We'll use Kafka for everything" | Match the broker to the problem |
| "Exactly-once solves duplicates" | Prefer at-least-once plus idempotency unless justified |
| "Ordering is guaranteed" | Clarify the scope of ordering |
| "We can retry forever" | Cap retries and use a DLQ |
| "Queue failure means message loss" | Discuss replication, persistence, and recovery |

---

## A Strong Messaging Answer Skeleton

Use this spoken structure:

1. "This part can be asynchronous."
2. "I would use queue/pub-sub because..."
3. "I would choose Kafka/RabbitMQ/SQS because..."
4. "Delivery will be at-least-once."
5. "Consumers will be idempotent."
6. "If ordering matters, I will partition by entity key."
7. "Retries go through bounded backoff, then DLQ."
8. "I will monitor lag, retry depth, and throughput."

---

## 30-SECOND REVISION BOX

```text
INTRODUCE MQ WHEN: async, decoupling, fan-out, buffering, replay
DEFAULT DELIVERY ANSWER: at-least-once + idempotent consumer
ORDERING ANSWER: only where needed, usually per entity key
KAFKA ANSWER: replay, throughput, consumer groups
RABBITMQ ANSWER: routing-heavy task queue
SQS/SNS ANSWER: AWS-managed simplicity
QUEUE DOWN ANSWER: HA, retries, resume, catch-up
ALWAYS MENTION: retry policy, DLQ, idempotency, monitoring
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
