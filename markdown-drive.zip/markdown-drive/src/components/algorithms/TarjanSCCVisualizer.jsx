import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: tarjan-scc */
const GRAPH = {
  nodes: [
    { id: '0', x: 120, y: 200, label: '0' },
    { id: '1', x: 260, y: 120, label: '1' },
    { id: '2', x: 400, y: 120, label: '2' },
    { id: '3', x: 260, y: 280, label: '3' },
    { id: '4', x: 400, y: 280, label: '4' },
    { id: '5', x: 540, y: 200, label: '5' },
  ],
  edges: [
    { from: '0', to: '1', directed: true },
    { from: '1', to: '2', directed: true },
    { from: '2', to: '0', directed: true },
    { from: '2', to: '3', directed: true },
    { from: '3', to: '4', directed: true },
    { from: '4', to: '5', directed: true },
    { from: '5', to: '3', directed: true },
  ],
};

function generateSteps() {
  const adj = {};
  GRAPH.nodes.forEach((n) => { adj[n.id] = []; });
  GRAPH.edges.forEach((e) => { adj[e.from].push(e.to); });
  const steps = [];
  let time = 0;
  const disc = {};
  const low = {};
  const stack = [];
  const onStack = {};
  const sccs = [];

  function strongConnect(v) {
    disc[v] = low[v] = time += 1;
    stack.push(v);
    onStack[v] = true;
    steps.push({
      type: 'visit',
      v,
      nodeColors: { [v]: 'current' },
      edgeColors: {},
      nodeLabels: { [v]: `d=${disc[v]} l=${low[v]}` },
      stack: [...stack],
    });
    for (const w of adj[v]) {
      steps.push({ type: 'edge', v, w, nodeColors: { [v]: 'processing', [w]: 'processing' }, edgeColors: { [`${v}-${w}`]: 'highlight' }, stack: [...stack] });
      if (disc[w] == null) {
        strongConnect(w);
        low[v] = Math.min(low[v], low[w]);
      } else if (onStack[w]) {
        low[v] = Math.min(low[v], disc[w]);
      }
      steps.push({
        type: 'lowlink',
        v,
        nodeColors: { [v]: 'processing' },
        edgeColors: {},
        nodeLabels: { [v]: `d=${disc[v]} l=${low[v]}` },
        stack: [...stack],
      });
    }
    if (low[v] === disc[v]) {
      const comp = [];
      let w;
      do {
        w = stack.pop();
        onStack[w] = false;
        comp.push(w);
      } while (w !== v);
      sccs.push(comp);
      steps.push({
        type: 'scc',
        nodeColors: Object.fromEntries(comp.map((id) => [id, 'visited'])),
        edgeColors: {},
        stack: [...stack],
        comp,
      });
    }
  }
  GRAPH.nodes.forEach((n) => {
    if (disc[n.id] == null) strongConnect(n.id);
  });
  steps.push({ type: 'done', nodeColors: Object.fromEntries(GRAPH.nodes.map((n) => [n.id, 'visited'])), edgeColors: {} });
  return steps;
}

export default function TarjanSCCVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Tarjan strongly connected components' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: {},
      edgeColors: {},
      nodeLabels: {},
      queue: [],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    const labels = { ...(step.nodeLabels || {}) };
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: labels,
      queue: [],
      stack: step.stack || [],
      distances: {},
      visited: step.comp || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
