# Common Mistakes by Hindi Speakers

> *"Galti sabse pehchano, phir fix karo. Agar galti pata hi nahi toh sudhaarogey kaise?"*

Hindi aur English ki structure alag hai. Isliye Hindi speakers kuch specific galtiyan baar-baar karte hain. Yeh chapter mein 40+ common mistakes hain — Wrong vs Right format mein, with explanation.

---

## 1. Direct Translation Errors (Hindi → English)

Hindi se seedha English mein translate karne se yeh galtiyan hoti hain:

| # | Wrong (Galat) | Right (Sahi) | Hindi Wala Logic | Fix |
|---|--------------|-------------|------------------|-----|
| 1 | I **am having** a car. | I **have** a car. | "Mere paas car **hai**" → "having" laga diya | "have" = possession, "having" = currently eating/experiencing |
| 2 | He **is** my cousin **brother**. | He is my **cousin**. | Hindi mein "cousin brother" bolte hain | English mein sirf "cousin" bolte hain |
| 3 | I **am** 25 years **old**. *(correct!)* But: What is your **good** name? | What is your **name**? | "Aapka shubh naam?" | English mein "good name" nahi kehte |
| 4 | She **told** me **that** come here. | She **told** me **to** come here. | "Usne mujhe kaha ki yahan aao" | told + person + to + verb |
| 5 | I **didn't went**. | I **didn't go**. | V2 laga diya didn't ke baad | did/didn't ke baad V1 aata hai |
| 6 | He **don't** know. | He **doesn't** know. | Hindi mein "nahi" universal hai | He/She/It → does/doesn't |
| 7 | I will **come** office tomorrow. | I will **come to** office tomorrow. / I will **go to** office. | "Kal office aaunga" | English mein "come to" ya "go to" lagta hai |
| 8 | Open the **lights**. | **Turn on** the lights. | "Light kholo" | English mein lights "turn on/off" hoti hain, "open/close" nahi |
| 9 | I want to **take** an admission. | I want to **get** admission. | "Admission lena hai" | English mein "get admission" ya "apply for admission" |
| 10 | She is **more taller** than me. | She is **taller** than me. | Hindi mein "zyada lambi" | -er ya more, dono nahi — sirf ek |

---

## 2. Article Mistakes (A / An / The)

| # | Wrong | Right | Rule |
|---|-------|-------|------|
| 1 | I am **engineer**. | I am **an** engineer. | Profession ke pehle a/an lagta hai |
| 2 | He is **honest** man. | He is **an** honest man. | "H" silent hai → vowel sound → "an" |
| 3 | I went to **the** India. | I went to **India**. | Country ke pehle "the" nahi (usually) |
| 4 | **The** water is important for life. | **Water** is important for life. | General statement mein "the" nahi |
| 5 | I bought **a** apple. | I bought **an** apple. | Vowel sound (a,e,i,o,u) → "an" |
| 6 | He is **a** MBA student. | He is **an** MBA student. | "M" ki sound "em" hai → vowel sound |
| 7 | I read **the** Times of India. *(correct!)* | ✓ Already correct | Newspaper ke pehle "the" lagta hai |

---

## 3. Preposition Mistakes

| # | Wrong | Right | Rule |
|---|-------|-------|------|
| 1 | I am good **in** English. | I am good **at** English. | good **at** + skill |
| 2 | I am married **with** her. | I am married **to** her. | married **to** someone |
| 3 | I am angry **on** him. | I am angry **with** him. | angry **with** a person |
| 4 | He is **in** the bus stop. | He is **at** the bus stop. | specific point → **at** |
| 5 | I reached **at** home. | I reached **home**. | "home" ke pehle preposition nahi |
| 6 | I discussed **about** the plan. | I **discussed** the plan. | "discuss" ke saath "about" nahi lagta |
| 7 | He **explained me** the problem. | He **explained** the problem **to me**. | explain something **to** someone |
| 8 | I go **to** home. | I go **home**. | "home" adverb ki tarah kaam karta hai |
| 9 | She is afraid **from** dogs. | She is afraid **of** dogs. | afraid **of** something |
| 10 | I will come **on** Monday. *(correct!)* | ✓ Already correct | Days ke liye "on" sahi hai |

---

## 4. Tense Mistakes

| # | Wrong | Right | Rule |
|---|-------|-------|------|
| 1 | I **am go** to office. | I **go** to office. / I **am going** to office. | Simple ya continuous — mix mat karo |
| 2 | She **have** a book. | She **has** a book. | He/She/It → has |
| 3 | I **have went** there. | I **have gone** there. | have/has ke baad V3 (gone, not went) |
| 4 | Yesterday I **have eaten** pizza. | Yesterday I **ate** pizza. | "Yesterday" = past simple, not present perfect |
| 5 | I **am knowing** the answer. | I **know** the answer. | Stative verbs continuous mein nahi aate |
| 6 | She **can sings** well. | She **can sing** well. | Modal ke baad V1, no s/es |
| 7 | He **don't has** a car. | He **doesn't have** a car. | doesn't ke baad V1 (have) |
| 8 | I **will going** tomorrow. | I **will go** tomorrow. | will ke baad V1 |
| 9 | When I **will reach**, I will call you. | When I **reach**, I will call you. | Time clause (when/after/before) mein "will" nahi lagta |
| 10 | I **am working** here **since** 2020. | I **have been working** here since 2020. | since/for → Perfect Continuous tense |

---

## 5. Vocabulary Confusion

| # | Wrong | Right | Explanation |
|---|-------|-------|-------------|
| 1 | I **passed out** from college. | I **graduated** from college. | "Passed out" = behosh hona! |
| 2 | He **expired** last year. | He **passed away** last year. | "Expired" products ke liye hai, logon ke liye "passed away" |
| 3 | I need to **prepone** the meeting. | I need to **move up** / **reschedule** the meeting. | "Prepone" English word nahi hai (Indian English mein use hota hai lekin globally nahi) |
| 4 | Please **revert** back to me. | Please **reply** to me. / Please **get back** to me. | "Revert" = purani haalat mein jaana, "reply" = jawab dena |
| 5 | What is your **native place**? | Where are you **from**? / What is your **hometown**? | "Native place" Indian English hai |
| 6 | He is my **co-brother**. | He is my **brother-in-law**. | "Co-brother" English word nahi hai |
| 7 | I have a **doubt**. | I have a **question**. | "Doubt" = shak, "question" = sawal |
| 8 | **Kindly** do the needful. | **Please** take care of this. / **Please** handle this. | "Do the needful" outdated British English hai |
| 9 | I'll **take** your **leave**. | I'll **take** my leave. | "Your leave" nahi — "my leave" (main ja raha hoon) |
| 10 | He is a **backbencher**. | He sits in the **back row**. / He is an **underperformer**. | "Backbencher" specifically Indian English hai |

---

## 6. Sentence Structure Mistakes

| # | Wrong | Right | Rule |
|---|-------|-------|------|
| 1 | **Yesterday I didn't went** office. | **Yesterday I didn't go** to office. | didn't ke baad V1 + "to" missing |
| 2 | **He told to me**. | **He told me.** | tell + person (no "to") |
| 3 | I **enjoy to play** cricket. | I **enjoy playing** cricket. | enjoy/avoid/finish + V-ing |
| 4 | I **am agree** with you. | I **agree** with you. | "agree" already verb hai — "am" nahi lagta |
| 5 | **It is raining since morning**. | **It has been raining since morning.** | since → Present Perfect Continuous |
| 6 | **One of my friend** is coming. | **One of my friends** is coming. | "one of" ke baad plural noun |
| 7 | **He suggested me to go.** | **He suggested that I go.** | suggest + that + subject + V1 |
| 8 | **I am having headache.** | **I have a headache.** | "have" (not "having") for conditions |

---

## 7. Pronunciation-Related Mistakes in Writing

| What People Write | What They Mean | Correct |
|------------------|---------------|---------|
| **loose** my phone | kho dena | **lose** my phone |
| **quite** vs **quiet** | bilkul vs shant | quite = bilkul, quiet = shant |
| **their**, **there**, **they're** | unka, wahan, woh hain | Context pe depend karta hai |
| **your** vs **you're** | tumhara vs tum ho | your = possessive, you're = you are |
| **then** vs **than** | phir vs se (comparison) | I went, **then** slept. / He is taller **than** me. |
| **accept** vs **except** | accept karna vs chhod ke | I **accept** the offer. / Everyone **except** him. |
| **advice** vs **advise** | salaah (noun) vs salaah dena (verb) | His **advice** was good. / I **advise** you to study. |

---

## 8. Quick Fix Cheat Sheet

| Rule | Remember This |
|------|--------------|
| didn't/doesn't + **V1** | didn't **go**, doesn't **like** (NEVER V2) |
| have/has + **V3** | have **gone**, has **eaten** (NEVER V2) |
| Modal + **V1** | can **speak**, will **go** (NEVER V-ing or V2) |
| Stative verbs = **No -ing** | know, like, want, have (ownership) |
| since = **point**, for = **duration** | since 2020, for 5 years |
| discuss = **no "about"** | discuss the plan (NOT discuss about) |
| marry/married **to** (not with) | married **to** her |
| good **at** (not in) | good **at** English |
| one of + **plural noun** | one of my **friends** |
| enjoy/avoid/finish + **V-ing** | enjoy **playing** (NOT enjoy to play) |

---

## 9. Self-Correction Practice

Neeche galat sentences hain. Sahi karo (answer neeche hai):

1. I didn't went to market yesterday.
2. She have two brothers.
3. He is more smarter than me.
4. I am knowing this.
5. She told to me that come here.
6. I discussed about the project.
7. He don't like coffee.
8. I will coming tomorrow.
9. I am agree with you.
10. One of my friend is absent.

### Answers:

1. I **didn't go** to the market yesterday.
2. She **has** two brothers.
3. He is **smarter** than me.
4. I **know** this.
5. She **told me to** come here.
6. I **discussed** the project.
7. He **doesn't** like coffee.
8. I **will come** tomorrow.
9. I **agree** with you.
10. One of my **friends** is absent.

---

*Agle chapter mein: Resources and Tools — best YouTube channels, apps, podcasts, books, aur AI tools*
