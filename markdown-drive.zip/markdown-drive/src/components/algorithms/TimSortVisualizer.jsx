import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const RUN_SIZE = 4;

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  for (let start = 0; start < n; start += RUN_SIZE) {
    const end = Math.min(start + RUN_SIZE - 1, n - 1);
    steps.push({ type: 'run-start', lo: start, hi: end, array: [...a] });
    for (let i = start + 1; i <= end; i++) {
      const key = a[i]; let j = i - 1;
      while (j >= start && a[j] > key) {
        steps.push({ type: 'compare', i, j, array: [...a] });
        a[j + 1] = a[j]; j--;
      }
      a[j + 1] = key;
    }
    steps.push({ type: 'run-sorted', lo: start, hi: end, array: [...a] });
  }
  for (let size = RUN_SIZE; size < n; size *= 2) {
    for (let lo = 0; lo < n; lo += size * 2) {
      const mid = Math.min(lo + size - 1, n - 1);
      const hi = Math.min(lo + size * 2 - 1, n - 1);
      if (mid >= hi) continue;
      const left = a.slice(lo, mid + 1), right = a.slice(mid + 1, hi + 1);
      let i = 0, j = 0, k = lo;
      while (i < left.length && j < right.length) {
        steps.push({ type: 'merge-compare', lo, hi, array: [...a] });
        if (left[i] <= right[j]) a[k++] = left[i++]; else a[k++] = right[j++];
      }
      while (i < left.length) a[k++] = left[i++];
      while (j < right.length) a[k++] = right[j++];
      steps.push({ type: 'merge-done', lo, hi, array: [...a] });
    }
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 20) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function TimSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements (tim sort, run=${RUN_SIZE})` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'run-start') {
      for (let k = step.lo; k <= step.hi; k++) colors[k] = 'active';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Run [${step.lo}..${step.hi}]` });
    } else if (step.type === 'compare' || step.type === 'merge-compare') {
      if (step.i !== undefined) colors[step.i] = 'compare';
      if (step.j !== undefined) colors[step.j] = 'compare';
      store.incComparisons();
    } else if (step.type === 'run-sorted') {
      for (let k = step.lo; k <= step.hi; k++) colors[k] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Run [${step.lo}..${step.hi}] sorted` });
    } else if (step.type === 'merge-done') {
      for (let k = step.lo; k <= step.hi; k++) colors[k] = 'merge';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Merged [${step.lo}..${step.hi}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
