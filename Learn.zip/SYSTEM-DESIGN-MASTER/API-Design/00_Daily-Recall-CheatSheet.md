# API Design — Daily Recall Cheat Sheet

> Read this every morning. 5 minutes. That's it.

---

## 1. Three API Types — When to Use What

```
REST     → Public API, simple CRUD, caching important
GraphQL  → Mobile app, different screens need different data
gRPC     → Internal services talking to each other, fast binary
```

**Easy way to remember:**

- REST = Restaurant menu (fixed dishes, you pick one)
- GraphQL = Custom order (tell chef exactly what you want)
- gRPC = Kitchen phone (chefs talk in short codes, fast)

---

## 2. REST Rules (Most Asked)

```
URL  = NOUN (resource)     →  /users, /orders, /products
HTTP = VERB (action)       →  GET, POST, PUT, PATCH, DELETE
```


| Do This             | NOT This              |
| ------------------- | --------------------- |
| `GET /users/123`    | `GET /getUser/123`    |
| `POST /orders`      | `POST /createOrder`   |
| `DELETE /users/123` | `GET /deleteUser/123` |


**Rules:** Plural nouns. No verbs in URL. Hierarchical: `/users/123/orders`

---

## 3. HTTP Status Codes (Memorize These)


| Code    | Meaning           | When                        |
| ------- | ----------------- | --------------------------- |
| **200** | OK                | GET, PUT, PATCH success     |
| **201** | Created           | POST success                |
| **204** | No Content        | DELETE success              |
| **400** | Bad Request       | Validation fail             |
| **401** | Unauthorized      | No login / bad token        |
| **403** | Forbidden         | Logged in but no permission |
| **404** | Not Found         | Resource doesn't exist      |
| **429** | Too Many Requests | Rate limited                |
| **500** | Server Error      | Something broke             |
| **503** | Unavailable       | Overloaded / maintenance    |


**Trick:** 401 = "Who are you?" | 403 = "I know you, but NO."

---

## 4. REST vs GraphQL vs gRPC


|               | REST        | GraphQL         | gRPC              |
| ------------- | ----------- | --------------- | ----------------- |
| **Format**    | JSON        | JSON            | Protobuf (binary) |
| **Transport** | HTTP/1.1    | HTTP            | HTTP/2            |
| **Best for**  | Public APIs | Mobile/flexible | Internal services |
| **Caching**   | Easy (HTTP) | Hard            | Custom            |
| **Browser**   | Yes         | Yes             | Needs gRPC-Web    |


---

## 5. Versioning (Always Version From Day 1)

```
URL path:    /v1/users     ← Most common, visible, simple
Header:      Accept-Version: 2     ← Clean URLs
Query:       /users?version=2      ← Quick but messy
```

**Interview line:** "I'd version via URL — `/v1/users` — simple and visible."

---

## 6. Pagination (Never Return All Data)


| Type       | Example                  | When                   |
| ---------- | ------------------------ | ---------------------- |
| **Offset** | `?page=2&limit=20`       | Small data, simple     |
| **Cursor** | `?cursor=abc&limit=20`   | Large data, scalable   |
| **Keyset** | `?after_id=123&limit=20` | Sorted data, efficient |


**Interview line:** "Cursor-based for scale. Offset breaks at large page numbers."

---

## 7. Rate Limiting (Protect Your API)


| Algorithm          | Easy Explanation                                                         |
| ------------------ | ------------------------------------------------------------------------ |
| **Token Bucket**   | You get 10 coins/sec. Each request costs 1 coin. No coins = rejected.    |
| **Leaky Bucket**   | Requests go in a queue. Processed at fixed speed. Queue full = rejected. |
| **Sliding Window** | Count requests in last 60 seconds. Over limit = rejected.                |


**On rejection:** Return `429` + `Retry-After: 30` header.

---

## 8. Authentication (Who Are You?)


| Method        | When to Use                               |
| ------------- | ----------------------------------------- |
| **API Key**   | Simple, internal, machine-to-machine      |
| **OAuth 2.0** | Third-party access, user gives permission |
| **JWT**       | Stateless, mobile/web apps, microservices |


**Interview line:** "OAuth for third-party. JWT for our own apps. API key for simple internal."

---

## 9. Idempotency (Handle Retries Safely)

```
GET, PUT, DELETE  → Already idempotent (same request = same result)
POST              → NOT idempotent (can create duplicates!)
```

**Fix for POST:** Client sends `Idempotency-Key: uuid-123` header.
Server checks: same key? → return cached response, no duplicate.

**Example:** Payment retry won't charge twice.

---

## 10. API Gateway (Single Entry Point)

```
Client → API Gateway → Microservices
              ↓
         Does: Auth check, Rate limit, Routing, Logging
```

---

## 11. Top Mistakes to Avoid


| #   | Mistake                  | Fix                                                    |
| --- | ------------------------ | ------------------------------------------------------ |
| 1   | Verbs in URL             | Nouns only: `/users` not `/getUsers`                   |
| 2   | No versioning            | `/v1/` from day one                                    |
| 3   | No pagination            | Always paginate lists                                  |
| 4   | No rate limiting         | Token bucket + 429                                     |
| 5   | POST without idempotency | Add Idempotency-Key                                    |
| 6   | Inconsistent naming      | Pick snake_case OR camelCase, stick to it              |
| 7   | No error format          | `{ "error": { "code": "...", "message": "..." } }`     |
| 8   | Breaking old clients     | Add fields, don't remove. Version for breaking changes |


---

## 12. Interview Quick-Fire Answers


| Question                      | Your Answer                                                       |
| ----------------------------- | ----------------------------------------------------------------- |
| "Design a public API"         | REST + versioning + rate limit + OAuth/JWT                        |
| "Mobile app, many screens"    | GraphQL — each screen queries what it needs                       |
| "Services talking internally" | gRPC — binary, HTTP/2, streaming                                  |
| "Handle duplicate POST"       | Idempotency-Key header                                            |
| "Paginate 10M records"        | Cursor-based, not offset                                          |
| "Rate limit how?"             | Token bucket per user in Redis, return 429                        |
| "301 or 302?"                 | 301 = permanent (browser caches), 302 = temporary (server tracks) |


---



---

