# Security and Authentication — Concept

> **Permanent Recall:** **Authentication** = who you are (identity). **Authorization** = what you can do (permissions). OAuth 2.0 (delegated auth: authorization code, client credentials, implicit, PKCE) and JWT (header.payload.signature, stateless validation) are core. Use session-based auth for server-side apps, token-based for APIs/microservices. SSO via SAML/OIDC. Encrypt in transit (HTTPS/TLS) and at rest. Hash passwords with **bcrypt**, never plain text. RBAC (roles) vs ABAC (attributes). Prevent CORS wildcard, CSRF, SQL injection, XSS; add rate limiting and DDoS protection.

---

## Authentication vs Authorization

| Term | Meaning | Example |
|------|---------|---------|
| **Authentication** | Verifying identity ("who are you?") | Login with username/password |
| **Authorization** | Verifying permissions ("what can you access?") | Checking if user can delete a resource |

```
    User → AuthN (login) → Identity confirmed
         → AuthZ (check) → Permission granted/denied
```

> **FAANG Tip:** 401 = not authenticated; 403 = authenticated but not authorized.

---

## OAuth 2.0 Grant Types

| Grant Type | Use Case | Flow |
|------------|----------|------|
| **Authorization Code** | Web apps (server-side) | Redirect → code → exchange for token |
| **Client Credentials** | Machine-to-machine | Client ID + secret → access token |
| **Implicit** | Legacy SPAs | Direct token in redirect (deprecated) |
| **PKCE** | Mobile, SPAs | Code + code_verifier, no client secret |

---

## OAuth 2.0 Authorization Code Flow (ASCII)

```
    User          App          Auth Server
      │            │                 │
      │  1. Click "Login with Google" │
      │  ─────────────────────────►  │
      │            │  2. Redirect     │
      │            │  ─────────────►  │
      │            │                 │
      │  3. Login + Consent          │
      │  ◄────────────────────────── │
      │            │                 │
      │  4. Redirect with CODE       │
      │  ─────────────────────────►  │
      │            │                 │
      │            │  5. POST /token  │
      │            │     code + secret│
      │            │  ─────────────►  │
      │            │                 │
      │            │  6. access_token │
      │            │  ◄─────────────  │
      │            │                 │
      │  7. API calls with Bearer token
      │  ◄────────────────────────  │
```

**PKCE adds:** App generates `code_verifier` → hashes to `code_challenge`. Sends challenge at step 2; sends verifier at step 5. Prevents code interception.

---

## JWT Structure

```
    header.payload.signature
    
    header:   { "alg": "HS256", "typ": "JWT" }
    payload:  { "sub": "user123", "exp": 1699..., "iat": 1699... }
    signature: HMAC(secret, base64(header).base64(payload))
```

**Validation:** Verify signature with secret; check `exp` (expiry); optionally `iss` (issuer), `aud` (audience).

| Field | Purpose |
|-------|---------|
| `sub` | Subject (user ID) |
| `exp` | Expiration timestamp |
| `iat` | Issued at |
| `iss` | Issuer |
| `aud` | Audience |

---

## Access Token vs Refresh Token

| Token | Lifespan | Purpose |
|-------|----------|---------|
| **Access token** | Short (15 min–1 hr) | API authorization; sent with each request |
| **Refresh token** | Long (days/weeks) | Get new access token when expired; stored securely |

**Flow:** Login → access + refresh. When access expires → POST refresh → new access. Refresh rotation: each use issues new refresh, invalidates old.

---

## Session-Based vs Token-Based Auth

| Aspect | Session-Based | Token-Based (JWT) |
|--------|---------------|-------------------|
| **State** | Server stores session | Stateless; token self-contained |
| **Storage** | Server (Redis, DB) | Client (cookie, storage) |
| **Revocation** | Delete session | Blacklist or short TTL |
| **Scalability** | Needs shared session store | Scales horizontally |
| **Use case** | Traditional web apps | APIs, microservices, SPAs |

---

## SSO (Single Sign-On)

**SSO:** Login once, access multiple apps without re-authenticating.

| Protocol | Use Case | Format |
|----------|----------|--------|
| **SAML 2.0** | Enterprise, XML-based | XML assertions |
| **OAuth 2.0** | Delegated API access | Tokens |
| **OpenID Connect** | Identity + OAuth | JWT ID token + OAuth tokens |

> **FAANG Tip:** OIDC = OAuth 2.0 + identity layer. OIDC adds `id_token` with user info.

---

## API Key Authentication

**How:** Client sends `Authorization: ApiKey <key>` or `X-API-Key: <key>`. Server validates against stored keys.

**Use:** Internal services, partner integrations, simple machine-to-machine.

---

## HTTPS/TLS Handshake

```
    Client                    Server
      │                         │
      │  1. ClientHello         │
      │  ───────────────────►  │
      │  2. ServerHello + Cert │
      │  ◄───────────────────  │
      │  3. Key exchange        │
      │  ◄──────────────────►  │
      │  4. Encrypted traffic  │
      │  ◄──────────────────►  │
```

**Simplified:** Client and server agree on cipher; server sends certificate; client verifies; shared key derived; all traffic encrypted.

---

## Encryption: At Rest vs In Transit

| Type | When | How |
|------|------|-----|
| **In transit** | Data moving over network | TLS/HTTPS |
| **At rest** | Data stored (DB, disk) | AES encryption, key management |

---

## Hashing for Passwords

| Algorithm | Use | Notes |
|-----------|-----|-------|
| **bcrypt** | Passwords | Slow, salt built-in, resist brute-force |
| **SHA-256** | Data integrity, signing | Fast; NOT for passwords alone |
| **Argon2** | Passwords | Modern alternative to bcrypt |

**Rule:** Never store plain-text passwords. Use bcrypt/Argon2 with salt.

---

## RBAC vs ABAC

| Model | Basis | Example |
|-------|-------|---------|
| **RBAC** (Role-Based) | User's role | Admin can delete; User can read |
| **ABAC** (Attribute-Based) | Attributes of user, resource, action | "User from HR dept can edit docs in HR folder" |

> **FAANG Tip:** RBAC simpler; ABAC more flexible for complex policies.

---

## CORS (Cross-Origin Resource Sharing)

**CORS:** Browser enforces same-origin; server must send `Access-Control-Allow-Origin` to allow cross-origin requests.

**Mistake:** `Access-Control-Allow-Origin: *` with credentials = insecure. Use specific origins.

---

## CSRF Protection

**CSRF:** Attacker tricks user's browser into sending request to a site where user is logged in.

**Mitigation:**
- **CSRF token:** Hidden token in form; server validates
- **SameSite cookies:** `SameSite=Strict` or `Lax`
- **Origin/Referer check:** Validate request origin

---

## SQL Injection Prevention

**Attack:** Malicious input in SQL: `' OR '1'='1`

**Prevention:**
- **Parameterized queries** (prepared statements)
- **ORM** (object-relational mapping)
- Never concatenate user input into SQL

---

## XSS Prevention

**Attack:** Inject script into page: `<script>alert('xss')</script>`

**Prevention:**
- **Output encoding** (escape HTML)
- **Content Security Policy** (CSP)
- **HttpOnly cookies** (no JS access)
- Sanitize user input

---

## Rate Limiting for Security

**Why:** Prevent brute-force login, credential stuffing, abuse.

**Approach:** Limit login attempts per IP/user (e.g., 5 attempts/15 min). Lock account or CAPTCHA after threshold.

---

## DDoS Protection Basics

| Layer | Mitigation |
|-------|-------------|
| **Network** | CDN, anycast, absorb traffic |
| **Application** | Rate limiting, WAF |
| **Infra** | Auto-scaling, overflow capacity |
| **Services** | Cloudflare, AWS Shield |

---

## 30-SECOND REVISION BOX

```
AUTHN = who | AUTHZ = what | OAUTH: Auth code, PKCE
JWT: header.payload.signature | SESSION vs TOKEN: Stateful vs stateless
SSO: SAML, OIDC | HTTPS + at rest | bcrypt, never plain
RBAC vs ABAC | CORS, CSRF, SQLi, XSS | RATE LIMIT
```

---

**Next: [[02_Mental-Model]]**
