# Data Warehouse Transformations

> "Data quality is not an act, it is a habit. Transformations are where raw inputs become trustworthy decisions."

**Real-world analogy:** A regional grocery chain receives carton labels, supplier spreadsheets, and POS exports that disagree on product codes and currencies. Transformations are the receiving dock and quality lab combined: items are inspected, relabeled to a single taxonomy, weighed in consistent units, and only then shelved where shoppers and analysts can trust the price on the tag.

---

## Core Idea (2 Lines)

Transformations reshape source data into conformed warehouse shapes so facts and dimensions answer the same business question the same way everywhere. Choosing ETL versus ELT and staging versus presentation-layer logic is a trade-off among latency, repeatability, governance, and who is allowed to change business rules.

---

## ETL versus ELT in a Retail Context

| Aspect | ETL (Transform before load) | ELT (Load then transform) |
|--------|----------------------------|-------------------------|
| Where compute runs | Often outside the warehouse (integration tool, Spark) | Inside the warehouse (SQL, dbt) |
| Raw history | May land in archive or reject quarantine first | Raw often lands in a landing or bronze zone |
| Skill mix | Pipeline engineers, proprietary steps | SQL-first analysts and engineers |
| Sensitive PII | Easier to mask before it hits the warehouse | Requires strict zone policies and row access |
| Late rule changes | Re-run pipeline or backfill | Re-run SQL models, sometimes cheaper at scale |

**Interview Tip:** State that "ETL" and "ELT" describe order and location of transform, not a moral superiority. Many retail stacks blend both: heavy cleansing in a staging job, conforming joins in warehouse SQL.

**Watch Out!** Pushing every transform into the BI layer duplicates logic across dashboards and breaks single source of truth.

---

## Types of Transformations

### Data cleansing

Retail sources often ship dirty strings: `"N/A"`, `"NULL"`, trailing spaces, mixed case brand names.

```sql
-- Example: normalize empty-like literals and trim
SELECT
  TRIM(UPPER(NULLIF(NULLIF(brand_name, 'N/A'), ''))) AS brand_name_clean
FROM retail_staging.supplier_product_feed;
```

### Data type conversion

POS may send monetary amounts as text with commas; dates as `DD/MM/YYYY`.

```sql
SELECT
  SAFE_CAST(REPLACE(sale_amount_text, ',', '') AS NUMERIC) AS sale_amount,
  PARSE_DATE('%d/%m/%Y', sale_date_text) AS sale_date
FROM retail_staging.pos_extract;
```

### Deduplication

Loyalty events can arrive twice from mobile retries.

```sql
WITH ranked AS (
  SELECT
    *,
    ROW_NUMBER() OVER (
      PARTITION BY loyalty_event_id
      ORDER BY ingested_at DESC
    ) AS rn
  FROM retail_staging.loyalty_events
)
SELECT * EXCEPT(rn)
FROM ranked
WHERE rn = 1;
```

### Filtering

Exclude test stores, voided transactions, or employee purchases depending on policy.

```sql
SELECT *
FROM retail_staging.pos_line
WHERE store_id NOT IN (SELECT test_store_id FROM retail_ref.test_stores)
  AND void_flag = FALSE;
```

### Aggregation

Roll raw POS lines to the grain you load into a periodic snapshot or summary table.

```sql
SELECT
  store_sk,
  product_sk,
  sale_date,
  SUM(extended_sale_amount) AS daily_sales_amount,
  SUM(quantity) AS daily_quantity
FROM retail_staging.pos_line_enriched
GROUP BY 1, 2, 3;
```

### Joining and merging

Attach conformed product and store keys before the fact load.

```sql
SELECT
  pl.*,
  p.product_sk,
  s.store_sk
FROM retail_staging.pos_line pl
JOIN retail_core.dim_product p
  ON pl.retailer_product_code = p.retailer_product_code
JOIN retail_core.dim_store s
  ON pl.store_code = s.store_code;
```

### Deriving new columns

Compute line discount percent, pack size, or fiscal period labels.

```sql
SELECT
  *,
  SAFE_DIVIDE(
    list_price - net_price,
    NULLIF(list_price, 0)
  ) AS discount_ratio
FROM retail_staging.pos_line;
```

### Conforming and standardization

Map vendor category trees to an internal hierarchy; unify currency to reporting currency using daily FX.

```sql
SELECT
  f.*,
  f.foreign_amount * fx.rate_to_reporting AS reporting_amount
FROM retail_staging.foreign_sales f
JOIN retail_ref.daily_fx_rate fx
  ON f.currency_code = fx.from_currency
 AND f.sale_date = fx.rate_date;
```

**Interview Tip:** Tie each transform type to a retail pain: duplicate loyalty rows, test stores polluting revenue, vendor categories blocking enterprise reporting.

**Watch Out!** Conforming in the presentation layer only produces inconsistent KPIs when two teams pick different mapping tables.

---

## Transformation in Staging versus User Access Layer

```
+------------------+     +------------------+     +------------------------+
|  Source systems  | --> | Staging / Bronze | --> | Core / Gold models     |
|  POS, ERP, web   |     | Cleanse, types   |     | Conformed dims, facts  |
+------------------+     +------------------+     +-----------+------------+
                                                           |
                                                           v
                                                 +------------------------+
                                                 | Semantic / BI layer    |
                                                 | Friendly names,      |
                                                 | row-level security     |
                                                 +------------------------+
```

| Layer | Typical transforms | Rationale |
|-------|-------------------|-----------|
| Staging | Parsing, rejects, dedupe keys, PII tokenization | Isolate volatility and protect downstream consumers |
| Core warehouse | Surrogate keys, SCD logic, conforming joins | Stable analytical contracts |
| Semantic / BI | Labels, light formatting, presentation hierarchies | UX and access control without redefining grain |

**Watch Out!** Putting surrogate-key assignment only in BI tools makes facts non-reloadable and breaks incremental processing.

---

## When to Transform: Before Load versus After Load

| Scenario | Prefer before load (ETL-heavy) | Prefer after load (ELT-heavy) |
|----------|-------------------------------|--------------------------------|
| Heavy regex on huge files | Yes, reduce bytes moved | Rarely first choice |
| Need raw forensic replay | Land raw first, transform in SQL | Yes |
| Complex window dedupe at scale | Engine-dependent; sometimes pre-warehouse | Warehouse SQL or Spark SQL |
| PII must not enter warehouse | Mask or hash upstream | Only if policy forbids raw storage |
| Rapidly changing business rules | Version SQL in repo, rerun | Often faster iteration |

```sql
-- Pattern: land raw unchanged, transform in a downstream view or table
CREATE OR REPLACE TABLE retail_core.pos_line_clean AS
SELECT * FROM retail_landing.pos_line_raw
WHERE 1=0; -- placeholder in docs; real job would INSERT...SELECT with transforms
```

**Interview Tip:** Frame the decision as risk management: compliance and cost push transforms earlier; agility and auditability of raw history push transforms later, with governance gates.

---

## End-to-End Retail Example: One Sale Line

```
POS file row
------------
store_code=NY-0145, sku=778812, qty=2, price_text="$3,49", ts="04/12/2025 14:05"

Transforms applied
------------------
1) type conversion: price_text -> 3.49 numeric
2) derive: extended_amount = qty * unit_price
3) join: sku -> product_sk, store_code -> store_sk
4) filter: drop if store in test_stores
5) conform: map sku to private label flag from product master
6) aggregate (only if loading a daily snapshot fact): sum by store_sk, product_sk, day
```

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Transforming only in dashboards | Divergent KPI definitions across teams | Centralize conforming logic in core models |
| Losing rejected rows without audit | Silent data loss and compliance gaps | Quarantine tables with reasons and counts |
| Coarse-grain aggregation in staging when facts need line-level | Cannot answer basket analysis later | Preserve atomic grain until the fact table choice is explicit |
| Hard-deleting source duplicates | No way to investigate upstream bugs | Keep lineage and use rank/dedupe with survivorship rules |
| Mixing time zones implicitly | Same fiscal day splits across regions | Standardize to a documented reporting time zone early |

---

## Key Takeaway

> Transformations are the contract between messy operational reality and trustworthy analytics: stage for hygiene and safety, core for conformed meaning, and presentation for readability, never the other way around.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| ETL = transform before load; ELT = load raw then SQL transforms. |
| Types: cleanse, cast, dedupe, filter, aggregate, join, derive.   |
| Staging isolates volatility; core holds conformed grain and keys.|
| Move PII transforms upstream when policy demands minimization.   |
| BI-only transforms duplicate logic and break consistent KPIs.    |
+------------------------------------------------------------------+
```
