import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const T = 'babad';

function preprocess(s) {
  return `^#${s.split('').join('#')}#$`;
}

function manacherSteps(s) {
  const A = preprocess(s);
  const steps = [];
  const P = Array(A.length).fill(0);
  let C = 0;
  let R = 0;
  steps.push({ type: 'init', msg: 'Padded string for even/odd palindromes', raw: s, A, C, R, P: [...P], i: 0 });
  for (let i = 1; i < A.length - 1; i++) {
    const mirror = 2 * C - i;
    if (i < R) P[i] = Math.min(R - i, P[mirror]);
    steps.push({
      type: 'center',
      msg: `Center i=${i}, mirror=${mirror}, expand from radius ${P[i]}`,
      raw: s,
      A,
      C,
      R,
      i,
      mirror,
      P: [...P],
    });
    while (A[i + (1 + P[i])] === A[i - (1 + P[i])]) {
      steps.push({
        type: 'grow',
        msg: `Expand palindrome at ${i}`,
        raw: s,
        A,
        C,
        R,
        i,
        rad: P[i],
        P: [...P],
      });
      P[i] += 1;
    }
    steps.push({ type: 'setp', msg: `P[${i}] = ${P[i]}`, raw: s, A, C, R, i, P: [...P] });
    if (i + P[i] > R) {
      C = i;
      R = i + P[i];
      steps.push({ type: 'right', msg: `New right edge R=${R}`, raw: s, A, C, R, i, P: [...P] });
    }
  }
  steps.push({ type: 'done', msg: 'Longest palindrome radius known at each center', raw: s, A, C, R, P: [...P] });
  return steps;
}

function paint(step) {
  const A = step.A || preprocess(T);
  const textColors = {};
  const patternColors = {};
  const comparePairs = [];
  if (step.type === 'grow' && step.i != null) {
    const i = step.i;
    const rad = step.rad ?? 0;
    const lo = i - rad - 1;
    const hi = i + rad + 1;
    if (lo >= 0) textColors[lo] = 'current';
    if (hi < A.length) patternColors[rad] = 'match';
    if (lo >= 0 && hi < A.length) comparePairs.push([lo, rad]);
  }
  if (step.type === 'center' || step.type === 'setp') {
    if (step.i != null) textColors[step.i] = 'found';
  }
  if (step.C != null && step.R != null) {
    for (let k = Math.max(0, step.C - 2); k <= Math.min(A.length - 1, step.R + 2); k++) {
      if (textColors[k] == null && k >= step.C - (step.P?.[step.C] || 0) && k <= step.C + (step.P?.[step.C] || 0)) textColors[k] = 'match';
    }
  }
  const P = step.P || [];
  return {
    text: A.split(''),
    pattern: A.split(''),
    textColors,
    patternColors,
    offset: 0,
    table: P,
    tableLabel: 'P (radius)',
    matchPositions: step.i != null ? [step.i] : [],
    comparePairs: comparePairs.length ? comparePairs : null,
  };
}

export default function ManachersVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = manacherSteps(T);
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Manacher on "${T}"` });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'grow') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
