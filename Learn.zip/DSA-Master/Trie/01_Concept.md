# Trie — Concept

> **Permanent Recall:** Trie (Prefix Tree) stores strings by sharing common prefixes. Each node = one character; path from root = string. O(L) per insert/search/delete where L = string length. Use when prefix queries matter; avoid when exact lookup only. FAANG tests in autocomplete, word search, IP routing, spell-check.

---

## Core Idea (2 Lines)

**A tree where each node holds one character; path from root spells a string. Children = next possible characters. Shared prefixes = shared paths → space-efficient prefix storage.**

---

## Intuition

Imagine a **dictionary where words share their beginnings**. "cat", "car", "card" all share "ca". Instead of storing "ca" three times, store it once and branch at 't' vs 'r'.

```
HashMap:  "cat" → 1, "car" → 1, "card" → 1  (3 separate entries)
Trie:     c → a → t (end)
              └→ r (end)
                  └→ d (end)   (shared "ca", shared "car")
```

---

## Trie vs HashMap

| Operation | HashMap | Trie |
|-----------|---------|------|
| Insert word | O(L) | O(L) |
| Search exact word | O(L) | O(L) |
| Search prefix | O(L) — must scan all keys | O(L) — direct path |
| Space | O(n·L) — n words, L avg len | O(n·L) but shared prefixes |
| Prefix enumeration | O(n) | O(k) — k = words with prefix |
| Alphabet size | Irrelevant | Affects node fan-out |

**When Trie wins:** Prefix search, autocomplete, "all words starting with X", word break (check prefixes).

**When HashMap wins:** Exact lookup only, no prefix queries, simple key-value.

---

## Time & Space Complexity

| Operation | Time | Space |
|-----------|------|-------|
| Insert | O(L) | O(L) new nodes (shared prefixes) |
| Search | O(L) | O(1) |
| Delete | O(L) | O(L) freed |
| startsWith | O(L) | O(1) |

**L** = length of string. **n** = number of strings. Total space: O(total characters) with sharing.

---

## When to Use Trie

| Signal | Use Trie |
|--------|----------|
| "Prefix search" | ✅ |
| "Autocomplete" | ✅ |
| "All words starting with X" | ✅ |
| "Word break" (check if prefix exists) | ✅ |
| "Longest common prefix" | ✅ |
| "Wildcard search" (e.g., "c.t") | ✅ (Trie + DFS) |
| "Max XOR" in array | ✅ (Bitwise Trie) |

---

## When NOT to Use Trie

| Scenario | Why Not | Use Instead |
|----------|---------|-------------|
| Exact lookup only, no prefix | Trie adds complexity | HashMap |
| Very large alphabet, sparse | Many null children | HashMap in node |
| Need sorted iteration by key | Trie gives prefix order, not full sort | TreeMap / B-tree |
| One-time batch lookup | Overhead of building trie | HashSet |
| Numeric keys (not string-like) | Trie is character-based | HashMap or Bitwise Trie |

---

## Golden Rules

1. **Prefix queries → Trie; exact lookup only → HashMap**
2. **Each node = one character; path = string**
3. **Must mark end-of-word** (boolean flag) — "car" ≠ "card"
4. **O(L) per operation** — one pass per character
5. **Children: HashMap (flexible) or fixed array (small alphabet)**
6. **Bitwise Trie** for XOR/max problems — treat bits as "characters"

---

## Node Structure Comparison

```
ARRAY-BASED (a-z, 26 children):
  children[26]  — O(1) access, O(26) space per node
  Good for: lowercase English

HASHMAP-BASED:
  children: Map<char, Node>  — O(1) avg, variable space
  Good for: Unicode, large alphabet, sparse
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Trie (Prefix Tree)
WHEN TO USE:        Prefix search, autocomplete, word break, wildcard
CORE IDEA:          Tree, node=char, path=string, shared prefixes
TIME COMPLEXITY:    O(L) per insert/search/delete
SPACE:              O(total chars) with sharing
TRIE vs HASHMAP:    Trie wins on prefix; HashMap wins on exact-only
INTERVIEW LINE:     "I'll use a trie to enable O(L) prefix lookups
                     and share storage for common prefixes."
```

---

## 30-SECOND REVISION BOX

```
TRIE = prefix tree, node=char, path=string
O(L) per op, L = string length
PREFIX search → Trie | EXACT only → HashMap
MARK end-of-word (car ≠ card)
CHILDREN: array (a-z) or HashMap (Unicode)
BITWISE TRIE for XOR/max problems
```
