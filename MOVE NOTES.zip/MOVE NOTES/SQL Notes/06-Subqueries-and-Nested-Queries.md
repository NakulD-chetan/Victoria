# Subqueries & Nested Queries — Complete Guide

> **Subquery = Query ke andar ek aur query** (nested query)
> Jab ek query ka result doosri query mein use karna ho — subquery lagao!
> Interview mein JOIN vs Subquery ka comparison zaroor puchha jaata hai.

---

## What is a Subquery?

> **Definition:** A subquery (inner query) is a SQL query nested inside another query (outer query). The inner query executes first, and its result is used by the outer query.

```sql
-- Outer Query
SELECT name, salary FROM employees
WHERE salary > (
    -- Inner Query (Subquery)
    SELECT AVG(salary) FROM employees
);
```

> **Flow:** Pehle inner query execute hogi → `AVG(salary)` niklega → phir outer query use karegi.

```
Step 1: Inner → SELECT AVG(salary) FROM employees → 74500
Step 2: Outer → SELECT name, salary FROM employees WHERE salary > 74500
```

---

## Types of Subqueries

```
Subqueries
├── 1. Single-Row Subquery    → Ek value return karta hai
├── 2. Multi-Row Subquery     → Multiple values return karta hai
├── 3. Multi-Column Subquery  → Multiple columns return karta hai
├── 4. Correlated Subquery    → Outer query pe depend karta hai
└── 5. Scalar Subquery        → Exactly 1 row, 1 column
```

---

## 1. Single-Row Subquery

> Returns exactly **one value** (one row, one column). Use with `=, >, <, >=, <=, !=`

```sql
-- Average se zyada salary wale employees
SELECT name, salary
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);

-- Sabse zyada salary wale employee ka naam
SELECT name FROM employees
WHERE salary = (SELECT MAX(salary) FROM employees);

-- Sabse purane employee ka department
SELECT department FROM employees
WHERE join_date = (SELECT MIN(join_date) FROM employees);
```

> **Rule:** Single-row subquery mein `=` ya comparison operator use karo. Agar subquery multiple rows return kare → ERROR!

---

## 2. Multi-Row Subquery

> Returns **multiple rows**. Use with `IN, ANY, ALL, EXISTS`

### IN — Match from list:

```sql
-- IT department mein jo cities hain, unme se kisi mein kaam karne wale
SELECT name, city FROM employees
WHERE city IN (
    SELECT DISTINCT city FROM employees WHERE department = 'IT'
);
```

### ANY — Kisi bhi value se match:

```sql
-- Kisi bhi HR employee se zyada salary wale
SELECT name, salary FROM employees
WHERE salary > ANY (
    SELECT salary FROM employees WHERE department = 'HR'
);
```

> `> ANY` = greater than the **minimum** value in the list.
> `< ANY` = less than the **maximum** value in the list.

### ALL — Sab values se match:

```sql
-- SAB HR employees se zyada salary wale
SELECT name, salary FROM employees
WHERE salary > ALL (
    SELECT salary FROM employees WHERE department = 'HR'
);
```

> `> ALL` = greater than the **maximum** value in the list.
> `< ALL` = less than the **minimum** value in the list.

### ANY vs ALL — Quick Comparison:


| Operator             | Meaning        | Example               |
| -------------------- | -------------- | --------------------- |
| `> ANY (10, 20, 30)` | > 10 (minimum) | Any ek se bada ho     |
| `> ALL (10, 20, 30)` | > 30 (maximum) | Sab se bada ho        |
| `< ANY (10, 20, 30)` | < 30 (maximum) | Any ek se chhota ho   |
| `< ALL (10, 20, 30)` | < 10 (minimum) | Sab se chhota ho      |
| `= ANY (10, 20, 30)` | Same as IN     | Kisi ek ke barabar ho |


---

## 3. Correlated Subquery — BAHUT IMPORTANT!

> **Definition:** A correlated subquery references columns from the outer query. It executes ONCE FOR EACH ROW of the outer query.

> **Normal Subquery:** Inner query independently execute hoti hai → ek baar result aata hai
> **Correlated Subquery:** Inner query **har row ke liye** execute hoti hai (outer query ke data pe depend karti hai)

```sql
-- Employees jo apne department ke average se zyada earn karte hain
SELECT e.name, e.salary, e.department
FROM employees e
WHERE e.salary > (
    SELECT AVG(e2.salary)
    FROM employees e2
    WHERE e2.department = e.department    -- ← Outer query ka reference!
);
```

### How it executes (step by step):

```
Row 1: Rahul (IT, 75000)
  → Inner: AVG(salary) WHERE department = 'IT' → 82500
  → 75000 > 82500? → NO → Skip

Row 2: Priya (HR, 65000)
  → Inner: AVG(salary) WHERE department = 'HR' → 60000
  → 65000 > 60000? → YES → Include

Row 3: Amit (IT, 80000)
  → Inner: AVG(salary) WHERE department = 'IT' → 82500
  → 80000 > 82500? → NO → Skip

... har row ke liye inner query chalti hai!
```

> **Performance:** Correlated subquery **slow** hoti hai (N rows × inner query). Window functions ya JOIN prefer karo jab possible ho.

---

## 4. EXISTS — Row Exist Karti Hai Ya Nahi?

> **Definition:** EXISTS returns TRUE if the subquery returns at least one row.

```sql
-- Departments jismein koi employee hai
SELECT d.dept_name
FROM departments d
WHERE EXISTS (
    SELECT 1 FROM employees e
    WHERE e.dept_id = d.dept_id
);
```

### NOT EXISTS:

```sql
-- Departments jismein koi employee NAHI hai
SELECT d.dept_name
FROM departments d
WHERE NOT EXISTS (
    SELECT 1 FROM employees e
    WHERE e.dept_id = d.dept_id
);
```

> **EXISTS vs IN — Interview MUST!**


| Feature                       | IN                     | EXISTS                       |
| ----------------------------- | ---------------------- | ---------------------------- |
| **Kaise check karta hai**     | Value match from list  | Row exist karti hai ya nahi  |
| **NULL handling**             | NOT IN fails with NULL | EXISTS handles NULL properly |
| **Performance (small inner)** | ✅ Better               | Slower                       |
| **Performance (large inner)** | Slower                 | ✅ Better                     |
| **Correlated?**               | Can be non-correlated  | Usually correlated           |
| **Returns**                   | Actual values          | TRUE/FALSE                   |


```sql
-- IN version (risky with NULLs)
SELECT name FROM employees
WHERE dept_id IN (SELECT dept_id FROM departments);

-- EXISTS version (safe with NULLs)
SELECT name FROM employees e
WHERE EXISTS (
    SELECT 1 FROM departments d WHERE d.dept_id = e.dept_id
);
```

> **Interview Tip:** "NOT IN with NULLs" is a classic trap!

```sql
-- Agar subquery mein NULL aata hai:
SELECT name FROM employees
WHERE dept_id NOT IN (101, 102, NULL);
-- Result: EMPTY SET! (NULL se comparison = UNKNOWN)

-- EXISTS safe hai:
SELECT name FROM employees e
WHERE NOT EXISTS (
    SELECT 1 FROM departments d WHERE d.dept_id = e.dept_id
);
-- Result: Correct rows
```

---

## 5. Subquery in Different Clauses

### In SELECT (Scalar Subquery):

```sql
SELECT
    name,
    salary,
    (SELECT AVG(salary) FROM employees) AS company_avg,
    salary - (SELECT AVG(salary) FROM employees) AS diff_from_avg
FROM employees;
```

### In FROM (Derived Table / Inline View):

```sql
SELECT dept, avg_sal
FROM (
    SELECT department AS dept, AVG(salary) AS avg_sal
    FROM employees
    GROUP BY department
) AS dept_avg
WHERE avg_sal > 70000;
```

> FROM mein subquery ko **alias dena mandatory** hai! (`AS dept_avg`)

### In WHERE:

```sql
SELECT name FROM employees
WHERE salary = (SELECT MAX(salary) FROM employees);
```

### In HAVING:

```sql
SELECT department, AVG(salary) AS avg_sal
FROM employees
GROUP BY department
HAVING AVG(salary) > (SELECT AVG(salary) FROM employees);
```

---

## 6. CTE — Common Table Expression (WITH Clause)

> **Definition:** CTE is a temporary named result set that exists only during the execution of a single SQL statement. Think of it as a "temporary view."

### Syntax:

```sql
WITH cte_name AS (
    -- Your query here
    SELECT department, AVG(salary) AS avg_sal
    FROM employees
    GROUP BY department
)
SELECT * FROM cte_name WHERE avg_sal > 70000;
```

### Multiple CTEs:

```sql
WITH
dept_avg AS (
    SELECT department, AVG(salary) AS avg_sal
    FROM employees
    GROUP BY department
),
high_earners AS (
    SELECT name, department, salary
    FROM employees
    WHERE salary > 80000
)
SELECT h.name, h.salary, d.avg_sal
FROM high_earners h
JOIN dept_avg d ON h.department = d.department;
```

### Recursive CTE (Employee Hierarchy):

```sql
-- Employee hierarchy — manager chain nikalo
WITH RECURSIVE emp_hierarchy AS (
    -- Base case: top-level managers
    SELECT emp_id, name, manager_id, 1 AS level
    FROM employees
    WHERE manager_id IS NULL

    UNION ALL

    -- Recursive case: employees under managers
    SELECT e.emp_id, e.name, e.manager_id, h.level + 1
    FROM employees e
    JOIN emp_hierarchy h ON e.manager_id = h.emp_id
)
SELECT * FROM emp_hierarchy;
```

```
Result:
+--------+---------+------------+-------+
| emp_id | name    | manager_id | level |
+--------+---------+------------+-------+
| 1      | Rahul   | NULL       | 1     |  ← Top boss
| 2      | Priya   | 1          | 2     |
| 3      | Amit    | 1          | 2     |
| 4      | Sneha   | 2          | 3     |
| 5      | Karan   | 2          | 3     |
| 6      | Neha    | 3          | 3     |
+--------+---------+------------+-------+
```

> **Recursive CTE** = Tree traversal jaisa! Base case + recursive step.

---

## CTE vs Subquery vs Temp Table


| Feature                       | Subquery              | CTE                    | Temp Table         |
| ----------------------------- | --------------------- | ---------------------- | ------------------ |
| **Readability**               | Low (nested)          | ✅ High (named)         | High               |
| **Reusability in same query** | ❌ Repeat karna padega | ✅ Multiple times use   | ✅ Multiple queries |
| **Scope**                     | Within that statement | Within that statement  | Within session     |
| **Recursive**                 | ❌ Not possible        | ✅ WITH RECURSIVE       | Need loops         |
| **Performance**               | Similar               | Similar (may optimize) | Stored on disk     |


> **Interview Answer:** "CTE is preferred for readability and when you need to reference the same subquery multiple times. Use subquery for simple one-off queries. Use temp tables when you need to persist data across multiple statements."

---

## Common Interview Patterns

### Pattern 1: Second Highest Salary

```sql
-- Method 1: Subquery with LIMIT
SELECT MAX(salary) FROM employees
WHERE salary < (SELECT MAX(salary) FROM employees);

-- Method 2: DISTINCT + LIMIT OFFSET
SELECT DISTINCT salary FROM employees
ORDER BY salary DESC
LIMIT 1 OFFSET 1;

-- Method 3: CTE with DENSE_RANK
WITH ranked AS (
    SELECT salary, DENSE_RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT DISTINCT salary FROM ranked WHERE rnk = 2;
```

### Pattern 2: Nth Highest Salary

```sql
-- Generic: Replace N with any number
WITH ranked AS (
    SELECT salary, DENSE_RANK() OVER (ORDER BY salary DESC) AS rnk
    FROM employees
)
SELECT DISTINCT salary FROM ranked WHERE rnk = N;
```

### Pattern 3: Department-wise Highest Salary

```sql
SELECT e.name, e.department, e.salary
FROM employees e
WHERE e.salary = (
    SELECT MAX(e2.salary)
    FROM employees e2
    WHERE e2.department = e.department
);
```

---

## Quick Memory Card


| Concept         | Ek Line Mein            | Kab Use Karo             |
| --------------- | ----------------------- | ------------------------ |
| Single-Row Sub  | 1 value return          | `=, >, <` comparison     |
| Multi-Row Sub   | Multiple values         | `IN, ANY, ALL`           |
| Correlated Sub  | Outer row pe depend     | Per-row comparison       |
| EXISTS          | TRUE/FALSE check        | Row exist karta hai?     |
| NOT IN danger   | NULL se fail hota hai   | EXISTS prefer karo       |
| CTE (WITH)      | Named temporary result  | Readable, reusable       |
| Recursive CTE   | Tree/hierarchy traverse | Manager chain, paths     |
| Scalar Subquery | 1 row, 1 column         | SELECT clause mein       |
| Derived Table   | FROM mein subquery      | Intermediate calculation |


---

*Notes Source: SQL Subqueries & CTEs + Interview preparation material*