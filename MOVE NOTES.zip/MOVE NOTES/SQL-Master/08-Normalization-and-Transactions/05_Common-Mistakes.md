# Normalization and Transactions — Common Mistakes

| Mistake | Correction |
|---------|-----------|
| Confusing 2NF and 3NF | 2NF = partial dep (composite PK); 3NF = transitive dep |
| "Normalization always good" | Denormalize for read performance when needed |
| Forgetting COMMIT | Transaction stays open → locks held → blocks others |
| Using Read Uncommitted casually | Dirty reads in prod = bugs |
| Not handling deadlocks | App should retry on deadlock error |

---

*Next: [[06_Edge-Cases]]*
