# Subqueries and CTE — Edge Cases

---

## NULL in `IN (subquery)`

If subquery can yield NULL, `x IN (subquery)` semantics include UNKNOWN — surprises possible.

---

## Multiple CTEs referencing each other

Order matters: define before use.

---

## Recursive CTE (advanced)

`WITH RECURSIVE` for org trees / graphs — dialect-specific.

---

*Next: [[07_Tricks-and-Recognition]]*
