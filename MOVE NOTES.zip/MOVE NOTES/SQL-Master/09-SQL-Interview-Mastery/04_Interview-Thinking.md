# SQL Interview Mastery — Interview Thinking

---

## The 5 things interviewers watch for

1. **Structured approach** — clarify → skeleton → edge cases → optimize.
2. **NULL awareness** — mention it proactively.
3. **Correct grain** — "one row per what?"
4. **Window vs GROUP BY** choice — know trade-offs.
5. **Optimization mention** — indexes, EXPLAIN, even briefly.

---

## How to talk through a solution

> "The grain is **one row per user per day**. I'll `GROUP BY user_id, DATE(ts)`, aggregate with `COUNT(DISTINCT session_id)`, filter with `HAVING > 5`. I'd check if `(user_id, ts)` has an index."

---

## "Write the query" timing

- **Easy** (15 min slot): 3-5 min read + 5-8 min write + 2-3 min edge cases.
- **Medium** (20 min): 5 min read + 10 min write + 5 min optimize/edge.
- **Hard** (30 min): 5 min clarify + 15 min write + 10 min refine.

---

## 50+ Rapid-Fire Theory Q&A (All Topics Combined)

### Foundations

**Q: What is SQL?**
A: Structured Query Language for managing relational databases. Sub-languages: DDL, DML, DQL, DCL, TCL.

**Q: DBMS vs RDBMS?**
A: DBMS = any data management software. RDBMS = tables + relationships + SQL + ACID (MySQL, PostgreSQL, Oracle).

**Q: What is a Schema?**
A: Blueprint defining tables, columns, types, constraints, relationships, indexes in a database.

**Q: Primary Key vs Unique Key?**
A: PK = NOT NULL + UNIQUE, one per table. UNIQUE allows NULL, multiple per table.

**Q: Candidate Key vs Primary Key?**
A: Candidate = any minimal unique column set. PK = the one candidate key chosen as row identifier.

**Q: Surrogate vs Natural Key?**
A: Surrogate = system-generated (auto-increment). Natural = business value (email). Prefer surrogate for stability.

**Q: What is a Foreign Key?**
A: References PK/UNIQUE of another table. Enforces referential integrity. Can be NULL (optional relationship).

**Q: DELETE vs TRUNCATE vs DROP?**
A: DELETE = row-level, logged, triggers. TRUNCATE = all rows, fast, no triggers. DROP = entire table gone.

### Clauses & Execution

**Q: SQL Execution Order?**
A: FROM → WHERE → GROUP BY → HAVING → SELECT → DISTINCT → ORDER BY → LIMIT.

**Q: WHERE vs HAVING?**
A: WHERE = row filter before grouping. HAVING = group filter after GROUP BY. WHERE can't use aggregates.

**Q: UNION vs UNION ALL?**
A: UNION removes duplicates (slower). UNION ALL keeps all rows (faster).

**Q: What is COALESCE?**
A: Returns first non-NULL argument. `COALESCE(a, b, c)`.

**Q: What is NULLIF?**
A: Returns NULL if two values equal. `x / NULLIF(y, 0)` avoids division by zero.

### Joins

**Q: INNER vs LEFT JOIN?**
A: INNER = only matching rows. LEFT = all left rows + matching right (NULL if no match).

**Q: What is CROSS JOIN?**
A: Cartesian product — every row from A paired with every row from B.

**Q: What is Self-Join?**
A: Joining table with itself using aliases. Employee-manager pattern.

**Q: What causes row duplication after JOIN?**
A: One-to-many relationship — one row matches multiple on other side (fan-out).

**Q: Join algorithms?**
A: Nested Loop, Hash Join, Merge Join. Optimizer picks based on data/indexes.

### Subqueries & CTE

**Q: What is a CTE?**
A: Named temp result set with WITH clause. Better readability, reusable in query, supports recursion.

**Q: EXISTS vs IN?**
A: EXISTS = boolean check, NULL-safe, short-circuits. IN = membership. NOT EXISTS >> NOT IN (NULL safety).

**Q: CTE vs Temp Table?**
A: CTE = query-scoped, no disk. Temp table = session-scoped, physical storage, good for large intermediate results.

**Q: What is a Recursive CTE?**
A: CTE referencing itself — anchor + recursive step. For hierarchies (org charts, trees).

### Aggregates

**Q: COUNT(*) vs COUNT(col)?**
A: COUNT(*) = all rows including NULLs. COUNT(col) = non-NULL values only.

**Q: What is GROUP BY?**
A: Groups rows for aggregation. One output row per unique group.

**Q: What is ROLLUP?**
A: Generates hierarchical subtotals. `GROUP BY ROLLUP(a, b)` → (a,b), (a), grand total.

### Window Functions

**Q: ROW_NUMBER vs RANK vs DENSE_RANK?**
A: ROW_NUMBER: unique 1..n. RANK: ties share, gaps after. DENSE_RANK: ties share, no gaps.

**Q: What is LAG/LEAD?**
A: LAG = previous row value. LEAD = next row value. Used for day-over-day comparison.

**Q: Window vs GROUP BY?**
A: GROUP BY collapses rows (one per group). Window keeps all rows, adds computed column.

**Q: ROWS vs RANGE in frame?**
A: ROWS = physical row count. RANGE = value-based (peers). ROWS is more predictable.

### Indexes & Optimization

**Q: What is an Index?**
A: Data structure (B-tree) for fast lookups. O(log n) vs full scan O(n). Speeds reads, slows writes.

**Q: Clustered vs Non-Clustered?**
A: Clustered = data physically sorted (1 per table). Non-clustered = separate structure with pointers (multiple allowed).

**Q: What is a Covering Index?**
A: Index containing all columns query needs — no table lookup (index-only scan).

**Q: What is a View?**
A: Virtual table — stored SQL query, no data storage. Re-executes each time.

**Q: What is a Materialized View?**
A: View that stores results physically. Fast reads but stale until refreshed. Indexable.

**Q: Stored Procedure vs Function?**
A: SP: called with CALL, can do DML, multiple results. Function: returns value, usable in SELECT/WHERE.

**Q: What is a Trigger?**
A: Auto-fires on INSERT/UPDATE/DELETE. Types: BEFORE, AFTER, INSTEAD OF. Use for auditing.

**Q: What is EXPLAIN?**
A: Shows query execution plan — access method, joins, estimated rows. Use EXPLAIN ANALYZE for actual timing.

**Q: OLTP vs OLAP?**
A: OLTP = transactions, normalized, many writes. OLAP = analytics, denormalized, complex reads.

### Normalization & Transactions

**Q: What is Normalization?**
A: Organizing tables to minimize redundancy. 1NF → 2NF → 3NF → BCNF.

**Q: 1NF → 2NF → 3NF?**
A: 1NF = atomic values. 2NF = no partial dependency. 3NF = no transitive dependency.

**Q: What is ACID?**
A: Atomicity, Consistency, Isolation, Durability — transaction guarantees.

**Q: Isolation Levels?**
A: Read Uncommitted → Read Committed → Repeatable Read → Serializable. Stronger = safer but slower.

**Q: What is a Deadlock?**
A: Two transactions waiting for each other's locks. Fix: consistent ordering, short tx, retry on error.

**Q: Optimistic vs Pessimistic Locking?**
A: Pessimistic = lock before read. Optimistic = check version at write, retry. Optimistic better for low contention.

**Q: What is MVCC?**
A: Multi-Version Concurrency Control — snapshot isolation. Readers don't block writers. Used by PostgreSQL, InnoDB.

**Q: Star vs Snowflake Schema?**
A: Star = denormalized dimensions, fewer joins. Snowflake = normalized dimensions, more joins. Star preferred for BI.

### Bonus Quick Points

**Q: What is MERGE / UPSERT?**
A: INSERT if row doesn't exist, UPDATE if it does. `MERGE INTO ... USING ... WHEN MATCHED THEN UPDATE WHEN NOT MATCHED THEN INSERT`.

**Q: What is a Sequence?**
A: Database object generating sequential numbers. Independent of table. `CREATE SEQUENCE seq START 1 INCREMENT 1`.

**Q: What is a Tablespace?**
A: Physical storage location for database objects. DBA concern, rarely asked in dev interviews.

**Q: What is Connection Pooling?**
A: Reusing DB connections instead of opening/closing each time. Reduces overhead. PgBouncer, HikariCP.

**Q: What is Sharding?**
A: Splitting data across multiple database servers horizontally. Each shard holds subset of data. For massive scale.

**Q: What is Replication?**
A: Copying data from one DB (primary) to another (replica). For read scaling and high availability. Types: synchronous, asynchronous.

**Q: What is ETL?**
A: Extract, Transform, Load — process of moving data from sources to data warehouse.

**Q: SQL Injection — how to prevent?**
A: Use parameterized queries / prepared statements. NEVER concatenate user input into SQL strings.

---

*Next: [[05_Common-Mistakes]]*
