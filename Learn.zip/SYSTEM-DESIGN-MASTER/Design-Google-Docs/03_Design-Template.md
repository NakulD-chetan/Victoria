# Design Google Docs — Design Template

> **Permanent Recall:** Architecture = Client (text editor + local buffer) → WebSocket → Collaboration Service (OT server transforms and broadcasts ops) → Document Storage (snapshot + operation log). Operation types: insert, delete, format. Document model = tree of blocks. Presence = cursor positions via WebSocket. Version history = operation log. Offline = queue ops, sync on reconnect.

---

## High-Level Architecture (ASCII)

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          CLIENTS (Browsers)                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐         │
│  │  Text Editor    │  │  Text Editor    │  │  Text Editor    │         │
│  │  Local Buffer   │  │  Local Buffer   │  │  Local Buffer   │         │
│  │  Apply ops      │  │  Apply ops      │  │  Apply ops      │         │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘         │
└───────────┼────────────────────┼────────────────────┼───────────────────┘
            │                    │                    │
            │    WebSocket (bi-directional)           │
            ▼                    ▼                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    COLLABORATION SERVICE (OT Server)                      │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │  Receive op → Transform against concurrent ops → Broadcast       │   │
│  │  OT Algorithm: transform(opA, opB) → (opA', opB')                │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│  ┌─────────────────┐  ┌─────────────────┐                               │
│  │ Presence        │  │ Permission      │                               │
│  │ (cursor pos)    │  │ Check          │                               │
│  └─────────────────┘  └─────────────────┘                               │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                      DOCUMENT STORAGE                                    │
│  ┌─────────────────────┐  ┌─────────────────────┐                       │
│  │ Snapshot (current   │  │ Operation Log       │                       │
│  │ doc state)          │  │ (append-only; for   │                       │
│  │ Periodic write      │  │ version history)    │                       │
│  └─────────────────────┘  └─────────────────────┘                       │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Operation Types

| Op Type | Parameters | Example |
|---------|------------|---------|
| **Insert** | position, content, (format?) | Insert(3, "X") |
| **Delete** | position, length | Delete(1, 2) |
| **Format** | position, length, format | Format(0, 4, bold) |

---

## OT Transformation Example (ASCII)

**Scenario:** Doc = `"Hi"`. User A inserts "X" at position 2. User B deletes at position 1 (the "i").

```
Initial: "Hi"
         pos: 0 1

A: Insert(2, "X")  →  "HiX"
B: Delete(1, 1)    →  would make "H" from "Hi"

--- Server receives A first, then B ---

Step 1: Apply A → doc = "HiX"
Step 2: B's Delete(1,1) was computed against "Hi". Now doc is "HiX".
        If we apply Delete(1,1) to "HiX" we delete "i" → "HX". ✓ Correct.

--- Server receives B first, then A ---

Step 1: Apply B → doc = "H"
Step 2: A's Insert(2, "X") was computed against "Hi". Position 2 is after "i".
        Now doc is "H" (len=1). Position 2 is out of bounds!
        TRANSFORM: Insert(2, "X") against Delete(1,1)
          - B's delete removed position 1. A's insert at 2: after the delete,
            position 2 in "Hi" = position 1 in "H". So: Insert(1, "X")
        Apply Insert(1, "X") → "HX". ✓ Same result.
```

```
Transform(Insert(A), Delete(B)) rules (simplified):
  - If Delete affects positions before Insert: adjust Insert position
  - If Delete affects same/after: adjust or cancel
  - Symmetric for Delete vs Insert
```

> **FAANG Tip:** You don't need to implement full OT. Explain: "We transform concurrent operations so applying them in any order yields the same document. The server is the authority."

---

## Document Model: Tree of Blocks

```
Document
├── Block 1 (paragraph): "Hello world"
├── Block 2 (paragraph): "Second paragraph"
└── Block 3 (heading): "Title"

Operations work on block IDs + offset within block.
Simpler OT: transform at block level; fewer edge cases than char-level.
```

| Model | Pros | Cons |
|-------|------|------|
| **Block-level** | Simpler OT; fewer ops | Coarser granularity |
| **Char-level** | Finer control | More ops; heavier OT |

---

## Presence Service (Cursor Positions)

```
Client sends: { user_id, cursor_position, selection_range? } every N ms
Server broadcasts to other clients in same document session
Clients render: colored cursor + name at position

WebSocket: low latency; no polling
Throttle: don't send every mousemove; debounce to ~100ms
```

---

## Version History

| Approach | How | Use Case |
|----------|-----|----------|
| **Operation log** | Append all ops; replay to get past version | Full history; can be large |
| **Periodic snapshot** | Save snapshot every N ops or every N min | Fast load; replay from last snapshot |
| **Checkpoint** | Snapshot + truncate log before checkpoint | Bound storage; history from checkpoint |

```
Version N = Snapshot(0) + Replay(ops 1..N)
```

---

## Permission Service

| Permission | Capability |
|------------|------------|
| **View** | Read only; receive ops for display; no send |
| **Edit** | Send ops; receive ops |
| **Comment** | Add comments; no edit |
| **Owner** | Share, delete, change permissions |

Check permission before accepting op in Collaboration Service.

---

## Offline Editing

```
1. Client queues ops locally when offline
2. On reconnect: send queued ops to server
3. Server transforms queued ops against ops that happened during offline
4. Server returns transformed ops; client applies to local state
5. Server broadcasts to other clients
```

- **OT:** Server does transform; client can't merge offline ops alone (needs server)
- **CRDT:** Client can merge locally; sync when online to converge with others

---

## API Design (REST for Load/Share)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/documents/{id}` | Load document (snapshot + recent ops if any) |
| POST | `/documents` | Create document |
| POST | `/documents/{id}/share` | Share with user; set permission |
| GET | `/documents/{id}/versions` | List versions |
| GET | `/documents/{id}/versions/{v}` | Get document at version v |
| WebSocket | `/ws/documents/{id}` | Real-time: send ops, receive ops, presence |

---

## Mermaid: End-to-End Flow

```mermaid
flowchart LR
    A[Client A types] --> B[Op: Insert]
    B --> C[WebSocket]
    C --> D[Collaboration Service]
    D --> E[Transform OT]
    E --> F[Broadcast]
    F --> G[Client B]
    G --> H[Apply to buffer]
    D --> I[Document Storage]
    I --> J[Snapshot + Log]
```

---

## Mermaid: OT Flow

```mermaid
flowchart TD
    A[Op from Client] --> B{Concurrent ops?}
    B -->|No| C[Apply directly]
    B -->|Yes| D[Transform op against each]
    D --> E[Apply transformed op]
    E --> F[Broadcast to clients]
    C --> F
    F --> G[Append to log]
```

---

## Data Model

| Table/Store | Key Fields |
|-------------|------------|
| **documents** | id, owner_id, snapshot (blob/JSON), updated_at |
| **operation_log** | doc_id, seq, op (JSON), timestamp |
| **document_permissions** | doc_id, user_id, permission (view/edit/owner) |
| **comments** | doc_id, block_id, position, user_id, text, resolved |
| **presence** | Ephemeral in memory; doc_id, user_id, cursor_pos |

---

## Sharding and Scaling

- **Document sessions:** Route by `doc_id` to same Collaboration Service instance (sticky connection)
- **Document storage:** Shard by `doc_id`
- **Operation log:** Append-only; partition by doc_id; retention policy (keep last N or last 30 days)
