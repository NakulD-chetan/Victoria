# Product Dimension and Snowflake Schema

> "The product dimension is where merchandising language meets the mathematics of the fact table—keep hierarchies truthful even when storage complains."

**Real-world analogy:** A product dimension is like the shelf-label system in a supermarket: shoppers see one sign for “Organic Milk 1 gal,” but behind that sign sits a web of buyers, brands, categories, and pack sizes that must stay consistent when headquarters reorganizes aisles without breaking historical sales comparisons.

---

## Core Idea (2 Lines)

The product dimension describes what was sold in retail facts, usually denormalized into one wide row per sellable SKU for simple star joins. When category hierarchies normalize into multiple tables, the schema snowflakes—trading join complexity and ETL discipline for reduced redundancy and stricter hierarchy integrity.

---

## Master Product Table vs Store Assortment

Enterprise retail maintains a **master product** hub (all SKUs the company could carry) while each store sells an **assortment** subset. The warehouse often models:

| Concept | Typical table | Grain | Retail note |
|---------|---------------|-------|-------------|
| Master SKU | `dim_product` | One row per corporate SKU | Stable attributes: UPC, brand, base description |
| Store assortment | `bridge_store_product` or fact flags | Store × SKU × time | Seasonal delistings, local ranging |
| Sellable variant | Same `dim_product` with variant columns | Color/size/pack | Apparel and grocery multipacks |

**Interview Tip:** Clarify whether “product dimension” means enterprise catalog versus what a given store had on shelf that week—assortment is often a bridge or slowly changing relationship, not only columns on `dim_product`.

**Watch Out!** Treating store-level assortment as identical to master catalog produces facts joined to products the store never carried.

---

## Product Dimension Columns (Retail)

Example attributes for `dim_product` in a general merchandise retailer:

| Column | Role | Example |
|--------|------|---------|
| `product_key` | Surrogate PK | 91004231 |
| `product_id` | Natural business key | UPC / internal SKU |
| `product_description` | Display label | “House Brand Paper Towels 6pk” |
| `brand` | Manufacturer or private label | “BrightHome” |
| `department` | High-level merchandising | “Household” |
| `category` | Mid level | “Paper goods” |
| `subcategory` | Fine grain | “Kitchen roll” |
| `package_size` | Consumer unit | “6 rolls” |
| `unit_of_measure` | Pricing basis | “EA”, “KG” |
| `discontinued_flag` | Lifecycle | Y/N |

DDL fragment:

```sql
CREATE TABLE dim_product (
    product_key         BIGINT      NOT NULL PRIMARY KEY,
    product_id          VARCHAR(20) NOT NULL,
    product_description VARCHAR(120) NOT NULL,
    brand               VARCHAR(60) NOT NULL,
    department          VARCHAR(40) NOT NULL,
    category            VARCHAR(60) NOT NULL,
    subcategory         VARCHAR(60) NOT NULL,
    package_size        VARCHAR(40) NOT NULL,
    standard_unit_cost  DECIMAL(9,4) NULL,  -- discuss placement vs fact
    row_effective_date  DATE        NOT NULL,
    row_end_date        DATE        NULL,
    current_flag        CHAR(1)     NOT NULL
);
```

**Watch Out!** Wide text columns on billions of fact joins inflate memory grants; still usually preferable to snowflaking everything for query ergonomics.

---

## Redundancy Problem: 1:N Hierarchy

Category hierarchies are inherently one-to-many: one **department** has many **categories**, one category has many **subcategories**, many SKUs roll up to one subcategory. Denormalizing all levels onto `dim_product` repeats higher-level names on every SKU row.

```
DEPARTMENT (1) ----< CATEGORY (1) ----< SUBCATEGORY (1) ----< SKU
     |                     |                      |
  repeated              repeated               unique
  on every SKU row      on every SKU row        per SKU
```

| Denormalized (star) | Normalized (snowflake) |
|---------------------|-------------------------|
| `department`, `category`, `subcategory` on `dim_product` | `dim_department`, `dim_category`, `dim_subcategory` |
| Redundant strings | Store IDs on child tables |
| Single join from fact | Chain of joins |

**Interview Tip:** Frame redundancy as a conscious trade: query simplicity vs storage and update anomalies.

---

## Star vs Snowflake: ASCII Diagrams

**Star (product dimension denormalized):**

```
              dim_store
                  |
                  |
dim_promo --- fact_store_sales --- dim_product (wide: dept/cat/subcat)
                  |
                  |
               dim_date
```

**Snowflake (product hierarchy normalized):**

```
dim_department
      |
      v
 dim_category
      |
      v
dim_subcategory ----> dim_product ----> fact_store_sales
                                              ^
                                              |
                                          dim_date
```

**Watch Out!** Deep snowflakes multiply join cardinality mistakes if bridge tables are missing or keys are not unique at each level.

---

## Star vs Snowflake Comparison

| Aspect | Star | Snowflake |
|--------|------|-----------|
| Design | Denormalized dimensions | Normalized hierarchy tables |
| Joins | Fewer, simpler | More joins from fact |
| Speed | Often faster for BI | Can be slower; depends on engine |
| Redundancy | Higher in dimensions | Lower in dimensions |
| Normalization | Dimensional style | Closer to 3NF in branches |

**Interview Tip:** Snowflake is still dimensional modeling—not OLTP 3NF for transactions—usually limited normalization around large repeating hierarchies.

---

## Standard Price: Dimension vs Fact

| Placement | What you store | Good for | Risk |
|-----------|----------------|----------|------|
| `dim_product.standard_list_price` | Reference list price as of dimension row version | Like-for-like shelf comparisons | Drifts from promotional reality |
| `fact_store_sales.unit_net_price` | What customer actually paid | Revenue truth | Not a substitute for list price analytics |
| Both | Dimension for reference, fact for actual | Rich margin stories | Must document which drives KPIs |

Retail example: end-aisle promotions sell below list; margin analysis needs fact price and cost, while planograms reference list or “everyday low price” attributes.

**Watch Out!** Putting volatile promotional price only in the dimension without Type 2 history destroys point-in-time list price reporting.

---

## Roll Up, Roll Down, Drill Up, Drill Down

| Term | Direction | Retail example |
|------|-----------|----------------|
| Roll up | Aggregate to higher level | SKU sales → subcategory → category → department |
| Roll down | Disaggregate (rare; needs atomic data) | Split allocated warehouse costs to SKU (requires rules) |
| Drill down | Navigation in BI from summary to detail | Department revenue → categories → SKUs in a store |
| Drill up | Opposite navigation | From SKU list to category totals |

ASCII drill path:

```
 YEAR --> QUARTER --> MONTH --> DAY --> STORE --> DEPT --> CATEGORY --> SKU
  ^        drill up / roll up direction -->
```

**Interview Tip:** “Drill” is interaction semantics; “roll” is aggregation semantics—many interviewers accept them used interchangeably but precision helps.

---

## When to Normalize Dimensions

| Signal | Lean star | Consider snowflake |
|--------|-----------|---------------------|
| Hierarchy depth | 2–3 levels, stable labels | Many levels, shared nodes |
| Attribute change rate | Rare renames | Frequent category moves |
| Shared entities | Same subcategory reused widely | Many-to-many merchandising structures |
| Query audience | Business self-service | Governed templates with controlled joins |
| Engine | Columnstore favors wide dims | Rowstore with narrow tables can tolerate joins |

**Watch Out!** Over-snowflaking for theoretical purity slows the majority of store-manager dashboards with minimal storage benefit.

---

## SQL Example: Star Join

```sql
SELECT
    p.department,
    p.category,
    SUM(f.quantity) AS units_sold,
    SUM(f.net_sales_amount) AS net_sales
FROM fact_store_sales AS f
JOIN dim_product AS p
  ON f.product_key = p.product_key
WHERE f.sale_date_key BETWEEN 20240101 AND 20241231
GROUP BY
    p.department,
    p.category
ORDER BY
    net_sales DESC;
```

## SQL Example: Snowflake Join

```sql
SELECT
    dpt.department_name,
    cat.category_name,
    SUM(f.quantity) AS units_sold
FROM fact_store_sales AS f
JOIN dim_product AS pr
  ON f.product_key = pr.product_key
JOIN dim_subcategory AS sc
  ON pr.subcategory_key = sc.subcategory_key
JOIN dim_category AS cat
  ON sc.category_key = cat.category_key
JOIN dim_department AS dpt
  ON cat.department_key = dpt.department_key
WHERE f.sale_date_key BETWEEN 20240101 AND 20241231
GROUP BY
    dpt.department_name,
    cat.category_name
ORDER BY
    units_sold DESC;
```

**Interview Tip:** Be ready to say snowflake adds maintainability for hierarchy masters at the cost of query and model complexity.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Mixing master SKU and store SKU keys on facts | Double counting or orphan keys | Conform keys; document keying rules |
| Category rename without SCD strategy | History appears under new label incorrectly | Apply SCD Type 1 vs 2 consciously |
| Snowflaking attributes users always filter together | Extra joins for no normalization win | Keep hot attributes denormalized |
| Storing promo price only in `dim_product` | Misstates historical pricing | Keep prices that change with sales in facts |
| Deep snowflake without surrogate keys | Join explosions, ambiguous rows | Surrogate keys per hierarchy entity |

---

## Key Takeaway

> Keep the product dimension wide enough for intuitive retail reporting, snowflake only where hierarchy integrity and reuse justify extra joins, and always separate reference list attributes from prices actually realized on the fact.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| 1) dim_product = sellable SKU grain; master vs assortment.     |
| 2) Star = dept/category/subcategory denormalized on product.   |
| 3) Snowflake = hierarchy tables chained from dim_product.      |
| 4) List/reference price in dim; actual paid price in fact.     |
| 5) Roll up/down = aggregate levels; drill = BI navigation.      |
| 6) Normalize when hierarchy shared/changing; else stay star.   |
| 7) Surrogate keys on each snowflake level avoid join traps.    |
+------------------------------------------------------------------+
```
