import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const steps = [];
  const stack = [];
  const nge = Array(arr.length).fill(null);
  steps.push({ type: 'init', array: [...arr], stack: [], nge: [...nge], idx: 0 });
  for (let i = 0; i < arr.length; i++) {
    steps.push({ type: 'visit', array: [...arr], stack: [...stack], nge: [...nge], idx: i });
    while (stack.length && arr[stack.at(-1)] < arr[i]) {
      const j = stack.pop();
      nge[j] = arr[i];
      steps.push({ type: 'pop-assign', array: [...arr], stack: [...stack], nge: [...nge], idx: i, assign: j });
    }
    stack.push(i);
    steps.push({ type: 'push', array: [...arr], stack: [...stack], nge: [...nge], idx: i });
  }
  while (stack.length) {
    const j = stack.pop();
    steps.push({ type: 'pop-empty', array: [...arr], stack: [...stack], nge: [...nge], idx: arr.length - 1, assign: j });
  }
  steps.push({ type: 'done', array: [...arr], stack: [], nge: [...nge], idx: -1 });
  return steps;
}

export default function NextGreaterElementVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = [4, 5, 2, 25, 7, 16];
    const steps = generateSteps(arr);
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Next Greater Element (monotonic stack)' });
    canvasRef.current?.setState({
      array: arr,
      colors: {},
      buckets: { Stack: [] },
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.idx >= 0) colors[step.idx] = 'compare';
    (step.stack || []).forEach((si) => {
      colors[si] = 'active';
    });
    if (step.assign != null) colors[step.assign] = 'merge';
    if (step.type === 'done') {
      for (let i = 0; i < step.array.length; i++) colors[i] = 'sorted';
    }
    const stackVals = (step.stack || []).map((i) => step.array[i]);
    store.addLog({
      time: `${store.stepIndex + 1}`,
      type: 'info',
      message: `${step.type} | NGE: [${step.nge.map((v) => (v == null ? '—' : v)).join(', ')}]`,
    });
    store.setArray(step.array);
    canvasRef.current?.setState({
      array: step.array,
      colors,
      buckets: { Stack: stackVals },
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
