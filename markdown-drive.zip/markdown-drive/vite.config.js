import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:3001',
        changeOrigin: true,
      },
    },
  },
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          'viz-bucket': [
            './src/components/algorithms/TokenBucketVisualizer.jsx',
            './src/components/algorithms/TokenBucketCanvas.jsx',
            './src/components/algorithms/LeakyBucketVisualizer.jsx',
            './src/components/algorithms/LeakyBucketCanvas.jsx',
          ],
          'viz-window': [
            './src/components/algorithms/FixedWindowVisualizer.jsx',
            './src/components/algorithms/FixedWindowCanvas.jsx',
            './src/components/algorithms/SlidingLogVisualizer.jsx',
            './src/components/algorithms/SlidingLogCanvas.jsx',
            './src/components/algorithms/SlidingCounterVisualizer.jsx',
            './src/components/algorithms/SlidingCounterCanvas.jsx',
          ],
          'viz-lb': [
            './src/components/algorithms/LeastConnVisualizer.jsx',
            './src/components/algorithms/LeastConnCanvas.jsx',
          ],
          'viz-morris': [
            './src/components/algorithms/MorrisTraversalVisualizer.jsx',
            './src/components/algorithms/MorrisTraversalCanvas.jsx',
          ],
          'notes-app': [
            './src/components/notes/NotesApp.jsx',
            './src/components/notes/FileTreeSidebar.jsx',
            './src/components/notes/NoteEditor.jsx',
            './src/stores/notes-store.js',
          ],
          'tiptap': ['@tiptap/react', '@tiptap/starter-kit', '@tiptap/extension-image', '@tiptap/extension-placeholder', '@tiptap/extension-task-list', '@tiptap/extension-task-item'],
          'excalidraw': ['@excalidraw/excalidraw'],
          'roughjs': ['roughjs'],
          'react-markdown': ['react-markdown', 'remark-gfm'],
          'monaco-editor': ['@monaco-editor/react'],
          'xterm': ['@xterm/xterm', '@xterm/addon-fit', '@xterm/addon-web-links'],
        },
      },
    },
  },
});
