# Database Scaling — Concept

> **Permanent Recall:** Database scaling splits into **replication** (multiple copies for read scaling and HA) and **sharding** (horizontal partitioning for write scaling and storage limits). Replication uses Master-Slave or Master-Master topologies; sharding uses range, hash, or directory strategies. Consistent hashing minimizes rebalancing when adding/removing nodes. Always try read replicas, caching, and federation before sharding—it's the last resort.

---

## Replication Overview

**Replication** creates copies of data across multiple nodes for read scaling, high availability (HA), and disaster recovery (DR). Writes go to one or more masters; reads can be served from replicas.

```
                    REPLICATION TOPOLOGY (Master-Slave)

                    ┌─────────────┐
                    │   MASTER    │  ← All writes
                    │  (Primary)  │
                    └──────┬──────┘
                           │
          ┌────────────────┼────────────────┐
          │                │                │
          ▼                ▼                ▼
    ┌──────────┐    ┌──────────┐    ┌──────────┐
    │ SLAVE 1  │    │ SLAVE 2  │    │ SLAVE 3  │  ← Reads
    │ (Replica)│    │ (Replica)│    │ (Replica)│
    └──────────┘    └──────────┘    └──────────┘
```

---

## Master-Slave (Primary-Replica) vs Master-Master

| Topology | Writes | Reads | Pros | Cons |
|----------|--------|-------|------|------|
| **Master-Slave** | Single master | All replicas | Simple, no write conflicts | Single point of failure for writes |
| **Master-Master** | Any master | Any node | Write HA, multi-DC | Conflicts, split-brain risk |

> **FAANG Tip:** Master-Slave is the default. Use Master-Master only when you need writes from multiple regions with careful conflict resolution.

---

## Synchronous vs Asynchronous Replication

| Mode | How It Works | Pros | Cons |
|------|--------------|------|------|
| **Synchronous** | Wait for replica ack before commit | Strong consistency | Higher write latency; one slow replica blocks |
| **Asynchronous** | Commit then replicate in background | Low write latency | Replication lag; possible data loss on failover |

```
SYNC:  Client → Master write → Replica ack → Master commit → Client ack
ASYNC: Client → Master write → Master commit → Client ack
                      ↓
              (background replicate)
```

**Comparison:** Use sync when consistency is critical (e.g., financial); async for read scaling with eventual consistency.

---

## Sharding / Partitioning

**Sharding** (horizontal partitioning) splits data across multiple databases. Each shard holds a subset of rows; together they form the full dataset.

```
                    SHARDING ARCHITECTURE

    ┌─────────────────────────────────────────────────────────┐
    │                    Application                           │
    └─────────────────────────┬───────────────────────────────┘
                              │
                    ┌─────────┴─────────┐
                    │   Shard Router    │  hash(key) → shard_id
                    └─────────┬─────────┘
          ┌───────────────────┼───────────────────┐
          ▼                   ▼                   ▼
    ┌──────────┐        ┌──────────┐        ┌──────────┐
    │ Shard 0   │        │ Shard 1   │        │ Shard 2   │
    │ user_id   │        │ user_id   │        │ user_id   │
    │ 0-333M    │        │ 333M-666M │        │ 666M-1B   │
    └──────────┘        └──────────┘        └──────────┘
```

| Type | Description | Use Case |
|------|-------------|----------|
| **Horizontal** | Split rows across shards by key | Scale storage and write throughput |
| **Vertical** | Split columns/tables (e.g., user vs orders) | Different access patterns |

---

## Sharding Strategies

| Strategy | How It Works | Pros | Cons |
|----------|--------------|------|------|
| **Range-based** | Partition by key range (e.g., A–M, N–Z) | Range queries easy | Hot spots; uneven distribution |
| **Hash-based** | `hash(key) % N` → shard | Even distribution | Range queries need all shards |
| **Directory-based** | Lookup table maps key → shard | Flexible, easy to move data | Lookup is SPOF; extra hop |
| **Geographic** | Partition by region (e.g., US, EU, APAC) | Low latency, compliance | Cross-region queries expensive |

```
RANGE-BASED:     shard_0: user_id 1-1M   shard_1: 1M-2M   shard_2: 2M-3M
HASH-BASED:      hash(user_id) % 3 → shard_0, 1, or 2
DIRECTORY:       mapping_table: user_id → shard_id
GEOGRAPHIC:      US users → shard_us, EU → shard_eu
```

> **FAANG Tip:** Hash-based is most common for even distribution. Range-based only if range queries are critical.

---

## Consistent Hashing

**Problem:** `hash(key) % N` — adding/removing a node forces ~K/N keys to move (massive rehashing).

**Solution:** Consistent hashing maps keys and nodes to a ring. Key goes to the next node clockwise. Adding a node affects only keys between its neighbors.

```
              CONSISTENT HASH RING

                 ┌─────────────┐
               N1╱               ╲N3
                ╱    ● key K     ╲
               │                  │
                ╲                 ╱
               N2╲               ╱N4
                 └─────────────┘

Key hashes to point on ring → assigned to next node clockwise.
Adding N5: only keys between N4 and N5 move.
```

| Approach | Rehash on node add/remove | Distribution |
|----------|---------------------------|--------------|
| Modulo | ~K/N keys move | Can be uneven |
| Consistent hashing | Only ~K/N keys to new/removed node | Good with virtual nodes |

**Virtual nodes:** Place 150–200 "virtual" nodes per physical node on the ring for smoother distribution.

---

## Connection Pooling

**Connection pooling** reuses DB connections instead of creating new ones per request. Reduces overhead (TCP handshake, auth, context switch).

| Without Pool | With Pool |
|--------------|-----------|
| Each request = new connection | Reuse connections from pool |
| High latency, connection exhaustion | Low latency, limited connections |

> **FAANG Tip:** Always use connection pooling. Default pool size ~10–50 per app instance depending on DB capacity.

---

## Read Replicas

Route read queries to replicas; writes stay on master. Scales read throughput without affecting writes.

```
    Writes                    Reads
       │                         │
       ▼                         ▼
┌──────────┐              ┌──────────┐
│  Master  │──────────────│ Replica 1│
└──────────┘   replicate   ├──────────┤
       │                  │ Replica 2│
       │                  ├──────────┤
       │                  │ Replica 3│
       │                  └──────────┘
```

---

## Database Proxies

**Proxies** (Vitess, ProxySQL, PgBouncer) sit between app and DB: connection pooling, query routing, read/write splitting.

| Proxy | Use Case |
|-------|----------|
| **Vitess** | MySQL scaling, sharding, Kubernetes |
| **ProxySQL** | MySQL connection pooling, read/write split |
| **PgBouncer** | PostgreSQL connection pooling |

---

## Federation / Functional Partitioning

**Federation** splits databases by function/domain (e.g., users DB, orders DB, products DB) rather than by shard key.

| Approach | Example | Pros | Cons |
|----------|---------|------|------|
| **Federation** | users.db, orders.db | Isolate load, independent scale | Cross-DB joins expensive |
| **Sharding** | Same schema, split by key | Scale single domain | Complex routing |

---

## Denormalization for Performance

Store redundant data to avoid joins. Trade-off: **faster reads** vs **write complexity** (multiple places to update).

| When to Denormalize | Example |
|---------------------|---------|
| Read-heavy, join is hotspot | Embed user name in order row |
| Replicas handle consistency | Eventual consistency OK |

---

## NewSQL Databases

**NewSQL** = SQL + horizontal scale + distributed consistency. Examples:

| Database | Key Feature | Use Case |
|----------|-------------|----------|
| **CockroachDB** | Geo-distributed, SQL, strong consistency | Multi-region, need SQL |
| **TiDB** | MySQL-compatible, HTAP | Scale MySQL, analytics |
| **Spanner** | Global scale, strong consistency, TrueTime | Google-scale, financial |

> **FAANG Tip:** NewSQL can eliminate custom sharding for many workloads. Consider before building sharding from scratch.

---

## 30-SECOND REVISION BOX

```
REPLICATION: Master-Slave (default), Master-Master (multi-write)
SYNC vs ASYNC: Sync = consistent, slow | Async = fast, lag
SHARDING: Range (hot spots), Hash (even), Directory (flexible), Geo (latency)
CONSISTENT HASHING: Ring, virtual nodes 150–200, minimal rehash
READ REPLICAS: Scale reads, replication lag risk
PROXY: Vitess, ProxySQL, PgBouncer — pooling, routing
FEDERATION: Split by domain (users, orders)
DENORMALIZE: Faster reads, complex writes
NEWSQL: CockroachDB, TiDB, Spanner — built-in scaling
```

---

**Next: [[02_Mental-Model]]**
