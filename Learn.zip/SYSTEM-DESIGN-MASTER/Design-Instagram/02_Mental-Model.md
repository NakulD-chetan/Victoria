# Design Instagram — Mental Model

> **Permanent Recall:** Instagram = **"Photo gallery at billion scale."** Upload once, view millions of times → optimize for **reads** and **CDN delivery**. Unlike Twitter, the bottleneck is **media storage and delivery**, not just the social graph.

---

## Core Challenges

1. **Efficient media storage and delivery** — Photos/videos are large; must serve globally with low latency via **CDN**
2. **News feed generation at scale** — Similar to Twitter (fan-out), but feeds are **media-heavy** (thumbnails, multiple resolutions)
3. **Media-centric vs text-centric** — Storage costs dominate; need **compression**, multiple resolutions, lazy loading

---

## Instagram vs Twitter

| Aspect | Twitter | Instagram |
|--------|---------|-----------|
| **Content type** | Text (280 chars) | Photos, videos (MB each) |
| **Storage** | Minimal | Dominant (200TB/day) |
| **Optimization** | Fan-out, timeline cache | CDN, S3, image pipeline, thumbnails |
| **Discovery** | Hashtags, trends | Explore, visual discovery, stories |
| **Ephemeral** | None | Stories (24h TTL) |

> **FAANG Tip:** The interviewer expects you to differentiate Instagram from Twitter — media handling is the key differentiator.

---

## Mental Model: "Photo Gallery"

```
Upload once  ──►  Store in S3  ──►  Process (resize, thumbnails)  ──►  CDN
                     │
                     └──►  View millions of times (optimize here)
```

- **Write path:** Client → Upload Service → Object Storage (S3) → Async processing → CDN
- **Read path:** Metadata from DB/cache → Media URLs from CDN (edge)

---

## Decomposition

| Component | Responsibility |
|-----------|----------------|
| **Upload pipeline** | Accept media, store in S3, trigger processing, write metadata |
| **Feed generation** | Fan-out (push) or pull; timeline cache (Redis); media URLs |
| **Media storage/CDN** | S3 (origin), CDN for global delivery; multiple resolutions |
| **Explore/Discovery** | Recommendation engine (collaborative filtering, content-based) |
| **Stories** | Ephemeral storage; TTL-based expiry; separate from permanent posts |

---

## Decomposition Diagram

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Upload Flow   │     │  Feed Pipeline  │     │  Media + CDN    │
│  (write-heavy)  │     │  (read-heavy)   │     │  (delivery)     │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         ▼                       ▼                       ▼
    S3 + Processing         Redis Timeline          CloudFront/CDN
         │                       │                       │
         └──────────────────────┴───────────────────────┘
                              Metadata DB
```

---

## "Optimize for Reads" Rule

- Store **multiple resolutions**: thumbnail (150px), medium (640px), full (1080px+)
- **CDN** for all static media — never serve images from origin to end users
- **Lazy load** — feed shows thumbnails first, full image on tap
- **Async processing** — never block upload on resize/filter

---

## Why This Mental Model Works

- **Upload path** is write-heavy but low QPS (~1K/s) — can afford async, queue-based design
- **Read path** is 100× — must be cached, CDN-served, pre-computed where possible
- **Stories** are a separate concern — ephemeral, different access patterns, TTL-driven cleanup
- **Explore** is read-only discovery — batch compute, cache per user

---

## Key Decisions Derived

1. **Object storage** → S3 (cheap, scalable, good for blobs)
2. **CDN** → Mandatory for media (low latency, offload origin)
3. **Multiple resolutions** → Bandwidth and UX optimization
4. **Fan-out** → Fast reads; hybrid for scale (celebrities)
5. **Stories** → Ephemeral store or lifecycle policy

---

## Data Flow Summary

```
WRITE:  User posts → S3 (raw) → Queue → Worker → Resize/Filter → S3 (processed) → CDN URLs → DB
        User follows → DB → (if fan-out) → Redis timelines of followers

READ:   User opens feed → Redis (timeline) → Post IDs → DB/Cache (metadata) → CDN URLs → Client
        User opens photo → CDN URL (direct) → No origin hit
```

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| Fan-out on write | Fast reads, slow writes for celebs → hybrid |
| Multiple resolutions | More storage, less bandwidth → net win |
| Async processing | Eventual consistency for "processing" state → acceptable |
| CDN everywhere | Cost of CDN vs origin load → CDN wins at scale |

---

## What Makes Instagram Hard

- **Storage volume** — 200TB/day is enormous
- **Media diversity** — Photos, videos, stories, different lifecycles
- **Discovery** — Explore needs good recommendations
- **Global** — Must work well in all regions (CDN, regional DBs)

---

## Component Priorities

1. **Media pipeline** — Without it, nothing works; highest priority
2. **Feed** — Core engagement; second
3. **CDN** — Enabler for both; design early
4. **Explore** — Growth driver; can be v2
5. **Stories** — Engagement; can be v2

---

## Mental Model Summary

```
Think: Netflix (media delivery) + Twitter (feed) + Pinterest (discovery)
Not:  Just another social app
```
