# Prefix Sum — Tricks and Recognition

> **Keyword triggers, hidden prefix sum problems, and decision frameworks.** How to recognize when to use prefix sum vs alternatives.

---

## Keyword Triggers

| Phrase | Implication |
|--------|-------------|
| "Subarray sum" | Prefix sum or prefix + hash map |
| "Range sum query" | 1D or 2D prefix sum |
| "Count subarrays with sum K" | Prefix + hash map |
| "Maximum/minimum subarray sum" | Kadane's (DP) or prefix + min/max tracking |
| "Matrix block sum" / "region sum" | 2D prefix sum |
| "Subarray XOR" | Prefix XOR |
| "Range update, point query" | Difference array |
| "Number of subarrays where..." | Often prefix + map or prefix + binary search |

---

## Hidden Prefix Sum Problems

### 1. "Find longest subarray with sum ≤ K"
- **Not sliding window** if negatives (window can grow when shrinking).
- **Prefix + binary search** or **prefix + sorted structure** (e.g., TreeMap in Java).
- For each j, find smallest i where prefix[i] ≥ prefix[j] - K. Longest = j - i.

### 2. "Count subarrays with sum in [L, R]"
- **Prefix + map** for "= K" gives count for exact K.
- **Trick:** count(≤ R) - count(≤ L-1). Use prefix + sorted structure (multiset, TreeMap) or merge sort (count inversion-style).

### 3. "Maximum sum subarray of size K"
- **Fixed sliding window** — but it's also "range sum of length K" = prefix[i+K]-prefix[i]. Same idea.

### 4. "Product of subarray" / "XOR of subarray"
- **Prefix product** (watch for zeros — breaks multiplicative inverse).
- **Prefix XOR** — same as sum: xor(i..j) = prefix[j+1] ^ prefix[i].

### 5. "Minimum operations to make array sum divisible by K"
- **Prefix sum mod K.** Track remainders. Pairs (i,j) with same remainder → sum(i..j) divisible by K.

---

## Prefix Sum + Binary Search Combo

**Pattern:** "Longest subarray with sum ≤ K" (with negatives).

```
For each end j, we want smallest i where prefix[i] ≥ prefix[j] - K.
prefix[j] - prefix[i] ≤ K  ⇒  prefix[i] ≥ prefix[j] - K

Store prefix values in sorted order. For each j, binary search for
smallest i with prefix[i] ≥ prefix[j] - K.
```

**Use case:** When sliding window fails (negatives), prefix + binary search or prefix + TreeMap gives O(n log n).

---

## Prefix Sum vs Sliding Window Decision

| Criterion | Prefix Sum | Sliding Window |
|-----------|------------|----------------|
| "Subarray sum = K" | ✅ Always works | ❌ Fails with negatives |
| "Shortest subarray sum ≥ K" | ✅ With deque (monotonic) | ✅ If non-negative only |
| "Longest subarray sum ≤ K" | ✅ Prefix + BS/TreeMap | ✅ If non-negative |
| "Count subarrays" | ✅ Prefix + map | ❌ Not natural |
| "Range query" | ✅ O(1) per query | ❌ N/A |
| Negatives present | ✅ Works | ❌ Unreliable for sum |
| Non-negative only | ✅ Works | ✅ Often simpler |

**Golden rule:** If **negatives** or **count subarrays** → prefix sum. If **non-negative** and **optimize length** → sliding window may be simpler.

---

## "Exactly K" Decomposition with Prefix Sum

**Problem:** Count subarrays with **exactly** K odd numbers (or exactly K distinct, etc.).

**Trick:** exactly(K) = atMost(K) - atMost(K-1)

- **atMost(K):** Count subarrays with ≤ K odd numbers. Use two pointers or prefix of "count of odds" + structure.
- **Prefix angle:** Prefix of 0/1 (odd=1). Count subarrays with sum in [0,K] minus [0,K-1] = exactly K.

**Same idea as:** Subarrays with K Different Integers (LC 992) — atMost(k) - atMost(k-1).

---

## Prefix Sum Variants

| Variant | Operation | Identity | Use Case |
|---------|------------|----------|----------|
| Prefix Sum | + | 0 | Range sum |
| Prefix XOR | ^ | 0 | XOR subarrays (x^x=0) |
| Prefix Product | * | 1 | Product subarrays (watch zeros) |
| Prefix Mod | % K | — | Divisibility, remainders |
| Difference Array | + (inverse) | — | Range add updates |

---

## Recognition Flowchart

```mermaid
flowchart TD
    A["Subarray / Range" problem?]
    B{"Sum / XOR" or "Count / Query"?}
    C["Sum / XOR"]
    D["Count / Query"]
    E{"Exact K" or "Range" or "Many queries?"}
    F[Prefix + Map]
    G[Prefix build]
    H[Prefix build]

    A --> B
    B --> C
    B --> D
    C --> E
    D --> H
    E -->|Exact K| F
    E -->|Range| G
    E -->|Many queries?| H

    style A fill:#ffd43b,color:#000
    style B fill:#ffd43b,color:#000
    style E fill:#ffd43b,color:#000
    style F fill:#51cf66,color:#fff
    style G fill:#51cf66,color:#fff
    style H fill:#51cf66,color:#fff
```

<details><summary>ASCII fallback</summary>

```
                    "Subarray / Range" problem?
                            |
                    +------+------+
                    |             |
              "Sum / XOR"    "Count / Query"
                    |             |
              +-----+-----+       |
              |           |      |
         "Exact K"   "Range"   "Many queries?"
              |           |      |
         Prefix +    Prefix   Prefix
           Map       build    build
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
TRIGGERS:       "subarray sum", "range query", "count subarrays"
HIDDEN:         Mod K → remainders; XOR → prefix XOR; product → prefix product
PREFIX + BS:    Longest subarray sum ≤ K with negatives
VS WINDOW:      Negatives or count → prefix; non-neg + length → window
EXACTLY K:      atMost(K) - atMost(K-1)
VARIANTS:       Sum(+), XOR(^), Product(*), Mod(%), Difference(inverse)
```
