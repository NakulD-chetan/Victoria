# Linked List — Interview Thinking

> **Permanent Recall:** Identify by "pointer manipulation" or "in-place." Justify approach by stating time/space. When pushed: "dummy head eliminates edge cases." Linked list vs array: "Do we need O(1) insert or O(1) access?"

---

## How to Identify Linked List Problems

### Keyword Triggers

| Phrase | Likely Pattern |
|--------|----------------|
| "Reverse a list" | Three-pointer reversal |
| "Detect cycle" / "loop" | Fast & slow pointers |
| "Find middle" | Fast & slow |
| "Merge sorted" | Dummy head + compare |
| "Remove from end" | Two pointers with gap |
| "Palindrome list" | Middle + reverse + compare |
| "Reorder" / "rearrange nodes" | Composite (middle + reverse + merge) |
| "Copy with random pointer" | HashMap or interleaving |
| "Flatten" | Recursion or iteration with merge |
| "Intersection point" | Length diff + walk together |

### Structural Triggers

- **Given a `ListNode` head** — obviously linked list
- **"In-place" with O(1) space** — pointer manipulation (no extra array)
- **"Without extra memory"** — in-place linked list operations
- **Sequential access only** — no random indexing

### Red Flags (Might Not Be Pure Linked List)

- "Sort the linked list" — merge sort (not comparison-based tricks)
- "Find kth element" — might need heap or two-pass
- "LRU Cache" — linked list + hashmap combo

---

## How to Approach Any Linked List Problem

### The 4-Step Framework

```
Step 1: DRAW IT
  - Sketch the list: boxes and arrows
  - Mark head, tail, any special nodes
  - Draw the desired output

Step 2: IDENTIFY THE PATTERN
  - Reversal? → prev/curr/next
  - Two-pointer? → fast/slow or gap
  - Merge? → dummy head
  - Composite? → break into sub-problems

Step 3: EDGE CASES FIRST
  - Empty list (head = null)
  - Single node
  - Two nodes
  - What if head changes?

Step 4: CODE WITH DUMMY
  - Start with dummy = ListNode(0, head)
  - Process nodes
  - Return dummy.next
```

---

## How to Justify Your Approach

### The 30-Second Pitch

> "I'll use a dummy head to avoid special-casing head operations. Then I'll [reverse / use two pointers / merge] which gives O(n) time and O(1) space."

### Response Framework

1. **State the technique:** "This is a fast-slow pointer problem."
2. **Give complexity:** "O(n) time, O(1) space."
3. **Justify dummy:** "Dummy head handles edge cases cleanly."
4. **Mention edge cases:** "I'll handle empty list and single node."

### Sample Dialogue

**Interviewer:** "Find if a linked list is a palindrome. O(1) space."

**You:** "I'll find the middle using fast-slow pointers, reverse the second half in-place, then compare both halves. O(n) time, O(1) space. After comparison I can restore the list if needed."

**Interviewer:** "Why not use a stack?"

**You:** "A stack gives O(n) space. The in-place approach is better for the constraint. But stack is simpler to implement if space isn't a concern — good trade-off to mention."

---

## Linked List vs Array Discussion

| Question to Ask | If Yes → | If No → |
|-----------------|----------|---------|
| Need random access? | Array | Linked List OK |
| Frequent insert/delete at front? | Linked List | Array |
| Fixed size, cache perf matters? | Array | Linked List OK |
| Need to split/merge efficiently? | Linked List | Array |
| Memory overhead a concern? | Array (no pointer overhead) | Either |

### Decision Tree

```
                    ┌────────────────────┐
                    │  Sequential data   │
                    └─────────┬──────────┘
                              │
               ┌──────────────┴──────────────┐
               │                             │
      "Need index access?"          "Frequent insert/delete?"
               │                             │
               ▼                             ▼
            ARRAY                      LINKED LIST
               │                             │
      "Sort? Binary search?"      "In-place O(1) space?"
      "Cache performance?"        "Pointer manipulation"
```

---

## Common Follow-Up Questions & Answers

### "Can you do it in O(1) space?"

→ In-place pointer manipulation. No extra data structures. Classic: palindrome check, reorder list.

### "What about thread safety?"

→ Linked lists are NOT thread-safe by default. Need locks on pointer updates or use lock-free CAS operations.

### "Can you do it recursively?"

→ Yes, but recursion uses O(n) stack space. Mention this trade-off. Iterative is generally preferred for space.

### "How would you test this?"

→ Empty list, single node, two nodes, odd/even length, cycle at head, cycle at tail, no cycle.

---

## What to Say When Stuck

- "Let me draw this out with a small example — 3 or 4 nodes."
- "I think this combines two patterns: first find middle, then reverse."
- "Let me start with a dummy head to handle edge cases, then figure out the main logic."
- "I'll consider: does this problem need two pointers at different speeds or same speed with a gap?"

---

## Complexity Quick Reference

| Problem | Time | Space | Technique |
|---------|------|-------|-----------|
| Reverse | O(n) | O(1) | prev/curr/next |
| Find middle | O(n) | O(1) | Fast/slow |
| Detect cycle | O(n) | O(1) | Fast/slow |
| Merge two sorted | O(n+m) | O(1) | Dummy head |
| Merge K sorted | O(N log k) | O(k) | Heap or D&C |
| Remove nth from end | O(n) | O(1) | Two-pointer gap |
| Palindrome check | O(n) | O(1) | Middle + reverse |
| Reorder list | O(n) | O(1) | Middle + reverse + merge |
| Copy random pointer | O(n) | O(n) or O(1) | HashMap or interleave |

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY: "reverse", "cycle", "merge", "in-place" → linked list
APPROACH: Draw → Pattern → Edge cases → Code with dummy
JUSTIFY: State technique, give O(n)/O(1), mention dummy
vs ARRAY: Index→Array, Insert/Delete→LL, Cache→Array
STUCK: Draw 3-4 nodes, try combining patterns
SPACE: Iterative > Recursive (stack space)
```
