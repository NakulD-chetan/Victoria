# Set Operations — Problem List

> **18 problems in progressive difficulty. 10 MUST-DO highlighted. Covers UNION, UNION ALL, INTERSECT, EXCEPT, unpivot via UNION, and full outer join simulation. Sources: LeetCode, HackerRank, DataLemur.**

---

## 10 MUST-DO Problems (Start Here)


| #   | Problem                              | Platform | Difficulty | Concept Tag        | Why Important                   |
| --- | ------------------------------------ | -------- | ---------- | ------------------ | ------------------------------- |
| 1   | Combine Two Tables                   | LC 175   | Easy       | JOIN baseline      | Foundation before set ops       |
| 2   | Employees With Missing Info          | LC 1965  | Easy       | UNION + filter     | Combine + find gaps             |
| 3   | Rearrange Products Table             | LC 1795  | Easy       | UNION ALL unpivot  | Columns to rows                 |
| 4   | Friend Requests II                   | LC 602   | Medium     | UNION ALL + GROUP  | Combine bidirectional, count    |
| 5   | Bank Account Summary II              | LC 1555  | Medium     | UNION ALL + SUM    | Combine credit/debit streams    |
| 6   | Products Not Ordered                 | Common   | Easy       | EXCEPT             | Simple set difference           |
| 7   | Active Users Not Churned             | Common   | Medium     | EXCEPT             | Set subtraction                 |
| 8   | Common Customers                     | Common   | Easy       | INTERSECT          | Customers in both tables        |
| 9   | Tree Node                            | LC 608   | Medium     | UNION approach     | Alternative: classify via UNION |
| 10  | Actors Who Cooperated Multiple Times | LC 1050  | Easy       | UNION ALL + HAVING | Combine + aggregate             |


---

## Complete 18-Problem Progression

### Easy (Problems 1-7) — Build Foundation


| #   | Problem                        | Platform | Concept                | Key Skill                       |
| --- | ------------------------------ | -------- | ---------------------- | ------------------------------- |
| 1   | Combine Two Tables             | LC 175   | LEFT JOIN              | Baseline: combine with JOIN     |
| 2   | Employees With Missing Info    | LC 1965  | UNION + NULL filter    | Full outer join via UNION       |
| 3   | Rearrange Products Table       | LC 1795  | UNION ALL unpivot      | Three SELECTs for three columns |
| 4   | Products Never Ordered         | Common   | EXCEPT                 | Set difference (or NOT EXISTS)  |
| 5   | Common Customers Across Stores | Common   | INTERSECT              | Find overlap between sets       |
| 6   | Actors Who Cooperated 3+ Times | LC 1050  | UNION ALL approach     | Alternative to GROUP BY         |
| 7   | All Contacts Combined          | Common   | UNION ALL + source tag | Merge with provenance column    |


### Medium (Problems 8-14) — Core Patterns


| #   | Problem                       | Platform | Concept             | Key Skill                         |
| --- | ----------------------------- | -------- | ------------------- | --------------------------------- |
| 8   | Friend Requests II            | LC 602   | UNION ALL normalize | Bidirectional → unidirectional    |
| 9   | Bank Account Summary II       | LC 1555  | UNION ALL + agg     | Credit + debit into single stream |
| 10  | Tree Node                     | LC 608   | UNION approach      | Root/inner/leaf via 3 SELECTs     |
| 11  | Report Contiguous Dates       | LC 1225  | UNION + sort        | Combine succeeded + failed dates  |
| 12  | Active Users Not Churned      | Common   | EXCEPT              | Set difference for retention      |
| 13  | Find New Customers This Month | Common   | EXCEPT              | This month EXCEPT last month      |
| 14  | Symmetric Difference          | Common   | Double EXCEPT       | (A EXCEPT B) UNION (B EXCEPT A)   |


### Hard (Problems 15-18) — Interview Differentiators


| #   | Problem                    | Platform      | Concept            | Key Skill                                |
| --- | -------------------------- | ------------- | ------------------ | ---------------------------------------- |
| 15  | Full Outer Join Simulation | Common        | UNION ALL          | LEFT + RIGHT with dedup                  |
| 16  | Reconcile Two Data Sources | Common        | EXCEPT both ways   | Find mismatches between systems          |
| 17  | Multi-Source Report        | StrataScratch | Complex UNION ALL  | 4+ sources with normalization            |
| 18  | Changelog Detection        | Advanced      | EXCEPT + timestamp | Detect changed records between snapshots |


---

## Problem-by-Problem Strategy Notes

### Problem 3: Rearrange Products Table (LC 1795)

```
Pattern:     UNION ALL unpivot
Approach:    SELECT product_id, 'store1' AS store, store1 AS price WHERE store1 IS NOT NULL
             UNION ALL
             SELECT product_id, 'store2', store2 WHERE store2 IS NOT NULL
             UNION ALL
             SELECT product_id, 'store3', store3 WHERE store3 IS NOT NULL
Key Insight: One SELECT per column, UNION ALL combines into rows
One-liner:   Three SELECTs (one per store column), UNION ALL, filter NULLs.
```

### Problem 8: Friend Requests II (LC 602)

```
Pattern:     UNION ALL to normalize bidirectional data
Approach:    SELECT requester_id AS id, accepter_id AS friend FROM requests
             UNION ALL
             SELECT accepter_id, requester_id FROM requests
             GROUP BY id, COUNT(DISTINCT friend) = total friends
Key Insight: Friendship is bidirectional — UNION ALL both directions
One-liner:   UNION ALL both directions of friendship; count friends per person.
```

### Problem 14: Symmetric Difference

```
Pattern:     Double EXCEPT
Approach:    (SELECT * FROM A EXCEPT SELECT * FROM B)
             UNION ALL
             (SELECT * FROM B EXCEPT SELECT * FROM A)
Key Insight: Symmetric difference = items unique to either set
One-liner:   (A EXCEPT B) UNION ALL (B EXCEPT A) = rows in only one set.
```

---

## Pattern Distribution

```
UNION ALL (combine/unpivot):        8 problems  (3, 6-9, 15, 17, 7)
EXCEPT (set difference):           5 problems  (4, 12-14, 16)
INTERSECT (common elements):       2 problems  (5, 8)
UNION (deduplicated merge):        3 problems  (2, 10-11)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)

- Day 1: LC 175, LC 1965 (join baseline, UNION)
- Day 2: LC 1795, EXCEPT basics (unpivot, set diff)
- Day 3: INTERSECT, UNION ALL with source tags

### Week 2: Core Patterns (Days 4-6)

- Day 4: LC 602 (bidirectional normalization)
- Day 5: LC 1555, LC 608 (account summary, tree node)
- Day 6: Active not churned, new customers (EXCEPT)

### Week 3: Hard + Review (Days 7-8)

- Day 7: Full outer join simulation, reconciliation
- Day 8: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns


| If You Need...            | Use This Pattern Instead/Also                           |
| ------------------------- | ------------------------------------------------------- |
| Correlated anti-join      | Pattern 05 (Subquery/EXISTS) — NOT EXISTS               |
| Unpivot with many columns | Pattern 06 (Pivot/CASE WHEN) — UNION ALL                |
| Combine then deduplicate  | Pattern 12 (Deduplication) — ROW_NUMBER after UNION ALL |
| Fill gaps after EXCEPT    | Pattern 11 (Date Series Fill) — generate missing values |


---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     18 (7 Easy, 7 Medium, 4 Hard)
MUST-DO:            LC 175, 1965, 1795, 602, 1555, 1050, 608
TOP 3 MOST ASKED:   LC 1795 (Unpivot), LC 602 (Friends), LC 1965 (Missing Info)
PATTERN SPLIT:      UNION ALL (8), EXCEPT (5), UNION (3), INTERSECT (2)
STUDY ORDER:        UNION ALL → UNION → EXCEPT → INTERSECT → Combined
KEY INSIGHT:        UNION ALL = fast concat; UNION = concat + dedup; EXCEPT = A-B
INTERVIEW LINE:     "I use UNION ALL for combining without dedup overhead,
                     EXCEPT for clean set difference, and INTERSECT for overlap."
```

---

## 30-SECOND REVISION BOX

```
UNION:         Combine + deduplicate (expensive sort)
UNION ALL:     Combine + keep duplicates (fast, no sort)
INTERSECT:     Only rows in BOTH sets
EXCEPT:        Rows in first set but NOT in second (MINUS in Oracle)
RULES:         Same column count, compatible types, ORDER BY at end
PERFORMANCE:   UNION ALL >> UNION (avoid unnecessary dedup)
UNPIVOT:       One SELECT per column, UNION ALL together
FULL OUTER:    LEFT JOIN UNION ALL unmatched RIGHT JOIN rows
NULL:          NULLs treated as equal in set ops
```

