import { memo } from 'react';
import UserProfileMenu from '../profile/UserProfileMenu';

const NAV_LINKS = [
  { href: '/algorithms', label: 'Algorithms' },
  { href: '/systemdesign', label: 'System Design' },
  { href: '/code', label: 'Code' },
  { href: '/canvas', label: 'Canvas' },
  { href: '/new-canvas', label: 'New Canvas' },
  { href: '/notes', label: 'Notes' },
];

/* Global cross-app events: any sidebar/legacy code can listen and react. */
function dispatchOpenSettings() {
  window.dispatchEvent(new CustomEvent('app:open-settings'));
}
function dispatchOpenHelp() {
  window.dispatchEvent(new CustomEvent('app:open-help'));
}

const AppNavbar = memo(function AppNavbar({ currentPath, theme, onThemeToggle }) {
  const navigate = (href) => {
    window.history.pushState(null, '', href);
    window.dispatchEvent(new PopStateEvent('popstate'));
  };

  return (
    <header className="dc-navbar">
      <div className="dc-navbar__inner">
        <button className="dc-navbar__brand" onClick={() => navigate('/')}>
          <svg width="22" height="22" viewBox="0 0 100 100" fill="none">
            <defs><linearGradient id="navGrad" x1="0.15" y1="0.1" x2="0.85" y2="0.9"><stop offset="0%" stopColor="#6366F1"/><stop offset="100%" stopColor="#10B981"/></linearGradient></defs>
            <path d="M50 10 C50 10 75 40 75 56 C75 70 64 80 50 80 C36 80 25 70 25 56 C25 40 50 10 50 10Z" fill="url(#navGrad)"/>
            <rect x="35" y="52" width="30" height="2.5" rx="1.25" fill="white" opacity="0.9"/><rect x="35" y="60" width="20" height="2.5" rx="1.25" fill="white" opacity="0.6"/>
          </svg>
          <span className="dc-navbar__title">Ink<span style={{ color: 'var(--accent-secondary)' }}>Drop</span></span>
        </button>

        <nav className="dc-navbar__links">
          {NAV_LINKS.map((link) => {
            const isActive = link.href === '/'
              ? currentPath === '/'
              : currentPath.startsWith(link.href);
            return (
              <button
                key={link.href}
                className={`dc-navbar__link ${isActive ? 'dc-navbar__link--active' : ''}`}
                onClick={() => navigate(link.href)}
              >
                {link.label}
              </button>
            );
          })}
        </nav>

        <div className="dc-navbar__actions">
          <button className="dc-navbar__icon-btn" onClick={onThemeToggle} title="Toggle theme" aria-label="Toggle theme">
            {theme === 'dark' ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            )}
          </button>
          <button
            className="dc-navbar__icon-btn"
            onClick={dispatchOpenSettings}
            title="Settings"
            aria-label="Settings"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
          </button>
          <UserProfileMenu
            variant="navbar"
            theme={theme}
            onToggleTheme={onThemeToggle}
            onOpenSettings={dispatchOpenSettings}
            onOpenHelp={dispatchOpenHelp}
          />
        </div>
      </div>
    </header>
  );
});

export default AppNavbar;
