import { create } from 'zustand';

export const useAlgorithmStore = create((set) => ({
  capacity: 10,
  refillRate: 2,
  cost: 1,
  autoRate: 5,
  autoActive: false,
  currentLang: 'python',
  allowed: 0,
  denied: 0,
  total: 0,
  currentStep: null,
  logs: [],
  startTime: typeof performance !== 'undefined' ? performance.now() : 0,

  setCapacity: (v) => set({ capacity: v }),
  setRefillRate: (v) => set({ refillRate: v }),
  setCost: (v) => set({ cost: v }),
  setAutoRate: (v) => set({ autoRate: v }),
  toggleAuto: () => set((s) => ({ autoActive: !s.autoActive })),
  setLang: (lang) => set({ currentLang: lang }),
  recordAllow: () => set((s) => ({ allowed: s.allowed + 1, total: s.total + 1 })),
  recordDeny: () => set((s) => ({ denied: s.denied + 1, total: s.total + 1 })),
  setStep: (step) => set({ currentStep: step }),
  addLog: (entry) => set((s) => ({ logs: [...s.logs.slice(-149), entry] })),
  reset: () => set({
    allowed: 0, denied: 0, total: 0, currentStep: null, logs: [],
    autoActive: false, startTime: performance.now(),
  }),
}));
