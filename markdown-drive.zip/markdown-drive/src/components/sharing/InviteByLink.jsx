import { useMemo, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';

/*
 * InviteByLink — shows existing token-based invites and lets owners
 * create new ones with a chosen role + expiry.
 */

const EXPIRY_OPTIONS = [
  { id: '1d',  label: '1 day',    ms: 24 * 3600 * 1000 },
  { id: '7d',  label: '7 days',   ms: 7 * 24 * 3600 * 1000 },
  { id: '30d', label: '30 days',  ms: 30 * 24 * 3600 * 1000 },
  { id: 'inf', label: 'Never',    ms: null },
];

function inviteUrlFor(token) {
  return `${window.location.origin}/invite/${token}`;
}

export default function InviteByLink({ vaultId, invites, isOwner, onError, onInfo }) {
  const { user } = useAuth();
  const [role, setRole] = useState('viewer');
  const [expiry, setExpiry] = useState('7d');
  const [creating, setCreating] = useState(false);

  const tokenInvites = useMemo(
    () => invites.filter((i) => !i.email).sort((a, b) => new Date(b.created_at) - new Date(a.created_at)),
    [invites],
  );

  const create = async () => {
    setCreating(true);
    onError('');
    onInfo('');
    const opt = EXPIRY_OPTIONS.find((o) => o.id === expiry);
    const expires_at = opt?.ms ? new Date(Date.now() + opt.ms).toISOString() : null;
    const { data, error } = await supabase
      .from('vault_invites')
      .insert({ vault_id: vaultId, role, invited_by: user.id, expires_at })
      .select()
      .single();
    setCreating(false);
    if (error) {
      onError(error.message);
      return;
    }
    try {
      await navigator.clipboard.writeText(inviteUrlFor(data.token));
      onInfo('Link created and copied to clipboard.');
    } catch {
      onInfo('Link created.');
    }
  };

  const revoke = async (id) => {
    const { error } = await supabase.from('vault_invites').update({ status: 'revoked' }).eq('id', id);
    if (error) onError(error.message);
  };

  return (
    <div className="sd-link">
      {isOwner && (
        <div className="sd-link-creator">
          <span className="sd-link-creator__label">New shareable link</span>
          <div className="sd-link-creator__controls">
            <select value={role} onChange={(e) => setRole(e.target.value)} disabled={creating}>
              <option value="viewer">Viewer</option>
              <option value="editor">Editor</option>
            </select>
            <select value={expiry} onChange={(e) => setExpiry(e.target.value)} disabled={creating}>
              {EXPIRY_OPTIONS.map((o) => (
                <option key={o.id} value={o.id}>{o.label}</option>
              ))}
            </select>
            <button onClick={create} disabled={creating}>
              {creating ? 'Creating…' : 'Create link'}
            </button>
          </div>
        </div>
      )}

      <h3 className="sd-section">Active links ({tokenInvites.filter((i) => i.status === 'pending').length})</h3>
      {tokenInvites.length === 0 && <p className="sd-muted">No links yet.</p>}
      <div className="sd-link-list">
        {tokenInvites.map((inv) => {
          const url = inviteUrlFor(inv.token);
          const isActive = inv.status === 'pending'
            && (!inv.expires_at || new Date(inv.expires_at) > new Date());
          return (
            <div className={`sd-link-row${isActive ? '' : ' sd-link-row--inactive'}`} key={inv.id}>
              <div className="sd-link-row__main">
                <input className="sd-link-row__url" value={url} readOnly onFocus={(e) => e.target.select()} />
                <span className="sd-role-pill">{inv.role}</span>
              </div>
              <div className="sd-link-row__meta">
                <span>
                  {inv.status === 'revoked' ? 'Revoked' :
                   inv.expires_at ? `Expires ${new Date(inv.expires_at).toLocaleDateString()}` : 'No expiry'}
                </span>
                <button
                  className="sd-link-btn"
                  onClick={async () => {
                    try { await navigator.clipboard.writeText(url); onInfo('Link copied.'); } catch { /* ignore */ }
                  }}
                >
                  Copy
                </button>
                {isOwner && isActive && (
                  <button className="sd-link-btn sd-link-btn--danger" onClick={() => revoke(inv.id)}>
                    Revoke
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
