# Python Functional Programming Style

> *"map/filter are beautiful — but sometimes comprehension is more readable"* — Pragmatic Python

`map`, `filter`, `functools`, `operator`, pure functions — functional style in Python is an **optional mix**. After [[13-Python-Modules-Packages]], connect tools in functional pipelines.

---

## 1. `map` and `filter`

> **Definition:** `map` applies a function to every element of an iterable and yields results; `filter` keeps only elements for which a predicate returns true.

**Why we need it:** They express “transform all” and “select some” as single higher-order operations, which pairs well with iterators and functional pipelines before comprehensions became idiomatic.

**Syntax:**
```python
map(<callable>, <iterable>)
filter(<predicate>, <iterable>)
```

```python
nums = [1, 2, 3, 4]
list(map(lambda x: x * x, nums))          # [1, 4, 9, 16] → applies function to EACH item
list(filter(lambda x: x % 2 == 0, nums))  # [2, 4] → keeps only items where condition is True
# map = "transform each item"
# filter = "keep only items that pass the test"
```

**Interview Tip:** Often a **list comprehension** is more Pythonic:

```python
[x * x for x in nums]
[x for x in nums if x % 2 == 0]
```

---

## 2. `functools.reduce`

> **Definition:** `reduce` folds an iterable into one value by repeatedly applying a binary function to an accumulator and the next item.

**Why we need it:** Many aggregations (sum, product, merge) are the same pattern; `reduce` captures that pattern as a named operation instead of an ad hoc loop.

**Syntax:**
```python
from functools import reduce
reduce(<binary_fn>, <iterable>[, <initial>])
```

```python
from functools import reduce
import operator

reduce(operator.add, [1, 2, 3, 4], 0)  # 10
# Starts with 0, adds each item one by one: 0+1=1, 1+2=3, 3+3=6, 6+4=10
# reduce = "combine all items into ONE value using a function"
```

**Watch Out!** `reduce` can hurt readability — for simple cases `sum()` or loops are clearer.

---

## 3. `functools.partial`

> **Definition:** `partial` builds a new callable by fixing (binding) some arguments of an existing function ahead of time, so callers pass only the remaining ones.

**Why we need it:** Callbacks and APIs often expect a specific signature; partial lets you adapt a multi-argument function to a simpler one without wrapping it in a custom `lambda` every time.

**Syntax:**
```python
from functools import partial

<new_fn> = partial(<callable>, <fixed_arg>=<value>, ...)
```

```python
from functools import partial

def power(base, exp):
    return base ** exp

square = partial(power, exp=2)   # Creates a NEW function with exp LOCKED to 2
square(5)  # 25 → only need to pass base now (exp is always 2)
# partial = "freeze some arguments, create a simpler version of the function"
```

Useful for callbacks / API fit.

---

## 4. `functools.lru_cache`

> **Definition:** `lru_cache` is a decorator that memoizes a function: it stores recent call results keyed by arguments and returns the cached value on repeat calls.

**Why we need it:** Pure recursive or expensive functions recompute the same subproblems; caching turns exponential work into near-linear time and is the standard interview pattern for DP-style speedups.

**Syntax:**
```python
from functools import lru_cache

@lru_cache(maxsize=<n_or_None>)
def <name>(<args>):
    ...
```

```python
from functools import lru_cache

@lru_cache(maxsize=None)   # CACHES results — if called again with same n, returns stored answer
def fib(n):
    if n < 2:
        return n
    return fib(n - 1) + fib(n - 2)

# Without cache: fib(30) takes VERY long (recalculates same values millions of times)
# With cache: fib(30) is instant (each value calculated only ONCE, then remembered)
# lru_cache = "remember previous results so you don't recalculate"
```

**Interview Tip:** Pure recursive functions — memoization; related to LeetCode DP.

**Watch Out!** Arguments must be **hashable** — a list argument won't work.

---

## 5. `functools.wraps` — decorators

> **Definition:** `wraps` copies metadata (`__name__`, `__doc__`, `__module__`, etc.) from the original function onto a decorator’s wrapper so the wrapped function still looks like itself to introspection and tools.

**Why we need it:** Bare wrapper functions hide the real callable’s identity, breaking docs, debuggers, and decorators that chain; `wraps` preserves the public contract.

**Syntax:**
```python
from functools import wraps

def <decorator>(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        ...
    return wrapper
```

```python
from functools import wraps

def logged(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        print("call", fn.__name__)
        return fn(*args, **kwargs)
    return wrapper
```

Preserves `__name__`, docstring — tooling/debug friendly. [[05-Python-Functions-Scope]] decorators.

---

## 6. `operator` module

> **Definition:** The `operator` module provides efficient C-built callables for basic operations (arithmetic, comparisons) and helpers like `itemgetter` / `attrgetter` for key functions.

**Why we need it:** Passing operations to higher-order functions (`sorted`, `map`) is clearer and often faster than `lambda`; `itemgetter`/`attrgetter` are the idiomatic sort keys.

**Syntax:**
```python
import operator as op
op.itemgetter(<index_or_key>)(<obj>)
op.attrgetter(<attr_name>)(<obj>)
op.methodcaller(<method_name>, *args)(<obj>)
```

```python
import operator as op

pairs = [(1, "a"), (3, "b"), (2, "c")]
sorted(pairs, key=op.itemgetter(0))

data = [{"x": 2}, {"x": 1}]
sorted(data, key=op.itemgetter("x"))
```

| Function | What it does |
|----------|-----|
| `itemgetter(0)` | Gets item by index/key — great as `key=` for sorting tuples/dicts |
| `attrgetter("name")` | Gets attribute by name — great for sorting objects by attribute |
| `methodcaller("upper")` | Calls a method by name — like doing `obj.upper()` |

---

## 7. Pure functions and immutability patterns

> **Definition:** A pure function returns a value that depends only on its inputs and does not mutate external state or I/O; immutability means preferring new values over changing shared objects in place.

**Why we need it:** Predictable functions are easier to test, reason about, and use with concurrency; immutable outputs reduce accidental coupling through shared mutable data.

**Syntax:**
```python
def <name>(<inputs>) -> <new_value>:
    # no global mutation, no I/O — return derived data
    return <expression>
```

**Pure function** — same input → same output, no observable side effects.

```python
def add_tuples(a, b):
    return (a[0] + b[0], a[1] + b[1])
```

Immutability — new tuple instead of mutating a shared list (easier reasoning).

**Interview Tip:** Parallel / concurrent code — immutable data reduces races.

---

## 8. `itertools` + functional

> **Definition:** `itertools` supplies iterator-building blocks (infinite streams, combinatorics, grouping) that compose with `map`, `filter`, and lazy generators for memory-efficient pipelines.

**Why we need it:** Many algorithms are clearer as streams of transformed items; itertools avoids materializing huge lists and pairs naturally with functional style.

**Syntax:**
```python
from itertools import <name>
<iterator> = <itertools_callable>(<iterables_or_args>, ...)
```

```python
from itertools import starmap

list(starmap(pow, [(2, 3), (3, 2), (10, 2)]))
```

---

## 9. Immutability patterns — defensive style

> **Definition:** Defensive immutability means typing and returning immutable containers (like tuples) so callers receive values that cannot be silently mutated in place unless they copy.

**Why we need it:** Shared mutable arguments cause hidden bugs across callers; returning new immutable data makes data flow obvious and pairs well with pure functions and testing.

**Syntax:**
```python
from typing import Tuple

def <name>(items: Tuple[<T>, ...]) -> Tuple[<T>, ...]:
    return tuple(<expression_using_items>)
```

```python
from typing import Tuple

def process(items: Tuple[int, ...]) -> Tuple[int, ...]:
    return tuple(x * 2 for x in items)
```

Tuple return — caller can't mutate inner policy (unless nested mutables).

**Interview Tip:** Pure function + immutable output — easier testing.

---

## 10. `functools.singledispatch` — polymorphic functions

> **Definition:** `singledispatch` builds a single function that dispatches to different implementations based on the type of the first argument (single-dispatch generic function).

**Why we need it:** You get overload-style behavior without a class hierarchy—handy for serializers, printers, and adapters while keeping a single entry point.

**Syntax:**
```python
from functools import singledispatch

@singledispatch
def <name>(arg, ...):
    ...

@<name>.register
def _(arg: <Type>, ...):
    ...
```

```python
from functools import singledispatch

@singledispatch
def show(arg):
    return f"default {arg}"

@show.register
def _(arg: int):
    return f"int {arg}"
```

Type-based dispatch — overload feel without OOP.

---

## 11. `itertools` + functional pipelines

> **Definition:** A functional pipeline chains lazy iterators (often from `itertools`) so each stage transforms or slices a stream without building huge intermediate lists.

**Why we need it:** Large or unbounded sequences stay memory-efficient; you compose small iterator tools instead of nested loops and temporary lists.

**Syntax:**
```python
from itertools import <tool>

<stage> = <tool>(<iterator_or_args>, ...)
<consume> = sum(<stage>)  # or loop, next(), etc.
```

```python
from itertools import islice
first_10 = islice((x * x for x in range(1000)), 10)
sum(first_10)
```

Lazy pipeline — memory friendly.

---

## Quick Memory Card

```
+------------------------------------------+
| MAP / FILTER                              |
| - often comprehension preferred          |
+------------------------------------------+
| REDUCE                                    |
| - functools.reduce + operator            |
+------------------------------------------+
| PARTIAL                                   |
| - freeze arguments                       |
+------------------------------------------+
| LRU_CACHE                                 |
| - memoization                            |
+------------------------------------------+
| WRAPS                                     |
| - decorator metadata                     |
+------------------------------------------+
| OPERATOR                                  |
| - itemgetter / attrgetter keys           |
+------------------------------------------+
| PURE + IMMUTABLE                          |
| - easier testing / concurrency           |
+------------------------------------------+
```

---

*Next: [[15-Python-Concurrency-Async]]*
