# Product Dimension and Snowflake Schema — Practice

> "Normalize for write convenience; denormalize for read clarity—know which side pays the bill."

---

## Quick Recall

**Q: What is a flat product dimension in a star?**  
A: One `dim_product` row with hierarchy attributes denormalized (brand, category, department in the same row).

**Q: What is snowflaking a product hierarchy?**  
A: Splitting brand, category, and subcategory into separate normalized tables linked by keys.

**Q: When might snowflake be acceptable for product?**  
A: Very wide shared hierarchies, many-to-one reuse across large catalogs, or strict master-data ownership per entity.

**Q: Main downside of snowflake for BI?**  
A: More joins, harder ad hoc queries, and more complex security row filters.

**Q: Conformed product dimension meaning?**  
A: Same `product_key` definitions across sales, inventory, and purchasing facts for consistent rollups.

---

## Interview Questions

**1. Model `dim_product` for a marketplace with third-party sellers.**  
Say: Include `seller_key`, `sku`, `marketplace_asin`, attributes for `brand`, `category`, `size`, `color`, `launch_date`, and flags for `is_own_brand` vs `third_party`. Keep hierarchy denormalized unless governance mandates snowflake.

**2. Explain snowflake vs star for a category hierarchy.**  
Say: Star repeats category text on every SKU row—simple joins. Snowflake stores category once and references it—saves space and eases category renames if only `dim_category` is Type 1.

**3. How do you handle private-label products with changing suppliers?**  
Say: Supplier is often a separate dimension or fact attribute; product dimension describes what is sold; contracts may be a bridge or fact.

**4. Rapidly changing product attributes?**  
Say: Offload volatile attributes to mini-dimensions or banding strategies so `dim_product` does not explode in Type 2 rows.

**5. Why conformed product matters for e-commerce KPIs?**  
Say: Gross merchandise value, conversion, and inventory turns must align to the same SKU identity across clickstream, orders, and warehouse tables.

**6. Surrogate key on product when source SKU changes?**  
Say: Surrogate survives business key changes; map natural keys in a reference table with effective dating.

**7. Snowflake impact on aggregate indexes?**  
Say: Fewer wide covering indexes on one table; more join paths—test query plans on your warehouse engine.

---

## Scenario-Based Exercises

**Scenario 1 — Star product dimension DDL sketch**

```sql
CREATE TABLE dw.dim_product (
    product_key           BIGINT PRIMARY KEY,
    sku                   VARCHAR(32) NOT NULL,
    product_name          VARCHAR(200),
    brand_name            VARCHAR(100),
    category_name         VARCHAR(100),
    department_name       VARCHAR(100),
    unit_of_measure       VARCHAR(10),
    standard_cost         NUMERIC(12,2),
    current_record_flag   CHAR(1) DEFAULT 'Y'
);
```

**Scenario 2 — Snowflake outline**  
Tables: `dim_product` (SKU attributes), `dim_brand`, `dim_category` with FKs from product to brand and category.  
**Solution:** Use when brand table is mastered separately and reused across non-product entities; expose a view that joins for analysts who need star simplicity.

**Scenario 3 — Many-to-many color variants**  
One style ID, many SKUs per color/size.  
**Solution:** Grain at SKU in `dim_product`; include `style_key` as an attribute or snowflake `dim_style` if style-level reporting dominates.

**Scenario 4 — Conformance check**  
Inventory and sales use different product IDs.  
**Solution:** Build `xref_product_source` mapping to a conformed `product_key`; reject facts that do not resolve in ETL.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|-------------------|----------------|
| Snowflake "because Kimball allows it" | Misses usability cost | Default star; justify snowflake with constraints |
| Mixing seller SKU and platform SKU | Broken joins | Canonical key + cross-reference |
| Category rename breaks history | Type 1 on text in star | Use SCD2 on hierarchy or outrigger |
| Over-normalizing attributes users filter on | Slow dashboards | Denormalize hot attributes |

---

## One-Liner Answers

- Star schema favors one wide product dimension for simpler retail analytics.
- Snowflake trades join complexity for normalization and shared master entities.
- Conformed product keys align sales, inventory, and web metrics on one catalog spine.
- Rapid changes may require mini-dimensions instead of huge Type 2 product rows.
- Always define canonical SKU versus pack versus case hierarchy explicitly.
- Expose analyst-friendly views even if the physical model is lightly snowflaked.
