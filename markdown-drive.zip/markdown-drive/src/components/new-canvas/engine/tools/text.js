import { uid } from '../../state/types';
import { worldFromClient } from '../coords';
import { screenFromWorld } from '../coords';

/**
 * Text tool — click anywhere to spawn a contenteditable overlay that
 * commits to the scene on blur/escape. We mount the editor ourselves
 * instead of making it React state because a) we need it positioned
 * exactly at a world point, b) it must disappear the moment we commit,
 * and c) we want zero re-render cost on every keystroke.
 */

export const textTool = {
  id: 'text',
  cursor: 'text',

  onPointerDown(ctx, ev) {
    if (ev.button !== 0) return false;
    const { canvasEl, getVp, store } = ctx;
    const vp = getVp();
    const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, vp);
    const opts = store.getState().toolOptions;
    const fontSize = opts.fontSize || 20;
    const color = opts.stroke;

    const editor = document.createElement('div');
    editor.contentEditable = 'true';
    editor.setAttribute('data-nc-text-editor', '1');
    editor.style.position = 'absolute';
    const screen = screenFromWorld(x, y, vp);
    const rect = canvasEl.getBoundingClientRect();
    editor.style.left = `${rect.left + window.scrollX + screen.x}px`;
    editor.style.top = `${rect.top + window.scrollY + screen.y}px`;
    editor.style.font = `${fontSize * vp.zoom}px ui-sans-serif, system-ui, sans-serif`;
    editor.style.color = color;
    editor.style.padding = '0';
    editor.style.margin = '0';
    editor.style.border = 'none';
    editor.style.outline = '2px dashed ' + (color === '#e2e8f0' ? '#60a5fa' : '#2563eb');
    editor.style.background = 'transparent';
    editor.style.minWidth = '1ch';
    editor.style.minHeight = `${fontSize * vp.zoom}px`;
    editor.style.whiteSpace = 'pre-wrap';
    editor.style.zIndex = '9999';
    editor.style.lineHeight = '1.25';
    document.body.appendChild(editor);
    editor.focus();

    let committed = false;
    const commit = () => {
      if (committed) return;
      committed = true;
      const text = editor.innerText || '';
      document.body.removeChild(editor);
      if (text.trim().length === 0) { ctx.markDirty(1); return; }
      // Measure final size using a canvas context so persisted bounds match the render.
      const meas = document.createElement('canvas').getContext('2d');
      meas.font = `${fontSize}px ui-sans-serif, system-ui, sans-serif`;
      const lines = text.split('\n');
      let maxW = 0;
      for (const line of lines) {
        const w = meas.measureText(line).width;
        if (w > maxW) maxW = w;
      }
      const el = {
        id: uid('text'),
        type: 'text',
        x, y,
        w: Math.max(maxW, fontSize),
        h: lines.length * fontSize * 1.25,
        z: 0,
        isDeleted: false,
        text,
        fontSize,
        fontFamily: 'ui-sans-serif, system-ui, sans-serif',
        style: {
          stroke: color,
          fill: 'transparent',
          strokeWidth: 1,
          opacity: opts.opacity ?? 1,
          dash: 'solid',
        },
        createdAt: Date.now(),
      };
      ctx.commit((els) => els.concat([el]));
      ctx.markDirty(2);
    };

    const onBlur = () => commit();
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); commit(); }
      // cmd/ctrl+enter also commits
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); commit(); }
    };
    editor.addEventListener('blur', onBlur);
    editor.addEventListener('keydown', onKey);
    return true;
  },

  onPointerMove() { /* text tool is click-only */ },
  onPointerUp() { /* text tool is click-only */ },
  onCancel() { /* managed by the overlay */ },
};
