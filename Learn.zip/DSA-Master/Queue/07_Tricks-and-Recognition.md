# Queue — Tricks and Recognition

> **Instant pattern recognition. "Level order" → BFS → queue. "Sliding window max" → monotonic deque.**

---

## "Level Order" → BFS → Queue


| Phrase                        | Implication                     | Action                  |
| ----------------------------- | ------------------------------- | ----------------------- |
| "Level order traversal"       | Tree: each level as list        | BFS + level_size        |
| "Level order" (list of lists) | Same                            | BFS with level tracking |
| "Print level by level"        | Same                            | BFS                     |
| "Zigzag level order"          | BFS + reverse every other level | BFS + level % 2         |


```
Level order = BFS = Queue
No exception.
```

---

## "Shortest Path in Unweighted Graph" → BFS


| Phrase                               | Implication                          | Action                      |
| ------------------------------------ | ------------------------------------ | --------------------------- |
| "Shortest path" (unweighted)         | BFS finds it                         | BFS + track distance/parent |
| "Minimum steps"                      | Same                                 | BFS                         |
| "Nearest" / "Closest"                | Expand from source                   | BFS                         |
| "Word ladder"                        | Each word = node, 1-char diff = edge | BFS                         |
| "0/1 Matrix" (distance to nearest 0) | Multi-source BFS                     | BFS from all 0s             |


```
Unweighted + shortest = BFS
Weighted = Dijkstra / Bellman-Ford
```

---

## Monotonic Deque Signals


| Phrase                                   | Implication     | Action                     |
| ---------------------------------------- | --------------- | -------------------------- |
| "Sliding window maximum"                 | O(n) needed     | Monotonic decreasing deque |
| "Sliding window minimum"                 | O(n) needed     | Monotonic increasing deque |
| "Max in every subarray of size k"        | Same            | Monotonic deque            |
| "Longest subarray with..." (with window) | Sometimes deque | Check constraints          |
| "Next greater in window"                 | Deque or stack  | Deque for sliding          |


### When NOT Monotonic Deque


| Phrase                                              | Use Instead                 |
| --------------------------------------------------- | --------------------------- |
| "Next greater element" (entire array, each element) | Monotonic **stack**         |
| "Largest rectangle"                                 | Monotonic **stack**         |
| "Sliding window sum"                                | Prefix sum / simple window  |
| "Sliding window" (no max/min)                       | Two pointers / simple queue |


ASCII fallback

```
                    ┌─────────────────┐
                    │  Need order?    │
                    └────────┬────────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
        OLDEST FIRST                  NEWEST FIRST
              │                             │
              ▼                             ▼
          [ QUEUE ]                     [ STACK ]
              │                             │
    BFS, level order,              DFS, recursion,
    task order                     next greater,
                                   parentheses
```



### Quick Test


| Question                    | Answer            |
| --------------------------- | ----------------- |
| Process in arrival order?   | Queue             |
| Process most recent first?  | Stack             |
| Level by level?             | Queue (BFS)       |
| Depth first?                | Stack (DFS)       |
| Shortest path (unweighted)? | Queue (BFS)       |
| Next greater element?       | Stack (monotonic) |
| Sliding window max/min?     | Deque (monotonic) |


---

## Multi-Source BFS

**Signal:** "Distance from nearest X" (e.g., nearest 0, nearest gate)

```
Instead of: queue = [single_source]
Use:        queue = [all_sources]  (e.g., all 0s)

Same BFS logic. All sources at level 0.
```

---

## 0-1 BFS (Special Case)

**Signal:** Graph with only edge weights 0 and 1. Shortest path.

- Use **deque**
- Weight 0 → push to front
- Weight 1 → push to back
- Ensures we process 0-cost edges first (like Dijkstra but O(V+E))

```
Rare in interviews, but know it exists.
```

---

## Topological Sort (Kahn's) — Queue

**Signal:** "Order tasks with dependencies" / "Course schedule"

- Compute in-degree
- Queue all with in-degree 0
- Process: dequeue, reduce neighbor in-degrees, enqueue if 0
- Order = topological sort

```
Kahn's = BFS on DAG with in-degree tracking
Uses queue.
```

---

## Trick: BFS for "Connected Components" in 2D Grid

```
Grid: 1 = land, 0 = water
"Number of islands" = BFS/DFS from each unvisited 1
```

- Visit each cell
- If 1 and not visited → BFS, mark all connected 1s
- Count BFS calls = number of islands

---

## Trick: Deque for Palindrome Check (Both Ends)

**Signal:** "Check if can form palindrome" / "valid palindrome"

- Deque: popleft and pop from right, compare
- Or: two pointers (no deque needed)
- Deque useful when we need to remove from both ends

---

## Recognition Flowchart

```mermaid
flowchart TD
    START[START]
    START --> A["Level order / BFS / Shortest path unweighted"]
    START --> B["Sliding window + max or min"]
    START --> C["Implement queue using stacks"]
    START --> D["Implement stack using queues"]
    START --> E["Task scheduler / Round robin"]
    START --> F["Next greater single array not sliding"]
    A --> A1[QUEUE BFS]
    B --> B1[MONOTONIC DEQUE]
    C --> C1[TWO STACKS]
    D --> D1[TWO QUEUES rotate]
    E --> E1[QUEUE or math]
    F --> F1[MONOTONIC STACK not deque]
    style A1 fill:#51cf66,color:#fff
    style B1 fill:#51cf66,color:#fff
    style C1 fill:#339af0,color:#fff
    style D1 fill:#339af0,color:#fff
    style E1 fill:#51cf66,color:#fff
    style F1 fill:#e03131,color:#fff
```



ASCII fallback

```
START
  │
  ├─ "Level order" / "BFS" / "Shortest path (unweighted)"
  │     → QUEUE (BFS)
  │
  ├─ "Sliding window" + "max" or "min"
  │     → MONOTONIC DEQUE
  │
  ├─ "Implement queue using stacks"
  │     → TWO STACKS
  │
  ├─ "Implement stack using queues"
  │     → TWO QUEUES (rotate)
  │
  ├─ "Task scheduler" / "Round robin"
  │     → QUEUE (or math)
  │
  └─ "Next greater" (single array, not sliding)
        → MONOTONIC STACK (not deque!)
```



---

## FINAL MEMORY COMPRESSION BLOCK

```
LEVEL ORDER:        → BFS → Queue
SHORTEST (unweight):→ BFS → Queue
WINDOW MAX/MIN:     → Monotonic deque
QUEUE VIA STACKS:   → Two stacks
STACK VIA QUEUES:   → Two queues, rotate
NEXT GREATER:       → Monotonic STACK (not deque)
MULTI-SOURCE:       → BFS from all sources
```

