# Design Twitter/X Feed — Edge Cases

> **Permanent Recall:** Edge cases: **celebrity tweet storm** (100M followers), **tweet deletion propagation**, **real-time feed updates** (WebSocket), **user unfollows during fan-out**, **viral tweet caching**, **timeline ordering with distributed clocks**, **media transcoding failures**. Design for these to show depth.

---

## Celebrity Tweet Storm

**Scenario:** User with 100M followers posts 10 tweets in 1 minute.

| Challenge | Mitigation |
|-----------|------------|
| 100M × 10 = 1B fan-out writes | Don't push—pull on read. Celebrity tweets fetched when user loads feed. |
| All followers loading feed simultaneously | CDN/cache for celebrity recent tweets; `celebrity:{id}:recent` in Redis |
| DB overload for celebrity tweet reads | Cache last 100–500 tweets per celebrity; TTL 5–10 min |
| Thundering herd | Stale-while-revalidate; one request refreshes, others read stale |

> **FAANG Tip:** "We never push for celebrities. Even 1 tweet from them would overwhelm fan-out. Pull + cache is the only way."

---

## Tweet Deletion Propagation

**Scenario:** User deletes a tweet that's already in millions of timelines.

| Approach | Pros | Cons |
|----------|------|------|
| **Remove from all caches** | Consistent | O(followers) work; impractical for celebrity |
| **Soft delete + filter on read** | Simple | Slightly stale; deleted tweet may show briefly |
| **Reverse fan-out** | Eventual consistency | Async; complex; still expensive for celebrities |
| **Tombstone** | Clean | Need to store tombstones, filter on read |

**Recommended:** Soft delete (mark `deleted=true`). On timeline read, filter out deleted. For cache, either: (a) don't remove (eventual—next refresh gets it), or (b) publish delete event, workers remove from cache (skip for celebrities—filter on read).

---

## Real-Time Feed Updates (WebSocket)

**Scenario:** User has feed open; new tweet from followee should appear without refresh.

| Approach | When to use |
|----------|-------------|
| **Polling** | Simple; 5–30 sec interval; higher load |
| **Long polling** | Better than polling; still not true real-time |
| **WebSocket** | Push new tweet IDs to connected clients; client fetches details or subscribes to tweet stream |
| **Server-Sent Events (SSE)** | Simpler than WebSocket; one-way server → client |

**Design:** WebSocket connection per user. When fan-out writes to `timeline:{user_id}`, also push `tweet_id` to user's WebSocket channel. Client prepends to feed. For celebrities, on read we already merge—WebSocket can push "new tweet from celeb X" and client triggers merge or refresh.

---

## User Unfollows During Fan-Out

**Scenario:** User A unfollows B. B's tweet is currently being fanned out. Does A get it?

| Option | Behavior |
|--------|----------|
| **Check at fan-out** | Before each ZADD, check if still following. Extra DB read per follower. |
| **Fan-out uses snapshot** | Fan-out reads followers at start; some may unfollow during. Eventually consistent: A may see B's tweet briefly. |
| **Remove on unfollow** | When A unfollows B, remove B's tweets from A's timeline. Costly for users following many. |
| **Lazy removal** | Don't remove. Next feed load filters out unfollowed. Simpler. |

**Recommended:** Eventual consistency. Snapshot at fan-out; lazy filter on next read. Or: background job to trim unfollowed users' tweets from timeline (lower priority).

---

## Viral Tweet Caching

**Scenario:** One tweet goes viral—millions of users view it (quote tweets, shared links).

| Challenge | Mitigation |
|-----------|------------|
| Same tweet in many timelines | Already in Redis per user—no extra storage for content; tweet metadata stored once |
| Deduplication | Tweet content in separate store; timeline holds tweet_ids only |
| Hot tweet reads | Cache tweet metadata (e.g., `tweet:{id}`) in Redis; CDN for media |
| DB read storm | Ensure tweet fetch is cached; avoid N reads for same tweet |

**Key:** Timeline = list of tweet IDs. Tweet content fetched separately, cached by ID. Viral tweet = one content object, many references.

---

## Timeline Ordering with Distributed Clocks

**Scenario:** Two tweets from different users with "same" timestamp. Order matters for UX.

| Approach | Pros | Cons |
|----------|------|------|
| **Wall clock** | Simple | Clock skew across servers |
| **Logical clock (Lamport)** | Ordering without real time | Doesn't match user expectation |
| **Snowflake IDs** | Globally unique, roughly time-ordered, no coordination | Slight reorder possible within same millisecond |
| **Hybrid** | Use Snowflake as sort key; fallback to timestamp | Best of both |

**Recommended:** Snowflake IDs. 64-bit: timestamp (ms) + worker ID + sequence. Sort timeline by tweet_id (desc) = chronological. Avoids distributed clock sync.

---

## Media Transcoding Failures

**Scenario:** User uploads video; transcoding (to multiple resolutions) fails or times out.

| Failure mode | Mitigation |
|--------------|------------|
| Transcode job fails | Retry with backoff; store original; async retry queue |
| Partial transcoding | Serve available resolution; fallback to original |
| Long transcoding time | Post tweet with "processing" state; poll or WebSocket for "ready" |
| Storage full | Quota per user; reject or archive old media |
| CDN propagate delay | Tweet shows placeholder; swap URL when CDN has it (or use CDN invalidation) |

**Design:** Upload → S3 raw → async job (Lambda/Kafka consumer) → transcode → write to S3 (multiple resolutions) → update tweet with CDN URLs. Tweet is "pending" until at least one resolution ready.

---

## Cold Start: New User or Empty Timeline

**Scenario:** User just signed up or follows nobody. Feed is empty.

| Approach | Implementation |
|----------|----------------|
| **Empty state** | Return empty; show "Who to follow" suggestions |
| **Discovery feed** | Curated/popular tweets; separate service |
| **Onboard followees** | Suggest accounts; once they follow, fan-out populates timeline |

---

## 30-SECOND REVISION BOX

```
CELEBRITY STORM: Pull only; cache celebrity recent tweets
DELETION: Soft delete + filter on read; or reverse fan-out (async)
REAL-TIME: WebSocket; push tweet_id on fan-out
UNFOLLOW: Eventually consistent; lazy filter or snapshot
VIRAL TWEET: Tweet IDs in timeline; content cached once
ORDERING: Snowflake IDs as sort key
TRANSCODING: Async job; retry; fallback to original
```

---

**Next: [[07_Tricks-and-Recognition]]**
