# Union-Find — Common Mistakes

> **Permanent Recall:** Always use path compression + union by rank. Wrong init → wrong components. C++: iota for init. Rust: &mut self. Python: list(range(n)). Language-specific traps in each section.

---

## Core UF Mistakes

### 1. Not Using Path Compression

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| `return parent[x]` without recursion | Forgot to flatten path | `parent[x] = find(parent[x]); return parent[x]` |
| Iterative find without compression | Doesn't update parent pointers | Must update all nodes on path to root |

```
Without:  find can be O(n) per call → O(n²) total
With:     O(α(n)) amortized
```

---

### 2. Not Using Union by Rank

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| Always attach y under x | Degenerate chain possible | Compare rank, attach smaller under larger |
| Forgetting to increment rank | Trees grow unbounded | `if rank[rx]==rank[ry]: rank[rx]++` |

```
Without rank:  Can get chain 0→1→2→3→... → O(n) find
With rank:    Tree stays shallow
```

---

### 3. Wrong Initialization

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| `parent[i] = 0` | All point to 0; wrong | `parent[i] = i` |
| `rank[i] = 1` | Rank should start 0 | `rank[i] = 0` |
| Forgetting rank array | Union by rank broken | Always init rank |

```python
# WRONG
parent = [0] * n   # All point to 0!

# RIGHT
parent = list(range(n))
rank = [0] * n
```

---

### 4. Union Without Finding Roots First

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| `parent[x] = y` | Merges nodes, not components | `parent[find(y)] = find(x)` (or attach by rank) |
| Union(x, y) using x,y directly | May create cycles or wrong structure | Always find roots, union roots |

---

### 5. Off-by-One in Node Indexing

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| n+1 vs n size | 1-indexed nodes in problem | `parent = list(range(n+1))` if 1-indexed |
| 2D grid: r*c vs (r+1)*(c+1) | Grid dimensions | `idx = r * cols + c` for r×c grid |

---

## C++ Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **Wrong vector init** | `vector<int> parent(n, 0)` — all zeros | `vector<int> parent(n); iota(parent.begin(), parent.end(), 0)` |
| **Forgetting iota** | Manual loop or wrong init | `#include <numeric>`, `iota(parent.begin(), parent.end(), 0)` |
| **Passing UF by value** | Copies; modifications lost | Pass by reference `UnionFind& uf` |
| **Integer overflow** | n up to 10^5, usually fine | Use `int` or `long long` as needed |
| **swap vs std::swap** | `swap(rx, ry)` needs `using std::swap` or `std::swap` | `std::swap(rx, ry)` |

```cpp
// WRONG
vector<int> parent(n, 0);  // All zeros!

// RIGHT
vector<int> parent(n);
iota(parent.begin(), parent.end(), 0);
```

---

## Rust Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **find takes &self** | Can't modify parent for path compression | `fn find(&mut self, x: usize)` |
| **Borrow checker in find** | `self.parent[x] = self.find(...)` — mutable borrow | Store in variable: `let p = self.parent[x]; self.parent[p] = self.find(p)` then assign |
| **Actually:** | `self.parent[x] = self.find(self.parent[x])` works — we're not borrowing self twice | Just use `&mut self` |
| **Index type** | Edges may be i32, parent is usize | Cast: `e[0] as usize` |
| **Clone in hot path** | Cloning UF for each query | Use `&mut UnionFind` and pass around |
| **Vec capacity** | `Vec::with_capacity(n)` doesn't fill | Use `(0..n).collect()` for parent |

```rust
// WRONG - find can't compress without &mut
pub fn find(&self, x: usize) -> usize { ... }

// RIGHT
pub fn find(&mut self, x: usize) -> usize {
    if self.parent[x] != x {
        self.parent[x] = self.find(self.parent[x]);
    }
    self.parent[x]
}
```

---

## Python Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **parent = [0]*n** | All zeros; wrong | `parent = list(range(n))` |
| **rank = [1]*n** | Rank starts at 0 | `rank = [0] * n` |
| **Forgetting self.** | Instance vs local variable | `self.parent[x]`, `self.rank[rx]` |
| **Returning find result wrong** | `return x` instead of `return self.parent[x]` | Return root after compression |
| **Mutable default** | `def __init__(self, n, parent=[])` | Never use mutable defaults |
| **0-index vs 1-index** | Problem uses 1..n nodes | `UnionFind(n+1)`, skip index 0 |

```python
# WRONG
parent = [0] * n
rank = [1] * n

# RIGHT
parent = list(range(n))
rank = [0] * n
```

---

## ASCII: Mistake Decision Tree

```
Wrong component count?
  ├─ Check init: parent[i]=i?
  ├─ Check union: finding roots first?
  └─ Check rank: attaching smaller under larger?

TLE?
  ├─ Path compression in find?
  └─ Union by rank?

Wrong cycle detection?
  ├─ Check: find(u)==find(v) BEFORE union
  └─ Undirected graph? (UF doesn't work for directed)

Rust compile error?
  ├─ find needs &mut self
  └─ Cast i32 to usize for indices
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATH COMPRESS:  Must do parent[x]=find(parent[x]) in find
UNION BY RANK:  Attach smaller under larger; increment if equal
INIT:           parent[i]=i, rank[i]=0
UNION:          Find roots first, then union roots
CPP:            iota(parent.begin(), parent.end(), 0)
RUST:           &mut self for find/union
PYTHON:         list(range(n)), not [0]*n
```

---

## 30-SECOND REVISION BOX

```
□ Path compression in find?
□ Union by rank?
□ parent[i]=i, rank[i]=0?
□ Find roots before union?
□ C++: iota for parent init
□ Rust: &mut self
□ Python: list(range(n))
```
