# Quick Revision — Interview Day Cheat Sheet

> **Permanent Recall:** What to remember ON THE DAY. The 4 phases, time allocation, key phrases, "always mention" checklist, what NOT to do, recovery phrases.

---

## The 4 Phases — Time Allocation

| Phase | Time | Focus |
|-------|------|-------|
| **1. Requirements** | 5 min | Clarify scope, constraints, assumptions |
| **2. High-Level** | 10 min | Draw components, API, data flow |
| **3. Deep Dive** | 20 min | 1–2 components, trade-offs, what-ifs |
| **4. Wrap-up** | 5 min | Bottlenecks, monitoring, security |

```
████ Requirements ██████████ High-Level ████████████████████████████████████ Deep Dive █████ Wrap-up
 5 min                  10 min                          20 min                         5 min
```

---

## Key Phrases to Use

| Phase | Opening |
|-------|---------|
| **Requirements** | "Let me start by clarifying requirements before we dive into the design." |
| **Estimation** | "Let me do a quick back-of-envelope estimation first." |
| **Architecture** | "Here's my high-level architecture. We'll have clients hitting a load balancer..." |
| **Deep Dive** | "I'd like to deep-dive into [X] because it's the most critical for this system." |
| **Trade-offs** | "Let me discuss the trade-offs here. Option A gives [pro] but [con]..." |
| **Wrap-up** | "Potential bottlenecks I see: [1], [2]. We'd monitor [metrics]. Future: [improvements]." |

---

## "Always Mention" Checklist

| Item | What to Say |
|------|-------------|
| **Caching** | "We'd cache [hot data] in Redis. Cache-aside. TTL [X]. Invalidation on write." |
| **Monitoring** | "Monitor latency p99, error rate, cache hit ratio, queue depth. Alerts on thresholds." |
| **Security** | "Auth tokens, HTTPS, rate limiting, input validation. Encryption at rest, DDoS." |
| **Failure** | "If [X] fails: redundancy, failover, circuit breaker, graceful degradation." |
| **Scalability** | "Horizontal scaling—add app servers. DB: read replicas, sharding when needed." |

---

## What NOT to Do

| Don't | Do |
|-------|-----|
| Dive into solution first | Clarify requirements first |
| Stay silent while drawing | Narrate your thinking |
| Skip trade-offs | "Trade-off is... I chose because..." |
| Forget monitoring/security | Always in wrap-up |
| Give up when stuck | "Let me think... The core problem is..." |

---

## Recovery Phrases (When Stuck)

| Situation | Say |
|-----------|-----|
| **Don't know** | "I'm not 100% sure, but my intuition is [X]. I'd verify in docs." |
| **Wrong mid-interview** | "Actually, I just realized [flaw]. The fix would be [Y]." |
| **Stuck** | "Let me step back. The core problem is [reframe]. So we need [simplified]." |
| **Time running out** | "We have X minutes—let me prioritize: [mini deep-dive] then wrap-up." |
| **Interruption** | "Good point—let me address that. [Answer]. To finish: [one sentence]." |

---

## Curveball Scripts

| Question | Response |
|----------|----------|
| "Traffic 10x?" | "Bottleneck would be [X]. We'd [scale horizontally/cache more/shard]." |
| "Component fails?" | "Impact: [Y]. Mitigate: [redundancy/failover/circuit breaker]." |
| "Why not [tech]?" | "Trade-off: [pro/con]. For our constraints, [Y] because [reason]." |
| "How to shard?" | "Shard by [key] for even distribution. Consistent hash to minimize rebalance." |

---

## Time Check Phrases

- "We have about [X] minutes left—let me cover wrap-up."
- "I want to make sure we get to monitoring—let me fast-forward through [less critical]."
- "I've spent a lot on [X]. Should I continue or move to [Y]?"

---

## Thinking Out Loud Rule

**Never go silent.** Always verbalize:
- "I'm choosing Redis because we need sub-ms lookups and TTL."
- "We need a queue to decouple write path from read path."
- "Let me calculate: 500M × 10 / 86400 ≈ 60K QPS."

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
