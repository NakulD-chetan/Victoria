import { existsSync } from 'fs';
import { readFile } from 'fs/promises';
import { dirname, resolve } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));

const DEFAULT_CONFIG_PATH = resolve(__dirname, '..', 'localagent', 'config', 'config.ini');
const DEFAULT_OPENROUTER_BASE_URL = 'https://openrouter.ai/api/v1';
const DEFAULT_OPENROUTER_MODEL = 'nex-agi/nex-n2-pro:free';

const PLANNER_SYSTEM_PROMPT = `You are CanvasTeacherPlanner, a planning model for a visual teaching agent.

Your job:
- Read the user's request and the current canvas state.
- Decide the best teaching strategy before any widget is drawn.
- Think in terms of visual explanation, coding practice, architecture, and reusable workspace widgets.
- Prefer a small number of high-value canvas blocks over clutter.

Return JSON only with this shape:
{
  "goal": "short goal",
  "intent": "teach|practice|system_design|data|sql|json|csv|general",
  "plan_summary": "one-sentence summary",
  "layout_strategy": "how widgets should be arranged on canvas",
  "needs_clarification": false,
  "clarification_question": "",
  "steps": [
    {
      "id": "step-1",
      "title": "Explain topic",
      "widget": "note|code|mermaid-diagram|array|tree|linked-list|stack|queue|hash-map|json|csv|sql-pad|progress",
      "purpose": "why this widget helps"
    }
  ]
}

Rules:
- Default to a teacher-style explanation that uses the canvas visually.
- If the user asks for coding practice, include at least one code-oriented step.
- If the user asks for system design, include at least one diagram-oriented step.
- If the canvas already has useful widgets, bias toward reusing or updating them.
- Keep steps concise and practical.`;

const EXECUTOR_SYSTEM_PROMPT = `You are CanvasTeacherAgent, a production-minded teaching agent that turns user requests into visual canvas actions.

Core behavior:
- The canvas is the primary output surface.
- Prefer tool calls over long prose when explaining, practicing, comparing, or demonstrating.
- Use a compact user-facing explanation plus the right tool calls.
- Reuse the user's existing canvas structure when possible by keeping titles stable and semantically matching the current layout.
- If the user asks for coding practice, create an explanation plus a runnable code or SQL workspace.
- If the user asks for architecture or system design, create a note plus a diagram.
- If the user asks for JSON, CSV, SQL, data structures, or flowcharts, choose the most specific tool.

Tool strategy:
- "teach_concept" for explanation notes and summaries.
- "write_code_example" for code practice or demos.
- "draw_flowchart" for architecture, process, and algorithm flow.
- "show_data_structure" for arrays, trees, linked lists, stacks, queues, and hash maps.
- "open_sql_workspace" for SQL workspaces.
- "show_json_viewer" for JSON inspection.
- "show_csv_loader" for CSV inspection.
- "show_progress" for roadmaps, study plans, and multi-step workflows.

Answering rules:
- Do not reveal chain-of-thought.
- Keep visible text short, helpful, and teacher-like.
- When a visual answer is appropriate, call one or more tools in the same response.`;

function parseIniSections(content) {
  const sections = {};
  let current = null;

  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;

    if (line.startsWith('[') && line.endsWith(']')) {
      current = line.slice(1, -1).trim();
      sections[current] = sections[current] || {};
      continue;
    }

    if (!current) continue;
    const equalsIndex = line.indexOf('=');
    if (equalsIndex === -1) continue;

    const key = line.slice(0, equalsIndex).trim();
    const value = line.slice(equalsIndex + 1).trim();
    sections[current][key] = value;
  }

  return sections;
}

function stripTrailingSlash(value) {
  return String(value || '').replace(/\/+$/, '');
}

function parseNumber(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function stripJsonFences(value) {
  const text = String(value || '').trim();
  if (!text.startsWith('```')) return text;
  return text
    .replace(/^```(?:json)?/i, '')
    .replace(/```$/i, '')
    .trim();
}

function normalizeChatContent(message) {
  if (Array.isArray(message?.content)) {
    const parts = message.content
      .map((part) => {
        if (part?.type === 'text') {
          return { type: 'text', text: part.text || '' };
        }
        if (part?.type === 'image_url' && part.image_url?.url) {
          return {
            type: 'image_url',
            image_url: { url: part.image_url.url },
          };
        }
        return null;
      })
      .filter(Boolean);
    return parts.length ? parts : '';
  }

  if (typeof message?.content === 'string') return message.content;
  if (typeof message?.text === 'string') return message.text;
  return '';
}

function normalizeMessages(messages) {
  return (messages || []).map((message) => ({
    role: message?.role === 'assistant' ? 'assistant' : 'user',
    content: normalizeChatContent(message),
  }));
}

function extractMessageText(message) {
  if (!message) return '';
  if (typeof message.content === 'string') return message.content.trim();
  if (Array.isArray(message.content)) {
    return message.content
      .filter((part) => part?.type === 'text' && typeof part.text === 'string')
      .map((part) => part.text)
      .join('\n')
      .trim();
  }
  return '';
}

function extractLatestUserText(messages) {
  for (let index = (messages || []).length - 1; index >= 0; index -= 1) {
    const message = messages[index];
    if (message?.role !== 'user') continue;
    const content = normalizeChatContent(message);
    if (typeof content === 'string' && content.trim()) return content.trim();
    if (Array.isArray(content)) {
      const text = content
        .filter((part) => part?.type === 'text' && typeof part.text === 'string')
        .map((part) => part.text)
        .join('\n')
        .trim();
      if (text) return text;
    }
  }
  return '';
}

function inferIntent(query) {
  const text = query.toLowerCase();
  if (/(system design|architecture|scalab|high level design|hld)/.test(text)) return 'system_design';
  if (/\b(json|api response|payload)\b/.test(text)) return 'json';
  if (/\bcsv\b|spreadsheet|table data/.test(text)) return 'csv';
  if (/\b(sql|mysql|oracle|sqlite|query|database)\b/.test(text)) return 'sql';
  if (/\b(array|tree|linked list|stack|queue|hash map|hashmap)\b/.test(text)) return 'data';
  if (/\b(code|coding|practice|problem|algorithm|leetcode|implement)\b/.test(text)) return 'practice';
  if (/\b(explain|teach|understand|learn|revise)\b/.test(text)) return 'teach';
  return 'general';
}

function heuristicPlan(latestUserText, sceneContext) {
  const intent = inferIntent(latestUserText);
  const widgetInventory = sceneContext?.widgets?.length ? `${sceneContext.widgets.length} widgets already on canvas` : 'blank or mostly blank canvas';
  const steps = [];

  if (intent === 'system_design') {
    steps.push(
      { id: 'step-1', title: 'Design Summary', widget: 'note', purpose: 'Frame the problem and trade-offs.' },
      { id: 'step-2', title: 'Architecture Flow', widget: 'mermaid-diagram', purpose: 'Show the system visually.' },
    );
  } else if (intent === 'practice') {
    steps.push(
      { id: 'step-1', title: 'Practice Framing', widget: 'note', purpose: 'Explain the task and approach.' },
      { id: 'step-2', title: 'Starter Code', widget: 'code', purpose: 'Give a runnable workspace.' },
    );
  } else if (intent === 'sql') {
    steps.push(
      { id: 'step-1', title: 'SQL Workspace', widget: 'sql-pad', purpose: 'Provide a query playground.' },
      { id: 'step-2', title: 'Query Notes', widget: 'note', purpose: 'Explain schema or query intent.' },
    );
  } else if (intent === 'json') {
    steps.push(
      { id: 'step-1', title: 'JSON Viewer', widget: 'json', purpose: 'Inspect the payload visually.' },
      { id: 'step-2', title: 'JSON Notes', widget: 'note', purpose: 'Explain the structure.' },
    );
  } else if (intent === 'csv') {
    steps.push(
      { id: 'step-1', title: 'CSV Loader', widget: 'csv', purpose: 'Inspect rows and columns.' },
      { id: 'step-2', title: 'CSV Notes', widget: 'note', purpose: 'Explain the dataset.' },
    );
  } else if (intent === 'data') {
    steps.push(
      { id: 'step-1', title: 'Data Structure View', widget: 'array', purpose: 'Make the structure visual.' },
      { id: 'step-2', title: 'Concept Notes', widget: 'note', purpose: 'Teach the behavior and operations.' },
    );
  } else {
    steps.push({ id: 'step-1', title: 'Teaching Notes', widget: 'note', purpose: 'Explain the topic clearly.' });
  }

  return {
    goal: latestUserText || 'Help the user on the canvas.',
    intent,
    plan_summary: `Use the ${widgetInventory} and extend it with a teacher-style visual explanation.`,
    layout_strategy: 'Keep the explanation near the center, practical workspaces to the right, and supporting visuals below.',
    needs_clarification: false,
    clarification_question: '',
    steps,
  };
}

function coerceValues(values) {
  if (!Array.isArray(values)) return [];
  return values.map((value) => {
    if (typeof value === 'string') return value;
    if (value == null) return '';
    return String(value);
  });
}

function buildFallbackToolCalls(query, plan) {
  const intent = plan?.intent || inferIntent(query);
  const calls = [];

  if (intent === 'system_design') {
    calls.push(
      {
        name: 'teach_concept',
        args: {
          title: 'System Design Overview',
          text: 'Break the system into clients, APIs, storage, caching, background work, and scale or failure trade-offs.',
        },
      },
      {
        name: 'draw_flowchart',
        args: {
          title: 'Architecture Flow',
          mermaid_code: 'graph TD;\n  Client-->API;\n  API-->Cache;\n  API-->DB;\n  API-->Queue;\n  Queue-->Worker;',
        },
      },
    );
  } else if (intent === 'practice') {
    calls.push(
      {
        name: 'teach_concept',
        args: {
          title: 'Approach',
          text: 'Start with the problem goal, derive the core idea, then test edge cases before coding.',
        },
      },
      {
        name: 'write_code_example',
        args: {
          title: 'Starter Code',
          language: 'cpp',
          code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  ios::sync_with_stdio(false);\n  cin.tie(nullptr);\n  \n  return 0;\n}\n',
        },
      },
    );
  } else if (intent === 'sql') {
    calls.push(
      {
        name: 'open_sql_workspace',
        args: {
          title: 'SQL Workspace',
          dialect: /mysql/.test(query.toLowerCase()) ? 'mysql' : /oracle/.test(query.toLowerCase()) ? 'oracle' : 'sqlite',
          starter_query: 'SELECT 1 AS example;',
        },
      },
    );
  } else if (intent === 'json') {
    calls.push(
      {
        name: 'show_json_viewer',
        args: {
          title: 'JSON Viewer',
          source: '{\n  "message": "Paste JSON here"\n}',
        },
      },
    );
  } else if (intent === 'csv') {
    calls.push(
      {
        name: 'show_csv_loader',
        args: {
          title: 'CSV Loader',
          source: 'name,score\nAda,100\nLinus,98',
          delimiter: 'auto',
        },
      },
    );
  } else if (intent === 'data') {
    const lower = query.toLowerCase();
    let type = 'array';
    if (lower.includes('linked list')) type = 'linked-list';
    else if (lower.includes('stack')) type = 'stack';
    else if (lower.includes('queue')) type = 'queue';
    else if (lower.includes('tree')) type = 'tree';
    else if (lower.includes('hash map') || lower.includes('hashmap')) type = 'hash-map';

    calls.push({
      name: 'show_data_structure',
      args: {
        type,
        title: type.replace(/-/g, ' '),
        values: ['10', '20', '30', '40'],
      },
    });
  } else {
    calls.push({
      name: 'teach_concept',
      args: {
        title: 'Teaching Notes',
        text: 'I will use the canvas to explain this clearly and keep the important ideas visible.',
      },
    });
  }

  return calls;
}

function normalizeToolCalls(rawCalls, tools, query, plan) {
  const allowed = new Set((tools || []).map((tool) => tool.name));
  const cleaned = (rawCalls || [])
    .map((call) => {
      const args = call?.args && typeof call.args === 'object'
        ? call.args
        : safeJsonParse(call?.args, {});
      return {
        name: call?.name || '',
        args: args || {},
      };
    })
    .filter((call) => allowed.has(call.name));

  if (cleaned.length > 0) return cleaned.map((call) => sanitizeToolCall(call));
  return buildFallbackToolCalls(query, plan).map((call) => sanitizeToolCall(call));
}

function sanitizeToolCall(call) {
  const args = { ...(call.args || {}) };

  if (call.name === 'show_data_structure') {
    args.type = args.type || 'array';
    args.title = args.title || 'Data Structure';
    args.values = coerceValues(args.values?.length ? args.values : ['1', '2', '3']);
  }

  if (call.name === 'write_code_example') {
    args.title = args.title || 'Code Example';
    args.language = ['cpp', 'python', 'java', 'javascript'].includes(args.language) ? args.language : 'cpp';
    args.code = typeof args.code === 'string' && args.code.trim()
      ? args.code
      : '// Write code here';
  }

  if (call.name === 'draw_flowchart') {
    args.title = args.title || 'Flowchart';
    args.mermaid_code = typeof args.mermaid_code === 'string' && args.mermaid_code.trim()
      ? args.mermaid_code
      : 'graph TD;\n  A-->B;';
  }

  if (call.name === 'teach_concept') {
    args.title = args.title || 'Explanation';
    args.text = typeof args.text === 'string' && args.text.trim()
      ? args.text
      : 'See the canvas note for the explanation.';
  }

  if (call.name === 'open_sql_workspace') {
    args.title = args.title || 'SQL Workspace';
    args.dialect = ['sqlite', 'mysql', 'oracle'].includes(args.dialect) ? args.dialect : 'sqlite';
    args.starter_query = typeof args.starter_query === 'string' && args.starter_query.trim()
      ? args.starter_query
      : 'SELECT 1 AS example;';
  }

  if (call.name === 'show_json_viewer') {
    args.title = args.title || 'JSON Viewer';
    args.source = typeof args.source === 'string' && args.source.trim()
      ? args.source
      : '{\n  "hello": "world"\n}';
  }

  if (call.name === 'show_csv_loader') {
    args.title = args.title || 'CSV Loader';
    args.source = typeof args.source === 'string' ? args.source : 'name,score\nAda,100';
    args.delimiter = typeof args.delimiter === 'string' ? args.delimiter : 'auto';
  }

  if (call.name === 'show_progress') {
    args.title = args.title || 'Plan';
    args.steps = coerceValues(args.steps?.length ? args.steps : ['Plan', 'Build', 'Review']);
    args.currentStepIndex = Number.isFinite(Number(args.currentStepIndex)) ? Number(args.currentStepIndex) : 0;
  }

  return { name: call.name, args };
}

function parsePlanResponse(text, fallbackPlan) {
  const stripped = stripJsonFences(text);
  const parsed = safeJsonParse(stripped);
  if (parsed && typeof parsed === 'object') {
    return {
      goal: parsed.goal || fallbackPlan.goal,
      intent: parsed.intent || fallbackPlan.intent,
      plan_summary: parsed.plan_summary || fallbackPlan.plan_summary,
      layout_strategy: parsed.layout_strategy || fallbackPlan.layout_strategy,
      needs_clarification: Boolean(parsed.needs_clarification),
      clarification_question: parsed.clarification_question || '',
      steps: Array.isArray(parsed.steps) ? parsed.steps : fallbackPlan.steps,
    };
  }
  return fallbackPlan;
}

function buildSceneContextMessage(sceneContext) {
  if (!sceneContext?.widgets?.length) {
    return 'Current canvas: no reusable widgets yet.';
  }

  const lines = sceneContext.widgets.map((widget) => (
    `- ${widget.type} :: ${widget.title || 'Untitled'} @ (${Math.round(widget.x)}, ${Math.round(widget.y)}) size ${Math.round(widget.w)}x${Math.round(widget.h)}`
  ));

  return `Current canvas widgets:\n${lines.join('\n')}`;
}

async function loadCanvasAgentProvider() {
  const envApiKey = process.env.OPENROUTER_API_KEY?.trim();
  const envBaseUrl = process.env.OPENROUTER_BASE_URL?.trim();
  const envModel = process.env.OPENROUTER_MODEL?.trim();
  const configPath = process.env.CANVAS_AGENT_LOCALAGENT_CONFIG_PATH?.trim() || DEFAULT_CONFIG_PATH;

  let parsed = {};
  if (existsSync(configPath)) {
    const configContents = await readFile(configPath, 'utf8');
    parsed = parseIniSections(configContents);
  }

  const defaultSection = parsed.llm_default || parsed.llm || {};
  const apiKey = envApiKey || defaultSection.api_key || '';
  if (!apiKey) {
    throw new Error('Canvas agent could not find an OpenRouter API key. Set OPENROUTER_API_KEY or configure localagent/config/config.ini.');
  }

  return {
    provider: 'openrouter',
    source: envApiKey ? 'env' : 'localagent/config.ini',
    baseUrl: stripTrailingSlash(envBaseUrl || defaultSection.base_url || DEFAULT_OPENROUTER_BASE_URL),
    apiKey,
    model: envModel || DEFAULT_OPENROUTER_MODEL,
    maxTokens: parseNumber(process.env.OPENROUTER_MAX_TOKENS, parseNumber(defaultSection.max_tokens, 8192)),
    temperature: parseNumber(process.env.OPENROUTER_TEMPERATURE, parseNumber(defaultSection.temperature, 0)),
  };
}

async function callOpenRouterChat({
  provider,
  systemPrompt,
  messages,
  tools,
  responseFormat,
  maxTokens,
  temperature,
}) {
  const payload = {
    model: provider.model,
    messages: [
      { role: 'system', content: systemPrompt },
      ...messages,
    ],
    temperature,
    max_tokens: maxTokens,
  };

  if (Array.isArray(tools) && tools.length > 0) {
    payload.tools = tools.map((tool) => ({
      type: 'function',
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }));
    payload.tool_choice = 'auto';
    payload.parallel_tool_calls = true;
  }

  if (responseFormat) {
    payload.response_format = responseFormat;
  }

  const response = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${provider.apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'http://localhost:5173',
      'X-Title': 'Markdown Drive Canvas Teacher Agent',
    },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(detail || `Canvas agent request failed with ${response.status}`);
  }

  const data = await response.json();
  const choice = data?.choices?.[0];
  const message = choice?.message;
  if (!message) {
    throw new Error('Canvas agent returned an empty response.');
  }

  return {
    message,
    usage: data?.usage || null,
  };
}

async function buildTeacherPlan(provider, messages, sceneContext) {
  const latestUserText = extractLatestUserText(messages);
  const fallbackPlan = heuristicPlan(latestUserText, sceneContext);
  const normalizedMessages = normalizeMessages(messages);
  const plannerMessages = normalizedMessages.concat([
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: `${buildSceneContextMessage(sceneContext)}\n\nReturn JSON only. Build a teacher-style plan for this conversation.`,
        },
      ],
    },
  ]);

  try {
    const planned = await callOpenRouterChat({
      provider,
      systemPrompt: PLANNER_SYSTEM_PROMPT,
      messages: plannerMessages,
      responseFormat: { type: 'json_object' },
      maxTokens: Math.min(provider.maxTokens, 1800),
      temperature: 0,
    });
    return parsePlanResponse(extractMessageText(planned.message), fallbackPlan);
  } catch {
    try {
      const planned = await callOpenRouterChat({
        provider,
        systemPrompt: PLANNER_SYSTEM_PROMPT,
        messages: plannerMessages,
        maxTokens: Math.min(provider.maxTokens, 1800),
        temperature: 0,
      });
      return parsePlanResponse(extractMessageText(planned.message), fallbackPlan);
    } catch {
      return fallbackPlan;
    }
  }
}

export async function getCanvasAgentMeta() {
  const provider = await loadCanvasAgentProvider();
  return {
    provider: provider.provider,
    model: provider.model,
    source: provider.source,
    pipeline: 'planner-plus-tool-executor',
    capabilities: {
      planning: true,
      multimodalInput: true,
      widgetReuse: true,
      voice: false,
    },
  };
}

export async function runCanvasTeacherAgent({ messages, tools, sceneContext }) {
  const provider = await loadCanvasAgentProvider();
  const latestUserText = extractLatestUserText(messages);
  const plan = await buildTeacherPlan(provider, messages, sceneContext);

  const executionMessages = normalizeMessages(messages).concat([
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: [
            buildSceneContextMessage(sceneContext),
            `Teacher plan:\n${JSON.stringify(plan, null, 2)}`,
            'Use the plan above. Reuse matching widget titles when updating the canvas.',
          ].join('\n\n'),
        },
      ],
    },
  ]);

  const result = await callOpenRouterChat({
    provider,
    systemPrompt: EXECUTOR_SYSTEM_PROMPT,
    messages: executionMessages,
    tools,
    maxTokens: Math.min(provider.maxTokens, 3200),
    temperature: provider.temperature,
  });

  const toolCalls = (result.message.tool_calls || []).map((toolCall) => ({
    name: toolCall?.function?.name || '',
    args: safeJsonParse(toolCall?.function?.arguments || '{}', {}),
  }));

  const normalizedToolCalls = normalizeToolCalls(toolCalls, tools, latestUserText, plan);
  const text = extractMessageText(result.message) || plan.plan_summary || 'I updated the canvas.';

  return {
    role: 'assistant',
    text,
    toolCalls: normalizedToolCalls,
    plan,
    meta: {
      provider: provider.provider,
      model: provider.model,
      source: provider.source,
    },
  };
}
