/**
 * Single source of truth for canvas stacking.
 *
 * Why this file exists:
 * Excalidraw composites its scene on `<canvas class="excalidraw__canvas">`.
 * Any sibling with `z-index > 0` that covers the canvas box (even with
 * `pointer-events: none`) is fine *visually* — but pointer-events: auto
 * children still intercept draws. To avoid silent "invisible strokes",
 * every overlay in the canvas tree must use one of the constants below,
 * and interactive children must opt in on the *smallest possible* rect.
 *
 * Layer order (bottom → top):
 *   1. Excalidraw's own <canvas class="excalidraw__canvas">      (library-owned, z: auto / ~1)
 *   2. CANVAS_SCENE_BACKDROP   — anything that must render behind widgets
 *   3. WIDGETS                 — DOM widget shells (compiler / note / array)
 *   4. SNAP_GUIDES             — transient SVG guides (purely visual)
 *   5. Excalidraw's `.layer-ui__wrapper` (z-index: 10 via canvas.css)
 *   6. DS_OVERLAY_UI           — +/- buttons pinned to data-structure groups
 *   7. WIDGET_DRAG_GHOST       — only during a drag preview
 *
 * Rule: widget shells are `pointer-events: none`. Only interactive children
 * (.cw-header, .cw-editor-area, .cw-resize, .aw-panel__body, etc.) set
 * `pointer-events: auto`. Never set auto on a widget *root*.
 */
export const CANVAS_Z = Object.freeze({
  SCENE_BACKDROP: 1,
  WIDGETS: 3,
  SNAP_GUIDES: 4,
  // (Excalidraw's layer-ui is 10 — see canvas.css)
  DS_OVERLAY_UI: 12,
  WIDGET_DRAG_GHOST: 20,
});
