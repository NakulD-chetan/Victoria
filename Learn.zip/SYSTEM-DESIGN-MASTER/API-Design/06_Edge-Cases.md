# API Design — Edge Cases

>

---

## Edge Case 1: Rate Limit Boundary Behavior

**Cause:** Limit resets exactly at boundary; client gets 429 then immediately 200.

**Symptom:** Unfair—one client at boundary gets blocked; another at same moment gets through.

**Mitigation:**


| Approach                    | How                     | Trade-off                     |
| --------------------------- | ----------------------- | ----------------------------- |
| **Sliding window**          | Count in rolling window | Fairer, more memory           |
| **Token bucket**            | Refill gradually        | Allows bursts within capacity |
| **Per-second + per-minute** | Two limits              | Covers burst and sustained    |


> **FAANG Tip:** Return `X-RateLimit-Reset` so clients know when to retry.

---

## Edge Case 2: API Versioning Migration

**Cause:** Need to move clients from v1 to v2 without downtime.

**Symptom:** Some clients on v1, some on v2; must run both; deprecation pressure.

**Mitigation:**

- Run v1 and v2 in parallel
- Sunset notice (6–12 months)
- Metrics: which clients still use v1
- Feature flags to gradually migrate
- Redirect v1 → v2 where possible (if backward compatible)

---

## Edge Case 3: GraphQL N+1 Query Problem

**Cause:** Resolver for `users` fetches one user; resolver for `orders` runs per user → N+1 DB queries.

```
query { users { id, orders { total } } }
→ 1 query users
→ N queries orders (one per user)
```

**Symptom:** Slow response; DB overload.

**Mitigation:**

- **DataLoader:** Batch and cache per-request; coalesce N IDs into one query
- **Eager loading:** Resolver fetches users + orders in one query
- **Limit depth:** Restrict query complexity

---

## Edge Case 4: gRPC in Browser

**Cause:** Browsers don't speak raw gRPC/HTTP2 in the same way.

**Symptom:** Cannot call gRPC directly from browser JavaScript.

**Mitigation:**

- **gRPC-Web:** Proxy translates HTTP/1.1 + JSON to gRPC
- **REST gateway:** Expose REST endpoints that proxy to gRPC internally
- **Use REST/GraphQL for browser:** Keep gRPC for service-to-service

---

## Edge Case 5: Large Payload Handling

**Cause:** Response or request body too large; timeouts, memory issues.

**Symptom:** 504 Gateway Timeout; OOM; slow transfers.

**Mitigation:**

- Pagination for lists
- Streaming for large responses (chunked, SSE)
- Compression (gzip)
- Limit max body size; reject with 413 Payload Too Large
- For uploads: multipart, chunked upload, presigned URLs

---

## Edge Case 6: Timeout Handling

**Cause:** Downstream service slow; request times out; client retries → duplicate or confusion.

**Symptom:** "Did it work or not?"—client uncertain, may retry POST.

**Mitigation:**

- Idempotency-Key for POST
- Return 202 Accepted for long-running; client polls or uses webhook
- Clear timeout values; document expected latency
- Circuit breaker to fail fast when downstream is down

---

## Edge Case 7: Partial Failures in Batch APIs

**Cause:** Batch request: 10 items, 3 fail. What to return?

**Symptom:** Client gets mixed success/failure; unclear what succeeded.

**Mitigation:**

- Option A: All-or-nothing (transaction); any fail → 4xx, no partial commit
- Option B: Partial success; return 207 Multi-Status with per-item results
- Document behavior; idempotency helps for retries

---

## Edge Case 8: CORS Issues

**Cause:** Browser blocks cross-origin requests; API on `api.example.com`, frontend on `app.example.com`.

**Symptom:** CORS error in console; preflight fails.

**Mitigation:**

- Set `Access-Control-Allow-Origin` (specific origins, not `*` for credentials)
- Handle OPTIONS preflight
- For credentials: `Access-Control-Allow-Credentials: true`
- API gateway can add CORS headers

---

## Edge Case 9: API Key Leakage

**Cause:** Key in URL (logged), in client-side code, in public repo.

**Symptom:** Key stolen; abuse; unexpected bill.

**Mitigation:**

- Key in header only (not URL)
- Never in frontend; use backend proxy or OAuth for user auth
- Rotate keys; short-lived tokens (JWT)
- Rate limit per key; monitor usage

---

## Edge Cases Summary Table


| Edge Case           | Cause               | Mitigation                        |
| ------------------- | ------------------- | --------------------------------- |
| Rate limit boundary | Fixed window unfair | Sliding window, token bucket      |
| Version migration   | Run v1 + v2         | Parallel run, sunset, metrics     |
| GraphQL N+1         | Resolver per item   | DataLoader, eager load            |
| gRPC in browser     | No native support   | gRPC-Web, REST gateway            |
| Large payload       | Timeout, OOM        | Pagination, streaming, 413        |
| Timeout             | Unknown outcome     | Idempotency, 202, circuit breaker |
| Batch partial fail  | Mixed results       | All-or-nothing or 207             |
| CORS                | Cross-origin block  | Allow-Origin, preflight           |
| Key leakage         | Key exposed         | Header only, no frontend, rotate  |


---

