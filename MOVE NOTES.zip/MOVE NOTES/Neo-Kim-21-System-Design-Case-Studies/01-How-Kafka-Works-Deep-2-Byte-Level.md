# How Kafka Works — Deep Internals (Every Concept Explained)

> **Permanent Recall:** Kafka is a distributed append-only commit log that achieves millions of messages/second through sequential disk I/O, OS page cache, zero-copy transfers, batching, and compression. Producers batch records and send to partition leaders. Brokers append to immutable log segments on disk, replicate to followers via the same fetch protocol consumers use, and track committed data via the high watermark. Consumers pull data in groups, each partition assigned to exactly one consumer. Exactly-once is achieved through idempotent producer IDs + sequence numbers + transactions. KRaft replaces ZooKeeper for metadata management. The entire design philosophy: treat disk as infinite, RAM as cache, and keep the broker as dumb as possible.

> Companion to: [01-How-Kafka-Works-In-Depth.md](01-How-Kafka-Works-In-Depth.md)

---

## 1. Why Kafka Is Fast — The 6 Secrets

Most people say "Kafka is fast" but can't explain WHY. Here are the 6 real reasons:

### Secret 1: Sequential I/O (Not Random I/O)

```
Traditional Database write:
  "Update row #4532" → disk head jumps to row → updates → jumps back
  "Insert row #9001" → disk head jumps to end → writes
  "Update row #12"   → disk head jumps to row → updates
  Result: Disk head bouncing around = 100-200 writes/second on HDD

Kafka write:
  "Append message" → write at end of file
  "Append message" → write at next position
  "Append message" → write at next position
  Result: Disk head moves in one direction = 600 MB/s on HDD, 2+ GB/s on SSD
```

Kafka ONLY appends to the end of files. It never updates or deletes data in place. This means the disk head never needs to jump around. Sequential I/O on a modern disk is almost as fast as writing to RAM.

### Secret 2: OS Page Cache (Let the OS Do the Caching)

Most systems (Redis, MySQL) maintain their own internal cache. Kafka does NOT. It delegates caching entirely to the operating system's **page cache**.

```
When Kafka "writes to disk":
  1. Kafka calls file.write(data)
  2. OS puts data in page cache (RAM)
  3. OS flushes to physical disk later in background

  So "write to disk" actually = write to RAM. Speed: 2-4 GB/s

When consumer reads recent data:
  1. Consumer asks: "give me offset 5000"
  2. Kafka asks OS for that file region
  3. OS: "I have it in page cache (RAM)!" → returns instantly
  4. Physical disk is NEVER touched

When consumer reads old data:
  1. Consumer asks: "give me offset from 3 days ago"
  2. OS: "not in page cache" → reads from disk
  3. Slower, but still works
```

**Why is this smart?**

- If Kafka cached data in JVM heap, it would be cached TWICE (JVM cache + page cache) — wasting RAM
- JVM garbage collection would cause pauses on large heaps
- Page cache survives broker restarts (data stays cached in OS memory even if Kafka process restarts)

**Golden rule:** Give Kafka brokers LESS JVM heap (4-8 GB), leave MORE RAM for page cache. A 64 GB machine should have ~6 GB JVM heap and ~58 GB for page cache.

### Secret 3: Zero-Copy Transfer

This is Kafka's single most important performance optimization for consumers.

```
NORMAL way to send a file over network (how most apps do it):

  Disk → [copy to Kernel Buffer] → [copy to App Memory] → [copy to Socket Buffer] → NIC
         
  4 data copies, CPU is busy copying bytes around
  Like: Library book → librarian's desk → your hands → photocopy machine → mail

KAFKA's way (zero-copy):

  Disk → [Kernel Page Cache] → NIC
  
  2 copies (both done by hardware DMA, CPU doesn't touch the data)
  Like: Library book → directly into the mail slot. No middlemen.
```

Kafka uses the Linux `sendfile()` system call. It tells the OS: "take this region of this file and send it directly to this network socket." The data goes from disk/page cache straight to the network card. The JVM never sees or touches the actual message bytes.

**Result:** Normal transfer = ~400 MB/s. Zero-copy = ~2.4 GB/s. **6x faster, 60% less CPU.**

**When zero-copy DOESN'T work:**
- TLS/SSL connections (data must be encrypted in application memory first)
- This is why Kafka clusters often use plaintext internally and TLS only for external clients

### Secret 4: Batching (Amortize the Overhead)

Kafka doesn't send messages one at a time. It collects them into **batches**.

```
Without batching:
  Message 1 → network round trip (1ms) → broker writes (0.05ms)
  Message 2 → network round trip (1ms) → broker writes (0.05ms)
  Message 3 → network round trip (1ms) → broker writes (0.05ms)
  1000 messages = 1000 round trips = ~1 second

With batching:
  [Message 1, 2, 3, ... 1000] → ONE network round trip (1ms) → ONE broker write (0.2ms)
  1000 messages = 1 round trip = ~1.2 milliseconds
```

The producer controls batching with two settings:
- **`batch.size`** (default 16 KB): Max size of a batch. When full, send immediately.
- **`linger.ms`** (default 0): How long to wait for more messages before sending. Set to 5ms to collect more messages per batch.

### Secret 5: Compression (Batch-Level)

Kafka compresses the ENTIRE batch of records together, not individual messages.

```
Why batch compression is genius:
  Single message:  {"user_id": 42, "event": "click", "page": "/home"}
  Compressed: barely any savings (no patterns to exploit)

  1000 similar messages compressed together:
  Keys repeat: "user_id", "event", "page" appear 1000 times
  Values have patterns: "/home", "/cart", "/checkout" repeat
  Compressor finds these patterns → 5-7x compression ratio
```

| Algorithm | Compression Ratio | Best For |
|-----------|------------------|----------|
| **zstd**  | 6-7x for JSON    | Best overall (high compression + decent speed) |
| **lz4**   | 3-4x             | Lowest latency (fastest decompress) |
| **gzip**  | 6x               | Legacy, slow — avoid for high throughput |
| **snappy**| 3x               | Deprecated, lz4/zstd are better |

**The broker never decompresses your data.** Producer compresses → broker stores compressed bytes as-is → consumer decompresses. The broker treats message payloads as opaque blobs.

### Secret 6: The Broker Is "Dumb" on Purpose

Kafka pushes complexity to producers and consumers. The broker does very little:

```
What the broker does:
  ✓ Append bytes to a file
  ✓ Send bytes from a file to a socket
  ✓ Replicate bytes to followers
  ✗ Parse or understand your message content — NEVER
  ✗ Track which consumer read what — NEVER (consumers track themselves)
  ✗ Route messages to specific consumers — NEVER (consumers pull)
  ✗ Filter or transform messages — NEVER
```

This is the opposite of traditional message brokers like RabbitMQ where the broker does routing, filtering, acknowledgment tracking, and dead-letter handling. By keeping the broker simple, Kafka can handle millions of messages/second with minimal CPU.

---

## 2. Producer Deep Dive — Everything That Happens Before a Message Reaches Kafka

### The Producer's Internal Architecture

When you call `producer.send(record)`, here's what happens inside the producer library (before anything hits the network):

```
Your Code: producer.send(new Record("orders", key="user-42", value="order placed"))
                |
                ▼
   ┌─────────────────────────┐
   │  1. INTERCEPTORS         │  Optional: modify/log the record before processing
   │     (if configured)      │  Use case: add headers, metrics, tracing
   └────────────┬────────────┘
                ▼
   ┌─────────────────────────┐
   │  2. SERIALIZER           │  Convert key and value from objects to bytes
   │     Key: "user-42" →     │  String → byte[] using configured serializer
   │     Value: Order obj →   │  Could be JSON, Avro, Protobuf, or custom
   └────────────┬────────────┘
                ▼
   ┌─────────────────────────┐
   │  3. PARTITIONER          │  Decide which partition this record goes to
   │     hash(key) % 3 = 1   │  Key present → hash-based (consistent partition)
   │                          │  No key → sticky partitioner (batch-friendly)
   └────────────┬────────────┘
                ▼
   ┌─────────────────────────┐
   │  4. RECORD ACCUMULATOR   │  Buffer that collects records per partition
   │     Partition 0: [...]   │  Each partition has its own batch buffer
   │     Partition 1: [msg]←  │  Records sit here until batch.size or linger.ms
   │     Partition 2: [...]   │  
   └────────────┬────────────┘
                ▼
   ┌─────────────────────────┐
   │  5. SENDER THREAD        │  Background thread that actually sends batches
   │     (separate thread)    │  Picks ready batches → sends ProduceRequest
   │                          │  Handles retries, in-flight requests
   └─────────────────────────┘
```

### The Partitioner — How Kafka Decides Where Your Message Goes

```
DEFAULT PARTITIONER LOGIC:

  if record has a key:
      partition = hash(key) % number_of_partitions
      → Same key ALWAYS goes to same partition
      → Guarantees ordering for that key
      → Example: all events for user-42 go to partition 1

  if record has NO key (Kafka 2.4+, "Sticky Partitioner"):
      → Pick one partition, keep sending to it until the batch is full
      → Then switch to another random partition for the next batch
      → Why? Fills batches faster → fewer, larger batches → better compression
      
  Old behavior for no key (before 2.4):
      → Round-robin: message 1 → P0, message 2 → P1, message 3 → P2
      → Problem: creates many tiny batches → bad for compression and network
```

**IMPORTANT interview point:** If you change the number of partitions after data exists, hash(key) % new_count will route keys to DIFFERENT partitions. All ordering guarantees break. This is why you should plan partition count carefully upfront.

### The `acks` Setting — Your Durability vs Speed Tradeoff

This is one of the most asked Kafka interview questions.

```
acks=0 ("Fire and Forget"):
  Producer sends message → doesn't wait for ANY response
  
  ┌──────────┐    send     ┌────────────┐
  │ Producer  │ ─────────→ │   Leader   │  (might have received it, might not)
  └──────────┘  (no wait)  └────────────┘
  
  Speed: ~0.5ms per batch
  Risk: Messages can be silently lost (network drop, broker crash)
  Use case: Metrics, logs where losing a few records is acceptable


acks=1 ("Leader Only"):
  Producer sends → waits for leader to write to ITS local log → gets ACK
  
  ┌──────────┐    send     ┌────────────┐
  │ Producer  │ ─────────→ │   Leader   │  writes to local log
  │           │ ←───────── │            │  "got it!"
  └──────────┘    ACK      └────────────┘
                           ┌────────────┐
                           │ Follower 1 │  hasn't copied yet...
                           │ Follower 2 │  hasn't copied yet...
                           └────────────┘
  
  Speed: ~2ms per batch
  Risk: If leader crashes BEFORE followers copy it → message lost
  Use case: Good balance for most applications


acks=-1 (or acks=all, "All In-Sync Replicas"):
  Producer sends → leader writes → waits for ALL in-sync followers to write → ACK
  
  ┌──────────┐    send     ┌────────────┐
  │ Producer  │ ─────────→ │   Leader   │  writes to local log
  │           │            │            │
  │           │            │  waits...  │──→ Follower 1 copies ✓
  │           │            │            │──→ Follower 2 copies ✓
  │           │ ←───────── │            │  
  └──────────┘   ACK       └────────────┘  "ALL replicas confirmed!"
  
  Speed: ~5-10ms per batch
  Risk: No data loss (as long as min.insync.replicas is > 1)
  Use case: Financial transactions, orders — anything you can't afford to lose
```

**Critical combo:** `acks=-1` ALONE is not enough. You MUST also set `min.insync.replicas=2`. Why?

```
Scenario: 3 replicas, but 2 followers are dead. ISR = [leader only]
  With acks=-1 but min.insync.replicas=1 (default):
    Leader is the only ISR member
    acks=-1 means "all ISR wrote it" = just the leader
    Leader crashes → DATA LOST (same risk as acks=1!)

  With acks=-1 AND min.insync.replicas=2:
    If ISR < 2 brokers, producer gets NotEnoughReplicasException
    Producer CANNOT write → no false sense of durability
    Data integrity guaranteed: at least 2 brokers always have the data
```

### Producer Retries and Ordering

```
Problem: Producer sends batch A, then batch B. Batch A fails (network timeout).
  Producer retries batch A. Now broker receives: B first, then A.
  → Messages are OUT OF ORDER!

Solution: max.in.flight.requests.per.connection = 1
  Only one batch in flight at a time → retry can't cause reordering
  But this HALVES throughput (can't pipeline requests)

Better Solution (Kafka 0.11+): enable.idempotence = true
  Producer gets a unique ID and uses sequence numbers
  Even with max.in.flight.requests = 5 (default):
    Broker detects "batch A has sequence 5, but I already wrote sequence 6"
    → Broker reorders correctly using sequence numbers
    → Retries are safe AND throughput is maintained
```

### Key Producer Configurations Cheat Sheet

| Config | Default | What It Does | When to Tune |
|--------|---------|-------------|--------------|
| `acks` | `all` (Kafka 3.0+) | Durability guarantee level | acks=1 if you need speed over safety |
| `batch.size` | 16384 (16KB) | Max batch size in bytes | Increase to 64-256KB for throughput |
| `linger.ms` | 0 | Wait time before sending partial batch | Set 5-20ms to fill batches better |
| `compression.type` | none | Compress batches | Use `zstd` or `lz4` almost always |
| `buffer.memory` | 32 MB | Total producer buffer RAM | Increase if producer blocks on full buffer |
| `max.in.flight.requests` | 5 | Pipelined requests per connection | Set to 1 if idempotence off and order matters |
| `enable.idempotence` | true (Kafka 3.0+) | Prevent duplicate writes on retries | Keep true. No reason to disable |
| `retries` | MAX_INT | Number of retry attempts | Default is fine with idempotence |
| `delivery.timeout.ms` | 120000 (2 min) | Total time for send+retries | Increase for unreliable networks |

---

## 3. Broker Deep Dive — What Happens Inside a Kafka Server

### Broker's Thread Architecture

This is how a single Kafka broker handles thousands of concurrent connections:

```
                        Client connections (producers, consumers, other brokers)
                                        │
                                        ▼
                    ┌───────────────────────────────────┐
                    │         ACCEPTOR THREAD (1)        │
                    │   Listens on port 9092             │
                    │   Accepts new TCP connections       │
                    │   Round-robins to network threads   │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼────────────────────┐
                    │      NETWORK THREADS (default 3)   │
                    │   Each handles hundreds of          │
                    │   connections using NIO (non-blocking IO) │
                    │   Reads complete request from socket │
                    │   Puts it on Request Queue           │
                    │   After processing, sends response   │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼────────────────────┐
                    │        REQUEST QUEUE (shared)       │
                    │   Bounded: max 500 queued requests  │
                    │   If full, network threads block    │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼────────────────────┐
                    │       I/O THREADS (default 8)      │
                    │   Do the actual work:               │
                    │   - ProduceRequest → append to log  │
                    │   - FetchRequest → read from log    │
                    │   - MetadataRequest → return info   │
                    │   Put response on Response Queue    │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼────────────────────┐
                    │     RESPONSE QUEUES (per network    │
                    │     thread)                         │
                    │   Network thread picks up response  │
                    │   Sends it back to the client       │
                    └───────────────────────────────────┘
```

**Why Non-Blocking IO (NIO)?**
```
Thread-per-connection model:
  10,000 clients = 10,000 threads = 10 GB RAM just for thread stacks
  Context switching between 10K threads = CPU wasted

NIO model:
  10,000 clients = 3 network threads + 8 I/O threads = 11 threads total
  Each thread uses a "selector" to check which sockets have data ready
  Like a restaurant: 3 waiters can serve 100 tables by checking who needs attention
```

### How a Broker Handles a Produce Request

```
1. Network thread reads bytes from socket → assembles complete request

2. I/O thread picks up the request:
   a. Validates the CRC checksum (detect corrupted data)
   b. Assigns offsets to each record in the batch
      (Producer doesn't know the offset — broker assigns it)
   c. Appends the entire batch to the .log file → goes to page cache (RAM)
      This is ONE sequential write — microseconds
   d. Updates the in-memory offset index
   
3. If acks=0: no response needed. Done.
   If acks=1: send success response immediately.
   If acks=-1: put request in "Purgatory" (wait queue)
      → When all ISR followers have replicated → send success response
      → If timeout expires before replication → send error response
```

**Purgatory** is Kafka's internal mechanism for delayed responses. It efficiently parks thousands of waiting requests without blocking threads.

### How a Broker Handles a Fetch Request (Consumer Read)

```
1. Consumer sends: "Give me data from partition orders-0, starting at offset 5000"

2. I/O thread:
   a. Find which log segment contains offset 5000
      (Segments are sorted by base offset → binary search, nanoseconds)
   
   b. Find exact position in the .log file
      → Check the .index file (memory-mapped, already in RAM)
      → Binary search: "offset 5000 is at byte position 820,456 in the .log"
   
   c. Use zero-copy (sendfile) to stream data from .log to consumer socket
      → If data is in page cache: RAM speed (~2 GB/s)
      → If data is on disk: disk speed (~200 MB/s SSD)

3. Long polling (max.wait.ms):
   If there's no new data for the consumer:
   → Broker DOESN'T return empty response immediately
   → Parks the request, waits up to max.wait.ms (default 500ms)
   → When new data arrives → respond immediately
   → When timeout expires → respond with empty

   Without long polling: consumer polls every 1ms = 1000 requests/sec (waste)
   With long polling: consumer waits up to 500ms = 2 requests/sec when idle
```

---

## 4. Storage Deep Dive — How Kafka Stores Data on Disk

### The Log Segment Structure

Kafka doesn't store a partition as one giant file. It splits it into **segments**.

```
/var/kafka-logs/
  └── orders-0/                              ← Partition directory
      ├── 00000000000000000000.log           ← Segment 1: offsets 0 to 342,155
      ├── 00000000000000000000.index          ← Offset index for segment 1
      ├── 00000000000000000000.timeindex      ← Timestamp index for segment 1
      ├── 00000000000000342156.log           ← Segment 2: offsets 342,156 to 685,000
      ├── 00000000000000342156.index
      ├── 00000000000000342156.timeindex
      ├── 00000000000000685001.log           ← Segment 3: ACTIVE (being written to)
      ├── 00000000000000685001.index
      ├── 00000000000000685001.timeindex
      ├── leader-epoch-checkpoint
      └── partition.metadata
```

**Key facts:**
- Filename = the base offset of the first message in that segment (zero-padded to 20 digits)
- Default segment size = 1 GB (`log.segment.bytes`). When a segment fills up, a new one is created
- Only the LAST (active) segment is written to. All older segments are **immutable**
- Immutable segments can be safely copied, cached, and deleted without coordination

**Why segments instead of one big file?**
```
1. DELETION: To delete old data, just delete old segment files
   (Can't easily delete the middle of a single giant file)

2. COMPACTION: Can compact old segments without affecting active writes

3. MEMORY MAPPING: Smaller files are easier to memory-map efficiently

4. REPLICATION: Can send complete segment files to new followers
```

### The .index File — How Kafka Finds Messages Fast

Kafka needs to quickly answer: "Where in the .log file is offset 5000?"

```
Without an index:
  Start at the beginning of the .log file
  Scan through every record batch until you find offset 5000
  If the file is 1 GB, this could take seconds → unacceptable

With the .index file (sparse index):
  .index stores entries like:
    offset 0     → byte position 0
    offset 500   → byte position 16,246
    offset 1000  → byte position 31,137
    offset 1500  → byte position 47,022
    ...

  To find offset 1234:
    1. Binary search the .index → "offset 1000 is at position 31,137"
    2. Seek to position 31,137 in .log
    3. Scan forward linearly through a few batches until offset 1234
    
  Total time: microseconds
```

**Why sparse (not every offset)?**
- Full index for 1 billion offsets = 8 GB of index data
- Sparse index (one entry every ~4 KB of log data) = ~2 MB
- Binary search on sparse index: max ~18 comparisons
- Then scan through at most 4 KB of log data → microseconds
- The .index file is memory-mapped (loaded into RAM by the OS), so lookups are just pointer reads

### The .timeindex File — Finding Messages by Time

```
.timeindex stores:
  timestamp 1711720790000  → offset 800
  timestamp 1711720850000  → offset 1200
  timestamp 1711720920000  → offset 1600
  ...

Use cases:
  1. consumer.seekToTimestamp("2024-03-29 14:00:00")
     → Binary search .timeindex → find the right offset → seek there
  
  2. Log retention by time ("delete data older than 7 days")
     → Check .timeindex of each segment → if all timestamps are old → delete segment
  
  3. Kafka Streams time-based windows
```

### Log Retention — How Kafka Deletes Old Data

Kafka offers two strategies:

```
STRATEGY 1: Time-based retention (default)
  log.retention.hours = 168 (7 days)
  
  Kafka checks each segment's latest timestamp
  If all messages in a segment are older than 7 days → delete the entire segment file
  
  Note: Kafka deletes WHOLE SEGMENTS, not individual messages
  The active (latest) segment is never deleted, even if some messages in it are old


STRATEGY 2: Size-based retention
  log.retention.bytes = 10737418240 (10 GB per partition)
  
  If partition size exceeds 10 GB → delete oldest segments until under the limit


STRATEGY 3: Log Compaction (keeps latest value per key)
  This is fundamentally different from the above two.
  
  Instead of deleting by time/size, Kafka keeps THE LATEST VALUE for each key.
  
  Before compaction:
    offset 0: key=user-42, value="created"
    offset 1: key=user-42, value="updated email"
    offset 2: key=user-99, value="created"
    offset 3: key=user-42, value="deleted account"    ← latest for user-42
    offset 4: key=user-99, value="updated name"       ← latest for user-99

  After compaction:
    offset 3: key=user-42, value="deleted account"    ← kept (latest for this key)
    offset 4: key=user-99, value="updated name"       ← kept (latest for this key)

  Use case: __consumer_offsets topic (only need latest committed offset per group)
            Kafka Streams state stores (only need latest state per key)
            CDC (Change Data Capture) — latest state of each database row
```

---

## 5. Replication Deep Dive — How Kafka Never Loses Data

### Leader, Followers, and ISR

```
Partition orders-0 with replication factor = 3:

  Broker 1: LEADER       ← All reads and writes go here
  Broker 2: FOLLOWER     ← Copies data from leader
  Broker 3: FOLLOWER     ← Copies data from leader

  ISR (In-Sync Replicas) = {Broker 1, Broker 2, Broker 3}
  All three are caught up → all in the ISR
```

### How Followers Replicate — They're Just Special Consumers

This is a beautiful design insight. Followers don't use a special replication protocol. They just send the SAME FetchRequest that regular consumers use, with one difference: they include their broker ID to identify as a replica.

```
Follower Broker 2 → Leader Broker 1:
  "FetchRequest: I am replica broker-2, give me data from offset 5000 onward"

Leader Broker 1 → Follower Broker 2:
  "FetchResponse: Here are record batches from offset 5000 to 5500"

Follower Broker 2:
  Writes those exact same bytes to ITS copy of the .log file
  Sends next FetchRequest: "give me from offset 5501 onward"

  This repeats continuously. The follower is always chasing the leader.
```

### The High Watermark — What Is "Committed" Data?

This is a critical concept for understanding Kafka's consistency guarantees.

```
Leader's log:

  offset: [0] [1] [2] [3] [4] [5] [6] [7] [8] [9]
                                      ↑              ↑
                                High Watermark    Log End Offset
                                (HW = 5)          (LEO = 9)

  Offsets 0-5: ALL replicas have these → "committed" → consumers can see these
  Offsets 6-9: ONLY the leader has these → "uncommitted" → consumers CANNOT see these yet

How HW advances:
  1. Leader writes offsets 6, 7, 8, 9
  2. Follower 1 fetches and gets up to offset 7 → reports "I have up to 7"
  3. Follower 2 fetches and gets up to offset 6 → reports "I have up to 6"
  4. Leader calculates: minimum offset ALL ISR replicas have = 6
     → HW advances to 6
     → Consumers can now read offset 6
  5. Follower 2 catches up to offset 9
     → HW advances to 9 → consumers can read all
```

**Why this matters:**
- Consumers with `isolation.level=read_committed` only see data up to HW
- If the leader crashes with HW=5 and LEO=9, offsets 6-9 are lost but that's okay because no consumer ever saw them and no producer got an ACK for them (with acks=-1)

### What Happens When a Leader Dies

```
Step 1: Leader detection
  Controllers detect that Broker 1 (leader) stopped sending heartbeats
  Grace period: 30 seconds (replica.lag.time.max.ms)

Step 2: New leader election
  Controller picks a new leader from the ISR (in-sync replicas)
  Typically the first broker in the ISR list
  
  ISR before crash = {Broker 1, Broker 2, Broker 3}
  Broker 1 is dead → pick Broker 2 as new leader

Step 3: Metadata update
  Controller updates cluster metadata: "orders-0 leader is now Broker 2"
  All brokers and clients learn about this change via metadata refresh

Step 4: Truncation (if necessary)
  New leader's log might be slightly behind the old leader's
  Old leader had offsets 0-5000, new leader might only have 0-4998
  
  Any follower that had 4999-5000 must TRUNCATE those offsets to match new leader
  This ensures all replicas are consistent with the new leader
```

### ISR — When a Follower Falls Behind

```
replica.lag.time.max.ms = 30000 (30 seconds)

If a follower hasn't fetched from the leader in 30 seconds:
  → Removed from ISR (it's "out of sync")
  → Leader no longer waits for it on acks=-1 writes
  → It CANNOT be elected as leader (would lose data)

When the follower catches back up:
  → Added back to ISR
  → Becomes eligible for leader election again

ISR shrink scenario:
  ISR was {1, 2, 3}, follower 3 goes slow
  ISR becomes {1, 2}
  With min.insync.replicas=2 and acks=-1:
    → Writes still work (ISR has 2 members)
    
  If follower 2 ALSO goes slow:
  ISR becomes {1} (only leader)
  With min.insync.replicas=2 and acks=-1:
    → Writes FAIL with NotEnoughReplicasException
    → Producer must retry or error out
    → This is CORRECT behavior: better to reject writes than lose data
```

### Unclean Leader Election — The Danger Zone

```
unclean.leader.election.enable = false (default since Kafka 0.11)

Scenario: ALL ISR replicas are dead. Only an out-of-sync follower is alive.
  That follower is missing some recent messages.

  If unclean election is ENABLED:
    → Out-of-sync follower becomes leader
    → Partition is available but SOME DATA IS LOST
    → Use case: availability matters more than data integrity (e.g., logs)

  If unclean election is DISABLED (default):
    → Partition stays OFFLINE until an ISR replica comes back
    → No data loss, but partition is unavailable
    → Use case: data integrity matters more than availability (e.g., payments)
```

### Leader Epoch — Preventing the "Split Brain" Problem

```
Problem without leader epochs:
  1. Leader A writes offset 100
  2. Network partition: Follower B can't reach Leader A
  3. Controller thinks A is dead → promotes B to leader
  4. B starts accepting writes at offset 100 (DIFFERENT data!)
  5. A comes back → TWO different offsets 100 exist → CORRUPTION

Solution with leader epochs:
  Each leader gets an "epoch" number (incrementing counter)
  Leader A was epoch 5, Leader B is epoch 6
  
  When A comes back:
    A says "I'm epoch 5 with offset 100"
    B says "I'm epoch 6, epoch 5's last offset was 99"
    A truncates its offset 100 → follows B's log
    → No split brain, no data corruption
```

---

## 6. Consumer Deep Dive — How Reading From Kafka Actually Works

### Consumer Group Protocol

When consumers start up and join a group, a complex coordination happens:

```
STEP 1: Find the Group Coordinator
  
  Consumer asks any broker: "Who is the coordinator for group 'billing-team'?"
  Kafka computes: hash("billing-team") % 50 = partition 23 of __consumer_offsets
  The LEADER of __consumer_offsets partition 23 = the coordinator for this group
  
  (The __consumer_offsets topic has 50 partitions by default.
   Each consumer group is "managed" by the broker leading one of these partitions)


STEP 2: Join the Group (JoinGroup Request)
  
  All consumers send JoinGroupRequest to the coordinator
  Coordinator waits for all consumers (up to session.timeout.ms)
  Coordinator picks ONE consumer as the "group leader" (not the Kafka leader — confusing name)
  
  The group leader gets the list of all consumers and all subscribed partitions


STEP 3: Partition Assignment (done by the group leader consumer, NOT the broker!)
  
  Group leader runs the assignment strategy:
  
  Strategy: RangeAssignor (default):
    Partitions sorted: P0, P1, P2, P3, P4, P5
    Consumers sorted: C0, C1, C2
    Divide: C0 gets P0,P1  |  C1 gets P2,P3  |  C2 gets P4,P5
    
  Strategy: RoundRobinAssignor:
    P0→C0, P1→C1, P2→C2, P3→C0, P4→C1, P5→C2
    
  Strategy: StickyAssignor:
    Like round-robin, but tries to KEEP existing assignments on rebalance
    If C1 dies: only C1's partitions are redistributed, C0 and C2 keep theirs
    
  Strategy: CooperativeStickyAssignor (recommended):
    Like sticky, but uses "incremental cooperative rebalancing"
    Other consumers don't stop processing during rebalance
    (With older strategies, ALL consumers stop during rebalance!)

  Group leader sends the assignment to the coordinator


STEP 4: Sync (SyncGroup Request)
  
  Coordinator distributes the assignment to all consumers
  Each consumer knows exactly which partitions it owns
  Consumers start fetching data from their assigned partitions
```

### Rebalancing — Why It Matters and Why It's Painful

A rebalance happens when:
- A consumer joins or leaves the group
- A consumer crashes (heartbeat timeout)
- Topic partition count changes
- Consumer's subscription changes

```
THE PROBLEM WITH EAGER REBALANCING (old default):

  1. Consumer C1 dies
  2. Coordinator: "EVERYONE STOP! Drop all your partitions!"
  3. All consumers in the group: stop processing, give up partitions
  4. New assignment computed
  5. All consumers: get new partitions, resume processing
  
  During steps 2-5: ZERO messages are being processed
  If you have 100 partitions and 1 consumer dies → entire group stops for seconds
  This is called "stop-the-world" rebalancing


THE SOLUTION — COOPERATIVE REBALANCING (Kafka 2.4+):

  1. Consumer C1 dies
  2. Coordinator: "C1's partitions need new owners"
  3. Only C1's partitions are revoked and reassigned
  4. Other consumers KEEP processing their partitions uninterrupted
  
  Much less disruption. Only the affected partitions see a brief pause.
  Enable with: partition.assignment.strategy = CooperativeStickyAssignor
```

### Offset Management — How Consumers Track Progress

```
When a consumer reads a message, it needs to remember "I've processed up to here."
This is called "committing offsets."

WHERE are offsets stored?
  In the internal topic __consumer_offsets (50 partitions, compacted)
  
  Key:   (group-id, topic, partition)  → e.g., ("billing-team", "orders", 0)
  Value: (offset, metadata, timestamp) → e.g., (5001, "", 1711720800000)
  
  This means: "billing-team has processed orders partition 0 up to offset 5001.
               Next time it restarts, start from 5001."


TWO COMMIT MODES:

  1. Auto-commit (enable.auto.commit=true, default):
     Every auto.commit.interval.ms (default 5 seconds), consumer automatically
     commits the latest offsets.
     
     RISK: You might process messages 5001-5050, crash before auto-commit,
           restart and re-process 5001-5050 → DUPLICATES
     
  2. Manual commit:
     You call consumer.commitSync() or consumer.commitAsync() explicitly
     
     commitSync():  blocks until broker confirms → safer, slower
     commitAsync(): non-blocking, returns immediately → faster, but if it fails
                    you might not notice


THE "AT LEAST ONCE" VS "AT MOST ONCE" VS "EXACTLY ONCE" DECISION:

  At Most Once (possible message loss):
    1. Commit offset
    2. Process message
    → If you crash after commit but before processing → message skipped (lost)
    
  At Least Once (possible duplicates, most common):
    1. Process message
    2. Commit offset
    → If you crash after processing but before commit → message processed again
    
  Exactly Once (no loss, no duplicates):
    Use Kafka transactions: read-process-write atomically within Kafka
    OR: make your processing idempotent (processing same message twice = same result)
```

### Consumer Liveness — Heartbeats and Session Timeouts

```
Consumer sends heartbeats to the coordinator in the background.

session.timeout.ms = 45000 (45 seconds, default for Kafka 3.0+)
  If coordinator doesn't receive a heartbeat for 45 seconds:
  → Consumer is considered dead → triggers rebalance

heartbeat.interval.ms = 3000 (3 seconds)
  How often the consumer sends heartbeats
  Rule of thumb: set to 1/3 of session.timeout.ms

max.poll.interval.ms = 300000 (5 minutes)
  Maximum time between poll() calls
  If your message processing takes longer than 5 minutes:
  → Consumer is considered "stuck" → kicked from group → rebalance
  
  This catches cases where the consumer is alive (heartbeating) but stuck
  in a long processing loop and not making progress.
```

---

## 7. Exactly-Once Semantics — How Kafka Prevents Duplicates

### The Problem

```
Without exactly-once:
  1. Producer sends message to broker
  2. Broker writes it, sends ACK
  3. ACK is lost in the network
  4. Producer thinks it failed, RETRIES
  5. Broker writes the SAME message again
  → DUPLICATE in the log!

  This happens more than you think. At millions of messages/second,
  even 0.01% duplicate rate = thousands of duplicates per minute.
```

### Idempotent Producer (Basic Deduplication)

```
When enable.idempotence=true (default since Kafka 3.0):

  1. Producer calls InitProducerId → broker assigns:
       producer_id = 42      (unique for this producer instance)
       producer_epoch = 0     (incremented on producer restart)

  2. Every RecordBatch carries: producer_id + epoch + sequence_number
       Batch 1: pid=42, epoch=0, sequence=0
       Batch 2: pid=42, epoch=0, sequence=1
       Batch 3: pid=42, epoch=0, sequence=2

  3. Broker maintains state per (producer_id, partition):
       "Producer 42 last wrote sequence 2"

  4. If batch with sequence=1 arrives AGAIN (retry):
       Broker: "I already have sequence 1 for producer 42"
       → Returns success (ACK) but does NOT write again
       → No duplicate!

  5. If batch with sequence=5 arrives (gap):
       Broker: "Expected sequence 3, got 5. Something is wrong"
       → Returns OutOfOrderSequenceException

  This is "idempotent" = doing the same thing multiple times has the same effect as once.
  Scope: per-partition per-producer session. Doesn't survive producer restart (new epoch).
```

### Transactions (Cross-Partition Exactly-Once)

Idempotent producers prevent duplicates within a single partition. But what about:
- Write to partition A AND partition B atomically?
- Read from partition X, process, write to partition Y atomically?

```
TRANSACTIONAL PRODUCER FLOW:

  producer.initTransactions();  // one-time setup
  
  producer.beginTransaction();
  try {
      producer.send(record1 to partitionA);
      producer.send(record2 to partitionB);
      producer.send(record3 to partitionC);
      
      // Optionally: commit consumer offsets as part of the transaction
      producer.sendOffsetsToTransaction(offsets, consumerGroupId);
      
      producer.commitTransaction();   // ALL or NOTHING
  } catch (Exception e) {
      producer.abortTransaction();     // rollback everything
  }


HOW IT WORKS INTERNALLY:

  1. BEGIN: Producer tells the Transaction Coordinator (a special broker role):
     "I'm starting transaction tx-001, I'll write to partitions A, B, C"

  2. WRITE: Producer sends records to partitions A, B, C normally
     → Brokers write the records to log BUT they're marked as "uncommitted"
     → Consumers with isolation.level=read_committed CANNOT see them yet

  3. COMMIT/ABORT: Producer tells Transaction Coordinator: "Commit" or "Abort"
     
     The coordinator writes COMMIT (or ABORT) control records to:
       - Partition A
       - Partition B
       - Partition C
     
     These control records are special markers in the log.

  4. After COMMIT markers are written:
     → Consumers with read_committed can now see the records
     → "Last Stable Offset" (LSO) advances past the transaction
     
     After ABORT markers:
     → Consumers with read_committed SKIP the aborted records
     → Records stay in the log but are invisible to committed readers


THE READ SIDE — TWO ISOLATION LEVELS:

  isolation.level=read_uncommitted (default):
    Consumer sees ALL records, even if their transaction hasn't committed yet
    Faster, but might read data that gets rolled back
    
  isolation.level=read_committed:
    Consumer only sees records from committed transactions
    Slightly higher latency (waits for transaction to complete)
    Required for exactly-once semantics
```

### The Complete Exactly-Once Pipeline (Read-Process-Write)

```
The "consume-transform-produce" pattern:

  Input Topic → [Your App] → Output Topic

  1. Consumer reads batch from input topic (offset 100-110)
  2. App processes each record (transform, enrich, filter)
  3. Producer writes results to output topic
  4. Producer commits consumer offsets to __consumer_offsets
  → Steps 3 and 4 happen in a SINGLE TRANSACTION
  
  If app crashes after step 2:
    Transaction aborts → output records are invisible → consumer offsets not committed
    App restarts → reads from offset 100 again → re-processes → no duplicates

  This is TRUE end-to-end exactly-once within the Kafka ecosystem.
  
  Note: If your "processing" involves writing to an external DB,
  Kafka can't guarantee exactly-once for that external system.
  You need the external system to support idempotent writes
  (e.g., upsert with dedup key).
```

---

## 8. KRaft Deep Dive — How Kafka Manages Itself

### Why ZooKeeper Was Removed

```
Problems with ZooKeeper:
  1. Operational burden: must deploy, monitor, and tune TWO separate systems
  2. Scalability: ZooKeeper was the bottleneck for large clusters (100K+ partitions)
  3. Split-brain risk: network partition between Kafka and ZK could cause issues
  4. Metadata propagation: changes had to go Kafka → ZK → Kafka → all brokers (slow)
  5. Security: two systems = two attack surfaces to secure

KRaft benefits:
  1. Single system to deploy and manage
  2. Metadata stored in a Kafka topic (scales like Kafka itself)
  3. Faster metadata propagation (direct log replication)
  4. Supports millions of partitions (ZK struggled beyond 200K)
```

### How KRaft Works

```
CONTROLLER QUORUM:

  Some brokers are designated as controllers (typically 3 or 5 for fault tolerance).
  They form a Raft quorum:

  Controller 1: ACTIVE CONTROLLER (leader of the quorum)
    → Makes all metadata decisions
    → Writes to __cluster_metadata topic
  
  Controller 2: FOLLOWER
    → Replicates __cluster_metadata from the active controller
    → Ready to become active if controller 1 fails
  
  Controller 3: FOLLOWER
    → Same as above

  All regular brokers:
    → Subscribe to __cluster_metadata topic
    → Receive metadata updates via standard Kafka replication
    → Know which broker leads which partition, ISR lists, configs, etc.


WHAT'S IN __cluster_metadata:

  This is a regular Kafka topic (single partition, replicated across controllers)
  containing records like:
  
  - TopicRecord: "topic 'orders' exists with ID abc-123"
  - PartitionRecord: "topic 'orders' partition 0 → leader=1, ISR=[1,2,3]"
  - BrokerRegistrationRecord: "broker 5 is alive at host:port"
  - ConfigRecord: "topic 'orders' retention.ms = 604800000"
  - ProducerIdsRecord: "assigned producer IDs 1000-2000 to broker 3"
  
  Every metadata change = a new record appended to this log
  Brokers replay this log to reconstruct the full cluster state


RAFT CONSENSUS (simplified):

  1. Controllers vote to elect an active controller (leader)
  2. A majority must agree (2 out of 3, or 3 out of 5) → no split brain
  3. Active controller proposes metadata changes
  4. Followers replicate the changes
  5. Change is "committed" when majority has it
  
  If active controller dies:
    → Remaining controllers notice missing heartbeat
    → They vote for a new leader (whoever is most up-to-date wins)
    → New leader continues from the exact point the old leader stopped
    → No metadata loss
```

### Combined vs Dedicated Mode

```
Combined mode (small clusters):
  Same JVM acts as BOTH a controller AND a broker
  process.roles = broker,controller
  Good for: development, small clusters (≤10 brokers)

Dedicated mode (production, large clusters):
  Controllers run on SEPARATE nodes from brokers
  Controller nodes: process.roles = controller
  Broker nodes: process.roles = broker
  Good for: production, isolation of metadata workload from data workload
```

---

## 9. Consumer Offsets and __consumer_offsets Deep Dive

```
__consumer_offsets is one of the most important internal topics:

  - 50 partitions (configurable: offsets.topic.num.partitions)
  - Replication factor 3 (configurable)  
  - COMPACTED (log.cleanup.policy=compact)
    → Only keeps the LATEST offset per (group, topic, partition) key
    → Old committed offsets are cleaned up automatically

HOW OFFSET COMMIT WORKS:

  1. Consumer processes messages from orders-0, up to offset 500
  
  2. Consumer sends OffsetCommitRequest to the GROUP COORDINATOR:
     key:   (group="billing", topic="orders", partition=0)
     value: (offset=501, metadata="", timestamp=now)
     
     Why offset=501 and not 500?
     → The committed offset is the NEXT offset to read, not the last read one
     → On restart, consumer starts from committed offset (501), not 500
  
  3. Coordinator writes this as a record to __consumer_offsets partition N
     (where N = hash("billing") % 50)
  
  4. Coordinator replicates to followers → ACKs the commit


ON CONSUMER RESTART:

  1. Consumer sends OffsetFetchRequest: "What's my last offset for orders-0?"
  2. Coordinator reads from __consumer_offsets: "offset 501"
  3. Consumer starts fetching from offset 501
  → No messages lost, no messages reprocessed (if commit timing was right)
```

---

## 10. Kafka's Binary Protocol — Why It's Fast

Kafka uses a custom binary protocol over raw TCP (not HTTP, not gRPC).

```
WHY NOT HTTP/REST?

  HTTP overhead for sending one message:
    POST /topics/orders HTTP/1.1\r\n
    Host: broker:9092\r\n
    Content-Type: application/json\r\n
    \r\n
    {"records":[{"value":"Hello"}]}
    → ~220 bytes total

  Kafka binary protocol for the same message:
    [size][api_key][version][correlation_id][client_id][acks][topic][partition][record_batch]
    → ~114 bytes total (48% smaller)

  At 1 million messages/second:
    HTTP: 220 MB/s just for framing overhead
    Binary: 114 MB/s for framing
    Savings: 106 MB/s = 9.2 TB/day

  Also: binary parsing is pointer arithmetic (nanoseconds)
        JSON parsing requires string comparison and state machines (microseconds)


THE PROTOCOL STRUCTURE:

  Every request has a header:
    - message_size (4 bytes): how big is this request?
    - api_key (2 bytes): what operation? (Produce=0, Fetch=1, Metadata=3, etc.)
    - api_version (2 bytes): which version of the API? (backward compatibility)
    - correlation_id (4 bytes): matches request to response (multiplexed connections)
    - client_id: identifies the application

  Response header:
    - message_size + correlation_id (to match the request)
    - API-specific response payload

  There are 67+ different API keys for all operations:
    Produce, Fetch, ListOffsets, Metadata, OffsetCommit, OffsetFetch,
    FindCoordinator, JoinGroup, SyncGroup, Heartbeat, LeaveGroup,
    CreateTopics, DeleteTopics, AlterConfigs, etc.


VERSION NEGOTIATION:

  First thing a client does on connection:
    1. Send ApiVersionsRequest: "What API versions do you support?"
    2. Broker responds: "I support Produce v0-v9, Fetch v0-v16, ..."
    3. Client uses the highest version both sides support
    → This is how old clients talk to new brokers (backward compatibility)
```

---

## 11. Performance Numbers You Should Know

```
SINGLE BROKER THROUGHPUT (modern hardware, compressed):

  Produce (acks=1):   800 MB/s - 1.5 GB/s
  Produce (acks=-1):  400 MB/s - 800 MB/s
  Consume:            1.5 GB/s - 2.5 GB/s (zero-copy, page cache hit)
  
  At 500-byte average message size:
    acks=1:   1.6 - 3 million messages/second per broker
    acks=-1:  0.8 - 1.6 million messages/second per broker


END-TO-END LATENCY (same data center):

  Producer batching (linger.ms):      0.1 - 5 ms
  Network producer → broker:          0.1 - 1 ms
  Broker disk write (page cache):     0.01 - 0.05 ms
  Replication (acks=-1, 2 followers): 0.5 - 2 ms
  Network broker → consumer:          0.1 - 1 ms
  Consumer deserialization:           0.01 - 0.1 ms
  ──────────────────────────────────────────
  TOTAL (typical same DC):            5 - 15 ms
  TOTAL (cross-region):               50 - 200 ms


SCALING NUMBERS:

  LinkedIn:     7 trillion messages/day across thousands of brokers
  Netflix:      700 billion events/day
  Uber:         Trillions of messages/day, petabytes of data
  
  A single Kafka cluster can handle:
    - Millions of partitions (KRaft removes the ZK bottleneck)
    - Hundreds of brokers
    - Hundreds of thousands of producer/consumer connections
```

---

## 12. Key Configurations Every Engineer Should Know

### Broker Configs

| Config | Default | What It Does |
|--------|---------|-------------|
| `num.partitions` | 1 | Default partitions for new topics. Set to 6-12 for moderate load |
| `default.replication.factor` | 1 | Default replicas per partition. **Set to 3 in production** |
| `min.insync.replicas` | 1 | Min ISR for acks=-1 writes. **Set to 2 in production** |
| `log.retention.hours` | 168 (7 days) | How long to keep data |
| `log.segment.bytes` | 1 GB | When to roll to a new segment file |
| `num.network.threads` | 3 | Threads handling network I/O |
| `num.io.threads` | 8 | Threads handling disk I/O and request processing |
| `unclean.leader.election.enable` | false | Allow data-losing leader election? Keep false |

### Producer Configs

| Config | Default | What It Does |
|--------|---------|-------------|
| `acks` | all | Durability level. `all` = safest |
| `enable.idempotence` | true | Prevent duplicates on retry |
| `batch.size` | 16 KB | Max batch size. Increase for throughput |
| `linger.ms` | 0 | Wait time to fill batch. Set 5-20ms for throughput |
| `compression.type` | none | Use `zstd` or `lz4` |
| `buffer.memory` | 32 MB | Total producer memory pool |
| `max.block.ms` | 60s | How long send() blocks when buffer full |

### Consumer Configs

| Config | Default | What It Does |
|--------|---------|-------------|
| `group.id` | (required) | Consumer group name |
| `auto.offset.reset` | latest | Where to start if no committed offset: `earliest` or `latest` |
| `enable.auto.commit` | true | Auto-commit offsets periodically |
| `auto.commit.interval.ms` | 5000 | Auto-commit frequency |
| `max.poll.records` | 500 | Max records per poll() call |
| `max.poll.interval.ms` | 5 min | Max time between polls before consumer is kicked |
| `session.timeout.ms` | 45s | Heartbeat timeout before consumer is declared dead |
| `isolation.level` | read_uncommitted | Use `read_committed` for transactional reads |
| `partition.assignment.strategy` | RangeAssignor | Use `CooperativeStickyAssignor` for less disruptive rebalances |

---

## 13. Kafka vs Other Systems — When to Use What

| Scenario | Best Choice | Why |
|----------|------------|-----|
| High-throughput event streaming (logs, clicks, metrics) | **Kafka** | Designed for this. Sequential I/O, batching, compression, zero-copy |
| Simple task/job queue (process once, delete) | **RabbitMQ** | Native queue semantics, message acknowledgment, dead letter queues |
| Microservice request-reply (synchronous) | **gRPC / HTTP** | Kafka is async. Don't use async messaging for sync request-response |
| Pub-sub with small messages, low latency | **Redis Pub/Sub** | Simpler, lower latency, but no persistence or replay |
| Ordered event log with replay capability | **Kafka** | Kafka's core design. No other system does this as well at scale |
| Cloud-native managed streaming (low ops) | **AWS Kinesis** | Serverless, less operational burden, but less flexible than Kafka |
| Real-time analytics on streaming data | **Kafka + Kafka Streams / Flink** | Stream processing on top of Kafka's durable log |
| Change Data Capture (CDC) from databases | **Kafka + Debezium** | Industry standard. Debezium captures DB changes into Kafka topics |

---

## 14. Common Kafka Failure Scenarios and How Kafka Handles Them

```
SCENARIO 1: BROKER DIES
  → Controller detects via missing heartbeat
  → New leaders elected for all partitions that were on the dead broker
  → Producers/consumers get metadata update, redirect to new leaders
  → If replication factor ≥ 3 and min.insync.replicas ≥ 2: ZERO data loss
  → Recovery: dead broker restarts, syncs data from current leaders, rejoins ISR


SCENARIO 2: NETWORK PARTITION (broker can't reach other brokers but clients can)
  → Controller removes the isolated broker from ISR
  → If isolated broker was leader → new leader elected elsewhere
  → The isolated broker might still accept writes (if producer connects to it)
    → Leader epoch prevents this: new leader has higher epoch
    → Old leader realizes it's stale and stops accepting writes
  → When network heals: broker truncates diverged data, syncs from current leader


SCENARIO 3: DISK FULL ON BROKER
  → Broker can't write new data → ProduceRequests fail
  → Solution: 
    - Enable tiered storage (old data moves to S3)
    - Reduce retention period
    - Add more brokers and rebalance partitions
  → Kafka supports log.retention.bytes to auto-delete when partition size exceeds limit


SCENARIO 4: SLOW CONSUMER (consumer lag growing)
  → Other consumers in the group are NOT affected (each has its own partitions)
  → If consumer stops polling for max.poll.interval.ms → kicked from group → rebalance
  → Fix: increase max.poll.interval.ms, reduce max.poll.records, or scale out consumers
  → Monitor consumer lag with kafka-consumer-groups CLI or metrics


SCENARIO 5: PRODUCER SENDS FASTER THAN BROKER CAN HANDLE
  → Producer's buffer.memory fills up
  → producer.send() blocks for up to max.block.ms
  → After timeout: BufferExhaustedException thrown
  → Fix: add more partitions, add more brokers, increase broker I/O threads,
    enable compression, increase batch.size


SCENARIO 6: ENTIRE DATA CENTER GOES DOWN
  → If all replicas are in one DC → data unavailable until DC recovers
  → Solution: Kafka MirrorMaker 2 (async cross-DC replication)
    OR: stretch cluster across DCs with rack-aware replica placement
  → Trade-off: cross-DC replication adds 10-50ms latency per write
```

---

## 15. Kafka Design Philosophy — The Key Principles

```
1. THE LOG IS THE DATABASE
   Kafka treats the append-only log as the source of truth
   Everything else (indexes, caches, derived state) is derived from the log
   This is fundamentally different from traditional DBs where the table is truth

2. DUMB BROKER, SMART CLIENTS
   Broker's job: store and forward bytes as fast as possible
   Producer's job: batching, compression, partitioning, retries, idempotency
   Consumer's job: tracking offsets, group coordination, deserialization
   This keeps the broker simple and fast

3. PULL, NOT PUSH
   Consumers PULL data from brokers (via FetchRequest)
   Brokers don't push data to consumers
   Why? Consumer controls its own speed. Fast consumer reads at max speed.
   Slow consumer reads at its own pace. Broker doesn't need backpressure logic.

4. SEQUENTIAL I/O OVER RANDOM I/O
   Every design decision optimizes for sequential disk access
   No B-trees, no random seeks, no in-place updates
   Append-only → sequential writes. Read from offset → sequential reads.

5. BATCHING EVERYWHERE
   Producer batches records before sending
   Broker writes batches (not individual records) to disk
   Consumer fetches batches of records
   Compression applied per batch (better ratios)

6. ZERO COPY AND PAGE CACHE
   Let the OS cache data (page cache), not the JVM
   Use sendfile() to avoid copying data through user space
   The broker barely touches the data bytes — just shuffles them

7. HORIZONTAL SCALING VIA PARTITIONS
   Need more throughput? Add more partitions and brokers
   Each partition is an independent, ordered log
   Partitions can be spread across hundreds of brokers
```

---

## 30-Second Revision Box

```
WHY FAST: Sequential I/O + OS page cache + zero-copy (sendfile) + batching + 
compression + dumb broker design = millions of msgs/sec per broker.

PRODUCER: serialize → partition (hash key) → batch in RecordAccumulator → 
compress → send. acks=0/1/-1 controls durability. Idempotent producer uses 
producer_id + sequence numbers to prevent duplicates on retry.

BROKER: Acceptor → network threads (NIO) → request queue → I/O threads → 
response. Writes = append to .log (page cache). Reads = sendfile() zero-copy.

STORAGE: partitions split into 1GB segment files (.log + .index + .timeindex).
Only latest segment is writable. Sparse offset index → binary search + short scan.
Retention = time-based or size-based deletion, or log compaction (keep latest per key).

REPLICATION: followers are consumers with replica IDs. High watermark = offset 
replicated to all ISR. Consumers only see up to HW. Leader epoch prevents split-brain.

CONSUMER: join group → coordinator assigns partitions (via group leader consumer) → 
pull model (FetchRequest + long polling). Offsets stored in __consumer_offsets topic.
CooperativeStickyAssignor for non-disruptive rebalancing.

EXACTLY-ONCE: idempotent producer (per-partition dedup via sequences) + transactions 
(atomic multi-partition writes + offset commits). Consumers use read_committed isolation.

KRAFT: Raft-based controller quorum replaces ZooKeeper. Metadata stored in 
__cluster_metadata topic. Scales to millions of partitions.
```

---

## Revision Flashcards

**Q: Why is Kafka so fast?**
A: Six reasons: (1) Sequential I/O only — append to end of files, never random seeks. (2) OS page cache — "writes to disk" actually write to RAM; reads of recent data come from RAM too. (3) Zero-copy via sendfile() — data goes from page cache to network card without touching JVM. (4) Batching — amortizes network and disk overhead. (5) Batch-level compression — 5-7x reduction. (6) Dumb broker — never parses message content, just shuffles bytes.

**Q: Explain acks=0, 1, and -1 and when to use each.**
A: acks=0: fire-and-forget, fastest, messages can be lost silently. Use for non-critical metrics/logs. acks=1: leader writes to its log before ACK, fast, but data lost if leader dies before replication. Use for most applications. acks=-1(all): all in-sync replicas write before ACK, slowest, no data loss when paired with min.insync.replicas=2. Use for financial/critical data.

**Q: What is the high watermark?**
A: The highest offset that ALL in-sync replicas have. Consumers can only read up to the high watermark. Data beyond it exists only on the leader and is "uncommitted." If the leader crashes, uncommitted data may be lost — but no consumer ever saw it and no producer received an ACK (with acks=-1), so consistency is maintained.

**Q: How does Kafka prevent duplicate messages?**
A: Idempotent producer: each producer gets a unique producer_id from the broker. Every batch carries a sequence number. Broker tracks the last 5 sequences per producer per partition. If a batch with an already-seen sequence arrives (retry), broker ACKs it without writing again. For cross-partition dedup, use transactions.

**Q: What happens during a consumer group rebalance?**
A: A rebalance occurs when a consumer joins, leaves, or crashes. The group coordinator collects JoinGroup requests from all consumers, selects a "group leader" consumer, which computes the partition-to-consumer assignment using the configured strategy (Range, RoundRobin, Sticky, CooperativeSticky). With eager rebalancing, ALL consumers stop during this. With cooperative rebalancing (recommended), only affected partitions pause.

**Q: What is log compaction and when would you use it?**
A: Instead of deleting old segments by time/size, compaction keeps the LATEST value for each message key and deletes older values. The log becomes a snapshot of the latest state per key. Used for __consumer_offsets (latest offset per group), Kafka Streams state stores (latest state per key), and CDC scenarios (latest state of each DB row).

**Q: How does Kafka handle a broker failure?**
A: Controller detects the dead broker via missing heartbeats. For each partition that had its leader on the dead broker, the controller picks a new leader from the ISR. Metadata is updated and propagated to all brokers/clients. Producers and consumers redirect to new leaders. If replication factor ≥ 3 and min.insync.replicas ≥ 2, zero data is lost. The dead broker can rejoin later and sync from current leaders.

**Q: What replaced ZooKeeper and why?**
A: KRaft (Kafka Raft) replaced ZooKeeper. ZK was an external dependency that added operational complexity, created a scalability bottleneck (~200K partition limit), and slowed metadata propagation. KRaft stores metadata in an internal __cluster_metadata topic, uses Raft consensus among controller nodes, and scales to millions of partitions. It's a single system to deploy and manage.

**Q: How does zero-copy work and when doesn't it work?**
A: Zero-copy uses the Linux sendfile() system call. Data goes from disk → OS page cache → network card via DMA. The JVM never touches the bytes. Result: 6x faster, 60% less CPU. It doesn't work with TLS/SSL (data must be encrypted in user space) or when the broker needs to modify the data (rare). This is why many clusters use plaintext internally and TLS only for external clients.

**Q: What is the difference between __consumer_offsets and __cluster_metadata?**
A: __consumer_offsets (50 partitions, compacted) stores committed consumer offsets — "group X has processed topic Y partition Z up to offset N." Each consumer group's offsets are managed by the broker leading the hash(group_id) % 50 partition. __cluster_metadata (1 partition, replicated across controllers) stores all cluster metadata — topic configs, partition assignments, leader elections, broker registrations. It's the KRaft metadata log.

**Q: Why should you give Kafka brokers LESS JVM heap?**
A: Kafka relies on the OS page cache for caching message data, not JVM heap. Every GB given to JVM heap is a GB taken from page cache. More page cache = more recent messages served from RAM = faster consumer reads. Typical setup: 64 GB machine → 6 GB JVM heap + 58 GB page cache. If you give 32 GB to heap, you also get GC pauses and only 32 GB for page cache — slower overall.

**Q: How should you choose the number of partitions?**
A: Partitions = unit of parallelism. Max consumer parallelism = number of partitions. Start with: target throughput / per-partition throughput. For example: you need 100 MB/s and one consumer can process 10 MB/s → 10 partitions. More partitions = more parallelism but also more overhead (file handles, memory, rebalance time, end-to-end latency). Cannot reduce partitions later (only increase). Common range: 6-30 per topic for most workloads. LinkedIn uses hundreds per high-throughput topic.

---

**Prev: [[01-How-Kafka-Works-In-Depth]] | Next: [[02-How-Amazon-S3-Works-In-Depth]]**
