# Security and Authentication — Interview Thinking

> **Permanent Recall:** When discussing security in interviews, bring up **authentication early** in requirements—"Who accesses the system? How do we verify identity?" Explain OAuth 2.0 flow concisely: redirect → user consents → code → exchange for token. Be ready for JWT vs session: stateless scale vs instant revocation. Know common security questions and have model answers. Show defense-in-depth thinking.

---

## How to Discuss Security in Interviews

**Don't treat security as an afterthought.** Bring it up when clarifying requirements:

1. **Who accesses the system?** Users, partners, internal services?
2. **What data is sensitive?** PII, financial, health?
3. **Compliance?** GDPR, HIPAA, PCI-DSS?
4. **Attack surface?** Public API, internal only?

> **FAANG Tip:** "I'd clarify authentication and authorization requirements early—who are the actors, what can they access, and what compliance we need."

---

## When to Bring Up Authentication (Early in Requirements)

| Requirement phase | Security to mention |
|-------------------|---------------------|
| **Clarifying users** | "How do users log in? SSO, email, social?" |
| **Clarifying access** | "Third-party apps? OAuth. Internal only? API keys." |
| **Clarifying scale** | "Stateless JWT for horizontal scale, or session for instant revoke." |
| **Clarifying data** | "Encryption at rest and in transit; password hashing with bcrypt." |

---

## How to Explain OAuth 2.0 Flow Concisely

**30-second version:**

"OAuth 2.0 is delegated authorization. User clicks 'Login with Google.' App redirects to Google. User logs in and consents. Google redirects back with an authorization code. App exchanges code (plus client secret) for access token. App uses token for API calls. User never shares password with the app."

**ASCII for whiteboard:**
```
User → App → Redirect to Google → User consents → Code back
    → App exchanges code for token → API calls with token
```

---

## JWT vs Session Conversation

**Interviewer:** "JWT or session-based auth?"

**You:** "Depends on requirements. JWT is stateless—no server-side storage, good for microservices and horizontal scaling. Session-based stores state on the server—instant revocation when we delete the session. For high-security or need for immediate logout, sessions win. For APIs and distributed systems, JWT. We can also use short-lived JWT with refresh tokens and a small blacklist for critical revocations."

---

## Common Security Questions and Model Answers

### Q: "How do you store passwords?"

**A:** "Never plain text. Hash with bcrypt or Argon2—they're slow by design to resist brute-force. Include a unique salt per password. Optionally add pepper (server-side secret)."

---

### Q: "How do you prevent SQL injection?"

**A:** "Parameterized queries—prepared statements. Never concatenate user input into SQL. Use an ORM that parameterizes by default. Validate and sanitize input."

---

### Q: "What's the difference between 401 and 403?"

**A:** "401 Unauthorized—authentication failed or missing. 403 Forbidden—authenticated but not allowed to perform the action."

---

### Q: "How do you handle token revocation with JWT?"

**A:** "Options: short TTL so tokens expire quickly; refresh token rotation; blacklist revoked tokens in Redis; or use a hybrid—short access token, check blacklist only for refresh."

---

### Q: "How would you design auth for microservices?"

**A:** "JWT for service-to-service—each service validates the token's signature. API gateway validates user tokens before forwarding. Internal service tokens can use a different key. Consider mutual TLS for extra security."

---

### Q: "What is CSRF and how do you prevent it?"

**A:** "CSRF tricks a logged-in user's browser into sending a request. Mitigations: CSRF token in forms, SameSite cookies, validate Origin/Referer header."

---

## Red Flags to Avoid

| Don't Say | Do Say |
|-----------|--------|
| "We'll add security later" | "Security from the start—auth, encryption, validation" |
| "Passwords in MD5" | "bcrypt or Argon2 with salt" |
| "JWT for everything" | "JWT when stateless; session when we need instant revoke" |
| "No rate limiting" | "Rate limit login and sensitive endpoints" |
| "CORS: * for credentials" | "Specific origins, no * with credentials" |

---

## Sample Interview Dialogue

**Interviewer:** "Design a login system for a mobile app."

**You:** "I'd start with the auth flow. For our own app: email/password with bcrypt hashing, or social login via OAuth. On success, issue short-lived JWT access token (15 min) and refresh token (7 days). Store refresh server-side with rotation—each use issues new refresh. API validates JWT signature and expiry. For sensitive actions, add MFA. Rate limit login attempts. All over HTTPS. I'd also consider session if we need instant logout everywhere."

---

## Handling Follow-ups

| Follow-up | Answer |
|-----------|--------|
| "What if token is stolen?" | "Short TTL limits window; refresh rotation detects reuse; revoke refresh family" |
| "Third-party app integration?" | "OAuth 2.0 with authorization code or PKCE for mobile" |
| "Enterprise customers with SSO?" | "SAML or OIDC; federate with their IdP" |
| "How scale auth service?" | "Stateless JWT; auth service replicates; DB/Redis for refresh tokens" |

---

## Interview Flow: Security Discussion

```mermaid
flowchart TD
    A[Clarify who accesses] --> B{Pick auth}
    B -->|Internal/Partner| C[API Key]
    B -->|Third-party| D[OAuth 2.0]
    B -->|Our app| E{Stateless?}
    E -->|Yes| F[JWT]
    E -->|No| G[Session]
    B -->|Enterprise SSO| H[SAML/OIDC]
    C --> I[Secrets, rotate]
    D --> J[Code flow, PKCE]
    F --> K[Short access + refresh]
    G --> L[Redis session store]
    H --> M[Federate IdP]
```

---

## Demonstrating Depth

| Topic | One-liner |
|-------|-----------|
| **OAuth** | "Authorization code flow; PKCE for mobile/SPA without client secret" |
| **JWT** | "Signed, self-contained; validate signature and exp; short TTL" |
| **Defense in depth** | "Layers: network, transport, auth, authorization, data" |
| **OWASP** | "Injection, broken auth, XSS, insecure design—address in design" |

---

## 30-SECOND REVISION BOX

```
BRING UP AUTH EARLY: Who, what, compliance
OAUTH: Redirect → consent → code → token
JWT vs SESSION: Stateless vs instant revoke
MODEL ANSWERS: bcrypt, parameterized, 401/403, CSRF
RED FLAGS: Plain passwords, no rate limit, CORS *
DEPTH: OAuth, JWT, defense in depth, OWASP
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
