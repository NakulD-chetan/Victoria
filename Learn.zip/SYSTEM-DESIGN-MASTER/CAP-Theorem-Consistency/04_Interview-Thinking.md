# CAP Theorem and Consistency — Interview Thinking

> **Permanent Recall:** CAP is nuanced—avoid saying "you pick 2 of 3" literally. Interviewers test whether you understand the partition scenario, CP vs AP trade-offs, and when to apply each. Frame choices as "during partition, we favor C or A." Mention PACELC for bonus depth. Explain eventual consistency as "replicas converge over time if no new writes"—not "no consistency."

---

## How to Discuss CAP in Interviews

**Opening line:** "CAP describes a trade-off during network partitions. Since partitions are inevitable in distributed systems, the real choice is: during a partition, do we favor consistency or availability?"

**Avoid:**
- "You can only have 2 of 3" (oversimplified)
- "We choose CP" without explaining *when* and *why*

**Prefer:**
- "For financial data, we choose CP—we'd rather reject requests than return incorrect balance."
- "For a social feed, we choose AP—we accept that some users might see slightly stale data during an outage."

---

## Common Misconceptions Interviewers Test

| Misconception | Correct View |
|---------------|--------------|
| "CP means no availability ever" | CP means *during partition* we sacrifice availability. Normal operation can be highly available. |
| "AP means no consistency" | AP means *during partition* we sacrifice consistency. Eventually, data converges. |
| "We design for normal case only" | Must design for partition—it will happen. |
| "Eventual = no consistency" | Eventual = replicas converge if writes stop. There *is* a consistency model. |
| "Strong consistency = ACID" | CAP consistency ≠ ACID. Different concepts. |

> **FAANG Tip:** When they say "explain CAP," give the partition-centric view first, then examples.

---

## How to Frame Consistency Choices

**Structure your answer:**
1. **Requirement:** "This system handles [X]. Stale reads could mean [impact]."
2. **Choice:** "So we need [strong / eventual / causal]."
3. **Implementation:** "We'd use [CP/AP system], with [quorum / read-from-one]."
4. **Trade-off:** "The cost is [latency / availability during partition]."

**Example:** "For an inventory system, overselling is unacceptable. We need strong consistency. We'd use a CP store like HBase or quorum reads in Cassandra. During a partition, we might reject updates rather than risk inconsistent stock."

---

## Discussing PACELC for Bonus Points

**When to bring it up:** After explaining CAP, or when they ask "what about when there's no partition?"

**Line:** "PACELC extends this—when there's *no* partition, we still choose between low latency and strong consistency. DynamoDB defaults to eventually consistent reads for speed, but you can request strongly consistent reads when needed. So the trade-off exists even in the normal case."

---

## Explaining Eventual Consistency Clearly

**Wrong:** "Eventual consistency means no consistency."

**Right:** "Eventual consistency means: if we stop writing, all replicas will eventually converge to the same state. Reads might return stale data in the meantime, but the system guarantees convergence. It's a consistency model—just weaker than strong."

**Add:** "For use cases like social media likes or view counts, brief staleness is acceptable. For bank balances, it's not."

---

## Interview Flow: Consistency Questions

```
Interviewer: "Design a payment system."
You: "Payments require strong consistency—we can't double-charge or lose money.
      I'd use a CP database or quorum writes. During a partition, we'd reject
      the transaction rather than risk inconsistency."

Interviewer: "What about a feed?"
You: "Feeds can tolerate eventual consistency. A user might see a like 1-2
      seconds late. We'd use AP—Cassandra or DynamoDB with eventual reads."
```

---

## What to Say When Asked "Is X CP or AP?"

| System | Answer | Nuance |
|--------|--------|--------|
| **Cassandra** | AP | Tunable to quorum for stronger reads |
| **DynamoDB** | AP default | Strongly consistent read option (PC/EC) |
| **MongoDB** | CP | Replica set blocks on primary loss |
| **HBase** | CP | Strong consistency, blocks on partition |
| **ZooKeeper** | CP | Coordination, consensus-based |
| **Redis Cluster** | CP | Blocks during split |

---

## Handling Follow-up: "What About Latency?"

**Line:** "Strong consistency adds latency—we wait for quorum. For critical paths we accept it. For non-critical we use eventual reads. That's the PACELC trade-off in the normal case."

---

## Handling "Design X" Questions — Consistency Angle

When asked to design any system, proactively address consistency:

1. **Identify data types** (payments, feeds, config, etc.)
2. **Classify each** (strong vs eventual vs causal)
3. **State choice** ("For payments we need strong—CP or quorum")
4. **Acknowledge trade-off** ("Higher latency but correct")

> **FAANG Tip:** Don't wait for "what about consistency?"—bring it up as part of your design.

---

## Handling "What About Multi-Region?"

**Line:** "For multi-region, we face the same trade-off. Either we use synchronous replication (strong consistency, higher latency) or async (eventual, lower latency). For critical data we'd use a CP store with cross-region failover. For non-critical we'd use eventually consistent multi-master with conflict resolution—LWW or application-level merge."

---

## 30-SECOND REVISION BOX

```
CAP: Partition → C or A. Explain the scenario.
FRAME: Requirement → Choice → Implementation → Trade-off
PACELC: No partition → Latency vs Consistency (bonus)
EVENTUAL: Converge over time, not "no consistency"
CP/AP MAPPING: Cassandra=AP, Mongo/HBase=CP, DynamoDB=AP+tunable
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
