# Scalability — Tricks and Recognition

> **Permanent Recall:** Scale Cube (X/Y/Z-axis), recognition triggers for scaling problems, numbers to memorize, interview shortcut estimates. X=clone, Y=decompose by function, Z=partition by data. Quick heuristics: bottleneck first, stateless, cache before scale.

---

## Quick Recognition Triggers

When the interviewer says this → think scalability:

| Phrase / Signal | Scaling Problem | Instant Recall |
|-----------------|-----------------|----------------|
| "How would you scale this?" | Overall scaling | Identify bottleneck, apply patterns |
| "Traffic 10x overnight" | App + cache | Horizontal scale, cache |
| "DB is slow" | Read or write bottleneck | Replicas vs sharding |
| "Millions of users" | Multi-tier scale | LB, stateless, DB + cache |
| "Global users" | Latency + HA | CDN, multi-region, read replicas |
| "Write-heavy" | DB writes | Sharding, async, batching |
| "Read-heavy" | DB reads | Replicas, cache |
| "Single point of failure" | SPOF | Replicas, LB, stateless |

---

## The Scale Cube (Martin Abbott)

```
                    Z-Axis
                    (Data partitioning)
                         *
                        /|
                       / |
                      /  |
                     /   |
                    /    |
         Y-Axis ---*-----+---- X-Axis
        (Functional    |     (Cloning)
         decompose)    |
                       |
```

| Axis | Strategy | What It Means | Example |
|------|----------|----------------|---------|
| **X-axis** | Cloning | Clone app + LB; same service, more instances | 1 server → 100 servers behind LB |
| **Y-axis** | Functional decomposition | Split by business capability; different services | Monolith → Auth, Feed, User, Media services |
| **Z-axis** | Data partitioning | Split by data (sharding); same service, different data | User 0–99 → Shard 1; User 100–199 → Shard 2 |

> **FAANG Tip:** "We'd scale on the X-axis first — clone our stateless API servers. If the DB becomes the bottleneck, we add Y-axis (read replicas) for reads and Z-axis (sharding) for writes." Shows you know the vocabulary.

---

## Common Scaling Numbers to Memorize

| Metric | Value | Use In |
|--------|-------|--------|
| **App server** | ~1K–5K RPS per instance (simple API) | "100K RPS → ~100 servers" |
| **DB server** | ~5K read QPS, ~1–2K write QPS (indexed) | "500K reads → 100 replicas" |
| **Redis** | ~100K ops/sec per node | "10M cache ops → 100 nodes" |
| **Kafka** | ~100K msg/sec per partition | "1M msg/s → 10+ partitions" |
| **Cross-region latency** | 50–200 ms | "Multi-region adds latency" |
| **Same-DC latency** | <1 ms | "Cache/DB in same DC = fast" |
| **CDN edge** | 1–5 ms | "Static from CDN" |
| **Replication lag** | 100ms–1s | "Eventually consistent reads" |

---

## Shortcuts for Interview Estimates

| Question | Shortcut | Example |
|----------|----------|---------|
| "How many app servers?" | RPS ÷ 1000 (conservative) | 100K RPS → 100 servers |
| "How many read replicas?" | Read QPS ÷ 5000 | 500K reads → 100 replicas |
| "Cache hit rate impact?" | 90% hit → 10× less DB load | 1M reads → 100K to DB |
| "Sharding count?" | Start 10–100; grow as needed | Don't over-shard early |
| "Bandwidth?" | QPS × response_size × 8 (bits) | 100K × 10KB × 8 = 8 Gbps |
| "Storage with replicas?" | Raw × 3 (typical) | 1 PB raw → 3 PB with 3× |

---

## Recognition: "This Needs Scaling"

```mermaid
flowchart TD
    A[Problem statement] --> B{Keyword?}
    B -->|"Scale" "millions" "billions"| C[Scaling required]
    B -->|"High throughput" "traffic spike"| C
    C --> D[Identify bottleneck]
    D --> E[Apply Scale Cube axis]
    E --> F[X: clone, Y: decompose, Z: partition]
```

---

## Pattern: Bottleneck-First Thinking

```
WRONG:  "Let's add microservices and sharding."
RIGHT:  "First I'd identify the bottleneck. Is it app tier, DB reads, DB writes, or network?
         Then I'd apply the right pattern."
```

| Suspected Bottleneck | First Question to Ask (mentally) | Pattern |
|----------------------|----------------------------------|---------|
| App CPU/memory | Are we stateless? | X-axis: add servers |
| DB reads | Read:write ratio? | Cache → replicas |
| DB writes | Single primary limit? | Sharding |
| Network/bandwidth | Static content? | CDN |
| Sync heavy work | Can it be async? | Queue + workers |

---

## Quick Heuristics Summary

| Heuristic | Meaning |
|-----------|---------|
| **Stateless first** | Any server can serve any request → easy X-axis |
| **Cache before scale** | 90% hit cuts DB load 10×; cheaper than 10× replicas |
| **Replicas before sharding** | Sharding is complex; exhaust replicas first |
| **Measure before scaling** | Don't scale what isn't the bottleneck |
| **Async for heavy work** | Don't block the request path |
| **CDN for static** | Never serve global static from single origin |

---

## "Just Use" Shortcuts (Interview)

| Need | "Just use" | Why |
|------|-------------|-----|
| Cache | Redis | In-memory, fast, pub/sub, sorted sets |
| Message queue | Kafka (high throughput) or SQS (simpler) | Ordering, replay, partitioning |
| Load balancer | nginx, ALB, HAProxy | Health checks, routing |
| CDN | CloudFront, Cloudflare | Edge caching, DDoS protection |
| Sharding | Consistent hash or modulo | Minimize rebalance on scale |
| Read replicas | Primary-replica replication | Standard DB pattern |

---

## 30-SECOND REVISION BOX

```
CUBE: X=clone, Y=decompose, Z=partition
TRIGGERS: "scale" "millions" "DB slow" "traffic spike"
NUMBERS: 1K RPS/server, 5K read/DB, 100K Redis ops
SHORTCUTS: RPS/1000=servers, 90% hit=10× less DB
HEURISTICS: Stateless, cache first, replicas before shard
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
