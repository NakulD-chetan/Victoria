# System-Patterns — Mental Model

> **Permanent Recall:** Given a problem, use the decision flowchart to pick the right pattern. The FAANG framework (Read→Clarify→Brute→Optimize→Code→Test) structures every interview. Constraints drive pattern selection.

---

## Decision Flowchart: Which Pattern?

```mermaid
flowchart TD
    START["Given a problem"] --> N{"Check n"}
    N -->|"n ≤ 10"| R1["O(n!) Brute, Backtrack"]
    N -->|"n ≤ 20"| R2["O(2^n) Bitmask, Subsets"]
    N -->|"n ≤ 40"| R3["Meet in the Middle"]
    N -->|"n ≤ 500"| R4["O(n³) Floyd-Warshall"]
    N -->|"n ≤ 2000"| R5["O(n²) DP, Two pointers"]
    N -->|"n ≤ 10^5"| R6["O(n log n) Sort, Heap, BIT"]
    N -->|"n ≤ 10^6"| R7["O(n) Two ptrs, Mono stack"]
    N -->|"n ≤ 10^8"| R8["O(log n) BS, Math"]
    START --> K{"Check keywords"}
    K -->|"Min/max X s.t. Y"| K1["BS on Answer"]
    K -->|"Intervals/meetings"| K2["Sweep Line"]
    K -->|"Range query+update"| K3["BIT / SegTree"]
    K -->|"Next greater/smaller"| K4["Monotonic Stack"]
    K -->|"Both left & right"| K5["Two-Pass"]
    K -->|"Shortest path"| K6["BFS / Dijkstra"]
    K -->|"Word/prefix"| K7["Trie + Backtrack"]
    K -->|"Stream + random"| K8["Reservoir Sampling"]
    K -->|"Shuffle"| K9["Fisher-Yates"]
    style R2 fill:#90EE90
    style R3 fill:#87CEEB
    style R6 fill:#DDA0DD
    style K1 fill:#FFE4B5
    style K3 fill:#F0E68C
```

<details>
<summary>ASCII fallback</summary>

```
START
  │
  ├─ "Min/max X such that Y is possible?"
  │     → Binary Search on Answer + Greedy/DP check
  │
  ├─ Intervals, meetings, events, overlapping?
  │     → Sweep Line
  │
  ├─ Need info from BOTH left and right?
  │     → Two-Pass (L→R, R→L)
  │
  ├─ Range queries + point/range updates?
  │     → BIT or Segment Tree
  │
  ├─ "Next greater/smaller" + optimal subproblem?
  │     → Monotonic Stack + DP
  │
  ├─ Shortest path (unweighted) + extra state?
  │     → BFS + DP (state = node + keys/visited)
  │
  ├─ Word/prefix search + exhaustive explore?
  │     → Trie + Backtracking
  │
  ├─ n ≤ 20? Subsets, permutations?
  │     → Brute / Backtrack / Bitmask
  │
  ├─ n ≤ 40? Subset sum, partition?
  │     → Meet in the Middle
  │
  ├─ Optimal substructure + merge step?
  │     → Divide and Conquer
  │
  ├─ Stream + pick random k?
  │     → Reservoir Sampling
  │
  └─ Shuffle array uniformly?
        → Fisher-Yates
```

</details>

---

## FAANG Problem-Solving Framework (6 Steps)

| Step | Time | Action | Script |
|------|------|--------|--------|
| **1. Read** | 2 min | Read problem 2×, note inputs/outputs | "Let me read through this carefully..." |
| **2. Clarify** | 2 min | Ask: duplicates? negatives? empty? overflow? | "Can the array be empty? Any negative numbers?" |
| **3. Brute Force** | 5 min | State naive O(n²) or worse solution | "A brute force would be to try all pairs..." |
| **4. Optimize** | 10 min | Identify bottleneck, apply pattern | "We can optimize with binary search on the answer..." |
| **5. Code** | 15 min | Write clean, modular code | "I'll implement the binary search first..." |
| **6. Test** | 5 min | Walk through examples, edge cases | "Let me trace through: n=1, n=0, sorted..." |

**Total: ~45 min** (adjust per problem difficulty)

---

## Constraint → Algorithm Mapping

| Constraint | Likely Complexity | Pattern |
|------------|-------------------|---------|
| n ≤ 10 | O(n!) | Brute, backtrack, permutations |
| n ≤ 20 | O(2^n) | Bitmask, subset enumeration |
| n ≤ 40 | O(2^(n/2)) | Meet in the Middle |
| n ≤ 500 | O(n³) | Floyd-Warshall, 3 nested loops |
| n ≤ 2000 | O(n²) | DP, two pointers, nested loops |
| n ≤ 10^4 | O(n²) | DP, graph BFS/DFS |
| n ≤ 10^5 | O(n log n) | Sort, heap, BIT, segment tree, D&C |
| n ≤ 10^6 | O(n log n) or O(n) | Linear scan, two pointers, monotonic stack |
| n ≤ 10^8 | O(n) or O(log n) | Math, formula, binary search |
| Stream / Unknown n | O(n) single pass | Reservoir, two pointers, sliding window |

---

## Pattern Selection by Keywords

| Keyword / Phrase | Pattern |
|------------------|---------|
| "minimum/maximum X such that..." | BS on Answer + Check |
| "intervals", "meetings", "overlap" | Sweep Line |
| "product except self", "left and right" | Two-Pass |
| "range sum", "update", "query" | BIT / Segment Tree |
| "next greater", "histogram", "trapping" | Monotonic Stack |
| "shortest path", "word ladder", "knight" | BFS (+ DP if state) |
| "word search", "prefix", "autocomplete" | Trie + Backtrack |
| "subset sum", "partition", n~40 | Meet in the Middle |
| "merge", "sort", "closest pair" | Divide and Conquer |
| "random from stream" | Reservoir Sampling |
| "shuffle" | Fisher-Yates |

---

## Mental Checklist Before Coding

- [ ] **Constraints** — What's n? What complexity is allowed?
- [ ] **Edge cases** — Empty, single, duplicates, negative?
- [ ] **Pattern** — Which meta-pattern fits?
- [ ] **Data structures** — Stack, heap, map, BIT?
- [ ] **Order** — Sort first? Process in specific order?
- [ ] **State** — What defines "visited" in BFS/DFS?

---

## Recovery Path When Stuck

1. **Re-read** — Missed a constraint or clarification?
2. **Brute force** — Can you at least solve it slowly?
3. **Small n** — What would you do for n=5?
4. **Similar problem** — "This reminds me of X..."
5. **Ask hint** — "Would binary search on the answer help here?"
6. **Simplify** — Solve a smaller version first

---

## FINAL MEMORY COMPRESSION BLOCK

```
FLOWCHART:     Keywords → Pattern (min/max→BS, intervals→sweep, both sides→two-pass, etc.)
FRAMEWORK:     Read→Clarify→Brute→Optimize→Code→Test (45 min)
CONSTRAINTS:   n≤20→bitmask, n≤40→meet-in-middle, n≤10^5→O(n log n), n≤10^6→O(n)
KEYWORDS:      "min X such that"→BS, "intervals"→sweep, "range query"→BIT/SegTree
RECOVERY:      Re-read, brute, small n, similar, ask hint
```

---

## 30-SECOND REVISION BOX

```
□ Min/max X s.t. Y → BS on answer + check
□ Intervals/overlap → Sweep line
□ Both directions → Two-pass
□ Range query+update → BIT/SegTree
□ n≤20 → bitmask; n≤40 → meet in middle
□ 6 steps: Read, Clarify, Brute, Optimize, Code, Test
□ Stuck: re-read, brute, small n, ask hint
```
