# Event Time, Windows & Watermarks

**Event time** is the time when an event **actually occurred** (often embedded in the payload). **Processing time** is when Spark **observes** the event. Structured Streaming’s correctness for out-of-order streams relies on **windows** (grouping in event time) and **watermarks** (bounding lateness).

---

## 1. Definitions

| Term | Definition |
| ---- | ---------- |
| **Event time** | Timestamp carried by the record (e.g., `click_ts`). Used for **business-accurate** analytics. |
| **Processing time** | Wall-clock time during execution. Used for **triggers**, not for correcting historical event ordering by itself. |
| **Window** | A finite interval in **event time** that buckets records (tumbling, sliding, session). |
| **Watermark** | A moving threshold on **event time**: data older than `max_event_time_seen − watermark_delay` may be **dropped** or **never joined**, depending on operator semantics—after Spark considers the corresponding interval **closed**. |

---

## 2. Why Event Time Matters

In real pipelines:

- Events arrive **out of order** (network delays).
- Sources replay **old** data after failures.
- **Wall-clock** triggers do **not** align with **business** periods.

Mapping aggregation to **event time** stabilizes metrics (e.g., “revenue per minute of occurrence”) independent of when Spark processed the row.

---

## 3. Window Types (Conceptual)

| Type | Behavior |
| ---- | -------- |
| **Tumbling** | Fixed-size, **non-overlapping** slices (e.g., 5-minute buckets). |
| **Sliding** | Fixed-size windows that **move** every slide step; windows **overlap**. |
| **Session** | Gaps in activity **define** session boundaries; window length is **data-dependent**. |

Windows are **logical** in event time; each micro-batch **assigns** arriving rows to the appropriate window(s) and updates partial aggregates in **state**.

---

## 4. Watermark Semantics (High Level)

A watermark **w** (in event time) means, informally:

> “We no longer expect events with event time **significantly less** than *w*.”

**Effects:**

- **Late data** beyond the allowed lateness is **dropped** for operators that need to **finalize** output (e.g., to support **Append** on windowed results).
- **State** for old windows can be **dropped**, bounding memory.

```
Event time:  ────|──────── window W ────────|───►
                late events    ^ finalized when
                may still      watermark passes
                arrive here    end of W + allowed lateness
```

Exact rules combine **window end**, **watermark delay**, and **output mode**—they must be read together.

---

## 5. Late Data

**Late data** is an event whose **event time** is **behind** the current watermark (beyond allowed lateness).

| Handling | Consequence |
| -------- | ----------- |
| **Accept** (within lateness) | Window state **updates**; may require **Update** output mode or retractions logic internally. |
| **Drop** (too late) | Sacrifices accuracy for **bounded state** and **append-safe** emission. |

---

## 6. Interaction with Output Mode

- **Append** on windowed aggregation typically requires **watermarks** so that a row is emitted **once** when Spark knows the window will not change.
- **Update** can show **revised** counts as late events arrive (within lateness).
- **Complete** restates all windows—accurate but costly.

---

## 7. Key Takeaways

1. Prefer **event time** for analytics that must match **real-world** timelines.
2. **Windows** group in event time; implement business periods correctly despite disorder.
3. **Watermarks** trade **completeness** (late events) for **bounded state** and **clear emission rules**.
4. Always co-design **watermark delay**, **sink upsert capability**, and **output mode**.

---
