# Design Notification System — Question List

> **Permanent Recall:** Variations: "Add in-app notifications," "Design notification analytics," "Add A/B testing for notifications," "Handle 10B notifications/day." Related: alerting system, email service. Master the pipeline, then apply to variations.

---

## Core Variations

| Question | Focus | Difficulty |
|----------|-------|------------|
| Design a notification system | Full pipeline, multi-channel | Medium |
| Add **in-app notifications** | Storage, real-time delivery, read/unread | Medium |
| Design **notification analytics** | Delivery/open/click tracking, dashboards | Medium |
| Add **A/B testing for notifications** | Variant assignment, metric collection | Hard |
| Handle **10B notifications/day** | Scale, partitioning, batching | Medium |
| Design push notifications only | APNS, FCM, device tokens | Medium |
| Design **email** service | Templates, batching, bounce handling | Medium |

---

## Follow-Up / Deep-Dive Questions

| Question | What They Test |
|----------|----------------|
| How would you add in-app notifications? | Real-time (WebSocket/polling), persistence, read state |
| Design notification analytics | Event pipeline, aggregation, dashboards |
| Add A/B testing for notifications | Variant storage, assignment, metric collection per variant |
| How handle 10B/day? | Queue partitioning, worker scaling, provider batching |
| Provider goes down (APNS): what do you do? | Circuit breaker, retry, queue backup |
| How prevent duplicate notifications? | Idempotency, deduplication |
| Design scheduled notifications | Delay queue, cron, timezone handling |
| How do you handle device token changes? | Upsert on app launch; remove on 410 |

---

## Related Designs

| Design | Overlap | Key Difference |
|--------|---------|----------------|
| **Alerting system** (PagerDuty) | Notifications to on-call | Ops-focused; escalation; different channels |
| **Email service** | Templates, deliver | Single channel; more batching, bounce handling |
| **Chat/Messaging** | Deliver to user | Real-time; WebSockets; different architecture |
| **Event-driven architecture** | Events trigger actions | Broader; notifications are one consumer |

---

## Full Question List (15+)

1. Design a notification system
2. Design push notifications (iOS + Android)
3. Add in-app notifications to the system
4. Design notification analytics (delivery, open, click tracking)
5. Add A/B testing for notifications
6. Handle 10B notifications per day
7. Design an email notification service
8. Design SMS notification system
9. How would you handle APNS being down?
10. Design scheduled notifications (remind in 24h)
11. Design rate limiting for notifications
12. How prevent duplicate notifications on retry?
13. Design device token management
14. Add notification preferences (opt-in/out)
15. Design notification templates with localization
16. How would you notify 10M users in 5 minutes?

---

## Difficulty Guide

| Difficulty | Questions |
|------------|-----------|
| **Medium** | Core design, push only, in-app, 10B scale, email service, scheduled, preferences |
| **Hard** | A/B testing, analytics at scale, provider outage handling, 10M blast |

> **FAANG Tip:** "Add in-app notifications" = add a storage layer (DB) + real-time delivery (WebSocket or polling) + read/unread state. Still uses same event pipeline for triggering.

---

## Prep Strategy

1. **Master core pipeline** — Event → Decide → Format → Deliver → Track
2. **Know all four providers** — APNS, FCM, Twilio, SendGrid
3. **Rate limiting + idempotency** — Always mention
4. **In-app variation** — Add persistence + real-time; same trigger pipeline
5. **Analytics variation** — Event tracking, aggregation, dashboards

---

## Quick Reference: What to Design per Question

| Question | Must Include |
|----------|--------------|
| Core notification system | Pipeline, per-channel queues, providers, rate limit, idempotency |
| + In-app | Storage (notifications table), WebSocket/polling, read/unread |
| + Analytics | Delivery events, aggregation, time-series or OLAP |
| + A/B testing | Variant assignment (hash user to A/B), metric per variant |
| + 10B/day | Partitioning, worker scaling, batch to provider |

---

## Bonus Questions

17. Design notification **grouping** (collapse similar notifications)
18. Add **rich push** (images, actions) to the system
19. Design **notification center** (history, filters)
20. How would you **migrate** from one SMS provider to another?
21. Design **digest notifications** (daily summary email)

---

## Cross-Reference

- **Design Twitter** → Feed; notifications are triggered by feed events
- **Design Uber** → Notifications for ride status, ETA
- **Design WhatsApp** → Push for new message; different from in-app delivery
- **Alerting system** → PagerDuty-style; escalation, on-call

---

## Summary

15+ question variations; core = pipeline + multi-channel + rate limit + idempotency. Variations add in-app, analytics, A/B testing, or scale. Related: alerting, email service, chat.

---

## Last-Minute Prep

Before interview: Review 01_Concept (10B/day, channels), 03_Design-Template (diagram), 05_Common-Mistakes (async, rate limit, idempotency).
