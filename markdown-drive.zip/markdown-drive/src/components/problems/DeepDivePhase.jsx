import { useState, useCallback } from 'react';
import { useProblemSessionStore } from '../../stores/problem-session-store';

export default function DeepDivePhase({ problem }) {
  const answers = useProblemSessionStore((s) => s.phases.deepDive.answers);
  const score = useProblemSessionStore((s) => s.phases.deepDive.score);
  const completed = useProblemSessionStore((s) => s.phases.deepDive.completed);
  const answerDeepDive = useProblemSessionStore((s) => s.answerDeepDive);
  const scoreDeepDive = useProblemSessionStore((s) => s.scoreDeepDive);
  const computeTotalScore = useProblemSessionStore((s) => s.computeTotalScore);
  const [showExplanations, setShowExplanations] = useState(false);

  const questions = problem.deepDiveQuestions || [];
  if (!questions.length) return <div className="dc-phase-empty">No deep dive questions for this problem.</div>;

  const handleSubmit = useCallback(() => {
    scoreDeepDive(problem);
    setShowExplanations(true);
  }, [problem, scoreDeepDive]);

  const handleFinish = useCallback(() => {
    if (!completed) scoreDeepDive(problem);
    computeTotalScore(problem);
  }, [completed, scoreDeepDive, computeTotalScore, problem]);

  return (
    <div className="dc-deep-dive">
      <div className="dc-deep-dive__header">
        <h3 className="dc-deep-dive__title">Phase 4: Deep Dive & Trade-offs</h3>
        <p className="dc-deep-dive__desc">
          Interviewers want to know how you reason through edge cases and trade-offs.
          Answer these follow-up questions about your design. Some questions have multiple correct answers.
        </p>
      </div>

      <div className="dc-deep-dive__questions">
        {questions.map((q, qIdx) => {
          const userAns = answers[qIdx] || [];
          const isCorrectOption = (optIdx) => q.correct.includes(optIdx);

          return (
            <div key={qIdx} className="dc-deep-dive__question">
              <div className="dc-deep-dive__q-header">
                <span className="dc-deep-dive__q-num">Q{qIdx + 1}</span>
                <span className="dc-deep-dive__q-text">{q.question}</span>
                {q.correct.length > 1 && (
                  <span className="dc-deep-dive__q-multi">(Select all that apply)</span>
                )}
              </div>

              <div className="dc-deep-dive__options">
                {q.options.map((opt, optIdx) => {
                  const selected = userAns.includes(optIdx);
                  let optCls = 'dc-deep-dive__option';
                  if (selected) optCls += ' dc-deep-dive__option--selected';
                  if (completed) {
                    if (isCorrectOption(optIdx)) optCls += ' dc-deep-dive__option--correct';
                    else if (selected) optCls += ' dc-deep-dive__option--wrong';
                  }

                  return (
                    <button
                      key={optIdx}
                      className={optCls}
                      onClick={() => !completed && answerDeepDive(qIdx, optIdx)}
                      disabled={completed}
                    >
                      <span className="dc-deep-dive__option-marker">
                        {completed ? (isCorrectOption(optIdx) ? '\u2713' : selected ? '\u2715' : '\u25CB') : (selected ? '\u25C9' : '\u25CB')}
                      </span>
                      <span>{opt}</span>
                    </button>
                  );
                })}
              </div>

              {completed && showExplanations && (
                <div className="dc-deep-dive__explanation">
                  <strong>Explanation:</strong> {q.explanation}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="dc-deep-dive__actions">
        {!completed ? (
          <button
            onClick={handleSubmit}
            className="dc-btn dc-btn--primary"
            disabled={Object.keys(answers).length === 0}
          >
            Submit Answers
          </button>
        ) : (
          <div className="dc-deep-dive__result">
            <div className={`dc-deep-dive__score ${score >= 70 ? 'dc-deep-dive__score--good' : 'dc-deep-dive__score--low'}`}>
              Score: {score}%
            </div>
            <button
              onClick={() => setShowExplanations(!showExplanations)}
              className="dc-btn dc-btn--outline"
            >
              {showExplanations ? 'Hide' : 'Show'} Explanations
            </button>
            <button onClick={handleFinish} className="dc-btn dc-btn--success">
              See Final Score
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
