# Dynamic Programming — Mental Model

> **Permanent Recall:** FAANG engineers ask: "What decision do I make?" → state. "What changes?" → transition. "What's smallest?" → base case. Draw the table mentally. Top-down: solve big, cache small. Bottom-up: solve small, build big. Robot-in-grid = universal 2D DP model.

---

## How FAANG Engineers Think About DP

### The Three Questions (In Order)

| # | Question | Maps To | Example (House Robber) |
|---|----------|---------|------------------------|
| 1 | **What decision do I make at each step?** | State definition | "Rob or skip this house" |
| 2 | **What changes after my decision?** | Transition | "If rob → can't rob next; if skip → can rob next" |
| 3 | **What's the smallest subproblem?** | Base case | "0 houses → 0; 1 house → its value" |

---

## Decision → State

```
At each step, you have CHOICES. Your state captures:
  - Where you are (position, index)
  - What constraints remain (capacity, budget)
  - Any "memory" needed (last action, count)

State = snapshot of the world that lets you make the next decision.
```

**Robot in a Grid (Universal 2D Model):**

```
     c0   c1   c2   c3
r0  [S]  [ ]  [ ]  [ ]
r1  [ ]  [ ]  [X]  [ ]
r2  [ ]  [ ]  [ ]  [E]

State: (row, col) = "How many ways to reach (r,c)?"
Decision: Come from (r-1,c) or (r,c-1)
Transition: dp[r][c] = dp[r-1][c] + dp[r][c-1]
Base: dp[0][0] = 1
```

---

## Transition = "What Changes?"

After each decision, the state evolves:

| Decision | New State | Recurrence Contribution |
|----------|-----------|--------------------------|
| Take item | (i-1, w-weight[i]) | value[i] + dp[i-1][w-w_i] |
| Skip item | (i-1, w) | dp[i-1][w] |
| Move right | (r, c+1) | dp[r][c+1] |
| Move down | (r+1, c) | dp[r+1][c] |

**Key:** Every valid transition must lead to a *smaller* or *earlier* subproblem (directed acyclic dependency).

---

## Base Case = Smallest Subproblem

```
Base cases are states where the answer is trivial — no recurrence needed.

Common base cases:
  - Empty input        → 0 or 1 (depending on problem)
  - Single element     → that element's value
  - Zero capacity      → 0 (knapsack)
  - i=0 or j=0         → 0 or 1 (LCS, edit distance)
  - Diagonal dp[i][i]   → 1 or 0 (interval DP)
```

---

## Draw the DP Table Mentally

### 1D DP (e.g., Climbing Stairs)

```
Index:    0   1   2   3   4   5
dp[i]:    1   1   2   3   5   8   ← ways to reach step i

Fill left → right. dp[i] = dp[i-1] + dp[i-2]
```

### 2D DP (e.g., LCS of "abc", "ace")

```
       ""  a   c   e
    ""  0   0   0   0
    a   0   1   1   1
    b   0   1   1   1
    c   0   1   2   2

dp[i][j] = LCS of s1[0..i-1] and s2[0..j-1]
Match: dp[i][j] = 1 + dp[i-1][j-1]
No match: dp[i][j] = max(dp[i-1][j], dp[i][j-1])
```

### Knapsack Table

```
         w=0  1  2  3  4  5  (capacity)
i=0      0   0  0  0  0  0
i=1      0   v  v  v  v  v   ← item 1
i=2      0   .  .  .  .  .   ← item 2
i=3      0   .  .  .  .  ans

Fill row by row. Each cell = max(skip, take)
```

### Interval DP (e.g., Matrix Chain)

```
     j=0  1  2  3
i=0  -   -  -  -
i=1  -   0  x  x
i=2  -   -  0  x
i=3  -   -  -  0

Fill by length (diagonal by diagonal). dp[i][j] = min cost to multiply A[i]..A[j]
```

---

## Top-Down vs Bottom-Up Mental Model

### Top-Down: "Solve Big, Cache Small"

```
You're given dp(5). You need dp(4) and dp(3).
  → Recurse to dp(4). It needs dp(3) and dp(2).
  → Recurse to dp(3). It needs dp(2) and dp(1).
  → ... until base case.
  → Cache each result. When dp(3) is needed again, return cached.

Mental image: Tree of calls, with cache cutting off redundant branches.
```

### Bottom-Up: "Solve Small, Build Big"

```
You know dp(0), dp(1). Compute dp(2) from them.
Then dp(3) from dp(1), dp(2).
Then dp(4) from dp(2), dp(3).
... until dp(5).

Mental image: Building a pyramid from the base up.
```

---

## The Robot-in-Grid Mental Model

**Universal 2D DP:** You're a robot at (0,0). Goal: (m-1, n-1). At each cell, decide: go right or down.

```
    →  →  →  →  E
    ↓  ↓  ↓  ↓
    ↓  ↓  ↓  ↓
    S  →  →  →

State: (r, c)
Transition: dp[r][c] = dp[r-1][c] + dp[r][c-1]
```

**Variants:**
- **Min path sum:** Add grid[r][c] to the min of (up, left)
- **Obstacles:** If grid[r][c]==1, dp[r][c]=0
- **Multiple moves:** Add more directions (diagonal, etc.)

---

## DP Table Fill Order

```mermaid
flowchart TD
    subgraph FillOrder["DP Table Fill Order"]
        A["Which DP type?"] --> B["Standard 2D<br/>(LCS, Knapsack)"]
        A --> C["Interval DP<br/>(Matrix Chain)"]
        A --> D["Space-Optimized Knapsack"]
        B --> E["Row-by-row: → → →"]
        C --> F["Diagonal: fill by length"]
        D --> G["Reverse: ← fill w backwards"]
    end
    style B fill:#E8F5E9
    style C fill:#E3F2FD
    style D fill:#FFF3E0
```

<details>
<summary>ASCII fallback</summary>

### Row-by-Row (Standard 2D)

```
→ → → → →
→ → → → →
→ → → → →
```

### Diagonal (Interval DP)

```
1 2 3 4
  1 2 3
    1 2
      1
```

### Reverse Order (Space-Optimized Knapsack)

```
For 1D: fill right-to-left so we don't overwrite dp[w-w_i] before using it
w:  5  4  3  2  1  0
    ←  ←  ←  ←  ←
```

</details>

---

## FINAL MEMORY COMPRESSION BLOCK

```
THREE QUESTIONS:     Decision? → State. Changes? → Transition. Smallest? → Base.
ROBOT GRID:         2D state (r,c); from up or left; base at (0,0)
TABLE MENTALLY:     1D left→right; 2D row-by-row; interval by diagonal
TOP-DOWN:           Solve big, recurse small, cache
BOTTOM-UP:          Solve small, build big, iterate
FILL ORDER:         Dependencies must be ready; knapsack space-opt = reverse
INTERVIEW:          "State is (i,j). At each step I can... So transition is..."
```
