# Interview Framework — Common Mistakes

> **Permanent Recall:** These are the TOP 20 interview-killing mistakes, ranked by severity. Avoiding the top 5 can mean the difference between Hire and No Hire. The rest compound: each one chips away at your score. Study this list before every mock interview.

---

## Severity Legend

| Level | Impact |
|-------|--------|
| **Critical** | Often alone = No Hire |
| **High** | Strong negative signal; 2+ = No Hire risk |
| **Medium** | Hurts score; recoverable with awareness |
| **Lower** | Still worth fixing |

---

## The Top 20 — Ranked by Severity

### 1. Diving into Solution Without Requirements — CRITICAL
**What it looks like:** Interviewer says "Design Twitter." You immediately draw boxes: LB, app servers, DB, cache.

**Why it kills you:** Interviewers explicitly test whether you clarify before building. Skipping requirements = automatic red flag.

**Fix:** Always start with "Let me clarify requirements first..." and spend 3–5 minutes on scope, constraints, and assumptions.

---

### 2. Not Asking Questions — CRITICAL
**What it looks like:** You accept the problem as stated. No "What's the scale? Read:write ratio? Latency target?"

**Why it kills you:** Real engineers ask questions. Silence suggests you don't know what to ask or aren't thinking.

**Fix:** Ask 3–5 clarifying questions in the first 5 minutes. Even obvious ones ("Should we optimize for latency or consistency?") show rigor.

---

### 3. Drawing Before Thinking — CRITICAL
**What it looks like:** You grab the whiteboard marker and start drawing components before you've articulated the problem or your approach.

**Why it kills you:** You lock yourself into a design that may not fit. Interviewers see premature commitment.

**Fix:** Think out loud first. "The core challenge is [X]. So we need [Y and Z]. Let me draw that."

---

### 4. Going Too Deep Too Early — HIGH
**What it looks like:** 10 minutes in, you're explaining the internals of B-tree indexes or consistent hashing before you've shown the high-level flow.

**Why it kills you:** You run out of time for other phases. The funnel is Requirements → High-Level → Deep Dive. Skipping levels confuses the narrative.

**Fix:** Establish the full picture first. Say "I'll come back to the details of [X] in the deep dive."

---

### 5. Not Discussing Trade-offs — HIGH
**What it looks like:** You pick Redis for caching but never say why Redis vs Memcached, or why cache-aside vs write-through.

**Why it kills you:** Trade-offs are the core of system design. No trade-offs = no demonstrated judgment.

**Fix:** For every major choice, say "The trade-off here is... I chose [X] because [reason]."

---

### 6. Over-Engineering — HIGH
**What it looks like:** You design for 1B users when the problem implies 1M. Microservices, Kafka, 10 regions, before establishing basics.

**Why it kills you:** Shows poor judgment. Interviewers want "right-sized" design. Overkill suggests you can't prioritize.

**Fix:** Start simple. "We'll start with a single region, single DB. When we scale, we add [X]."

---

### 7. Under-Engineering — HIGH
**What it looks like:** "We'll use one server and one database." No mention of scaling, caching, or failure modes.

**Why it kills you:** The problem usually implies scale. Ignoring it suggests you don't think about production.

**Fix:** At minimum: LB, stateless app servers, cache for read-heavy, DB with replicas. Mention "we can add X when we scale."

---

### 8. Being Silent — HIGH
**What it looks like:** Long pauses while you draw or think. Interviewer has no idea what you're doing.

**Why it kills you:** They can't evaluate your thinking. Silence reads as confusion or lack of structure.

**Fix:** Narrate constantly. "I'm adding a cache here because..." "Let me calculate the QPS..."

---

### 9. Not Mentioning Monitoring — MEDIUM
**What it looks like:** You design the system but never say how you'd observe it in production.

**Why it kills you:** Operations matter. No monitoring = design feels academic, not production-ready.

**Fix:** In wrap-up, always say "We'd monitor latency p99, error rate, cache hit ratio. Alerts on [X]."

---

### 10. Forgetting Security — MEDIUM
**What it looks like:** No auth, no encryption, no rate limiting, no input validation.

**Why it kills you:** Security is table stakes for any real system. Forgetting it suggests inexperience.

**Fix:** In wrap-up: "For security: authentication, HTTPS, rate limiting, input validation. We'd consider [encryption at rest, DDoS]."

---

### 11. Single Point of Failure — MEDIUM
**What it looks like:** One database, one server, no redundancy. "If this goes down, we're done."

**Why it kills you:** Availability is a key non-functional requirement. SPOF = automatic weakness.

**Fix:** Always: multiple app servers, DB replicas, failover. Say "We'd run multiple instances for redundancy."

---

### 12. Not Estimating — MEDIUM
**What it looks like:** You never do back-of-envelope numbers. No DAU, QPS, storage, bandwidth.

**Why it kills you:** Estimation shows you think about scale. Skipping it = missed opportunity to demonstrate quantitative thinking.

**Fix:** Spend 2 minutes: "Rough numbers: [DAU], [QPS], [storage]. That informs our architecture."

---

### 13. Wrong Database Choice Without Justification — MEDIUM
**What it looks like:** You pick MongoDB for a strongly consistent financial ledger, or a relational DB for a social graph with complex traversals.

**Why it kills you:** Database choice drives the whole design. Wrong choice + no justification = weak systems thinking.

**Fix:** "We need [ACID / flexible schema / horizontal scale]. So I'd use [Postgres / MongoDB / Cassandra] because [reason]."

---

### 14. Not Handling Failure Modes — MEDIUM
**What it looks like:** You never discuss "What if the DB goes down? What if the cache fails? What if a region is out?"

**Why it kills you:** Production systems fail. Not discussing it = naive design.

**Fix:** For critical components: "If [X] fails, we'd [failover / circuit breaker / degrade gracefully]."

---

### 15. Copying a Specific Company's Architecture — LOWER
**What it looks like:** "Twitter uses fan-out on write, so we will too" — without explaining why or when it applies.

**Why it kills you:** You may be wrong about the company's architecture. Even if right, you're not showing original thinking.

**Fix:** Reason from requirements. "Given our read:write ratio and latency target, fan-out on write makes sense because..."

---

### 16. Naming Specific Tools Without Explaining Why — LOWER
**What it looks like:** "We'll use Kafka, Redis, and Kubernetes" — as a list, with no rationale.

**Why it kills you:** Sounds like buzzword bingo. Interviewers want reasoning, not a tech stack dump.

**Fix:** "We need a durable message queue for event ordering—Kafka fits because it gives us partitions and replay. Redis for caching because we need TTL and sub-ms latency."

---

### 17. Not Managing Time — LOWER
**What it looks like:** 35 minutes on deep dive, 2 minutes for wrap-up. Or 20 minutes on requirements.

**Why it kills you:** Incomplete interview = incomplete evaluation. You may not reach your strongest areas.

**Fix:** Allocate 5–10–20–5. Check time periodically. "We have X minutes left—let me cover wrap-up."

---

### 18. Skipping Requirements — CRITICAL (see #1)
*Consolidated with #1.*

---

### 19. Not Leading the Conversation — MEDIUM
**What it looks like:** You wait for the interviewer to tell you what to do. "What should I focus on?"

**Why it kills you:** You're supposed to drive. Passivity = weak ownership.

**Fix:** "I'd like to deep-dive into [X] next." "Let me move to wrap-up so we cover monitoring."

---

### 20. Giving Up When Stuck — HIGH
**What it looks like:** "I don't know." Full stop. Or long silence with no attempt to reason.

**Why it kills you:** Recovery and persistence matter. Giving up = No Hire.

**Fix:** "Let me think out loud... The core problem is [reframe]. So we need [simplified approach]." Or "I'm not sure about [X], but my intuition is [Y]. I'd verify in practice."

---

## Quick Reference: Top 5 to Avoid

| # | Mistake | One-Line Fix |
|---|---------|--------------|
| 1 | Diving into solution | Always clarify requirements first |
| 2 | Not asking questions | Ask 3–5 clarifying questions upfront |
| 3 | Drawing before thinking | Articulate approach, then draw |
| 4 | Too deep too early | Establish high-level first |
| 5 | No trade-offs | For every choice: "Trade-off is... I chose because..." |

---

## Pre-Interview Checklist

- [ ] I will clarify requirements before designing
- [ ] I will ask 3–5 clarifying questions
- [ ] I will articulate before drawing
- [ ] I will discuss trade-offs for major choices
- [ ] I will mention monitoring and security in wrap-up
- [ ] I will handle at least one "what if" (failure, 10x traffic)
- [ ] I will lead the conversation and manage time
