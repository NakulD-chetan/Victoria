import { extname, basename } from 'path';

const SUPABASE_URL = 'https://svuumfizxptnxaidishq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';
const BUCKET = 'inkdrop-files';
const CHAT_BUCKET = 'inkdrop-chat';

const STORAGE_BASE = `${SUPABASE_URL}/storage/v1`;
const HEADERS = {
  'apikey': SUPABASE_ANON_KEY,
  'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
};

const MD_EXTENSIONS = ['.md', '.markdown', '.txt', '.mdx'];
const isMd = (f) => MD_EXTENSIONS.includes(extname(f).toLowerCase());

async function supaFetch(path, options = {}) {
  const url = `${STORAGE_BASE}${path}`;
  const res = await fetch(url, {
    ...options,
    headers: { ...HEADERS, ...options.headers },
  });
  return res;
}

export class SupabaseStorageProvider {
  async init() {
    console.log('  Testing Supabase connectivity...');
    try {
      const res = await supaFetch(`/object/list/${BUCKET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: '', limit: 1, offset: 0 }),
      });
      if (res.ok) {
        console.log(`  Supabase connected! Bucket "${BUCKET}" accessible.`);
      } else {
        const errText = await res.text();
        console.error(`  Supabase bucket "${BUCKET}" returned ${res.status}: ${errText}`);
        if (res.status === 400 || errText.includes('not found')) {
          console.error(`  → Create the bucket "${BUCKET}" in Supabase Dashboard > Storage`);
        }
        if (res.status === 403 || errText.includes('security policy')) {
          console.error(`  → Add RLS policies in Supabase Dashboard > Storage > Policies`);
          console.error(`  → Or run this SQL in Supabase SQL Editor:`);
          console.error(`    CREATE POLICY "allow_all" ON storage.objects FOR ALL USING (bucket_id = '${BUCKET}') WITH CHECK (bucket_id = '${BUCKET}');`);
        }
      }
    } catch (err) {
      console.error('  Supabase connection FAILED:', err.message);
      if (err.cause) console.error('  Cause:', err.cause.message || err.cause);
      console.error('  Make sure your network can reach:', SUPABASE_URL);
    }
  }

  sanitize(name) {
    if (!name) return 'General';
    const cleaned = name.replace(/\.\./g, '');
    return cleaned.split('/').map(p => p.replace(/[^a-zA-Z0-9_\-\s.]/g, '').trim()).filter(Boolean).join('/') || 'General';
  }

  async listFolders() {
    try {
      const res = await supaFetch(`/object/list/${BUCKET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: '', limit: 1000, offset: 0 }),
      });
      if (!res.ok) { console.error('listFolders error:', await res.text()); return []; }
      const topLevel = await res.json();

      const folders = [];
      for (const item of topLevel) {
        if (item.name.startsWith('.')) continue;
        if (item.id) continue;
        await this._buildFolderTree(item.name, item.name, folders);
      }
      folders.sort((a, b) => a.name.localeCompare(b.name));
      return folders;
    } catch (err) {
      console.error('listFolders fetch failed:', err.message);
      return [];
    }
  }

  async _buildFolderTree(path, name, result) {
    try {
      const res = await supaFetch(`/object/list/${BUCKET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: path, limit: 1000, offset: 0 }),
      });
      if (!res.ok) return;
      const entries = await res.json();

      const mdFiles = entries.filter(e => e.id && isMd(e.name));
      const subfolders = entries.filter(e => !e.id && !e.name.startsWith('.'));
      const children = [];

      for (const sub of subfolders) {
        await this._buildFolderTree(`${path}/${sub.name}`, sub.name, children);
      }

      result.push({
        name,
        path,
        fileCount: mdFiles.length,
        files: mdFiles.map(f => ({
          name: f.name,
          title: basename(f.name, extname(f.name)).replace(/[-_]/g, ' '),
        })),
        children,
      });
    } catch (err) {
      console.error(`_buildFolderTree(${path}) failed:`, err.message);
    }
  }

  async getFile(folder, filename) {
    const safe = this.sanitize(folder);
    const path = `${safe}/${filename}`;

    try {
      const res = await supaFetch(`/object/${BUCKET}/${path}`);
      if (!res.ok) return null;

      const content = await res.text();
      const headings = [];
      for (const line of content.split('\n')) {
        const m = line.match(/^(#{1,6})\s+(.+)/);
        if (m) {
          headings.push({
            level: m[1].length,
            text: m[2].replace(/[*_`]/g, ''),
            id: m[2].toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''),
          });
        }
      }
      const wordCount = content.split(/\s+/).filter(Boolean).length;

      return {
        name: filename, folder: safe, content, headings, wordCount,
        readTime: Math.ceil(wordCount / 200),
        size: Buffer.byteLength(content, 'utf-8'),
        modified: new Date().toISOString(),
      };
    } catch (err) {
      console.error(`getFile(${path}) failed:`, err.message);
      return null;
    }
  }

  async getFileSections(folder, filename, from = 0, limit = 3) {
    const fileData = await this.getFile(folder, filename);
    if (!fileData) return null;

    const sections = this._splitSections(fileData.content);
    const slice = sections.slice(from, from + limit).map((s, i) => ({ index: from + i, content: s }));
    return { sections: slice, total: sections.length };
  }

  _splitSections(content) {
    const lines = content.split('\n');
    const sections = [];
    let current = [];
    for (const line of lines) {
      if (/^## /.test(line) && current.length > 0) {
        sections.push(current.join('\n').trim());
        current = [line];
      } else {
        current.push(line);
      }
    }
    if (current.length > 0) {
      const text = current.join('\n').trim();
      if (text) sections.push(text);
    }
    return sections.length > 0 ? sections : [content];
  }

  async uploadFile(folder, filename, buffer) {
    const safe = this.sanitize(folder);
    const path = `${safe}/${filename}`;

    try {
      const res = await supaFetch(`/object/${BUCKET}/${path}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'text/markdown',
          'x-upsert': 'true',
        },
        body: buffer,
      });

      if (!res.ok) {
        const errText = await res.text();
        console.error(`Upload failed [${res.status}]:`, errText);
        throw new Error(`Upload failed: ${errText}`);
      }

      console.log(`  Uploaded: ${path}`);
      return path;
    } catch (err) {
      console.error(`uploadFile(${path}) error:`, err.message);
      if (err.cause) console.error('  Cause:', err.cause);
      throw err;
    }
  }

  async deleteFile(folder, filename) {
    const safe = this.sanitize(folder);
    const path = `${safe}/${filename}`;
    try {
      await supaFetch(`/object/${BUCKET}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefixes: [path] }),
      });
    } catch (err) {
      console.error(`deleteFile(${path}) failed:`, err.message);
    }
  }

  async deleteFolder(folder) {
    const safe = this.sanitize(folder);
    await this._removeAllInPath(safe);
    await this.clearChatHistory(folder, null);
  }

  async _removeAllInPath(path) {
    try {
      const res = await supaFetch(`/object/list/${BUCKET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: path, limit: 1000, offset: 0 }),
      });
      if (!res.ok) return;
      const entries = await res.json();

      const files = entries.filter(e => e.id).map(e => `${path}/${e.name}`);
      if (files.length > 0) {
        await supaFetch(`/object/${BUCKET}`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prefixes: files }),
        });
      }

      const subdirs = entries.filter(e => !e.id);
      for (const sub of subdirs) {
        await this._removeAllInPath(`${path}/${sub.name}`);
      }
    } catch (err) {
      console.error(`_removeAllInPath(${path}) failed:`, err.message);
    }
  }

  async createFolder(name) {
    const safe = this.sanitize(name);
    const placeholder = `${safe}/.keep`;
    try {
      const res = await supaFetch(`/object/${BUCKET}/${placeholder}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream', 'x-upsert': 'true' },
        body: new Uint8Array(0),
      });
      if (!res.ok) {
        const errText = await res.text();
        if (!errText.includes('already exists')) {
          console.error(`createFolder(${safe}) failed:`, errText);
        }
      }
    } catch (err) {
      console.error(`createFolder(${safe}) error:`, err.message);
    }
    return safe;
  }

  async renameFolder(oldName, newName) {
    const oldSafe = this.sanitize(oldName);
    const segments = oldSafe.split('/');
    const pureName = this.sanitize(newName).split('/').pop();
    segments[segments.length - 1] = pureName;
    const newSafe = segments.join('/');

    const entries = await this._listPath(oldSafe);
    if (!entries || entries.length === 0) throw new Error('Folder not found');

    for (const entry of entries) {
      if (!entry.id) continue;
      await this._copyFile(`${oldSafe}/${entry.name}`, `${newSafe}/${entry.name}`);
    }

    await this._removeAllInPath(oldSafe);
    return { oldName: oldSafe, newName: newSafe };
  }

  async nestFolder(srcPath, parentPath) {
    const srcSafe = this.sanitize(srcPath);
    const parentSafe = this.sanitize(parentPath);
    const srcName = srcSafe.split('/').pop();
    if (srcSafe === parentSafe) throw new Error('Cannot nest folder into itself');
    if (parentSafe.startsWith(srcSafe + '/')) throw new Error('Cannot nest into own subfolder');

    const newPath = `${parentSafe}/${srcName}`;
    await this._moveAllFiles(srcSafe, newPath);
    return { nested: true, src: srcSafe, newPath };
  }

  async moveFolder(srcName, dstName) {
    const srcSafe = this.sanitize(srcName);
    const dstSafe = this.sanitize(dstName);
    if (srcSafe === dstSafe) throw new Error('Cannot move folder into itself');
    await this._moveAllFiles(srcSafe, dstSafe);
    return { merged: true, src: srcSafe, dst: dstSafe };
  }

  async _listPath(path) {
    try {
      const res = await supaFetch(`/object/list/${BUCKET}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefix: path, limit: 1000, offset: 0 }),
      });
      if (!res.ok) return [];
      return await res.json();
    } catch { return []; }
  }

  async _copyFile(srcPath, dstPath) {
    try {
      const res = await supaFetch(`/object/${BUCKET}/${srcPath}`);
      if (!res.ok) return;
      const buf = Buffer.from(await res.arrayBuffer());
      await supaFetch(`/object/${BUCKET}/${dstPath}`, {
        method: 'POST',
        headers: { 'Content-Type': 'text/markdown', 'x-upsert': 'true' },
        body: buf,
      });
    } catch (err) {
      console.error(`_copyFile(${srcPath} → ${dstPath}) failed:`, err.message);
    }
  }

  async _moveAllFiles(srcPath, dstPath) {
    const entries = await this._listPath(srcPath);
    if (!entries || entries.length === 0) throw new Error('Source folder not found');

    for (const entry of entries) {
      if (!entry.id) {
        await this._moveAllFiles(`${srcPath}/${entry.name}`, `${dstPath}/${entry.name}`);
        continue;
      }
      await this._copyFile(`${srcPath}/${entry.name}`, `${dstPath}/${entry.name}`);
    }
    await this._removeAllInPath(srcPath);
  }

  async moveFile(folder, filename, targetFolder) {
    const srcFolder = this.sanitize(folder);
    const dstFolder = this.sanitize(targetFolder);
    const srcPath = `${srcFolder}/${filename}`;
    const dstPath = `${dstFolder}/${filename}`;

    const res = await supaFetch(`/object/${BUCKET}/${srcPath}`);
    if (!res.ok) throw new Error('File not found');

    const buf = Buffer.from(await res.arrayBuffer());
    await supaFetch(`/object/${BUCKET}/${dstPath}`, {
      method: 'POST',
      headers: { 'Content-Type': 'text/markdown', 'x-upsert': 'true' },
      body: buf,
    });
    await supaFetch(`/object/${BUCKET}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prefixes: [srcPath] }),
    });
  }

  async createFile(folder, filename, content) {
    const safe = this.sanitize(folder || 'General');
    const safeName = filename.endsWith('.md') ? filename : `${filename}.md`;
    const path = `${safe}/${safeName}`;
    const buf = Buffer.from(content, 'utf-8');

    const res = await supaFetch(`/object/${BUCKET}/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'text/markdown', 'x-upsert': 'true' },
      body: buf,
    });
    if (!res.ok) {
      const errText = await res.text();
      console.error(`createFile(${path}) failed:`, errText);
    }
    return { name: safeName, folder: safe };
  }

  _chatKey(folder, filename) {
    const f = this.sanitize(folder).replace(/\//g, '__');
    const fn = filename || '__all__';
    return `${f}__${fn}.json`;
  }

  async getChatHistory(folder, filename, offset = 0, limit = 50) {
    const key = this._chatKey(folder, filename);
    try {
      const res = await supaFetch(`/object/${CHAT_BUCKET}/${key}`);
      if (!res.ok) return { messages: [], total: 0 };
      const parsed = await res.json();
      const msgs = parsed.messages || [];
      return { messages: msgs.slice(offset, offset + limit), total: msgs.length };
    } catch { return { messages: [], total: 0 }; }
  }

  async saveChatMessages(folder, filename, userMsg, assistantMsg) {
    const key = this._chatKey(folder, filename);
    let existing = { messages: [] };
    try {
      const res = await supaFetch(`/object/${CHAT_BUCKET}/${key}`);
      if (res.ok) existing = await res.json();
    } catch { /* fresh */ }

    const now = new Date().toISOString();
    existing.messages.push({ id: `msg_${Date.now()}`, role: 'user', content: userMsg, timestamp: now });
    existing.messages.push({ id: `msg_${Date.now() + 1}`, role: 'assistant', ...assistantMsg, timestamp: now });

    const buf = Buffer.from(JSON.stringify(existing, null, 2), 'utf-8');
    await supaFetch(`/object/${CHAT_BUCKET}/${key}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-upsert': 'true' },
      body: buf,
    });
  }

  async clearChatHistory(folder, filename) {
    if (filename) {
      const key = this._chatKey(folder, filename);
      await supaFetch(`/object/${CHAT_BUCKET}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prefixes: [key] }),
      }).catch(() => {});
    } else {
      const safe = this.sanitize(folder).replace(/\//g, '__');
      try {
        const res = await supaFetch(`/object/list/${CHAT_BUCKET}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prefix: '', limit: 1000, offset: 0 }),
        });
        if (res.ok) {
          const files = await res.json();
          const toDelete = files.filter(f => f.name.startsWith(`${safe}__`)).map(f => f.name);
          if (toDelete.length) {
            await supaFetch(`/object/${CHAT_BUCKET}`, {
              method: 'DELETE',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ prefixes: toDelete }),
            });
          }
        }
      } catch { /* ignore */ }
    }
  }

  async searchContent(question, folder, filename) {
    let searchContent = '';
    let searchScope = '';

    if (folder && filename) {
      const fileData = await this.getFile(folder, filename);
      if (fileData) {
        searchContent = fileData.content;
        searchScope = `${folder}/${filename}`;
      }
    } else if (folder) {
      const safe = this.sanitize(folder);
      const entries = await this._listPath(safe);
      const mdFiles = entries.filter(e => e.id && isMd(e.name));
      const contents = [];
      for (const f of mdFiles) {
        try {
          const res = await supaFetch(`/object/${BUCKET}/${safe}/${f.name}`);
          if (res.ok) contents.push(`## File: ${f.name}\n\n${await res.text()}`);
        } catch { /* skip */ }
      }
      searchContent = contents.join('\n\n---\n\n');
      searchScope = folder;
    } else {
      const allFolders = await this.listFolders();
      const contents = [];
      const gather = async (list) => {
        for (const f of list) {
          const entries = await this._listPath(f.path);
          for (const e of entries.filter(e => e.id && isMd(e.name))) {
            try {
              const res = await supaFetch(`/object/${BUCKET}/${f.path}/${e.name}`);
              if (res.ok) contents.push(`## File: ${f.path}/${e.name}\n\n${await res.text()}`);
            } catch { /* skip */ }
          }
          if (f.children?.length) await gather(f.children);
        }
      };
      await gather(allFolders);
      searchContent = contents.join('\n\n---\n\n');
      searchScope = 'all files';
    }

    return { searchContent, searchScope };
  }
}
