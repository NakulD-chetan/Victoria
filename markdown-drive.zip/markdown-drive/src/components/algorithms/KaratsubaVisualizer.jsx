import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function pow10(n) {
  return 10 ** n;
}

function generateSteps(x, y) {
  const steps = [];
  function rec(a, b, depth) {
    const sa = String(a);
    const sb = String(b);
    const n = Math.max(sa.length, sb.length);
    steps.push({
      type: 'call',
      array: [a, b, depth * 5, n, 0, 0, 0, 0].map((v) => Math.min(90, v + 5)),
      note: `multiply ${a} × ${b}`,
    });
    if (n <= 1) {
      const prod = a * b;
      steps.push({
        type: 'base',
        array: [prod, a, b, 0, 0, 0, 0, 0].map((v) => Math.min(95, v + 5)),
        note: `base ${a}×${b}=${prod}`,
      });
      return prod;
    }
    const m = Math.floor(n / 2);
    const sm = pow10(m);
    const aHi = Math.floor(a / sm);
    const aLo = a % sm;
    const bHi = Math.floor(b / sm);
    const bLo = b % sm;
    steps.push({
      type: 'split',
      array: [aHi + 10, aLo + 10, bHi + 10, bLo + 10, m * 8, 0, 0, 0],
      note: `split at m=${m}: (${aHi},${aLo}) × (${bHi},${bLo})`,
    });
    const z0 = rec(aLo, bLo, depth + 1);
    steps.push({
      type: 'z0',
      array: [z0, aLo, bLo, 0, 0, 0, 0, 0].map((v) => Math.min(95, v + 5)),
      note: `z0 = ${aLo}×${bLo} = ${z0}`,
    });
    const z2 = rec(aHi, bHi, depth + 1);
    steps.push({
      type: 'z2',
      array: [z0, z2, aHi, bHi, 0, 0, 0, 0].map((v) => Math.min(95, v + 5)),
      note: `z2 = ${aHi}×${bHi} = ${z2}`,
    });
    const z1 = rec(aHi + aLo, bHi + bLo, depth + 1);
    steps.push({
      type: 'z1',
      array: [z0, z1, z2, 0, 0, 0, 0, 0].map((v) => Math.min(95, v + 5)),
      note: `z1 = (${aHi}+${aLo})×(${bHi}+${bLo}) = ${z1}`,
    });
    const sub = z1 - z2 - z0;
    steps.push({
      type: 'combine-mid',
      array: [z0, sub, z2, m * 10, 0, 0, 0, 0].map((v) => Math.min(95, Math.max(5, v))),
      note: `z1 - z2 - z0 = ${sub}`,
    });
    const res = z2 * pow10(2 * m) + sub * pow10(m) + z0;
    steps.push({
      type: 'combine',
      array: [res / 100, res % 100 + 10, z2, z0, m * 7, 0, 0, 0].map((v) => Math.min(95, Math.abs(v) + 5)),
      note: `combine → ${res}`,
    });
    return res;
  }
  const ans = rec(x, y, 0);
  steps.push({
    type: 'done',
    array: [ans % 90 + 5, x % 80 + 5, y % 80 + 5, 0, 0, 0, 0, 0],
    note: `result ${x}×${y}=${ans}`,
  });
  return steps;
}

export default function KaratsubaVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const x = 1234 + Math.floor(Math.random() * 200);
    const y = 567 + Math.floor(Math.random() * 300);
    const steps = generateSteps(x, y);
    useVisualizerStore.getState().setArray(steps[0].array);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Karatsuba on ${x} × ${y}` });
    canvasRef.current?.setState({ array: steps[0].array, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    const n = step.array.length;
    if (step.type === 'split') {
      for (let i = 0; i < 4; i++) colors[i] = 'active';
      colors[4] = 'pivot';
    } else if (step.type === 'z0' || step.type === 'z1' || step.type === 'z2') {
      colors[0] = 'sorted';
      colors[1] = 'compare';
      colors[2] = step.type === 'z2' ? 'compare' : 'merge';
    } else if (step.type === 'combine' || step.type === 'combine-mid') {
      for (let i = 0; i < n; i++) colors[i] = i < 4 ? 'merge' : 'default';
    } else if (step.type === 'done') {
      for (let i = 0; i < n; i++) colors[i] = 'sorted';
    } else {
      for (let i = 0; i < n; i++) colors[i] = i < 2 ? 'pivot' : 'default';
    }
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.note || step.type });
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
