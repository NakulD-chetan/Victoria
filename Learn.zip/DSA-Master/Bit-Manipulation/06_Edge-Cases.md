# Bit Manipulation — Edge Cases

> **FAANG Focus:** Always consider these; interviewers probe for them.

---

## 1. Zero

| Operation | Behavior | Handle |
|-----------|----------|--------|
| `n & (n-1)` | `0 & (-1)` — undefined for unsigned | Check `n > 0` first |
| `n & (-n)` | `0 & 0` = 0 | Check `n != 0` |
| `__builtin_ctz(0)` | **UB in C++** | Guard: `if (n) ctz(n)` |
| Power of 2 | 0 has no set bits | `n > 0 && (n & (n-1)) == 0` |
| Popcount | 0 has 0 bits | OK |
| XOR single number | `[0]` → 0 | OK |

```
n=0:
  n & (n-1)  →  0 & (-1)  →  undefined for unsigned!
  n & (-n)   →  0 & 0     →  0
```

---

## 2. Negative Numbers

| Scenario | Issue | Fix |
|----------|-------|-----|
| Right shift signed | Implementation-defined | Use unsigned |
| `-n` for INT_MIN | Overflow (e.g. `-(-2^31)` = 2^31 overflow) | Use unsigned or check |
| `n & (-n)` for negative | Works (two's complement) | Usually OK |
| XOR with negatives | Cancellation still works | OK |

```
INT_MIN = -2^31
-INT_MIN overflows in signed 32-bit!
```

---

## 3. Overflow

| Operation | Risk | Fix |
|-----------|------|-----|
| `1 << 31` (int) | Signed overflow UB | `1u << 31` or `1LL << 31` |
| `1 << 32` | Shift ≥ width = UB | Use 64-bit: `1LL << 32` |
| `n << k` | Bits lost if k large | Ensure k < bit width |
| Multiplication via shift | Same as above | Check range |

---

## 4. Single Element

| Problem | Edge Case |
|---------|-----------|
| Single number (XOR) | `[x]` → return x |
| Two single numbers | `[a, b]` → xor_all = a^b, split works |
| Subsets | `[]` → `[[]]` |
| Power of 2 | 1 is power of 2 ✓ |

---

## 5. All Same Bits

| Scenario | Behavior |
|----------|----------|
| All elements same | XOR all = 0 (if even count) or x (if odd) |
| All zeros | XOR = 0 |
| Single number among pairs | One unique → XOR gives it |

---

## 6. Boundary Values

| Value | Check |
|-------|-------|
| n = 1 | Subsets: `[[], [x]]` |
| n = 31 | Bitmask: 2^31 states — may be too large |
| n = 32 | Use `1LL << 32` in C++ |
| MAX_INT | `n & (n-1)` for 2^31-1: has multiple bits |

---

## 7. Quick Reference Table

| Edge | XOR | n&(n-1) | n&(-n) | Popcount | Subsets |
|------|-----|---------|--------|----------|---------|
| n=0 | 0 | Careful | 0 | 0 | `[[]]` |
| n=1 | x | N/A | 1 | 1 | `[[],[x]]` |
| Negative | OK | Use unsigned | OK | Careful | N/A |
| INT_MIN | OK | - | Overflow | - | - |

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  n=0: n&(n-1) undefined for unsigned; ctz(0) UB  │
│  Negative: right shift impl-defined; use unsigned│
│  Overflow: 1<<31 UB; use 1u<<31 or 1LL<<40     │
│  Single elem: XOR returns it; subsets [[], [x]]  │
│  All same: XOR cancels to 0 or x                 │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] n=0: guard `n > 0` for power-of-2; `ctz(0)` UB in C++
- [ ] Negative: use unsigned for shifts
- [ ] Overflow: `1 << 31` UB; use `1u` or `1LL`
- [ ] Single element: valid for XOR/subsets
- [ ] All same: XOR = 0 (even count) or x (odd)
