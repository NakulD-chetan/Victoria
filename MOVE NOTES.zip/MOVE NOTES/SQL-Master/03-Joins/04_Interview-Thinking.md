# Joins — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is a JOIN?
**A:** Combines rows from two or more tables based on a related column (predicate). Types: INNER, LEFT, RIGHT, FULL OUTER, CROSS, SELF.

### Q: INNER JOIN vs LEFT JOIN?
**A:** INNER returns only matching rows from both tables. LEFT returns ALL rows from left table + matching rows from right (NULL where no match). Use LEFT when the left entity must always appear.

### Q: What is a FULL OUTER JOIN?
**A:** Returns ALL rows from both tables. Where there's a match, combines them. Where there's no match, fills NULLs for the missing side.

### Q: What is a CROSS JOIN?
**A:** Cartesian product — every row from table A paired with every row from table B. If A has 10 rows and B has 5, result = 50 rows. No ON clause needed.

### Q: What is a SELF JOIN?
**A:** Joining a table with itself using different aliases. Common use: employee-manager relationship, comparing rows within same table.

### Q: What is NATURAL JOIN? Should we use it?
**A:** Joins on ALL columns with matching names automatically. Avoid in production — fragile, if column names change the join changes silently. Prefer explicit `ON`.

### Q: What is the USING clause?
**A:** Shorthand when join column has same name in both tables. `JOIN t2 USING (id)` — cleaner than `ON t1.id = t2.id`, and column appears only once in result.

### Q: What happens when JOIN keys have NULLs?
**A:** NULL = NULL is UNKNOWN in SQL, not TRUE. So rows with NULL join keys won't match in equi-join. Handle with COALESCE or IS NULL logic.

### Q: What is an Anti-Join?
**A:** Finding rows in A that have NO match in B. Three methods: LEFT JOIN + IS NULL, NOT EXISTS, NOT IN. Prefer NOT EXISTS for NULL safety.

### Q: What is a Semi-Join?
**A:** Returns rows from A where a match EXISTS in B, but doesn't add columns from B. Implemented with EXISTS subquery.

### Q: ON vs WHERE in LEFT JOIN — what's the difference?
**A:** In LEFT JOIN, conditions in ON filter the right table before joining (left rows preserved). Conditions in WHERE filter AFTER join — can remove left rows with no match, effectively making it an INNER join.

### Q: What causes duplicate rows after JOIN?
**A:** One-to-many relationship — one row in left matches multiple in right. Called "fan-out." Fix: aggregate after join, or join at correct grain.

### Q: What are Join algorithms?
**A:** Nested Loop (scan inner for each outer row), Hash Join (build hash table, probe), Merge Join (sort both, merge). Optimizer picks based on data size and indexes.

### Q: Join vs Subquery — which is better?
**A:** Often equivalent performance (optimizer rewrites). Joins are more readable for combining columns. Subqueries better for existence checks. Correlated subquery can be slower without optimization.

### Q: Can we join more than 2 tables?
**A:** Yes, chain joins. Each JOIN adds one more table. Order matters for readability; optimizer may reorder.

---

## Follow-up traps

- **"Can you do a LEFT JOIN without an ON clause?"** → No (syntax error). Only CROSS JOIN has no ON.
- **"What if you join on non-key columns?"** → Works but may produce many-to-many (cartesian-like explosion).
- **"RIGHT JOIN vs LEFT JOIN?"** → Logically equivalent if you swap table order. Convention: prefer LEFT for consistency.

---

*Next: [[05_Common-Mistakes]]*
