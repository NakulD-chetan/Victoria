const SUPABASE_URL = 'https://svuumfizxptnxaidishq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';

const REST_BASE = `${SUPABASE_URL}/rest/v1`;
const HEADERS = {
  'apikey': SUPABASE_ANON_KEY,
  'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
  'Content-Type': 'application/json',
  'Prefer': 'return=representation',
};

async function dbFetch(path, options = {}, retries = 3) {
  const url = `${REST_BASE}${path}`;
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(url, {
        ...options,
        headers: { ...HEADERS, ...options.headers },
      });
      return res;
    } catch (err) {
      if (attempt === retries) throw err;
      const delay = 1000 * attempt + Math.random() * 500;
      await new Promise(r => setTimeout(r, delay));
    }
  }
}

export class AlgorithmService {
  async listAlgorithms({ page = 1, limit = 20, category, tag, difficulty, q } = {}) {
    const offset = (page - 1) * limit;
    let query = `?select=id,slug,title,category,difficulty,short_description,icon,color,languages,tags,visualizer_key,sort_order&published=eq.true&order=sort_order.asc,id.asc&offset=${offset}&limit=${limit}`;

    if (category && category !== 'All') query += `&category=eq.${encodeURIComponent(category)}`;
    if (difficulty) query += `&difficulty=eq.${encodeURIComponent(difficulty)}`;
    if (tag) query += `&tags=cs.{${encodeURIComponent(tag)}}`;
    if (q) query += `&or=(title.ilike.*${encodeURIComponent(q)}*,short_description.ilike.*${encodeURIComponent(q)}*)`;

    const [dataRes, countRes] = await Promise.all([
      dbFetch(`/algorithms${query}`),
      dbFetch(`/algorithms?select=id&published=eq.true${category && category !== 'All' ? `&category=eq.${encodeURIComponent(category)}` : ''}${difficulty ? `&difficulty=eq.${encodeURIComponent(difficulty)}` : ''}${tag ? `&tags=cs.{${encodeURIComponent(tag)}}` : ''}${q ? `&or=(title.ilike.*${encodeURIComponent(q)}*,short_description.ilike.*${encodeURIComponent(q)}*)` : ''}`, {
        headers: { ...HEADERS, 'Prefer': 'count=exact', 'Range-Unit': 'items', 'Range': '0-0' },
      }),
    ]);

    const data = dataRes.ok ? await dataRes.json() : [];
    const contentRange = countRes.headers.get('content-range');
    const total = contentRange ? parseInt(contentRange.split('/')[1]) || data.length : data.length;

    return { data, total, page, limit };
  }

  async getAlgorithmBySlug(slug) {
    const algoRes = await dbFetch(`/algorithms?slug=eq.${encodeURIComponent(slug)}&published=eq.true&select=*&limit=1`);
    if (!algoRes.ok) return null;
    const algos = await algoRes.json();
    if (algos.length === 0) return null;
    const algo = algos[0];

    const [contentRes, codeRes] = await Promise.all([
      dbFetch(`/algorithm_content?algorithm_id=eq.${algo.id}&select=lang,intro_markdown`),
      dbFetch(`/algorithm_code?algorithm_id=eq.${algo.id}&select=language,code_lines,step_info,steps_allow,steps_deny`),
    ]);

    const contents = contentRes.ok ? await contentRes.json() : [];
    const codes = codeRes.ok ? await codeRes.json() : [];

    const introEnglish = contents.find(c => c.lang === 'en')?.intro_markdown || '';
    const introHinglish = contents.find(c => c.lang === 'hi')?.intro_markdown || '';

    const code = {};
    const steps = {};
    let stepsAllow = [];
    let stepsDeny = [];
    for (const c of codes) {
      code[c.language] = c.code_lines;
      if (Object.keys(steps).length === 0 && c.step_info) Object.assign(steps, c.step_info);
      if (c.steps_allow?.length) stepsAllow = c.steps_allow;
      if (c.steps_deny?.length) stepsDeny = c.steps_deny;
    }

    return {
      meta: {
        id: algo.id,
        slug: algo.slug,
        title: algo.title,
        category: algo.category,
        difficulty: algo.difficulty,
        shortDescription: algo.short_description,
        icon: algo.icon,
        color: algo.color,
        languages: algo.languages || [],
        tags: algo.tags || [],
      },
      introEnglish,
      introHinglish,
      code,
      steps,
      stepsAllow,
      stepsDeny,
      defaultParams: algo.default_params || {},
      visualizerKey: algo.visualizer_key,
    };
  }

  async getCategories() {
    const res = await dbFetch(`/algorithms?select=category&published=eq.true`);
    if (!res.ok) return [];
    const rows = await res.json();
    const counts = {};
    rows.forEach(r => { counts[r.category] = (counts[r.category] || 0) + 1; });
    return Object.entries(counts).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  }

  async getTags() {
    const res = await dbFetch(`/algorithms?select=tags&published=eq.true`);
    if (!res.ok) return [];
    const rows = await res.json();
    const counts = {};
    rows.forEach(r => { (r.tags || []).forEach(t => { counts[t] = (counts[t] || 0) + 1; }); });
    return Object.entries(counts).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  }

  async listProblems({ page = 1, limit = 20, difficulty, q } = {}) {
    const offset = (page - 1) * limit;
    let query = `?select=id,slug,number,title,icon,difficulty&published=eq.true&order=number.asc&offset=${offset}&limit=${limit}`;

    if (difficulty) query += `&difficulty=eq.${encodeURIComponent(difficulty)}`;
    if (q) query += `&or=(title.ilike.*${encodeURIComponent(q)}*,description.ilike.*${encodeURIComponent(q)}*)`;

    const res = await dbFetch(`/problems${query}`, {
      headers: { 'Prefer': 'count=exact, return=representation' },
    });
    const data = res.ok ? await res.json() : [];
    const contentRange = res.headers?.get('content-range') || '';
    const total = contentRange.includes('/') ? parseInt(contentRange.split('/')[1], 10) || data.length : data.length;
    return { data, total, page, limit };
  }

  async getProblemBySlug(slug) {
    return this.getProblemFull(slug);
  }

  async getProblemFull(slug) {
    const res = await dbFetch(`/problems?slug=eq.${encodeURIComponent(slug)}&published=eq.true&select=*&limit=1`);
    if (!res.ok) return null;
    const rows = await res.json();
    if (!rows[0]) return null;
    const row = rows[0];
    return {
      ...row,
      testCases: row.test_cases || [],
      requirementChecklist: row.requirement_checklist || {},
      expectedAPIs: row.expected_apis || [],
      chaosScenarios: row.chaos_scenarios || [],
      deepDiveQuestions: row.deep_dive_questions || [],
      scoring: row.scoring || { requirements: 20, api: 15, architecture: 40, deepDive: 25 },
    };
  }

  async getProblemForClient(slug) {
    const full = await this.getProblemFull(slug);
    if (!full) return null;

    const safeDeepDive = (full.deepDiveQuestions || []).map(q => ({
      question: q.question,
      options: q.options,
    }));

    const safeChaos = (full.chaosScenarios || []).map(s => ({
      label: s.label,
      type: s.type,
    }));

    const safeTestCases = (full.testCases || []).map(tc => ({
      name: tc.name,
      type: tc.type,
      ...(tc.rps ? { rps: tc.rps } : {}),
    }));

    return {
      id: full.id,
      slug: full.slug,
      number: full.number,
      icon: full.icon,
      title: full.title,
      difficulty: full.difficulty,
      description: full.description,
      requirements: full.requirements,
      constraints: full.constraints,
      hints: full.hints,
      testCases: safeTestCases,
      requirementChecklist: full.requirementChecklist,
      expectedAPIs: full.expectedAPIs,
      chaosScenarios: safeChaos,
      deepDiveQuestions: safeDeepDive,
    };
  }

  async saveSubmission(data) {
    const res = await dbFetch('/submissions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => 'unknown');
      throw new Error(`Failed to save submission: ${text}`);
    }
    const rows = await res.json();
    return rows[0]?.id || null;
  }

  async upsertAlgorithm(data) {
    const res = await dbFetch('/algorithms', {
      method: 'POST',
      headers: { ...HEADERS, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify(data),
    });
    return res.ok ? (await res.json())[0] : null;
  }

  async upsertContent(algorithmId, lang, markdown) {
    const res = await dbFetch('/algorithm_content', {
      method: 'POST',
      headers: { ...HEADERS, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify({ algorithm_id: algorithmId, lang, intro_markdown: markdown }),
    });
    return res.ok;
  }

  async upsertCode(algorithmId, language, codeLines, stepInfo, stepsAllow, stepsDeny) {
    const res = await dbFetch('/algorithm_code', {
      method: 'POST',
      headers: { ...HEADERS, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify({
        algorithm_id: algorithmId, language,
        code_lines: codeLines, step_info: stepInfo,
        steps_allow: stepsAllow, steps_deny: stepsDeny,
      }),
    });
    return res.ok;
  }

  async upsertProblem(data) {
    const { requirement_checklist, expected_apis, chaos_scenarios, deep_dive_questions, scoring, ...safeData } = data;
    const res = await dbFetch('/problems', {
      method: 'POST',
      headers: { ...HEADERS, 'Prefer': 'resolution=merge-duplicates,return=representation' },
      body: JSON.stringify(safeData),
    });
    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      console.error(`[upsertProblem] ${res.status}: ${errText}`);
      return null;
    }
    return (await res.json())[0] || null;
  }
}
