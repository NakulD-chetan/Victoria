# Back-of-Envelope Estimation — Tricks and Recognition

> **Permanent Recall:** Quick shortcuts: **1M seconds ≈ 12 days**, **1B seconds ≈ 32 years**, **86400 ≈ 100K** sec/day, **2.5M** sec/month. Use rule-of-thumb formulas per system type. Recognition patterns help you estimate faster in interviews.

---

## Time Conversion Shortcuts

| Conversion | Value | Use Case |
|------------|-------|----------|
| 1 million seconds | ~12 days | "1M events in 2 weeks" |
| 1 billion seconds | ~32 years | Sanity check for large numbers |
| Seconds per day | 86,400 ≈ 10^5 | QPS from daily volume |
| Seconds per month | ~2.5 × 10^6 | Monthly aggregates |
| Seconds per year | ~3.15 × 10^7 | Yearly retention |

```
    1M sec  = 11.6 days   ≈ 12 days
    1B sec  = 31.7 years   ≈ 32 years
    86400   = 8.64 × 10^4  ≈ 100K (round up)
```

---

## Common Conversion Factors

| From | To | Factor |
|------|-----|--------|
| Days → seconds | × 86400 | Or × 10^5 |
| Bytes → bits | × 8 | For bandwidth |
| KB → bytes | × 1000 | (or 1024 for exact) |
| Mbps → MB/s | ÷ 8 | 8 Mbps = 1 MB/s |
| GB → TB | ÷ 1000 | 1000 GB = 1 TB |

---

## Rule of Thumb by System Type

| System | Quick Formula | Dominant Metric |
|--------|---------------|-----------------|
| **Social feed** | DAU × 10 / 100K ≈ read QPS | Read QPS |
| **Chat** | DAU × 50 / 100K ≈ msg QPS | Msg/sec |
| **Search** | DAU × 5 / 100K ≈ search QPS | Query QPS |
| **E-commerce** | DAU × 10 / 100K ≈ page QPS | Read QPS |
| **Video** | Concurrent × 5 Mbps = egress | Bandwidth |

> **FAANG Tip:** DAU × actions_per_day / 100000 gives QPS in one step (86400 ≈ 100K).

---

## Quick Capacity Planning Formulas

```
    Web servers    = Peak QPS / 1000
    DB read repl.  = Read QPS / 5000
    Cache (Redis)  = Read QPS / 100000  (if 80% cache hit: 20% to DB)
    Kafka parts    = Write QPS / 10000  (order of magnitude)
```

---

## "Napkin Math" Rounding Rules

| Number | Round To | Why |
|--------|----------|-----|
| 86400 | 100,000 | Easier division |
| 47,000 | 50,000 | Order of magnitude |
| 1.7M | 2M | Cleaner |
| 0.5 | 1/2 | Fractions for ratios |

---

## Recognition: Spot the Scale

| Mentioned | Implies | Estimation hint |
|-----------|---------|-----------------|
| "100M users" | Large consumer | ~10K–100K QPS |
| "1B users" | FAANG scale | ~100K–1M QPS |
| "Real-time" | Low latency | Sub-100ms, cache/DB |
| "Viral" | Spiky | 10× peak factor |
| "Global" | Multi-region | 150ms RTT, regional capacity |
| "5 years" | Long retention | Storage × years |

---

## Capacity Cheat Sheet

```
    COMPONENT          CAPACITY
    ─────────────────────────────────
    Web server          ~1,000 QPS
    DB read             ~5,000 QPS
    DB write            ~1,000 QPS
    Redis               ~100,000 QPS
    Kafka partition     ~10–100K msg/s
    CDN (per edge)      Gbps–Tbps
```

---

## One-Line Estimations

| Question | One-Liner |
|----------|-----------|
| QPS from DAU | DAU × actions / 100K |
| Storage for tweets | tweets × 300 bytes × 3 |
| Bandwidth | QPS × response_bytes × 8 |
| Web servers | Peak QPS / 1K |

---

## Fraction Approximations

| Fraction | Decimal | Use |
|----------|---------|-----|
| 1/10 | 0.1 | 10% of X |
| 1/5 | 0.2 | 20% |
| 1/3 | 0.33 | Peak factor, cache miss |
| 2/3 | 0.67 | Majority |

---

## Exponential / Growth Shortcuts

| Growth | Doubling Time |
|--------|---------------|
| 10% / year | ~7 years |
| 25% / year | ~3 years |
| 50% / year | ~1.4 years |

Rule of 72: 72 / growth_rate ≈ doubling time in years.

---

## 30-SECOND REVISION BOX

```
TIME: 1M sec≈12 days, 1B sec≈32 yrs, 86400≈100K
UNITS: ×8 bytes→bits, ÷8 Mbps→MB/s
QPS: DAU×actions/100K
CAPACITY: Web 1K, DB 5K, Redis 100K
SYSTEM RULES: Feed 10/100K, Chat 50/100K, Video concurrent×5Mbps
```

---

**Next: [[08_Question-List]]**
