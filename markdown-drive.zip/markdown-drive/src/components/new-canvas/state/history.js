/**
 * Linear undo/redo with two features the naive version lacks:
 *
 * 1. Snapshots are *pointers* to element arrays (structural sharing via the
 *    store's immutable updates), so memory cost == number of undo steps, not
 *    number of elements.
 *
 * 2. Coalescing: a caller marks a commit as "chainable" (e.g. while moving
 *    a selection with the arrow keys) and successive chainable commits are
 *    merged into one undo entry until a non-chainable commit breaks the chain.
 */

const MAX_HISTORY = 200;

export function createHistory(initialElements = []) {
  return {
    past: [],
    present: initialElements,
    future: [],
    lastCoalesceKey: null,
  };
}

/**
 * Push a new state. `coalesceKey` lets back-to-back commits with the same key
 * merge — only the first snapshot before the run is kept in `past`.
 */
export function commit(hist, nextElements, coalesceKey = null) {
  const canCoalesce =
    coalesceKey != null && hist.lastCoalesceKey === coalesceKey && hist.past.length > 0;

  if (canCoalesce) {
    return {
      past: hist.past,
      present: nextElements,
      future: [],
      lastCoalesceKey: coalesceKey,
    };
  }

  const past = hist.past.concat([hist.present]);
  if (past.length > MAX_HISTORY) past.shift();
  return {
    past,
    present: nextElements,
    future: [],
    lastCoalesceKey: coalesceKey,
  };
}

export function undo(hist) {
  if (hist.past.length === 0) return hist;
  const previous = hist.past[hist.past.length - 1];
  return {
    past: hist.past.slice(0, -1),
    present: previous,
    future: [hist.present, ...hist.future],
    lastCoalesceKey: null,
  };
}

export function redo(hist) {
  if (hist.future.length === 0) return hist;
  const next = hist.future[0];
  return {
    past: hist.past.concat([hist.present]),
    present: next,
    future: hist.future.slice(1),
    lastCoalesceKey: null,
  };
}

export function canUndo(hist) { return hist.past.length > 0; }
export function canRedo(hist) { return hist.future.length > 0; }
