# Top Python Questions for Amazon DE2 - Interview Answer Format

## One-Line Goal

Amazon DE2 Python rounds usually test practical ETL-style coding: parsing data, transforming records, handling bad input, and writing clean readable logic.

---

## How to Answer Python Coding Questions

Use this structure:

1. Clarify input and output
2. Explain the approach in 2-3 lines
3. Write simple readable code
4. Mention edge cases
5. Mention production improvements

### Strong opening line

> "Before I code, I want to confirm the input shape, expected output, and what to do with malformed or missing data."

---

## What Interviewers Usually Test

- dictionaries and lists
- parsing
- aggregation
- deduplication
- file handling
- timestamps
- error handling

They care about:

- correctness
- readability
- edge cases
- time and space complexity awareness

---

## 1. Count Events by Key

### Common prompt

Given a list of events, count how many events came from each `user_id`.

### What to say first

> "I would iterate once through the events and keep a dictionary from `user_id` to count."

### Pattern

```python
def count_events_by_user(events):
    counts = {}

    for event in events:
        user_id = event.get("user_id")
        if user_id is None:
            continue

        counts[user_id] = counts.get(user_id, 0) + 1

    return counts
```

### What this tests

- dictionary usage
- safe field access
- linear scan aggregation

---

## 2. Deduplicate by Latest Timestamp

### Common prompt

Given multiple records for a customer, keep only the latest one.

### What to say first

> "I would keep a dictionary keyed by customer and update it whenever I see a newer timestamp."

### Pattern

```python
def latest_record_by_customer(records):
    latest = {}

    for record in records:
        customer_id = record["customer_id"]
        updated_at = record["updated_at"]

        if customer_id not in latest or updated_at > latest[customer_id]["updated_at"]:
            latest[customer_id] = record

    return list(latest.values())
```

### Follow-up point

- common in ETL and CDC logic

---

## 3. Parse JSON Safely

### Common prompt

Read JSON lines and return only valid events.

### What to say first

> "I would parse line by line with `try/except` so one bad record does not crash the whole batch."

### Pattern

```python
import json


def parse_valid_events(lines):
    valid_events = []

    for line in lines:
        try:
            event = json.loads(line)
            valid_events.append(event)
        except json.JSONDecodeError:
            continue

    return valid_events
```

### Better discussion

- count bad records
- send bad rows to quarantine instead of silently dropping

---

## 4. Group and Aggregate

### Common prompt

Compute total revenue per product.

### What to say first

> "This is a standard aggregation problem, so I would use a dictionary from product ID to running total."

### Pattern

```python
def revenue_by_product(records):
    totals = {}

    for record in records:
        product_id = record["product_id"]
        revenue = record.get("revenue", 0)

        totals[product_id] = totals.get(product_id, 0) + revenue

    return totals
```

---

## 5. Deduplicate Events

### Common prompt

Remove duplicate events using `event_id`.

### What to say first

> "I would keep a `seen` set of event IDs and only append the first occurrence of each event."

### Pattern

```python
def deduplicate_events(events):
    seen = set()
    deduped = []

    for event in events:
        event_id = event.get("event_id")
        if event_id is None or event_id in seen:
            continue

        seen.add(event_id)
        deduped.append(event)

    return deduped
```

### Interview point

- for very large data, in-memory sets may not be enough

---

## 6. Normalize Raw Records

### Common prompt

Convert raw order events into curated records with normalized fields.

### What to say first

> "I would map each raw record into a clean canonical output schema and apply type conversions carefully."

### Pattern

```python
def normalize_orders(raw_orders):
    curated = []

    for order in raw_orders:
        curated.append(
            {
                "order_id": str(order["order_id"]),
                "customer_id": str(order["customer_id"]),
                "amount": float(order.get("amount", 0)),
                "status": order.get("status", "UNKNOWN").upper(),
            }
        )

    return curated
```

---

## 7. Top N Values

### Common prompt

Return the top 3 customers by total spend.

### What to say first

> "I would first aggregate spend per customer, then sort descending and keep the top N."

### Pattern

```python
def top_customers_by_spend(records, top_n=3):
    spend_by_customer = {}

    for record in records:
        customer_id = record["customer_id"]
        amount = record.get("amount", 0)
        spend_by_customer[customer_id] = spend_by_customer.get(customer_id, 0) + amount

    ranked = sorted(
        spend_by_customer.items(),
        key=lambda item: item[1],
        reverse=True,
    )

    return ranked[:top_n]
```

---

## 8. Process Files Line by Line

### Common prompt

Read a large log file without loading everything into memory.

### What to say first

> "I would stream the file line by line using a `with open(...)` block instead of reading the full file at once."

### Pattern

```python
def count_error_lines(file_path):
    error_count = 0

    with open(file_path, "r", encoding="utf-8") as file:
        for line in file:
            if "ERROR" in line:
                error_count += 1

    return error_count
```

### Why this matters

- tests memory awareness

---

## 9. Basic ETL Class

### Common prompt

Show how you would structure a simple ETL job.

### What to say first

> "I would separate extract, transform, and load into different methods so the code stays testable and easier to maintain."

### Pattern

```python
class ETLJob:
    def extract(self):
        return [{"id": 1, "value": "10"}, {"id": 2, "value": "20"}]

    def transform(self, records):
        output = []
        for record in records:
            output.append({"id": record["id"], "value": int(record["value"])})
        return output

    def load(self, records):
        return len(records)

    def run(self):
        raw_records = self.extract()
        transformed_records = self.transform(raw_records)
        return self.load(transformed_records)
```

### Production follow-up

- add logging
- add retries
- add validation
- add exception handling

---

## 10. Data Quality Validation

### Common prompt

Validate records before loading them.

### What to say first

> "I would separate valid and invalid records so bad data can be quarantined instead of silently dropped."

### Pattern

```python
def validate_orders(orders):
    valid_orders = []
    invalid_orders = []

    for order in orders:
        if (
            order.get("order_id") is not None
            and order.get("customer_id") is not None
            and order.get("amount", 0) >= 0
        ):
            valid_orders.append(order)
        else:
            invalid_orders.append(order)

    return valid_orders, invalid_orders
```

---

## 11. Timestamp Parsing

### Common prompt

Parse timestamps and filter events from the last 24 hours.

### What to say first

> "I would parse each timestamp into a `datetime`, compute the cutoff time once, and keep only events newer than that cutoff."

### Pattern

```python
from datetime import datetime, timedelta


def filter_recent_events(events, now):
    cutoff = now - timedelta(hours=24)
    recent = []

    for event in events:
        event_time = datetime.fromisoformat(event["event_time"])
        if event_time >= cutoff:
            recent.append(event)

    return recent
```

---

## Practice Questions

1. Merge two sorted lists of event timestamps
2. Count word frequency in log lines
3. Parse CSV rows and reject malformed records
4. Deduplicate records by composite key
5. Aggregate daily revenue by region
6. Find the most recent record per entity
7. Build a retry wrapper for flaky API calls
8. Design a small ETL class with extract, transform, and load methods

---

## Common Mistakes

1. Ignoring missing keys or nulls
2. Writing everything in one giant function
3. Using too much memory
4. No error handling for bad input
5. Poor variable names
6. Forgetting to explain complexity

---

## Good Things to Mention in Interviews

- input validation
- logging
- exception handling
- idempotency
- memory efficiency
- testability
- clean function boundaries

---

## Interview Tips

- Write simple readable code first
- Explain assumptions clearly
- Mention edge cases and bad input
- Say what you would improve for production scale
- If asked for optimization, first explain current complexity

---

## Quick Revision (5 points)

1. Clarify input, output, and bad-data behavior before coding
2. Explain the approach first, then write simple code
3. Dictionaries, sets, loops, parsing, and file handling are core DE2 skills
4. Handle missing data, malformed input, and duplicates explicitly
5. Mention production concerns like logging, retries, and idempotency
