# 4. Consumers & Consumer Groups

> **Permanent Recall Note:** Consumers **pull** records and **advance offsets**. A **consumer group** is a **load-balanced subscription**: each partition is assigned to **at most one** consumer in the group at a time. **Rebalancing** redistributes partitions on join/leave/failure — the silent cause of **duplicates** and **latency spikes**. Cross-reference: Spark’s Kafka integration manages offsets in checkpoint — relate to “processing vs commit” here and in [../spark/10_Structured_Streaming_DE.md](../spark/10_Structured_Streaming_DE.md).

### The 10-Second Summary
- **Group coordinator** broker handles **join/sync** protocol.
- **Assignors** implement Range / RoundRobin / Sticky / CooperativeSticky.
- **Offsets:** `__consumer_offsets` internal topic (or ZooKeeper legacy).
- **Lag** = broker end − consumer position — **primary** DE health metric.

---

# 4.1 Consumer Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Consumer (each member)                                      │
│  • Fetcher threads → partition streams                       │
│  • Deserializers                                             │
│  • Offset committer (auto/manual)                            │
│  • Heartbeat thread (group protocol)                         │
└─────────────────────────────────────────────────────────────┘
         │ Fetch                    │
         ▼                          │
    Broker leaders ◄────────────────┘
```

💡 **Key Insight:** **One partition → one consumer in group** for active processing; more consumers than partitions ⇒ **idle** members.

---

# 4.2 Consumer Groups — Fan-Out vs Load Balance

```
TOPIC (3 partitions)

Consumer Group "etl":
  C1 ← P0    C2 ← P1    C3 ← P2     (3 consumers)

Consumer Group "monitoring":
  independent offsets — same topic, separate progress
```

📏 **Golden Rule:** **Multiple groups** = **fan-out**; **multiple consumers in one group** = **scale-out** with partition ceiling.

---

# 4.3 Group Coordinator

- One broker is **coordinator** for `group.id` hash.
- Handles **JoinGroup**, **SyncGroup**, **Heartbeat**, **OffsetCommit**.

---

# 4.4 Partition Assignment Strategies

| Assignor | Notes |
|----------|-------|
| **Range** | Sub-ranges per consumer — topic-heavy skew possible |
| **RoundRobin** | Round-robin partitions |
| **Sticky** | Keep assignment stable when possible |
| **CooperativeSticky** | **Revoke incrementally** — less stop-the-world |

🔄 **Trade-off:** Cooperative needs **consumer version** support — upgrade brokers/clients in lockstep in prod.

---

# 4.5 Rebalancing — Eager vs Cooperative

**Eager (classic):** revoke **all** partitions → reassign — **pause** processing.

**Cooperative:** revoke **subset** → handoff smoother.

⚠️ **Warning:** **Rebalance storm** — frequent session timeouts (GC, slow poll) ⇒ constant rebalance ⇒ **lag explosion**.

---

# 4.6 Offset Management — Auto vs Manual

```properties
enable.auto.commit=true
auto.commit.interval.ms=5000
```

| Mode | Pros | Cons |
|------|------|------|
| **Auto** | Simple | May commit **before** processing completes |
| **Manual** | At-least-once control | You must **commit after** success |

🏗️ **Production:** **Manual commit** (or transactional EOS) for **exactly-once** pipelines when combined with idempotent sinks.

---

# 4.7 Committed Offset vs Current Position

- **Current position:** in-memory where next fetch continues (may be ahead of commit).
- **Committed:** stored in `__consumer_offsets` for restart recovery.

🧠 **Memory Trick:** **Commit** = “safe to restart here”; **current** = “already read to here” — gap ⇒ **reprocess** on crash if commit lags.

---

# 4.8 Consumer Lag

```
lag_per_partition ≈ log_end_offset - consumer_offset
```

- **Burrow**, **Kafka Lag Exporter**, **Prometheus** + Grafana dashboards.

🔥 **Pro Tip:** Alert on **max lag** and **lag growth rate**, not only absolute value.

---

# 4.9 __consumer_offsets Topic

- Internal **compact** topic storing **(group, topic, partition) → offset**.
- **offsets.retention.minutes** — old group metadata expiry.

---

# 4.10 Static Group Membership

```properties
group.instance.id=consumer-1
```

- **Stable identity** — on restart, **no immediate rebalance** identity story (reduces churn).

💡 **Use when:** fixed consumer instances with **predictable** IDs.

---

# 4.11 Heartbeat & Session Timeout

| Config | Role |
|--------|------|
| `session.timeout.ms` | Missed heartbeats ⇒ **dead** member |
| `heartbeat.interval.ms` | How often to ping |
| `max.poll.interval.ms` | Max between `poll()` — **long processing** must stay under |

⚠️ **Warning:** **max.poll.interval** too low + **heavy** `process()` ⇒ **rebalance** while processing.

---

# 4.12 max.poll.records & max.poll.interval.ms

```properties
max.poll.records=500
max.poll.interval.ms=300000
```

- Pull **more** records per poll → faster throughput but **longer** processing per batch.
- Tune together with **processing time** — Spark/Flink manage differently.

---

# 4.13 Java — Manual commit pattern

```java
while (true) {
    ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(1000));
    for (ConsumerRecord<String, String> r : records) {
        process(r);
    }
    consumer.commitSync(); // after batch success
}
```

---

# 4.14 Partition EOF & Seek (Advanced)

```java
consumer.seekToEnd(Collections.singletonList(tp));
consumer.seek(tp, 100L); // jump for replay / recovery tools
```

Simple bhasha mein: **seek** se **replay** and **rewind** testing easy — production mein **careful** with committed offsets.

---

# 4.15 Consumer Config Quick Reference

```properties
group.id=my-service
enable.auto.commit=false
isolation.level=read_committed   # with transactional producer
partition.assignment.strategy=org.apache.kafka.clients.consumer.CooperativeStickyAssignor
```

---

# 4.16 Interview Questions & Answers

**Q: Same message do groups ko alag alag milega?**  
**A:** **Haan** — independent offsets; fan-out pattern.

**Q: Ek group mein do consumer same partition?**  
**A:** **Nahi** — active assignment mein **one consumer per partition**.

**Q: Lag badh gaya — pehla check?**  
**A:** **Processing slow**, **rebalance loop**, **broker ISR issues**, **downstream** bottleneck — **metrics** se narrow karo.

**Q: Spark streaming offset?**  
**A:** Checkpoint — conceptually **committed offset** tied to **micro-batch** completion — see Spark notes.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 4 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Group = load-balanced; groups = fan-out                 │
│  🧠 Coordinator + assignor + rebalance protocol             │
│  🧠 poll interval + session timeout = stability             │
│  🧠 Lag = primary health metric                              │
│  ⚠️  Long GC ⇒ missed heartbeat ⇒ rebalance storm           │
│  🎯 CooperativeSticky + static ids in stable deployments    │
└─────────────────────────────────────────────────────────────┘
```
