const BORDER_COLORS = {
  blue: 'var(--accent-secondary)',
  green: 'var(--accent)',
  red: 'var(--danger)',
};

export default function ExplanationBox({ step, liveValues, borderColor }) {
  const bc = borderColor ? BORDER_COLORS[borderColor] : 'var(--border)';

  return (
    <div className="dc-explanation" style={{ borderColor: bc }}>
      <div className="dc-explanation__icon">{step?.icon || '\uD83D\uDCA1'}</div>
      <div className="dc-explanation__body">
        <div className="dc-section-label">{step?.title || 'How it works'}</div>
        <div className="dc-explanation__text">
          {step?.text || 'Click "Send Request" to watch the algorithm execute step by step. Each line highlights as it runs.'}
        </div>
        {liveValues && <div className="dc-explanation__live">{liveValues}</div>}
      </div>
    </div>
  );
}
