# How URL Shortener Works - In Depth (Easy Language)

> Companion to: [05-How-URL-Shortener-Works.md](05-How-URL-Shortener-Works.md)

---

## What Problem Does a URL Shortener Solve?

### Long URLs Are Ugly and Impractical

```
Before: https://www.example.com/products/electronics/smartphones/samsung-galaxy-s24-ultra?color=black&storage=256gb&ref=homepage_banner_2024&utm_source=twitter

After:  https://bit.ly/3xK9mT2
```

URL shorteners are used for:
- **Social media** (Twitter/X had character limits)
- **Print materials** (nobody types a 200-character URL from a poster)
- **Analytics** (track how many people clicked the link)
- **Branded links** (companies create custom short URLs)

---

## The Three Ways to Generate Short URLs (and Why Two Fail)

### Method 1: Random UUID (BAD)

```
Generate a random ID like: 550e8400-e29b-41d4-a716-446655440000
Take first 7 characters: "550e840"

Problem:
  Two different long URLs could generate the SAME 7 chars!
  → Must check database: "Does this short URL exist?"
  → If yes, generate another random one and check again
  → If database has billions of URLs, this gets SLOW
  → Could loop forever in theory
```

**Why it fails**: High collision probability, expensive DB checks, no guarantee of uniqueness.

### Method 2: Hashing (MD5/SHA256) (BAD)

```
Hash the long URL:
  MD5("https://example.com/very-long-url") = "d41d8cd98f00b204e9800998ecf8427e"
  Take first 7 chars: "d41d8cd"

Problem:
  Different URLs can hash to same first 7 chars (collision!)
  Anyone can predict the short URL from the long URL (security risk)
  Still need DB check for collisions
```

**Why it fails**: Truncation causes collisions, output is predictable.

### Method 3: Token Range Service (THE WINNER)

```
How it works:

Token Range Service (ZooKeeper/DynamoDB):
  "Server 1, here's your range: 1,000,000 to 1,999,999"
  "Server 2, here's your range: 2,000,000 to 2,999,999"
  "Server 3, here's your range: 3,000,000 to 3,999,999"

Server 1 receives a new URL:
  Counter = 1,000,000 → encode to base62 → "4c92"
  Counter = 1,000,001 → encode to base62 → "4c93"
  Counter = 1,000,002 → encode to base62 → "4c94"
  ...

When Server 1 reaches 1,999,999:
  → Asks Token Range Service for a NEW range: 4,000,000 to 4,999,999
```

**Why this wins:**
- **Zero collisions** (each number used exactly once)
- **No DB lookups** needed to check for duplicates
- **O(1) time** to generate a short URL
- **Scales horizontally** (each server has its own non-overlapping range)

---

## Base62 Encoding - Making Numbers Readable

### What Is Base62?

We normally count in base 10 (digits 0-9). Base62 uses 62 characters: `a-z` (26) + `A-Z` (26) + `0-9` (10) = 62 characters.

```
Base 10 (decimal):  0, 1, 2, ... 9, 10, 11, ...
Base 62:            0, 1, 2, ... 9, a, b, c, ... z, A, B, ... Z, 10, 11, ...

Examples:
  Number 100,000     → base62: "q0U"
  Number 1,000,000   → base62: "4c92"  
  Number 3,500,000,000,000 → base62: "zzzzzzzz" (max with 7 chars)
```

### Why 7 Characters?

```
62^7 = 3,521,614,606,208 ≈ 3.5 TRILLION unique URLs

At 1,000 URLs per second:
  3.5 trillion / 1,000 / 60 / 60 / 24 / 365 = ~111,000 years

You'll NEVER run out!
```

### Base62 vs Base58

Some characters look confusingly similar:
- `O` (letter O) vs `0` (zero)
- `I` (letter I) vs `l` (letter L) vs `1` (one)

**Base58** removes these confusing characters. Bitcoin addresses use base58 for this reason.

---

## The Read Path - How Redirects Work (The Hard Part)

### Why Is the Read Path the Focus?

For every URL that's created (written), it gets clicked (read) about **100 times**. This is a 100:1 read-to-write ratio.

```
1 URL created → clicked 100 times on average

That means:
  Write QPS: ~1,200 URLs/sec created
  Read QPS: ~120,000 URLs/sec redirected
  
  The read path is 100x more important to optimize!
```

### Multi-Layer Caching Strategy

```
User clicks bit.ly/abc123
          ↓
Layer 1: CLIENT BROWSER CACHE
  "I visited this URL 5 min ago, I know where it goes"
  → Redirect without any network request!
  ↓ (cache miss)

Layer 2: CDN (CloudFlare, Akamai)
  Edge server near the user has cached the mapping
  → Redirect from edge location (~10ms latency)
  ↓ (cache miss)

Layer 3: REVERSE PROXY
  Nginx/Varnish in front of app servers
  → Return cached response
  ↓ (cache miss)

Layer 4: REDIS CACHE
  In-memory cache on app servers
  → Lookup in Redis (~1ms)
  ↓ (cache miss)

Layer 5: NoSQL DATABASE
  DynamoDB/MongoDB has the mapping
  → Lookup in DB (~5-10ms)
  ↓ (not found)

Layer 6: 404 NOT FOUND
  → Short URL doesn't exist
```

### Why So Many Layers?

Each layer catches a percentage of requests, preventing the next layer from being overwhelmed:

```
100,000 requests arrive
  → 50,000 served by browser cache (50%)
  → 30,000 served by CDN (30%)
  → 10,000 served by reverse proxy (10%)
  → 8,000 served by Redis (8%)
  → 2,000 reach database (2%)

Database only handles 2% of total traffic!
Without caching, it would need to handle 100,000 QPS. Impossible.
```

---

## Bloom Filters - The Clever Shortcut

### What Is a Bloom Filter?

A Bloom filter is a space-efficient data structure that answers: "Is this item in the set?"

```
Possible answers:
  "DEFINITELY NOT in the set" → 100% certain (skip the lookup!)
  "PROBABLY in the set"       → might be wrong (go check the DB)
```

It can never say "definitely yes" -- only "definitely no" or "probably yes."

### How It Works (Simple Version)

```
Imagine a row of 10 light switches, all OFF:
  [OFF][OFF][OFF][OFF][OFF][OFF][OFF][OFF][OFF][OFF]

Add "abc123" to the filter:
  Hash function 1: hash("abc123") → position 2
  Hash function 2: hash("abc123") → position 5
  Hash function 3: hash("abc123") → position 8
  
  Turn ON positions 2, 5, 8:
  [OFF][OFF][ON][OFF][OFF][ON][OFF][OFF][ON][OFF]

Check "xyz789":
  Hash: positions 2, 4, 8
  Position 2: ON ✓
  Position 4: OFF ✗  → DEFINITELY NOT in set! (one position is OFF)
  
Check "abc123":
  Hash: positions 2, 5, 8
  All ON: ✓ ✓ ✓ → PROBABLY in set (could be coincidence from other items)
```

### Two Uses in URL Shortener

**Use 1 - Write path (duplicate detection):**
```
User submits long URL for shortening
  → Bloom filter: "Is this long URL already shortened?"
  → "DEFINITELY NOT" → generate new short URL (fast! no DB check needed)
  → "PROBABLY YES" → check database to confirm
```

**Use 2 - Read path (invalid URL detection):**
```
Someone clicks bit.ly/xyz789
  → Bloom filter: "Does this short URL exist?"
  → "DEFINITELY NOT" → return 404 immediately (no DB/cache check needed!)
  → "PROBABLY YES" → proceed to cache/DB lookup
```

This prevents attackers from flooding your system with random URLs that don't exist, causing expensive DB lookups.

---

## 301 vs 302 Redirects - An Important Choice

```
301 Moved PERMANENTLY:
  Browser: "This URL permanently points to example.com/page"
  → Browser caches this forever
  → Next time user clicks same short URL, browser goes directly to target
  → Reduces load on your servers
  → BUT: you can't track how many times the link was clicked (browser doesn't ask you again)

302 Found (TEMPORARY):
  Browser: "This URL temporarily points to example.com/page"
  → Browser does NOT cache
  → Every click goes through your server
  → You CAN track every click (great for analytics!)
  → BUT: higher server load
```

**Recommendation**: Use 301 for SEO-friendly links. Use 302 when analytics matter.

---

## Handling Concurrent Requests - The Race Condition

### The Problem

Two users submit the SAME long URL at the exact same time:

```
Time 0.000s: User A submits "https://example.com/long-page"
Time 0.001s: User B submits "https://example.com/long-page"

Without protection:
  Server 1 checks: "Does this URL exist?" → NO
  Server 2 checks: "Does this URL exist?" → NO (race condition!)
  
  Server 1 creates: bit.ly/abc → https://example.com/long-page
  Server 2 creates: bit.ly/def → https://example.com/long-page
  
  Now you have TWO short URLs for the same page! Violates 1-to-1 mapping!
```

### The Solution: Distributed Lock

```
Server 1: acquires lock on "https://example.com/long-page"
  → Checks DB: doesn't exist
  → Creates bit.ly/abc → https://example.com/long-page
  → Releases lock

Server 2: tries to acquire lock → WAIT (Server 1 has it)
  → Lock released
  → Checks DB: FOUND! bit.ly/abc already exists
  → Returns existing bit.ly/abc to User B
```

Both users get the same short URL. 1-to-1 mapping preserved.

---

## The Data Model

```
URL Table (NoSQL - DynamoDB):
  ┌──────────────────────────────────────────────────┐
  │ short_url (PK) │ long_url       │ created_at     │
  ├──────────────────────────────────────────────────┤
  │ "abc123"       │ "https://..."  │ 2024-01-15     │
  │ "def456"       │ "https://..."  │ 2024-01-15     │
  └──────────────────────────────────────────────────┘
  → Optimized for READ by short_url (most common query)

Inverted Index (Key-Value):
  ┌──────────────────────────────────────────────────┐
  │ long_url (KEY)     │ short_url (VALUE)            │
  ├──────────────────────────────────────────────────┤
  │ "https://..."      │ "abc123"                     │
  └──────────────────────────────────────────────────┘
  → Used on WRITE path to check if long URL already shortened
```

**Why NoSQL for URLs?**
- Simple key-value lookup (no JOINs, no complex queries)
- High read throughput (read-heavy workload)
- Easy horizontal scaling (shard by short_url)

**Why SQL for Users?**
- Users have relational data (name, email, API keys)
- Need ACID transactions (prevent duplicate accounts)
- Complex queries (find users by email, list API keys)

---

## Revision Flashcards

**Q: Why is Token Range better than hashing or random UUIDs?**
A: Token Range guarantees zero collisions (each server gets a unique number range), needs no DB checks, runs in O(1) time, and scales horizontally.

**Q: How many unique URLs can 7 base62 characters represent?**
A: 62^7 = ~3.5 trillion. At 1,000 URLs/sec, this lasts over 100,000 years.

**Q: Why does the read path have so many cache layers?**
A: The system is read-heavy (100:1 ratio). Each cache layer catches a chunk of traffic. By the time requests reach the database, only ~2% of original traffic remains.

**Q: What is a Bloom filter and how is it used here?**
A: A space-efficient structure that says "definitely not in set" or "probably in set." Used on write path to check duplicate URLs and on read path to quickly reject non-existent short URLs without DB lookups.

**Q: What's the difference between 301 and 302 redirects?**
A: 301 = permanent (browser caches, good for SEO, fewer server hits). 302 = temporary (browser doesn't cache, every click tracked, better for analytics).
