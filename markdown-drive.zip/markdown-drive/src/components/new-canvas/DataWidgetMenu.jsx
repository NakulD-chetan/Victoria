import { memo, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useNewCanvasStore } from './state/store';

const DATA_WIDGETS = [
  { id: 'json', label: 'JSON Viewer', hint: 'Validate and explore JSON', badge: '{}' },
  { id: 'csv', label: 'CSV Loader', hint: 'Load and preview tabular data', badge: 'CSV' },
  { id: 'array', label: 'Array', hint: 'Indexed editable values', badge: '[]' },
  { id: 'linked-list', label: 'Linked List', hint: 'Nodes connected in sequence', badge: '→' },
  { id: 'stack', label: 'Stack', hint: 'LIFO data structure', badge: 'S' },
  { id: 'queue', label: 'Queue', hint: 'FIFO data structure', badge: 'Q' },
  { id: 'tree', label: 'Binary Tree', hint: 'Level-order editable nodes', badge: 'T' },
  { id: 'hash-map', label: 'Hash Map', hint: 'Editable key/value buckets', badge: '#' },
];

function DataWidgetMenuImpl() {
  const tool = useNewCanvasStore((state) => state.tool);
  const setTool = useNewCanvasStore((state) => state.setTool);
  const [open, setOpen] = useState(false);
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const triggerRef = useRef(null);
  const menuRef = useRef(null);
  const active = DATA_WIDGETS.some((item) => tool === `widget-${item.id}`);

  const place = () => {
    const rect = triggerRef.current?.getBoundingClientRect();
    if (!rect) return;
    setPosition({
      top: rect.bottom + 10,
      left: Math.max(10, Math.min(window.innerWidth - 300, rect.left - 120)),
    });
  };

  useLayoutEffect(() => {
    if (open) place();
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    const onPointerDown = (event) => {
      if (triggerRef.current?.contains(event.target) || menuRef.current?.contains(event.target)) return;
      setOpen(false);
    };
    const onKeyDown = (event) => {
      if (event.key === 'Escape') setOpen(false);
    };
    const onPosition = () => place();
    document.addEventListener('mousedown', onPointerDown, true);
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('resize', onPosition);
    window.addEventListener('scroll', onPosition, true);
    return () => {
      document.removeEventListener('mousedown', onPointerDown, true);
      document.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('resize', onPosition);
      window.removeEventListener('scroll', onPosition, true);
    };
  }, [open]);

  return (
    <>
      <button
        ref={triggerRef}
        type="button"
        className={`nc-tool-btn${active || open ? ' is-active' : ''}`}
        onClick={() => setOpen((value) => !value)}
        title="Data widgets"
        aria-label="Data widgets"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <ellipse cx="12" cy="5" rx="8" ry="3" />
          <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" />
          <path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
        </svg>
      </button>
      {open && typeof document !== 'undefined' ? createPortal(
        <div
          ref={menuRef}
          className="nc-data-menu"
          role="menu"
          aria-label="Add data widget"
          style={{ top: position.top, left: position.left }}
        >
          <div className="nc-data-menu__head">Data widgets</div>
          <div className="nc-data-menu__grid">
            {DATA_WIDGETS.map((item) => (
              <button
                key={item.id}
                type="button"
                role="menuitem"
                className={tool === `widget-${item.id}` ? 'is-active' : ''}
                onClick={() => {
                  setTool(`widget-${item.id}`);
                  setOpen(false);
                }}
              >
                <span className="nc-data-menu__badge">{item.badge}</span>
                <span className="nc-data-menu__copy">
                  <strong>{item.label}</strong>
                  <small>{item.hint}</small>
                </span>
              </button>
            ))}
          </div>
          <div className="nc-data-menu__foot">Choose a type, then drag on the canvas.</div>
        </div>,
        document.body,
      ) : null}
    </>
  );
}

export default memo(DataWidgetMenuImpl);
