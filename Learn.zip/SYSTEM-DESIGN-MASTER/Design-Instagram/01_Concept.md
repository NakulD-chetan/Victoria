# Design Instagram — Concept

> **Permanent Recall:** Instagram is a photo/video sharing platform at billion-user scale. The core design challenge is **media-centric storage + feed generation**, not just social graph like Twitter. Storage dominates — 100M photos/day × 2MB = 200TB/day; read:write ratio is **100:1**.

---

## Problem Statement

Design a **photo and video sharing platform** where users can:
- Upload photos/videos, apply filters, and share with followers
- Follow other users and consume a **personalized news feed**
- Like, comment, and engage with content
- Discover content via **explore/discover** and ephemeral **stories**

Scale: **1B+ MAU**, **100M photo uploads/day**.

---

## Functional Requirements

| Feature | Description |
|---------|-------------|
| **Upload photos/videos** | Users upload media, optionally apply filters; support multiple formats (JPEG, PNG, MP4) |
| **Follow users** | Asymmetric follow; follow/unfollow; notification on new followers |
| **News feed** | Chronological or algorithmically ranked feed of posts from followed users |
| **Like/Comment** | Like posts; add comments; view like counts and comment threads |
| **Stories** | Ephemeral content visible for 24 hours; view count, replies |
| **Explore/Discover** | Personalized discovery of content from non-followed users; trending, categories |
| **Search** | Search users, hashtags, places; autocomplete |

---

## Non-Functional Requirements

| NFR | Target |
|-----|--------|
| **Availability** | 99.9% uptime; media must be highly available |
| **Latency** | Feed load < 200ms P99; image delivery via CDN < 100ms |
| **Consistency** | Eventual consistency acceptable for likes, follower counts |
| **Read:Write** | ~100:1 (read-heavy) — optimize for reads |
| **Scale** | 1B+ MAU, 100M uploads/day |

> **FAANG Tip:** Always state the read:write ratio early — it drives caching and CDN decisions.

---

## Capacity Estimation

### Storage (Photos/Video)

- **Daily uploads:** 100M photos × 2MB avg = **200TB/day** new storage
- **5-year horizon:** 200TB × 365 × 5 ≈ **365PB** (including metadata, thumbnails, multiple resolutions)

### Throughput

- **Uploads:** 100M / 86,400 ≈ **1,160 uploads/sec**
- **Feed reads:** Assume 10× more reads than uploads → **~116K reads/sec**

### Bandwidth (Rough)

- Upload: 1160 × 2MB ≈ 2.3 GB/s
- Read: Assumption ~100× → significant CDN egress

---

## Key Numbers to Memorize

| Metric | Value |
|--------|-------|
| MAU | 1B+ |
| Photos/day | 100M |
| Avg photo size | 2MB |
| Storage/day | 200TB |
| Storage (5yr) | ~365PB |
| Upload QPS | ~1,160/s |
| Feed read QPS | ~116K/s |
| Read:write | 100:1 |

---

## Out of Scope (Clarify in Interview)

- **DMs / Messaging** — separate design
- **Live streaming** — real-time delivery
- **Ads / monetization** — separate consideration
- **Exact ranking algorithm** — high-level (engagement, recency)

---

## Summary

Instagram's design centers on **three pillars**: (1) **media pipeline** (S3 + async + CDN), (2) **feed** (fan-out + Redis), (3) **discovery** (explore + stories). The 100:1 read:write ratio justifies heavy caching and CDN investment.

---

## Assumptions (State in Interview)

- Photos are the primary content; videos are secondary but similar pipeline
- Filters applied server-side or via pre-computed LUTs
- Hashtags and mentions are metadata — stored with post
- Users can have both public and private accounts
- Feed can be chronological or algorithmically ranked (clarify)

---

## Constraints

- **Budget:** Storage at 365PB is costly — need compression, lifecycle
- **Latency:** Global users — CDN mandatory
- **Consistency:** Likes, follower counts can be eventually consistent

---

## Success Criteria

- Upload completes within seconds (async processing)
- Feed loads < 200ms P99
- Images display < 100ms from CDN
- 99.9% availability for core flows

---

## Extended Capacity Notes

- **Metadata:** ~1KB per photo (caption, user, timestamps) → 100GB/day metadata
- **Thumbnails:** ~20KB each × 100M = 2TB/day additional
- **Replication:** 3× for durability → 600TB/day raw storage
- **Peak load:** Assume 3× average → ~3.5K uploads/sec, ~350K reads/sec at peak

---

## Latency Budget (Feed Load)

| Component | Budget |
|-----------|--------|
| API + auth | 30ms |
| Redis timeline read | 20ms |
| Metadata fetch (batch) | 40ms |
| CDN URL resolution | 10ms |
| Client render | 100ms |
| **Total** | **200ms** |

---

## Quick Reference

- **1B MAU**, **100M photos/day**, **200TB/day** storage
- **100:1** read:write → optimize reads
- **S3 + CDN** for media; **async** processing; **fan-out** for feed
