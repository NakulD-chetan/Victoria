import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(arr) {
  const a = [...arr], steps = [], n = a.length;
  function heapify(size, i) {
    let largest = i, l = 2 * i + 1, r = 2 * i + 2;
    steps.push({ type: 'compare', i, l, r, size, array: [...a] });
    if (l < size && a[l] > a[largest]) largest = l;
    if (r < size && a[r] > a[largest]) largest = r;
    if (largest !== i) {
      [a[i], a[largest]] = [a[largest], a[i]];
      steps.push({ type: 'swap', i, j: largest, array: [...a] });
      heapify(size, largest);
    }
  }
  for (let i = Math.floor(n / 2) - 1; i >= 0; i--) heapify(n, i);
  steps.push({ type: 'heap-built', array: [...a] });
  for (let i = n - 1; i > 0; i--) {
    [a[0], a[i]] = [a[i], a[0]];
    steps.push({ type: 'extract', i, array: [...a] });
    heapify(i, 0);
  }
  steps.push({ type: 'done', array: [...a] });
  return steps;
}

function randomArray(n = 15) { return Array.from({ length: n }, () => Math.floor(Math.random() * 80) + 5); }

export default function HeapSortVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Array of ${arr.length} elements` });
    canvasRef.current?.setState({ array: arr, colors: {} });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'compare') {
      colors[step.i] = 'active';
      if (step.l < step.size) colors[step.l] = 'compare';
      if (step.r < step.size) colors[step.r] = 'compare';
      store.incComparisons();
    } else if (step.type === 'swap') {
      colors[step.i] = 'swap'; colors[step.j] = 'swap';
      store.incSwaps();
      canvasRef.current?.addAnim('swap', { i: step.i, j: step.j }, 300);
    } else if (step.type === 'heap-built') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Max-heap built' });
    } else if (step.type === 'extract') {
      colors[step.i] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Extract max to [${step.i}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Array sorted!' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
