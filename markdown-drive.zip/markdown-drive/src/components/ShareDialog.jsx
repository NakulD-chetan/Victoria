import { useState, useEffect, useCallback, memo } from 'react';
import { getAuthHeaders } from './AuthGate';

const EXPIRY_OPTIONS = [
  { value: 'never', label: 'Never', unit: null },
  { value: '1h', label: '1 hour', unit: 'hours', n: 1 },
  { value: '6h', label: '6 hours', unit: 'hours', n: 6 },
  { value: '24h', label: '24 hours', unit: 'hours', n: 24 },
  { value: '7d', label: '7 days', unit: 'days', n: 7 },
  { value: '30d', label: '30 days', unit: 'days', n: 30 },
  { value: '90d', label: '90 days', unit: 'days', n: 90 },
];

function timeLeft(expiresAt) {
  if (!expiresAt) return 'Never';
  const diff = new Date(expiresAt) - Date.now();
  if (diff <= 0) return 'Expired';
  const h = Math.floor(diff / 3600000);
  if (h < 1) return `${Math.ceil(diff / 60000)}m left`;
  if (h < 24) return `${h}h left`;
  return `${Math.ceil(h / 24)}d left`;
}

const ShareDialog = memo(function ShareDialog({ folderPath, folderName, onClose }) {
  const [shares, setShares] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [copied, setCopied] = useState(null);
  const [tab, setTab] = useState('create');

  const [label, setLabel] = useState('');
  const [permissions, setPermissions] = useState(['view']);
  const [expiry, setExpiry] = useState('never');
  const [password, setPassword] = useState('');
  const [usePassword, setUsePassword] = useState(false);
  const [maxAccess, setMaxAccess] = useState('');
  const [useMaxAccess, setUseMaxAccess] = useState(false);
  const [allowDownload, setAllowDownload] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const fetchShares = useCallback(async () => {
    try {
      const res = await fetch(`/api/shares?folder=${encodeURIComponent(folderPath)}`, { headers: getAuthHeaders() });
      setShares(await res.json());
    } catch {}
    setLoading(false);
  }, [folderPath]);

  useEffect(() => { fetchShares(); }, [fetchShares]);

  const handleCreate = useCallback(async () => {
    if (creating) return;
    setCreating(true);
    try {
      const opt = EXPIRY_OPTIONS.find(o => o.value === expiry);
      const body = {
        folderPath,
        permissions,
        label: label.trim() || undefined,
        allowDownload,
      };
      if (opt?.unit === 'hours') body.expiresInHours = opt.n;
      else if (opt?.unit === 'days') body.expiresInDays = opt.n;
      if (usePassword && password.trim()) body.password = password.trim();
      if (useMaxAccess && parseInt(maxAccess) > 0) body.maxAccess = parseInt(maxAccess);

      const res = await fetch('/api/shares', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
        body: JSON.stringify(body),
      });
      const share = await res.json();
      if (!share.error) {
        await fetchShares();
        setLabel('');
        setPassword('');
        setMaxAccess('');
        setUsePassword(false);
        setUseMaxAccess(false);
        setShowAdvanced(false);
        setTab('links');
        copyLink(share.id);
      }
    } catch {}
    setCreating(false);
  }, [folderPath, permissions, expiry, password, usePassword, maxAccess, useMaxAccess, label, allowDownload, fetchShares, creating]);

  const handleDelete = useCallback(async (shareId) => {
    try {
      await fetch(`/api/shares/${shareId}`, { method: 'DELETE', headers: getAuthHeaders() });
      setShares(prev => prev.filter(s => s.id !== shareId));
    } catch {}
  }, []);

  const handleToggle = useCallback(async (shareId) => {
    try {
      const res = await fetch(`/api/shares/${shareId}/toggle`, { method: 'PATCH', headers: getAuthHeaders() });
      const updated = await res.json();
      setShares(prev => prev.map(s => s.id === shareId ? { ...s, ...updated } : s));
    } catch {}
  }, []);

  const copyLink = useCallback((shareId) => {
    const url = `${window.location.origin}?share=${shareId}`;
    navigator.clipboard.writeText(url).then(() => {
      setCopied(shareId);
      setTimeout(() => setCopied(null), 2500);
    });
  }, []);

  const togglePerm = useCallback((perm) => {
    setPermissions(prev =>
      prev.includes(perm) ? prev.filter(p => p !== perm) : [...prev, perm]
    );
  }, []);

  const activeShares = shares.filter(s => s.status === 'active');
  const expiredShares = shares.filter(s => s.status === 'expired');

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal share-dialog" onClick={e => e.stopPropagation()}>
        <div className="share-dialog__header">
          <div className="share-dialog__header-left">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
            </svg>
            <div>
              <h2 className="share-dialog__title">Share</h2>
              <p className="share-dialog__folder-name">{folderName}</p>
            </div>
          </div>
          <button className="modal__close" onClick={onClose}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        <div className="share-dialog__tabs">
          <button className={`share-dialog__tab ${tab === 'create' ? 'share-dialog__tab--active' : ''}`} onClick={() => setTab('create')}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            New Link
          </button>
          <button className={`share-dialog__tab ${tab === 'links' ? 'share-dialog__tab--active' : ''}`} onClick={() => setTab('links')}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" /><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" /></svg>
            Active Links{activeShares.length > 0 && <span className="share-dialog__tab-count">{activeShares.length}</span>}
          </button>
        </div>

        <div className="share-dialog__body">
          {tab === 'create' && (
            <div className="share__create-panel">
              <div className="share__field">
                <label className="share__label">Label</label>
                <input
                  className="share__input"
                  type="text"
                  placeholder="e.g. For review, Team access..."
                  value={label}
                  onChange={e => setLabel(e.target.value)}
                />
              </div>

              <div className="share__row">
                <div className="share__field share__field--flex">
                  <label className="share__label">Permissions</label>
                  <div className="share__perm-btns">
                    {[
                      { key: 'view', label: 'View', icon: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3' },
                      { key: 'edit', label: 'Edit', icon: 'M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z' },
                      { key: 'download', label: 'Download', icon: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><polyline points="7 10 12 15 17 10" /><line x1="12" y1="15" x2="12" y2="3' },
                    ].map(p => (
                      <button
                        key={p.key}
                        className={`share__perm-btn ${permissions.includes(p.key) ? 'share__perm-btn--active' : ''}`}
                        onClick={() => p.key === 'download' ? setAllowDownload(!allowDownload) : togglePerm(p.key)}
                      >
                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={p.icon} /></svg>
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="share__field">
                <label className="share__label">Expires</label>
                <div className="share__expiry-grid">
                  {EXPIRY_OPTIONS.map(opt => (
                    <button
                      key={opt.value}
                      className={`share__expiry-btn ${expiry === opt.value ? 'share__expiry-btn--active' : ''}`}
                      onClick={() => setExpiry(opt.value)}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <button className="share__advanced-toggle" onClick={() => setShowAdvanced(!showAdvanced)}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: showAdvanced ? 'rotate(90deg)' : 'rotate(0)', transition: 'transform 0.15s' }}>
                  <polyline points="9 18 15 12 9 6" />
                </svg>
                Advanced Options
              </button>

              {showAdvanced && (
                <div className="share__advanced">
                  <div className="share__toggle-row">
                    <div className="share__toggle-info">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                      <div>
                        <span className="share__toggle-label">Password Protection</span>
                        <span className="share__toggle-desc">Require password to access</span>
                      </div>
                    </div>
                    <button className={`share__switch ${usePassword ? 'share__switch--on' : ''}`} onClick={() => setUsePassword(!usePassword)}>
                      <span className="share__switch-knob" />
                    </button>
                  </div>
                  {usePassword && (
                    <input
                      className="share__input share__input--indent"
                      type="text"
                      placeholder="Set a password..."
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      autoFocus
                    />
                  )}

                  <div className="share__toggle-row">
                    <div className="share__toggle-info">
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M23 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
                      <div>
                        <span className="share__toggle-label">Max Access Limit</span>
                        <span className="share__toggle-desc">Limit total number of views</span>
                      </div>
                    </div>
                    <button className={`share__switch ${useMaxAccess ? 'share__switch--on' : ''}`} onClick={() => setUseMaxAccess(!useMaxAccess)}>
                      <span className="share__switch-knob" />
                    </button>
                  </div>
                  {useMaxAccess && (
                    <input
                      className="share__input share__input--indent"
                      type="number"
                      placeholder="Max views (e.g. 10)"
                      value={maxAccess}
                      onChange={e => setMaxAccess(e.target.value)}
                      min="1"
                    />
                  )}
                </div>
              )}

              <button className="share__create-btn" onClick={handleCreate} disabled={creating || permissions.length === 0}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                </svg>
                {creating ? 'Creating...' : 'Generate Share Link'}
              </button>
            </div>
          )}

          {tab === 'links' && (
            <div className="share__links-panel">
              {loading ? (
                <div className="share__loading">Loading links...</div>
              ) : activeShares.length === 0 && expiredShares.length === 0 ? (
                <div className="share__empty-state">
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" strokeWidth="1.2" opacity="0.5">
                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
                  </svg>
                  <p>No share links yet</p>
                  <button className="share__empty-btn" onClick={() => setTab('create')}>Create your first link</button>
                </div>
              ) : (
                <>
                  {activeShares.map(share => (
                    <div key={share.id} className="share__link-card">
                      <div className="share__link-top">
                        <span className="share__link-label">{share.label}</span>
                        <div className="share__link-badges">
                          {share.hasPassword && (
                            <span className="share__badge share__badge--lock">
                              <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
                            </span>
                          )}
                          <span className={`share__badge share__badge--${share.active ? 'active' : 'paused'}`}>
                            {share.active ? 'Active' : 'Paused'}
                          </span>
                        </div>
                      </div>

                      <div className="share__link-meta">
                        <span>{share.permissions.map(p => p.charAt(0).toUpperCase() + p.slice(1)).join(', ')}</span>
                        <span className="share__link-dot">·</span>
                        <span>{share.accessCount} view{share.accessCount !== 1 ? 's' : ''}{share.maxAccess ? ` / ${share.maxAccess} max` : ''}</span>
                        <span className="share__link-dot">·</span>
                        <span>{timeLeft(share.expiresAt)}</span>
                      </div>

                      <div className="share__link-actions">
                        <button
                          className={`share__action-btn share__action-btn--copy ${copied === share.id ? 'share__action-btn--copied' : ''}`}
                          onClick={() => copyLink(share.id)}
                        >
                          {copied === share.id ? (
                            <><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12" /></svg>Copied</>
                          ) : (
                            <><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>Copy</>
                          )}
                        </button>
                        <button className="share__action-btn" onClick={() => handleToggle(share.id)} title={share.active ? 'Pause' : 'Resume'}>
                          {share.active ? (
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="6" y="4" width="4" height="16" /><rect x="14" y="4" width="4" height="16" /></svg>
                          ) : (
                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 3 19 12 5 21 5 3" /></svg>
                          )}
                        </button>
                        <button className="share__action-btn share__action-btn--danger" onClick={() => handleDelete(share.id)} title="Delete">
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                        </button>
                      </div>
                    </div>
                  ))}

                  {expiredShares.length > 0 && (
                    <>
                      <div className="share__section-divider">
                        <span>Expired / Exhausted ({expiredShares.length})</span>
                      </div>
                      {expiredShares.map(share => (
                        <div key={share.id} className="share__link-card share__link-card--expired">
                          <div className="share__link-top">
                            <span className="share__link-label">{share.label}</span>
                            <span className="share__badge share__badge--expired">Expired</span>
                          </div>
                          <div className="share__link-meta">
                            <span>{share.accessCount} views</span>
                            <span className="share__link-dot">·</span>
                            <span>Created {new Date(share.createdAt).toLocaleDateString()}</span>
                          </div>
                          <div className="share__link-actions">
                            <button className="share__action-btn share__action-btn--danger" onClick={() => handleDelete(share.id)}>
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6" /><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" /></svg>
                              Remove
                            </button>
                          </div>
                        </div>
                      ))}
                    </>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
});

export default ShareDialog;
