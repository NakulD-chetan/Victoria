# Union-Find — Edge Cases

> **Permanent Recall:** Single node, empty edges, already connected, self-loop, duplicate edges, 1-indexed nodes, large n. Always validate before union. Handle empty graph explicitly.

---

## Edge Case Table

| Edge Case | Input | Expected | Handle |
|-----------|-------|----------|--------|
| **Single node** | n=1, edges=[] | 1 component | UF(1), count=1 |
| **No edges** | n=5, edges=[] | 5 components | Each node alone |
| **Already connected** | union(0,1) then union(1,0) | No change | find same → return false |
| **Self-loop** | edge (2,2) | Cycle (if undirected) | u==v → cycle or skip |
| **Duplicate edges** | (0,1), (0,1), (1,0) | Same result | Union is idempotent |
| **1-indexed nodes** | nodes 1..n | Adjust indices | UF(n+1), use 1..n |
| **Large n** | n=10^5 | No overflow | Use appropriate types |
| **Empty graph** | n=0 | 0 components | Return 0 early |

---

## Single Node

```python
# n=1, edges=[]
uf = UnionFind(1)
# uf.count == 1
# No unions; single component
```

```
    [0]  →  parent[0]=0, count=1
```

---

## Already Connected

```python
# union(0,1) → True, count=2→1
# union(0,1) again → find(0)==find(1) → False, count stays 1
# union(1,0) → same, False
```

**Key:** Union returns False when already in same component. No double-counting.

---

## Self-Loop (Undirected)

```python
# edge (2, 2) — node connected to itself
# Before union: find(2)==find(2) always!
# → Cycle detected (trivial cycle)
```

| Interpretation | Action |
|----------------|--------|
| **Cycle detection** | Return True (cycle exists) |
| **Component count** | Skip self-loops; they don't change connectivity |
| **Redundant connection** | Self-loop is redundant |

---

## Duplicate Edges

```python
# edges: [(0,1), (0,1), (1,0)]
# First union(0,1): merges
# Second union(0,1): find(0)==find(1) → no-op
# Third union(1,0): same
# Result: 1 component, no error
```

**Union is idempotent** — calling again is safe.

---

## 1-Indexed Nodes

```python
# Problem: "nodes labeled 1 to n"
# Option 1: UF(n+1), use indices 1..n, ignore 0
uf = UnionFind(n + 1)
for u, v in edges:
    uf.union(u, v)  # u,v are 1..n

# Option 2: Convert to 0-indexed
for u, v in edges:
    uf.union(u - 1, v - 1)
```

---

## Large Graphs (n=10^5)

| Concern | Handle |
|---------|--------|
| **Stack overflow** | Python recursion limit; iterative find if needed |
| **Memory** | O(n) for parent+rank — fine |
| **Time** | O(m α(n)) — acceptable |
| **Integer overflow** | n fits in int; use long if n² possible elsewhere |

---

## Empty Graph

```python
if n == 0:
    return 0  # or [] depending on problem
```

---

## 2D Grid Edge Cases

| Case | Handle |
|------|--------|
| **1×1 grid** | 1 cell, 0 edges |
| **1×n row** | n cells, n-1 horizontal edges |
| **All water** | No land to union |
| **Single island** | All land, one component |

---

## FINAL MEMORY COMPRESSION BLOCK

```
SINGLE NODE:    n=1 → count=1
NO EDGES:       n components
ALREADY CONN:   union returns false, no-op
SELF-LOOP:      (u,u) → cycle or skip
DUPLICATES:     Idempotent, safe
1-INDEXED:      UF(n+1) or subtract 1
EMPTY:          n=0 → return 0
LARGE N:        O(n) space, O(m α(n)) time — fine
```

---

## 30-SECOND REVISION BOX

```
□ n=1? count=1
□ edges=[]? n components
□ Self-loop (u,u)? Cycle or skip
□ Duplicate edges? Safe, idempotent
□ 1-indexed? n+1 or u-1, v-1
□ n=0? Early return
```
