# Greedy — Common Mistakes

> **Permanent Recall:** Top 5: (1) Using greedy on 0/1 knapsack, (2) Wrong sort key, (3) Ignoring ties, (4) Not proving, (5) Interval overlap edge cases. Avoid these = avoid rejection.

---

## Mistake 1: Applying Greedy When DP Is Needed

### The Trap: 0/1 Knapsack

```
WRONG: Sort by value/weight, take greedily
      → Fails! [ (10,100), (5,60), (5,60) ], cap=10
      → Greedy: 100. Optimal: 120

RIGHT: Use DP — dp[i][w] = max value using first i items, weight w
```

### When to Suspect DP

- Items are **indivisible** (take whole or nothing)
- Choices **affect future** in non-obvious ways
- Problem asks for **subset** with constraints

---

## Mistake 2: Wrong Sorting Criteria

### Intervals: End vs Start

| Goal | Sort By | Why |
|------|---------|-----|
| Max non-overlapping | **End time** | Earliest end = most room for others |
| Min rooms (partitioning) | **Start time** | Process as events arrive |
| Merge overlapping | **Start time** | Chronological merge |

```
WRONG for "max activities": sort by start
  [1,10], [2,3], [4,5] → pick [1,10], get 1. Optimal: 2 ([2,3], [4,5])

RIGHT: sort by end
  [2,3], [4,5], [1,10] → pick [2,3], [4,5], get 2
```

### Fractional Knapsack

```
WRONG: sort by value (total)
RIGHT: sort by value/weight (density)
```

---

## Mistake 3: Not Handling Ties Correctly

### Interval Ties (Same End Time)

```
[1,5], [2,5], [3,5] — all end at 5

Need secondary sort: by start time (asc) or arbitrary but consistent
Python: intervals.sort(key=lambda x: (x[1], x[0]))
```

### Why It Matters

- Inconsistent tie-breaking can cause wrong count in edge cases
- Some problems require specific tie-breaking (e.g., by index)

---

## Mistake 4: Forgetting to Prove Greedy Choice Property

### Interview Impact

- Interviewer asks: "Why does this work?"
- Answer "It just does" → **Red flag**
- Answer "Exchange argument: we can swap..." → **Strong**

### Quick Proof Checklist

- [ ] State: "Greedy choice property holds"
- [ ] Sketch: "Any optimal can include our choice"
- [ ] Example: "Earliest-ending activity can replace first activity in any optimal set"

---

## Mistake 5: Edge Cases in Interval Overlap

### Off-by-One in Overlap Check

```python
# WRONG: strict < for "no overlap"
if intervals[i][0] < end:  # [1,2] and [2,3] considered overlapping!

# RIGHT: >= means no overlap (next starts when/after current ends)
if intervals[i][0] >= end:
    count += 1
    end = intervals[i][1]
```

### Merge Intervals: Inclusive vs Exclusive

```
[1,2] and [2,3] — do they overlap?
If inclusive: [1,2] ends at 2, [2,3] starts at 2 → OVERLAP (merge)
If exclusive: no overlap

Standard: inclusive. [1,2] and [2,3] → merge to [1,3]
```

---

## Mistake 6: Jump Game — Wrong Order of Checks

```python
# WRONG: update max_reach before checking i > max_reach
for i in range(len(nums)):
    max_reach = max(max_reach, i + nums[i])  # Too late!
    if i > max_reach:
        return False

# RIGHT: check first, then update
for i in range(len(nums)):
    if i > max_reach:
        return False
    max_reach = max(max_reach, i + nums[i])
```

---

## Mistake 7: Gas Station — Forgetting Total Check

```python
# WRONG: only track running sum, return first positive
# Fails when total gas < total cost (impossible trip)

# RIGHT: early exit if impossible
if sum(gas) < sum(cost):
    return -1
```

---

## Mistake 8: Empty / Single Element

```python
# Intervals: [] → return 0 or []
# Single interval: return 1
# Jump: [0] → can "reach" (already at end)
# Jump: [] → false
```

---

## Summary Table

| Mistake | Fix |
|---------|-----|
| Greedy on 0/1 knapsack | Use DP |
| Sort intervals by start (for max count) | Sort by end |
| Ignore ties | Secondary sort key |
| No proof | Exchange argument |
| Wrong overlap check | Use >= for "no overlap" |
| Jump: wrong check order | Check i > max_reach before update |
| Gas: skip total check | if sum(gas) < sum(cost): return -1 |

---

## FINAL MEMORY COMPRESSION BLOCK

```
1. 0/1 knapsack → DP, NOT greedy
2. Intervals max count → sort by END
3. Ties → secondary sort (start or index)
4. Always have exchange argument ready
5. Overlap: start >= last_end = no overlap
6. Jump: check i > max_reach BEFORE update
7. Gas: sum(gas) >= sum(cost) or return -1
8. Empty/single: handle explicitly
```
