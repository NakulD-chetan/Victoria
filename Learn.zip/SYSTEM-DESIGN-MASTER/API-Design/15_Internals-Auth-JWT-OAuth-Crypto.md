# Internals: Authentication — JWT, OAuth, Crypto

> **Permanent Recall:** JWT = header.payload.signature, Base64URL encoded. HS256: HMAC-SHA256(secret, header.payload). RS256: RSA sign with private key, verify with public (no shared secret). OAuth 2.0: authorize → code → token exchange; access (short), refresh (long), ID token (JWT). PKCE for SPA/mobile. API keys: random bytes, hashed like passwords. Sessions: server-side store (Redis), secure cookies (HttpOnly, Secure, SameSite).

---

## 1. JWT Structure at Byte Level

```
JWT — THREE PARTS, DOT-SEPARATED:

  eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4iLCJpYXQiOjE2MTYyMzkwMjJ9.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c

  ┌────────────────────────────────┬─────────────────────────────────────┬────────────────────────────┐
  │ HEADER (Base64URL)             │ PAYLOAD (Base64URL)                  │ SIGNATURE (Base64URL)     │
  │ {"alg":"HS256","typ":"JWT"}    │ {"sub":"1234567890","name":"John",   │ HMAC-SHA256(...)          │
  │                                │  "iat":1616239022}                   │                           │
  └────────────────────────────────┴─────────────────────────────────────┴────────────────────────────┘
```

### Base64URL vs Base64

```
  BASE64: Uses +, /, = for padding
  BASE64URL: Uses -, _, no padding (URL-safe)

  Standard Base64:  "a+b/c="
  Base64URL:        "a-b_c"  (no padding, or = stripped)

  ENCODING STEPS:
    1. UTF-8 encode JSON string
    2. Base64 encode
    3. Replace + → -, / → _
    4. Remove trailing =
```

### Actual Bytes of Each Part

```
  HEADER (raw JSON): {"alg":"HS256","typ":"JWT"}
  UTF-8 bytes: 7B 22 61 6C 67 22 3A 22 48 53 32 35 36 22 2C 22 74 79 70 22 3A 22 4A 57 54 22 7D

  Base64URL of header:
    Input:  {"alg":"HS256","typ":"JWT"}
    Base64: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9
    (no + or /, no padding needed)

  PAYLOAD (raw JSON): {"sub":"1234567890","name":"John","iat":1616239022}
  Base64URL: eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4iLCJpYXQiOjE2MTYyMzkwMjJ9

  SIGNATURE INPUT: base64url(header) + "." + base64url(payload)
  For HS256: HMAC-SHA256(secret_key, "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4iLCJpYXQiOjE2MTYyMzkwMjJ9")
  Output: 32 bytes (256 bits) → Base64URL encoded
```

### Header and Payload Claims

```
  HEADER CLAIMS:
    alg: Algorithm (HS256, RS256, ES256, none — avoid!)
    typ: Type ("JWT")
    kid: Key ID (when multiple keys, for key rotation)
    cty: Content type (optional)

  PAYLOAD CLAIMS (standard):
    sub: Subject (user ID)
    iss: Issuer (who created the token)
    aud: Audience (intended recipient)
    exp: Expiration (Unix timestamp)
    nbf: Not Before (Unix timestamp)
    iat: Issued At (Unix timestamp)
    jti: JWT ID (unique identifier, for revocation)

  CUSTOM CLAIMS: Any additional key-value (e.g., "role": "admin")
```

---

## 2. HMAC-SHA256 Signing

```
HMAC — KEYED HASH FOR MESSAGE AUTHENTICATION:

  HMAC(K, m) = H((K' ⊕ opad) || H((K' ⊕ ipad) || m))

  K' = key padded/trimmed to block size (64 bytes for SHA-256)
  ipad = 0x36 repeated 64 times
  opad = 0x5D repeated 64 times
```

### How HMAC Works Internally

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │ HMAC-SHA256 INTERNALS                                                │
  │                                                                     │
  │ 1. Key preparation:                                                 │
  │    If key > 64 bytes: K' = SHA256(key)                              │
  │    If key < 64 bytes: K' = key || zeros                             │
  │                                                                     │
  │ 2. Inner hash:                                                      │
  │    inner = SHA256((K' ⊕ ipad) || message)                            │
  │    ipad = 0x36363636... (64 bytes)                                   │
  │                                                                     │
  │ 3. Outer hash:                                                      │
  │    outer = SHA256((K' ⊕ opad) || inner)                              │
  │    opad = 0x5C5C5C5C... (64 bytes)                                   │
  │                                                                     │
  │ 4. Output: 32 bytes (256 bits)                                      │
  └─────────────────────────────────────────────────────────────────────┘
```

### JWT Signing and Verification

```
  SIGNING (HS256):
    message = base64url(header) + "." + base64url(payload)
    signature = HMAC-SHA256(secret, message)
    jwt = message + "." + base64url(signature)

  VERIFICATION:
    received_jwt = "header.payload.sig"
    message = "header.payload"
    computed_sig = HMAC-SHA256(secret, message)
    if constant_time_compare(computed_sig, base64url_decode(sig)):
      return VALID
    return INVALID

  CRITICAL: Use constant-time comparison to prevent timing attacks.
```

---

## 3. RSA Signing (RS256)

```
RSA — ASYMMETRIC: PRIVATE KEY SIGNS, PUBLIC KEY VERIFIES

  Key pair: (n, e) = public, (n, d) = private
  n = p × q (large primes, 2048+ bits)
  e = public exponent (typically 65537)
  d = private exponent (e × d ≡ 1 mod φ(n))
```

### Crypto-Level Operations

```
  SIGNING (private key operation):
    message_hash = SHA256(base64url(header) + "." + base64url(payload))
    signature = message_hash^d mod n
    (Actually: padded hash per PKCS#1 v1.5, then modular exponentiation)

  VERIFICATION (public key operation):
    received_signature^e mod n = ?
    Decrypted = padded_hash
    Extract hash, compare with SHA256(message)
    If match → VALID
```

### PKCS#1 v1.5 Padding

```
  BEFORE RSA: hash is padded to key size

  PKCS#1 v1.5 padding (simplified):
    0x00 0x01 0xff 0xff ... 0xff 0x00 || digest_algorithm || hash

  For SHA-256:
    00 01 ff ff ff ... ff 00 30 31 30 0d 06 09 60 86 48 01 65 03 04 02 01 05 00 04 20 || H
    (DigestInfo for SHA-256)                                                         (32-byte hash)

  RSA encrypts this padded block with private key (signing).
```

### Why RS256 for Distributed Systems

```
  ┌────────────────────┬─────────────────────────┬─────────────────────────┐
  │ Aspect             │ HS256                   │ RS256                   │
  ├────────────────────┼─────────────────────────┼─────────────────────────┤
  │ Secret              │ Shared (symmetric)     │ Private (server only)   │
  │ Verification        │ Needs secret           │ Public key only         │
  │ Key distribution    │ Every verifier needs    │ Publish public key      │
  │                    │ the secret              │ (JWKS endpoint)         │
  │ Use case            │ Single server          │ Microservices, APIs     │
  │                    │                         │ (any service can verify)│
  └────────────────────┴─────────────────────────┴─────────────────────────┘

  RS256: Auth server signs with private key. API servers, mobile apps,
  third parties verify with public key — no secret sharing.
```

---

## 4. JWT Validation Pipeline

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │ JWT VALIDATION — STEP BY STEP                                        │
  │                                                                     │
  │ 1. SPLIT: Split on "." → [header_b64, payload_b64, sig_b64]         │
  │    Fail if not 3 parts                                               │
  │                                                                     │
  │ 2. DECODE: Base64URL decode header and payload                       │
  │    Fail if invalid Base64                                            │
  │                                                                     │
  │ 3. PARSE: JSON parse header and payload                              │
  │    Fail if invalid JSON                                              │
  │                                                                     │
  │ 4. ALGORITHM: Read header.alg                                        │
  │    Fail if alg is "none" (alg:none attack!)                         │
  │    Fail if alg not in allowed list (prevent algorithm confusion)     │
  │                                                                     │
  │ 5. VERIFY SIGNATURE: Recompute sig, constant-time compare           │
  │    Fail if mismatch                                                  │
  │                                                                     │
  │ 6. EXP: Check payload.exp >= now (with clock skew tolerance)        │
  │    Fail if expired                                                   │
  │                                                                     │
  │ 7. NBF: Check payload.nbf <= now                                     │
  │    Fail if not yet valid                                             │
  │                                                                     │
  │ 8. IAT: Optional — reject if too old (e.g., > 24h)                  │
  │                                                                     │
  │ 9. ISS: Check payload.iss in allowed issuers                         │
  │    Fail if wrong issuer                                              │
  │                                                                     │
  │ 10. AUD: Check payload.aud includes this service                    │
  │     Fail if audience mismatch                                        │
  │                                                                     │
  │ 11. EXTRACT CLAIMS: sub, custom claims → pass to application        │
  └─────────────────────────────────────────────────────────────────────┘
```

### Algorithm Confusion Attack

```
  ATTACK: Attacker has token signed with HS256 and secret "secret".
  Server expects RS256, has public key only.

  Attacker forges: header says alg=HS256, uses RSA public key AS the
  HMAC secret. If server naively uses public key as HMAC key for "HS256",
  verification can succeed! (Public key is long, HMAC accepts any key.)

  DEFENSE: Explicitly whitelist algorithms. Never trust header.alg
  to choose verification method. If expecting RS256, only verify with RS256.
```

---

## 5. OAuth 2.0 Authorization Code Flow — Deep Internals

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │ OAUTH 2.0 AUTHORIZATION CODE FLOW                                    │
  │                                                                     │
  │   Client (Web App)     User Browser      Auth Server (IdP)          │
  │         │                    │                    │                 │
  │         │  1. Redirect to /authorize               │                 │
  │         │  ──────────────────────────────────────►│                 │
  │         │  GET /authorize?response_type=code&client_id=...&          │
  │         │      redirect_uri=...&scope=openid&state=xyz               │
  │         │                    │                    │                 │
  │         │                    │  2. User logs in    │                 │
  │         │                    │  (credentials)     │                 │
  │         │                    │                    │                 │
  │         │  3. Redirect with code                   │                 │
  │         │  ◄──────────────────────────────────────│                 │
  │         │  Location: https://app.com/cb?code=ABC123&state=xyz        │
  │         │                    │                    │                 │
  │         │  4. POST /token (code exchange)          │                 │
  │         │  ──────────────────────────────────────►│                 │
  │         │  grant_type=authorization_code&code=ABC123&                 │
  │         │  redirect_uri=...&client_id=...&client_secret=...         │
  │         │                    │                    │                 │
  │         │  5. access_token + refresh_token        │                 │
  │         │  ◄──────────────────────────────────────│                 │
  │         │  {"access_token":"...","refresh_token":"...","expires_in":3600}
  │         │                    │                    │                 │
  └─────────────────────────────────────────────────────────────────────┘
```

### Every HTTP Request in Detail

```
  REQUEST 1 — Redirect to /authorize:

    HTTP/1.1 302 Found
    Location: https://auth.example.com/authorize?
      response_type=code
      &client_id=my_client_id
      &redirect_uri=https%3A%2F%2Fapp.example.com%2Fcallback
      &scope=openid%20profile%20email
      &state=random_state_xyz
      &code_challenge=E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM
      &code_challenge_method=S256

  REQUEST 2 — User logs in (form POST to auth server):

    POST /login HTTP/1.1
    Content-Type: application/x-www-form-urlencoded

    username=user@example.com&password=***

  REQUEST 3 — Callback with code:

    HTTP/1.1 302 Found
    Location: https://app.example.com/callback?code=SplxlOBeZQQYbYS6WxSbIA&state=random_state_xyz

  REQUEST 4 — Token exchange:

    POST /token HTTP/1.1
    Host: auth.example.com
    Content-Type: application/x-www-form-urlencoded

    grant_type=authorization_code
    &code=SplxlOBeZQQYbYS6WxSbIA
    &redirect_uri=https%3A%2F%2Fapp.example.com%2Fcallback
    &client_id=my_client_id
    &client_secret=client_secret_here
    &code_verifier=dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk

  RESPONSE 5 — Tokens:

    HTTP/1.1 200 OK
    Content-Type: application/json

    {
      "access_token": "eyJhbGciOiJSUzI1NiIs...",
      "token_type": "Bearer",
      "expires_in": 3600,
      "refresh_token": "tGzv3JOkF0XG5Qx2TlKWIA",
      "scope": "openid profile email"
    }
```

### PKCE (Proof Key for Code Exchange)

```
  PKCE — FOR MOBILE AND SPA (no client_secret):

    1. Client generates: code_verifier = random 43-128 chars
    2. code_challenge = BASE64URL(SHA256(code_verifier))
    3. Send code_challenge + code_challenge_method=S256 in /authorize
    4. Auth server stores code_challenge with the authorization code
    5. On /token: send code_verifier
    6. Server: SHA256(code_verifier) == stored code_challenge?
       If yes, code was not intercepted (attacker can't derive verifier)

  Prevents: Authorization code interception (e.g., malicious app on device).
```

### Token Storage

```
  ACCESS TOKEN: In memory (JS variable) or secure storage.
    Never in localStorage (XSS can steal). Prefer httpOnly cookie or memory.

  REFRESH TOKEN: Secure storage (httpOnly cookie, or mobile keychain).
    Long-lived; if stolen, attacker gets long-term access.
```

---

## 6. OAuth 2.0 Token Types

```
  ┌────────────────────┬──────────────┬──────────────┬──────────────────────┐
  │ Token Type         │ Lifetime     │ Purpose      │ Storage              │
  ├────────────────────┼──────────────┼──────────────┼──────────────────────┤
  │ Access token       │ 15 min–1 hr  │ API calls    │ Memory, short-lived  │
  │ Refresh token      │ Days–months  │ Get new      │ Secure, httpOnly     │
  │                    │              │ access token │ cookie or keychain   │
  │ ID token (OIDC)    │ Same as      │ User info    │ Pass to app, decode  │
  │                    │ access       │ (JWT)        │                      │
  └────────────────────┴──────────────┴──────────────┴──────────────────────┘
```

### Token Introspection

```
  When API receives opaque token (not JWT):

    POST /introspect HTTP/1.1
    Authorization: Basic base64(client_id:client_secret)
    Content-Type: application/x-www-form-urlencoded

    token=opaque_token_here

  Response:
    {"active": true, "sub": "user123", "scope": "read write", "exp": 1710345660}

  API checks "active" and claims before allowing access.
```

### Token Revocation

```
  POST /revoke HTTP/1.1
  Content-Type: application/x-www-form-urlencoded

  token=refresh_token_here&token_type_hint=refresh_token

  Server invalidates the token. Next use of refresh token → error.
  Access tokens: short-lived, so revocation often not needed (expire naturally).
```

---

## 7. API Key Internals

```
  API KEY — SIMPLE AUTH FOR MACHINE-TO-MACHINE:

    Authorization: ApiKey sk_live_abc123xyz789
    or
    X-API-Key: sk_live_abc123xyz789
```

### Generation

```
  CRYPTOGRAPHICALLY RANDOM:

    bytes = random_bytes(32)   // 256 bits of entropy
    key = base62_encode(bytes)   // or base64url, hex

  Base62: 0-9, a-z, A-Z (no ambiguous chars like 0/O)
  Example: "sk_live_a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"

  PREFIX: "sk_live_" or "pk_test_" for identification (live vs test, secret vs public).
```

### Storage

```
  NEVER store plain API key. Store hash (like password):

    stored = bcrypt(api_key)   // or argon2, scrypt
    or
    stored = SHA256(api_key)   // if constant-time compare, less ideal but common

  On validation: hash(provided_key) == stored_hash
```

### Validation

```
  ON REQUEST:
    1. Extract API key from header
    2. Look up by prefix or first N chars (index)
    3. hash(candidate) == stored_hash
    4. If match, load associated permissions/tenant
```

### Key Rotation Without Downtime

```
  ┌─────────────────────────────────────────────────────────────────────┐
  │ ROTATION STRATEGY                                                     │
  │                                                                     │
  │ 1. Generate new key, store hash                                      │
  │ 2. Add both old and new to "valid" set (overlap period)              │
  │ 3. Notify client to switch to new key                                │
  │ 4. After overlap (e.g., 7 days): revoke old key                      │
  │ 5. Remove old key hash from DB                                      │
  │                                                                     │
  │ Client can use either key during overlap — no downtime.              │
  └─────────────────────────────────────────────────────────────────────┘
```

---

## 8. Session Management

```
  SESSION — SERVER-SIDE STATE FOR AUTHENTICATED USER:

    1. User logs in → server creates session, stores server-side
    2. Server sends session ID in cookie (Set-Cookie)
    3. Client sends cookie on every request
    4. Server looks up session by ID → user identity
```

### Server-Side Session Store

```
  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Store              │ Pros                    │ Cons                    │
  ├────────────────────┼─────────────────────────┼─────────────────────────┤
  │ Redis              │ Fast, TTL, distributed  │ Extra dependency       │
  │ Memcached          │ Fast, simple            │ No persistence         │
  │ Database           │ Durable, queryable      │ Slower, connection pool │
  │ In-memory (single) │ No extra service        │ Lost on restart, no HA  │
  └────────────────────┴─────────────────────────┴─────────────────────────┘

  SESSION DATA (typical):
    session_id, user_id, created_at, expires_at, ip, user_agent
```

### Session Fixation Attack

```
  ATTACK:
    1. Attacker gets session ID (e.g., from link ?session_id=ATTACKER_SESSION)
    2. Victim logs in using that session ID
    3. Server associates session with victim's identity
    4. Attacker uses same session ID → now logged in as victim

  DEFENSE: Regenerate session ID on login.
    Old: session_id = "fixed_by_attacker"
    After login: session_id = new_random_id, invalidate old
```

### Secure Cookie Attributes

```
  Set-Cookie: session_id=abc123; Path=/; HttpOnly; Secure; SameSite=Strict

  ┌────────────────────┬──────────────────────────────────────────────────┐
  │ Attribute          │ Effect                                            │
  ├────────────────────┼──────────────────────────────────────────────────┤
  │ HttpOnly           │ JavaScript cannot read cookie (XSS mitigation)    │
  │ Secure             │ Cookie sent only over HTTPS                       │
  │ SameSite=Strict    │ Cookie not sent on cross-site requests            │
  │                    │ (CSRF mitigation)                                 │
  │ SameSite=Lax       │ Sent on top-level nav (e.g., link click)         │
  │ SameSite=None      │ Sent cross-site (must have Secure)                │
  │ Path=/             │ Cookie sent only for paths under /                │
  │ Max-Age=3600       │ Expiry in seconds                                 │
  └────────────────────┴──────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

```
JWT: header.payload.signature, Base64URL; alg/typ in header; sub/exp/iss/aud in payload.
HS256: HMAC-SHA256(secret, message); shared secret; verify with same secret.
RS256: RSA sign with private key, verify with public; no shared secret; JWKS.
VALIDATION: decode→parse→alg check→signature→exp/nbf→iss/aud; reject alg=none.
OAUTH: authorize (code) → token (code+secret or PKCE); access + refresh tokens.
PKCE: code_verifier random, code_challenge=SHA256(verifier); for SPA/mobile.
TOKENS: access 15min-1hr, refresh days-months, ID token JWT with user info.
API KEY: random bytes, base62/hex; stored hashed; validate hash compare; rotate with overlap.
SESSION: session ID in cookie → Redis/DB; HttpOnly, Secure, SameSite; regenerate on login.
```

---

**Prev: [[14_Internals-Rate-Limiting-Algorithms]]**
