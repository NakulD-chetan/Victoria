import { memo, useCallback, useEffect, useRef, useState } from 'react';
import Editor from '@monaco-editor/react';

const MONACO_LANGUAGE = {
  cpp: 'cpp',
  python: 'python',
  java: 'java',
  javascript: 'javascript',
};

function V3CodePortal({ portal, viewport, onUpdate }) {
  const [displayCode, setDisplayCode] = useState(portal.content || '');
  const [output, setOutput] = useState('');
  const [running, setRunning] = useState(false);
  const codeRef = useRef(portal.content || '');

  useEffect(() => {
    if (portal.typingState !== 'queued' || !portal.content) {
      codeRef.current = portal.content || '';
      setDisplayCode(portal.content || '');
      return undefined;
    }

    const fullText = portal.content;
    const startedAt = Date.now();
    const timer = window.setInterval(() => {
      const length = Math.min(fullText.length, Math.max(1, Math.floor((Date.now() - startedAt) / 24)));
      const next = fullText.slice(0, length);
      codeRef.current = next;
      setDisplayCode(next);
      if (length >= fullText.length) {
        window.clearInterval(timer);
        onUpdate({ typingState: 'done', content: fullText });
      }
    }, 32);
    return () => window.clearInterval(timer);
  }, [onUpdate, portal.content, portal.typingState]);

  const save = useCallback((value) => {
    codeRef.current = value || '';
    setDisplayCode(value || '');
    onUpdate({ content: value || '', typingState: 'editing' });
  }, [onUpdate]);

  const run = useCallback(async () => {
    if (running) return;
    setRunning(true);
    setOutput('Running...');
    try {
      const response = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source_code: codeRef.current,
          language: portal.language || 'cpp',
          stdin: '',
        }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || `Server error (${response.status})`);
      const nextOutput = [
        result.compile_output,
        result.stdout,
        result.stderr,
        result.error,
      ].filter(Boolean).join('\n') || 'No output';
      setOutput(nextOutput);
    } catch (error) {
      setOutput(`Error: ${error.message}`);
    } finally {
      setRunning(false);
    }
  }, [portal.language, running]);

  const zoom = viewport.zoom?.value || 1;
  const left = (portal.x + (viewport.scrollX || 0)) * zoom;
  const top = (portal.y + (viewport.scrollY || 0)) * zoom;

  return (
    <div
      className="nc-v3-code-portal"
      style={{
        left,
        top,
        width: portal.width,
        height: portal.height,
        transform: `scale(${zoom})`,
      }}
      data-portal-id={portal.id}
    >
      <div className="nc-v3-code-portal__header">
        <span>{portal.title || 'Code Editor'}</span>
        <div className="nc-v3-code-portal__header-actions">
          <span className="nc-v3-code-portal__language">{portal.language || 'cpp'}</span>
          <button type="button" onClick={run} disabled={running}>
            <span aria-hidden>▶</span>
            {running ? 'Running' : 'Run'}
          </button>
        </div>
      </div>
      <div className="nc-v3-code-portal__editor">
        <Editor
          language={MONACO_LANGUAGE[portal.language] || 'plaintext'}
          value={displayCode}
          onChange={save}
          theme="vs-dark"
          options={{
            minimap: { enabled: false },
            fontSize: 14,
            lineHeight: 21,
            automaticLayout: true,
            scrollBeyondLastLine: false,
            wordWrap: 'on',
            padding: { top: 10, bottom: 10 },
          }}
        />
      </div>
      {output ? <pre className="nc-v3-code-portal__output">{output}</pre> : null}
    </div>
  );
}

export default memo(V3CodePortal);

