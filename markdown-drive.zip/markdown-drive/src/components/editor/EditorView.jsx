import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import Editor from '@monaco-editor/react';
import AppNavbar from '../shared/AppNavbar';
import CodeTreeSidebar from './CodeTreeSidebar';
import TerminalComponent from './Terminal';
import { useFileStore, detectLanguage } from './useFileStore';
import { registerFallbackCompletions, disposeFallbackCompletions } from './fallbackCompletions';
import SmartEngine from './SmartEngine';

export default function EditorView({ path, theme, onThemeToggle }) {
  const files = useFileStore((s) => s.files);
  const folders = useFileStore((s) => s.folders);
  const activeFile = useFileStore((s) => s.activeFile);
  const openTabs = useFileStore((s) => s.openTabs);
  const setActiveFile = useFileStore((s) => s.setActiveFile);
  const clearActiveFile = useFileStore((s) => s.clearActiveFile);
  const closeTab = useFileStore((s) => s.closeTab);
  const createFile = useFileStore((s) => s.createFile);
  const createStarterFile = useFileStore((s) => s.createStarterFile);
  const updateFileContent = useFileStore((s) => s.updateFileContent);

  const [consoleSize, setConsoleSize] = useState(35);
  const [layoutMode, setLayoutMode] = useState('stacked');
  const [isRunning, setIsRunning] = useState(false);
  const [stdinValue, setStdinValue] = useState('');
  const [showStdin, setShowStdin] = useState(false);
  const [execTime, setExecTime] = useState(null);
  const [execMemory, setExecMemory] = useState(null);
  const [execEngine, setExecEngine] = useState(null);
  const [moreMenuOpen, setMoreMenuOpen] = useState(false);
  const [isNewTabOpen, setIsNewTabOpen] = useState(false);

  const editorRef = useRef(null);
  const monacoRef = useRef(null);
  const viewStatesRef = useRef({});
  const splitRef = useRef(null);
  const terminalRef = useRef(null);
  const handleRunRef = useRef(null);
  const smartEngineRef = useRef(null);
  const moreMenuRef = useRef(null);

  const activeFileData = activeFile ? files[activeFile] : null;
  const showWelcomeTab = isNewTabOpen || (!activeFile && openTabs.length === 0);
  const inferredLanguage = activeFileData ? detectLanguage(activeFileData.name || '') : 'plaintext';
  const monacoTheme = theme === 'dark' ? 'garage-dark' : 'garage-light';
  const monacoLang = inferredLanguage === 'cpp' ? 'cpp'
    : inferredLanguage === 'python' ? 'python'
    : inferredLanguage === 'java' ? 'java'
    : inferredLanguage === 'javascript' ? 'javascript'
    : inferredLanguage || 'plaintext';

  const getFileDisplayPath = useCallback((id) => {
    const file = files[id];
    if (!file) return '';
    const parts = [file.name];
    let folderId = file.folderId;
    while (folderId && folders[folderId]) {
      parts.unshift(folders[folderId].name);
      folderId = folders[folderId].parentId;
    }
    return parts.join('/');
  }, [files, folders]);

  const tabCountForDensity = openTabs.length + (showWelcomeTab ? 1 : 0);
  const tabDensityClass = tabCountForDensity > 24
    ? 'obs-tabs--tiny'
    : tabCountForDensity > 14
      ? 'obs-tabs--dense'
      : tabCountForDensity > 9
        ? 'obs-tabs--compact'
        : '';

  const attachActiveModel = useCallback(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco || !activeFile || !activeFileData) return;

    const uri = monaco.Uri.parse(`file:///${activeFile}/${activeFileData.name}`);
    const currentModel = editor.getModel();
    if (currentModel && currentModel.uri.toString() === uri.toString()) {
      if (currentModel.getLanguageId() !== monacoLang) {
        monaco.editor.setModelLanguage(currentModel, monacoLang);
      }
      return;
    }

    if (currentModel) {
      viewStatesRef.current[currentModel.uri.toString()] = editor.saveViewState();
    }

    let model = monaco.editor.getModel(uri);
    if (!model) {
      model = monaco.editor.createModel(activeFileData.content, monacoLang, uri);
    } else if (model.getLanguageId() !== monacoLang) {
      monaco.editor.setModelLanguage(model, monacoLang);
    }

    editor.setModel(model);

    const savedState = viewStatesRef.current[uri.toString()];
    if (savedState) editor.restoreViewState(savedState);
    editor.focus();
  }, [activeFile, activeFileData, monacoLang]);

  const defineMonacoTheme = useCallback((monaco, currentTheme) => {
    monaco.editor.defineTheme('garage-dark', {
      base: 'vs-dark',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#0d0d0d',
        'editorGutter.background': '#0d0d0d',
        'editorLineNumber.foreground': '#5a5a5a',
        'editorLineNumber.activeForeground': '#999999',
        'editor.lineHighlightBackground': '#141414',
        'editor.selectionBackground': '#2e2e2e80',
        'editor.inactiveSelectionBackground': '#25252566',
        'editorCursor.foreground': '#e8e8e8',
        'scrollbarSlider.background': '#7a7a7a44',
        'scrollbarSlider.hoverBackground': '#9a9a9a66',
        'scrollbarSlider.activeBackground': '#b0b0b088',
      },
    });

    monaco.editor.defineTheme('garage-light', {
      base: 'vs',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#f9fafb',
        'editorGutter.background': '#f9fafb',
        'editorLineNumber.foreground': '#999999',
        'editorLineNumber.activeForeground': '#6b6b6b',
        'editor.lineHighlightBackground': '#f0f1f3',
        'editor.selectionBackground': '#dbe5ff',
        'editor.inactiveSelectionBackground': '#ebefff',
        'editorCursor.foreground': '#1a1a1a',
        'scrollbarSlider.background': '#8f98a633',
        'scrollbarSlider.hoverBackground': '#7f879555',
        'scrollbarSlider.activeBackground': '#6b738188',
      },
    });

    monaco.editor.setTheme(currentTheme === 'dark' ? 'garage-dark' : 'garage-light');
  }, []);

  const handleEditorMount = useCallback((editor, monaco) => {
    editorRef.current = editor;
    monacoRef.current = monaco;
    defineMonacoTheme(monaco, theme);

    const engine = new SmartEngine();
    smartEngineRef.current = engine;

    const initLang = monacoLang === 'cpp' ? 'cpp' : monacoLang === 'python' ? 'python' : null;
    if (initLang) {
      engine.init(initLang).then(() => {
        const code = editor.getValue();
        if (code) engine.parse(code);
      });
    }

    registerFallbackCompletions(monaco, engine);

    monaco.languages.setLanguageConfiguration('cpp', {
      wordPattern: /(-?\d*\.\d\w*)|([#@$]?[a-zA-Z_]\w*)/,
    });

    editor.addAction({
      id: 'run-code',
      label: 'Run Code',
      keybindings: [monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter],
      run: () => handleRunRef.current?.(),
    });

    if (activeFile && activeFileData) {
      queueMicrotask(() => {
        attachActiveModel();
      });
    }

    editor.focus();
  }, [activeFile, activeFileData, attachActiveModel, defineMonacoTheme, theme]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (!monacoRef.current) return;
    defineMonacoTheme(monacoRef.current, theme);
  }, [defineMonacoTheme, theme]);

  useEffect(() => {
    if (showWelcomeTab) return;
    attachActiveModel();
  }, [attachActiveModel, showWelcomeTab]);

  useEffect(() => {
    if (!showWelcomeTab) return;
    editorRef.current = null;
    monacoRef.current = null;
  }, [showWelcomeTab]);

  useEffect(() => {
    if (!activeFile && openTabs.length === 0) {
      setIsNewTabOpen(true);
    }
  }, [activeFile, openTabs.length]);

  useEffect(() => {
    if (activeFile && isNewTabOpen) {
      setIsNewTabOpen(false);
    }
  }, [activeFile, isNewTabOpen]);

  useEffect(() => {
    const editor = editorRef.current;
    if (!editor) return;

    let parseTimer = null;
    let saveTimer = null;
    const disposable = editor.onDidChangeModelContent(() => {
      const content = editor.getValue();
      if (activeFile) {
        // Debounce store updates so every keystroke doesn't re-render and
        // recompute monacoLang/activeFileData — which was swapping the Monaco
        // model mid-typing and breaking arrows / Ctrl+A / backspace.
        clearTimeout(saveTimer);
        saveTimer = setTimeout(() => updateFileContent(activeFile, content), 200);
      }
      if (smartEngineRef.current?.isReady()) {
        clearTimeout(parseTimer);
        parseTimer = setTimeout(() => smartEngineRef.current.parse(content), 250);
      }
    });

    return () => {
      disposable.dispose();
      clearTimeout(parseTimer);
      clearTimeout(saveTimer);
      // Flush pending save on unmount / file switch.
      if (activeFile) {
        try { updateFileContent(activeFile, editor.getValue()); } catch {}
      }
    };
  }, [activeFile, updateFileContent]);

  const handleRun = useCallback(() => {
    if (!activeFileData || isRunning) return;
    const editor = editorRef.current;
    const code = editor ? editor.getValue() : activeFileData.content;
    const language = inferredLanguage || activeFileData.language;

    if (!code.trim()) return;

    setIsRunning(true);
    setExecTime(null);
    setExecMemory(null);
    setExecEngine(null);

    if (!terminalRef.current) {
      setIsRunning(false);
      return;
    }

    terminalRef.current.runCode(code, language, stdinValue);
  }, [activeFileData, inferredLanguage, isRunning, stdinValue]);

  useEffect(() => { handleRunRef.current = handleRun; }, [handleRun]);

  const handleExecDone = useCallback((info) => {
    setIsRunning(false);
    if (info) {
      setExecTime(info.time || null);
      setExecMemory(info.memory || null);
      setExecEngine(info.engine || null);
    }
  }, []);

  const handleClear = useCallback(() => {
    if (terminalRef.current) terminalRef.current.clear();
    setExecTime(null);
    setExecMemory(null);
    setExecEngine(null);
  }, []);

  const handleStop = useCallback(() => {
    if (terminalRef.current) terminalRef.current.kill();
    setIsRunning(false);
  }, []);

  useEffect(() => {
    const engine = smartEngineRef.current;
    if (!engine) return;
    const lang = monacoLang === 'cpp' ? 'cpp' : monacoLang === 'python' ? 'python' : null;
    if (lang) {
      engine.init(lang).then(() => {
        const editor = editorRef.current;
        if (editor) engine.parse(editor.getValue());
      });
    }
  }, [monacoLang]);

  useEffect(() => {
    return () => {
      disposeFallbackCompletions();
      if (smartEngineRef.current) {
        smartEngineRef.current.dispose();
        smartEngineRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const handler = (e) => {
      // Only handle Ctrl/Cmd key combinations
      if (!(e.ctrlKey || e.metaKey)) return;
      
      // Skip if Monaco editor has focus (let Monaco handle its own shortcuts)
      if (editorRef.current?.hasTextFocus?.()) {
        // Only intercept Ctrl+Enter for run even when editor has focus
        if (e.key === 'Enter') {
          e.preventDefault();
          handleRun();
        }
        return;
      }

      const target = e.target;
      const tag = target?.tagName;
      const cls = (target?.className || '').toString();
      
      // Skip if target is any editable element or Monaco's internal elements
      const isEditableTarget = Boolean(
        target?.isContentEditable
        || tag === 'INPUT'
        || tag === 'TEXTAREA'
        || tag === 'SELECT'
        || cls.includes('monaco')
        || cls.includes('inputarea')
        || target?.closest?.('.monaco-editor')
      );
      if (isEditableTarget) return;

      const key = e.key.toLowerCase();
      if (e.key === 'Enter') {
        e.preventDefault();
        handleRun();
        return;
      }
      if (key === 'w') {
        if (activeFile) {
          e.preventDefault();
          e.stopPropagation();
          closeTab(activeFile);
        }
      }
      if (key === 'n') {
        e.preventDefault();
        e.stopPropagation();
        setIsNewTabOpen(true);
        clearActiveFile();
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [handleRun, activeFile, clearActiveFile, closeTab]);

  useEffect(() => {
    if (!moreMenuOpen) return;
    const onOutside = (e) => {
      if (moreMenuRef.current && !moreMenuRef.current.contains(e.target)) {
        setMoreMenuOpen(false);
      }
    };
    window.addEventListener('mousedown', onOutside);
    return () => window.removeEventListener('mousedown', onOutside);
  }, [moreMenuOpen]);

  const handleSplitMouseDown = useCallback((e) => {
    e.preventDefault();
    const container = splitRef.current;
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const onMove = (moveE) => {
      if (layoutMode === 'side') {
        const pct = ((moveE.clientX - rect.left) / rect.width) * 100;
        setConsoleSize(Math.max(20, Math.min(60, 100 - pct)));
        return;
      }
      const pct = ((moveE.clientY - rect.top) / rect.height) * 100;
      setConsoleSize(Math.max(15, Math.min(70, 100 - pct)));
    };
    const onUp = () => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    };
    document.body.style.cursor = layoutMode === 'side' ? 'col-resize' : 'row-resize';
    document.body.style.userSelect = 'none';
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }, [layoutMode]);

  const activeFilePath = useMemo(() => (
    activeFile && !showWelcomeTab ? getFileDisplayPath(activeFile) : ''
  ), [activeFile, getFileDisplayPath, showWelcomeTab]);

  const handleCreateUntitled = useCallback(() => {
    const id = createFile(`untitled${Date.now().toString(36).slice(-4)}.txt`, null);
    if (id) {
      setIsNewTabOpen(false);
      setActiveFile(id);
    }
  }, [createFile, setActiveFile]);

  const openBlankTab = useCallback(() => {
    setIsNewTabOpen(true);
    clearActiveFile();
  }, [clearActiveFile]);

  const handleCreateStarter = useCallback((langId) => {
    const id = createStarterFile(langId, null);
    if (id) {
      setIsNewTabOpen(false);
      setActiveFile(id);
    }
  }, [createStarterFile, setActiveFile]);

  const handleSelectTab = useCallback((tabId) => {
    setIsNewTabOpen(false);
    setActiveFile(tabId);
  }, [setActiveFile]);

  return (
    <div className="obs-app ce-app">
      <AppNavbar currentPath={path} theme={theme} onThemeToggle={onThemeToggle} />

      <div className="obs-app__body">
        <CodeTreeSidebar onNewFile={handleCreateUntitled} onThemeToggle={onThemeToggle} />

        <div className="obs-main">
          <div className="obs-tabbar">
            <div className="obs-tabbar__left">
              <div className={`obs-tabs ${tabDensityClass}`}>
                {openTabs.map((tabId) => {
                  const f = files[tabId];
                  if (!f) return null;
                  const isActive = tabId === activeFile;
                  return (
                    <div
                      key={tabId}
                      className={`obs-tab ${isActive ? 'obs-tab--active' : ''}`}
                      onClick={() => handleSelectTab(tabId)}
                      title={getFileDisplayPath(tabId)}
                    >
                      <span className="obs-tab__title">{f.name}</span>
                      <button
                        className="obs-tab__close"
                        onClick={(e) => { e.stopPropagation(); closeTab(tabId); }}
                      >
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                          <line x1="18" y1="6" x2="6" y2="18" />
                          <line x1="6" y1="6" x2="18" y2="18" />
                        </svg>
                      </button>
                    </div>
                  );
                })}
                {showWelcomeTab && (
                  <div
                    className={`obs-tab ${!activeFile ? 'obs-tab--active' : ''}`}
                    onClick={openBlankTab}
                    title="New tab"
                  >
                    <span className="obs-tab__title">New tab</span>
                    <button
                      className="obs-tab__close"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (openTabs.length > 0) {
                          setIsNewTabOpen(false);
                          setActiveFile(openTabs[openTabs.length - 1]);
                        }
                      }}
                    >
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        <line x1="18" y1="6" x2="6" y2="18" />
                        <line x1="6" y1="6" x2="18" y2="18" />
                      </svg>
                    </button>
                  </div>
                )}
              </div>

              <button className="obs-tabbar__new-btn" onClick={openBlankTab} title="New tab">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <line x1="12" y1="5" x2="12" y2="19" />
                  <line x1="5" y1="12" x2="19" y2="12" />
                </svg>
              </button>
            </div>

            <div className="obs-tabbar__right">
              <button
                className={`obs-tabbar__icon-btn ${showStdin ? 'obs-tabbar__icon-btn--active' : ''}`}
                onClick={() => setShowStdin((v) => !v)}
                title="Toggle stdin input"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                  <polyline points="9 11 12 14 15 11" />
                </svg>
              </button>

              <button
                className="obs-tabbar__icon-btn"
                onClick={handleClear}
                title="Clear terminal"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="1 4 1 10 7 10" />
                  <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
                </svg>
              </button>

              <button
                className={`obs-tabbar__icon-btn ${layoutMode === 'side' ? 'obs-tabbar__icon-btn--active' : ''}`}
                onClick={() => setLayoutMode((v) => (v === 'stacked' ? 'side' : 'stacked'))}
                title={layoutMode === 'side' ? 'Switch to stacked view' : 'Switch to side-by-side view'}
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="3" y="5" width="18" height="14" rx="2" />
                  <line x1="12" y1="5" x2="12" y2="19" />
                </svg>
              </button>

              {isRunning ? (
                <button className="ce-run-btn ce-run-btn--stop" onClick={handleStop} title="Stop (Ctrl+C)">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="6" y="6" width="12" height="12" rx="1" />
                  </svg>
                </button>
              ) : (
                <button className="ce-run-btn" onClick={handleRun} title="Run (Ctrl+Enter)">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="6 4 20 12 6 20 6 4" />
                  </svg>
                </button>
              )}

              <button
                className={`obs-tabbar__icon-btn ${moreMenuOpen ? 'obs-tabbar__icon-btn--active' : ''}`}
                title="More options"
                onClick={() => setMoreMenuOpen((v) => !v)}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="5" r="1.5" />
                  <circle cx="12" cy="12" r="1.5" />
                  <circle cx="12" cy="19" r="1.5" />
                </svg>
              </button>
              {moreMenuOpen && (
                <div className="obs-more-menu" ref={moreMenuRef}>
                  <button onClick={() => { openBlankTab(); setMoreMenuOpen(false); }}>New tab</button>
                  <button onClick={() => { handleClear(); setMoreMenuOpen(false); }}>Clear terminal</button>
                  {activeFile && (
                    <button onClick={() => { closeTab(activeFile); setMoreMenuOpen(false); }}>Close tab</button>
                  )}
                </div>
              )}
            </div>
          </div>

          <div className="obs-subheader">
            <div className="obs-subheader__title" title={showWelcomeTab ? 'New tab' : (activeFilePath || 'No file')}>
              {showWelcomeTab ? 'New tab' : (activeFilePath || 'No file')}
              {!isRunning && execTime && (
                <span className="ce-subheader__stats">
                  <span className="ce-subheader__stat">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                    {execTime}s
                  </span>
                  {execMemory && (
                    <span className="ce-subheader__stat">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="2" y="2" width="20" height="8" rx="2" ry="2" />
                        <rect x="2" y="14" width="20" height="8" rx="2" ry="2" />
                      </svg>
                      {execMemory}
                    </span>
                  )}
                  {execEngine && <span className="ce-subheader__engine">{execEngine}</span>}
                </span>
              )}
              {isRunning && <span className="ce-subheader__running">Running...</span>}
            </div>
          </div>

          {!showWelcomeTab && activeFile && activeFileData ? (
            <div className={`ce-main ${layoutMode === 'side' ? 'ce-main--side' : ''}`} ref={splitRef}>
              <div
                className="ce-editor-area"
                style={layoutMode === 'side'
                  ? { width: `${100 - consoleSize}%` }
                  : { height: `${100 - consoleSize}%` }}
              >
                <div className="ce-editor-pane">
                  <Editor
                    height="100%"
                    theme={monacoTheme}
                    onMount={handleEditorMount}
                    loading={
                      <div className="ce-editor-loading">
                        <div className="ce-spinner" />
                        <span>Loading editor...</span>
                      </div>
                    }
                    options={{
                      fontSize: 14,
                      fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace",
                      minimap: { enabled: false },
                      readOnly: false,
                      domReadOnly: false,
                      // Force the classic <textarea> input host. Monaco's new
                      // EditContext-based input (native-edit-context DIV) was
                      // swallowing all keys in this app (confirmed via runtime
                      // logs: zero onKeyDown events, focus bouncing to
                      // DIV.native-edit-context).
                      experimentalEditContextEnabled: false,
                      scrollBeyondLastLine: false,
                      automaticLayout: true,
                      tabSize: 4,
                      wordWrap: 'on',
                      suggestOnTriggerCharacters: true,
                      quickSuggestions: { other: 'on', comments: 'off', strings: 'on' },
                      acceptSuggestionOnCommitCharacter: true,
                      snippetSuggestions: 'inline',
                      suggest: {
                        localityBonus: true,
                        showIcons: true,
                        showStatusBar: true,
                        preview: true,
                        filterGraceful: true,
                        snippetsPreventQuickSuggestions: false,
                      },
                      wordBasedSuggestions: 'currentDocument',
                      parameterHints: { enabled: true, cycle: true },
                      padding: { top: 8 },
                      lineNumbers: 'on',
                      renderLineHighlight: 'line',
                      cursorBlinking: 'smooth',
                      cursorSmoothCaretAnimation: 'on',
                      smoothScrolling: true,
                      bracketPairColorization: { enabled: true },
                      guides: { bracketPairs: true },
                      scrollbar: {
                        horizontal: 'hidden',
                        verticalScrollbarSize: 7,
                        horizontalScrollbarSize: 0,
                        useShadows: false,
                        verticalHasArrows: false,
                        horizontalHasArrows: false,
                        arrowSize: 0,
                      },
                    }}
                  />
                </div>
              </div>

              <div className="ce-hsplit" onMouseDown={handleSplitMouseDown} />

              <div
                className="ce-terminal-area"
                style={layoutMode === 'side' ? { width: `${consoleSize}%` } : { height: `${consoleSize}%` }}
              >
                <div className="ce-terminal-header">
                  <div className="ce-terminal-header__left">
                    <span className="ce-terminal-header__title">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <polyline points="4 17 10 11 4 5" />
                        <line x1="12" y1="19" x2="20" y2="19" />
                      </svg>
                      Output
                    </span>
                  </div>
                </div>

                {showStdin && (
                  <div className="ce-stdin-panel">
                    <div className="ce-stdin-panel__label">
                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2" />
                        <polyline points="9 11 12 14 15 11" />
                      </svg>
                      Standard Input (stdin)
                    </div>
                    <textarea
                      className="ce-stdin-panel__input"
                      value={stdinValue}
                      onChange={(e) => setStdinValue(e.target.value)}
                      placeholder="Enter input for your program here... (one value per line)"
                      rows={3}
                      spellCheck={false}
                    />
                  </div>
                )}

                <TerminalComponent ref={terminalRef} theme={theme} onExecDone={handleExecDone} />
              </div>
            </div>
          ) : (
            <div className="obs-empty">
              <div className="obs-empty__content ce-empty__content">
                <span className="ce-empty__eyebrow">Code Workspace</span>
                <h2 className="ce-empty__title">New tab</h2>
                <p className="ce-empty__copy">
                  Start with a ready template for C++, Python, Java, or JavaScript.
                </p>
                <div className="ce-empty__actions">
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('cpp')}>
                    <span>C++ starter</span>
                    <kbd>.cpp</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('python')}>
                    <span>Python starter</span>
                    <kbd>.py</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('java')}>
                    <span>Java starter</span>
                    <kbd>.java</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('javascript')}>
                    <span>JavaScript starter</span>
                    <kbd>.js</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('sqlite')}>
                    <span>SQLite starter</span>
                    <kbd>.sql</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('mysql')}>
                    <span>MySQL starter</span>
                    <kbd>.sql</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={() => handleCreateStarter('oracle')}>
                    <span>Oracle starter</span>
                    <kbd>.sql</kbd>
                  </button>
                  <button className="obs-empty__action ce-empty__action" onClick={handleCreateUntitled}>
                    <span>Create empty file</span>
                    <kbd>.txt</kbd>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
