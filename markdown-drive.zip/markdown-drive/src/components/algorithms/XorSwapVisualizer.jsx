import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(a0, b0) {
  let a = a0;
  let b = b0;
  const steps = [];
  const push = (label) => {
    steps.push({ type: 'state', cells: [String(a), String(b)], title: label });
  };
  push(`start a=${a}, b=${b}`);
  a ^= b;
  push('a ^= b');
  b ^= a;
  push('b ^= a');
  a ^= b;
  push('a ^= b  (values swapped)');
  steps.push({ type: 'done', cells: [String(a), String(b)], title: `✓ a=${a}, b=${b}` });
  return steps;
}

export default function XorSwapVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(14, 27);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Swap without temp using XOR' });
    canvasRef.current?.setState({
      cells: steps[0].cells,
      colors: { 0: 'active', 1: 'pivot' },
      title: steps[0].title,
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = { 0: 'active', 1: 'pivot' };
    if (step.type === 'done') {
      colors[0] = 'sorted';
      colors[1] = 'sorted';
    }
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.title || step.type });
    canvasRef.current?.setState({
      cells: step.cells,
      colors,
      title: step.title,
      pointers: { i: 0, j: 1 },
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
