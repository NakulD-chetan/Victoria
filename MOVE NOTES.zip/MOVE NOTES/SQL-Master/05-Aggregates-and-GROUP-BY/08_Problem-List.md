# Aggregates and GROUP BY — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. GROUP BY = backbone of data analysis interviews.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|------|-------------|---------------|
| 1 | Duplicate Emails | Easy | 182 | GROUP + HAVING | Purest GROUP BY problem — find duplicates |
| 2 | Classes More Than 5 Students | Easy | 596 | HAVING COUNT ≥ 5 | Simple threshold filter on groups |
| 3 | Actors & Directors ≥ 3 Cooperations | Easy | 1050 | Multi-column GROUP | Pair grouping with HAVING |
| 4 | Daily Leads and Partners | Easy | 1693 | COUNT DISTINCT + GROUP | Multi-column distinct count |
| 5 | Average Selling Price | Medium | 1251 | Weighted AVG | SUM(price*units)/SUM(units) |
| 6 | Queries Quality and Percentage | Medium | 1211 | AVG + CASE | Conditional aggregation |
| 7 | Monthly Transactions I | Medium | 1193 | Multi-agg + CASE | COUNT/SUM with conditions in one query |
| 8 | Product Sales Analysis III | Medium | 1070 | GROUP + MIN | First year logic per product |
| 9 | Confirmation Rate | Medium | 1934 | AVG(CASE WHEN) | Ratio computation — FAANG staple |
| 10 | Trips and Users | Hard | 262 | GROUP + multi-filter | Cancel rate with role exclusions |

---

## Complete 30-Problem Progression

### Easy (Problems 1-10) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Duplicate Emails | 182 | GROUP + HAVING > 1 | Find duplicates |
| 2 | Classes More Than 5 Students | 596 | HAVING COUNT | Threshold on group size |
| 3 | Customer Placing Largest # Orders | 586 | GROUP + ORDER + LIMIT | Most frequent value |
| 4 | Actors & Directors ≥ 3 Times | 1050 | Multi-col GROUP | Pair frequency |
| 5 | Daily Leads and Partners | 1693 | COUNT(DISTINCT) | Unique counts per group |
| 6 | Game Play Analysis I | 511 | MIN per group | First login date |
| 7 | Group Sold Products By Date | 1484 | GROUP_CONCAT | Aggregate strings per group |
| 8 | Customer Who Visited No Transaction | 1581 | LEFT JOIN + COUNT | Count with anti-pattern |
| 9 | The Latest Login in 2020 | 1890 | MAX + WHERE year | Last event per user |
| 10 | User Activity for Past 30 Days I | 1141 | COUNT DISTINCT + date | DAU within window |

### Medium (Problems 11-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 11 | Average Selling Price | 1251 | Weighted average | SUM(p*q)/SUM(q) |
| 12 | Queries Quality and Percentage | 1211 | AVG(CASE) | Conditional mean |
| 13 | Monthly Transactions I | 1193 | Multi-CASE agg | Multiple conditional aggregates |
| 14 | Immediate Food Delivery II | 1174 | AVG on first-row | Subquery for first order → ratio |
| 15 | Confirmation Rate | 1934 | AVG(CASE) ratio | Fraction confirmed |
| 16 | Product Sales Analysis III | 1070 | GROUP + MIN join | First-year sales |
| 17 | Percentage of Users Attended Contest | 1633 | COUNT / total | Ratio to fixed denominator |
| 18 | Investments in 2016 | 585 | GROUP HAVING + NOT | Shared value AND unique location |
| 19 | Count Salary Categories | 1907 | CASE buckets + COUNT | Categorize then count per bucket |
| 20 | Managers with ≥ 5 Direct Reports | 570 | Self-join + HAVING | Count children ≥ 5 |
| 21 | Market Analysis I | 1158 | LEFT JOIN + COUNT | Count per user with year filter |
| 22 | Number of Unique Subjects Taught | 2356 | COUNT DISTINCT per group | Multi-dimension grouping |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | Trips and Users | 262 | Multi-filter + ratio | Cancel rate excluding banned |
| 24 | Median Employee Salary | 569 | Median via ROW_NUMBER | Middle row(s) per dept |
| 25 | Find Cumulative Salary | 579 | Rolling 3-month SUM | Running aggregate with exclusion |
| 26 | Average Salary: Departments vs Company | 615 | CTE + compare | Dept avg vs company avg per month |
| 27 | Active Businesses | 1126 | Avg per event → filter | HAVING occurrences > avg |
| 28 | Reported Posts II | 1132 | Daily ratio → AVG | Average of daily fractions |
| 29 | Tournament Winners | 1194 | CTE + SUM + RANK | Multi-step aggregate chain |
| 30 | Sales by Day of the Week | 1479 | PIVOT via CASE | SUM(CASE WHEN day=X) per category |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Duplicate Emails (LC 182)
```
Type: GROUP + HAVING
Key: SELECT email FROM Person GROUP BY email HAVING COUNT(*) > 1
One-liner: GROUP BY candidate, HAVING COUNT > 1 = find duplicates. Universal pattern.
```

### Problem 11: Average Selling Price (LC 1251)
```
Type: Weighted average
Key: SUM(price * units) / SUM(units) — NOT AVG(price)
Trap: Simple AVG(price) ignores quantity weighting
One-liner: Weighted average = total revenue / total units sold.
```

### Problem 13: Monthly Transactions I (LC 1193)
```
Type: Multi-conditional aggregation
Key: COUNT(*), SUM(amount), COUNT(CASE WHEN state='approved'), SUM(CASE WHEN …)
One-liner: Multiple CASE-aggregates in one SELECT — avoids multiple queries.
```

### Problem 23: Trips and Users (LC 262)
```
Type: Multi-filter ratio
Key: Filter out banned users via subquery/join, GROUP BY day,
     ROUND(SUM(CASE WHEN status LIKE 'cancelled%' THEN 1 ELSE 0 END) / COUNT(*), 2)
One-liner: Cancel rate = cancelled trips / total trips per day (exclude banned).
```

---

## Pattern Distribution

```
GROUP + HAVING (find):   6 problems  (1-5, 20)
MIN/MAX per group:       3 problems  (6, 9, 16)
COUNT DISTINCT:          4 problems  (5, 10, 17, 22)
CONDITIONAL AGG (CASE):  7 problems  (11-15, 19, 30)
WEIGHTED/RATIO:          4 problems  (11, 15, 17, 23)
MULTI-STEP CTE + AGG:   4 problems  (25, 26, 28, 29)
PIVOT/UNPIVOT:           2 problems  (19, 30)
```

---

## Weekly Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Problems 1-4 (GROUP + HAVING basics)
- Day 2: Problems 5-7 (COUNT DISTINCT, GROUP_CONCAT)
- Day 3: Problems 8-10 (LEFT JOIN + COUNT, date grouping)

### Week 2: Core (Days 4-7)
- Day 4: Problems 11-13 (weighted avg, conditional agg)
- Day 5: Problems 14-16 (ratio, first-year logic)
- Day 6: Problems 17-19 (percentage, categories)
- Day 7: Problems 20-22 (self-join + HAVING, market analysis)

### Week 3: Hard (Days 8-10)
- Day 8: Problems 23-25 (Trips, median, cumulative)
- Day 9: Problems 26-28 (dept vs company avg, daily ratio avg)
- Day 10: Problems 29-30 (tournament chain, pivot)

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (10 Easy, 12 Medium, 8 Hard)
MUST-DO:            LC 182, 596, 1050, 1693, 1251, 1211, 1193, 1070, 1934, 262
TOP 3 MOST ASKED:   LC 1934 (Confirm Rate), LC 1251 (Weighted Avg), LC 262 (Trips)
PATTERN SPLIT:      HAVING (6), MIN/MAX (3), COUNT DISTINCT (4),
                    CASE agg (7), Ratio (4), CTE+agg (4), Pivot (2)
STUDY ORDER:        GROUP+HAVING → COUNT DISTINCT → CASE agg → Weighted avg → Ratio
INTERVIEW LINE:     "I compute ratios via AVG(CASE WHEN … THEN 1 ELSE 0 END)
                     and weighted averages via SUM(x*w)/SUM(w)."
```

---

## 30-SECOND REVISION BOX

```
DUPLICATES:     LC 182 — GROUP BY col HAVING COUNT(*) > 1
WEIGHTED AVG:   LC 1251 — SUM(price*units) / SUM(units)
RATIO:          LC 1934 — AVG(CASE WHEN action='confirmed' THEN 1 ELSE 0 END)
MULTI-CASE:     LC 1193 — Multiple COUNT/SUM(CASE WHEN …) in one SELECT
CANCEL RATE:    LC 262 — Exclude banned users → GROUP BY day → ratio
```
