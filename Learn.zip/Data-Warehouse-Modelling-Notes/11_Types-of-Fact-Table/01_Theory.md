# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}

==================================================

1. TYPES OF FACT TABLES (VERY IMPORTANT)

==================================================

Key idea:

- Not all fact tables are same
- Different business needs → different fact table types

Types:

1. Transaction Fact Table
2. Periodic Snapshot Fact Table
3. Accumulating Snapshot Fact Table

---

## Real-world analogy

Grocery store tracks:

1. Checkout sales → Transaction fact
2. Daily inventory → Periodic snapshot
3. Order lifecycle → Accumulating snapshot

Meaning:

- Different data → different structure

==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Each fact table type depends on:

- Nature of data
- Time behavior
- Update pattern

Important:
Choose fact type based on business process

==================================================
3. TRANSACTION FACT TABLE
==================================================

---

## Definition

- One row per event

Example:

- One sale line
- One click
- One transaction

---

## Properties

Grain:

- Very detailed (atomic)

Growth:

- Very large table

Updates:

- Mostly insert only

Time:

- Event time

---

## Example

Receipt:

- Item 1 → 1 row
- Item 2 → 1 row

---

## SQL Example

CREATE TABLE fact_pos_sale_line (
  transaction_id,
  line_no,
  product_sk,
  store_sk,
  date_sk,
  sale_amount,
  quantity
);

---

## When to use

- Sales analysis
- Promotion analysis
- Detailed reporting

---

## Important Note

This is most common fact type

==================================================
4. PERIODIC SNAPSHOT FACT TABLE
==================================================

---

## Definition

- One row per entity per time period

Example:

- Daily inventory per store and product

---

## Properties

Grain:

- Time-based (daily, weekly)

Growth:

- Dense table (many rows)

Updates:

- Replace or merge per period

---

## Example

Day 1:
Store A, Product X → 100

Day 2:
Store A, Product X → 90

---

## SQL Example

CREATE TABLE fact_inventory_daily (
  store_sk,
  product_sk,
  date_sk,
  on_hand_units
);

---

## Important Insight

- Even if value is 0 → row exists

---

## Challenges

- Large storage
- Dense data

---

## Mitigation(control or minimize damage)

- Use weekly instead of daily
- Store only active products

==================================================
5. ACCUMULATING SNAPSHOT FACT TABLE
==================================================

---

## Definition

- One row per process
- Updated over time

---

## Example

Order lifecycle:

placed → picked → shipped → delivered

---

## Properties

Grain:

- One row per order

Updates:

- Multiple updates

Purpose:

- Track process stages

---

## SQL Example

CREATE TABLE fact_order_fulfillment (
  order_id,
  customer_sk,
  placed_date,
  shipped_date,
  delivered_date,
  total_amount
);

---

## Important Insight

- Same row gets updated

---

## Use case

- SLA tracking
- Delivery time analysis

==================================================
6. COMPARISON OF ALL TYPES
==================================================

Transaction:

- What happened?
- Insert-only

Periodic Snapshot:

- What was state at time?
- Dense data

Accumulating Snapshot:

- How process progressed?
- Update-heavy

==================================================
7. INSERT vs UPDATE PATTERNS
==================================================

---

## Transaction Fact

- Only INSERT

---

## Periodic Snapshot

- Delete + Insert (per day)

---

## Accumulating Snapshot

- MERGE (update existing rows)

==================================================
8. WHEN TO USE WHICH
==================================================

---

## Use Transaction Fact

- Sales
- Clickstream

---

## Use Periodic Snapshot

- Inventory
- Balance

---

## Use Accumulating Snapshot

- Order lifecycle
- Workflow tracking

==================================================
9. USING MULTIPLE FACT TABLES
==================================================

Example system:

- fact_sales → demand
- fact_inventory → supply
- fact_orders → process

---

## Important Rule

Use shared dimensions:

- dim_product
- dim_store

---

## Why?

- Enables combined analysis

==================================================
10. IMPORTANT WARNING
==================================================

Problem:
Joining different grains incorrectly

Example:

- Sales (line-level)
- Inventory (daily)

Result:

- Duplicate data

---

## Solution

- Aggregate before join

==================================================
11. COMMON MISTAKES
==================================================

---

1. Using wrong fact type

---

Problem:

- Wrong analysis

Fix:

- Match business need

---

1. Using transaction for inventory

---

Problem:

- Cannot track levels

Fix:

- Use snapshot

---

1. Too many updates in transaction fact

---

Problem:

- Performance issue

Fix:

- Keep insert-only

---

1. Mixed grain in same table

---

Problem:

- Wrong aggregation

Fix:

- Separate tables

---

1. Huge accumulating snapshot

---

Problem:

- Sparse data

Fix:

- Use better design

==================================================
12. FINAL TAKEAWAY
==================================================

Fact table type depends on:

- Event data → Transaction
- State data → Snapshot
- Process data → Accumulating

---

## Golden Rule

Match:
Data type → Fact table type

---

## Big Insight

Wrong fact type = wrong data model

==================================================
13. QUICK MEMORY SUMMARY
==================================================

Transaction:

- Event-based
- Insert-only

Periodic Snapshot:

- Time-based
- Dense data

Accumulating Snapshot:

- Process-based
- Update-heavy

Goal:

- Choose correct structure for correct analysis

