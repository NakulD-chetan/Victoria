# Scalability — Concept

> **Permanent Recall:** Scalability is the ability of a system to handle growth in load without proportional degradation. You scale **up** (vertical) by adding CPU/RAM to a single machine, or **out** (horizontal) by adding more machines. Stateless services scale horizontally easily; stateful services are bottlenecked. Read-heavy systems use replicas; write-heavy systems need sharding. FAANG asks scalability in nearly every system design round — start simple, identify bottlenecks, then scale intelligently.

---

## What Is Scalability?

**Scalability** = a system's capacity to accommodate increasing load (more users, requests, or data) while maintaining performance.

```
Load increases (10x traffic)  →  System should handle it
                               →  Without 10x latency or 10x cost (ideally sublinear cost)
```

Two dimensions:
- **Throughput scalability:** More requests per second (RPS)
- **Data scalability:** More data to store and query

---

## Vertical vs Horizontal Scaling

| Aspect | Vertical Scaling (Scale Up) | Horizontal Scaling (Scale Out) |
|--------|----------------------------|---------------------------------|
| **What** | Add CPU, RAM, disk to existing machine | Add more machines to the fleet |
| **Complexity** | Simple — often just configuration | Complex — load balancing, distributed state |
| **Limit** | Hardware ceiling (single machine max) | Nearly unlimited (add machines) |
| **Cost** | Expensive at high tiers (non-linear) | More linear cost curve |
| **Downtime** | Often requires restart | Zero-downtime rolling deploys |
| **Single point of failure** | Yes — one big machine | No — distributed across many |
| **When** | Quick fix, low traffic, monolith | Production, high traffic, cloud-native |

> **FAANG Tip:** In interviews, say "I'll start with vertical scaling for simplicity, then move to horizontal when we hit limits" — shows you understand both and think pragmatically.

---

## ASCII: Vertical vs Horizontal Scaling

```
VERTICAL (Scale Up):
┌─────────────────────────────────────┐
│         SINGLE MACHINE              │
│  CPU: 4 → 16 cores                  │
│  RAM: 16GB → 64GB                   │
│  [App] [DB] [Cache]  all on one     │
└─────────────────────────────────────┘
          ↑ Bigger box

HORIZONTAL (Scale Out):
┌─────┐  ┌─────┐  ┌─────┐  ┌─────┐
│ App │  │ App │  │ App │  │ App │  ...
└──┬──┘  └──┬──┘  └──┬──┘  └──┬──┘
   └────────┴────────┴────────┘
              │
        ┌─────┴─────┐
        │ Load Balancer │
        └───────────┘
          ↑ More identical boxes
```

---

## Stateless vs Stateful Services

| Type | Definition | Scaling | Example |
|------|------------|---------|---------|
| **Stateless** | No in-memory session or user-specific state; any server can serve any request | Trivial — add servers, LB distributes | Web API servers, microservices |
| **Stateful** | Session data, sticky connections, or local cache that must stay with a server | Complex — must preserve affinity or centralize state | WebSocket servers, in-process caches |

**Golden rule:** Design stateless whenever possible. Store state in Redis, DB, or client (JWT). Then you can add/remove servers without breaking sessions.

---

## Read Scaling vs Write Scaling

| Operation | Primary Strategy | Secondary |
|-----------|------------------|-----------|
| **Read-heavy** | Read replicas (primary + N replicas) | Caching (Redis, CDN) |
| **Write-heavy** | Sharding (partition data by key) | Write-behind, async processing |
| **Read + Write balanced** | Replicas + sharding | CQRS (separate read/write models) |

- **Read replicas:** Primary handles writes; replicas serve reads. Replication lag (eventual consistency) is the trade-off.
- **Sharding:** Split data across DBs by partition key (e.g., `user_id % N`). Writes distributed; cross-shard queries are expensive.

---

## Scaling Bottlenecks

The **slowest component** determines system throughput. Common bottlenecks:

| Component | Bottleneck | Typical Fix |
|-----------|------------|-------------|
| **Application servers** | CPU, memory per request | Horizontal scale (more app servers) |
| **Database** | Query latency, connection pool | Read replicas, connection pooling, sharding |
| **Cache** | Hit rate, memory | Bigger cache, better eviction, multi-tier |
| **Network** | Bandwidth, latency | CDN, edge caching, compression |
| **Disk I/O** | Reads/writes per second | SSD, RAID, read replicas |

> **FAANG Tip:** Always ask "What is the bottleneck?" before proposing a solution. Scaling the wrong thing wastes effort.

---

## Auto-Scaling and Elasticity

- **Auto-scaling:** Automatically add/remove instances based on metrics (CPU, RPS, queue depth).
- **Elasticity:** System scales up for peak load and down for low load — pay for what you use.

```
Low traffic    →  2 instances
Peak (Black Friday)  →  200 instances
Night    →  Scale back to 5
```

---

## Capacity Planning

Estimate resources before building:

| Step | Action |
|------|--------|
| 1 | Define target load (users, RPS, data size) |
| 2 | Estimate per-request cost (CPU, DB queries, cache lookups) |
| 3 | Calculate required capacity (RPS × cost per request) |
| 4 | Add headroom (2–3x for spikes) |
| 5 | Plan scaling triggers and limits |

---

## Scale Numbers Every Engineer Should Know

| Metric | Approximate Value | Context |
|--------|-------------------|---------|
| Single server RPS (simple API) | 1,000–5,000 | Stateless, in-memory |
| Single server RPS (DB-heavy) | 50–500 | Per-request DB queries |
| Read replica RPS | Similar to primary | Limited by replication |
| Cache (Redis) ops/s | 50,000–100,000 | In-memory, single node |
| DB connections per instance | ~100–500 | Pool size limit |
| Latency: same DC | &lt;1 ms | In-network |
| Latency: cross-region | 50–200 ms | US-East to US-West |
| CDN cache hit | ~1–5 ms | Edge |
| DB query (indexed) | 1–10 ms | Depends on query |

Use these for back-of-envelope: "1 server ≈ 1K RPS → 100K RPS needs ~100 app servers (with LB)."

---

## Database Scaling Preview

| Strategy | When | Trade-off |
|----------|------|-----------|
| **Read replicas** | Read-heavy, few writes | Replication lag; eventually consistent reads |
| **Sharding** | Write-heavy, large data | Cross-shard joins expensive; rebalancing hard |
| **Connection pooling** | Connection exhaustion | Reduces connections per process |

---

## Application Scaling Preview

| Strategy | When |
|----------|------|
| **Load balancers** | Distribute traffic across stateless app servers |
| **Microservices** | Scale services independently by load |
| **Async processing** | Offload heavy work to queues; decouple request from response |

---

## How Netflix / Google / Amazon Scale

| Company | Key Scaling Approach |
|---------|----------------------|
| **Netflix** | Microservices, chaos engineering, multi-region, CDN for video |
| **Google** | Spanner (global DB), Borg/Kubernetes, massive sharding |
| **Amazon** | Service-oriented architecture, Dynamo-style partitioning, S3 for object storage |

---

## Golden Rules

1. **Start simple** — single server, then scale when needed.
2. **Identify the bottleneck** — don't scale what isn't limiting you.
3. **Stateless &gt; stateful** for app tier.
4. **Read replicas** for read-heavy; **sharding** for write-heavy.
5. **Cache** before you scale DB.
6. **Measure** before and after scaling.

---

## Quick Memory Card

```
SCALE UP:    Bigger machine — simple, limited ceiling
SCALE OUT:   More machines — complex, unlimited
STATELESS:   Any server, any request → easy horizontal scale
READ:        Replicas + cache
WRITE:       Sharding + async
BOTTLENECK:  Slowest component limits throughput
AUTO-SCALE:  Add/remove instances by metric
NUMBERS:     1 server ≈ 1K RPS (simple); DB = bottleneck often
```

---

**Next: [[02_Mental-Model]]**
