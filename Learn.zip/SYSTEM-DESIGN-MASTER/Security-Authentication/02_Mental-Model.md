# Security and Authentication — Mental Model

> **Permanent Recall:** Think of **tokens as hotel key cards**—short-lived, self-contained, room-specific. **Authentication = passport** (proves identity), **authorization = visa** (proves permission to enter). Security uses **defense in depth** (layers). OAuth = "You ask Google for a letter of recommendation for the app." JWT = "self-contained passport" with expiry. Use session-based when you need instant revocation; token-based when you need stateless scale. Use the auth choice flowchart to pick the right approach.

---

## Hotel Key Card Analogy for Tokens

```
    HOTEL KEY CARD = JWT / ACCESS TOKEN
    
    • Issued at check-in (login)
    • Works only for your room (scoped permissions)
    • Expires when you check out (expiry)
    • Self-contained: no need to ask front desk every time
    • Lost? Get a new one (refresh token)
    • Hand it back at checkout (logout / revoke)
```

| Token Concept | Hotel Analogy |
|---------------|---------------|
| Access token | Key card for your room |
| Refresh token | Receipt to get new key if lost |
| Expiry | Key stops working at checkout time |
| Revocation | Hotel deactivates key |

---

## Passport + Visa for Authentication vs Authorization

```
    PASSPORT = Authentication
    • Proves WHO you are
    • Issued by trusted authority (IdP)
    
    VISA = Authorization
    • Proves you're ALLOWED to enter/cross border
    • Issued based on passport + rules
```

**Mental model:** Authentication confirms identity; authorization checks what that identity is allowed to do. You need both.

---

## Defense in Depth (Security Layers)

```
    ┌─────────────────────────────────────┐
    │  LAYER 1: Network (WAF, DDoS)      │
    ├─────────────────────────────────────┤
    │  LAYER 2: Transport (HTTPS/TLS)     │
    ├─────────────────────────────────────┤
    │  LAYER 3: Auth (login, MFA)        │
    ├─────────────────────────────────────┤
    │  LAYER 4: Authorization (RBAC)     │
    ├─────────────────────────────────────┤
    │  LAYER 5: Data (encrypt at rest)    │
    └─────────────────────────────────────┘
```

**Rule:** One breach shouldn't compromise everything. Each layer adds protection.

---

## OAuth 2.0 Flow Mental Model

**"You, Google, and the App"**

```
    YOU (User)     → Want to use App with your Google account
    GOOGLE (Auth)  → Trusted identity provider
    APP            → Wants limited access (e.g., read email)
    
    Flow: You tell Google "App wants X" → You consent → Google gives App
          a limited token (not your password). App uses token to call
          Google APIs on your behalf.
```

**Key idea:** You never give the app your password. You delegate access via Google.

---

## JWT as "Self-Contained Passport"

```
    TRADITIONAL: Server stores session → lookup on every request
    JWT:          Token carries claims → server verifies signature only
    
    Like a passport: all info is IN the document. Border (server) just
    checks it's valid (signature, not expired) — no central lookup.
```

**When it fits:** Stateless APIs, microservices, distributed systems.

---

## When Session-Based Is Better Than Token-Based

| Prefer Session | Why |
|----------------|-----|
| Need instant revocation | Delete session → done. JWT needs blacklist or short TTL |
| High-security apps | Banking, admin: want "logout everywhere" immediately |
| Server-rendered pages | Cookies, same-origin; simpler |
| Small scale | Single server or small cluster; session store is fine |

> **FAANG Tip:** "For instant logout and high-security, session-based wins. For scale and microservices, JWT wins."

---

## Decision Flowchart: Auth Choice

```mermaid
flowchart TD
    A[Choose Auth Strategy] --> B{Who accesses?}
    B -->|Internal service / Partner API| C[API Key]
    B -->|End user, third-party app| D[OAuth 2.0]
    B -->|End user, our own app| E{Need stateless?}
    E -->|Yes, microservices / APIs| F[JWT]
    E -->|No, traditional web app| G[Session-based]
    B -->|Enterprise SSO| H[SAML / OIDC]
    C --> I[Simple, revocable key]
    D --> J[Authorization code / PKCE]
    F --> K[Short access + refresh]
    G --> L[Server session store]
    H --> M[Identity provider federation]
```

---

## Auth Choice Summary Table

| Scenario | Best Choice |
|----------|-------------|
| Internal API, machine-to-machine | API key |
| Third-party app, user consent | OAuth 2.0 |
| Our mobile/web app, stateless backend | JWT |
| Traditional web app, need instant logout | Session |
| Enterprise SSO, multiple apps | SAML / OIDC |

---

## Security Decision Mental Models

| Question | Mental Model |
|----------|---------------|
| "Which auth?" | Who is the client? What do they need? |
| "JWT or session?" | Stateless + scale vs instant revoke |
| "OAuth or API key?" | User delegation vs machine identity |
| "How to store passwords?" | Never plain; bcrypt = slow, salted |

---

## 30-SECOND REVISION BOX

```
TOKEN = Hotel key card (self-contained, expires)
AUTHN = Passport (identity)
AUTHZ = Visa (permission)
DEFENSE IN DEPTH = Multiple layers
OAUTH = You + Google + App (delegate, no password)
JWT = Self-contained passport (stateless)
SESSION when: Instant revoke, high security
FLOWCHART: Internal→API key, Third-party→OAuth, Our app→JWT/Session
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
