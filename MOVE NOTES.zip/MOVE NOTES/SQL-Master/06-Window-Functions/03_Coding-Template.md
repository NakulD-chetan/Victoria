# Window Functions — Coding Templates

---

## Rank within groups

```sql
SELECT
    user_id,
    order_ts,
    amount,
    ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY order_ts) AS ord_num
FROM orders;
```

---

## Running total

```sql
SELECT d, revenue,
       SUM(revenue) OVER (ORDER BY d ROWS UNBOUNDED PRECEDING) AS cum
FROM daily;
```

---

## Previous value

```sql
SELECT day, revenue,
       LAG(revenue, 1) OVER (ORDER BY day) AS prev_rev
FROM daily;
```

---

## Top-N per partition (pattern)

```sql
WITH ranked AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY dept_id ORDER BY salary DESC) AS rn
    FROM employees
)
SELECT * FROM ranked WHERE rn <= 3;
```

---

*Next: [[04_Interview-Thinking]]*
