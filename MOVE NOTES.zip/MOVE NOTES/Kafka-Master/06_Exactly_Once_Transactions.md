# 6. Exactly-Once Semantics & Transactions

> **Permanent Recall Note:** **At-most-once** = no retries (loss). **At-least-once** = retries (duplicates). **Exactly-once** in Kafka means **EOS within Kafka** via **idempotent producer + transactions + read_committed consumer** — end-to-end EOS still needs **idempotent sinks** (DB upsert, merge) or **outbox** patterns. Spark’s EOS vocabulary overlaps — compare with checkpoint + idempotent writes in [../spark/13_Data_Quality_Idempotency.md](../spark/13_Data_Quality_Idempotency.md).

### The 10-Second Summary
- **Idempotent producer:** PID + sequence numbers — **broker-side** deduplication.
- **Transactions:** `transactional.id`, `initTransactions`, `beginTransaction`, `commit`/`abort`.
- **Isolation:** `read_committed` hides open transactions; `read_uncommitted` sees all.
- **Transaction coordinator:** **internal __transaction_state** partition assignment per transactional id.

---

# 6.1 Delivery Semantics Triangle

```
        At-most-once
              ▲
             / \
            /   \
           /     \
   No retry   Retries +
   no dup      dedupe
            At-least-once ─────► Exactly-once (Kafka + app)
```

💡 **Key Insight:** **EOS** is never “free” — latency, throughput, and operational **transaction timeout** constraints.

---

# 6.2 Idempotent Producer — Deep Dive

```properties
enable.idempotence=true
# Sets: acks=all, appropriate retries, max.in.flight bounded (per version)
```

- Broker tracks **(PID, seq)** per partition — duplicates from retries **dropped**.
- **New** session (new PID) — **not** deduped against old — **still** need idempotent sinks.

### Java — minimal

```java
props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, "true");
```

---

# 6.3 Transactional Producer API

```java
producer.initTransactions();

producer.beginTransaction();
producer.send(record1);
producer.send(record2);
producer.sendOffsetsToTransaction(offsets, consumer.groupMetadata());
producer.commitTransaction();

// on failure
producer.abortTransaction();
```

⚠️ **Warning:** `sendOffsetsToTransaction` ties **consumer offsets** to **message writes** — consumer must **`enable.auto.commit=false`** and **isolation=read_committed**.

---

# 6.4 read_committed vs read_uncommitted

| `isolation.level` | Consumer sees |
|-------------------|---------------|
| **read_committed** | Only **committed** messages (no aborted txn data) |
| **read_uncommitted** | All (faster visibility, **dirty** reads) |

📏 **Golden Rule:** EOS pipeline ⇒ **read_committed** on consumer.

---

# 6.5 Transaction Coordinator

- Each **transactional.id** maps to a partition in **`__transaction_state`** (internal).
- **Epoch** fencing — zombie producer **cannot** commit after new instance starts.

🧠 **Memory Trick:** **Transactional id** = **lease** on EOS for that producer identity.

---

# 6.6 Consumer Exactly-Once Patterns

**Read-process-write (single Kafka cluster):**

1. **Consume** (read_committed)
2. **Begin transaction** — produce to output topics
3. **sendOffsetsToTransaction** — commit offsets with output
4. **commitTransaction**

🔄 **Trade-off:** **Transactional** overhead — not for ultra-low-latency firehose.

---

# 6.7 Kafka Streams Exactly-Once

- `processing.guarantee=exactly_once_v2` (broker 2.5+)
- Uses **Streams** transactional tasks + **changelog** topics.

---

# 6.8 End-to-End EOS with Sinks

| Sink | Pattern |
|------|---------|
| **Database** | **Primary key upsert**, **idempotent** SQL, **dedupe** table |
| **Another topic** | **Transactional** producer + consumer as above |
| **S3 / Parquet** | **Partition overwrite** + deterministic paths — align with Spark [../spark/13_Data_Quality_Idempotency.md](../spark/13_Data_Quality_Idempotency.md) |

🏗️ **Real-World:** **Debezium** → Kafka → **Flink/Spark** with **upsert** sink — **at-least-once** Kafka + **exactly-once** sink = practical EOS.

---

# 6.9 Python — Conceptual (confluent-kafka)

```python
from confluent_kafka import Producer

p = Producer({
    "bootstrap.servers": "localhost:9092",
    "enable.idempotence": True,
    "transactional.id": "my-app-1",
})
p.init_transactions()
# begin / commit / abort as per librdkafka API
```

---

# 6.10 Transaction Timeouts & Fencing (Production)

```properties
transaction.timeout.ms=60000
```

- **Long** transactions block **consumer** visibility (`read_committed`) and stress **transaction coordinator**.
- **Zombie** producer **fenced** when new instance starts with same `transactional.id` — **epoch** increments.
- Simple bhasha mein: **txn** chhota rakho; **failure** par **abort** quickly — **stuck** open txn = **lag** for readers.

⚡ **Note:** Align **processing** duration with **transaction.timeout** — **Spark/Flink** EOS configs have analogous **timeout** knobs.

---

# 6.11 Interview Questions & Answers

**Q: Exactly-once possible without transactions?**  
**A:** **Within broker** for single producer idempotent produce — **cross-topic** consumer offset + output needs **transactions** or **external idempotency**.

**Q: Zombie fencing?**  
**A:** **transactional.id** epoch bump — old producer **cannot** commit.

**Q: Why not read_uncommitted everywhere?**  
**A:** **Uncommitted** data may **abort** — consumers see **ghost** records.

**Q: Spark Structured Streaming EOS?**  
**A:** **Micro-batch** idempotent + WAL — different mechanism, same **business** need: **no duplicate side effects**.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 6 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Idempotent = retries without duplicate log            │
│  🧠 Transactions = atomic publish + offset commit         │
│  🧠 read_committed = EOS consumer view                    │
│  🧠 End-to-end needs sink idempotency                     │
│  ⚠️  transactional.id ops — fencing and timeouts          │
│  🎯 Draw read-process-write with txn boundaries           │
└─────────────────────────────────────────────────────────────┘
```
