# How Tinder Works - In Depth (Easy Language)

> Companion to: [17-How-Tinder-Works.md](17-How-Tinder-Works.md)

---

## The Scale

```
1.6 BILLION swipes per day
26 MILLION matches per day
500+ microservices running simultaneously
```

Tinder's two unique challenges:
1. **Geospatial**: Find users within a radius (e.g., 160 km)
2. **Real-time matching**: When two people like each other, notify them instantly

---

## S2 Geospatial Library - How Tinder Finds Nearby Users

### Why Not Just Use Latitude/Longitude?

```
Naive approach:
  "Find all users within 10 km of me"
  SELECT * FROM users WHERE 
    distance(my_lat, my_lng, user_lat, user_lng) < 10 km

Problem:
  → Calculate distance for EVERY user in the database
  → 50 million users × distance calculation = extremely slow
  → No index can help (can't index a computed distance)
```

### The S2 Solution: Divide the Earth into Hexagons

Google's **S2 library** divides the entire Earth's surface into a grid of hexagonal cells:

```
Earth's surface (imagine a zoomed-in view):

    ⬡ ⬡ ⬡ ⬡ ⬡ ⬡
   ⬡ ⬡ ⬡ ⬡ ⬡ ⬡ ⬡
    ⬡ ⬡ ⬡ ⬡ ⬡ ⬡
   ⬡ ⬡ ⬡ ⬡ ⬡ ⬡ ⬡
    ⬡ ⬡ ⬡ ⬡ ⬡ ⬡

Each ⬡ = one S2 cell (hexagon)
Each cell has a unique 64-bit ID
```

### Why Hexagons? (Not Squares or Triangles)

```
With squares:
    ┌───┬───┐
    │   │   │
    ├───┼───┤
    │ • │   │  ← "•" is in center
    ├───┼───┤     Distance to corner neighbor = 1.41x
    │   │   │     Distance to edge neighbor = 1.00x
    └───┴───┘     UNEQUAL distances!

With hexagons:
      ⬡ ⬡
     ⬡ • ⬡    ← "•" is in center
      ⬡ ⬡       Distance to ALL 6 neighbors = EQUAL!
                  Simpler and more accurate distance math!
```

**Hexagons have 6 neighbors, all at the same distance.** This makes distance calculations simpler and more uniform.

### Hierarchical Cells

S2 cells are hierarchical (like zooming in on Google Maps):

```
Level 0:  Very large cell (covers a continent)
Level 5:  Medium cell (covers a city)
Level 10: Small cell (covers a neighborhood)
Level 15: Tiny cell (covers a building)
Level 30: Smallest (covers ~1 square centimeter)
```

Each level subdivides into smaller cells. The 64-bit cell ID encodes the hierarchy.

### How Tinder Uses S2

```
1. User's location: latitude=19.076, longitude=72.877 (Mumbai)
2. Convert to S2 cell ID at appropriate level: cell_id = 0x3456789ABCDEF012
3. Store user: { user_id, cell_id, profile... }
4. Cell ID is the SHARD KEY: users in same cell → same database shard

Finding nearby users:
  1. My S2 cell: 0x3456789A...
  2. Find neighboring cells: kRing(my_cell, radius=160km) → 3 cell IDs
  3. Query ONLY those 3 shards (not the entire database!)
  4. Return users from those cells
  
  Query: 3 shards instead of scanning 50 million users!
```

---

## Matching Flow - What Happens When You Swipe

```
1. You see profile of User B → Swipe RIGHT (like)

2. Your swipe goes to: Amazon Kinesis (swipe stream)
   { swiper: "you", swiped: "userB", action: "like" }

3. Match Worker picks up the swipe:
   → Check Likes Cache (Redis): "Did User B already like me?"
   
   Case A: User B hasn't liked you yet
   → Store your like in Likes Cache: "you → likes → userB"
   → Done (no match yet)
   
   Case B: User B already liked you! IT'S A MATCH!
   → Create match record
   → Send WebSocket notification to BOTH users:
     "It's a match! 🎉 You and User B liked each other!"
```

---

## The Hot Shard Problem

### What Is a Hot Shard?

```
S2 cells are shard keys. Users in the same area → same shard.

Normal area (suburbs):    1,000 users per shard → fine
Manhattan during rush hour: 500,000 users per shard → HOT SHARD!

This ONE shard gets 100x more read/write traffic than others.
It becomes the bottleneck, slowing everything down.
```

### How Tinder Solves It

```
Solution 1: Many shards per physical server
  → 1,000 virtual shards spread across 100 physical servers
  → Even if one virtual shard is hot, the physical server handles others too
  → Load is distributed randomly across hardware

Solution 2: Rate limiting on write hot shards
  → If a shard gets too many writes, slow down location updates
  → "You updated location 1 second ago, wait before updating again"
  → Reduces write pressure on hot shards
```

---

## Kafka for Location Updates - Order Matters!

### Why Ordering Is Critical

```
User moves quickly:
  10:00:00 → Location A (cell_100)
  10:00:01 → Location B (cell_200)
  10:00:02 → Location C (cell_300)

These updates MUST be processed in order!
If processed out of order (C, A, B):
  → User appears to jump from C to A to B
  → Other users searching in cell_100 find stale data
  → Matches happen with wrong location
```

### How Kafka Ensures Order

```
Kafka partition key = user_id

All location updates for User_42 go to the SAME partition:
  Partition 7: [User_42: A] → [User_42: B] → [User_42: C]
  
  Processed in order: A, B, C ✓
  
  User_99's updates go to a different partition:
  Partition 3: [User_99: X] → [User_99: Y]
  
  Different users can be processed in parallel
  Same user's updates are always in order
```

---

## The Tech Stack

```
DynamoDB:        User profiles (scalable NoSQL)
DynamoDB Streams: Change propagation (when profile updates)
S2 Library:      Geospatial indexing (hexagonal cells)
Kafka:           Location update ordering (FIFO per user)
Amazon Kinesis:  Swipe stream processing
Redis:           Likes cache (fast match checking)
WebSockets:      Real-time match notifications
S3:              Disliked profile storage (analytics)
500+ microservices behind API Gateway with service mesh
```

---

## Revision Flashcards

**Q: Why does Tinder use hexagonal cells (S2) instead of squares?**
A: Hexagons have equal distance to all 6 neighbors. Squares have unequal distances (edge neighbor vs corner neighbor). Hexagons make distance calculations simpler and more accurate.

**Q: How does S2 reduce the number of database queries?**
A: Convert user's location to an S2 cell ID. Use kRing to find neighboring cells. Query only those 3 shards (instead of scanning 50 million users). Cell ID is the shard key.

**Q: What is the hot shard problem?**
A: Dense areas (Manhattan, downtown Mumbai) have many users in one S2 cell/shard, creating disproportionate load. Solved by distributing many virtual shards across physical servers and rate limiting writes.

**Q: Why does Kafka use user_id as the partition key for location updates?**
A: To guarantee FIFO ordering per user. All location updates for one user go to the same partition, so they're processed in sequence. Different users' updates are parallelized.

**Q: How does real-time matching work?**
A: Swipes go to Kinesis stream → match workers check Likes cache (Redis) → if mutual like found → match event → WebSocket notification to both users.
