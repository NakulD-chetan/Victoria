# Data Warehouse Internals

> *"Not all tables are created equal — some are scaffolding, some are the building."* — Practical warehouse engineering saying

**Real-world analogy:** When a nationwide grocery retailer receives pallets from **different regional suppliers**, the back room first **stages** boxes **exactly as labeled** for inspection. Only after checks does stock move to the **sales floor** where shoppers see **consistent prices and unified barcodes**. A warehouse's **staging layer** is the back room; the **user access layer** is the curated floor.

---

## Core Idea (2 Lines)

Internally, a mature warehouse separates **landing and validation work** (**staging**) from **trusted, conformed publishing** (**user access / curated**). **ETL/ELT** moves data **through staging** so quality issues are caught **before** business rules join sources into **master dimensions** and **facts** used by BI.

---

## Two Layers: Staging and User Access

| Layer | Primary audience | Primary goal |
|-------|------------------|--------------|
| **Staging** | Engineers, data quality monitors | **Traceability**, **raw fidelity**, **validation**, replay |
| **User access (curated / presentation)** | Analysts, BI tools, certified datasets | **Stable grain**, **conformed keys**, **business-ready** joins |

```
+----------------------+        +-----------------------------+
|   STAGING LAYER      |        |   USER ACCESS LAYER         |
|  (land, inspect,     | -----> |  (dimensions, facts,        |
|   isolate issues)    |        |   conformed masters)        |
+----------------------+        +-----------------------------+
```

**Interview Tip:** Say *"Staging is where we **prove** feeds; curated is where we **promise** metrics."*

---

## ETL and Where Staging Fits

| Phase | Staging involvement |
|-------|----------------------|
| **Extract** | Often lands **as-is** payloads (files, CDC batches) |
| **Transform** | Cleansing can happen **in staging SQL** or external engines before promotion |
| **Load** | Final publish goes to **user access** tables with contracts |

```
SOURCE --> LANDING/STAGING --> TRANSFORM/CHECKS --> CURATED (USER ACCESS) --> BI
```

**Watch Out!** If everything is "curated" with no isolated landing, you lose the **time machine** to compare **what arrived** vs **what you interpreted**.

---

## Retail Example: Multiple Zones, Different Table Shapes

| Source zone | Quirk | Staging tactic |
|-------------|-------|----------------|
| **Web storefront** | Rich JSON line items, bundles | Explode JSON to staging tables with preserved raw JSON column |
| **Partner convenience stores** | Delayed files, odd SKU formats | Land file batches with **batch_id** and **file_hash** |
| **Corporate ERP** | GL-centric identifiers | Map ERP item numbers to **retailer product keys** in curated model |

```sql
-- Staging: preserve vendor columns 1:1 + metadata
CREATE TABLE stg.partner_pos_sales (
  ingest_batch_id      STRING,
  ingest_ts_utc        TIMESTAMP,
  source_file_name     STRING,
  partner_store_code   STRING,
  partner_sku          STRING,
  sale_qty             DECIMAL(18,4),
  sale_amount_local    DECIMAL(18,4),
  currency_code        STRING,
  sale_ts_local        STRING   -- intentionally raw; parse later
);
```

**Interview Tip:** Show you know **why strings stay strings** early: avoid silent bad casts; parse with explicit rules.

---

## One-to-One Staging Mapping from Source

| Principle | Meaning |
|-----------|---------|
| **1:1 column mapping** | Staging reflects upstream fields with minimal semantic change |
| **Additive metadata** | Add `ingest_ts`, `batch_id`, `checksum`, `source_system` |
| **No business joins yet** | Avoid hiding upstream problems inside early joins |

```
SOURCE TABLE A                STAGING TABLE A'
----------------              -----------------
100 columns                   100 columns + ingest metadata
```

**Watch Out!** "Helpful" early merges in staging make **root cause analysis** harder when one feed is wrong.

---

## Master and Conformed Tables in the User Access Layer

| Artifact | Role |
|----------|------|
| **`dim_product` (master)** | One row per product surrogate key; SCD attributes |
| **`dim_store` (conformed)** | Same store key used in inventory facts and sales facts |
| **`fact_sales` (grain defined)** | One row per line or per order line — documented |

```sql
-- Curated: business-ready join keys
CREATE TABLE dw.dim_product (
  product_sk          BIGINT PRIMARY KEY,
  product_natural_key STRING NOT NULL,
  category            STRING,
  brand               STRING,
  is_perishable       BOOLEAN,
  effective_start_dt  DATE,
  effective_end_dt    DATE,
  is_current            BOOLEAN
);

CREATE TABLE dw.fact_sales (
  sales_fact_sk       BIGINT PRIMARY KEY,
  order_line_id       STRING NOT NULL,
  order_date_sk       INT  NOT NULL REFERENCES dw.dim_date(date_sk),
  product_sk          BIGINT NOT NULL REFERENCES dw.dim_product(product_sk),
  store_sk            INT    NOT NULL REFERENCES dw.dim_store(store_sk),
  gross_sales_usd     DECIMAL(18,2),
  net_sales_usd       DECIMAL(18,2),
  quantity            DECIMAL(18,4)
);
```

**Interview Tip:** Emphasize **surrogate keys** in curated models for **slowly changing dimensions** and **integration**, even if natural keys exist upstream.

---

## Non-Persistent vs Persistent Staging

| Mode | Definition | Pros | Cons |
|------|------------|------|------|
| **Non-persistent staging** | Staging tables truncated/overwritten each load | Saves storage; simple mental model | Harder forensic audits; replay depends on external logs |
| **Persistent staging** | Retains history of landed batches (partitioned) | Strong audit, replay, late-arriving corrections | Higher storage and retention policy needs |

| Question | Non-persistent bias | Persistent bias |
|----------|---------------------|-----------------|
| Regulatory audit | risky | stronger |
| Cost sensitivity | stronger | risky |
| Frequent upstream re-sends | painful without external archive | easier |

**Watch Out!** "Persistent" without **retention and PII classification** becomes a **compliance warehouse** by accident.

---

## ASCII: Internal Flow with Quality Gates

```
+----------------+     +-------------------+     +----------------------+
| Source feeds    | --> | LANDING / STAGING | --> | VALIDATION & TESTS   |
| (POS, web, ERP) |     | (1:1-ish capture) |     | (row counts, keys,   |
+----------------+     +-------------------+     |  domains, dupes)     |
                                                   +----------+-----------+
                                                              |
                                                              v
                                                   +----------------------+
                                                   | CURATED / USER ACCESS|
                                                   | (masters, facts)     |
                                                   +----------+-----------+
                                                              |
                                                              v
                                                   +----------------------+
                                                   | BI / consumers       |
                                                   +----------------------+
```

---

## Data Quality and Validation in Staging

| Check type | Example | Failure handling |
|------------|---------|------------------|
| **Schema** | Expected columns exist | Quarantine batch |
| **Referential** | `store_code` exists in reference directory | Route to exception table |
| **Distribution** | Sudden 10x row volume | Alert on-call |
| **Business rule** | `net <= gross` | Flag rows for review |

```sql
-- Illustrative validation query (pattern)
SELECT
  ingest_batch_id,
  COUNT(*) AS row_cnt,
  COUNT(DISTINCT partner_store_code) AS store_cnt,
  SUM(CASE WHEN sale_qty < 0 THEN 1 ELSE 0 END) AS negative_qty_rows
FROM stg.partner_pos_sales
GROUP BY 1;
```

**Interview Tip:** Mention **Great Expectations / dbt tests / SQL assertions** as implementations of the same idea: **contracts at promotion time**.

---

## Staging Naming and Partitioning Conventions

| Convention | Why it helps |
|------------|--------------|
| Prefix `stg_` or schema `staging` | Clear mental boundary |
| Partition by `ingest_date` | Prune validations and replays |
| Keep **raw** and **cleansed staging** separate | Compare parser changes safely |

```
staging.raw_partner_pos_sales
staging.cln_partner_pos_sales   -- parsed types, still not conformed
dw.dim_store                    -- conformed master
```

**Watch Out!** Mixing **cleansed** and **curated** in one object often confuses **SLAs** and **ownership**.

---

## User Access Layer: Presentation Patterns

| Pattern | Description |
|---------|-------------|
| **Star schema** | Facts + dimensions; primary BI path |
| **Views as API** | `vw_sales` exposes stable columns while physical tables evolve |
| **Certified datasets** | Catalog labels for human trust |

```sql
-- Presentation view hides surrogate joins complexity for a metric subset
CREATE VIEW dw_presentation.vw_store_sales_daily AS
SELECT
  d.calendar_date,
  s.store_name,
  SUM(f.net_sales_usd) AS net_sales_usd
FROM dw.fact_sales f
JOIN dw.dim_date d ON f.order_date_sk = d.date_sk
JOIN dw.dim_store s ON f.store_sk = s.store_sk
GROUP BY 1, 2;
```

**Interview Tip:** Explain **why views** help: decouple BI from physical remapping while keeping **one curated core**.

---

## Performance Considerations by Layer

| Layer | Optimization focus |
|-------|--------------------|
| **Staging** | Fast loads, minimal indexes, partition for batch replay |
| **Curated** | Clustering/partitioning on date, foreign keys (logical), aggregates where justified |

**Watch Out!** Over-indexing staging slows **bulk loads** — index **after** load patterns are understood.

---

## Security Posture Across Layers

| Layer | Typical controls |
|-------|------------------|
| **Staging** | Engineer-only access; may contain sensitive raw fields |
| **User access** | Column masks for PII; row filters by region/role |

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Letting BI users query staging "temporarily" | **Leaks raw PII** and trains bad habits | Lock staging; expose curated views |
| Skipping validation gates | Bad batches **poison facts** | Add automated checks + quarantine |
| Joining sources first in staging | Harder debugging; hidden partial keys | Keep **1:1 land**, then controlled integration steps |
| Treating staging retention as infinite | Cost + legal exposure | Set **retention** + anonymization policies |
| No batch metadata | Cannot replay a single bad file | Store `batch_id`, checksums, lineage |

---

## Key Takeaway

> Warehouse internals are a **pipeline of trust**: **staging** captures and validates reality **close to sources**, while the **user access layer** publishes **conformed masters and facts** with stable keys and grains. Choose **persistent vs non-persistent staging** deliberately, enforce **data quality at promotion boundaries**, and keep **1:1 landing** discipline so forensic work stays possible when a partner feed goes wrong the night before Black Friday.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Two layers: STAGING (land/validate) vs USER ACCESS (trusted BI)  |
| ETL fits: extract -> stage -> transform/checks -> curated publish |
| Retail: heterogeneous sources -> staging preserves vendor shapes |
| 1:1 staging mapping aids debugging; add ingest metadata            |
| User access holds conformed masters (dim) + grain-defined facts  |
| Persistent vs non-persistent staging: audit vs cost trade        |
| DQ in staging: schema, keys, volumes, business invariants        |
+------------------------------------------------------------------+
```
