# Design YouTube/Netflix — Edge Cases

> **Permanent Recall:** Edge cases: **viral video** (millions concurrent), **transcoding failure** (retry, dead-letter), **copyright (Content ID)**, **live vs on-demand**, **low-bandwidth region**, **very large upload** (resumable), **video deletion** (CDN invalidation across POPs).

---

## Edge Cases and Solutions

| Edge Case | Problem | Solution |
|-----------|---------|----------|
| **Viral video** | Millions of concurrent streams; origin overload; CDN thundering herd | Pre-push to all CDN POPs; chunks immutable; horizontal CDN scale |
| **Transcoding failure** | Worker crash; corrupt input; partial output | Retry with backoff; dead-letter queue; alert; fallback serve partial (lower res only) |
| **Copyright detection** | DMCA; Content ID; duplicate/reused content | Hash pipeline (fingerprint); match against reference DB; block before publish; human review |
| **Live streaming vs on-demand** | Live = real-time; different pipeline | Live: ingest → real-time transcode → HLS low-latency; VOD: batch transcoding |
| **User in low-bandwidth region** | 3G; cannot stream 1080p | Adaptive bitrate: serve 240p/360p; client selects; CDN in region |
| **Very large file upload** | 10+ hour video; network drop = restart | Resumable multipart upload; chunk idempotency; retry from last chunk |
| **Video deletion** | Must remove from CDN; cached at hundreds of POPs | CDN invalidation (purge) across all POPs; eventually consistent; TTL as fallback |

---

## Viral Video (10M Concurrent Viewers)

```
Problem: One video goes viral
         → Millions of requests/sec
         → Origin would die; CDN cache cold for first request

Solution:
• Pre-push: After transcoding, push to all CDN POPs (or high-traffic regions)
• Chunks are immutable — once cached, no origin hit
• Horizontal: CDN scales; add more edge capacity
• Throttle: If unprecedentedly viral, gracefully degrade (serve lower quality)
```

> **FAANG Tip:** "Pre-push viral content to CDN" and "chunks are immutable" are the right answers.

---

## Transcoding Failure

```
Failure modes:
• Worker crash mid-encode
• Corrupt input file
• Out-of-memory (4K, long video)
• FFmpeg error

Handling:
1. Retry (3× with exponential backoff)
2. Dead-letter queue → alert → manual review
3. Partial success: If 720p done but 4K failed → serve 720p; retry 4K async
4. Fallback: Serve original (single res) if transcoding never succeeds
```

---

## Copyright Detection (Content ID)

| Stage | What | How |
|-------|------|-----|
| **Pre-publish** | Fingerprint video | Generate perceptual/fingerprint hash |
| **Match** | Compare to reference DB | Known copyrighted content |
| **Action** | Block or claim | Block upload; or monetize to rights holder |
| **Appeal** | Dispute | Human review; counter-notification |

- Pipeline: Transcoding produces fingerprint → Content ID service matches → block before CDN publish
- Reference DB: Rights holders upload reference; hashes stored; matching is O(1) lookup per segment

---

## Live Streaming vs On-Demand

| Aspect | On-Demand (VOD) | Live |
|--------|-----------------|------|
| **Transcoding** | Batch; after upload | Real-time; as stream ingests |
| **Latency** | Minutes to availability | Seconds (5–30 sec typical) |
| **Storage** | Full copy in object store | Optional DVR; ephemeral segments |
| **CDN** | Pre-push possible | Ingest → transcode → CDN (no pre-push) |
| **Failure** | Retry job | Dropped stream; restart ingest |

---

## Low-Bandwidth Region

- **Adaptive bitrate:** Client requests 240p or 360p; server has it; no special logic
- **CDN in region:** Ensure POP in or near region; avoid cross-continent fetch
- **Manifest:** Client gets all quality URLs; picks based on estimated bandwidth
- **Start low:** Client can start with 240p for fast first frame; bump up as buffer fills

---

## Resumable Upload (Very Large File)

```
1. POST /upload/init → { upload_id, chunk_size (e.g., 5MB) }
2. Client uploads chunks: PUT /upload/chunk { upload_id, chunk_index, data }
3. Each chunk idempotent: same chunk_index overwrites
4. On network drop: Client retries from last successful chunk_index
5. POST /upload/complete { upload_id } → merge chunks, trigger transcoding
6. Cleanup: Orphaned uploads (no complete in 7 days) deleted
```

---

## Video Deletion and CDN Invalidation

```
Problem: User deletes video; it's cached at 200+ CDN POPs

Solution:
• CDN invalidation API: Purge by path/pattern (e.g., /videos/123/*)
• All POPs: Invalidate across entire CDN (can take minutes)
• Eventually consistent: Some edges may serve stale until TTL
• Fallback: Short TTL for "deleted" placeholder if invalidation delayed

Caveat: Invalidation has cost (per path); use sparingly; batch if bulk delete
```

---

## Thumbnail Generation Failure

- Thumbnail = frame extraction during transcoding
- If fails: Retry; or extract from first frame of lowest resolution
- Fallback: Generic placeholder

---

## Duplicate Video Upload

- **Perceptual hash** (like photos): Detect near-duplicate
- **Action:** Soft merge (don't store twice); or flag for review
- **Storage:** Dedup in object store if identical hash

---

## Regional Failures

- **Origin down:** CDN serves from cache; no new content until origin back
- **Transcoding region down:** Queue backs up; failover workers in other region
- **Multi-region:** Replicate metadata; video in primary; async replication to DR region

---

## Rate Limiting

| Operation | Limit | Reason |
|-----------|-------|--------|
| Upload | Per-user (e.g., 10 videos/hour) | Prevent abuse |
| Transcoding | Priority queue | Premium creators first |
| Stream | Per-IP (DDoS) | Prevent scraping |

---

## Search Edge Cases

- **Empty search:** Return trending, suggestions
- **Private/unlisted video:** Exclude from search
- **Deleted video:** Remove from index; eventual consistency

---

## Recommendation Edge Cases

- **New user (no history):** Trending, popular by region
- **Cold start (new video):** Content-based (same channel, tags)
- **Filter bubble:** Diversify; occasional random explore
