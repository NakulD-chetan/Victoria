# Cache and Persist in Spark

Caching and persisting are **performance optimization techniques** that store intermediate DataFrames so Spark doesn't recompute them every time.

---

## Why Do We Need Caching?

Spark DataFrames are **immutable** and computed **lazily**. If the same DataFrame is used multiple times, Spark will **re-run all transformations** every time an action is triggered.

### The Problem (Without Cache)

```python
df = spark.read.csv("large_file.csv")
df_clean = df.filter(...).join(df2, "id").withColumn(...)

# Every action below triggers FULL recomputation of df_clean
df_clean.count()              # Computes everything from scratch
df_clean.show()               # Computes everything AGAIN
df_clean.write.parquet("out") # Computes everything YET AGAIN
```

Each action above reads the file, filters, joins, and transforms from scratch. That's 3x the work.

### The Solution (With Cache)

```python
df_clean = df.filter(...).join(df2, "id").withColumn(...)
df_clean.cache()       # Marks for caching (lazy — doesn't cache yet)
df_clean.count()       # FIRST action: computes AND caches the result

df_clean.show()        # Uses cached data — instant!
df_clean.write.parquet("out")  # Uses cached data — instant!
```

Computation cost is paid **once**. All subsequent actions reuse the cached result.

---

## Where Is Cached Data Stored?

Cached data lives in the executor's **Storage Memory** pool:

```
Executor JVM Heap
  └── Spark Memory (60%)
       └── Storage Memory (50% of Spark Memory)
            └── YOUR CACHED DATA HERE
```

- Managed by **LRU (Least Recently Used)** eviction
- If memory fills up, Spark drops old cached blocks automatically
- Evicted blocks are recomputed when needed (from DAG lineage)

---

## cache() vs persist()

### `cache()` — Simple Shortcut

```python
df.cache()
```

This is equivalent to:
```python
df.persist(StorageLevel.MEMORY_ONLY)
```

It stores data in **RAM only** as deserialized Java objects.

### `persist()` — Full Control

```python
from pyspark import StorageLevel
df.persist(StorageLevel.MEMORY_AND_DISK)
```

You choose exactly how and where to store data.

### Storage Levels

| Storage Level         | Where         | Serialized? | Speed   | Memory Usage |
|-----------------------|---------------|-------------|---------|--------------|
| MEMORY_ONLY          | RAM           | No          | Fastest | Highest      |
| MEMORY_ONLY_SER      | RAM           | Yes         | Fast    | Lower        |
| MEMORY_AND_DISK      | RAM → Disk    | No          | Medium  | Medium       |
| MEMORY_AND_DISK_SER  | RAM → Disk    | Yes         | Slower  | Low          |
| DISK_ONLY            | Disk          | Yes         | Slowest | Very low     |
| MEMORY_ONLY_2        | RAM (2 copies)| No          | Fast    | Double       |

**Most common choices:**
- `MEMORY_ONLY` — default, fastest, for data that fits in memory
- `MEMORY_AND_DISK` — for data that might not fit in memory (spills to disk instead of recomputing)
- `MEMORY_ONLY_SER` — for large datasets where you want to save memory (trades CPU for space)

---

## When TO Cache

Cache when ALL of these are true:
- DataFrame is **reused multiple times** (joins, aggregates, multiple writes)
- DataFrame is **expensive to compute** (complex transformations, heavy joins)
- DataFrame is **large enough** that recomputation is costly
- You have **enough executor memory** to hold it

### Good Caching Pattern

```python
df_enriched = (df_raw
    .join(dim_customer, "cust_id")
    .join(dim_product, "prod_id")
    .filter(col("amount") > 100)
    .withColumn("tax", col("amount") * 0.18))

df_enriched.cache()
df_enriched.count()  # Trigger caching

# Now reuse many times without recomputation
report_a = df_enriched.groupBy("region").sum("amount")
report_b = df_enriched.groupBy("category").avg("amount")
df_enriched.write.parquet("enriched_output/")
```

---

## When NOT to Cache

- DataFrame is **used only once** — caching wastes memory
- DataFrame is **small** — recomputing is cheap
- **Memory is limited** — caching will cause eviction of other important data
- Job is **bottlenecked by shuffle**, not computation — caching won't help

**Caching unnecessarily can actually slow down your job** by eating up storage memory that execution memory needs for shuffles and sorts.

---

## Unpersist — Freeing Memory

Always free cached data when you're done with it:

```python
df.unpersist()                  # Free this specific DataFrame
spark.catalog.clearCache()      # Free ALL cached data
```

This prevents unnecessary memory pressure and eviction of other cached data.

---

## Key Takeaway

> `cache()` = `persist(MEMORY_ONLY)` — stores in RAM for fast reuse.
> `persist()` = choose your storage level (RAM, disk, serialized).
> Cache only when the DataFrame is reused multiple times AND is expensive to compute.
> Always `unpersist()` when done to free memory.
