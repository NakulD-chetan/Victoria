# Design YouTube/Netflix — Interview Thinking

> **Permanent Recall:** Walkthrough order: 1) Clarify video types (short vs long-form), 2) Focus on **upload pipeline + transcoding** as the differentiator, 3) CDN strategy for global delivery, 4) Adaptive bitrate, 5) Recommendations can be mentioned but don't deep-dive unless asked. Allocate time to transcoding — it's what they're testing.

---

## Walkthrough Order

| Step | Focus | Key Points |
|------|-------|------------|
| 1 | Requirements | Upload, stream (adaptive), search, recommendations, comments, channels |
| 2 | Clarify | Short-form (Shorts/TikTok) vs long-form (YouTube/Netflix) — affects pipeline |
| 3 | Scale | 500 hours/min upload, 1B views/day, 2B users |
| 4 | **Upload pipeline** | Raw → Object Store → Transcoding (FFmpeg, multi-res) → Processed → CDN → Metadata |
| 5 | **Transcoding** | DAG of tasks; parallel encodes; most compute-expensive part |
| 6 | **Streaming** | CDN edge → origin on miss; adaptive bitrate (HLS/DASH) |
| 7 | CDN strategy | Push popular; pull long-tail |
| 8 | Metadata / Search | Cassandra, Elasticsearch |
| 9 | Recommendations | Collaborative + content-based; mention, don't over-design |

---

## What to Emphasize First

> "Video streaming has two completely different systems: the upload path and the streaming path. Upload is slow and compute-heavy because of transcoding. Streaming is fast and CDN-heavy. I'd start with the upload pipeline since transcoding is the most expensive operation."

---

## Transcoding Discussion

- **Say early:** "Transcoding is the most compute-expensive part — we'd use FFmpeg to produce multiple resolutions in parallel."
- **DAG:** "Each resolution (240p, 360p, 480p, 720p, 1080p, 4K) can be encoded in parallel; then we segment into chunks and generate the HLS manifest."
- **Async:** "Upload returns immediately; transcoding happens in background workers. User sees 'processing' until ready."

> **FAANG Tip:** Mentioning "transcoding as a DAG" and "parallel resolution encodes" signals deep video-system knowledge.

---

## CDN Strategy Discussion

- **Push vs pull:** "For popular or new videos, we pre-push to CDN edge. For long-tail, we pull on first request and cache."
- **90%+ cache hit:** "CDN should handle 90% or more of reads; origin only sees cache misses."
- **Global:** "Users worldwide — CDN POPs in every region for low latency."

---

## Adaptive Bitrate Discussion

- **HLS/DASH:** "We serve video as chunks in multiple qualities. Client selects based on network and buffer. HLS or DASH."
- **Why:** "User on 3G gets 360p; user on fiber gets 4K — same video, different quality. Reduces buffering."

---

## Time Allocation (45-min interview)

| Phase | Minutes | Content |
|-------|---------|---------|
| Requirements | 5 | Upload, stream, search, recommendations, comments, channels |
| Scale / capacity | 5 | 500 hours/min, 1B views/day, storage (5× resolution multiplier) |
| **Upload pipeline** | 12 | Raw → Transcoding (DAG) → Processed → CDN → Metadata |
| **Streaming pipeline** | 8 | CDN, adaptive bitrate, manifest |
| Metadata, search | 5 | Cassandra, Elasticsearch |
| Recommendations | 3 | Collaborative + content-based; high-level |
| Deep dive / trade-offs | 7 | Viral video, transcoding failure, or follow-up |

> **FAANG Tip:** Spend more time on upload + transcoding than on recommendations. Transcoding is the differentiator.

---

## Clarifying Questions to Ask

1. **Video type:** Short-form (Shorts/TikTok) or long-form (YouTube/Netflix)? Affects chunk size, transcoding profile.
2. **Live streaming:** In scope or out? (Live = different architecture)
3. **Scale:** 2B from day 1 or growth path?
4. **Monetization:** Ads, subscriptions — need strong consistency for payments?
5. **Content moderation:** Required in v1?

---

## What to Say in Interview

> "I'd design this as two pipelines. First, upload: client uploads raw video to object store, we enqueue a transcoding job, workers use FFmpeg to produce 240p through 4K, segment into HLS chunks, store in object store, optionally push to CDN for popular content, and update metadata. Second, streaming: client requests manifest, gets CDN URLs for chunks, fetches segments with adaptive bitrate. CDN handles 90%+ of reads. Metadata is in Cassandra; search in Elasticsearch. Recommendations would use collaborative filtering and content-based signals."

---

## Phrases That Show Depth

- "Transcoding is a DAG — we encode each resolution in parallel, then segment."
- "We'd use resumable multipart upload for large files."
- "CDN push for viral content to avoid thundering herd on origin."
- "Eventual consistency for views and likes; strong consistency for payments."
- "Content ID or similar for copyright detection in the pipeline."

---

## If You Run Out of Time

Prioritize: **Upload pipeline + transcoding** → **Streaming + CDN** → **Adaptive bitrate**. Defer: Recommendations details, comments threading, exact search implementation.

---

## Common Follow-Ups

| Question | Answer |
|----------|--------|
| "How does adaptive bitrate work?" | Manifest lists chunks at multiple qualities; client picks based on bandwidth/buffer; switches mid-stream. |
| "What if transcoding fails?" | Retry with backoff; dead-letter queue; alert; optionally serve partial (lower res only). |
| "How do you handle 10M concurrent viewers on one video?" | CDN push to all POPs; chunks are immutable; horizontal CDN scale. |
| "Add live streaming" | Real-time transcoding; HLS low-latency; different pipeline from VOD. |

---

## Key Differentiators to Emphasize

1. **Two paths** — Upload (slow, compute) vs Streaming (fast, CDN)
2. **Transcoding** — DAG, FFmpeg, parallel resolutions
3. **Adaptive bitrate** — HLS/DASH, chunks, quality ladder
4. **CDN** — Push popular, pull long-tail; 90%+ hit rate

---

## Wrap-Up

Summarize: "Two pipelines: upload with async transcoding to multiple resolutions, and streaming via CDN with adaptive bitrate. Transcoding is the compute bottleneck; CDN handles delivery. Metadata and search are separate services."
