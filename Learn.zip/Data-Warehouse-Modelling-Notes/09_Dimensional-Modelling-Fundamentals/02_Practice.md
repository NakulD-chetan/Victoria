# Dimensional Modelling Fundamentals — Practice

> "Star schemas reward discipline: one grain, many clear stories."

---

## Quick Recall

**Q:** What is a star schema?  
**A:** A central fact table connected directly to dimensions without normalized snowflake chains between facts and attributes.

**Q:** What is a snowflake in modeling terms?  
**A:** Normalized dimensions (for example, brand in a separate table from product) to save storage at the cost of extra joins.

**Q:** What is a conformed dimension?  
**A:** A dimension reused across subject areas with consistent keys and attributes—same `product_key` in web and store facts.

**Q:** What is a bus matrix?  
**A:** A grid listing business processes (facts) versus conformed dimensions showing integration scope.

**Q:** What is junk vs outrigger caution?  
**A:** Junk combines flags; outriggers hang mini-dimensions off a dimension—both need cardinality control to avoid complexity creep.

---

## Interview Questions

**1. Why are star schemas popular in retail BI?**  
**Model answer:** They are intuitive for business users, perform well on columnar engines with selective joins, and map cleanly to BI tools. Retail questions are mostly additive sums grouped by product, time, and geography. Stars reduce cognitive load compared to wide normalized schemas.

**2. When would you snowflake a product dimension?**  
**Model answer:** When brand or supplier tables are shared across many products and maintained centrally—still expose a denormalized view for BI if join complexity hurts adoption. Snowflaking is a maintenance trade, not a moral failure.

**3. How do you choose the first business process to model?**  
**Model answer:** Pick a high-value process with stable sources—often `sales` or `inventory_snapshot`—and build conformed `dim_date`, `dim_product`, and `dim_store` early so later facts plug in. Starting with a brittle process teaches bad habits.

**4. What is a factless fact table?**  
**Model answer:** A table capturing events without numeric measures, like `fact_store_promotion_display` with keys only, used for coverage or existence questions. Retailers use these for planogram compliance and promotion presence.

**5. Explain slowly changing dimensions at a high level.**  
**Model answer:** Type 1 overwrites, Type 2 versions rows with new surrogate keys and effective dates, Type 3 keeps limited "previous value" columns—retail uses Type 2 heavily for pricing and assortment attributes. The choice is always tied to reporting questions about history.

**6. What is a bridge table in dimensional modeling?**  
**Model answer:** A many-to-many resolver, such as linking `fact_sales` to multiple promotions affecting one basket, with allocation rules documented. Without rules, dollar metrics double count.

**7. How do you prevent inconsistent hierarchies in `dim_product`?**  
**Model answer:** Single parent per level, enforced ETL checks, and QA reports for orphan categories after merchandising reorganizations. A one-time hierarchy fix script is not enough without ongoing validation.

**8. What is drill-across risk with web and store sales facts?**  
**Model answer:** If both facts share conformed `dim_product` and `dim_date`, you can sum compatible measures separately and align dimensions; naive joins of two facts at mismatched grains create overstated numbers. Use aggregate queries per fact or a unified fact if appropriate.

---

## Scenario-Based Exercises

**Scenario 1 — Bus matrix workshop**  
Processes: web sales, store sales, inventory, shipments. Shared dims: date, product, customer, store.  
**Solution:** Mark conformed dims across all; note customer may be optional for anonymous web sessions with a conformed `anonymous_customer` row. Highlight which facts are periodic snapshots versus transactions.

**Scenario 2 — Returns as a separate process**  
**Solution:** Model `fact_returns` at return-line grain sharing `dim_product` and `dim_date` (return date role); reconcile to `fact_sales` via `original_order_line_key`. Document sign conventions so net sales rollups stay intuitive.

**Scenario 3 — Gift orders**  
Buyer differs from recipient.  
**Solution:** `dim_customer` for bill-to; optional `dim_recipient` or role-playing customer dimension if reporting requires both. Privacy reviews may restrict recipient detail.

```sql
SELECT d.fiscal_month,
       p.category_name,
       p.subcategory_name,
       SUM(f.net_sales_amount) AS net_sales
FROM dw.fact_sales f
JOIN dw.dim_date d ON f.order_date_key = d.date_key
JOIN dw.dim_product p ON f.product_key = p.product_key
GROUP BY ROLLUP (d.fiscal_month, p.category_name, p.subcategory_name)
ORDER BY d.fiscal_month, p.category_name, p.subcategory_name;
```

**Scenario 4 — Omnichannel customer and promotion bridges**  
**Solution:** Use a conformed `dim_customer` with channel-agnostic `party_id`; facts carry channel-specific keys as degenerate if needed, and avoid three incompatible customer dimensions. If finance will not approve promotion allocation to lines, publish a factless `fact_order_promotion` for coverage counts and keep dollar discounts on `fact_sales_line` only with explicit promotion keys.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| "Normalize everything" OLTP habit | Hurts BI usability | Justify denormalization for query patterns |
| Too many mini-facts at vague grain | Double counting | Spend time on grain statements |
| Bridge without allocation rules | Metrics explode | Document weighting or use factless for counts only |
| Skipping conformation | Siloed stars | Start with shared dimensions early |
| Confusing snowflake with star failure | Snowflake can be fine | Explain views for BI friendliness |
| Drill-across by joining two facts directly | Classic overstated KPI | Aggregate per fact or unify grain |

---

## One-Liner Answers

- Dimensional modeling organizes data into facts and dimensions for intuitive, fast retail analytics.
- Star schemas favor wide dimensions and simple joins; snowflakes trade joins for storage normalization.
- Conformed dimensions are the integration glue across e-commerce and store facts.
- A bus matrix plans which dimensions apply to which business processes.
- Grain must be explicit before any SQL or ETL is written.
- SCD strategies decide how history of changing attributes is preserved.
- Bridge tables solve many-to-many relationships with explicit business rules.
