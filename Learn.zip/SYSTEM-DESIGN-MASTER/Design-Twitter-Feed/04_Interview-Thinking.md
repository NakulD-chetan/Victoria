# Design Twitter/X Feed — Interview Thinking

> **Permanent Recall:** Step-by-step walkthrough: clarify scope → requirements → capacity → high-level design → **fan-out strategy** (the critical discussion) → deep dive. The interviewer wants to hear the **hybrid approach** and why. Expect deep dives on fan-out, timeline caching, celebrity handling, search. Minute-by-minute guide keeps you on track.

---

## Step-by-Step Interview Walkthrough

```mermaid
flowchart TD
    A[Clarify scope] --> B[Functional + NFRs]
    B --> C[Capacity estimation]
    C --> D[High-level architecture]
    D --> E[FAN-OUT STRATEGY - Critical]
    E --> F[API + Data model]
    F --> G[Deep dive]
```

| Step | Time | Focus |
|------|------|-------|
| 1. Clarify | 1–2 min | "Home feed only or user timeline too? Search? Trending? Scale?" |
| 2. Requirements | 2–3 min | Functional (post, follow, timeline, like) + NFRs (100:1, <200ms, 500M DAU) |
| 3. Estimation | 2–3 min | 2.5B tweets/day, ~28K writes, ~2.8M reads, storage PB-scale |
| 4. Architecture | 3–5 min | Tweet storage, fan-out, timeline, cache; media, search |
| 5. **Fan-out** | 5–8 min | **THE critical discussion**—push vs pull vs hybrid |
| 6. Deep dive | 5–10 min | Whatever they ask: caching, celebrity, search, etc. |

---

## The Critical Discussion: Fan-Out Strategy

**Interviewer will ask:** "When user A with 10M followers posts, how does it get to everyone's feed?"

**Wrong answers:**
- "We push to all 10M timelines" → "What if it takes minutes? What about storage?"
- "We pull on every read" → "Too slow for 2.8M read QPS"

**Right answer (hybrid):**
> "We use a hybrid. For normal users—say, under 100K followers—we fan-out on write. When they post, we push the tweet to their followers' Redis timeline caches. Reads are O(1) from cache. For celebrities—over 100K followers—we don't push. Their tweets are fetched on demand when a user loads their feed. We merge the cached timeline (from non-celeb followees) with recent tweets from celebrities. Celebrities are <1% of users but cause >50% of fan-out cost, so we optimize for them."

> **FAANG Tip:** Say the numbers. "<1% of users, >50% of cost" shows you understand the Pareto principle. This is the winning answer.

---

## How to Present the Hybrid Approach

| Point | What to say |
|-------|-------------|
| **Threshold** | "We use a follower-count threshold, e.g., 100K. Tunable based on cost." |
| **Push path** | "Tweet → Kafka → fan-out worker → for each follower, ZADD to Redis timeline" |
| **Pull path** | "On feed load: read Redis. For each celebrity in followees, fetch their last N tweets from DB. Merge, sort by timestamp, return." |
| **Trade-off** | "Slight delay for celebrity tweets (we fetch on read). Eventual consistency acceptable for feed." |
| **Optimization** | "We can cache celebrity tweets in a shared cache (e.g., celebrity:{id}:recent) to reduce DB load." |

---

## Deep Dives to Expect

| Topic | Key points |
|-------|------------|
| **Fan-out** | Hybrid, threshold, async via Kafka, batch Redis writes |
| **Timeline caching** | Redis sorted set, ZREVRANGE by timestamp, trim to 800–1000 |
| **Celebrity handling** | Pull on read; optional shared cache for celebrity recent tweets |
| **Search** | Elasticsearch; index text, hashtags; ingest from Kafka or CDC |
| **Tweet ID** | Snowflake or similar—globally unique, time-ordered, 64-bit |
| **Unfollow** | Don't remove from cache (expensive); on next feed load, filter out. Or background job to trim. |
| **Tweet deletion** | Soft delete; remove from timelines via fan-out in reverse, or filter on read |

---

## Minute-by-Minute Guide (45 min slot)

| Minutes | Activity |
|---------|----------|
| 0–2 | Clarify: "Home feed, user timeline, search? Scale—assume 500M DAU?" |
| 2–5 | Requirements: post, follow, timeline, like; 100:1 read:write, <200ms |
| 5–8 | Estimation: 2.5B tweets/day, 28K writes, 2.8M reads |
| 8–12 | High-level: Tweet Service, Fan-out, Timeline, Redis, DB |
| 12–20 | **Fan-out deep dive**—push vs pull, hybrid, celebrity threshold |
| 20–30 | API design, schema, Redis structure, media (S3 + CDN) |
| 30–40 | Search (ES), trending (stream), edge cases (unfollow, delete) |
| 40–45 | Q&A, trade-offs, scalability, wrap-up |

---

## Red Flags to Avoid

| Red flag | Fix |
|----------|-----|
| Jumping to "push to everyone" | Always discuss scale: "10M followers = 10M writes. That's a problem." |
| Ignoring celebrities | "What about Elon Musk with 100M followers?"—you must have an answer |
| No caching | "2.8M read QPS to DB? We need Redis/cache." |
| Over-engineering search | Start simple: "Elasticsearch for full-text." Don't design custom search infra. |
| Forgetting media | "Images/videos go to S3, served via CDN." |

---

## Handling Curveballs

| Curveball | Response |
|-----------|----------|
| "What if we need strong consistency?" | "We'd need synchronous fan-out or accept higher write latency. For feed, eventual is industry standard." |
| "Scale to 1B DAU?" | "Same architecture; more shards, more Redis clusters, more fan-out workers. Linear scaling." |
| "Add real-time updates?" | "WebSocket; on fan-out push, also push tweet_id to user's connection." |
| "How do you rank tweets?" | "Chronological is baseline. For relevance: ML model; merge score with recency." |

---

## 30-SECOND REVISION BOX

```
WALKTHROUGH: Scope → Reqs → Est → Arch → FAN-OUT → Deep dive
CRITICAL: Fan-out—hybrid is the answer
HYBRID: Push <100K followers, pull for celebrities
NUMBERS: <1% users, >50% fan-out cost
DEEP DIVES: Fan-out, cache, celebrity, search, Snowflake IDs
TIME: 12–20 min on fan-out; don't rush it
```

---

**Next: [[05_Common-Mistakes]]**
