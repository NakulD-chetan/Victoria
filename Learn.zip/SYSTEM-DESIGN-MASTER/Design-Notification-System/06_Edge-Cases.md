# Design Notification System — Edge Cases

> **Permanent Recall:** Edge cases: **device token invalidation**, **third-party provider outage** (APNS down), **mass notification blast** (10M users at once), **timezone-aware scheduling**, **notification priority** (urgent vs marketing), **user uninstalls app**.

---

## Edge Cases and Solutions

| Edge Case | Problem | Solution |
|-----------|---------|----------|
| **Device token invalidation** | User uninstalls; APNS returns 410 Unregistered | Remove token on 410; stop sending to that device; batch token validation |
| **Provider outage (APNS down)** | All iOS pushes fail; queue backs up | Circuit breaker; retry with backoff; optionally failover; alert |
| **Mass notification (10M users)** | Single event; 10M queue writes; hot partition | Fan-out with partitioning (user_id % N); rate-limit enqueue; batch to provider |
| **Timezone-aware scheduling** | "Remind at 9am user's local time" | Store user timezone; compute trigger time per user; delayed jobs |
| **Notification priority** | Urgent (security) vs marketing; different SLAs | Priority queues; urgent bypasses some rate limits; marketing throttled |
| **User uninstalls app** | No way to know immediately; keep sending to dead token | Rely on 410 from provider; periodic token validation job; prune inactive tokens |

---

## Device Token Invalidation

```
APNS Response: 410 Unregistered
  → Token is no longer valid (app uninstalled or token rotated)
  → Remove from device_tokens table
  → Do not retry this token

FCM Response: InvalidRegistration / NotRegistered
  → Same handling — remove token
```

- **Batch check:** Periodically send test messages to validate tokens; remove invalid
- **Multi-device:** User may have 3 devices; 1 invalid → remove that one; continue sending to other 2

---

## Third-Party Provider Outage

| Provider | Mitigation |
|----------|------------|
| **APNS down** | No failover (Apple only); circuit breaker; queue backs up; retry when healthy |
| **FCM down** | Same — Google only; retry |
| **Twilio down** | Optional: failover to secondary SMS provider (e.g., AWS SNS) |
| **SendGrid down** | Optional: failover to SES or Mailgun |

- **Circuit breaker:** After N failures, stop calling for 60s; half-open to retry
- **Monitoring:** Alert on error rate spike; dashboard for queue depth

---

## Mass Notification Blast

```
Problem: Security alert → 10M users in 5 minutes
         → 10M messages to queue
         → Hot partition if keyed poorly

Solution:
• Partition queue by user_id % 100
• Rate-limit enqueue: don't burst 10M at once; throttle to provider limit
• Batch: FCM allows 500/request; batch users by token
• Priority: Urgent queue processed first; separate from marketing
```

> **FAANG Tip:** For "notify 10M users," mention partitioning, batching to provider, and rate limiting the blast.

---

## Timezone-Aware Scheduling

```
"Send reminder at 9am user's local time"

1. User has timezone: America/Los_Angeles
2. Compute: next 9am in that timezone = 2025-03-11 17:00 UTC
3. Schedule job for that timestamp
4. Timer fires → Enqueue → Same pipeline
```

- **Storage:** `scheduled_at` in UTC; scheduler (e.g., cron, sorted set) triggers at that time
- **Edge:** User changes timezone — recalculate if job not yet fired

---

## Notification Priority

| Priority | Example | Rate limit | Queue |
|----------|---------|------------|-------|
| **Urgent** | Password reset, security alert | Bypass or high limit | High-priority queue |
| **Transactional** | Order shipped, payment | Medium limit | Normal queue |
| **Marketing** | Promo, newsletter | Low limit (5/day) | Low-priority queue |

- **Urgent** may override "no marketing" but not "no transactional"
- **Implementation:** Multiple queues or priority field; workers process high first

---

## User Uninstalls App

- **No direct signal** — We don't get "user uninstalled" from OS
- **Provider tells us:** Next send → 410/InvalidRegistration → remove token
- **Until then:** Wasted send; harmless but costs (SMS) or quota (push)
- **Mitigation:** Don't over-notify; respect rate limits; batch validation for inactive tokens

---

## Bounce and Complaints (Email)

| Event | Action |
|-------|--------|
| **Hard bounce** (invalid address) | Remove email; stop sending |
| **Soft bounce** (mailbox full) | Retry; after N failures → remove or mark |
| **Spam complaint** | Immediate opt-out; reduce send to domain |

---

## Duplicate Events

- **Problem:** Order service sends `order_shipped` twice (bug or retry)
- **Solution:** Idempotency key from event source; dedupe at API or first queue stage
- **Key:** `(user_id, event_id)` or client-provided `idempotency_key`

---

## Provider Rate Limits

- **Twilio:** e.g., 100 concurrent connections; 1 msg/sec per number
- **SendGrid:** e.g., 10K emails/hour on free tier
- **APNS/FCM:** Connection limits; batch where possible
- **Solution:** Token bucket per provider; queue backs up; don't exceed provider limits
