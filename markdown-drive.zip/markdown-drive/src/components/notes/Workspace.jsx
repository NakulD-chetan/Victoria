import { useCallback, useState } from 'react';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useSensor,
  useSensors,
} from '@dnd-kit/core';
import { useWorkspaceStore } from '../../stores/workspace-store';
import EditorPane from './EditorPane';

/*
 * Workspace — recursive renderer for the split-tree.
 *
 * Layout:
 *   - SplitNode  → <PanelGroup direction={row|col}> with two <Panel> kids
 *   - PaneNode   → <EditorPane>
 *
 * DnD wraps the whole thing so cross-pane tab drags arrive at the right
 * drop target; we read the drop's data and dispatch into workspace-store.
 */

function renderNode(node, focusedPaneId, totalPanes, setRatio) {
  if (!node) return null;
  if (node.type === 'pane') {
    return (
      <EditorPane
        pane={node.pane}
        isFocused={node.pane.id === focusedPaneId}
        canClose={totalPanes > 1}
      />
    );
  }
  /* Resize handle direction is opposite the panel-group axis. */
  const direction = node.direction === 'row' ? 'horizontal' : 'vertical';
  const ratio = Math.max(0.1, Math.min(0.9, node.ratio || 0.5));
  const splitId = node.__id;
  return (
    <PanelGroup
      direction={direction}
      className="obs-split"
      autoSaveId={splitId ? `obs:${splitId}` : undefined}
      onLayout={(sizes) => {
        if (!splitId || !Array.isArray(sizes) || sizes.length < 2) return;
        const next = sizes[0] / 100;
        if (Math.abs(next - ratio) < 0.005) return;
        setRatio(splitId, next);
      }}
    >
      <Panel defaultSize={ratio * 100} minSize={10}>
        {renderNode(node.a, focusedPaneId, totalPanes, setRatio)}
      </Panel>
      <PanelResizeHandle className={`obs-split__handle obs-split__handle--${direction}`} />
      <Panel defaultSize={(1 - ratio) * 100} minSize={10}>
        {renderNode(node.b, focusedPaneId, totalPanes, setRatio)}
      </Panel>
    </PanelGroup>
  );
}

export default function Workspace() {
  const root = useWorkspaceStore((s) => s.root);
  const focusedPaneId = useWorkspaceStore((s) => s.focusedPaneId);
  const moveTab = useWorkspaceStore((s) => s.moveTab);
  const setRatio = useWorkspaceStore((s) => s.setRatio);
  const [dragTab, setDragTab] = useState(null);

  /* Activation distance prevents accidental drags when clicking close ×. */
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 6 } }));

  const onDragStart = useCallback((event) => {
    const d = event.active.data?.current;
    if (d?.type === 'tab') {
      setDragTab({ noteId: d.noteId, title: d.title || 'Untitled' });
    }
  }, []);

  const onDragEnd = useCallback((event) => {
    const { active, over } = event;
    setDragTab(null);
    if (!over) return;
    const a = active.data?.current;
    const o = over.data?.current;
    if (!a || a.type !== 'tab') return;

    if (o.type === 'tab-slot') {
      moveTab(a.noteId, a.paneId, o.paneId, { before: o.before });
      return;
    }
    if (o.type === 'pane-strip' || o.type === 'pane-body') {
      moveTab(a.noteId, a.paneId, o.paneId);
      return;
    }
    if (o.type === 'pane-edge') {
      moveTab(a.noteId, a.paneId, o.paneId, { direction: o.direction });
    }
  }, [moveTab]);

  const onDragCancel = useCallback(() => setDragTab(null), []);

  /* Counted once so child renders share the same value. */
  const totalPanes = (function count(node) {
    if (!node) return 0;
    if (node.type === 'pane') return 1;
    return count(node.a) + count(node.b);
  })(root);

  return (
    <DndContext
      sensors={sensors}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragCancel={onDragCancel}
    >
      <div className="obs-workspace" data-dragging={dragTab ? 'true' : 'false'}>
        {renderNode(root, focusedPaneId, totalPanes, setRatio)}
      </div>
      <DragOverlay dropAnimation={{ duration: 220, easing: 'cubic-bezier(0.22, 1, 0.36, 1)' }}>
        {dragTab ? (
          <div className="obs-tab obs-tab--active obs-tab--drag-overlay">
            <span className="obs-tab__title">{dragTab.title}</span>
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
