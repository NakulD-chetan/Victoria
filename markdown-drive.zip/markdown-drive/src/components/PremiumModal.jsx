import { useState, useEffect } from 'react';
import { dbService } from '../firebase';

const PLANS = [
  {
    id: 'monthly',
    name: 'Pro Monthly',
    price: 99,
    currency: 'INR',
    period: '/month',
    features: ['Ad-free experience', '50GB cloud storage', 'Priority support', 'Custom themes'],
    popular: false,
  },
  {
    id: 'yearly',
    name: 'Pro Yearly',
    price: 799,
    currency: 'INR',
    period: '/year',
    features: ['Everything in Monthly', '100GB cloud storage', 'API access', 'Team sharing', 'Save 33%'],
    popular: true,
  },
  {
    id: 'lifetime',
    name: 'Lifetime',
    price: 1999,
    currency: 'INR',
    period: 'one-time',
    features: ['Everything in Yearly', 'Unlimited storage', 'Lifetime updates', 'White-label option', 'Custom domain'],
    popular: false,
  },
];

export default function PremiumModal({ user, onClose, onUpgrade }) {
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [referralApplied, setReferralApplied] = useState(false);
  const [discount, setDiscount] = useState(0);

  const applyReferral = async () => {
    if (!referralCode.trim()) return;
    try {
      const ref = await dbService.getReferral(referralCode.trim());
      if (ref && ref.referrerId !== user?.id) {
        setReferralApplied(true);
        setDiscount(20);
        setError('');
      } else {
        setError('Invalid referral code');
      }
    } catch {
      setError('Could not verify referral code');
    }
  };

  const handlePayment = async () => {
    const plan = PLANS.find(p => p.id === selectedPlan);
    if (!plan || !user) return;

    setLoading(true);
    setError('');

    const finalPrice = referralApplied ? Math.round(plan.price * (1 - discount / 100)) : plan.price;

    try {
      if (!window.Razorpay) {
        setError('Payment gateway loading... Please try again.');
        setLoading(false);
        return;
      }

      const options = {
        key: 'rzp_test_XXXXXXXXXXXXXXXX',
        amount: finalPrice * 100,
        currency: plan.currency,
        name: 'InkDrop Premium',
        description: `${plan.name} Plan`,
        image: 'https://i.imgur.com/3g7nmJC.png',
        handler: async function (response) {
          try {
            const paymentData = {
              paymentId: response.razorpay_payment_id,
              plan: selectedPlan,
              amount: finalPrice,
              currency: plan.currency,
              status: 'success',
              referralCode: referralApplied ? referralCode : null,
            };
            await dbService.savePayment(user.id, paymentData);

            const premiumData = {
              active: true,
              plan: selectedPlan,
              activatedAt: new Date().toISOString(),
              expiresAt: selectedPlan === 'lifetime' ? null :
                selectedPlan === 'yearly' ?
                  new Date(Date.now() + 365 * 86400000).toISOString() :
                  new Date(Date.now() + 30 * 86400000).toISOString(),
              paymentId: response.razorpay_payment_id,
            };
            await dbService.setPremiumStatus(user.id, premiumData);

            if (referralApplied) {
              await dbService.recordReferralSignup(referralCode, user.id);
            }

            await dbService.trackAnalytics(user.id, {
              type: 'premium_upgrade',
              plan: selectedPlan,
              amount: finalPrice,
            });

            onUpgrade(premiumData);
            onClose();
          } catch (err) {
            setError('Payment recorded but activation failed. Contact support.');
          }
        },
        prefill: {
          name: user.name || '',
          email: user.email || '',
        },
        theme: {
          color: '#6366F1',
        },
        modal: {
          ondismiss: () => setLoading(false),
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.on('payment.failed', (resp) => {
        setError(`Payment failed: ${resp.error.description}`);
        setLoading(false);
      });
      rzp.open();
    } catch (err) {
      setError('Could not initiate payment. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="premium-modal">
        <button className="premium-modal__close" onClick={onClose}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
        </button>

        <div className="premium-modal__header">
          <div className="premium-modal__badge">PRO</div>
          <h2 className="premium-modal__title">Upgrade to InkDrop Pro</h2>
          <p className="premium-modal__subtitle">Remove ads, unlock cloud storage, and get premium features</p>
        </div>

        <div className="premium-modal__plans">
          {PLANS.map(plan => {
            const finalPrice = referralApplied ? Math.round(plan.price * (1 - discount / 100)) : plan.price;
            return (
              <button
                key={plan.id}
                className={`premium-plan ${selectedPlan === plan.id ? 'premium-plan--selected' : ''} ${plan.popular ? 'premium-plan--popular' : ''}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && <span className="premium-plan__tag">Most Popular</span>}
                <span className="premium-plan__name">{plan.name}</span>
                <span className="premium-plan__price">
                  {referralApplied && <span className="premium-plan__original">{plan.currency === 'INR' ? '\u20B9' : '$'}{plan.price}</span>}
                  <span className="premium-plan__amount">{plan.currency === 'INR' ? '\u20B9' : '$'}{finalPrice}</span>
                  <span className="premium-plan__period">{plan.period}</span>
                </span>
                <ul className="premium-plan__features">
                  {plan.features.map((f, i) => (
                    <li key={i}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12" /></svg>
                      {f}
                    </li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>

        <div className="premium-modal__referral">
          <label>Have a referral code?</label>
          <div className="premium-modal__referral-input">
            <input
              type="text"
              placeholder="Enter code"
              value={referralCode}
              onChange={e => setReferralCode(e.target.value)}
              disabled={referralApplied}
            />
            {referralApplied ? (
              <span className="premium-modal__referral-applied">-{discount}% applied</span>
            ) : (
              <button onClick={applyReferral} disabled={!referralCode.trim()}>Apply</button>
            )}
          </div>
        </div>

        {error && <p className="premium-modal__error">{error}</p>}

        <button className="premium-modal__pay" onClick={handlePayment} disabled={loading}>
          {loading ? (
            <><div className="auth__google-spinner" /> Processing...</>
          ) : (
            <>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="1" y="4" width="22" height="16" rx="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>
              Pay & Upgrade
            </>
          )}
        </button>

        <p className="premium-modal__secure">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" /></svg>
          Secured by Razorpay. Cancel anytime.
        </p>
      </div>
    </div>
  );
}
