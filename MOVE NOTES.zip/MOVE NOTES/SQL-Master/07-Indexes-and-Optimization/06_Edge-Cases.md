# Indexes and Optimization — Edge Cases

---

## NULL in indexes

- Most B-tree indexes **include** NULL values — but queries with `IS NULL` may or may not use index (engine-dependent).

---

## Implicit indexes from constraints

- `PRIMARY KEY` → auto-creates clustered index (most engines).
- `UNIQUE` constraint → auto-creates unique index.

---

## Fragmentation

- Heavy INSERT/DELETE → index pages fragment → performance degrades.
- `REINDEX` / `ALTER INDEX REBUILD` periodically.

---

## Statistics stale

- Optimizer uses statistics; after bulk loads, run `ANALYZE` / `UPDATE STATISTICS`.

---

*Next: [[07_Tricks-and-Recognition]]*
