# Vocabulary Building — Naye Words Kaise Seekhein

> *"Vocabulary ek din mein nahi banti — roz 5 words seekho, 1 saal mein 1800+ words hain tumhare paas"*

Grammar backbone hai, lekin vocabulary bina tumhare paas bolne ke liye words hi nahi honge. Yeh chapter mein: daily method, word families, replacements, aur situation-based vocabulary.

---

## 1. The Daily 5-Word Method

> **Roz 5 naye words seekho. Sirf 5. Lekin PROPERLY seekho.**

### Har Word Ke Liye Yeh 4 Cheezein Karo:

| Step | Kya Karo | Example (word: "appreciate") |
|------|---------|------------------------------|
| 1 | **Meaning** samjho (English + Hindi) | To recognize the value of something / qadr karna |
| 2 | **Sentence** banao | I really appreciate your help. |
| 3 | **Pronunciation** suno | Google pe word type karo, speaker icon dabao |
| 4 | **Use karo** din mein | Kisi ko thank you ki jagah "I appreciate it" bolo |

[TIP] Words ko notebook mein mat likho aur bhool jao. **Use karo** — tabhi yaad rahega.

### Weekly Math:
- 5 words/day x 7 days = **35 words/week**
- 35 words x 4 weeks = **140 words/month**
- 140 words x 12 months = **1,680 words/year**

> 1500-2000 words se daily English conversation comfortably ho sakti hai.

---

## 2. Word Families — Ek Word Se 4-5 Words Seekho

Ek word seekhte ho toh uski poori family seekho:

| Base Word | Noun | Adjective | Adverb | Verb |
|-----------|------|-----------|--------|------|
| **happy** | happiness | happy | happily | — |
| **beauty** | beauty | beautiful | beautifully | beautify |
| **success** | success | successful | successfully | succeed |
| **create** | creation / creativity | creative | creatively | create |
| **decide** | decision | decisive | decisively | decide |
| **communicate** | communication | communicative | communicatively | communicate |
| **improve** | improvement | improved | — | improve |
| **confuse** | confusion | confusing / confused | confusingly | confuse |
| **excite** | excitement | exciting / excited | excitingly | excite |
| **danger** | danger | dangerous | dangerously | endanger |

[TIP] "Confusing" vs "Confused" — **-ing** = cheez describe karta hai, **-ed** = feeling describe karta hai.
- The movie was **boring**. (movie ki quality)
- I was **bored**. (meri feeling)

---

## 3. Replace Basic Words — Sound Smarter

Roz ke boring words ko better words se replace karo:

| Basic Word | Better Replacements | Example |
|-----------|--------------------|---------| 
| **good** | excellent, wonderful, fantastic, great, superb | The food was **excellent**. |
| **bad** | terrible, awful, horrible, poor, dreadful | The weather is **terrible**. |
| **happy** | delighted, thrilled, joyful, pleased, ecstatic | I'm **thrilled** about the news. |
| **sad** | upset, devastated, heartbroken, gloomy, miserable | She was **devastated** by the result. |
| **big** | huge, enormous, massive, gigantic, vast | The hall was **enormous**. |
| **small** | tiny, miniature, compact, petite, slight | It's a **tiny** room. |
| **nice** | wonderful, pleasant, lovely, delightful, charming | What a **lovely** day! |
| **very** | extremely, incredibly, remarkably, exceptionally | It's **incredibly** hot today. |
| **important** | crucial, vital, essential, significant, critical | This meeting is **crucial**. |
| **fast** | rapid, swift, quick, speedy, prompt | He gave a **prompt** reply. |
| **said** | mentioned, stated, explained, remarked, declared | She **mentioned** the deadline. |
| **think** | believe, consider, assume, suppose, reckon | I **believe** this is correct. |

[DAILY PRACTICE] Har din 1 basic word ko replace karke bolo. "Good morning" ki jagah "Wonderful morning!"

---

## 4. 50 Most Useful Everyday Words

### Group 1 — Actions (Verbs)

| Word | Hindi Meaning | Example Sentence |
|------|-------------|-----------------|
| manage | sambhaalna | I can manage this task. |
| suggest | sujhav dena | I suggest we take a break. |
| expect | umeed karna | I didn't expect this result. |
| provide | dena / uplabdh karana | Can you provide more details? |
| consider | sochna / vichar karna | Please consider my request. |
| require | zaroorat hona | This job requires experience. |
| achieve | paana / haasil karna | She achieved her goal. |
| develop | vikas karna | We need to develop new skills. |
| maintain | banaaye rakhna | Maintain your focus. |
| avoid | bachna | Avoid making the same mistake. |

### Group 2 — Describing (Adjectives)

| Word | Hindi Meaning | Example Sentence |
|------|-------------|-----------------|
| available | uplabdh | Is this seat available? |
| convenient | suvidhaajanak | What time is convenient for you? |
| appropriate | uchit | That's not an appropriate response. |
| efficient | prabhavi | She is very efficient at work. |
| reliable | bharosemand | He is a reliable person. |
| flexible | laachila | We need a flexible schedule. |
| relevant | sambandhit | Is this relevant to our topic? |
| genuine | asli | She gave a genuine smile. |
| reasonable | uchit / waajib | The price is reasonable. |
| obvious | saaf / zahir | The answer is obvious. |

### Group 3 — Connectors

| Word | Use | Example |
|------|-----|---------|
| however | lekin (formal) | I wanted to go. **However**, it rained. |
| therefore | isliye | He studied hard. **Therefore**, he passed. |
| moreover | iske alaava | The plan is good. **Moreover**, it's cheap. |
| although | halaki | **Although** it rained, we went out. |
| meanwhile | is beech | I'll cook. **Meanwhile**, you set the table. |
| besides | iske alaava | **Besides** English, I speak Hindi. |
| instead | ki jagah | Don't complain. **Instead**, find a solution. |
| otherwise | varna | Hurry up, **otherwise** we'll be late. |
| furthermore | aur yeh bhi | The food is great. **Furthermore**, it's affordable. |
| nevertheless | phir bhi | It was risky. **Nevertheless**, we tried. |

---

## 5. Vocabulary by Situation

### Office / Workplace

| Word/Phrase | Meaning | Use |
|-------------|---------|-----|
| deadline | last date | The deadline is Friday. |
| feedback | raay | Can I get your feedback? |
| collaborate | saath mein kaam karna | Let's collaborate on this project. |
| prioritize | pehle kya karna hai decide karna | We need to prioritize our tasks. |
| escalate | upar report karna | I'll escalate this issue to the manager. |
| follow up | aage puchhna | I'll follow up on this tomorrow. |
| deliverable | jo dena hai | What are the deliverables for this sprint? |

### Emotions / Feelings

| Emotion | Light Version | Strong Version |
|---------|-------------|---------------|
| Happy | pleased, glad, cheerful | thrilled, ecstatic, overjoyed |
| Sad | upset, disappointed, low | devastated, heartbroken, miserable |
| Angry | annoyed, irritated, frustrated | furious, enraged, livid |
| Scared | nervous, anxious, worried | terrified, horrified, petrified |
| Surprised | amazed, astonished, stunned | shocked, speechless, flabbergasted |

### Food & Restaurant

| Word/Phrase | Meaning |
|-------------|---------|
| appetizer | starter |
| beverage | peene ki cheez |
| cuisine | khaane ki style (Indian cuisine) |
| allergic | allergy hai |
| portion | khaane ki quantity |
| spicy / bland | teekha / feeka |

### Travel

| Word/Phrase | Meaning |
|-------------|---------|
| itinerary | travel plan |
| boarding pass | flight ka ticket/pass |
| layover | beech mein rukna |
| commute | office aana-jaana |
| reservation | booking |
| check-in / check-out | hotel mein register / leave |

---

## 6. Vocabulary Yaad Rakhne Ke Tips

| # | Technique | Kaise Kare |
|---|-----------|-----------|
| 1 | **Use it or Lose it** | Naya word seekha toh din mein 3 baar use karo |
| 2 | **Flashcards** | Phone app (Anki, Quizlet) pe cards banao — daily 5 min revise |
| 3 | **Context mein seekho** | "Abandon" akela mat seekho — "He abandoned the plan" seekho |
| 4 | **Group mein seekho** | Related words saath mein: happy, happiness, happily, unhappy |
| 5 | **Sticky notes** | Ghar mein cheezein pe English name ka sticky note lagao |
| 6 | **English diary** | Roz 5 sentences likho naye words use karke |
| 7 | **Spaced repetition** | Day 1 seekho, Day 3 revise, Day 7 revise, Day 15 revise |

---

*Agle chapter mein: Speaking Practice Techniques — actually kaise bolo, shadowing, mirror practice, self-talk*
