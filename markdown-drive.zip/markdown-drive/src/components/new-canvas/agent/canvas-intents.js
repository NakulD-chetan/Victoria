import { createWidgetElement } from '../widgets/widget-registry';
import { CANVAS_TOOLS } from './canvas-tool-registry';
import { getAccessToken } from '../../../lib/supabase';
import { uid } from '../state/types';
import { computeSceneClusterSummary, findBestWidgetPlacement } from './canvas-layout-intelligence';
import { compileTeachingScene } from './teaching-composer';
import { createBoundArrow } from '../engine/binding-engine';
import { createTextElement, HAND_FONT } from '../engine/text-layout';
import { repairSceneOverlaps, validateScene } from '../engine/scene-validator';
import { isCanvasV3Enabled } from '../canvas-v3/feature-flags';
import {
  compileCodeLessonV3,
  compileTeachingDocumentV3,
} from '../canvas-v3/compiler';
import { normalizeTeachingDocumentV3 } from '../canvas-v3/document';

const AGENT_MOTION_MS = 420;

function animateViewport(store, from, to, duration = 460) {
  if (typeof window === 'undefined' || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
    store.getState().setViewport(to);
    return;
  }
  const startedAt = performance.now();
  const tick = (now) => {
    const progress = Math.min(1, (now - startedAt) / duration);
    const eased = 1 - ((1 - progress) ** 3);
    store.getState().setViewport({
      zoom: from.zoom + (to.zoom - from.zoom) * eased,
      panX: from.panX + (to.panX - from.panX) * eased,
      panY: from.panY + (to.panY - from.panY) * eased,
    }, { transient: progress < 1 });
    if (progress < 1) window.requestAnimationFrame(tick);
  };
  window.requestAnimationFrame(tick);
}

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function visibleWorldCenter(scene, stageElement) {
  const viewport = scene?.viewport || { zoom: 1, panX: 0, panY: 0 };
  const zoom = Math.max(0.1, viewport.zoom || 1);
  const width = stageElement?.clientWidth || 1100;
  const height = stageElement?.clientHeight || 720;
  return {
    x: -viewport.panX + width / (2 * zoom),
    y: -viewport.panY + Math.max(320, height - 150) / (2 * zoom),
  };
}

function signatureForText(parts) {
  return String(parts.filter(Boolean).join('|'))
    .trim()
    .toLowerCase()
    .slice(0, 220);
}

function detectInvalidWidgetData(widget) {
  const data = widget?.widgetData || {};
  if (widget.widgetType === 'mermaid-diagram') {
    return !/(graph|flowchart|sequenceDiagram|classDiagram|erDiagram|stateDiagram)/i.test(data.code || '');
  }
  if (widget.widgetType === 'json') {
    return !safeJsonParse(data.source);
  }
  if (widget.widgetType === 'csv') {
    return !String(data.source || '').includes('\n');
  }
  return false;
}

function inferWidgetRole(widget) {
  return widget?.widgetData?.agentMeta?.semanticRole
    || widget?.widgetData?.role
    || (widget?.widgetType === 'note' ? 'explanation'
      : widget?.widgetType === 'code' ? 'practice-code'
      : widget?.widgetType === 'mermaid-diagram' ? 'diagram'
      : widget?.widgetType === 'sql-pad' ? 'sql-workspace'
      : widget?.widgetType === 'json' ? 'json-data'
      : widget?.widgetType === 'csv' ? 'csv-data'
      : widget?.widgetType === 'progress' ? 'roadmap'
      : widget?.widgetType || 'general');
}

function inferWidgetSignature(widget) {
  const data = widget?.widgetData || {};
  if (widget.widgetType === 'note') {
    return signatureForText([data.title, data.text]);
  }
  if (widget.widgetType === 'code' || widget.widgetType === 'sql-pad') {
    return signatureForText([data.title, data.language, data.code]);
  }
  if (widget.widgetType === 'mermaid-diagram') {
    return signatureForText([data.title, data.code]);
  }
  if (widget.widgetType === 'json' || widget.widgetType === 'csv') {
    return signatureForText([data.title, data.source]);
  }
  if (Array.isArray(data.values)) {
    return signatureForText([data.title, ...data.values]);
  }
  if (Array.isArray(data.steps)) {
    return signatureForText([data.title, ...data.steps]);
  }
  return signatureForText([data.title, widget.widgetType]);
}

export function summarizeScene(scene, sceneId = null, state = null) {
  if (isCanvasV3Enabled() && scene?.v3Document) {
    const document = normalizeTeachingDocumentV3(scene.v3Document);
    const selectedIds = Array.isArray(scene.v3Selection) ? scene.v3Selection : [];
    const semanticByElement = new Map();
    document.semanticGraph.nodes.forEach((node) => {
      (node.elementIds || []).forEach((elementId) => semanticByElement.set(elementId, node));
    });
    const elements = document.elements
      .filter((element) => !element.isDeleted)
      .map((element) => {
        const semantic = semanticByElement.get(element.id);
        return {
          id: element.id,
          type: element.type,
          x: element.x,
          y: element.y,
          w: element.width,
          h: element.height,
          title: element.type === 'text' ? element.text : '',
          role: semantic?.role || element.customData?.semanticRole || null,
          topic: semantic?.topic || element.customData?.topic || null,
          cluster: element.customData?.lessonFrameId || null,
          startBinding: element.startBinding?.elementId || null,
          endBinding: element.endBinding?.elementId || null,
          frameId: element.frameId || null,
        };
      });
    const widgets = document.portals.map((portal) => ({
      id: portal.id,
      type: portal.type,
      kind: portal.type,
      title: portal.title || portal.type,
      role: portal.semanticId || `${portal.type}-editor`,
      content_signature: signatureForText([portal.title, portal.language, portal.content]),
      can_reuse: true,
      can_expand: true,
      has_invalid_data: false,
      last_agent_touch: null,
      importance_score: 0.9,
      x: portal.x,
      y: portal.y,
      w: portal.width,
      h: portal.height,
      lesson_page_id: portal.frameId,
    }));
    const currentFrame = document.lessonDeck.frames.find(
      (frame) => frame.id === document.lessonDeck.currentFrameId,
    ) || document.lessonDeck.frames.at(-1) || null;
    return {
      documentVersion: 3,
      sceneVersion: 'v3',
      sceneId,
      widgetCount: widgets.length,
      widgets,
      clusters: document.lessonDeck.frames.map((frame) => ({
        key: frame.id,
        count: frame.semanticNodeIds?.length || 0,
        bounds: frame.bounds,
      })),
      elements,
      viewport: {
        zoom: document.appState.zoom?.value || 1,
        panX: document.appState.scrollX || 0,
        panY: document.appState.scrollY || 0,
      },
      activeSelection: selectedIds,
      selectionContext: elements.filter((element) => selectedIds.includes(element.id)),
      pinnedTarget: scene.pinnedTarget || null,
      lessonDeck: {
        pages: document.lessonDeck.frames.map((frame) => ({
          id: frame.id,
          title: frame.title,
          topic: frame.topic,
          focus: 'lesson',
          order: frame.order,
          bounds: {
            x: frame.bounds.x,
            y: frame.bounds.y,
            w: frame.bounds.width,
            h: frame.bounds.height,
          },
        })),
        currentPageId: currentFrame?.id || null,
      },
      currentFrameId: currentFrame?.id || null,
      semanticScene: document.semanticGraph,
      playback: document.playback,
      recentAgentActions: (scene.agentHistory || []).slice(-8),
      humanReplaySummary: document.lessonDeck.frames.length
        ? document.lessonDeck.frames.map((frame) => `Slide ${frame.order + 1}: ${frame.title}`).join(' | ')
        : 'Blank V3 teaching canvas.',
    };
  }

  const widgets = (scene?.elements || [])
    .filter((element) => element.type === 'widget' && !element.isDeleted)
    .map((widget) => ({
      id: widget.id,
      type: widget.widgetType,
      kind: widget.widgetType,
      title: widget.widgetData?.title || widget.widgetData?.fileName || widget.widgetType,
      role: inferWidgetRole(widget),
      content_signature: inferWidgetSignature(widget),
      can_reuse: widget.widgetData?.agentMeta?.canReuse ?? true,
      can_expand: widget.widgetData?.agentMeta?.canExpand ?? true,
      has_invalid_data: detectInvalidWidgetData(widget),
      last_agent_touch: widget.widgetData?.agentMeta?.lastAgentTouch || null,
      importance_score: widget.widgetData?.agentMeta?.importanceScore ?? 0.5,
      x: widget.x,
      y: widget.y,
      w: widget.w,
      h: widget.h,
      lesson_page_id: widget.customData?.lessonPageId || null,
    }));

  const selectedIds = [...(state?.selection || [])];
  const viewport = scene?.viewport || { zoom: 1, panX: 0, panY: 0 };
  const elements = (scene?.elements || [])
    .filter((element) => !element.isDeleted)
    .map((element) => ({
      id: element.id,
      type: element.type === 'widget' ? `widget:${element.widgetType}` : element.type,
      x: element.x,
      y: element.y,
      w: element.w,
      h: element.h,
      z: element.z,
      title: element.widgetData?.title || element.text || '',
      role: element.customData?.semanticRole || element.widgetData?.agentMeta?.semanticRole || null,
      topic: element.customData?.topic || null,
      cluster: element.customData?.clusterKey || element.widgetData?.agentMeta?.clusterKey || null,
      importance: element.customData?.importance ?? element.widgetData?.agentMeta?.importanceScore ?? null,
      startBinding: element.startBinding?.elementId || null,
      endBinding: element.endBinding?.elementId || null,
      containerId: element.containerId || null,
      points: Array.isArray(element.points) ? element.points.slice(0, 12) : null,
    }));

  return {
    sceneId,
    widgetCount: widgets.length,
    widgets,
    clusters: computeSceneClusterSummary(scene, scene?.elements || []),
    elements,
    viewport,
    activeSelection: selectedIds,
    selectionContext: widgets.filter((widget) => selectedIds.includes(widget.id)),
    pinnedTarget: scene?.pinnedTarget || null,
    lessonDeck: scene?.lessonDeck || { pages: [], currentPageId: null },
    recentAgentActions: (scene?.agentHistory || []).slice(-8),
    humanReplaySummary: widgets.length
      ? widgets.slice(0, 10).map((widget) => `${widget.role}: ${widget.title}`).join(' | ')
      : 'Blank or mostly blank canvas.',
  };
}

function applySceneOpsV3(sceneOps, { store, runId }) {
  const state = store.getState();
  const scene = state.scenes[state.activeId];
  if (!scene) return { created: 0, reused: 0, touchedWidgetIds: [] };
  let document = normalizeTeachingDocumentV3(scene.v3Document);
  let lastResult = null;

  for (const op of sceneOps) {
    if (op.kind === 'compose_teaching_scene') {
      lastResult = compileTeachingDocumentV3({
        document,
        request: op,
        runId,
      });
      document = lastResult.document;
      continue;
    }

    if (op.kind === 'upsert_widget' && op.widgetType === 'code') {
      const pinnedPortal = scene.pinnedTarget?.elementId
        ? document.portals.find((portal) => portal.id === scene.pinnedTarget.elementId)
        : null;
      if (pinnedPortal) {
        document = {
          ...document,
          portals: document.portals.map((portal) => (
            portal.id === pinnedPortal.id
              ? {
                  ...portal,
                  title: op.title || portal.title,
                  language: op.payload?.language || portal.language,
                  content: op.payload?.code || portal.content,
                  typingState: op.payload?.liveTyping ? 'queued' : 'editing',
                }
              : portal
          )),
          updatedAt: Date.now(),
        };
        continue;
      }
      lastResult = compileCodeLessonV3({
        document,
        operation: {
          title: op.title,
          language: op.payload?.language,
          code: op.payload?.code,
          liveTyping: Boolean(op.payload?.liveTyping),
          pageMode: op.lessonPageId ? 'current' : 'next',
        },
        runId,
      });
      document = lastResult.document;
      continue;
    }

    if (op.kind === 'upsert_widget' && op.widgetType === 'note') {
      lastResult = compileTeachingDocumentV3({
        document,
        request: {
          topic: op.semanticRole || 'concept',
          structureType: 'concept',
          title: op.title,
          definition: op.payload?.text || op.title,
          pageMode: 'next',
        },
        runId,
      });
      document = lastResult.document;
    }
  }

  store.getState().setV3Document(document);
  store.getState().setV3Selection([]);
  return {
    created: lastResult?.document?.elements?.length || 0,
    reused: 0,
    touchedWidgetIds: lastResult?.frame?.semanticNodeIds || [],
    validation: lastResult?.validation || { valid: true, errors: [], warnings: [] },
  };
}

function markAgentSpawn(widget, delayMs, runId, eventId) {
  return {
    ...widget,
    widgetData: {
      ...widget.widgetData,
      agentSpawnId: `${Date.now()}-${widget.id}`,
      spawnDelayMs: delayMs,
      agentMoveId: null,
      moveDelayMs: 0,
      agentMeta: {
        ...(widget.widgetData?.agentMeta || {}),
        lastAgentTouch: eventId,
        sourceRunId: runId,
      },
    },
  };
}

function markAgentMove(widget, delayMs, runId, eventId) {
  return {
    ...widget,
    widgetData: {
      ...widget.widgetData,
      agentMoveId: `${Date.now()}-${widget.id}`,
      moveDelayMs: delayMs,
      agentSpawnId: null,
      spawnDelayMs: 0,
      agentMeta: {
        ...(widget.widgetData?.agentMeta || {}),
        lastAgentTouch: eventId,
        sourceRunId: runId,
      },
    },
  };
}

function clearAgentMotionFlags(store, widgetIds) {
  if (!widgetIds.length) return;
  window.setTimeout(() => {
    store.getState().commitElements((elements) => elements.map((element) => {
      if (!widgetIds.includes(element.id) || element.type !== 'widget') return element;
      return {
        ...element,
        widgetData: {
          ...element.widgetData,
          agentSpawnId: null,
          spawnDelayMs: 0,
          agentMoveId: null,
          moveDelayMs: 0,
        },
      };
    }), { transient: true });
  }, AGENT_MOTION_MS + 60);
}

function buildAgentMetaFromOp(op, runId, eventId) {
  return {
    semanticRole: op.semanticRole || 'general',
    contentSignature: op.contentSignature || signatureForText([op.title, op.semanticRole]),
    canReuse: op.canReuse ?? true,
    canExpand: op.canExpand ?? true,
    hasInvalidData: false,
    lastAgentTouch: eventId,
    importanceScore: op.importanceScore ?? 0.5,
    sourceRunId: runId,
    clusterKey: op.placementIntent?.clusterKey || null,
    preferredZone: op.placementIntent?.preferredZone || null,
  };
}

function matchReusableWidget(element, op) {
  if (element.type !== 'widget' || element.isDeleted) return false;
  if (op.targetElementId) return element.id === op.targetElementId;
  if (element.widgetType !== op.widgetType) return false;

  const elementTitle = (element.widgetData?.title || '').trim().toLowerCase();
  const targetTitle = (op.title || '').trim().toLowerCase();
  const elementMeta = element.widgetData?.agentMeta || {};

  if (elementMeta.semanticRole && op.semanticRole && elementMeta.semanticRole === op.semanticRole) return true;
  if (targetTitle && elementTitle && targetTitle === elementTitle) return true;
  if (elementMeta.contentSignature && op.contentSignature && elementMeta.contentSignature === op.contentSignature) return true;

  return ['json', 'csv', 'sql-pad', 'progress'].includes(op.widgetType);
}

function applyWidgetPayload(widget, op, runId, eventId) {
  const payload = { ...(op.payload || {}) };
  if (op.widgetType === 'code' && payload.liveTyping) {
    payload.liveTyping = {
      fullText: payload.code || '',
      startedAt: Date.now(),
      cps: 38,
    };
    payload.typingState = 'typing';
    payload.code = '';
  }
  const next = {
    ...widget,
    widgetData: {
      ...(widget.widgetData || {}),
      ...payload,
      title: op.title || op.payload?.title || widget.widgetData?.title || widget.widgetType,
      agentMeta: buildAgentMetaFromOp(op, runId, eventId),
    },
  };
  return next;
}

function findElementIndexBySemantic(elements, ref) {
  const normalizedRef = String(ref || '').trim().toLowerCase();
  if (!normalizedRef) return -1;
  return elements.findIndex((element) => {
    if (element.type !== 'widget' || element.isDeleted) return false;
    const title = (element.widgetData?.title || '').trim().toLowerCase();
    const role = (element.widgetData?.agentMeta?.semanticRole || '').trim().toLowerCase();
    return title === normalizedRef || role === normalizedRef;
  });
}

function createArrowBetween(fromWidget, toWidget, label, runId, eventId) {
  const arrowId = uid('arrow');
  const arrow = createBoundArrow({
    id: arrowId,
    from: fromWidget,
    to: toWidget,
    elements: [fromWidget, toWidget],
    style: {
      stroke: '#7c83ff',
      fill: 'transparent',
      strokeWidth: 2,
      opacity: 0.9,
      dash: 'solid',
    },
    customData: {
      owner: 'agent',
      semanticRole: 'connector',
      sourceRunId: runId,
      lastAgentTouch: eventId,
      label: label || '',
    },
  });

  const labelElement = label
    ? createTextElement({
        id: uid('text'),
        text: label,
        x: arrow.x,
        y: arrow.y,
        maxWidth: 180,
        fontSize: 15,
        fontFamily: HAND_FONT,
        color: '#cbd5f5',
        semanticRole: 'connector-label',
        containerId: arrowId,
        z: arrow.z + 1,
        customData: {
          owner: 'agent',
          semanticRole: 'connector-label',
          sourceRunId: runId,
        },
      })
    : null;

  if (labelElement) arrow.labelId = labelElement.id;

  return { arrow, labelElement };
}

function applySceneOps(sceneOps, { store, stageElement, runId, eventId }) {
  if (!Array.isArray(sceneOps) || !sceneOps.length) return { created: 0, reused: 0, touchedWidgetIds: [] };

  if (isCanvasV3Enabled()) {
    return applySceneOpsV3(sceneOps, { store, runId, eventId });
  }

  const state = store.getState();
  const scene = state.scenes[state.activeId];
  if (!scene) return { created: 0, reused: 0, touchedWidgetIds: [] };

  const composition = sceneOps.find((op) => op.kind === 'compose_teaching_scene');
  if (composition) {
    const compiled = compileTeachingScene({
      scene,
      stageElement,
      request: composition,
      replaceExistingTopic: composition.replaceExistingTopic !== false,
    });
    if (!compiled.validation.valid) {
      throw new Error(`Teaching scene rejected: ${compiled.validation.errors[0]?.message || 'layout validation failed'}`);
    }
    store.getState().commitElements(compiled.elements);
    store.getState().patchActiveSceneMeta?.({
      lessonDeck: compiled.lessonDeck,
    });
    if (compiled.currentPage?.id) {
      store.getState().setCurrentLessonPage?.(compiled.currentPage.id);
    }
    animateViewport(store, scene.viewport || { zoom: 1, panX: 0, panY: 0 }, compiled.viewport);
    store.getState().setTool('select');
    store.getState().clearSelection();
    clearAgentMotionFlags(
      store,
      compiled.elements
        .filter((element) => compiled.createdIds.includes(element.id) && element.type === 'widget')
        .map((element) => element.id),
    );
    return {
      created: compiled.createdIds.length,
      reused: 0,
      touchedWidgetIds: compiled.createdIds,
      validation: compiled.validation,
    };
  }

  const touchedWidgetIds = [];
  let created = 0;
  let reused = 0;
  let transactionValidation = { valid: true, errors: [] };

  store.getState().commitElements((elements) => {
    const nextElements = elements.slice();

    sceneOps.forEach((op, index) => {
      if (op.kind === 'upsert_widget') {
        const delay = index * 120;
        const existingIndex = nextElements.findIndex((element) => matchReusableWidget(element, op));
        const existingWidget = existingIndex >= 0 ? nextElements[existingIndex] : null;
        const placement = findBestWidgetPlacement({
          scene,
          elements: nextElements,
          stageElement,
          op,
          index,
          existingWidget,
        });

        if (existingIndex >= 0) {
          const existing = nextElements[existingIndex];
          const moved = markAgentMove({
            ...existing,
            x: placement.x,
            y: placement.y,
            w: placement.w || existing.w,
            h: placement.h || existing.h,
          }, delay, runId, eventId);
          nextElements[existingIndex] = applyWidgetPayload(moved, op, runId, eventId);
          touchedWidgetIds.push(nextElements[existingIndex].id);
          reused += 1;
          return;
        }

        const createdWidget = createWidgetElement(op.widgetType, placement.x, placement.y, placement.w, placement.h);
        const nextWidget = applyWidgetPayload(markAgentSpawn(createdWidget, delay, runId, eventId), op, runId, eventId);
        nextElements.push(nextWidget);
        touchedWidgetIds.push(nextWidget.id);
        created += 1;
        return;
      }

      if (op.kind === 'create_text_callout') {
        const placement = findBestWidgetPlacement({
          scene,
          elements: nextElements,
          stageElement,
          op: {
            widgetType: 'note',
            semanticRole: op.semanticRole || 'callout',
            title: op.text,
            placementIntent: op.placementIntent,
          },
          index,
        });
        nextElements.push({
          id: uid('text'),
          type: 'text',
          text: op.text,
          fontSize: 18,
          fontFamily: HAND_FONT,
          x: placement.x,
          y: placement.y + 120,
          w: 0,
          h: 0,
          z: nextElements.length + 1,
          isDeleted: false,
          style: {
            stroke: '#dbe4ff',
            fill: 'transparent',
            strokeWidth: 1,
            opacity: 1,
            dash: 'solid',
          },
          createdAt: Date.now(),
        });
        return;
      }

      if (op.kind === 'create_connector') {
        const fromIndex = findElementIndexBySemantic(nextElements, op.from);
        const toIndex = findElementIndexBySemantic(nextElements, op.to);
        if (fromIndex === -1 || toIndex === -1) return;
        const { arrow, labelElement } = createArrowBetween(nextElements[fromIndex], nextElements[toIndex], op.label, runId, eventId);
        nextElements.push(arrow);
        if (labelElement) nextElements.push(labelElement);
      }
    });

    const repaired = repairSceneOverlaps(nextElements, { iterations: 90, gap: 28 });
    transactionValidation = validateScene(repaired);
    return transactionValidation.valid ? repaired : elements;
  });

  clearAgentMotionFlags(store, touchedWidgetIds);
  store.getState().setTool('select');
  store.getState().clearSelection();

  return { created, reused, touchedWidgetIds, validation: transactionValidation };
}

async function authorizedFetch(url, options = {}) {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Sign in to use LocalAgent AI on the canvas.');
  }

  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${token}`);

  return fetch(url, {
    ...options,
    headers,
  });
}

function parseSseFrames(buffer) {
  const frames = [];
  let start = 0;

  while (true) {
    const end = buffer.indexOf('\n\n', start);
    if (end === -1) break;
    frames.push(buffer.slice(start, end));
    start = end + 2;
  }

  return {
    frames,
    rest: buffer.slice(start),
  };
}

async function consumeRunStream(runId, { since = 0, onEvent }) {
  const response = await authorizedFetch(`/api/canvas-agent/runs/${runId}/events?since=${since}`, {
    method: 'GET',
  });

  if (!response.ok || !response.body) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to open agent event stream');
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const parsed = parseSseFrames(buffer);
    buffer = parsed.rest;

    for (const frame of parsed.frames) {
      if (!frame.trim() || frame.startsWith(':')) continue;
      const lines = frame.split('\n');
      const eventName = lines.find((line) => line.startsWith('event:'))?.slice(6).trim() || 'message';
      const dataLines = lines.filter((line) => line.startsWith('data:')).map((line) => line.slice(5).trim());
      const payload = safeJsonParse(dataLines.join('\n'), null);
      if (payload && typeof onEvent === 'function') {
        await onEvent({ ...payload, eventName });
      }
    }
  }
}

export async function fetchCanvasAgentRun(runId) {
  const response = await authorizedFetch(`/api/canvas-agent/runs/${runId}`, { method: 'GET' });
  const json = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(json.error || 'Failed to load canvas run');
  return json;
}

export async function cancelCanvasAgentRun(runId) {
  const response = await authorizedFetch(`/api/canvas-agent/runs/${runId}/cancel`, { method: 'POST' });
  const json = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(json.error || 'Failed to cancel canvas run');
  return json;
}

export async function resumeCanvasAgentRun(runId, { store, stageElement, since = 0, onEvent }) {
  const aggregate = {
    ok: true,
    text: '',
    toolCalls: [],
    plan: null,
    meta: null,
    stats: null,
    finalDiff: null,
    runId,
    eventCount: since,
  };

  await consumeRunStream(runId, {
    since,
    onEvent: async (event) => {
      aggregate.eventCount += 1;

      if (event.type === 'plan_started') {
        aggregate.plan = event.plan;
      } else if (event.type === 'agent_text_delta') {
        aggregate.text = event.content || aggregate.text;
      } else if (event.type === 'tool_result' && event.sceneOps?.length) {
        applySceneOps(event.sceneOps, {
          store,
          stageElement,
          runId,
          eventId: event.id,
        });
      } else if (event.type === 'done') {
        aggregate.ok = true;
        aggregate.text = event.text || aggregate.text;
        aggregate.toolCalls = event.toolCalls || aggregate.toolCalls;
        aggregate.plan = event.plan || aggregate.plan;
        aggregate.meta = event.meta || aggregate.meta;
        aggregate.stats = event.stats || aggregate.stats;
        aggregate.finalDiff = event.finalDiff || aggregate.finalDiff;
        store.getState().appendAgentHistory?.({
          runId,
          completedAt: event.createdAt || Date.now(),
          goal: aggregate.plan?.goal || '',
          intent: aggregate.plan?.intent || 'teach',
          summary: event.text || aggregate.text || 'Canvas updated.',
          stats: aggregate.stats,
          finalDiff: aggregate.finalDiff,
        });
      } else if (event.type === 'error' || event.type === 'cancelled') {
        aggregate.ok = false;
        aggregate.text = event.message || aggregate.text;
      }

      if (typeof onEvent === 'function') {
        await onEvent(event, aggregate);
      }
    },
  });

  return aggregate;
}

export async function runCanvasAgentTurn(messages, { store, stageElement, tools = CANVAS_TOOLS, onEvent }) {
  const state = store.getState();
  const scene = state.scenes[state.activeId];
  if (!scene) return { ok: false, text: 'Open a canvas before using LocalAgent.' };

  const createResponse = await authorizedFetch('/api/canvas-agent/runs', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      messages,
      tools,
      sceneContext: summarizeScene(scene, state.activeId, state),
    }),
  });

  const run = await createResponse.json().catch(() => ({}));
  if (!createResponse.ok) {
    throw new Error(run.error || 'Failed to create canvas agent run');
  }

  return resumeCanvasAgentRun(run.id, {
    store,
    stageElement,
    since: 0,
    onEvent,
  });
}
