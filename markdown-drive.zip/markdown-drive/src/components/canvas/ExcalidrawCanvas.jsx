import { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle, memo, useMemo } from 'react';
import { createPortal } from 'react-dom';
import { Excalidraw, MainMenu, CaptureUpdateAction, zoomToFitBounds, getCommonBounds } from '@excalidraw/excalidraw';
import '@excalidraw/excalidraw/index.css';
import { DS_SHAPES, uid as dsUid, nextSeed, canvasStrokePalette } from './dsLibrary';
import { WIDGET_SHAPES, WIDGET_DIMS } from './widgetLibrary';
import CompilerWidgetOverlay from './CompilerWidgetOverlay';
import NoteWidgetOverlay from './NoteWidgetOverlay';
import ArrayWidgetOverlay from './ArrayWidgetOverlay';
import { computeAllSnaps } from '../../lib/canvas/excalidraw-guides';
import SnapGuidesOverlay from './SnapGuidesOverlay';
import { createSafeScene } from './safe-scene';
import RenderDebugHUD from './RenderDebugHUD';
import {
  loadWidgetsFromStorage,
  saveWidgetRegistry,
  saveWidgetData,
  removeWidgetStorage,
} from './widget-storage';

function unionBounds(a, b) {
  if (!a) return b;
  if (!b) return a;
  return [
    Math.min(a[0], b[0]),
    Math.min(a[1], b[1]),
    Math.max(a[2], b[2]),
    Math.max(a[3], b[3]),
  ];
}

function boundsFromWidgets(widgetGroups) {
  if (!widgetGroups || widgetGroups.size === 0) return null;
  let b = null;
  for (const [, w] of widgetGroups) {
    if (w == null || typeof w.worldX !== 'number' || typeof w.worldY !== 'number') continue;
    const ww = w.w ?? 0;
    const wh = w.h ?? 0;
    const wb = [w.worldX, w.worldY, w.worldX + ww, w.worldY + wh];
    b = unionBounds(b, wb);
  }
  return b;
}

/** Ensure zoomToFitBounds never divides by ~0 */
function normalizeBoundsForFit(bounds) {
  if (!bounds) return null;
  const [x1, y1, x2, y2] = bounds;
  const minSpan = 8;
  let nx1 = x1;
  let ny1 = y1;
  let nx2 = x2;
  let ny2 = y2;
  if (nx2 - nx1 < minSpan) {
    const c = (nx1 + nx2) / 2;
    nx1 = c - 40;
    nx2 = c + 40;
  }
  if (ny2 - ny1 < minSpan) {
    const c = (ny1 + ny2) / 2;
    ny1 = c - 40;
    ny2 = c + 40;
  }
  return [nx1, ny1, nx2, ny2];
}

function fitSceneAndWidgets(api, widgetGroups) {
  if (!api) return false;
  const els = api.getSceneElements().filter((e) => !e.isDeleted);
  let elementBounds = null;
  if (els.length > 0) {
    elementBounds = getCommonBounds(els);
  }
  const widgetBounds = boundsFromWidgets(widgetGroups);
  const merged = unionBounds(elementBounds, widgetBounds);
  const bounds = normalizeBoundsForFit(merged);
  if (!bounds) return false;
  const appState = api.getAppState();
  const canvasOffsets = typeof api.getEditorUIOffsets === 'function' ? api.getEditorUIOffsets() : undefined;
  const { appState: next, captureUpdate } = zoomToFitBounds({
    bounds,
    appState,
    canvasOffsets,
    fitToViewport: true,
    viewportZoomFactor: 0.92,
  });
  api.updateScene({
    appState: {
      scrollX: next.scrollX,
      scrollY: next.scrollY,
      zoom: next.zoom,
    },
    captureUpdate,
  });
  return true;
}

const SAVE_DEBOUNCE = 800;

let _wc = 0;
function widgetUid() {
  return 'w' + Date.now().toString(36) + (++_wc).toString(36);
}

function isWidgetProxyElement(el, widgetType) {
  if (!el?.customData?.isWidgetProxy) return false;
  return widgetType ? el.customData.widgetType === widgetType : true;
}

function getWidgetProxyStyle(el) {
  return {
    strokeColor: el.strokeColor || '#64748b',
    backgroundColor: el.backgroundColor || 'transparent',
    strokeWidth: el.strokeWidth || 2,
    strokeStyle: el.strokeStyle || 'solid',
    opacity: el.opacity ?? 100,
    roundness: el.roundness || { type: 3, value: 8 },
  };
}

function getProxyRenderPatch(widgetType) {
  if (widgetType === 'array') {
    return {
      strokeColor: 'transparent',
      backgroundColor: 'transparent',
      fillStyle: 'solid',
      opacity: 100,
    };
  }
  return null;
}

/** Excalidraw may omit `locked` or use different strings than 'transparent' — avoid sync/sanitize loops. */
function isEffectivelyTransparentColor(c) {
  if (c == null || c === '' || c === 'transparent' || c === 'none') return true;
  if (typeof c !== 'string') return false;
  const s = c.replace(/\s/g, '').toLowerCase();
  if (s === 'rgba(0,0,0,0)' || s === 'rgba(0,0,0,0.0)') return true;
  return /^#[0-9a-f]{6}00$/i.test(s) || /^#[0-9a-f]{3}0$/i.test(s);
}

function proxyMatchesArrayPatch(el, patch) {
  const oc = el.opacity ?? 100;
  return (
    isEffectivelyTransparentColor(el.strokeColor)
    && isEffectivelyTransparentColor(el.backgroundColor)
    && oc === (patch.opacity ?? 100)
  );
}

function neutralProxyStroke(isDark) {
  return isDark ? '#cbd5e1' : '#334155';
}

function createWidgetProxyElement(widgetId, info, isDark) {
  const renderPatch = getProxyRenderPatch(info.type) || {};
  const baseStroke = neutralProxyStroke(isDark);
  return {
    id: dsUid(),
    type: 'rectangle',
    x: info.worldX,
    y: info.worldY,
    width: info.w,
    height: info.h,
    angle: 0,
    strokeColor: renderPatch.strokeColor ?? info.data?.proxyStyle?.strokeColor ?? baseStroke,
    backgroundColor: renderPatch.backgroundColor ?? info.data?.proxyStyle?.backgroundColor ?? 'transparent',
    fillStyle: 'solid',
    strokeWidth: info.data?.proxyStyle?.strokeWidth || 2,
    strokeStyle: info.data?.proxyStyle?.strokeStyle || 'solid',
    roughness: 1,
    opacity: renderPatch.opacity ?? info.data?.proxyStyle?.opacity ?? 100,
    groupIds: [],
    frameId: null,
    index: null,
    roundness: info.data?.proxyStyle?.roundness || { type: 3, value: 8 },
    seed: nextSeed(),
    version: 1,
    versionNonce: nextSeed(),
    isDeleted: false,
    boundElements: null,
    updated: Date.now(),
    link: null,
    /* Excluded from hit-testing so shape/pen tools interact with the canvas, not this frame */
    locked: true,
    customData: {
      isWidgetProxy: true,
      widgetType: info.type,
      widgetId,
    },
  };
}

function supportsWidgetProxy(type) {
  return type === 'compiler' || type === 'note' || type === 'array';
}

/** Top-left of the interactive canvas relative to wrapRef (for overlay left/top). */
function measureCanvasOffsetInWrap(wrapEl) {
  if (!wrapEl) return { x: 0, y: 0 };
  const canvas = wrapEl.querySelector('canvas.excalidraw__canvas');
  if (!canvas) return { x: 0, y: 0 };
  const wr = wrapEl.getBoundingClientRect();
  const cr = canvas.getBoundingClientRect();
  return { x: cr.left - wr.left, y: cr.top - wr.top };
}

/** Client-space rect of the interactive canvas (for drop → scene mapping). */
function getInteractiveCanvasClientRect(wrapEl) {
  if (!wrapEl) return null;
  const canvas = wrapEl.querySelector('canvas.excalidraw__canvas');
  return canvas ? canvas.getBoundingClientRect() : null;
}

/**
 * Merge missing widget proxy rectangles into the Excalidraw scene.
 * Shared by the widgetGroups useEffect and handleInsertWidget so drops apply immediately
 * instead of racing pointerDown or effect ordering.
 */
function syncWidgetProxiesToScene(api, widgetGroups, isDark, captureUpdate = CaptureUpdateAction.NEVER) {
  const elements = api.getSceneElements();
  let nextElements = elements.map((el) => {
    if (el.isDeleted || !isWidgetProxyElement(el)) return el;
    /* Only `locked === false` needs fixing; true or undefined must not re-clone every frame
     * (Excalidraw often omits `locked` on read → would otherwise force updateScene forever). */
    if (el.locked !== false) return el;
    return { ...el, locked: true };
  });
  let changed = nextElements.some((el, i) => el !== elements[i]);
  for (const [id, info] of widgetGroups) {
    if (!supportsWidgetProxy(info.type)) continue;
    const existingProxy = nextElements.find(
      (el) => !el.isDeleted && isWidgetProxyElement(el) && el.customData.widgetId === id,
    );
    if (existingProxy) continue;
    nextElements = [...nextElements, createWidgetProxyElement(id, info, isDark)];
    changed = true;
  }
  if (!changed) return;
  api.updateScene({
    elements: nextElements,
    captureUpdate,
  });
}

/* Do NOT add capture-phase window/document listeners that call stopImmediatePropagation()
 * when the target is inside .monaco-editor: that runs before the keydown reaches the
 * editor’s textarea and cancels the entire dispatch, so arrows / Ctrl+A / typing break.
 * Widget overlays use bubble-phase stopPropagation (see CompilerWidgetOverlay stopBubble)
 * so keys reach Monaco first, then don’t bubble to Excalidraw.
 */

/* ── DS toolbar ────────────────────────────────────────────────── */

const DS_ICONS = {
  'ds-array': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="7" width="6" height="10" rx="1"/><rect x="9" y="7" width="6" height="10" rx="1"/><rect x="16" y="7" width="6" height="10" rx="1"/>
    </svg>
  ),
  'ds-linked-list': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="4" cy="12" r="3"/><circle cx="14" cy="12" r="3"/><line x1="7" y1="12" x2="11" y2="12"/><path d="M17 12h4m-2-2 2 2-2 2"/>
    </svg>
  ),
  'ds-stack': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="5" y="2" width="14" height="6" rx="1"/><rect x="5" y="9" width="14" height="6" rx="1"/><rect x="5" y="16" width="14" height="6" rx="1"/>
    </svg>
  ),
  'ds-queue': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="1" y="8" width="6" height="8" rx="1"/><rect x="9" y="8" width="6" height="8" rx="1"/><rect x="17" y="8" width="6" height="8" rx="1"/>
      <path d="M1 20h22M1 4h22" strokeDasharray="3 3"/>
    </svg>
  ),
  'ds-binary-tree': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <circle cx="12" cy="4" r="2.5"/><circle cx="6" cy="13" r="2.5"/><circle cx="18" cy="13" r="2.5"/>
      <line x1="10.5" y1="6" x2="7.5" y2="11"/><line x1="13.5" y1="6" x2="16.5" y2="11"/>
      <circle cx="3" cy="21" r="1.5"/><circle cx="9" cy="21" r="1.5"/>
      <line x1="5" y1="15" x2="3.5" y2="19.5"/><line x1="7" y1="15" x2="8.5" y2="19.5"/>
    </svg>
  ),
  'ds-hash-table': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="3" width="8" height="5" rx="1"/><rect x="2" y="10" width="8" height="5" rx="1"/><rect x="2" y="17" width="8" height="5" rx="1"/>
      <rect x="14" y="4" width="6" height="3" rx="1"/><line x1="10" y1="5.5" x2="14" y2="5.5"/>
      <rect x="14" y="11" width="6" height="3" rx="1"/><line x1="10" y1="12.5" x2="14" y2="12.5"/>
    </svg>
  ),
};

function DSToolbarButtons({ onInsert }) {
  return (
    <>
      <div className="cv-ds-divider" />
      {DS_SHAPES.map((ds) => (
        <button
          key={ds.id}
          className="cv-ds-tool__btn"
          onClick={() => onInsert(ds)}
          title={ds.name}
        >
          {DS_ICONS[ds.id]}
        </button>
      ))}
    </>
  );
}

/* ── Widget toolbar (drag-and-drop) ────────────────────────────── */

const WIDGET_ICONS = {
  'widget-compiler': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="3" width="20" height="18" rx="2"/><line x1="2" y1="9" x2="22" y2="9"/>
      <path d="M9 13l-3 3 3 3"/><path d="M15 13l3 3-3 3"/>
    </svg>
  ),
  'widget-note': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
      <polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="12" y2="17"/>
    </svg>
  ),
  'widget-array': (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <rect x="2" y="7" width="5" height="10" rx="1.2"/><rect x="9.5" y="7" width="5" height="10" rx="1.2"/><rect x="17" y="7" width="5" height="10" rx="1.2"/>
      <path d="M19.5 4v-2m-1 1h2"/>
    </svg>
  ),
};

function WidgetToolbarButtons({ onDragStart }) {
  const handleDragStart = useCallback((e, widget) => {
    e.dataTransfer.setData('application/x-widget-id', widget.id);
    e.dataTransfer.effectAllowed = 'copy';
    const ghost = document.createElement('div');
    ghost.className = 'cw-drag-ghost';
    if (widget.id === 'widget-compiler') {
      ghost.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="1.5"><rect x="2" y="3" width="20" height="18" rx="2"/><line x1="2" y1="9" x2="22" y2="9"/><path d="M9 13l-3 3 3 3"/><path d="M15 13l3 3-3 3"/></svg>';
    } else if (widget.id === 'widget-array') {
      ghost.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#6965db" stroke-width="1.5"><rect x="2" y="7" width="5" height="10" rx="1.2"/><rect x="9.5" y="7" width="5" height="10" rx="1.2"/><rect x="17" y="7" width="5" height="10" rx="1.2"/><path d="M19.5 4v-2m-1 1h2"/></svg>';
    } else {
      ghost.innerHTML = '<svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#ca8a04" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
    }
    ghost.style.cssText = 'position:fixed;top:-100px;left:-100px;pointer-events:none;z-index:9999;background:rgba(99,102,241,0.1);border-radius:8px;padding:8px;';
    document.body.appendChild(ghost);
    e.dataTransfer.setDragImage(ghost, 24, 24);
    setTimeout(() => document.body.removeChild(ghost), 0);
    onDragStart(widget);
  }, [onDragStart]);

  return (
    <>
      <div className="cv-ds-divider" />
      {WIDGET_SHAPES.map((w) => (
        <button
          key={w.id}
          className="cv-ds-tool__btn"
          draggable
          onDragStart={(e) => handleDragStart(e, w)}
          title={`Drag to place: ${w.name}`}
        >
          {WIDGET_ICONS[w.id]}
        </button>
      ))}
    </>
  );
}

/* ── DS Overlay (add/remove node buttons) ──────────────────────── */

function DSOverlay({ dsGroups, api, onAddNode, onRemoveNode, canvasOffset = { x: 0, y: 0 } }) {
  const [overlayData, setOverlayData] = useState(null);
  const rafRef = useRef(null);

  const updateOverlay = useCallback(() => {
    if (!api || dsGroups.size === 0) {
      setOverlayData((p) => (p == null ? p : null));
      return;
    }

    const appState = api.getAppState();
    const selectedIds = new Set(
      Object.keys(appState.selectedElementIds || {}).filter((id) => appState.selectedElementIds[id])
    );
    if (selectedIds.size === 0) {
      setOverlayData((p) => (p == null ? p : null));
      return;
    }

    const allElements = api.getSceneElements();
    let matchedGroup = null;

    for (const el of allElements) {
      if (!selectedIds.has(el.id) || el.isDeleted) continue;
      for (const gid of el.groupIds || []) {
        if (dsGroups.has(gid)) {
          if (matchedGroup && matchedGroup !== gid) {
            setOverlayData((p) => (p == null ? p : null));
            return;
          }
          matchedGroup = gid;
        }
      }
    }

    if (!matchedGroup) {
      setOverlayData((p) => (p == null ? p : null));
      return;
    }

    const groupInfo = dsGroups.get(matchedGroup);
    const groupElements = allElements.filter(
      (el) => !el.isDeleted && (el.groupIds || []).includes(matchedGroup)
    );

    if (groupElements.length === 0) {
      setOverlayData((p) => (p == null ? p : null));
      return;
    }

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const el of groupElements) {
      minX = Math.min(minX, el.x);
      minY = Math.min(minY, el.y);
      maxX = Math.max(maxX, el.x + (el.width || 0));
      maxY = Math.max(maxY, el.y + (el.height || 0));
    }

    const zoom = appState.zoom?.value || 1;
    const sx = appState.scrollX || 0;
    const sy = appState.scrollY || 0;

    const screenLeft = canvasOffset.x + (minX + sx) * zoom;
    const screenTop = canvasOffset.y + (minY + sy) * zoom;
    const screenRight = canvasOffset.x + (maxX + sx) * zoom;
    const screenBottom = canvasOffset.y + (maxY + sy) * zoom;

    const next = {
      groupId: matchedGroup,
      type: groupInfo.type,
      size: groupInfo.size,
      left: screenLeft,
      top: screenTop,
      width: screenRight - screenLeft,
      height: screenBottom - screenTop,
    };
    setOverlayData((prev) => {
      if (
        prev &&
        prev.groupId === next.groupId &&
        prev.type === next.type &&
        prev.size === next.size &&
        Math.abs(prev.left - next.left) < 0.35 &&
        Math.abs(prev.top - next.top) < 0.35 &&
        Math.abs(prev.width - next.width) < 0.35 &&
        Math.abs(prev.height - next.height) < 0.35
      ) {
        return prev;
      }
      return next;
    });
  }, [api, dsGroups, canvasOffset.x, canvasOffset.y]);

  useEffect(() => {
    if (!api) return;
    const tick = () => {
      updateOverlay();
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [api, updateOverlay]);

  if (!overlayData) return null;

  const dsShape = DS_SHAPES.find((s) => s.id === `ds-${overlayData.type}`) ||
                  DS_SHAPES.find((s) => s.id.includes(overlayData.type));
  const canAdd = dsShape && overlayData.size < (dsShape.maxSize || 20);
  const canRemove = dsShape && overlayData.size > (dsShape.minSize || 1);

  const isArray = overlayData.type === 'array';

  return (
    <div
      className={`cv-ds-overlay${isArray ? ' cv-ds-overlay--array' : ''}`}
      style={{
        left: isArray ? overlayData.left + overlayData.width - 13 : overlayData.left + overlayData.width + 6,
        top: isArray ? overlayData.top + overlayData.height / 2 - (canRemove ? 28 : 13) : overlayData.top,
      }}
    >
      {canAdd && (
        <button
          className="cv-ds-overlay__btn cv-ds-overlay__btn--add"
          onClick={() => onAddNode(overlayData.groupId)}
          title="Add node"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      )}
      {canRemove && (
        <button
          className="cv-ds-overlay__btn cv-ds-overlay__btn--remove"
          onClick={() => onRemoveNode(overlayData.groupId)}
          title="Remove node"
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
        </button>
      )}
    </div>
  );
}

/* ── Main Canvas Component ─────────────────────────────────────── */

const ExcalidrawCanvas = forwardRef(function ExcalidrawCanvas(
  { theme, canvasId, canvasName, initialElements, initialFiles, onSceneChange, onExportPNG, dsNodeCount },
  ref
) {
  const [api, setApi] = useState(null);
  const saveTimer = useRef(null);
  const latestData = useRef({ elements: initialElements || [], files: initialFiles || {} });
  const wrapRef = useRef(null);
  const [toolbarSlot, setToolbarSlot] = useState(null);
  const [dsGroups, setDsGroups] = useState(new Map());

  const cn = canvasName || 'Untitled Canvas';
  const canvasNameRef = useRef(cn);
  const prevCanvasNameRef = useRef(null);
  const [widgetGroups, setWidgetGroups] = useState(() => loadWidgetsFromStorage(cn));
  const widgetGroupsRef = useRef(widgetGroups);
  const [selectedWidgetId, setSelectedWidgetId] = useState(null);
  const [viewport, setViewport] = useState({ zoom: 1, scrollX: 0, scrollY: 0 });
  const viewportRef = useRef({ zoom: 1, scrollX: 0, scrollY: 0 });
  /* Track Excalidraw's active tool so widget overlays can mirror shape behavior:
   * interactive only when the Selection tool is active; otherwise inert so
   * drawing / highlighting flows straight through to the canvas underneath. */
  const [activeTool, setActiveTool] = useState('selection');
  const activeToolRef = useRef('selection');
  /* Interactive canvas is inset inside wrapRef (toolbar/sidebar); overlays must add this offset. */
  const [canvasOffset, setCanvasOffset] = useState({ x: 0, y: 0 });

  const updateCanvasOffset = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    const next = measureCanvasOffsetInWrap(el);
    setCanvasOffset((prev) => (prev.x === next.x && prev.y === next.y ? prev : next));
  }, []);

  /* Coalesce offset work — onChange fires very often; unbounded rAF + parent re-renders can stress Excalidraw. */
  const canvasOffsetRafPending = useRef(false);
  const scheduleCanvasOffset = useCallback(() => {
    if (canvasOffsetRafPending.current) return;
    canvasOffsetRafPending.current = true;
    requestAnimationFrame(() => {
      canvasOffsetRafPending.current = false;
      updateCanvasOffset();
    });
  }, [updateCanvasOffset]);

  const themeRef = useRef(theme);
  useEffect(() => {
    themeRef.current = theme;
  }, [theme]);

  /* Toolbar / layout shifts move the canvas inside wrapRef — keep overlay alignment in sync. */
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    updateCanvasOffset();
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(updateCanvasOffset);
    });
    ro.observe(el);
    window.addEventListener('resize', updateCanvasOffset);
    const t = setTimeout(updateCanvasOffset, 0);
    const t2 = setTimeout(updateCanvasOffset, 250);
    return () => {
      ro.disconnect();
      window.removeEventListener('resize', updateCanvasOffset);
      clearTimeout(t);
      clearTimeout(t2);
    };
  }, [api, updateCanvasOffset]);

  const [snapState, setSnapState] = useState({ guides: [], gapGuides: [], distances: [], zoom: 1, scrollX: 0, scrollY: 0 });
  const isDragging = useRef(false);
  const prevPositions = useRef(new Map());
  const snapApplied = useRef(false);
  const pointerDown = useRef(false);
  const clearTimer = useRef(null);
  const saveRegistryTimer = useRef(null);
  /* Populated in handleChange — feeds the dev HUD so we can see onChange cadence. */
  const lastChangeRef = useRef(0);

  /*
   * Safe scene gateway: the ONLY place that calls `api.updateScene` for
   * non-tool-initiated patches. Guarantees no element-array replacement runs
   * while a pointer gesture is active — the #1 cause of "I drew, nothing appears".
   * Tool-initiated inserts (DS, widget drop, fit) can still call api directly,
   * because those never fire while the user is mid-draw.
   */
  const apiRef = useRef(null);
  useEffect(() => { apiRef.current = api; }, [api]);
  const safeSceneRef = useRef(null);
  if (!safeSceneRef.current) {
    safeSceneRef.current = createSafeScene({
      getApi: () => apiRef.current,
      isPointerDown: () => pointerDown.current,
    });
  }

  useEffect(() => {
    widgetGroupsRef.current = widgetGroups;
  }, [widgetGroups]);

  const updateWidgetProxyElement = useCallback((widgetId, updater) => {
    if (!api) return;
    const elements = api.getSceneElements();
    let changed = false;
    const nextElements = elements.map((el) => {
      if (el.isDeleted || !isWidgetProxyElement(el) || el.customData.widgetId !== widgetId) return el;
      const next = updater(el);
      if (next !== el) changed = true;
      return next;
    });
    if (!changed) return;
    api.updateScene({
      elements: nextElements,
      captureUpdate: CaptureUpdateAction.NEVER,
    });
  }, [api]);

  const handleSelectWidget = useCallback((id) => {
    setSelectedWidgetId(id);
    if (!api) return;
    const proxy = api.getSceneElements().find((el) => !el.isDeleted && isWidgetProxyElement(el) && el.customData.widgetId === id);
    if (!proxy) return;
    api.updateScene({
      appState: {
        selectedElementIds: {
          [proxy.id]: true,
        },
      },
      captureUpdate: CaptureUpdateAction.NEVER,
    });
  }, [api]);

  useImperativeHandle(ref, () => ({
    getApi: () => api,
    updateScene(elements, files) {
      if (!api) return;
      api.updateScene({
        elements: elements || [],
        captureUpdate: CaptureUpdateAction.NEVER,
      });
      if (files && Object.keys(files).length) {
        api.addFiles(Object.values(files));
      }
      const nonDeleted = (elements || []).filter((e) => !e.isDeleted);
      const hasWidgets = widgetGroupsRef.current && widgetGroupsRef.current.size > 0;
      if (nonDeleted.length > 0 || hasWidgets) {
        const runFit = () => fitSceneAndWidgets(api, widgetGroupsRef.current);
        requestAnimationFrame(() => requestAnimationFrame(runFit));
      }
    },
    fitView() {
      if (!api) return;
      const runFit = () => fitSceneAndWidgets(api, widgetGroupsRef.current);
      requestAnimationFrame(() => requestAnimationFrame(runFit));
    },
    undo() {
      if (!api) return;
      api.history.undo();
    },
    redo() {
      if (!api) return;
      api.history.redo();
    },
    zoomIn() {
      if (!api) return;
      const appState = api.getAppState();
      const currentZoom = appState.zoom?.value || 1;
      const newZoom = Math.min(currentZoom * 1.2, 10);
      api.updateScene({ appState: { zoom: { value: newZoom } } });
    },
    zoomOut() {
      if (!api) return;
      const appState = api.getAppState();
      const currentZoom = appState.zoom?.value || 1;
      const newZoom = Math.max(currentZoom / 1.2, 0.1);
      api.updateScene({ appState: { zoom: { value: newZoom } } });
    },
    resetZoom() {
      if (!api) return;
      api.updateScene({ appState: { zoom: { value: 1 } } });
    },
    insertElements(newEls) {
      if (!api) return;
      const existing = api.getSceneElements();
      const appState = api.getAppState();
      const cx = (appState.scrollX || 0) * -1 + (appState.width || window.innerWidth) / 2 / (appState.zoom?.value || 1);
      const cy = (appState.scrollY || 0) * -1 + (appState.height || window.innerHeight) / 2 / (appState.zoom?.value || 1);
      const offsetEls = newEls.map((el) => ({ ...el, x: (el.x || 0) + cx - 150, y: (el.y || 0) + cy - 100 }));
      api.updateScene({
        elements: [...existing, ...offsetEls],
        captureUpdate: CaptureUpdateAction.IMMEDIATELY,
      });
    },
    async exportPNG() {
      if (!api) return null;
      const { exportToBlob } = await import('@excalidraw/excalidraw');
      const els = api.getSceneElements();
      const appState = api.getAppState();
      const files = api.getFiles();
      return exportToBlob({ elements: els, appState: { ...appState, exportWithDarkMode: theme === 'dark' }, files });
    },
  }), [api, theme]);

  /* ── Toolbar slot mounting ─────────────────────────────────── */

  useEffect(() => {
    if (!wrapRef.current) return;
    const tryMount = () => {
      const toolbar = wrapRef.current.querySelector('.App-toolbar');
      if (!toolbar) return false;
      let slot = toolbar.querySelector('.cv-ds-slot');
      if (!slot) {
        slot = document.createElement('div');
        slot.className = 'cv-ds-slot';
        toolbar.appendChild(slot);
      }
      setToolbarSlot(slot);

      /* Widget overlays render in a stable div under wrapRef (see render). Do NOT portal into
       * .excalidraw: Excalidraw can replace its DOM on refresh/update and detach that node,
       * so createPortal would target a detached element → widgets flash then disappear. */
      return true;
    };
    if (tryMount()) return;
    const observer = new MutationObserver(() => {
      if (tryMount()) observer.disconnect();
    });
    observer.observe(wrapRef.current, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, [api]);

  /* ── Sync viewport when API mounts (before first onChange) ── */

  useEffect(() => {
    if (!api) return;
    let cancelled = false;
    const sync = () => {
      if (cancelled) return;
      const s = api.getAppState();
      const z = s.zoom?.value || 1;
      const sx = s.scrollX || 0;
      const sy = s.scrollY || 0;
      const prev = viewportRef.current;
      if (z !== prev.zoom || sx !== prev.scrollX || sy !== prev.scrollY) {
        viewportRef.current = { zoom: z, scrollX: sx, scrollY: sy };
        setViewport({ zoom: z, scrollX: sx, scrollY: sy });
      }
      const tool = s.activeTool?.type || 'selection';
      if (activeToolRef.current !== tool) {
        activeToolRef.current = tool;
        setActiveTool(tool);
      }
    };
    sync();
    const raf = requestAnimationFrame(sync);
    const t = setTimeout(sync, 50);
    const t2 = setTimeout(sync, 200);
    return () => {
      cancelled = true;
      cancelAnimationFrame(raf);
      clearTimeout(t);
      clearTimeout(t2);
    };
  }, [api]);

  /* Default stroke for new shapes — must track theme after mount (initialData runs once).
   * Routed through safeScene: if a gesture happens to be active (theme toggle during
   * drawing, extreme edge case), the appState patch is queued and applied on pointerup. */
  useEffect(() => {
    if (!api) return;
    const s = api.getAppState();
    const next = theme === 'dark' ? '#e2e8f0' : '#1e293b';
    if (s.currentItemStrokeColor === next) return;
    safeSceneRef.current?.updateScene({
      appState: { currentItemStrokeColor: next },
      captureUpdate: CaptureUpdateAction.NEVER,
    });
  }, [api, theme]);

  useEffect(() => {
    if (!api) return;
    /*
     * CRITICAL: never call api.updateScene mid-gesture. syncWidgetProxiesToScene
     * can replace the elements array, which wipes Excalidraw's `state.newElement`
     * and aborts the shape the user is currently drawing. If a gesture is active,
     * defer the sync until pointerup via safeScene.
     */
    if (pointerDown.current) {
      safeSceneRef.current?.enqueueAfterGesture((liveApi) => {
        syncWidgetProxiesToScene(liveApi, widgetGroupsRef.current, themeRef.current === 'dark', CaptureUpdateAction.NEVER);
      });
      return;
    }
    syncWidgetProxiesToScene(api, widgetGroups, theme === 'dark', CaptureUpdateAction.NEVER);
  }, [api, widgetGroups, theme]);

  /* Viewport sync is rAF-throttled so React state never updates faster than one frame.
   * During a freehand gesture we skip setViewport entirely — viewportRef still
   * updates synchronously so overlays re-render correctly on pointerup, and no proxy
   * geometry depends on it during the gesture. */
  const viewportRafPending = useRef(false);
  const scheduleViewportFlush = useCallback(() => {
    if (viewportRafPending.current) return;
    viewportRafPending.current = true;
    requestAnimationFrame(() => {
      viewportRafPending.current = false;
      const v = viewportRef.current;
      setViewport({ zoom: v.zoom, scrollX: v.scrollX, scrollY: v.scrollY });
    });
  }, []);

  /* ── Snap guides pointer tracking ─────────────────────────── */

  useEffect(() => {
    if (!api) return;
    const unsubDown = api.onPointerDown(() => {
      pointerDown.current = true;
      const appState = api.getAppState();
      const selectedIds = Object.keys(appState.selectedElementIds || {}).filter(id => appState.selectedElementIds[id]);
      if (selectedIds.length > 0 && appState.activeTool?.type === 'selection') {
        const elements = api.getSceneElements();
        const posMap = new Map();
        for (const el of elements) {
          if (!el.isDeleted) posMap.set(el.id, { x: el.x, y: el.y });
        }
        prevPositions.current = posMap;
        isDragging.current = false;
        snapApplied.current = false;
      }
    });
    const unsubUp = api.onPointerUp(() => {
      pointerDown.current = false;
      isDragging.current = false;
      prevPositions.current = new Map();
      snapApplied.current = false;
      if (clearTimer.current) clearTimeout(clearTimer.current);
      clearTimer.current = setTimeout(() => {
        setSnapState({ guides: [], gapGuides: [], distances: [], zoom: 1, scrollX: 0, scrollY: 0 });
      }, 150);
      /* Flush any scene patches that were deferred during the gesture.
       * Excalidraw commits `state.newElement` on its own pointerup handler
       * (fires before this one per subscription order), so a zero-delay
       * setTimeout is still required to let that commit land first. */
      setTimeout(() => {
        safeSceneRef.current?.flushOnGestureEnd();
        /* Catch up any viewport sync we skipped during freehand */
        scheduleViewportFlush();
      }, 0);
      /*
       * CRITICAL: Excalidraw fires onPointerUp BEFORE it commits
       * `state.newElement` into the scene (see index.js ~31900). If we call
       * setWidgetGroups here (which triggers api.updateScene), the shape the
       * user just drew will be wiped out before commit.
       * Defer via setTimeout so Excalidraw's internal pointerup handler
       * finishes finalising newElement first.
       */
      setTimeout(() => {
        /* Sync proxies without cloning widgetGroups (avoids extra re-renders → update loops). */
        syncWidgetProxiesToScene(
          api,
          widgetGroupsRef.current,
          themeRef.current === 'dark',
          CaptureUpdateAction.NEVER,
        );
      }, 0);
    });
    return () => { unsubDown(); unsubUp(); };
  }, [api]);

  const debouncedSave = useCallback(() => {
    clearTimeout(saveRegistryTimer.current);
    saveRegistryTimer.current = setTimeout(() => {
      const cname = canvasNameRef.current;
      setWidgetGroups((cur) => {
        saveWidgetRegistry(cname, cur);
        return cur;
      });
    }, 250);
  }, []);

  /* ── Excalidraw onChange (scene save + snap + viewport sync) ── */

  const handleChange = useCallback((elements, appState, files) => {
    lastChangeRef.current = performance.now();
    latestData.current = { elements: [...elements], files: { ...files } };
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      onSceneChange?.(latestData.current.elements, latestData.current.files);
    }, SAVE_DEBOUNCE);

    /*
     * FREEHAND FAST PATH:
     * While the user is actively drawing with the pen tool, we do ZERO React work
     * beyond the debounced save above. Every unnecessary setState here triggers a
     * re-render of three widget overlays and the snap SVG — at ~120 events/sec this
     * starves the browser's rAF budget and visually stutters (or worse, drops) the
     * stroke that Excalidraw is currently painting on its interactive canvas.
     * All the skipped work (viewport sync, selection tracking, widget proxy reconcile)
     * is idempotent and will run on the very next onChange *after* pointerup.
     */
    const tool = appState.activeTool?.type;
    /* Tools that create a new element by drag (freedraw, shapes, arrows, line, text).
     * During the gesture, ANY external setState here risks (a) overlay churn stutter
     * and (b) hitting the `maximum update depth` path Excalidraw itself flags if a
     * parent re-enters updateScene mid-commit. Gesture-active selection/move keeps
     * the slow path because snap guides need live feedback. */
    const SHAPE_TOOLS = new Set([
      'freedraw', 'rectangle', 'ellipse', 'diamond', 'arrow', 'line', 'text',
    ]);
    const isFreehandGesture = pointerDown.current && SHAPE_TOOLS.has(tool);
    if (isFreehandGesture) {
      /* Keep viewportRef fresh without the setState — overlays re-flush on pointerup. */
      const fz = appState.zoom?.value || 1;
      viewportRef.current = {
        zoom: fz,
        scrollX: appState.scrollX || 0,
        scrollY: appState.scrollY || 0,
      };
      return;
    }

    scheduleCanvasOffset();

    const z = appState.zoom?.value || 1;
    const sx = appState.scrollX || 0;
    const sy = appState.scrollY || 0;
    const prev = viewportRef.current;
    const viewportChanged = z !== prev.zoom || sx !== prev.scrollX || sy !== prev.scrollY;
    if (viewportChanged) {
      viewportRef.current = { zoom: z, scrollX: sx, scrollY: sy };
      scheduleViewportFlush();
    }

    /* Mirror tool changes onto a state used by widget overlays (pointer-events
     * gating). Cheap string compare; only re-renders overlays on transitions. */
    const nextTool = appState.activeTool?.type || 'selection';
    if (activeToolRef.current !== nextTool) {
      activeToolRef.current = nextTool;
      setActiveTool(nextTool);
    }

    const selectedIdsList = Object.keys(appState.selectedElementIds || {}).filter((id) => appState.selectedElementIds[id]);
    const selectedWidgetProxy = elements.find((el) => !el.isDeleted && isWidgetProxyElement(el) && selectedIdsList.includes(el.id));
    if (selectedWidgetProxy) {
      const proxyWidgetId = selectedWidgetProxy.customData.widgetId;
      if (selectedWidgetId !== proxyWidgetId) setSelectedWidgetId(proxyWidgetId);
    } else if (selectedIdsList.length > 0 && selectedWidgetId) {
      setSelectedWidgetId(null);
    }

    const deletedWidgetIds = new Set(
      elements
        .filter((el) => el.isDeleted && isWidgetProxyElement(el))
        .map((el) => el.customData.widgetId),
    );
    const widgetProxies = new Map(
      elements
        .filter((el) => !el.isDeleted && isWidgetProxyElement(el))
        .map((el) => [el.customData.widgetId, el]),
    );

    if (deletedWidgetIds.size || widgetProxies.size) {
      const proxyDataToSave = [];
      const removedWidgetIds = [];
      const sanitizedProxyIds = [];
      let didWidgetChange = false;
      setWidgetGroups((prevGroups) => {
        let nextGroups = prevGroups;
        for (const [id, info] of prevGroups) {
          if (!supportsWidgetProxy(info.type)) continue;
          if (deletedWidgetIds.has(id)) {
            if (nextGroups === prevGroups) nextGroups = new Map(prevGroups);
            nextGroups.delete(id);
            removedWidgetIds.push(id);
            didWidgetChange = true;
            continue;
          }
          const proxy = widgetProxies.get(id);
          if (!proxy) continue;
          const nextProxyStyle = getWidgetProxyStyle(proxy);
          const prevProxyStyle = info.data?.proxyStyle || {};
          const styleChanged =
            prevProxyStyle.strokeColor !== nextProxyStyle.strokeColor ||
            prevProxyStyle.backgroundColor !== nextProxyStyle.backgroundColor ||
            prevProxyStyle.strokeWidth !== nextProxyStyle.strokeWidth ||
            prevProxyStyle.strokeStyle !== nextProxyStyle.strokeStyle ||
            prevProxyStyle.opacity !== nextProxyStyle.opacity ||
            JSON.stringify(prevProxyStyle.roundness || null) !== JSON.stringify(nextProxyStyle.roundness || null);
          const geometryChanged =
            info.worldX !== proxy.x ||
            info.worldY !== proxy.y ||
            info.w !== proxy.width ||
            info.h !== proxy.height;
          if (!styleChanged && !geometryChanged) continue;
          if (nextGroups === prevGroups) nextGroups = new Map(prevGroups);
          const nextData = { ...(info.data || {}), proxyStyle: nextProxyStyle };
          nextGroups.set(id, {
            ...info,
            worldX: proxy.x,
            worldY: proxy.y,
            w: proxy.width,
            h: proxy.height,
            data: nextData,
          });
          proxyDataToSave.push([id, nextData]);
          if (info.type === 'array') sanitizedProxyIds.push(id);
          didWidgetChange = true;
        }
        return nextGroups;
      });
      if (didWidgetChange) {
        removedWidgetIds.forEach((id) => removeWidgetStorage(canvasNameRef.current, id));
        proxyDataToSave.forEach(([id, data]) => saveWidgetData(canvasNameRef.current, id, data));
        debouncedSave();
        /* Skip proxy-style sanitization while a gesture is active — calling
         * updateScene mid-draw destroys state.newElement and aborts drawing. */
        if (sanitizedProxyIds.length && !pointerDown.current) {
          const sanitizeSet = new Set(sanitizedProxyIds);
          const nextEls = elements.map((el) => {
            if (el.isDeleted || !isWidgetProxyElement(el) || !sanitizeSet.has(el.customData.widgetId)) return el;
            const patch = getProxyRenderPatch(el.customData.widgetType);
            if (!patch) return el;
            if (proxyMatchesArrayPatch(el, patch)) {
              return el;
            }
            return {
              ...el,
              strokeColor: patch.strokeColor,
              backgroundColor: patch.backgroundColor,
              opacity: patch.opacity,
            };
          });
          api.updateScene({
            elements: nextEls,
            captureUpdate: CaptureUpdateAction.NEVER,
          });
        }
      }
    }

    if (!pointerDown.current || !api) return;

    const selectedIds = new Set(selectedIdsList);
    if (selectedIds.size === 0 || appState.activeTool?.type !== 'selection') return;

    let hasMoved = false;
    for (const el of elements) {
      if (!selectedIds.has(el.id) || el.isDeleted) continue;
      const p = prevPositions.current.get(el.id);
      if (p && (Math.abs(el.x - p.x) > 0.1 || Math.abs(el.y - p.y) > 0.1)) {
        hasMoved = true;
        break;
      }
    }

    if (!hasMoved) return;
    isDragging.current = true;

    if (snapApplied.current) {
      snapApplied.current = false;
      return;
    }

    const allElements = [...elements].filter(el => !el.isDeleted);
    const canvasW = appState.width || window.innerWidth;
    const canvasH = appState.height || window.innerHeight;

    const result = computeAllSnaps(selectedIds, allElements, z, canvasW, canvasH, sx, sy);
    if (clearTimer.current) clearTimeout(clearTimer.current);

    const hasVisuals = result.guides.length > 0 || result.gapGuides.length > 0 || result.distances.length > 0;
    if (hasVisuals) {
      setSnapState({ guides: result.guides, gapGuides: result.gapGuides, distances: result.distances, zoom: z, scrollX: sx, scrollY: sy });
    } else {
      setSnapState({ guides: [], gapGuides: [], distances: [], zoom: z, scrollX: sx, scrollY: sy });
    }

    if (result.snapDx !== 0 || result.snapDy !== 0) {
      const updatedElements = elements.map(el => {
        if (selectedIds.has(el.id) && !el.isDeleted) {
          return { ...el, x: el.x + result.snapDx, y: el.y + result.snapDy };
        }
        return el;
      });
      snapApplied.current = true;
      const newPosMap = new Map();
      for (const el of updatedElements) {
        if (!el.isDeleted) newPosMap.set(el.id, { x: el.x, y: el.y });
      }
      prevPositions.current = newPosMap;
      api.updateScene({ elements: updatedElements, captureUpdate: CaptureUpdateAction.NEVER });
    } else {
      const newPosMap = new Map();
      for (const el of elements) {
        if (!el.isDeleted) newPosMap.set(el.id, { x: el.x, y: el.y });
      }
      prevPositions.current = newPosMap;
    }
  }, [onSceneChange, api, selectedWidgetId, debouncedSave, scheduleCanvasOffset]);

  /* ── DS shape handlers (unchanged) ───────────────────────── */

  const handleInsertDS = useCallback((ds, screenX = null, screenY = null) => {
    if (!api) return;
    const existing = api.getSceneElements();
    const appState = api.getAppState();
    const zoom = appState.zoom?.value || 1;

    const sizeToUse = dsNodeCount || ds.defaultSize;
    const result = ds.make(sizeToUse, canvasStrokePalette(theme === 'dark'));
    const newEls = result.elements;
    const groupId = result.groupId;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const el of newEls) {
      minX = Math.min(minX, el.x);
      minY = Math.min(minY, el.y);
      maxX = Math.max(maxX, el.x + (el.width || 0));
      maxY = Math.max(maxY, el.y + (el.height || 0));
    }
    const boundsW = maxX - minX;
    const boundsH = maxY - minY;

    let targetX;
    let targetY;
    if (screenX != null && screenY != null) {
      const crect = getInteractiveCanvasClientRect(wrapRef.current);
      const localX = crect ? screenX - crect.left : screenX - (wrapRef.current?.getBoundingClientRect().left || 0);
      const localY = crect ? screenY - crect.top : screenY - (wrapRef.current?.getBoundingClientRect().top || 0);
      targetX = localX / zoom - (appState.scrollX || 0) - boundsW / 2;
      targetY = localY / zoom - (appState.scrollY || 0) - boundsH / 2;
    } else {
      const cx = (appState.scrollX || 0) * -1 + (appState.width || window.innerWidth) / 2 / zoom;
      const cy = (appState.scrollY || 0) * -1 + (appState.height || window.innerHeight) / 2 / zoom;
      targetX = cx - boundsW / 2;
      targetY = cy - boundsH / 2;
    }

    const offsetEls = newEls.map((el) => ({
      ...el,
      x: (el.x || 0) - minX + targetX,
      y: (el.y || 0) - minY + targetY,
    }));
    api.updateScene({
      elements: [...existing, ...offsetEls],
      captureUpdate: CaptureUpdateAction.IMMEDIATELY,
    });

    setDsGroups((prev) => {
      const next = new Map(prev);
      next.set(groupId, { type: ds.id.replace('ds-', ''), size: sizeToUse });
      return next;
    });
  }, [api, dsNodeCount, theme]);

  const handleAddNode = useCallback((groupId) => {
    if (!api) return;
    const info = dsGroups.get(groupId);
    if (!info) return;
    const dsShape = DS_SHAPES.find((s) => s.id === `ds-${info.type}`) || DS_SHAPES.find((s) => s.id.includes(info.type));
    if (!dsShape || info.size >= (dsShape.maxSize || 20)) return;

    const allElements = api.getSceneElements();
    const groupEls = allElements.filter((el) => !el.isDeleted && (el.groupIds || []).includes(groupId));
    if (groupEls.length === 0) return;

    let minX = Infinity, minY = Infinity;
    for (const el of groupEls) { minX = Math.min(minX, el.x); minY = Math.min(minY, el.y); }

    const newSize = info.size + 1;
    const result = dsShape.make(newSize, canvasStrokePalette(theme === 'dark'));
    const newEls = result.elements.map((el) => ({ ...el, x: (el.x || 0) + minX, y: (el.y || 0) + minY }));
    const keepIds = new Set(groupEls.map((el) => el.id));
    const otherElements = allElements.filter((el) => !keepIds.has(el.id));
    api.updateScene({ elements: [...otherElements, ...newEls], captureUpdate: CaptureUpdateAction.IMMEDIATELY });
    setDsGroups((prev) => { const next = new Map(prev); next.delete(groupId); next.set(result.groupId, { type: info.type, size: newSize }); return next; });
  }, [api, dsGroups, theme]);

  const handleRemoveNode = useCallback((groupId) => {
    if (!api) return;
    const info = dsGroups.get(groupId);
    if (!info) return;
    const dsShape = DS_SHAPES.find((s) => s.id === `ds-${info.type}`) || DS_SHAPES.find((s) => s.id.includes(info.type));
    if (!dsShape || info.size <= (dsShape.minSize || 1)) return;

    const allElements = api.getSceneElements();
    const groupEls = allElements.filter((el) => !el.isDeleted && (el.groupIds || []).includes(groupId));
    if (groupEls.length === 0) return;

    let minX = Infinity, minY = Infinity;
    for (const el of groupEls) { minX = Math.min(minX, el.x); minY = Math.min(minY, el.y); }

    const newSize = info.size - 1;
    const result = dsShape.make(newSize, canvasStrokePalette(theme === 'dark'));
    const newEls = result.elements.map((el) => ({ ...el, x: (el.x || 0) + minX, y: (el.y || 0) + minY }));
    const keepIds = new Set(groupEls.map((el) => el.id));
    const otherElements = allElements.filter((el) => !keepIds.has(el.id));
    api.updateScene({ elements: [...otherElements, ...newEls], captureUpdate: CaptureUpdateAction.IMMEDIATELY });
    setDsGroups((prev) => { const next = new Map(prev); next.delete(groupId); next.set(result.groupId, { type: info.type, size: newSize }); return next; });
  }, [api, dsGroups, theme]);

  /* ── Widget handlers (new architecture) ──────────────────── */

  const handleInsertWidget = useCallback((widgetShape, screenX, screenY) => {
    const dims = WIDGET_DIMS[widgetShape.type];
    /* Prefer live app state (same as handleInsertDS). viewportRef can lag onChange and
     * place widgets off-screen or at (0,0) until the next scroll/zoom event. */
    const app = api?.getAppState();
    const zoom = app?.zoom?.value ?? viewportRef.current.zoom ?? 1;
    const scrollX = app?.scrollX ?? viewportRef.current.scrollX ?? 0;
    const scrollY = app?.scrollY ?? viewportRef.current.scrollY ?? 0;

    let worldX;
    let worldY;
    if (screenX != null && screenY != null) {
      const crect = getInteractiveCanvasClientRect(wrapRef.current);
      const localX = crect ? screenX - crect.left : screenX - (wrapRef.current?.getBoundingClientRect().left || 0);
      const localY = crect ? screenY - crect.top : screenY - (wrapRef.current?.getBoundingClientRect().top || 0);
      const sceneX = localX / zoom - scrollX;
      const sceneY = localY / zoom - scrollY;
      /* Center widget under cursor (matches DS insert math); avoids huge perceived offset. */
      worldX = sceneX - dims.w / 2;
      worldY = sceneY - dims.h / 2;
    } else {
      const vpW = wrapRef.current?.clientWidth || window.innerWidth;
      const vpH = wrapRef.current?.clientHeight || window.innerHeight;
      worldX = vpW / 2 / zoom - scrollX - dims.w / 2;
      worldY = vpH / 2 / zoom - scrollY - dims.h / 2;
    }

    const id = widgetUid();
    const cname = canvasNameRef.current;
    const newEntry = { type: widgetShape.type, worldX, worldY, w: dims.w, h: dims.h, data: {} };
    const isDark = theme === 'dark';
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      next.set(id, newEntry);
      saveWidgetRegistry(cname, next);
      widgetGroupsRef.current = next;
      /* Apply proxy to scene in the same turn as state so the Map is never stale vs ref. */
      if (api) {
        const run = () => syncWidgetProxiesToScene(api, next, isDark, CaptureUpdateAction.IMMEDIATELY);
        if (pointerDown.current) {
          setTimeout(run, 0);
        } else {
          run();
        }
      }
      return next;
    });
    setSelectedWidgetId(id);
  }, [api, theme]);

  const handleWidgetMove = useCallback((id, worldX, worldY) => {
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      const entry = next.get(id);
      if (entry) next.set(id, { ...entry, worldX, worldY });
      return next;
    });
    updateWidgetProxyElement(id, (el) => ({ ...el, x: worldX, y: worldY }));
    debouncedSave();
  }, [debouncedSave, updateWidgetProxyElement]);

  const handleWidgetResize = useCallback((id, w, h) => {
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      const entry = next.get(id);
      if (entry) next.set(id, { ...entry, w, h });
      return next;
    });
    updateWidgetProxyElement(id, (el) => ({ ...el, width: w, height: h }));
    debouncedSave();
  }, [debouncedSave, updateWidgetProxyElement]);

  const handleWidgetMoveResize = useCallback((id, worldX, worldY, w, h) => {
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      const entry = next.get(id);
      if (entry) next.set(id, { ...entry, worldX, worldY, w, h });
      return next;
    });
    updateWidgetProxyElement(id, (el) => ({ ...el, x: worldX, y: worldY, width: w, height: h }));
    debouncedSave();
  }, [debouncedSave, updateWidgetProxyElement]);

  const handleWidgetDataUpdate = useCallback((id, data) => {
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      const entry = next.get(id);
      if (entry) next.set(id, { ...entry, data });
      return next;
    });
    saveWidgetData(canvasNameRef.current, id, data);
  }, []);

  const handleWidgetDelete = useCallback((id) => {
    setSelectedWidgetId((s) => (s === id ? null : s));
    const cname = canvasNameRef.current;
    setWidgetGroups((prev) => {
      const next = new Map(prev);
      next.delete(id);
      saveWidgetRegistry(cname, next);
      removeWidgetStorage(cname, id);
      return next;
    });
    updateWidgetProxyElement(id, (el) => ({ ...el, isDeleted: true }));
  }, [updateWidgetProxyElement]);

  useEffect(() => {
    canvasNameRef.current = cn;
  }, [cn]);

  useEffect(() => {
    const prev = prevCanvasNameRef.current;
    if (prev === cn) return;
    clearTimeout(saveRegistryTimer.current);
    const loaded = loadWidgetsFromStorage(cn);
    widgetGroupsRef.current = loaded;
    setWidgetGroups((cur) => {
      if (prev != null) saveWidgetRegistry(prev, cur);
      return loaded;
    });
    setSelectedWidgetId(null);
    prevCanvasNameRef.current = cn;
  }, [cn]);

  /* Delete / Backspace removes selected widget when canvas has focus (like shapes) */
  useEffect(() => {
    const typingInsideWidget = (node) => node && typeof node.closest === 'function'
      && node.closest('input, textarea, select, [contenteditable="true"], .monaco-editor, .monaco-mouse-cursor-text');
    const onKey = (e) => {
      if (e.key !== 'Delete' && e.key !== 'Backspace') return;
      const t = e.target;
      const active = typeof document !== 'undefined' ? document.activeElement : null;
      if (typingInsideWidget(t) || typingInsideWidget(active)) return;
      if (!selectedWidgetId) return;
      if (api) {
        const app = api.getAppState();
        const sel = Object.keys(app?.selectedElementIds || {}).filter((k) => app.selectedElementIds[k]);
        if (sel.length > 0) return;
      }
      e.preventDefault();
      handleWidgetDelete(selectedWidgetId);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [selectedWidgetId, api, handleWidgetDelete]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const clearSel = (e) => {
      if (e.target?.closest?.('.cw-overlay, .nw-overlay, .aw-overlay, .cv-ds-slot, .App-toolbar')) return;
      /* Bubble phase only: capture + sync setState ran before the canvas received the event and broke drag-to-draw */
      setSelectedWidgetId(null);
    };
    el.addEventListener('pointerdown', clearSel, false);
    return () => el.removeEventListener('pointerdown', clearSel, false);
  }, []);

  /* ── Drag-and-drop from toolbar (native listeners to bypass Excalidraw) ── */

  const insertRef = useRef(handleInsertWidget);
  insertRef.current = handleInsertWidget;

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;

    const onDragOver = (e) => {
      if (e.dataTransfer.types.includes('application/x-widget-id')) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
      }
    };

    const onDrop = (e) => {
      const widgetId = e.dataTransfer.getData('application/x-widget-id');
      if (!widgetId) return;
      e.preventDefault();
      e.stopPropagation();
      const widget = WIDGET_SHAPES.find((w) => w.id === widgetId);
      if (widget) insertRef.current(widget, e.clientX, e.clientY);
    };

    el.addEventListener('dragover', onDragOver, true);
    el.addEventListener('drop', onDrop, true);
    return () => {
      el.removeEventListener('dragover', onDragOver, true);
      el.removeEventListener('drop', onDrop, true);
    };
  }, []);

  const handleWidgetDragStart = useCallback(() => {}, []);

  /*
   * initialData must NOT track live `elements` from the store (updates every stroke).
   * New initialData each render → Excalidraw store churn → maximum update depth.
   * Snapshot only when `canvasId` changes; ongoing edits use onChange → setScene, not this prop.
   */
  const excalidrawInitialData = useMemo(
    () => ({
      elements: initialElements || [],
      files: initialFiles || {},
      appState: {
        viewBackgroundColor: 'transparent',
        gridModeEnabled: false,
        currentItemStrokeColor: theme === 'dark' ? '#e2e8f0' : '#1e293b',
        currentItemBackgroundColor: 'transparent',
      },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps -- intentionally freeze initial scene per canvas
    [canvasId],
  );

  const excalidrawUIOptions = useMemo(
    () => ({
      canvasActions: {
        loadScene: false,
        saveToActiveFile: false,
        toggleTheme: false,
        export: false,
        clearCanvas: false,
      },
    }),
    [],
  );

  const widgetOverlayContent = (
    <>
      <CompilerWidgetOverlay
        widgetGroups={widgetGroups}
        viewport={viewport}
        canvasOffset={canvasOffset}
        selectedWidgetId={selectedWidgetId}
        onSelectWidget={setSelectedWidgetId}
        onMove={handleWidgetMove}
        onResize={handleWidgetResize}
        onMoveResize={handleWidgetMoveResize}
        onUpdateData={handleWidgetDataUpdate}
        onDelete={handleWidgetDelete}
        theme={theme}
        activeTool={activeTool}
      />
      <NoteWidgetOverlay
        widgetGroups={widgetGroups}
        viewport={viewport}
        canvasOffset={canvasOffset}
        selectedWidgetId={selectedWidgetId}
        onSelectWidget={setSelectedWidgetId}
        onMove={handleWidgetMove}
        onResize={handleWidgetResize}
        onMoveResize={handleWidgetMoveResize}
        onUpdateData={handleWidgetDataUpdate}
        onDelete={handleWidgetDelete}
        theme={theme}
        activeTool={activeTool}
      />
      <ArrayWidgetOverlay
        widgetGroups={widgetGroups}
        viewport={viewport}
        canvasOffset={canvasOffset}
        selectedWidgetId={selectedWidgetId}
        onSelectWidget={setSelectedWidgetId}
        onMove={handleWidgetMove}
        onResize={handleWidgetResize}
        onMoveResize={handleWidgetMoveResize}
        onUpdateData={handleWidgetDataUpdate}
        onDelete={handleWidgetDelete}
        theme={theme}
        activeTool={activeTool}
      />
    </>
  );

  /* ── Render ──────────────────────────────────────────────── */

  return (
    <div
      ref={wrapRef}
      style={{ width: '100%', height: '100%', position: 'relative' }}
    >
      <Excalidraw
        theme={theme === 'dark' ? 'dark' : 'light'}
        initialData={excalidrawInitialData}
        onChange={handleChange}
        excalidrawAPI={setApi}
        UIOptions={excalidrawUIOptions}
        autoFocus
      >
        <MainMenu>
          <MainMenu.Item
            onSelect={() => {
              if (!api) return;
              requestAnimationFrame(() =>
                requestAnimationFrame(() => fitSceneAndWidgets(api, widgetGroupsRef.current)),
              );
            }}
          >
            Fit to view
          </MainMenu.Item>
          <MainMenu.Item onSelect={() => onExportPNG?.()}>
            Export as PNG
          </MainMenu.Item>
          <MainMenu.Item onSelect={() => {
            if (!api) return;
            const els = api.getSceneElements();
            const appState = api.getAppState();
            const blob = new Blob([JSON.stringify({ type: 'excalidraw', version: 2, elements: els, appState: { viewBackgroundColor: appState.viewBackgroundColor } }, null, 2)], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'canvas.excalidraw';
            a.click();
            URL.revokeObjectURL(a.href);
          }}>
            Save as .excalidraw
          </MainMenu.Item>
          <MainMenu.Separator />
          <MainMenu.Item onSelect={() => api?.history.clear()}>
            Clear History
          </MainMenu.Item>
        </MainMenu>
      </Excalidraw>

      {toolbarSlot && createPortal(
        <>
          <DSToolbarButtons onInsert={handleInsertDS} />
          <WidgetToolbarButtons onDragStart={handleWidgetDragStart} />
        </>,
        toolbarSlot,
      )}

      <DSOverlay
        dsGroups={dsGroups}
        api={api}
        onAddNode={handleAddNode}
        onRemoveNode={handleRemoveNode}
        canvasOffset={canvasOffset}
      />

      {/*
       * Do NOT wrap widget overlays in a full-screen div (even with pointer-events:none).
       * As a sibling after <Excalidraw />, z-index &gt; 0 stacks above the canvas and can
       * hide drawn shapes; only the panels need positioning (cw-overlay is absolute).
       */}
      {widgetOverlayContent}

      <SnapGuidesOverlay
        guides={snapState.guides}
        gapGuides={snapState.gapGuides}
        distances={snapState.distances}
        zoom={snapState.zoom}
        scrollX={snapState.scrollX}
        scrollY={snapState.scrollY}
      />

      {/* Dev-only HUD: toggle by opening DevTools and running
       *   localStorage.setItem('cv:hud','1'); location.reload();
       * The flag check is inlined so the component tree-shakes in prod. */}
      {import.meta.env?.DEV && typeof window !== 'undefined'
        && window.localStorage?.getItem?.('cv:hud') === '1' && (
        <RenderDebugHUD
          getApi={() => api}
          pointerDownRef={pointerDown}
          lastChangeRef={lastChangeRef}
          enabled
        />
      )}
    </div>
  );
});

export default ExcalidrawCanvas;
