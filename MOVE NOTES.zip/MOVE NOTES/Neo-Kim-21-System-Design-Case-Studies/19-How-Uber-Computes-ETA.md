# 19. How Uber Computes ETA

## One-Line Summary
Uber computes real-time ETAs at massive scale (~500K requests/sec) using graph-based routing with precomputed partition boundaries, traffic-aware edge weights, and map-matching algorithms to handle noisy GPS data.

## Key Requirements
- **Scale**: ~500,000 ETA requests per second
- **Latency**: Sub-second response times for routing decisions
- **Accuracy**: ETAs must reflect real-time traffic conditions
- **Coverage**: 18 million trips daily; single trip generates ~1,000 ETA requests
- **Four ETA scenarios**:
  1. **Eyeball**: When user enters destination (pre-booking)
  2. **Dispatch**: Finding nearest available car
  3. **Pick up**: Time for driver to reach rider
  4. **On-trip**: Live ETA updates during the ride

## High-Level Architecture
```
[User App] → [ETA API] → [Routing Service] → [Graph DB + Traffic Data]
                ↓
         [Map Matching] ← [GPS Stream]
```

## Core Components Deep Dive

### 1. Map as a Graph
- **Nodes**: Road intersections
- **Edges**: Road segments (directed, weighted)
- **Edge weights**: Travel time based on traffic (time of day, weather, vehicle count)
- **Data sources**: Historical average speed + real-time speed data

### 2. Routing Algorithm Challenge
- **Naive approach**: Dijkstra's algorithm — O(n log n)
- **Problem**: San Francisco alone has ~500K intersections; too slow for real-time
- **Solution**: Graph partitioning + precomputing best paths within each partition
  - Only traverse partition boundaries (not entire graph)
  - Complexity drops from **area (πr²)** to **perimeter (2πr)**
  - SF: 500K nodes → ~700 boundary nodes to consider

### 3. Map Matching
- **Problem**: GPS signals are noisy (tunnels, multipath effect from buildings)
- **Goal**: Map raw GPS coordinates to actual road segments
- **Kalman filter**: Smart location guesser combining old + new information
- **Viterbi algorithm**: Dynamic programming to find most probable sequence of road segments

### 4. Traffic Information
- Edge weights populated with traffic data
- Factors: time of day, weather, vehicle count
- Combined historical + real-time speed data

## Key Design Decisions
1. **Graph partitioning** over full Dijkstra — reduces search space from area to perimeter
2. **Precomputed intra-partition paths** — avoid recomputing known routes
3. **Map matching pipeline** — essential for noisy GPS; Kalman + Viterbi handle uncertainty
4. **Traffic-aware edge weights** — ETAs reflect real-world conditions, not just distance

## Scaling Strategies
- Partition graph by geographic regions; precompute boundary-to-boundary paths
- Cache frequently requested routes (popular origin-destination pairs)
- Shard traffic data by region; parallel ETA computation per partition
- Async map-matching pipeline for GPS streams; batch updates to traffic weights

## Interview Tips
- Start with the four ETA scenarios — shows you understand the product
- Emphasize the **area vs perimeter** insight — it's the key algorithmic breakthrough
- Mention map matching — many candidates forget GPS is noisy
- Discuss trade-offs: precomputation (storage) vs query latency (speed)

## Quick Revision
- 4 ETA scenarios: Eyeball, Dispatch, Pick up, On-trip
- Graph: intersections = nodes, road segments = weighted directed edges
- Partitioning: complexity πr² → 2πr; SF 500K → 700 boundary nodes
- Map matching: Kalman filter (location estimation) + Viterbi (most probable road path)
- Traffic: historical + real-time speed; weights vary by time, weather, vehicle count
