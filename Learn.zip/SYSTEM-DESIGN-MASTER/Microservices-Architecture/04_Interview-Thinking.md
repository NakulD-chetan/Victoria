# Microservices Architecture — Interview Thinking

> **Permanent Recall:** Discuss microservices when the problem involves scale, multiple teams, or independent deploy. Propose monolith first for new/small systems; microservices when justified. Be ready to explain service boundaries (DDD), inter-service communication, distributed transactions (Saga), and migration strategy (Strangler Fig). Keep answers structured and concise.

---

## How to Discuss Microservices in Interviews

| Trigger | What to say |
|---------|-------------|
| "Design a scalable system" | "We'd start with a monolith for speed; extract microservices when we have multiple teams or need independent deploy." |
| "Design an e-commerce platform" | "We'd decompose by domain: User, Order, Payment, Inventory, Search. Each service owns its data; we use events for coordination." |
| "How do services communicate?" | "Sync (REST/gRPC) for request-response; async (Kafka/RabbitMQ) for events and eventual consistency." |
| "How do you handle distributed transactions?" | "We avoid 2PC. We use Saga—each step has compensating action; eventual consistency." |

> **FAANG Tip:** Lead with tradeoffs: *"Microservices add operational complexity; we use them when the benefits outweigh the cost."*

---

## When to Propose Monolith vs Microservices

| Scenario | Propose | One-liner |
|----------|---------|-----------|
| New startup, 2 devs | Monolith | "Start simple; extract later when we have scale and teams." |
| "Design Twitter" | Microservices | "Multiple domains (tweet, timeline, user, DM); independent scale." |
| "Design Uber" | Microservices | "Real-time, matching, billing—different scaling profiles." |
| "MVP in 3 months" | Monolith | "Speed to market; refactor when we validate." |
| "100M users, 10 teams" | Microservices | "Team ownership and deploy independence are critical." |

---

## How to Explain Service Boundaries

**Structured answer:**

1. **Domain-based:** "We split by business capability—User, Order, Payment. Each owns its data."
2. **DDD:** "We use bounded contexts. User context doesn't know Order's internal model; they share IDs."
3. **Team alignment:** "Ideally one team per service; Conway's Law."

**Red flag to avoid:** "We split by technical layer (API layer, DB layer)"—that's not microservices.

---

## Discussing Inter-Service Communication

| Question | Answer |
|----------|--------|
| Sync vs async? | "Sync for immediate response (e.g., get user). Async for fire-and-forget or events (e.g., order placed → notify, update inventory)." |
| REST vs gRPC? | "REST for external; gRPC internally for performance and streaming." |
| When to use message queue? | "When we need decoupling, retries, or one-to-many (pub/sub)." |

---

## Handling "How Do You Handle Distributed Transactions?"

**Model answer:**

*"We avoid distributed transactions across many services. We use the Saga pattern: each service performs its step and publishes an event. If a later step fails, we run compensating actions in reverse order. We accept eventual consistency—e.g., order might be 'pending' until all steps complete."*

**Follow-up:** "What about 2PC?" → *"2PC blocks; doesn't scale across many services. We use it only for 2–3 tightly coupled services if strong consistency is required."*

---

## Presenting Migration Strategy

**Strangler Fig in 3 steps:**

1. **Identify:** "We pick the most independent module first—e.g., notifications or reporting."
2. **Route:** "We add a gateway; new features and migrated paths go to the new service."
3. **Shift:** "We migrate traffic gradually; dual-write if needed; eventually retire the monolith path."

> **FAANG Tip:** *"We don't do big-bang. We extract one service at a time; each extraction is a separate release."*

---

## Interview Flow: Microservices Discussion

1. **Clarify scale/team** → If small, suggest monolith first.
2. **Draw high-level** → API Gateway → Services → DBs.
3. **Explain boundaries** → Domain, DDD, team.
4. **Communication** → Sync vs async with examples.
5. **Transactions** → Saga; mention 2PC only if asked.
6. **Migration** → Strangler Fig if existing system.

---

## Red Flags to Avoid

- **Don't say:** "We use microservices for everything" (without justification)
- **Don't say:** "Each microservice is a single function" (too granular)
- **Don't say:** "We share the database across services" (breaks encapsulation)
- **Don't say:** "2PC for distributed transactions" (as default—it doesn't scale)

---

## Quick Memory Card

```
DISCUSS:       When scale, teams, deploy independence matter
MONOLITH:      Small team, early stage, unclear boundaries
BOUNDARIES:    Domain, DDD bounded context, team
COMMUNICATION: Sync (REST/gRPC) vs async (queue)
TRANSACTIONS:  Saga; 2PC only for 2-3 services
MIGRATION:     Strangler Fig; one module at a time
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
