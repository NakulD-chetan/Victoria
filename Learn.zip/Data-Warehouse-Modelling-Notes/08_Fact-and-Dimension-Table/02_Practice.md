# Fact Table and Dimension Table — Practice

> "Facts measure the business; dimensions describe the context of those measures."

---

## Quick Recall

**Q:** What rows live in a fact table for retail?  
**A:** Rows at a declared grain carrying numeric measures (sales, quantity) and foreign keys to dimensions.

**Q:** What rows live in a dimension table?  
**A:** Descriptive context: customer, product, store, date, promotion—attributes used for slicing facts.

**Q:** What is grain in `fact_sales_line`?  
**A:** One row per order line item (order id plus line number), typically.

**Q:** What are degenerate dimensions?  
**A:** Operational identifiers stored on the fact when no useful attribute set exists—like `order_id` or `transaction_number`.

**Q:** Why surrogate keys on dimensions?  
**A:** Stable joins, support for SCD Type 2, and insulation from source system merges or rekeys.

---

## Interview Questions

**1. Explain facts vs dimensions to a non-technical retail VP.**  
**Model answer:** Facts are the numbers we add up—units sold, revenue. Dimensions are the words we group by—brand, region, week, promotion. Together they answer "how much, by what, over when." I avoid saying "foreign keys" unless they care about implementation.

**2. Should `product_name` live on the fact or product dimension?**  
**Model answer:** On `dim_product` as an attribute. Putting names on facts duplicates data, complicates SCD handling, and bloats storage. If names are needed for export speed, expose a denormalized view, not a second source of truth.

**3. When is it acceptable to denormalize into a fact?**  
**Model answer:** Low-cardinality flags needed for performance or late-binding attributes with clear governance—still sparingly compared to rich dimensions. Example: a stable `is_marketplace` flag agreed by finance might live on the fact if join elimination materially helps a hot dashboard.

**4. What is a junk dimension?**  
**Model answer:** A bucket of low-cardinality flags (for example, `is_gift`, `is_marketplace`, `is_bopis`) combined to reduce fact width while avoiding an explosion of individual dimensions. Cardinality must stay bounded or the junk dimension itself becomes huge.

**5. How do you model a promotion that applies to a basket, not a line?**  
**Model answer:** Allocate promotion discount to lines using a documented rule (prorate by line amount) or model a bridge table between orders and promotions with careful double-counting controls. Finance usually has an opinion on allocation.

**6. What is a role-playing dimension?**  
**Model answer:** The same `dim_date` joined multiple times on a shipment fact for `order_date`, `ship_date`, and `delivery_date` using views or aliases. Clear naming prevents analysts from joining the wrong date role.

**7. Why are foreign keys important in star schemas?**  
**Model answer:** They enforce referential intent, help optimizers, and keep BI tools from creating accidental many-to-many joins. Even if the engine does not enforce constraints, modeling communicates valid paths.

**8. What is a factless fact table and a retail example?**  
**Model answer:** Keys without numeric measures—such as `fact_product_store_assortment` capturing which SKUs were ranged in which stores each week. Supports coverage questions like "which stores should have carried this SKU?"

---

## Scenario-Based Exercises

**Scenario 1 — Choose grain for click attribution**  
**Solution:** If reporting is order-level, grain is one row per attributed order; if path analysis, a separate fact at event grain with a bridge to orders. Mixing both in one table usually breaks additivity.

**Scenario 2 — Store dimension with regions**  
**Solution:** `dim_store` holds region hierarchy; `fact_sales` references `store_key` only; region rolls up via the dimension. Avoid storing region text redundantly on the fact unless there is a proven performance need with a governance note.

**Scenario 3 — Customer changes address mid-quarter**  
**Solution:** Type 2 `dim_customer` preserves history; `fact_sales` keeps the `customer_key` as of purchase for historical accuracy. Marketing "current segment" is a different join pattern and must be labeled clearly.

```sql
SELECT d.fiscal_week,
       p.brand_name,
       SUM(f.net_sales_amount) AS net_sales,
       SUM(f.quantity) AS units
FROM dw.fact_sales_line f
JOIN dw.dim_date d ON f.order_date_key = d.date_key
JOIN dw.dim_product p ON f.product_key = p.product_key
GROUP BY d.fiscal_week, p.brand_name
ORDER BY d.fiscal_week, p.brand_name;
```

**Scenario 4 — Degenerate keys and gift cards**  
**Solution:** Keep `order_id` and `line_number` on the fact for drill-through to OMS; do not create a junk dimension for every identifier unless it carries attributes. For gift cards sold but not redeemed, model issuance and redemption as separate facts or event types with conformed `dim_date` and `dim_product` (gift cards as products), and model liability as semi-additive snapshots if finance requires balance-style reporting.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Mixing header and line grain | Double-count revenue | Declare grain explicitly; line facts for line measures |
| Storing measures on dimensions | Breaks additivity rules | Keep measures on facts |
| Joining dimensions directly without facts | Fabricates relationships | Bridge tables or factless facts when needed |
| Ignoring role-playing clarity | Wrong date semantics | Name joins explicitly in views |
| Treating degenerate dimensions as junk | Confuses modeling vocabulary | Degenerate = identifier on fact; junk = low-card flags |
| Overusing bridges | Many-to-many without weights | Document allocation or keep bridges for existence counts only |

---

## One-Liner Answers

- Fact tables hold numeric measures at a consistent grain plus dimension foreign keys.
- Dimension tables hold descriptive attributes and hierarchies for filtering and grouping.
- Grain must be explicit before any SQL or ETL is written for retail facts.
- Surrogate keys support slowly changing dimensions and stable joins over time.
- Degenerate dimensions store operational IDs on the fact when no attribute dimension exists.
- Star schemas simplify SQL and help BI tools generate correct aggregations.
