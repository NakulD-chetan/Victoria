# Window Functions — Interview Thinking

---

## Rapid-Fire Q&A

### Q: What is a Window Function?
**A:** A function that performs calculation across a set of rows related to the current row, without collapsing them. Uses OVER() clause. Keeps all original rows and adds computed columns.

### Q: What is the OVER clause?
**A:** Defines the "window" for the function: PARTITION BY (groups), ORDER BY (sort within group), Frame (which rows to include). `SUM(x) OVER (PARTITION BY dept ORDER BY date)`.

### Q: What is PARTITION BY?
**A:** Divides rows into independent groups (like GROUP BY but doesn't collapse rows). Each partition gets its own numbering/calculation. If omitted, entire result set is one partition.

### Q: ROW_NUMBER vs RANK vs DENSE_RANK?
**A:**
- ROW_NUMBER: Always unique (1,2,3,4) — ties get arbitrary different numbers.
- RANK: Ties share same rank, then gaps (1,1,3,4).
- DENSE_RANK: Ties share same rank, no gaps (1,1,2,3).
Use ROW_NUMBER for dedup (pick one per group), DENSE_RANK for "top N" allowing ties.

### Q: What is NTILE?
**A:** Divides rows into N roughly equal buckets. `NTILE(4)` creates quartiles (1,2,3,4). Useful for percentile analysis.

### Q: What is LAG and LEAD?
**A:** LAG(col, n) returns the value from n rows BEFORE current row. LEAD(col, n) returns n rows AFTER. Used for day-over-day comparison, calculating change between consecutive rows.

### Q: What is FIRST_VALUE and LAST_VALUE?
**A:** FIRST_VALUE returns the first value in the window frame. LAST_VALUE returns the last — but watch the default frame! Default frame only goes to current row, so LAST_VALUE may not give expected result. Fix: specify full frame explicitly.

### Q: What is NTH_VALUE?
**A:** Returns the Nth value in the window frame. `NTH_VALUE(salary, 2)` = second salary in the window. Returns NULL if N exceeds frame size.

### Q: What is PERCENT_RANK?
**A:** Relative rank as a fraction: `(rank - 1) / (total_rows - 1)`. First row = 0, last row = 1. Useful for percentile calculation.

### Q: What is CUME_DIST?
**A:** Cumulative distribution: proportion of rows with values ≤ current row. Range > 0 to 1. Last row always = 1.

### Q: ROWS vs RANGE vs GROUPS in frame?
**A:** ROWS = exact physical row count. RANGE = all rows with same value (peers). GROUPS = groups of peers. ROWS is most predictable and commonly used.

### Q: What is the default window frame?
**A:** With ORDER BY: `RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW` (running total). Without ORDER BY: entire partition. This default catches people off guard with LAST_VALUE.

### Q: Can you use window functions in WHERE?
**A:** No! Window functions compute in SELECT phase, WHERE runs earlier. Use CTE/subquery: compute window in inner query, filter in outer.

### Q: Window function vs GROUP BY — when to use which?
**A:** GROUP BY when you need collapsed summary (one row per group). Window when you need both individual row detail AND aggregate/ranking in the same result.

### Q: How to get Top-N per group?
**A:** `ROW_NUMBER() OVER (PARTITION BY group_col ORDER BY metric DESC) AS rn` in CTE, then `WHERE rn <= N` in outer query.

### Q: How to detect consecutive days/values?
**A:** Use LAG to check previous value. Or island trick: `date - ROW_NUMBER() = constant` groups consecutive dates together.

### Q: What is a Moving Average?
**A:** `AVG(col) OVER (ORDER BY date ROWS BETWEEN 6 PRECEDING AND CURRENT ROW)` = 7-day moving average. Frame explicitly defines the window.

---

## Hot questions

- **ROW_NUMBER vs RANK vs DENSE_RANK** — ties.
- **Why** `WHERE rn = 1` fails on same query level — evaluation order; use CTE.
- **LAG** for day-over-day metrics.

---

## Strong answer

"Windows keep **row-level detail** while computing **group-aware** metrics — ideal for rankings, running totals, and comparative analysis."

---

*Next: [[05_Common-Mistakes]]*
