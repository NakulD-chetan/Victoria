# How LLMs Like ChatGPT Work - In Depth (Easy Language)

> Companion to: [04-How-LLMs-ChatGPT-Work.md](04-How-LLMs-ChatGPT-Work.md)

---

## What Is an LLM, Really?

### The Simplest Explanation

An LLM is an **incredibly sophisticated autocomplete**. That's it.

When you type "The capital of France is..." on your phone keyboard, your phone suggests "Paris." An LLM does the same thing, but at a mind-blowing scale.

```
Your phone autocomplete:
  "Good morn" → "morning"  (simple word prediction)

ChatGPT autocomplete:
  "Explain quantum physics in simple terms" →
  "Quantum physics is the study of how very tiny particles
   (smaller than atoms) behave. At this tiny scale, things
   work very differently than what we see in everyday life..."
```

Both are predicting "what word comes next?" But ChatGPT was trained on the entire internet, so its predictions are extraordinarily good.

---

## Tokens - How LLMs Read Text

### LLMs Don't See Words, They See Numbers

Computers can't understand text directly. They need numbers. So text is broken into small pieces called **tokens**.

```
"What is fine-tuning?"
  ↓ (tokenizer breaks it up)
["What", " is", " fine", "-", "tuning", "?"]
  ↓ (each token gets a number)
[2061, 318, 5765, 12, 28286, 30]
```

**Important rules:**
- One token ≈ 4 characters (roughly)
- Common words = 1 token ("the" = 1 token)
- Rare words = multiple tokens ("cryptocurrency" = "crypt" + "o" + "currency" = 3 tokens)
- Spaces and punctuation are also tokens

**Why does this matter?**

The model's **context window** is measured in tokens (not words). GPT-4 Turbo has a 128K token context window ≈ roughly 96,000 words ≈ about 300 pages of a book. That's how much it can "see" at once.

---

## Embeddings - Giving Meaning to Numbers

### The Problem

Token IDs are just labels. Token 2061 ("What") and token 2062 (some random word) look similar as numbers, but their meanings could be completely different.

### The Solution: Embeddings

An **embedding** is a long list of numbers that captures the MEANING of a token. Think of it as coordinates on a "meaning map."

```
Imagine a 2D meaning map (real embeddings have 1000+ dimensions):

         "happy"  "joyful"
            •      •           ← close together (similar meaning)


  "sad" •                      ← far from happy (opposite meaning)


                    "table" •  ← far from all emotions (unrelated)
```

In reality, embeddings are lists of 1000+ numbers:
```
"dog"  → [0.21, -0.54, 0.89, 0.12, -0.33, 0.67, ... 1000+ numbers]
"puppy" → [0.23, -0.52, 0.91, 0.14, -0.31, 0.65, ... 1000+ numbers]
                  ↑ very similar numbers!

"refrigerator" → [0.87, 0.43, -0.12, 0.56, 0.91, -0.78, ... 1000+ numbers]
                  ↑ very different numbers!
```

**Why embeddings matter:**
- Search engines use them: "cheap flights" and "affordable airfare" have similar embeddings, so they return similar results
- RAG systems use them to find relevant documents
- Recommendation systems use them to find similar items

---

## How LLMs Learn - The Training Pipeline

### Stage 1: Pre-Training (The Brute Force Phase)

**What happens:**
The model reads MASSIVE amounts of internet text (books, Wikipedia, code, forums, news) and learns to predict the next word.

```
Training example:
  Input:  "The cat sat on the ___"
  Target: "mat"
  
  Model guesses: "car" (wrong!)
  → Adjust billions of parameters slightly
  
  Model guesses again: "table" (closer but wrong!)
  → Adjust parameters again
  
  ... repeat TRILLIONS of times ...
  
  Model guesses: "mat" (correct!)
```

**Scale of pre-training:**
- Training data: ~13 trillion tokens (GPT-4 level)
- Cost: ~$100 million in compute
- Time: weeks to months on thousands of GPUs
- Result: a "base model" that knows language patterns

**The base model is like a very well-read person who knows a lot but doesn't know HOW to be helpful.** It can complete text, but it might ramble, give dangerous advice, or ignore your question.

### Stage 2: Fine-Tuning (The Specialization Phase)

Take the base model and train it further on a smaller, specific dataset.

```
Base model: knows everything about everything (but messy)
                    ↓ fine-tune on code
GitHub Copilot: great at writing code (specialized)

Base model: knows everything about everything (but messy)
                    ↓ fine-tune on medical texts
Medical AI: great at medical Q&A (specialized)
```

**Key insight**: Fine-tuning doesn't add new knowledge. It changes the model's BEHAVIOR to be better at a specific task.

### Stage 3: RLHF (Making It Actually Helpful)

**RLHF = Reinforcement Learning from Human Feedback**

This is the secret sauce that makes ChatGPT feel "smart" and "helpful" instead of just being a text predictor.

```
Step 1: Ask the model a question
  "How do I make pasta?"

Step 2: Model generates 3 different answers:
  Answer A: "Boil water, add pasta, cook 8 min, drain"
  Answer B: "Pasta originates from Italy in the 13th century..."
  Answer C: "Here's a detailed recipe: 1. Bring a large pot..."

Step 3: Human rankers rate them:
  Answer C > Answer A > Answer B
  (C is best: detailed, practical, well-structured)

Step 4: Train a "reward model" (judge) from these rankings
  The judge learns: "detailed, practical answers score high"

Step 5: Use the judge to train the LLM
  Model generates answer → judge scores it → model adjusts
  → Over time, model learns to give C-style answers
```

**This is why ChatGPT refuses dangerous requests.** During RLHF, humans ranked answers that refused harmful requests higher than answers that complied. The model learned: refusing = high score.

---

## Context Window - The Model's Working Memory

### The Goldfish Problem

LLMs have a fixed "working memory" called the context window. Everything must fit inside it:

```
Context Window (e.g., 128K tokens for GPT-4 Turbo):
┌─────────────────────────────────────────────┐
│ System prompt: "You are a helpful assistant" │
│ User message 1: "What is Python?"           │
│ Assistant reply 1: "Python is a..."          │
│ User message 2: "How do I install it?"      │
│ Assistant reply 2: "You can install..."      │
│ User message 3: "Write a hello world"       │
│ Assistant reply 3: "print('hello world')"    │
│ ... (more conversation) ...                  │
│ Current response being generated...          │
└─────────────────────────────────────────────┘
```

**What happens when the window is full?**

Old messages get dropped from the beginning. The model literally "forgets" the start of the conversation.

```
Window full:
  [Message 1] [Message 2] [Message 3] ... [Message 50] [New message]
       ↓ dropped!
  [Message 2] [Message 3] ... [Message 50] [New message] [Newest message]
```

This is why very long conversations sometimes feel like the AI "forgot" what you discussed earlier.

---

## Temperature - Controlling Creativity

### The Dice Analogy

When the model predicts the next token, it calculates probabilities for ALL possible next tokens:

```
"The capital of France is ___"
  "Paris"  → 95% probability
  "Lyon"   → 2%
  "Berlin" → 1%
  "pizza"  → 0.001%
```

**Temperature controls which token gets picked:**

```
Temperature = 0 (deterministic):
  ALWAYS picks "Paris" (highest probability)
  Same input → same output every time
  Good for: factual Q&A, code generation, math

Temperature = 0.7 (balanced):
  Usually picks "Paris" but sometimes "Lyon"
  Adds variety while staying sensible
  Good for: general conversation, writing

Temperature = 1.0 (creative):
  Picks from a wider range, might even say "Lyon" or "the city of lights"
  More varied, sometimes surprising
  Good for: creative writing, brainstorming
  
Temperature = 1.5 (chaotic):
  Might pick "pizza" occasionally
  Too random, often incoherent
  Not recommended for most uses
```

---

## Inference - What Happens When You Hit Send

### Step-by-Step Process

```
You type: "What is 2+2?"

Step 1: Tokenize input
  ["What", " is", " 2", "+", "2", "?"] → [2061, 318, 362, 10, 362, 30]

Step 2: Process through the neural network
  All tokens processed at once (this is the "attention" mechanism)
  Model calculates: "The most likely next token is..."

Step 3: Generate first token
  Predicted next token: "2" (start of "2+2=4")
  
Step 4: Add "2" to the sequence, generate next token
  Input now: "What is 2+2? 2"
  Predicted: "+"
  
Step 5: Continue one token at a time
  "What is 2+2? 2+"  → "2"
  "What is 2+2? 2+2" → "="
  "What is 2+2? 2+2=" → "4"
  "What is 2+2? 2+2=4" → "." 
  "What is 2+2? 2+2=4." → [END]  (stop token)

Result: "2+2=4."
```

**Key insight**: The model generates ONE token at a time. That's why you see ChatGPT "typing" -- it's literally producing one word at a time.

### Two Speed Metrics

- **TTFT (Time-to-First-Token)**: How long until the first word appears (~500ms-2s)
- **Time-between-tokens**: How fast subsequent words appear (~20-50ms each)

TTFT is slower because the model must process your entire input first. After that, each new token is faster.

---

## RAG - How to Make LLMs Accurate

### The Hallucination Problem

LLMs can confidently make up information that sounds real but is completely wrong.

```
You: "Who won the 2024 Cricket World Cup?"
LLM: "Australia won the 2024 Cricket World Cup, 
      defeating India in the final."  ← COULD BE WRONG!
```

The model doesn't "know" facts. It predicts what sounds statistically likely. Sometimes it gets it right. Sometimes it doesn't.

### RAG = Retrieval-Augmented Generation

The fix: give the LLM reliable information BEFORE it answers.

```
Step 1 - RETRIEVE:
  Search your trusted documents for "2024 Cricket World Cup"
  → Found: "India won the 2024 T20 World Cup..."

Step 2 - AUGMENT:
  Add the found information to the prompt:
  "Based on this document: [India won the 2024 T20 World Cup...]
   Answer the user's question: Who won the 2024 Cricket World Cup?"

Step 3 - GENERATE:
  LLM reads the context and answers based on IT, not its training data:
  "According to the available information, India won the 2024 
   T20 Cricket World Cup."
```

**How the search works (embeddings!)**:
```
1. Your documents are pre-processed: each chunk gets an embedding (vector)
2. User's question also gets an embedding
3. Find document chunks whose embeddings are CLOSEST to the question's embedding
4. Those are the most relevant chunks → add them to the prompt
```

**Real-world examples:**
- **Perplexity AI**: Searches the web → adds results to prompt → generates answer with citations
- **GitHub Copilot**: Searches your codebase → adds relevant code to prompt → generates suggestions
- **Enterprise chatbots**: Search company wiki → answer employees' questions accurately

---

## Agents vs Workflows

### Workflow: You Control the Steps

```
Fixed pipeline (developer decides the path):
  1. User asks question
  2. Search database
  3. Format results
  4. Generate response
  
  Always follows steps 1→2→3→4. Never deviates.
  Predictable, reliable, but rigid.
```

### Agent: The LLM Controls the Steps

```
Flexible pipeline (LLM decides what to do):
  1. User: "Find cheap flights to Paris and book the best one"
  2. Agent thinks: "I need to search flights first"
     → Uses flight search tool
  3. Agent thinks: "Let me compare prices and dates"
     → Analyzes results
  4. Agent thinks: "This one is best, let me book it"
     → Uses booking tool
  5. Agent thinks: "Done, let me confirm with the user"
     → Returns summary
```

The agent decided to use search, then analyze, then book. A different query might lead to completely different tool usage.

---

## Common LLM Failures and How to Fix Them

| Failure | Why It Happens | How to Fix |
|---------|---------------|------------|
| **Hallucination** | Model predicts likely-sounding but false info | RAG (ground answers in real docs) |
| **Bad at math** | It's a pattern matcher, not a calculator | Give it a calculator tool |
| **Outdated knowledge** | Training data has a cutoff date | RAG with web search |
| **Bias** | Training data reflects internet biases | RLHF, guardrails, careful prompting |
| **Inconsistent answers** | Temperature > 0 means randomness | Use temperature = 0 for consistency |
| **Ignores instructions** | Prompt wasn't clear enough | Use system prompt, few-shot examples |

---

## Revision Flashcards

**Q: What is an LLM fundamentally doing?**
A: Predicting the next token (word piece), one at a time, based on all previous tokens. It's advanced autocomplete trained on internet-scale text.

**Q: What are the 3 stages of training an LLM?**
A: (1) Pre-training: learn language patterns from massive text, (2) Fine-tuning: specialize behavior on specific tasks, (3) RLHF: align with human values using human feedback rankings.

**Q: What is an embedding?**
A: A list of numbers (vector) that represents the MEANING of a word/token. Similar words have similar embeddings (close together in vector space).

**Q: How does RAG reduce hallucination?**
A: Retrieve relevant documents first, add them to the prompt as context, then generate an answer based on the retrieved evidence instead of the model's potentially inaccurate training data.

**Q: What does temperature control?**
A: Randomness in token selection. Low (0) = always picks most likely word (deterministic). High (1+) = picks from wider range (creative but less reliable).

**Q: What's the difference between a base model and an instruct model?**
A: A base model is a raw text predictor (might ignore your question and just continue the text). An instruct model has been fine-tuned and RLHF-trained to follow instructions and be helpful (ChatGPT, Claude).
