import { useCallback, useRef, useState, useMemo } from 'react';
import { COMPONENT_TYPES, CONNECTION_RULES } from '../../lib/problems/component-types';
import { usePlaygroundStore } from '../../stores/playground-store';

export default function ComponentSidebar({ canvasRef }) {
  const [search, setSearch] = useState('');
  const ghostRef = useRef(null);

  const filteredTypes = useMemo(() => {
    const q = search.toLowerCase().trim();
    return Object.entries(COMPONENT_TYPES).filter(([key, t]) =>
      !q || t.name.toLowerCase().includes(q) || key.includes(q)
    );
  }, [search]);

  const handleMouseDown = useCallback((e, type) => {
    e.preventDefault();
    const t = COMPONENT_TYPES[type];
    const ghost = document.createElement('div');
    ghost.style.cssText = `position:fixed;pointer-events:none;z-index:1000;padding:5px 10px;border-radius:7px;font-size:13px;font-weight:600;opacity:0.85;transform:translate(-50%,-50%);border:2px solid ${t.color};background:${t.fill};color:${t.color};box-shadow:0 4px 14px rgba(0,0,0,.15);left:${e.clientX}px;top:${e.clientY}px;`;
    ghost.textContent = `${t.icon} ${t.name}`;
    document.body.appendChild(ghost);
    ghostRef.current = ghost;

    const onMove = (ev) => {
      if (ghostRef.current) { ghostRef.current.style.left = ev.clientX + 'px'; ghostRef.current.style.top = ev.clientY + 'px'; }
    };
    const onUp = (ev) => {
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
      if (ghostRef.current) { ghostRef.current.remove(); ghostRef.current = null; }
      if (canvasRef.current) {
        const r = canvasRef.current.getBoundingClientRect();
        if (ev.clientX >= r.left && ev.clientX <= r.right && ev.clientY >= r.top && ev.clientY <= r.bottom) {
          const store = usePlaygroundStore.getState();
          const sx = ev.clientX - r.left, sy = ev.clientY - r.top;
          const world = canvasRef.current.screenToWorld
            ? canvasRef.current.screenToWorld(sx, sy)
            : { x: sx, y: sy };
          store.addComponent(type, world.x - t.w / 2, world.y - t.h / 2);
        }
      }
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  }, [canvasRef]);

  const handleDelete = useCallback(() => {
    const state = usePlaygroundStore.getState();
    if (state.selectedCompId) state.removeComponent(state.selectedCompId);
    else if (state.selectedConnId) state.removeConnection(state.selectedConnId);
  }, []);

  const handleFitAll = useCallback(() => {
    if (canvasRef.current) canvasRef.current.dispatchEvent(new CustomEvent('fit-all'));
  }, [canvasRef]);

  return (
    <div className="dc-comp-sidebar">
      <div className="dc-comp-sidebar__search">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
          <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
        </svg>
        <input type="text" placeholder="Search components..." value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      <div className="dc-comp-sidebar__grid">
        {filteredTypes.map(([key, t]) => (
          <div key={key} className="dc-comp-tile" onMouseDown={(e) => handleMouseDown(e, key)} title={`${t.name} — drag to canvas`}>
            <span className="dc-comp-tile__icon">{t.icon}</span>
            <span className="dc-comp-tile__name">{t.name}</span>
          </div>
        ))}
        {filteredTypes.length === 0 && (
          <div className="dc-comp-sidebar__no-results">No match</div>
        )}
      </div>

      <div className="dc-comp-sidebar__tools">
        <button onClick={handleDelete} className="dc-btn dc-btn--outline dc-btn--xs" style={{ flex: 1 }} title="Delete selected (Del)">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
        <button onClick={handleFitAll} className="dc-btn dc-btn--outline dc-btn--xs" style={{ flex: 1 }} title="Fit all (F)">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg>
        </button>
      </div>
    </div>
  );
}
