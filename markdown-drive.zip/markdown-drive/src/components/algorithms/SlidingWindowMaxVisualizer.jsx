import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(nums, k) {
  const steps = [];
  const dq = [];
  for (let i = 0; i < nums.length; i++) {
    while (dq.length && dq[0] <= i - k) {
      dq.shift();
      steps.push({ type: 'shrink', nums: [...nums], dq: [...dq], i, k, window: { start: Math.max(0, i - k + 1), end: i }, title: 'Shrink deque (out of window)' });
    }
    while (dq.length && nums[dq.at(-1)] <= nums[i]) {
      dq.pop();
      steps.push({ type: 'pop-smaller', nums: [...nums], dq: [...dq], i, k, window: { start: Math.max(0, i - k + 1), end: i }, title: 'Pop ≤ current from back' });
    }
    dq.push(i);
    steps.push({ type: 'push-index', nums: [...nums], dq: [...dq], i, k, window: { start: Math.max(0, i - k + 1), end: i }, title: 'Push index, deque stores max candidates' });
    if (i >= k - 1) {
      steps.push({
        type: 'max-out',
        nums: [...nums],
        dq: [...dq],
        i,
        k,
        window: { start: i - k + 1, end: i },
        maxVal: nums[dq[0]],
        title: `Window max = nums[${dq[0]}] = ${nums[dq[0]]}`,
      });
    }
  }
  steps.push({ type: 'done', nums, dq: [], k, window: null, title: '✓ Sliding window max' });
  return steps;
}

export default function SlidingWindowMaxVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const nums = [1, 3, -1, -3, 5, 3, 6, 7];
    const k = 3;
    const steps = generateSteps(nums, k);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Window size ${k}` });
    const s0 = steps[0];
    canvasRef.current?.setState({
      cells: s0.nums.map(String),
      colors: {},
      window: s0.window,
      title: s0.title,
      pointers: Object.fromEntries((s0.dq || []).map((idx, p) => [`d${p}`, idx])),
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    (step.dq || []).forEach((idx) => {
      colors[idx] = 'compare';
    });
    if (step.window) {
      for (let j = step.window.start; j <= step.window.end; j++) colors[j] = colors[j] || 'active';
    }
    if (step.type === 'max-out' && step.dq?.length) colors[step.dq[0]] = 'sorted';
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.title || step.type });
    const ptrs = {};
    (step.dq || []).forEach((idx, p) => {
      ptrs[`d${p}`] = idx;
    });
    canvasRef.current?.setState({
      cells: step.nums.map(String),
      colors,
      window: step.window || undefined,
      title: step.title,
      pointers: ptrs,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
