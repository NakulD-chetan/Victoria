import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import AuthGate from '../components/AuthGate';

/*
 * InviteAccept — handles `/invite/:token`.
 *
 * Flow:
 *   1. Look up the invite (anon read is allowed for pending tokens via
 *      a dedicated RLS policy on a public RPC, see future hardening).
 *      Today: anonymous users see "sign in to accept" + AuthGate.
 *   2. After sign-in, call the SQL function accept_invite(token).
 *   3. On success, redirect into the vault (?vault=<id> on /notes).
 */

function tokenFromPath() {
  const match = window.location.pathname.match(/\/invite\/([A-Za-z0-9_-]+)/);
  return match ? match[1] : null;
}

export default function InviteAccept() {
  const { user, loading } = useAuth();
  const [token] = useState(() => tokenFromPath());
  const [state, setState] = useState('idle'); // idle | accepting | done | error
  const [error, setError] = useState('');
  const [vaultId, setVaultId] = useState(null);

  useEffect(() => {
    if (loading || !user || !token || state !== 'idle') return;
    (async () => {
      setState('accepting');
      const { data, error: err } = await supabase.rpc('accept_invite', { p_token: token });
      if (err) {
        setError(err.message || 'Could not accept invite');
        setState('error');
        return;
      }
      setVaultId(data);
      setState('done');
      /* Bounce into the notes app for the new vault. */
      setTimeout(() => {
        window.location.href = `/notes?vault=${encodeURIComponent(data)}`;
      }, 800);
    })();
  }, [loading, user, token, state]);

  if (!token) {
    return (
      <div className="auth">
        <div className="auth__card">
          <h1 className="auth__title">Invalid invite</h1>
          <p className="auth__subtitle">The link you followed does not contain a valid token.</p>
        </div>
      </div>
    );
  }

  if (loading || (!user && state === 'idle')) {
    return (
      <AuthGate>
        {/* When AuthGate's child renders, the user is signed in and the
            effect above will fire next render. */}
        <div className="auth">
          <div className="auth__card">
            <div className="auth__spinner" />
            <p className="auth__subtitle">Checking your invite…</p>
          </div>
        </div>
      </AuthGate>
    );
  }

  return (
    <div className="auth">
      <div className="auth__card">
        {state === 'accepting' && (
          <>
            <div className="auth__spinner" />
            <p className="auth__subtitle">Accepting your invite…</p>
          </>
        )}
        {state === 'done' && (
          <>
            <h1 className="auth__title">You&rsquo;re in!</h1>
            <p className="auth__subtitle">Redirecting you into the shared vault…</p>
          </>
        )}
        {state === 'error' && (
          <>
            <h1 className="auth__title">Couldn&rsquo;t accept invite</h1>
            <p className="auth__error">{error}</p>
            <button className="auth__submit" onClick={() => { window.location.href = '/'; }}>
              Back to InkDrop
            </button>
          </>
        )}
        {vaultId && state === 'done' && (
          <p className="auth__hint" style={{ marginTop: 8 }}>Vault id: {vaultId}</p>
        )}
      </div>
    </div>
  );
}
