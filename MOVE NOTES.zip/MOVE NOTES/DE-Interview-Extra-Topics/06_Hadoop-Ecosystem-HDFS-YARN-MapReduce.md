# 06 — Hadoop Ecosystem (HDFS, YARN, MapReduce)

> **One-line:** Hadoop was the **original big data framework** — HDFS for distributed storage, YARN for resource management, MapReduce for processing — and understanding it is still **foundational knowledge** asked in DE interviews.

---

## 1. Why Hadoop Is Still Asked in 2026

| Reason | Detail |
|--------|--------|
| **Legacy systems** | Many enterprises still run Hadoop clusters (banks, telecom, govt) |
| **Foundation** | Spark, Hive, HBase, Kafka — all evolved **from** or **alongside** Hadoop |
| **Concepts transfer** | Distributed storage, fault tolerance, data locality → same ideas in modern tools |
| **Interview filter** | Shows you understand **fundamentals**, not just managed cloud services |

---

## 2. Hadoop Core Components

```
┌────────────────── Hadoop Ecosystem ──────────────────┐
│                                                       │
│  ┌──────────────────────────────────────────────────┐ │
│  │              APPLICATIONS / TOOLS                 │ │
│  │  Hive (SQL) │ Pig │ HBase │ Spark │ Sqoop │ ...  │ │
│  └──────────────────────┬───────────────────────────┘ │
│                         │                             │
│  ┌──────────────────────┴───────────────────────────┐ │
│  │              YARN (Resource Manager)              │ │
│  │   Manages CPU, memory across cluster              │ │
│  └──────────────────────┬───────────────────────────┘ │
│                         │                             │
│  ┌──────────────────────┴───────────────────────────┐ │
│  │              HDFS (Storage)                       │ │
│  │   Distributed file system across commodity HW     │ │
│  └──────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────┘
```

---

## 3. HDFS — Hadoop Distributed File System

### How HDFS Works

```
                    ┌─────────────┐
                    │  NameNode   │  (Master)
                    │  - Metadata │
                    │  - File→Block│
                    │    mapping  │
                    └──────┬──────┘
                           │
            ┌──────────────┼──────────────┐
            │              │              │
    ┌───────┴──────┐ ┌────┴───────┐ ┌────┴───────┐
    │ DataNode 1   │ │ DataNode 2 │ │ DataNode 3 │
    │ Block A      │ │ Block A    │ │ Block B    │
    │ Block C      │ │ Block B    │ │ Block A    │
    └──────────────┘ └────────────┘ └────────────┘
    
File "orders.csv" → split into blocks (128MB each)
Each block replicated 3x across different DataNodes
```

### HDFS Key Concepts

| Concept | Detail |
|---------|--------|
| **Block size** | Default 128MB (was 64MB in Hadoop 1.x) — large to reduce metadata overhead |
| **Replication factor** | Default 3 — each block stored on 3 different DataNodes |
| **NameNode** | Master — stores metadata (file→block mapping, permissions) — single point of failure |
| **Secondary NameNode** | NOT a failover — periodically merges edit logs with fsimage (checkpoint) |
| **DataNode** | Workers — store actual data blocks, send heartbeats to NameNode |
| **Rack awareness** | Replicas placed across racks for fault tolerance |
| **Write-once** | Files are immutable after creation (append supported but no random writes) |

### HDFS Commands

| Command | Purpose |
|---------|---------|
| `hdfs dfs -ls /data/` | List files |
| `hdfs dfs -put local.csv /data/` | Upload file to HDFS |
| `hdfs dfs -get /data/file.csv .` | Download from HDFS |
| `hdfs dfs -cat /data/file.csv` | Read file content |
| `hdfs dfs -mkdir /data/raw/` | Create directory |
| `hdfs dfs -rm -r /data/old/` | Delete recursively |

---

## 4. YARN — Yet Another Resource Negotiator

### Why YARN Exists

Hadoop 1.x: MapReduce handled **both** processing and resource management → bottleneck.
Hadoop 2.x: YARN **separates** resource management from processing → any engine (Spark, Flink, MapReduce) can use the cluster.

### YARN Architecture

```
┌─────────────────┐
│ ResourceManager  │  (Master — one per cluster)
│ - Scheduler      │  Allocates resources
│ - App Manager    │  Manages application lifecycles
└────────┬────────┘
         │
    ┌────┴──────────────────┐
    │                       │
┌───┴──────────┐    ┌──────┴───────┐
│ NodeManager 1 │    │ NodeManager 2│  (One per node)
│  Container A  │    │  Container C │  Report resources
│  Container B  │    │  Container D │  Run containers
└──────────────┘    └──────────────┘
```

| Component | Role |
|-----------|------|
| **ResourceManager** | Central authority — allocates cluster resources |
| **NodeManager** | Per-node agent — launches/monitors containers |
| **Container** | Allocated resources (CPU + memory) for a task |
| **ApplicationMaster** | Per-application coordinator — requests containers from RM, monitors tasks |

### YARN Job Submission Flow

```
1. Client submits app to ResourceManager
2. RM launches ApplicationMaster in a container
3. AM requests containers from RM for tasks
4. RM allocates containers on NodeManagers
5. AM launches tasks in containers
6. Tasks execute, report to AM
7. AM reports completion to RM, releases resources
```

---

## 5. MapReduce — The Original Processing Framework

### MapReduce Phases

```
Input Data
    │
    ▼
┌──────────┐
│   MAP    │  → Transform each record → emit (key, value) pairs
└──────────┘
    │
    ▼
┌──────────┐
│ SHUFFLE  │  → Group all values by key, sort, transfer across network
│ & SORT   │
└──────────┘
    │
    ▼
┌──────────┐
│  REDUCE  │  → Aggregate values per key → produce output
└──────────┘
    │
    ▼
Output Data
```

### Classic Example: Word Count

```
Input:  "hello world hello hadoop"

MAP Phase:
  Mapper 1: "hello world"  → (hello, 1), (world, 1)
  Mapper 2: "hello hadoop" → (hello, 1), (hadoop, 1)

SHUFFLE & SORT:
  (hadoop, [1])
  (hello, [1, 1])
  (world, [1])

REDUCE Phase:
  (hadoop, 1)
  (hello, 2)
  (world, 1)
```

### MapReduce vs Spark — Why Spark Won

| Dimension | MapReduce | Spark |
|-----------|-----------|-------|
| **Processing** | Disk-based (read/write HDFS between stages) | In-memory (RDDs/DataFrames cached) |
| **Speed** | Slow (disk I/O bottleneck) | 10-100x faster |
| **Ease of use** | Verbose Java code | Concise Python/Scala/SQL |
| **Iteration** | Each iteration = full disk read/write cycle | Cache intermediate results in memory |
| **Streaming** | Not native | Structured Streaming built-in |
| **ML** | Mahout (limited) | MLlib (rich) |

**Interview line:** "MapReduce writes intermediate results to **disk** after every stage. Spark keeps them in **memory** — that's why Spark is 10-100x faster for iterative and interactive workloads."

---

## 6. Key Hadoop Ecosystem Tools

| Tool | Purpose | Modern Equivalent |
|------|---------|-------------------|
| **Hive** | SQL on Hadoop (translates SQL → MapReduce/Tez/Spark) | Spark SQL, Trino, Presto |
| **HBase** | Wide-column NoSQL on HDFS | Cassandra, DynamoDB |
| **Sqoop** | Bulk data transfer between RDBMS ↔ HDFS | Spark JDBC, Airbyte, Fivetran |
| **Flume** | Log ingestion to HDFS | Kafka, Fluentd, Logstash |
| **Oozie** | Workflow scheduler for Hadoop jobs | Airflow, Prefect, Dagster |
| **Pig** | Scripting language for data transformation | Spark, dbt |
| **Tez** | Optimized execution engine (replaced MapReduce for Hive) | Spark |
| **ZooKeeper** | Distributed coordination service | etcd (K8s), still used by Kafka/HBase |

---

## 7. HDFS vs Cloud Object Storage

| Dimension | HDFS | Cloud Object Store (S3/ADLS/GCS) |
|-----------|------|----------------------------------|
| **Management** | Self-managed cluster | Fully managed, serverless |
| **Cost** | Expensive (always-on servers) | Pay-per-use, cheap storage |
| **Scalability** | Add nodes manually | Virtually unlimited |
| **Data locality** | Compute near data (same node) | Compute and storage decoupled |
| **Fault tolerance** | 3x replication | 11 nines durability (built-in) |
| **Performance** | Fast local reads | Network latency (but caching helps) |

**Interview line:** "The industry moved from HDFS to cloud object storage because **decoupled storage** is cheaper and scales independently. But HDFS concepts (blocks, replication, fault tolerance) are the **foundation**."

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "What is HDFS?" | Distributed file system — files split into 128MB blocks, replicated 3x across DataNodes |
| "What does NameNode do?" | Stores metadata (file→block mapping), doesn't store actual data |
| "What if NameNode fails?" | Single point of failure in Hadoop 1. HA NameNode (active/standby) in Hadoop 2 |
| "What is YARN?" | Resource manager — separates resource allocation from processing framework |
| "Explain MapReduce" | Map (transform) → Shuffle & Sort (group by key) → Reduce (aggregate) |
| "Why is Spark faster than MapReduce?" | In-memory processing vs disk I/O between stages |
| "What is data locality in Hadoop?" | Move compute to data (run task on node that has the block) → reduces network transfer |
| "HDFS vs S3?" | HDFS: self-managed, data locality. S3: managed, cheap, decoupled, industry standard now |

---

## Key Takeaways

- **Hadoop** = HDFS (storage) + YARN (resource management) + MapReduce (processing).
- **HDFS**: files → 128MB blocks → 3x replicated across DataNodes. NameNode = metadata master.
- **YARN**: separates resource management from processing — enables Spark/Flink on Hadoop clusters.
- **MapReduce**: Map → Shuffle & Sort → Reduce. Slow because of **disk I/O between stages**.
- **Spark replaced MapReduce** for processing but often still uses HDFS/YARN underneath (in legacy).
- Modern world: **cloud object storage** (S3) replaced HDFS, **Kubernetes** replaced YARN.
- Still asked because **concepts transfer**: distributed storage, fault tolerance, data locality.

---
