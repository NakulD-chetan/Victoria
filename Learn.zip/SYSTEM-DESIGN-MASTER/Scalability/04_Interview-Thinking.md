# Scalability — Interview Thinking

> **Permanent Recall:** When asked "how would you scale this?" — start simple, identify the bottleneck, propose a targeted solution, then discuss trade-offs. Never jump to sharding first. Show you think in layers: app tier → cache → database. Demonstrate back-of-envelope estimation. FAANG wants to see structured thinking and awareness of cost, consistency, and complexity.

---

## How to Discuss Scalability in Interviews

**Structure your answer:**

1. **Clarify requirements** — "What's our target? 1K, 10K, or 1M RPS? What's read vs write ratio?"
2. **Start with baseline** — "Assume single server handles ~1K RPS. For 10K we need ~10 servers behind a load balancer."
3. **Identify bottleneck** — "Likely the database next. We'd add read replicas for reads, or sharding for writes."
4. **Propose solution** — Draw the architecture; explain each component's role
5. **Discuss trade-offs** — "Read replicas give eventual consistency. Sharding adds operational complexity."

> **FAANG Tip:** Say "Let me start with a simple design and then scale it" — this shows maturity. Jumping straight to distributed systems can backfire if the interviewer wants to see your reasoning.

---

## The Scaling Conversation Flow

```
Interviewer: "How would you scale this to 1M users?"
                    |
                    v
You: "First, what's our load? 1M users — are they concurrent? Let's say 10% active,
     100K concurrent. At ~1 request/min each, that's ~1.6K RPS. One server can
     handle that for a simple API. If each request does 2–3 DB queries, we might
     need a cache. Let me draw..."
                    |
                    v
[Draw: Client → LB → App servers → Cache → DB]
                    |
                    v
You: "If we grow to 100K RPS, the DB becomes the bottleneck. I'd add read replicas
     for reads, and consider sharding if writes dominate. Let me explain the trade-offs..."
```

---

## What to Say When Asked "How Would You Scale This?"

**Opening (30 seconds):**

> "I'll start with a single-server baseline, then scale out the bottleneck. For a typical web app, the order is: add more app servers behind a load balancer, then cache, then read replicas, then sharding for writes. I want to understand our target load first — that drives which of these we need."

**If they give numbers (e.g., 100K RPS):**

> "At 100K RPS, we need roughly 100 app servers if each handles ~1K. The database would be the next concern — 100K queries per second is a lot. I'd add a caching layer first to reduce DB load, then read replicas. If writes are heavy, we'd look at sharding."

**If they ask about 1M users:**

> "1M users doesn't mean 1M RPS. Let me estimate: maybe 10% active, 1 request every few minutes → on the order of 1K–10K RPS. That's manageable with a few servers and a cache. If we're talking 1M concurrent users, that's a different scale — we'd need significant infrastructure."

---

## Demonstrating Scaling Knowledge at Different Levels

| Level | What to Show |
|-------|--------------|
| **Junior** | Know vertical vs horizontal; can add more servers; mention load balancer |
| **Mid** | Draw LB + app + cache + DB; explain read replicas; know when to cache |
| **Senior** | Identify bottleneck first; discuss sharding trade-offs; capacity planning; cost |
| **Staff+** | Multi-region; consistency vs availability; operational runbooks; failure modes |

---

## How to Estimate If Current Design Can Handle Load

**Back-of-envelope formula:**

```
Required app servers ≈ Target RPS / Per-server capacity
Per-server capacity ≈ 1,000 (simple API) to 500 (DB-heavy)

Example: 50K RPS, simple API
  50,000 / 1,000 = 50 app servers (with headroom, maybe 60–70)
```

**Database estimate:**

```
DB queries/sec ≈ RPS × queries per request
If 50K RPS × 2 queries = 100K QPS
Single DB: ~10K QPS max → need 10 read replicas for reads,
or sharding if writes are significant
```

---

## Common Follow-Up Questions and Answers

| Question | Strong Answer |
|----------|---------------|
| "What's the bottleneck?" | "I'd profile first. Typically: app CPU, then DB, then network. For our design, the DB is likely the bottleneck once we scale app servers." |
| "Why not shard from the start?" | "Sharding adds complexity — rebalancing, cross-shard queries, operational overhead. We should exhaust replicas and caching first. Shard when a single DB can't handle write throughput or data volume." |
| "How do you handle cache invalidation?" | "Cache-aside with TTL for simplicity. On write, invalidate the key. For harder cases: write-through or event-driven invalidation. It's a known hard problem — I'd keep it simple initially." |
| "What about consistency?" | "Read replicas are eventually consistent — replication lag. For read-after-write, route to primary. For strong consistency, we'd need to accept slower reads or different architecture." |
| "How would you scale to 1M RPS?" | "App tier: hundreds of servers, multi-region. DB: sharded, each shard with replicas. Cache: distributed Redis cluster. CDN for static. Async queues for heavy work. Would need to design for this from scratch in some areas." |

---

## Red Flags to Avoid

- **Don't:** "We'll use microservices and Kubernetes" (without explaining why)
- **Don't:** "Sharding from day one" (over-engineering)
- **Don't:** Ignore the database when discussing scale
- **Don't:** Forget cost ("just add more servers" without considering efficiency)
- **Don't:** Assume infinite scalability — discuss limits

---

## Interview Script: Scaling Question

1. *"What's our target? Users, RPS, or data size?"*
2. *"Let me estimate. [Do back-of-envelope.]"*
3. *"I'll start with: Client → LB → App servers → Cache → DB."*
4. *"For this scale, we need [X] app servers. The DB will likely be the bottleneck next."*
5. *"I'd add read replicas for reads. If writes scale, we'd look at sharding."*
6. *"Trade-off: replicas have replication lag. Sharding adds operational complexity."*
7. *"We'd monitor and iterate — scale based on actual bottlenecks."*

---

## Quick Memory Card

```
FLOW:        Clarify → Baseline → Bottleneck → Solution → Trade-offs
OPENING:     "Start simple, then scale the bottleneck"
LEVELS:      Junior=LB; Mid=cache+replicas; Senior=sharding+cost
ESTIMATE:    Servers ≈ RPS/1000; DB = next bottleneck
FOLLOW-UP:   Bottleneck? Why not shard? Cache invalidation? Consistency?
RED FLAGS:   Microservices buzzwords; shard day one; ignore DB
```

---

**Next: [[05_Common-Mistakes]]**
