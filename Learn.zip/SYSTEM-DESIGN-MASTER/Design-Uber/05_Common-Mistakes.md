# Design Uber — Common Mistakes

> **Permanent Recall:** Top mistakes: not discussing geospatial indexing (just saying "find nearby"), using SQL for location queries, not handling driver location updates at scale, synchronous matching, ignoring surge pricing, not discussing real-time tracking, single-region design for global service. Avoid these to pass ride-sharing system design.

---

## Mistake 1: Not Discussing Geospatial Indexing

**What happens:** Candidate says "we'll find nearby drivers" but doesn't explain how. Interviewer expects you to know this is the hard part.

| Wrong | Right |
|-------|-------|
| "We query drivers where lat/lng is close" | "We use Geohash—encode lat/lng so nearby points share a prefix; lookup is O(1) per cell" |
| "Database with lat/lng columns" | "Geospatial index: Geohash, QuadTree, or Redis GEO" |

> **FAANG Tip:** Geospatial indexing is THE differentiator for Uber. Mention Geohash or QuadTree in the first 5 minutes.

---

## Mistake 2: Using SQL for Location Queries

**What happens:** `SELECT * FROM drivers WHERE lat BETWEEN ? AND ?` — full table scan; 15M rows; doesn't scale.

**Fix:**
- Use **Geohash** → lookup by cell; O(1) or O(log n)
- Use **Redis GEO** (GEORADIUS) — built for this
- Use **QuadTree** or **S2** — hierarchical, efficient range queries

---

## Mistake 3: Not Handling Driver Location Updates at Scale

**What happens:** 15M drivers × 0.25 Hz = 3.75M writes/s. Writing every update to PostgreSQL = bottleneck.

**Fix:**
- In-memory geospatial store (Redis GEO, custom QuadTree)
- Persist asynchronously for analytics
- Shard by geographic region (NYC servers for NYC drivers)
- Batch or stream; don't block on disk

---

## Mistake 4: Synchronous Matching

**What happens:** Send request to 5 drivers; wait for all 5 to respond. Rider waits 30+ seconds; poor UX.

**Fix:**
- **First-accept-wins:** First driver to accept gets the ride
- Others get "ride taken" notification
- Set timeout (15–30s); expand search if no accept
- Reduces rider wait time significantly

---

## Mistake 5: Ignoring Surge Pricing

**What happens:** Interviewer asks "how does pricing work?" — you only mention base fare. Surge is a core Uber feature.

**Fix:**
- Supply/demand ratio per geohash region
- Multiplier (1.0–3.0×) when demand > supply
- Recalculate every 5–10 minutes
- Show rider before they confirm
- Mention fairness (cap) and transparency

---

## Mistake 6: Not Discussing Real-Time Tracking

**What happens:** Rider sees "driver is 5 min away" — how? No answer. Tracking is expected.

**Fix:**
- WebSocket for real-time push
- Driver location every 4s → push to rider
- Fallback: long polling if WebSocket blocked
- ETA updates as driver moves

---

## Mistake 7: Single Region Design for Global Service

**What happens:** One cluster for NYC, SF, London, Mumbai — latency and compliance issues.

**Fix:**
- Partition by region/city
- Each region has its own Location Service shard
- Cross-region: rider in NYC doesn't need London drivers
- Multi-region deployment for availability

---

## Mistake 8: No Trip State Machine

**What happens:** "Trip goes from request to done" — vague. State transitions matter for idempotency and edge cases.

**Fix:**
- Explicit states: REQUESTED → MATCHED → DRIVER_EN_ROUTE → IN_PROGRESS → COMPLETED
- CANCELLED from REQUESTED or MATCHED
- Each transition is an event; enables auditing and retries

---

## Mistake 9: Ignoring Driver at Geohash Boundary

**What happens:** Driver sits on cell edge; visible in one cell but not the adjacent one rider queries. Rider doesn't see nearby driver.

**Fix:**
- Query rider's cell + 8 adjacent cells (3×3 grid)
- Or: store driver in multiple cells if near boundary
- Redis GEO handles this with radius query (GEORADIUS)

---

## Mistake 10: No ETA Discussion

**What happens:** "Driver is 5 min away" — how calculated? Straight line? Ignores traffic?

**Fix:**
- Graph-based routing (roads, not Euclidean)
- Historical travel time for time-of-day
- Real-time traffic data
- Mention trade-off: accuracy vs. compute cost

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| No geo indexing | Red flag | Geohash, QuadTree, Redis GEO |
| SQL for location | Doesn't scale | Geospatial index |
| No location scale handling | 3.75M/s bottleneck | In-memory; shard by region |
| Sync matching | Poor UX | First-accept-wins |
| No surge | Missing feature | Supply/demand per region |
| No real-time tracking | Incomplete | WebSocket; 4s push |
| Single region | Latency, scale | Partition by geography |
| No state machine | Vague lifecycle | Explicit states |
| Geohash boundary | Miss drivers | Query adjacent cells |
| No ETA | Incomplete | Graph + historical + traffic |

---

## Interviewer Signals

When interviewer says "How do you find nearby drivers?" → Mistake 1, 2.
When they ask "How do you handle millions of location updates?" → Mistake 3.
When they mention "peak hour" or "demand" → Mistake 5 (surge).
When they ask "How does the rider see the driver on the map?" → Mistake 6.

---

## 30-SECOND REVISION BOX

```
1. Geospatial index — Geohash, not SQL
2. Location scale — in-memory, shard
3. Matching — first-accept-wins
4. Surge — supply/demand per region
5. Tracking — WebSocket
6. Multi-region — partition by geography
7. Trip states — explicit state machine
8. Boundaries — query adjacent cells
9. ETA — graph + historical
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
