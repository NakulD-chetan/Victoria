# Unbounded Table & Incremental Execution

This note explains **how** a standing query over an infinite logical relation becomes **concrete Spark jobs** over finite slices of data—without contradicting the batch DataFrame API.

---

## 1. Standing Query vs One-Shot Job

In batch, you build a **DAG** and run it **once** for an action.

In Structured Streaming, you build a **logical plan once**, but Spark **reevaluates** an **incremental physical plan** on every trigger for **only the delta** of input (and sometimes recomputes affected state).

```
Batch:
  Logical plan ──optimization──► Physical plan ──► ONE execution

Streaming:
  Logical plan ──optimization──► Incremental execution strategy
                                      │
                         each trigger └──► Job over new micro-batch (+ state merge)
```

---

## 2. What “Incremental” Means

**Incremental execution** means: compute updates to the **result** from **new input** plus **existing operator state**, instead of scanning all historical input every time.

| Operator type | Incremental behavior (conceptual) |
| ------------- | ----------------------------------- |
| Stateless maps, filters, projections | Apply only to **new rows** in the micro-batch. |
| Aggregations with grouping keys | **Merge** new partial aggregates into **state** per key. |
| Windowed aggregations (event time) | Update only windows touched by new rows; drop late data per watermark rules. |
| Stream–stream joins | Maintain **state** for keys in join interval; expire per watermark. |

Not every query admits efficient incrementalization; some patterns require full recomputation of a slice—Spark’s engine chooses the **minimum work** consistent with semantics.

---

## 3. Result Table vs Physical Output

Structured Streaming distinguishes:

| Concept | Meaning |
| ------- | ------- |
| **Internal result table** | The evolving relation produced by your query **before** applying an output mode. |
| **Sink output** | What gets **written** each trigger—depends on **output mode** (Append / Update / Complete). |

The internal table can be **larger than what you emit**: for example, in **Append** mode, only **new, finalized** rows may be written even though intermediate state exists internally.

---

## 4. Lineage in Streaming

Batch lineage enables **replay** of lost partitions. Streaming adds **metadata lineage**:

- **Source offsets** — which input has been consumed.
- **Operator state** — intermediate aggregates, join buffers, etc.
- **Watermark** — how far event time has advanced for dropping late records.

On failure, recomputation must align **input replay** with **state restore** from checkpoint—otherwise duplicates or gaps appear at sinks.

---

## 5. Catalyst’s Role Per Trigger

Each micro-batch typically gets:

1. **Logical plan** for the query (same as batch).
2. **Incremental physical plan** that respects streaming-specific operators (stateful, watermark).
3. **Optimized execution** (predicate pushdown to sources where applicable, column pruning, etc.).

Thus streaming inherits **most** batch optimizations **within** each micro-batch, while **global** correctness is governed by streaming rules (output mode, watermarks, state).

---

## 6. End-to-End Mental Flow

```
Trigger fires
     │
     ▼
Determine available input range (offsets / files / poll)
     │
     ▼
Read delta as DataFrame batch(es)
     │
     ▼
Merge with restored state from checkpoint
     │
     ▼
Execute optimized plan; update state; advance watermark
     │
     ▼
Emit to sink per output mode; commit offsets atomically with checkpoint (sink-dependent)
```

---

## 7. Key Takeaways

1. **Unbounded input** is consumed as a sequence of **bounded deltas** per trigger.
2. **Incremental execution** minimizes work using **state** and streaming-aware physical plans.
3. **Result vs output**: internal tables evolve continuously; sinks see **mode-filtered** writes.
4. **Catalyst optimizes each slice**, but **streaming semantics** (time, mode, checkpoint) define correctness across triggers.

---
