# Scalability — Edge Cases

> **Permanent Recall:** Scaling introduces edge cases: thundering herd on server restart, cold start problems, auto-scaling lag, database connection exhaustion, hot partitions in sharded systems, cache stampede during scale-up, session stickiness breaking, data migration during scaling, cross-region latency, and network bandwidth limits. Knowing these helps you design for failure and discuss trade-offs in FAANG interviews.

---

## Edge Case 1: Thundering Herd on Server Restart

**What:** All servers restart or new deploy. Caches are empty. First requests all miss cache → flood the database simultaneously.

```
[App 1] ──cache miss──┐
[App 2] ──cache miss──┼──→ [DB] overwhelmed
[App 3] ──cache miss──┘
```

**Mitigation:**
- **Staggered deployment** — roll out one instance at a time
- **Cache warming** — pre-populate cache before traffic cutover
- **Request coalescing** — one request fetches, others wait (e.g., singleflight pattern)
- **Progressive traffic shift** — canary 5% → 50% → 100%

---

## Edge Case 2: Cold Start Problems

**What:** New instances (or serverless functions) start cold. First request pays initialization cost (JVM warm-up, DB connection setup, etc.). Latency spike for cold requests.

**Mitigation:**
- **Keep-alive / minimum instances** — don't scale to zero if latency matters
- **Warm-up requests** — health checks or scheduled pings to keep instances warm
- **Pre-provision** — scale up before predicted load (e.g., before campaign)
- **Serverless:** Provisioned concurrency for critical paths

---

## Edge Case 3: Auto-Scaling Lag

**What:** Traffic spikes. Auto-scaler needs 1–5 minutes to detect and add instances. During that window, existing instances are overloaded → high latency or errors.

**Mitigation:**
- **Predictive scaling** — scale before known events (e.g., product launch)
- **Aggressive scale-up, conservative scale-down** — scale out fast, scale in slowly
- **Queue-based scaling** — scale on queue depth, not just CPU
- **Over-provision for known peaks** — keep buffer during Black Friday

---

## Edge Case 4: Database Connection Exhaustion

**What:** Each app instance has a connection pool (e.g., 20 connections). 100 instances × 20 = 2,000 connections. DB supports 500. Connections refused or queued → cascading failures.

```
[App 1] 20 conn ─┐
[App 2] 20 conn ─┼──→ [DB] max 500 connections
...              │
[App 100] 20 conn┘
```

**Mitigation:**
- **Connection pooling** — PgBouncer, ProxySQL; pool at proxy level
- **Reduce connections per app** — smaller pool; share across instances
- **Read replicas** — spread reads across replicas (each has its own pool)
- **Limit total instances** — cap app count or use serverless with managed pooling

---

## Edge Case 5: Hot Partition in Sharded Systems

**What:** One shard gets disproportionate load. Example: `user_id` sharding, but one celebrity has millions of followers → their shard is hot. Other shards underutilized.

**Mitigation:**
- **Sub-partition** — e.g., `(user_id, post_id)` or add random suffix
- **Consistent hashing with virtual nodes** — spread load more evenly
- **Separate hot entities** — put celebrities on dedicated shards
- **Rate limiting** — protect hot shards from burst

---

## Edge Case 6: Cache Stampede During Scale-Up

**What:** Popular key expires. Thousands of requests miss cache simultaneously. All try to recompute → thundering herd to DB or compute.

**Mitigation:**
- **Singleflight** — first request computes; others wait for result
- **Probabilistic early expiration** — expire slightly before TTL, spread load
- **Background refresh** — refresh before expiry; serve stale if refresh delayed
- **Lock per key** — only one process recomputes; others wait

---

## Edge Case 7: Session Stickiness Breaking

**What:** Load balancer uses sticky sessions. Server dies → sessions on that server lost. Or scaling down removes server with active sessions.

**Mitigation:**
- **Stateless sessions** — store in Redis/DB; any server can serve
- **Sticky with fallback** — if sticky server unavailable, route to any; re-auth if needed
- **Short TTL** — reduce blast radius of lost sessions
- **Prefer stateless** — JWT or encrypted cookie; no server-side session

---

## Edge Case 8: Data Migration During Scaling

**What:** Adding shards requires moving data. Rebalancing. During migration: some data in old place, some in new. Queries may need to check both. Downtime or inconsistency risk.

**Mitigation:**
- **Dual-write during migration** — write to old and new; sync; switch read; stop old
- **Consistent hashing** — minimize keys that move when adding shards
- **Off-peak migration** — run during low traffic
- **Phased cutover** — migrate shard by shard; validate each

---

## Edge Case 9: Cross-Region Latency

**What:** Multi-region deployment. User in Asia, DB in US. Each request has 100–200 ms round-trip. Unacceptable for interactive apps.

**Mitigation:**
- **Regional read replicas** — read from nearby replica
- **Edge caching** — CDN, edge compute
- **Data locality** — put user data in their region when possible
- **Eventually consistent reads** — accept lag for cross-region reads

---

## Edge Case 10: Network Bandwidth Limits

**What:** Servers have limited NIC bandwidth. High throughput (video, large payloads) can saturate network before CPU.

**Mitigation:**
- **Compression** — gzip, Brotli for API responses
- **CDN** — offload static/media to edge
- **Chunked transfer** — stream instead of bulk
- **Bigger instances or multiple NICs** — when necessary

---

## Edge Case Summary Table

| Edge Case | Trigger | Mitigation |
|-----------|---------|------------|
| Thundering herd | Restart, cache empty | Stagger deploy, cache warm, singleflight |
| Cold start | New instances, scale from zero | Min instances, warm-up, provisioned concurrency |
| Auto-scale lag | Traffic spike | Predictive scaling, queue-based, over-provision |
| DB connection exhaustion | Too many app instances | Pooling proxy, read replicas, limit instances |
| Hot partition | Uneven shard load | Sub-partition, virtual nodes, separate hot keys |
| Cache stampede | Popular key expires | Singleflight, probabilistic expiry, background refresh |
| Stickiness breaking | Server death, scale down | Stateless sessions, Redis, JWT |
| Data migration | Shard rebalance | Dual-write, consistent hashing, phased cutover |
| Cross-region latency | User far from DB | Regional replicas, CDN, data locality |
| Bandwidth limits | High throughput | Compression, CDN, streaming |

---

## Quick Memory Card

```
THUNDERING:   Cache empty → stagger, warm, singleflight
COLD START:   Min instances, warm-up
SCALE LAG:    Predictive, queue-based scaling
CONN EXHAUST: Pool proxy, replicas
HOT PART:     Sub-partition, virtual nodes
STAMPEDE:     Singleflight, probabilistic expiry
STICKINESS:   Stateless, Redis, JWT
MIGRATION:    Dual-write, phased
CROSS-REG:    Regional replicas, CDN
BANDWIDTH:    Compress, CDN, stream
```

---

**Next: [[07_Tricks-and-Recognition]]**
