# Microservices Architecture — Concept

> **Permanent Recall:** Microservices = loosely coupled, independently deployable services, each owning its **domain**. Key patterns: **API Gateway** (routing, auth, rate limiting), **service discovery** (Consul, Eureka, K8s DNS), **service mesh** (Istio, Linkerd, Envoy sidecar), **database per service**, **Strangler Fig** migration. Inter-service: sync (REST/gRPC) vs async (message queues). Distributed transactions: **Saga** or **2PC**. Use **circuit breaker**, **BFF**, **sidecar**.

---

## Monolith vs Microservices — Detailed Comparison

| Aspect | Monolith | Microservices |
|--------|----------|---------------|
| **Deployment** | Single deploy; all or nothing | Independent deploy per service |
| **Scaling** | Scale whole app; vertical or duplicate entire app | Scale individual services; fine-grained |
| **Team structure** | Single team, shared codebase | Team per service; ownership |
| **Data management** | Shared DB; ACID transactions | DB per service; eventual consistency |
| **Communication** | In-process calls | Network calls (sync/async) |
| **Fault isolation** | One bug can crash whole app | Failure contained to one service |
| **Complexity** | Lower upfront; grows over time | Higher from start; operational overhead |

> **FAANG Tip:** Start with monolith; extract microservices when scaling, team size, or deploy frequency demand it.

---

## ASCII Microservices Architecture Diagram

```
    ┌─────────────────────────────────────────────────────────────────────┐
    │                         CLIENTS (Web, Mobile, API)                    │
    └────────────────────────────────┬────────────────────────────────────┘
                                      │
                                      ▼
    ┌─────────────────────────────────────────────────────────────────────┐
    │                      API GATEWAY (Kong, Zuul, AWS)                   │
    │              Routing │ Auth │ Rate Limit │ Request Aggregation       │
    └────────────────────────────────┬────────────────────────────────────┘
                                      │
        ┌─────────────────────────────┼─────────────────────────────┐
        ▼                             ▼                             ▼
┌───────────────┐           ┌───────────────┐           ┌───────────────┐
│ Service A     │           │ Service B     │           │ Service C     │
│ (User)        │◄─────────►│ (Order)       │◄─────────►│ (Payment)     │
│ DB A          │  REST/    │ DB B          │  Message  │ DB C          │
└───────────────┘  gRPC     └───────────────┘  Queue     └───────────────┘
        │                             │                             │
        └─────────────────────────────┼─────────────────────────────┘
                                      ▼
                            ┌───────────────────┐
                            │ Service Discovery │
                            │ (Consul, Eureka)  │
                            └───────────────────┘
```

---

## API Gateway Pattern

**Purpose:** Single entry point for clients; handles cross-cutting concerns.

| Responsibility | Description | Tools |
|----------------|-------------|-------|
| **Routing** | Path-based routing to backends | Kong, Zuul |
| **Authentication** | JWT validation, API key, OAuth | AWS API Gateway |
| **Rate limiting** | Per-client, per-endpoint limits | Kong plugins |
| **Request aggregation** | BFF-style; combine multiple backend calls | Custom / GraphQL |

**Tools:** Kong, Zuul (Netflix), AWS API Gateway, Nginx, Traefik.

---

## Service Discovery

| Type | How It Works | Pros | Cons | Tools |
|------|--------------|------|------|-------|
| **Client-side** | Client queries registry; picks instance | Lower latency; no extra hop | Logic in every client | Eureka, Consul |
| **Server-side** | LB/Proxy queries registry; client hits one endpoint | Simple clients | Extra hop; LB bottleneck | Consul, K8s DNS |

**Kubernetes DNS:** Each service gets `<service>.<namespace>.svc.cluster.local`; no separate registry needed.

---

## Service Mesh

**Sidecar proxy pattern:** Each service gets a proxy (Envoy, Linkerd) that handles mTLS, retries, timeouts, observability.

```
    ┌─────────────────┐         ┌─────────────────┐
    │   Service A      │         │   Service B      │
    │   ┌───────────┐  │         │   ┌───────────┐  │
    │   │  App      │  │         │   │  App      │  │
    │   └─────┬─────┘  │         │   └─────┬─────┘  │
    │         │        │         │         │        │
    │   ┌─────▼─────┐  │  mTLS   │   ┌─────▼─────┐  │
    │   │ Sidecar   │◄─┼─────────┼──►│ Sidecar   │  │
    │   │ (Envoy)   │  │         │   │ (Envoy)   │  │
    │   └───────────┘  │         │   └───────────┘  │
    └─────────────────┘         └─────────────────┘
```

**Tools:** Istio (control plane + Envoy), Linkerd (lightweight), Envoy (data plane only).

---

## Inter-Service Communication

| Type | Use Case | Pros | Cons |
|------|----------|------|------|
| **Sync (REST)** | Simple request-response | Easy, ubiquitous | Tight coupling; cascading failure |
| **Sync (gRPC)** | Internal, high-throughput | Binary, streaming, fast | Requires codegen, HTTP/2 |
| **Async (Message queue)** | Fire-and-forget, eventual consistency | Loose coupling, resilient | Complexity, ordering, idempotency |

**Rule:** Prefer async for non-critical path; sync when immediate response needed.

---

## Distributed Transactions

| Pattern | How | Use When |
|---------|-----|----------|
| **Saga** | Choreography or Orchestration; each step has compensating action | Multi-service workflow; eventual consistency OK |
| **2PC** | Coordinator; prepare → commit/abort | Strong consistency; few participants |

> **FAANG Tip:** Saga is preferred for microservices; 2PC rarely scales across many services.

---

## Key Patterns Summary

| Pattern | Purpose |
|---------|---------|
| **Strangler Fig** | Gradually replace monolith by routing new features to new services |
| **Database per service** | Each service owns its DB; no shared DB |
| **BFF (Backend for Frontend)** | Per-client API (mobile BFF, web BFF) |
| **Sidecar** | Deploy proxy/cache alongside service container |
| **Circuit breaker** | Stop calling failing service; fail fast; avoid cascade |

---

## 30-SECOND REVISION BOX

```
MONOLITH vs MICRO: Deploy, scale, team, data, fault isolation
API GATEWAY: Routing, auth, rate limit, aggregation
SERVICE DISCOVERY: Client-side (Eureka) vs server-side; K8s DNS
SERVICE MESH: Sidecar (Istio, Linkerd, Envoy); mTLS, retries
COMMUNICATION: Sync (REST/gRPC) vs Async (queues)
TRANSACTIONS: Saga (eventual) vs 2PC (strong)
PATTERNS: Strangler Fig, DB per service, BFF, circuit breaker
```

---

**Next: [[02_Mental-Model]]**
