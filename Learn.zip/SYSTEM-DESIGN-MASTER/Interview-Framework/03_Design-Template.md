# Interview Framework — Design Template

> **Permanent Recall:** The Master Template is a fill-in-the-blank framework that works for **any** system design question. Use it as a mental checklist. Never skip Step 1 (Requirements) or Step 5 (Wrap-up). Estimation (Step 2) is optional but impresses interviewers when done well.

---

## THE MASTER TEMPLATE

```
STEP 1: Requirements
├── Functional: [list 3–5 core features]
├── Non-functional: [latency, availability, consistency, scale]
├── Constraints: [read:write ratio, data size, user count]
└── Out of scope: [explicitly exclude]

STEP 2: Estimation
├── DAU: ___
├── QPS: ___
├── Peak QPS: ___
├── Storage/day: ___
├── Storage/5yr: ___
└── Bandwidth: ___

STEP 3: High-Level Design
├── [Draw components: Client → LB → App → Cache → DB → Queues → CDN]
├── API design: [key endpoints]
└── Data model: [key tables/collections]

STEP 4: Deep Dive
├── Component 1: [most critical component]
├── Component 2: [second most critical]
└── Trade-offs discussed: [list]

STEP 5: Wrap-up
├── Bottlenecks: [identified and addressed]
├── Monitoring: [key metrics]
└── Future: [improvements for scale]
```

---

## Step 1: Requirements — Detailed Checklist

| Category | Questions to Answer |
|----------|---------------------|
| **Functional** | What are the 3–5 core user-facing features? |
| **Non-functional** | Latency target? Availability (99.9%? 99.99%)? Consistency (strong vs eventual)? Scale (users, QPS)? |
| **Constraints** | Read:write ratio? Data size per entity? Retention? Geography? |
| **Out of scope** | What are we explicitly NOT building? |

---

## Step 2: Estimation — Back-of-Envelope Formulas

| Metric | Formula / Rule of Thumb |
|--------|-------------------------|
| **DAU** | Given or assume (e.g., 100M, 500M) |
| **QPS** | DAU × actions per user per day ÷ 86400 |
| **Peak QPS** | 2–3× average QPS |
| **Storage/day** | Records × size per record × writes per day |
| **Storage/5yr** | Storage/day × 365 × 5 (assume growth) |
| **Bandwidth** | QPS × request/response size |

> **FAANG Tip:** Estimation shows you think about scale. Even rough numbers ("~10K QPS, ~1TB/year") are better than skipping it.

---

## Step 3: High-Level Design — Component Checklist

| Component | When to Include |
|-----------|-----------------|
| **Load Balancer** | Almost always (multi-server) |
| **App Servers** | Always |
| **Cache (Redis)** | Read-heavy, hot data |
| **Database** | Persistent data |
| **Message Queue** | Async, decoupling, event-driven |
| **CDN** | Static assets, media, global users |
| **Object Storage** | Blobs, images, videos |
| **Search Index** | Full-text search (Elasticsearch) |
| **WebSocket Server** | Real-time (chat, notifications) |

---

## Worked Example 1: Design a URL Shortener

### STEP 1: Requirements

| Category | Content |
|----------|---------|
| **Functional** | Create short URL from long URL; redirect short→long; optional custom alias; optional expiry |
| **Non-functional** | Redirect <100ms p99; 99.9% availability; read-heavy (100:1) |
| **Constraints** | 100M URLs/month; 7-char short codes; long URL ≤2KB |
| **Out of scope** | Analytics dashboard, click fraud, custom domains |

### STEP 2: Estimation

| Metric | Value |
|--------|-------|
| DAU | 10M (assume) |
| Writes | 1M shorts/day → ~12 QPS write |
| Reads | 100M redirects/day → ~1.2K QPS read |
| Storage/day | 1M × 500B ≈ 500MB/day |
| Storage/5yr | ~1TB |
| Bandwidth | 1.2K × 500B ≈ 600KB/s read |

### STEP 3: High-Level Design

```
Client → LB → API Servers → Redis (cache) + KGS (key pool) → DB
```

**API:**
- `POST /shorten` — create short URL
- `GET /:shortCode` — redirect (302)

**Data model:**
- `url_mappings`: short_url, long_url, created_at, expires_at, user_id

### STEP 4: Deep Dive

- **Key generation:** KGS pre-generates keys; API pulls from pool. Trade-off: KGS adds complexity vs hash+collision retry.
- **Redirect flow:** Cache-aside; 302 for analytics. Trade-off: 301 vs 302 (caching, analytics).
- **Scalability:** Shard by short_url hash; cache hot URLs.

### STEP 5: Wrap-up

- **Bottleneck:** DB writes → KGS batches, connection pooling.
- **Monitoring:** Redirect latency p99, cache hit ratio, error rate.
- **Future:** Multi-region, CDN for redirect, analytics pipeline.

---

## Worked Example 2: Design Twitter (Brief)

### STEP 1: Requirements

| Category | Content |
|----------|---------|
| **Functional** | Post tweet; follow/unfollow; view timeline (home feed); view user profile |
| **Non-functional** | Feed <200ms p99; 99.9% availability; read-heavy (1000:1) |
| **Constraints** | 500M DAU; 500M tweets/day; 300B timeline reads/day |
| **Out of scope** | DMs, search, ads, trending |

### STEP 2: Estimation

| Metric | Value |
|--------|-------|
| DAU | 500M |
| Writes | 500M tweets/day → ~6K QPS |
| Reads | 300B timeline views/day → ~3.5M QPS |
| Storage/day | 500M × 1KB ≈ 500GB/day tweets |

### STEP 3: High-Level Design

```
Client → LB → API Servers → Fan-out Service + Cache → DB (tweets, follows, timelines)
                                    ↓
                            Message Queue (async fan-out)
```

**API:**
- `POST /tweets` — create tweet
- `GET /timeline` — get home feed (paginated)
- `GET /users/:id/tweets` — user timeline
- `POST /follow`, `DELETE /follow`

**Data model:**
- `tweets`: id, user_id, content, created_at
- `follows`: follower_id, followee_id
- `timelines`: user_id, tweet_ids (pre-computed for fan-out)

### STEP 4: Deep Dive

- **Fan-out:** Push (write-time) vs Pull (read-time). Push for celebrities; hybrid. Trade-off: write amplification vs read latency.
- **Timeline merge:** For pull, merge from followees' recent tweets; use heap. For push, read pre-computed timeline from cache.
- **Scale:** Shard tweets by user_id; cache timelines in Redis; fan-out workers consume queue.

### STEP 5: Wrap-up

- **Bottleneck:** Fan-out for celebrity (millions of followers) → dedicated pipeline, eventual consistency.
- **Monitoring:** Feed latency p99, fan-out lag, cache hit ratio.
- **Future:** Search index, trending, multi-region.

---

## Quick Reference Table

| Step | Time | Key Output |
|------|------|------------|
| 1. Requirements | ~5 min | Functional, non-functional, constraints, out of scope |
| 2. Estimation | ~2 min | DAU, QPS, storage, bandwidth |
| 3. High-Level | ~8 min | Components, API, data model |
| 4. Deep Dive | ~20 min | 1–2 components, trade-offs, what-ifs |
| 5. Wrap-up | ~5 min | Bottlenecks, monitoring, future |

---

## ASCII: Universal Component Diagram (Starting Point)

```
                    ┌─────────────┐
                    │   Clients   │
                    └──────┬──────┘
                           │
                    ┌──────▼──────┐
                    │ Load Balancer│
                    └──────┬──────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│  App Server 1 │  │  App Server 2 │  │  App Server N │
└───────┬───────┘  └───────┬───────┘  └───────┬───────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
┌───────────────┐  ┌───────────────┐  ┌───────────────┐
│    Cache      │  │ Message Queue │  │   Database    │
│  (Redis)      │  │ (Kafka/SQS)   │  │  (Primary +   │
│               │  │               │  │   Replicas)   │
└───────────────┘  └───────────────┘  └───────────────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
                    ┌──────▼──────┐
                    │    CDN      │  (optional)
                    └─────────────┘
```
