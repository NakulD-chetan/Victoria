import { useCallback, useEffect, useImperativeHandle, useRef, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const ACTS = [
  { id: 'A', s: 1, e: 3 },
  { id: 'B', s: 2, e: 5 },
  { id: 'C', s: 4, e: 6 },
  { id: 'D', s: 6, e: 7 },
  { id: 'E', s: 5, e: 8 },
  { id: 'F', s: 8, e: 9 },
];

function generateSteps() {
  const sorted = [...ACTS].sort((a, b) => a.e - b.e);
  const steps = [];
  steps.push({ type: 'sort', msg: 'Sort by finish time', order: sorted.map((x) => x.id), selected: [] });
  const picked = [];
  let lastEnd = -Infinity;
  for (const a of sorted) {
    steps.push({ type: 'consider', msg: `Consider ${a.id} [${a.s},${a.e}]`, current: a.id, selected: [...picked], lastEnd });
    if (a.s >= lastEnd) {
      picked.push(a.id);
      lastEnd = a.e;
      steps.push({ type: 'pick', msg: `Select ${a.id} (non-overlap)`, current: a.id, selected: [...picked], lastEnd });
    } else {
      steps.push({ type: 'skip', msg: `Skip ${a.id} (overlaps)`, current: a.id, selected: [...picked], lastEnd });
    }
  }
  steps.push({ type: 'done', msg: `Greedy set: ${picked.join(', ')}`, selected: [...picked], lastEnd });
  return steps;
}

const TMAX = 10;

const TimelineCanvas = forwardRef(function TimelineCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    order: [...ACTS].sort((a, b) => a.e - b.e).map((x) => x.id),
    selected: [],
    highlight: null,
    phase: '',
  });
  const addAnim = useCallback(() => {}, []);
  const setState = useCallback((p) => Object.assign(stateRef.current, p), []);
  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 320;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);
    let raf;
    function draw() {
      const { order, selected, highlight } = stateRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = '#e7e5e4';
      if (document.documentElement.getAttribute('data-theme') !== 'light') ctx.fillStyle = 'rgba(255,255,255,0.06)';
      for (let gx = 20; gx < W; gx += 20) for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.2, 1.2);
      const pad = 40;
      const axisY = H - 50;
      const axisW = W - pad * 2;
      ctx.strokeStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#1c1917' : '#e7e5e4';
      ctx.beginPath();
      ctx.moveTo(pad, axisY);
      ctx.lineTo(W - pad, axisY);
      ctx.stroke();
      for (let t = 0; t <= TMAX; t++) {
        const x = pad + (t / TMAX) * axisW;
        ctx.fillStyle = ctx.strokeStyle;
        ctx.font = '10px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(String(t), x, axisY + 18);
      }
      const byId = Object.fromEntries(ACTS.map((a) => [a.id, a]));
      let row = 0;
      order.forEach((id) => {
        const a = byId[id];
        if (!a) return;
        const x0 = pad + (a.s / TMAX) * axisW;
        const x1 = pad + (a.e / TMAX) * axisW;
        const y = 50 + row * 28;
        row += 1;
        const sel = selected.includes(id);
        const hi = highlight === id;
        ctx.fillStyle = hi ? '#ffec99' : sel ? '#b2f2bb' : '#a5d8ff';
        if (document.documentElement.getAttribute('data-theme') !== 'light') {
          ctx.fillStyle = hi ? '#805b10' : sel ? '#1e5631' : '#1c4a6e';
        }
        ctx.fillRect(x0, y, Math.max(4, x1 - x0), 18);
        ctx.strokeStyle = ctx.fillStyle;
        ctx.strokeRect(x0, y, Math.max(4, x1 - x0), 18);
        ctx.fillStyle = document.documentElement.getAttribute('data-theme') === 'light' ? '#111' : '#eee';
        ctx.font = 'bold 11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(id, (x0 + x1) / 2, y + 13);
      });
      raf = requestAnimationFrame(draw);
    }
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function paint(step) {
  const sorted = [...ACTS].sort((a, b) => a.e - b.e);
  return {
    order: sorted.map((x) => x.id),
    selected: step.selected || [],
    highlight: step.current || null,
  };
}

export default function ActivitySelectionVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Greedy by earliest finish' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={TimelineCanvas} onInit={onInit} onStep={onStep} />;
}
