# Bit Manipulation — Core Concepts

> **FAANG Focus:** Bitwise ops are O(1) per word. Master these for low-level optimization and XOR/bitmask patterns.

---

## 1. Core Bitwise Operations

| Operator | Symbol | Truth Table | Use Case |
|----------|--------|-------------|----------|
| **AND** | `&` | 1&1=1, else 0 | Masking, extract bits |
| **OR** | `\|` | 0\|0=0, else 1 | Set bits, union |
| **XOR** | `^` | Same→0, Diff→1 | Toggle, cancel pairs |
| **NOT** | `~` | 0→1, 1→0 | Flip all bits |
| **Left Shift** | `<<` | `n << k = n × 2^k` | Multiply by power of 2 |
| **Right Shift** | `>>` | `n >> k = n ÷ 2^k` | Divide by power of 2 |

### ASCII: AND vs OR vs XOR

```
AND (&) — both must be 1:
  A:  1 0 1 1 0
  B:  1 1 0 1 0
  ─────────────
  &:  1 0 0 1 0

OR (|) — at least one 1:
  A:  1 0 1 1 0
  B:  1 1 0 1 0
  ─────────────
  |:  1 1 1 1 0

XOR (^) — exactly one 1:
  A:  1 0 1 1 0
  B:  1 1 0 1 0
  ─────────────
  ^:  0 1 1 0 0
```

---

## 2. Key Properties (Memorize)

| Property | Formula | Example |
|----------|---------|---------|
| XOR identity | `x ^ 0 = x` | `5 ^ 0 = 5` |
| XOR self-inverse | `x ^ x = 0` | `5 ^ 5 = 0` |
| XOR cancellation | `a ^ b ^ b = a` | Swap without temp |
| Remove lowest set bit | `n & (n-1)` | `1100 & 1011 = 1000` |
| Isolate lowest set bit | `n & (-n)` | `1100 & 0100 = 0100` |
| Power of 2 check | `n > 0 && (n & (n-1)) == 0` | 8, 16, 32... |

### Why `n & (n-1)` Removes Lowest Set Bit

```
n     = 1 1 0 0  (12)
n-1   = 1 0 1 1  (11) — borrow flips LSB and all trailing zeros
─────────────────────
n&(n-1)= 1 0 0 0  (8) — lowest 1 is gone
```

---

## 3. Two's Complement & Signed vs Unsigned

### Two's Complement (Negation)

```
-n = ~n + 1

Example: -5 in 8-bit
  5  = 00000101
 ~5  = 11111010
~5+1 = 11111011  ← -5
```

### Signed vs Unsigned (n-bit)

| Type | Range | MSB meaning |
|------|-------|-------------|
| Unsigned | `0` to `2^n - 1` | Magnitude |
| Signed | `-2^(n-1)` to `2^(n-1)-1` | Sign (1=negative) |

```
8-bit number line (signed):
  00000000 → 0    01111111 → +127
  10000000 → -128 11111111 → -1
```

---

## 4. Bitmask DP Connection

| When to Use | When NOT to Use |
|-------------|-----------------|
| n ≤ 20–25 items | n > 25 (state explosion) |
| "Which items chosen" state | Continuous/float state |
| Subset enumeration | Order matters heavily |
| TSP, assignment, partitioning | Need full backtracking path |

### Golden Rules

1. **n ≤ 20** → Bitmask DP is tractable (2^20 ≈ 1M states)
2. **"Unique among pairs"** → XOR cancels duplicates
3. **Power of 2** → `n & (n-1) == 0`
4. **Subsets** → Iterate `mask` from 0 to `(1<<n)-1`
5. **Always parenthesize** bitwise in comparisons: `(n & 1) == 0`

---

## 5. Modulo by Power of 2

```
n % 2^k  ==  n & ((1 << k) - 1)
n % 8    ==  n & 7
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  & = mask    | = set    ^ = toggle/cancel        │
│  n & (n-1)   = remove lowest set bit            │
│  n & (-n)    = isolate lowest set bit           │
│  x ^ x = 0   x ^ 0 = x   (XOR properties)       │
│  -n = ~n + 1 (two's complement)                 │
│  n ≤ 20 → bitmask DP   "unique" → XOR           │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] AND/OR/XOR/NOT truth tables
- [ ] `n & (n-1)` removes LSB; `n & (-n)` isolates LSB
- [ ] `x ^ x = 0`, `x ^ 0 = x`
- [ ] Two's complement: `-n = ~n + 1`
- [ ] Power of 2: `n > 0 && (n & (n-1)) == 0`
- [ ] Bitmask DP when n ≤ 20; XOR for "single among pairs"
