import { useEffect, useRef, memo, useState } from 'react';

const AD_CLIENT = 'ca-pub-XXXXXXXXXXXXXXXX'; // Replace with your AdSense publisher ID

function useAdSenseReady() {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    if (window.adsbygoogle) { setReady(true); return; }
    const interval = setInterval(() => {
      if (window.adsbygoogle) { setReady(true); clearInterval(interval); }
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  return ready;
}

const AdUnit = memo(function AdUnit({ slot, format = 'auto', style = {}, className = '' }) {
  const adRef = useRef(null);
  const pushed = useRef(false);
  const adReady = useAdSenseReady();

  useEffect(() => {
    if (pushed.current || !adReady || !adRef.current) return;
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
      pushed.current = true;
    } catch { /* AdSense not loaded */ }
  }, [adReady]);

  return (
    <ins
      ref={adRef}
      className={`adsbygoogle ${className}`}
      style={{ display: 'block', ...style }}
      data-ad-client={AD_CLIENT}
      data-ad-slot={slot}
      data-ad-format={format}
      data-full-width-responsive="true"
    />
  );
});

export function ContentAd({ isPremium }) {
  if (isPremium) return null;

  return (
    <div className="ad-content">
      <div className="ad-content__inner">
        <div className="ad-content__badge">Ad</div>
        <div className="ad-content__body">
          <AdUnit slot="1234567890" format="horizontal" style={{ minHeight: 50 }} />
          <div className="ad-content__fallback">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z" />
              <path d="M15.5 8.5L12 12l-3.5-3.5" />
              <path d="M8.5 15.5L12 12l3.5 3.5" />
            </svg>
            <div className="ad-content__fallback-text">
              <strong>InkDrop Pro</strong>
              <span>Remove ads & unlock cloud sync, themes, and API access</span>
            </div>
          </div>
        </div>
        <button className="ad-content__upgrade" onClick={() => window.dispatchEvent(new CustomEvent('open-premium'))}>
          Upgrade
        </button>
      </div>
    </div>
  );
}

export function SidebarAd({ isPremium }) {
  if (isPremium) return null;

  return (
    <div className="ad-sidebar">
      <AdUnit slot="0987654321" format="rectangle" style={{ minHeight: 100 }} />
      <div className="ad-sidebar__fallback">
        <div className="ad-sidebar__promo">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
          </svg>
          <strong>Go Pro</strong>
          <span>Ad-free experience</span>
          <span>Cloud storage</span>
          <span>Custom themes</span>
        </div>
        <button className="ad-sidebar__cta" onClick={() => window.dispatchEvent(new CustomEvent('open-premium'))}>
          Remove Ads
        </button>
      </div>
    </div>
  );
}

export function InArticleAd({ isPremium }) {
  if (isPremium) return null;

  return (
    <div className="ad-article">
      <div className="ad-article__label">Sponsored</div>
      <AdUnit slot="1122334455" format="fluid" style={{ minHeight: 90 }} />
      <div className="ad-article__fallback">
        <div className="ad-article__card">
          <div className="ad-article__icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.27 5.82 22 7 14.14l-5-4.87 6.91-1.01z" />
            </svg>
          </div>
          <div className="ad-article__text">
            <strong>Enjoying InkDrop?</strong>
            <p>Upgrade to Pro for an ad-free reading experience with premium features.</p>
          </div>
          <button className="ad-article__btn" onClick={() => window.dispatchEvent(new CustomEvent('open-premium'))}>
            Try Pro
          </button>
        </div>
      </div>
    </div>
  );
}

export function FooterAd({ isPremium }) {
  if (isPremium) return null;

  return (
    <div className="ad-footer">
      <AdUnit slot="5566778899" format="horizontal" style={{ minHeight: 60 }} />
      <div className="ad-footer__fallback">
        <span className="ad-footer__tag">Ad</span>
        <div className="ad-footer__content">
          <strong>InkDrop Pro</strong> — Read without interruptions.
          <button className="ad-footer__link" onClick={() => window.dispatchEvent(new CustomEvent('open-premium'))}>
            Upgrade now
          </button>
        </div>
      </div>
    </div>
  );
}

export default AdUnit;
