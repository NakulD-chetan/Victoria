# Normalization and Transactions — Edge Cases

---

## Single-column PK → already 2NF

2NF violations only happen with **composite** PK. Single-column PK → no partial dependency possible.

---

## BCNF vs 3NF

Sometimes 3NF table isn't BCNF — if a non-candidate-key determines another column. Rare in interviews; mention awareness.

---

## Autocommit

Many DBs default to **autocommit** — each statement is its own transaction. Explicit `BEGIN` needed for multi-statement atomicity.

---

## Long transactions

Long-running tx hold locks → starve others. Keep tx short; do heavy reads outside tx.

---

*Next: [[07_Tricks-and-Recognition]]*
