# Bit Manipulation — Interview Thinking

> **FAANG Focus:** How to identify, approach, and communicate bit problems.

---

## 1. How to Identify Bit Problems

| Signal | Think Bits |
|--------|------------|
| "Unique element among pairs/triples" | XOR |
| "Power of 2" | `n & (n-1) == 0` |
| "All subsets" / "choose from n items" | Bitmask |
| n ≤ 20, "visited" / "assigned" state | Bitmask DP |
| "XOR of subarray" | Prefix XOR |
| "Count 1s" / "parity" | Popcount |
| "Divide into 2 groups" | Often bitmask |
| Direct mention: AND, OR, XOR, bits | Bit manipulation |

---

## 2. XOR Properties — Decision Tree

```
Problem mentions "unique" / "appears once" / "others twice"?
    → XOR all elements

Two unique numbers?
    → XOR all → get a^b → split by diff bit (a^b & -a^b)

XOR of range [L,R]?
    → prefix[r+1] ^ prefix[l]

XOR 1 to n (closed form)?
    → n%4: 0→n, 1→1, 2→n+1, 3→0
```

---

## 3. Bitmask Thinking

| Question | Approach |
|----------|----------|
| Enumerate all subsets? | `for mask in 0..(1<<n)` |
| Subsets of size k? | Filter by popcount or Gosper's hack |
| State = "which items used"? | `dp[mask]` or `dp[mask][i]` |
| Submask iteration? | `for sub = mask; sub; sub = (sub-1) & mask` |
| Set operations? | `\|` union, `&` intersect, `^` sym diff |

---

## 4. Communication Checklist

- [ ] **State the pattern:** "This is a XOR cancellation problem" / "We can use bitmask DP"
- [ ] **Mention complexity:** "O(n) with XOR" / "O(2^n × n) for bitmask DP"
- [ ] **Edge cases:** "n=0, single element, all same"
- [ ] **Clarify bit width:** "32-bit integers" / "Python has arbitrary precision"

### Example Script

> "I notice every element appears twice except one. XOR has the property that x^x=0 and x^0=x, so XORing all elements will cancel pairs and leave the unique one. Time O(n), space O(1)."

---

## 5. Problem → Technique Mapping

| Problem Type | Technique |
|--------------|-----------|
| Single number (others 2x) | XOR all |
| Single number (others 3x) | Bit counting mod 3 |
| Two single numbers | XOR + split by diff bit |
| Power of 2/4 | `n & (n-1)` + extra check |
| Subsets | Bitmask iteration |
| TSP / assignment | Bitmask DP |
| Max XOR pair | Trie or greedy bit construction |
| Hamming distance | XOR + popcount |

---

## 6. When to Avoid Bits

- n > 25 (state too large)
- Need explicit ordering of choices
- Problem is clearer with recursion/backtracking
- Interviewer prefers readable over clever

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  "Unique among pairs" → XOR all                 │
│  "Power of 2" → n & (n-1) == 0                  │
│  "Subsets" / n≤20 → Bitmask / Bitmask DP        │
│  XOR range: prefix[r+1] ^ prefix[l]             │
│  Communicate: pattern + complexity + edges      │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] Unique among pairs → XOR
- [ ] Power of 2 → `n & (n-1) == 0`
- [ ] Subsets / n≤20 → Bitmask
- [ ] State pattern + complexity + edge cases
- [ ] Avoid bits when n>25 or clarity suffers
