# Dynamic Programming — Coding Templates

> **Generic, reusable templates. No problem-specific logic. Copy, adapt, solve.**

---

## Template 1: 1D DP (Climbing Stairs / House Robber Style)

**Use when:** Linear sequence, each step depends on previous 1–2 positions.

### Python
```python
def dp_1d_linear(n):
    if n <= 1:
        return n  # base
    dp = [0] * (n + 1)
    dp[0] = 0  # base
    dp[1] = 1  # base
    for i in range(2, n + 1):
        dp[i] = dp[i - 1] + dp[i - 2]  # recurrence
    return dp[n]
```

### C++
```cpp
int dp1dLinear(int n) {
    if (n <= 1) return n;
    vector<int> dp(n + 1);
    dp[0] = 0;
    dp[1] = 1;
    for (int i = 2; i <= n; i++)
        dp[i] = dp[i - 1] + dp[i - 2];
    return dp[n];
}
```

---

## Template 2: 1D DP — House Robber (Take/Skip)

**Use when:** At each index, choose take or skip; can't take adjacent.

### Python
```python
def dp_1d_take_skip(nums):
    if not nums:
        return 0
    if len(nums) == 1:
        return nums[0]
    dp = [0] * (len(nums) + 1)
    dp[0] = 0
    dp[1] = nums[0]
    for i in range(2, len(nums) + 1):
        dp[i] = max(dp[i - 1], nums[i - 1] + dp[i - 2])
    return dp[len(nums)]
```

### C++
```cpp
int dp1dTakeSkip(vector<int>& nums) {
    if (nums.empty()) return 0;
    if (nums.size() == 1) return nums[0];
    vector<int> dp(nums.size() + 1);
    dp[0] = 0;
    dp[1] = nums[0];
    for (int i = 2; i <= nums.size(); i++)
        dp[i] = max(dp[i - 1], nums[i - 1] + dp[i - 2]);
    return dp[nums.size()];
}
```

---

## Template 3: 2D DP — Grid Paths

**Use when:** Move on m×n grid, from (0,0) to (m-1,n-1).

### Python
```python
def dp_2d_grid(m, n):
    dp = [[0] * n for _ in range(m)]
    dp[0][0] = 1
    for r in range(m):
        for c in range(n):
            if r > 0:
                dp[r][c] += dp[r - 1][c]
            if c > 0:
                dp[r][c] += dp[r][c - 1]
    return dp[m - 1][n - 1]
```

### C++
```cpp
int dp2dGrid(int m, int n) {
    vector<vector<int>> dp(m, vector<int>(n, 0));
    dp[0][0] = 1;
    for (int r = 0; r < m; r++)
        for (int c = 0; c < n; c++) {
            if (r > 0) dp[r][c] += dp[r - 1][c];
            if (c > 0) dp[r][c] += dp[r][c - 1];
        }
    return dp[m - 1][n - 1];
}
```

---

## Template 4: 2D DP — Edit Distance

**Use when:** Two strings, insert/delete/replace operations.

### Python
```python
def dp_2d_edit_distance(s1, s2):
    m, n = len(s1), len(s2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                dp[i][j] = dp[i - 1][j - 1]
            else:
                dp[i][j] = 1 + min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
    return dp[m][n]
```

### C++
```cpp
int dp2dEditDistance(string& s1, string& s2) {
    int m = s1.size(), n = s2.size();
    vector<vector<int>> dp(m + 1, vector<int>(n + 1));
    for (int i = 0; i <= m; i++) dp[i][0] = i;
    for (int j = 0; j <= n; j++) dp[0][j] = j;
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1])
                dp[i][j] = dp[i - 1][j - 1];
            else
                dp[i][j] = 1 + min({dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]});
        }
    return dp[m][n];
}
```

---

## Template 5: 0/1 Knapsack

**Use when:** Each item use at most once; maximize value with weight limit.

### Python
```python
def dp_01_knapsack(weights, values, W):
    n = len(weights)
    dp = [[0] * (W + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for w in range(W + 1):
            dp[i][w] = dp[i - 1][w]
            if w >= weights[i - 1]:
                dp[i][w] = max(dp[i][w], values[i - 1] + dp[i - 1][w - weights[i - 1]])
    return dp[n][W]
```

### C++
```cpp
int dp01Knapsack(vector<int>& weights, vector<int>& values, int W) {
    int n = weights.size();
    vector<vector<int>> dp(n + 1, vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++)
        for (int w = 0; w <= W; w++) {
            dp[i][w] = dp[i - 1][w];
            if (w >= weights[i - 1])
                dp[i][w] = max(dp[i][w], values[i - 1] + dp[i - 1][w - weights[i - 1]]);
        }
    return dp[n][W];
}
```

---

## Template 6: Unbounded Knapsack (Coin Change)

**Use when:** Each item can be used infinitely; minimize/maximize count or value.

### Python
```python
def dp_unbounded_knapsack(coins, amount):
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0
    for a in range(1, amount + 1):
        for c in coins:
            if a >= c:
                dp[a] = min(dp[a], 1 + dp[a - c])
    return dp[amount] if dp[amount] != float('inf') else -1
```

### C++
```cpp
int dpUnboundedKnapsack(vector<int>& coins, int amount) {
    vector<int> dp(amount + 1, INT_MAX);
    dp[0] = 0;
    for (int a = 1; a <= amount; a++)
        for (int c : coins)
            if (a >= c && dp[a - c] != INT_MAX)
                dp[a] = min(dp[a], 1 + dp[a - c]);
    return dp[amount] == INT_MAX ? -1 : dp[amount];
}
```

---

## Template 7: LCS (Longest Common Subsequence)

**Use when:** Two sequences; longest subsequence common to both.

### Python
```python
def dp_lcs(s1, s2):
    m, n = len(s1), len(s2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]
    for i in range(1, m + 1):
        for j in range(1, n + 1):
            if s1[i - 1] == s2[j - 1]:
                dp[i][j] = 1 + dp[i - 1][j - 1]
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    return dp[m][n]
```

### C++
```cpp
int dpLCS(string& s1, string& s2) {
    int m = s1.size(), n = s2.size();
    vector<vector<int>> dp(m + 1, vector<int>(n + 1, 0));
    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++) {
            if (s1[i - 1] == s2[j - 1])
                dp[i][j] = 1 + dp[i - 1][j - 1];
            else
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1]);
        }
    return dp[m][n];
}
```

---

## Template 8: LIS (Longest Increasing Subsequence)

**Use when:** Longest strictly increasing subsequence in array.

### Python
```python
def dp_lis(nums):
    if not nums:
        return 0
    n = len(nums)
    dp = [1] * n
    for i in range(n):
        for j in range(i):
            if nums[j] < nums[i]:
                dp[i] = max(dp[i], 1 + dp[j])
    return max(dp)
```

### C++
```cpp
int dpLIS(vector<int>& nums) {
    if (nums.empty()) return 0;
    int n = nums.size();
    vector<int> dp(n, 1);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < i; j++)
            if (nums[j] < nums[i])
                dp[i] = max(dp[i], 1 + dp[j]);
    return *max_element(dp.begin(), dp.end());
}
```

---

## Template 9: Interval DP (Matrix Chain / Burst Balloons)

**Use when:** Optimize over contiguous subarrays; fill by length.

### Python
```python
def dp_interval(arr):
    n = len(arr)
    dp = [[0] * n for _ in range(n)]
    for length in range(2, n + 1):
        for left in range(n - length + 1):
            right = left + length - 1
            dp[left][right] = float('inf')
            for k in range(left, right):
                cost = dp[left][k] + dp[k + 1][right] + arr[left] * arr[k + 1] * arr[right + 1]
                dp[left][right] = min(dp[left][right], cost)
    return dp[0][n - 1]
```

### C++
```cpp
int dpInterval(vector<int>& arr) {
    int n = arr.size();
    vector<vector<int>> dp(n, vector<int>(n, 0));
    for (int len = 2; len <= n; len++)
        for (int left = 0; left <= n - len; left++) {
            int right = left + len - 1;
            dp[left][right] = INT_MAX;
            for (int k = left; k < right; k++) {
                int cost = dp[left][k] + dp[k + 1][right]
                        + arr[left] * arr[k + 1] * arr[right + 1];
                dp[left][right] = min(dp[left][right], cost);
            }
        }
    return dp[0][n - 1];
}
```

---

## Template 10: Bitmask DP (TSP-Style)

**Use when:** Visit each of n nodes exactly once; state = subset of visited.

### Python
```python
def dp_bitmask_tsp(n, dist):
    # dist[i][j] = cost from i to j
    FULL = (1 << n) - 1
    dp = [[float('inf')] * n for _ in range(1 << n)]
    dp[1][0] = 0  # start at 0, visited {0}
    for mask in range(1 << n):
        for last in range(n):
            if not (mask & (1 << last)):
                continue
            for next_node in range(n):
                if mask & (1 << next_node):
                    continue
                new_mask = mask | (1 << next_node)
                dp[new_mask][next_node] = min(
                    dp[new_mask][next_node],
                    dp[mask][last] + dist[last][next_node]
                )
    return min(dp[FULL][j] + dist[j][0] for j in range(n))
```

### C++
```cpp
int dpBitmaskTSP(int n, vector<vector<int>>& dist) {
    int FULL = (1 << n) - 1;
    vector<vector<int>> dp(1 << n, vector<int>(n, INT_MAX));
    dp[1][0] = 0;
    for (int mask = 0; mask < (1 << n); mask++)
        for (int last = 0; last < n; last++) {
            if (!(mask & (1 << last))) continue;
            for (int next = 0; next < n; next++) {
                if (mask & (1 << next)) continue;
                int newMask = mask | (1 << next);
                int cost = dp[mask][last] + dist[last][next];
                if (cost < dp[newMask][next])
                    dp[newMask][next] = cost;
            }
        }
    int ans = INT_MAX;
    for (int j = 0; j < n; j++)
        if (dp[FULL][j] != INT_MAX)
            ans = min(ans, dp[FULL][j] + dist[j][0]);
    return ans;
}
```

---

## Template 11: Space-Optimized DP (Rolling Array)

**Use when:** dp[i] depends only on dp[i-1] (or last few rows).

### Python — 1D (e.g., House Robber)
```python
def dp_1d_space_opt(nums):
    if not nums:
        return 0
    prev, curr = 0, nums[0]
    for i in range(1, len(nums)):
        prev, curr = curr, max(curr, nums[i] + prev)
    return curr
```

### Python — 0/1 Knapsack (1D, reverse fill)
```python
def dp_01_knapsack_space_opt(weights, values, W):
    dp = [0] * (W + 1)
    for i in range(len(weights)):
        for w in range(W, weights[i] - 1, -1):  # reverse!
            dp[w] = max(dp[w], values[i] + dp[w - weights[i]])
    return dp[W]
```

### C++ — 0/1 Knapsack Space-Optimized
```cpp
int dp01KnapsackSpaceOpt(vector<int>& weights, vector<int>& values, int W) {
    vector<int> dp(W + 1, 0);
    for (int i = 0; i < weights.size(); i++)
        for (int w = W; w >= weights[i]; w--)
            dp[w] = max(dp[w], values[i] + dp[w - weights[i]]);
    return dp[W];
}
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
1D LINEAR:       dp[i] = f(dp[i-1], dp[i-2]); fill 0..n
1D TAKE-SKIP:    dp[i] = max(skip, take); base dp[0], dp[1]
2D GRID:         dp[r][c] from up/left; base dp[0][0]=1
2D EDIT:         dp[i][j] = match? same : 1+min(3 ops)
01 KNAPSACK:     dp[i][w] = max(skip, take); row-by-row
UNBOUNDED:       dp[a] = min over coins; 1D, same row reuse
LCS:             match → 1+diag; else max(up, left)
LIS:             dp[i] = 1+max(dp[j]) for j<i, nums[j]<nums[i]
INTERVAL:        fill by length; k splits [left,right]
BITMASK:         mask = visited set; dp[mask][last]
SPACE OPT:       reverse fill for knapsack; 2 vars for 1D
```
