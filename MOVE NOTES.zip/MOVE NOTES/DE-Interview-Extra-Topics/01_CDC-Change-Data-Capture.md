# 01 — CDC (Change Data Capture)

> **One-line:** CDC captures **row-level INSERT / UPDATE / DELETE** from a source database and streams them as **events** — enabling **real-time** or **near-real-time** data sync without heavy batch queries.

---

## 1. What is CDC and Why It Matters

| Aspect | Detail |
|--------|--------|
| **Problem** | Traditional batch ETL queries full tables periodically → **high latency**, **heavy DB load**, **misses deletes** |
| **CDC Solution** | Read the **database transaction log** (or use triggers) → capture **only changes** → stream downstream |
| **Result** | Millisecond-to-second latency, **minimal** source DB impact, **complete** change history |

**Interview line:** "CDC gives us a **real-time event stream** from OLTP databases without impacting production performance."

---

## 2. CDC Approaches

| Approach | How It Works | Pros | Cons |
|----------|-------------|------|------|
| **Log-based CDC** | Reads DB transaction log (WAL in Postgres, binlog in MySQL) | No schema changes, captures deletes, low overhead | Needs log access permissions, log retention config |
| **Trigger-based CDC** | DB triggers write changes to shadow/audit tables | Works on any DB | Adds write overhead, complex trigger management |
| **Query-based (polling)** | Periodically query `WHERE updated_at > last_run` | Simple to implement | Misses deletes, high latency, heavy queries |
| **Timestamp-based** | Compare timestamps on each poll | Easy | Cannot detect deletes, needs `updated_at` column |

**Interview tip:** "Log-based is the **gold standard** — minimal overhead, captures all change types including deletes, and provides **exactly the order** of operations."

---

## 3. Debezium — The Most Popular CDC Tool

### What is Debezium?

| Feature | Detail |
|---------|--------|
| **Type** | Open-source CDC platform built on **Kafka Connect** |
| **Supported DBs** | PostgreSQL, MySQL, MongoDB, SQL Server, Oracle, Cassandra, Vitess |
| **Output** | Structured **change events** to **Kafka topics** |
| **Format** | JSON or Avro (with Schema Registry) |

### Debezium Architecture

```
┌──────────────┐     ┌─────────────────┐     ┌───────────┐     ┌──────────────┐
│  Source DB   │────►│ Debezium        │────►│  Kafka    │────►│ Consumers    │
│ (Postgres/   │     │ Connector       │     │  Topics   │     │ (Spark/Flink/│
│  MySQL)      │ WAL │ (Kafka Connect) │     │           │     │  DW/Lake)    │
└──────────────┘     └─────────────────┘     └───────────┘     └──────────────┘
```

### Change Event Structure (Debezium)

```json
{
  "before": { "id": 1, "name": "Manish", "city": "Gurugram" },
  "after":  { "id": 1, "name": "Manish", "city": "Bengaluru" },
  "op": "u",
  "ts_ms": 1711900000000,
  "source": {
    "connector": "postgresql",
    "db": "mydb",
    "table": "customers"
  }
}
```

| Field | Meaning |
|-------|---------|
| `before` | Row state **before** the change (null for INSERT) |
| `after` | Row state **after** the change (null for DELETE) |
| `op` | Operation: `c` = create, `u` = update, `d` = delete, `r` = read (snapshot) |
| `ts_ms` | Timestamp of the change |

---

## 4. CDC Use Cases (Interview Favorites)

| Use Case | How CDC Helps |
|----------|--------------|
| **Real-time DW sync** | Stream OLTP changes → transform → load into warehouse in near-real-time |
| **Microservice event sourcing** | DB changes become domain events for other services |
| **Cache invalidation** | DB update → CDC event → invalidate/update Redis cache |
| **Search index sync** | DB change → update Elasticsearch/OpenSearch index |
| **Audit trail** | Complete history of all changes with timestamps |
| **Data lake ingestion** | Stream changes to Bronze layer instead of full-table dumps |

---

## 5. CDC vs Traditional ETL

| Dimension | Traditional Batch ETL | CDC |
|-----------|----------------------|-----|
| **Latency** | Minutes to hours | Seconds to milliseconds |
| **Source DB load** | High (full table scans) | Minimal (reads log only) |
| **Detects deletes** | Only with soft-delete columns | Yes (log captures DELETE) |
| **Data completeness** | May miss intermediate states | Captures **every** change |
| **Complexity** | Lower | Higher (Kafka, connectors, schema evolution) |
| **Cost** | Compute spikes during batch | Steady streaming cost |

---

## 6. Handling Schema Evolution in CDC

| Scenario | Strategy |
|----------|----------|
| **New column added** | Debezium auto-detects; configure `schema.change.policy` |
| **Column renamed** | Breaks consumers → use **Schema Registry** + compatibility checks |
| **Column dropped** | Old events have it, new don't → handle in consumer |
| **Type change** | Risky → test with **shadow topic** first |

**Interview tip:** "Schema Registry (Confluent) with **backward compatibility** mode ensures consumers don't break when producers evolve schemas."

---

## 7. CDC with SCD Type 2

CDC is a **natural fit** for maintaining **SCD Type 2** dimensions in a warehouse:

```
CDC event (op: "u", customer moved city)
    │
    ▼
ETL Logic:
  1. Mark old row → status = Inactive, end_date = today
  2. Insert new row → status = Active, end_date = 9999-12-31
  3. New surrogate key for new version
```

**Interview line:** "CDC provides the **real-time trigger** for SCD Type 2 processing — instead of nightly batch comparison, we process changes **as they happen**."

---

## 8. Common Interview Questions

| Question | Key Points |
|----------|------------|
| "What is CDC?" | Row-level change capture from source DB, real-time event stream |
| "Log-based vs query-based?" | Log-based: low overhead, captures deletes, ordered. Query: simple, misses deletes |
| "Explain Debezium architecture" | Kafka Connect connector → reads WAL → publishes to Kafka topics |
| "How do you handle schema changes in CDC?" | Schema Registry, backward compatibility, consumer migration plan |
| "CDC vs batch ETL — when to choose?" | CDC for low-latency, real-time needs. Batch for simple, infrequent, cost-sensitive |
| "How does CDC relate to SCD Type 2?" | CDC events trigger dimension versioning in real-time |
| "What happens if Debezium goes down?" | Resumes from last committed offset; snapshot if WAL expired |
| "CDC exactly-once guarantees?" | Kafka transactional writes + idempotent consumers = effectively exactly-once |

---

## Key Takeaways

- **CDC** = capture **every** DB change as an **event** — the bridge between **OLTP** and **analytics/streaming** worlds.
- **Log-based CDC** (Debezium) is the **industry standard** — reads WAL, minimal DB overhead.
- Debezium + Kafka = **most common** CDC stack in production.
- CDC enables **real-time** warehouse sync, **cache invalidation**, **search indexing**, and **event-driven** architectures.
- Always discuss **Schema Registry** and **exactly-once semantics** when explaining CDC in interviews.

---
