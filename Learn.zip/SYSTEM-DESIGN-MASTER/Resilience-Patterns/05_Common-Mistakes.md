# Resilience Patterns — Common Mistakes

> **Permanent Recall:** Top 10 resilience mistakes to avoid: (1) No circuit breakers, (2) Retry without backoff, (3) Retry non-idempotent operations, (4) No timeout, (5) No rate limiting, (6) No graceful degradation, (7) Testing only happy path, (8) Ignoring cascading failures, (9) Too aggressive retries (retry storm), (10) No monitoring of resilience patterns. Each mistake compounds; defense in depth requires addressing multiple layers.

---

## 1. No Circuit Breakers

**Mistake:** Calling a failing dependency repeatedly; threads block, resources exhaust.

**Impact:** Cascading failure—one bad service takes down the caller.

**Fix:** Add circuit breaker; fail fast with fallback when threshold exceeded.

---

## 2. Retry Without Backoff

**Mistake:** Immediate retries (e.g., 3 retries with 0ms delay).

**Impact:** Thundering herd on the failing service; makes recovery harder.

**Fix:** Exponential backoff (1s, 2s, 4s...) + jitter.

---

## 3. Retry Non-Idempotent Operations

**Mistake:** Retrying payment, order creation, or any write without idempotency.

**Impact:** Double charges, duplicate orders.

**Fix:** Idempotency keys; server deduplicates by key; retry safe.

---

## 4. No Timeout

**Mistake:** Infinite or very long timeouts on outbound calls.

**Impact:** Threads hang; connection pool exhausts; request backlog grows.

**Fix:** Set connection timeout (5–10s) and read timeout (30–60s) per dependency.

---

## 5. No Rate Limiting

**Mistake:** Accepting unlimited requests; no per-user or per-IP limits.

**Impact:** Abuse, DDoS amplification, cost explosion, backend overload.

**Fix:** Rate limit at gateway; token bucket or sliding window; 429 with Retry-After.

---

## 6. No Graceful Degradation

**Mistake:** All-or-nothing; if one feature fails, entire system fails.

**Impact:** Minor dependency failure causes total outage.

**Fix:** Fallback responses, feature flags, reduced functionality for non-critical path.

---

## 7. Testing Only Happy Path

**Mistake:** Unit/integration tests assume everything works.

**Impact:** Production failures reveal untested failure modes.

**Fix:** Chaos engineering, fault injection, failure scenario tests, game days.

---

## 8. Ignoring Cascading Failures

**Mistake:** Not modeling failure propagation—e.g., DB slow → threads block → LB health fails → total down.

**Impact:** Single failure triggers chain reaction.

**Fix:** Circuit breakers, bulkheads, timeouts; trace failure paths.

---

## 9. Too Aggressive Retries (Retry Storm)

**Mistake:** High retry count, no backoff, many clients retrying at once.

**Impact:** Overwhelms failing service; delays recovery.

**Fix:** Retry budget, exponential backoff, jitter, circuit breaker to stop retries when open.

---

## 10. No Monitoring of Resilience Patterns

**Mistake:** Circuit breakers, rate limiters, retries in place but no metrics.

**Impact:** Can't tune thresholds; can't detect when patterns misbehave.

**Fix:** Instrument circuit breaker state, rate limit hits, retry count, fallback usage; alert on anomalies.

---

## Summary Table

| # | Mistake | Fix |
|---|---------|-----|
| 1 | No circuit breakers | Add CB for all dependencies |
| 2 | Retry without backoff | Exponential backoff + jitter |
| 3 | Retry non-idempotent | Idempotency keys |
| 4 | No timeout | Connection + read timeouts |
| 5 | No rate limiting | Gateway rate limit |
| 6 | No graceful degradation | Fallbacks, feature flags |
| 7 | Only happy path tests | Chaos, fault injection |
| 8 | Ignore cascading failures | CB, bulkhead, trace paths |
| 9 | Retry storm | Backoff, budget, CB |
| 10 | No monitoring | Instrument all patterns |

> **FAANG Tip:** "The most common resilience mistake? Retrying without backoff on non-idempotent operations. That's how you get double charges and cascading failures."

---

## Anti-Pattern: The Retry Cascade

**Scenario:** Service A calls B; B calls C. C is slow. B retries. A retries. Now C gets 3× load from retries. C gets slower. More retries. Death spiral.

**Fix:** Circuit breaker at each layer stops retries when downstream is broken. Plus backoff + jitter at each caller.

---

## Mistake Severity (What to Fix First)

| Priority | Mistake | Why First |
|----------|---------|-----------|
| P0 | Retry non-idempotent | Data corruption, double charge |
| P0 | No circuit breaker | Cascading failure |
| P1 | No timeout | Resource exhaustion |
| P1 | Retry without backoff | Retry storm |
| P2 | No rate limiting | Abuse, cost |
| P2 | No graceful degradation | All-or-nothing failure |

---

## Red Flags in Code Reviews

- `retry(3)` with no delay
- No `Idempotency-Key` on payment/order endpoints
- `Timeout.Infinite` or very large timeout values
- No circuit breaker around external HTTP calls
- Single thread pool for all outbound calls

---

## 30-SECOND REVISION BOX

```
1. No CB → cascade
2. Retry no backoff → thundering herd
3. Retry non-idempotent → double charge
4. No timeout → thread exhaustion
5. No rate limit → abuse
6. No degradation → all-or-nothing
7. Only happy path → prod surprise
8. Ignore cascade → chain reaction
9. Retry storm → overwhelm
10. No monitoring → blind tuning
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
