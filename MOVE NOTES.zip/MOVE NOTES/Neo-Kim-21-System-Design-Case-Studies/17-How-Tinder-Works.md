# 17. How Tinder Works

## One-Line Summary
Tinder is a location-based dating app handling 1.6B swipes/day and 26M matches/day, using DynamoDB, S2 geospatial indexing (hexagonal hierarchical grid), Kafka for ordering, and WebSockets for real-time match notifications.

## Key Requirements
- **Scale**: 1.6 billion swipes/day, 26 million matches/day
- **Functional**: User profiles, location-based discovery, swipe (like/dislike), matching, real-time notifications
- **Geospatial**: Find users within radius (e.g., 160km); users close together stored in same shard
- **Ordering**: Location updates must be processed in order for consistency

## High-Level Architecture
```
[Client] → [API Gateway] → [500+ Microservices] ← [Service Mesh]
                ↓
[DynamoDB] ← [Dynamo Streams] → [Kafka] → [Match Workers]
     ↓              ↓
[S2 Index]    [Kinesis] ← Swipes
     ↓
[Redis Cache]  [WebSockets]  [S3 - Disliked Profiles]
```

- **API Gateway**: 500+ microservices; auth, rate limiting
- **DynamoDB** for user profiles; **Dynamo Streams** for change propagation
- **S2 geospatial library** (Google) for location indexing
- **Kafka** for ordering guarantees on location updates
- **Amazon Kinesis** for swipe stream; match workers check Likes cache
- **WebSockets** for real-time match notifications
- **S3** for storing disliked profiles (analytics)

## Core Components Deep Dive

### S2 Geospatial Library (Google)
- **Hexagonal hierarchical grid** — hexagons have equal distance to all neighbors (unlike squares/triangles)
- **64-bit cell ID** — hierarchical (big cells subdivide into smaller)
- **Based on Hilbert curve** — preserves spatial locality
- **Sharding**: Users close together stored in same database shard
- **Query**: Average ~3 shards queried for 160km radius

### Kafka for Location Updates
- **FIFO ordering** with partition locks — ensures location updates processed in order
- Prevents race conditions when user moves quickly

### Matching Flow
- Swipes → Amazon Kinesis → match workers check Likes cache
- On mutual like → match event → WebSocket notification

### Hot Shard Problem
- **Problem**: Popular areas (e.g., NYC) create hot shards
- **Solution**: Randomly assign many shards per physical server; rate limiting for write hot shard

## Key Design Decisions
1. **S2 hexagons** — Equal distance to neighbors; simpler distance math than squares
2. **DynamoDB + Dynamo Streams** — Scalable storage + change propagation
3. **Kafka for location ordering** — FIFO per partition
4. **Redis cache-aside** — Read scaling for profiles and Likes
5. **WebSockets** — Real-time match notifications

## Scaling Strategies
- **Read scaling**: Redis cache-aside
- **Write scaling**: DynamoDB auto-scaling; rate limiting for hot shards
- **Hot shard mitigation**: Many shards per server; random distribution
- **Geospatial**: S2 reduces shard fan-out (avg 3 shards for 160km)

## Interview Tips
- Explain why hexagons over squares (equal distance to neighbors)
- S2 vs H3: S2 (Google) vs H3 (Uber) — both hexagonal, different implementations
- Kafka for ordering: partition key = user ID for FIFO
- Hot shard: popular locations; solution = shard distribution + rate limiting

## Quick Revision
- **Scale**: 1.6B swipes/day, 26M matches/day
- **S2**: Hexagonal grid, Hilbert curve, 64-bit cell ID, ~3 shards for 160km
- **Stack**: DynamoDB, Dynamo Streams, Kafka, Kinesis, Redis, WebSockets, S3
- **Hot shard**: Many shards per server; rate limiting
- **Matching**: Swipes → Kinesis → match workers → Likes cache → WebSocket
