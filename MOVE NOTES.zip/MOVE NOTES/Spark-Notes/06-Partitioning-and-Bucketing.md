# Partitioning and Bucketing

Both techniques organize data to reduce scan time, improve parallelism, and make queries faster. But they work at different levels and solve different problems.

---

## 1. Partitioning — Physical Folder Split

### What It Does

Partitioning splits data files into **separate folders** based on column values. Each folder contains rows for one partition value.

### How It Looks on Disk

```
/orders/
    region=US/
        part-0001.snappy.parquet
    region=IN/
        part-0001.snappy.parquet
    region=UK/
        part-0001.snappy.parquet
```

### How It Works

For each **distinct value** of the partition column, Spark writes data into a separate directory. At query time, Spark **skips** folders that don't match your filter — this is called **partition pruning**.

```python
# Creating a partitioned table
df.write.partitionBy("region").parquet("output/orders")

# Reading with partition pruning
spark.read.parquet("output/orders").filter(col("region") == "US")
# Spark reads ONLY the region=US folder — skips everything else
```

### When to Use Partitioning

Use columns with **low cardinality** (few unique values):

- `country`, `region`, `state`
- `year`, `month`, `day`
- `category`, `status`

### When NOT to Use

- **High-cardinality columns** (like `customer_id`, `order_id`) → creates millions of tiny folders
- Too many small files → metadata overhead, slow listing

### SQL Syntax

```sql
CREATE TABLE orders_partitioned (
    order_id INT,
    cust_id INT,
    amount DOUBLE
)
PARTITIONED BY (region STRING);
```

---

## 2. Bucketing — Logical Split Inside Files

### What It Does

Bucketing divides data into a **fixed number of files** using a **hash function**. Unlike partitioning, all files stay inside one folder.

### How It Looks on Disk

```
/orders/
    part-00000.snappy.parquet  (bucket 0)
    part-00001.snappy.parquet  (bucket 1)
    part-00002.snappy.parquet  (bucket 2)
    ...
    part-00007.snappy.parquet  (bucket 7)
```

### How It Works

```
bucket_id = hash(column_value) % num_buckets
```

Rows with the same key always end up in the same bucket file. This means when joining two bucketed tables on the same key, **Spark already knows which files to match** — no shuffle needed.

```python
# Creating a bucketed table
df.write.bucketBy(8, "cust_id").saveAsTable("orders_bucketed")
```

### When to Use Bucketing

- Columns with **high cardinality** (many unique values) like `customer_id`, `user_id`
- When you frequently **join** two large tables on the same column
- When you want **deterministic file distribution**

### When NOT to Use

- Column isn't used in joins or aggregations
- You don't know the ideal bucket count (it's fixed at creation time)
- Table is small enough for broadcast join

### SQL Syntax

```sql
CREATE TABLE orders_bucketed (
    order_id INT,
    cust_id INT,
    amount DOUBLE
)
CLUSTERED BY (cust_id) INTO 8 BUCKETS;
```

---

## 3. Key Differences


| Feature            | Partitioning                    | Bucketing                          |
| ------------------ | ------------------------------- | ---------------------------------- |
| Physical structure | Separate folders                | Files inside one folder            |
| How data is split  | By column value (exact match)   | By hash(column_value) % N          |
| Best column type   | Low cardinality (country, year) | High cardinality (customer_id)     |
| File count         | Dynamic (depends on data)       | Fixed (you choose number)          |
| Best for           | Filtering (WHERE clauses)       | Joins and aggregations             |
| Pruning support    | Yes (partition pruning)         | No direct pruning                  |
| Shuffle reduction  | Partial (for filter queries)    | Strong (for bucket joins)          |
| Example syntax     | `PARTITIONED BY (region)`       | `CLUSTERED BY (id) INTO 8 BUCKETS` |


---

## 4. Real-Life Analogy

Think of a **school library**:

- **Partitioning** = Different **rooms** for each subject (Math room, Science room, History room)
  - Want a Math book? Go directly to the Math room. Skip all others.
- **Bucketing** = Inside the Math room, books are arranged on **shelves by author name hash**
  - Want to find two authors who collaborate? They're on the same shelf — no searching needed.

---

## 5. Best of Both Worlds — Partition + Bucket Together

For maximum performance, combine both:

```sql
CREATE TABLE orders (
    order_id INT,
    cust_id INT,
    amount DOUBLE
)
PARTITIONED BY (year INT, month INT)
CLUSTERED BY (cust_id) INTO 8 BUCKETS;
```

- `year`, `month` → partitions (for fast filtering / partition pruning)
- `cust_id` → buckets (for fast joins / no shuffle)

---

## 6. Important Config

```
spark.sql.files.maxPartitionBytes = 128 MB (default)
```

This controls how big each **input partition** is when reading files. It's about reading, not about partitioning the output.

---

## Key Takeaway

> **Partitioning** = folder-level split for faster filtering (low-cardinality columns).
> **Bucketing** = file-level split for faster joins (high-cardinality columns).
> Use partitioning when you filter with WHERE, use bucketing when you join repeatedly on the same key.

