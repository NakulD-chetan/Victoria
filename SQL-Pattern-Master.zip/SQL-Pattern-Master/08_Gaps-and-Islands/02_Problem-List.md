# Gaps and Islands — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers consecutive streaks, gap detection, status periods, session grouping, and longest streaks. Sources: LeetCode, HackerRank, DataLemur, StrataScratch.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Consecutive Numbers | LC 180 | Medium | Basic consecutive | Foundation — detect 3+ same values |
| 2 | Human Traffic of Stadium | LC 601 | Hard | 3+ consecutive rows | Consecutive above threshold |
| 3 | Report Contiguous Dates | LC 1225 | Hard | Date islands | Group consecutive dates by type |
| 4 | Find Login Streaks | Common | Medium | Date islands | Consecutive login days per user |
| 5 | Find Missing Dates | Common | Medium | Gap detection | Identify holes in date series |
| 6 | Server Uptime Periods | Common | Medium | Status islands | Group consecutive same-status rows |
| 7 | Longest Winning Streak | StrataScratch | Medium | Max island length | Find longest consecutive group |
| 8 | Session Detection | Common | Hard | Custom gap threshold | Group events into sessions |
| 9 | Consecutive Available Seats | LC 603 | Easy | Adjacent pairs | Simplest consecutive problem |
| 10 | Find Gaps in Sequences | Common | Medium | Gap detection | Find missing numbers in sequence |

---

## Complete 20-Problem Progression

### Easy (Problems 1-4) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Consecutive Available Seats | LC 603 | Adjacent join | Self join a.id + 1 = b.id |
| 2 | Rising Temperature | LC 197 | Adjacent compare | LAG/self join for prev row |
| 3 | Find Missing Numbers | Common | Simple gap | Find holes in 1..N sequence |
| 4 | Consecutive Numbers | LC 180 | 3-consecutive | LAG or triple self join |

### Medium (Problems 5-14) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 5 | Find Login Streaks | Common | Date islands | date - ROW_NUMBER for group |
| 6 | Find Missing Dates | Common | Date gaps | LEAD - date > 1 for holes |
| 7 | Find Gaps in Number Sequence | Common | Numeric gaps | val + 1 to LEAD(val) - 1 |
| 8 | Server Uptime Periods | Common | Status islands | Double ROW_NUMBER trick |
| 9 | Longest Winning Streak | StrataScratch | Max island | MAX(COUNT) per island group |
| 10 | Employee Status Periods | Common | Category islands | Group consecutive same-status |
| 11 | Price Stability Periods | Common | Value islands | Consecutive days same price |
| 12 | Find Consecutive Failures | Common | Status streak | Consecutive error/fail rows |
| 13 | Active Subscription Periods | Common | Date range islands | Merge overlapping subscriptions |
| 14 | User Engagement Sessions | DataLemur | Session detection | Gap > threshold = new session |

### Hard (Problems 15-20) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 15 | Human Traffic of Stadium | LC 601 | 3+ consecutive | IDs with people >= 100 |
| 16 | Report Contiguous Dates | LC 1225 | Date + type islands | Double ROW_NUMBER on type + date |
| 17 | Session Duration Analysis | Common | Session + agg | Find sessions, compute duration |
| 18 | Stock Consecutive Days Up | Common | Price streak | Consecutive days price increased |
| 19 | Merge Overlapping Intervals | Advanced | Interval merge | Combine overlapping time ranges |
| 20 | Find N-Day Active Streaks | Advanced | Streak + filter | Users with streak >= N days |

---

## Problem-by-Problem Strategy Notes

### Problem 1: Consecutive Numbers (LC 180)

```
Pattern:     3 consecutive same values
Approach:    LAG(num,1), LAG(num,2) — check curr = lag1 = lag2
             OR: Self join l.id+1=m.id AND m.id+1=r.id, all num equal
Key Insight: Need exactly 3, so check 2 neighbors
One-liner:   LAG twice or triple self join; all three values must match.
```

### Problem 2: Human Traffic of Stadium (LC 601)

```
Pattern:     3+ consecutive rows above threshold
Approach:    1) Filter people >= 100
             2) id - ROW_NUMBER() OVER (ORDER BY id) AS grp
             3) COUNT per grp, keep groups with COUNT >= 3
             4) Return original rows from qualifying groups
Key Insight: After filtering, id - ROW_NUMBER is constant for consecutive IDs
One-liner:   Filter by threshold; id - ROW_NUMBER groups; keep groups of 3+.
```

### Problem 3: Report Contiguous Dates (LC 1225)

```
Pattern:     Date islands by type (succeeded/failed)
Approach:    ROW_NUMBER global - ROW_NUMBER per type = group ID
             GROUP BY type + group: MIN(date) as start, MAX(date) as end
Key Insight: Two ROW_NUMBERs: one overall, one per status type
One-liner:   Double ROW_NUMBER trick; group by type + diff; min/max dates.
```

### Problem 8: Session Detection

```
Pattern:     LAG + running SUM for custom gap threshold
Approach:    1) LAG(event_time) — compute gap to previous event
             2) Flag: gap > 30 min → 1, else 0
             3) Running SUM of flags = session_id
             4) GROUP BY session_id for session boundaries
Key Insight: Running SUM of binary flags creates auto-incrementing group IDs
One-liner:   Flag large gaps; running sum of flags = session ID; group by it.
```

---

## Pattern Distribution

```
NUMERIC/DATE ISLANDS (consecutive detection):  8 problems  (1, 4-5, 9, 11-12, 18, 20)
GAP DETECTION (find missing):                  4 problems  (3, 6-7, 10)
STATUS/CATEGORY ISLANDS (double RN):           4 problems  (8, 10, 16, 17)
SESSION DETECTION (threshold-based):           2 problems  (14, 17)
INTERVAL MERGE:                                2 problems  (13, 19)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: LC 603, LC 197 (adjacent pairs, rising temp)
- Day 2: LC 180 (consecutive numbers — master this first)
- Day 3: Simple gap detection, missing numbers

### Week 2: Core Islands (Days 4-7)
- Day 4: Login streaks (date - ROW_NUMBER)
- Day 5: Status periods (double ROW_NUMBER)
- Day 6: Longest streak, price stability
- Day 7: Session detection (LAG + SUM flags)

### Week 3: Hard + Review (Days 8-10)
- Day 8: LC 601 (stadium traffic)
- Day 9: LC 1225 (contiguous dates), interval merge
- Day 10: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| Simple consecutive comparison | Pattern 01 (Window Functions) — LAG/LEAD |
| Fill the gaps with data | Pattern 11 (Date Series Fill) — generate missing rows |
| Running total during streak | Pattern 07 (Running Total) — SUM OVER within island |
| Compare rows in same table | Pattern 03 (Self Join) — simpler for fixed-depth |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (4 Easy, 10 Medium, 6 Hard)
MUST-DO:            LC 180, 601, 1225, 603 + login streaks, session detection
TOP 3 MOST ASKED:   LC 601 (Stadium), LC 1225 (Contiguous), LC 180 (Consecutive)
PATTERN SPLIT:      Islands (8), Gaps (4), Status islands (4), Sessions (2), Merge (2)
STUDY ORDER:        Adjacent compare → Numeric islands → Status islands → Sessions
KEY INSIGHT:        val - ROW_NUMBER() = constant within consecutive streak
INTERVIEW LINE:     "I use val minus ROW_NUMBER to group consecutive values,
                     double ROW_NUMBER for category-based islands, and
                     LAG + running SUM for session detection."
```

---

## 30-SECOND REVISION BOX

```
ISLAND:          Consecutive rows that belong together
GAP:             Missing value/date between two islands
FORMULA:         val - ROW_NUMBER() OVER (ORDER BY val) = group ID
WHY IT WORKS:    Both increment by 1 when consecutive → difference constant
STATUS ISLANDS:  rn_global - rn_per_status = group ID (double ROW_NUMBER)
SESSION:         LAG gap > threshold → flag=1; SUM(flag) OVER = session_id
BOUNDARIES:      MIN(val), MAX(val) per group = island start/end
LONGEST:         MAX(COUNT(*)) across all groups per user
GAPS:            LEAD(val) - val > 1 → gap from val+1 to LEAD(val)-1
```
