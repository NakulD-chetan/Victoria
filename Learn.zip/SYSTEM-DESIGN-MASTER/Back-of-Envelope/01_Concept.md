# Back-of-Envelope Estimation — Concept



---

## Why Estimation Matters

In system design interviews, you must **size** the system: QPS, storage, bandwidth, server count. Back-of-envelope estimation shows you can translate user scale into technical requirements.

```
    User Scale  →  Actions/Time  →  QPS  →  Servers / Storage / Bandwidth
         │              │              │
    DAU, MAU      requests/day      peak vs avg
```

> **FAANG Tip:** Estimation is the bridge between "we have 500M users" and "we need 1000 web servers." Interviewers expect this step early in the design.

---

## Latency Numbers Every Programmer Should Know


| Operation                                 | Latency | Notes                 |
| ----------------------------------------- | ------- | --------------------- |
| **L1 cache reference**                    | 0.5 ns  | On-CPU                |
| **L2 cache reference**                    | 7 ns    | On-CPU                |
| **Main memory (RAM)**                     | 100 ns  | ~200× L2              |
| **SSD random read**                       | 150 μs  | ~1.5× RAM             |
| **HDD seek**                              | 10 ms   | ~100× SSD             |
| **Network round trip (same DC)**          | 500 μs  | RTT within datacenter |
| **Network round trip (CA → Netherlands)** | 150 ms  | Cross-continental     |
| **Round trip within same rack**           | ~0.5 ms | ~500 μs               |
| **Packet round trip US → Europe**         | ~150 ms | ~100 ms each way      |


```
    HIERARCHY (fast → slow)
    L1 (0.5ns)  →  L2 (7ns)  →  RAM (100ns)  →  SSD (150μs)  →  HDD (10ms)  →  Network (500μs–150ms)
```

---

## Powers of 2 Reference Table


| Exponent | Value | Common Usage                  |
| -------- | ----- | ----------------------------- |
| 2^10     | 1 KB  | Small object, cache entry     |
| 2^20     | 1 MB  | Image, document               |
| 2^30     | 1 GB  | RAM per process, DB buffer    |
| 2^40     | 1 TB  | Single server disk, DB shard  |
| 2^50     | 1 PB  | Data warehouse, large cluster |


| 2^10 | 1 KB | 2^30 | 1 GB |
| 2^20 | 1 MB | 2^40 | 1 TB |
| 2^25 | 32 MB | 2^50 | 1 PB |

---

## QPS Estimation

**Formula:** `QPS = DAU × avg_requests_per_user / 86400`

- `86400` = seconds per day
- Typical: **average QPS** ≈ 1/10 to 1/20 of peak (traffic varies by hour)
- **Peak QPS** ≈ 2–3× average for uniform, up to **10×** for viral spikes

```
    Average QPS = Total requests per day / 86400
    Peak QPS    ≈ 2× to 10× Average QPS (assume 3× if unspecified)
```

---

## Storage Estimation

**Formula:** `Total Storage = items × bytes_per_item × replication_factor`

Include: **metadata overhead** (indexes, IDs, timestamps ~20–30%), **replication** (3× for typical durability), **compression** (optional 2–5× for text).

---

## Bandwidth Estimation

**Formula:** `Bandwidth (bps) = QPS × avg_response_size × 8`

- Response size in bytes → multiply by 8 for bits
- Include both **ingress** (requests) and **egress** (responses); egress often dominates.

---

## Common Server Capacity


| Component         | Approximate Capacity | Notes                 |
| ----------------- | -------------------- | --------------------- |
| 1 web server      | ~1,000 QPS           | Stateless, CPU-bound  |
| 1 DB server       | ~5,000 read QPS      | With indexes          |
| 1 DB server       | ~1,000 write QPS     | Writes cost more      |
| 1 Redis           | ~100,000 QPS         | In-memory, simple ops |
| 1 Kafka partition | ~10–100 K msg/s      | Ordered throughput    |


---

## Read vs Write Ratio


| System Type     | Typical Read:Write | Impact                       |
| --------------- | ------------------ | ---------------------------- |
| Social feed     | 100:1              | Heavy caching, read replicas |
| Chat            | 1:1                | Balanced                     |
| Video streaming | 1000:1             | CDN + caching dominates      |
| E-commerce      | 10:1               | Cache product, DB for writes |
| Search          | 100:1              | Read-heavy, index-heavy      |


---

## Rule of 72 (Growth)

**Doubling time (years) ≈ 72 / growth_rate_percent**

- 10% growth → ~7 years to double
- 20% growth → ~3.6 years to double
- 50% growth → ~1.4 years to double

---

## Standard Scale References


| System       | Approximate Scale    | Use for Sanity Check         |
| ------------ | -------------------- | ---------------------------- |
| **Twitter**  | 500M tweets/day      | ~6K writes/sec avg           |
| **Google**   | 8.5B searches/day    | ~100K QPS avg                |
| **WhatsApp** | 100B messages/day    | ~1.2M messages/sec           |
| **Netflix**  | 200M+ subscribers    | Streaming bandwidth dominant |
| **YouTube**  | 500 hrs/min uploaded | Storage + transcoding        |


---

## 30-SECOND REVISION BOX

```
LATENCY: L1 0.5ns → L2 7ns → RAM 100ns → SSD 150μs → HDD 10ms → DC RTT 500μs → CA-NL 150ms
POWERS: 2^10=1KB, 2^20=1MB, 2^30=1GB, 2^40=1TB, 2^50=1PB
QPS: DAU × requests / 86400 | Peak ≈ 2–10× avg
CAPACITY: Web ~1K, DB read ~5K, Redis ~100K QPS
READ:WRITE: Feed 100:1, Chat 1:1, Video 1000:1
RULE OF 72: Doubling years ≈ 72 / growth%
```

---

**Next: [[02_Mental-Model]]**