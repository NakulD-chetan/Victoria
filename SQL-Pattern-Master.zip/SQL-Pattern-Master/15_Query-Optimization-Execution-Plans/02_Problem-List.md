# Query Optimization and Execution Plans — Problem List

> **15 problems in progressive difficulty. 8 MUST-DO highlighted. Covers EXPLAIN reading, index selection, query rewriting, join optimization, and anti-pattern fixing. Sources: Real-world scenarios, HackerRank, StrataScratch, Interview questions.**

---

## 8 MUST-DO Problems (Start Here)

| # | Problem | Platform | Difficulty | Concept Tag | Why Important |
|---|---------|----------|------------|-------------|---------------|
| 1 | Read a Basic EXPLAIN Plan | Common | Easy | EXPLAIN reading | Foundation — understand plan nodes |
| 2 | Add Index to Fix Seq Scan | Common | Easy | Index creation | Most common optimization |
| 3 | Rewrite Function on Indexed Column | Common | Medium | Sargability | WHERE YEAR(date) → range condition |
| 4 | Choose Correct Composite Index | Common | Medium | Index design | Column order in composite index |
| 5 | Convert NOT IN to NOT EXISTS | Common | Medium | NULL-safe rewrite | Fix broken + slow query |
| 6 | Optimize Correlated Subquery | Common | Medium | Rewrite as JOIN | O(N^2) → O(N log N) |
| 7 | Identify Hash vs Nested Loop | Common | Medium | Join strategy | Read plan, understand join choice |
| 8 | Full Query Optimization Scenario | Common | Hard | End-to-end | Given slow query, make it fast |

---

## Complete 15-Problem Progression

### Easy (Problems 1-4) — Build Foundation

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 1 | Read a Basic EXPLAIN Plan | Common | Plan reading | Identify scan type, cost, rows |
| 2 | Add Index to Fix Seq Scan | Common | B-tree index | CREATE INDEX on WHERE column |
| 3 | Explain Why Query Is Slow | Common | Analysis | Read EXPLAIN, spot the bottleneck |
| 4 | Compare Two Query Approaches | Common | Cost comparison | EXPLAIN both, compare costs |

### Medium (Problems 5-11) — Core Patterns

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 5 | Rewrite Function on Index Column | Common | Sargability | YEAR(date) → range, LOWER → functional index |
| 6 | Choose Composite Index Order | Common | Index design | Most selective column first, query patterns |
| 7 | Convert NOT IN to NOT EXISTS | Common | Rewrite | NULL safety + performance |
| 8 | Optimize Correlated Subquery | Common | Rewrite as JOIN | Eliminate per-row subquery execution |
| 9 | Identify Join Strategy | Common | Plan reading | Hash vs Nested Loop vs Merge |
| 10 | Fix OR Condition Performance | Common | UNION ALL rewrite | OR → UNION ALL for index usage |
| 11 | Covering Index Design | Common | Index-only scan | INCLUDE columns for SELECT list |

### Hard (Problems 12-15) — Interview Differentiators

| # | Problem | Platform | Concept | Key Skill |
|---|---------|----------|---------|-----------|
| 12 | Full Query Optimization | Common | End-to-end | Multi-step: read plan, add index, rewrite |
| 13 | Partition Pruning | Advanced | Table partitioning | Verify partition elimination in plan |
| 14 | Materialized View vs Query | Advanced | Precomputation | When to materialize vs compute |
| 15 | Estimate Query Cost | Advanced | Cost model | Calculate IO + CPU cost manually |

---

## Problem-by-Problem Strategy Notes

### Problem 2: Add Index to Fix Seq Scan

```
Scenario:    SELECT * FROM orders WHERE customer_id = 42 — does Seq Scan
Diagnosis:   EXPLAIN shows Seq Scan on orders, cost=0..150000
Fix:         CREATE INDEX idx_orders_customer ON orders(customer_id);
Verify:      EXPLAIN again → Index Scan, cost drops 100×
One-liner:   Seq Scan on WHERE column → add B-tree index on that column.
```

### Problem 5: Rewrite Function on Indexed Column

```
Scenario:    WHERE YEAR(order_date) = 2024 — Seq Scan despite index on order_date
Diagnosis:   Function on column prevents index usage (not "sargable")
Fix:         WHERE order_date >= '2024-01-01' AND order_date < '2025-01-01'
Verify:      EXPLAIN → Index Scan on order_date range
One-liner:   Never apply functions to indexed columns; rewrite as range condition.
```

### Problem 8: Optimize Correlated Subquery

```
Scenario:    SELECT e.* FROM employees e
             WHERE salary > (SELECT AVG(salary) FROM employees WHERE dept = e.dept)
             — O(N × M) execution
Fix 1:       CTE: compute avg per dept first, then JOIN
             WITH dept_avg AS (SELECT dept, AVG(salary) FROM employees GROUP BY dept)
             SELECT e.* FROM employees e JOIN dept_avg d ON e.dept = d.dept
             WHERE e.salary > d.avg_sal
Fix 2:       Window function: AVG(salary) OVER (PARTITION BY dept)
One-liner:   Replace correlated subquery with CTE or window function for single scan.
```

### Problem 12: Full Query Optimization Scenario

```
Scenario:    Complex slow query with multiple joins, subqueries, and aggregates
Step 1:      EXPLAIN ANALYZE — identify most expensive node
Step 2:      Check for Seq Scans on large tables → add indexes
Step 3:      Check for Nested Loops on large tables → ensure Hash Join
Step 4:      Check for Sort operations → add index matching ORDER BY
Step 5:      Check estimated vs actual rows → run ANALYZE for fresh stats
Step 6:      Rewrite anti-patterns (NOT IN, function on column, SELECT *)
One-liner:   EXPLAIN → find bottleneck → fix scan/join/sort → verify improvement.
```

---

## Optimization Checklist (Use for Every Slow Query)

```
□ Run EXPLAIN ANALYZE — read bottom-up
□ Check for Seq Scan on large tables → add index
□ Check for function on indexed column → rewrite as range
□ Check for NOT IN → convert to NOT EXISTS
□ Check for correlated subquery → rewrite as JOIN/CTE
□ Check for SELECT * → select only needed columns
□ Check for missing statistics → run ANALYZE
□ Check join strategy → ensure appropriate join type
□ Check ORDER BY → add index matching sort order
□ Check for LIMIT without index → add index for TOP-N
```

---

## Pattern Distribution

```
PLAN READING (understand EXPLAIN):      4 problems  (1, 3-4, 9)
INDEX DESIGN (create right index):      4 problems  (2, 6, 11, 13)
QUERY REWRITE (fix anti-patterns):      4 problems  (5, 7-8, 10)
END-TO-END OPTIMIZATION:               3 problems  (12, 14-15)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)
- Day 1: Run EXPLAIN on simple queries, read plan output
- Day 2: Add indexes, observe plan changes
- Day 3: Compare costs of different approaches

### Week 2: Core Techniques (Days 4-6)
- Day 4: Sargability — rewrite function-on-column patterns
- Day 5: NOT IN → NOT EXISTS, correlated → JOIN
- Day 6: Composite index design, covering indexes

### Week 3: Advanced + Review (Days 7-8)
- Day 7: Full optimization scenarios, partition pruning
- Day 8: Practice explaining optimization decisions verbally

---

## Cross-Reference: Related Patterns

| If You Need... | Use This Pattern Instead/Also |
|-----------------|-------------------------------|
| NOT EXISTS pattern | Pattern 05 (Subquery/EXISTS) — detailed coverage |
| Window function instead of subquery | Pattern 01 (Window Functions) — single-scan approach |
| CTE instead of correlated subquery | Pattern 02 (CTE) — cleaner multi-step queries |
| Index for Top-N queries | Pattern 09 (Top-N Per Group) — index on ORDER BY |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     15 (4 Easy, 7 Medium, 4 Hard)
MUST-DO:            EXPLAIN reading, index creation, sargability, rewrite patterns
TOP 3 MOST ASKED:   "Why is this query slow?", composite index, correlated→JOIN
PATTERN SPLIT:      Plan reading (4), Index design (4), Query rewrite (4), E2E (3)
STUDY ORDER:        Read plans → Add indexes → Rewrite anti-patterns → Full scenarios
KEY INSIGHT:        EXPLAIN ANALYZE is your debugger — read it bottom-up
INTERVIEW LINE:     "I optimize by reading EXPLAIN ANALYZE bottom-up, adding
                     indexes for Seq Scans, ensuring sargable WHERE clauses,
                     and rewriting correlated subqueries as JOINs."
```

---

## 30-SECOND REVISION BOX

```
EXPLAIN:         Show plan without running query
EXPLAIN ANALYZE: Run query + show actual vs estimated metrics
READ BOTTOM-UP:  Innermost node executes first
SEQ SCAN:        Full table read — usually bad for large tables → add index
INDEX SCAN:      B-tree lookup — fast for selective queries
HASH JOIN:       Best for large-large equi-join
NESTED LOOP:     Good for small outer + indexed inner
SARGABLE:        WHERE col = val ✓ | WHERE FUNC(col) = val ✗
COMPOSITE:       (a, b) index works for WHERE a=x or WHERE a=x AND b=y
                 Does NOT work for WHERE b=y alone
COVERING:        CREATE INDEX ... INCLUDE (col) — enables index-only scan
STATISTICS:      Run ANALYZE for fresh table stats → better optimizer choices
```
