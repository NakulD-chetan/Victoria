# DETAILED EXPLANATION (SIMPLE LANGUAGE, FULL COVERAGE, NO TRIMMING)

Source: :contentReference[oaicite:0]{index=0}


==================================================
1. TYPES OF DIMENSIONS (VERY IMPORTANT)
==================================================

Key idea:
- Dimension = context (who, what, where, when, why)
- Different types of dimensions solve different problems

Types:
1. Conformed Dimension  
2. Role-Playing Dimension  
3. Junk Dimension  
4. Degenerate Dimension  


----------------------------------------
Real-world analogy
----------------------------------------

Think of labels in a store:

- Standard barcode → used everywhere → conformed  
- Same label reused differently → role-playing  
- Small flags combined → junk  
- Transaction ID on receipt → degenerate  



==================================================
2. CORE IDEA (VERY IMPORTANT)
==================================================

Dimension:
- Logical concept (e.g., product, store)

Dimension Table:
- Physical table (e.g., dim_product)

Important:
Facts = numbers  
Dimensions = explanation of numbers  



==================================================
3. CONFORMED DIMENSION
==================================================

Definition:
- Same dimension used across multiple fact tables
- Same structure, same meaning


----------------------------------------
Example
----------------------------------------

dim_date used in:
- sales
- inventory
- orders


----------------------------------------
Why important?
----------------------------------------

- Consistency
- Integration across systems


----------------------------------------
Example
----------------------------------------

store_key same in:
- POS system
- online sales


----------------------------------------
Important Rule
----------------------------------------
Conformed = same key + same meaning


----------------------------------------
Problem if not conformed
----------------------------------------
- Different results across reports



==================================================
4. ROLE-PLAYING DIMENSION
==================================================

Definition:
- Same dimension used multiple times in one fact


----------------------------------------
Example
----------------------------------------

Order table has:
- order_date
- ship_date


Both use:
- dim_date


----------------------------------------
SQL Example
----------------------------------------

JOIN dim_date d1 ON order_date  
JOIN dim_date d2 ON ship_date  


----------------------------------------
Important Insight
----------------------------------------
- Same table
- Different roles


----------------------------------------
Key point
----------------------------------------
No data duplication



==================================================
5. JUNK DIMENSION
==================================================

Definition:
- Combines multiple small attributes into one table


----------------------------------------
Example attributes
----------------------------------------

- is_online
- is_discounted
- payment_type


----------------------------------------
Without junk
----------------------------------------
- Many columns in fact


----------------------------------------
With junk
----------------------------------------
- One foreign key


----------------------------------------
Example
----------------------------------------

dim_checkout_profile:
- channel
- fulfillment
- discount flag


----------------------------------------
Important Insight
----------------------------------------
- Reduces fact table size


----------------------------------------
Warning
----------------------------------------
Too many combinations → explosion



==================================================
6. DEGENERATE DIMENSION
==================================================

Definition:
- Dimension stored directly in fact table
- No separate dimension table


----------------------------------------
Example
----------------------------------------

- transaction_id
- receipt_number


----------------------------------------
Why?
----------------------------------------
- No extra attributes
- Only identifier


----------------------------------------
Important Insight
----------------------------------------
- High cardinality
- Not useful as separate dimension


----------------------------------------
Example
----------------------------------------

fact_sales:
- transaction_id stored directly



==================================================
7. COMPARISON OF DIMENSION TYPES
==================================================

Conformed:
- Shared across facts

Role-playing:
- Same dimension used multiple times

Junk:
- Combine small flags

Degenerate:
- Stored in fact only



==================================================
8. SQL PATTERN (JUNK DIMENSION)
==================================================

Step 1: Create dimension

INSERT INTO dim_checkout_profile
(channel, fulfillment, is_discounted)


Step 2: Map to fact

UPDATE fact_sales
SET checkout_profile_key = ...


----------------------------------------
Meaning
----------------------------------------
- Replace multiple columns with one key



==================================================
9. FACT + DIMENSION RELATION
==================================================

Example structure:

fact_sales
  → dim_product
  → dim_store
  → dim_date
  → dim_checkout_profile (junk)
  → transaction_id (degenerate)


----------------------------------------
Important Insight
----------------------------------------
Each dimension adds context



==================================================
10. COMMON MISTAKES
==================================================

----------------------------------------
1. Multiple date dimensions
----------------------------------------
Problem:
- Inconsistent data

Fix:
- Use one conformed dim_date


----------------------------------------
2. Junk dimension explosion
----------------------------------------
Problem:
- Too many combinations

Fix:
- Use only low-cardinality fields


----------------------------------------
3. Creating dimension for every ID
----------------------------------------
Problem:
- Unnecessary joins

Fix:
- Use degenerate dimension


----------------------------------------
4. Not conforming keys
----------------------------------------
Problem:
- Data mismatch

Fix:
- Standardize keys


----------------------------------------
5. Poor naming for role-playing
----------------------------------------
Problem:
- Confusion

Fix:
- Use clear names (order_date, ship_date)



==================================================
11. FINAL TAKEAWAY
==================================================

Dimension types help:
- Optimize design
- Improve performance
- Maintain consistency


----------------------------------------
Golden Rule
----------------------------------------

Use right dimension type for right problem


----------------------------------------
Key Insight
----------------------------------------

- Conformed → integration
- Role-playing → reuse
- Junk → optimization
- Degenerate → simplicity


----------------------------------------
Goal
----------------------------------------

Make data:
- consistent
- efficient
- easy to use



==================================================
12. QUICK MEMORY SUMMARY
==================================================

Conformed:
- Shared across facts

Role-playing:
- Same dimension, multiple roles

Junk:
- Combine small flags

Degenerate:
- Stored in fact

Rule:
- Choose based on use case