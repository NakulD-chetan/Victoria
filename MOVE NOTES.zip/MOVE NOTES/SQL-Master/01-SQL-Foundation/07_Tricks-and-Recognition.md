# SQL Foundation — Tricks and Recognition

---

## When you hear “schema migration”

→ Think **DDL** (`ALTER`, new columns, indexes), often with backward/forward compatibility.

---

## When you hear “orphan rows”

→ Missing **parent** for FK, or bad ETL — fix with constraints + cleanup.

---

## When interviewer says “surrogate key”

→ Artificial id (`BIGINT`) vs business key — prefer surrogate for stable joins.

---

## Quick vocabulary match

| Phrase | Points to |
|--------|-----------|
| Entity integrity | PK / uniqueness |
| Referential integrity | FK |
| Domain integrity | `CHECK`, types, `NOT NULL` |

---

*Next: [[08_Problem-List]]*
