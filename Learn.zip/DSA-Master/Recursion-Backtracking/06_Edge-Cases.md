# Recursion-Backtracking — Edge Cases

> **Permanent Recall:** Empty input, single element, all duplicates, no valid solution, deep recursion (stack limit), large n. Always test n=0, n=1, all-same, and "impossible" cases.

---

## 1. Empty Input

### Subsets / Permutations / Combinations

- `nums = []` → return `[[]]` for subsets (empty set is valid)
- `nums = []` → return `[]` for permutations
- `n=0, k=0` → combinations: `[[]]` or `[]` depending on problem

### Combination Sum

- `candidates = []`, target = 5 → `[]`
- `target = 0` → `[[]]` (empty combination sums to 0)

### N-Queens

- `n = 0` → `[[]]` (empty board, one "solution")

### Word Search

- `word = ""` → typically true (empty string found)
- `board = []` → false

---

## 2. Single Element

### Subsets

- `nums = [1]` → `[[], [1]]`

### Permutations

- `nums = [1]` → `[[1]]`

### Combinations

- `n=1, k=1` → `[[1]]`
- `n=1, k=2` → `[]` (impossible)

### N-Queens

- `n=1` → `[["Q"]]`

### Word Search

- `board = [['a']]`, `word = "a"` → true

---

## 3. All Duplicates

### Subsets with Duplicates

- `nums = [1, 1, 1]` → `[[], [1], [1,1], [1,1,1]]` (4 subsets, not 8)
- Must sort and skip: `i > start and nums[i] == nums[i-1]`

### Permutations with Duplicates

- `nums = [1, 1, 1]` → `[[1,1,1]]` (one unique permutation)
- Without skip logic: 6 duplicate permutations

### Combination Sum II

- `candidates = [1, 1, 1]`, target = 2 → `[[1, 1]]` (one way, using two 1s)
- Must not produce `[1,1]` twice from different indices

---

## 4. No Valid Solution

### Combination Sum

- `candidates = [2, 4, 6]`, target = 5 → `[]`
- All candidates > target or no combination sums exactly

### Combination Sum II

- `candidates = [10, 20]`, target = 5 → `[]`

### N-Queens

- `n = 2` or `n = 3` → `[]` (no valid placement)

### Sudoku

- Invalid initial board (no solution) → return false / don't modify

### Word Search

- Word not in grid → false

### Handling

- Return empty list `[]` or empty vector
- Don't infinite loop; pruning should eventually exhaust options

---

## 5. Very Deep Recursion (Stack Limit)

### When It Happens

- n = 20+ for subsets/permutations
- Large grid for Word Search
- Python default recursion limit ~1000

### Mitigations

| Language | Approach |
|----------|----------|
| Python | `sys.setrecursionlimit(10**6)` — use sparingly |
| All | Prefer iterative/stack-based if n very large |
| All | Consider DP if counting only (no enumeration) |

### FAANG Interview Reality

- n usually ≤ 20 for enumeration
- If n is large, problem likely wants DP or different approach
- Mention: "For very large n we might hit stack limits; we could convert to iterative with explicit stack."

---

## 6. Large Constraint Values

### Combination Sum

- `target = 10^9` — even with pruning, may be slow
- Pruning: sort, break when `candidates[i] > remain`

### N-Queens

- `n = 9` — tractable
- `n = 15` — may be slow; pruning is critical

### General

- If constraints are huge, verify that backtracking is expected
- Some problems want only count → DP

---

## 7. Negative Numbers / Zero

### Combination Sum

- `candidates = [-1, 1, 2]`, target = 0 → valid
- Zero in candidates: can sum to 0 with `[0]` or `[]`
- Negative: sort still helps for "break when > remain" only if all positive; otherwise need different pruning

### Subsets

- Negative numbers don't change the logic
- Zero: include/exclude as usual

---

## 8. Word Search Edge Cases

| Case | Expected |
|------|----------|
| `word` longer than total cells | false |
| `word` has repeated char (e.g. "aaa") | Must not reuse same cell |
| 1×1 board, word length 1 | Check if char matches |
| Word not starting from any cell | false |

---

## 9. N-Queens Edge Cases

| n | Result |
|---|--------|
| 0 | `[[]]` or `[]` |
| 1 | `[["Q"]]` |
| 2 | `[]` |
| 3 | `[]` |
| 4 | 2 solutions |

---

## 10. Sudoku Edge Cases

- Already solved board → return quickly
- Multiple solutions → typically return first found
- Invalid initial (duplicate in row/col/box) → no solution

---

## Test Case Checklist

| Case | Subsets | Permute | Combo Sum | N-Queens | Word |
|------|---------|---------|-----------|----------|------|
| Empty input | `[[]]` | `[]` | `[]` or `[[]]` | `[[]]` | - |
| Single elem | `[[],[x]]` | `[[x]]` | - | `[["Q"]]` | - |
| All dup | 2^n unique | 1 perm | - | - | - |
| No solution | - | - | `[]` | `[]` (n=2,3) | false |
| n=0 | `[[]]` | `[]` | - | `[[]]` | - |

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:           [] → [[]] for subsets, [] for permute
SINGLE:          [x] → [[],[x]] or [[x]]
ALL DUP:         Sort + skip, avoid duplicate subsets/perms
NO SOLUTION:     Return [], don't loop forever
DEEP RECURSE:    n>20, stack limit; consider iterative
LARGE TARGET:    Prune early, break when elem > remain
N-QUEENS n=2,3:  No solution → []
WORD SEARCH:     Empty word, 1x1 board, repeated chars
TEST:            n=0, n=1, all same, impossible
```
