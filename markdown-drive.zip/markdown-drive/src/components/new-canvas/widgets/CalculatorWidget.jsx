import { memo, useState } from 'react';
import { useNewCanvasStore } from '../state/store';

function CalculatorWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [display, setDisplay] = useState('0');

  const handlePress = (val) => {
    if (val === 'C') return setDisplay('0');
    if (val === '=') {
      try {
        // Safe eval for basic calc
        // eslint-disable-next-line no-new-func
        const res = new Function(`return ${display}`)();
        setDisplay(String(res));
      } catch {
        setDisplay('Error');
      }
      return;
    }
    setDisplay((prev) => (prev === '0' || prev === 'Error' ? val : prev + val));
  };

  const onDelete = () => {
    commitElements((els) => els.map((e) => (e.id === element.id ? { ...e, isDeleted: true } : e)));
  };

  const bg = data.chromeBg || '#1e293b';
  const stroke = element.style?.stroke || '#475569';

  const buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    'C', '0', '=', '+'
  ];

  return (
    <div
      className="nc-widget"
      style={{
        background: bg,
        borderColor: stroke,
        borderWidth: element.style?.strokeWidth ?? 1,
        borderStyle: 'solid',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      <div className="nc-widget-header" data-nc-drag-handle="1">
        <div className="nc-widget-header__label">{data.title || 'Calculator'}</div>
        <div className="nc-widget-header__actions">
          <button type="button" className="nc-widget-header__btn" onClick={onDelete}>×</button>
        </div>
      </div>
      <div className="nc-widget-body" style={{ padding: '16px', flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div style={{
          background: '#0f172a',
          padding: '12px',
          textAlign: 'right',
          fontSize: '24px',
          borderRadius: '4px',
          marginBottom: '16px',
          fontFamily: 'monospace',
          color: '#38bdf8',
          minHeight: '28px',
          overflow: 'hidden'
        }}>
          {display}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', flex: 1 }}>
          {buttons.map((btn) => (
            <button
              key={btn}
              onClick={() => handlePress(btn)}
              style={{
                background: ['/', '*', '-', '+', '='].includes(btn) ? '#38bdf8' : '#334155',
                color: ['/', '*', '-', '+', '='].includes(btn) ? '#0f172a' : '#f8fafc',
                border: 'none',
                borderRadius: '4px',
                fontSize: '18px',
                fontWeight: 'bold',
                cursor: 'pointer',
                pointerEvents: 'auto',
              }}
            >
              {btn}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default memo(CalculatorWidgetImpl);
