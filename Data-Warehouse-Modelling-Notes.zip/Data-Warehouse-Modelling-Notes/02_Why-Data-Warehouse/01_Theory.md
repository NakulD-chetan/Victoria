# Why Do We Need a Data Warehouse

> *"Without data you're just another person with an opinion."* — W. Edwards Deming

**Real-world analogy:** Imagine a **kitchen** where chefs are plating meals during the dinner rush. If every regional manager walked into that kitchen during service to ask *"How many gluten-free desserts did we sell last year?"*, meals would burn and tickets would collapse. A data warehouse is the **dining room's menu analytics binder** — fed from the kitchen, but **separate** from the heat of service.

---

## Core Idea (2 Lines)

Operational systems **optimize for correctness and speed of transactions**, not for cross-system reporting at scale. A data warehouse **consolidates, cleanses, and histories** data so analytics workloads **do not destabilize production** and leaders can answer questions with **one governed source**.

---

## The Problem: Scattered Data Across Operational Silos

| Symptom | What you observe in a large retailer |
|---------|----------------------------------------|
| **Multiple sources of truth** | Web commerce DB, marketplace partner feeds, store POS, loyalty platform — each has its own customer key |
| **Inconsistent definitions** | *"Order"* might mean placed, paid, shipped, or delivered depending on the system |
| **Limited history** | OLTP databases archive or purge aggressively to stay fast |
| **Schema churn** | Application releases change tables without warning reporting teams |

```
+----------------+   +----------------+   +----------------+
|  Web Commerce  |   | Partner POS /  |   | Loyalty / CRM  |
|  (orders DB)   |   | 3rd-party API  |   | (events)       |
+-------+--------+   +--------+-------+   +--------+-------+
        |                     |                    |
        v                     v                    v
   "Revenue?"            "Revenue?"            "Revenue?"
        \                     |                    /
         v                    v                   v
              THREE DIFFERENT ANSWERS (without a DW)
```

**Interview Tip:** Frame the problem as **integration + history + workload isolation**, not "we needed more disk."

---

## Five Benefits of a Data Warehouse

| Benefit | Plain language | Retail example |
|---------|----------------|----------------|
| **Single source of truth** | One place for official KPIs | Finance and merchandising both use the same *Net Sales* definition |
| **Faster reads for analytics** | Layout and engines tuned for scans/aggregates | Year-over-year category trends without hammering checkout DBs |
| **Cleaned, conformed data** | Rules applied once, reused everywhere | One `product_id` across web bundles and store barcodes |
| **Historical storage** | You can time-travel for analysis | *Promotional lift* last holiday season vs the season before |
| **Isolates production** | Reporting load is separated from OLTP | Black Friday checkout stays stable while analysts refresh dashboards |

**Watch Out!** "Single source of truth" still requires **governance**. A DW without owners becomes a **single source of disagreement**.

---

## Why OLTP Databases Are Poor for Heavy Reporting

| OLTP strength | Why it conflicts with reporting |
|---------------|----------------------------------|
| Row-oriented storage | Analytical queries often read **few columns across many rows** — inefficient on classic rowstores |
| Normalized schemas | Reporting needs **many joins**; query plans explode without careful modeling |
| Frequent small writes | Heavy reads create **lock/latch contention** and cache pressure |
| Tight SLAs on writes | Long-running aggregates **steal resources** from customers trying to pay |

```sql
-- Reporting-style question (expensive if run naively on OLTP during peak)
SELECT p.category,
       SUM(oi.quantity * oi.unit_price) AS gross_line_revenue
FROM order_items oi
JOIN orders o ON oi.order_id = o.order_id
JOIN products p ON oi.product_sku = p.sku
WHERE o.order_ts >= TIMESTAMP '2025-01-01'
  AND o.order_ts <  TIMESTAMP '2026-01-01'
GROUP BY p.category;
```

**Interview Tip:** Say *"OLTP is optimized for **many small transactions with strong integrity**; OLAP needs **fewer, larger read operations** and often **denormalized or columnar** patterns."*

---

## Impact on Production When Analytics Hits OLTP

| Failure mode | What happens | Who notices first |
|--------------|--------------|-------------------|
| **CPU saturation** | Query scans millions of rows | DBAs, SREs |
| **I/O bottlenecks** | Storage queues grow | Checkout latency spikes |
| **Blocking / deadlocks** | Long transactions hold locks | Customers see timeouts |
| **Replication lag** | Read replicas fall behind | Fraud checks, inventory reads become stale |

```
  Analyst runs "big aggregate"
            |
            v
   +------------------+
   | OLTP buffer pool |  <-- hot pages evicted
   +------------------+
            |
            v
   +------------------+
   | Checkout queries |  <-- slower, p95 grows
   +------------------+
```

**Watch Out!** "We'll just use a read replica" helps **some** teams — until **replica lag** and **cost of duplicate compute** become their own crisis. A DW addresses **modeling and governance**, not only load shedding.

---

## Kitchen vs Dining Table (Classic Teaching Analogy)

| Space | Role | Data parallel |
|-------|------|----------------|
| **Kitchen (OLTP)** | Cook under time pressure; ingredients move fast | Capture orders, adjust inventory, process refunds |
| **Dining table (DW/BI)** | Guests compare notes, plan next dinner party | Compare channels, plan assortment, set targets |

**Interview Tip:** Use this analogy to explain **why separation is not duplication of malice** — it is **separation of concerns** for reliability.

---

## Manager Question: "Total Revenue Last Year?"

| Without a mature DW | With a DW |
|---------------------|-----------|
| Someone exports three spreadsheets | A metric *Net Revenue (GAAP)* is defined in a catalog |
| Finance excludes tax; ops includes shipping | Finance and ops read the **same conformed fact table** |
| Returns from January applied to December orders create arguments | **Business rules** for recognition timing are implemented once |
| The query runs for 20 minutes on production | The query hits a **partitioned fact** with **pre-aggregates** where appropriate |

```sql
-- DW-backed answer (illustrative; real models add refunds, FX, etc.)
SELECT SUM(f.net_revenue_usd) AS net_revenue_last_year
FROM fact_sales f
JOIN dim_date d ON f.order_date_sk = d.date_sk
WHERE d.calendar_year = 2025;
```

**Watch Out!** Even with a DW, **bad grain** (double counting marketplace orders) produces confident wrong answers. Modeling discipline matters.

---

## When NOT to Use a Data Warehouse

| Situation | Better fit |
|-----------|------------|
| **Small data**, single team, one operational database | Lightweight reporting on OLTP + careful indexing |
| **Single source** with stable schema and modest history needs | Operational DB + materialized views |
| **Strict real-time only** decisions (milliseconds) | Stream processing + operational stores; DW is often **near real-time** or batch |
| **Exploratory science** on raw blobs | Data lake / lakehouse may land first |

**Interview Tip:** Show judgment: *"We use a DW when **integration, history, and analytical performance** dominate; we avoid over-building when **volume and complexity** do not justify the operating cost."*

---

## Cost of Not Having a Warehouse (Stakeholder View)

| Role | Pain |
|------|------|
| **Executives** | Inconsistent board metrics |
| **Merchandising** | Slow answers during seasonal planning |
| **Finance** | Manual close processes, audit risk |
| **Engineering** | Permanent firefighting from ad hoc reporting on prod |

---

## Staging vs Curated Layers (Why "Warehouse" Is a System)

| Layer | Purpose |
|-------|---------|
| **Landing / staging** | Catch upstream weirdness without polluting curated models |
| **Curated / dimensional** | Publish **trusted** tables for BI |

**Watch Out!** Skipping staging and loading straight to "pretty" tables makes **debugging lineage** painful when a feed breaks.

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Using production OLTP as the enterprise reporting database | **Outages** and **wrong** numbers under load | Introduce a governed analytical path (DW or governed mart) |
| Confusing "we have backups" with "we have history" | Backups are for recovery, not **trend analysis** | Model **time variance** explicitly |
| Building a DW without metric owners | Beautiful tables, endless debates | Pair tech delivery with **data stewardship** |
| Over-promising real-time everything | Architecture sprawl, high cost | Define **latency SLAs** per use case (hourly vs daily) |
| Ignoring data quality at ingest | Garbage accumulates faster at scale | Add validation gates in **staging** |

---

## Key Takeaway

> We need a data warehouse when the business must **integrate many operational silos**, preserve **trustworthy history**, and run **heavy analytical workloads** without **harming production systems**. It delivers a **governed path** from scattered operational truth to decisions — while recognizing that **small, simple, or purely real-time** problems may not warrant a classic DW investment.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Problem: siloed systems, weak history, OLTP not built for scans  |
| Benefits: SSOT, fast reads, cleaned data, history, prod isolation  |
| OLTP vs reporting: kitchen vs dining table separation            |
| Big queries on prod: CPU/IO/lag/locks hurt customers             |
| When NOT to use: tiny data, single source, ms-real-time only    |
| Manager test: "last year revenue" needs definitions + safe compute |
+------------------------------------------------------------------+
```
