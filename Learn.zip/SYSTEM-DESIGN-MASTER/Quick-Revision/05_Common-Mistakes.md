# Quick Revision — Top 10 Killer Mistakes

> **Permanent Recall:** The worst mistakes across ALL topics. Mistake → why fatal → one-line fix. Study before every mock.

---

## The Top 10

| # | Mistake | Why Fatal | One-Line Fix |
|---|---------|-----------|--------------|
| **1** | Diving into solution without requirements | Interviewers test clarification; skip = No Hire | Always: "Let me clarify requirements first..." |
| **2** | Not asking questions | Silence = don't know what to ask | Ask 3–5 clarifying questions upfront |
| **3** | Drawing before thinking | Lock into wrong design | Articulate approach, then draw |
| **4** | Going too deep too early | Run out of time; confuse narrative | Establish high-level first |
| **5** | Not discussing trade-offs | No trade-offs = no judgment shown | Every choice: "Trade-off is... I chose because..." |
| **6** | Over-engineering | Poor judgment; can't prioritize | Start simple; add when needed |
| **7** | Under-engineering | "One server, one DB" — naive | At minimum: LB, stateless app, cache, replicas |
| **8** | Being silent | They can't evaluate thinking | Narrate constantly |
| **9** | Not mentioning monitoring | Design feels academic | Wrap-up: "Monitor latency p99, error rate..." |
| **10** | Forgetting security | Table stakes for real systems | "Auth, HTTPS, rate limit, input validation" |

---

## Severity Legend

| Level | Impact |
|-------|--------|
| **Critical** | Often alone = No Hire |
| **High** | Strong negative; 2+ = risk |
| **Medium** | Hurts score; recoverable |

---

## Pre-Interview Checklist

- [ ] I will clarify requirements before designing
- [ ] I will ask 3–5 clarifying questions
- [ ] I will articulate before drawing
- [ ] I will discuss trade-offs for major choices
- [ ] I will mention monitoring and security in wrap-up
- [ ] I will handle at least one "what if"
- [ ] I will lead the conversation and manage time

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
