# Heap / Priority Queue — Problem List

> **30 problems in progressive difficulty. 10 MUST-DO highlighted. Heavy focus on Top-K and Two-Heap — the most frequently tested heap patterns at FAANG.**

---

## 10 MUST-DO Problems (Start Here)

| # | Problem | Difficulty | LC# | Concept Tag | Why Important |
|---|---------|-----------|-----|-------------|----------------|
| 1 | **Kth Largest Element in Array** | Medium | 215 | Top-K / Kth | **#1 heap problem — pure Top-K** |
| 2 | **Top K Frequent Elements** | Medium | 347 | Top-K by freq | **Top-K with custom key** |
| 3 | **Find Median from Data Stream** | Hard | 295 | Two-heap | **#1 two-heap problem** |
| 4 | **Merge K Sorted Lists** | Hard | 23 | Merge K | **Classic merge K** |
| 5 | **K Closest Points to Origin** | Medium | 973 | K closest | **Max-heap by distance** |
| 6 | **Task Scheduler** | Medium | 621 | Greedy + heap | **Frequency + cooldown** |
| 7 | **Top K Frequent Words** | Medium | 692 | Top-K + custom sort | **Custom comparator** |
| 8 | **Kth Largest Element in Stream** | Medium | 703 | Streaming Top-K | **Streaming variant** |
| 9 | **Reorganize String** | Medium | 767 | Greedy + heap | **Alternate most frequent** |
| 10 | **Merge K Sorted Lists** (array variant) | Medium | 23 | Merge K | **Same pattern as LC 23** |

---

## Complete 30-Problem Progression

### Easy (Problems 1-6) — Build Foundation

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 1 | Kth Largest Element in Array | 215 | Top-K | Min-heap size K |
| 2 | Kth Largest Element in Stream | 703 | Streaming Top-K | Maintain heap across adds |
| 3 | Last Stone Weight | 1046 | Simulate with heap | Pop two, push diff |
| 4 | K Closest Points to Origin | 973 | K closest | Max-heap by distance |
| 5 | Min Cost to Connect Sticks | 1167 | Greedy heap | Always merge smallest two |
| 6 | Third Maximum Number | 414 | Min-heap size 3 | Keep 3 distinct largest |

### Medium (Problems 7-22) — Core FAANG Level

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 7 | **Top K Frequent Elements** | 347 | Top-K by freq | Min-heap by frequency |
| 8 | **Top K Frequent Words** | 692 | Top-K + custom | Custom comparator (word order) |
| 9 | **Task Scheduler** | 621 | Greedy + heap | Max-heap by freq, cooldown |
| 10 | **Reorganize String** | 767 | Greedy + heap | Alternate most frequent |
| 11 | **Find K Pairs with Smallest Sums** | 373 | K-way merge variant | Min-heap of (i,j) pairs |
| 12 | **Sort Characters By Frequency** | 451 | Max-heap by freq | Build string from heap |
| 13 | **Kth Largest Element in Array** | 215 | Top-K | Foundation |
| 14 | **Design Twitter** | 355 | Heap for feed | K most recent from follows |
| 15 | **Furthest Building You Can Reach** | 1642 | Greedy + heap | Use ladder for largest gaps |
| 16 | **Process Tasks Using Servers** | 1881 | Two heaps | Free servers + busy servers |
| 17 | **Single-Threaded CPU** | 1834 | Scheduling heap | Min-heap by (enqueueTime, index) |
| 18 | **Maximum Subsequence Score** | 2542 | Heap + sort | Pick K from two arrays |
| 19 | **Seat Reservation Manager** | 1845 | Min-heap | Reserve smallest available |
| 20 | **Minimum Operations to Halve Array Sum** | 2208 | Greedy heap | Always halve largest |
| 21 | **Maximum Average Pass Ratio** | 1792 | Max-heap by gain | Greedy add student |
| 22 | **Construct Target Array** | 1354 | Reverse + heap | Work backwards |

### Hard (Problems 23-30) — Interview Differentiators

| # | Problem | LC# | Concept | Key Skill |
|---|---------|-----|---------|-----------|
| 23 | **Find Median from Data Stream** | 295 | Two-heap | Max + Min heap balance |
| 24 | **Merge K Sorted Lists** | 23 | Merge K | Min-heap of list heads |
| 25 | **Trapping Rain Water II** | 407 | BFS + heap | Min-heap of boundary |
| 26 | **Minimum Cost to Hire K Workers** | 857 | Heap + sort | Maintain min-heap of quality |
| 27 | **Sliding Window Maximum** | 239 | Deque (monotonic) | Or heap with lazy delete |
| 28 | **IPO** | 502 | Greedy + heap | Max-heap by profit, min by capital |
| 29 | **Find the Kth Smallest Sum of a Matrix** | 1439 | K-way merge | Heap of (sum, i, j) |
| 30 | **Maximum Performance of a Team** | 1383 | Sort + heap | Fix min speed, heap efficiency |

---

## Problem-by-Problem Strategy Notes

### LC 215: Kth Largest Element ⭐
```
Type: Top-K
Template: Min-heap size K
Key: Root at end = Kth largest
One-liner: Min-heap of size K; evict when larger arrives.
```

### LC 295: Find Median from Data Stream ⭐
```
Type: Two-heap
Template: Max-heap (left) + Min-heap (right)
Key: Balance sizes; median = top(s)
One-liner: Split stream; left max + right min.
```

### LC 347: Top K Frequent Elements ⭐
```
Type: Top-K by frequency
Template: Min-heap size K by (freq, num)
Key: Count first, then heap
One-liner: Counter + min-heap by freq.
```

### LC 23: Merge K Sorted Lists ⭐
```
Type: Merge K
Template: Min-heap of (val, list_idx, node)
Key: Pop smallest, push next from that list
One-liner: Tournament of list heads.
```

### LC 973: K Closest Points ⭐
```
Type: K closest
Template: Max-heap size K by distance²
Key: Evict farthest when closer arrives
One-liner: Max-heap by dist²; keep K closest.
```

### LC 621: Task Scheduler ⭐
```
Type: Greedy + heap
Template: Max-heap by frequency
Key: Pop (n+1) per cycle; push back if count > 1
One-liner: Always pick most frequent; respect cooldown.
```

### LC 703: Kth Largest in Stream ⭐
```
Type: Streaming Top-K
Template: Same as 215, but add() maintains heap
Key: Constructor: add initial k elements; add: heapreplace if larger
One-liner: Min-heap K; add evicts when val > root.
```

### LC 692: Top K Frequent Words ⭐
```
Type: Top-K + custom
Template: Min-heap by (-freq, word) — tiebreak by lex order
Key: Custom comparator: freq desc, then word asc
One-liner: Heap by (-freq, word) for correct tiebreak.
```

### LC 767: Reorganize String ⭐
```
Type: Greedy + heap
Template: Max-heap by freq; pop two, append, push back
Key: Can't reorganize if max_freq > (n+1)/2
One-liner: Alternate two most frequent.
```

### LC 1642: Furthest Building You Can Reach
```
Type: Greedy + heap
Template: Min-heap of ladder uses (largest gaps)
Key: Use ladder for largest jumps; bricks for rest
One-liner: Min-heap of K largest gaps; use ladder for those.
```

---

## Pattern Distribution

```
TOP-K / KTH:       12 problems  (215, 347, 692, 703, 973, etc.)
TWO-HEAP:          1 problem   (295)
MERGE K:           3 problems  (23, 373, 1439)
GREEDY + HEAP:     8 problems  (621, 767, 1046, 1167, 1642, 2208, 502, 857)
CUSTOM / DESIGN:   4 problems  (355, 1834, 1845, 1881)
OTHER:             2 problems  (407, 239)
```

---

## Weekly Study Plan

### Week 1: Top-K Mastery (Days 1-4)
- Day 1: LC 215 (Kth Largest), LC 703 (Stream)
- Day 2: LC 347 (Top K Frequent), LC 692 (Top K Words)
- Day 3: LC 973 (K Closest), LC 451 (Sort by Freq)
- Day 4: LC 373 (K Pairs), LC 2542 (Subsequence Score)

### Week 2: Two-Heap & Merge K (Days 5-7)
- Day 5: LC 295 (Median Stream) — master two-heap
- Day 6: LC 23 (Merge K Lists), array variant
- Day 7: LC 1439 (Kth Smallest Sum), LC 1167 (Connect Sticks)

### Week 3: Greedy + Heap (Days 8-10)
- Day 8: LC 621 (Task Scheduler), LC 767 (Reorganize)
- Day 9: LC 1046 (Last Stone), LC 1642 (Furthest Building)
- Day 10: LC 2208 (Halve Sum), LC 502 (IPO)

### Week 4: Hard & Polish (Days 11-12)
- Day 11: LC 857 (Hire K Workers), LC 1383 (Team Performance)
- Day 12: LC 407 (Rain Water II), LC 1834 (CPU), LC 355 (Twitter)

---

## Top-K and Two-Heap — Quick Reference

| Pattern | Problems |
|---------|----------|
| **Top-K** | 215, 347, 692, 703, 973 |
| **Two-Heap** | 295 |
| **Merge K** | 23, 373, 1439 |
| **Greedy + Heap** | 621, 767, 1046, 1167, 1642, 2208, 502 |

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     30 (6 Easy, 16 Medium, 8 Hard)
MUST-DO:           LC 215, 347, 295, 23, 973, 621, 692, 703, 767
TOP 3 TOP-K:       LC 215 (Kth Largest), LC 347 (Top K Freq), LC 703 (Stream)
TOP 1 TWO-HEAP:    LC 295 (Median Stream)
TOP 1 MERGE K:     LC 23 (Merge K Lists)
PATTERN SPLIT:     Top-K (12), Greedy+Heap (8), Merge K (3), Two-Heap (1)
STUDY ORDER:       Top-K → Two-Heap → Merge K → Greedy+Heap → Hard
INTERVIEW LINE:    "I've practiced Top-K and two-heap patterns — the most
                    frequently tested heap problems at FAANG."
```
