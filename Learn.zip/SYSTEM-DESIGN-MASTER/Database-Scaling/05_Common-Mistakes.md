# Database Scaling — Common Mistakes

> **Permanent Recall:** The top 10 DB scaling mistakes: sharding too early, bad shard key (low cardinality, causes hot spots), ignoring cross-shard queries, not handling replication lag, losing data during migration, uneven shard distribution, not considering re-sharding, ignoring backup strategy, single point of failure in replication, and ignoring connection limits. Avoid these to pass FAANG system design and build production-ready scaled databases.

---

## Mistake 1: Sharding Too Early

**What happens:** Shard before exhausting simpler options → unnecessary complexity, cross-shard joins, hard migrations.

| Wrong | Right |
|-------|-------|
| "We'll shard from day one" | Try vertical scaling, read replicas, caching first |
| Shard at 10K QPS | Shard when single DB cannot handle load |

> **FAANG Tip:** Sharding is irreversible complexity. Exhaust vertical scaling and read replicas first.

---

## Mistake 2: Bad Shard Key

**What happens:** Low cardinality → uneven shards. Wrong key → cross-shard for every query. Time-based → hot shard.

| Bad Key | Problem | Better |
|---------|---------|--------|
| `country` | 200 values, US/India overloaded | `user_id` (high cardinality) |
| `created_at` | Recent shard always hot | `user_id` or `order_id` |
| Key not in query | Every query hits all shards | Shard key = primary query predicate |

---

## Mistake 3: Ignoring Cross-Shard Queries

**What happens:** Need "all users who ordered product X" → must query every shard → slow, complex.

```
CROSS-SHARD: SELECT * FROM orders WHERE product_id = 123
  → Must fan out to ALL shards (sharded by user_id)
  → N queries, merge results
```

**Fix:** Denormalize, maintain product→orders index, or use separate analytics DB.

---

## Mistake 4: Not Handling Replication Lag

**What happens:** User writes, immediately reads from replica → sees old data. Confusion, bugs, lost trust.

**Fix:**
- Route "read-after-write" to master
- Use session affinity (same user → same replica with acceptable lag)
- Accept eventual consistency and document it

---

## Mistake 5: Losing Data During Migration

**What happens:** Migrate shards without dual-write → data loss. Switch reads before backfill complete → missing data.

**Fix:**
- Dual-write to old and new
- Backfill fully before switching reads
- Verify checksums before cutover

---

## Mistake 6: Uneven Shard Distribution

**What happens:** Hash gives skewed distribution; range-based creates hot shards. One shard at 100%, others idle.

**Fix:**
- Use consistent hashing with virtual nodes (150–200)
- Monitor shard sizes and rebalance
- Avoid low-cardinality shard keys

---

## Mistake 7: Not Considering Re-Sharding

**What happens:** Need more shards later → expensive migration. Picked shard key that can't scale.

**Fix:**
- Design for re-sharding (directory-based or consistent hashing)
- Plan 2x–3x headroom before sharding
- Document migration runbook

---

## Mistake 8: Ignoring Backup Strategy

**What happens:** Sharded DB → backup each shard. Restore requires all shards consistent. Cross-shard restore order matters.

**Fix:**
- Backup each shard with consistent point-in-time
- Test restore procedure regularly
- Consider distributed backup (e.g., Percona XtraBackup for MySQL)

---

## Mistake 9: Single Point of Failure in Replication

**What happens:** One master, no automatic failover → master dies, downtime. No replica promotion.

**Fix:**
- Use orchestrator (Orchestrator, Patroni) for auto-failover
- Multi-AZ deployment
- Test failover regularly

---

## Mistake 10: Ignoring Connection Limits

**What happens:** 100 app servers × 50 connections each = 5000 connections. DB limit 1000 → connection exhaustion.

**Fix:**
- Connection pooling (PgBouncer, ProxySQL)
- Limit connections per app instance
- Use proxy to multiplex

---

## Summary Table

| Mistake | Impact | Fix |
|---------|--------|-----|
| Shard too early | Unnecessary complexity | Vertical, replicas, cache first |
| Bad shard key | Hot spots, cross-shard | High cardinality, in query |
| Cross-shard queries | Slow, complex | Denormalize, index, analytics DB |
| Replication lag | Stale reads | Read-from-master for critical |
| Migration data loss | Data gone | Dual-write, backfill, verify |
| Uneven distribution | Hot shard | Virtual nodes, monitor |
| No re-shard plan | Painful scale-out | Design for it, directory/ch |
| Backup strategy | Restore failures | Per-shard backup, test |
| SPOF replication | Downtime on fail | Auto-failover, orchestrator |
| Connection limits | Exhaustion | Pooling, proxy |

---

## 30-SECOND REVISION BOX

```
1. Shard last — vertical, replicas, cache first
2. Shard key — high cardinality, in query, avoid hot spots
3. Cross-shard — plan for it, denormalize
4. Replication lag — handle read-after-write
5. Migration — dual-write, backfill, verify
6. Distribution — virtual nodes, monitor
7. Re-sharding — design for it
8. Backup — per shard, test restore
9. Failover — auto-promote, orchestration
10. Connections — pooling, proxy
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
