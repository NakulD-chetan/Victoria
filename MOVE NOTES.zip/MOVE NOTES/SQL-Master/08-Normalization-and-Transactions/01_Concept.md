# Normalization and Transactions — Concept

> **Permanent recall:** **Normalization** = eliminate redundancy + anomalies by splitting tables (1NF → 2NF → 3NF → BCNF). **Transactions** = ACID guarantees — all-or-nothing, consistent, isolated, durable.

---

## Normalization — Definition

**Normalization** is the process of organizing database tables to minimize data redundancy and dependency. Each normal form builds on the previous one.

---

## Normal Forms (detailed)

| Form | Rule | Eliminates | How to spot violation |
|------|------|-----------|----------------------|
| **1NF** | Atomic values; no repeating groups; each row unique | Multi-value cells, nested tables | Column has comma-separated values or array |
| **2NF** | 1NF + no **partial** dependency (non-key depends on part of composite PK) | Partial dependency | Non-key column depends on only part of composite PK |
| **3NF** | 2NF + no **transitive** dependency (non-key depends on another non-key) | Transitive dependency | Non-key column depends on another non-key column |
| **BCNF** | Every determinant is a candidate key | Remaining anomalies from non-CK determinants | A non-candidate-key determines another column |
| **4NF** | BCNF + no multi-valued dependencies | Independent multi-valued facts in one table | One entity has two independent one-to-many relationships in same table |
| **5NF** | 4NF + no join dependencies | Lossy decomposition | Table can only be reconstructed by joining 3+ tables |

### 4NF Example

```
BAD (not 4NF):
  employee_skills_hobbies(emp_id, skill, hobby)
  → emp_id →→ skill and emp_id →→ hobby are INDEPENDENT multi-valued deps

FIX:
  employee_skills(emp_id, skill)
  employee_hobbies(emp_id, hobby)
```

> **Interview:** Most questions stop at 3NF/BCNF. Mention 4NF/5NF to show depth.

---

## Anomalies (why normalize)

| Anomaly | Problem | Example |
|---------|---------|---------|
| **Insert** | Can't add data without unrelated info | Can't add new department without an employee |
| **Update** | Changing one fact must update many rows | Change dept name → update every employee row |
| **Delete** | Removing a row loses unrelated info | Delete last employee in dept → lose dept info |

---

## Denormalization (when to undo)

**Definition:** Intentionally adding redundancy back to improve read performance.

| When to denormalize | How |
|---------------------|-----|
| **Read-heavy** analytics / dashboards | Precomputed columns, summary tables |
| **Join cost too high** for reporting | Flatten into wide tables |
| **Frequently accessed aggregations** | Materialized views |
| **Caching layer** | Redis/cache for hot data |

**Trade-off:** Faster reads ↔ Harder writes + potential inconsistency.

---

## Star Schema vs Snowflake Schema

| Feature | Star Schema | Snowflake Schema |
|---------|-------------|-----------------|
| **Structure** | Fact table + denormalized dimension tables | Fact table + normalized dimension tables |
| **Joins** | Fewer (fact → dimension directly) | More (dimension → sub-dimension) |
| **Query speed** | Faster (fewer joins) | Slower (more joins) |
| **Storage** | More (redundancy in dimensions) | Less (normalized) |
| **Complexity** | Simpler to understand/query | More complex |
| **Use case** | Data warehouses, BI dashboards | When storage is critical, dimensions are large |

> **Fact table** = measures/metrics (sales amount, quantity). **Dimension table** = descriptors (product name, customer city, date).

---

## ACID

| Property | Meaning | Example |
|----------|---------|---------|
| **Atomicity** | All statements succeed or all rollback | Bank transfer: both debit and credit happen, or neither |
| **Consistency** | DB moves from valid state to valid state | Constraints, triggers satisfied before and after |
| **Isolation** | Concurrent transactions don't interfere | Two users updating same row don't corrupt data |
| **Durability** | Once committed, data survives crash | Write-ahead log ensures data persists |

---

## Isolation levels (weakest → strongest)

| Level | Dirty read | Non-repeatable read | Phantom read | Performance |
|-------|-----------|--------------------|-|-------------|
| **Read Uncommitted** | Yes | Yes | Yes | Fastest |
| **Read Committed** | No | Yes | Yes | Default in Postgres, Oracle |
| **Repeatable Read** | No | No | Yes | Default in MySQL InnoDB |
| **Serializable** | No | No | No | Slowest, safest |

---

## Read Phenomena (detailed)

| Phenomenon | What happens | Example |
|-----------|-------------|---------|
| **Dirty read** | Read uncommitted changes from another tx | Tx1 updates salary to 5000 (not committed); Tx2 reads 5000; Tx1 rollbacks → Tx2 has wrong data |
| **Non-repeatable read** | Re-read same row, different value | Tx1 reads salary=3000; Tx2 updates to 5000 and commits; Tx1 re-reads = 5000 |
| **Phantom read** | Re-run query, different set of rows | Tx1 counts employees=10; Tx2 inserts new employee; Tx1 re-counts=11 |

---

## Locking Types

| Lock | Who can access | Use case |
|------|---------------|----------|
| **Shared (S) lock** | Multiple readers can hold; blocks writers | SELECT with lock |
| **Exclusive (X) lock** | Only one tx; blocks all others | UPDATE, DELETE |
| **Intent lock** | Signals intention to lock at finer level | Table-level hint for row locks |
| **Row lock** | Locks specific row | Most granular, best concurrency |
| **Table lock** | Locks entire table | Least granular, worst concurrency |
| **Page lock** | Locks a page of data | Middle ground |

### Optimistic vs Pessimistic Locking

| Strategy | How | When |
|----------|-----|------|
| **Pessimistic** | Lock row before reading (SELECT FOR UPDATE) | High contention, must prevent conflicts |
| **Optimistic** | No lock; check version/timestamp at write time; retry on conflict | Low contention, most reads |

---

## MVCC (Multi-Version Concurrency Control)

**Definition:** Instead of locking, each transaction sees a snapshot of data at a point in time. Writers create new versions; readers see old versions. No read-write blocking.

**Used by:** PostgreSQL, MySQL InnoDB, Oracle.

**Benefit:** Readers never block writers, writers never block readers.

---

## WAL (Write-Ahead Logging)

**Definition:** Before any data change is written to disk, the change is first written to a log file. Ensures **durability** — on crash, replay log to recover.

**How:** Write log entry → Write data → On crash, check log → Redo/undo incomplete operations.

---

## Key terms

| Term | Definition |
|------|-----------|
| **Dirty read** | Read uncommitted changes from another tx |
| **Non-repeatable read** | Re-read same row, different value |
| **Phantom read** | Re-run query, different set of rows |
| **Deadlock** | Two tx each wait for the other's lock → neither can proceed |
| **Starvation** | A tx waits indefinitely because others keep getting priority |
| **Two-Phase Locking (2PL)** | Growing phase (acquire locks) → Shrinking phase (release locks). Guarantees serializability |
| **SAVEPOINT** | Marker within transaction to partially rollback to |
| **Autocommit** | Each statement auto-commits (default in many DBs). Explicit BEGIN needed for multi-statement tx |

---

## Deadlock

**What:** Tx1 holds lock A, waits for B. Tx2 holds lock B, waits for A. Neither can proceed.

**Detection:** DB has deadlock detector — kills one transaction (victim).

**Prevention:**
1. Consistent lock ordering (always lock in same order)
2. Lock timeout
3. Keep transactions short
4. Application should catch deadlock error and **retry**

---

*Next: [[02_Mental-Model]]*
