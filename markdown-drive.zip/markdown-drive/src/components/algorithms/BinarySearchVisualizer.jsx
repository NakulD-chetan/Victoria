import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: binary-search */
function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  let lo = 0;
  let hi = a.length - 1;
  steps.push({ type: 'init', array: [...a], pointers: { lo, hi }, target });
  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    steps.push({ type: 'compare', array: [...a], pointers: { lo, mid, hi }, target, mid });
    if (a[mid] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { lo, mid, hi }, target, mid });
      return steps;
    }
    if (a[mid] < target) {
      steps.push({ type: 'eliminate-left', array: [...a], pointers: { lo, mid, hi }, target, keepFrom: mid + 1, keepTo: hi });
      lo = mid + 1;
    } else {
      steps.push({ type: 'eliminate-right', array: [...a], pointers: { lo, mid, hi }, target, keepFrom: lo, keepTo: mid - 1 });
      hi = mid - 1;
    }
    steps.push({ type: 'window', array: [...a], pointers: { lo, hi }, target });
  }
  steps.push({ type: 'notfound', array: [...a], pointers: {}, target });
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

function paintWindow(colors, lo, hi, n) {
  for (let i = 0; i < n; i++) {
    if (i >= lo && i <= hi) colors[i] = 'active';
    else colors[i] = 'eliminated';
  }
}

export default function BinarySearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Searching for ${target} in array of ${arr.length}` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    if (step.type === 'init') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Window [${pointers.lo}, ${pointers.hi}]` });
    } else if (step.type === 'compare') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid] = 'compare';
      store.incComparisons();
      store.addLog({
        time: `${store.stepIndex + 1}`,
        type: 'info',
        message: `Compare mid=${step.mid} value ${step.array[step.mid]} vs target ${step.target}`,
      });
    } else if (step.type === 'eliminate-left' || step.type === 'eliminate-right') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      colors[step.mid] = 'compare';
      for (let i = 0; i < n; i++) {
        if (i < step.keepFrom || i > step.keepTo) colors[i] = 'eliminated';
      }
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Discard half of search space' });
    } else if (step.type === 'window') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.mid] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at index ${step.mid}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Target not in array' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      found: found != null ? found : undefined,
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
