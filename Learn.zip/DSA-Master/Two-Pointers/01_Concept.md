# Two Pointers — Concept

> **Permanent Recall:** Two Pointers uses two indices (or references) that traverse a data structure, often from different directions or at different speeds. Instead of brute-force O(n²) pair checking, you exploit structure (sorted order, monotonicity) to eliminate half the search space per step. Two main variants: **Opposite-direction (converging)** and **Same-direction (fast/slow)**. FAANG tests this in 20%+ of array/linked-list rounds.

---

## Core Idea (2 Lines)

**Use two indices that move strategically—either toward each other (sorted arrays) or at different speeds (cycles, partitioning)—to achieve O(n) or O(n log n) instead of O(n²). The key is exploiting structure to know which pointer to move next.**

---

## Intuition

Imagine finding two numbers that sum to target in a **sorted** array. Brute force checks every pair → O(n²). But if the array is sorted, you know: if `arr[left] + arr[right] > target`, then `arr[left] + arr[right-1]` might work, but `arr[left+1] + arr[right]` is even larger (since array is sorted). So you **decrease right**. Conversely, if sum < target, **increase left**. Each comparison eliminates a row or column of the search space.

```
Sorted Array: [1, 2, 4, 6, 8, 9], target = 10

Brute Force: Check all 15 pairs → O(n²)

Two Pointers: Exploit sorted order
  L           R
[1, 2, 4, 6, 8, 9]  → 1+9=10 ✓ DONE in 1 step!

  L     R
[1, 2, 4, 6, 8, 9]  → 1+8=9 < 10 → move L (need bigger)
     L  R
[1, 2, 4, 6, 8, 9]  → 2+8=10 ✓
```

---

## Why Brute Force Fails

| Approach | What It Does | Time | Problem |
|----------|-------------|------|---------|
| Brute Force | Check every pair (i, j) | O(n²) | Redundant—doesn't use sorted structure |
| Two Pointers | Move based on comparison result | O(n) | Optimal—each move eliminates possibilities |

**The redundancy:** In a sorted array, if `arr[i] + arr[j] > target`, then `arr[i] + arr[j+1]` is even larger. So you never need to check `(i, j+1)`. Similarly, `arr[i+1] + arr[j]` might work—so you move `i`. Each step rules out O(n) pairs.

---

## Optimization Reasoning

### Opposite-Direction (Converging)
- **When:** Sorted array, pair/triplet sum, palindrome check
- **Logic:** `left` starts at 0, `right` at n-1. Move toward each other based on comparison
- **Why it works:** Sorted order gives **directional information**—you know which way to go

### Same-Direction (Fast/Slow)
- **When:** Linked list cycle, partition, remove duplicates in-place
- **Logic:** `slow` and `fast` both start at head; `fast` moves 2x speed
- **Why it works:** Different speeds create **phase difference**—fast laps slow when cycle exists

### Partition (Dutch National Flag)
- **When:** In-place sort of 0s, 1s, 2s; move elements to one side
- **Logic:** Three pointers: `low`, `mid`, `high`—partition into regions
- **Why it works:** Each swap makes progress toward final arrangement

---

## Time Complexity Intuition

| Variant | Time | Why |
|---------|------|-----|
| Opposite-direction | O(n) | Each pointer moves at most n times, total 2n steps |
| Same-direction | O(n) | Each element visited at most twice (by slow and fast) |
| Three pointers (3Sum) | O(n²) | Outer loop n, inner two-pointer O(n) |
| Partition | O(n) | Each element swapped at most once |

**Space:** O(1) for all variants—no extra data structures.

---

## When NOT to Use This Pattern

| Scenario | Why Not | Use Instead |
|----------|---------|-------------|
| Array is NOT sorted and you need pair sum | No directional info from comparison | Hash Map (O(n) time, O(n) space) |
| Need ALL pairs/triplets (not just existence) | Two pointers finds one; need different enumeration | Hash Map or nested loops |
| Non-contiguous elements | Two pointers typically work on contiguous/adjacent | Sliding Window, Backtracking |
| Need to preserve relative order of non-target elements | Partition may not preserve order | Stable sort, different approach |
| Problem requires binary search on answer | Two pointers ≠ binary search | Binary Search |
| Graph/tree structure | Two pointers are for linear structures | BFS, DFS |

### The Sorted Assumption Trap

**Critical FAANG catch:** Opposite-direction two pointers **require sorted input** (or you can sort first—adds O(n log n)). If you can't sort (e.g., need original indices), use Hash Map.

---

## Two Main Variants Decision Table

| Signal | Opposite-Direction | Same-Direction |
|--------|-------------------|----------------|
| "sorted array" | ✅ | |
| "pair sum", "triplet sum" | ✅ | |
| "palindrome" | ✅ | |
| "linked list cycle" | | ✅ |
| "partition", "move to one side" | | ✅ |
| "remove duplicates in-place" | | ✅ |
| "find middle of linked list" | | ✅ |
| "nth from end" | | ✅ |

---

## Golden Rules

1. **Sorted array + pair/triplet → Opposite-direction two pointers**
2. **Linked list cycle / middle / partition → Same-direction (fast/slow or multi-pointer)**
3. **Each pointer moves in ONE direction only—never backward**
4. **Opposite-direction: move the pointer that "hurts" the constraint**
5. **If unsorted and need pair sum → Hash Map, not two pointers**
6. **Three pointers (3Sum): fix one, run two-pointer on rest**

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Two Pointers
WHEN TO USE:        Sorted array pairs, cycles, partition, in-place ops
CORE IDEA:          Two indices move strategically; exploit structure
VARIANT 1:          Opposite (L←→R): sorted pairs, palindrome
VARIANT 2:          Same (slow/fast): cycle, middle, partition
MOVEMENT RULE:      Opposite: move pointer that improves constraint
                   Same: fast=2×slow for cycle
TIME COMPLEXITY:    O(n) typically; O(n²) for 3Sum
SPACE COMPLEXITY:   O(1)
INTERVIEW LINE:     "Since the array is sorted, I can use two pointers
                     to find the pair in O(n) by moving based on the sum."
```
