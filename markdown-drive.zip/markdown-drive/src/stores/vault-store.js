import { create } from 'zustand';
import { getAuthHeaders } from '../components/AuthGate';

/*
 * Vault store — a single source of truth for the user's workspaces.
 *
 * A "vault" is a unified workspace that scopes three data domains:
 *   1. Notes   — per-vault notebooks + notes (notes-store.js)
 *   2. Code    — per-vault files + folders (useFileStore.js)
 *   3. Canvas  — per-vault canvas scenes (canvas-store.js)
 *
 * The store itself only owns the *registry* (list of vaults + the active
 * one). Domain stores read `getActiveVaultId()` when they decide where to
 * persist / fetch their own data, and subscribe to `vaultChangeBus` so
 * they can hot-reload when the user switches vaults.
 */

const STORAGE_KEY = 'inkdrop-vaults';
const DEFAULT_VAULT_ID = 'default';
const DEFAULT_VAULT_NAME = 'MY_DATA';
const CLOUD_DEBOUNCE_MS = 1500;

function genId() {
  return 'v_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function loadLocal() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !Array.isArray(parsed.vaults)) return null;
    return parsed;
  } catch { return null; }
}

function saveLocal(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      vaults: state.vaults,
      activeVaultId: state.activeVaultId,
    }));
  } catch { /* quota / SSR */ }
}

let _cloudTimer = null;
async function saveCloud(state) {
  try {
    await fetch('/api/vaults/sync', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
      body: JSON.stringify({
        vaults: state.vaults,
        activeVaultId: state.activeVaultId,
      }),
    });
  } catch (e) {
    console.warn('[Vaults] cloud save failed:', e.message);
  }
}
function debouncedCloudSave(state) {
  if (_cloudTimer) clearTimeout(_cloudTimer);
  _cloudTimer = setTimeout(() => saveCloud(state), CLOUD_DEBOUNCE_MS);
}

async function loadCloud() {
  try {
    const res = await fetch('/api/vaults/sync', { headers: getAuthHeaders() });
    if (!res.ok) return null;
    const json = await res.json();
    if (!json.exists || !json.data) return null;
    return json.data;
  } catch { return null; }
}

/*
 * Simple pub/sub so domain stores can react to vault switches without
 * depending on React (stores live outside the React tree).
 */
const listeners = new Set();
export function onVaultChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
function emitVaultChange(next, prev) {
  listeners.forEach((fn) => {
    try { fn(next, prev); } catch (e) { console.error('[Vaults] listener error:', e); }
  });
}

function defaultVault() {
  return {
    id: DEFAULT_VAULT_ID,
    name: DEFAULT_VAULT_NAME,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

/* Boot the initial registry:
 *  - If localStorage has one, use it.
 *  - Otherwise create the default "MY_DATA" vault (and keep existing
 *    data anchored to it because domain stores treat 'default' as their
 *    legacy path). */
const bootLocal = loadLocal();
const initialVaults = bootLocal?.vaults?.length ? bootLocal.vaults : [defaultVault()];
const initialActiveId = bootLocal?.activeVaultId
  && initialVaults.some((v) => v.id === bootLocal.activeVaultId)
  ? bootLocal.activeVaultId
  : initialVaults[0].id;

/* Eagerly publish the active vault id on window so non-React modules
 * (e.g. canvas-store) can read it synchronously before any hook runs. */
if (typeof window !== 'undefined') {
  window.__activeVaultId = initialActiveId;
}

export function getActiveVaultId() {
  if (typeof window !== 'undefined' && window.__activeVaultId) return window.__activeVaultId;
  return useVaultStore.getState().activeVaultId;
}

export const useVaultStore = create((set, get) => ({
  vaults: initialVaults,
  activeVaultId: initialActiveId,
  cloudLoaded: false,
  /* Bumped by createVault so UI (e.g. modal) can show a spinner while
   * the domain stores do their seed writes. */
  creating: false,
  /* True from the moment switchVault() is called until the new vault's
   * notes/canvas blobs are fully loaded. UI uses this to render the
   * blur+skeleton overlay so the swap is flicker-free. */
  isSwitching: false,

  _persist: () => {
    const s = get();
    if (typeof window !== 'undefined') window.__activeVaultId = s.activeVaultId;
    saveLocal(s);
    debouncedCloudSave(s);
  },

  loadFromCloud: async () => {
    const cloud = await loadCloud();
    if (!cloud || !Array.isArray(cloud.vaults) || !cloud.vaults.length) {
      set({ cloudLoaded: true });
      return;
    }
    /* Merge: keep local-only vaults, prefer cloud metadata for shared ids.
     * Active vault preference: cloud wins only if it still exists locally
     * after merge, otherwise fall back to current local active. */
    const localVaults = get().vaults;
    const byId = new Map();
    localVaults.forEach((v) => byId.set(v.id, v));
    cloud.vaults.forEach((v) => byId.set(v.id, { ...byId.get(v.id), ...v }));
    const merged = Array.from(byId.values());
    const activeFromCloud = cloud.activeVaultId && merged.some((v) => v.id === cloud.activeVaultId)
      ? cloud.activeVaultId
      : get().activeVaultId;
    set({ vaults: merged, activeVaultId: activeFromCloud, cloudLoaded: true });
    if (typeof window !== 'undefined') window.__activeVaultId = activeFromCloud;
    saveLocal(get());
  },

  createVault: async (rawName) => {
    const name = (rawName || '').trim() || 'Untitled Vault';
    const id = genId();
    const now = new Date().toISOString();
    const vault = { id, name, createdAt: now, updatedAt: now };
    set((s) => ({ vaults: [...s.vaults, vault], creating: true }));
    get()._persist();
    try {
      /* Switching seeds the new (empty) vault because domain stores run
       * their "ensureVaultData" logic on every reload. */
      await get().switchVault(id);
    } finally {
      set({ creating: false });
    }
    return id;
  },

  renameVault: (id, rawName) => {
    const name = (rawName || '').trim();
    if (!name) return;
    set((s) => ({
      vaults: s.vaults.map((v) => v.id === id
        ? { ...v, name, updatedAt: new Date().toISOString() }
        : v),
    }));
    get()._persist();
  },

  deleteVault: async (id) => {
    if (id === DEFAULT_VAULT_ID) return; /* default is protected */
    const { vaults, activeVaultId } = get();
    if (vaults.length <= 1) return;
    const nextVaults = vaults.filter((v) => v.id !== id);
    const needsSwitch = activeVaultId === id;
    set({ vaults: nextVaults });
    /* Fire and forget: server deletes notes + canvas blobs under this id. */
    try {
      await fetch(`/api/vaults/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        headers: getAuthHeaders(),
      });
    } catch { /* non-fatal */ }
    /* Clear any per-vault localStorage entries too (the domain store
     * keys encode the vault id, see their own files). */
    try {
      localStorage.removeItem(`inkdrop-notes-data:${id}`);
      localStorage.removeItem(`ce-filestore:${id}`);
      localStorage.removeItem(`inkdrop-canvas-meta:${id}`);
      localStorage.removeItem(`inkdrop-canvas-data:${id}`);
    } catch { /* ignore */ }

    if (needsSwitch) {
      await get().switchVault(nextVaults[0].id);
    } else {
      get()._persist();
    }
  },

  switchVault: async (id) => {
    const { vaults, activeVaultId } = get();
    if (!vaults.some((v) => v.id === id)) return;
    if (id === activeVaultId) return;
    const prev = activeVaultId;
    set({ activeVaultId: id, isSwitching: true });
    if (typeof window !== 'undefined') window.__activeVaultId = id;
    get()._persist();
    try {
      /* Notify domain stores to reload their state from the new vault's
       * storage slot. Listeners may return a Promise so we await any
       * heavy work and keep the skeleton up until they all settle. */
      const results = [];
      listeners.forEach((fn) => {
        try {
          const r = fn(id, prev);
          if (r && typeof r.then === 'function') results.push(r);
        } catch (e) { console.error('[Vaults] listener error:', e); }
      });
      if (results.length) {
        await Promise.allSettled(results);
      } else {
        /* Always show the skeleton for at least one frame so the swap
         * registers visually even on a fast local-only switch. */
        await new Promise((r) => setTimeout(r, 120));
      }
    } finally {
      set({ isSwitching: false });
    }
  },

  getActiveVault: () => {
    const { vaults, activeVaultId } = get();
    return vaults.find((v) => v.id === activeVaultId) || vaults[0] || null;
  },
}));

export { DEFAULT_VAULT_ID };
