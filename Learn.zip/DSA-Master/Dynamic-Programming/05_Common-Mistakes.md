# Dynamic Programming — Common Mistakes

> **Permanent Recall:** Wrong state → wrong answer. Wrong base case → wrong answer. No memoization → TLE. Subsequence ≠ subarray ≠ substring. Language-specific traps: C++ overflow, Rust ownership, Python mutable defaults.

---

## Core DP Mistakes

### 1. Wrong State Definition

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| Too few dimensions | Can't express all choices; e.g., knapsack needs (index, capacity) | Ask: "What varies when I make a decision?" |
| Too many dimensions | Redundant; harder to fill; more memory | Simplify: "Do I really need this dimension?" |
| Ambiguous meaning | dp[i] = "best" without defining "best for what" | Be explicit: "dp[i] = max profit from prefix 0..i" |

**Example:** House Robber — `dp[i] = max money if we rob house i` is wrong. We need "max money from first i houses" (may or may not include i).

---

### 2. Wrong Base Case

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| dp[0] wrong | Off-by-one; empty vs first element confusion | Trace: "What is dp[0] for empty input?" |
| Missing base | Recursion hits undefined; wrong init | List all base cases before coding |
| Base for 2D | dp[0][j] and dp[i][0] often different | Initialize first row AND first column |

**Example:** LCS — `dp[0][j] = 0` (empty string vs s2 prefix = 0 common chars). Edit distance — `dp[i][0] = i` (delete all from s1).

---

### 3. Wrong Transition

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| Missing a choice | Forgot "skip" or "take" branch | List ALL choices at each state |
| Wrong dependency | Using dp[i+1] when filling dp[i] | Dependencies must be smaller/earlier |
| Wrong aggregation | Used sum instead of max (or vice versa) | Re-read: "maximize" vs "count" |

---

### 4. Not Memoizing (Exponential TLE)

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| Pure recursion, no cache | Same subproblem solved repeatedly | Add `@lru_cache` / `memo` dict / dp table |
| Forgetting to return cached | Cache populated but not used | Check: "Did I return memo[state]?" |

```
Without memo:  fib(n) → O(2^n) calls
With memo:     fib(n) → O(n) unique states
```

---

### 5. Off-by-One in Table

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| dp[n] vs dp[n-1] | 0-index vs 1-index confusion | Be consistent: dp[i] = answer for prefix length i |
| Loop bounds | `range(n)` vs `range(1, n+1)` | Trace: "Does dp[n] exist? What's the last index?" |
| String indices | s[i-1] when dp uses 1-indexed | dp[i][j] often = s1[0..i-1], s2[0..j-1] |

---

### 6. Subsequence vs Subarray vs Substring

| Term | Definition | Contiguous? | Example |
|------|------------|-------------|---------|
| **Subsequence** | Elements in order, can skip | No | [1,3,5] from [1,2,3,4,5] |
| **Subarray** | Contiguous slice | Yes | [2,3,4] from [1,2,3,4,5] |
| **Substring** | Contiguous slice of string | Yes | "bcd" from "abcde" |

**Mistake:** Using subarray recurrence for subsequence (or vice versa). Subsequence → 2D LCS-style; subarray → kadane or 2D with (start, end).

---

## C++ Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **2D vector init wrong** | `vector<vector<int>> dp(n, m)` is wrong | `vector<vector<int>> dp(n, vector<int>(m, 0))` |
| **Integer overflow** | `dp[i] + value` exceeds INT_MAX | Use `long long`; check before add |
| **Wrong dp direction** | Filling dp[i] before dp[i-1] ready | Ensure loop order respects dependencies |
| **INT_MAX + 1** | Overflow in min-cost DP | Use `if (x != INT_MAX) dp[i] = min(...)` |
| **Negative indexing** | `dp[w - weight[i]]` when w < weight[i] | Check `w >= weights[i]` before access |

```cpp
// WRONG
vector<vector<int>> dp(n, m);  // m is second dim, not init value

// RIGHT
vector<vector<int>> dp(n, vector<int>(m, 0));
```

---

## Rust Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **Ownership of dp arrays** | Can't mutably borrow and read same slice | Use indices; or `Vec::with_capacity` and push |
| **Borrowing in recursion with memo** | `&mut HashMap` in recursive fn causes borrow conflicts | Use `RefCell<HashMap>` or pass memo as mutable ref carefully |
| **HashMap for memoization** | Need `Eq + Hash` for key; tuple works | `(i, j)` or struct with `#[derive(Hash, Eq, PartialEq)]` |
| **Vec<Vec<T>> creation** | `vec![vec![0; n]; m]` — row major | `vec![vec![0; n]; m]` gives m×n; ensure m,n correct |
| **Index out of bounds** | usize underflow when `i - 1` with i=0 | Use `i.checked_sub(1)` or guard `if i > 0` |
| **Clone in hot loop** | Cloning Vec in recurrence kills perf | Use references; avoid unnecessary clones |

```rust
// Memoization: use RefCell for interior mutability
use std::cell::RefCell;
fn dp(i: usize, memo: &RefCell<HashMap<usize, i32>>) -> i32 {
    if let Some(&v) = memo.borrow().get(&i) { return v; }
    let result = /* recurrence */;
    memo.borrow_mut().insert(i, result);
    result
}
```

---

## Python Specific Mistakes

| Mistake | Why It Happens | Fix |
|---------|----------------|-----|
| **Recursion limit** | Default 1000; deep recursion hits limit | `sys.setrecursionlimit(10**6)` or use bottom-up |
| **Mutable default args** | `def f(memo={})` — shared across calls | Use `def f(memo=None): memo = memo or {}` |
| **Not using @lru_cache** | Manual dict memo is verbose; easy to forget | `@lru_cache(maxsize=None)` for top-down |
| **lru_cache with unhashable args** | List/dict as arg → TypeError | Convert to tuple: `tuple(nums)` |
| **Shallow copy of 2D list** | `[[0]*n]*m` — rows share same list | `[[0]*n for _ in range(m)]` |

```python
# WRONG
dp = [[0] * n] * m   # All rows reference SAME list!

# RIGHT
dp = [[0] * n for _ in range(m)]
```

---

## ASCII: Mistake Decision Tree

```
Wrong answer?
  ├─ Check state definition — does dp[i] mean what you think?
  ├─ Check base case — dp[0], dp[1], first row/col
  ├─ Check transition — all choices? correct formula?
  └─ Check indices — 0 vs 1-indexed? off-by-one?

TLE?
  ├─ Forgot memoization? → Add cache
  └─ Wrong complexity? → Optimize algorithm

Wrong for edge case?
  ├─ Empty input?
  ├─ Single element?
  └─ Subsequence vs subarray?
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
STATE:       Too few → wrong; too many → wasteful; be precise
BASE CASE:   dp[0], first row/col; list before coding
TRANSITION:  All choices; dependencies must be ready
MEMO:        No cache → exponential TLE
OFF-BY-ONE:  dp[n] vs dp[n-1]; loop bounds; string indices
SUBSEQ≠SUBARR: Subsequence skips; subarray contiguous
CPP:         2D init, overflow, INT_MAX+1
RUST:        Ownership, RefCell for memo, Vec init
PYTHON:      [[0]*n]*m wrong; @lru_cache; recursion limit
```

---

## 30-SECOND REVISION BOX

```
□ State correct? All dimensions needed?
□ Base case: empty, single, first row/col?
□ All choices in transition?
□ Memoization if top-down?
□ Subsequence vs subarray?
□ C++: vector<vector<int>>(n, vector<int>(m,0))
□ Rust: RefCell for memo; vec![vec![0;n]; m]
□ Python: [[0]*n for _ in range(m)]; @lru_cache
```
