# Design URL Shortener — Design Template

> **Permanent Recall:** Full architecture: Client → LB → API Servers → Redis (cache) → DB. Key generation: KGS pre-generates keys; API pulls from pool. Redirect: cache-aside; 302 for analytics. DB schema: id, short_url, long_url, created_at, expires_at, user_id. ASCII diagram below is your whiteboard template.

---

## API Design

### POST /shorten (Create short URL)

```http
POST /api/v1/shorten
Content-Type: application/json

{
  "long_url": "https://example.com/very/long/path?query=value",
  "custom_alias": "mysite",     // optional
  "expires_in_days": 365       // optional
}

// Response
201 Created
{
  "short_url": "https://short.io/xyz7Ab",
  "long_url": "https://example.com/...",
  "expires_at": "2026-03-10T00:00:00Z"
}
```

### GET /:shortUrl (Redirect)

```http
GET /xyz7Ab
→ 302 Found
Location: https://example.com/very/long/path?query=value
```

---

## High-Level Architecture

```
                    ┌──────────────────────────────────────────┐
                    │              Load Balancer                │
                    └─────────────────────┬────────────────────┘
                                          │
              ┌───────────────────────────┼───────────────────────────┐
              │                           │                           │
              ▼                           ▼                           ▼
    ┌─────────────────┐         ┌─────────────────┐         ┌─────────────────┐
    │  API Server 1   │         │  API Server 2   │         │  API Server N   │
    │  (stateless)    │         │  (stateless)    │         │  (stateless)    │
    └────────┬────────┘         └────────┬────────┘         └────────┬────────┘
             │                          │                          │
             └──────────────────────────┼──────────────────────────┘
                                        │
                    ┌───────────────────┼───────────────────┐
                    │                   │                   │
                    ▼                   ▼                   ▼
            ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
            │ Redis Cache  │   │ Key Gen Svc   │   │   Database   │
            │ short→long   │   │ (KGS) pool   │   │  (primary +  │
            │ popular URLs │   │              │   │   replicas)  │
            └──────┬───────┘   └──────────────┘   └──────┬───────┘
                   │                                      │
                   └──────────────────────────────────────┘
                            cache-aside lookup
```

---

## Database Schema

```sql
CREATE TABLE url_mappings (
  id           BIGINT PRIMARY KEY AUTO_INCREMENT,
  short_url    VARCHAR(10) NOT NULL UNIQUE,   -- e.g., xyz7Ab
  long_url     VARCHAR(2048) NOT NULL,
  user_id      VARCHAR(64),                   -- optional, for analytics
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at   TIMESTAMP NULL,                -- NULL = no expiry
  INDEX idx_short (short_url),
  INDEX idx_expires (expires_at)
);
```

| Column | Purpose |
|--------|---------|
| `short_url` | Lookup key; unique index for redirect |
| `long_url` | Destination; up to 2KB typical |
| `expires_at` | For TTL cleanup; NULL = permanent |
| `user_id` | Optional; for per-user analytics |

---

## Key Generation Approaches

### 1. Hash + base62 (simple, stateless)

```
long_url → MD5/SHA256 → first 43 bits → base62 encode → 7 chars
Collision: retry with salt (append random) or use more chars
```

**Base62:** `0-9`, `a-z`, `A-Z` = 62 chars. 7 chars = 62^7 ≈ 3.5 trillion combinations.

### 2. Counter + base62

```
DB: auto_increment or Snowflake ID → base62 encode → short code
No collisions; needs distributed ID generator
```

### 3. Key Generation Service (KGS) — preferred at scale

```
KGS runs in background:
  1. Pre-generate keys (batch of 1M) via counter
  2. Store in DB key_pool table or Redis list
  3. API servers: GET key from pool (atomic pop)
  4. Refill when pool < threshold
```

---

## Redirect Flow (302 for analytics)

```
GET /xyz7Ab
    │
    ├─► Redis.GET("xyz7Ab")  →  HIT  →  302 Location: long_url
    │
    └─► MISS  →  DB SELECT short_url='xyz7Ab'
                    │
                    ├─► Not found or expired  →  404
                    │
                    └─► Found  →  Redis.SET("xyz7Ab", long_url, TTL=24h)
                               →  302 Location: long_url
```

> **FAANG Tip:** Use **302** if you need click analytics. Use **301** if destination never changes and you want browser caching to reduce load.

---

## Caching Strategy

| Aspect | Choice |
|--------|--------|
| **What to cache** | short_url → long_url mapping |
| **Key** | short_url (e.g., `xyz7Ab`) |
| **Value** | long_url |
| **TTL** | 24h–7d; or no TTL for permanent URLs |
| **Invalidation** | On URL update/delete; or let TTL expire |
| **Capacity** | Hot URLs (~20% get 80% traffic); Redis can hold millions |

---

## Mermaid: End-to-End Flow

```mermaid
flowchart TD
    A[Client: POST /shorten] --> B[API Server]
    B --> C{Has custom alias?}
    C -->|Yes| D[Check DB for conflict]
    C -->|No| E[Get key from KGS]
    D --> F{Conflict?}
    F -->|Yes| G[409 Conflict]
    F -->|No| H[Insert DB]
    E --> H
    H --> I[Return 201 short_url]
    
    J[Client: GET /xyz7Ab] --> K[API Server]
    K --> L{Redis hit?}
    L -->|Yes| M[302 Redirect]
    L -->|No| N[DB lookup]
    N --> O{Found?}
    O -->|No| P[404]
    O -->|Yes| Q[Cache in Redis]
    Q --> M
```

---

## 30-SECOND REVISION BOX

```
API: POST /shorten (body: long_url, custom_alias, expires)
     GET /:shortUrl → 302 Location
ARCH: LB → API → Redis → DB, KGS for keys
SCHEMA: short_url, long_url, expires_at, user_id
KEY GEN: Hash+base62, Counter+base62, KGS (best)
REDIRECT: Cache-aside, 302 for analytics
CACHE: Redis, short→long, TTL 24h
```

---

**Prev: [[02_Mental-Model]] | Next: [[04_Interview-Thinking]]**
