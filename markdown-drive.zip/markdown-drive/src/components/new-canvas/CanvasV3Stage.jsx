import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  CaptureUpdateAction,
  Excalidraw,
  exportToBlob,
} from '@excalidraw/excalidraw';
import '@excalidraw/excalidraw/index.css';
import { useNewCanvasStore } from './state/store';
import {
  normalizeTeachingDocumentV3,
  persistableAppState,
} from './canvas-v3/document';
import { compileTeachingDocumentV3 } from './canvas-v3/compiler';
import V3CodePortal from './canvas-v3/V3CodePortal';

function sameAppState(a, b) {
  return (
    a?.theme === b?.theme &&
    a?.viewBackgroundColor === b?.viewBackgroundColor &&
    a?.zoom?.value === b?.zoom?.value &&
    a?.scrollX === b?.scrollX &&
    a?.scrollY === b?.scrollY &&
    a?.width === b?.width &&
    a?.height === b?.height
  );
}

function sameSelection(a, b) {
  if (a === b) return true;
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function visibleElementsForPlayback(document) {
  const playback = document.playback || {};
  if (playback.status === 'idle' || playback.status === 'done') return document.elements;
  const beat = Number(playback.currentBeat);
  return document.elements.filter((element) => {
    const role = element.customData?.semanticRole;
    if (role === 'lesson-frame' || role === 'lesson-background') return true;
    const revealBeat = Number(element.customData?.revealBeat);
    return !Number.isFinite(revealBeat) || revealBeat <= beat;
  });
}

function activeFrameElements(document) {
  const activeFrame = document.lessonDeck.frames.find(
    (frame) => frame.id === document.playback?.activeFrameId,
  );
  if (!activeFrame) return [];
  return document.elements.filter((element) => (
    element.id === activeFrame.frameElementId || element.frameId === activeFrame.frameElementId
  ));
}

const CanvasV3Stage = forwardRef(function CanvasV3Stage(_props, ref) {
  const activeId = useNewCanvasStore((state) => state.activeId);
  const scene = useNewCanvasStore((state) => state.scenes[state.activeId]);
  const setV3Document = useNewCanvasStore((state) => state.setV3Document);
  const patchV3Document = useNewCanvasStore((state) => state.patchV3Document);
  const setV3Selection = useNewCanvasStore((state) => state.setV3Selection);
  const setV3Playback = useNewCanvasStore((state) => state.setV3Playback);
  const document = useMemo(
    () => normalizeTeachingDocumentV3(scene?.v3Document),
    [scene?.v3Document],
  );
  const [viewport, setViewport] = useState(document.appState);
  const apiRef = useRef(null);
  const applyingRef = useRef(false);
  const persistTimerRef = useRef(null);
  const lastFocusedFrameRef = useRef(null);
  const fixtureLoadedRef = useRef(false);
  const lastSelectionRef = useRef([]);
  const initialDataRef = useRef(null);
  const [apiReady, setApiReady] = useState(false);
  const canvasTheme = 'light';
  const canvasBackground = '#f7f5ef';

  if (!initialDataRef.current) {
    initialDataRef.current = {
      elements: visibleElementsForPlayback(document),
      appState: {
        ...document.appState,
        theme: canvasTheme,
        viewBackgroundColor: canvasBackground,
        scrollToContent: document.elements.length > 0,
      },
      files: document.files,
    };
  }

  const applyScene = useCallback((nextDocument, { focusFrame = false } = {}) => {
    const api = apiRef.current;
    if (!api) return;
    applyingRef.current = true;
    const visible = visibleElementsForPlayback(nextDocument);
    api.updateScene({
      elements: visible,
      appState: {
        ...nextDocument.appState,
        theme: canvasTheme,
        viewBackgroundColor: canvasBackground,
      },
      captureUpdate: CaptureUpdateAction.NEVER,
    });
    window.requestAnimationFrame(() => {
      applyingRef.current = false;
    });

    if (focusFrame) {
      const targets = activeFrameElements(nextDocument);
      if (targets.length) {
        window.setTimeout(() => {
          api.scrollToContent(targets, {
            fitToViewport: true,
            viewportZoomFactor: 0.82,
            animate: !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches,
            duration: 900,
          });
        }, 30);
      }
    }
  }, [canvasBackground, canvasTheme]);

  useEffect(() => {
    if (!apiReady || !apiRef.current) return;
    const activeFrameId = document.playback?.activeFrameId;
    const shouldFocus = activeFrameId && lastFocusedFrameRef.current !== activeFrameId;
    if (shouldFocus) lastFocusedFrameRef.current = activeFrameId;
    applyScene(document, { focusFrame: shouldFocus });
  }, [apiReady, applyScene, document]);

  useEffect(() => {
    if (document.playback?.status !== 'playing') return undefined;
    const storyboard = document.playback?.storyboard;
    const beats = storyboard?.slides?.[0]?.beats || [];
    if (!beats.length) return undefined;

    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (reducedMotion) {
      setV3Playback({
        currentBeat: beats.length - 1,
        status: 'done',
        reducedMotion: true,
      });
      return undefined;
    }

    const nextBeat = document.playback.currentBeat + 1;
    if (nextBeat >= beats.length) {
      setV3Playback({ status: 'done', currentBeat: beats.length - 1 });
      return undefined;
    }

    const delay = nextBeat === 0
      ? 220
      : Math.max(320, Number(beats[nextBeat - 1]?.durationMs) || 650);
    const timer = window.setTimeout(() => {
      setV3Playback({
        currentBeat: nextBeat,
        status: nextBeat === beats.length - 1 ? 'done' : 'playing',
      });
    }, delay);
    return () => window.clearTimeout(timer);
  }, [
    document.playback?.currentBeat,
    document.playback?.status,
    document.playback?.storyboard,
    setV3Playback,
  ]);

  useEffect(() => {
    if (!import.meta.env.DEV || fixtureLoadedRef.current) return;
    const fixture = new URLSearchParams(window.location.search).get('nc-fixture');
    if (fixture !== 'array' || document.elements.length) return;
    fixtureLoadedRef.current = true;
    const compiled = compileTeachingDocumentV3({
      document,
      request: {
        topic: 'array',
        structureType: 'array',
        title: 'What is an array?',
        definition: 'An array is a data structure that stores multiple values of the same type in contiguous (continuous) memory locations.',
        values: ['12', '7', '19', '4', '23'],
        callout: 'Think of it like a row of numbered boxes.',
        pageMode: 'next',
      },
      runId: 'fixture-array',
    });
    setV3Document(compiled.document);
  }, [document, setV3Document]);

  useEffect(() => () => {
    if (persistTimerRef.current) window.clearTimeout(persistTimerRef.current);
  }, []);

  const onChange = useCallback((elements, appState, files) => {
    if (applyingRef.current) return;

    const nextAppState = persistableAppState(appState);
    setViewport((current) => (sameAppState(current, nextAppState) ? current : nextAppState));

    const nextSelection = Object.keys(appState.selectedElementIds || {});
    if (!sameSelection(lastSelectionRef.current, nextSelection)) {
      lastSelectionRef.current = nextSelection;
      setV3Selection(nextSelection);
    }

    if (document.playback?.status === 'playing') return;

    if (persistTimerRef.current) window.clearTimeout(persistTimerRef.current);
    persistTimerRef.current = window.setTimeout(() => {
      setV3Document({
        ...document,
        elements: [...elements],
        files,
        appState: nextAppState,
        updatedAt: Date.now(),
      });
    }, 180);
  }, [document, setV3Document, setV3Selection]);

  const updatePortal = useCallback((portalId, patch) => {
    patchV3Document((current) => ({
      ...current,
      portals: current.portals.map((portal) => (
        portal.id === portalId ? { ...portal, ...patch } : portal
      )),
      updatedAt: Date.now(),
    }));
  }, [patchV3Document]);

  useImperativeHandle(ref, () => ({
    async exportPNG() {
      const api = apiRef.current;
      if (!api) return null;
      return exportToBlob({
        elements: api.getSceneElements(),
        appState: {
          ...api.getAppState(),
          exportBackground: true,
        },
        files: api.getFiles(),
        mimeType: 'image/png',
      });
    },
    getEngine: () => apiRef.current,
  }));

  const visiblePortals = document.portals.filter((portal) => {
    if (document.playback.status === 'idle' || document.playback.status === 'done') return true;
    return Number(portal.revealBeat) <= Number(document.playback.currentBeat);
  });

  return (
    <div className="nc-stage nc-v3-stage" data-engine="v3">
      <Excalidraw
        excalidrawAPI={(api) => {
          apiRef.current = api;
          setApiReady(Boolean(api));
        }}
        initialData={{
          ...initialDataRef.current,
        }}
        onChange={onChange}
        UIOptions={{
          canvasActions: {
            loadScene: false,
            saveToActiveFile: false,
            toggleTheme: false,
          },
        }}
      />

      <div className="nc-v3-portal-layer">
        {visiblePortals.map((portal) => (
          <V3CodePortal
            key={portal.id}
            portal={portal}
            viewport={viewport}
            onUpdate={(patch) => updatePortal(portal.id, patch)}
          />
        ))}
      </div>

      <div className="nc-v3-engine-badge" title="Excalidraw Teacher Canvas V3">
        V3
      </div>
    </div>
  );
});

export default CanvasV3Stage;
