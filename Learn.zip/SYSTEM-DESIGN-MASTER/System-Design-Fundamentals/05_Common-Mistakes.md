# System Design Fundamentals — Common Mistakes

> **Permanent Recall:** Top 15 mistakes: jumping into solution, not estimating scale, SPOF, ignoring NFRs, over-engineering, no trade-offs, no monitoring, ignoring security, no failure modes, designing for current scale, mixing paths, no caching, monolithic thinking, no data model, being silent. For each: what it is, why it's bad, how to fix.

---

## Top 15 Common Mistakes — Summary Table

| # | Mistake | What It Is | Why It's Bad | How to Fix |
|---|---------|------------|--------------|------------|
| 1 | **Jumping into solution** | Start drawing boxes before understanding requirements | Wrong problem solved; wasted time; back-and-forth | Requirements first: functional, NFRs, constraints |
| 2 | **Not estimating scale** | No QPS, storage, or bandwidth numbers | Can't size components; over/under-design | Back-of-envelope: DAU, actions, read:write |
| 3 | **Single point of failure (SPOF)** | One DB, one server, no redundancy | Any failure = total outage | Replicas, LB, multi-AZ, failover |
| 4 | **Ignoring NFRs** | Only discuss features; skip latency, consistency, availability | Design doesn't match real needs | State: latency target, consistency model, availability % |
| 5 | **Over-engineering** | Microservices, Kafka, 10 shards from day one | Complexity for no gain; hard to operate | Start simple; add when bottleneck proven |
| 6 | **Not discussing trade-offs** | Present design as "the" answer | Shows lack of judgment; no prioritization | "We trade X for Y because Z" |
| 7 | **No monitoring/observability** | Design works but can't detect or debug issues | Blind in production; long MTTR | Metrics, logs, traces, alerting |
| 8 | **Ignoring security** | No auth, no encryption, no threat model | Unacceptable at scale; compliance failure | Auth, HTTPS, encryption at rest, rate limiting |
| 9 | **No failure modes** | Assume everything works | Real systems fail; no plan = chaos | Discuss: DB down, region down, cache stampede |
| 10 | **Designing for current scale only** | "10K users is fine" | Doesn't scale; rewrite later | Design for 10–100× growth |
| 11 | **Mixing multiple paths** | Jump between "happy path" and "error path" | Confusing; incomplete flows | One flow at a time; then edge cases |
| 12 | **No caching** | Every request hits DB | DB overload; slow; expensive | Cache hot data; CDN for static |
| 13 | **Monolithic thinking** | One giant component does everything | Can't scale parts; tight coupling | Logical separation; scale units |
| 14 | **No data model** | Tables/schema not discussed | Ambiguous; can't reason about queries | Define tables, keys, indexes |
| 15 | **Being silent** | Draw without talking | Interviewer can't follow; no collaboration | Think aloud; ask; validate assumptions |

---

## Mistake 1: Jumping Into Solution

**What:** Draw load balancer and boxes before asking "What are we building? Who are the users? What's the scale?"

**Why bad:** Solves wrong problem. Interviewer expects requirements gathering first.

**Fix:** "Before I design, I'd clarify: functional requirements, non-functional (latency, scale, consistency), and constraints. Let me state my assumptions."

---

## Mistake 2: Not Estimating Scale

**What:** No numbers — "we'll have many users" — no QPS, storage, or bandwidth.

**Why bad:** Can't size DB, cache, or servers. Design is abstract, not grounded.

**Fix:** "Assume 100M DAU, 10 actions/day → ~12K QPS average, ~40K peak. Storage: 100M users × 1KB ≈ 100 GB. That drives our DB and cache sizing."

---

## Mistake 3: Single Point of Failure

**What:** One DB, one server, one region. No redundancy.

**Why bad:** Any single failure = total outage. Unacceptable for production.

**Fix:** "We avoid SPOF: load balancer in front of multiple app servers; primary + read replicas for DB; multi-AZ deployment."

---

## Mistake 4: Ignoring NFRs

**What:** Only discuss features. No latency target, consistency model, or availability.

**Why bad:** Design can't be evaluated. "Fast" and "reliable" mean nothing without numbers.

**Fix:** "NFRs: p99 latency <200ms, eventual consistency OK for feed, 99.99% availability. That means we need caching and multi-region."

---

## Mistake 5: Over-Engineering

**What:** Microservices, event sourcing, 50 Kafka partitions for a MVP.

**Why bad:** Complexity without benefit. Hard to operate. Interviewer expects pragmatic choices.

**Fix:** "Start with a monolith or few services. Add Kafka when we need async; add sharding when DB is the bottleneck. Measure first."

---

## Mistake 6: Not Discussing Trade-offs

**What:** Present design as the only answer. No "we could do X or Y; we choose X because..."

**Why bad:** Shows lack of judgment. Real design is about trade-offs.

**Fix:** "We could use strong consistency, but that adds latency. For a feed, eventual consistency is acceptable, so we favor performance."

---

## Mistake 7: No Monitoring

**What:** Design works but no metrics, logs, or alerting.

**Why bad:** Can't detect failures, debug issues, or meet SLOs.

**Fix:** "We'd add: latency metrics (p50, p99), error rate, throughput. Distributed tracing for debugging. Alerts on SLO breach."

---

## Mistake 8: Ignoring Security

**What:** No auth, no encryption, no rate limiting.

**Why bad:** Insecure by design. Fails compliance; vulnerable to abuse.

**Fix:** "Auth via JWT or OAuth. HTTPS everywhere. Encryption at rest for sensitive data. Rate limiting per user/IP."

---

## Mistake 9: No Failure Modes

**What:** Assume everything works. No plan for DB down, cache miss storm, or region outage.

**Why bad:** Real systems fail. No plan = poor availability.

**Fix:** "If DB is down: failover to replica. If cache is cold: cache stampede mitigation (lock or probabilistic early expiration). If region down: multi-region failover."

---

## Mistake 10: Designing for Current Scale Only

**What:** "10K users, so one server is fine."

**Why bad:** Doesn't scale. Rewrite at 10× or 100×.

**Fix:** "Design for 10–100× growth. Stateless app, so we can add servers. DB with replication path to sharding."

---

## Mistake 11: Mixing Paths

**What:** Jump between "user posts tweet" and "what if DB fails" mid-flow.

**Why bad:** Confusing. Incomplete understanding of either path.

**Fix:** "Let me walk the happy path end-to-end first. Then we can discuss edge cases and failure handling."

---

## Mistake 12: No Caching

**What:** Every request hits DB.

**Why bad:** DB overload. High latency. Expensive. Most systems are read-heavy.

**Fix:** "Read-heavy → cache hot data (Redis). Static assets → CDN. Cache-aside with TTL and invalidation on write."

---

## Mistake 13: Monolithic Thinking

**What:** One box does auth, feed, storage, search.

**Why bad:** Can't scale components independently. Tight coupling.

**Fix:** "Separate services: Auth, Feed, User, Media. Scale Feed separately when it's the bottleneck."

---

## Mistake 14: No Data Model

**What:** No tables, schema, or data structures.

**Why bad:** Ambiguous. Can't reason about queries, indexes, or sharding key.

**Fix:** "Users table: id, name, created_at. Tweets table: id, user_id, content, created_at. Index on user_id for timeline queries. Shard by user_id."

---

## Mistake 15: Being Silent

**What:** Draw diagrams without explaining. Long pauses.

**Why bad:** Interviewer can't follow. No collaboration. Looks unprepared.

**Fix:** "I'm drawing the flow: client hits API, which checks cache, then DB. I'm assuming cache hit rate around 80%. Does that match your expectations?"

---

## Recovery Phrases

| If you did... | Say this |
|---------------|----------|
| Jumped to solution | "Let me step back. What are the core requirements?" |
| Forgot scale | "Before we continue, let me estimate: 100M DAU → ~12K QPS..." |
| Single DB | "We'd add read replicas and failover to avoid SPOF." |
| No trade-offs | "The trade-off here is consistency vs latency. We choose eventual consistency for the feed." |
| No monitoring | "We'd add metrics, traces, and alerting to observe this in production." |

---

## Severity (Interview Impact)

| Severity | Mistakes | Impact |
|----------|----------|--------|
| **Critical** | 1, 2, 3 | Often fail; fix immediately |
| **Major** | 4, 6, 9, 15 | Strong negative signal |
| **Moderate** | 5, 7, 8, 12 | Shows gaps |
| **Minor** | 10, 11, 13, 14 | Depth differentiator |

---

## 30-SECOND REVISION BOX

```
1. Requirements first
2. Estimate scale (QPS, storage)
3. No SPOF (replicas, LB)
4. State NFRs (latency, consistency, availability)
5. Start simple, add complexity when needed
6. Discuss trade-offs
7. Monitoring and observability
8. Security (auth, encryption, rate limit)
9. Failure modes
10. Design for growth
11. One flow at a time
12. Cache
13. Logical separation
14. Data model
15. Think aloud
```

---

**Prev: [[04_Interview-Thinking]] | Next: [[06_Edge-Cases]]**
