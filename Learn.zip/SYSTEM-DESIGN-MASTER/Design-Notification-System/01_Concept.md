# Design Notification System — Concept

> **Permanent Recall:** A multi-channel notification system delivering push (iOS/Android), SMS, and email at **10B notifications/day**. Core insight: **Event → Decide → Format → Deliver → Track** — each channel uses a different third-party provider (APNS, FCM, Twilio, SendGrid). Soft real-time (<10s for push), at-least-once delivery.

---

## Problem Statement

Design a **multi-channel notification system** that delivers messages to users via:
- **Push notifications** (iOS via APNS, Android via FCM)
- **SMS**
- **Email**

Scale: **10B notifications/day**. Must respect user preferences, support templates, scheduling, and rate limiting.

---

## Functional Requirements

| Feature | Description |
|---------|-------------|
| **Push (iOS/Android)** | Native push via APNS (Apple) and FCM (Firebase); device tokens required |
| **SMS** | Deliver via Twilio, AWS SNS, or similar; phone number required |
| **Email** | Deliver via SendGrid, SES, Mailgun; templates with substitution |
| **User preferences** | Opt-in/opt-out per channel (push, SMS, email); per notification type (transactional, marketing) |
| **Templates** | Parameterized templates (e.g., `"Hi {{name}}, your order {{order_id}} shipped"`) |
| **Scheduling** | Immediate send + delayed/scheduled send (e.g., reminder in 24h) |
| **Rate limiting** | Per-user limits (e.g., max 5 marketing emails/day); prevent spam and fatigue |
| **Delivery tracking** | Track delivered, opened, clicked (where supported by channel) |

---

## Non-Functional Requirements

| NFR | Target |
|-----|--------|
| **Latency** | Soft real-time: push < 10s P99 from event to delivery |
| **Delivery guarantee** | At-least-once (retries until success or dead-letter); idempotency to avoid duplicates |
| **Scale** | 10B notifications/day (~115K/sec average; 3× peak ≈ 350K/sec) |
| **Availability** | High availability (99.9%+); notification delivery is user-facing SLA |
| **Throughput** | Burst-tolerant (e.g., 1M users notified in <5 min for alerts) |

> **FAANG Tip:** State the at-least-once + idempotency pairing early — prevents duplicate notifications when retries occur.

---

## Capacity Estimation

### Throughput

- **Daily:** 10B notifications
- **Average QPS:** 10B / 86,400 ≈ **115,740/sec**
- **Peak (3×):** ~350K/sec
- **Burst:** Mass notifications (e.g., security alert) can spike to millions in minutes

### Per-Channel Rough Split (Example)

| Channel | % | Notifications/day | QPS (avg) |
|---------|---|-------------------|-----------|
| Push | 40% | 4B | ~46K |
| Email | 35% | 3.5B | ~40K |
| SMS | 25% | 2.5B | ~29K |

### Storage

- **Event log:** ~500 bytes/notification × 10B = **5TB/day** (for tracking, retries)
- **Device tokens:** 1B users × 2 devices × 100 bytes ≈ **200GB**
- **User preferences:** 1B × 200 bytes ≈ **200GB**

### Third-Party Limits (Key Constraint)

- **APNS:** Connection limits per provider; batch requests
- **FCM:** 500 messages/batch; rate limits apply
- **Twilio/SMS:** Per-account limits; cost scales linearly
- **SendGrid/SES:** Per-second sending limits; need multiple accounts or batching

---

## Key Numbers to Memorize

| Metric | Value |
|--------|-------|
| Notifications/day | 10B |
| Avg QPS | ~116K |
| Peak QPS | ~350K |
| Push latency SLA | < 10s P99 |
| Delivery guarantee | At-least-once |
| Channels | Push (iOS/Android), SMS, Email |

---

## Out of Scope (Clarify in Interview)

- **In-app notifications** — separate storage/real-time delivery
- **Rich media in push** — images, actions (can extend)
- **Notification grouping/collapsing** — client-side concern
- **Exact cost optimization** — high-level (batch, rate limits)

---

## Assumptions (State in Interview)

- Push requires device tokens (client registers with APNS/FCM); tokens can invalidate
- SMS/email require verified phone/email from user profile
- User preferences stored per user, per channel, per notification type
- Templates are server-side; rendered before delivery
- At-least-once; idempotency key prevents duplicate sends on retry

---

## Constraints

- **Third-party dependence:** APNS, FCM, Twilio, SendGrid have rate limits and SLAs
- **Cost:** SMS is expensive (~$0.01–0.05/msg); batch and rate limit
- **Regulatory:** GDPR, CAN-SPAM for email; SMS consent (TCPA)
- **Provider outages:** Must degrade gracefully (retry, circuit breaker)

---

## Success Criteria

- Push delivered < 10s P99
- No duplicate notifications for same event (idempotency)
- User preferences always respected
- Rate limits enforced per user and globally
- Delivery tracking available for supported channels
