# How LLMs Like ChatGPT Actually Work - System Design

> Source: https://newsletter.systemdesign.one/p/llm-concepts

## One-Line Summary
LLMs are advanced autocomplete systems that predict the next token one at a time, trained on massive internet text, and aligned through human feedback to be helpful assistants.

## Key Concepts Map

```
AI (big umbrella)
 └── Machine Learning (learn from data)
      └── Deep Learning (neural networks)
           └── NLP (human language)
                └── Generative AI (creates content)
                     └── LLMs (text generation)
```

## 33 LLM Concepts in Plain Language

### Part 1: The Hidden Machinery (What's Inside)

**1. Token**
- LLMs work with numbers, not words
- A **tokenizer** breaks text into small chunks called tokens
- "What is fine-tuning?" → ["What", "is", "fine", "-", "tuning", "?"]
- Each token gets mapped to a number ID

**2. Embeddings**
- Token IDs are just random labels -- no meaning
- An **embedding** = a list of numbers (vector) representing a token's meaning
- Similar words are placed close together on a "meaning map"
- "dog" and "puppy" are close; "dog" and "refrigerator" are far apart
- This is how search engines find results even when you use different words

**3. Latent Space**
- The giant "meaning map" where all embeddings live
- During training, the model organizes concepts so their positions reflect real relationships
- Questions about "fine-tuning" will be near other training-related concepts

**4. Parameters**
- Billions of internal adjustable settings (knobs and dials)
- Start random, get tuned through trillions of training examples
- After training, they encode language patterns, concepts, and knowledge
- GPT-4 has hundreds of billions of parameters

### Part 2: How LLMs Learn (Training)

**5. Pre-training**
- The foundational training phase
- Model reads massive amounts of internet text
- Task: predict the next token in a sequence
- Wrong guess → tiny parameter adjustment → repeat trillions of times
- Result: a "base model" that knows language patterns

**6. Base Model vs Instruct Model**
- **Base Model**: raw text predictor, not designed to be helpful
- **Instruct Model**: base model + extra training to follow instructions
- ChatGPT, Claude = instruct models
- Extra training uses instruction-answer pairs (not new facts, just better behavior)

**7. Fine-Tuning**
- Further training a pre-trained model on a smaller, specific dataset
- Example: GitHub Copilot = base model fine-tuned on billions of lines of code
- Doesn't add new knowledge, just specializes the behavior

### Part 3: Shaping Behavior (Alignment)

**8. Alignment**
- Making the model helpful, honest, and harmless
- Doesn't add facts -- shapes HOW the model responds
- ChatGPT declines unsafe requests because of alignment

**9. RLHF (Reinforcement Learning from Human Feedback)**
- Step 1: Model generates multiple answers to a question
- Step 2: Humans rank answers from best to worst
- Step 3: Train a "reward model" (judge) using these rankings
- Step 4: Use the judge to score future answers, nudge model toward higher scores
- This is how ChatGPT learned to be clear, helpful, and safe

### Part 4: Interaction Layer (How You Use Them)

**10. Prompts (System vs User)**
- **System Prompt**: hidden instructions that set the model's role and rules
- **User Prompt**: your actual question or command
- Model processes both together

**11. Context Window**
- Maximum tokens the model can "see" at once
- Includes: system prompt + full conversation history + current response
- If conversation gets too long, oldest messages get dropped
- GPT-4 Turbo: 128K tokens; Claude 3: 200K tokens

**12. Zero-shot vs Few-shot Learning**
- **Zero-shot**: give instruction with NO examples ("Summarize this text")
- **Few-shot**: give instruction WITH examples ("Here are 3 examples of good summaries, now summarize this")
- Few-shot = more reliable, structured output

**13. Chain-of-Thought (CoT) Reasoning**
- Add "Let's think step by step" to complex questions
- Model breaks problem into logical steps instead of jumping to answer
- Dramatically improves accuracy for multi-step problems
- Newer reasoning models have this built-in

### Part 5: Runtime (What Happens When You Hit Enter)

**14. Inference**
- The process of generating output from a trained model
- Predicts one token at a time, adds it to sequence, repeats
- Continues until "end-of-sequence" token or max length

**15. Latency**
- **TTFT (Time-to-First-Token)**: how fast first word appears
- **Time-between-tokens**: the "typing speed" of the model
- Both need to be low for good user experience

**16. Temperature**
- Controls randomness in token selection
- **Low temp (0.0)**: always picks most probable token → same answer every time (deterministic)
- **High temp (0.8-1.0)**: picks from wider range → varied, creative answers (stochastic)
- Factual tasks → low temperature; Creative tasks → higher temperature

### Part 6: Architectures & Extensions

**17. Grounding**
- Force LLM to answer based only on provided, verifiable sources
- Reduces hallucination -- if info isn't available, model says "I don't know"

**18. RAG (Retrieval-Augmented Generation)**
- **Retrieve**: search trusted documents for relevant info
- **Augment**: add retrieved info to the prompt as context
- **Generate**: model answers using ONLY the retrieved evidence
- Example: Perplexity AI searches the web before answering
- Best way to reduce hallucination and keep answers current

**19. Workflow vs Agent**
- **Workflow**: fixed sequence of steps (developer controls the path)
- **Agent**: LLM decides which tools to use and in what order (autonomous)
- Workflows = reliable, predictable; Agents = flexible, less predictable

**20. Agentic AI**
- System that can plan and execute multi-step tasks on its own
- Example: "Create a study guide on fine-tuning" → agent searches, extracts, organizes
- Examples: Gemini Deep Research, Claude Code, Copilot Agent Mode

### Part 7: Model Types & Tradeoffs

**21. Proprietary vs Open-Source**
- **Proprietary** (GPT-5, Claude): best quality, pay-per-use, no control
- **Open-Weight** (Llama, Mistral): good quality, can run yourself, some restrictions
- **Open-Source**: full transparency, most control, often lower quality

**22. API**
- How your app talks to the model provider
- Send prompt → get response (like ordering food via delivery app)
- You're NOT running the model locally

**23. SLM (Small Language Model)**
- <15B parameters, runs on laptop/phone
- Fast, cheap, good for specific tasks
- Examples: Phi-3, Mistral 7B
- Enables: offline assistants, private on-device AI

**24. Multimodality**
- Models that handle multiple input types (text + images + audio)
- GPT-4o and Gemini can process text and images together

**25. Reasoning Models**
- Designed for multi-step problem solving
- Built-in "think step by step" capability
- Slower but more accurate for complex tasks

### Part 8: Measuring & Failures

**26. Benchmarks**: Standardized tests to compare models (MMLU, HumanEval, BBH)

**27. Metrics**: Task-specific quality measures (faithfulness, relevance)

**28. LLM-as-Judge**: Use a powerful model to evaluate another model's outputs at scale

**29. Hallucination**: Model confidently generates false information (fix: RAG/grounding)

**30. Poor Math/Logic**: Pattern matcher, not a calculator (fix: external tools)

**31. Inherited Bias**: Training data biases reflected in outputs (fix: RLHF, guardrails)

**32. Knowledge Cutoff**: Training data has a date limit (fix: RAG, web search)

**33. Guardrails/Safety Filters**: Block harmful, inappropriate, or off-topic content

## Interview Tips

- Explain LLMs as "advanced autocomplete" -- predict next token, one at a time
- Know the training pipeline: Pre-training → Fine-tuning → Alignment (RLHF)
- **RAG** is the go-to architecture for reducing hallucination -- explain the 3 steps
- Understand **temperature** and when to use low vs high
- Know the difference: **Base Model** (raw predictor) vs **Instruct Model** (helpful assistant)
- For system design: discuss inference latency (TTFT), scaling (model parallelism), caching

## Quick Revision (5 bullet points)

1. **LLMs predict the next token** one at a time using billions of parameters trained on internet text
2. **Training pipeline**: Pre-training (learn patterns) → Fine-tuning (specialize) → RLHF (align with human values)
3. **RAG = Retrieve + Augment + Generate** -- the standard architecture to reduce hallucination by grounding answers in real documents
4. **Temperature** controls randomness: low = consistent/factual, high = creative/varied
5. **Key failures**: hallucination (fix: RAG), poor math (fix: tools), bias (fix: RLHF), outdated knowledge (fix: web search/RAG)
