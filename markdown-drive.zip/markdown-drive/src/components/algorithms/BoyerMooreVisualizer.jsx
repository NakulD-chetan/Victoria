import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import StringCanvasBase from './canvas-bases/StringCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const T = 'ABCAABCAB';
const P = 'ABCAB';

function badCharRule(pattern) {
  const m = pattern.length;
  const map = {};
  for (let i = 0; i < m - 1; i++) map[pattern[i]] = m - 1 - i;
  return map;
}

function generateSteps() {
  const steps = [];
  const n = T.length;
  const m = P.length;
  const bc = badCharRule(P);
  const shifts = P.split('').map((c) => bc[c] ?? m);
  steps.push({
    type: 'bc',
    msg: 'Bad-character shifts (last occurrence)',
    T,
    P,
    offset: 0,
    bc,
    table: shifts,
    tableLabel: 'shift',
  });
  let s = 0;
  while (s <= n - m) {
    let j = m - 1;
    steps.push({ type: 'align', msg: `Window start s=${s}`, T, P, offset: s, j });
    while (j >= 0 && P[j] === T[s + j]) {
      steps.push({
        type: 'match',
        msg: `Match P[${j}] with T[${s + j}]`,
        T,
        P,
        offset: s,
        j,
      });
      j -= 1;
    }
    if (j < 0) {
      steps.push({ type: 'found', msg: `Full match at offset ${s}`, T, P, offset: s, matchStart: s });
      s += 1;
    } else {
      const bad = T[s + j];
      const shift = Math.max(1, bc[bad] ?? m);
      steps.push({
        type: 'mis',
        msg: `Mismatch at j=${j}, shift by ${shift}`,
        T,
        P,
        offset: s,
        j,
        shift,
      });
      s += shift;
    }
  }
  steps.push({ type: 'done', msg: 'Scan complete', T, P, offset: Math.max(0, n - m) });
  return steps;
}

function paint(step) {
  const textColors = {};
  const patternColors = {};
  const comparePairs = [];
  const off = step.offset ?? 0;
  if (step.j != null && step.j >= 0) {
    const ti = off + step.j;
    if (step.type === 'match' || step.type === 'mis') {
      textColors[ti] = step.type === 'mis' ? 'mismatch' : 'match';
      patternColors[step.j] = step.type === 'mis' ? 'mismatch' : 'match';
      comparePairs.push([ti, step.j]);
    } else if (step.type === 'align') {
      patternColors[step.j] = 'current';
      comparePairs.push([ti, step.j]);
    }
  }
  if (step.type === 'found' && step.matchStart != null) {
    for (let k = 0; k < step.P.length; k++) {
      textColors[step.matchStart + k] = 'found';
      patternColors[k] = 'found';
    }
  }
  return {
    text: step.T.split(''),
    pattern: step.P.split(''),
    textColors,
    patternColors,
    offset: off,
    table: step.table || null,
    tableLabel: step.tableLabel || 'Bad char shift',
    matchPositions: step.matchStart != null ? [step.matchStart] : [],
    comparePairs: comparePairs.length ? comparePairs : null,
  };
}

export default function BoyerMooreVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: 'Boyer–Moore (bad character rule)' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'match' || step.type === 'mis') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'mis') canvasRef.current?.addAnim('flashText', { i: step.offset + step.j }, 300);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={StringCanvasBase} onInit={onInit} onStep={onStep} />;
}
