# System-Patterns — Edge Cases

> **Permanent Recall:** The FAANG edge case formula: **Empty, Single, Boundary, Overflow, Negative, Duplicate**. Apply this checklist to ANY problem type before saying "done."

---

## The FAANG Edge Case Formula (6 Categories)

| Category | What to Check | Example |
|----------|---------------|---------|
| **E**mpty | Empty input | `[]`, `""`, `null`, no nodes |
| **S**ingle | One element | `[1]`, single node, one interval |
| **B**oundary | Min/max, first/last, lo/hi | `n=0`, `n=1`, `arr[0]`, `arr[n-1]` |
| **O**verflow | Integer overflow, stack overflow | `10^9 * 10^9`, deep recursion |
| **N**egative | Negative numbers | `[-1, 0, 1]`, negative weights |
| **D**uplicate | Repeated elements | `[1,1,1]`, duplicate edges |

**Mnemonic:** **E**very **S**mart **B**ug **O**ught **N**ot **D**ebug (Empty, Single, Boundary, Overflow, Negative, Duplicate)

---

## Per-Category Checklist

### Empty

| Input Type | Edge Case | Typical Return |
|------------|-----------|----------------|
| Array | `[]` | `0`, `[]`, or problem-specific |
| String | `""` | `0`, `""`, `true` |
| Tree | `null` / no root | `0`, `[]` |
| Graph | No nodes / no edges | `0`, `[]` |
| Intervals | `[]` | `0` (e.g., 0 meeting rooms) |

**Code:** Always add `if not nums: return ...` (or equivalent) at the start.

---

### Single

| Input Type | Edge Case | Watch For |
|------------|-----------|-----------|
| Array | `[x]` | Index 0 only; no pairs |
| Tree | Single node | No children; root is answer |
| Graph | One node | No edges; distance 0 |
| Interval | `[[1,2]]` | One room; count = 1 |
| String | `"a"` | Length 1; palindrome |

**Code:** Check `n == 1` or `len(arr) == 1`; avoid `arr[1]` out of bounds.

---

### Boundary

| Boundary | Check | Example |
|----------|-------|---------|
| **Index 0** | First element access | `arr[0]` in loop starting at 1 |
| **Index n-1** | Last element | Off-by-one in range |
| **Lo/Hi in BS** | `lo == hi` | Ensure loop terminates; handle `lo` |
| **Min value** | `n=0`, `k=0` | Division by zero; empty range |
| **Max value** | `n=10^6` | TLE; use O(n) or O(n log n) |
| **Equal boundaries** | `start == end` | Interval `[5,5]` — length 0? |

**Code:** Test `lo`, `hi`, `mid` when `lo == hi`; test `range(0)`, `range(1)`.

---

### Overflow

| Scenario | Risk | Fix |
|----------|------|-----|
| **Multiplication** | `a * b` when a,b large | Use `long long` (C++), `int`→`long` (Java), `i64` (Rust) |
| **Addition** | Running sum of large nums | Same as above |
| **Binary search** | `mid = (lo + hi) / 2` | Use `lo + (hi - lo) / 2` to avoid overflow |
| **Recursion depth** | Deep recursion | Use iterative; or increase limit (Python) |
| **Negative index** | `i - 1` when `i=0` | Check `i > 0` before `i-1` |

**Code:** `mid = lo + (hi - lo) // 2`; use 64-bit for sums/products.

---

### Negative

| Scenario | Check | Example |
|----------|-------|---------|
| **Array elements** | Can values be negative? | Two Sum with negatives |
| **Weights/costs** | Negative edges? | Dijkstra fails; use Bellman-Ford |
| **Indices** | Can index be negative? | Usually no; validate input |
| **Binary search** | Search space includes negatives? | `lo` can be negative |
| **Modulo** | `-1 % 5` | Language-dependent; use `(x % n + n) % n` |

**Code:** Ask "Can we have negative numbers?"; handle in comparisons.

---

### Duplicate

| Scenario | Impact | Fix |
|----------|--------|-----|
| **Array** | Same value multiple times | Count; use set for uniqueness |
| **Graph edges** | Duplicate edges | Use set of edges; or handle in algo |
| **Intervals** | Overlapping same start/end | Sort with secondary key |
| **Subsets** | Duplicate subsets | Sort before adding; or use set of tuples |
| **Two pointers** | Skip duplicates | `while i+1 < n and arr[i]==arr[i+1]: i+=1` |

**Code:** Consider `collections.Counter`; sort and skip duplicates in two pointers.

---

## Pattern-Specific Edge Cases

| Pattern | Edge Cases |
|---------|------------|
| **BS on Answer** | `lo == hi`; empty array; all same; `check(lo)` false |
| **Monotonic Stack** | Empty stack pop; all increasing (stack never pops) |
| **Sweep Line** | Intervals with same start and end; single interval |
| **Two-Pass** | Single element; all zeros (product) |
| **BIT** | Index 0; `range_query(0, 0)` |
| **Trie + Backtrack** | Empty board; single cell; word longer than grid |
| **BFS + DP** | No path; start == end; disconnected |
| **Meet in Middle** | Empty half; single element in half |
| **Reservoir** | Stream of length 1; k > n |
| **Fisher-Yates** | Single element; empty array |

---

## Quick Test Matrix

| Problem Type | Empty | Single | Boundary | Overflow | Negative | Duplicate |
|--------------|-------|--------|----------|----------|----------|-----------|
| Array/List | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| String | ✓ | ✓ | ✓ | - | - | ✓ |
| Tree | ✓ | ✓ | ✓ | - | - | - |
| Graph | ✓ | ✓ | ✓ | - | ✓ | ✓ |
| Intervals | ✓ | ✓ | ✓ | - | ✓ | ✓ |
| Binary Search | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| DP | ✓ | ✓ | ✓ | ✓ | ✓ | - |

---

## Code Snippets for Common Edge Checks

### Python

```python
# Empty
if not nums: return 0

# Single
if len(nums) == 1: return nums[0]

# Boundary (BS)
if lo == hi: return lo  # or hi

# Overflow (use // for int)
mid = lo + (hi - lo) // 2

# Negative (ask in clarify)
# Duplicate: use set or sort+skip
```

### C++

```cpp
// Empty
if (nums.empty()) return 0;

// Single
if (nums.size() == 1) return nums[0];

// Boundary (BS)
// Overflow: use long long; mid = lo + (hi - lo) / 2;
```

### Rust

```rust
// Empty
if nums.is_empty() { return 0; }

// Single
if nums.len() == 1 { return nums[0]; }

// Overflow: use i64/u64; mid = lo + (hi - lo) / 2;
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
FORMULA:      Empty, Single, Boundary, Overflow, Negative, Duplicate
EMPTY:        [], "", null → handle at start
SINGLE:       [x], one node → no loop or special case
BOUNDARY:     lo==hi, index 0, n-1, n=0
OVERFLOW:     mid=lo+(hi-lo)/2; long long for sums
NEGATIVE:     Ask; affects Dijkstra, modulo
DUPLICATE:    set, sort+skip, Counter
ALWAYS:       Add edge checks before main logic
```

---

## 30-SECOND REVISION BOX

```
□ E: empty — [], "", null
□ S: single — [x], one node
□ B: boundary — lo, hi, 0, n-1
□ O: overflow — mid=lo+(hi-lo)/2, long long
□ N: negative — ask; affects algo choice
□ D: duplicate — set, sort+skip
□ Apply to EVERY problem before "done"
```
