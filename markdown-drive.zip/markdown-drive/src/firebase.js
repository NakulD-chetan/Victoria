import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getDatabase, ref, set, get, push, update, remove, onValue } from 'firebase/database';
import { getAnalytics } from 'firebase/analytics';
import { createClient } from '@supabase/supabase-js';

// ── Firebase (Auth + Realtime DB + Analytics) ────────────────────

const firebaseConfig = {
  apiKey: "AIzaSyB2C64L5EtUhUyP4hRHgm2nKLPDJ1KGUJQ",
  authDomain: "inkdrop-85bdf.firebaseapp.com",
  projectId: "inkdrop-85bdf",
  storageBucket: "inkdrop-85bdf.firebasestorage.app",
  messagingSenderId: "632648722211",
  appId: "1:632648722211:web:ad13f8538273f436a90e96",
  measurementId: "G-CJWWR9KRBH"
};

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getDatabase(app);

// ── Supabase (Free Storage — 1GB free) ───────────────────────────
// 1. Go to https://supabase.com → Create free project
// 2. Go to Project Settings → API → copy URL and anon key
// 3. Go to Storage → Create bucket named "inkdrop-files" (set to public)

const SUPABASE_URL = 'https://svuumfizxptnxaidishq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN2dXVtZml6eHB0bnhhaWRpc2hxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI2MDc2NzgsImV4cCI6MjA4ODE4MzY3OH0.uviUDg_vsahjBZwEJaxjUDscMOrDfmkof0veBuNTpHs';
const STORAGE_BUCKET = 'inkdrop-files';

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ── Realtime Database helpers ────────────────────────────────────

const safeKey = (s) => s.replace(/[.#$\[\]\/]/g, '_');

export const dbService = {
  async saveUserProfile(uid, profile) {
    await set(ref(db, `users/${uid}/profile`), {
      ...profile,
      updatedAt: new Date().toISOString(),
    });
  },

  async getUserProfile(uid) {
    const snap = await get(ref(db, `users/${uid}/profile`));
    return snap.exists() ? snap.val() : null;
  },

  async setPremiumStatus(uid, premiumData) {
    await set(ref(db, `users/${uid}/premium`), premiumData);
  },

  async getPremiumStatus(uid) {
    const snap = await get(ref(db, `users/${uid}/premium`));
    return snap.exists() ? snap.val() : { active: false, plan: 'free' };
  },

  onPremiumChange(uid, callback) {
    return onValue(ref(db, `users/${uid}/premium`), (snap) => {
      callback(snap.exists() ? snap.val() : { active: false, plan: 'free' });
    });
  },

  async savePayment(uid, payment) {
    const payRef = push(ref(db, `payments/${uid}`));
    await set(payRef, { ...payment, createdAt: new Date().toISOString() });
    return payRef.key;
  },

  async getPayments(uid) {
    const snap = await get(ref(db, `payments/${uid}`));
    if (!snap.exists()) return [];
    const data = snap.val();
    return Object.entries(data).map(([id, val]) => ({ id, ...val }));
  },

  async saveReferral(uid, code) {
    await set(ref(db, `referrals/${code}`), {
      referrerId: uid,
      createdAt: new Date().toISOString(),
      signups: 0,
      earnings: 0,
    });
  },

  async getReferral(code) {
    const snap = await get(ref(db, `referrals/${safeKey(code)}`));
    return snap.exists() ? snap.val() : null;
  },

  async recordReferralSignup(code, newUserId) {
    const refData = await this.getReferral(code);
    if (!refData) return false;
    await update(ref(db, `referrals/${safeKey(code)}`), {
      signups: (refData.signups || 0) + 1,
    });
    return true;
  },

  async trackAnalytics(uid, event) {
    const analyticsRef = push(ref(db, `analytics/${uid}`));
    await set(analyticsRef, { ...event, timestamp: new Date().toISOString() });
  },

  async updateUsageStats(uid, stats) {
    await update(ref(db, `users/${uid}/usage`), {
      ...stats,
      lastActive: new Date().toISOString(),
    });
  },

  async getUsageStats(uid) {
    const snap = await get(ref(db, `users/${uid}/usage`));
    return snap.exists() ? snap.val() : { totalFiles: 0, totalViews: 0 };
  },

  async saveChatMessage(uid, folder, filename, messages) {
    const key = `${safeKey(folder)}__${safeKey(filename)}`;
    await set(ref(db, `chats/${uid}/${key}`), { messages, updatedAt: new Date().toISOString() });
  },

  async getChatMessages(uid, folder, filename) {
    const key = `${safeKey(folder)}__${safeKey(filename)}`;
    const snap = await get(ref(db, `chats/${uid}/${key}`));
    return snap.exists() ? snap.val().messages || [] : [];
  },

  async clearChat(uid, folder, filename) {
    const key = `${safeKey(folder)}__${safeKey(filename)}`;
    await remove(ref(db, `chats/${uid}/${key}`));
  },

  async saveDrawing(uid, folder, filename, sceneData) {
    const key = `${safeKey(folder)}__${safeKey(filename)}`;
    const payload = {
      elements: JSON.stringify(sceneData.elements || []),
      appState: JSON.stringify({
        viewBackgroundColor: sceneData.appState?.viewBackgroundColor,
      }),
      updatedAt: new Date().toISOString(),
    };
    try {
      await set(ref(db, `drawings/${uid}/${key}`), payload);
    } catch {
      localStorage.setItem(`drawing_${uid}_${key}`, JSON.stringify(payload));
    }
  },

  async getDrawing(uid, folder, filename) {
    const key = `${safeKey(folder)}__${safeKey(filename)}`;
    try {
      const snap = await get(ref(db, `drawings/${uid}/${key}`));
      if (snap.exists()) {
        const data = snap.val();
        return {
          elements: JSON.parse(data.elements || '[]'),
          appState: data.appState ? JSON.parse(data.appState) : {},
        };
      }
    } catch { /* Firebase permission denied - try localStorage */ }
    const local = localStorage.getItem(`drawing_${uid}_${key}`);
    if (local) {
      const data = JSON.parse(local);
      return {
        elements: JSON.parse(data.elements || '[]'),
        appState: data.appState ? JSON.parse(data.appState) : {},
      };
    }
    return null;
  },
};

// ── Supabase Storage helpers (FREE 1GB) ──────────────────────────

export const storageService = {
  _path(uid, folder, filename) {
    return `${uid}/${folder}/${filename}`;
  },

  async uploadFile(uid, folder, filename, content) {
    const path = this._path(uid, folder, filename);
    const blob = new Blob([content], { type: 'text/markdown' });
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(path, blob, { upsert: true, contentType: 'text/markdown' });
    if (error) throw error;
    const { data: urlData } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path);
    return urlData.publicUrl;
  },

  async uploadFileBlob(uid, folder, filename, blob) {
    const path = this._path(uid, folder, filename);
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(path, blob, { upsert: true });
    if (error) throw error;
    const { data: urlData } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path);
    return urlData.publicUrl;
  },

  async downloadFile(uid, folder, filename) {
    const path = this._path(uid, folder, filename);
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKET)
      .download(path);
    if (error) return null;
    return await data.text();
  },

  async getFileURL(uid, folder, filename) {
    const path = this._path(uid, folder, filename);
    const { data } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(path);
    return data?.publicUrl || null;
  },

  async deleteFile(uid, folder, filename) {
    const path = this._path(uid, folder, filename);
    await supabase.storage.from(STORAGE_BUCKET).remove([path]);
  },

  async deleteFolder(uid, folder) {
    const { data } = await supabase.storage
      .from(STORAGE_BUCKET)
      .list(`${uid}/${folder}`);
    if (data?.length) {
      const paths = data.map(f => `${uid}/${folder}/${f.name}`);
      await supabase.storage.from(STORAGE_BUCKET).remove(paths);
    }
  },

  async listFiles(uid, folder) {
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKET)
      .list(`${uid}/${folder}`, { sortBy: { column: 'name', order: 'asc' } });
    if (error) return [];
    return data.filter(f => !f.id?.startsWith('.')).map(f => f.name);
  },

  async listFolders(uid) {
    const { data, error } = await supabase.storage
      .from(STORAGE_BUCKET)
      .list(uid, { sortBy: { column: 'name', order: 'asc' } });
    if (error) return [];
    return data.filter(f => f.id === null || f.metadata === null).map(f => f.name);
  },

  async getStorageUsage(uid) {
    const { data } = await supabase.storage.from(STORAGE_BUCKET).list(uid);
    if (!data) return { files: 0, sizeBytes: 0 };
    let totalSize = 0;
    let totalFiles = 0;
    for (const item of data) {
      if (item.metadata?.size) {
        totalSize += item.metadata.size;
        totalFiles++;
      }
    }
    return { files: totalFiles, sizeBytes: totalSize, sizeMB: (totalSize / (1024 * 1024)).toFixed(2) };
  },
};
