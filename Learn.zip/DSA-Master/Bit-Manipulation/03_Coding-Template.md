# Bit Manipulation — Coding Templates

> **FAANG Focus:** Copy-paste ready templates in Python, C++, Rust.

---

## 1. Check / Set / Clear / Toggle Bit

### Python

```python
def check_bit(n: int, i: int) -> bool:
    return (n >> i) & 1 == 1
    # or: (n & (1 << i)) != 0

def set_bit(n: int, i: int) -> int:
    return n | (1 << i)

def clear_bit(n: int, i: int) -> int:
    return n & ~(1 << i)

def toggle_bit(n: int, i: int) -> int:
    return n ^ (1 << i)
```

### C++

```cpp
bool checkBit(int n, int i) {
    return (n >> i) & 1;
}
int setBit(int n, int i) {
    return n | (1 << i);
}
int clearBit(int n, int i) {
    return n & ~(1 << i);
}
int toggleBit(int n, int i) {
    return n ^ (1 << i);
}
```

### Rust

```rust
fn check_bit(n: u32, i: u32) -> bool {
    (n >> i) & 1 == 1
}
fn set_bit(n: u32, i: u32) -> u32 {
    n | (1 << i)
}
fn clear_bit(n: u32, i: u32) -> u32 {
    n & !(1 << i)
}
fn toggle_bit(n: u32, i: u32) -> u32 {
    n ^ (1 << i)
}
```

---

## 2. Count Set Bits (Brian Kernighan's)

### Python

```python
def count_set_bits(n: int) -> int:
    count = 0
    while n:
        n &= n - 1
        count += 1
    return count
# Or: bin(n).count('1')
```

### C++

```cpp
int countSetBits(int n) {
    int count = 0;
    while (n) {
        n &= n - 1;
        count++;
    }
    return count;
}
// Or: __builtin_popcount(n)  // 32-bit
//     __builtin_popcountll(n) // 64-bit
```

### Rust

```rust
fn count_set_bits(n: u32) -> u32 {
    n.count_ones()
}
// Manual: 
// let mut count = 0;
// let mut n = n;
// while n != 0 { n &= n - 1; count += 1; }
```

---

## 3. Check Power of 2

### Python

```python
def is_power_of_two(n: int) -> bool:
    return n > 0 and (n & (n - 1)) == 0
```

### C++

```cpp
bool isPowerOfTwo(int n) {
    return n > 0 && (n & (n - 1)) == 0;
}
```

### Rust

```rust
fn is_power_of_two(n: u32) -> bool {
    n > 0 && (n & (n - 1)) == 0
}
```

---

## 4. Find Single Number (XOR Trick)

### Python

```python
def single_number(nums: list[int]) -> int:
    result = 0
    for x in nums:
        result ^= x
    return result
```

### C++

```cpp
int singleNumber(vector<int>& nums) {
    int result = 0;
    for (int x : nums) result ^= x;
    return result;
}
```

### Rust

```rust
fn single_number(nums: &[i32]) -> i32 {
    nums.iter().fold(0, |acc, &x| acc ^ x)
}
```

---

## 5. Find Two Single Numbers

### Python

```python
def two_single_numbers(nums: list[int]) -> tuple[int, int]:
    xor_all = 0
    for x in nums:
        xor_all ^= x
    diff_bit = xor_all & (-xor_all)  # or: xor_all & (~xor_all + 1)
    a, b = 0, 0
    for x in nums:
        if x & diff_bit:
            a ^= x
        else:
            b ^= x
    return (a, b)
```

### C++

```cpp
pair<int,int> twoSingleNumbers(vector<int>& nums) {
    int xorAll = 0;
    for (int x : nums) xorAll ^= x;
    int diffBit = xorAll & (-xorAll);
    int a = 0, b = 0;
    for (int x : nums) {
        if (x & diffBit) a ^= x;
        else b ^= x;
    }
    return {a, b};
}
```

### Rust

```rust
fn two_single_numbers(nums: &[i32]) -> (i32, i32) {
    let xor_all: i32 = nums.iter().fold(0, |a, &x| a ^ x);
    let diff_bit = xor_all & (-xor_all);
    let (mut a, mut b) = (0, 0);
    for &x in nums {
        if (x & diff_bit) != 0 { a ^= x; } else { b ^= x; }
    }
    (a, b)
}
```

---

## 6. Subsets Using Bitmask

### Python

```python
def subsets(nums: list[int]) -> list[list[int]]:
    n = len(nums)
    result = []
    for mask in range(1 << n):
        sub = [nums[i] for i in range(n) if (mask >> i) & 1]
        result.append(sub)
    return result
```

### C++

```cpp
vector<vector<int>> subsets(vector<int>& nums) {
    int n = nums.size();
    vector<vector<int>> result;
    for (int mask = 0; mask < (1 << n); mask++) {
        vector<int> sub;
        for (int i = 0; i < n; i++)
            if ((mask >> i) & 1) sub.push_back(nums[i]);
        result.push_back(sub);
    }
    return result;
}
```

### Rust

```rust
fn subsets(nums: &[i32]) -> Vec<Vec<i32>> {
    let n = nums.len();
    (0..1 << n).map(|mask| {
        (0..n).filter(|i| (mask >> i) & 1 == 1)
              .map(|i| nums[i]).collect()
    }).collect()
}
```

---

## 7. Bitmask DP Template

### Python

```python
def bitmask_dp(n: int, cost: list[list[int]]) -> int:
    dp = [float('inf')] * (1 << n)
    dp[0] = 0
    for mask in range(1 << n):
        if dp[mask] == float('inf'):
            continue
        for i in range(n):
            if (mask >> i) & 1:
                continue
            new_mask = mask | (1 << i)
            dp[new_mask] = min(dp[new_mask], dp[mask] + cost[popcount(mask)][i])
    return dp[(1 << n) - 1]
```

### C++

```cpp
int bitmaskDP(int n, vector<vector<int>>& cost) {
    vector<int> dp(1 << n, INT_MAX);
    dp[0] = 0;
    for (int mask = 0; mask < (1 << n); mask++) {
        if (dp[mask] == INT_MAX) continue;
        for (int i = 0; i < n; i++) {
            if (mask & (1 << i)) continue;
            int newMask = mask | (1 << i);
            dp[newMask] = min(dp[newMask], dp[mask] + cost[__builtin_popcount(mask)][i]);
        }
    }
    return dp[(1 << n) - 1];
}
```

### Rust

```rust
fn bitmask_dp(n: usize, cost: &[Vec<i32>]) -> i32 {
    let mut dp = vec![i32::MAX; 1 << n];
    dp[0] = 0;
    for mask in 0..1 << n {
        if dp[mask] == i32::MAX { continue; }
        for i in 0..n {
            if (mask >> i) & 1 == 1 { continue; }
            let new_mask = mask | (1 << i);
            let c = cost[mask.count_ones() as usize][i];
            dp[new_mask] = dp[new_mask].min(dp[mask].saturating_add(c));
        }
    }
    dp[(1 << n) - 1]
}
```

---

## 8. Swap Without Temp (XOR)

### Python

```python
def swap(a: int, b: int) -> tuple[int, int]:
    a ^= b
    b ^= a
    a ^= b
    return (a, b)
```

### C++

```cpp
void swap(int& a, int& b) {
    a ^= b;
    b ^= a;
    a ^= b;
}
```

### Rust

```rust
fn swap(a: &mut i32, b: &mut i32) {
    *a ^= *b;
    *b ^= *a;
    *a ^= *b;
}
```

---

## 9. Language-Specific Notes

| Language | Key APIs |
|----------|----------|
| **Python** | `bin(n)`, `n.bit_length()`, infinite-width ints |
| **C++** | `__builtin_popcount`, `__builtin_ctz`, `bitset<N>` |
| **Rust** | `n.count_ones()`, `n.trailing_zeros()`, no implicit overflow |

### Python: `bin()`, `bit_length()`

```python
bin(13)         # '0b1101'
(13).bit_length()  # 4
```

### C++: `bitset`, `unsigned`

```cpp
#include <bitset>
std::bitset<32>(n);  // "00000000000000000000000000001101"
unsigned x = 1u << 31;  // safe for 32-bit
```

### Rust: Overflow

```rust
// Use wrapping/saturating/checked for shifts
let x = 1u32 << 31;  // OK
// 1i32 << 31;       // overflow in debug!
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
┌─────────────────────────────────────────────────┐
│  Check: (n>>i)&1   Set: n|(1<<i)   Clear: n&~(1<<i)  Toggle: n^(1<<i) │
│  Popcount: n&=n-1; count++  or __builtin_popcount │
│  Power of 2: n>0 && (n&(n-1))==0                 │
│  Single: xor all   Two singles: split by diff bit │
│  Subsets: for mask in 0..(1<<n)                  │
│  Swap: a^=b; b^=a; a^=b;                         │
└─────────────────────────────────────────────────┘
```

---

## 30-SECOND REVISION BOX

- [ ] Check/set/clear/toggle bit formulas
- [ ] Brian Kernighan: `n &= n-1` in loop for popcount
- [ ] Power of 2: `n > 0 && (n & (n-1)) == 0`
- [ ] Single number: XOR all; two singles: split by `xor_all & (-xor_all)`
- [ ] Subsets: `for mask in 0..(1<<n)`
- [ ] Swap: `a^=b; b^=a; a^=b`
