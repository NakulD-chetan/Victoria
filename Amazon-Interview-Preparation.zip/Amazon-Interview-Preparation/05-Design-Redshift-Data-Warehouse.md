# Design a Redshift Data Warehouse - Interview Answer Format

## One-Line Answer

A Redshift warehouse loads curated data from the lake, models it into fact and dimension tables, and serves BI dashboards with faster and more predictable SQL performance than querying raw storage directly.

---

## Step 1: Clarify Requirements (1-2 min)

### What to ask

- What kinds of analytics do users need: dashboards, ad hoc SQL, executive reporting?
- What is the query concurrency and SLA?
- How much historical reporting is needed?
- Are we serving raw data or curated business-ready data?
- Do dimensions need history, such as SCD Type 2?
- What is the budget sensitivity for compute and storage?

### Good interview line

> "Before I design the warehouse, I want to clarify the reporting patterns, concurrency, SLA, and whether historical dimension tracking is required, because those influence schema design and Redshift optimization choices."

---

## Step 2: High-Level Design (2-3 min)

### Say this clearly

```text
Curated S3 Data -> Staging Tables -> Merge/Transform -> Facts and Dimensions -> BI
```

### Short explanation you can speak

1. Bring curated data from S3 into Redshift staging tables
2. Validate it before merging
3. Load production fact and dimension tables
4. Serve dashboards and analyst queries from those business-ready models

### Architecture

```text
S3 Curated Data
     |
 COPY / ELT Jobs
     |
 Redshift Staging Tables
     |
 Transform / Merge
     |
 Fact Tables + Dimension Tables
     |
 BI Tools / Analysts / Dashboards
```

### Good interview line

> "My high-level design is curated lake data flowing into Redshift staging tables, then being validated and merged into fact and dimension models for BI consumption."

---

## Step 3: Deep Dive (This Is Where You Win)

### A. Data Modeling

#### Fact tables

Store measurable events such as:

- orders
- clicks
- shipments

#### Dimension tables

Store descriptive attributes such as:

- customer
- product
- seller
- date

#### Why star schema?

- simpler for BI users
- faster and clearer joins
- common pattern for dashboards and analytics

### Good interview line

> "I would use a star schema because fact tables hold business events and dimension tables provide descriptive context, which makes BI queries simpler and more performant."

---

### B. Historical Modeling

#### SCD Type 1

- overwrite old value
- use when history is not needed

#### SCD Type 2

- keep old and new versions
- use when historical reporting matters

#### Surrogate keys

- helpful when natural keys change
- support clean joins with historical dimensions

### Good interview line

> "If the business needs historical correctness, I would use SCD Type 2 for dimensions like customer or seller, because overwriting old values would break past reporting."

---

### C. Load Strategy and Reliability

#### Why stage before publish?

- validate schema and row counts
- deduplicate before merge
- avoid corrupting production tables directly

#### Why incremental loads?

- faster than full reloads
- cheaper
- better for daily or hourly updates

#### Safe load pattern

1. Load into staging
2. Validate
3. Merge/upsert
4. Publish

### Good interview line

> "I would not load directly into production tables. I would stage first, validate the data, then merge into facts and dimensions so the warehouse stays reliable."

---

### D. Performance Optimization

#### What to mention

- distribution style
- sort keys
- materialized views
- summary tables
- compression

#### Why they matter

- reduce shuffle and scan cost
- improve join performance
- reduce dashboard latency

### Good interview line

> "For performance, I would tune sort and distribution keys based on real query patterns, and I would use materialized views or summary tables for repeated dashboard queries."

---

## Step 4: Scaling

### Main scaling points

#### Keep raw and cold data in S3

- Redshift should be the serving layer, not the raw data lake

#### Use incremental loads

- reduces load time
- avoids unnecessary recomputation

#### Serve heavy BI queries efficiently

- create summary tables
- isolate heavy transforms from dashboard usage

### Good interview line

> "To scale the warehouse, I would keep raw and historical data in S3, use incremental loads into Redshift, and optimize serving with summary tables and proper key design."

---

## Step 5: Trade-Offs

### Example trade-offs

#### Redshift vs S3-only analytics

- Redshift gives better dashboard performance
- but it is more expensive than leaving everything in S3

#### Star schema vs fully normalized design

- star schema is simpler and faster for BI
- but can duplicate some descriptive data

#### SCD Type 2 vs overwrite-only dimensions

- Type 2 gives historical correctness
- but adds more complexity and storage

### Good interview line

> "I would use Redshift as the serving warehouse because it gives fast BI performance, but I would still keep raw and large historical data in S3 because Redshift is not the cheapest storage layer."

---

## Strong 2-Minute Answer Script

> "First, I would clarify the reporting workload, concurrency, SLA, and whether the business needs historical dimension tracking. My design would keep curated data in S3 as the upstream source and load it into Redshift staging tables using COPY or ELT jobs. From staging, I would validate row counts and schema, then merge into production fact and dimension tables.
>
> I would use a star schema because it is the common pattern for BI and dashboard workloads. Facts would store measurable business events like orders, while dimensions would store descriptive attributes like customer, product, and date. If history matters, I would model dimensions with SCD Type 2 instead of overwrite-only logic.
>
> For performance, I would tune sort and distribution choices, use incremental loads, and add materialized views or summary tables for heavy dashboards. For reliability, I would stage before publish and keep Redshift focused on serving analytics, while raw and cold data remains in S3. The main trade-off is that Redshift gives much better query performance than querying raw storage directly, but it costs more and should not be used as the raw system of record."

---

## Common Failure Cases

### Duplicate loads

- use batch IDs
- deduplicate in staging

### Slow joins

- revisit sort and distribution choices
- denormalize selectively if needed

### Wrong historical reporting

- likely missing SCD Type 2 logic
- avoid overwriting history accidentally

### Cost grows too much

- keep more data in S3
- use Redshift mainly for high-value serving workloads

---

## Interview Tips

- Mention **star schema** early
- Explain **fact vs dimension** clearly
- Mention **SCD Type 2** if history matters
- Use the phrase **staging -> validate -> merge -> publish**
- Do not describe Redshift as the raw data lake

---

## Quick Revision (5 points)

1. Clarify reporting needs, concurrency, SLA, and history requirements first
2. Explain the flow as `Curated S3 -> Staging -> Facts/Dimensions -> BI`
3. Deep dive on star schema, SCD Type 2, and safe load strategy
4. Mention sort keys, distribution, and summary tables
5. Close with Redshift performance benefits vs S3 storage cost advantages
