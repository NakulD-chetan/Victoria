# Greedy — Interview Thinking

> **Permanent Recall:** Identify greedy by keywords + structure. Justify with exchange argument. When pushed: "local choice doesn't hurt optimality." Greedy vs DP: "Do I need to try multiple choices?" → DP. "One best choice per step?" → Greedy.

---

## How to Identify Greedy Problems

### Keyword Triggers

| Phrase | Likely Greedy |
|--------|---------------|
| "Maximum number of..." | ✓ |
| "Minimum number of..." | ✓ |
| "Earliest / Latest" | ✓ |
| "Non-overlapping" | ✓ |
| "Can you reach..." | ✓ |
| "Optimal / Best" with local structure | ✓ |

### Structural Triggers

- **Intervals** — scheduling, meetings, activities
- **Sorted + process** — often greedy after sort
- **Single pass** — no need to revisit
- **No dependencies** — choice at step i doesn't constrain step i+1 in complex ways

### Red Flags (Maybe NOT Greedy)

- "Subset" with complex constraints
- "Partition" where parts interact
- "0/1" choices (take or leave) — think DP
- Need to "try all" or "explore" — backtracking/DP

---

## How to Justify "Greedy Is Correct"

### The 30-Second Pitch

> "At each step, we make the locally optimal choice. We can prove this leads to global optimum using an **exchange argument**: any optimal solution can be modified to include our greedy choice without getting worse."

### Exchange Argument (Template)

1. **Assume** optimal solution O exists
2. **Suppose** O doesn't use our greedy choice G
3. **Show** we can swap some element in O with G, solution stays valid and at least as good
4. **Conclude** greedy choice is safe

**Example (Activity Selection):**
- Greedy: pick activity with earliest end time
- Optimal O picks some activity A first
- If A ends after our greedy G: we can replace A with G (G ends earlier, so valid)
- Our solution ≥ O → greedy works

---

## When Interviewer Pushes Back: "How Do You Know Greedy Works?"

### Response Framework

1. **State the property:** "This problem has the greedy choice property."
2. **Give intuition:** "Picking X first never hurts — it frees up more options."
3. **Sketch proof:** "By exchange argument: any optimal solution can be modified to include our choice."
4. **Acknowledge edge cases:** "We handle ties by [secondary sort]."

### Sample Dialogue

**Interviewer:** "Why sort by end time and not start time?"

**You:** "Sorting by end time ensures we pick the interval that frees the resource soonest. If we picked one that ends later, we'd block more potential activities. By exchange argument: any optimal set can be transformed to include our earliest-ending choice without losing count."

---

## Greedy vs DP Discussion Strategy

| Question to Ask | If Yes → | If No → |
|-----------------|----------|---------|
| Can we take fractions? (knapsack) | Greedy | DP (0/1) |
| Does local choice always extend to global? | Greedy | DP |
| Do we need to try multiple choices? | DP | Greedy |
| Overlapping subproblems? | DP | Maybe greedy |
| "Minimum/maximum" with single criterion? | Often greedy | Check |

### Decision Tree

```
                    ┌──────────────────┐
                    │  Optimization    │
                    │  problem         │
                    └────────┬─────────┘
                             │
              ┌──────────────┴──────────────┐
              │                             │
     "Take fractions?"              "0/1 choices?"
     (fractional knapsack)           (0/1 knapsack)
              │                             │
              ▼                             ▼
           GREEDY                          DP
              │                             │
     "Intervals? Sort by end"        "Overlapping subproblems"
     "Jump? Max reach"               "Try all combinations"
```

---

## Proving Greedy: Two Techniques

### 1. Exchange Argument

- Transform optimal → include greedy
- Show transformation doesn't worsen

### 2. Greedy Stays Ahead

- Inductive: at each step, greedy ≥ any other
- Used in: Jump Game, scheduling

---

## What to Say When Stuck

- "Let me try sorting by [X] and see if a greedy strategy emerges."
- "I'll check: if I pick this, does it block better options? If not, greedy might work."
- "For intervals, sorting by end time is standard — let me try that."
- "I'm considering DP as backup if greedy doesn't work."

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY: "max/min number", intervals, "can you reach"
JUSTIFY: Exchange argument — swap greedy into optimal, no worse
PUSHBACK: "Greedy choice property — picking X frees more options"
GREEDY vs DP: Fractions→Greedy, 0/1→DP, try multiple→DP
PROOF: Exchange OR Greedy stays ahead
```
