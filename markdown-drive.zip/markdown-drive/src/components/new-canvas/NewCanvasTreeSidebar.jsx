import { memo, useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useNewCanvasStore } from './state/store';

/**
 * NewCanvasTreeSidebar — folder tree + search + context menus.
 * Port of CanvasTreeSidebar. Reuses `ft-*` from components/canvas/canvas.css.
 */

function canvasMatchesQuery(c, q) {
  if (!q?.trim()) return true;
  return (c.name || '').toLowerCase().includes(q.trim().toLowerCase());
}

function folderMatchesQuery(folder, allFolders, allCanvases, q) {
  if (!q?.trim()) return true;
  const qq = q.trim().toLowerCase();
  if ((folder.name || '').toLowerCase().includes(qq)) return true;
  const hasCanvas = allCanvases.some(
    (c) => (c.folderId || null) === folder.id && canvasMatchesQuery(c, qq),
  );
  if (hasCanvas) return true;
  const children = allFolders.filter((d) => d.parentId === folder.id);
  return children.some((child) => folderMatchesQuery(child, allFolders, allCanvases, qq));
}

function sortCanvasList(list, mode) {
  const sorted = [...list];
  sorted.sort((a, b) => {
    if (mode === 'recent') return (b.updatedAt || 0) - (a.updatedAt || 0);
    return (a.name || '').localeCompare(b.name || '');
  });
  return sorted;
}

function clampContextMenuPosition(anchor, menuEl) {
  const margin = 8;
  if (!anchor || !menuEl) return null;
  const rect = menuEl.getBoundingClientRect();
  const width = rect.width || 180;
  const height = rect.height || 120;
  return {
    left: Math.min(Math.max(anchor.x, margin), window.innerWidth - width - margin),
    top: Math.min(Math.max(anchor.y, margin), window.innerHeight - height - margin),
  };
}

function TreeCanvas({ canvas, isActive, onOpen, onDelete, onDuplicate, onStartRename }) {
  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const menuRef = useRef(null);

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const esc = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const sr = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', esc);
    window.addEventListener('resize', sr);
    window.addEventListener('scroll', sr, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', esc);
      window.removeEventListener('resize', sr);
      window.removeEventListener('scroll', sr, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  return (
    <div
      className={`ft-node ft-node--file ${isActive ? 'ft-node--active' : ''}`}
      style={{ paddingLeft: 14 }}
      onClick={() => onOpen(canvas.id)}
      onContextMenu={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setMenuAnchor({ x: e.clientX, y: e.clientY });
        setMenuPos(null);
      }}
    >
      <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <rect x="3" y="3" width="18" height="18" rx="2" />
        <circle cx="8.5" cy="8.5" r="1.5" />
        <path d="M21 15l-5-5L5 21" />
      </svg>
      <span className="ft-node__label">{canvas.name || 'Untitled'}</span>

      {menuAnchor && (
        <div
          ref={menuRef}
          className="ft-ctx"
          style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
          onClick={(e) => e.stopPropagation()}
        >
          <button onClick={() => { onOpen(canvas.id); setMenuAnchor(null); }}>Open</button>
          <button onClick={() => { onStartRename(canvas.id); setMenuAnchor(null); }}>Rename</button>
          <button onClick={() => { onDuplicate(canvas.id); setMenuAnchor(null); }}>Duplicate</button>
          <button className="ft-ctx--danger" onClick={() => { onDelete(canvas.id); setMenuAnchor(null); }}>Delete</button>
        </div>
      )}
    </div>
  );
}

function TreeRenameRow({ initialValue, depth, kind, onSubmit, onCancel }) {
  const [val, setVal] = useState(initialValue || '');
  const inputRef = useRef(null);
  useEffect(() => {
    if (inputRef.current) { inputRef.current.focus(); inputRef.current.select(); }
  }, []);
  return (
    <div
      className="ft-node ft-node--creating"
      style={{ paddingLeft: depth > 0 ? 14 : 10 }}
      onClick={(e) => e.stopPropagation()}
    >
      {kind === 'folder' ? (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
        </svg>
      ) : (
        <svg className="ft-node__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <rect x="3" y="3" width="18" height="18" rx="2" />
          <circle cx="8.5" cy="8.5" r="1.5" />
          <path d="M21 15l-5-5L5 21" />
        </svg>
      )}
      <input
        ref={inputRef}
        className="ft-node__edit"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={() => onSubmit(val)}
        onKeyDown={(e) => {
          if (e.key === 'Enter') onSubmit(val);
          if (e.key === 'Escape') onCancel();
        }}
        placeholder={kind === 'folder' ? 'Folder name...' : 'Canvas name...'}
      />
    </div>
  );
}

function TreeFolder({
  folder, depth, canvases, allFolders, activeCanvasId,
  deleteCanvas, duplicateCanvas, renameCanvas, startRenameCanvas,
  deleteFolder, renameFolder, createFolder, createCanvas, openCanvasInTab,
  searchQuery, sortMode, renamingId, beginRename, cancelRename,
  creatingIn, setCreatingIn, foldCommand,
}) {
  const [collapsed, setCollapsed] = useState(false);

  useEffect(() => {
    if (!foldCommand) return;
    if (foldCommand.action === 'collapse') setCollapsed(true);
    else if (foldCommand.action === 'expand') setCollapsed(false);
  }, [foldCommand]);

  const [menuAnchor, setMenuAnchor] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const menuRef = useRef(null);

  const childFolders = allFolders.filter((d) =>
    d.parentId === folder.id
    && folderMatchesQuery(d, allFolders, canvases, searchQuery),
  );
  const childCanvases = sortCanvasList(
    canvases.filter((c) => (c.folderId || null) === folder.id && canvasMatchesQuery(c, searchQuery)),
    sortMode,
  );

  useEffect(() => {
    if (!menuAnchor) return;
    const close = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuAnchor(null); };
    const esc = (e) => { if (e.key === 'Escape') setMenuAnchor(null); };
    const sr = () => setMenuAnchor(null);
    document.addEventListener('mousedown', close);
    window.addEventListener('keydown', esc);
    window.addEventListener('resize', sr);
    window.addEventListener('scroll', sr, true);
    return () => {
      document.removeEventListener('mousedown', close);
      window.removeEventListener('keydown', esc);
      window.removeEventListener('resize', sr);
      window.removeEventListener('scroll', sr, true);
    };
  }, [menuAnchor]);

  useEffect(() => {
    if (!menuAnchor || !menuRef.current) return;
    const frame = requestAnimationFrame(() => {
      const next = clampContextMenuPosition(menuAnchor, menuRef.current);
      if (next) setMenuPos(next);
    });
    return () => cancelAnimationFrame(frame);
  }, [menuAnchor]);

  const isRenamingThis = renamingId === folder.id;
  const isCreatingHere = creatingIn?.folderId === folder.id;

  return (
    <>
      {isRenamingThis ? (
        <TreeRenameRow
          initialValue={folder.name}
          depth={depth}
          kind="folder"
          onSubmit={(v) => { const t = (v || '').trim(); if (t) renameFolder(folder.id, t); cancelRename(); }}
          onCancel={cancelRename}
        />
      ) : (
        <div
          className={`ft-node ft-node--folder ${depth > 0 ? 'ft-node--guided' : ''}`}
          style={{ paddingLeft: 6 }}
          onClick={() => setCollapsed(!collapsed)}
          onContextMenu={(e) => {
            e.preventDefault();
            e.stopPropagation();
            setMenuAnchor({ x: e.clientX, y: e.clientY });
            setMenuPos(null);
          }}
        >
          <svg className="ft-node__arrow" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.3"
            style={{ transform: collapsed ? 'rotate(-90deg)' : 'rotate(0)' }}>
            <polyline points="8 10 12 14 16 10" />
          </svg>
          <span className="ft-node__label">{folder.name}</span>

          {menuAnchor && (
            <div
              ref={menuRef}
              className="ft-ctx"
              style={menuPos ? { left: `${menuPos.left}px`, top: `${menuPos.top}px` } : { left: `${menuAnchor.x}px`, top: `${menuAnchor.y}px`, visibility: 'hidden' }}
              onClick={(e) => e.stopPropagation()}
            >
              <button onClick={() => {
                setCreatingIn({ kind: 'canvas', folderId: folder.id });
                setCollapsed(false);
                setMenuAnchor(null);
              }}>New canvas here</button>
              <button onClick={() => {
                setCreatingIn({ kind: 'folder', folderId: folder.id });
                setCollapsed(false);
                setMenuAnchor(null);
              }}>New sub-folder</button>
              <button onClick={() => { beginRename(folder.id); setMenuAnchor(null); }}>Rename</button>
              <button className="ft-ctx--danger" onClick={() => {
                if (confirm(`Delete folder "${folder.name}" and all its canvases?`)) deleteFolder(folder.id);
                setMenuAnchor(null);
              }}>Delete folder</button>
            </div>
          )}
        </div>
      )}

      <div className={`ft-children ${collapsed ? 'ft-children--collapsed' : 'ft-children--expanded'}`}>
        <div className="ft-children__inner">
          {isCreatingHere && (
            <TreeRenameRow
              initialValue=""
              depth={depth + 1}
              kind={creatingIn.kind === 'folder' ? 'folder' : 'canvas'}
              onSubmit={(v) => {
                const t = (v || '').trim();
                if (t) {
                  if (creatingIn.kind === 'folder') createFolder(t, folder.id);
                  else { const id = createCanvas(t, folder.id); if (id) openCanvasInTab(id); }
                }
                setCreatingIn(null);
              }}
              onCancel={() => setCreatingIn(null)}
            />
          )}

          {childFolders.map((child) => (
            <TreeFolder
              key={child.id}
              folder={child}
              depth={depth + 1}
              canvases={canvases}
              allFolders={allFolders}
              activeCanvasId={activeCanvasId}
              deleteCanvas={deleteCanvas}
              duplicateCanvas={duplicateCanvas}
              renameCanvas={renameCanvas}
              startRenameCanvas={startRenameCanvas}
              deleteFolder={deleteFolder}
              renameFolder={renameFolder}
              createFolder={createFolder}
              createCanvas={createCanvas}
              openCanvasInTab={openCanvasInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              renamingId={renamingId}
              beginRename={beginRename}
              cancelRename={cancelRename}
              creatingIn={creatingIn}
              setCreatingIn={setCreatingIn}
              foldCommand={foldCommand}
            />
          ))}
          {childCanvases.map((canvas) => (
            renamingId === canvas.id ? (
              <TreeRenameRow
                key={canvas.id}
                initialValue={canvas.name}
                depth={depth + 1}
                kind="canvas"
                onSubmit={(v) => { const t = (v || '').trim(); if (t) renameCanvas(canvas.id, t); cancelRename(); }}
                onCancel={cancelRename}
              />
            ) : (
              <TreeCanvas
                key={canvas.id}
                canvas={canvas}
                isActive={canvas.id === activeCanvasId}
                onOpen={openCanvasInTab}
                onDelete={deleteCanvas}
                onDuplicate={duplicateCanvas}
                onStartRename={startRenameCanvas}
              />
            )
          ))}
        </div>
      </div>
    </>
  );
}

const NewCanvasTreeSidebar = memo(function NewCanvasTreeSidebar({ onNewCanvas, onThemeToggle }) {
  const scenesMap = useNewCanvasStore((s) => s.scenes);
  const foldersMap = useNewCanvasStore((s) => s.folders);
  const activeId = useNewCanvasStore((s) => s.activeId);
  const openInTab = useNewCanvasStore((s) => s.openInTab);
  const createScene = useNewCanvasStore((s) => s.createScene);
  const deleteScene = useNewCanvasStore((s) => s.deleteScene);
  const renameScene = useNewCanvasStore((s) => s.renameScene);
  const duplicateScene = useNewCanvasStore((s) => s.duplicateScene);
  const createFolder = useNewCanvasStore((s) => s.createFolder);
  const deleteFolder = useNewCanvasStore((s) => s.deleteFolder);
  const renameFolder = useNewCanvasStore((s) => s.renameFolder);

  const [collapsed, setCollapsed] = useState(false);
  const [creatingIn, setCreatingIn] = useState(null);
  const [renamingId, setRenamingId] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState('name');
  const [allExpanded, setAllExpanded] = useState(true);
  const [foldCommand, setFoldCommand] = useState(null);
  const [foldAnimating, setFoldAnimating] = useState(false);
  const searchRef = useRef(null);

  const canvasesArr = useMemo(() => Object.values(scenesMap), [scenesMap]);
  const foldersArr  = useMemo(() => Object.values(foldersMap), [foldersMap]);

  const rootFolders = useMemo(() => (
    foldersArr
      .filter((d) => (d.parentId || null) === null && folderMatchesQuery(d, foldersArr, canvasesArr, searchQuery))
      .sort((a, b) => (a.name || '').localeCompare(b.name || ''))
  ), [foldersArr, canvasesArr, searchQuery]);

  const rootCanvases = useMemo(() => sortCanvasList(
    canvasesArr.filter((c) => (c.folderId || null) === null && canvasMatchesQuery(c, searchQuery)),
    sortMode,
  ), [canvasesArr, searchQuery, sortMode]);

  const hasResults = rootFolders.length > 0 || rootCanvases.length > 0;
  const hasAny = canvasesArr.length > 0 || foldersArr.length > 0;

  useEffect(() => {
    const onFocusSearch = (e) => {
      const key = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && key === 'f') {
        if (!searchRef.current) return;
        e.preventDefault();
        searchRef.current.focus();
        searchRef.current.select();
      }
    };
    window.addEventListener('keydown', onFocusSearch, true);
    return () => window.removeEventListener('keydown', onFocusSearch, true);
  }, []);

  const openCanvasInTab = useCallback((id) => { openInTab(id); }, [openInTab]);

  const startRenameCanvas = useCallback((id) => setRenamingId(id), []);
  const beginRename = useCallback((id) => setRenamingId(id), []);
  const cancelRename = useCallback(() => setRenamingId(null), []);

  const handleToggleSort = useCallback(() => {
    setSortMode((prev) => (prev === 'name' ? 'recent' : 'name'));
  }, []);

  const handleToggleFoldAll = useCallback(() => {
    setAllExpanded((prev) => {
      const next = !prev;
      setFoldCommand({ action: next ? 'expand' : 'collapse', nonce: Date.now() });
      return next;
    });
    setFoldAnimating(true);
    setTimeout(() => setFoldAnimating(false), 360);
  }, []);

  const handleNewCanvasTopLevel = useCallback(() => {
    if (onNewCanvas) { onNewCanvas(); return; }
    setCreatingIn({ kind: 'canvas', folderId: null });
  }, [onNewCanvas]);

  const handleNewFolderTopLevel = useCallback(() => {
    setCreatingIn({ kind: 'folder', folderId: null });
  }, []);

  const rootCreatingHere = creatingIn && (creatingIn.folderId === null || creatingIn.folderId === undefined);

  return (
    <div className={`ft-sidebar${collapsed ? ' ft-sidebar--collapsed' : ''}`}>
      {collapsed ? (
        <button
          type="button"
          className="ft-sidebar__toggle"
          onClick={() => setCollapsed(false)}
          title="Expand sidebar"
          aria-label="Expand sidebar"
          aria-expanded={false}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
        </button>
      ) : (
      <div className="ft-pane">
        <div className="ft-actions">
          <button className="ft-actions__btn" onClick={handleNewCanvasTopLevel} title="New canvas">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="18" height="18" rx="2" />
              <line x1="12" y1="8" x2="12" y2="16" />
              <line x1="8" y1="12" x2="16" y2="12" />
            </svg>
          </button>
          <button className="ft-actions__btn" onClick={handleNewFolderTopLevel} title="New folder">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
              <line x1="12" y1="11" x2="12" y2="17" />
              <line x1="9" y1="14" x2="15" y2="14" />
            </svg>
          </button>
          <button className="ft-actions__btn" title={`Sort: ${sortMode === 'name' ? 'Name' : 'Recent'}`} onClick={handleToggleSort}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="4" y1="6" x2="20" y2="6" /><line x1="4" y1="12" x2="14" y2="12" /><line x1="4" y1="18" x2="10" y2="18" /></svg>
          </button>
          <button
            className={`ft-actions__btn ft-fold-all${foldAnimating ? ' ft-fold-all--animating' : ''}`}
            title={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-label={allExpanded ? 'Collapse all folders' : 'Expand all folders'}
            aria-pressed={!allExpanded}
            onClick={handleToggleFoldAll}
          >
            <span className="ft-fold-all__icon" key={allExpanded ? 'expanded' : 'collapsed'}>
              {allExpanded ? (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="17 11 12 6 7 11" />
                  <polyline points="17 18 12 13 7 18" />
                </svg>
              ) : (
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="7 13 12 18 17 13" />
                  <polyline points="7 6 12 11 17 6" />
                </svg>
              )}
            </span>
          </button>
          <button className="ft-actions__btn" title="Collapse sidebar" onClick={() => setCollapsed(true)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><line x1="9" y1="3" x2="9" y2="21" /></svg>
          </button>
        </div>

        <div className="ft-search">
          <svg className="ft-search__icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="8" />
            <line x1="21" y1="21" x2="16.65" y2="16.65" />
          </svg>
          <input
            ref={searchRef}
            className="ft-search__input"
            placeholder="Search canvases..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="ft-search__clear" onClick={() => setSearchQuery('')} title="Clear search">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" />
                <line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>

        <div className="ft-tree">
          {!hasAny && !creatingIn && (
            <div className="ft-tree__empty-state">
              <div className="ft-tree__empty-title">No canvases yet</div>
              <div className="ft-tree__empty-copy">Create a new canvas to get started.</div>
              <button className="ft-tree__empty-btn" onClick={handleNewCanvasTopLevel}>Create new canvas</button>
            </div>
          )}

          {rootCreatingHere && (
            <TreeRenameRow
              initialValue=""
              depth={0}
              kind={creatingIn.kind === 'folder' ? 'folder' : 'canvas'}
              onSubmit={(v) => {
                const t = (v || '').trim();
                if (t) {
                  if (creatingIn.kind === 'folder') createFolder(t, null);
                  else { const id = createScene(t, null); if (id) openCanvasInTab(id); }
                }
                setCreatingIn(null);
              }}
              onCancel={() => setCreatingIn(null)}
            />
          )}

          {rootFolders.map((folder) => (
            <TreeFolder
              key={folder.id}
              folder={folder}
              depth={0}
              canvases={canvasesArr}
              allFolders={foldersArr}
              activeCanvasId={activeId}
              deleteCanvas={deleteScene}
              duplicateCanvas={duplicateScene}
              renameCanvas={renameScene}
              startRenameCanvas={startRenameCanvas}
              deleteFolder={deleteFolder}
              renameFolder={renameFolder}
              createFolder={createFolder}
              foldCommand={foldCommand}
              createCanvas={createScene}
              openCanvasInTab={openCanvasInTab}
              searchQuery={searchQuery}
              sortMode={sortMode}
              renamingId={renamingId}
              beginRename={beginRename}
              cancelRename={cancelRename}
              creatingIn={creatingIn}
              setCreatingIn={setCreatingIn}
            />
          ))}

          {rootCanvases.map((canvas) => (
            renamingId === canvas.id ? (
              <TreeRenameRow
                key={canvas.id}
                initialValue={canvas.name}
                depth={0}
                kind="canvas"
                onSubmit={(v) => { const t = (v || '').trim(); if (t) renameScene(canvas.id, t); cancelRename(); }}
                onCancel={cancelRename}
              />
            ) : (
              <TreeCanvas
                key={canvas.id}
                canvas={canvas}
                isActive={canvas.id === activeId}
                onOpen={openCanvasInTab}
                onDelete={deleteScene}
                onDuplicate={duplicateScene}
                onStartRename={startRenameCanvas}
              />
            )
          ))}

          {hasAny && !hasResults && (
            <div className="ft-tree__empty">No canvases found</div>
          )}
        </div>

        <div className="ft-bottom">
          <button
            type="button"
            className="ft-bottom__vault-btn"
            title="Local storage (no cloud sync for new-canvas)"
            aria-haspopup={false}
          >
            <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M7 10l5 5 5-5z" /></svg>
            <span className="ft-bottom__vault-btn-name">LOCAL</span>
          </button>
        </div>
      </div>
      )}
    </div>
  );
});

export default NewCanvasTreeSidebar;
