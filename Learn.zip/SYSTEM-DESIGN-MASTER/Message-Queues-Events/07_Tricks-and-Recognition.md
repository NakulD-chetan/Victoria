# Message Queues and Events — Tricks and Recognition

> **Permanent Recall:** This file is about pattern spotting. When you hear **background processing**, **fan-out**, **spikes**, **replay**, **workflow**, or **multiple services reacting**, messaging should come to mind immediately. Then choose the right model and tool.

---

## The Recognition Layer

In interviews, you often do not get asked, "Should we use Kafka?"  
You get a business problem and must recognize that messaging fits.

This file trains that reflex.

---

## Trigger Phrases That Suggest Messaging

| Trigger Phrase | What It Usually Means |
|---|---|
| "Process later" | Async queue |
| "Run in background" | Job queue |
| "Handle spikes" | Buffering with broker |
| "Many services need this event" | Pub/sub |
| "Event-driven architecture" | Topic/event bus |
| "Need replay" | Kafka |
| "Need audit trail" | Kafka or event sourcing |
| "Workflow across services" | Saga |
| "Loose coupling" | Messaging is a candidate |

---

## Fast Tool Recognition

### Kafka fits when you hear

- replay
- analytics pipeline
- activity stream
- event sourcing
- many independent consumers
- very high throughput

### RabbitMQ fits when you hear

- task queue
- routing rules
- work distribution
- exchange and binding style delivery

### SQS/SNS fits when you hear

- AWS-native
- simple managed queue
- fan-out without self-managing brokers

---

## One-Line Selection Tricks

| Need | Fast Choice |
|---|---|
| Replayable event history | Kafka |
| Routing-heavy worker system | RabbitMQ |
| Managed AWS queue | SQS |
| Managed AWS fan-out | SNS + SQS |

Quick shortcut:

```text
Replay -> Kafka
Routing -> RabbitMQ
Managed AWS simplicity -> SQS/SNS
```

---

## Queue vs Pub/Sub Recognition

| If The Problem Sounds Like | Better Fit |
|---|---|
| "Whoever worker is free should process it" | Queue |
| "Every interested service should react" | Pub/Sub |
| "One business event, many side effects" | Pub/Sub |
| "Distribute jobs across workers" | Queue |

---

## Ordering Recognition

If the domain mentions:

- account updates
- order lifecycle
- inventory reservation
- payment state
- cart changes

ask yourself:

"Do events for the same entity need ordered handling?"

If yes:

- partition by entity key
- do not talk about global ordering unless required

---

## Partition Count Recognition

You do not need perfect numbers in interviews.  
You do need the right reasoning.

### Safe heuristics

- partitions should be at least as many as peak active consumers
- more partitions increase parallelism
- too many partitions increase metadata and coordination overhead

### Good interview phrasing

"I would start with enough partitions to support expected consumer parallelism and grow if lag suggests we need more."

---

## Consumer Group Recognition

Remember these 3 quick facts:

- one partition is actively consumed by one consumer in a group
- extra consumers stay idle if there are not enough partitions
- consumer groups scale reads horizontally

```text
4 partitions -> at most 4 active consumers in one group
```

---

## Pattern Shortcuts For Common Design Questions

| Design Problem | Messaging Angle |
|---|---|
| Notification system | Pub/sub fan-out |
| Analytics pipeline | Kafka stream/event log |
| Order processing | Event-driven workflow |
| Payment workflow | Saga + idempotency |
| Ride matching / job dispatch | Queue + workers |
| Audit or replay requirement | Kafka |

---

## Delivery Guarantee Recognition

| Requirement | Practical Answer |
|---|---|
| "Do not lose messages" | At-least-once |
| "Do not double-apply business effect" | Idempotent consumer |
| "Best effort is enough" | At-most-once |
| "We really want exactly-once" | Explain limited scope and complexity |

---

## Choreography vs Orchestration Recognition

| If Flow Looks Like | Better Default |
|---|---|
| Small number of steps, loose coupling | Choreography |
| Many steps, branching logic, compensation complexity | Orchestration |

Simple rule:

- small workflow -> choreography can be okay
- complex workflow -> orchestration is easier to explain and operate

---

## Red-Flag Phrases To Catch

If you hear yourself saying any of these, stop and refine:

- "Kafka for everything"
- "Ordering is guaranteed"
- "Exactly-once"
- "We can retry forever"
- "Extra consumers always help"

Each one needs a qualifier.

---

## 30-SECOND REVISION BOX

```text
TRIGGERS: background work, spikes, fan-out, replay, workflow
QUEUE: one worker handles one message
PUB/SUB: many services react to one event
KAFKA: replay, throughput, event log
RABBITMQ: routing and task queues
SQS/SNS: managed AWS messaging
ORDERING: ask if per-entity ordering matters
PARTITIONS: parallelism up, overhead up
CONSUMER GROUP: one active consumer per partition
SAGA: choreography for simpler flows, orchestration for complex flows
```

---

**Prev: [[06_Edge-Cases]] | Next: [[08_Question-List]]**
