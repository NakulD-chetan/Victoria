import { create } from 'zustand';
import { defaultViewport } from './types';
import { createHistory, commit, undo, redo, canUndo, canRedo } from './history';
import {
  readAll,
  scheduleWrite,
  createBlankScene,
  createBlankFolder,
} from './persist';
import { normalizeElementsV2 } from './types';
import { resolveSceneBindings } from '../engine/binding-engine';
import { normalizeTeachingDocumentV3 } from '../canvas-v3/document';

/**
 * useNewCanvasStore — single source of truth for the new canvas app.
 *
 * Scoping rules (important for keeping the "draw → visible" loop clean):
 *   - The current `elements` array is the render input. Replacing it is what
 *     drives repaints (via the engine's subscription).
 *   - Mid-gesture draft elements live in the ENGINE, not here. We never write
 *     to this store during a pointer gesture. Commit happens on pointerup.
 *   - History holds *full element arrays*. Because we use immutable updates,
 *     unchanged elements share references, so this is cheap.
 *   - Viewport writes are rAF-throttled in the engine; direct `setViewport`
 *     from the UI (zoom buttons, fit-to-screen) is fine.
 */

const initialRaw = readAll();
const initial = {
  ...initialRaw,
  scenes: Object.fromEntries(
    Object.entries(initialRaw.scenes || {}).map(([id, scene]) => [
      id,
      {
        ...scene,
        elements: resolveSceneBindings(normalizeElementsV2(scene.elements)),
      },
    ]),
  ),
};

function writeBack(state) {
  scheduleWrite({
    documentVersion: 2,
    scenes: state.scenes,
    folders: state.folders,
    openTabs: state.openTabs,
    activeId: state.activeId,
  });
}

function sameIds(a = [], b = []) {
  if (a === b) return true;
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
  for (let i = 0; i < a.length; i += 1) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

export const useNewCanvasStore = create((set, get) => ({
  scenes: initial.scenes,
  folders: initial.folders,
  openTabs: initial.openTabs,
  activeId: initial.activeId,

  // derived-by-convention getters read from scenes[activeId]
  history: createHistory(initial.scenes[initial.activeId]?.elements || []),

  tool: 'pen',
  toolOptions: {
    stroke: '#e2e8f0',
    fill: 'transparent',
    strokeWidth: 2,
    opacity: 1,
    fontSize: 20,
  },
  selection: new Set(),

  /* ── Scene lifecycle ─────────────────────────────────────── */

  setActiveScene(id) {
    const { scenes, openTabs } = get();
    if (!scenes[id]) return;
    const elements = scenes[id].elements;
    let nextOpenTabs = openTabs;
    if (!openTabs.includes(id)) nextOpenTabs = openTabs.concat([id]);
    const next = {
      activeId: id,
      history: createHistory(elements),
      selection: new Set(),
      openTabs: nextOpenTabs,
    };
    set(next);
    writeBack({ ...get(), ...next });
  },

  openInTab(id) {
    const { scenes, openTabs } = get();
    if (!scenes[id]) return;
    if (!openTabs.includes(id)) {
      const nextTabs = openTabs.concat([id]);
      set({ openTabs: nextTabs });
    }
    get().setActiveScene(id);
  },

  closeTab(id) {
    const { openTabs, activeId, scenes } = get();
    const idx = openTabs.indexOf(id);
    if (idx === -1) return;
    const nextTabs = openTabs.filter((t) => t !== id);
    let nextActive = activeId;
    if (activeId === id) {
      nextActive = nextTabs[Math.max(0, idx - 1)] || nextTabs[0] || null;
    }
    const nextHistory = nextActive
      ? createHistory(scenes[nextActive]?.elements || [])
      : createHistory([]);
    set({
      openTabs: nextTabs,
      activeId: nextActive,
      history: nextHistory,
      selection: new Set(),
    });
    writeBack(get());
  },

  createScene(name, folderId = null) {
    const scene = createBlankScene(name, folderId);
    const scenes = { ...get().scenes, [scene.id]: scene };
    const openTabs = get().openTabs.concat([scene.id]);
    set({
      scenes,
      activeId: scene.id,
      openTabs,
      history: createHistory([]),
      selection: new Set(),
    });
    writeBack(get());
    return scene.id;
  },

  renameScene(id, name) {
    const scenes = get().scenes;
    const prev = scenes[id];
    if (!prev) return;
    const next = { ...scenes, [id]: { ...prev, name, updatedAt: Date.now() } };
    set({ scenes: next });
    writeBack(get());
  },

  duplicateScene(id) {
    const src = get().scenes[id];
    if (!src) return null;
    const copy = {
      ...src,
      id: createBlankScene('').id,
      name: `${src.name} (copy)`,
      elements: src.elements.map((e) => ({ ...e })),
      updatedAt: Date.now(),
    };
    const scenes = { ...get().scenes, [copy.id]: copy };
    set({ scenes });
    writeBack(get());
    return copy.id;
  },

  moveSceneToFolder(id, folderId) {
    const scenes = get().scenes;
    const prev = scenes[id];
    if (!prev) return;
    const next = { ...scenes, [id]: { ...prev, folderId: folderId || null, updatedAt: Date.now() } };
    set({ scenes: next });
    writeBack(get());
  },

  deleteScene(id) {
    const { scenes, activeId, openTabs } = get();
    if (!scenes[id]) return;
    const { [id]: _removed, ...rest } = scenes;
    void _removed;
    let nextScenes = rest;
    let nextTabs = openTabs.filter((t) => t !== id);
    let nextActive = activeId;
    if (Object.keys(nextScenes).length === 0) {
      const fresh = createBlankScene('Canvas 1');
      nextScenes = { [fresh.id]: fresh };
      nextActive = fresh.id;
      nextTabs = [fresh.id];
    } else if (activeId === id) {
      nextActive = nextTabs[0] || Object.keys(nextScenes)[0];
    }
    set({
      scenes: nextScenes,
      activeId: nextActive,
      openTabs: nextTabs,
      history: createHistory(nextScenes[nextActive].elements),
      selection: new Set(),
    });
    writeBack(get());
  },

  /* ── Folder lifecycle ─────────────────────────────────────── */

  createFolder(name, parentId = null) {
    const folder = createBlankFolder(name, parentId);
    const folders = { ...get().folders, [folder.id]: folder };
    set({ folders });
    writeBack(get());
    return folder.id;
  },

  renameFolder(id, name) {
    const folders = get().folders;
    const prev = folders[id];
    if (!prev) return;
    const next = { ...folders, [id]: { ...prev, name, updatedAt: Date.now() } };
    set({ folders: next });
    writeBack(get());
  },

  deleteFolder(id) {
    const { folders, scenes, openTabs, activeId } = get();
    if (!folders[id]) return;

    // collect all descendant folder ids (including self)
    const toDelete = new Set([id]);
    let grew = true;
    while (grew) {
      grew = false;
      for (const f of Object.values(folders)) {
        if (!toDelete.has(f.id) && f.parentId && toDelete.has(f.parentId)) {
          toDelete.add(f.id);
          grew = true;
        }
      }
    }

    const nextFolders = {};
    for (const [k, v] of Object.entries(folders)) {
      if (!toDelete.has(k)) nextFolders[k] = v;
    }

    const nextScenes = {};
    for (const [k, v] of Object.entries(scenes)) {
      if (!toDelete.has(v.folderId)) nextScenes[k] = v;
    }

    const removedSceneIds = Object.keys(scenes).filter((sid) => !nextScenes[sid]);
    let nextTabs = openTabs.filter((t) => !removedSceneIds.includes(t));
    let nextActive = activeId;
    if (removedSceneIds.includes(activeId)) {
      nextActive = nextTabs[0] || Object.keys(nextScenes)[0] || null;
    }
    if (!nextActive && Object.keys(nextScenes).length === 0) {
      const fresh = createBlankScene('Canvas 1');
      nextScenes[fresh.id] = fresh;
      nextActive = fresh.id;
      nextTabs = [fresh.id];
    }

    set({
      folders: nextFolders,
      scenes: nextScenes,
      openTabs: nextTabs,
      activeId: nextActive,
      history: createHistory(nextScenes[nextActive]?.elements || []),
      selection: new Set(),
    });
    writeBack(get());
  },

  /* ── Elements (the render input) ─────────────────────────── */

  /**
   * Replace the whole element array for the active scene. Writes a history
   * snapshot unless `{ transient: true }` is passed (used for move drags that
   * haven't committed yet — but normally you should keep drafts in the engine
   * and call commitElements once on pointerup).
   */
  commitElements(updater, opts = {}) {
    const { scenes, activeId, history } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const current = scene.elements;
    const updated = typeof updater === 'function' ? updater(current) : updater;
    const nextElements = resolveSceneBindings(normalizeElementsV2(updated));
    if (nextElements === current) return;

    const nextHistory = opts.transient
      ? { ...history, present: nextElements }
      : commit(history, nextElements, opts.coalesceKey || null);

    const nextScene = {
      ...scene,
      documentVersion: 2,
      elements: nextElements,
      updatedAt: Date.now(),
    };
    const nextScenes = { ...scenes, [activeId]: nextScene };
    set({ scenes: nextScenes, history: nextHistory });
    writeBack(get());
  },

  /**
   * Finalize a gesture that was driven by `commitTransient`. We override the
   * history entry so that undo restores the pre-gesture state in ONE step.
   * Pass the element array that existed BEFORE the gesture started.
   */
  commitGesture(prevElements, nextElements) {
    const { scenes, activeId, history } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    if (nextElements === prevElements) return;
    const past = history.past.concat([prevElements]);
    const MAX = 200;
    if (past.length > MAX) past.shift();
    const nextHistory = { past, present: nextElements, future: [], lastCoalesceKey: null };
    const normalized = resolveSceneBindings(normalizeElementsV2(nextElements));
    const nextScene = {
      ...scene,
      documentVersion: 2,
      elements: normalized,
      updatedAt: Date.now(),
    };
    const nextScenes = { ...scenes, [activeId]: nextScene };
    set({
      scenes: nextScenes,
      history: { ...nextHistory, present: normalized },
    });
    writeBack(get());
  },

  /* ── Viewport ────────────────────────────────────────────── */

  setViewport(updater, options = {}) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const current = scene.viewport || defaultViewport();
    const next = typeof updater === 'function' ? updater(current) : updater;
    if (
      next.zoom === current.zoom
      && next.panX === current.panX
      && next.panY === current.panY
    ) return;
    const nextScenes = { ...scenes, [activeId]: { ...scene, viewport: next } };
    set({ scenes: nextScenes });
    if (!options.transient) writeBack(get());
  },

  appendAgentHistory(entry) {
    if (!entry?.runId) return;
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const history = Array.isArray(scene.agentHistory) ? scene.agentHistory : [];
    if (history.some((item) => item.runId === entry.runId)) return;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        agentHistory: history.concat([entry]).slice(-40),
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    writeBack(get());
  },

  patchActiveSceneMeta(patch) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        ...patch,
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    writeBack(get());
  },

  setV3Document(document, { persist = true } = {}) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        v3Document: normalizeTeachingDocumentV3(document),
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    if (persist) writeBack({ ...get(), scenes: nextScenes });
  },

  patchV3Document(updater, options = {}) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const current = normalizeTeachingDocumentV3(scene.v3Document);
    const next = typeof updater === 'function' ? updater(current) : { ...current, ...updater };
    get().setV3Document(next, options);
  },

  setV3Selection(ids) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const nextIds = Array.isArray(ids) ? ids : [];
    if (sameIds(scene.v3Selection, nextIds)) return;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        v3Selection: nextIds,
      },
    };
    set({ scenes: nextScenes });
  },

  setV3Playback(patch) {
    get().patchV3Document((document) => ({
      ...document,
      playback: {
        ...document.playback,
        ...patch,
      },
      updatedAt: Date.now(),
    }));
  },

  setPinnedTarget(target) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const normalized = target?.elementId
      ? {
          sceneId: activeId,
          elementId: target.elementId,
          widgetType: target.widgetType || null,
          title: target.title || '',
          role: target.role || 'general',
          lessonPageId: target.lessonPageId || null,
          pinnedAt: Date.now(),
        }
      : null;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        pinnedTarget: normalized,
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    writeBack(get());
  },

  clearPinnedTarget() {
    get().setPinnedTarget(null);
  },

  upsertLessonPage(page) {
    if (!page?.id) return;
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene) return;
    const currentDeck = scene.lessonDeck || { pages: [], currentPageId: null };
    const existingIndex = currentDeck.pages.findIndex((candidate) => candidate.id === page.id);
    const nextPages = existingIndex === -1
      ? currentDeck.pages.concat([page])
      : currentDeck.pages.map((candidate, index) => (index === existingIndex ? { ...candidate, ...page } : candidate));
    const nextDeck = {
      pages: nextPages
        .map((candidate, index) => ({
          ...candidate,
          order: Number.isFinite(candidate.order) ? candidate.order : index,
        }))
        .sort((a, b) => a.order - b.order),
      currentPageId: page.id,
    };
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        lessonDeck: nextDeck,
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    writeBack(get());
  },

  setCurrentLessonPage(pageId) {
    const { scenes, activeId } = get();
    const scene = scenes[activeId];
    if (!scene || !pageId) return;
    const deck = scene.lessonDeck || { pages: [], currentPageId: null };
    if (!deck.pages.some((page) => page.id === pageId)) return;
    const nextScenes = {
      ...scenes,
      [activeId]: {
        ...scene,
        lessonDeck: {
          ...deck,
          currentPageId: pageId,
        },
        updatedAt: Date.now(),
      },
    };
    set({ scenes: nextScenes });
    writeBack(get());
  },

  /* ── Tool / options ──────────────────────────────────────── */

  setTool(tool) { set({ tool, selection: new Set() }); },
  setToolOptions(patch) {
    set((s) => ({ toolOptions: { ...s.toolOptions, ...patch } }));
  },

  /* ── Selection ───────────────────────────────────────────── */

  setSelection(ids) {
    const set_ = ids instanceof Set ? ids : new Set(ids);
    set({ selection: set_ });
  },
  clearSelection() { set({ selection: new Set() }); },

  /* ── Undo / redo ─────────────────────────────────────────── */

  undo() {
    const { history, scenes, activeId } = get();
    if (!canUndo(history)) return;
    const nh = undo(history);
    const nextScenes = {
      ...scenes,
      [activeId]: { ...scenes[activeId], elements: nh.present, updatedAt: Date.now() },
    };
    set({ history: nh, scenes: nextScenes, selection: new Set() });
    writeBack(get());
  },
  redo() {
    const { history, scenes, activeId } = get();
    if (!canRedo(history)) return;
    const nh = redo(history);
    const nextScenes = {
      ...scenes,
      [activeId]: { ...scenes[activeId], elements: nh.present, updatedAt: Date.now() },
    };
    set({ history: nh, scenes: nextScenes, selection: new Set() });
    writeBack(get());
  },
}));

/** Helper: read the current scene without subscribing. */
export function getActiveScene() {
  const s = useNewCanvasStore.getState();
  return s.scenes[s.activeId];
}
