# Normalization and Transactions — Coding Templates

---

## Transaction basics

```sql
BEGIN;
  UPDATE accounts SET balance = balance - 500 WHERE id = 1;
  UPDATE accounts SET balance = balance + 500 WHERE id = 2;
COMMIT;
```

---

## SAVEPOINT

```sql
BEGIN;
  INSERT INTO logs VALUES (1, 'start');
  SAVEPOINT sp1;
  INSERT INTO logs VALUES (2, 'risky step');
  -- oops
  ROLLBACK TO sp1;
  INSERT INTO logs VALUES (3, 'safe step');
COMMIT;
```

---

## Set isolation level

```sql
-- Postgres
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
BEGIN;
  SELECT * FROM inventory WHERE product_id = 42;
  -- guaranteed same result on re-read within this tx
COMMIT;

-- MySQL
SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE;
```

---

## Normalization example (1NF fix)

```sql
-- BAD (not 1NF): phones column has "123,456"
-- FIX: separate table
CREATE TABLE user_phones (
    user_id INT REFERENCES users(id),
    phone   VARCHAR(20),
    PRIMARY KEY (user_id, phone)
);
```

---

## 2NF fix (remove partial dependency)

```sql
-- BAD: student_courses(student_id, course_id, student_name, course_name)
-- student_name depends only on student_id (partial dep on composite PK)

-- FIX:
-- students(student_id PK, student_name)
-- courses(course_id PK, course_name)
-- enrollments(student_id, course_id) PK
```

---

*Next: [[04_Interview-Thinking]]*
