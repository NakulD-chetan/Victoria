# Types of Facts: Additive, Semi-Additive, Non-Additive

> "Summation is a privilege, not a right. Know which dimensions grant it."

**Real-world analogy:** A regional grocer can add daily sales dollars across stores to get a chain total, but cannot add "average shelf temperature" across stores to learn anything about food safety. Additivity is the rulebook that says which totals are meaningful arithmetic versus which require a different statistical path.

---

## Core Idea (2 Lines)

Additivity describes whether a numeric fact can be meaningfully summed along a given dimension. Classifying retail measures correctly prevents executives from summing unit prices, averaging ratios without weights, or summing end-of-day inventory across stores as if it were cash.

---

## What Additivity Means

For a fact `M`, dimension `D`, and a set of rows `R` selected by a filter on `D`:

| Property | Meaning |
|----------|---------|
| Additive along `D` | `SUM(M)` over `R` matches the business definition of a total across `D` |
| Semi-additive along `D` | Summing across `D` is wrong; an aggregate like `AVG` or end-of-period pick is needed |
| Non-additive along `D` | Almost any naive `SUM` or simple `AVG` misleads; recompute from components |

```
Decision flow (conceptual)
==========================
Start with a measure
        |
        v
Can you SUM it across TIME for one store-SKU?
        |
   yes--+---> check PRODUCT, STORE, PROMO similarly
   |              |
   |              v
   |         If SUM ok along all key dims -> ADDITIVE
   |
   no
        |
        v
Is it a balance / level / account snapshot across time?
        |
   yes--+---> SEMI-ADDITIVE (often sum across some dims, not time)
   |
   no
        |
        v
Is it a ratio, distinct count, temperature, unit price?
        |
   yes--+---> NON-ADDITIVE (derive from parts or re-aggregate source)
```

**Interview Tip:** Always pair the classification with "along which dimension" because semi-additivity is defined by exceptions.

**Watch Out!** Tools default to `SUM`; non-additive facts silently become false KPIs.

---

## Additive Facts (Retail Sales Example)

| Measure | Typical additive behavior |
|---------|---------------------------|
| `sale_amount` | Sum across time, store, product, promotion |
| `quantity` | Sum across same dimensions if UOM consistent |
| `discount_amount` | Sum across dimensions if sign conventions stable |

```sql
-- Additive rollups are straightforward
SELECT
  d.fiscal_month,
  SUM(f.sale_amount) AS monthly_sales,
  SUM(f.quantity) AS monthly_units
FROM retail_core.fact_pos_sale_line f
JOIN retail_core.dim_date d ON f.date_sk = d.date_sk
GROUP BY 1
ORDER BY 1;
```

**Interview Tip:** Mention that additivity still needs guardrails such as currency conversion before summing international banners.

---

## Non-Additive Facts (Unit Price, Temperature, Percentages)

| Measure | Why SUM fails | Safer aggregation |
|---------|---------------|-------------------|
| `unit_price` | Double-counts weight toward high-volume SKUs | `SUM(amount)/SUM(qty)` weighted average |
| `avg_store_temperature_c` | Physical meaninglessness | `AVG` with care, or min/max thresholds per store |
| `basket_penetration_percent` | Percents of percents | Recompute from counts at combined grain |

```sql
-- Weighted average unit price at monthly category level
SELECT
  d.fiscal_month,
  p.category,
  SAFE_DIVIDE(SUM(f.sale_amount), NULLIF(SUM(f.quantity), 0)) AS avg_implied_unit_price
FROM retail_core.fact_pos_sale_line f
JOIN retail_core.dim_date d ON f.date_sk = d.date_sk
JOIN retail_core.dim_product p ON f.product_sk = p.product_sk
GROUP BY 1, 2;
```

**Watch Out!** Storing `margin_percent` on each line tempts analysts to `SUM(margin_percent)`.

---

## Semi-Additive Facts (Inventory on Hand)

End-of-day `units_on_hand` can be summed across products within one store at one timestamp to get store total on-hand, but cannot be summed across multiple dates for one SKU without double counting the same units repeatedly.

| Along dimension | Typical semi-additive rule for inventory snapshot |
|-----------------|---------------------------------------------------|
| `product` | SUM ok within a single store-day snapshot |
| `store` | SUM ok within a single product-day snapshot |
| `time` (calendar) | SUM across days is wrong; use average on-hand, min, max, or last non-null |

```sql
-- Wrong: summing daily snapshots across a month for one SKU in one store
SELECT SUM(on_hand_units) FROM retail_core.fact_inventory_daily; -- misleading

-- Better: average ending on-hand across days in month
SELECT
  d.fiscal_month,
  s.store_sk,
  p.product_sk,
  AVG(on_hand_units) AS avg_daily_on_hand
FROM retail_core.fact_inventory_daily f
JOIN retail_core.dim_date d ON f.date_sk = d.date_sk
JOIN retail_core.dim_store s ON f.store_sk = s.store_sk
JOIN retail_core.dim_product p ON f.product_sk = p.product_sk
GROUP BY 1, 2, 3;
```

**Interview Tip:** Contrast "flow" facts (sales) with "level" facts (balances, temperatures, headcount).

**Watch Out!** Some warehouses store inventory as transactions (receipts and sales) where flows are additive and levels are derived; mixing both without documentation confuses users.

---

## Along Which Dimensions Summing Is Valid (Reference)

| Fact type | Time | Store | Product | Promotion |
|-----------|------|-------|---------|-----------|
| POS `sale_amount` | additive | additive | additive | additive (watch double-count promos) |
| `unit_price` | non | non | non | non |
| Daily `on_hand_units` | semi | additive within day | additive within day | usually not applicable |
| `distinct_shoppers` | non (sum of counts) | non | non | non |

---

## Interview Examples (Concise Scripts)

| Prompt | Answer spine |
|--------|--------------|
| "Is discount percent additive?" | Non-additive; sum discounts and sales separately, then divide. |
| "Can I sum loyalty points redeemed?" | Often additive as a flow measure; confirm expiration rules. |
| "Web conversion rate by day?" | Non-additive across days; sum numerators and denominators first. |

```sql
-- Conversion rate across a week, correctly recomputed
SELECT
  SAFE_DIVIDE(SUM(checkout_completed), NULLIF(SUM(cart_started), 0)) AS conversion_rate
FROM retail_core.fact_web_funnel_daily
WHERE date_sk BETWEEN 20250101 AND 20250107;
```

---

## Quick Reference Table

| Class | Retail examples | Default BI behavior risk |
|-------|-----------------|--------------------------|
| Additive | sales amount, units sold, tax collected | Low if UOM and currency handled |
| Semi-additive | inventory snapshot, account balance | High: users sum across dates |
| Non-additive | unit price, ratio KPIs, distinct counts | High: users sum or average naively |

---

## Common Mistakes

| Mistake | Why It Hurts | Fix |
|---------|--------------|-----|
| Treating averages of averages as KPI | Under/over-weighting small stores | Aggregate from line facts or weighted formula |
| Summing inventory snapshots across weeks | Inflated "person-years of inventory" | Use averages or movement-based facts |
| Marking distinct customer count additive | Double counts people across regions | Compute distinct in BI with care or use bridge tables |
| Hiding measure class in column name | Analysts assume all measures sum | Suffix conventions `_amount`, `_ratio`, `_balance` |
| Using `SUM` on promotion discount rate | Nonsense chain totals | Store discount amount and sale amount |

---

## Key Takeaway

> Classify each retail measure by how it behaves along time, geography, and product before you expose it in a semantic layer, because the warehouse's credibility is the sum of only the measures that were allowed to be summed.

```
+------------------------------------------------------------------+
|                     QUICK MEMORY CARD                             |
+------------------------------------------------------------------+
| Additive: SUM is meaningful along the dimension.                 |
| Semi-additive: SUM across time often wrong; balances, levels.    |
| Non-additive: ratios, prices, percents; recompute carefully.     |
| Always say "additive along WHICH dimension."                     |
| Inventory snapshots: sum within a slice of time, not across it.  |
+------------------------------------------------------------------+
```
