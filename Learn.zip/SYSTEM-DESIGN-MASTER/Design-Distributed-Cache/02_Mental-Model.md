# Design Distributed Cache — Mental Model

> **Permanent Recall:** A distributed cache is a **hash table split across machines**. Three core problems: 1) **Where does key X go?** (consistent hashing), 2) **What if a node dies?** (replication), 3) **What if memory is full?** (LRU/LFU eviction). Think: a library where each branch holds a slice of books; find shelf by hashing the title; copies at neighboring branches for backup.

---

## Core Abstraction: Partitioned Hash Table

```
Single node:  hash_table[key] → value
Distributed:  node_for(key) = hash(key) mod N  →  node[key] → value
```

The jump from single machine to cluster is **partitioning** + **replication**.

---

## Library with Branches Analogy

| Library | Distributed Cache |
|---------|-------------------|
| **Central catalog** | Consistent hashing ring: which branch holds book X? |
| **Branch** | Cache node (in-memory hash table) |
| **Books** | Key-value pairs |
| **Shelf space** | Memory limit; evict least-used when full |
| **Branch closure** | Node failure; books move to neighboring branches |
| **Photocopies at nearby branch** | Replication; replica holds copy of primary's data |

> **FAANG Tip:** The analogy explains why consistent hashing matters — when a branch closes (node fails), only nearby shelves are affected, not the whole library.

---

## Three Core Problems

### 1. Key Distribution: Where does key X go?

| Approach | Problem |
|----------|---------|
| **Modulo hashing** `hash(key) % N` | When N changes (add/remove node), ~(N-1)/N keys must move → cascading failure |
| **Consistent hashing** | Only K/N keys move (K = keys on failed node); ring minimizes disruption |

```
Consistent hashing ring (simplified):
        0
    N3      N1
        N2
  hash(key) → walk clockwise → first node owns key
```

---

### 2. Node Failure: What if a node dies?

| Approach | Trade-off |
|----------|-----------|
| **No replication** | Fast, but data lost on failure |
| **Primary-replica** | Replica holds copy; promote on primary failure; async replication = eventual consistency |
| **Multi-replica** | Higher durability; quorum reads for stronger consistency |

---

### 3. Memory Full: What to evict?

| Policy | Implementation | Use Case |
|--------|----------------|---------|
| **LRU** | Hash map + doubly-linked list; O(1) get, put, evict | General cache; recent = hot |
| **LFU** | Frequency buckets + doubly-linked list per bucket | Access frequency matters more than recency |
| **TTL** | Lazy expiration on access; background scan; or timer heap | Time-based invalidation |

---

## Data Flow (Mental Model)

```
Client SET("user:123", data)
    │
    ├─► hash("user:123") → ring position
    │
    ├─► Find primary node on ring (clockwise)
    │
    ├─► Send to primary
    │       └─► Primary: hash_table["user:123"] = data
    │       └─► Primary: async replicate to replica(s)
    │
    └─► Response: OK

Client GET("user:123")
    │
    ├─► hash("user:123") → same ring position
    │
    ├─► Route to primary (or replica for read scaling)
    │
    ├─► Node: lookup O(1) → return value or null
    │
    └─► Response: value or miss
```

---

## Decomposition Summary

| Component | Responsibility |
|-----------|-----------------|
| **Client library** | Consistent hashing; route request to correct node |
| **Ring** | Map hash space to nodes; virtual nodes for balance |
| **Cache node** | In-memory hash table; eviction; TTL; data structures |
| **Replication** | Primary writes to replica(s); failover on primary death |
| **Cluster manager** | Node discovery; health checks; membership |

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| **Consistent hashing** | Minimal reshuffling on failure vs slight complexity |
| **Virtual nodes** | Better key distribution vs more ring entries |
| **Sync vs async replication** | Sync = stronger consistency, higher latency; async = lower latency, eventual |
| **LRU vs LFU** | LRU simpler, good for most cases; LFU better for frequency-skewed workloads |
