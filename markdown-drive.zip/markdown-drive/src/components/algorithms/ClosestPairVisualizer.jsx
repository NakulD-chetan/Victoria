import { useCallback, useEffect, useRef, useImperativeHandle, forwardRef } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';
import { DPR } from '../../lib/canvas/rough-helpers';

const ClosestPairCanvas = forwardRef(function ClosestPairCanvas(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    points: [],
    best: null,
    strip: [],
    phase: '',
  });

  const setState = useCallback((p) => {
    Object.assign(stateRef.current, p);
  }, []);

  useImperativeHandle(ref, () => ({ setState }), [setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let raf;
    function loop() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const W = rect.width;
      const H = 320;
      canvas.width = W * DPR;
      canvas.height = H * DPR;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const { points, best, strip, phase } = stateRef.current;
      const pad = 36;
      const xs = points.map((p) => p.x);
      const ys = points.map((p) => p.y);
      const minX = Math.min(...xs, 0);
      const maxX = Math.max(...xs, 1);
      const minY = Math.min(...ys, 0);
      const maxY = Math.max(...ys, 1);
      const sx = (x) => pad + ((x - minX) / (maxX - minX || 1)) * (W - pad * 2);
      const sy = (y) => pad + ((y - minY) / (maxY - minY || 1)) * (H - pad * 2 - 28);

      ctx.fillStyle = 'var(--dc-canvas-dots, #e7e5e4)';
      for (let gx = 16; gx < W; gx += 18) for (let gy = 16; gy < H; gy += 18) ctx.fillRect(gx, gy, 1, 1);

      if (phase) {
        ctx.fillStyle = '#78716c';
        ctx.font = '600 11px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(phase, W / 2, 16);
      }

      points.forEach((p, idx) => {
        const x = sx(p.x);
        const y = sy(p.y);
        const inStrip = strip?.includes(idx);
        ctx.beginPath();
        ctx.arc(x, y, inStrip ? 8 : 6, 0, Math.PI * 2);
        ctx.fillStyle = inStrip ? '#74c0fc' : '#a5d8ff';
        ctx.fill();
        ctx.strokeStyle = '#1c1917';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      });

      if (best && points[best.i] && points[best.j]) {
        const a = points[best.i];
        const b = points[best.j];
        ctx.beginPath();
        ctx.moveTo(sx(a.x), sy(a.y));
        ctx.lineTo(sx(b.x), sy(b.y));
        ctx.strokeStyle = '#e03131';
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      raf = requestAnimationFrame(loop);
    }
    loop();
    return () => cancelAnimationFrame(raf);
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

function dist2(a, b) {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  return dx * dx + dy * dy;
}

function bruteSteps(pts) {
  const steps = [];
  let best = { i: 0, j: 1, d2: dist2(pts[0], pts[1]) };
  for (let i = 0; i < pts.length; i++) {
    for (let j = i + 1; j < pts.length; j++) {
      const d2 = dist2(pts[i], pts[j]);
      steps.push({ type: 'check-pair', i, j, d2, best: { ...best }, points: pts });
      if (d2 < best.d2) best = { i, j, d2 };
    }
  }
  steps.push({ type: 'done', best, points: pts });
  return steps;
}

function generateSteps(pts) {
  const sorted = pts.map((p, idx) => ({ ...p, idx })).sort((a, b) => a.x - b.x);
  const steps = [];
  const n = sorted.length;
  if (n <= 3) return bruteSteps(pts);

  const mid = Math.floor(n / 2);
  const midx = sorted[mid].x;
  steps.push({ type: 'divide', midx, points: pts, strip: [], best: null, phase: 'Divide: split by x-median' });

  const left = sorted.slice(0, mid);
  const right = sorted.slice(mid);
  steps.push({ type: 'conquer', side: 'left', points: pts, strip: [], best: null, phase: 'Solve left half' });
  steps.push({ type: 'conquer', side: 'right', points: pts, strip: [], best: null, phase: 'Solve right half' });

  let best = { i: left[0].idx, j: left[1].idx, d2: dist2(left[0], left[1]) };
  for (let i = 0; i < left.length; i++) {
    for (let j = i + 1; j < left.length; j++) {
      const d2 = dist2(left[i], left[j]);
      if (d2 < best.d2) best = { i: left[i].idx, j: left[j].idx, d2 };
    }
  }
  for (let i = 0; i < right.length; i++) {
    for (let j = i + 1; j < right.length; j++) {
      const d2 = dist2(right[i], right[j]);
      if (d2 < best.d2) best = { i: right[i].idx, j: right[j].idx, d2 };
    }
  }
  const d = Math.sqrt(best.d2);
  const stripIdx = [];
  sorted.forEach((p) => {
    if (Math.abs(p.x - midx) <= d) stripIdx.push(p.idx);
  });
  steps.push({
    type: 'strip',
    midx,
    d,
    strip: stripIdx,
    best,
    points: pts,
    phase: 'Check strip around dividing line',
  });
  stripIdx.forEach((i) => {
    stripIdx.forEach((j) => {
      if (j <= i) return;
      const d2 = dist2(pts[i], pts[j]);
      if (d2 < best.d2) {
        best = { i, j, d2 };
        steps.push({ type: 'strip-pair', i, j, best: { ...best }, strip: stripIdx, points: pts, phase: 'Update closest in strip' });
      }
    });
  });
  steps.push({ type: 'done', best, points: pts, strip: stripIdx, phase: '✓ Closest pair' });
  return steps;
}

function randomPoints(m = 10) {
  return Array.from({ length: m }, () => ({
    x: Math.round(Math.random() * 100) / 20,
    y: Math.round(Math.random() * 100) / 20,
  }));
}

export default function ClosestPairVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const pts = randomPoints(10);
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(generateSteps(pts));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `${pts.length} points in the plane` });
    canvasRef.current?.setState({ points: pts, best: null, strip: [], phase: 'Start' });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.type === 'check-pair' || step.type === 'strip-pair') store.incComparisons();
    if (step.type === 'done') {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Closest pair indices ${step.best.i}, ${step.best.j}` });
    } else {
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.phase || step.type });
    }
    canvasRef.current?.setState({
      points: step.points,
      best: step.best || null,
      strip: step.strip || [],
      phase: step.phase || '',
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={ClosestPairCanvas} onInit={onInit} onStep={onStep} />;
}
