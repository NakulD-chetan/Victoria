/**
 * localStorage persistence for the new canvas.
 *
 * Shape of the persisted blob (key: "new-canvas:v2"):
 *   {
 *     activeId: string | null,
 *     scenes:   { [sceneId]: { id, name, folderId, elements, viewport, updatedAt } }
 *     folders:  { [folderId]: { id, name, parentId, updatedAt } }
 *     openTabs: string[]     // sceneIds currently open as tabs
 *   }
 *
 * Why this file exists separately from the store:
 *   - The store shouldn't know about storage backends.
 *   - A future swap to Supabase / indexedDB changes only this file.
 *   - Debounced writes keep us off the main thread during freehand commits.
 */

import {
  CANVAS_DOCUMENT_VERSION,
  defaultViewport,
  normalizeElementsV2,
  uid,
} from './types.js';
import {
  createEmptyTeachingDocumentV3,
  normalizeTeachingDocumentV3,
} from '../canvas-v3/document.js';

export const STORAGE_KEY = 'new-canvas:v2';
export const LEGACY_STORAGE_KEY = 'new-canvas:v1';
export const LEGACY_BACKUP_KEY = 'new-canvas:v1:backup';
const WRITE_DEBOUNCE_MS = 400;

function safeParse(text) {
  if (!text) return null;
  try { return JSON.parse(text); } catch { return null; }
}

function normalizeLessonDeck(rawDeck) {
  const pages = Array.isArray(rawDeck?.pages) ? rawDeck.pages : [];
  const normalizedPages = pages
    .filter((page) => page && typeof page === 'object')
    .map((page, index) => ({
      id: page.id || uid('lesson-page'),
      title: page.title || `Lesson ${index + 1}`,
      topic: page.topic || 'general',
      focus: page.focus || 'overview',
      order: Number.isFinite(page.order) ? page.order : index,
      bounds: page.bounds && typeof page.bounds === 'object'
        ? {
            x: Number(page.bounds.x) || 0,
            y: Number(page.bounds.y) || 0,
            w: Number(page.bounds.w) || 0,
            h: Number(page.bounds.h) || 0,
          }
        : { x: 0, y: 0, w: 0, h: 0 },
      summary: page.summary || '',
      createdAt: Number(page.createdAt) || Date.now(),
      updatedAt: Number(page.updatedAt) || Date.now(),
    }))
    .sort((a, b) => a.order - b.order);

  return {
    pages: normalizedPages,
    currentPageId: rawDeck?.currentPageId && normalizedPages.some((page) => page.id === rawDeck.currentPageId)
      ? rawDeck.currentPageId
      : normalizedPages[0]?.id || null,
  };
}

function normalizePinnedTarget(rawTarget) {
  if (!rawTarget || typeof rawTarget !== 'object' || !rawTarget.elementId) return null;
  return {
    sceneId: rawTarget.sceneId || null,
    elementId: rawTarget.elementId,
    widgetType: rawTarget.widgetType || null,
    title: rawTarget.title || '',
    role: rawTarget.role || 'general',
    lessonPageId: rawTarget.lessonPageId || null,
    pinnedAt: Number(rawTarget.pinnedAt) || Date.now(),
  };
}

export function readAll() {
  if (typeof localStorage === 'undefined') return emptyStorage();
  const current = safeParse(localStorage.getItem(STORAGE_KEY));
  if (current && typeof current === 'object' && current.scenes) {
    return restoreDocument(current);
  }

  const legacyText = localStorage.getItem(LEGACY_STORAGE_KEY);
  const legacy = safeParse(legacyText);
  if (!legacy || typeof legacy !== 'object' || !legacy.scenes) return emptyStorage();

  try {
    if (legacyText && !localStorage.getItem(LEGACY_BACKUP_KEY)) {
      localStorage.setItem(LEGACY_BACKUP_KEY, legacyText);
    }
    const migrated = migrateLegacyDocument(legacy);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
    return restoreDocument(migrated);
  } catch (error) {
    console.error('[new-canvas] V2 migration failed; using the untouched V1 document:', error);
    return restoreDocument(legacy);
  }
}

export function restoreDocument(raw) {
  if (!raw || typeof raw !== 'object' || !raw.scenes) return emptyStorage();

  const scenes = {};
  for (const [id, s] of Object.entries(raw.scenes)) {
    scenes[id] = {
      folderId: null,
      ...s,
      id,
      documentVersion: CANVAS_DOCUMENT_VERSION,
      elements: normalizeElementsV2(s?.elements),
      viewport: { ...defaultViewport(), ...(s?.viewport || {}) },
      agentHistory: Array.isArray(s?.agentHistory) ? s.agentHistory : [],
      lessonDeck: normalizeLessonDeck(s?.lessonDeck),
      pinnedTarget: normalizePinnedTarget(s?.pinnedTarget),
      v3Document: normalizeTeachingDocumentV3(s?.v3Document),
      v3Selection: Array.isArray(s?.v3Selection) ? s.v3Selection : [],
    };
  }
  return {
    documentVersion: CANVAS_DOCUMENT_VERSION,
    activeId: raw.activeId ?? Object.keys(scenes)[0] ?? null,
    scenes,
    folders: raw.folders && typeof raw.folders === 'object' ? raw.folders : {},
    openTabs: Array.isArray(raw.openTabs) && raw.openTabs.length
      ? raw.openTabs.filter((t) => !!scenes[t])
      : (raw.activeId && scenes[raw.activeId] ? [raw.activeId] : []),
  };
}

export function migrateLegacyDocument(raw) {
  const restored = restoreDocument(raw);
  return {
    ...restored,
    migratedAt: Date.now(),
    migratedFrom: 1,
  };
}

export function emptyStorage() {
  const first = createBlankScene('Canvas 1');
  return {
    documentVersion: CANVAS_DOCUMENT_VERSION,
    activeId: first.id,
    scenes: { [first.id]: first },
    folders: {},
    openTabs: [first.id],
  };
}

export function createBlankScene(name, folderId = null) {
  return {
    id: uid('scene'),
    name: name || 'Untitled',
    folderId,
    documentVersion: CANVAS_DOCUMENT_VERSION,
    elements: [],
    viewport: defaultViewport(),
    agentHistory: [],
    lessonDeck: {
      pages: [],
      currentPageId: null,
    },
    pinnedTarget: null,
    v3Document: createEmptyTeachingDocumentV3(),
    v3Selection: [],
    updatedAt: Date.now(),
  };
}

export function createBlankFolder(name, parentId = null) {
  return {
    id: uid('folder'),
    name: name || 'Folder',
    parentId,
    updatedAt: Date.now(),
  };
}

let writeTimer = null;
let pendingBlob = null;

export function scheduleWrite(blob) {
  if (typeof localStorage === 'undefined') return;
  pendingBlob = blob;
  if (writeTimer) return;
  writeTimer = setTimeout(() => {
    writeTimer = null;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(pendingBlob));
    } catch (err) {
      /* quota exceeded is the realistic failure mode — surface in console,
       * do not crash the app */
      console.error('[new-canvas] persist failed:', err);
    }
    pendingBlob = null;
  }, WRITE_DEBOUNCE_MS);
}

/** Flush pending writes immediately (call on unload / tab hide). */
export function flushWrite() {
  if (!writeTimer || !pendingBlob) return;
  clearTimeout(writeTimer);
  writeTimer = null;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(pendingBlob));
  } catch (err) {
    console.error('[new-canvas] flush failed:', err);
  }
  pendingBlob = null;
}
