# Greedy — Tricks and Recognition

> **Permanent Recall:** "Sort + process" = greedy. Intervals → greedy. Jump/reach → greedy. "Minimum number of..." → often greedy. Use the decision table when stuck.

---

## The "Sort + Process" Pattern

**Most common greedy pattern at FAANG.**

```
1. Sort the input (by end, start, value/weight, deadline)
2. Single pass — make decision at each step
3. No backtracking
```

| Sort By | Problem Type | Why |
|---------|--------------|-----|
| End time | Max non-overlapping intervals | Earliest end = most room |
| Start time | Merge intervals, min rooms | Chronological |
| Value/weight | Fractional knapsack | Best density first |
| Deadline | Task scheduling | Meet deadlines |
| Start + end | Complex intervals | Break ties |

---

## "Interval" → Greedy Candidate

**Strong signal.** Almost all interval scheduling is greedy.

| Problem | Greedy Approach |
|---------|-----------------|
| Max non-overlapping | Sort by end, pick if no overlap |
| Merge overlapping | Sort by start, merge adjacent |
| Min meeting rooms | Sort events, count concurrent |
| Insert interval | Find position, merge if needed |
| Remove min to make non-overlapping | Sort by end, same as max |

```
Interval + "maximum" / "minimum" / "non-overlapping"
    → Think GREEDY first
```

---

## "Jump" / "Reach" → Greedy

**Linear scan with max_reach.**

| Problem | Key Idea |
|---------|----------|
| Can you reach end? | max_reach = max(max_reach, i + nums[i]) |
| Min jumps to end? | Track cur_end, jump when i == cur_end |
| Min refueling stops? | Heap of gas, take largest when needed |

```
"Can you get from A to B?"
"How many steps to reach?"
    → Track reachability, extend greedily
```

---

## "Minimum Number of..." → Often Greedy

| Phrase | Example |
|--------|---------|
| Min arrows to burst balloons | Sort by end, shoot at end |
| Min rooms | Sort events, count overlaps |
| Min refueling stops | Greedy heap |
| Min deletions to make valid | Balance count |
| Min partitions | Greedy scan |

**Caveat:** "Minimum" with complex constraints might be DP (e.g., min coins).

---

## Greedy vs DP Decision Table

| Signal | Greedy | DP |
|--------|--------|-----|
| Intervals, scheduling | ✓ | |
| Jump, reachability | ✓ | |
| Fractional (take parts) | ✓ | |
| 0/1 (take or leave) | | ✓ |
| Overlapping subproblems | | ✓ |
| "Try all combinations" | | ✓ |
| Local = global (provable) | ✓ | |
| Need to explore choices | | ✓ |

---

## Recognition Flowchart

```mermaid
flowchart TD
    A[Optimization problem]
    A --> B{Intervals?}
    B -->|Yes| C[Sort by end/start, greedy]
    B -->|No| D{Jump/Reach?}
    D -->|Yes| E[max_reach, linear scan]
    D -->|No| F{Knapsack?}
    F -->|Fractional| G[Sort by value/weight]
    F -->|0/1| H[DP]
    F -->|No| I{Min number of?}
    I -->|Yes| J[Often greedy arrows rooms]
    I -->|No| K[Consider DP, try exchange argument]
    style B fill:#ffd43b,color:#000
    style D fill:#ffd43b,color:#000
    style F fill:#ffd43b,color:#000
    style I fill:#ffd43b,color:#000
    style C fill:#51cf66,color:#fff
    style E fill:#51cf66,color:#fff
    style G fill:#51cf66,color:#fff
    style J fill:#51cf66,color:#fff
    style H fill:#e03131,color:#fff
    style K fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
                    ┌────────────────────┐
                    │  Optimization      │
                    │  problem           │
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  Intervals?        │──Yes──► Sort by end/start, greedy
                    └─────────┬──────────┘
                              │ No
                    ┌─────────▼──────────┐
                    │  Jump/Reach?       │──Yes──► max_reach, linear scan
                    └─────────┬──────────┘
                              │ No
                    ┌─────────▼──────────┐
                    │  Knapsack?         │
                    │  Fractional?       │──Yes──► Sort by value/weight
                    │  0/1?              │──Yes──► DP
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  "Min number of"? │──Yes──► Often greedy (arrows, rooms)
                    └─────────┬──────────┘
                              │
                    ┌─────────▼──────────┐
                    │  Otherwise         │──► Consider DP, try exchange argument
                    └───────────────────┘
```

</details>

---

## Quick Recognition Cheat Sheet

| Keywords | → Approach |
|----------|------------|
| non-overlapping, meetings, activities | Interval, sort by end |
| merge, overlapping | Sort by start, merge |
| rooms, concurrent | Sort events, count |
| jump, reach, steps | max_reach |
| gas, refuel | Running sum or heap |
| value, weight, capacity (fractional) | Sort by value/weight |
| tasks, deadline | Sort by deadline |
| minimum arrows, minimum removals | Often greedy |

---

## The "Exchange" Sanity Check

**Before coding:** Can I argue that my greedy choice is safe?

- "If I pick X, can any optimal solution be modified to include X?" → Yes → Greedy OK
- "Might I need to skip X for something better later?" → Yes → Consider DP

---

## FINAL MEMORY COMPRESSION BLOCK

```
SORT+PROCESS: #1 greedy pattern
INTERVALS: sort by end (max) or start (merge, rooms)
JUMP: max_reach, linear scan
MIN NUMBER: arrows, rooms, refuels → often greedy
GREEDY vs DP: intervals/jump/fractional→Greedy; 0/1/explore→DP
EXCHANGE CHECK: "Can optimal include my choice?" before coding
```
