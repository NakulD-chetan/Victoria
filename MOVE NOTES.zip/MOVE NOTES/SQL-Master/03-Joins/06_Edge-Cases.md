# Joins — Edge Cases

---

## LEFT JOIN … WHERE right.col = X

Can **remove** non-matching right rows if not careful — sometimes move predicate to `ON`:

```sql
LEFT JOIN t2 ON t1.id = t2.id AND t2.flag = 1
```

vs filtering in `WHERE` — know the difference.

---

## Duplicate keys in dimension table

Join can multiply rows — **dedupe** dimension or use aggregation.

---

## Multiple paths to same table

Join same table twice with different aliases (e.g., airport from/to).

---

*Next: [[07_Tricks-and-Recognition]]*
