# Stages, Tasks & Shuffle Boundaries — Problem List

> **18 prediction tasks.** Goal: for any code snippet, predict (number of stages, task count of each stage). Then verify in Spark UI Stages tab.

---

## 10 MUST-DO Tasks

| # | Code Snippet                                                                                          | (Stages, Tasks)                            | Concept                                  |
|---|-------------------------------------------------------------------------------------------------------|--------------------------------------------|------------------------------------------|
| 1 | `df.count()` (single parquet file, 16 partitions)                                                     | (2, [16, 1])                               | Source + final agg                       |
| 2 | `df.filter(col("x")>0).count()` (no shuffle)                                                          | (2, [16, 1])                               | Filter is narrow                         |
| 3 | `df.repartition(8).count()`                                                                           | (3, [16, 8, 1])                            | Repartition adds shuffle                 |
| 4 | `df.groupBy("k").count().count()` (shuffle.partitions=8)                                              | (3, [16, 8, 1])                            | Partial + final agg                      |
| 5 | `df.join(df2, "k").count()` (SortMergeJoin, shuffle.partitions=8)                                     | (3, [16, 16, 1] + 8 join stage)            | Two-side shuffle                         |
| 6 | `df.coalesce(4).count()`                                                                              | (2, [4, 1])                                | Coalesce no-shuffle                      |
| 7 | `df.orderBy("v").count()` (shuffle.partitions=8)                                                      | (3, [16, 8, 1])                            | Sort uses range partitioner              |
| 8 | `df.distinct().count()` (shuffle.partitions=8)                                                         | (3, [16, 8, 1])                            | distinct → groupBy hash                  |
| 9 | `df.write.parquet("out/")` (no shuffle)                                                                | (1, [16])                                  | Source-only write                        |
|10 | `df.repartition(2,"k").groupBy("k").count().count()` (shuffle.partitions=8)                            | (4, [16, 2, 8, 1])                         | Two shuffles                             |

---

## Complete 18-Task Progression

### Easy (1–6) — Single Operation

| # | Code                                                       | Stages | Task Pattern               | Why                                            |
|---|------------------------------------------------------------|--------|----------------------------|------------------------------------------------|
| 1 | `df.count()`                                               | 2      | [N_input, 1]                | Map + final reduce                             |
| 2 | `df.filter(...).count()`                                   | 2      | [N_input, 1]                | Filter pipelined                               |
| 3 | `df.select("a","b").count()`                               | 2      | [N_input, 1]                | Project pipelined                              |
| 4 | `df.collect()`                                             | 1      | [N_input]                   | No final agg; all parts to driver              |
| 5 | `df.write.parquet(p)`                                      | 1      | [N_input]                   | Plain write, no shuffle                        |
| 6 | `df.coalesce(2).count()`                                   | 2      | [2, 1]                      | Coalesce changes input partition count         |

### Medium (7–13) — Single Shuffle

| # | Code                                                       | Stages | Task Pattern                 | Why                                              |
|---|------------------------------------------------------------|--------|------------------------------|--------------------------------------------------|
| 7 | `df.repartition(N).count()`                                | 3      | [N_in, N, 1]                 | Repartition + final agg                          |
| 8 | `df.groupBy("k").sum("v").count()`                         | 3      | [N_in, P, 1]                 | P = shuffle.partitions                           |
| 9 | `df.join(broadcast(small)).count()`                        | 2      | [N_in, 1]                    | Broadcast join doesn't add a shuffle             |
|10 | `df.join(big2, "k").count()` (SortMergeJoin)               | 4      | [N1, N2, P, 1]               | Both sides shuffled                              |
|11 | `df.orderBy("v").count()`                                  | 3      | [N_in, P, 1]                 | Range partitioner shuffle                        |
|12 | `df.distinct().count()`                                    | 3      | [N_in, P, 1]                 | distinct → groupBy hash                          |
|13 | Window: `df.withColumn("rn", row_number().over(w)).count()`| 3      | [N_in, P, 1]                 | Window forces partition + sort                   |

### Hard (14–18) — Multi-Shuffle / AQE

| # | Code                                                                                  | Stages | Task Pattern                  | Notes                                                    |
|---|---------------------------------------------------------------------------------------|--------|-------------------------------|----------------------------------------------------------|
|14 | `df.repartition(2,"k").groupBy("k").count().count()`                                  | 4      | [N_in, 2, P, 1]               | Two shuffle boundaries                                   |
|15 | `df.groupBy("k").count().filter("count>10").count()`                                  | 3      | [N_in, P, 1]                  | Filter post-agg pipelined into next; just 1 shuffle      |
|16 | `df1.join(df2, "k").join(df3, "k").count()` (all SMJ)                                  | 5+     | [N1, N2, P, P_join1+N3, 1]    | Two SMJs = at least 2 shuffles                           |
|17 | `df.groupBy("k").count()` with AQE on (small reduce)                                  | 3, AQE coalesced | [N_in, < P, 1]      | AQE merges small post-shuffle partitions                 |
|18 | `df.repartition(8).repartition(4).count()` (back-to-back)                             | 4      | [N_in, 8, 4, 1]               | Two shuffles, both kept                                  |

---

## Strategy Notes

### Task 1 — The Simplest Case

```
df.count() with 16-partition input parquet
  Stage 0: 16 tasks   read + partial count
  Stage 1:  1 task    final count
Total: 2 stages, 17 tasks.
```

### Task 4 — `groupBy().count()`

```
df.groupBy("k").count().count()
  Stage 0: N_in tasks   scan + partial groupBy
  Stage 1: P tasks      shuffle read + groupBy final
  Stage 2: 1 task       outer count() final reduce
```

> First `count()` here is a column producer (group counts), second `count()` is the action that triggers the job.

### Task 5 — Two-Sided Join

```
df1.join(df2, "k").count() with SortMergeJoin
  Stage 0: N1   scan df1 + shuffle write
  Stage 1: N2   scan df2 + shuffle write    (in parallel with Stage 0)
  Stage 2: P    shuffle read both sides + sort + merge join + partial count
  Stage 3: 1    final count
```

> Stage 0 and Stage 1 may run in parallel because they have no dependency on each other.

### Task 9 — Broadcast Join (No Shuffle)

```
df.join(broadcast(small_df), "k").count()
  Stage 0: N_in tasks   scan big + broadcast lookup + partial count
  Stage 1: 1 task       final count
```

> Look for `BroadcastHashJoin` in the SQL tab — that's the confirmation.

### Task 17 — AQE Coalesce in Action

```
Without AQE:
  Stage post-shuffle has 200 tasks (default)
With AQE on:
  Stage post-shuffle may show 8 tasks because AQE merged tiny partitions.
Verify in SQL tab: look for "AQEShuffleRead" or "CoalesceShufflePartitions".
```

---

## Predicting Stages — A Repeatable Recipe

```
1. Run df.explain("formatted")  (or just df.explain())
2. Count "Exchange" operators in the physical plan.
3. stage_count = #Exchange + (1 if action is count/sum etc. else 0) + 1 (for the leaf scan)

   Equivalently:
       Final 1-task reduce         -> +1 stage if action is global agg
       Each Exchange               -> +1 stage boundary
       Source scan                 -> stage 0

4. For each stage, output partition count =
       - source: file split count or defaultParallelism
       - after Exchange(N): N
       - after coalesce(N) (no exchange): N
       - after shuffle without explicit N: spark.sql.shuffle.partitions
       - final reduce: 1
```

---

## Stage Counting Cheat Table

```
Code Pattern                                  Stages  Notes
---------------------------------------       ------  ---------------------------
read + filter + count                          2      narrow, then final reduce
read + groupBy + count                         3      shuffle in middle
read + join (SMJ) + count                      4      shuffles for both sides
read + broadcast join + count                  2      no shuffle
read + orderBy + count                         3      shuffle for range partitioner
read + repartition(N) + count                  3      shuffle then final reduce
read + window + count                          3      window forces shuffle
read + distinct + count                        3      distinct = groupBy
read + 2 joins + count                         5      two shuffles + agg
read + write                                   1      no shuffle, no final agg
```

---

## Common Mistakes

| Mistake                                                | Why                                               | Fix                                                         |
|--------------------------------------------------------|---------------------------------------------------|-------------------------------------------------------------|
| Counting `select + filter + project` as 3 stages       | Pipelined together                                | Same stage; count `Exchange` operators only                 |
| Forgetting the +1 for global reduce                    | Final agg is always 1 task                        | `count/sum/...` adds a 1-task stage at the end              |
| Missing 2 shuffles in chained joins                    | Each join is its own shuffle                      | Two SMJs = ≥ 4 stages                                       |
| Expecting AQE to keep N=200 tasks                      | AQE coalesces small partitions                    | Check SQL tab for "AQEShuffleRead"                          |
| Using broadcast join then expecting Stage 1 of join    | Broadcast join doesn't shuffle the small side     | Only the large side stage exists                            |

---

## Cross-Reference

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| Why some stages show "skipped"                     | 05      |
| Reading the physical plan in SQL tab               | 06      |
| Diagnosing slow stages (skew/spill/GC)             | 08      |
| Why a job has 1 vs many runs                       | 02, 03  |

---

## Study Plan

### Day 1 — Easy
- Tasks 1–6. For each, run `df.explain()` first, then predict (stages, tasks), then run + verify.

### Day 2 — Single Shuffle
- Tasks 7–13. Toggle `spark.sql.shuffle.partitions` between 4, 8, 200 and observe the post-shuffle task count.

### Day 3 — Multi-Shuffle
- Tasks 14–18. Practice counting Exchange operators in `explain("formatted")`.

### Day 4 — Joins
- Build small + big df pair. Run with broadcast hint vs without; compare stages.

---

## Final Revision Box

```
STAGE = pipelined chunk between shuffles
TASK  = one partition's worth of work in a stage
TASK COUNT = output partitions of that stage

Source stage     ->  defaultParallelism or file splits
Post-shuffle     ->  spark.sql.shuffle.partitions
After repart(N)  ->  N
After coalesce(N)->  N (no shuffle stage added)
Final reduce     ->  1 task

NARROW (no boundary): select, filter, withColumn, map, union, narrow limit
WIDE (boundary):      groupBy, join (non-broadcast), orderBy, distinct, window, repartition

PREDICTION RECIPE:
  stage_count = #Exchange + 1 (source) + 1 (if global reduce)

RULE: "Run explain. Count Exchanges. That's your stage count."
```
