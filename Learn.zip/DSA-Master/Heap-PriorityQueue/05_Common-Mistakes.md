# Heap — Common Mistakes

> **Pitfalls that cost FAANG interviews. Python heapq vs C++ priority_queue. Wrong heap type. Size bugs.**

---

## Mistake 1: Python heapq is Min-Heap Only

**Error:** Using heapq as max-heap without negation.

```python
# WRONG: heapq.heappop gives MIN, not max
heapq.heappush(heap, 5)
heapq.heappush(heap, 10)
heapq.heappop(heap)  # Returns 5, not 10!
```

**Fix:** Negate for max-heap.

```python
# CORRECT: Store (-val, val) or just -val
heapq.heappush(heap, -5)
heapq.heappush(heap, -10)
max_val = -heapq.heappop(heap)  # Returns 10
```

**Or use tuple:** `(-freq, val)` for max-heap by frequency.

---

## Mistake 2: C++ priority_queue is Max-Heap by Default

**Error:** Assuming default is min-heap for "K largest."

```cpp
// WRONG for K largest: default is max-heap
priority_queue<int> pq;  // Largest at top!
pq.push(3); pq.push(1); pq.push(5);
pq.top();  // 5 — we get max, not min
```

**Fix:** Use `greater<>` for min-heap.

```cpp
// CORRECT for Top-K largest (min-heap of size K)
priority_queue<int, vector<int>, greater<int>> min_heap;
```

---

## Mistake 3: Not Maintaining Heap Size K

**Error:** Pushing everything, then extracting K. Wastes space and time.

```python
# WRONG: O(n) space, O(n log n) time
heap = []
for x in nums:
    heapq.heappush(heap, x)  # Heap grows to size n!
return heapq.nlargest(k, heap)  # Extra work
```

**Fix:** Cap heap at K. Evict when full and new element is better.

```python
# CORRECT: O(K) space, O(n log K) time
heap = []
for x in nums:
    if len(heap) < k:
        heapq.heappush(heap, x)
    elif x > heap[0]:
        heapq.heapreplace(heap, x)
return heap
```

---

## Mistake 4: Wrong Heap Type for Top-K

| Goal | Wrong | Correct |
|------|-------|---------|
| K largest | Max-heap (keep max at top) | Min-heap size K (evict min when larger arrives) |
| K smallest | Min-heap (keep min at top) | Max-heap size K (evict max when smaller arrives) |

**Why:** For K largest, we want to *evict the smallest* of our K candidates. The smallest of K is at the root of a min-heap. So we use min-heap.

---

## Mistake 5: Custom Comparator Errors

**Python:** heapq compares tuples by first element, then second.

```python
# For (freq, num): min-heap by freq
heapq.heappush(heap, (freq, num))  # Correct

# WRONG: (num, freq) if we want min by freq — heap would sort by num!
heapq.heappush(heap, (num, freq))  # Wrong order
```

**C++:** Comparator semantics are inverted for priority_queue.

```cpp
// Max-heap: a < b means a has LOWER priority (b comes first)
priority_queue<int> pq;  // default: less<int> → max-heap

// Min-heap: a > b means a has LOWER priority
priority_queue<int, vector<int>, greater<int>> pq;

// Custom max-heap by freq:
auto cmp = [](pair<int,int>& a, pair<int,int>& b) {
    return a.second < b.second;  // smaller freq = lower priority
};
```

---

## Mistake 6: Heap vs Sorted Array Confusion

**Error:** Treating heap as sorted. Heap only guarantees root is min/max.

```python
# WRONG: heap is NOT sorted
heap = [1, 3, 2, 5, 4]  # After heappush in some order
heapq.heapify(heap)
# heap = [1, 3, 2, 5, 4] — only heap[0] is min!
# heap[1], heap[2] are not necessarily next smallest
```

**Fix:** To get sorted order, repeatedly pop: `sorted_result = [heappop(heap) for _ in range(len(heap))]`

---

## Mistake 7: Forgetting heapreplace vs push+pop

**Less efficient:**
```python
heapq.heappop(heap)
heapq.heappush(heap, x)
```

**More efficient:** `heapq.heapreplace(heap, x)` — pop and push in one step, avoids extra comparison.

---

## Mistake 8: Two-Heap Median — Wrong Balance

**Error:** Not maintaining "all left ≤ all right."

```python
# WRONG: Just pushing to one heap
heapq.heappush(lo, -num)  # What if -num > hi[0]?
```

**Fix:** After adding to left, ensure max(left) ≤ min(right). Swap tops if needed, then rebalance sizes.

---

## Mistake 9: K Closest — Wrong Heap Type

**Goal:** K *closest* = K *smallest* distances.

**Wrong:** Min-heap of size K by distance — we'd keep K elements but the root is the *closest* of our K, so we'd evict when a *farther* point arrives. That's backwards.

**Correct:** Max-heap of size K by distance. Root = farthest of our K. When a *closer* point arrives, evict the farthest.

---

## Mistake 10: Empty Heap Access

```python
# WRONG: No check
x = heapq.heappop(heap)  # IndexError if empty
```

```cpp
// WRONG
int x = pq.top();  // Undefined if empty
pq.pop();
```

**Fix:** Always check `if heap` / `!pq.empty()` before pop/top.

---

## Quick Reference: Heap Type by Problem

| Problem | Heap Type | Size |
|---------|-----------|------|
| K largest | Min-heap | K |
| K smallest | Max-heap | K |
| K closest (smallest dist) | Max-heap by dist | K |
| K farthest (largest dist) | Min-heap by dist | K |
| Median stream | Max (left) + Min (right) | — |
| Merge K sorted | Min-heap | K |
| Top K frequent | Min-heap by freq | K |

---

## FINAL MEMORY COMPRESSION BLOCK

```
PYTHON:        heapq = min only; max = negate or (-x, x)
CPP:           priority_queue = max default; min = greater<int>
SIZE K:        Always evict when full and new is better
TOP-K LARGEST: Min-heap (evict min)
TOP-K SMALLEST: Max-heap (evict max)
K CLOSEST:     Max-heap by distance (evict farthest)
HEAP ≠ SORTED: Only root guaranteed; pop for order
EMPTY:         Check before pop/top
HEAPREPLACE:   Use instead of pop+push for efficiency
```
