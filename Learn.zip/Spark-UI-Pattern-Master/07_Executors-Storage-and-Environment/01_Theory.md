# Executors, Storage & Environment Tabs

Yeh teen tabs aapko **resource health** ka picture dete hain. Jobs/Stages tabs batate hain *kya hua*; yeh tabs batate hain *kis machine pe, kitne resources ke saath, kis config ke saath* hua.

**DSA Analogy**: htop / Activity Monitor + config dashboard. Workers ki memory, GC, dead/alive status, plus the rulebook (configs) used for the run.

---

## Core Idea (2 Lines)

**Executors** tab tumhari runtime resource health hai. **Storage** tab cache health hai. **Environment** tab tumhari config sanity check hai. Inhi 3 tabs se OOM, eviction, aur "config-not-applied" bugs solve hote hain.

---

## Tab A — Executors

### What You See

```
Executors Tab:
+--------+---------+----------+----------+--------+--------+--------+--------+
| ID     | Status  | RDD Mem  | Storage  | Disk   | Total  | Failed | GC     |
|        |         | Used/Max | Mem Used | Used   | Tasks  | Tasks  | Time   |
+--------+---------+----------+----------+--------+--------+--------+--------+
| driver | Alive   |   0/2GB  |   200MB  |   0    |   -    |   -    |  2 s   |
|   0    | Alive   | 1.8/4GB  |   240MB  | 500MB  |  100   |   0    | 45 s   |
|   1    | Alive   | 3.9/4GB  |   240MB  | 2.1GB  |  100   |   3    | 120 s  |  <- HOT
|   2    | Alive   | 1.5/4GB  |   240MB  | 200MB  |  100   |   0    | 30 s   |
|   3    | Dead    |   -      |    -     |   -    |   80   |   1    |  -     |  <- LOST
+--------+---------+----------+----------+--------+--------+--------+--------+
```

### Per-Column Meaning

| Column                     | Meaning                                                              |
|----------------------------|----------------------------------------------------------------------|
| ID                         | `driver` or executor index                                           |
| Status                     | `Alive` / `Dead` (lost = OOM, network failure, etc.)                |
| RDD Mem Used / Max         | Memory used by cached RDDs (storage memory) / max heap available     |
| Storage Mem Used           | Total cached size on this executor                                   |
| Disk Used                  | Spilled bytes during shuffle / cache spill                           |
| Total Tasks                | Tasks ever run on this executor                                       |
| Failed Tasks               | Tasks that failed (retried elsewhere)                                |
| GC Time                    | Cumulative time in JVM garbage collection                             |
| Active Tasks               | Currently running                                                     |
| Cores                      | Slots available                                                       |

### 3 Critical Ratios

```
GC ratio    = GC_Time / Total_Task_Time
              < 5%   healthy
              5-10%  warning
              > 10%  unhealthy (cache pressure / heap pressure)

Spill ratio = Disk_Used / Shuffle_Read
              0      healthy
              > 0    execution memory tight

Mem usage   = (RDD_Used + Storage_Used) / Max_Mem
              < 70%  healthy
              70-90% warning
              > 90%  OOM imminent
```

### How to Tell Which Executor Is the Problem

```
Symptom in UI                                Likely Diagnosis
-----------------------------------------    -----------------------------
RDD Used >> others                            Skewed cache distribution
GC Time >> others                             Memory pressure on that node
Failed Tasks > 0                              OOM or transient failures
Active Tasks >> others                         Skew (one big partition stuck)
Status = Dead                                  Lost executor (look at logs)
Disk Used >> others                            That node is doing all the spill
Cores Used 0 while others busy                 Idle / not assigned tasks
```

### Driver vs Worker Distinction

```
ID = "driver"     -> the JVM where SparkContext lives
                     - schedules tasks
                     - holds broadcast variables
                     - runs collect() output
                     - never runs tasks itself

ID = 0, 1, 2, ... -> executor JVMs that actually run tasks
```

> If `driver` GC time is high, you're collecting too much to driver (collect / show / toPandas).

### Tasks per Executor — Why Some Have More

In `local[*]` mode, only 1 executor exists. In a real cluster:

| Setting                                   | Effect                                                |
|-------------------------------------------|--------------------------------------------------------|
| `spark.executor.cores`                    | Tasks per executor in parallel                        |
| `spark.executor.instances`                | Number of executors                                    |
| `spark.dynamicAllocation.enabled`         | Spark scales executors up/down based on load          |
| `spark.executor.memory`                   | Heap per executor                                      |
| `spark.executor.memoryOverhead`           | Off-heap (network buffers, metadata)                  |

---

## Tab B — Storage

### What You See

```
Storage Tab:
+----------+----------------------+-----------------+-------+--------+----------+
| RDD Name | Storage Level         | Cached Partitions | Size  | OnDisk | Fraction |
+----------+----------------------+-----------------+-------+--------+----------+
| df_filt  | MEMORY_AND_DISK_DESER |     6 / 6        | 240MB |   0    |  100%    |
| lookup   | MEMORY_ONLY           |    10 / 10       |  50MB |   0    |  100%    |
| big_df   | MEMORY_AND_DISK       |    18 / 24       | 4.2GB | 1.1GB  |   75%    |  <- partial
+----------+----------------------+-----------------+-------+--------+----------+
```

### Storage Levels

| Level                          | Memory  | Disk Fallback | Serialized | Replicated |
|--------------------------------|---------|---------------|-------------|-------------|
| `MEMORY_ONLY` (default in PySpark since 3.0) | yes     | no            | no          | no          |
| `MEMORY_ONLY_SER`              | yes     | no            | yes         | no          |
| `MEMORY_AND_DISK`              | yes     | yes           | yes         | no          |
| `MEMORY_AND_DISK_DESER` (default for DataFrames in 3.x) | yes | yes | no | no |
| `DISK_ONLY`                    | no      | yes           | yes         | no          |
| `*_2`                          | (any)   |               |             | yes (×2)   |
| `OFF_HEAP`                     | off-heap| no            | yes         | no          |

### What "Cached Partitions" Tells You

```
6 / 6  : all partitions cached (100%)
3 / 6  : only half — eviction is happening; memory is tight
0 / 6  : storage entry exists but evicted (rare)
not present: cache() never triggered, or unpersisted
```

> Always read with the `Fraction` column. `< 100%` = silent eviction.

### Common "Storage Tab Mysteries"

| You see...                              | Reason                                                    |
|-----------------------------------------|-----------------------------------------------------------|
| Tab is empty after `df.cache()`         | You forgot to trigger an action                           |
| Tab fills then partially empties         | Eviction (memory pressure)                                |
| Cached size = 4× of file size            | Deserialization overhead (especially for `MEMORY_ONLY`)   |
| `OnDisk` > 0                             | Memory full → spilling cache to executor disk             |
| Two entries with similar names           | DataFrame cached at different lineage points              |

### Bringing Cache Health Up

```python
# 1) Trigger materialization
df.cache(); df.count()

# 2) If only partially cached, switch to MEMORY_AND_DISK
df.persist(StorageLevel.MEMORY_AND_DISK)

# 3) If still partial, you're caching too much; reduce columns/rows
df.select("a","b").cache()
```

---

## Tab C — Environment

### Sections

```
Environment Tab:
+-------------------------------------------------------+
| Runtime Information                                    |
|   Java Version: 11                                     |
|   Spark Version: 3.5.0                                 |
|   Scala Version: 2.12.18                               |
+-------------------------------------------------------+
| Spark Properties                                       |
|   spark.app.name = MyApp                               |
|   spark.sql.shuffle.partitions = 8                     |
|   spark.sql.adaptive.enabled = false                   |
|   spark.executor.memory = 4g                           |
|   spark.driver.memory = 2g                             |
|   ... (all configs)                                    |
+-------------------------------------------------------+
| Hadoop Properties                                      |
|   fs.s3a.access.key = ...                             |
+-------------------------------------------------------+
| System Properties                                      |
|   user.home, java.home, ...                            |
+-------------------------------------------------------+
| Classpath Entries                                      |
|   /path/to/spark/jars/*.jar                            |
+-------------------------------------------------------+
```

### What This Tab Saves You From

```
Common bugs caught by Environment tab:
  - Typo in config name: "spark.sql.shuffle.parititons"  (misspelled)
  - Config set after getOrCreate(): silently ignored
  - Wrong jar version: e.g. delta-core-2.0 with Spark 3.5
  - Hadoop S3 credentials missing
  - Java 17 vs Java 8 mismatch
```

### Common Workflow

```python
spark.conf.set("spark.sql.shuffle.partitions", "8")    # this won't apply for some configs
# 1. Open Environment tab
# 2. Cmd-F search "shuffle.partitions"
# 3. Verify the value
# 4. If wrong, set it in builder before getOrCreate()
```

---

## Putting the 3 Tabs Together — A Resource Diagnosis Flow

```
Symptom: "My job fails with OOM"
    |
    v
Open Executors Tab
    |
    +-- Mem usage > 90%? -> raise spark.executor.memory
    +-- Failed Tasks > 0 on one exec? -> check logs for OOM
    +-- One exec hot, others idle? -> data skew (Pattern 08)
    |
    v
Open Storage Tab
    |
    +-- Cached too much? Reduce or use MEMORY_AND_DISK
    +-- Fraction < 100%? Eviction; raise memory or unpersist unused
    |
    v
Open Environment Tab
    |
    +-- Memory configs as expected?
    +-- Adaptive / coalesce flags right?
    +-- Java/Spark version match production?
```

---

## Worked Example — Reading a Healthy Run

```
Executors:
  driver  GC 2s     RDD 0    Mem 200MB / 2GB    Tasks -
  exec-0  GC 5s     RDD 240  Mem 1.5GB / 4GB    Tasks 23 (0 failed)

Storage:
  df_filtered  MEMORY_AND_DISK_DESER  6/6  240MB

Environment:
  spark.sql.shuffle.partitions = 8
  spark.sql.adaptive.enabled = false
  spark.executor.memory = 4g
  spark.driver.memory = 2g
```

**Health verdict:**
- GC ratio = 5/Total_task_time → small.
- Memory = 1.5/4 = 37%.
- Cache fraction = 100%.
- Configs match script.
- → Healthy.

---

## Common Mistakes

| Mistake                                                 | Why It Misleads                                              | Fix                                                                |
|---------------------------------------------------------|--------------------------------------------------------------|--------------------------------------------------------------------|
| Setting config in code via `spark.conf.set` and expecting it to apply at runtime | Some configs are static (read at session start)              | Set in `SparkSession.builder` before `getOrCreate()`               |
| Reading driver memory and ignoring executors            | Driver size is for collected data, not executor work          | Look at Executors tab for executor health                          |
| Trusting "Storage Mem Used" alone                        | Doesn't reflect execution memory used during shuffles        | Use Stages tab (Spill Mem/Disk) for execution memory              |
| Treating cache size = file size                          | Deserialized cache is much bigger than parquet               | Use `MEMORY_ONLY_SER` to compress                                  |
| Not refreshing Environment after config changes          | Each app run is a fresh dump                                  | Restart driver to apply new builder configs                        |
| Forgetting OFF_HEAP needs `spark.memory.offHeap.enabled` | OFF_HEAP storage level silently fails without it             | Set `spark.memory.offHeap.enabled=true` and `offHeap.size=Xg`     |

---

## Quick Field Reference Cards

### Executor Card

```
Status: Alive | Dead
RDD Used / Max   : storage memory headroom
Storage Mem Used : total cached size
Disk Used        : spill (warning if non-zero)
Total Tasks      : workload share
Failed Tasks     : ideally 0
GC Time          : < 10% of total task time
Active Tasks     : currently running
Cores            : parallel slots
```

### Storage Card

```
RDD Name           : your DataFrame's tracking id
Storage Level      : MEMORY_AND_DISK / MEMORY_ONLY / etc.
Cached Partitions  : N / total — fraction matters
Size in Memory     : current size
Size on Disk       : if spilled (only for MEMORY_AND_DISK)
```

### Environment Card

```
Spark Version, Java Version, Scala Version
Spark Properties: every spark.* you set + defaults
Hadoop Properties: filesystem credentials
System Properties: JVM and OS info
Classpath Entries: every jar loaded
```

---

## Cross-Reference

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| Why a stage shows spill in Stages tab               | 04, 08  |
| Why some tasks slower than others (skew)            | 08      |
| Why cache appears empty after `cache()` call         | 05      |
| Reading job duration in context of executors         | 02      |

---

## Real-World Use Cases

```
1. "Pipeline runs but fails after 30 min with OOM"
   - Executors tab: see one exec hitting Max mem before failure
   - Storage tab: cache size huge -> reduce or change level

2. "Cache works in dev but evicts in prod"
   - Storage tab in prod shows < 100% cached
   - Increase spark.executor.memory or storage fraction

3. "spark.sql.shuffle.partitions = 8 set in code but UI shows 200"
   - Environment tab: setting was ignored
   - Move to builder; restart app

4. "GC time is 70% of task time"
   - Executors tab: GC = 70 of 100 sec
   - Reduce cache or shuffle.partitions; consider G1GC

5. "I ran df.cache() 3 times — Storage shows 3 entries"
   - Each call cached at a different lineage point
   - Use df.unpersist() and cache only the canonical version
```

---

## Configs You Often Tune After Reading These Tabs

| Config                                | Tuned When                                          |
|---------------------------------------|-----------------------------------------------------|
| `spark.executor.memory`               | Mem usage > 90% in Executors tab                    |
| `spark.executor.memoryOverhead`       | Container kills due to overhead                      |
| `spark.driver.memory`                 | Driver GC high or `collect()` OOMs                   |
| `spark.memory.fraction`               | Spill > 0 but cache fraction = 100%                  |
| `spark.memory.storageFraction`        | Cache being evicted often                            |
| `spark.sql.shuffle.partitions`        | Stage tasks too few or too many                       |
| `spark.serializer = KryoSerializer`   | High shuffle bytes                                    |
| `spark.dynamicAllocation.*`           | Cluster utilization is uneven                         |

---

## Key Takeaway

> Executors = runtime health (memory, GC, dead nodes).
> Storage = cache health (level, fraction, eviction).
> Environment = config sanity (did your settings actually apply?).
> Whenever Jobs/Stages tab show *something is wrong*, these 3 tabs tell you *why* — usually within 30 seconds of looking.
