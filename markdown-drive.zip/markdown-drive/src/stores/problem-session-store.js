import { create } from 'zustand';

export const useProblemSessionStore = create((set, get) => ({
  hintsRevealed: [],
  hintsUsed: 0,
  deepDiveAnswers: {},
  deepDiveScore: 0,
  deepDiveCompleted: false,
  deepDiveResults: null,
  showDeepDive: false,
  archScore: 0,
  chaosActive: null,
  chaosResults: null,
  totalScore: 0,
  verdict: null,
  showScoreCard: false,
  submitted: false,
  serverVerdict: null,

  revealHint: (idx) => set((s) => {
    if (s.hintsRevealed.includes(idx)) return {};
    return {
      hintsRevealed: [...s.hintsRevealed, idx],
      hintsUsed: s.hintsUsed + 1,
    };
  }),

  answerDeepDive: (qIdx, optionIdx) => set((s) => {
    const answers = { ...s.deepDiveAnswers };
    const current = answers[qIdx] || [];
    const pos = current.indexOf(optionIdx);
    if (pos >= 0) {
      answers[qIdx] = current.filter((v) => v !== optionIdx);
    } else {
      answers[qIdx] = [...current, optionIdx];
    }
    return { deepDiveAnswers: answers };
  }),

  submitDeepDive: async (problem, components, connections) => {
    const state = get();
    try {
      const res = await fetch(`/api/problems/${problem.id}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          components,
          connections,
          hintsUsed: state.hintsUsed,
          deepDiveAnswers: state.deepDiveAnswers,
        }),
      });
      const data = await res.json();
      if (!res.ok) return;

      set({
        deepDiveScore: data.deepDive?.score || 0,
        deepDiveResults: data.deepDive?.results || null,
        deepDiveCompleted: true,
        archScore: data.archScore,
        totalScore: data.totalScore,
        serverVerdict: data,
      });
    } catch { /* network error handled silently */ }
  },

  showFinalScore: () => set((s) => {
    const sv = s.serverVerdict;
    if (!sv) return {};

    let verdict;
    if (sv.totalScore >= 90) verdict = { label: 'Strong Hire', color: '#2f9e44' };
    else if (sv.totalScore >= 70) verdict = { label: 'Hire', color: '#1971c2' };
    else if (sv.totalScore >= 50) verdict = { label: 'Lean Hire', color: '#f08c00' };
    else verdict = { label: 'Needs Practice', color: '#e03131' };

    return {
      totalScore: sv.totalScore,
      verdict,
      showScoreCard: true,
    };
  }),

  setArchScore: (score) => set({ archScore: score }),
  setSubmitted: (val) => set({ submitted: val }),
  setShowDeepDive: (val) => set({ showDeepDive: val }),
  setChaosResults: (results) => set({ chaosResults: results }),
  setServerVerdict: (data) => set({ serverVerdict: data }),

  setChaosActive: (scenario) => set({ chaosActive: scenario }),
  clearChaos: () => set({ chaosActive: null }),

  resetSession: () => set({
    hintsRevealed: [],
    hintsUsed: 0,
    deepDiveAnswers: {},
    deepDiveScore: 0,
    deepDiveCompleted: false,
    deepDiveResults: null,
    showDeepDive: false,
    archScore: 0,
    chaosActive: null,
    chaosResults: null,
    totalScore: 0,
    verdict: null,
    showScoreCard: false,
    submitted: false,
    serverVerdict: null,
  }),
}));
