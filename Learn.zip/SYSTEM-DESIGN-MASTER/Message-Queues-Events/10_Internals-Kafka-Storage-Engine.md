# Internals: Kafka Storage Engine — The Commit Log

> **Permanent Recall:** Kafka stores messages in an **append-only commit log** on disk. Each partition = directory of **log segments** (`.log` + `.index` + `.timeindex`). Writes append sequentially (no random I/O). Reads use **mmap'd sparse indexes** to find offsets, then **zero-copy sendfile()** to stream data directly from page cache to NIC. Kafka's speed comes from **sequential disk I/O + OS page cache + zero-copy** — not from being "in-memory."

---

## Why This Matters

Kafka performance is often misunderstood.

The usual wrong mental model is:

- disk is slow
- memory is fast
- therefore Kafka must somehow be mostly in memory

The correct mental model is:

- sequential disk I/O is extremely fast
- page cache keeps hot data in RAM
- zero-copy avoids wasteful copies

This file is the foundation for explaining why Kafka can be both durable and fast.

---

## The Fundamental Insight: Why Kafka is Fast on Disk

```
COMMON MISCONCEPTION:
  "Disk is slow, memory is fast, so message queues should be in-memory"

REALITY:
  Random disk I/O:    ~10 ms (HDD), ~0.1 ms (SSD)    ← SLOW
  Sequential disk I/O: ~600 MB/s (HDD), ~3 GB/s (SSD) ← FAST
  Random memory:       ~100 ns                          ← FAST
  Sequential memory:   ~10 GB/s                         ← FASTEST

  Sequential disk reads can be FASTER than random memory access!

KAFKA'S STRATEGY:
  1. Only sequential writes (append to end of file)
  2. Only sequential reads (consumers read forward through log)
  3. Let OS page cache handle caching (no double-buffering)
  4. Use zero-copy to avoid copying data through userspace

  Result: Kafka saturates disk/network bandwidth, not CPU
```

---

## Partition Directory Structure on Disk

```
KAFKA DATA DIRECTORY LAYOUT:

/var/kafka-logs/                              # log.dirs config
├── orders-0/                                 # topic "orders", partition 0
│   ├── 00000000000000000000.log              # first segment (starts at offset 0)
│   ├── 00000000000000000000.index            # offset index for segment
│   ├── 00000000000000000000.timeindex        # timestamp index
│   ├── 00000000000005242880.log              # second segment (starts at offset 5242880)
│   ├── 00000000000005242880.index
│   ├── 00000000000005242880.timeindex
│   ├── 00000000000010485760.log              # third segment (active)
│   ├── 00000000000010485760.index
│   ├── 00000000000010485760.timeindex
│   └── leader-epoch-checkpoint               # leader epoch data
│
├── orders-1/                                 # partition 1
│   └── ...
├── orders-2/                                 # partition 2
│   └── ...
├── payments-0/                               # different topic
│   └── ...
├── meta.properties                           # broker metadata
├── cleaner-offset-checkpoint
├── recovery-point-offset-checkpoint          # fsync'd offsets
└── replication-offset-checkpoint             # replicated offsets

FILE NAMING:
  Segment file name = base offset (zero-padded to 20 digits)
  00000000000000000000.log → starts at offset 0
  00000000000005242880.log → starts at offset 5,242,880
  Allows binary search across segment files by offset
```

---

## Log Segment Internals

### The .log File (Message Data)

```
LOG SEGMENT FILE (.log):

  A segment is a sequence of Record Batches (also called Message Sets).
  Each batch contains one or more records.

  ┌──────────────────────────────────────────────────────────────┐
  │                    LOG SEGMENT FILE                           │
  │                                                              │
  │  ┌─────────────────────────────────────────────────────────┐ │
  │  │ Record Batch 0                                          │ │
  │  │  baseOffset: 0                                          │ │
  │  │  batchLength: 482 bytes                                 │ │
  │  │  magic: 2 (version)                                     │ │
  │  │  crc: 0xA3B2C1D0                                       │ │
  │  │  attributes: compression=snappy, timestampType=create   │ │
  │  │  lastOffsetDelta: 4 (5 records in batch: 0,1,2,3,4)    │ │
  │  │  firstTimestamp: 1710000000000                          │ │
  │  │  maxTimestamp: 1710000000050                             │ │
  │  │  producerId: 1234 (for exactly-once)                    │ │
  │  │  producerEpoch: 0                                       │ │
  │  │  baseSequence: 0                                        │ │
  │  │  ┌──────────────────────────────────────────────────┐   │ │
  │  │  │ Record 0: offsetDelta=0, key="order-1", value=.. │   │ │
  │  │  │ Record 1: offsetDelta=1, key="order-2", value=.. │   │ │
  │  │  │ Record 2: offsetDelta=2, key="order-3", value=.. │   │ │
  │  │  │ Record 3: offsetDelta=3, key="order-4", value=.. │   │ │
  │  │  │ Record 4: offsetDelta=4, key="order-5", value=.. │   │ │
  │  │  └──────────────────────────────────────────────────┘   │ │
  │  └─────────────────────────────────────────────────────────┘ │
  │                                                              │
  │  ┌─────────────────────────────────────────────────────────┐ │
  │  │ Record Batch 1                                          │ │
  │  │  baseOffset: 5                                          │ │
  │  │  ... (next batch of records)                            │ │
  │  └─────────────────────────────────────────────────────────┘ │
  │                                                              │
  │  ... more batches appended sequentially ...                  │
  └──────────────────────────────────────────────────────────────┘

SEGMENT ROLLING (creating new segment):
  New segment when any condition met:
    - Size: log.segment.bytes (default 1 GB)
    - Time: log.roll.ms / log.roll.hours (default 7 days)
    - Index full: index file size limit reached

  Only the LAST segment is "active" (writable)
  All older segments are IMMUTABLE (read-only)
```

### Record Batch Binary Format (On Disk, Byte Level)

```
RECORD BATCH BINARY FORMAT (v2, magic=2):

Offset  Size   Field
──────  ─────  ─────────────────────────────────────────
0       8      baseOffset (int64)
8       4      batchLength (int32) — bytes after this field
12      4      partitionLeaderEpoch (int32)
16      1      magic (int8) = 2
17      4      crc (uint32) — CRC-32C of bytes 21..end
21      2      attributes (int16):
                 bit 0-2: compression (0=none, 1=gzip, 2=snappy, 3=lz4, 4=zstd)
                 bit 3:   timestamp type (0=create, 1=log append)
                 bit 4:   is transactional
                 bit 5:   is control batch
                 bit 6:   has delete horizon
23      4      lastOffsetDelta (int32)
27      8      firstTimestamp (int64)
35      8      maxTimestamp (int64)
43      8      producerId (int64) — for idempotent/transactional
51      2      producerEpoch (int16)
53      4      baseSequence (int32) — for idempotent dedup
57      4      numRecords (int32)
61      ...    [compressed record data]

INDIVIDUAL RECORD FORMAT (within batch, after decompression):
  length:          varint
  attributes:      int8 (unused, reserved)
  timestampDelta:  varint (relative to firstTimestamp)
  offsetDelta:     varint (relative to baseOffset)
  keyLength:       varint (-1 if null)
  key:             bytes
  valueLength:     varint (-1 if null)
  value:           bytes
  numHeaders:      varint
  headers:         [headerKey (string), headerValue (bytes)]...

VARINT ENCODING (Protobuf-style):
  Uses variable-length encoding to save space
  Small numbers = fewer bytes:
    0-127       → 1 byte
    128-16383   → 2 bytes
    16384+      → 3+ bytes
  High bit = "more bytes follow"
  Example: 300 = 0xAC 0x02 (2 bytes instead of 4)
```

---

## Index Files — How Kafka Finds Messages by Offset

### The .index File (Offset Index)

```
OFFSET INDEX (.index):

Purpose: Given an offset, quickly find the POSITION in the .log file.

Structure: SPARSE index (not every offset is indexed)
  Every log.index.interval.bytes (default 4096) of log data,
  one entry is added to the index.

  ┌──────────────────────────────────────────────────────┐
  │ OFFSET INDEX FILE (memory-mapped)                     │
  │                                                      │
  │  Entry format: [relative_offset (4 bytes)] [position (4 bytes)]
  │                                                      │
  │  Entry 0: offset_delta=0,      file_position=0       │
  │  Entry 1: offset_delta=12,     file_position=4096    │
  │  Entry 2: offset_delta=27,     file_position=8192    │
  │  Entry 3: offset_delta=41,     file_position=12288   │
  │  Entry 4: offset_delta=55,     file_position=16384   │
  │  ...                                                 │
  └──────────────────────────────────────────────────────┘

  relative_offset = target_offset - baseOffset_of_segment
  position = byte offset within the .log file

LOOKUP ALGORITHM (finding offset 30 in this segment):
  1. Binary search in .index for largest entry ≤ 30
     Found: entry 2 (offset=27, position=8192)
  2. Seek to position 8192 in .log file
  3. Scan forward linearly through record batches
     until offset 30 is found
  4. Return the record

WHY SPARSE (not every offset)?
  - Full index for 1 billion offsets = 8 GB
  - Sparse (every ~4KB): 1 billion offsets with 4KB avg record ≈ 2 MB index
  - Linear scan over ~4KB is fast (CPU cache, sequential access)
  - Trade: slightly more CPU for MUCH less memory/disk

MEMORY MAPPING (mmap):
  Index files are mmap'd into broker's virtual address space:
    void *addr = mmap(NULL, file_size, PROT_READ, MAP_PRIVATE, fd, 0);
  Kernel maps file pages directly to process's virtual memory
  No explicit read() syscall needed — just pointer dereference
  OS page cache handles caching automatically
  If page not in cache → page fault → kernel loads from disk
```

### The .timeindex File (Timestamp Index)

```
TIMESTAMP INDEX (.timeindex):

Purpose: Given a timestamp, find the offset.
Used for: consumer.seekToTimestamp(), log retention by time.

  Entry format: [timestamp (8 bytes)] [relative_offset (4 bytes)]
  12 bytes per entry

  Entry 0: timestamp=1710000000000, offset_delta=0
  Entry 1: timestamp=1710000060000, offset_delta=12
  Entry 2: timestamp=1710000120000, offset_delta=27
  ...

LOOKUP: "Find messages from 2024-03-10 00:01:00"
  1. Binary search in .timeindex for largest timestamp ≤ target
  2. Get the offset from that entry
  3. Use .index to find position in .log
  4. Start reading from there
```

---

## How Writes Work — Append Path

```
PRODUCE REQUEST → DISK WRITE PATH:

1. IO Thread receives ProduceRequest
   Topic: "orders", Partition: 2, Records: [batch of 5 messages]

2. VALIDATION:
   - Topic/partition exists?
   - Client authorized? (ACL check)
   - Message size ≤ max.message.bytes?
   - If transactional: valid producerId + epoch?

3. ASSIGN OFFSETS:
   Broker assigns monotonically increasing offsets:
   ┌─────────────────────────────────────────────┐
   │ synchronized (partition_lock) {              │
   │   nextOffset = log.nextOffsetMetadata()     │
   │   for each record in batch:                 │
   │     record.offset = nextOffset++            │
   │   log.updateNextOffset(nextOffset)          │
   │ }                                           │
   └─────────────────────────────────────────────┘
   This lock is per-partition (not global)!

4. APPEND TO ACTIVE SEGMENT:
   ┌─────────────────────────────────────────────┐
   │ activeSegment.append(recordBatch):           │
   │                                             │
   │   // Write to .log file                      │
   │   fileChannel.write(batchBytes, position)   │
   │   // This writes to OS page cache            │
   │   // NOT directly to disk (no fsync yet)     │
   │   position += batchBytes.length             │
   │                                             │
   │   // Update .index if interval reached       │
   │   if (bytesSinceLastIndex >= 4096):         │
   │     index.append(offsetDelta, position)     │
   │     bytesSinceLastIndex = 0                 │
   │                                             │
   │   // Update .timeindex                       │
   │   timeindex.append(maxTimestamp, offsetDelta)│
   └─────────────────────────────────────────────┘

5. PAGE CACHE (kernel):
   ┌─────────────────────────────────────────────┐
   │ File write goes to PAGE CACHE, not disk:     │
   │                                             │
   │   write() → data in page cache (RAM)         │
   │   Page marked "dirty"                        │
   │   Kernel flushes dirty pages in background:  │
   │     dirty_expire_centisecs = 3000 (30 sec)  │
   │     dirty_writeback_centisecs = 500 (5 sec) │
   │                                             │
   │ Kafka's fsync policy:                        │
   │   log.flush.interval.messages = Long.MAX     │
   │   log.flush.interval.ms = Long.MAX           │
   │   DEFAULT: Kafka does NOT fsync per message! │
   │   Relies on replication for durability       │
   │   OS flushes dirty pages eventually          │
   │                                             │
   │ Why no fsync?                                │
   │   fsync() forces disk write: ~0.5-5 ms       │
   │   Without fsync: write() returns in ~1-10 µs │
   │   500x-5000x faster!                         │
   │   Durability via replication to other brokers │
   └─────────────────────────────────────────────┘

6. RESPOND TO PRODUCER:
   If acks=0: already returned (fire-and-forget)
   If acks=1: respond now (leader wrote to page cache)
   If acks=all: wait for ISR replicas → Purgatory → respond
```

### Sequential Write Performance

```
WHY SEQUENTIAL WRITES ARE SO FAST:

HDD (spinning disk):
  Random write: seek (~8ms) + rotation (~4ms) + transfer
    = ~10ms per write = ~100 writes/sec
  Sequential write: NO seek, NO rotation
    = ~100 MB/s sustained (head stays in place)

SSD:
  Random write: ~0.1ms per write = ~10,000 writes/sec
  Sequential write: ~500 MB/s - 3 GB/s
  BUT: random writes cause write amplification (garbage collection)
  Sequential writes avoid this → longer SSD life

NVMe SSD:
  Random write: ~0.02ms = ~50,000 writes/sec
  Sequential write: 2-7 GB/s
  Multiple I/O queues (up to 64K queues × 64K depth)

KAFKA EXPLOITS THIS:
  ONLY appends to end of file → pure sequential I/O
  OS read-ahead works perfectly (prefetch next pages)
  Disk bandwidth fully utilized, not limited by latency

  Throughput example (single partition, 1KB messages):
    HDD: ~100,000 messages/sec (100 MB/s ÷ 1KB)
    SSD: ~500,000 messages/sec
    NVMe: ~2,000,000 messages/sec
    (Limited by other factors in practice: network, CPU, replication)
```

---

## How Reads Work — Fetch/Consume Path

```
FETCH REQUEST → DISK READ PATH:

Consumer sends: FetchRequest(topic="orders", partition=2, offset=42, maxBytes=1MB)

1. FIND THE SEGMENT:
   Partition has segments: [0.log, 5242880.log, 10485760.log]
   Binary search: 42 < 5242880, so → segment 0.log

2. FIND POSITION IN SEGMENT:
   Use offset index (0.index):
     Binary search for largest entry with offset ≤ 42
     Found: entry at offset=27, position=8192
   Seek to byte position 8192 in 0.log
   Scan forward through batches until offset 42 found
   Record position of offset 42: say byte 9500

3. READ DATA:
   Two paths — zero-copy or regular:

   REGULAR PATH (rare, when SSL enabled):
     read(log_fd, userspace_buffer, maxBytes)
     // Kernel → userspace copy
     encrypt(userspace_buffer)  // SSL/TLS
     write(client_fd, encrypted_buffer, len)
     // Userspace → kernel copy
     // Total: 4 copies, 2 syscalls, 2 context switches

   ZERO-COPY PATH (default, no SSL):
     sendfile(client_fd, log_fd, &offset, count)
     // Kernel does everything — no userspace copy!
     // Covered in detail below
```

### Zero-Copy: sendfile() Deep Dive

```
ZERO-COPY WITH sendfile() — KAFKA'S SECRET WEAPON:

Traditional read+write (4 copies):
  ┌──────────────────────────────────────────────────────────────┐
  │                                                              │
  │  DISK → [kernel read buffer] → [userspace buffer]            │
  │                copy 1              copy 2                    │
  │                                                              │
  │  [userspace buffer] → [kernel socket buffer] → NIC           │
  │       copy 3              copy 4                             │
  │                                                              │
  │  4 data copies                                               │
  │  4 context switches (read syscall in+out, write syscall in+out)
  │  CPU is busy copying bytes it doesn't even look at           │
  └──────────────────────────────────────────────────────────────┘

sendfile() (2 copies, no userspace):
  ┌──────────────────────────────────────────────────────────────┐
  │                                                              │
  │  DISK → [kernel page cache] ────────────► [socket buffer] → NIC
  │              copy 1                          copy 2          │
  │                                                              │
  │  Data NEVER enters userspace                                 │
  │  2 data copies, 1 syscall, 2 context switches               │
  └──────────────────────────────────────────────────────────────┘

sendfile() with DMA gather (modern NIC, 0 CPU copies):
  ┌──────────────────────────────────────────────────────────────┐
  │                                                              │
  │  DISK → [kernel page cache]                                  │
  │              DMA read                                        │
  │                                                              │
  │  sendfile():                                                 │
  │    Socket buffer gets POINTER to page cache (not data copy)  │
  │    NIC DMA scatter-gather reads directly from page cache     │
  │                                                              │
  │  [page cache pages] ──DMA──► NIC → wire                      │
  │                                                              │
  │  ZERO CPU copies! Data goes disk→RAM→NIC via DMA only        │
  │  CPU just manages descriptors and pointers                   │
  └──────────────────────────────────────────────────────────────┘

KERNEL sendfile() IMPLEMENTATION:
  ssize_t sendfile(int out_fd, int in_fd, off_t *offset, size_t count) {
      // Simplified flow:
      // 1. Look up page cache pages for in_fd at offset
      // 2. If not cached: trigger read-ahead, load from disk
      // 3. Create pipe_buffer pointing to cached pages
      // 4. Splice pages to socket's send buffer
      // 5. NIC DMA reads from those pages
      // 6. Return bytes transferred
  }

PERFORMANCE IMPACT:
  Without zero-copy: ~400 MB/s (CPU-bound on copying)
  With zero-copy:    ~2-4 GB/s (network/disk bound)
  CPU usage: drops by 50-70% for the same throughput

WHY NOT ALWAYS ZERO-COPY:
  SSL/TLS encryption: must read data into userspace to encrypt
  Kafka with SSL: falls back to regular read+write
  Kafka without SSL: uses sendfile() (this is why Kafka docs recommend
  no SSL within datacenter, only at edge)
```

---

## Page Cache — The OS as Kafka's Cache

```
OS PAGE CACHE — KAFKA'S PRIMARY CACHING LAYER:

Kafka intentionally does NOT cache messages in JVM heap.
Instead, it relies entirely on the OS page cache.

WHY?
  1. JVM heap cache = double caching (data in heap AND page cache)
  2. JVM garbage collection pauses (GC) = latency spikes
  3. Page cache survives broker restart (JVM heap doesn't)
  4. Page cache is managed by kernel (very efficient LRU)
  5. Page cache works with sendfile() (JVM heap doesn't)

HOW PAGE CACHE WORKS:
  ┌──────────────────────────────────────────────────────────────┐
  │                       PHYSICAL RAM (e.g., 128 GB)            │
  │                                                              │
  │  ┌──────────────────┐  ┌────────────────────────────────────┐│
  │  │ Kernel + Apps     │  │ PAGE CACHE (rest of free RAM)      ││
  │  │ JVM heap (6 GB)   │  │                                    ││
  │  │ OS buffers        │  │ Cached file pages from disk:       ││
  │  │ (~10 GB total)    │  │ orders-0/00..00.log: pages 0-999  ││
  │  │                   │  │ orders-1/00..00.log: pages 0-500  ││
  │  │                   │  │ payments-0/00..00.log: pages 0-200││
  │  │                   │  │ ... (LRU eviction when full)      ││
  │  │                   │  │                                    ││
  │  │                   │  │ ~118 GB available for page cache   ││
  │  └──────────────────┘  └────────────────────────────────────┘│
  └──────────────────────────────────────────────────────────────┘

WRITE PATH (Producer):
  write(fd, data, len)
  → Kernel copies to page cache page
  → Page marked DIRTY
  → write() returns IMMEDIATELY (sub-microsecond)
  → Kernel flushes dirty pages to disk in background
  → If consumer reads before flush: data served from page cache (fast!)

READ PATH (Consumer — caught up):
  Consumer offset ≈ producer offset (reading latest data)
  Data was JUST written → still in page cache (hot!)
  sendfile() → data from page cache → NIC
  NO DISK I/O AT ALL for caught-up consumers

READ PATH (Consumer — behind, or replay):
  Consumer reading old data (e.g., from 3 days ago)
  Data NOT in page cache → page fault
  Kernel loads from disk → page cache → NIC
  OS read-ahead: kernel prefetches next pages (sequential pattern)
  After first page fault: subsequent reads are fast (prefetched)

THIS IS WHY KAFKA RECOMMENDS:
  - Small JVM heap (6-8 GB) — leave rest for page cache
  - Lots of RAM — more page cache = more hot data
  - Don't use swap — page cache eviction is fine; swapping JVM is not
  - vm.swappiness = 1 (almost never swap)
```

---

## Log Retention and Cleanup

```
LOG RETENTION — HOW OLD DATA IS DELETED:

TIME-BASED (default):
  log.retention.hours = 168 (7 days)
  Check: if segment's maxTimestamp < now - retention → delete

SIZE-BASED:
  log.retention.bytes = -1 (unlimited by default)
  If set: delete oldest segments until total size ≤ limit

CLEANUP PROCESS:
  LogCleaner thread runs periodically:
  ┌─────────────────────────────────────────────────────┐
  │ For each partition:                                  │
  │   segments = list all segments by base offset        │
  │   for each segment (except active):                 │
  │     if segment.maxTimestamp < now - retention:       │
  │       // Rename to .deleted                          │
  │       segment.log  → segment.log.deleted             │
  │       segment.index → segment.index.deleted          │
  │       // Schedule actual file deletion               │
  │       // after log.segment.delete.delay.ms (60s)    │
  │       // This delay allows in-flight reads to finish │
  └─────────────────────────────────────────────────────┘

LOG COMPACTION (alternative to deletion):
  cleanup.policy = compact
  Used for changelog topics (e.g., KTable state)

  Before compaction:
    offset 0: key=A, value=1
    offset 1: key=B, value=2
    offset 2: key=A, value=3    ← newer A
    offset 3: key=C, value=4
    offset 4: key=B, value=null ← tombstone (delete B)

  After compaction:
    offset 2: key=A, value=3    ← latest A kept
    offset 3: key=C, value=4    ← only C kept
    offset 4: key=B, value=null ← tombstone kept (for propagation)

  HOW COMPACTION WORKS INTERNALLY:
  ┌─────────────────────────────────────────────────────┐
  │ LogCleaner thread:                                   │
  │                                                     │
  │ 1. Build offset map:                                 │
  │    Scan dirty segments (uncompacted)                 │
  │    For each key: store latest offset                 │
  │    Map stored in memory (SkipList):                  │
  │    key_hash → latest_offset                          │
  │    Memory: log.cleaner.dedupe.buffer.size (128 MB)  │
  │                                                     │
  │ 2. Copy pass:                                        │
  │    Read each segment                                 │
  │    For each record:                                  │
  │      if record.offset == map[record.key]:           │
  │        copy to new segment (keep)                    │
  │      else:                                           │
  │        skip (superseded by newer record)             │
  │                                                     │
  │ 3. Swap:                                             │
  │    Atomically replace old segment files with new     │
  │    Update indexes                                    │
  └─────────────────────────────────────────────────────┘
```

---

## Compression: How Kafka Reduces I/O

```
COMPRESSION IN KAFKA:

Producer compresses entire record batch BEFORE sending:
  Raw batch (10 records, 1KB each):  10 KB
  Compressed (snappy):               ~3 KB (70% reduction)

  compression.type = snappy | lz4 | zstd | gzip | none

COMPRESSION LIFECYCLE:
  Producer:  records → compress → send compressed batch
  Broker:    receive → store AS-IS (still compressed on disk!)
  Consumer:  receive → decompress → records

  Broker NEVER decompresses (except for validation if needed)
  Saves: network bandwidth, disk I/O, disk space

COMPRESSION COMPARISON:
  ┌──────────┬────────────┬────────────┬──────────┐
  │ Codec    │ Ratio      │ Compress   │ Decompress│
  │          │ (smaller=  │ Speed      │ Speed     │
  │          │  better)   │            │           │
  ├──────────┼────────────┼────────────┼──────────┤
  │ none     │ 1.0x       │ N/A        │ N/A       │
  │ snappy   │ ~2-3x      │ ~500 MB/s  │ ~1 GB/s   │
  │ lz4      │ ~2-3x      │ ~600 MB/s  │ ~2 GB/s   │
  │ zstd     │ ~3-5x      │ ~300 MB/s  │ ~800 MB/s │
  │ gzip     │ ~4-6x      │ ~50 MB/s   │ ~300 MB/s │
  └──────────┴────────────┴────────────┴──────────┘

  Kafka default recommendation: lz4 or zstd
  lz4: best speed, decent ratio
  zstd: best ratio with reasonable speed
  snappy: legacy, still common
  gzip: highest ratio but CPU-heavy, rarely used

BATCH COMPRESSION (not per-message):
  Compressing 1 message: poor ratio (not enough redundancy)
  Compressing 100 messages together: MUCH better ratio
  Kafka compresses at batch level → encourages batching
  linger.ms > 0 → more messages in batch → better compression
```

---

## FileChannel and Memory-Mapped I/O

```
HOW KAFKA ACTUALLY READS/WRITES FILES:

WRITES (log data): Java FileChannel
  FileChannel channel = FileChannel.open(path, WRITE, APPEND);
  channel.write(ByteBuffer.wrap(batchBytes));
  // Translates to: pwrite() syscall → page cache

  Why FileChannel (not mmap for writes)?
  - mmap write: risk of SIGBUS if disk full (unrecoverable)
  - FileChannel write: returns error code (recoverable)
  - mmap: harder to control when data hits disk
  - FileChannel: can explicitly fsync() when needed

READS (index files): mmap
  MappedByteBuffer indexBuffer = channel.map(READ_ONLY, 0, size);
  int position = indexBuffer.getInt(entryOffset);
  // Translates to: memory access → page fault if not cached → kernel loads

  Why mmap for indexes?
  - Indexes are frequently accessed, relatively small
  - mmap: zero-copy access (no syscall per read)
  - OS manages caching automatically
  - Binary search on mmap'd buffer: pointer arithmetic, very fast

READS (log data for consumers): sendfile
  FileChannel.transferTo(position, count, socketChannel);
  // Translates to: sendfile() syscall → zero-copy

  Why transferTo/sendfile for log reads?
  - Consumer reads are large sequential transfers
  - sendfile: data goes page cache → NIC, no userspace copy
  - Perfect for streaming large amounts of data

SUMMARY OF I/O METHODS:
  ┌──────────────┬───────────────┬─────────────────────────┐
  │ Operation    │ I/O Method    │ Syscall                 │
  ├──────────────┼───────────────┼─────────────────────────┤
  │ Write log    │ FileChannel   │ pwrite()                │
  │ Read index   │ mmap          │ memory access (no call) │
  │ Read log     │ transferTo    │ sendfile()              │
  │ Fsync        │ FileChannel   │ fsync() / fdatasync()   │
  └──────────────┴───────────────┴─────────────────────────┘
```

---

## Segment Lifecycle: Creation to Deletion

```
COMPLETE SEGMENT LIFECYCLE:

1. CREATION:
   New segment created when previous rolls
   Files created: .log (empty), .index (pre-allocated), .timeindex
   Index pre-allocated to segment.index.bytes (default 10 MB)
   Pre-allocation: fallocate() syscall → reserves contiguous disk blocks

2. ACTIVE (writable):
   Only ONE segment per partition is active (the latest)
   Producers append to this segment
   File grows as batches are appended
   Index entries added every ~4 KB of log data

3. ROLLED (immutable):
   When active segment hits size/time limit → roll
   Old segment becomes immutable
   New empty segment becomes active
   Rolled segments: only read by consumers and replication

4. ELIGIBLE FOR DELETION:
   When segment's maxTimestamp < now - retention
   Or when partition size exceeds log.retention.bytes

5. MARKED FOR DELETION:
   Renamed: .log → .log.deleted, .index → .index.deleted
   Still readable for delete.delay (60s)

6. ACTUALLY DELETED:
   After delay: unlink() syscall → kernel deletes inode
   Disk blocks freed (eventually, after filesystem journal flush)

TIMELINE:
  ┌──────┐   ┌────────┐   ┌──────┐   ┌────────┐   ┌─────────┐
  │Create│──►│ Active │──►│ Roll │──►│Eligible│──►│ Delete  │
  │      │   │(append)│   │(close│   │(old    │   │(.deleted│
  │      │   │        │   │ file)│   │ enough)│   │→unlink) │
  └──────┘   └────────┘   └──────┘   └────────┘   └─────────┘
             seconds-days  instant    after         after
                                     retention     delay
```

---

## 30-SECOND REVISION BOX

```
PARTITION = directory of segments (.log + .index + .timeindex)
SEGMENT: active (append-only) → immutable → delete after retention
WRITE: append to page cache → no fsync (replication = durability)
READ: mmap index → binary search → sendfile() zero-copy → NIC
ZERO-COPY: sendfile() = page cache → NIC DMA, no userspace copy
PAGE CACHE: Kafka uses OS RAM, not JVM heap (small heap = more cache)
COMPRESSION: batch-level, stored compressed, broker doesn't decompress
INDEX: sparse offset index (every ~4KB), mmap'd, binary search
LOG COMPACTION: keep latest value per key, for changelog/state topics
SEQUENTIAL I/O: the foundation — append-only, read-ahead, no seek
```

---

**Prev: [[09_Internals-From-Bits-to-Broker]] | Next: [[11_Internals-Kafka-Replication-Consensus]]**
