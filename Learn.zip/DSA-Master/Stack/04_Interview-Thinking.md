# Stack — Interview Thinking

> **Permanent Recall:** In FAANG interviews, stack problems are identified by keywords ("next greater," "valid parentheses," "histogram") and solved by communicating the monotonic stack amortized O(n) argument clearly. This file covers identification, explanation strategy, and how to defend your complexity analysis.

---

## How to Identify Stack Problems

### Primary Triggers

| Trigger Phrase | Pattern | Confidence |
|----------------|---------|------------|
| "Next greater element" | Monotonic decreasing stack | Very high |
| "Next smaller element" | Monotonic increasing stack | Very high |
| "Previous greater/smaller" | Same, possibly reversed scan | Very high |
| "Valid parentheses" / "balanced brackets" | Simple stack (push/pop match) | Very high |
| "Largest rectangle in histogram" | Monotonic stack for boundaries | Very high |
| "Daily temperatures" / "days until warmer" | Monotonic decreasing stack | Very high |
| "Expression evaluation" / "calculator" | Operator stack + operand stack | High |
| "Remove k digits" / "smallest number" | Monotonic stack (greedy) | Medium-High |
| "Trapping rain water" | Can use stack (or two pointers) | Medium |
| "Asteroid collision" | Stack (simulate collisions) | High |
| "Decode string" / "nested" | Stack for nesting | High |

### Secondary Signals

- **"For each element, find..."** — suggests NGE/NSE pattern
- **"Contiguous" + "largest/smallest"** — histogram/rectangle
- **"Matching pairs"** — parentheses, brackets
- **"Nested structure"** — stack for depth
- **"Order matters"** — LIFO often relevant

---

## "I Need to Find Next Greater/Smaller" — The Trigger

When you hear this, immediately think:

```
1. Brute force: O(n²) — for each i, scan right until find greater/smaller
2. Monotonic stack: O(n) — each element enters and leaves stack at most once
3. Stack type: Next GREATER → decreasing stack
              Next SMALLER → increasing stack
4. Store: Indices (for result array and width calculations)
```

**Interview script:**  
"I'll use a monotonic stack. As I scan left to right, elements that haven't found their next greater yet stay in the stack. When a larger element arrives, it answers all smaller elements on top of the stack, then joins. Each element is pushed once and popped at most once, so it's O(n)."

---

## Monotonic Stack Explanation Strategy

### Step 1: State the brute force
"We could for each element scan right until we find a greater one — that's O(n²)."

### Step 2: Introduce the optimization
"We can do better with a stack. The key insight: when we see a larger element, it's the next greater for all smaller elements we've seen and not yet answered."

### Step 3: Explain the stack invariant
"The stack maintains indices in decreasing order of their values. So the top is always the smallest among those still waiting."

### Step 4: Defend O(n)
"Each index is pushed once. Each index is popped at most once when we find its answer. So total operations are O(n), even though we have a nested while loop."

### ASCII to draw on whiteboard

```
arr:  [2, 1, 4, 3, 5]
      Scan →  When 4 arrives, it answers 2 and 1.
      Stack (indices): [0,1] → 4 answers 1,0 → stack becomes [2]
```

---

## How to Communicate O(n) Despite Nested Loops

**Interviewer may ask:** "You have a while loop inside a for loop — isn't that O(n²)?"

**Answer:**
"The inner while loop doesn't run n times for each i. Each element is pushed onto the stack exactly once when we reach its index. Each element is popped at most once when we find its answer. So across the entire algorithm, we do at most n pushes and n pops — 2n operations total. That's O(n)."

**Amortized argument:**
"Think of it as each element 'paying' for its push and pop. No element pays more than twice. So total cost is O(n)."

---

## Decision Tree: Stack vs Other Structures

```
Need "next greater/smaller" for each element?
  → YES: Monotonic stack

Need to match open/close pairs (parentheses)?
  → YES: Stack

Need LIFO order (undo, backtrack)?
  → YES: Stack

Need FIFO order?
  → NO: Use Queue

Need random access or middle elements?
  → NO: Stack only has top

Need global min/max over all elements?
  → Consider Heap; for "min so far" in push order: Min Stack
```

---

## What to Say When Stuck

| Situation | Response |
|-----------|----------|
| Not sure if stack | "Let me try brute force first. For each element I'm scanning right... that suggests I could optimize with a stack that maintains 'unanswered' elements." |
| Wrong stack direction | "I used decreasing stack for next greater. If I needed next smaller, I'd use increasing stack." |
| Forgot to handle remaining | "After the loop, any indices left in the stack never found their answer — I'll set those to -1." |
| Off-by-one in width | "For histogram, the width is right - left - 1 because we exclude both boundaries." |

---

## Red Flags to Avoid

1. **Saying "stack" without specifying monotonic** — For NGE/NSE, say "monotonic stack"
2. **Storing values instead of indices** — You need indices for the result
3. **Not handling the remaining stack** — Elements left in stack have no answer
4. **Claiming O(n²)** — Defend O(n) with the amortized argument

---

## FINAL MEMORY COMPRESSION BLOCK

```
IDENTIFY:        "Next greater/smaller" → monotonic stack
EXPLAIN:         "Elements wait in stack; larger/smaller element answers them"
O(n) DEFENSE:    "Each element pushed once, popped once → 2n operations"
STACK TYPE:      Decreasing → NGE | Increasing → NSE
STORE:           Indices
REMAINING:       No answer → -1 or n
```
