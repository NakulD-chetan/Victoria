import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function sampleTree() {
  const nodes = [
    { id: 0, value: 50, left: 1, right: 2 },
    { id: 1, value: 30, left: 3, right: 4 },
    { id: 2, value: 70, left: 5, right: 6 },
    { id: 3, value: 20, left: 7, right: 8 },
    { id: 4, value: 40, left: 9, right: null },
    { id: 5, value: 60, left: null, right: 10 },
    { id: 6, value: 80, left: 11, right: 12 },
    { id: 7, value: 15, left: null, right: null },
    { id: 8, value: 25, left: null, right: null },
    { id: 9, value: 35, left: null, right: null },
    { id: 10, value: 65, left: null, right: null },
    { id: 11, value: 75, left: null, right: null },
    { id: 12, value: 90, left: null, right: null },
  ];
  const edges = [];
  nodes.forEach((n) => {
    if (n.left != null) edges.push([n.id, n.left]);
    if (n.right != null) edges.push([n.id, n.right]);
  });
  return { nodes, edges };
}

function parentMap(nodes) {
  const m = new Map([[0, null]]);
  nodes.forEach((n) => {
    if (n.left != null) m.set(n.left, n.id);
    if (n.right != null) m.set(n.right, n.id);
  });
  return m;
}

function generateSteps(tree, va, vb) {
  const { nodes, edges } = tree;
  const byVal = Object.fromEntries(nodes.map((n) => [n.value, n.id]));
  const idA = byVal[va];
  const idB = byVal[vb];
  const par = parentMap(nodes);
  const steps = [];

  const path = (start) => {
    const out = [];
    for (let x = start; x != null; x = par.get(x)) out.push(x);
    return out;
  };

  const pathA = path(idA);
  const pathB = path(idB);
  const setA = new Set(pathA);

  steps.push({
    caption: `Nodes ${va} and ${vb}: climb to root`,
    nodes, edges,
    nodeColors: { [idA]: 'current', [idB]: 'current' },
    stack: pathA.map((i) => nodes[i].value),
    queue: pathB.map((i) => nodes[i].value),
    result: [],
  });

  pathA.forEach((id, idx) => {
    steps.push({
      caption: `Path from ${va}: step ${idx + 1} → ${nodes[id].value}`,
      nodes, edges,
      nodeColors: Object.fromEntries(pathA.slice(0, idx + 1).map((x) => [x, 'visited'])),
      stack: pathA.slice(0, idx + 1).map((i) => nodes[i].value),
      queue: pathB.map((i) => nodes[i].value),
      result: [],
    });
  });

  let lca = null;
  pathB.forEach((id, idx) => {
    const hit = setA.has(id);
    if (hit && lca == null) lca = id;
    const colors = {};
    pathA.forEach((x) => { colors[x] = 'visited'; });
    pathB.slice(0, idx + 1).forEach((x) => { colors[x] = 'visited'; });
    if (hit) colors[id] = 'result';
    else colors[id] = 'current';
    steps.push({
      caption: hit
        ? `Path from ${vb} hits ${nodes[id].value} — lowest common ancestor`
        : `Path from ${vb}: step ${idx + 1} → ${nodes[id].value}`,
      nodes, edges,
      nodeColors: colors,
      stack: pathA.map((i) => nodes[i].value),
      queue: pathB.slice(0, idx + 1).map((i) => nodes[i].value),
      result: hit ? [nodes[id].value] : [],
    });
  });

  return steps;
}

export default function LCAVisualizer({ config }) {
  const treeRef = { current: sampleTree() };

  const onInit = useCallback((canvasRef) => {
    treeRef.current = sampleTree();
    const steps = generateSteps(treeRef.current, 35, 90);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'LCA by walking ancestor chains' });
    canvasRef.current?.setState({
      ...treeRef.current,
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'Lowest common ancestor',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
