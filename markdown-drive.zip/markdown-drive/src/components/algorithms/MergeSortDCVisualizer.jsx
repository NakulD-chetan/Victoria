import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SortingCanvasBase from './canvas-bases/SortingCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function makeSplitTree(lo, hi, depth, maxDepth = 5) {
  const nodes = [];
  const edges = [];
  const id = `s${lo}-${hi}`;
  nodes.push({ id, value: `${lo}–${hi}`, level: depth });
  if (lo >= hi || depth >= maxDepth) return { nodes, edges };
  const mid = Math.floor((lo + hi) / 2);
  const left = makeSplitTree(lo, mid, depth + 1, maxDepth);
  const right = makeSplitTree(mid + 1, hi, depth + 1, maxDepth);
  [...left.nodes, ...right.nodes].forEach((n) => nodes.push(n));
  [...left.edges, ...right.edges].forEach((e) => edges.push(e));
  edges.push([id, `s${lo}-${mid}`]);
  edges.push([id, `s${mid + 1}-${hi}`]);
  return { nodes, edges };
}

function generateSteps(arr) {
  const a = [...arr];
  const steps = [];
  function mergeSort(lo, hi) {
    if (lo >= hi) {
      steps.push({ type: 'base', lo, hi, array: [...a], treeView: makeSplitTree(lo, hi, 0) });
      return;
    }
    const mid = Math.floor((lo + hi) / 2);
    steps.push({
      type: 'divide',
      lo,
      mid,
      hi,
      array: [...a],
      treeView: makeSplitTree(lo, hi, 0),
    });
    mergeSort(lo, mid);
    mergeSort(mid + 1, hi);
    merge(lo, mid, hi);
  }
  function merge(lo, mid, hi) {
    const left = a.slice(lo, mid + 1);
    const right = a.slice(mid + 1, hi + 1);
    let i = 0;
    let j = 0;
    let k = lo;
    while (i < left.length && j < right.length) {
      steps.push({ type: 'compare', li: lo + i, ri: mid + 1 + j, lo, hi, array: [...a], treeView: null });
      if (left[i] <= right[j]) {
        a[k++] = left[i++];
      } else {
        a[k++] = right[j++];
      }
      steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a], treeView: null });
    }
    while (i < left.length) {
      a[k++] = left[i++];
      steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a], treeView: null });
    }
    while (j < right.length) {
      a[k++] = right[j++];
      steps.push({ type: 'place', k: k - 1, lo, hi, array: [...a], treeView: null });
    }
    steps.push({ type: 'merged', lo, hi, array: [...a], treeView: null });
  }
  mergeSort(0, a.length - 1);
  steps.push({ type: 'done', array: [...a], treeView: null });
  return steps;
}

function randomArray(n = 12) {
  return Array.from({ length: n }, () => Math.floor(Math.random() * 70) + 8);
}

export default function MergeSortDCVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomArray();
    useVisualizerStore.getState().setArray(arr);
    useVisualizerStore.getState().setSteps(generateSteps(arr));
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: `Divide & conquer merge sort, n=${arr.length}` });
    canvasRef.current?.setState({ array: arr, colors: {}, treeView: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const colors = {};
    if (step.type === 'divide') {
      for (let k = step.lo; k <= step.mid; k++) colors[k] = 'active';
      for (let k = step.mid + 1; k <= step.hi; k++) colors[k] = 'pivot';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Divide [${step.lo}..${step.mid}] | [${step.mid + 1}..${step.hi}]` });
      canvasRef.current?.setState({
        array: step.array,
        colors,
        treeView: step.treeView,
      });
      store.setArray(step.array);
      return;
    }
    if (step.type === 'base') {
      colors[step.lo] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Base case index ${step.lo}` });
      canvasRef.current?.setState({ array: step.array, colors, treeView: step.treeView });
      store.setArray(step.array);
      return;
    }
    canvasRef.current?.setState({ treeView: null });
    if (step.type === 'compare') {
      colors[step.li] = 'compare';
      colors[step.ri] = 'compare';
      store.incComparisons();
    } else if (step.type === 'place') {
      colors[step.k] = 'merge';
      for (let k = step.lo; k <= step.hi; k++) if (k !== step.k) colors[k] = 'active';
    } else if (step.type === 'merged') {
      for (let k = step.lo; k <= step.hi; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Merged [${step.lo}..${step.hi}]` });
    } else if (step.type === 'done') {
      for (let k = 0; k < step.array.length; k++) colors[k] = 'sorted';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: '✓ Sorted (divide & conquer)' });
    }
    store.setArray(step.array);
    canvasRef.current?.setState({ array: step.array, colors });
  }, []);

  return <AlgoVisualizer config={config} canvas={SortingCanvasBase} onInit={onInit} onStep={onStep} />;
}
