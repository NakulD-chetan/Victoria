# Indexes and Optimization — Tricks and Recognition

| Signal | Think |
|--------|--------|
| "Query is slow on large table" | Check EXPLAIN → missing index? seq scan? |
| "Write-heavy workload" | Fewer indexes; batch inserts; consider partitioning |
| "Reporting dashboard slow" | Materialized view or summary table |
| "SELECT *" | Bad habit; SELECT only needed cols → covering index possible |
| "ORDER BY slow" | Index on ORDER BY column or composite (WHERE + ORDER) |

---

*Next: [[08_Problem-List]]*
