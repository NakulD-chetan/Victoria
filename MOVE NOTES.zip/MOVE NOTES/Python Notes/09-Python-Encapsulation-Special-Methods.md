# Python Encapsulation and Special (Dunder) Methods

> *"We are all consenting adults"* — Python privacy by convention

Python has no `public/private` keywords — `_` and `__` conventions, `property`, and the rich dunder protocol. After [[08-Python-Inheritance-Polymorphism]], this file builds the Pythonic interface for objects.

---

## 1. Naming conventions — encapsulation hint

> **Definition:** Python uses **naming conventions** instead of access modifiers: no prefix means public; a single leading `_` signals internal use; a double leading `__` triggers **name mangling** on instances.

**Why we need it:** The language trusts programmers but still offers gentle boundaries and collision avoidance in subclasses without rigid compile-time privacy.

**Syntax:**
```python
self.public
self._internal
self.__mangled
```

| Style | What it means |
|-------|---------|
| `name` | **Public** — anyone can use it freely |
| `_name` | **Internal** — "please don't touch from outside" (convention, not enforced) |
| `__name` | **Name mangled** — Python renames it to `_ClassName__name` to avoid accidental override in child classes |

```python
class Bank:
    def __init__(self, bal):
        self.__balance = bal   # Python secretly renames this to _Bank__balance

    def get_balance(self):
        return self.__balance  # Inside the class, you can still use __balance normally

b = Bank(1000)
# b.__balance        # ERROR — can't access directly from outside
# b._Bank__balance   # 1000 — CAN access with mangled name (but don't do this)
b.get_balance()      # 1000 — proper way: use the method
```

**Watch Out!** You can still reach `__balance` from outside as `b._Bank__balance` — this is **not** security; it avoids **accidental clashes**.

---

## 2. `@property` recap — getters/setters

> **Definition:** **`@property`** exposes a method as a readable attribute; paired **`@name.setter`** runs when the attribute is assigned, so you can validate or compute without changing call sites.

**Why we need it:** You keep a simple `obj.field` API while evolving from a plain attribute to logic-backed storage—no noisy `get_field()` / `set_field()` everywhere.

**Syntax:**
```python
class ClassName:
    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value
```

```python
class Account:
    def __init__(self, owner, amount):
        self.owner = owner
        self._amount = amount

    @property
    def amount(self):
        return self._amount

    @amount.setter
    def amount(self, v):
        if v < 0:
            raise ValueError("negative")
        self._amount = v
```

**Interview Tip:** Keep attribute access stable — change the inside, keep the same API.

---

## 3. Container protocol — `__len__`, `__getitem__`

> **Definition:** The **container protocol** means implementing `__len__` for `len(obj)` and `__getitem__` for `obj[key]` (and optionally `__setitem__` / `__delitem__` for mutability).

**Why we need it:** Your types can feel like lists or mappings to callers and work with loops, indexing, and built-ins instead of ad-hoc accessor methods.

**Syntax:**
```python
class ClassName:
    def __len__(self):
        ...

    def __getitem__(self, key):
        ...
```

```python
class Bucket:
    def __init__(self):
        self._items = []

    def add(self, x):
        self._items.append(x)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, idx):
        return self._items[idx]

b = Bucket()
b.add(5)
len(b)     # 1 → __len__ makes len() work on your object
b[0]       # 5 → __getitem__ makes [] indexing work on your object
```

**Watch Out!** For a mutable sequence, add `__setitem__`, `__delitem__` too.

---

## 4. Iteration — `__iter__` / `__next__`

> **Definition:** An **iterator** implements `__next__` (returns the next item or raises `StopIteration`); an **iterable** implements `__iter__` to return a fresh iterator, which powers `for` loops and `iter()`.

**Why we need it:** Custom sequences and streams integrate with Python’s iteration protocol so you get lazy, memory-friendly loops without special-case syntax.

**Syntax:**
```python
class ClassName:
    def __iter__(self):
        return self  # or return other iterator

    def __next__(self):
        ...
        raise StopIteration
```

```python
class CountDown:
    def __init__(self, start):
        self.n = start

    def __iter__(self):
        return self

    def __next__(self):
        if self.n <= 0:
            raise StopIteration
        self.n -= 1
        return self.n + 1
```

Often `__iter__` returns a **generator** — [[12-Python-Iterators-Generators]].

---

## 5. Equality and hashing — `__eq__`, `__hash__`

> **Definition:** `__eq__` defines what `==` means for your type; `__hash__` returns an integer so instances can be keys in `dict` or elements in `set` when hashing is allowed.

**Why we need it:** Collections and algorithms assume consistent equality and hash contracts; Python exposes them as hooks so user types behave correctly in sets and dicts.

**Syntax:**
```python
class ClassName:
    def __eq__(self, other):
        ...

    def __hash__(self):
        return hash(...)
```

```python
class Point:
    __slots__ = ("x", "y")  # optional memory hint — [[16-Python-Advanced-Topics]]

    def __init__(self, x, y):
        self.x, self.y = x, y

    def __eq__(self, other):
        if not isinstance(other, Point):
            return NotImplemented
        return self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash((self.x, self.y))
```

**Watch Out!** After defining `__eq__`, default `__hash__` may become `None` — don't use mutable objects as `set` keys.

---

## 6. Context managers — `__enter__`, `__exit__`

> **Definition:** A **context manager** defines `__enter__` (run when entering `with`) and `__exit__` (run when leaving, with exception info) so setup and teardown pair reliably.

**Why we need it:** Resources like files, locks, and timers must close or release even when errors occur; `with` plus this protocol guarantees cleanup in one clear pattern.

**Syntax:**
```python
class ClassName:
    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        ...
        return False  # re-raise unless suppressing
```

```python
class Timer:
    def __enter__(self):
        import time
        self.t0 = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb):
        import time
        print("elapsed", time.perf_counter() - self.t0)
        return False  # don't suppress exceptions

with Timer():
    sum(range(10_000))
```

**Interview Tip:** For file-like resources prefer `with open()`; custom cleanup uses this RAII-style pattern.

---

## 7. Callable objects — `__call__`

> **Definition:** **`__call__`** lets instances be invoked like functions: `obj(...)` runs the instance’s `__call__` method with the given arguments.

**Why we need it:** You can pass around stateful “functions,” build functors, and wrap behavior in an object without losing the natural `f(x)` call style.

**Syntax:**
```python
class ClassName:
    def __call__(self, *args, **kwargs):
        ...
```

```python
class Adder:
    def __init__(self, n):
        self.n = n
    def __call__(self, x):     # __call__ makes the object CALLABLE like a function
        return x + self.n

plus3 = Adder(3)   # Creates object with n=3
plus3(10)          # 13 → calling the object like a function! (10 + 3)
```

---

## 8. `__bool__` — custom truthiness

> **Definition:** **`__bool__`** returns `True` or `False` and defines how your object behaves in boolean contexts (`if obj`, `while obj`, `bool(obj)`).

**Why we need it:** Collections and domain objects often have a natural “empty” or “meaningful” notion; customizing truthiness avoids awkward checks like `if len(x) > 0` everywhere.

**Syntax:**
```python
class ClassName:
    def __bool__(self):
        return ...
```

```python
class EmptyOK:
    def __init__(self, n): self.n = n
    def __bool__(self): return self.n != 0

if EmptyOK(0):
    print("no")
```

**Watch Out!** If there is no `__bool__`, `__len__` is used as fallback; if neither, default is True.

---

## 9. `__contains__` — `in` operator

> **Definition:** **`__contains__(self, item)`** defines membership: `item in obj` calls `obj.__contains__(item)` when present.

**Why we need it:** You can make `in` read naturally for bags, trees, or custom searches instead of exposing a separate `has()` or `find()` for the common case.

**Syntax:**
```python
class ClassName:
    def __contains__(self, item):
        return ...
```

```python
class Bag:
    def __init__(self, items): self.items = items
    def __contains__(self, x):
        return x in self.items
```

---

## 10. Comparison suite — total ordering helpers

> **Definition:** The **comparison suite** is the set of rich comparison methods (`__lt__`, `__le__`, `__gt__`, `__ge__`, `__eq__`, `__ne__`); **`functools.total_ordering`** can fill in the rest from `__eq__` plus one ordering method.

**Why we need it:** Sorting, `min`/`max`, and `sorted` rely on a consistent ordering; implementing every dunder by hand is repetitive, so the helper reduces boilerplate when appropriate.

**Syntax:**
```python
from functools import total_ordering

@total_ordering
class ClassName:
    def __eq__(self, other):
        ...

    def __lt__(self, other):
        ...
```

`functools.total_ordering` — define `__eq__` + one comparison and derive the rest — practical shortcut (watch performance / edge cases).

---

## Quick Memory Card

```
+------------------------------------------+
| ENCAPSULATION                             |
| - _ internal, __ name mangling           |
+------------------------------------------+
| PROPERTY                                  |
| - getter/setter without ugly syntax      |
+------------------------------------------+
| CONTAINER                                 |
| - __len__, __getitem__                   |
+------------------------------------------+
| ITERATION                                 |
| - __iter__ / __next__                    |
+------------------------------------------+
| EQ / HASH                                 |
| - set/dict keys need stable hash         |
+------------------------------------------+
| CONTEXT                                   |
| - __enter__ / __exit__                   |
+------------------------------------------+
| CALLABLE                                  |
| - __call__                               |
+------------------------------------------+
```

---

*Next: [[10-Python-Exception-Handling]]*
