import { memo, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Editor from '@monaco-editor/react';
import { useNewCanvasStore } from '../state/store';
import { SQL_LANGS, SQL_MONACO_LANG } from './widget-registry';
import { CODE_TEMPLATES } from './code-templates';
import { computeWidgetLayoutScale } from './widget-layout-scale';
import CodeLangDropdown from './CodeLangDropdown';

const DEFAULT_CHROME = '#1f1f1f';

const IconPlay = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <path d="M8 5v14l11-7-11-7z" />
  </svg>
);

const IconSquare = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <rect x="6" y="6" width="12" height="12" rx="1.5" />
  </svg>
);

const IconChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <polyline points="6 9 12 15 18 9" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconChevronUp = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <polyline points="18 15 12 9 6 15" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const IconX = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden>
    <line x1="18" y1="6" x2="6" y2="18" />
    <line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

function applyMonacoSurfaceTheme(monaco, editor, bgHex) {
  const bg = bgHex || DEFAULT_CHROME;
  monaco.editor.defineTheme('nc-code-surface', {
    base: 'vs-dark',
    inherit: true,
    rules: [],
    colors: {
      'editor.background': bg,
      'editorGutter.background': bg,
      'lineNumber.foreground': '#64748b',
      'editorLineNumber.activeForeground': '#94a3b8',
      'editorCursor.foreground': '#e2e8f0',
      'editor.lineHighlightBackground': '#2a2a2a',
      'editor.lineHighlightBorder': '#00000000',
    },
  });
  monaco.editor.setTheme('nc-code-surface');
  editor?.layout?.();
}

/**
 * Monaco-based compiler widget. Toolbar color (with Select + this widget
 * chosen) updates `chromeBg` + frame stroke — same flow as shapes.
 */
function SqlPadWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || { language: 'sqlite', code: CODE_TEMPLATES.sqlite, output: '', chromeBg: DEFAULT_CHROME };
  const lang = data.language || 'sqlite';

  const codeRef = useRef(data.code || '');
  codeRef.current = data.code || '';
  const [running, setRunning] = useState(false);
  const [output, setOutput] = useState(data.output || '');
  const [showOutput, setShowOutput] = useState(!!data.output);
  const [runStatus, setRunStatus] = useState('');
  const abortRef = useRef(null);
  const monacoMountRef = useRef(null);
  const chromeBg = data.chromeBg || DEFAULT_CHROME;
  const chromeBgRef = useRef(chromeBg);
  chromeBgRef.current = chromeBg;
  const frameStroke = element.style?.stroke || '#475569';
  const frameW = element.style?.strokeWidth ?? 1;
  const effectiveFrameStroke = (frameStroke === '#94a3b8' || frameStroke === '#475569')
    ? 'rgba(255,255,255,0.10)'
    : frameStroke;

  const layoutScale = useMemo(
    () => computeWidgetLayoutScale('code', element.w, element.h),
    [element.w, element.h],
  );

  const baseFontSize = Number(data.fontSize) > 0 ? Number(data.fontSize) : 13;
  const fontFamily = data.fontFamily
    || 'ui-monospace, SFMono-Regular, Menlo, monospace, Consolas, "Courier New", monospace';
  const monacoFont = Math.max(10, Math.round(baseFontSize * layoutScale));
  const editorOptions = useMemo(() => ({
    minimap: { enabled: false },
    fontSize: monacoFont,
    fontFamily,
    lineHeight: Math.round(monacoFont * 1.42),
    scrollBeyondLastLine: false,
    wordWrap: 'off',
    tabSize: 4,
    insertSpaces: true,
    automaticLayout: true,
    lineNumbers: 'on',
    fixedOverflowWidgets: true,
    renderLineHighlight: 'line',
    overviewRulerBorder: false,
    hideCursorInOverviewRuler: true,
    scrollbar: {
      verticalScrollbarSize: 6,
      horizontalScrollbarSize: 6,
      alwaysConsumeMouseWheel: false,
    },
    quickSuggestions: { other: true, comments: false, strings: true },
    quickSuggestionsDelay: 70,
    suggestOnTriggerCharacters: true,
    acceptSuggestionOnEnter: 'smart',
    acceptSuggestionOnCommitCharacter: true,
    tabCompletion: 'on',
    wordBasedSuggestions: 'currentDocument',
    suggestSelection: 'recentlyUsedByPrefix',
    parameterHints: { enabled: true },
    snippetSuggestions: 'top',
    inlineSuggest: { enabled: true },
    smoothScrolling: true,
    cursorSmoothCaretAnimation: 'on',
    cursorBlinking: 'smooth',
    bracketPairColorization: { enabled: true },
    guides: { bracketPairs: true, indentation: true },
    formatOnPaste: true,
    formatOnType: true,
    autoClosingBrackets: 'always',
    autoClosingQuotes: 'always',
    autoIndent: 'advanced',
    padding: {
      top: Math.max(4, Math.round(8 * layoutScale)),
      bottom: Math.max(4, Math.round(8 * layoutScale)),
    },
    suggestFontSize: Math.max(11, Math.round(12 * layoutScale)),
    suggestLineHeight: Math.max(18, Math.round(22 * layoutScale)),
  }), [monacoFont, fontFamily, layoutScale]);

  const save = useCallback((patch) => {
    commitElements((els) => els.map((e) => e.id === element.id
      ? { ...e, widgetData: { ...e.widgetData, ...patch } }
      : e));
  }, [commitElements, element.id]);

  const onChange = useCallback((val) => {
    codeRef.current = val || '';
  }, []);

  const onBlur = useCallback(() => {
    if (codeRef.current !== data.code) save({ code: codeRef.current });
  }, [save, data.code]);

  const onLang = useCallback((lang) => {
    const code = CODE_TEMPLATES[lang] || '';
    codeRef.current = code;
    save({ language: lang, code, output: '' });
    setOutput('');
    setShowOutput(false);
    setRunStatus('');
  }, [save]);

  const onRun = useCallback(async () => {
    if (running) {
      abortRef.current?.abort();
      setRunStatus('');
      return;
    }
    setRunning(true);
    setShowOutput(true);
    setOutput('Running…');
    setRunStatus('Running...');
    const controller = new AbortController();
    abortRef.current = controller;
    try {
      const res = await fetch('/api/sql/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ source_code: codeRef.current, language: lang, stdin: '' }),
        signal: controller.signal,
      });
      if (!res.ok) throw new Error(`Server error (${res.status})`);
      const result = await res.json();
      let out = '';
      if (result.compile_output) out += result.compile_output;
      if (result.stdout) out += result.stdout;
      if (result.stderr) out += (out ? '\n' : '') + result.stderr;
      if (!out && result.error) out = result.error;
      if (!out) out = 'No output';
      setOutput(out);
      setRunStatus(out.startsWith('Error') || out.startsWith('Compile') ? 'Error' : 'Done');
      save({ output: out, code: codeRef.current });
    } catch (err) {
      if (err.name !== 'AbortError') {
        const next = 'Error: ' + err.message;
        setOutput(next);
        setRunStatus('Error');
        save({ output: next, code: codeRef.current });
      } else {
        setOutput('');
      }
    } finally {
      setRunning(false);
      abortRef.current = null;
    }
  }, [running, lang, save]);

  const onDelete = useCallback(() => {
    commitElements((els) => els.map((e) => e.id === element.id ? { ...e, isDeleted: true } : e));
  }, [commitElements, element.id]);

  const handleEditorMount = useCallback((editor, monaco) => {
    monacoMountRef.current = { editor, monaco };
    applyMonacoSurfaceTheme(monaco, editor, chromeBgRef.current);
  }, []);

  useEffect(() => {
    const m = monacoMountRef.current;
    if (!m?.monaco || !m?.editor) return;
    applyMonacoSurfaceTheme(m.monaco, m.editor, chromeBgRef.current);
  }, [chromeBg]);

  useEffect(() => {
    const ed = monacoMountRef.current?.editor;
    if (!ed) return;
    ed.updateOptions({
      fontSize: monacoFont,
      fontFamily,
      lineHeight: Math.round(monacoFont * 1.42),
      padding: {
        top: Math.max(4, Math.round(8 * layoutScale)),
        bottom: Math.max(4, Math.round(8 * layoutScale)),
      },
      suggestFontSize: Math.max(11, Math.round(12 * layoutScale)),
      suggestLineHeight: Math.max(18, Math.round(22 * layoutScale)),
    });
    ed.layout();
  }, [layoutScale, monacoFont, fontFamily]);

  const runButtonLabel = running ? 'Stop' : 'Run';

  return (
    <div
      className="nc-code"
      style={{
        background: chromeBg,
        borderColor: effectiveFrameStroke,
        borderWidth: frameW,
        borderStyle: 'solid',
      }}
    >
      <div className="nc-widget-header nc-code__header" data-nc-drag-handle="1">
        <div className="nc-code__toolbar">
          <CodeLangDropdown value={lang} options={SQL_LANGS} onChange={onLang} />
          <div className="nc-code__toolbar-spacer" aria-hidden />
          <button
            type="button"
            className={`nc-code__runbtn${running ? ' is-running' : ''}`}
            onPointerDown={(event) => event.preventDefault()}
            onClick={onRun}
            title={runButtonLabel}
            aria-label={runButtonLabel}
          >
            {running ? <IconSquare /> : <IconPlay />}
            <span>{runButtonLabel}</span>
          </button>
        </div>
        <div className="nc-widget-header__actions">
          <button
            type="button"
            className="nc-code__toolbtn"
            onPointerDown={(event) => event.preventDefault()}
            onClick={() => setShowOutput((v) => !v)}
            title={showOutput ? 'Hide output' : 'Show output'}
            aria-label={showOutput ? 'Hide output' : 'Show output'}
          >
            {showOutput ? <IconChevronDown /> : <IconChevronUp />}
          </button>
          <button
            type="button"
            className="nc-widget-header__btn nc-code__close"
            onPointerDown={(event) => {
              event.preventDefault();
              event.stopPropagation();
              onDelete();
            }}
            onClick={(event) => {
              // Keyboard activation has no pointer-down event.
              if (event.detail === 0) onDelete();
            }}
            aria-label="Delete widget"
            title="Delete widget"
          >
            <IconX />
          </button>
        </div>
      </div>
      <div className="nc-code__editor" onBlurCapture={onBlur}>
        <Editor
          language={SQL_MONACO_LANG[lang] || 'sql'}
          value={data.code || ''}
          onChange={onChange}
          theme="vs-dark"
          onMount={handleEditorMount}
          options={editorOptions}
        />
      </div>
      {showOutput && (
        <div className="nc-code__output">
          <div className="nc-code__output-head">
            <span>Output</span>
            <button
              type="button"
              className="nc-widget-header__btn"
              onPointerDown={(event) => event.preventDefault()}
              onClick={() => setShowOutput(false)}
              aria-label="Hide output"
              title="Hide output"
            >
              <IconX />
            </button>
          </div>
          <pre className="nc-code__output-body">{output}</pre>
        </div>
      )}
    </div>
  );
}

export default memo(SqlPadWidgetImpl);
