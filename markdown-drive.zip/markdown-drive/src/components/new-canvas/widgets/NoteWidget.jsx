import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { useNewCanvasStore } from '../state/store';

function NoteWidgetImpl({ element }) {
  const commitElements = useNewCanvasStore((s) => s.commitElements);
  const data = element.widgetData || {};
  const [text, setText] = useState(data.text || '');
  const saveTimerRef = useRef(null);

  useEffect(() => {
    setText(data.text || '');
  }, [data.text]);

  const update = useCallback((patch) => {
    commitElements((els) => els.map((e) => e.id === element.id
      ? { ...e, widgetData: { ...e.widgetData, ...patch } }
      : e));
  }, [commitElements, element.id]);

  const onChange = useCallback((ev) => {
    const next = ev.currentTarget.value;
    setText(next);
    window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(() => update({ text: next }), 300);
  }, [update]);

  useEffect(() => () => window.clearTimeout(saveTimerRef.current), []);

  const onDelete = useCallback(() => {
    commitElements((els) => els.map((e) => e.id === element.id ? { ...e, isDeleted: true } : e));
  }, [commitElements, element.id]);

  const textColor = data.textColor;
  const fontFamily = data.fontFamily;
  const fontSize = Number(data.fontSize) > 0 ? Number(data.fontSize) : null;
  const noteColor = !data.color || data.color === '#fde68a' ? '#fefce8' : data.color;
  const noteTitle = data.title || '';

  return (
    <div
      className="nc-note"
      style={{
        ['--nc-note-bg']: noteColor,
        ['--nc-note-border']: element.style?.stroke || '#ca8a04',
        ['--nc-note-border-width']: `${element.style?.strokeWidth ?? 1.5}px`,
      }}
    >
      <div className="nc-widget-header nc-note__header" data-nc-drag-handle="1">
        <span className="nc-widget-header__label">Note</span>
        <button
          type="button"
          className="nc-note__close"
          onClick={onDelete}
          aria-label="Delete note"
          title="Remove note"
        >
          ×
        </button>
      </div>
      {noteTitle ? (
        <div className="nc-note__title">
          {noteTitle}
        </div>
      ) : null}
      <textarea
        className="nc-note__text"
        value={text}
        placeholder="Type your notes here..."
        onChange={onChange}
        spellCheck={false}
        style={{
          ...(textColor ? { color: textColor } : {}),
          ...(fontFamily ? { fontFamily } : {}),
          ...(fontSize ? { fontSize: `calc(${fontSize}px / 13 * 1em)` } : {}),
        }}
      />
    </div>
  );
}

export default memo(NoteWidgetImpl);
