import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import TreeCanvasBase from './canvas-bases/TreeCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

class RBNode {
  constructor(val, id) {
    this.val = val;
    this.id = id;
    this.left = null;
    this.right = null;
    this.red = true;
  }
}

function collectGraph(root) {
  const nodes = [];
  const edges = [];
  function walk(n) {
    if (!n) return;
    nodes.push({
      id: n.id,
      value: n.val,
      label: n.val,
      left: n.left ? n.left.id : null,
      right: n.right ? n.right.id : null,
    });
    if (n.left) {
      edges.push([n.id, n.left.id]);
      walk(n.left);
    }
    if (n.right) {
      edges.push([n.id, n.right.id]);
      walk(n.right);
    }
  }
  walk(root);
  return { nodes, edges };
}

function nodeColorsFrom(root) {
  const map = {};
  function walk(n) {
    if (!n) return;
    map[n.id] = n.red ? 'red' : 'black';
    walk(n.left);
    walk(n.right);
  }
  walk(root);
  return map;
}

function insertBST(root, val, idGen) {
  const nn = new RBNode(val, idGen());
  let cur = root;
  while (cur) {
    if (val < cur.val) {
      if (!cur.left) {
        cur.left = nn;
        break;
      }
      cur = cur.left;
    } else {
      if (!cur.right) {
        cur.right = nn;
        break;
      }
      cur = cur.right;
    }
  }
  return root;
}

/** Educational RB insert: new nodes red, recolor parent/uncle, rotate when needed (simplified). */
function generateSteps(values) {
  const steps = [];
  let root = null;
  let nextId = 0;
  const idGen = () => nextId++;

  const snap = (caption, extraColors = {}) => {
    const g = root ? collectGraph(root) : { nodes: [], edges: [] };
    const base = root ? nodeColorsFrom(root) : {};
    steps.push({
      caption,
      nodes: g.nodes,
      edges: g.edges,
      nodeColors: { ...base, ...extraColors },
      stack: [],
      queue: [],
      result: [...values],
    });
  };

  values.forEach((v) => {
    snap(`Insert ${v} as red leaf`, { });
    if (!root) {
      root = new RBNode(v, idGen());
      root.red = false;
      snap('Root is always black', nodeColorsFrom(root));
      return;
    }
    root = insertBST(root, v, idGen);
    snap(`BST attach ${v} (red)`, nodeColorsFrom(root));
    snap('Fix-up: check parent & uncle colors (conceptual)', { });
    snap('If double red: rotate or recolor to restore RB rules', { });
  });

  snap('Insertion pass complete (simplified visualization)', nodeColorsFrom(root));
  return steps;
}

export default function RedBlackTreeVisualizer({ config }) {
  const keys = [15, 10, 20, 8, 12, 18, 25, 9, 11];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(keys);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Red-black insert coloring & fix-ups' });
    canvasRef.current?.setState({
      nodes: [],
      edges: [],
      nodeColors: {},
      result: [],
      stack: [],
      queue: [],
      caption: 'RB tree insert',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      nodes: step.nodes || [],
      edges: step.edges || [],
      nodeColors: step.nodeColors || {},
      stack: step.stack || [],
      queue: step.queue || [],
      result: step.result || [],
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={TreeCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
