# Diagnosing Slow Jobs — Problem List

> **20 production-style debug scenarios.** For each: read the symptoms, propose the most likely cause and the fix.

---

## 10 MUST-DO Scenarios

| # | Symptom                                                               | Most Likely Cause       | First Fix                              |
|---|-----------------------------------------------------------------------|-------------------------|----------------------------------------|
| 1 | Stage Summary: Min 1s, Max 30s, Median 1.5s                            | Data skew                | AQE skew join / salt                   |
| 2 | Spill (Memory) 8 GB, Spill (Disk) 2 GB                                  | Execution memory tight  | ↑ executor.memory / repartition        |
| 3 | GC Time = 60% of Task Time                                              | Heap pressure / cache   | Reduce cache; use G1GC                 |
| 4 | One executor Dead, others Alive                                         | OOM                     | ↑ memory + memoryOverhead              |
| 5 | Tiny dim table (5 MB) → SortMergeJoin in SQL tab                       | Plan miss                | `broadcast(dim)`                       |
| 6 | 200 tasks for 50 MB total data                                          | Wrong shuffle partitions| `shuffle.partitions = 8`                |
| 7 | `df.cache()` shows 18/24 cached, others evicted                         | Memory tight + cache    | `MEMORY_AND_DISK` or trim columns      |
| 8 | `df.show()` shows 5 showString rows                                     | executeTake loop        | `limit.initialNumPartitions = P`       |
| 9 | Plan has `PushedFilters: []`                                             | No pushdown              | Avoid UDF in filter                    |
|10 | Driver crashes after `df.collect()`                                      | Driver OOM               | Replace collect with write             |

---

## Complete 20-Scenario Progression

### Easy (1–6) — Single-Cause Symptoms

| # | Symptom                                                           | Cause                          | Fix                                       |
|---|-------------------------------------------------------------------|--------------------------------|-------------------------------------------|
| 1 | Stage spread: Max/Median > 10                                      | Skew                           | Salt / broadcast / AQE skewJoin           |
| 2 | Spill > 0 on every stage                                           | Tight memory                    | ↑ memory or shuffle partitions            |
| 3 | GC time 50%                                                         | Heap pressure                   | Reduce cache, G1GC                        |
| 4 | Cached partitions 18/24                                              | Eviction                        | `MEMORY_AND_DISK`, smaller cache          |
| 5 | 1 executor dead                                                       | OOM                              | Bigger executor.memory + overhead         |
| 6 | 200 tasks for 50MB                                                    | Default shuffle partitions     | Lower partitions                          |

### Medium (7–14) — Multi-Cause Diagnosis

| # | Symptom                                                                          | Likely Cause                  | Fix                                            |
|---|----------------------------------------------------------------------------------|-------------------------------|------------------------------------------------|
| 7 | Skew + spill + high GC simultaneously                                             | Hot key + memory tight         | Broadcast small side; salt; ↑ memory          |
| 8 | Pipeline 2x slower after Spark 3.2 upgrade                                         | AQE on by default              | Verify; tune AQE configs                      |
| 9 | `show()` suddenly creates 5 jobs                                                   | Filtered rows are very sparse  | `limit.initialNumPartitions = P`               |
|10 | Stage 0 fast, Stage 1 slow, Stage 2 fast                                            | Mid-pipeline shuffle / skew    | Look at Stage 1 metrics                        |
|11 | `cache()` works in dev but not prod                                                  | Bigger prod data               | `MEMORY_AND_DISK`                              |
|12 | Plan shows `Cartesian` operator                                                       | Missing equi-join              | Fix join condition                             |
|13 | `BroadcastExchange` size = 200 MB                                                     | Broadcast too large            | Increase threshold OR don't broadcast           |
|14 | Multiple back-to-back `Exchange` in plan                                              | Catalyst couldn't combine      | Inspect transformations; cache mid-plan          |

### Hard (15–20) — Production Incidents

| # | Symptom                                                                                    | Likely Cause                              | Fix                                                          |
|---|--------------------------------------------------------------------------------------------|--------------------------------------------|--------------------------------------------------------------|
|15 | YARN container killed; `Exit code 137`                                                      | Container OOM (not heap OOM)              | ↑ memoryOverhead                                              |
|16 | Job times out at 24h on streaming                                                            | Deadlock or skew                           | Check streaming UI; force restart                             |
|17 | Pipeline runs fine standalone, fails in shared cluster                                       | Resource contention / preemption          | Adjust cores, reservations                                    |
|18 | Cache gives wrong results occasionally                                                        | Lineage with non-deterministic ops         | Make deterministic or `localCheckpoint`                       |
|19 | One stage shows shuffle read 0 but takes 30 min                                                | Pulled cached data; cache evicted partially| Re-cache with right level                                     |
|20 | Pipeline gets steadily slower over hours                                                       | Driver OOM creep / shuffle GC              | Reset; reduce cache; check `spark.cleaner.*`                 |

---

## Strategy Notes

### Scenario 1 — Skew Detection

```
Open Stage page:
  Summary Metrics > Duration:
    Min  P25  P50  P75  Max
    1s   1.2s 1.5s 2s   30s    <- Max/Median = 20

Action:
  - Click Tasks tab.
  - Sort by Duration desc.
  - Inspect Shuffle Read of slowest task vs others.
  - If huge -> skewed partition.

Fix priority:
  1) broadcast(small) if join
  2) AQE skewJoin
  3) salt
  4) repartition with derived key
```

### Scenario 2 — Spill Diagnosis

```
Stage page:
  Spill (Memory): 8 GB    -> uncompressed in-memory bytes spilled
  Spill (Disk):    2 GB   -> compressed serialized bytes on disk

Read together:
  spill_ratio = 2 GB / shuffle_read_total
  > 0.1 -> non-trivial; aim to eliminate

Fix priority:
  1) df.repartition(N*2) before the shuffle -> smaller per-task memory
  2) ↑ spark.executor.memory
  3) tune spark.memory.fraction
```

### Scenario 7 — Triple Trouble

```
Triple symptom: skew + spill + GC

Approach:
  - Skew is usually the root cause; fix it first.
  - With smaller, even partitions, both spill and GC often disappear.
  - Sequence:
      1) broadcast / salt
      2) verify spill goes to 0
      3) verify GC ratio drops
```

### Scenario 9 — Show Sudden Slowness

```
Symptom:    df.show() creates many jobs and takes 30s.
Cause:      filter or sort produced sparse partitions; executeTake loops.
Verify:     Open Jobs tab; count showString rows.
Fix:        spark.conf.set("spark.sql.limit.initialNumPartitions",
                                                      str(num_shuffle_partitions))
```

### Scenario 15 — Container OOM (137)

```
Symptom:    "Exit code 137" in stderr; executor lost.
Cause:      Container memory (heap + overhead) exceeded.
Fix:
  --conf spark.executor.memory=4g
  --conf spark.executor.memoryOverhead=2g     (default ~10% only)
```

### Scenario 18 — Wrong Cache Results

```
Cause: cache() over a non-deterministic plan (uses rand(), now(), etc.)
       Different action invocations recompute differently.
Fix: localCheckpoint() to materialize a single, reproducible snapshot.
```

---

## Decision Tree (Print and Pin)

```
Slow job?
  |
  +-- Open Jobs -> find slow job
  +-- Open Stages of that job -> find slow stage
  +-- Open Stage Summary Metrics
        |
        +-- Max >> Median? --> SKEW
        +-- Spill > 0?      --> MEMORY TIGHT
        +-- GC > 10%?       --> HEAP PRESSURE
        +-- Big shuffle?    --> Inspect SQL tab
        +-- Failed tasks?   --> OOM (Executors tab)

Each path leads to a specific fix table above.
```

---

## Common "Why is this slow?" Lookup Table

| You Observe...                                                | Most Likely Cause     | Fix Section |
|--------------------------------------------------------------|------------------------|-------------|
| Max task time > 10x Median                                     | Skew                   | Section 1   |
| Spill (memory) or (disk) > 0                                   | Spill                  | Section 2   |
| GC time > 10% of total                                         | GC                     | Section 3   |
| Executor Status = Dead                                          | OOM                    | Section 4   |
| Many "(N skipped)" in Jobs tab                                  | Healthy reuse           | Pattern 5   |
| Pipeline slows over time                                         | Cache eviction          | Pattern 7   |
| `show()` makes many jobs                                         | executeTake loop        | Pattern 3   |
| Cache empty after `cache()`                                       | No action triggered     | Pattern 5   |
| `PushedFilters: []`                                              | No predicate pushdown   | Pattern 6   |
| Cartesian operator in plan                                       | Bad join                | Pattern 6   |

---

## Cross-Reference

| Topic                                              | Pattern |
|----------------------------------------------------|---------|
| What "skipped" really means                         | 05      |
| Reading Summary Metrics for skew                    | 04      |
| Confirming broadcast in plan                         | 06      |
| Adjusting executor memory                            | 07      |
| Action → job count predictions                       | 02      |
| `show()` job count                                   | 03      |

---

## Study Plan

### Day 1 — Easy
- Scenarios 1–6. Run a controlled bad pipeline; observe each symptom.

### Day 2 — Medium
- Scenarios 7–14. Combine multiple villains; practice prioritizing fixes.

### Day 3 — Production
- Scenarios 15–20. Set up small YARN/k8s cluster (or use docker-spark) and intentionally break it.

### Day 4 — Interview Prep
- Practice the verbatim answer in the theory file.
- Walk through 3 different scenarios end-to-end.

---

## Final Revision Box

```
4 VILLAINS  ->  Skew, Spill, GC, OOM
WORKFLOW    ->  Jobs -> Stages -> Task Summary -> Executors -> SQL

SKEW        ->  Max > 10x Median  -> broadcast / salt / AQE skewJoin
SPILL       ->  Spill > 0         -> ↑ memory OR repartition
GC          ->  GC > 10% time     -> reduce cache / G1GC
OOM         ->  Dead executor     -> ↑ memory + memoryOverhead

PLAN ISSUES ->  PushedFilters: []     -> rewrite filter
                Cartesian              -> fix join condition
                Tiny SMJ               -> add broadcast hint
                200 tasks tiny data    -> ↓ shuffle.partitions

GOLDEN RULE ->  "Always read Summary Metrics first.
                 Max/Median tells you 80% of the story."
```
