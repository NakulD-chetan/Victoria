import { useState, useEffect } from 'react';
import { dbService } from '../firebase';

export default function ReferralPanel({ user, onClose }) {
  const [referralCode, setReferralCode] = useState('');
  const [stats, setStats] = useState(null);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.id) return;
    const code = `INK-${user.id.slice(0, 6).toUpperCase()}`;
    setReferralCode(code);

    (async () => {
      try {
        const existing = await dbService.getReferral(code);
        if (existing) {
          setStats(existing);
        } else {
          await dbService.saveReferral(user.id, code);
          setStats({ signups: 0, earnings: 0 });
        }
      } catch { setStats({ signups: 0, earnings: 0 }); }
      setLoading(false);
    })();
  }, [user]);

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const shareLink = `${window.location.origin}?ref=${referralCode}`;

  const shareOptions = [
    {
      name: 'WhatsApp',
      icon: '💬',
      url: `https://wa.me/?text=${encodeURIComponent(`Check out InkDrop - the best markdown reader! Use my code ${referralCode} for 20% off Pro: ${shareLink}`)}`,
    },
    {
      name: 'Twitter',
      icon: '🐦',
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(`I use InkDrop for reading markdown files. Try it out! Referral: ${referralCode}`)}&url=${encodeURIComponent(shareLink)}`,
    },
    {
      name: 'LinkedIn',
      icon: '💼',
      url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareLink)}`,
    },
    {
      name: 'Email',
      icon: '📧',
      url: `mailto:?subject=${encodeURIComponent('Try InkDrop')}&body=${encodeURIComponent(`Hey! I've been using InkDrop to manage my markdown files. Use my code ${referralCode} for 20% off Pro!\n\n${shareLink}`)}`,
    },
  ];

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="referral-panel">
        <div className="referral-panel__header">
          <h2>Refer & Earn</h2>
          <button className="modal__close" onClick={onClose}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="referral-panel__hero">
          <div className="referral-panel__icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
            </svg>
          </div>
          <h3>Share InkDrop, Earn Rewards</h3>
          <p>Earn 20% commission for every friend who upgrades to Pro</p>
        </div>

        <div className="referral-panel__code-section">
          <label>Your Referral Code</label>
          <div className="referral-panel__code-box">
            <span className="referral-panel__code">{referralCode}</span>
            <button className={`referral-panel__copy ${copied ? 'referral-panel__copy--done' : ''}`} onClick={copyCode}>
              {copied ? 'Copied!' : 'Copy'}
            </button>
          </div>
        </div>

        {stats && (
          <div className="referral-panel__stats">
            <div className="referral-panel__stat">
              <span className="referral-panel__stat-value">{stats.signups || 0}</span>
              <span className="referral-panel__stat-label">Referrals</span>
            </div>
            <div className="referral-panel__stat">
              <span className="referral-panel__stat-value">{'\u20B9'}{(stats.signups || 0) * 20}</span>
              <span className="referral-panel__stat-label">Earned</span>
            </div>
          </div>
        )}

        <div className="referral-panel__share">
          <label>Share via</label>
          <div className="referral-panel__share-grid">
            {shareOptions.map(opt => (
              <a key={opt.name} href={opt.url} target="_blank" rel="noopener noreferrer" className="referral-panel__share-btn">
                <span>{opt.icon}</span>
                <span>{opt.name}</span>
              </a>
            ))}
          </div>
        </div>

        <div className="referral-panel__link-section">
          <label>Share Link</label>
          <div className="referral-panel__link-box">
            <input readOnly value={shareLink} />
            <button onClick={() => { navigator.clipboard.writeText(shareLink); }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
