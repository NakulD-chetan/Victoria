# Stack — Common Mistakes

> **Permanent Recall:** The top 5 stack mistakes in FAANG interviews: (1) popping from empty stack, (2) wrong monotonic direction, (3) storing values instead of indices, (4) forgetting remaining elements after loop, (5) off-by-one in result/width. Avoid these to pass.

---

## 1. Popping from Empty Stack

### The Mistake
```python
# WRONG
while stack and arr[i] > arr[stack[-1]]:
    idx = stack.pop()
    result[idx] = arr[i]
# Forgot to check stack empty before accessing stack[-1] in some variants
```

```python
# WRONG — accessing stack[-1] when stack might be empty
while arr[i] > arr[stack[-1]]:  # IndexError if stack empty!
    idx = stack.pop()
```

### The Fix
**Always check `stack` (or `!stack.empty()`) before accessing top.**

```python
# CORRECT
while stack and arr[i] > arr[stack[-1]]:
    idx = stack.pop()
    result[idx] = arr[i]
```

```cpp
// CORRECT
while (!stack.empty() && arr[i] > arr[stack.back()]) {
    int idx = stack.back();
    stack.pop_back();
    result[idx] = arr[i];
}
```

### When It Happens
- First few iterations when stack is empty
- All elements in array are same (nothing gets popped, but if logic is inverted)
- Edge case: single element array

---

## 2. Wrong Monotonic Direction

### The Mistake

| Goal | Wrong Stack | Correct Stack |
|------|-------------|---------------|
| Next **Greater** Element | Increasing (pop when smaller) | **Decreasing** (pop when larger) |
| Next **Smaller** Element | Decreasing (pop when larger) | **Increasing** (pop when smaller) |

```python
# WRONG: Next Greater Element with INCREASING stack
while stack and arr[i] < arr[stack[-1]]:  # Pop when smaller — wrong!
    idx = stack.pop()
    result[idx] = arr[i]
```

```python
# CORRECT: Next Greater Element with DECREASING stack
while stack and arr[i] > arr[stack[-1]]:  # Pop when larger — correct
    idx = stack.pop()
    result[idx] = arr[i]
```

### Memory Aid
- **Next Greater** → we want someone **bigger** → stack keeps **smaller** (decreasing)
- **Next Smaller** → we want someone **smaller** → stack keeps **larger** (increasing)

---

## 3. Storing Values Instead of Indices

### The Mistake
```python
# WRONG — we store values
stack = []
for i in range(n):
    while stack and arr[i] > stack[-1]:
        val = stack.pop()
        # Which index had value val? We don't know! Can't write to result.
```

### The Fix
**Always store indices.** You need them for:
- Writing to `result[idx]`
- Computing width: `right - left - 1` (in histogram)
- Handling duplicates (values can repeat, indices are unique)

```python
# CORRECT
stack = []  # indices
for i in range(n):
    while stack and arr[i] > arr[stack[-1]]:
        idx = stack.pop()
        result[idx] = arr[i]  # or i
    stack.append(i)
```

---

## 4. Forgetting Remaining Elements in Stack After Loop

### The Mistake
```python
# WRONG — never process remaining stack
for i in range(n):
    while stack and arr[i] > arr[stack[-1]]:
        idx = stack.pop()
        result[idx] = arr[i]
    stack.append(i)
return result  # result[idx] for remaining indices is still -1... 
# Actually if we init result = [-1]*n, we're OK. But for "next smaller INDEX" 
# we might need result[idx] = n. Check problem spec!
```

**For "next smaller index" (e.g., histogram right boundary):**  
If we don't set `right[idx] = n` for remaining indices, we get wrong width.

```python
# For histogram: remaining stack elements have NO next smaller to the right
# So their "right boundary" = n (past the array)
while stack:
    idx = stack.pop()
    right[idx] = n  # Must do this!
```

### The Fix
- **Next Greater/Smaller value:** If `result` initialized to `-1`, remaining elements are often correct.
- **Next Greater/Smaller index:** Remaining must get `n` (or `-1` per problem).
- **Always explicitly handle** remaining stack in your mental model.

---

## 5. Off-by-One in Result Array or Width

### The Mistake

**Histogram width:**
```python
# WRONG
width = right[i] - left[i]  # Off by one! Excludes one bar.
```

**Correct:** Width = number of bars between left and right (exclusive).  
`right[i]` = index of next smaller (exclusive).  
`left[i]` = index of prev smaller (exclusive).  
So width = `right[i] - left[i] - 1`.

```python
# CORRECT
width = right[i] - left[i] - 1
area = heights[i] * width
```

**Index vs 0-based:**
- Some problems want "1-based index" for answer — convert at end.
- "Days until warmer" = `i - j` (current index - stored index), not `i - j - 1`.

---

## 6. Other Common Mistakes

| Mistake | Fix |
|---------|-----|
| Using `>=` instead of `>` for strict NGE | Use `>` so equal elements don't "answer" each other (unless problem says otherwise) |
| Using `>` instead of `>=` for histogram | For "previous smaller," use `>=` so equal height extends boundary |
| Min stack: pushing when `val < min` instead of `val <= min` | Use `<=` so duplicates work; otherwise pop fails |
| Parentheses: not checking stack empty before pop | `if not stack: return False` |
| Parentheses: not checking stack empty at end | `return len(stack) == 0` |
| Infix: wrong precedence for `^` (right-associative) | Handle right-associative separately |

---

## Checklist Before Submitting

- [ ] Empty stack check before `stack[-1]` or `stack.back()`
- [ ] Correct monotonic direction (decreasing for NGE, increasing for NSE)
- [ ] Storing indices, not values
- [ ] Remaining stack elements handled (e.g., right[idx]=n for histogram)
- [ ] Width = right - left - 1 (for histogram)
- [ ] Result array initialized (e.g., -1 for NGE)

---

## FINAL MEMORY COMPRESSION BLOCK

```
1. EMPTY CHECK:    while stack and ... (always first)
2. DIRECTION:     NGE → decreasing (>); NSE → increasing (<)
3. STORE:         Indices, never just values
4. REMAINING:     Process stack after loop (right[idx]=n for histogram)
5. WIDTH:         right - left - 1 for histogram
6. EQUAL:         NGE use >; histogram prev smaller use >=
```
