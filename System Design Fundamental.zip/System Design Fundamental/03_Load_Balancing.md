# Load Balancing — Traffic Ko Barabari Se Baanto

> **Load Balancer = Traffic police jo decide kare ki kaun sa request kis server pe jaaye**
> Bina LB ke ek server pe sara load — server fat jaayega!

---

## Table of Contents
1. [Load Balancer Kya Hai?](#load-balancer-kya-hai)
2. [Kyu Zaroori Hai?](#kyu-zaroori-hai)
3. [Load Balancing Algorithms](#load-balancing-algorithms)
4. [Layer 4 vs Layer 7](#layer-4-vs-layer-7)
5. [Health Checks](#health-checks)
6. [High Availability](#high-availability)
7. [Software vs Hardware LB](#software-vs-hardware-lb)
8. [Session Persistence](#session-persistence)
9. [SSL Termination](#ssl-termination)
10. [Global Server Load Balancing](#global-server-load-balancing)
11. [Common Mistakes & Interview Qs](#common-mistakes--interview-qs)

---

## Load Balancer Kya Hai?

### Core Concept
Load Balancer ek **traffic police** jaisa hai — jo incoming requests ko multiple servers ke beech **barabari se distribute** karta hai.

```
                    [Client Requests]
                           |
                           v
                    +--------------+
                    | Load Balancer |
                    +------+-------+
                           |
         +-----------------+-----------------+
         |                 |                 |
         v                 v                 v
    [Server 1]        [Server 2]        [Server 3]
```

### How It Works
- Client sirf LB ka address jaanta hai
- LB har request ko kisi ek backend server ko forward karta hai
- Server capacity, health, algorithm ke hisaab se decision hota hai

### Real World Example
**Bank ke counter:** 1 line mein log khade, 4 counters khule — manager sabko ek ek karke different counters pe bhejta hai. Yeh hi load balancing hai!

### Quick Recall
- LB = Traffic distributor
- Single point of entry for clients
- Backend servers invisible to client

---

## Kyu Zaroori Hai?

### Core Concept
**Single Server Problem:** Ek server pe 10,000 requests aayein toh?
- CPU 100% → slow response
- Memory full → crash
- Network saturated → timeout

### How It Works
```
BINA LOAD BALANCER:
[10K Users] -----> [1 Server] = 💥 CRASH

LOAD BALANCER KE SAATH:
[10K Users] -----> [LB] -----> [S1] [S2] [S3] [S4] = ✅ Happy
                     |          2.5K  2.5K  2.5K  2.5K each
```

### Benefits Table
| Benefit | Matlab |
|---------|--------|
| **Scalability** | Server add karo, load auto-distribute |
| **Availability** | Ek server fail = baaki kaam karte rahenge |
| **Performance** | Load divide = fast response |
| **Maintenance** | Server down karo bina downtime ke |

### 1 Minute Recall Block
> Load balancing = traffic divide karna multiple servers pe taaki koi ek overload na ho. Scalability + Availability dono milte hain.

### 5 Bullet Memory Hooks
- Single server = bottleneck
- LB = traffic police
- Horizontal scaling ka foundation
- Zero downtime maintenance possible
- High availability ka first step

---

## Load Balancing Algorithms

### 1. Round Robin (Ek Ek Karke)

**Core Concept:** Sabko ek ek karke bhejo — S1, S2, S3, S1, S2, S3...

```
Request 1 → S1, Request 2 → S2, Request 3 → S3, Request 4 → S1...
```

**When to use:** Sab servers same capacity ke hon

**Common Interview Trap:** Round Robin **connection-based** ya **request-based** ho sakta hai — clarify karo!

---

### 2. Weighted Round Robin

**Core Concept:** Strong servers ko zyada load do

| Server | Weight | Matlab |
|--------|--------|--------|
| S1 | 5 | 5 requests |
| S2 | 3 | 3 requests |
| S3 | 2 | 2 requests |

Sequence: S1,S1,S1,S1,S1, S2,S2,S2, S3,S3...

**Real World:** Old server = weight 1, New powerful server = weight 5

---

### 3. Least Connections

**Core Concept:** Jis server pe sabse kam active connections hon, usko next request do

```
S1: 100 connections (busy)
S2: 20 connections  ← Next request yahan
S3: 150 connections (busy)
```

**When to use:** Long-lived connections (WebSocket, gaming, streaming)

**Common Interview Trap:** Round Robin vs Least Connections — **variable request duration** mein Least Connections better!

---

### 4. Least Response Time

**Core Concept:** Jis server ka response time sabse kam hai, usko bhejo

- Response time = server processing + network latency
- Fastest server gets next request

**When to use:** Response times vary a lot across servers

---

### 5. IP Hash (Sticky Sessions)

**Core Concept:** Same client IP = Same server (consistency)

```
hash(client_ip) % num_servers = server_index
```

**Pros:** Session data same server pe rehta hai
**Cons:** Uneven distribution — kuch IPs zyada requests bhejte hain

---

### 6. Consistent Hashing

**Core Concept:** Server add/remove hone pe minimal redistribution

```
        [Hash Ring]
             0
         S3      S1
            \   /
             S2
    Key "user123" → hash → ring pe point → clockwise nearest server
```

**Why better than IP Hash:** Server add/remove pe sirf 1/N keys move hote hain (N = server count)

### Algorithms Comparison Table
| Algorithm | Use Case | Pros | Cons |
|-----------|----------|------|------|
| Round Robin | Equal servers | Simple, fair | Ignores server load |
| Weighted RR | Unequal capacity | Flexible | Manual weight tuning |
| Least Connections | Long connections | Handles variable load | Connection count overhead |
| Least Response Time | Variable latency | Adaptive | Measurement overhead |
| IP Hash | Sticky sessions | Session affinity | Uneven distribution |
| Consistent Hash | Distributed cache | Minimal rebalancing | Complex |

### 1 Minute Recall Block
> Round Robin = simple rotation. Least Connections = busy servers avoid. IP Hash = same client same server. Consistent Hash = cache scaling.

### 5 Bullet Memory Hooks
- RR = ek ek karke
- Weighted = strong ko zyada
- Least Conn = kam connections wala
- IP Hash = sticky sessions
- Consistent Hash = cache ke liye best

---

## Layer 4 vs Layer 7

### Core Concept
OSI model ke different layers pe LB kaam kar sakta hai.

### Layer 4 (Transport Layer) — L4 LB

**Kya dekhta hai:** IP + Port only
- TCP/UDP packets
- No application data pehchanta

```
[Client] --TCP packet--> [L4 LB] --forward--> [Server]
         IP:Port only          IP:Port change
```

**Pros:** Fast, low latency, simple
**Cons:** Same IP:Port pe multiple services nahi distinguish kar sakta

---

### Layer 7 (Application Layer) — L7 LB

**Kya dekhta hai:** HTTP headers, URL, cookies, body
- Content-based routing
- URL path se decide: /api → S1, /images → S2

```
[Client] --HTTP--> [L7 LB] --route by path/header--> [App Server]
         Full HTTP           /api → S1, /static → S2
```

**Pros:** Smart routing, SSL termination, content-aware
**Cons:** More CPU, slightly higher latency

### Comparison Table
| Feature | Layer 4 | Layer 7 |
|---------|---------|---------|
| Sees | IP, Port | URL, Headers, Cookies |
| Speed | Faster | Slower (more processing) |
| Use Case | Raw TCP/UDP, gaming | HTTP/HTTPS, APIs |
| SSL | Pass-through | Can terminate |
| Routing | Connection-based | Content-based |

### 1 Minute Recall Block
> L4 = IP+Port level, fast. L7 = HTTP level, smart routing. Web apps = L7. Raw TCP = L4.

---

## Health Checks

### Core Concept
LB ko pata hona chahiye — kaun sa server healthy hai, kaun dead.

### Active Health Checks

**How it works:** LB periodically servers ko **probe** bhejta hai

```
LB ---GET /health every 10s---> S1 ✅
LB ---GET /health every 10s---> S2 ❌ (no response)
LB ---GET /health every 10s---> S3 ✅
```

- S2 ko pool se hata do until healthy
- **Pros:** Real-time status
- **Cons:** Extra traffic, false positives possible

### Passive Health Checks

**How it works:** Actual request fail hone pe mark karo

```
Request to S2 → Connection refused → Mark S2 unhealthy
```

- **Pros:** No extra traffic
- **Cons:** User ko pehle failed request face karna padega

### Best Practice
**Dono use karo!** Active = proactive, Passive = backup

### Common Interview Trap
> "Health check fail hone pe kya hota hai?" — LB server ko pool se **remove** karta hai (not delete!). Recovery pe wapas add.

---

## High Availability

### Problem
LB khud single point of failure ban sakta hai!

### Active-Passive (Failover)

```
     [Active LB]  ←── All traffic
          |
     [Passive LB]  ←── Standby, heartbeat monitor
```

- Active fail = Passive takeover (VIP flip)
- **Downtime:** 10-30 seconds typically

### Active-Active LB Pairs

```
[LB1] <---> [LB2]   Both serve traffic
  |           |
  +-- Shared state (sessions)
```

- Dono simultaneously serve
- Fail hone pe ek handle karega
- **Zero downtime** with proper setup

### 1 Minute Recall Block
> LB bhi fail ho sakta — isliye LB pair (Active-Passive ya Active-Active). Heartbeat + VIP failover.

---

## Software vs Hardware LB

### Software Load Balancers

| Tool | Type | Best For |
|------|------|----------|
| **Nginx** | L7 | HTTP, reverse proxy, high concurrency |
| **HAProxy** | L4/L7 | Performance, flexibility |
| **AWS ALB** | L7 | AWS ecosystem, auto-scaling |
| **AWS NLB** | L4 | Low latency, millions connections |

### Hardware Load Balancers

- **F5 BIG-IP,** Citrix NetScaler
- Dedicated appliances
- **Pros:** Very high throughput, specialized
- **Cons:** Expensive, less flexible

### When to Use
- **Startup/Small:** Nginx, HAProxy (free, flexible)
- **Cloud:** ALB/NLB (managed, auto-scale)
- **Enterprise:** F5 (compliance, extreme scale)

---

## Session Persistence (Sticky Sessions)

### Core Concept
User ne login kiya Server 1 pe — session data S1 pe hai. Next request bhi S1 pe jana chahiye!

### How It Works
- LB cookie set karta hai (e.g., `SERVER_ID=S1`)
- Next request mein cookie = same server
- **OR** IP Hash use karo

### Pros & Cons
| Pros | Cons |
|------|------|
| Session data local | Uneven distribution |
| No shared session store | Server down = session lost |
| Simple | Scale karte waqt problem |

### Better Alternative
**Shared session store** (Redis) — phir sticky sessions ki zaroorat nahi!

### Common Interview Trap
> "Sticky sessions vs stateless?" — Stateless + shared cache = better scaling. Sticky = quick fix but scaling issue.

---

## SSL Termination

### Core Concept
HTTPS = encrypted. LB decrypt karke backend ko plain HTTP bhej sakta hai.

```
[Client] --HTTPS--> [LB] --HTTP--> [Server]
         Encrypted      Decrypted (internal network)
```

### Why at LB?
- Servers ko SSL processing nahi karni
- Single certificate management
- CPU offload from app servers

### Security Note
Internal network **trusted** hona chahiye. Otherwise end-to-end encryption rakho.

---

## Global Server Load Balancing (GSLB)

### Core Concept
Multiple **datacenters** across world — user ko nearest/healthy DC bhejo

```
        [User Mumbai]          [User NYC]
               |                     |
               v                     v
         [DNS / GSLB]
               |
    +----------+----------+
    v          v          v
 [DC India] [DC Europe] [DC USA]
```

### How It Works
- DNS-based: User's location → nearest IP
- Health-based: Unhealthy DC ko skip
- Geo-routing: Latency minimize

### Use Case
Netflix, Google — global users ko nearest server

---

## Common Mistakes & Interview Qs

### Common Mistakes
1. **LB pe SSL terminate karke internal network insecure** — Ensure trusted network
2. **Sticky sessions without fallback** — Server down = session lost
3. **Wrong algorithm** — Long connections mein Round Robin galat
4. **Single LB** — LB bhi SPOF hai!
5. **Health check too aggressive** — False positives = servers unnecessarily removed

### Interview Questions

**Q1: Round Robin vs Least Connections?**
> RR = equal distribution, ignores current load. Least Connections = busy servers avoid. Variable duration = Least Connections.

**Q2: L4 vs L7 LB?**
> L4 = IP+Port, fast. L7 = HTTP aware, content routing, SSL termination.

**Q3: How to achieve zero downtime deployment?**
> LB + rolling update. Health check fail = LB stops sending traffic. Deploy new, drain old, remove.

**Q4: What if LB fails?**
> Active-Passive/Active-Active pair. VIP failover. Keepalived, AWS multi-AZ.

**Q5: Consistent Hashing kyu use karte hain?**
> Cache scaling — server add/remove pe minimal keys redistribute. Avoid thundering herd.

### 1 Minute Recall Block (Full Topic)
> Load Balancer = traffic distributor. Algorithms: RR, Weighted, Least Conn, IP Hash, Consistent Hash. L4 fast, L7 smart. Health checks = active + passive. LB pair for HA. Sticky sessions = same server. SSL termination at LB. GSLB = global routing.

### 5 Bullet Memory Hooks (Full Topic)
- LB = traffic police, barabari baanto
- Algorithm = use case pe depend (RR/Least Conn/Consistent Hash)
- L4 vs L7 = speed vs intelligence
- Health check = unhealthy remove
- LB bhi fail ho sakta = pair rakho

---

## Load Balancer Placement — Where Does LB Sit?

### Core Concept
LB system mein kahan aata hai — yeh architecture pe depend karta hai.

### Typical Architecture

```
                    [Internet]
                         |
                    [DNS / CDN]
                         |
                    [Load Balancer]  ← First point of contact
                         |
              +----------+----------+
              |          |          |
         [Web Tier] [Web Tier] [Web Tier]
              |          |          |
         [App LB] (optional - internal)
              |          |          |
         [App Tier] [App Tier] [App Tier]
```

### DMZ (Demilitarized Zone)
- LB often DMZ mein — public aur internal network ke beech
- External traffic → LB → internal servers
- Security: LB pe firewall rules, DDoS protection

### 1 Minute Recall Block
> LB = first contact for traffic. DMZ placement common. Can have multiple tiers (web LB, app LB).

---

## Load Balancer Metrics — Kya Monitor Karein?

### Key Metrics

| Metric | Matlab | Alert When |
|--------|--------|------------|
| **Request rate** | Requests per second | Sudden spike/drop |
| **Response time** | P95, P99 latency | High latency |
| **Error rate** | 5xx responses | > 1% |
| **Active connections** | Current connections | Near limit |
| **Backend health** | Healthy vs unhealthy | Any unhealthy |
| **Throughput** | Bytes/sec | Capacity planning |

### Real World
Netflix, Uber — LB metrics = first line of observability. LB pe problem = sab pe impact.

---

## Quick Recall — Cheat Sheet

```
LOAD BALANCING CHEAT SHEET
==========================
• Purpose: Distribute traffic across servers
• Algorithms: RR | Weighted | Least Conn | IP Hash | Consistent Hash
• Layers: L4 (fast) | L7 (smart routing)
• Health: Active (probe) + Passive (observe failures)
• HA: Active-Passive or Active-Active pair
• Tools: Nginx, HAProxy, AWS ALB/NLB
• Sticky: Same client → same server (session affinity)
• SSL: Terminate at LB for offload
• GSLB: Global routing, geo + health
```
