# Design Distributed Cache — Interview Thinking

> **Permanent Recall:** Start **simple** (single-node in-memory cache), then **evolve**: add consistent hashing for distribution → add replication for HA → discuss eviction → mention persistence. The evolution story is the interview narrative — shows you think incrementally and understand trade-offs.

---

## Step 1: Single-Node Cache (5 min)

**"Let's start with the simplest design."**

- In-memory **hash table**: `map[key] → value`
- O(1) GET, SET, DELETE
- When full: **eviction** — LRU (hash map + doubly-linked list)
- **TTL**: lazy expiration on GET; or background scanner

```
┌─────────────────────┐
│   Single Node       │
│  ┌───────────────┐  │
│  │  Hash Table   │  │
│  │  + LRU list   │  │
│  └───────────────┘  │
└─────────────────────┘
```

*Interviewer: "What if we need more capacity?"*

---

## Step 2: Add Distribution — Consistent Hashing (10 min)

**"We need to partition data across multiple nodes."**

- **Problem with modulo:** `hash(key) % N` — when N changes, most keys move
- **Solution:** Consistent hashing ring
  - Hash nodes and keys to ring (e.g., 0 .. 2^32)
  - Key goes to first node clockwise from `hash(key)`
  - Add/remove node: only keys in affected arc move
- **Virtual nodes:** Each physical node = many points on ring → even distribution

```
Client: hash(key) → ring position → route to node
```

*Interviewer: "What if a node fails?"*

---

## Step 3: Add Replication — HA (5 min)

**"We need high availability."**

- **Primary-replica:** Each shard has 1 primary + 1+ replicas
- **Replication:** Async (primary ack before replica) for low latency
- **Failover:** Sentinel/controller detects failure; promotes replica
- **Read scaling:** Clients can read from replica (eventual consistency)

*Interviewer: "How do you evict when memory is full?"*

---

## Step 4: Eviction (5 min)

**"Eviction policies."**

- **LRU:** Hash map + doubly-linked list — O(1) get, set, evict
- **LFU:** Frequency buckets — better for stable access patterns
- **TTL:** Lazy delete on access; periodic cleanup
- **Redis:** Configurable — `noeviction`, `allkeys-lru`, `volatile-ttl`, etc.

*Interviewer: "Do we need persistence?"*

---

## Step 5: Persistence (Optional)

**"Depends on use case."**

- **Pure cache:** No persistence; recompute from DB on miss
- **Cache-as-datastore:** RDB (snapshot) and/or AOF (append-only log)
- **RDB:** Fork, dump to disk; fast restore; point-in-time
- **AOF:** Log every write; replay on restart; more durable

---

## Evolution Summary

| Step | Addition | Why |
|------|----------|-----|
| 1 | Single node + LRU | Baseline |
| 2 | Consistent hashing | Partition across nodes; minimal rehash |
| 3 | Replication | HA; survive node failure |
| 4 | Eviction detail | O(1) LRU; policy choice |
| 5 | Persistence | Durability vs pure cache |

---

## What to State Up Front

1. **Scale:** Billions of keys, TB across cluster
2. **Latency:** Sub-millisecond; in-memory
3. **Operations:** GET, SET, DELETE, TTL, eviction
4. **Data structures:** Strings, hashes, lists, sets, sorted sets (if asked)

---

## When to Go Deeper

| If interviewer asks... | Go deeper on... |
|------------------------|-----------------|
| "How does LRU work?" | Hash map + doubly-linked list; O(1) |
| "How does consistent hashing work?" | Ring, virtual nodes, K/N keys move |
| "Sorted sets?" | Skip list + hash; ZRANGE, ZRANGEBYSCORE |
| "Hot key?" | Replication, local cache, shard the key |
| "Multi-region?" | Cross-region replication; conflict resolution |

---

## Red Flags to Avoid

- Jumping to distributed before nailing single-node
- Modulo hashing instead of consistent hashing
- No eviction policy
- No replication when asked about HA
- Ignoring data structure implementation (sorted set = skip list)
