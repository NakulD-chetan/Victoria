# Design YouTube/Netflix — Common Mistakes

> **Permanent Recall:** Top mistakes = **not separating upload and streaming paths**, **synchronous transcoding**, **storing single resolution**, **no CDN**, **ignoring transcoding pipeline complexity**. Always treat video as two systems + **adaptive bitrate** + **copyright/moderation**.

---

## Top 10 Common Mistakes

| # | Mistake | Why It's Wrong | Correct Approach |
|---|---------|----------------|------------------|
| 1 | **Not separating upload and streaming paths** | They have different bottlenecks; conflating causes wrong design | Upload = write path; Streaming = read path; design separately |
| 2 | **Synchronous transcoding** | Blocks upload; 1 hr video = 30+ min wait; timeout, poor UX | Async queue + workers; return immediately; "processing" status |
| 3 | **Storing single resolution** | No adaptive bitrate; poor UX on slow networks; wasted bandwidth on high-end | 240p–4K ladder; HLS/DASH chunks |
| 4 | **No CDN** | Origin overload; high latency globally; 75 PB/day egress kills origin | CDN mandatory; 90%+ cache hit target |
| 5 | **Ignoring transcoding pipeline** | Transcoding is the most compute-heavy part; hand-waving fails | FFmpeg, DAG, parallel resolution encodes, segment, manifest |
| 6 | **Not discussing adaptive bitrate** | Buffering, poor experience; shows lack of video-domain knowledge | HLS/DASH; chunks at multiple qualities; client selects |
| 7 | **Treating metadata DB same as video storage** | Video = PB-scale blobs; metadata = GB-scale; different stores | Object store for video; Cassandra/NoSQL for metadata |
| 8 | **Ignoring copyright/content moderation** | Legal requirement at scale; Content ID, DMCA | Pipeline: hash check, Content ID, human review; block before publish |
| 9 | **Storing video in database** | DB can't handle PB; blobs don't belong in relational DB | Object storage (S3/GCS) for video; DB only for metadata |
| 10 | **No resumable upload** | Large files (hours) — network drop = restart from zero | Multipart/resumable upload; chunk-level idempotency |

---

## Detailed Callouts

### Mistake 1: Conflating Upload and Streaming

```
❌ Single pipeline: Upload → Store → Stream (same path)
✅ Upload path: Client → Raw store → Transcoding → Processed store → CDN → Metadata
   Streaming path: Client → CDN → (Origin on miss) → Chunks
```

### Mistake 2: Synchronous Transcoding

```
❌ Upload → Transcode (30 min) → Save → Response (user waits)
✅ Upload → Save raw → Return 202 → Queue → Worker transcodes → Notify when ready
```

### Mistake 3: Single Resolution

```
❌ One 1080p file; stream to everyone
✅ 240p, 360p, 480p, 720p, 1080p, 4K — client picks based on network
```

### Mistake 5: Hand-Waving Transcoding

```
❌ "We process the video" (no detail)
✅ FFmpeg DAG: parallel encodes per resolution → segment into chunks → generate HLS manifest
```

---

## Anti-Pattern Diagram

```
❌ BAD:
Client ─► Upload ─► Transcode (sync) ─► DB (store video) ─► Stream from DB
              │                              │
              └── User waits 30 min          └── DB explodes at PB scale

✅ GOOD:
Client ─► Upload ─► S3 (raw) ─► Queue ─► Workers (FFmpeg) ─► S3 (processed) ─► CDN
              │                                                    │
              └── Return 202 immediately                           └── Metadata → DB
                                                                  Stream: Client → CDN → chunks
```

---

## What Interviewers Listen For

- **"Two separate paths: upload and streaming"**
- **"Transcoding is async — queue and workers"**
- **"Multiple resolutions for adaptive bitrate — HLS or DASH"**
- **"CDN for delivery — we never serve video from origin to users"**
- **"Object store for video; DB only for metadata"**
- **"Copyright detection in the pipeline"**

---

## Red Flags to Avoid

- "We store video in MySQL/Postgres" — instant fail
- "We transcode synchronously" — shows no scale thinking
- "Single resolution is fine" — no adaptive bitrate knowledge
- "We don't need CDN" — ignores global scale
- Treating upload and streaming as one pipeline — wrong mental model
- Not mentioning transcoding at all — missed the core

---

## Recovery Phrases

If you slip: "Actually, for video at this scale, we'd have two pipelines — upload with async transcoding, and streaming via CDN. Transcoding would be the most expensive part."

---

## Mistake Severity

| Severity | Mistakes | Impact |
|----------|----------|--------|
| **Critical** | Conflating paths, sync transcoding, no CDN, video in DB | System won't work; instant rejection |
| **Major** | Single resolution, no adaptive bitrate, hand-wave transcoding | Poor UX; shows shallow knowledge |
| **Moderate** | Ignoring copyright/moderation, no resumable upload | Incomplete; legal risk |
| **Minor** | Metadata in same store as video (if designed for scale) | Suboptimal but recoverable |

---

## Correct Architecture Checklist

- [ ] Upload path separate from streaming path
- [ ] Async transcoding (queue + workers)
- [ ] Multiple resolutions (240p–4K)
- [ ] Adaptive bitrate (HLS/DASH)
- [ ] CDN for delivery (90%+ hit rate)
- [ ] Object store for video; metadata in DB
- [ ] Resumable upload for large files
- [ ] Copyright/content moderation mentioned

---

## Why Candidates Make These Mistakes

- **Conflating paths:** Used to CRUD apps; don't think in write vs read paths
- **Sync transcoding:** Simpler to reason about; don't consider 30-min video
- **Single resolution:** Familiar with image resize; don't know HLS/DASH
- **No CDN:** Local dev works without it; forget 75 PB/day egress
- **Video in DB:** Treat video like any other "file" attachment

---

## Interview Impact

Mistakes #1 (conflating paths), #2 (sync transcoding), or #4 (no CDN) in a FAANG interview are strong negative signals. This question specifically tests media handling and CDN knowledge — missing these is costly.
