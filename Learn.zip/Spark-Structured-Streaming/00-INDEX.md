# Structured Streaming — Theory Notes

High-quality theory notes for **Apache Spark Structured Streaming**, aligned in structure and depth with [Spark-Notes](../Spark-Notes/) topics **01–10**. These files focus on definitions, execution model, and semantics—not step-by-step coding labs.

For hands-on PySpark streaming examples, see [26-Structured-Streaming-Hands-On.md](../Spark-Notes/26-Structured-Streaming-Hands-On.md) and [14-Streaming-DStream-vs-Structured.md](../Spark-Notes/14-Streaming-DStream-vs-Structured.md).

---

## Table of Contents

| # | Topic | File |
|---|--------|------|
| 01 | Architecture & Mental Model | [01-Architecture-and-Mental-Model.md](01-Architecture-and-Mental-Model.md) |
| 02 | Unbounded Table & Incremental Execution | [02-Unbounded-Table-Incremental-Execution.md](02-Unbounded-Table-Incremental-Execution.md) |
| 03 | Triggers & Micro-Batch Engine | [03-Triggers-and-Micro-Batch-Engine.md](03-Triggers-and-Micro-Batch-Engine.md) |
| 04 | Output Modes (Append, Update, Complete) | [04-Output-Modes.md](04-Output-Modes.md) |
| 05 | Event Time, Windows & Watermarks | [05-Event-Time-Windows-Watermarks.md](05-Event-Time-Windows-Watermarks.md) |
| 06 | Stateful Operations & State Store | [06-Stateful-Operations-State-Store.md](06-Stateful-Operations-State-Store.md) |
| 07 | Checkpointing & Exactly-Once Semantics | [07-Checkpointing-Fault-Tolerance-Exactly-Once.md](07-Checkpointing-Fault-Tolerance-Exactly-Once.md) |
| 08 | Sources, Sinks & Offset Management | [08-Sources-Sinks-Offsets.md](08-Sources-Sinks-Offsets.md) |
| 09 | Streaming Joins | [09-Streaming-Joins.md](09-Streaming-Joins.md) |
| 10 | Optimization & Tuning | [10-Optimization-and-Tuning.md](10-Optimization-and-Tuning.md) |

---

## Recommended Reading Order

**Foundation**: 01 → 02 → 03 → 04  

**Time & correctness**: 05 → 06 → 07  

**Integration & advanced**: 08 → 09 → 10  

---
