import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: exponential-search */
function generateBinarySteps(a, target, lo, hi) {
  const steps = [];
  let L = lo;
  let R = hi;
  steps.push({ type: 'bin-window', array: [...a], pointers: { lo: L, hi: R }, target, phase: 'binary' });
  while (L <= R) {
    const mid = Math.floor((L + R) / 2);
    steps.push({ type: 'bin-compare', array: [...a], pointers: { lo: L, mid, hi: R }, target, mid });
    if (a[mid] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { lo: L, mid, hi: R }, target, idx: mid });
      return steps;
    }
    if (a[mid] < target) {
      steps.push({ type: 'bin-shrink-right', array: [...a], pointers: { lo: L, mid, hi: R }, target });
      L = mid + 1;
    } else {
      steps.push({ type: 'bin-shrink-left', array: [...a], pointers: { lo: L, mid, hi: R }, target });
      R = mid - 1;
    }
    steps.push({ type: 'bin-window', array: [...a], pointers: { lo: L, hi: R }, target, phase: 'binary' });
  }
  steps.push({ type: 'notfound', array: [...a], pointers: {}, target });
  return steps;
}

function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  const n = a.length;
  steps.push({ type: 'check-zero', array: [...a], pointers: { i: 0 }, target });
  if (a[0] === target) {
    steps.push({ type: 'found', array: [...a], pointers: { i: 0 }, target, idx: 0 });
    return steps;
  }
  let bound = 1;
  while (bound < n && a[bound] < target) {
    steps.push({ type: 'double', array: [...a], pointers: { i: bound }, target, bound });
    bound *= 2;
  }
  const lo = Math.floor(bound / 2);
  const hi = Math.min(bound, n - 1);
  steps.push({ type: 'range-found', array: [...a], pointers: { lo, hi, bound: hi }, target, lo, hi });
  steps.push(...generateBinarySteps(a, target, lo, hi));
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

export default function ExponentialSearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Exponential (galloping) search for ${target}` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    const paint = (lo, hi) => {
      for (let i = 0; i < n; i++) {
        colors[i] = i >= lo && i <= hi ? 'active' : 'eliminated';
      }
    };
    if (step.type === 'check-zero') {
      for (let i = 0; i < n; i++) colors[i] = i === 0 ? 'compare' : 'eliminated';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: 'Check A[0]' });
    } else if (step.type === 'double') {
      for (let i = 0; i < n; i++) {
        colors[i] = i <= step.bound ? 'active' : 'eliminated';
      }
      colors[step.bound] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: `Double bound to index ${step.bound}` });
    } else if (step.type === 'range-found') {
      paint(step.lo, step.hi);
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Binary search in [${step.lo}, ${step.hi}]` });
    } else if (step.type === 'bin-window') {
      paint(pointers.lo, pointers.hi);
    } else if (step.type === 'bin-compare') {
      paint(pointers.lo, pointers.hi);
      colors[step.mid] = 'compare';
      store.incComparisons();
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Binary mid ${step.mid}` });
    } else if (step.type === 'bin-shrink-left' || step.type === 'bin-shrink-right') {
      paint(pointers.lo, pointers.hi);
      colors[pointers.mid] = 'compare';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Halve interval' });
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.idx] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at ${step.idx}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Not found' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      ...(found != null ? { found } : {}),
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
