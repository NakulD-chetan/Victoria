import { memo, useEffect, useRef, useState, useCallback } from 'react';
import { Excalidraw } from '@excalidraw/excalidraw';
import '@excalidraw/excalidraw/index.css';
import { dbService } from '../firebase';

const TOOLS = [
  { type: 'hand', label: 'Hand', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 11V6a2 2 0 0 0-4 0v1M14 10V4a2 2 0 0 0-4 0v6M10 10.5V6a2 2 0 0 0-4 0v8"/><path d="M18 8a2 2 0 0 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg> },
  { type: 'selection', label: 'Select', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="M13 13l6 6"/></svg> },
  { type: 'freedraw', label: 'Pen', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/><path d="M2 2l7.586 7.586"/><circle cx="11" cy="11" r="2"/></svg> },
  { type: 'line', label: 'Line', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="19" x2="19" y2="5"/></svg> },
  { type: 'arrow', label: 'Arrow', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg> },
  { type: 'rectangle', label: 'Rectangle', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/></svg> },
  { type: 'ellipse', label: 'Circle', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/></svg> },
  { type: 'diamond', label: 'Diamond', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3.5" y="3.5" width="17" height="17" rx="1" transform="rotate(45 12 12)"/></svg> },
  { type: 'text', label: 'Text', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="4 7 4 4 20 4 20 7"/><line x1="9.5" y1="20" x2="14.5" y2="20"/><line x1="12" y1="4" x2="12" y2="20"/></svg> },
  { type: 'eraser', label: 'Eraser', icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 20H7L3 16l9-9 8 8-4 4"/><path d="M6.5 13.5l5-5"/></svg> },
];

/* ── Element helpers ──────────────────────────────────────── */
let _id = 0;
const uid = () => `ds_${Date.now()}_${++_id}`;

function makeRect(x, y, w, h, gid, opts = {}) {
  return {
    id: uid(), type: 'rectangle', x, y, width: w, height: h,
    angle: 0, strokeColor: opts.stroke || '#1e1e1e', backgroundColor: opts.fill || 'transparent',
    fillStyle: 'solid', strokeWidth: 2, roughness: 0, opacity: 100,
    groupIds: [gid], roundness: { type: 3 }, isDeleted: false, locked: false,
    boundElements: null, updated: Date.now(), link: null, ...opts,
  };
}
function makeText(x, y, text, gid, opts = {}) {
  const w = Math.max(text.length * 10, 14);
  return {
    id: uid(), type: 'text', x, y, width: w, height: 20,
    angle: 0, strokeColor: opts.stroke || '#1e1e1e', backgroundColor: 'transparent',
    fillStyle: 'solid', strokeWidth: 1, roughness: 0, opacity: 100,
    groupIds: [gid], isDeleted: false, locked: false,
    boundElements: null, updated: Date.now(), link: null,
    text, fontSize: opts.fontSize || 16, fontFamily: 1, textAlign: 'center', verticalAlign: 'middle',
    containerId: null, originalText: text, autoResize: true, ...opts,
  };
}
function makeArrow(x1, y1, x2, y2, gid, opts = {}) {
  return {
    id: uid(), type: 'arrow', x: x1, y: y1, width: x2 - x1, height: y2 - y1,
    angle: 0, strokeColor: opts.stroke || '#1e1e1e', backgroundColor: 'transparent',
    fillStyle: 'solid', strokeWidth: 2, roughness: 0, opacity: 100,
    groupIds: [gid], isDeleted: false, locked: false,
    boundElements: null, updated: Date.now(), link: null,
    points: [[0, 0], [x2 - x1, y2 - y1]],
    lastCommittedPoint: null, startBinding: null, endBinding: null,
    startArrowhead: null, endArrowhead: opts.endArrowhead !== undefined ? opts.endArrowhead : 'arrow', ...opts,
  };
}
function makeEllipse(x, y, w, h, gid, opts = {}) {
  return {
    id: uid(), type: 'ellipse', x, y, width: w, height: h,
    angle: 0, strokeColor: opts.stroke || '#1e1e1e', backgroundColor: opts.fill || 'transparent',
    fillStyle: 'solid', strokeWidth: 2, roughness: 0, opacity: 100,
    groupIds: [gid], isDeleted: false, locked: false,
    boundElements: null, updated: Date.now(), link: null, ...opts,
  };
}

/* ── Data Structure generators ────────────────────────────── */
const CELL_W = 64, CELL_H = 48;
const COLORS = {
  array:  { fill: '#dbe4ff', stroke: '#364fc7', text: '#1c3d99', label: '#5c7cfa' },
  stack:  { fill: '#fff3bf', stroke: '#e67700', text: '#b35c00', label: '#f59f00', top: '#ffe066' },
  ll:     { fill: '#c3fae8', stroke: '#087f5b', text: '#055e44', label: '#20c997' },
  tree:   { fill: '#d0ebff', stroke: '#1864ab', text: '#134b85', label: '#339af0' },
  graph:  { fill: '#f3d9fa', stroke: '#862e9c', text: '#6b2480', label: '#be4bdb' },
};

function genArray(values, cx, cy) {
  const gid = uid();
  const n = values.length;
  const totalW = n * CELL_W;
  const sx = cx - totalW / 2, sy = cy - CELL_H / 2;
  const els = [];
  const c = COLORS.array;
  els.push(makeText(cx - 20, sy - 30, 'Array', gid, { stroke: c.label, fontSize: 13 }));
  for (let i = 0; i < n; i++) {
    const x = sx + i * CELL_W;
    els.push(makeRect(x, sy, CELL_W, CELL_H, gid, { fill: c.fill, stroke: c.stroke }));
    els.push(makeText(x + CELL_W / 2 - 6, sy + 14, String(values[i]), gid, { stroke: c.text }));
    els.push(makeText(x + CELL_W / 2 - 4, sy + CELL_H + 4, String(i), gid, { stroke: '#868e96', fontSize: 11 }));
  }
  return { gid, type: 'array', values: [...values], cx, cy, els };
}

function genStack(values, cx, cy) {
  const gid = uid();
  const n = values.length;
  const cellW = 80;
  const sx = cx - cellW / 2, sy = cy - (n * CELL_H) / 2;
  const els = [];
  const c = COLORS.stack;
  els.push(makeText(cx - 18, sy - 30, 'Stack', gid, { stroke: c.label, fontSize: 13 }));
  for (let i = 0; i < n; i++) {
    const y = sy + (n - 1 - i) * CELL_H;
    const isTop = i === n - 1;
    els.push(makeRect(sx, y, cellW, CELL_H, gid, { fill: isTop ? c.top : c.fill, stroke: c.stroke }));
    els.push(makeText(sx + cellW / 2 - 6, y + 14, String(values[i]), gid, { stroke: c.text }));
  }
  els.push(makeText(sx + cellW + 8, sy - 2, '← TOP', gid, { stroke: c.stroke, fontSize: 12 }));
  return { gid, type: 'stack', values: [...values], cx, cy, els };
}

function genLinkedList(values, cx, cy) {
  const gid = uid();
  const n = values.length;
  const gap = 40;
  const totalW = n * CELL_W + (n - 1) * gap;
  const sx = cx - totalW / 2, sy = cy - CELL_H / 2;
  const els = [];
  const c = COLORS.ll;
  els.push(makeText(cx - 35, sy - 30, 'Linked List', gid, { stroke: c.label, fontSize: 13 }));
  for (let i = 0; i < n; i++) {
    const x = sx + i * (CELL_W + gap);
    els.push(makeRect(x, sy, CELL_W, CELL_H, gid, { fill: c.fill, stroke: c.stroke }));
    els.push(makeText(x + CELL_W / 2 - 6, sy + 14, String(values[i]), gid, { stroke: c.text }));
    if (i < n - 1) {
      els.push(makeArrow(x + CELL_W + 2, sy + CELL_H / 2, x + CELL_W + gap - 2, sy + CELL_H / 2, gid, { stroke: c.stroke }));
    }
  }
  const lastX = sx + (n - 1) * (CELL_W + gap) + CELL_W + 8;
  els.push(makeText(lastX, sy + 14, 'NULL', gid, { stroke: '#adb5bd', fontSize: 12 }));
  return { gid, type: 'linkedlist', values: [...values], cx, cy, els };
}

function genBinaryTree(values, cx, cy) {
  const gid = uid();
  const nodeR = 22, hGap = 70, vGap = 65;
  const positions = [
    { x: 0, y: 0 },
    { x: -hGap, y: vGap },
    { x: hGap, y: vGap },
    { x: -hGap * 1.5, y: 2 * vGap },
    { x: -hGap * 0.5, y: 2 * vGap },
  ];
  const edges = [[0,1],[0,2],[1,3],[1,4]];
  const els = [];
  const c = COLORS.tree;
  els.push(makeText(cx - 35, cy - nodeR - 28, 'Binary Tree', gid, { stroke: c.label, fontSize: 13 }));
  for (const e of edges) {
    if (e[0] < values.length && e[1] < values.length) {
      const a = positions[e[0]], b = positions[e[1]];
      els.push(makeArrow(cx + a.x, cy + a.y + nodeR, cx + b.x, cy + b.y - nodeR, gid, { endArrowhead: null, stroke: '#adb5bd' }));
    }
  }
  for (let i = 0; i < values.length && i < positions.length; i++) {
    const p = positions[i];
    els.push(makeEllipse(cx + p.x - nodeR, cy + p.y - nodeR, nodeR * 2, nodeR * 2, gid, { fill: c.fill, stroke: c.stroke }));
    els.push(makeText(cx + p.x - 6, cy + p.y - 10, String(values[i]), gid, { stroke: c.text }));
  }
  return { gid, type: 'tree', values: [...values], cx, cy, els };
}

function genGraph(values, cx, cy) {
  const gid = uid();
  const nodeR = 22;
  const angleStep = (2 * Math.PI) / values.length;
  const radius = 70;
  const positions = values.map((_, i) => ({
    x: cx + Math.cos(angleStep * i - Math.PI / 2) * radius,
    y: cy + Math.sin(angleStep * i - Math.PI / 2) * radius,
  }));
  const edges = [];
  for (let i = 0; i < values.length; i++) {
    if (i + 1 < values.length) edges.push([i, i + 1]);
    if (i + 2 < values.length) edges.push([i, i + 2]);
  }
  const els = [];
  const c = COLORS.graph;
  els.push(makeText(cx - 18, cy - radius - nodeR - 28, 'Graph', gid, { stroke: c.label, fontSize: 13 }));
  for (const e of edges) {
    const a = positions[e[0]], b = positions[e[1]];
    els.push(makeArrow(a.x, a.y, b.x, b.y, gid, { endArrowhead: null, stroke: '#adb5bd' }));
  }
  for (let i = 0; i < values.length; i++) {
    const p = positions[i];
    els.push(makeEllipse(p.x - nodeR, p.y - nodeR, nodeR * 2, nodeR * 2, gid, { fill: c.fill, stroke: c.stroke }));
    els.push(makeText(p.x - 6, p.y - 10, String(values[i]), gid, { stroke: c.text }));
  }
  return { gid, type: 'graph', values: [...values], cx, cy, els };
}

const DS_GENERATORS = { array: genArray, stack: genStack, linkedlist: genLinkedList, tree: genBinaryTree, graph: genGraph };

const SHAPE_PRESETS = [
  { key: 'array', label: 'Array [5]', icon: '[ ]', defaults: [10, 20, 30, 40, 50] },
  { key: 'stack', label: 'Stack [5]', icon: '≡', defaults: [1, 2, 3, 4, 5] },
  { key: 'linkedlist', label: 'Linked List', icon: '→', defaults: ['A', 'B', 'C', 'D', 'E'] },
  { key: 'tree', label: 'Binary Tree', icon: '⌄', defaults: [1, 2, 3, 4, 5] },
  { key: 'graph', label: 'Graph', icon: '◇', defaults: ['A', 'B', 'C', 'D', 'E'] },
];

/* ── Operations panel per DS type ─────────────────────────── */
const DS_OPS = {
  array: [
    { id: 'push_back', label: 'Push Back', icon: '+→' },
    { id: 'pop_back', label: 'Pop Back', icon: '←−' },
    { id: 'push_front', label: 'Push Front', icon: '→+' },
    { id: 'pop_front', label: 'Pop Front', icon: '−→' },
  ],
  stack: [
    { id: 'push', label: 'Push', icon: '↑+' },
    { id: 'pop', label: 'Pop', icon: '↓−' },
  ],
  linkedlist: [
    { id: 'push_back', label: 'Append', icon: '+→' },
    { id: 'pop_back', label: 'Remove Last', icon: '←−' },
    { id: 'push_front', label: 'Prepend', icon: '→+' },
    { id: 'pop_front', label: 'Remove First', icon: '−→' },
  ],
  tree: [
    { id: 'add_node', label: 'Add Node', icon: '+' },
    { id: 'remove_leaf', label: 'Remove Leaf', icon: '−' },
  ],
  graph: [
    { id: 'add_node', label: 'Add Node', icon: '+' },
    { id: 'remove_node', label: 'Remove Node', icon: '−' },
  ],
};

/* ── DSPanel: floating ops when a DS group is selected ───── */
function DSPanel({ ds, onOp, onClose, canvasRect, appState }) {
  if (!ds) return null;
  const ops = DS_OPS[ds.type] || [];
  const els = ds.els || [];
  const bounds = getBounds(els);
  const zoom = appState?.zoom?.value || 1;
  const sx = appState?.scrollX || 0;
  const sy = appState?.scrollY || 0;
  const screenX = (bounds.maxX + 10) * zoom + sx + (canvasRect?.left || 0);
  const screenY = bounds.minY * zoom + sy + (canvasRect?.top || 0);

  return (
    <div className="ds-panel" style={{ left: screenX, top: screenY }}>
      <div className="ds-panel__header">
        <span className="ds-panel__title">{ds.type.replace('linkedlist', 'Linked List').replace(/^\w/, c => c.toUpperCase())}</span>
        <span className="ds-panel__count">{ds.values.length} items</span>
        <button className="ds-panel__close" onClick={onClose}>×</button>
      </div>
      <div className="ds-panel__ops">
        {ops.map(op => (
          <button key={op.id} className="ds-panel__op-btn" onClick={() => onOp(op.id)}>
            <span className="ds-panel__op-icon">{op.icon}</span>
            <span>{op.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function getBounds(els) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const el of els) {
    if (el.isDeleted) continue;
    minX = Math.min(minX, el.x);
    minY = Math.min(minY, el.y);
    maxX = Math.max(maxX, el.x + (el.width || 0));
    maxY = Math.max(maxY, el.y + (el.height || 0));
  }
  return { minX, minY, maxX, maxY };
}

/* ── Main DrawCanvas ──────────────────────────────────────── */
const DrawCanvas = memo(function DrawCanvas({ folder, filename, theme, userId, onSwitchToRead, displayName }) {
  const [initialData, setInitialData] = useState(undefined);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTool, setActiveTool] = useState('freedraw');
  const [shapesOpen, setShapesOpen] = useState(false);
  const [selectedDS, setSelectedDS] = useState(null);
  const [canvasRect, setCanvasRect] = useState(null);
  const [appSt, setAppSt] = useState(null);
  const saveTimer = useRef(null);
  const latestScene = useRef(null);
  const apiRef = useRef(null);
  const dsRegistry = useRef(new Map());
  const wrapRef = useRef(null);

  useEffect(() => {
    if (!userId || !folder || !filename) {
      setInitialData({ elements: [], appState: {} });
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    dbService.getDrawing(userId, folder, filename).then((data) => {
      if (cancelled) return;
      setInitialData(data ? { elements: data.elements, appState: data.appState } : { elements: [], appState: {} });
      setLoading(false);
    }).catch(() => { if (!cancelled) { setInitialData({ elements: [], appState: {} }); setLoading(false); } });
    return () => { cancelled = true; };
  }, [userId, folder, filename]);

  const handleChange = useCallback((elements, appState) => {
    latestScene.current = { elements, appState };
    if (appState?.activeTool?.type) setActiveTool(appState.activeTool.type);
    setAppSt(appState);

    const selIds = appState.selectedElementIds || {};
    const selGroupIds = new Set();
    for (const el of elements) {
      if (selIds[el.id] && el.groupIds?.length) {
        el.groupIds.forEach(g => selGroupIds.add(g));
      }
    }
    let foundDS = null;
    for (const [gid, ds] of dsRegistry.current) {
      if (selGroupIds.has(gid)) { foundDS = ds; break; }
    }
    setSelectedDS(foundDS);

    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      if (!latestScene.current || !userId) return;
      const scene = latestScene.current;
      const nonDeleted = scene.elements.filter(el => !el.isDeleted);
      if (nonDeleted.length === 0 && !scene.appState?.viewBackgroundColor) return;
      setSaving(true);
      dbService.saveDrawing(userId, folder, filename, { elements: nonDeleted, appState: scene.appState })
        .catch(() => {}).finally(() => setSaving(false));
    }, 2000);
  }, [userId, folder, filename]);

  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
      if (latestScene.current && userId) {
        const scene = latestScene.current;
        const nonDeleted = scene.elements.filter(el => !el.isDeleted);
        if (nonDeleted.length > 0) dbService.saveDrawing(userId, folder, filename, { elements: nonDeleted, appState: scene.appState });
      }
    };
  }, [userId, folder, filename]);

  useEffect(() => {
    if (!wrapRef.current) return;
    const update = () => setCanvasRect(wrapRef.current.getBoundingClientRect());
    update();
    window.addEventListener('resize', update);
    return () => window.removeEventListener('resize', update);
  }, []);

  const selectTool = useCallback((type) => { setActiveTool(type); apiRef.current?.setActiveTool({ type }); }, []);

  const insertShape = useCallback((preset) => {
    const api = apiRef.current;
    if (!api) return;
    const as = api.getAppState();
    const cx = (-as.scrollX + as.width / 2) / as.zoom.value;
    const cy = (-as.scrollY + as.height / 2) / as.zoom.value;
    const gen = DS_GENERATORS[preset.key];
    const ds = gen(preset.defaults, cx, cy);
    dsRegistry.current.set(ds.gid, ds);
    const existing = api.getSceneElements();
    api.updateScene({ elements: [...existing, ...ds.els] });
    setShapesOpen(false);
    api.setActiveTool({ type: 'selection' });
    setActiveTool('selection');
  }, []);

  const handleDSOp = useCallback((opId) => {
    const ds = selectedDS;
    const api = apiRef.current;
    if (!ds || !api) return;

    let nextVal;
    const peek = ds.values[ds.values.length - 1];
    const defaultNew = typeof peek === 'number' ? (peek + 1) : String.fromCharCode(65 + ds.values.length);

    switch (opId) {
      case 'push_back':
      case 'push':
        nextVal = prompt('Enter value:', defaultNew);
        if (nextVal === null) return;
        ds.values.push(isNaN(nextVal) ? nextVal : Number(nextVal));
        break;
      case 'pop_back':
      case 'pop':
        if (ds.values.length <= 1) return;
        ds.values.pop();
        break;
      case 'push_front':
        nextVal = prompt('Enter value:', defaultNew);
        if (nextVal === null) return;
        ds.values.unshift(isNaN(nextVal) ? nextVal : Number(nextVal));
        break;
      case 'pop_front':
        if (ds.values.length <= 1) return;
        ds.values.shift();
        break;
      case 'add_node':
        nextVal = prompt('Enter value:', defaultNew);
        if (nextVal === null) return;
        ds.values.push(isNaN(nextVal) ? nextVal : Number(nextVal));
        break;
      case 'remove_node':
      case 'remove_leaf':
        if (ds.values.length <= 1) return;
        ds.values.pop();
        break;
      default: return;
    }

    const existing = api.getSceneElements().map(el =>
      el.groupIds?.includes(ds.gid) ? { ...el, isDeleted: true } : el
    );
    const bounds = getBounds(ds.els);
    const ncx = (bounds.minX + bounds.maxX) / 2;
    const ncy = (bounds.minY + bounds.maxY) / 2;
    const gen = DS_GENERATORS[ds.type];
    const newDS = gen(ds.values, ncx, ncy);
    newDS.gid = ds.gid;
    newDS.els.forEach(el => { el.groupIds = [ds.gid]; });
    dsRegistry.current.set(ds.gid, newDS);
    api.updateScene({ elements: [...existing, ...newDS.els] });
    setSelectedDS(newDS);
  }, [selectedDS]);

  const handleUndo = useCallback(() => {
    document.querySelector('.draw-canvas-wrap .excalidraw')
      ?.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', ctrlKey: true, bubbles: true }));
  }, []);
  const handleRedo = useCallback(() => {
    document.querySelector('.draw-canvas-wrap .excalidraw')
      ?.dispatchEvent(new KeyboardEvent('keydown', { key: 'z', ctrlKey: true, shiftKey: true, bubbles: true }));
  }, []);

  if (loading || initialData === undefined) {
    return (
      <div className="draw-canvas-wrap draw-canvas-wrap--loading">
        <div className="draw-canvas-loader">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83" />
          </svg>
          <span>Loading canvas...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="draw-canvas-wrap draw-canvas-wrap--custom-ui" ref={wrapRef}>
      {saving && <div className="draw-canvas-saving">Saving...</div>}

      <div className="draw-toolbar">
        {onSwitchToRead && (
          <>
            <button className="draw-toolbar__read-btn" onClick={onSwitchToRead} title="Switch to Read mode">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                <polyline points="14 2 14 8 20 8" />
              </svg>
              Read
            </button>
            {displayName && <span className="draw-toolbar__filename" title={displayName}>{displayName}</span>}
            <div className="draw-toolbar__sep" />
          </>
        )}
        {TOOLS.map((t) => (
          <button key={t.type} className={`draw-toolbar__btn ${activeTool === t.type ? 'draw-toolbar__btn--active' : ''}`} onClick={() => selectTool(t.type)} title={t.label}>
            {t.icon}
          </button>
        ))}
        <div className="draw-toolbar__sep" />
        <div className="draw-toolbar__shapes-wrap">
          <button className={`draw-toolbar__btn ${shapesOpen ? 'draw-toolbar__btn--active' : ''}`} onClick={() => setShapesOpen(s => !s)} title="Insert data structure">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="2" y="4" width="6" height="6" rx="1"/><rect x="9" y="4" width="6" height="6" rx="1"/><rect x="16" y="4" width="6" height="6" rx="1"/>
              <rect x="2" y="14" width="6" height="6" rx="1"/><rect x="9" y="14" width="6" height="6" rx="1"/><rect x="16" y="14" width="6" height="6" rx="1"/>
            </svg>
          </button>
          {shapesOpen && (
            <div className="draw-toolbar__shapes-menu">
              {SHAPE_PRESETS.map(p => (
                <button key={p.key} className="draw-toolbar__shapes-item" onClick={() => insertShape(p)}>
                  <span className="draw-toolbar__shapes-icon">{p.icon}</span>
                  <span>{p.label}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="draw-toolbar__sep" />
        <button className="draw-toolbar__btn" onClick={handleUndo} title="Undo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>
        </button>
        <button className="draw-toolbar__btn" onClick={handleRedo} title="Redo">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.13-9.36L23 10"/></svg>
        </button>
      </div>

      {selectedDS && (
        <DSPanel ds={selectedDS} onOp={handleDSOp} onClose={() => setSelectedDS(null)} canvasRect={canvasRect} appState={appSt} />
      )}

      <Excalidraw
        excalidrawAPI={(api) => { apiRef.current = api; }}
        initialData={initialData}
        theme={theme === 'dark' ? 'dark' : 'light'}
        onChange={handleChange}
        UIOptions={{ canvasActions: { loadScene: false, export: { saveFileToDisk: true } } }}
      />
    </div>
  );
});

export default DrawCanvas;
