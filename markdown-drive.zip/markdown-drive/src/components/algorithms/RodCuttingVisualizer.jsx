import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(prices) {
  const n = prices.length;
  const dp = Array(n + 1).fill(0);
  const steps = [];
  const colLabels = Array.from({ length: n + 1 }, (_, i) => i);

  const snap = (caption, arr, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [arr],
      rowLabels: ['best'],
      colLabels,
      cellColors: colors || {},
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('Rod DP: dp[len] = max revenue for length len', [...dp], {}, null, []);

  for (let len = 1; len <= n; len += 1) {
    let best = prices[len - 1];
    const colors = { [`0-${len}`]: 'current' };
    const arrows = [];
    snap(`Uncut rod of length ${len} sells for ${prices[len - 1]}`, [...dp], colors, [0, len], []);
    for (let cut = 1; cut < len; cut += 1) {
      const cand = dp[cut] + dp[len - cut];
      colors[`0-${cut}`] = 'filling';
      colors[`0-${len - cut}`] = 'filling';
      arrows.push({ from: [0, cut], to: [0, len] });
      arrows.push({ from: [0, len - cut], to: [0, len] });
      snap(`Try cut at ${cut}: ${dp[cut]} + ${dp[len - cut]}`, [...dp], { ...colors, [`0-${len}`]: 'current' }, [0, len], arrows);
      best = Math.max(best, cand);
    }
    dp[len] = best;
    snap(`dp[${len}] = ${best}`, { [`0-${len}`]: 'optimal' }, [0, len], []);
  }

  snap(`Max revenue for length ${n} = ${dp[n]}`, { [`0-${n}`]: 'optimal' }, [0, n], []);
  return steps;
}

export default function RodCuttingVisualizer({ config }) {
  const prices = [1, 5, 8, 9, 10, 17, 17, 20];

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(prices);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: 'Rod cutting price table DP' });
    canvasRef.current?.setState({
      table: [[0]],
      rowLabels: [],
      colLabels: [],
      cellColors: {},
      arrows: [],
      highlight: null,
      items: prices.map((p, i) => (i ? `ℓ${i}:${p}` : '')).filter(Boolean),
      caption: 'Rod cutting',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[0]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      items: prices.map((p, i) => (i ? `ℓ${i}:${p}` : '')).filter(Boolean),
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return <AlgoVisualizer config={safeConfig} canvas={DPCanvasBase} onInit={onInit} onStep={onStep} statsBuilder={statsBuilder} />;
}
