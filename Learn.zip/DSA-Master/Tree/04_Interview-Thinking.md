# Tree — Interview Thinking

> How to approach ANY tree problem in an interview. Follow this process every time.

---

## Step-by-Step Interview Process

### Step 1: Clarify the Tree Type

Before writing ANY code, ask:
- Is it a **Binary Tree** or can nodes have more than 2 children?
- Is it a **BST**? (Can I exploit the ordering property?)
- Is it **balanced**?
- Can values be **duplicates**?
- Can the tree be **empty** (null root)?

### Step 2: Identify the Pattern

Look at what the problem asks for and match it to a pattern:

| What the problem asks | Pattern to use |
|----------------------|----------------|
| Visit every node once | DFS (Pre/In/Post) or BFS |
| Process level by level | BFS with level tracking |
| Something about height / depth | Bottom-up recursion |
| Something about paths from root to leaf | Top-down DFS with state |
| Find min/max in BST | Go right (max) or left (min) |
| BST validity check | Pass min/max bounds top-down |
| Nearest common ancestor | Post-order + check left+right returns |
| Sorted output from BST | In-order traversal |

### Step 3: Draw a Small Example

Always draw a tree with 5-7 nodes. Trace through your logic manually BEFORE coding.

```
Example tree to keep handy:
      1
     / \
    2   3
   / \   \
  4   5   6
```

### Step 4: Define Your Recursive Function

Say OUT LOUD (or write as a comment):
> "My function takes a node and returns ___. If the node is null, it returns ___."

### Step 5: Handle the Base Case First

```python
def solve(node):
    if node is None:
        return ???   # ALWAYS handle this first
```

### Step 6: Write Recursive Case

Use the result from left and right children to compute the answer for the current node.

### Step 7: Test Edge Cases

- Empty tree (root = None)
- Single node
- Only left children (skewed left)
- Only right children (skewed right)

---

## Classic Interview Problems and How to Think About Them

### Problem 1: Maximum Depth / Height

**Think:** I need the longest path from this node to any leaf below.

```
At any node: answer = 1 + max(depth of left, depth of right)
Base case (null): return 0
```

### Problem 2: Check if Tree is Balanced

**Think:** A tree is balanced if EVERY node has |left_height - right_height| ≤ 1.

**Key insight:** I need to check bottom-up because I need heights first.

```
At each node: compute height AND whether balanced
If |left_h - right_h| > 1 → not balanced
```

### Problem 3: Lowest Common Ancestor (LCA)

**Think:** For nodes p and q, their LCA is:
- The node that has p in one subtree and q in the other
- Or the node itself if it IS p or q

**Algorithm (bottom-up):**
```
search(node, p, q):
    if node is null: return null
    if node == p or node == q: return node
    left  = search(node.left,  p, q)
    right = search(node.right, p, q)
    if left and right: return node  ← p and q are on different sides
    return left or right            ← both on same side
```

### Problem 4: Path Sum

**Think:** Starting from root, subtract node value from target as you go down. At leaf, check if remaining = 0.

```
has_path_sum(node, remaining):
    if node is null: return False
    remaining -= node.data
    if is_leaf(node): return remaining == 0
    return has_path_sum(node.left, remaining) or has_path_sum(node.right, remaining)
```

### Problem 5: Serialize and Deserialize Tree

**Think:** Pre-order is perfect — root comes first, so you can rebuild in the same order.

```
Serialize: Pre-order traversal, write "null" for empty nodes
Deserialize: Read values one by one, pre-order

Serialized: "1,2,4,null,null,5,null,null,3,null,6,null,null"
```

### Problem 6: Validate BST

**Think:** At each node, there's a valid range [min, max]. Check if node value is within range.

```
is_valid_bst(node, min_val=-inf, max_val=+inf):
    if node is null: return True
    if not (min_val < node.data < max_val): return False
    return (is_valid_bst(node.left,  min_val, node.data) and
            is_valid_bst(node.right, node.data, max_val))
```

### Problem 7: Right Side View of Tree

**Think:** BFS level-by-level; take the LAST node of each level.

```python
def right_side_view(root):
    if not root: return []
    result, q = [], deque([root])
    while q:
        for i in range(len(q)):
            node = q.popleft()
            if i == len(q): result.append(node.data)  # last in level
            if node.left:  q.append(node.left)
            if node.right: q.append(node.right)
    return result
```

---

## Time/Space Complexity Cheat Sheet

| Operation | Time | Space (stack) |
|-----------|------|---------------|
| Any DFS traversal | O(n) | O(h) |
| BFS traversal | O(n) | O(w) — w = max width |
| BST search/insert/delete | O(h) | O(h) |
| Balanced tree (AVL) | O(log n) | O(log n) |
| Skewed tree (worst) | O(n) | O(n) |
| Heap insert | O(log n) | O(1) |
| Heap extract-min/max | O(log n) | O(1) |
| Build heap from array | O(n) | O(1) |

> h = height of tree. For balanced tree h = O(log n). For skewed h = O(n).

---

## Communication During Interview

**When you first see the problem:**
> "This looks like a tree traversal problem. Let me think about whether I need DFS or BFS, and whether I should pass information top-down or collect it bottom-up."

**Before coding:**
> "I'll define my recursive function: it takes a node and returns [X]. Base case when null is [Y]. For each node, I combine the left and right results by [Z]."

**When stuck:**
> "Let me try on a small example — a tree with 3 nodes." (Draw and trace manually)

**After coding:**
> "Let me check edge cases: empty tree, single node, and skewed tree."
