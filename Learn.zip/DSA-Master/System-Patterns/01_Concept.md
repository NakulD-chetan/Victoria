# System-Patterns — Concept

> **Permanent Recall:** System-Patterns are META-PATTERNS that combine multiple DSA techniques. FAANG engineers use these high-level strategies when single-topic solutions fail. Master these to solve the hardest interview problems.

---

## Core Idea (2 Lines)

**Single-topic:** One technique (DP, BFS, etc.) solves the problem.

**System-pattern:** Two or more techniques work together — e.g., Binary Search finds the answer, Greedy validates it.

---

## Meta-Pattern Catalog

| Pattern | Combines | When to Use | Example |
|---------|----------|-------------|---------|
| **Monotonic Stack + DP** | Stack for "next greater" + DP for optimal subproblem | Next greater element + optimal substructure | Largest Rectangle in Histogram, Trapping Rain Water |
| **BFS + DP** | Level-order + state transitions | Shortest path in unweighted graph + state | Word Ladder, Knight Moves |
| **Binary Search on Answer + Greedy** | BS for value + Greedy for feasibility | "Min/max X such that Y is possible" | Koko Eating Bananas, Split Array Largest Sum |
| **Trie + Backtracking** | Prefix lookup + exhaustive search | Word search, autocomplete with constraints | Word Search II, Word Squares |
| **Segment Tree / BIT** | Range queries + updates | Dynamic range sum/min/max | Range Sum Query Mutable, Count Inversions |
| **Sweep Line** | Sort + linear scan | Intervals, overlapping events | Meeting Rooms II, Skyline Problem |
| **Two-Pass** | Left→Right then Right→Left | Need info from both sides | Product Except Self, Candy |
| **Divide and Conquer** | Split, solve, merge | Optimal substructure + merge step | Merge Sort, Closest Pair of Points |
| **Meet in the Middle** | Split into halves, combine | n ≤ 40, brute force too slow | Subset Sum, 4Sum II |
| **Reservoir Sampling** | Single pass + probability | Random k from stream | Random Pick Index |
| **Fisher-Yates Shuffle** | In-place random permutation | Shuffle array uniformly | Shuffle an Array |

---

## Pattern Deep Dives

### 1. Monotonic Stack + DP

- **Stack:** Maintain indices in decreasing order of value (for "next greater")
- **DP:** Store optimal result for each index
- **Use:** Histogram area, trapping water, stock span

### 2. BFS + DP

- **BFS:** Explores level by level (shortest unweighted path)
- **DP:** State = (node, extra info) — avoid revisiting same state
- **Use:** Word Ladder, Knight, multi-key maze

### 3. Binary Search on Answer + Greedy Check

- **BS:** Search space = possible answer values [lo, hi]
- **Greedy:** For mid, check if feasible in O(n)
- **Use:** Min capacity, max min-distance, threshold problems

### 4. Trie + Backtracking

- **Trie:** Fast prefix lookup during backtrack
- **Backtrack:** Explore all valid paths
- **Use:** Word Search II, Word Squares, Boggle

### 5. Segment Tree / Fenwick Tree (BIT)

- **BIT:** O(log n) point update + prefix sum
- **Segment Tree:** O(log n) range query/update
- **Use:** Inversions, range sum, dynamic RMQ

### 6. Sweep Line

- **Events:** Start/end of intervals as (time, +1/-1)
- **Sort:** Process in chronological order
- **Use:** Meeting rooms, skyline, merge intervals

### 7. Two-Pass (Left→Right, Right→Left)

- **Pass 1:** Compute cumulative from left
- **Pass 2:** Compute from right, combine
- **Use:** Product except self, candy, trapping water (alternative)

### 8. Divide and Conquer

- **Split:** Divide into subproblems
- **Solve:** Recursively solve each
- **Merge:** Combine results (e.g., merge step in merge sort)
- **Use:** Merge sort, closest pair, max subarray (Kadane alternative)

### 9. Meet in the Middle

- **Split:** Divide set into two halves
- **Enumerate:** Generate all subsets/sums for each half
- **Combine:** Match halves (e.g., two pointers, hash)
- **Use:** Subset sum n≤40, 4Sum II

### 10. Reservoir Sampling

- **Stream:** Process elements one by one
- **Rule:** Replace with prob 1/i for i-th element
- **Result:** Uniform random sample of size 1 (or k)

### 11. Fisher-Yates Shuffle

- **In-place:** Swap a[i] with a[random(i..n-1)]
- **Uniform:** Each permutation equally likely
- **O(n):** One pass

---

## Complexity Quick Reference

| Pattern | Time | Space | Typical n |
|---------|------|-------|-----------|
| Monotonic Stack + DP | O(n) | O(n) | 10^5 |
| BFS + DP | O(V+E) or O(n·k) | O(n) | 10^4 |
| BS on Answer + Greedy | O(n log V) | O(1) | 10^6 |
| Trie + Backtrack | O(m·4^L) | O(m) | m=words, L=len |
| BIT / Segment Tree | O(n log n) | O(n) | 10^5 |
| Sweep Line | O(n log n) | O(n) | 10^5 |
| Two-Pass | O(n) | O(1) or O(n) | 10^5 |
| Divide and Conquer | O(n log n) | O(log n) | 10^5 |
| Meet in the Middle | O(2^(n/2)) | O(2^(n/2)) | n≤40 |
| Reservoir Sampling | O(n) | O(1) | stream |
| Fisher-Yates | O(n) | O(1) | 10^6 |

---

## Golden Rules

1. **Read constraints first** — n ≤ 20 → brute/backtrack; n ≤ 40 → meet in middle; n ≤ 10^5 → O(n log n)
2. **"Min/max X such that Y"** → Binary search on answer + feasibility check
3. **Intervals / events** → Sweep line
4. **Need both directions** → Two-pass
5. **Range queries + updates** → BIT or Segment Tree
6. **Stream + random sample** → Reservoir sampling
7. **Shuffle uniformly** → Fisher-Yates
8. **Combine techniques when one alone fails**

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       System-Patterns (Meta-Patterns)
CORE IDEA:          Combine 2+ DSA techniques for hard problems
KEY COMBOS:         Monotonic+DP, BFS+DP, BS+Greedy, Trie+Backtrack, BIT/SegTree, Sweep, Two-Pass, D&C, Meet-in-Middle, Reservoir, Fisher-Yates
WHEN:               Single technique insufficient; constraints hint at combo
GOLDEN RULES:       Constraints → algorithm; "min/max X s.t. Y" → BS on answer; intervals → sweep; both sides → two-pass
INTERVIEW LINE:    "This looks like a combination of X and Y — I'll use..."
```

---

## 30-SECOND REVISION BOX

```
□ Monotonic Stack + DP: next greater + optimal subproblem
□ BFS + DP: shortest path + state
□ BS on Answer + Greedy: search value, check feasibility
□ Trie + Backtrack: prefix lookup during search
□ BIT/SegTree: range queries, O(log n) update
□ Sweep Line: sort events, process in order
□ Two-Pass: left→right, right→left, combine
□ Meet in Middle: split n/2, enumerate, combine
□ Reservoir: stream, replace with prob 1/i
□ Fisher-Yates: swap a[i] with a[random(i..n)]
```
