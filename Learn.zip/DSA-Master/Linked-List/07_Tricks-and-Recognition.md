# Linked List — Tricks and Recognition

> **Permanent Recall:** "Pointer manipulation" = linked list. Reverse → 3 pointers. Cycle → fast/slow. Middle → fast/slow. Merge → dummy. Composite problems combine these basics. Use the recognition flowchart when stuck.

---

## The "Pointer Rewiring" Pattern

**Most common linked list pattern at FAANG.**

```
1. Identify which pointers need to change
2. Save references BEFORE modifying
3. Rewire in correct order
4. Move to next position
```

| Operation | Pointers Changed | Save First |
|-----------|-----------------|------------|
| Reverse | curr.next | next_node = curr.next |
| Delete node | prev.next | (just skip) |
| Insert after | new.next, prev.next | (just link) |
| Swap pairs | a.next, b.next | save references |

---

## "Reverse" → Three Pointers

**Strong signal.** Almost all reversal is prev/curr/next.

| Problem | Variation |
|---------|-----------|
| Reverse entire list | Standard template |
| Reverse between L and R | Find position, reverse sublist |
| Reverse in groups of K | Reverse K, connect, repeat |
| Reverse alternate K | Reverse K, skip K, repeat |

```
"Reverse" + any qualifier
    → prev/curr/next + maybe dummy head
```

---

## "Cycle" / "Loop" → Fast & Slow

**Floyd's algorithm solves all cycle problems.**

| Problem | Approach |
|---------|----------|
| Detect cycle | fast == slow → yes |
| Find cycle start | Reset one to head, both move 1 |
| Cycle length | After meeting, count until meet again |
| Happy number | Treat as linked list cycle |

```
"Cycle" / "loop" / "circular" / "repeating"
    → Fast & slow pointers
```

---

## "Middle" → Fast & Slow (Variant)

| Problem | Fast/Slow Variant |
|---------|-------------------|
| Find middle | Standard: while fast and fast.next |
| Find first middle (even) | while fast.next and fast.next.next |
| Split list in half | Find middle, cut at slow |

---

## "Merge" → Dummy Head + Compare

| Problem | Approach |
|---------|----------|
| Merge 2 sorted | Compare heads, attach smaller |
| Merge K sorted | D&C or min-heap |
| Merge in alternating order | Two-pointer interleave |
| Sort linked list | Merge sort (split + merge) |

```
"Merge" / "combine" / "sort linked list"
    → Dummy head + merge logic
```

---

## Composite Tricks (Combine Basics)

### Trick 1: Palindrome = Middle + Reverse + Compare

```
1 → 2 → 3 → 2 → 1

Step 1: Find middle → 3
Step 2: Reverse second half → 1 → 2
Step 3: Compare: 1==1, 2==2 → palindrome!
```

### Trick 2: Reorder = Middle + Reverse + Interleave

```
1 → 2 → 3 → 4 → 5

Step 1: Find middle, split → [1,2,3] and [4,5]
Step 2: Reverse second half → [5,4]
Step 3: Interleave → 1 → 5 → 2 → 4 → 3
```

### Trick 3: Sort = Split (Middle) + Merge Sort

```
4 → 2 → 1 → 3

Step 1: Find middle, split → [4,2] and [1,3]
Step 2: Recurse: sort [4,2]→[2,4], sort [1,3]→[1,3]
Step 3: Merge → [1,2,3,4]
```

### Trick 4: Intersection = Length + Align + Walk

```
A: 1 → 2 ↘
          5 → 6 → 7
B: 3 → 4 ↗

len(A)=5, len(B)=5 → aligned
Walk together until same node → 5
```

---

## The "Skip Node" Delete Trick

**Delete a node without access to previous (given only the node to delete):**

```python
# Copy next node's value, then skip next node
def delete_node(node):
    node.val = node.next.val
    node.next = node.next.next
```

**Limitation:** Cannot delete the LAST node this way.

---

## HashMap + Linked List Combo

| Problem | Why HashMap? |
|---------|-------------|
| Copy list with random pointer | Map old → new nodes |
| LRU Cache | O(1) lookup + O(1) remove/insert |
| Remove duplicates (unsorted) | Track seen values |
| Find intersection | Store addresses |

---

## Recursive Thinking for Linked Lists

**Recursion = "trust that the subproblem is solved."**

```
Reverse recursively:
  reverseList(1 → 2 → 3 → 4)
  = reverseList(2 → 3 → 4) then fix 1
  = 4 → 3 → 2, then 2.next.next = 1, 1.next = null
  = 4 → 3 → 2 → 1
```

**When to use recursive:**
- Reverse in groups (elegant recursion)
- Merge two sorted (clean code)
- When explicitly asked

**When NOT to use:**
- Large lists (stack overflow)
- When O(1) space required

---

## Recognition Flowchart

```
                    ┌───────────────────┐
                    │  Linked List      │
                    │  Problem          │
                    └─────────┬─────────┘
                              │
                    ┌─────────▼─────────┐
                    │  Reverse?         │──Yes──► prev/curr/next (+ maybe K groups)
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Cycle/Loop?      │──Yes──► Fast/Slow (Floyd's)
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Find Middle?     │──Yes──► Fast/Slow variant
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Merge/Sort?      │──Yes──► Dummy head + compare / merge sort
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Remove/Delete?   │──Yes──► Dummy head + two-pointer
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Composite?       │──Yes──► Break into: middle + reverse + merge
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Random pointer?  │──Yes──► HashMap or interleaving
                    └─────────┬─────────┘
                              │ No
                    ┌─────────▼─────────┐
                    │  Consider: LL +   │
                    │  HashMap/Heap     │
                    └───────────────────┘
```

---

## Quick Recognition Cheat Sheet

| Keywords | → Approach |
|----------|------------|
| reverse, flip, backward | prev/curr/next |
| cycle, loop, circular | fast/slow |
| middle, halfway | fast/slow |
| merge, combine, sorted lists | dummy + compare |
| remove, delete, nth from end | dummy + two-pointer gap |
| palindrome | middle + reverse half + compare |
| reorder, rearrange | middle + reverse + interleave |
| sort linked list | merge sort (split + merge) |
| copy, clone, random pointer | HashMap or interleave |
| LRU, recent, evict | doubly linked list + HashMap |
| flatten, multilevel | recursion or DFS with merge |
| intersection, common node | length diff + walk |
| swap pairs, k-group | pointer rewiring |

---

## FINAL MEMORY COMPRESSION BLOCK

```
REVERSE: prev/curr/next — groups of K, between L-R, alternate
CYCLE: fast/slow meet → reset one → entry point
MIDDLE: fast/slow → palindrome, reorder, sort
MERGE: dummy + compare → merge K with heap/D&C
COMPOSITE: palindrome(mid+rev+cmp), reorder(mid+rev+zip), sort(mid+merge)
HASHMAP+LL: copy random, LRU, dedup unsorted
RECURSIVE: elegant but O(n) space — prefer iterative
FLOWCHART: Reverse? → Cycle? → Middle? → Merge? → Composite? → HashMap?
```
