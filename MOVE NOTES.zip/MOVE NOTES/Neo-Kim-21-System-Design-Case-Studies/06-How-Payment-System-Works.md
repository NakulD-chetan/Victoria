# How Payment System Works - System Design

> Source: https://newsletter.systemdesign.one/p/payment-system-design

## One-Line Summary
A payment system like Uber's handles 30M+ transactions/day by tokenizing card data through payment providers, splitting payments via a disbursement engine, and ensuring reliability through idempotent operations and retry mechanisms.

## Key Requirements

### Functional
- Users add payment methods (credit card, debit card, wallet)
- Process payments for rides/orders in real-time
- Split payments across multiple parties (driver, platform, taxes)
- Support refunds and chargebacks
- Track payment status (pending, completed, failed)
- Generate receipts and transaction history

### Non-Functional
- Security (PCI-DSS compliance, no sensitive data on servers)
- Reliability (handle network failures, partial outages)
- Exactly-once payment processing (no double charges)
- Low latency for payment confirmation
- High availability (payments must always work)
- Auditability (complete transaction logs)

## High-Level Architecture

```
Mobile App
    |
    ├── Payment Provider SDK (Stripe/Braintree)
    |     (collects card info directly)
    |     (returns a TOKEN)
    |
    ├── Uber Backend
    |     ├── Payment Service
    |     |     ├── Risk Engine (fraud detection)
    |     |     ├── Wallet Service (user balance)
    |     |     └── Payment Orchestrator
    |     |
    |     ├── Disbursement Engine
    |     |     (splits: driver + platform + taxes)
    |     |
    |     └── Ledger Service
    |           (immutable transaction log)
    |
    └── External Systems
          ├── Payment Provider (Stripe, Braintree)
          ├── Card Networks (Visa, Mastercard)
          └── Banks (issuing + acquiring)
```

## Core Components Deep Dive

### 1. Payment Tokenization (Key Security Pattern)
- **Problem**: Storing credit card numbers on Uber servers = huge security risk
- **Solution**: Use payment provider SDK (Stripe/Braintree) in the mobile app
- Card details go DIRECTLY to the payment provider (never touch Uber servers)
- Payment provider returns a **token** (safe reference to the card)
- Token is: reusable, scoped to Uber's account, useless if stolen
- From now on, mobile app uses TOKEN instead of actual card number
- **Result**: Neither Uber servers nor the mobile device stores sensitive data

### 2. Payment Processing Flow
```
1. Ride ends → Calculate fare
2. Payment Service sends charge request (with token) to Payment Provider
3. Payment Provider contacts Card Network (Visa/MC)
4. Card Network contacts Issuing Bank (user's bank)
5. Bank approves/declines
6. Response flows back through the chain
7. Payment Service updates status
8. Disbursement Engine splits the payment
```

### 3. Disbursement Engine
- A single Uber payment gets split into multiple parts:
  - **Driver payout** (e.g., 75%)
  - **Platform fee** (e.g., 20%)
  - **Taxes and regulatory fees** (e.g., 5%)
- Each split is tracked as a separate ledger entry
- Driver payouts may be batched (daily/weekly settlement)

### 4. Risk Engine (Fraud Detection)
- Real-time fraud scoring before processing payment
- Checks for: unusual location, velocity of transactions, stolen card patterns
- May trigger additional verification (3D Secure, OTP)
- Machine learning models trained on historical fraud patterns
- Can block or flag suspicious transactions

### 5. Ledger Service (Double-Entry Bookkeeping)
- Every transaction recorded as immutable ledger entries
- **Double-entry**: every debit has a matching credit
- Enables: auditing, reconciliation, dispute resolution
- Append-only log (never modify, never delete)
- Used for regulatory compliance and financial reporting

### 6. Idempotency (Preventing Double Charges)
- **Problem**: Network timeout after sending charge → did it go through?
- **Solution**: Every request includes a unique **idempotency key**
- If same key sent twice, payment provider returns original result (no double charge)
- This is CRITICAL for payment systems
- Idempotency keys stored with TTL (e.g., 24 hours)

### 7. Retry & Error Handling
- **Transient failures** (timeout, network blip): retry with exponential backoff
- **Permanent failures** (insufficient funds, invalid card): fail immediately, notify user
- **Dead Letter Queue**: failed payments after max retries go here for manual review
- **Circuit breaker**: if payment provider is down, stop sending requests temporarily

## Key Design Decisions

| Decision | Why |
|----------|-----|
| Tokenization (not storing cards) | PCI-DSS compliance, security |
| Payment provider SDK on client | Card data never touches our servers |
| Idempotency keys | Prevent double charges on retry |
| Double-entry ledger | Auditing, reconciliation, compliance |
| Async disbursement | Driver payouts can be batched, not real-time |
| Event-driven architecture | Decouple payment from other services |
| Exponential backoff + circuit breaker | Handle external system failures gracefully |

## Data Model

```
Payment:
  - payment_id: UUID (primary key)
  - idempotency_key: string (unique)
  - user_id: string
  - amount: decimal
  - currency: string
  - status: enum (pending, authorized, captured, failed, refunded)
  - payment_token: string (from payment provider)
  - created_at: timestamp

Ledger Entry:
  - entry_id: UUID
  - payment_id: UUID (foreign key)
  - account: string (driver/platform/tax)
  - type: enum (debit, credit)
  - amount: decimal
  - timestamp: datetime

Disbursement:
  - disbursement_id: UUID
  - payment_id: UUID
  - recipient: string (driver_id)
  - amount: decimal
  - status: enum (pending, settled, failed)
  - settlement_date: date
```

## Scaling Strategies

1. **Horizontal scaling** of payment service behind load balancer
2. **Sharding ledger** by user_id or payment_id
3. **Message queues** (Kafka) between payment service and disbursement
4. **Read replicas** for transaction history queries
5. **Caching** for frequently accessed payment methods
6. **Multi-region deployment** for global availability
7. **Batch processing** for driver payouts (reduces transaction volume)

## Interview Tips

- Start with **tokenization** -- it shows you understand payment security
- Always mention **idempotency keys** -- this is the #1 concern in payment systems
- Draw the payment flow through external systems (payment provider → card network → bank)
- Discuss **exactly-once semantics** and how to achieve it with idempotency
- Mention **double-entry bookkeeping** for the ledger
- Talk about failure handling: retries, circuit breakers, dead letter queues
- Know the difference: **authorization** (hold funds) vs **capture** (actually charge)
- Disbursement is async -- drivers don't get paid instantly per ride

## Quick Revision (5 bullet points)

1. **Tokenization**: card data goes directly to payment provider SDK, returns a token -- Uber NEVER stores card numbers
2. **Idempotency keys** on every payment request prevent double charges during retries and network failures
3. **Payment flow**: App → Payment Service → Payment Provider → Card Network → Issuing Bank → approval/decline
4. **Disbursement engine** splits each payment: driver share + platform fee + taxes; driver payouts batched daily/weekly
5. **Double-entry ledger** (append-only, immutable) ensures auditability; circuit breaker + exponential backoff handle external failures
