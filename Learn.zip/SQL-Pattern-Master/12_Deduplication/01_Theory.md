# Deduplication

Deduplication removes duplicate rows from a dataset, keeping only one representative row per group. This is one of the most common data cleaning operations in both interviews and production pipelines.

**DSA Analogy**: HashSet for uniqueness — like iterating over an array and adding elements to a HashSet, which automatically rejects duplicates, keeping only the first occurrence.

---

## Core Idea (2 Lines)

Assign a `ROW_NUMBER()` partitioned by the duplicate key columns. Keep only rows where `ROW_NUMBER = 1`. The ORDER BY inside the window function controls WHICH duplicate is kept (most recent, highest value, etc.).

---

## The 4 Deduplication Approaches

### Approach 1: ROW_NUMBER (Most Flexible — Go-To Method)

```sql
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY email
               ORDER BY created_at DESC     -- keep most recent
           ) AS rn
    FROM users
)
SELECT * FROM ranked WHERE rn = 1;
```

**Why ROW_NUMBER is best:**

- You control which duplicate to keep (via ORDER BY)
- Works for any dedup criteria
- Can also DELETE duplicates (see below)

### Approach 2: DISTINCT

```sql
-- Simple: remove exact duplicate rows
SELECT DISTINCT name, email, city
FROM users;

-- SELECT DISTINCT ON (PostgreSQL only) — keeps first per group
SELECT DISTINCTx ON (email) *
FROM users
ORDER BY email, created_at DESC;
```


| DISTINCT Type                    | What It Does                          | Limitation                    |
| -------------------------------- | ------------------------------------- | ----------------------------- |
| `SELECT DISTINCT col1, col2`     | Unique combinations of listed columns | Must list all desired columns |
| `DISTINCT ON (col)` (PostgreSQL) | First row per group (by ORDER BY)     | PostgreSQL only               |


### Approach 3: GROUP BY

```sql
-- Keep one representative per email, using aggregate for other columns
SELECT email,
       MAX(name) AS name,
       MAX(created_at) AS latest_created
FROM users
GROUP BY email;
```

Limitation: Must apply aggregate to every non-grouped column. Loses row identity.

### Approach 4: EXISTS (Anti Self-Join)

```sql
-- Keep the row with the smallest id per email
SELECT * FROM users u1
WHERE NOT EXISTS (
    SELECT 1 FROM users u2
    WHERE u2.email = u1.email AND u2.id < u1.id
);
```

---

## Comparison of Approaches


| Approach    | Keep Control         | All Columns          | DELETE Support     | Performance            |
| ----------- | -------------------- | -------------------- | ------------------ | ---------------------- |
| ROW_NUMBER  | Full (ORDER BY)      | Yes                  | Yes (CTE + DELETE) | Good                   |
| DISTINCT    | None (arbitrary)     | Must list all        | No                 | Good for exact dedup   |
| DISTINCT ON | Full (ORDER BY)      | Yes                  | No                 | Best (PostgreSQL only) |
| GROUP BY    | Limited (aggregates) | No (need aggregates) | No                 | Good                   |
| EXISTS      | By comparison        | Yes                  | Yes                | OK                     |


---

## Deleting Duplicates (Keep One, Remove Rest)

### Method 1: DELETE with ROW_NUMBER (Best)

```sql
-- Delete duplicate emails, keep the one with smallest id
WITH ranked AS (
    SELECT id,
           ROW_NUMBER() OVER (PARTITION BY email ORDER BY id) AS rn
    FROM users
)
DELETE FROM users WHERE id IN (
    SELECT id FROM ranked WHERE rn > 1
);
```

### Method 2: DELETE with Self Join

```sql
-- Delete the duplicate with the larger id
DELETE u1 FROM users u1
JOIN users u2
    ON u1.email = u2.email
    AND u1.id > u2.id;
```

### Method 3: DELETE with NOT IN (careful with NULLs)

```sql
DELETE FROM users
WHERE id NOT IN (
    SELECT MIN(id)
    FROM users
    GROUP BY email
);
```

---

## Common Dedup Scenarios

### Scenario 1: Keep Most Recent Record

```sql
-- Latest order per customer
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY customer_id
               ORDER BY order_date DESC, id DESC    -- tiebreak by id
           ) AS rn
    FROM orders
)
SELECT * FROM ranked WHERE rn = 1;
```

### Scenario 2: Keep Record with Most Data (Fewest NULLs)

```sql
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY email
               ORDER BY
                   (CASE WHEN phone IS NOT NULL THEN 1 ELSE 0 END) +
                   (CASE WHEN address IS NOT NULL THEN 1 ELSE 0 END) +
                   (CASE WHEN city IS NOT NULL THEN 1 ELSE 0 END) DESC,
                   created_at DESC
           ) AS rn
    FROM contacts
)
SELECT * FROM ranked WHERE rn = 1;
```

### Scenario 3: Merge Duplicates (Coalesce Fields)

```sql
-- Combine the best data from all duplicates into one row
SELECT email,
       COALESCE(MAX(phone), '') AS phone,          -- first non-null phone
       COALESCE(MAX(address), '') AS address,
       MIN(created_at) AS first_seen,
       MAX(updated_at) AS last_seen,
       COUNT(*) AS duplicate_count
FROM contacts
GROUP BY email;
```

### Scenario 4: Exact Duplicate Rows (All Columns Same)

```sql
-- When rows are completely identical (no unique ID)
SELECT DISTINCT * FROM staging_table;

-- Or identify them:
SELECT *, COUNT(*) OVER (PARTITION BY col1, col2, col3) AS dup_count
FROM staging_table;
```

---

## Dedup in Data Pipelines (ETL)

```
Source (may have dupes) → Staging → Dedup → Clean Table

Common causes of duplicates:
  - Multiple data source loads
  - Retry logic in event streaming
  - CDC (Change Data Capture) replays
  - Manual data entry errors
  - UNION ALL without dedup
```

```sql
-- Typical ETL dedup: keep latest version per business key
INSERT INTO clean_table
SELECT * FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY business_key
               ORDER BY event_timestamp DESC
           ) AS rn
    FROM staging_table
) WHERE rn = 1;
```

---

## Common Mistakes


| Mistake                     | Why It Breaks                               | Fix                                           |
| --------------------------- | ------------------------------------------- | --------------------------------------------- |
| DISTINCT on wrong columns   | Removes valid distinct rows                 | DISTINCT on the key, not all columns          |
| No ORDER BY in ROW_NUMBER   | Arbitrary row kept — nondeterministic       | Always ORDER BY to control which row survives |
| No tiebreak column          | Ties in ORDER BY → random selection         | Add secondary tiebreak (id, timestamp)        |
| DELETE without WHERE rn > 1 | Deletes ALL rows instead of just duplicates | Always filter rn > 1 (or rn != 1)             |
| GROUP BY losing columns     | Need aggregate for every non-grouped column | Use ROW_NUMBER approach instead               |


---

## Key Takeaway

> ROW_NUMBER partitioned by the duplicate key is the universal dedup pattern. ORDER BY controls which duplicate to keep. Use `rn = 1` to SELECT the survivors, or `rn > 1` to DELETE the duplicates. For PostgreSQL, `DISTINCT ON` is the cleanest shortcut. Always add a deterministic tiebreak column.

