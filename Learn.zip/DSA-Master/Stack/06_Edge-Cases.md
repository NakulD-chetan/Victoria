# Stack — Edge Cases

> **Permanent Recall:** Stack edge cases that break FAANG solutions: empty input, single element, all increasing/decreasing/same, nested parentheses, and stack overflow. Always test these before claiming "done."

---

## 1. Empty Input

### Monotonic Stack (NGE/NSE)
```python
arr = []
# Loop never runs. Stack empty. Result = [].
# Must handle: return [] or [] based on problem
```

### Valid Parentheses
```python
s = ""
# Stack empty at end. Valid! return True
```

### Expression Evaluation
```python
expr = ""
# Empty expression — return 0 or error per spec
```

| Problem Type | Empty Input | Expected |
|--------------|-------------|----------|
| NGE/NSE | `[]` | `[]` |
| Valid parentheses | `""` | `True` |
| Histogram | `[]` | `0` |
| Min stack | — | N/A (no input) |

---

## 2. Single Element

### Monotonic Stack
```python
arr = [5]
# i=0: stack=[0], no pops
# After loop: stack=[0], result[0]=-1 (no next greater)
```

### Valid Parentheses
```python
s = "("   # Invalid — stack has 1 at end
s = ")"   # Invalid — pop from empty
s = "a"   # If only parens matter, might be valid
```

### Histogram
```python
heights = [2]
# Single bar: width=1, area=2
# left=[-1], right=[1] → width = 1-(-1)-1 = 1 ✓
```

---

## 3. All Increasing

```
arr = [1, 2, 3, 4, 5]
```

**NGE:** Every element (except last) finds next greater immediately to its right.  
Stack: `[0] → pop 0 when 2 arrives → [1] → pop 1 when 3 arrives → ...`  
**Result:** `[2, 3, 4, 5, -1]`

**NSE:** No element finds next smaller (everything to the right is larger).  
Stack grows: `[0] → [0,1] → [0,1,2] → [0,1,2,3] → [0,1,2,3,4]` — all remain.  
**Result:** `[-1, -1, -1, -1, -1]`

**Key:** Ensure remaining stack is handled. All indices get -1 for NSE.

---

## 4. All Decreasing

```
arr = [5, 4, 3, 2, 1]
```

**NGE:** No element finds next greater (everything to the right is smaller).  
Stack grows: `[0] → [0,1] → [0,1,2] → [0,1,2,3] → [0,1,2,3,4]` — all remain.  
**Result:** `[-1, -1, -1, -1, -1]`

**NSE:** Every element (except last) finds next smaller immediately to its right.  
Stack: `[0] → pop 0 when 4 arrives → [1] → pop 1 when 3 arrives → ...`  
**Result:** `[4, 3, 2, 1, -1]`

---

## 5. All Same Elements

```
arr = [3, 3, 3, 3]
```

**Critical:** Do we consider "next greater" to include equal or exclude?

- **Strict NGE (greater, not equal):** No one answers anyone. Result: `[-1, -1, -1, -1]`
- **NGE including equal:** Depends on problem. Usually strict.

**Histogram with equal heights:**
```
heights = [2, 2, 2]
```
- Use `>=` for "previous smaller" so equal extends left boundary.
- Use `<` for "next smaller" so equal does NOT extend right (or vice versa per problem).
- **Largest Rectangle:** Typically `>=` on one side, `>` on other to avoid double-counting.

---

## 6. Nested Parentheses Edge Cases

| Input | Valid? | Notes |
|-------|--------|-------|
| `""` | Yes | Empty is valid |
| `"()"` | Yes | Basic |
| `"(())"` | Yes | Nested |
| `"(()"` | No | Stack has 1 at end |
| `"())"` | No | Pop from empty on 3rd char |
| `"([)]"` | No | Interleaved — wrong type |
| `"([])"` | Yes | Proper nesting |
| `"((((((("` | No | Stack grows, never closes |
| `")))))))"` | No | Pop from empty immediately |

### Interleaving
```
"([)]" — Invalid. When we see ')', stack top is '[' — mismatch.
"([])" — Valid. Inner [] closes before outer ().
```

---

## 7. Stack Overflow with Deep Recursion

**When:** Recursive DFS on a very deep tree/graph (e.g., linked list as tree).

```
Tree: 1 -> 2 -> 3 -> ... -> 10^5
Recursive DFS: 10^5 stack frames → stack overflow
```

**Fix:** Use iterative DFS with explicit stack.

```python
# Recursive (risky for deep trees)
def dfs(node):
    if not node: return
    dfs(node.left)
    dfs(node.right)

# Iterative (safe)
def dfs_iterative(root):
    stack = [root]
    while stack:
        node = stack.pop()
        if not node: continue
        stack.append(node.right)
        stack.append(node.left)
```

---

## 8. Expression Evaluation Edge Cases

| Input | Issue |
|-------|-------|
| `"3"` | Single operand — no operators |
| `"3 + "` | Incomplete |
| `"()"` | Empty parens |
| `"-3"` | Unary minus (needs special handling) |
| `"2 * 3 + 4"` | Precedence |
| `"2 ^ 3 ^ 4"` | Right-associative |

---

## 9. Min Stack Edge Cases

| Operation | Edge Case |
|-----------|-----------|
| `getMin()` on empty | Undefined — problem usually guarantees non-empty |
| `pop()` when min is top | Must pop from min_stack too |
| Multiple same mins | Push to min_stack when `val <= min` (not `<`) |
| `push` then immediate `pop` | Min stack must mirror |

---

## 10. Histogram-Specific Edge Cases

```
heights = []        → area = 0
heights = [1]       → area = 1
heights = [1,1,1]   → area = 3 (width 3, height 1)
heights = [2,1,2]   → area = 2 (middle bar height 1, or sides height 2)
heights = [0]       → bar with 0 height — width still 1? Usually area=0
```

**Zero height bars:** Typically contribute 0 area. Width calculation may need to handle `height=0`.

---

## Quick Test Matrix

| Edge Case | NGE | Parentheses | Histogram | Min Stack |
|-----------|-----|-------------|-----------|-----------|
| Empty | `[]` | `""` → True | `[]` → 0 | — |
| Single | `[x]` → [-1] | `"("` → False | `[1]` → 1 | push/pop |
| All inc | All found | — | — | — |
| All dec | All -1 | — | — | — |
| All same | All -1 | — | Equal heights | Duplicate min |
| Deep recursion | — | — | — | Use iterative |

---

## FINAL MEMORY COMPRESSION BLOCK

```
EMPTY:           Return [] or 0; parentheses "" → valid
SINGLE:          NGE → -1; histogram → bar area
ALL INCREASING:  NGE all found immediately; NSE all -1 (handle remaining stack)
ALL DECREASING:  NGE all -1 (handle remaining stack); NSE all found immediately
ALL SAME:        Strict NGE all -1; histogram use >= on one side
PARENTHESES:     "" valid; "())" pop empty; "(()" non-empty end
OVERFLOW:        Deep recursion → iterative + explicit stack
MIN STACK:       val <= min (not <) for duplicates
```
