import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GraphCanvasBase from './canvas-bases/GraphCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** visualizerKey / slug: bfs */
const GRAPH = {
  nodes: [
    { id: 'A', x: 90, y: 200, label: 'A' },
    { id: 'B', x: 200, y: 120, label: 'B' },
    { id: 'C', x: 320, y: 120, label: 'C' },
    { id: 'D', x: 430, y: 200, label: 'D' },
    { id: 'E', x: 320, y: 280, label: 'E' },
    { id: 'F', x: 200, y: 280, label: 'F' },
    { id: 'G', x: 540, y: 140, label: 'G' },
    { id: 'H', x: 560, y: 260, label: 'H' },
  ],
  edges: [
    { from: 'A', to: 'B', directed: false },
    { from: 'A', to: 'F', directed: false },
    { from: 'B', to: 'C', directed: false },
    { from: 'B', to: 'F', directed: false },
    { from: 'C', to: 'D', directed: false },
    { from: 'C', to: 'E', directed: false },
    { from: 'C', to: 'G', directed: false },
    { from: 'D', to: 'H', directed: false },
    { from: 'E', to: 'F', directed: false },
    { from: 'G', to: 'H', directed: false },
  ],
};

function generateSteps() {
  const adj = {
    A: ['B', 'F'], B: ['A', 'C', 'F'], C: ['B', 'D', 'E', 'G'], D: ['C', 'H'],
    E: ['C', 'F'], F: ['A', 'B', 'E'], G: ['C', 'H'], H: ['D', 'G'],
  };
  const steps = [];
  const source = 'A';
  const visited = new Set();
  const queue = [source];
  steps.push({ type: 'start', nodeColors: { [source]: 'source' }, edgeColors: {}, queue: [...queue], visited: [] });
  visited.add(source);
  steps.push({ type: 'visit', nodeColors: { [source]: 'visited' }, edgeColors: {}, queue: [...queue], visited: [...visited] });
  while (queue.length) {
    const u = queue.shift();
    steps.push({ type: 'dequeue', nodeColors: { [u]: 'current' }, edgeColors: {}, queue: [...queue], visited: [...visited] });
    for (const v of adj[u] || []) {
      steps.push({ type: 'edge', nodeColors: { [u]: 'processing', [v]: 'processing' }, edgeColors: { [`${u}-${v}`]: 'highlight', [`${v}-${u}`]: 'highlight' }, queue: [...queue], visited: [...visited] });
      if (!visited.has(v)) {
        visited.add(v);
        queue.push(v);
        steps.push({
          type: 'enqueue',
          nodeColors: { [u]: 'processing', [v]: 'visited' },
          edgeColors: { [`${u}-${v}`]: 'tree', [`${v}-${u}`]: 'tree' },
          queue: [...queue],
          visited: [...visited],
        });
      }
    }
    steps.push({ type: 'done-u', nodeColors: { [u]: 'visited' }, edgeColors: {}, queue: [...queue], visited: [...visited] });
  }
  steps.push({ type: 'done', nodeColors: Object.fromEntries([...visited].map((id) => [id, 'visited'])), edgeColors: {}, queue: [], visited: [...visited] });
  return steps;
}

export default function BFSVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    const store = useVisualizerStore.getState();
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: 'Breadth-first search from A' });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: { A: 'source' },
      edgeColors: {},
      nodeLabels: {},
      queue: ['A'],
      stack: [],
      distances: {},
      visited: [],
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.type });
    canvasRef.current?.setState({
      nodes: GRAPH.nodes,
      edges: GRAPH.edges,
      nodeColors: step.nodeColors || {},
      edgeColors: step.edgeColors || {},
      nodeLabels: step.nodeLabels || {},
      queue: step.queue || [],
      stack: step.stack || [],
      distances: step.distances || {},
      visited: step.visited || [],
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={GraphCanvasBase} onInit={onInit} onStep={onStep} />;
}
