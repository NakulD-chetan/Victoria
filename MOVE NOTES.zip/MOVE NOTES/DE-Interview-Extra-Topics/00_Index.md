# DE Interview Extra Topics — Index

> These topics are **frequently asked** in Data Engineering interviews but were **not covered** in your existing folders (Data-Warehouse-Modelling-Notes, Data-Engineering-Master, Spark-Notes, Kafka-Master, Airflow-Master, SQL-Master).

---

## Topics

| # | Topic | Why It's Asked |
|---|-------|----------------|
| 01 | **CDC (Change Data Capture)** | Top interview topic — Debezium, log-based vs query-based, real-time sync |
| 02 | **Docker & Kubernetes for DE** | Every company deploys pipelines in containers now |
| 03 | **NoSQL Databases** | MongoDB, Cassandra, DynamoDB, Redis — "when SQL vs NoSQL?" is classic |
| 04 | **Snowflake Architecture Deep Dive** | #1 cloud DW — micro-partitions, clustering keys, Snowpipe |
| 05 | **Databricks & Unity Catalog** | Hot platform — Delta Live Tables, Jobs, Photon, governance |
| 06 | **Hadoop Ecosystem (HDFS, YARN, MapReduce)** | Still asked as foundational knowledge even in 2026 |
| 07 | **Data Pipeline System Design** | Senior-level must — end-to-end pipeline design patterns |
| 08 | **Data Security & Compliance** | GDPR, PII masking, encryption — increasingly mandatory |
| 09 | **CI/CD for Data Pipelines** | Git workflows, testing, deployment for data projects |
| 10 | **Data Mesh & Modern Architectures** | Trending — domain-driven data ownership |
| 11 | **Real-Time OLAP Engines** | ClickHouse, Apache Druid, Apache Pinot — new-age analytics |
| 12 | **Great Expectations & Data Testing** | Data validation frameworks — practical interview questions |

---

## Already Covered Elsewhere

| Topic | Folder |
|-------|--------|
| Data Warehouse, Dimensional Modelling, SCD, Facts, Dimensions | `Data-Warehouse-Modelling-Notes/` |
| ETL/ELT, Batch/Stream, Lambda/Kappa, Formats, Idempotency | `Data-Engineering-Master/01-DE-Fundamentals/` |
| Data Lakes, Lakehouse, Delta/Iceberg/Hudi, Medallion | `Data-Engineering-Master/03-Data-Lakes-and-Lakehouse/` |
| Data Modeling (Star, Snowflake, Data Vault) | `Data-Engineering-Master/04-Data-Modeling/` |
| Data Quality & Governance | `Data-Engineering-Master/05-Data-Quality-Governance/` |
| Cloud Platforms (general) | `Data-Engineering-Master/06-Cloud-Data-Platforms/` |
| Python for DE | `Data-Engineering-Master/07-Python-for-DE/` |
| dbt | `Data-Engineering-Master/08-dbt-and-Transforms/` |
| Spark (Architecture to Internals) | `Spark-Notes/` |
| Kafka (Architecture to Interview Guide) | `Kafka-Master/` |
| Airflow (Architecture to Interview Guide) | `Airflow-Master/` |
| SQL (Foundation to Interview Mastery) | `SQL-Master/` |

---
