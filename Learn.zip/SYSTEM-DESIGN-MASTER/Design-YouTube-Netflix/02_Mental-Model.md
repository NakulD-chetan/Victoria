# Design YouTube/Netflix — Mental Model

> **Permanent Recall:** Video streaming has **two completely different paths**: the **upload pipeline** (write path — slow, async, compute-heavy) and the **streaming pipeline** (read path — fast, CDN-heavy, latency-sensitive). Never conflate them; they have different bottlenecks and optimizations.

---

## Core Mental Model: "TV Station"

| Analogy | Upload Pipeline | Streaming Pipeline |
|---------|-----------------|-------------------|
| **TV production** | Producing, editing, mastering the show | Broadcasting to viewers |
| **Characteristics** | Slow (minutes to hours) | Fast (milliseconds) |
| **Bottleneck** | Transcoding (CPU/GPU) | CDN edge proximity |
| **Optimization** | Parallel workers, async | Edge caching, pre-push |

---

## Two Paths Diagram

```
UPLOAD (Write Path) — slow, async, compute-heavy
────────────────────────────────────────────────────
Client ─► Upload ─► Raw Storage ─► TRANSCODING ─► Processed Storage ─► CDN Push ─► Metadata
                │                        │
                │   Minutes to hours     │
                └────────────────────────┘

STREAMING (Read Path) — fast, CDN-heavy, latency-sensitive
──────────────────────────────────────────────────────────
Client ─► CDN Edge ─► (Origin if miss) ─► Adaptive bitrate chunks
          <200ms      Rare for popular    HLS/DASH manifest
```

---

## Key Insight: Transcoding Is the Differentiator

| Operation | Cost | Why |
|-----------|------|-----|
| **Transcoding** | **Highest** | CPU/GPU intensive; 1 hr video → multiple resolutions takes significant compute |
| Storage write | Medium | Object store is cheap |
| CDN delivery | Low per request | CDN handles scale; origin rarely hit |
| Metadata DB | Low | Small records |

> **FAANG Tip:** Saying "transcoding is the most compute-expensive part" shows you understand video systems. It's what separates YouTube/Netflix from simple file hosting.

---

## Adaptive Bitrate Streaming (HLS/DASH)

```
Client requests manifest (e.g., master.m3u8)
         │
         ▼
Manifest lists chunks at different qualities: 240p, 360p, 480p, 720p, 1080p
         │
         ▼
Client picks quality based on: network speed, buffer level, device capability
         │
         ▼
Fetches chunks (e.g., segment_0.ts, segment_1.ts) from CDN
         │
         ▼
Player switches quality mid-stream if network changes (up or down)
```

- **HLS** (HTTP Live Streaming): Apple; `.m3u8` manifest + `.ts` chunks
- **DASH** (Dynamic Adaptive Streaming over HTTP): MPEG standard; similar concept
- **Key benefit:** User in poor network gets 360p; user on fiber gets 4K — same video, different quality served

---

## Decomposition by Path

| Path | Components | Responsibility |
|------|------------|----------------|
| **Upload** | Upload Service, Object Store (raw), Transcoding Service, Object Store (processed), Metadata DB | Accept video, transcode to multiple resolutions, store, register |
| **Streaming** | CDN, Origin, Manifest service | Serve chunks at right quality, low latency |
| **Metadata** | Cassandra/DynamoDB, Elasticsearch | Video info, search, recommendations |
| **Social** | Comments, likes, channels | Engagement; separate from core streaming |

---

## Decomposition Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          UPLOAD PIPELINE (Write)                             │
│  Client → Upload Svc → S3 (raw) → Transcoding (FFmpeg) → S3 (processed)      │
│                              → CDN Pre-push → Metadata DB                    │
└─────────────────────────────────────────────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STREAMING PIPELINE (Read)                            │
│  Client → CDN Edge → (Origin on miss) → Adaptive bitrate chunks             │
│          90%+ cache hit rate                                                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Why Two Paths Matter

| Aspect | Upload Path | Streaming Path |
|--------|-------------|----------------|
| **QPS** | Low (thousands/min globally) | High (millions/sec) |
| **Latency budget** | Minutes OK | Milliseconds |
| **Scaling** | Add transcoding workers | Add CDN edges |
| **Failure mode** | Retry, queue, dead-letter | Serve lower quality, cache |

---

## Transcoding as DAG

Transcoding is not a single step — it's a **DAG of tasks**:

```
                    Raw video (single resolution)
                              │
              ┌───────────────┼───────────────┐
              ▼               ▼               ▼
          [240p encode]  [480p encode]  [1080p encode]   ... (parallel)
              │               │               │
              └───────────────┼───────────────┘
                              ▼
                    Segment into chunks (e.g., 6-sec each)
                              │
                              ▼
                    Generate manifest (HLS/DASH)
                              │
                              ▼
                    Store in object store + CDN
```

- Each resolution can be encoded **in parallel**
- Chunking happens after encode
- **FFmpeg** or similar handles the pipeline

---

## CDN Strategy

| Strategy | Use Case | How |
|----------|----------|-----|
| **Push** | Popular/new videos | Pre-push to edge POPs after transcoding |
| **Pull** | Long-tail content | Lazy; cache on first request |

- **90%+ of requests** served from CDN — origin sees only cache misses
- Popular video: push to many regions
- Niche video: pull on first view; stays cached if rewatched

---

## Data Flow Summary

```
WRITE:  Upload → S3 (raw) → Queue → Transcoding workers → S3 (processed) → CDN → Metadata
        User likes/comment → Metadata service (eventual consistency)

READ:   User clicks play → Manifest API → CDN URL for chunks → Stream
        Search → Elasticsearch → Metadata → CDN URLs for thumbnails
```

---

## Trade-offs

| Decision | Trade-off |
|----------|-----------|
| Async transcoding | User waits minutes for playback; acceptable — return "processing" |
| Multiple resolutions | 5× storage; saves bandwidth + enables adaptive bitrate → net win |
| CDN push for popular | More storage at edge; faster first byte → worth it for viral |
| Eventual consistency (views) | Count can be slightly off; acceptable for non-payment |

---

## What Makes This Hard

- **Transcoding scale** — 500 hours/min needs massive parallel compute
- **Storage** — 3 PB/day; need lifecycle, cold storage for old content
- **Global delivery** — CDN must cover world; latency varies by region
- **Adaptive bitrate** — Client logic + server manifest + chunk storage

---

## Mental Model Summary

```
Think: Upload = TV production (slow, expensive)
       Streaming = Broadcasting (fast, CDN)
       Transcoding = The expensive middle step
       Adaptive bitrate = HLS/DASH chunks at multiple qualities

Not:  Single pipeline; synchronous processing; single resolution
```
