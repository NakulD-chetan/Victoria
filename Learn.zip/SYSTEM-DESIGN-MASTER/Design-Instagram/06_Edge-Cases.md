# Design Instagram — Edge Cases

> **Permanent Recall:** Edge cases: **viral photo** (hot key), **upload failure** (resumable), **EXIF privacy**, **duplicate detection**, **content moderation**, **stories cleanup**, **celebrity posting**.

---

## Edge Cases and Solutions

| Edge Case | Problem | Solution |
|-----------|---------|----------|
| **Viral photo** | Millions of likes → hot key; DB/cache overload | Shard by photo_id; cache like count; eventual consistency |
| **Upload failure mid-way** | Network drop; partial S3 upload | Resumable uploads (chunked); idempotent retry; cleanup orphaned chunks |
| **EXIF data** | Location, device info in photos — privacy risk | Strip EXIF on upload; optionally keep only safe fields |
| **Duplicate photo** | Same photo uploaded multiple times | Perceptual hash (pHash); dedup in storage; soft merge in feed |
| **Content moderation** | Illegal/inappropriate content at scale | ML pre-screening; human review queue; block before CDN publish |
| **Stories expiry** | 24h TTL; millions of stories | Cron/event-driven cleanup; S3 lifecycle; or ephemeral store with TTL |
| **Celebrity posting** | User with 10M followers; fan-out write = 10M Redis writes | Hybrid: fan-out on read for celebs; don't push to all timelines |

---

## Viral Photo (Hot Key)

```
Problem: Photo gets 10M likes in 1 hour
         → like_count update = hot row
         → Cache invalidation storm

Solution:
• Shard likes by (photo_id % N)
• Increment like_count in Redis; batch sync to DB
• Accept eventual consistency for count
• CDN caches the photo (immutable) — no problem
```

---

## Resumable Uploads

```
1. Client requests upload_id
2. Upload in chunks (e.g., 5MB each)
3. Each chunk: POST /upload/chunk { upload_id, chunk_index, data }
4. Server: Store chunks in temp; reassemble when complete
5. On failure: Client retries from last successful chunk
6. Cleanup: Orphaned chunks deleted after 24h
```

> **FAANG Tip:** For large videos, resumable/chunked uploads are expected — mention it when discussing upload.

---

## Content Moderation at Scale

| Stage | What | How |
|-------|------|-----|
| **Pre-upload** | Client-side hash check | Block known bad content |
| **Post-upload** | ML classification | Auto-flag before publish |
| **Async** | Human review | Queue for flagged content |
| **Post-publish** | User reports | Takedown workflow |

---

## Stories Expiry Cleanup

```mermaid
flowchart LR
    A[Story created] --> B[TTL=24h]
    B --> C{Cron every hour}
    C --> D[Delete expired]
    D --> E[S3 lifecycle / Delete]
```

- **Option 1:** S3 lifecycle policy — delete objects with prefix `stories/` after 24h
- **Option 2:** Separate ephemeral store (Redis with TTL, or DynamoDB TTL)
- **Option 3:** Cron job queries `expires_at < NOW()` and deletes

---

## Celebrity Fan-Out

| Follower count | Strategy |
|----------------|----------|
| < 10K | Fan-out on write (push to all) |
| 10K – 1M | Delayed fan-out; async workers |
| > 1M | Fan-out on read (pull model) |

- Store "celebrity" flag or threshold in user metadata
- Celebrities: On feed read, fetch their recent posts and merge
- Avoid writing to millions of Redis keys per post

---

## EXIF and Privacy

- **Problem:** Photos contain GPS, device model, timestamp
- **Solution:** Strip on upload; store only in user's private export if needed
- **Compliance:** GDPR, CCPA — user data handling

---

## Duplicate Photo Detection

- **Perceptual hash (pHash):** Robust to resize, filter; small hash per image
- **Store:** Hash → photo_id mapping; on upload, check if hash exists
- **Action:** Dedup storage; optionally merge in feed (don't show duplicate)

---

## Regional Failures

- **Problem:** One region goes down
- **Solution:** Multi-region S3 replication; CDN with multiple origins; DB replicas

---

## Thumbnail Generation Failure

- **Problem:** Image processor crashes mid-job
- **Solution:** Idempotent jobs; retry with backoff; dead-letter queue; fallback to original

---

## Rate Limiting

- **Upload:** Per-user rate limit (e.g., 10/min) to prevent abuse
- **Feed:** Per-IP or per-user to prevent scraping
- **Like:** Throttle to prevent bot-like bursts

---

## Search Edge Cases

- **Empty search:** Return trending or suggestions
- **Typos:** Fuzzy matching, edit distance
- **Private accounts:** Exclude from search results

---

## Stories Edge Cases

- **User views own story:** Count or not? (Usually yes, for consistency)
- **Story not expired but user deleted:** Soft delete; exclude from feed

---

## Feed Edge Cases

- **New user (no follows):** Show suggested users, trending, or explore preview
- **User follows 0 people:** Explore-only experience
