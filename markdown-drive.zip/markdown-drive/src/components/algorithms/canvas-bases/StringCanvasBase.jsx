import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9',
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    cellDefault: '#f5f5f4',
    cellMatch: '#b2f2bb',
    cellMismatch: '#ffc9c9',
    cellCurrent: '#ffec99',
    cellFound: '#e9d5ff',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    arrow: '#57534e',
  },
  dark: {
    bg: 'transparent',
    dotGrid: 'rgba(255,255,255,0.06)',
    stroke: 'rgba(255,255,255,0.65)',
    cellDefault: '#292524',
    cellMatch: '#1e5631',
    cellMismatch: '#7c1d1d',
    cellCurrent: '#805b10',
    cellFound: '#3b2e6e',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    arrow: 'rgba(255,255,255,0.45)',
  },
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}

const COLOR_KEYS = ['default', 'match', 'mismatch', 'current', 'found'];

function cellFill(p, key) {
  const k = (key || 'default').toLowerCase();
  const cap = k.charAt(0).toUpperCase() + k.slice(1);
  return p[`cell${cap}`] || p.cellDefault;
}

const StringCanvasBase = forwardRef(function StringCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    text: [],
    pattern: [],
    textColors: {},
    patternColors: {},
    offset: 0,
    table: null,
    tableLabel: '',
    matchPositions: [],
    comparePairs: null,
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 400) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((patch) => {
    Object.assign(stateRef.current, patch);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 360;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function drawCharRow(ctx2, p, chars, colors, y, x0, cellW, padY) {
      const h = 36;
      chars.forEach((ch, i) => {
        const x = x0 + i * cellW;
        const ck = colors[i] || 'default';
        ctx2.fillStyle = cellFill(p, ck);
        ctx2.strokeStyle = p.stroke;
        ctx2.lineWidth = 1.2;
        ctx2.beginPath();
        ctx2.roundRect(x + 2, y, cellW - 4, h, 4);
        ctx2.fill();
        ctx2.stroke();
        ctx2.fillStyle = p.textPrimary;
        ctx2.font = '600 14px Consolas, "Courier New", monospace';
        ctx2.textAlign = 'center';
        ctx2.textBaseline = 'middle';
        ctx2.fillText(String(ch), x + cellW / 2, y + padY + h / 2);
      });
    }

    function render() {
      const now = performance.now();
      const p = getPalette();
      const {
        text,
        pattern,
        textColors,
        patternColors,
        offset,
        table,
        tableLabel,
        matchPositions,
        comparePairs,
      } = stateRef.current;

      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20) ctx.fillRect(gx, gy, 1.2, 1.2);

      const textArr = text || [];
      const patArr = pattern || [];
      const nT = textArr.length;
      const nP = patArr.length;
      const maxCells = Math.max(nT, offset + nP, 1);
      const padX = 24;
      const cellW = Math.min(44, Math.max(22, (W - padX * 2) / maxCells));
      const rowYText = 48;
      const rowYPat = 118;
      const baseX = padX;

      drawCharRow(ctx, p, textArr, textColors, rowYText, baseX, cellW, 0);

      const patX0 = baseX + offset * cellW;
      drawCharRow(ctx, p, patArr, patternColors, rowYPat, patX0, cellW, 0);

      const flashAlpha = {};
      for (const a of animsRef.current) {
        const t = Math.min((now - a.t0) / a.dur, 1);
        const e = easeOut(t);
        if (a.type === 'flashText' && a.data.i != null) flashAlpha[`t-${a.data.i}`] = (1 - e) * 0.55;
        if (a.type === 'flashPat' && a.data.i != null) flashAlpha[`p-${a.data.i}`] = (1 - e) * 0.55;
      }

      Object.entries(flashAlpha).forEach(([key, al]) => {
        const [side, idxStr] = key.split('-');
        const idx = +idxStr;
        const x = side === 't' ? baseX + idx * cellW : patX0 + idx * cellW;
        const y = side === 't' ? rowYText : rowYPat;
        ctx.fillStyle = `rgba(239, 68, 68, ${al})`;
        ctx.fillRect(x + 2, y, cellW - 4, 36);
      });

      ctx.strokeStyle = p.arrow;
      ctx.lineWidth = 1.2;
      const pairs = comparePairs || [];
      pairs.forEach(([ti, pi]) => {
        if (ti < 0 || ti >= nT || pi < 0 || pi >= nP) return;
        const x1 = baseX + ti * cellW + cellW / 2;
        const x2 = patX0 + pi * cellW + cellW / 2;
        const y1 = rowYText + 36;
        const y2 = rowYPat;
        ctx.beginPath();
        ctx.moveTo(x1, y1 + 2);
        ctx.lineTo(x2, y2 - 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(x2 - 4, y2 - 8);
        ctx.lineTo(x2, y2 - 2);
        ctx.lineTo(x2 + 4, y2 - 8);
        ctx.stroke();
      });

      (matchPositions || []).forEach((ti) => {
        if (ti < 0 || ti >= nT) return;
        const x = baseX + ti * cellW;
        ctx.strokeStyle = cellFill(p, 'found');
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x + 4, rowYText + 38);
        ctx.lineTo(x + cellW - 4, rowYText + 38);
        ctx.stroke();
      });

      if (table && Array.isArray(table) && table.length > 0) {
        const tableY = rowYPat + 64;
        ctx.fillStyle = p.textSecondary;
        ctx.font = '500 11px -apple-system, sans-serif';
        ctx.textAlign = 'left';
        ctx.fillText(tableLabel || 'Table', padX, tableY - 8);
        const tw = Math.min(cellW, (W - padX * 2) / table.length);
        table.forEach((val, i) => {
          const x = padX + i * tw;
          ctx.fillStyle = p.cellDefault;
          ctx.strokeStyle = p.stroke;
          ctx.lineWidth = 1;
          ctx.strokeRect(x, tableY, tw - 2, 28);
          ctx.fillRect(x, tableY, tw - 2, 28);
          ctx.fillStyle = p.textPrimary;
          ctx.font = '600 12px Consolas, monospace';
          ctx.textAlign = 'center';
          ctx.fillText(String(val), x + (tw - 2) / 2, tableY + 18);
        });
      }

      for (let i = animsRef.current.length - 1; i >= 0; i--) {
        if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) animsRef.current.splice(i, 1);
      }

      rafRef.current = requestAnimationFrame(render);
    };

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default StringCanvasBase;
