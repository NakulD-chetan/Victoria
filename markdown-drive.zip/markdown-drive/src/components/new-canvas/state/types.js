/**
 * Type definitions for the new-canvas data model.
 *
 * All coordinates/sizes are WORLD space. Screen-space conversion happens
 * in engine/coords.js and only when drawing or positioning DOM overlays.
 *
 * The scene is a flat, ordered list of elements. Z-order == array order
 * (later elements paint on top). Soft-delete via `isDeleted` keeps undo
 * cheap — a later GC pass can compact.
 *
 * @typedef {Object} Viewport
 * @property {number} zoom    world→screen scale (1 == 100%)
 * @property {number} panX    world-space x offset; screenX = (worldX + panX) * zoom
 * @property {number} panY    world-space y offset
 *
 * @typedef {Object} StyleProps
 * @property {string} stroke
 * @property {string} fill
 * @property {number} strokeWidth
 * @property {number} opacity    0..1
 * @property {'solid'|'dashed'|'dotted'} [dash]
 *
 * @typedef {Object} BaseElement
 * @property {string} id
 * @property {string} type
 * @property {number} x
 * @property {number} y
 * @property {number} w
 * @property {number} h
 * @property {number} z            draw order (ascending)
 * @property {boolean} isDeleted
 * @property {StyleProps} style
 * @property {number} createdAt
 *
 * @typedef {BaseElement & {type:'pen'|'highlighter', points: number[][]}} StrokeElement
 *   points: Array<[worldX, worldY, pressure?]>
 *
 * @typedef {BaseElement & {type:'rect'|'ellipse'}} BoxElement
 *
 * @typedef {BaseElement & {type:'line'|'arrow', x2:number, y2:number}} LineElement
 *
 * @typedef {BaseElement & {type:'text', text:string, fontSize:number, fontFamily:string}} TextElement
 *
 * @typedef {BaseElement & {
 *   type:'widget',
 *   widgetType:'code'|'note'|'array'|'json'|'csv'|'linked-list'|'stack'|'queue'|'tree'|'hash-map',
 *   widgetData: any,
 * }} WidgetElement
 *
 * @typedef {StrokeElement|BoxElement|LineElement|TextElement|WidgetElement} Element
 *
 * @typedef {Object} Scene
 * @property {string} id
 * @property {string} name
 * @property {Element[]} elements
 * @property {Viewport} viewport
 * @property {number} updatedAt
 */

/** Factory for a canonical world-space viewport. */
export function defaultViewport() {
  return { zoom: 1, panX: 0, panY: 0 };
}

export const CANVAS_DOCUMENT_VERSION = 2;

export function defaultStyle(isDark) {
  return {
    stroke: isDark ? '#e2e8f0' : '#1e293b',
    fill: 'transparent',
    strokeWidth: 2,
    opacity: 1,
    dash: 'solid',
  };
}

let _counter = 0;
export function uid(prefix = 'el') {
  _counter += 1;
  return `${prefix}_${Date.now().toString(36)}_${_counter.toString(36)}`;
}

function stableSeed(id) {
  const text = String(id || 'element');
  let hash = 2166136261;
  for (let index = 0; index < text.length; index += 1) {
    hash ^= text.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return Math.abs(hash) || 1;
}

function normalizeLinearPoints(element) {
  if (Array.isArray(element.points) && element.points.length >= 2) {
    return element.points.map((point) => [
      Number(point?.[0]) || 0,
      Number(point?.[1]) || 0,
    ]);
  }
  const x2 = Number.isFinite(element.x2) ? element.x2 : element.x;
  const y2 = Number.isFinite(element.y2) ? element.y2 : element.y;
  return [[0, 0], [x2 - element.x, y2 - element.y]];
}

/**
 * Backfills the Excalidraw-compatible V2 fields while preserving the compact
 * legacy fields used by existing widgets and tools.
 */
export function normalizeElementV2(input) {
  if (!input || typeof input !== 'object') return input;
  const id = input.id || uid(input.type || 'el');
  const width = Number.isFinite(input.width) ? input.width : (Number(input.w) || 0);
  const height = Number.isFinite(input.height) ? input.height : (Number(input.h) || 0);
  const element = {
    ...input,
    id,
    x: Number(input.x) || 0,
    y: Number(input.y) || 0,
    w: width,
    h: height,
    width,
    height,
    angle: Number(input.angle) || 0,
    seed: Number(input.seed) || stableSeed(id),
    roughness: Number.isFinite(input.roughness) ? input.roughness : 1,
    version: Math.max(1, Number(input.version) || 1),
    versionNonce: Number(input.versionNonce) || stableSeed(`${id}:${input.createdAt || 0}`),
    index: input.index ?? null,
    groupIds: Array.isArray(input.groupIds) ? input.groupIds : [],
    frameId: input.frameId ?? null,
    boundElements: Array.isArray(input.boundElements) ? input.boundElements : [],
    locked: Boolean(input.locked),
    link: input.link ?? null,
    updated: Number(input.updated) || Number(input.createdAt) || Date.now(),
    createdAt: Number(input.createdAt) || Date.now(),
    customData: {
      ...(input.customData || {}),
      schemaVersion: CANVAS_DOCUMENT_VERSION,
    },
  };

  if (element.type === 'line' || element.type === 'arrow') {
    const points = normalizeLinearPoints(element);
    const last = points[points.length - 1];
    element.points = points;
    element.x2 = element.x + last[0];
    element.y2 = element.y + last[1];
    element.w = element.x2 - element.x;
    element.h = element.y2 - element.y;
    element.width = Math.abs(element.w);
    element.height = Math.abs(element.h);
    element.startBinding = element.startBinding || null;
    element.endBinding = element.endBinding || null;
    element.startArrowhead = element.startArrowhead ?? null;
    element.endArrowhead = element.type === 'arrow'
      ? (element.endArrowhead || 'arrow')
      : (element.endArrowhead ?? null);
    element.elbowed = element.type === 'arrow' ? element.elbowed !== false : false;
    element.routing = element.routing || (element.elbowed ? 'orthogonal' : 'straight');
    element.labelId = element.labelId || null;
  }

  if (element.type === 'text') {
    element.containerId = element.containerId || null;
    element.originalText = element.originalText ?? element.text ?? '';
    element.textAlign = element.textAlign || 'left';
    element.verticalAlign = element.verticalAlign || 'top';
    element.autoResize = element.autoResize !== false;
    element.lineHeight = Number(element.lineHeight) || 1.25;
  }

  return element;
}

export function normalizeElementsV2(elements) {
  return (Array.isArray(elements) ? elements : []).map(normalizeElementV2);
}
