# Self Join — Problem List

> **20 problems in progressive difficulty. 10 MUST-DO highlighted. Covers hierarchy traversal, consecutive detection, pair finding, and duplicate matching. Sources: LeetCode, HackerRank, DataLemur.**

---

## 10 MUST-DO Problems (Start Here)


| #   | Problem                              | Platform   | Difficulty | Concept Tag           | Why Important                     |
| --- | ------------------------------------ | ---------- | ---------- | --------------------- | --------------------------------- |
| 1   | Employees Earning More Than Managers | LC 181     | Easy       | Hierarchical join     | Purest self join — foundation     |
| 2   | Rising Temperature                   | LC 197     | Easy       | Consecutive dates     | Row-to-previous comparison        |
| 3   | Duplicate Emails                     | LC 182     | Easy       | Duplicate detection   | Self join for matching values     |
| 4   | Consecutive Numbers                  | LC 180     | Medium     | Consecutive values    | 3-way self join or LAG            |
| 5   | Students With Same Birthday          | HackerRank | Medium     | Pair finding          | a.id < b.id pattern               |
| 6   | Employee Chain of Command            | Common     | Medium     | Multi-level hierarchy | Join table 3+ times               |
| 7   | Customers With Same City             | DataLemur  | Easy       | Pair finding          | Basic pair matching               |
| 8   | Friend Requests: Mutual Friends      | LC 1264    | Medium     | Pair + count          | Social graph via self join        |
| 9   | Employees Whose Salary > Dept Avg    | Common     | Medium     | Self + aggregate      | Self join with aggregate subquery |
| 10  | Consecutive Available Seats          | LC 603     | Easy       | Consecutive rows      | Adjacent seat matching            |


---

## Complete 20-Problem Progression

### Easy (Problems 1-7) — Build Foundation


| #   | Problem                              | Platform  | Concept        | Key Skill                                  |
| --- | ------------------------------------ | --------- | -------------- | ------------------------------------------ |
| 1   | Employees Earning More Than Managers | LC 181    | Hierarchy      | e.manager_id = m.id, e.salary > m.salary   |
| 2   | Rising Temperature                   | LC 197    | Consecutive    | Join on date + 1 day, compare temps        |
| 3   | Duplicate Emails                     | LC 182    | Duplicates     | a.email = b.email AND a.id != b.id         |
| 4   | Consecutive Available Seats          | LC 603    | Consecutive    | a.id + 1 = b.id, both free                 |
| 5   | Customers With Same City             | DataLemur | Pairs          | a.city = b.city AND a.id < b.id            |
| 6   | Delete Duplicate Emails              | LC 196    | Dedup          | Self join to find dupes, DELETE smaller id |
| 7   | Biggest Single Number                | LC 619    | Self anti-join | Number that appears exactly once           |


### Medium (Problems 8-15) — Core Patterns


| #   | Problem                                   | Platform   | Concept           | Key Skill                              |
| --- | ----------------------------------------- | ---------- | ----------------- | -------------------------------------- |
| 8   | Consecutive Numbers                       | LC 180     | 3-consecutive     | Triple self join or LAG approach       |
| 9   | Employee Chain of Command                 | Common     | Multi-level       | Join 3× for emp → mgr → VP             |
| 10  | Friend Requests: Mutual Friends           | LC 1264    | Graph pairs       | Count shared connections               |
| 11  | Employees Salary > Dept Average           | Common     | Self + agg        | Join with dept average subquery        |
| 12  | Products More Expensive Than Category Avg | Common     | Self + agg        | Compare product to its category avg    |
| 13  | Symmetric Pairs                           | HackerRank | Pair matching     | a.x = b.y AND a.y = b.x AND a.x <= b.x |
| 14  | Triangle Judgement                        | LC 610     | Triple comparison | Check triangle inequality on same row  |
| 15  | Employees Who Report to Same Manager      | Common     | Shared parent     | a.mgr = b.mgr AND a.id < b.id          |


### Hard (Problems 16-20) — Interview Differentiators


| #   | Problem                               | Platform | Concept        | Key Skill                                 |
| --- | ------------------------------------- | -------- | -------------- | ----------------------------------------- |
| 16  | Human Traffic of Stadium              | LC 601   | 3+ consecutive | 3-way self join on consecutive ids        |
| 17  | Find Cumulative Salary of an Employee | LC 579   | Self + running | 3-month running sum via self join         |
| 18  | Department vs Company Comparison      | LC 615   | Self + cross   | Compare dept avg to company avg per month |
| 19  | Trips and Users (Cancellation Rate)   | LC 262   | Self + filter  | Join trips with users, rate calc          |
| 20  | Count Pairs With Distance <= K        | Advanced | Pair + math    | a.id < b.id with distance constraint      |


---

## Problem-by-Problem Strategy Notes

### Problem 1: Employees Earning More Than Managers (LC 181)

```
Pattern:     Hierarchical self join
Approach:    JOIN employees e, employees m ON e.manager_id = m.id
             WHERE e.salary > m.salary
Key Insight: LEFT side is employee, RIGHT side is their manager
One-liner:   Self join on manager_id = id, filter salary > manager's salary.
```

### Problem 2: Rising Temperature (LC 197)

```
Pattern:     Consecutive date comparison
Approach:    JOIN weather a, weather b ON b.recordDate = a.recordDate + 1
             WHERE b.temperature > a.temperature
Key Insight: Join links "today" to "yesterday" — then compare
One-liner:   Self join on date+1, filter where today's temp > yesterday's.
```

### Problem 8: Consecutive Numbers (LC 180)

```
Pattern:     Triple self join
Approach:    a.id + 1 = b.id AND b.id + 1 = c.id
             AND a.num = b.num AND b.num = c.num
Key Insight: Three copies of same table, linked by consecutive IDs
One-liner:   Three-way self join on consecutive IDs, all nums must match.
```

### Problem 13: Symmetric Pairs (HackerRank)

```
Pattern:     Mirror pair matching
Approach:    a.x = b.y AND a.y = b.x AND a.x <= a.y
             Special case: a.x = a.y needs COUNT >= 2
Key Insight: a.x <= a.y avoids printing both (a,b) and (b,a)
One-liner:   Self join where x,y are swapped; use <= to avoid duplicates.
```

---

## Pattern Distribution

```
HIERARCHICAL (parent-child):       5 problems  (1, 6, 9, 15, 18)
CONSECUTIVE (sequential rows):     5 problems  (2, 4, 8, 16, 17)
PAIR FINDING (combinations):       6 problems  (3, 5, 10, 13, 14, 20)
DUPLICATE DETECTION:               2 problems  (3, 6)
SELF + AGGREGATE:                  2 problems  (11, 12)
```

---

## Study Plan

### Week 1: Foundation (Days 1-3)

- Day 1: LC 181, LC 197 (hierarchy + consecutive)
- Day 2: LC 182, LC 603 (duplicates + adjacent)
- Day 3: LC 196, DataLemur pairs (delete dupes + pair matching)

### Week 2: Core Patterns (Days 4-6)

- Day 4: LC 180 (3-consecutive), LC 610 (triangle)
- Day 5: Multi-level hierarchy, symmetric pairs
- Day 6: Self + aggregate patterns

### Week 3: Hard + Review (Days 7-9)

- Day 7: LC 601, LC 579 (stadium traffic, cumulative salary)
- Day 8: LC 262, LC 615 (trips, dept vs company)
- Day 9: Re-solve MUST-DO without hints

---

## Cross-Reference: Related Patterns


| If You Need...            | Use This Pattern Instead/Also                                 |
| ------------------------- | ------------------------------------------------------------- |
| Previous/next row value   | Pattern 01 (Window Functions) — LAG/LEAD is cleaner           |
| Arbitrary depth hierarchy | Pattern 02 (Recursive CTE) — self join limited to fixed depth |
| Detect duplicates         | Pattern 12 (Deduplication) — GROUP BY approach often simpler  |
| Find pairs across tables  | Regular JOIN — self join only for same-table pairs            |


---

## FINAL MEMORY COMPRESSION BLOCK

```
TOTAL PROBLEMS:     20 (7 Easy, 8 Medium, 5 Hard)
MUST-DO:            LC 181, 197, 182, 180, 603 + HackerRank/DataLemur pairs
TOP 3 MOST ASKED:   LC 181 (Emp > Manager), LC 197 (Rising Temp), LC 180 (Consecutive)
PATTERN SPLIT:      Hierarchy (5), Consecutive (5), Pairs (6), Dupes (2), Agg (2)
STUDY ORDER:        Hierarchy → Consecutive → Pairs → Self+Aggregate → Hard
KEY INSIGHT:        Two aliases on same table = two pointers on same array
INTERVIEW LINE:     "I self join when I need to compare rows within the same
                     table — using a.id < b.id for unique pairs, or
                     a.manager_id = b.id for hierarchy traversal."
```

---

## 30-SECOND REVISION BOX

```
SYNTAX:        FROM table a JOIN table b ON a.col = b.col
SELF-MATCH:    AND a.id != b.id (exclude row matching itself)
UNIQUE PAIRS:  AND a.id < b.id (avoid (A,B) and (B,A) duplicates)
HIERARCHY:     ON e.manager_id = m.id (child → parent)
CONSECUTIVE:   ON b.id = a.id + 1 (or date + 1 day)
DUPLICATES:    ON a.email = b.email AND a.id != b.id
PERFORMANCE:   O(N²) worst case — index join columns
PREFER LAG:    For simple prev/next row, LAG/LEAD is single-scan
```

