import { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/*
 * CodeLangDropdown — fully custom replacement for the native <select>.
 *
 * Design notes:
 *   - Trigger renders [monogram badge] [label] [chevron], using the same
 *     chevron weight as UserProfileMenu so icon language stays consistent.
 *   - Menu is portaled into document.body so the widget-shell `transform:
 *     scale()` ancestor doesn't capture our `position: fixed` containing
 *     block. We then position via viewport-relative coordinates.
 *   - Keyboard: Up/Down to navigate, Enter to select, Escape to close,
 *     Tab/blur to dismiss. Outside click closes too.
 *   - Inert outside select tool because parent .nc-widget-shell delegates
 *     pointer-events to children — and our trigger sits behind the existing
 *     `[data-nc-tool='select']` CSS gate.
 */

const Chevron = () => (
  <svg
    className="nc-code__lang-chev"
    width="12"
    height="12"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden
  >
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

const Check = () => (
  <svg
    className="nc-code__lang-option__check"
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.4"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden
  >
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

const PAD = 8;

export default function CodeLangDropdown({ value, options, onChange, ariaLabel = 'Language' }) {
  const triggerRef = useRef(null);
  const menuRef = useRef(null);
  const menuId = useId();
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ left: 0, top: 0, minWidth: 0, maxHeight: 320 });
  const [focusIdx, setFocusIdx] = useState(() =>
    Math.max(0, options.findIndex((o) => o.id === value)),
  );

  const selected = useMemo(() => options.find((o) => o.id === value) || options[0], [options, value]);

  const place = useCallback(() => {
    const trigger = triggerRef.current;
    if (!trigger) return;
    const r = trigger.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const minWidth = Math.max(180, r.width);
    const spaceBelow = vh - r.bottom - PAD;
    const spaceAbove = r.top - PAD;
    const placeBelow = spaceBelow >= 200 || spaceBelow >= spaceAbove;
    const maxHeight = Math.max(160, Math.min(360, placeBelow ? spaceBelow : spaceAbove));
    let left = r.left;
    if (left + minWidth + PAD > vw) left = Math.max(PAD, vw - minWidth - PAD);
    const top = placeBelow ? r.bottom + 6 : r.top - maxHeight - 6;
    setPos({ left, top, minWidth, maxHeight });
  }, []);

  useLayoutEffect(() => {
    if (!open) return;
    place();
  }, [open, place]);

  useEffect(() => {
    if (!open) return;
    const onScrollOrResize = () => place();
    window.addEventListener('scroll', onScrollOrResize, true);
    window.addEventListener('resize', onScrollOrResize);
    return () => {
      window.removeEventListener('scroll', onScrollOrResize, true);
      window.removeEventListener('resize', onScrollOrResize);
    };
  }, [open, place]);

  useEffect(() => {
    if (!open) return;
    const onDocDown = (e) => {
      if (menuRef.current?.contains(e.target)) return;
      if (triggerRef.current?.contains(e.target)) return;
      setOpen(false);
    };
    document.addEventListener('mousedown', onDocDown, true);
    return () => document.removeEventListener('mousedown', onDocDown, true);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        setOpen(false);
        triggerRef.current?.focus();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setFocusIdx((i) => Math.min(options.length - 1, i + 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setFocusIdx((i) => Math.max(0, i - 1));
      } else if (e.key === 'Home') {
        e.preventDefault();
        setFocusIdx(0);
      } else if (e.key === 'End') {
        e.preventDefault();
        setFocusIdx(options.length - 1);
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const opt = options[focusIdx];
        if (opt) {
          onChange(opt.id);
          setOpen(false);
          triggerRef.current?.focus();
        }
      } else if (e.key === 'Tab') {
        setOpen(false);
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => document.removeEventListener('keydown', onKey, true);
  }, [open, options, focusIdx, onChange]);

  const onTriggerKeyDown = (e) => {
    if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      setFocusIdx(Math.max(0, options.findIndex((o) => o.id === value)));
      setOpen(true);
    }
  };

  return (
    <>
      <button
        type="button"
        ref={triggerRef}
        className={`nc-code__lang-trigger${open ? ' is-open' : ''}`}
        onPointerDown={(event) => event.preventDefault()}
        onClick={() => {
          setFocusIdx(Math.max(0, options.findIndex((o) => o.id === value)));
          setOpen((v) => !v);
        }}
        onKeyDown={onTriggerKeyDown}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? menuId : undefined}
        aria-label={ariaLabel}
      >
        <span className="nc-code__lang-label">{selected.label}</span>
        <Chevron />
      </button>
      {open && typeof document !== 'undefined' && createPortal(
        <div
          ref={menuRef}
          id={menuId}
          className="nc-code__lang-menu"
          role="listbox"
          aria-label={ariaLabel}
          style={{
            left: pos.left,
            top: pos.top,
            minWidth: pos.minWidth,
            maxHeight: pos.maxHeight,
          }}
        >
          {options.map((opt, i) => {
            const isActive = opt.id === value;
            const isFocused = i === focusIdx;
            return (
              <button
                key={opt.id}
                type="button"
                role="option"
                aria-selected={isActive}
                className={`nc-code__lang-option${isActive ? ' is-active' : ''}${isFocused ? ' is-focused' : ''}`}
                onMouseEnter={() => setFocusIdx(i)}
                onClick={() => {
                  onChange(opt.id);
                  setOpen(false);
                  triggerRef.current?.focus();
                }}
              >
                <span className="nc-code__lang-option__label">{opt.label}</span>
                <Check />
              </button>
            );
          })}
        </div>,
        document.body,
      )}
    </>
  );
}
