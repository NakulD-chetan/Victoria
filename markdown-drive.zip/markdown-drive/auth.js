import { createHash, randomBytes, randomUUID } from 'crypto';
import { existsSync } from 'fs';
import { readFile, writeFile, mkdir } from 'fs/promises';
import { join } from 'path';

export class AuthManager {
  constructor(metaDir) {
    this.metaDir = metaDir;
    this.usersFile = join(metaDir, 'users.json');
    this.sharesFile = join(metaDir, 'shares.json');
    this.users = [];
    this.shares = [];
  }

  async init() {
    if (!existsSync(this.metaDir)) await mkdir(this.metaDir, { recursive: true });
    this.users = await this._load(this.usersFile, []);
    this.shares = await this._load(this.sharesFile, []);
  }

  async _load(path, fallback) {
    try {
      if (existsSync(path)) return JSON.parse(await readFile(path, 'utf-8'));
    } catch {}
    return fallback;
  }

  async _saveUsers() { await writeFile(this.usersFile, JSON.stringify(this.users, null, 2)); }
  async _saveShares() { await writeFile(this.sharesFile, JSON.stringify(this.shares, null, 2)); }

  _hash(value, salt) {
    return createHash('sha256').update(`${salt}:${value}`).digest('hex');
  }

  hasUsers() { return this.users.length > 0; }

  async createUser(name, pin) {
    const salt = randomBytes(16).toString('hex');
    const token = randomUUID();
    const user = {
      id: randomUUID(),
      name: name.trim() || 'User',
      pinHash: this._hash(pin, salt),
      salt,
      token,
      role: this.users.length === 0 ? 'owner' : 'member',
      createdAt: new Date().toISOString(),
      lastLogin: new Date().toISOString(),
    };
    this.users.push(user);
    await this._saveUsers();
    return { id: user.id, name: user.name, token, role: user.role };
  }

  async verifyToken(token) {
    if (!token) return null;
    const user = this.users.find(u => u.token === token);
    if (!user) return null;
    user.lastLogin = new Date().toISOString();
    await this._saveUsers();
    return { id: user.id, name: user.name, role: user.role };
  }

  async loginWithPin(pin) {
    for (const user of this.users) {
      if (this._hash(pin, user.salt) === user.pinHash) {
        const newToken = randomUUID();
        user.token = newToken;
        user.lastLogin = new Date().toISOString();
        await this._saveUsers();
        return { id: user.id, name: user.name, token: newToken, role: user.role };
      }
    }
    return null;
  }

  getUser(id) {
    const u = this.users.find(u => u.id === id);
    if (!u) return null;
    return { id: u.id, name: u.name, role: u.role, createdAt: u.createdAt };
  }

  // ── Share Management ──────────────────────────────────────────

  async createShare(folderPath, userId, options = {}) {
    const {
      permissions = ['view'],
      expiresInDays = null,
      expiresInHours = null,
      password = null,
      maxAccess = null,
      label = '',
      allowDownload = true,
    } = options;

    let expiresAt = null;
    if (expiresInHours) {
      expiresAt = new Date(Date.now() + expiresInHours * 3600000).toISOString();
    } else if (expiresInDays) {
      expiresAt = new Date(Date.now() + expiresInDays * 86400000).toISOString();
    }

    let passwordHash = null;
    let passwordSalt = null;
    if (password) {
      passwordSalt = randomBytes(16).toString('hex');
      passwordHash = this._hash(password, passwordSalt);
    }

    const share = {
      id: randomUUID().replace(/-/g, '').slice(0, 12),
      folderPath,
      createdBy: userId,
      label: label || `Share ${new Date().toLocaleDateString()}`,
      permissions,
      passwordHash,
      passwordSalt,
      hasPassword: !!password,
      maxAccess: maxAccess || null,
      allowDownload,
      createdAt: new Date().toISOString(),
      expiresAt,
      accessCount: 0,
      lastAccessedAt: null,
      active: true,
    };
    this.shares.push(share);
    await this._saveShares();
    return this._sanitizeShare(share);
  }

  async updateShare(shareId, userId, updates) {
    const share = this.shares.find(s => s.id === shareId && s.createdBy === userId);
    if (!share) return null;

    if (updates.label !== undefined) share.label = updates.label;
    if (updates.permissions !== undefined) share.permissions = updates.permissions;
    if (updates.maxAccess !== undefined) share.maxAccess = updates.maxAccess || null;
    if (updates.allowDownload !== undefined) share.allowDownload = updates.allowDownload;
    if (updates.active !== undefined) share.active = updates.active;

    if (updates.expiresInDays !== undefined) {
      share.expiresAt = updates.expiresInDays
        ? new Date(Date.now() + updates.expiresInDays * 86400000).toISOString()
        : null;
    }
    if (updates.expiresInHours !== undefined) {
      share.expiresAt = updates.expiresInHours
        ? new Date(Date.now() + updates.expiresInHours * 3600000).toISOString()
        : null;
    }

    if (updates.password !== undefined) {
      if (updates.password) {
        share.passwordSalt = randomBytes(16).toString('hex');
        share.passwordHash = this._hash(updates.password, share.passwordSalt);
        share.hasPassword = true;
      } else {
        share.passwordHash = null;
        share.passwordSalt = null;
        share.hasPassword = false;
      }
    }

    await this._saveShares();
    return this._sanitizeShare(share);
  }

  _isShareValid(share) {
    if (!share.active) return false;
    if (share.expiresAt && new Date(share.expiresAt) < new Date()) return false;
    if (share.maxAccess && share.accessCount >= share.maxAccess) return false;
    return true;
  }

  async accessShare(shareId) {
    const share = this.shares.find(s => s.id === shareId);
    if (!share) return null;
    if (!this._isShareValid(share)) return null;
    return { ...this._sanitizeShare(share), requiresPassword: share.hasPassword };
  }

  async verifySharePassword(shareId, password) {
    const share = this.shares.find(s => s.id === shareId);
    if (!share || !share.hasPassword) return false;
    return this._hash(password, share.passwordSalt) === share.passwordHash;
  }

  async recordShareAccess(shareId) {
    const share = this.shares.find(s => s.id === shareId);
    if (!share) return;
    share.accessCount++;
    share.lastAccessedAt = new Date().toISOString();
    await this._saveShares();
  }

  _sanitizeShare(share) {
    const { passwordHash, passwordSalt, ...safe } = share;
    return safe;
  }

  getSharesForFolder(folderPath) {
    return this.shares
      .filter(s => s.folderPath === folderPath)
      .map(s => ({
        ...this._sanitizeShare(s),
        status: this._isShareValid(s) ? 'active' : 'expired',
      }));
  }

  getSharesByUser(userId) {
    return this.shares
      .filter(s => s.createdBy === userId)
      .map(s => ({
        ...this._sanitizeShare(s),
        status: this._isShareValid(s) ? 'active' : 'expired',
      }));
  }

  async deleteShare(shareId, userId) {
    const idx = this.shares.findIndex(s => s.id === shareId && s.createdBy === userId);
    if (idx === -1) return false;
    this.shares.splice(idx, 1);
    await this._saveShares();
    return true;
  }

  async toggleShareActive(shareId, userId) {
    const share = this.shares.find(s => s.id === shareId && s.createdBy === userId);
    if (!share) return null;
    share.active = !share.active;
    await this._saveShares();
    return this._sanitizeShare(share);
  }
}

export function authMiddleware(authManager) {
  return async (req, res, next) => {
    if (req.path.startsWith('/auth/') || req.path.startsWith('/share/')
      || req.path.startsWith('/algorithms') || req.path.startsWith('/problems')
      || req.path.startsWith('/execute') || req.path.startsWith('/sql/execute')) {
      return next();
    }

    if (!authManager.hasUsers()) return next();

    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Authentication required', code: 'NO_TOKEN' });
    }

    const token = header.slice(7);

    /* Legacy: the original code accepted any token starting with `firebase-`
     * and trusted the UID portion without verifying it against Firebase
     * Admin. That was an authentication bypass and is removed in v4 — we
     * now require a real, verifiable Supabase JWT (handled by the wrapper
     * middleware in supabase-jwt.js) or a PIN-issued opaque token below. */
    if (token.startsWith('firebase-')) {
      return res.status(401).json({
        error: 'Firebase tokens are no longer accepted. Please sign in again to migrate to the new auth system.',
        code: 'AUTH_MIGRATION_REQUIRED',
      });
    }

    const user = await authManager.verifyToken(token);
    if (!user) {
      return res.status(401).json({ error: 'Invalid token', code: 'INVALID_TOKEN' });
    }

    req.user = user;
    next();
  };
}
