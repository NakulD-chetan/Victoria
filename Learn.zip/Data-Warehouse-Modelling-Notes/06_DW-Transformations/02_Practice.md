# Data Warehouse Transformations — Practice

> "Transformations are where business rules meet data: clarity beats cleverness."

---

## Quick Recall

**Q:** What is the difference between cleansing and conforming?  
**A:** Cleansing fixes quality issues (nulls, duplicates); conforming aligns keys and attributes to enterprise standards.

**Q:** What is surrogate key assignment in retail dimensions?  
**A:** Replacing source system IDs with warehouse-managed integers to handle merges, changes, and multiple sources.

**Q:** Name a common transformation on e-commerce order currency.  
**A:** Convert multi-currency amounts to a reporting currency using a daily exchange rate dimension or table.

**Q:** What is denormalization in warehouse modeling?  
**A:** Flattening hierarchies into dimension attributes to reduce joins at query time.

**Q:** What is a slowly changing dimension Type 1 change?  
**A:** Overwrite the attribute in place; history of the old value is not preserved in that dimension row.

---

## Interview Questions

**1. Walk through how you transform raw marketplace orders into `fact_sales`.**  
**Model answer:** I validate grain (one line per SKU per order), dedupe idempotent loads, map seller and product to conformed keys, derive `net_sales = gross - discount - allocated_tax`, convert currency to corporate USD, and assign `order_date_key` from a trusted timestamp in the customer's time zone policy. I log batch totals for reconciliation before publishing.

**2. How do you handle ambiguous product identifiers from dropship partners?**  
**Model answer:** Maintain a staging cross-reference table, human-in-the-loop mapping for low-volume exceptions, and default to `UNKNOWN_PRODUCT` only with explicit reporting flags. Never silently pick a random SKU match when GTIN collisions occur.

**3. What is the role of a business rules engine vs SQL transforms?**  
**Model answer:** Complex branching rules with audit trails sometimes belong in a rules service or metadata-driven framework; SQL remains fine for stable, reviewable transformations in many retail pipelines. The decision hinges on who must change the rule and how often.

**4. Explain conforming a customer across guest checkout and loyalty accounts.**  
**Model answer:** Use identity resolution with confidence tiers, separate `party_id` from `account_id`, and never silently merge without governance thresholds. Retail fraud and privacy reviews care deeply about this boundary.

**5. How do you document transformations for compliance?**  
**Model answer:** Field-level lineage, versioned rule definitions, change tickets, and reconciliation outputs stored with each load batch. PCI scope minimization is part of the story for payment-adjacent fields.

**6. What is idempotency and why does it matter?**  
**Model answer:** Re-running the same batch should not double-count rows; we use natural keys, merge logic, or merge keys to make loads safe on retry. Marketplaces retry pipelines constantly during incidents.

**7. When would you push logic to the BI layer instead of ETL?**  
**Model answer:** Presentation formatting and user-specific filters belong in BI; revenue recognition rules belong in the warehouse layer for consistency. If finance cares, it should not live in a desktop workbook only.

**8. How do you validate transformations before go-live?**  
**Model answer:** Parallel run against legacy reports, aggregate reconciliations by channel, edge-case sampling (returns, split shipments, gift cards), and sign-off from domain owners with explicit exception handling for late data.

---

## Scenario-Based Exercises

**Scenario 1 — Free shipping promotions**  
Marketing codes free shipping as a discount line; finance wants shipping revenue separate.  
**Solution:** Standardize line type codes in staging; split adjustments into `discount_amount` vs `shipping_subsidy_amount` columns with documented rules. Publish both measures so marketing and finance each see their view without forking tables.

**Scenario 2 — Returns posted days after original sale**  
**Solution:** Load return facts linked to `original_order_id`; optionally maintain rolling net sales measures with a clear as-of policy. Document whether reporting uses order date vs return posting date for each dashboard family.

**Scenario 3 — Multi-currency**  
European web sales in EUR, reporting in USD.  
**Solution:** Join to `dim_fx_rate` on `rate_date` and `from_currency`; store both `local_amount` and `usd_amount`.

```sql
SELECT o.order_id,
       o.gross_amount_local * r.rate_to_usd AS gross_amount_usd
FROM staging.orders o
JOIN dw.dim_fx_rate r
  ON r.rate_date = o.order_date
 AND r.from_currency = o.currency_code
 AND r.to_currency = 'USD';
```

**Scenario 4 — PII and seller fee changes**  
**Solution:** Hash email at ingest for join keys; keep raw email in a restricted vault table with tighter ACLs; tokenize device identifiers where possible for web analytics joins. When seller fee schedules change mid-quarter, model fees as a Type 2 `dim_seller_fee_plan` or snapshot fees on the fact at transaction time if payouts require frozen fees, aligning with marketplace finance policy before coding.

---

## Common Interview Traps

| Trap | Why It Catches You | How to Handle |
|------|--------------------|-----------------|
| Transform in BI "for speed" | Creates metric drift | Anchor financial rules in the warehouse |
| Overwriting facts on correction | Breaks audit | Model reversals or adjustments as new rows |
| Ignoring time zones for same-day sales | End-of-day mismatch | State policy: UTC vs local vs warehouse cut |
| Silent coalesce to zero | Hides bad data | Use explicit null handling and quarantine rows |
| One-size currency conversion | Intraday FX nuance | Document rate type (daily close vs intraday) |
| Encoding promotions inconsistently | Breaks margin math | Standardize line typing early in staging |

---

## One-Liner Answers

- Cleansing improves quality; conforming aligns entities and keys to enterprise standards.
- Surrogate keys decouple the warehouse from volatile source identifiers.
- Currency conversion belongs in transformation with a documented rate source and date.
- Idempotent merges prevent duplicate facts when pipelines retry.
- Business-critical rules should live where all consumers inherit the same logic.
- Identity resolution for retail customers should carry confidence and governance, not guesses.
