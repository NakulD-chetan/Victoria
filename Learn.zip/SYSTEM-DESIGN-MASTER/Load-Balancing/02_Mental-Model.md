# Load Balancing — Mental Model (Deep Understanding)

> **Permanent Recall:** Think of the LB as a **traffic cop**—it doesn't create traffic, it directs it. For algorithm choice: stateless/short-lived → round robin; variable duration → least connections; session/cache affinity → consistent hashing or IP hash. Always assume LB is a single point of failure—use active-passive pair or LB cluster.

---

## Mental Model 1: The Traffic Cop

**Load balancer = traffic cop at an intersection.**

Imagine a busy road with 3 lanes, each leading to a different toll booth. A traffic cop stands at the intersection:

```
     CARS (requests) arriving
           │ │ │ │ │
           ▼ ▼ ▼ ▼ ▼
      ┌───────────────┐
      │  TRAFFIC COP  │  ← Load Balancer
      │  (directs     │
      │   traffic)    │
      └───┬───┬───┬───┘
          │   │   │
          ▼   ▼   ▼
       Lane1 Lane2 Lane3  ← Backend Servers
       (Toll  (Toll  (Toll
       Booth1) Booth2) Booth3)
```

| Traffic Cop Behavior | LB Equivalent |
|---------------------|---------------|
| Cop sends cars to lanes in order | Round Robin |
| Cop sends car to shortest queue | Least Connections |
| Cop sends trucks to "heavy vehicle" lane | L7 path-based routing |
| Cop puts "CLOSED" sign on broken lane | Health check removes dead server |
| Cop keeps same family's cars in one lane | Sticky sessions |
| Cop is sick — no one directing traffic | LB is SPOF → chaos |

**Why this analogy works in interviews:** It immediately communicates that the LB is a **director, not a doer**. The LB doesn't process your request — it just decides WHERE to send it. The real work happens on the backend servers (toll booths).

---

## Mental Model 2: The Restaurant Host

Another powerful analogy — imagine you walk into a restaurant with 10 tables.

```
Customers arriving → Host (LB) → seats at tables (servers)

Without host: Everyone crowds Table 1, tables 2-10 empty
With host:    Host distributes evenly across all tables
```

| Restaurant Behavior | LB Equivalent |
|--------------------|---------------|
| Host seats next group at next empty table | Round Robin |
| Host seats at table with fewest people | Least Connections |
| Host seats VIP at their "usual table" | Sticky Sessions / IP Hash |
| Host closes table if waiter called in sick | Health Check → remove server |
| Host sends couples to small tables, groups to large | Weighted Round Robin |
| Two hosts work together (one main, one backup) | Active-Passive LB pair |

---

## Mental Model 3: The Mail Room Sorter

For understanding **L4 vs L7**, think of a mail room:

```
L4 LOAD BALANCER = Sorter who reads ONLY the envelope
┌─────────────┐
│ TO: Building A│  ← IP + Port = envelope address
│ FROM: John   │
│ [sealed]     │  ← Cannot open, cannot read contents
└─────────────┘
Decision: "Addressed to Building A, send to Building A mailbox"

L7 LOAD BALANCER = Sorter who OPENS the envelope and reads the letter
┌─────────────┐
│ TO: Building A│  ← IP + Port
│ FROM: John   │
│ Dear HR,     │  ← HTTP path: /hr/complaints
│ I want to    │  ← HTTP headers, cookies
│ file a       │  ← Can read everything
│ complaint... │
└─────────────┘
Decision: "This is addressed to HR → send to HR department (not marketing)"
```

**Key insight:**
- **L4** is fast because it doesn't open envelopes — just reads the outside
- **L7** is smarter because it reads the contents — but it takes more time

---

## Mental Model 4: Understanding Consistent Hashing

This is the hardest algorithm to understand. Let me build your intuition step by step.

### Problem: Why Normal Hashing Breaks

Say you have 3 cache servers and you use `hash(key) % 3`:

```
hash("user_1") % 3 = 0 → Server 0
hash("user_2") % 3 = 1 → Server 1
hash("user_3") % 3 = 2 → Server 2
hash("user_4") % 3 = 1 → Server 1
```

Now you add Server 3 (total = 4 servers). Formula becomes `hash(key) % 4`:

```
hash("user_1") % 4 = 1 → Server 1  (was 0 → MOVED!)
hash("user_2") % 4 = 2 → Server 2  (was 1 → MOVED!)
hash("user_3") % 4 = 3 → Server 3  (was 2 → MOVED!)
hash("user_4") % 4 = 0 → Server 0  (was 1 → MOVED!)
```

**ALMOST EVERY key moved to a different server!** For a cache, this means EVERY user's cached data is now on the wrong server → massive cache misses → database gets hammered → potential outage. This is called the **thundering herd problem**.

### Solution: The Hash Ring

Consistent hashing uses a **circular ring** (imagine a clock face from 0 to 360 degrees).

```
Step 1: Place SERVERS on the ring by hashing their names

        0°
        │
   S3 ●─┤──── 40°
        │
        │
  270° ─┤──── ● S1 (90°)
        │
        │
   S2 ●─┤──── 200°
        │
       180°

Step 2: Place KEYS on the ring by hashing the key value

        0°
        │
   S3 ●─┤── key_A (50°)
        │
        │
  270° ─┤──── ● S1 (90°)
        │
  key_B (150°)
   S2 ●─┤──── 200°
        │
  key_C (250°)
       
Step 3: Each key goes to the NEXT server clockwise:
  key_A (50°)  → next server clockwise = S1 (90°)
  key_B (150°) → next server clockwise = S2 (200°)
  key_C (250°) → next server clockwise = S3 (40° on next loop)
```

### What Happens When a Server is Added or Removed?

```
ADD Server S4 at 120°:

Before: key_B (150°) → S2 (200°)
After:  key_B (150°) → S2 (200°)  ← UNCHANGED!

Before: key_A (50°) → S1 (90°)
After:  key_A (50°) → S1 (90°)    ← UNCHANGED!

Only keys between the new server and the previous server get remapped.
That's roughly 1/N of all keys (not ALL keys like simple hash).
```

**This is why consistent hashing exists:** Adding or removing a server only affects ~1/N of the keys, not all of them. This minimizes cache misses during scale events.

### Virtual Nodes — Solving Uneven Distribution

With just 3 physical servers, the ring might have uneven gaps (one server handles 60% of the ring). Virtual nodes fix this:

```
Physical Server S1 → placed at 150 positions on the ring
Physical Server S2 → placed at 150 positions on the ring
Physical Server S3 → placed at 150 positions on the ring

Total: 450 points on the ring → very even distribution
Each physical server handles ~33% of keys
```

---

## Decision Tree: Which Algorithm to Choose (with reasoning)

```
START: What is your workload like?
  │
  ├── "Requests are short, similar, stateless (REST API)"
  │     └── ✅ Round Robin (simplest, fair for uniform workloads)
  │
  ├── "Servers have different CPU/RAM capacity"
  │     └── ✅ Weighted Round Robin (bigger server = bigger weight)
  │
  ├── "Requests have very different durations (some 1ms, some 30s)"
  │     └── ✅ Least Connections (adapts to real-time load)
  │
  ├── "Same user must hit same server (sessions stored locally)"
  │     ├── "Can we move sessions to Redis instead?"
  │     │     └── ✅ YES: Move to Redis + use Round Robin (best approach)
  │     └── "No, must stay on same server"
  │           ├── ✅ Cookie-based sticky (works across IP changes)
  │           └── ✅ IP Hash (simpler, but breaks behind NAT)
  │
  ├── "This is a cache pool (memcached / Redis cluster)"
  │     └── ✅ Consistent Hashing (scale in/out without killing cache)
  │
  └── "I honestly don't care / don't know"
        └── ✅ Round Robin (safe default)
```

---

## Mental Model for L4 vs L7 Decision

```
Ask yourself: "Does my LB need to READ the HTTP request?"

NO → Use L4
  Examples:
  - Forwarding TCP to a database cluster
  - High-throughput packet forwarding
  - SSL pass-through (backend handles TLS)
  - Non-HTTP protocols (gRPC binary, custom TCP)

YES → Use L7
  Examples:
  - Route /api/users to user-service, /api/orders to order-service
  - Terminate SSL at LB (decrypt once, send HTTP to backends)
  - Read cookies for sticky sessions
  - Rate limit by URL path
  - Cache responses at LB level
  - Add X-Forwarded-For header
```

### The Real-World Analogy

```
L4 = Airport security checking your TICKET
  "You have a ticket to Gate B? Go to Gate B."
  Doesn't care what's in your luggage.

L7 = Customs officer checking your LUGGAGE
  Opens your bags, reads your documents, asks questions.
  Can route you differently based on what you're carrying.
  Takes more time, but makes smarter decisions.
```

---

## Mental Model for Health Checking

### The Doctor Analogy

```
ACTIVE HEALTH CHECK = Regular doctor checkup
  Doctor (LB) calls you (server) every 6 months: "How are you?"
  If you don't answer 3 times → "Patient is unhealthy"
  ✅ Catches problems early
  ❌ Costs time/money (extra probe traffic)

PASSIVE HEALTH CHECK = Only go to doctor when you feel sick
  Doctor (LB) only notices when you (server) show symptoms (failed requests)
  If real patients (users) complain about you 5 times → "Something is wrong"
  ✅ No extra visits (no probe traffic)
  ❌ Slower to detect (users suffer first)
```

### What a Good Health Endpoint Looks Like

```
GET /health → responds in < 50ms

BASIC (just alive check):
  { "status": "healthy" }   → 200 OK

DETAILED (checks dependencies):
  {
    "status": "healthy",
    "database": "connected",    ← Can reach DB?
    "redis": "connected",       ← Can reach cache?
    "disk_space": "ok",         ← Enough disk?
    "memory": "ok"              ← Not OOM?
  }

If DB is down:
  { "status": "unhealthy", "database": "disconnected" } → 503
  LB sees 503 → starts counting failures → removes server
```

**Critical design choice:** Should the health endpoint check dependencies (DB, Redis)?
- **YES:** If DB is down, the server can't serve requests anyway → mark unhealthy → stop traffic
- **NO:** If DB is down for ALL servers, they ALL become unhealthy → LB has zero backends → total outage
- **Best practice:** Have two endpoints: `/health` (basic, for LB) and `/ready` (deep, for monitoring)

---

## LB as Single Point of Failure (SPOF) — Deep Understanding

### Why a Single LB is Dangerous

```
Normal:     Client → [LB] → [Server 1, Server 2, Server 3]
                      ↑
                    If this dies, NOTHING works!
                    
You added 10 backend servers for reliability...
but your ONE load balancer is the weakest link.
```

### Solution 1: Active-Passive Pair

```
┌─────────────────────────────────────────────┐
│                                             │
│  ┌──────────────┐    ┌──────────────┐       │
│  │  LB (Active) │    │ LB (Passive) │       │
│  │  IP: 10.0.0.1│◄──►│ IP: 10.0.0.2│       │
│  │  Handles ALL │    │ Sits IDLE    │       │
│  │  traffic     │    │ Monitors     │       │
│  └──────┬───────┘    │ active via   │       │
│         │            │ heartbeat    │       │
│         │            └──────┬───────┘       │
│         │                   │               │
│  Virtual IP (VIP): 10.0.0.100              │
│  Clients connect to VIP, not real IPs       │
│                                             │
└─────────────────────────────────────────────┘

HOW FAILOVER WORKS:
1. Active LB holds the VIP (10.0.0.100) and serves all traffic
2. Passive LB sends heartbeat to Active every 1 second
3. If Active doesn't respond to 3 heartbeats → Passive assumes it's dead
4. Passive takes over the VIP (10.0.0.100) using gratuitous ARP
5. All new packets to 10.0.0.100 now go to Passive (now the new Active)
6. Clients don't notice — they still connect to 10.0.0.100
```

**What is a VIP (Virtual IP)?**
A VIP is an IP address that doesn't belong to a specific machine — it **floats** between machines. Whoever "owns" it right now gets the traffic. It's like a phone number that can be forwarded to different phones.

**What is Gratuitous ARP?**
When the passive LB takes over, it sends an ARP broadcast: "Hey everyone on this network, IP 10.0.0.100 is now at MY MAC address." All switches/routers update their tables and route traffic to the new LB.

**Tradeoff:** The passive LB is idle — you're paying for a server that does nothing 99.9% of the time.

### Solution 2: Active-Active (Multiple LBs)

```
┌─────────────────────────────────────────────┐
│  DNS returns multiple IPs (or anycast):     │
│                                             │
│  ┌───────┐  ┌───────┐  ┌───────┐           │
│  │ LB 1  │  │ LB 2  │  │ LB 3  │           │
│  │Active │  │Active │  │Active │           │
│  └───┬───┘  └───┬───┘  └───┬───┘           │
│      │          │          │                │
│      └──────────┼──────────┘                │
│                 │                           │
│          Backend Pool                       │
│    [S1] [S2] [S3] [S4] [S5]                │
└─────────────────────────────────────────────┘

If LB 2 dies:
  DNS removes LB 2's IP (or anycast routes around it)
  LB 1 and LB 3 handle all traffic
  No single LB is critical
```

**Anycast explained:** All LBs share the SAME IP address. The internet (BGP routing) automatically sends each user to the geographically nearest LB. If one LB dies, BGP routes around it. This is how Cloudflare, Google, and AWS work.

| | Active-Passive | Active-Active |
|---|----------------|---------------|
| **Cost** | One idle LB (50% "wasted") | All LBs work (better utilization) |
| **Failover speed** | Few seconds (heartbeat + ARP) | Instant (traffic shifts to other LBs) |
| **Complexity** | Simple (heartbeat + VIP) | Complex (shared state, DNS/anycast) |
| **Scaling** | Can't scale (only 1 active) | Add more LBs for more capacity |

---

## Mental Model: How the Request Flows End-to-End

```
USER types https://api.example.com/users in browser

Step 1: DNS Resolution
  Browser → DNS → "api.example.com = 52.12.34.56" (LB's IP)

Step 2: TCP Connection
  Browser opens TCP connection to 52.12.34.56:443

Step 3: SSL/TLS Handshake
  Browser and LB negotiate encryption (certificates exchanged)
  
Step 4: HTTP Request sent (now encrypted)
  GET /api/users HTTP/1.1
  Host: api.example.com
  Cookie: session=xyz

Step 5: LB Receives and Decides
  L7 LB decrypts SSL → reads HTTP → sees path /api/users
  Routing rule: /api/* → backend pool "api-servers"
  Algorithm: Round Robin → picks Server 2 (10.0.1.2:8080)
  
Step 6: LB Forwards to Backend
  LB opens HTTP connection to 10.0.1.2:8080
  Adds headers: X-Forwarded-For: <user's real IP>
  Forwards: GET /api/users

Step 7: Backend Processes
  Server 2 processes request, queries DB, builds response

Step 8: Response Returns
  Server 2 → HTTP 200 + JSON body → LB
  LB encrypts (SSL) → sends to browser
  
Step 9: Browser Renders
  Browser shows users list
  User never knew Server 2 existed
```

---

## Quick Memory Card

```
ANALOGY:       LB = traffic cop / restaurant host; directs, doesn't create
L4 vs L7:      L4 = reads envelope (IP/port); L7 = reads letter (HTTP content)
ALGORITHM:     Affinity? → hash/sticky. Varying duration? → least conn. Else → RR
CONSISTENT HASH: Ring of servers + keys; add/remove server affects only ~1/N keys
HEALTH:        Active = doctor checkup; Passive = wait for symptoms
SPOF:          Single LB = bad. Active-passive (VIP) or active-active (anycast)
VIP:           Floating IP that moves between LBs on failover
REQUEST FLOW:  DNS → LB → decrypt SSL → pick server → forward → response → encrypt → client
```

---

**Next:** [[03_Design-Template]]
