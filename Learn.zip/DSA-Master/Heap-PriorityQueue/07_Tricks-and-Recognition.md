# Heap — Tricks and Recognition

> **"Top K" → heap. "Median of stream" → two heaps. "Merge K sorted" → min-heap. Pattern triggers for FAANG.**

---

## Recognition Triggers

| Phrase / Clue | Pattern | Heap Setup |
|---------------|---------|------------|
| "Top K" | Top-K | Min-heap size K (largest) or Max-heap size K (smallest) |
| "K largest" | Top-K | Min-heap size K |
| "K smallest" | Top-K | Max-heap size K |
| "Kth largest" | Kth element | Min-heap size K; root = answer |
| "Kth smallest" | Kth element | Max-heap size K; root = answer |
| "Median of stream" | Two-heap | Max-heap (left) + Min-heap (right) |
| "Running median" | Two-heap | Same |
| "Merge K sorted" | Merge K | Min-heap of (val, list_idx) |
| "K closest points" | K closest | Max-heap size K by distance |
| "K farthest" | K farthest | Min-heap size K by distance |
| "Most frequent K" | Top-K by freq | Min-heap size K by frequency |
| "Task scheduler" | Greedy + heap | Max-heap by frequency |
| "Kth largest in stream" | Streaming Top-K | Min-heap size K |

---

## "Top K" / "Kth Largest" → Heap

**Trigger words:** top, largest, smallest, kth, most, best, frequent

**Decision:** Min-heap of size K for K largest. Root = Kth largest.

**Why heap over sort:** Streaming data; or when K is small (O(n log K) vs O(n log n)).

---

## "Median of Stream" → Two Heaps

**Trigger words:** median, running median, find median as data streams

**Decision:** Max-heap (left half) + Min-heap (right half). Balance sizes. Median = top(s).

**No alternative:** Two heaps is the standard. Sorting each time would be O(n² log n).

---

## "Merge K Sorted" → Min-Heap

**Trigger words:** merge, K sorted lists/arrays, combine K sorted

**Decision:** Min-heap of (value, list_index, element_index). Pop smallest, push next from that list.

**Complexity:** O(N log K) where N = total elements, K = number of lists.

---

## "K Closest Points" → Max-Heap of Size K

**Trigger words:** closest, nearest, K points, distance from origin

**Decision:** Max-heap by distance. Keep K smallest distances. Evict when closer point arrives.

**Trick:** Use squared distance (x² + y²) to avoid sqrt — same ordering.

---

## Heap vs Quickselect — Decision Tree

```mermaid
flowchart TD
    A{Is data STREAMING?}
    A -->|YES| B[Heap only option]
    A -->|NO| C{K small?}
    C -->|YES| D[Heap is fine O(n log K)]
    C -->|NO| E{Need Kth only?}
    E -->|YES| F[Quickselect O(n) avg]
    E -->|NO| G[Heap or sort both work]
    style A fill:#ffd43b,color:#000
    style C fill:#ffd43b,color:#000
    style E fill:#ffd43b,color:#000
    style B fill:#51cf66,color:#fff
    style D fill:#51cf66,color:#fff
    style F fill:#339af0,color:#fff
    style G fill:#339af0,color:#fff
```

<details><summary>ASCII fallback</summary>

```
Is data STREAMING (arrives one by one)?
  YES → Heap (only option)
  NO  → Is K small (e.g., K < 100)?
          YES → Heap is fine (O(n log K))
          NO  → Need Kth only (not full Top-K)?
                  YES → Quickselect O(n) avg
                  NO  → Heap or sort both work
```

</details>

---

## Custom Key Tricks

| Problem Type | Heap Key | Order |
|--------------|----------|-------|
| Top K by value | (val) | Min-heap for largest |
| Top K by frequency | (freq, val) | Min-heap by freq |
| K closest | (dist², point) | Max-heap by dist |
| Merge K | (val, list_idx, elem_idx) | Min-heap by val |
| Task scheduler | (freq) | Max-heap by freq |

---

## Python Negation Cheat Sheet

| Want | Store | Extract |
|------|-------|---------|
| Max-heap | `-x` or `(-freq, val)` | `-heapq.heappop(h)` |
| Min-heap | `x` | `heapq.heappop(h)` |
| Max by custom key | `(-key, val)` | `heapq.heappop(h)[1]` |

---

## C++ Comparator Cheat Sheet

| Want | Comparator |
|------|------------|
| Min-heap (default order) | `greater<int>` |
| Max-heap (default) | `less<int>` (default) |
| Max-heap by pair.second | `a.second < b.second` |
| Min-heap by pair.second | `a.second > b.second` |

---

## When NOT Heap — Red Flags

| Phrase | Use Instead |
|--------|-------------|
| "Sorted order" | Sort, or heap then extract all |
| "Range query" | Segment tree, BIT |
| "All elements, K=N" | Sort might be simpler |
| "Index of Kth" | Quickselect (returns index) |
| "BFS/DFS" | Queue/Stack |

---

## One-Line Recognition

```
"Top K" / "Kth"           → Min-heap size K (largest) or Max-heap (smallest)
"Median stream"           → Two heaps
"Merge K sorted"          → Min-heap of heads
"K closest"               → Max-heap size K by distance
"Most frequent K"        → Min-heap size K by frequency
"Task scheduler"          → Max-heap by frequency
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
TOP-K LARGEST:    Min-heap K; evict when new > root
TOP-K SMALLEST:   Max-heap K; evict when new < root
MEDIAN STREAM:    Max(left) + Min(right); balance
MERGE K:          Min-heap of (val, list_idx)
K CLOSEST:        Max-heap K by distance
HEAP VS QUICK:    Stream → heap; Static Kth → quickselect
PYTHON MAX:       Negate: -x or (-key, val)
CPP MIN:          greater<int>
RED FLAG:         Sorted output, range query → not heap
```
