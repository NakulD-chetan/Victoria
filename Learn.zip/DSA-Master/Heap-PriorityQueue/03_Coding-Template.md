# Heap — Coding Templates

> **Generic, reusable templates. Python: heapq. C++: priority_queue. Copy, adapt, solve.**

---

## Python: heapq Module

```python
import heapq

# heapq is MIN-HEAP only
# For max-heap: negate values, or use (-val, val) tuples

heapq.heapify(arr)        # O(n) in-place
heapq.heappush(h, x)      # O(log n)
heapq.heappop(h)          # O(log n) — returns min
h[0]                      # O(1) peek min (don't pop)
heapq.nlargest(k, arr)    # O(n log k) — built-in Top-K
heapq.nsmallest(k, arr)   # O(n log k)
```

---

## C++: priority_queue

```cpp
#include <queue>

// Default: MAX-HEAP (largest at top)
priority_queue<int> max_pq;

// Min-heap: use greater
priority_queue<int, vector<int>, greater<int>> min_pq;

// Custom comparator
auto cmp = [](int a, int b) { return a > b; };  // min-heap
priority_queue<int, vector<int>, decltype(cmp)> pq(cmp);

// Operations
pq.push(x);      // O(log n)
pq.pop();       // O(log n)
pq.top();       // O(1) peek
pq.empty();
pq.size();
```

---

## Rust: BinaryHeap

```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

// BinaryHeap is MAX-HEAP (largest at top)
let mut max_heap: BinaryHeap<i32> = BinaryHeap::new();

// Min-heap: wrap with Reverse
let mut min_heap: BinaryHeap<Reverse<i32>> = BinaryHeap::new();
min_heap.push(Reverse(5));

// Operations
max_heap.push(x);           // O(log n)
max_heap.pop();             // O(log n)
max_heap.peek();            // O(1) — Option<&T>
max_heap.is_empty();
max_heap.len();
```

**Rust note:** No decrease-key — push new entry, skip stale when popping.

---

## Template 1: Top K Elements (Min-Heap of Size K)

**Use when:** K largest elements from array or stream.

### Python

```python
def top_k_largest(nums, k):
    if k <= 0:
        return []
    heap = []  # min-heap of size k
    
    for x in nums:
        if len(heap) < k:
            heapq.heappush(heap, x)
        elif x > heap[0]:  # x is larger than smallest in heap
            heapq.heapreplace(heap, x)  # pop min, push x (more efficient)
            # OR: heapq.heappushpop(heap, x)
    
    return list(heap)  # order not guaranteed; sort if needed
```

### C++

```cpp
vector<int> topKLargest(vector<int>& nums, int k) {
    if (k <= 0) return {};
    priority_queue<int, vector<int>, greater<int>> min_heap;
    
    for (int x : nums) {
        if (min_heap.size() < k) {
            min_heap.push(x);
        } else if (x > min_heap.top()) {
            min_heap.pop();
            min_heap.push(x);
        }
    }
    
    vector<int> result;
    while (!min_heap.empty()) {
        result.push_back(min_heap.top());
        min_heap.pop();
    }
    return result;  // reverse if need descending
}
```

### Rust
```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

fn top_k_largest(nums: &[i32], k: usize) -> Vec<i32> {
    if k == 0 { return vec![]; }
    let mut heap: BinaryHeap<Reverse<i32>> = BinaryHeap::new();
    for &x in nums {
        if heap.len() < k {
            heap.push(Reverse(x));
        } else if x > heap.peek().unwrap().0 {
            heap.pop();
            heap.push(Reverse(x));
        }
    }
    heap.into_iter().map(|r| r.0).collect()
}
```
**Rust note:** `BinaryHeap<Reverse<T>>` = min-heap. `Reverse` wraps for opposite ordering.

---

## Template 2: Kth Largest Element

**Same as Top-K; at end, root = Kth largest.**

### Python

```python
def find_kth_largest(nums, k):
    heap = []
    for x in nums:
        if len(heap) < k:
            heapq.heappush(heap, x)
        elif x > heap[0]:
            heapq.heapreplace(heap, x)
    return heap[0]
```

### C++

```cpp
int findKthLargest(vector<int>& nums, int k) {
    priority_queue<int, vector<int>, greater<int>> min_heap;
    for (int x : nums) {
        if (min_heap.size() < k)
            min_heap.push(x);
        else if (x > min_heap.top()) {
            min_heap.pop();
            min_heap.push(x);
        }
    }
    return min_heap.top();
}
```

### Rust
```rust
fn find_kth_largest(nums: &[i32], k: usize) -> i32 {
    let mut heap: BinaryHeap<Reverse<i32>> = BinaryHeap::new();
    for &x in nums {
        if heap.len() < k {
            heap.push(Reverse(x));
        } else if x > heap.peek().unwrap().0 {
            heap.pop();
            heap.push(Reverse(x));
        }
    }
    heap.peek().unwrap().0
}
```

---

## Template 3: Two-Heap Median

**Use when:** Find median of stream as elements arrive.

### Python

```python
class MedianFinder:
    def __init__(self):
        self.lo = []   # max-heap: store negated for max
        self.hi = []   # min-heap
    
    def addNum(self, num):
        heapq.heappush(self.lo, -num)           # add to left
        heapq.heappush(self.hi, -heapq.heappop(self.lo))  # balance
        
        if len(self.lo) < len(self.hi):        # lo should be >= hi
            heapq.heappush(self.lo, -heapq.heappop(self.hi))
    
    def findMedian(self):
        if len(self.lo) > len(self.hi):
            return -self.lo[0]
        return (-self.lo[0] + self.hi[0]) / 2
```

### C++

```cpp
class MedianFinder {
    priority_queue<int> lo;  // max-heap
    priority_queue<int, vector<int>, greater<int>> hi;  // min-heap
    
public:
    void addNum(int num) {
        lo.push(num);
        hi.push(lo.top());
        lo.pop();
        if (lo.size() < hi.size()) {
            lo.push(hi.top());
            hi.pop();
        }
    }
    
    double findMedian() {
        return lo.size() > hi.size() ? lo.top() : (lo.top() + hi.top()) / 2.0;
    }
};
```

### Rust
```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

struct MedianFinder {
    lo: BinaryHeap<i32>,   // max-heap (default)
    hi: BinaryHeap<Reverse<i32>>,  // min-heap
}

impl MedianFinder {
    fn new() -> Self {
        Self { lo: BinaryHeap::new(), hi: BinaryHeap::new() }
    }
    fn add_num(&mut self, num: i32) {
        self.lo.push(num);
        if let Some(x) = self.lo.pop() {
            self.hi.push(Reverse(x));
        }
        if self.lo.len() < self.hi.len() {
            if let Some(Reverse(x)) = self.hi.pop() {
                self.lo.push(x);
            }
        }
    }
    fn find_median(&self) -> f64 {
        if self.lo.len() > self.hi.len() {
            *self.lo.peek().unwrap() as f64
        } else {
            (self.lo.peek().unwrap() + self.hi.peek().unwrap().0) as f64 / 2.0
        }
    }
}
```
**Rust note:** `BinaryHeap` default = max-heap. `Reverse` for min-heap. Balance sizes.

---

## Template 4: Merge K Sorted Lists

**Use when:** Merge K sorted linked lists or arrays.

### Python

```python
def merge_k_lists(lists):
    heap = []
    for i, lst in enumerate(lists):
        if lst:
            heapq.heappush(heap, (lst[0], i, 0))
    
    result = []
    while heap:
        val, list_idx, elem_idx = heapq.heappop(heap)
        result.append(val)
        lst = lists[list_idx]
        if elem_idx + 1 < len(lst):
            heapq.heappush(heap, (lst[elem_idx + 1], list_idx, elem_idx + 1))
    
    return result
```

**For linked lists (LeetCode 23):**

```python
def mergeKLists(self, lists):
    heap = []
    for i, node in enumerate(lists):
        if node:
            heapq.heappush(heap, (node.val, i, node))
    
    dummy = ListNode(0)
    cur = dummy
    while heap:
        val, i, node = heapq.heappop(heap)
        cur.next = node
        cur = cur.next
        if node.next:
            heapq.heappush(heap, (node.next.val, i, node.next))
    
    return dummy.next
```

### C++

```cpp
ListNode* mergeKLists(vector<ListNode*>& lists) {
    auto cmp = [](auto& a, auto& b) { return a.first > b.first; };
    priority_queue<pair<int, ListNode*>, vector<pair<int,ListNode*>>, decltype(cmp)> pq(cmp);
    
    for (auto* node : lists)
        if (node) pq.push({node->val, node});
    
    ListNode dummy(0);
    ListNode* cur = &dummy;
    while (!pq.empty()) {
        auto [val, node] = pq.top();
        pq.pop();
        cur->next = node;
        cur = cur->next;
        if (node->next) pq.push({node->next->val, node->next});
    }
    return dummy.next;
}
```

### Rust
```rust
use std::collections::BinaryHeap;
use std::cmp::Reverse;

fn merge_k_sorted(lists: &[Vec<i32>]) -> Vec<i32> {
    let mut heap: BinaryHeap<Reverse<(i32, usize, usize)>> = BinaryHeap::new();
    for (i, list) in lists.iter().enumerate() {
        if let Some(&val) = list.first() {
            heap.push(Reverse((val, i, 0)));
        }
    }
    let mut result = vec![];
    while let Some(Reverse((val, i, j))) = heap.pop() {
        result.push(val);
        if j + 1 < lists[i].len() {
            heap.push(Reverse((lists[i][j + 1], i, j + 1)));
        }
    }
    result
}
```
**Rust note:** `(val, list_idx, elem_idx)` in min-heap. Tuple comparison by first element. Borrow `lists` for indices.

---

## Template 5: K Closest Points to Origin

**Use when:** K points with smallest distance. Max-heap of size K (evict farthest).

### Python

```python
def k_closest(points, k):
    # Max-heap by distance: store (-dist, point) to simulate max-heap
    heap = []
    for p in points:
        dist = p[0]**2 + p[1]**2  # skip sqrt for efficiency
        if len(heap) < k:
            heapq.heappush(heap, (-dist, p))
        elif -dist > heap[0][0]:  # new point is closer than farthest in heap
            heapq.heapreplace(heap, (-dist, p))
    
    return [p for _, p in heap]
```

### C++

```cpp
vector<vector<int>> kClosest(vector<vector<int>>& points, int k) {
    auto cmp = [](auto& a, auto& b) { return a.first < b.first; };  // max-heap by dist
    priority_queue<pair<int,vector<int>>, vector<pair<int,vector<int>>>, decltype(cmp)> pq(cmp);
    
    for (auto& p : points) {
        int d = p[0]*p[0] + p[1]*p[1];
        if (pq.size() < k) pq.push({d, p});
        else if (d < pq.top().first) {
            pq.pop();
            pq.push({d, p});
        }
    }
    
    vector<vector<int>> result;
    while (!pq.empty()) {
        result.push_back(pq.top().second);
        pq.pop();
    }
    return result;
}
```

### Rust
```rust
fn k_closest(points: Vec<Vec<i32>>, k: usize) -> Vec<Vec<i32>> {
    let mut heap: BinaryHeap<(i32, Vec<i32>)> = BinaryHeap::new();
    for p in points {
        let d = p[0] * p[0] + p[1] * p[1];
        if heap.len() < k {
            heap.push((d, p));
        } else if d < heap.peek().unwrap().0 {
            heap.pop();
            heap.push((d, p));
        }
    }
    heap.into_iter().map(|(_, p)| p).collect()
}
```
**Rust note:** Max-heap by distance (default Ord). Evict farthest when heap full. Skip sqrt for efficiency.

---

## Template 6: Task Scheduler (LC 621)

**Use when:** Schedule tasks with cooldown; pick most frequent first.

### Python

```python
def least_interval(tasks, n):
    counts = Counter(tasks)
    max_heap = [-c for c in counts.values()]  # negate for max-heap
    heapq.heapify(max_heap)
    
    time = 0
    while max_heap:
        cycle = []
        for _ in range(n + 1):
            if max_heap:
                c = heapq.heappop(max_heap)
                if c + 1 < 0:
                    cycle.append(c + 1)
            time += 1
            if not max_heap and not cycle:
                break
        for c in cycle:
            heapq.heappush(max_heap, c)
    
    return time
```

### C++

```cpp
int leastInterval(vector<char>& tasks, int n) {
    unordered_map<char, int> count;
    for (char c : tasks) count[c]++;
    
    priority_queue<int> pq;
    for (auto& [c, cnt] : count) pq.push(cnt);
    
    int time = 0;
    while (!pq.empty()) {
        vector<int> cycle;
        for (int i = 0; i <= n; i++) {
            if (!pq.empty()) {
                int c = pq.top(); pq.pop();
                if (c > 1) cycle.push_back(c - 1);
            }
            time++;
            if (pq.empty() && cycle.empty()) break;
        }
        for (int c : cycle) pq.push(c);
    }
    return time;
}
```

### Rust
```rust
fn least_interval(tasks: Vec<char>, n: i32) -> i32 {
    let mut count = std::collections::HashMap::new();
    for &c in &tasks { *count.entry(c).or_insert(0) += 1; }
    let mut heap: BinaryHeap<i32> = count.into_values().collect();
    let mut time = 0;
    while !heap.is_empty() {
        let mut cycle = vec![];
        for _ in 0..=n {
            if let Some(c) = heap.pop() {
                if c > 1 { cycle.push(c - 1); }
            }
            time += 1;
            if heap.is_empty() && cycle.is_empty() { break; }
        }
        for c in cycle { heap.push(c); }
    }
    time
}
```
**Rust note:** `BinaryHeap` = max-heap. Pop n+1 per cycle; push back counts-1.

---

## Template 7: Custom Comparator in Heap

**Use when:** Sort by custom key (e.g., frequency, tuple, object).

### Python

```python
# heapq compares by first element of tuple
# For (val, freq): min-heap by val, or use (-freq, val) for max by freq

# Top K frequent: max-heap by frequency
heap = []
for num, freq in count.items():
    heapq.heappush(heap, (-freq, num))  # negate freq for max
    if len(heap) > k:
        heapq.heappop(heap)

# Or: min-heap of size K by frequency (keep K most frequent)
heap = []
for num, freq in count.items():
    if len(heap) < k:
        heapq.heappush(heap, (freq, num))
    elif freq > heap[0][0]:
        heapq.heapreplace(heap, (freq, num))
```

### C++

```cpp
// Custom: sort by second element (frequency) descending
auto cmp = [](pair<int,int>& a, pair<int,int>& b) {
    return a.second < b.second;  // max-heap by freq
};
priority_queue<pair<int,int>, vector<pair<int,int>>, decltype(cmp)> pq(cmp);

// Or use struct with operator<
struct Node {
    int val, freq;
    bool operator<(const Node& o) const { return freq < o.freq; }  // max-heap
};
priority_queue<Node> pq;
```

### Rust
```rust
#[derive(Eq, PartialEq)]
struct Node { val: i32, freq: i32 }
impl Ord for Node {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering { self.freq.cmp(&other.freq) }
}
impl PartialOrd for Node { fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> { Some(self.cmp(other)) } }

// Top K by freq: min-heap of size k, or max-heap with Reverse
let mut heap: BinaryHeap<Reverse<(i32, i32)>> = BinaryHeap::new();
for (num, freq) in count.iter() {
    if heap.len() < k { heap.push(Reverse((*freq, *num))); }
        else if *freq > (heap.peek().unwrap().0).0 {
        heap.pop();
        heap.push(Reverse((*freq, *num)));
    }
}
```
**Rust note:** Custom `Ord` for structs. `Reverse((freq, num))` for min-heap by freq.

---

## Template 8: Top K Frequent Elements

### Python

```python
def top_k_frequent(nums, k):
    count = Counter(nums)
    # Min-heap of size k by frequency
    heap = []
    for num, freq in count.items():
        if len(heap) < k:
            heapq.heappush(heap, (freq, num))
        elif freq > heap[0][0]:
            heapq.heapreplace(heap, (freq, num))
    return [num for _, num in heap]
```

### C++

```cpp
vector<int> topKFrequent(vector<int>& nums, int k) {
    unordered_map<int, int> count;
    for (int x : nums) count[x]++;
    
    auto cmp = [](auto& a, auto& b) { return a.first > b.first; };  // min by freq
    priority_queue<pair<int,int>, vector<pair<int,int>>, decltype(cmp)> pq(cmp);
    
    for (auto& [num, freq] : count) {
        if (pq.size() < k) pq.push({freq, num});
        else if (freq > pq.top().first) {
            pq.pop();
            pq.push({freq, num});
        }
    }
    
    vector<int> result;
    while (!pq.empty()) {
        result.push_back(pq.top().second);
        pq.pop();
    }
    return result;
}
```

### Rust
```rust
fn top_k_frequent(nums: Vec<i32>, k: usize) -> Vec<i32> {
    let mut count = std::collections::HashMap::new();
    for &x in &nums { *count.entry(x).or_insert(0) += 1; }
    let mut heap: BinaryHeap<Reverse<(i32, i32)>> = BinaryHeap::new();
    for (num, freq) in count {
        if heap.len() < k { heap.push(Reverse((freq, num))); }
        else if freq > (heap.peek().unwrap().0).0 {
            heap.pop();
            heap.push(Reverse((freq, num)));
        }
    }
    heap.into_iter().map(|r| (r.0).1).collect()
}
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PYTHON:            heapq (min-heap); max-heap = (-x, x) or -x
CPP:               priority_queue (max default); min = greater<int>
RUST:              BinaryHeap (max default); min = Reverse<T>
TOP-K LARGEST:     Min-heap size K; if x > root: heapreplace
KTH LARGEST:       Same; return heap[0] at end
TWO-HEAP MEDIAN:   lo (max) + hi (min); balance sizes; median = top(s) 
MERGE K:           (val, list_idx, node) in min-heap; pop, push next
K CLOSEST:         Max-heap size K by distance; evict farthest
TASK SCHEDULER:    Max-heap by freq; pop n+1 per cycle
CUSTOM:            Tuple (key, val) — heap compares first element
```

---

## 30-SECOND REVISION BOX

| Pattern | Key Idea |
|---------|----------|
| Min-heap | Python: heapq; C++: greater; Rust: Reverse\<T\> |
| Top-K | Min-heap size K; evict when new > root |
| Two-heap median | lo (max) + hi (min); balance; median from top(s) |
| Merge K | (val, idx, pos) in heap; pop, push next |
| K closest | Max-heap by dist; evict farthest |
| Task scheduler | Max-heap by freq; pop n+1 per cycle |
| No decrease-key | Push new; skip stale when popping |

---

## Language Comparison

| Construct | Python | C++ | Rust |
|-----------|--------|-----|------|
| Heap | `heapq` (min only) | `priority_queue` (max default) | `BinaryHeap` (max default) |
| Min-heap | Negate or `(-x,x)` | `greater<T>` | `Reverse<T>` |
| Peek | `h[0]` | `pq.top()` | `heap.peek()` → `Option<&T>` |
| Custom order | Tuple `(key, val)` | Comparator / `operator<` | `Ord` impl or `Reverse` |
