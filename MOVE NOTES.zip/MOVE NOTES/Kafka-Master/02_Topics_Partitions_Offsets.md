# 2. Topics, Partitions & Offsets

> **Permanent Recall Note:** A **topic** is a **logical channel**; **partitions** split it for **parallelism** and **durability placement**. An **offset** is an **opaque position** in a partition’s log — consumers advance it; brokers do not “pop” messages. Yaad rakho: **ordering guarantee = single partition**; more partitions = more parallelism but more operational surface.

### The 10-Second Summary
- **Topic** → N **partitions** (immutable count growth story — prefer planning).
- **Offset** = monotonic address in one partition; **committed** vs **current** positions matter for lag.
- **Replication factor (RF)** + **ISR** decide durability; **leader** serves reads/writes.
- **Retention:** time, size, **compact** — not the same as “delete after read.”

---

# 2.1 Topic as Logical Channel

```
TOPIC: payments.events
  ├── partition 0  → broker A (leader), B,C (followers)
  ├── partition 1  → broker B (leader), ...
  └── partition 2  → ...
```

💡 **Key Insight:** Same topic name across cluster — **partition id** disambiguates parallel logs.

---

# 2.2 Partition = Unit of Parallelism

| Benefit | Cost |
|---------|------|
| Higher **produce/consume** throughput | More **files**, **replicas**, **rebalance** churn |
| Parallel consumers in one group | **Cross-partition** ordering lost |

📏 **Golden Rule:** Max parallelism in one consumer group ≈ **number of partitions** (one consumer thread per partition assignment).

---

# 2.3 Offset — Position Pointer

```
Partition 7:  [0][1][2] ... [k-1][k][k+1] ...
                     ▲
              committed offset = k-1 (example)
              current position / next fetch → k
```

- **Log End Offset (LEO):** last written offset + 1 semantics (broker-side).
- **Consumer lag** ≈ LEO − consumer position (per partition).

⚠️ **Warning:** **Auto-commit** can acknowledge past **processing** — processing failure ⇒ **skip or duplicate** unless you design idempotency.

---

# 2.4 Partition Assignment Strategies (Consumer Group)

| Strategy | Behavior |
|----------|----------|
| **Range** | Contiguous ranges per consumer — can imbalance |
| **RoundRobin** | Rotate partitions — fairer in some layouts |
| **Sticky** | Minimize movement on rebalance |
| **CooperativeSticky** | **Incremental** revoke — less stop-the-world |

🔄 **Trade-off:** Cooperative = smoother; older clients may not support — check versions.

---

# 2.5 Replication Factor & Leader/Follower

```
Replication factor = 3

Partition P:
   Leader (L) ──replicate──► Follower F1
                    └──► Follower F2
```

- **All produce/fetch to leader** (KRaft/broker handles metadata).
- Followers **fetch** from leader like consumers (replica fetcher threads).

🏗️ **Production:** RF=3 common on prod; RF=1 only dev — **no fault tolerance**.

---

# 2.6 ISR — In-Sync Replicas

**ISR** = replicas **caught up** enough (controlled by replica lag thresholds / configs).

- Producer with `acks=all` waits for **ISR** acknowledgment policy semantics (with `min.insync.replicas`).
- **Out-of-sync** follower dropped from ISR — may rejoin if catches up.

🧠 **Memory Trick:** **ISR** = “safe quorum for acks” — not necessarily all replicas.

---

# 2.7 Partition Count — How Many?

**Heuristics (not laws):**

- Start from **target throughput** / **consumer count** / **max desired parallelism**.
- Too **few** → bottleneck; too **many** → metadata, file handles, longer election.
- Changing count **does not** repartition old keys — **new** keys route to new range.

🔥 **Pro Tip:** Prefer **stable** partition count; if you must expand, treat **downstream** state (keys, joins) carefully.

---

# 2.8 Key-Based Partitioning

```text
partition = hash(key) % numPartitions   (default murmur2 in Java producer)
```

- Same **key** → same partition → **order per key**.
- **Null key** → round-robin / sticky behavior (versioned).

💡 **Key Insight:** Global order **impossible** at scale — design **key** to match business entity.

---

# 2.9 Round-Robin vs Sticky (No Key)

- **Round-robin:** spread load; **no** per-key order.
- **Sticky:** batch-friendly — fewer partition switches while batches fill.

---

# 2.10 Ordering Guarantees

| Scope | Ordering |
|-------|----------|
| **Single partition** | Total order of writes |
| **Topic (multi-partition)** | **No** global order |
| **Multiple producers** | Ordering per partition if single producer or careful design |

---

# 2.11 Compacted Topics vs Delete Topics

| Policy | Effect |
|--------|--------|
| **Delete (default)** | Drop segments by **retention.ms** / **retention.bytes** |
| **Compact** | Keep **latest** record per **key** — tombstones delete |

⚠️ **Warning:** Compaction needs **keys**; still not a **primary key store**.

---

# 2.12 Retention Policies

```properties
# broker/topic config examples
retention.ms=604800000
retention.bytes=-1
cleanup.policy=delete    # or compact, or compact,delete
```

🎯 **Interview Tip:** **Tiered storage** (vendor) vs **MirrorMaker** for long archive — different from core broker retention.

---

# 2.13 Python — Consumer position (conceptual)

```python
from kafka import KafkaConsumer

c = KafkaConsumer(
    "payments.events",
    bootstrap_servers=["localhost:9092"],
    group_id="de-pipeline",
    enable_auto_commit=False,
)
for msg in c:
    process(msg)
    # manual commit after successful processing
    c.commit()
```

---

# 2.14 Operational Snippets — kafka-topics

```bash
# Increase partitions (does not repartition existing keys retroactively)
kafka-topics.sh --bootstrap-server localhost:9092 \
  --alter --topic payments.events --partitions 12

# Inspect offsets (kafka-consumer-groups)
kafka-consumer-groups.sh --bootstrap-server localhost:9092 \
  --group de-pipeline --describe
```

---

# 2.15 Interview Questions & Answers

**Q: Partition aur offset ka exact relation?**  
**A:** Offset **partition-scoped** hai — (topic, partition, offset) uniquely locate a record.

**Q: Ordering chahiye pure topic par — kaise?**  
**A:** Practically **single partition** (limits throughput) or **downstream** reorder by key (Flink/Spark state).

**Q: ISR shrink kya hota hai?**  
**A:** Slow/dead follower **ISR se hat** sakta hai — **UnderReplicatedPartitions** metric dekho.

**Q: Spark shuffle vs Kafka partition?**  
**A:** Dono parallelism — Kafka **storage + delivery** boundary; Spark **compute** partition — often align counts for throughput; see [../spark/08_Partitions_Layout_DE.md](../spark/08_Partitions_Layout_DE.md).

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 2 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Topic = logical; Partition = parallel ordered log       │
│  🧠 Offset = cursor; lag = how far behind                   │
│  🧠 Key → partition → per-key order                         │
│  🧠 RF + ISR = durability; leader serves I/O                 │
│  ⚠️  retention ≠ message queue ack                          │
│  🎯 CooperativeSticky for smoother rebalances               │
└─────────────────────────────────────────────────────────────┘
```
