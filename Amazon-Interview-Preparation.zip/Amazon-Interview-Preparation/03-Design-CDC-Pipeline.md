# Design a CDC Pipeline - Interview Answer Format

## One-Line Answer

A CDC pipeline continuously captures inserts, updates, and deletes from database transaction logs, moves them into a raw change stream, and merges them into curated analytics tables with low source impact.

---

## Step 1: Clarify Requirements (1-2 min)

### What to ask

- Which source database are we capturing from?
- Do we need near-real-time or is minute-level latency okay?
- What is the expected change volume?
- Do downstream systems need current state only, or also full history?
- Do we need to support deletes and schema evolution?
- What is the tolerance for duplicates or temporary lag?

### Good interview line

> "Before I design the CDC pipeline, I want to clarify the source database type, expected change volume, freshness target, and whether downstream consumers need full history or only current-state tables."

---

## Step 2: High-Level Design (2-3 min)

### Say this clearly

```text
Database -> Binlog/WAL -> CDC Connector -> Raw Change Stream -> Merge Layer -> Analytics Tables
```

### Short explanation you can speak

1. Read changes from the database transaction log, not by polling full tables
2. Use a CDC connector like DMS or Debezium
3. Store raw change events with metadata
4. Merge those changes into curated lake or warehouse tables
5. Serve downstream analytics from current-state or history-preserving tables

### Architecture

```text
OLTP Database
    |
Database Binlog / WAL
    |
CDC Connector (DMS / Debezium)
    |
Kafka / Kinesis / S3 Raw Change Log
    |
Transform / Merge Layer
    |
Curated Lake Tables / Redshift
```

### Good interview line

> "My high-level design is reading database changes from the binlog or WAL, sending them through a CDC connector into a raw change log, and then applying merge logic into curated analytical tables."

---

## Step 3: Deep Dive (This Is Where You Win)

### A. Why CDC Instead of Polling?

#### Why read binlog/WAL?

- Lower load on the production database
- Better freshness
- Captures inserts, updates, and deletes more reliably
- Easier to preserve order per key or transaction sequence

### Good interview line

> "CDC is better than repeated full-table polling because it reads the transaction log directly, which reduces source load and gives much fresher and more complete change capture."

---

### B. Snapshot + Incremental Flow

This is one of the most important interview points.

#### Step 1: Initial snapshot

- Take a consistent snapshot of the existing table state
- Load it into S3 or the warehouse

#### Step 2: Continuous changes

- Start reading the log from a captured checkpoint
- Apply inserts, updates, and deletes from that point onward

#### Critical detail

You must explain how you avoid missing changes between the snapshot and the stream start.

Good answer:

1. Capture a consistent snapshot position
2. Start streaming from that same log position

### Good interview line

> "The key CDC design point is snapshot plus incremental replication from a consistent checkpoint, so we do not miss changes between the snapshot and the continuous stream."

---

### C. Merge / Upsert Layer

#### What the merge layer does

- apply inserts
- apply updates
- apply deletes
- deduplicate by source offset or change sequence

#### Why delete handling matters

- If deletes are ignored, the warehouse becomes wrong
- Some systems use tombstones or delete markers

#### Why checkpoints matter

- They allow restart after failure
- They reduce duplicate processing

### Good interview line

> "Downstream correctness depends on idempotent merges, explicit delete handling, and careful tracking of source offsets or checkpoints."

---

## Step 4: Scaling

### Main scaling points

#### Stream partitioning

- Partition by table or primary key hash
- This increases parallelism

#### Incremental merges

- Avoid rewriting full target tables
- Merge only the changed partitions or keys

#### Separate operational replication from analytics

- Keep the CDC path lightweight
- Push heavy joins and analytics to downstream layers

### Good interview line

> "To scale, I would partition the change stream, keep replication lightweight, and do incremental merges instead of full table rewrites."

---

## Step 5: Trade-Offs

### Example trade-offs

#### CDC vs polling

- CDC is fresher and lighter on the source
- But it is more complex operationally

#### Raw change log vs only current-state table

- Raw change log helps replay and audit
- But it adds storage and merge complexity

#### Exactly-once style processing vs simpler restart logic

- Stronger correctness is possible
- But complexity and cost increase

### Good interview line

> "CDC gives much better freshness and lower source impact than polling, but it requires more careful handling of checkpoints, schema changes, and downstream merge correctness."

---

## Strong 2-Minute Answer Script

> "First, I would clarify the source database, expected change volume, freshness requirement, and whether the target needs only current state or also historical replay. My design would read changes from the database transaction log, such as MySQL binlog or Postgres WAL, using a CDC connector like DMS or Debezium. Those changes would be written to a raw change stream in Kafka, Kinesis, or S3 with metadata like table name, operation type, primary key, and source offset.
>
> Then I would build a merge layer that converts the raw change stream into curated analytics tables by applying inserts, updates, and deletes. The most important detail is snapshot plus incremental replication. I would first take a consistent initial snapshot, capture the checkpoint position, and then start reading the log from that exact point so no changes are missed.
>
> For reliability, I would track checkpoints carefully, keep the raw change log for replay, and make downstream merges idempotent. For scale, I would partition the change stream and merge incrementally instead of rewriting full tables. The main trade-off is that CDC is more complex than polling, but it gives much better freshness and much lower impact on the source system."

---

## Common Failure Cases

### Connector restarts

- Resume from last checkpoint
- Deduplicate if needed

### Schema changes

- Keep raw events even if target schema lags
- Version schemas and alert consumers

### Target merge fails

- Replay from raw change log
- Rerun from checkpoint range

### Deletes ignored

- Current-state tables become wrong
- Model tombstones or explicit delete markers

---

## Interview Tips

- Say **CDC is better than polling full tables**
- Mention **binlog/WAL** early
- Explain **snapshot + incremental** carefully
- Always mention **deletes**
- Mention **idempotent merges** and **checkpoints**
- Name common tools like DMS, Debezium, Kafka/MSK, S3, and Redshift

---

## Quick Revision (5 points)

1. Clarify source DB, freshness, volume, and target table needs first
2. Explain the flow as `Database -> Binlog/WAL -> CDC Connector -> Merge Layer`
3. Deep dive on transaction logs, snapshot + incremental, and delete handling
4. Mention checkpoints, replay, and idempotent merges
5. Close with CDC vs polling trade-offs
