# Self Join

A self join is when you join a table to **itself** — giving it two aliases so you can compare rows within the same table. It's like placing two copies of the same array side by side and using two pointers.

**DSA Analogy**: Two-pointer on the same array — you iterate with pointer `a` and pointer `b` over the same data structure, comparing elements at different positions.

---

## Core Idea (2 Lines)

Join a table to itself using two different aliases. This lets you compare, pair, or relate rows from the **same table** — finding managers for employees, matching consecutive events, detecting duplicates, or pairing complementary records.

---

## Syntax Template

```sql
SELECT a.col1, b.col2
FROM table_name a
JOIN table_name b
    ON a.some_column = b.some_column
    [AND a.id != b.id]              -- avoid matching a row to itself
WHERE ...;
```

**Key rule**: Always alias the table twice (e.g., `a` and `b`) — otherwise SQL doesn't know which "copy" you mean.

---

## The 4 Self Join Patterns

### Pattern 1: Hierarchical (Parent-Child)

The classic — employees and their managers live in the same table.

```sql
-- Find each employee's manager name
SELECT e.name AS employee, m.name AS manager
FROM employees e
LEFT JOIN employees m ON e.manager_id = m.id;
```

```
employees table:                         Result:
id | name    | manager_id               employee | manager
───┼─────────┼────────────               ─────────┼────────
1  | Alice   | NULL                      Alice    | NULL
2  | Bob     | 1                         Bob      | Alice
3  | Charlie | 1                         Charlie  | Alice
4  | Diana   | 2                         Diana    | Bob
```

### Pattern 2: Row Comparison (Consecutive/Sequential)

Compare a row to its previous or next row by joining on sequential IDs or dates.

```sql
-- Find days where temperature was higher than the previous day
SELECT b.id, b.recordDate, b.temperature
FROM weather a
JOIN weather b
    ON b.recordDate = a.recordDate + INTERVAL '1 day'
WHERE b.temperature > a.temperature;
```

### Pattern 3: Pair Finding (Combinations)

Find all pairs of rows that satisfy a condition.

```sql
-- Find pairs of employees in the same department with salary diff < 10000
SELECT a.name AS emp1, b.name AS emp2, a.dept
FROM employees a
JOIN employees b
    ON a.dept = b.dept
    AND a.id < b.id                  -- avoid duplicates and self-match
WHERE ABS(a.salary - b.salary) < 10000;
```

**Why `a.id < b.id`?** Without it you get both (Alice,Bob) AND (Bob,Alice) — plus (Alice,Alice). Using `<` instead of `!=` eliminates both duplicates and self-pairs.

### Pattern 4: Duplicate Detection

Find rows that share the same value in certain columns.

```sql
-- Find duplicate emails
SELECT DISTINCT a.email
FROM person a
JOIN person b
    ON a.email = b.email
    AND a.id != b.id;
```

---

## How It Works Internally

```
Table: employees                  Self Join (e JOIN m ON e.manager_id = m.id)

┌──┬─────────┬────────────┐       ┌──────────────────────────────────────────────┐
│id│  name   │ manager_id │       │  For EACH row in 'e' (left copy):            │
├──┼─────────┼────────────┤       │    Find matching row in 'm' (right copy)     │
│1 │ Alice   │ NULL       │       │    where e.manager_id = m.id                 │
│2 │ Bob     │ 1          │       │                                              │
│3 │ Charlie │ 1          │       │  e.Bob (manager_id=1) → m.Alice (id=1) ✓     │
│4 │ Diana   │ 2          │       │  e.Charlie (manager_id=1) → m.Alice (id=1) ✓ │
└──┴─────────┴────────────┘       │  e.Diana (manager_id=2) → m.Bob (id=2) ✓    │
                                  │  e.Alice (manager_id=NULL) → no match (NULL) │
                                  └──────────────────────────────────────────────┘
```

---

## Self Join vs Modern Alternatives

| Task | Self Join Approach | Modern Alternative |
|------|--------------------|--------------------|
| Previous row value | `JOIN ON b.id = a.id - 1` | `LAG(col) OVER (ORDER BY id)` |
| Next row value | `JOIN ON b.id = a.id + 1` | `LEAD(col) OVER (ORDER BY id)` |
| Manager lookup | `JOIN ON e.manager_id = m.id` | Still best with self join |
| Consecutive detection | `JOIN ON b.date = a.date + 1` | LAG/LEAD often cleaner |
| Pair finding | `JOIN ON a.id < b.id` | Self join is the best approach |
| Duplicate detection | `JOIN ON a.col = b.col AND a.id != b.id` | `GROUP BY + HAVING COUNT > 1` |

**Rule of thumb**: Use LAG/LEAD for simple "previous/next row" comparisons. Use self join when you need to pair arbitrary rows or traverse parent-child relationships.

---

## Common Mistakes

| Mistake | Why It Breaks | Fix |
|---------|---------------|-----|
| Forgetting to exclude self-match | Row matches itself: (Alice, Alice) | Add `AND a.id != b.id` |
| Using `!=` instead of `<` for pairs | Get both (A,B) and (B,A) | Use `a.id < b.id` for unique pairs |
| INNER JOIN on hierarchical data | Lose root nodes (NULL manager_id) | Use LEFT JOIN to keep orphans |
| No index on join column | Full table scan × full table scan = O(n²) | Ensure index on join columns |
| Cartesian explosion | Join condition too loose | Make join condition specific enough |

---

## Performance Considerations

```
Self Join = Table scanned TWICE
Size: If table has N rows, the join considers up to N × N pairs

Optimization:
1. Index the join column (manager_id, date, email, etc.)
2. Add tight WHERE conditions to reduce rows BEFORE the join
3. For "previous row" patterns, prefer LAG() — single scan
4. For pair finding, a.id < b.id cuts result set in half
```

---

## Real-World Use Cases

```
Org charts — find employee → manager → VP chain
Consecutive events — orders placed on back-to-back days
Duplicate detection — same email, phone, or SSN across records
Pair matching — students in same class, flights with same origin
Price comparison — products cheaper than their category average
Friendship pairs — mutual friends in social network tables
```

---

## Key Takeaway

> A self join places two pointers on the same table. Use it to compare rows within the same dataset — manager lookups, pair finding, consecutive detection, and duplicate identification. For simple previous/next row access, prefer LAG/LEAD. For arbitrary pairing or parent-child relationships, self join is the right tool.
