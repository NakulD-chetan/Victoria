import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import SearchCanvasBase from './canvas-bases/SearchCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

/** slug: interpolation-search */
function generateSteps(arr, target) {
  const steps = [];
  const a = [...arr];
  let lo = 0;
  let hi = a.length - 1;
  steps.push({ type: 'init', array: [...a], pointers: { lo, hi }, target });
  while (lo <= hi && target >= a[lo] && target <= a[hi]) {
    if (lo === hi) {
      steps.push({ type: 'compare', array: [...a], pointers: { lo, hi, probe: lo }, target, probeIdx: lo });
      if (a[lo] === target) {
        steps.push({ type: 'found', array: [...a], pointers: { lo, hi, probe: lo }, target, idx: lo });
        return steps;
      }
      break;
    }
    const denom = a[hi] - a[lo];
    const pos = denom === 0 ? lo : lo + Math.floor(((target - a[lo]) * (hi - lo)) / denom);
    const probe = Math.min(hi, Math.max(lo, pos));
    steps.push({
      type: 'probe',
      array: [...a],
      pointers: { lo, hi, probe },
      target,
      probeIdx: probe,
    });
    if (a[probe] === target) {
      steps.push({ type: 'found', array: [...a], pointers: { lo, hi, probe }, target, idx: probe });
      return steps;
    }
    if (a[probe] < target) {
      steps.push({ type: 'shrink-left', array: [...a], pointers: { lo, hi, probe }, target, newLo: probe + 1, newHi: hi });
      lo = probe + 1;
    } else {
      steps.push({ type: 'shrink-right', array: [...a], pointers: { lo, hi, probe }, target, newLo: lo, newHi: probe - 1 });
      hi = probe - 1;
    }
    steps.push({ type: 'window', array: [...a], pointers: { lo, hi }, target });
  }
  steps.push({ type: 'notfound', array: [...a], pointers: { lo, hi }, target });
  return steps;
}

function randomSortedArray(n = 20) {
  return Array.from({ length: n }, (_, i) => i * 3 + Math.floor(Math.random() * 3)).sort((a, b) => a - b);
}

function paintWindow(colors, lo, hi, n) {
  for (let i = 0; i < n; i++) {
    if (i >= lo && i <= hi) colors[i] = 'active';
    else colors[i] = 'eliminated';
  }
}

export default function InterpolationSearchVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const arr = randomSortedArray();
    const target = arr[Math.floor(Math.random() * arr.length)];
    const steps = generateSteps(arr, target);
    const store = useVisualizerStore.getState();
    store.setArray(arr);
    store.setSteps(steps);
    store.addLog({ time: '0s', type: 'info', message: `Interpolation search for ${target}` });
    canvasRef.current?.setState({ array: arr, colors: {}, pointers: {}, target, found: null });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    const n = step.array.length;
    const colors = {};
    const pointers = step.pointers || {};
    if (step.type === 'init' || step.type === 'window') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: `Range [${pointers.lo}, ${pointers.hi}]` });
    } else if (step.type === 'compare' || step.type === 'probe') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      const pi = step.probeIdx ?? pointers.probe;
      if (pi != null) colors[pi] = 'compare';
      store.incComparisons();
      store.addLog({
        time: `${store.stepIndex + 1}`,
        type: 'info',
        message:
          step.type === 'probe'
            ? `Probe index ${pi} (proportion of target in value range)`
            : `Single-slot check at ${pi}`,
      });
    } else if (step.type === 'shrink-left' || step.type === 'shrink-right') {
      paintWindow(colors, pointers.lo, pointers.hi, n);
      const pi = pointers.probe;
      if (pi != null) colors[pi] = 'compare';
      for (let i = 0; i < n; i++) {
        if (i < step.newLo || i > step.newHi) colors[i] = 'eliminated';
      }
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'refill', message: 'Narrow range using probe' });
    } else if (step.type === 'found') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      colors[step.idx] = 'found';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'allow', message: `Found at index ${step.idx}` });
      canvasRef.current?.addAnim('foundFlash', {}, 640);
    } else if (step.type === 'notfound') {
      for (let i = 0; i < n; i++) colors[i] = 'eliminated';
      store.addLog({ time: `${store.stepIndex + 1}`, type: 'deny', message: 'Target not in array' });
      canvasRef.current?.addAnim('notFoundFlash', {}, 640);
    }
    store.setArray(step.array);
    const found = step.type === 'found' ? true : step.type === 'notfound' ? false : null;
    canvasRef.current?.setState({
      array: step.array,
      colors,
      pointers,
      target: step.target,
      ...(found != null ? { found } : {}),
    });
  }, []);

  return <AlgoVisualizer config={config} canvas={SearchCanvasBase} onInit={onInit} onStep={onStep} />;
}
