# How WhatsApp Works - System Design

> Source: https://newsletter.systemdesign.one/p/whatsapp-system-design

## One-Line Summary
WhatsApp handles 100 billion messages/day for 2B+ users using WebSocket connections, Cassandra for storage, Redis for connection tracking, and a fan-out model for group messaging with offline message queuing.

## Key Requirements

### Functional
- Send/receive text messages in 1:1 chats
- Group chats (up to 100 participants)
- Message status tracking (sent, delivered, read)
- Media attachments (images, videos, audio)
- Online/offline status with "last seen"
- Offline message queuing (30-day retention)

### Non-Functional
- Low latency (<500ms when online)
- Guaranteed message delivery (no lost messages)
- Handle billions of users with high throughput
- Minimal server-side message storage
- Resilient to component failures

## Capacity Planning

| Metric | Value |
|--------|-------|
| Registered users | 1 billion |
| DAU | 500 million |
| Peak concurrent | 50 million |
| Messages/day | 10 billion |
| Avg messages/sec | 115,000 (peak: 500,000) |
| Daily storage | 10 TB |
| Active storage | 400-500 TB (30-day retention) |

## High-Level Architecture

```
Mobile App (Client)
      |
  WebSocket Connection (persistent, bidirectional)
      |
Load Balancer (sticky sessions)
      |
Chat Servers (maintain WebSocket connections)
      |
  +------+------+------+------+
  |      |      |      |      |
Message  User   Blob   Push   Presence
Queue   Cache  Store  Notif  Service
(Kafka) (Redis) (S3)  (APNs/ (heartbeat)
  |              |    FCM)
Message        CDN
Storage
Service
  |
Message DB
(Cassandra)
```

## Core Components Deep Dive

### 1. Why WebSockets (Not Polling)

| Protocol | How It Works | Problem |
|----------|-------------|---------|
| **Polling** | Client asks "new messages?" every few sec | Wastes bandwidth, adds latency |
| **Long Polling** | Hold request open until message arrives | Constant connection cycling, overhead |
| **WebSocket** (chosen) | Persistent bidirectional connection | Minimal overhead after initial handshake |

- Connection stays open throughout session
- Both client and server can push data anytime
- Heartbeat ping every 30 sec; if no pong for 60 sec → connection considered dead

### 2. Load Balancer
- Uses **sticky sessions** (once connected to Server A, stay on Server A)
- Layer 4 load balancing (needed for WebSocket support)
- Monitors server health, stops routing to dead servers

### 3. Chat Servers
- Maintain WebSocket connections to clients
- Each server handles hundreds of thousands of simultaneous connections
- Route messages between users
- On message receipt: immediately ACK to sender → async push to queue

### 4. User Connection Cache (Redis)
- Tracks: which users are online, which chat server they're on, last activity
- Enables fast routing: "User B is on Server 3" → route message to Server 3
- Microsecond lookups (vs milliseconds for DB)

### 5. Message Queue (Kafka/RabbitMQ)
- Decouples message receipt from delivery and storage
- Chat server ACKs sender immediately, then pushes to queue
- Storage service consumes from queue and writes to DB

### 6. Message Database (Cassandra/DynamoDB)
- NoSQL: high write throughput, simple query patterns
- Query pattern: fetch messages by user/conversation/timestamp
- 10B messages/day → needs massive write capacity

### 7. Presence Service (Online/Offline)
- Client sends heartbeat every 5 seconds
- If no heartbeat for 60 sec → mark offline
- Updates Redis with online/offline status
- Publishes presence changes to interested subscribers

### 8. Media Handling
- Media uploaded directly to **Blob Storage (S3)** via pre-signed URL
- Chat servers are NOT bottlenecked by large file transfers
- CDN caches popular files at edge locations worldwide
- Flow: client gets pre-signed URL → uploads to S3 → sends media_id in message

## Message Delivery Flow

### User A sends to User B (both online):
```
1. User A → WebSocket → Chat Server 1
2. Chat Server 1 → ACK to User A ("sent ✓")
3. Chat Server 1 → Redis lookup: "User B is on Server 3"
4. Chat Server 1 → Chat Server 3 → WebSocket → User B
5. User B → delivery ACK → Chat Server 3 → User A ("delivered ✓✓")
6. User B opens chat → read receipt → User A ("read ✓✓ blue")
```

### User B is OFFLINE:
```
1-2. Same as above (ACK to sender)
3. Redis says: "User B is offline"
4. Message stored in User B's inbox (Redis + Cassandra)
5. Push notification sent via APNs/FCM
6. When User B comes online → pull all queued messages → deliver → ACK
```

## Data Model

```
Users (SQL - PostgreSQL):
  user_id, phone, display_name, avatar_url, created_at

Messages (NoSQL - Cassandra):
  Partition key: conversation_id
  Clustering key: timestamp
  Fields: message_id, sender_id, content, media_url, status, type

Groups (SQL):
  group_id, name, created_by, created_at, member_count

User Connection (Redis):
  user_id → { server_id, status, last_seen }

Message Inbox (Redis):
  user_id → [pending_message_ids]
```

## Group Messaging
- Sender sends ONE message to chat server
- Chat server **fans out** to all group members
- Each member's chat server receives a copy
- For offline members: queue message + push notification
- Groups capped at 100 members to limit fan-out cost

## Key Design Decisions

| Decision | Why |
|----------|-----|
| WebSocket (not HTTP polling) | Persistent, bidirectional, low overhead |
| Sticky sessions on LB | WebSocket connections can't bounce between servers |
| Redis for connection tracking | Microsecond lookups for routing |
| Cassandra for messages | High write throughput, simple queries |
| Pre-signed URLs for media | Chat servers don't handle large file transfers |
| Heartbeat for presence | Detects dead connections, manages status |
| Message queue (Kafka) | Decouple receipt from storage, handle bursts |

## Scaling Strategies

1. **Add more chat servers** behind load balancer (horizontal scaling)
2. **Cassandra clustering** for message storage (handles PB-scale)
3. **Redis clustering** for connection cache
4. **Message queue** absorbs traffic spikes
5. **CDN** for media delivery worldwide
6. **Service registry** (Consul) for dynamic service discovery
7. **Multi-device sync**: each device maintains separate WebSocket connection

## Interview Tips

- Start with scale numbers: 100B messages/day, 2B users
- Explain **WebSocket vs polling vs long polling** -- this always comes up
- Draw the online vs offline delivery flow separately
- Mention **end-to-end encryption** (Signal Protocol in real WhatsApp)
- Discuss **group messaging fan-out** and why groups are capped
- Know the data model: Cassandra partition by conversation_id, cluster by timestamp
- Talk about **heartbeat mechanism** for presence detection
- Compare with Slack (workspace-based) and Telegram (cloud-first)

## Quick Revision (5 bullet points)

1. **WebSocket** for persistent bidirectional messaging; heartbeat every 5 sec detects dead connections
2. **Redis** tracks which user is on which server (microsecond routing); **Cassandra** stores messages (high write throughput)
3. **Online delivery**: sender → chat server → Redis lookup → recipient's server → recipient; **Offline**: queue in inbox + push notification
4. **Media via pre-signed URLs** to S3/CDN -- chat servers never handle large files directly
5. **Group messaging** = fan-out from sender's server to all members' servers; capped at 100 members to limit cost
