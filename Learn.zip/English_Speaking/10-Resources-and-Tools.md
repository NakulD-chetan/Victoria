# Resources and Tools

> *"Sahi resources use karo — warna YouTube pe motivational videos dekhte reh jaoge aur English nahi aayegi"*

Yeh chapter mein curated resources hain — YouTube channels, podcasts, apps, books, aur AI tools. Sab free ya affordable hain. Sabme se **2-3 choose karo** aur consistently use karo. Sab mat try karo — overwhelm ho jaoge.

---

## 1. YouTube Channels

### Beginners Ke Liye

| Channel | Focus | Language | Best For |
|---------|-------|----------|----------|
| **BBC Learning English** | Grammar, vocab, pronunciation, daily usage | English | Overall learning — best starting point |
| **English with Bharat** | Spoken English for Indians | Hinglish | Hindi speakers ke liye perfect |
| **English Today by Shifali Vig** | Daily English, pronunciation, common mistakes | Hinglish | Indian context mein practical English |
| **Mass Study** | Live sessions, pronunciation, fluency | Hinglish | Interactive learning, feedback milta hai |
| **Learn English with Let's Talk** | Vocabulary, grammar, phrases, IELTS | English | Wide range of topics |
| **English Addict with Mr Duncan** | Fun English lessons | English | Entertaining + educational |

### Intermediate / Advanced

| Channel | Focus | Best For |
|---------|-------|----------|
| **TED Talks** | Speeches on various topics | Listening practice + vocabulary |
| **Rachel's English** | American pronunciation | Pronunciation deep dives |
| **English with Lucy** | British English, grammar, vocabulary | British accent + grammar |
| **JForrest English** | Real-life English, idioms, slang | Natural speech patterns |
| **Speak English With Vanessa** | Conversation, pronunciation | Conversational fluency |

[TIP] Roz **1 video** dekho (10-15 min). Dekho mat sirf — **shadow karo** (saath mein repeat karo).

---

## 2. Podcasts

| Podcast | Level | Duration | Best For |
|---------|-------|----------|----------|
| **6 Minute English** (BBC) | Beginner-Intermediate | 6 min | Short, daily habit ke liye perfect |
| **All Ears English** | Intermediate | 15-20 min | Real American English, cultural tips |
| **The English We Speak** (BBC) | Beginner | 3 min | Ek phrase per episode — quick learning |
| **Espresso English** | Beginner-Intermediate | 5-10 min | Grammar + vocabulary in small doses |
| **Luke's English Podcast** | Intermediate-Advanced | 30-60 min | British humor + deep English learning |
| **EnglishClass101** | All levels | 10-15 min | Structured lessons, beginner friendly |

### Podcast Kaise Use Karein:

| Step | Action |
|------|--------|
| 1 | Pehli baar sunna — samajhne ki koshish karo |
| 2 | Doosri baar — transcript ke saath suno |
| 3 | Teesri baar — saath mein bolo (shadowing) |
| 4 | New words note karo |

---

## 3. Apps

### Speaking Practice

| App | Free/Paid | Best Feature |
|-----|-----------|-------------|
| **Elsa Speak** | Freemium | AI-powered pronunciation feedback — har word pe score deta hai |
| **Tandem** | Free | Real native speakers se baat karo (language exchange) |
| **HelloTalk** | Free | Chat + voice messages native speakers ke saath |
| **Speakly** | Paid | Most frequently used words + speaking practice |

### Vocabulary & Grammar

| App | Free/Paid | Best Feature |
|-----|-----------|-------------|
| **Duolingo** | Free | Gamified learning — daily 10 min habit bana sakte ho |
| **Anki** | Free | Flashcards with spaced repetition — vocabulary yaad rakhne ke liye best |
| **Quizlet** | Free | Flashcard sets banao aur share karo |
| **Grammarly** | Freemium | Writing mein grammar check karta hai (Chrome extension + keyboard) |

### All-in-One

| App | Free/Paid | Best Feature |
|-----|-----------|-------------|
| **Cake** | Free | Short video clips se English seekho — fun format |
| **Engvarta** | Paid | Indian English tutors se phone pe practice |
| **FluentU** | Paid | Real videos (movie clips, news) se English seekho |

[TIP] **2 apps choose karo max** — ek speaking ke liye (Elsa Speak), ek vocabulary ke liye (Anki/Duolingo). Zyada apps = less consistency.

---

## 4. AI Tools — Conversation Practice

| Tool | Kaise Use Karein | Best For |
|------|-----------------|----------|
| **ChatGPT** | "Let's have a conversation about [topic]. Ask me questions and correct my mistakes." | Free conversation practice, grammar correction |
| **Google Gemini** | Same as ChatGPT — conversation mode mein baat karo | Alternative to ChatGPT |
| **Claude** | Detailed explanations, grammar teaching | In-depth learning |
| **Elsa Speak AI** | Voice-based pronunciation feedback | Pronunciation scoring |

### ChatGPT Se Practice Kaise Karein:

**Prompt 1 — Conversation Partner:**
> "You are my English speaking partner. Let's have a casual conversation about weekend plans. Ask me questions, and after each of my responses, gently correct any grammar or vocabulary mistakes I made. Keep it friendly and encouraging."

**Prompt 2 — Grammar Teacher:**
> "I will write sentences. Tell me if they are correct or incorrect. If incorrect, explain the mistake in simple Hindi and give the correct version."

**Prompt 3 — Vocabulary Builder:**
> "Give me 5 new English words related to [office/travel/food] with meaning in Hindi, an example sentence, and pronunciation guide."

**Prompt 4 — Mock Interview:**
> "Conduct a mock job interview for a software developer position. Ask me one question at a time. After my answer, give feedback on my English and suggest improvements."

---

## 5. Books

| Book | Author | Level | Best For |
|------|--------|-------|----------|
| **Essential English Grammar** | Raymond Murphy | Beginner | Grammar basics — sabse popular book |
| **Intermediate English Grammar** | Raymond Murphy | Intermediate | Grammar ka next level |
| **Word Power Made Easy** | Norman Lewis | All | Vocabulary building — systematic method |
| **English Vocabulary in Use** | Michael McCarthy & Felicity O'Dell | All | Topic-wise vocabulary + exercises |
| **How to Win Friends and Influence People** | Dale Carnegie | Intermediate+ | English mein padho — vocabulary + communication skills dono |
| **The Alchemist** | Paulo Coelho | Intermediate | Simple English mein likhi hai — reading practice ke liye perfect |

[TIP] Raymond Murphy ki **Essential English Grammar (Red Book)** se start karo — Indian students ke liye specifically designed hai.

---

## 6. Websites

| Website | Best For | Link |
|---------|----------|------|
| **BBC Learning English** | Structured courses, grammar, vocab | bbc.co.uk/learningenglish |
| **British Council - Learn English** | Free courses, grammar exercises | learnenglish.britishcouncil.org |
| **Grammarly Blog** | Grammar rules explained simply | grammarly.com/blog |
| **Oxford Learner's Dictionary** | Word meanings + pronunciation audio | oxfordlearnersdictionaries.com |
| **YouGlish** | Koi bhi word search karo → real YouTube clips mein sunao | youglish.com |
| **News in Levels** | Same news 3 difficulty levels mein | newsinlevels.com |
| **Lyrics Training** | English songs se seekho — fill in blanks game | lyricstraining.com |

---

## 7. Daily Media Consumption — English Mein Switch Karo

| Current Habit | English Mein Switch |
|--------------|-------------------|
| Hindi news padhte ho | English newspaper app install karo (TOI, NDTV English) |
| Hindi songs sunte ho | English songs bhi mix karo — lyrics ke saath suno |
| Hindi movies dekhte ho | English movies/shows dekho — subtitles ON |
| Hindi memes dekhte ho | English meme pages follow karo (Instagram/Reddit) |
| Hindi YouTube dekhte ho | 1 English video roz add karo |
| WhatsApp Hindi mein | Ek group mein English mein likhne ki koshish karo |

---

## 8. Recommended Learning Path

### Month 1 — Foundation

| Week | Resources |
|------|-----------|
| Week 1 | BBC Learning English (YouTube) + Phone language English + Self-talk start |
| Week 2 | Duolingo daily + Raymond Murphy Chapter 1-5 + Mirror practice |
| Week 3 | Elsa Speak (pronunciation) + 6 Minute English podcast + Recording start |
| Week 4 | ChatGPT conversation practice + News in Levels reading |

### Month 2 — Building

| Week | Resources |
|------|-----------|
| Week 1 | TED Talk shadowing + Word Power Made Easy (5 words/day) |
| Week 2 | Tandem/HelloTalk (real conversation) + English movie with subtitles |
| Week 3 | Anki flashcards + English diary writing |
| Week 4 | Mock interview with ChatGPT + Review all progress |

### Month 3 — Confidence

| Week | Resources |
|------|-----------|
| Week 1 | 3-min speaking bursts + Advanced BBC content |
| Week 2 | English debate (self or partner) + The Alchemist reading |
| Week 3 | Subtitles OFF for movies + Real-life conversations |
| Week 4 | Full review + Record final progress video — compare with Month 1 |

---

## 9. Quick Resource Cheat Sheet

| Need | Use This |
|------|---------|
| Grammar seekhni hai | Raymond Murphy + BBC Learning English |
| Pronunciation fix karna hai | Elsa Speak + Rachel's English YouTube |
| Vocabulary badhani hai | Anki + Word Power Made Easy |
| Speaking practice chahiye | Mirror + ChatGPT + Tandem |
| Listening improve karni hai | 6 Minute English + TED Talks |
| Reading improve karni hai | News in Levels + The Alchemist |
| Writing improve karni hai | Grammarly + English diary |
| Fun mein seekhna hai | English songs (Lyrics Training) + Movies with subtitles |

---

*Ab 00-Index.md dekho — poore course ka overview aur revision path wahan milega*
