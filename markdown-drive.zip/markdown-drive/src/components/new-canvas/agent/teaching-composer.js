import { createWidgetElement } from '../widgets/widget-registry.js';
import {
  createBoundArrow,
  elementBounds,
  resolveSceneBindings,
} from '../engine/binding-engine.js';
import { validateScene } from '../engine/scene-validator.js';
import { createTextElement, HAND_FONT, measureTextBlock } from '../engine/text-layout.js';
import { normalizeElementsV2, uid } from '../state/types.js';

const LESSON_COLORS = {
  ink: '#25201f',
  darkCanvasInk: '#f8fafc',
  pink: '#ffc9c9',
  pinkSoft: '#fff1f1',
  yellow: '#fff3bf',
  blue: '#dbeafe',
  green: '#dcfce7',
  board: '#fff9f0',
  boardDark: '#101827',
  accent: '#7c83ff',
  danger: '#fb7185',
};

const LESSON_VERSION = 3;
const LESSON_BOARD = { w: 920, h: 620 };
const LESSON_PAGE_GAP = 180;

function canvasInk() {
  if (typeof document === 'undefined') return LESSON_COLORS.ink;
  return document.documentElement.getAttribute('data-theme') === 'dark'
    ? LESSON_COLORS.darkCanvasInk
    : LESSON_COLORS.ink;
}

function lessonBoardFill() {
  if (typeof document === 'undefined') return LESSON_COLORS.board;
  return document.documentElement.getAttribute('data-theme') === 'dark'
    ? LESSON_COLORS.boardDark
    : LESSON_COLORS.board;
}

function viewportWorldBounds(scene, stageElement) {
  const viewport = scene?.viewport || { zoom: 1, panX: 0, panY: 0 };
  const zoom = Math.max(0.1, viewport.zoom || 1);
  const width = stageElement?.clientWidth || 1180;
  const height = stageElement?.clientHeight || 760;
  return {
    x: -viewport.panX + 64,
    y: -viewport.panY + 64,
    w: Math.max(880, width / zoom - 128),
    h: Math.max(640, height / zoom - 128),
  };
}

function createCallout({
  text,
  x,
  y,
  width = 220,
  fill = LESSON_COLORS.yellow,
  role = 'callout',
  topic,
  z = 4,
  frameId = null,
}) {
  const metrics = measureTextBlock(text, {
    fontSize: 18,
    fontFamily: HAND_FONT,
    maxWidth: width - 28,
    padding: 14,
  });
  return {
    id: uid('callout'),
    type: 'callout',
    text,
    x,
    y,
    w: Math.max(width, metrics.width),
    h: Math.max(62, metrics.height),
    width: Math.max(width, metrics.width),
    height: Math.max(62, metrics.height),
    z,
    isDeleted: false,
    roughness: 1.35,
    style: {
      stroke: LESSON_COLORS.ink,
      fill,
      strokeWidth: 2,
      opacity: 1,
      dash: 'solid',
    },
    createdAt: Date.now(),
    customData: {
      owner: 'agent',
      semanticRole: role,
      topic,
      importance: 0.72,
    },
    frameId,
  };
}

function teachingStyle(role, topic, importance = 0.8) {
  return {
    owner: 'agent',
    semanticRole: role,
    topic,
    clusterKey: `lesson:${topic}`,
    lessonVersion: LESSON_VERSION,
    importance,
    themeInk: role === 'definition' || role.endsWith('connector'),
  };
}

function normalizeTopic(value) {
  return String(value || '').trim().toLowerCase().replace(/\s+/g, '-');
}

function isAgentOwned(element) {
  return element?.customData?.owner === 'agent'
    || Boolean(element?.customData?.sourceRunId)
    || Boolean(element?.widgetData?.agentMeta?.sourceRunId)
    || Boolean(element?.widgetData?.agentSpawnId);
}

function lessonTopicForElement(element) {
  const explicit = element?.customData?.topic;
  if (explicit) return normalizeTopic(explicit);
  const cluster = element?.customData?.clusterKey || element?.widgetData?.agentMeta?.clusterKey || '';
  if (cluster.startsWith('lesson:')) return normalizeTopic(cluster.slice('lesson:'.length));
  return '';
}

function elementMentionsTopic(element, topic) {
  const haystack = [
    element?.text,
    element?.widgetType,
    element?.widgetData?.title,
    element?.widgetData?.text,
    element?.customData?.semanticRole,
  ].filter(Boolean).join(' ').toLowerCase();
  const variants = topic === 'hash-map'
    ? ['hash map', 'hashmap']
    : topic === 'linked-list'
      ? ['linked list', 'linked-list']
      : [topic.replace(/-/g, ' ')];
  return variants.some((variant) => haystack.includes(variant));
}

function belongsToAgentLesson(element, topic) {
  if (!isAgentOwned(element)) return false;
  return lessonTopicForElement(element) === topic || elementMentionsTopic(element, topic);
}

function intersectsWithGap(a, b, gap = 36) {
  return a.x < b.x + b.w + gap
    && a.x + a.w + gap > b.x
    && a.y < b.y + b.h + gap
    && a.y + a.h + gap > b.y;
}

function findLessonOrigin(scene, stageElement, retained) {
  const bounds = viewportWorldBounds(scene, stageElement);
  const candidates = [
    { x: bounds.x + 28, y: bounds.y + 24 },
    { x: bounds.x + bounds.w + 120, y: bounds.y + 24 },
    { x: bounds.x + 28, y: bounds.y + bounds.h + 120 },
    { x: bounds.x - LESSON_BOARD.w - 120, y: bounds.y + 24 },
  ];
  const obstacles = retained
    .filter((element) => !element.isDeleted && !['arrow', 'line', 'pen', 'highlighter'].includes(element.type))
    .map(elementBounds);
  return candidates
    .map((candidate) => ({
      ...candidate,
      collisions: obstacles.filter((obstacle) => intersectsWithGap(
        { ...candidate, ...LESSON_BOARD },
        obstacle,
      )).length,
    }))
    .sort((a, b) => a.collisions - b.collisions)[0];
}

function inferLessonPages(scene) {
  const pages = Array.isArray(scene?.lessonDeck?.pages) ? scene.lessonDeck.pages : [];
  if (pages.length) return pages;
  const byPage = new Map();
  (scene?.elements || []).forEach((element) => {
    const pageId = element?.customData?.lessonPageId;
    if (!pageId) return;
    const existing = byPage.get(pageId) || {
      id: pageId,
      title: 'Lesson',
      topic: lessonTopicForElement(element) || 'general',
      focus: element?.customData?.focus || 'overview',
      order: byPage.size,
      bounds: elementBounds(element),
      summary: '',
      createdAt: element.createdAt || Date.now(),
      updatedAt: element.updated || Date.now(),
    };
    const bounds = elementBounds(element);
    existing.bounds = {
      x: Math.min(existing.bounds.x, bounds.x),
      y: Math.min(existing.bounds.y, bounds.y),
      w: Math.max(existing.bounds.x + existing.bounds.w, bounds.x + bounds.w) - Math.min(existing.bounds.x, bounds.x),
      h: Math.max(existing.bounds.y + existing.bounds.h, bounds.y + bounds.h) - Math.min(existing.bounds.y, bounds.y),
    };
    existing.title = element?.customData?.lessonPageTitle || existing.title;
    byPage.set(pageId, existing);
  });
  return [...byPage.values()].sort((a, b) => a.order - b.order);
}

function nextLessonPage(scene, topic, title, focus) {
  const pages = inferLessonPages(scene);
  const lastPage = pages.at(-1);
  const order = lastPage ? (Number.isFinite(lastPage.order) ? lastPage.order + 1 : pages.length) : 0;
  return {
    id: uid('lesson-page'),
    title: title || `Lesson ${order + 1}`,
    topic,
    focus,
    order,
    bounds: lastPage
      ? {
          x: lastPage.bounds.x + lastPage.bounds.w + LESSON_PAGE_GAP,
          y: lastPage.bounds.y,
          w: LESSON_BOARD.w,
          h: LESSON_BOARD.h,
        }
      : null,
    summary: '',
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

function createLessonBoard(page, topic) {
  return {
    id: uid('rect'),
    type: 'rect',
    x: page.bounds.x,
    y: page.bounds.y,
    w: page.bounds.w,
    h: page.bounds.h,
    width: page.bounds.w,
    height: page.bounds.h,
    z: 1,
    isDeleted: false,
    roughness: 1.15,
    style: {
      stroke: canvasInk(),
      fill: lessonBoardFill(),
      strokeWidth: 2,
      opacity: 1,
      dash: 'solid',
    },
    createdAt: Date.now(),
    customData: {
      ...teachingStyle('lesson-board', topic, 0.98),
      lessonPageId: page.id,
      lessonPageTitle: page.title,
      focus: page.focus,
    },
  };
}

function createLessonPageBadge(page, topic, frameId) {
  return createTextElement({
    id: uid('text'),
    text: `Lesson ${page.order + 1}`,
    x: page.bounds.x + 42,
    y: page.bounds.y + 26,
    maxWidth: 180,
    fontSize: 16,
    fontFamily: HAND_FONT,
    color: LESSON_COLORS.accent,
    semanticRole: 'lesson-badge',
    frameId,
    z: 5,
    customData: {
      ...teachingStyle('lesson-badge', topic, 0.7),
      lessonPageId: page.id,
      lessonPageTitle: page.title,
      focus: page.focus,
    },
  });
}

function cleanValues(values, fallback) {
  const source = Array.isArray(values) ? values : [];
  const cleaned = source
    .map((value) => String(value ?? '').trim())
    .filter((value) => value && value.length <= 12)
    .filter((value) => !/[;{}()[\]=]|example|array|delete|include/i.test(value))
    .slice(0, 8);
  return cleaned.length >= 3 ? cleaned : fallback;
}

function arrayPorts(count) {
  const ports = {
    left: { fixedPoint: [0, 0.68], side: 'left' },
    right: { fixedPoint: [1, 0.68], side: 'right' },
    'memory-strip': { fixedPoint: [0.5, 0.9], side: 'bottom', mode: 'inside', gap: 0 },
  };
  for (let index = 0; index < count; index += 1) {
    const x = (index + 0.5) / count;
    ports[`index:${index}`] = { fixedPoint: [x, 0.48], side: 'top', mode: 'inside', gap: 0 };
    ports[`cell:${index}`] = { fixedPoint: [x, 0.76], side: 'top', mode: 'inside', gap: 0 };
  }
  return ports;
}

function inferArrayFocus(request) {
  const explicit = normalizeTopic(request.focus);
  if (['overview', 'access', 'memory', 'insertion', 'deletion'].includes(explicit)) return explicit;
  const text = [request.title, request.definition, request.operation, request.callout].join(' ').toLowerCase();
  if (/\b(delete|deletion|remove|pop)\b/.test(text)) return 'deletion';
  if (/\b(insert|insertion|append|push)\b/.test(text)) return 'insertion';
  if (/\b(memory|contiguous|address)\b/.test(text)) return 'memory';
  if (/\b(access|index|lookup|read)\b/.test(text)) return 'access';
  return 'overview';
}

function arrayLessonCopy(focus, values) {
  const last = Math.max(0, values.length - 1);
  const middle = Math.min(2, last);
  const common = {
    definition: 'An array stores same-type values in one ordered, contiguous block of memory.',
    callouts: [
      { role: 'index-note', text: 'Index 0 is first.', port: 'index:0', fill: LESSON_COLORS.yellow },
      { role: 'access-note', text: `arr[${middle}] reads ${values[middle]} directly in O(1).`, port: `cell:${middle}`, fill: LESSON_COLORS.blue },
      { role: 'memory-note', text: 'Neighboring cells sit next to each other in memory.', port: 'memory-strip', fill: LESSON_COLORS.green },
    ],
    prompt: 'Next, ask about insertion, deletion, memory addresses, or open a code editor.',
  };
  if (focus === 'access') {
    return {
      ...common,
      definition: 'Array access uses a zero-based index to jump directly to one fixed-size cell.',
      callouts: [
        { role: 'index-note', text: `Index ${middle} marks the target cell.`, port: `index:${middle}`, fill: LESSON_COLORS.yellow },
        { role: 'access-note', text: `arr[${middle}] -> ${values[middle]} in O(1) time.`, port: `cell:${middle}`, fill: LESSON_COLORS.blue },
      ],
      prompt: 'Try changing a cell, then ask why indexed access stays O(1).',
    };
  }
  if (focus === 'memory') {
    return {
      ...common,
      definition: 'Contiguous storage means each array cell follows the previous cell at a predictable address.',
      callouts: [
        { role: 'memory-note', text: 'Every cell has the same width in memory.', port: 'memory-strip', fill: LESSON_COLORS.green },
        { role: 'access-note', text: 'address = base + index x element size', port: `cell:${middle}`, fill: LESSON_COLORS.blue },
      ],
      prompt: 'Next, ask how contiguous storage improves cache locality.',
    };
  }
  if (focus === 'insertion') {
    return {
      ...common,
      definition: 'Inserting into an array may require shifting later values to preserve order.',
      callouts: [
        { role: 'operation-note', text: 'Insert here: later cells shift one position right.', port: `cell:${middle}`, fill: LESSON_COLORS.yellow },
        { role: 'complexity-note', text: 'Middle insertion is O(n); appending can be O(1) when capacity exists.', port: `cell:${last}`, fill: LESSON_COLORS.blue },
      ],
      prompt: 'Ask for code to practice array insertion in the editor.',
    };
  }
  if (focus === 'deletion') {
    return {
      ...common,
      definition: 'Deleting an array value may require shifting later values; removing the final value needs no shift.',
      callouts: [
        { role: 'operation-note', text: 'Remove this cell: later values shift left.', port: `cell:${middle}`, fill: LESSON_COLORS.yellow },
        { role: 'complexity-note', text: 'Middle deletion is O(n); deleting the final logical item is O(1).', port: `cell:${last}`, fill: LESSON_COLORS.blue },
      ],
      prompt: 'For C++ memory cleanup, ask specifically about delete[].',
    };
  }
  return common;
}

function createLessonHeading({ topic, title, definition, x, y, width, focus, pageId, pageTitle, frameId }) {
  const heading = createTextElement({
    id: uid('text'),
    text: `${title} · ${focus === 'overview' ? 'step-by-step overview' : focus}`,
    x,
    y,
    maxWidth: width,
    fontSize: 28,
    fontFamily: HAND_FONT,
    color: canvasInk(),
    semanticRole: 'lesson-heading',
    z: 5,
    frameId,
    customData: {
      ...teachingStyle('lesson-heading', topic, 1),
      lessonPageId: pageId,
      lessonPageTitle: pageTitle,
      focus,
    },
  });
  const body = createTextElement({
    id: uid('text'),
    text: definition,
    x,
    y: heading.y + heading.h + 18,
    maxWidth: width,
    fontSize: 20,
    fontFamily: HAND_FONT,
    color: canvasInk(),
    semanticRole: 'definition',
    z: 5,
    frameId,
    customData: {
      ...teachingStyle('definition', topic, 1),
      lessonPageId: pageId,
      lessonPageTitle: pageTitle,
      focus,
    },
  });
  return { heading, body };
}

function createArrayLesson(page, request) {
  const topic = 'array';
  const values = cleanValues(request.values, ['12', '7', '19', '4', '23']);
  const focus = inferArrayFocus(request);
  const copy = arrayLessonCopy(focus, values);
  const baseX = page.bounds.x;
  const baseY = page.bounds.y;
  const foreground = canvasInk();
  const board = createLessonBoard(page, topic);
  const badge = createLessonPageBadge(page, topic, board.id);
  const { heading, body: definition } = createLessonHeading({
    topic,
    title: request.title || 'Array',
    definition: copy.definition,
    x: baseX + 48,
    y: baseY + 58,
    width: 720,
    focus,
    pageId: page.id,
    pageTitle: page.title,
    frameId: board.id,
  });

  const array = createWidgetElement(
    'array',
    baseX + 92,
    baseY + 214,
    Math.max(420, values.length * 68 + 76),
    146,
  );
  array.widgetData = {
    ...array.widgetData,
    title: request.title || 'Array',
    values,
    chromeBg: LESSON_COLORS.pink,
    valueColor: LESSON_COLORS.ink,
    caption: focus === 'deletion'
      ? 'Delete by shifting later elements left.'
      : focus === 'insertion'
        ? 'Insert by shifting later elements right.'
        : focus === 'memory'
          ? 'Cells stay contiguous in memory.'
          : 'Use the index to reach the exact cell.',
    highlights: focus === 'deletion'
      ? {
          2: { tone: 'danger', label: 'remove' },
          3: { tone: 'shift', label: 'shift left' },
          4: { tone: 'shift', label: 'shift left' },
        }
      : focus === 'insertion'
        ? {
            2: { tone: 'focus', label: 'insert here' },
            3: { tone: 'shift', label: 'shift right' },
            4: { tone: 'shift', label: 'shift right' },
          }
        : focus === 'access'
          ? { 2: { tone: 'focus', label: 'direct read' } }
          : focus === 'memory'
            ? { 1: { tone: 'memory', label: 'same-size cells' }, 2: { tone: 'memory', label: 'contiguous' } }
            : { 0: { tone: 'focus', label: 'index 0' }, 2: { tone: 'focus', label: 'O(1) lookup' } },
    agentMeta: {
      semanticRole: 'primary-visual',
      clusterKey: `lesson:${topic}`,
      contentSignature: `array:${values.join(',')}`,
    },
    agentSpawnId: `lesson-${Date.now()}`,
    spawnDelayMs: 140,
  };
  array.style = {
    ...array.style,
    stroke: LESSON_COLORS.ink,
    strokeWidth: 2,
  };
  array.customData = {
    ...teachingStyle('primary-visual', topic, 1),
    ports: arrayPorts(values.length),
    focus,
    lessonPageId: page.id,
    lessonPageTitle: page.title,
  };
  array.frameId = board.id;

  const positions = request.includeCodeEditor
    ? [
        { x: baseX - 120, y: baseY + 228, width: 150 },
        { x: baseX + 662, y: baseY + 214, width: 206 },
        { x: baseX + 560, y: baseY + 404, width: 290 },
      ]
    : [
        { x: baseX - 120, y: baseY + 228, width: 150 },
        { x: baseX + 662, y: baseY + 214, width: 206 },
        { x: baseX + 320, y: baseY + 404, width: 438 },
      ];
  const callouts = copy.callouts.map((item, index) => createCallout({
    text: item.text,
    ...positions[index],
    fill: item.fill,
    role: item.role,
    topic,
    frameId: board.id,
  }));
  const nextPrompt = createCallout({
    text: copy.prompt,
    x: request.includeCodeEditor ? baseX + 468 : baseX + 520,
    y: baseY + 518,
    width: request.includeCodeEditor ? 380 : 328,
    fill: LESSON_COLORS.pinkSoft,
    role: 'next-question',
    topic,
    frameId: board.id,
  });

  const highlight = (focus === 'access' || focus === 'deletion' || focus === 'insertion')
    ? {
        id: uid('ellipse'),
        type: 'ellipse',
        x: array.x + array.w * (focus === 'access' ? 0.32 : 0.48),
        y: array.y + 38,
        w: 86,
        h: 56,
        width: 86,
        height: 56,
        z: 4,
        isDeleted: false,
        roughness: 1.3,
        frameId: board.id,
        style: {
          stroke: focus === 'deletion' ? LESSON_COLORS.danger : LESSON_COLORS.accent,
          fill: 'transparent',
          strokeWidth: 2.4,
          opacity: 1,
          dash: 'dashed',
        },
        createdAt: Date.now(),
        customData: {
          ...teachingStyle('highlight-circle', topic, 0.66),
          lessonPageId: page.id,
          lessonPageTitle: page.title,
          focus,
        },
      }
    : null;

  const codeWidget = request.includeCodeEditor
    ? createWidgetElement(
        'code',
        baseX + 84,
        baseY + 402,
        360,
        174,
      )
    : null;

  if (codeWidget) {
    codeWidget.widgetData = {
      ...codeWidget.widgetData,
      title: request.codeTitle || `${request.title || 'Array'} Code`,
      language: request.codeLanguage || 'cpp',
      code: request.liveTyping ? '' : (request.code || codeWidget.widgetData.code || ''),
      liveTyping: request.liveTyping
        ? {
            fullText: request.code || '',
            startedAt: Date.now(),
            cps: 38,
          }
        : null,
      typingState: request.liveTyping ? 'typing' : 'idle',
    };
    codeWidget.customData = {
      ...teachingStyle('code-editor', topic, 0.94),
      lessonPageId: page.id,
      lessonPageTitle: page.title,
      focus,
    };
    codeWidget.frameId = board.id;
  }

  const baseElements = normalizeElementsV2([
    board,
    badge,
    heading,
    definition,
    array,
    ...(highlight ? [highlight] : []),
    ...callouts,
    nextPrompt,
    ...(codeWidget ? [codeWidget] : []),
  ]);
  const arrowStyle = {
    stroke: foreground,
    fill: 'transparent',
    strokeWidth: 2.4,
    opacity: 1,
    dash: 'solid',
  };
  const arrows = callouts.map((callout, index) => createBoundArrow({
    id: uid('arrow'),
    from: callout,
    to: array,
    toPort: copy.callouts[index].port,
    elements: baseElements,
    style: index === 0 ? { ...arrowStyle, strokeWidth: 2.8 } : arrowStyle,
    customData: {
      ...teachingStyle(`${copy.callouts[index].role}-connector`, topic, 0.78),
      targetPort: copy.callouts[index].port,
    },
  }));

  return resolveSceneBindings([...baseElements, ...arrows]);
}

function reconcileLessonElements(existing, lesson) {
  const oldByRole = new Map(
    existing
      .filter((element) => element.customData?.semanticRole)
      .map((element) => [`${element.type}:${element.customData.semanticRole}`, element]),
  );
  const idMap = new Map();
  lesson.forEach((element) => {
    const old = oldByRole.get(`${element.type}:${element.customData?.semanticRole}`);
    if (old) idMap.set(element.id, old.id);
  });

  return lesson.map((element) => {
    const oldId = idMap.get(element.id);
    const old = oldId ? existing.find((candidate) => candidate.id === oldId) : null;
    const next = {
      ...element,
      id: oldId || element.id,
      createdAt: old?.createdAt || element.createdAt,
      startBinding: element.startBinding
        ? { ...element.startBinding, elementId: idMap.get(element.startBinding.elementId) || element.startBinding.elementId }
        : element.startBinding,
      endBinding: element.endBinding
        ? { ...element.endBinding, elementId: idMap.get(element.endBinding.elementId) || element.endBinding.elementId }
        : element.endBinding,
      containerId: idMap.get(element.containerId) || element.containerId,
      labelId: idMap.get(element.labelId) || element.labelId,
    };
    if (next.type === 'widget' && old) {
      next.widgetData = {
        ...next.widgetData,
        agentSpawnId: null,
        spawnDelayMs: 0,
        agentMoveId: `lesson-move-${Date.now()}`,
        moveDelayMs: 80,
      };
    } else if (next.type === 'widget') {
      next.widgetData = {
        ...next.widgetData,
        agentSpawnId: next.widgetData?.agentSpawnId || `lesson-spawn-${Date.now()}`,
        spawnDelayMs: next.widgetData?.spawnDelayMs ?? 140,
      };
    }
    return next;
  });
}

const STRUCTURE_COPY = {
  stack: {
    definition: 'A stack keeps one active end: the last value pushed is the first value popped.',
    first: 'Push adds a value at the top.',
    second: 'Pop removes only the top value.',
    prompt: 'Next, ask for stack code or a push/pop walkthrough.',
  },
  queue: {
    definition: 'A queue processes values in arrival order: first in, first out.',
    first: 'Enqueue adds at the rear.',
    second: 'Dequeue removes from the front.',
    prompt: 'Next, ask for circular queue code or a trace.',
  },
  'linked-list': {
    definition: 'A linked list stores values in nodes connected by explicit next pointers.',
    first: 'The head points to the first node.',
    second: 'Each node links to the next node.',
    prompt: 'Next, ask about insertion, deletion, or pointer code.',
  },
  tree: {
    definition: 'A tree organizes nodes into parent-child relationships starting from one root.',
    first: 'The root is the entry point.',
    second: 'Children begin smaller subtrees.',
    prompt: 'Next, ask for a traversal or editable tree code.',
  },
  'hash-map': {
    definition: 'A hash map turns a key into a bucket so values can usually be found in O(1) time.',
    first: 'The hash function chooses a bucket.',
    second: 'Collisions need a resolution strategy.',
    prompt: 'Next, ask about collisions or open a code editor.',
  },
};

function genericStructureLesson(page, request) {
  const type = request.structureType || 'array';
  const title = request.title || type.replace(/-/g, ' ');
  const foreground = canvasInk();
  const copy = STRUCTURE_COPY[type] || {
    definition: `${title} connects its structure to a small set of predictable operations.`,
    first: 'Start by identifying the entry point.',
    second: 'Follow the relationships between values.',
    prompt: 'Ask for one operation at a time to continue.',
  };
  const board = createLessonBoard(page, type);
  const badge = createLessonPageBadge(page, type, board.id);
  const { heading, body: definition } = createLessonHeading({
    topic: type,
    title,
    definition: copy.definition,
    x: page.bounds.x + 54,
    y: page.bounds.y + 58,
    width: 620,
    focus: 'overview',
    pageId: page.id,
    pageTitle: page.title,
    frameId: board.id,
  });
  const visual = createWidgetElement(
    type,
    page.bounds.x + 220,
    page.bounds.y + 205,
    undefined,
    undefined,
  );
  visual.widgetData = {
    ...visual.widgetData,
    title,
    values: request.values || visual.widgetData.values,
    agentMeta: {
      semanticRole: 'primary-visual',
      clusterKey: `lesson:${type}`,
    },
  };
  visual.customData = {
    ...teachingStyle('primary-visual', type, 1),
    ports: {
      entry: { fixedPoint: [0.12, 0.35], side: 'left', mode: 'inside', gap: 0 },
      operation: { fixedPoint: [0.82, 0.68], side: 'right', mode: 'inside', gap: 0 },
    },
    lessonPageId: page.id,
    lessonPageTitle: page.title,
  };
  visual.frameId = board.id;
  const first = createCallout({
    text: copy.first,
    x: page.bounds.x + 26,
    y: page.bounds.y + 218,
    topic: type,
    role: 'entry-note',
    width: 175,
    fill: LESSON_COLORS.yellow,
    frameId: board.id,
  });
  const second = createCallout({
    text: copy.second,
    x: page.bounds.x + 654,
    y: page.bounds.y + 240,
    topic: type,
    role: 'operation-note',
    width: 180,
    fill: LESSON_COLORS.blue,
    frameId: board.id,
  });
  const prompt = createCallout({
    text: copy.prompt,
    x: page.bounds.x + 374,
    y: page.bounds.y + 508,
    topic: type,
    role: 'next-question',
    width: 445,
    fill: LESSON_COLORS.green,
    frameId: board.id,
  });
  const base = normalizeElementsV2([board, badge, heading, definition, visual, first, second, prompt]);
  return resolveSceneBindings([
    ...base,
    createBoundArrow({
      id: uid('arrow'),
      from: first,
      to: visual,
      toPort: 'entry',
      elements: base,
      style: {
        stroke: foreground,
        fill: 'transparent',
        strokeWidth: 2.3,
        opacity: 1,
        dash: 'solid',
      },
      customData: teachingStyle('entry-connector', type, 0.7),
    }),
    createBoundArrow({
      id: uid('arrow'),
      from: second,
      to: visual,
      toPort: 'operation',
      elements: base,
      style: {
        stroke: foreground,
        fill: 'transparent',
        strokeWidth: 2.3,
        opacity: 1,
        dash: 'solid',
      },
      customData: teachingStyle('operation-connector', type, 0.7),
    }),
  ]);
}

function boundsForElements(elements) {
  const visible = (elements || []).filter((element) => !element.isDeleted);
  if (!visible.length) return { x: 0, y: 0, w: 1, h: 1 };
  const minX = Math.min(...visible.map((element) => element.x));
  const minY = Math.min(...visible.map((element) => element.y));
  const maxX = Math.max(...visible.map((element) => element.x + Math.abs(element.w || element.width || 0)));
  const maxY = Math.max(...visible.map((element) => element.y + Math.abs(element.h || element.height || 0)));
  return { x: minX, y: minY, w: Math.max(1, maxX - minX), h: Math.max(1, maxY - minY) };
}

export function frameTeachingScene(elements, stageElement, {
  margin = 54,
  reservedTop = 94,
  reservedBottom = 142,
} = {}) {
  const bounds = boundsForElements(elements);
  const stageWidth = Math.max(320, stageElement?.clientWidth || 1180);
  const stageHeight = Math.max(280, (stageElement?.clientHeight || 760) - reservedTop - reservedBottom);
  const zoom = Math.max(0.32, Math.min(
    1,
    (stageWidth - margin * 2) / bounds.w,
    (stageHeight - margin) / bounds.h,
  ));
  return {
    zoom,
    panX: margin / zoom - bounds.x,
    panY: reservedTop / zoom - bounds.y,
  };
}

export function compileTeachingScene({
  scene,
  stageElement,
  request,
  replaceExistingTopic = true,
}) {
  const structureType = request?.structureType || 'array';
  const topic = normalizeTopic(request?.topic || structureType);
  const allElements = scene?.elements || [];
  const currentDeck = scene?.lessonDeck || { pages: [], currentPageId: null };
  const requestedPageMode = request?.pageMode === 'next' ? 'next' : 'current';
  const currentPage = currentDeck.pages.find((page) => page.id === currentDeck.currentPageId) || null;
  const requestedPage = requestedPageMode === 'current' && request?.lessonPageId
    ? currentDeck.pages.find((page) => page.id === request.lessonPageId) || null
    : null;
  const page = requestedPage
    || (requestedPageMode === 'current' && currentPage)
    || nextLessonPage(scene, topic, request?.title || structureType, request?.focus || 'overview');
  if (!page.bounds) {
    const retainedForOrigin = (scene?.elements || []).filter((element) => !belongsToAgentLesson(element, topic));
    const origin = findLessonOrigin(scene, stageElement, retainedForOrigin);
    page.bounds = { x: origin.x, y: origin.y, w: LESSON_BOARD.w, h: LESSON_BOARD.h };
  }
  page.title = request?.title || page.title;
  page.topic = topic;
  page.focus = request?.focus || page.focus || 'overview';
  page.updatedAt = Date.now();
  page.summary = request?.definition || page.summary || '';

  const retained = (scene?.elements || []).filter((element) => {
    if (!replaceExistingTopic) return true;
    if (requestedPageMode === 'next') return true;
    if (!belongsToAgentLesson(element, topic)) return true;
    const elementPageId = element?.customData?.lessonPageId || null;
    return elementPageId && elementPageId !== page.id;
  });

  const lesson = structureType === 'array'
    ? createArrayLesson(page, request || {})
    : genericStructureLesson(page, request || {});
  const existingTopic = allElements.filter((element) => (
    lessonTopicForElement(element) === topic
    && element.customData?.lessonVersion === LESSON_VERSION
    && element.customData?.lessonPageId === page.id
  ));
  const reconciledLesson = reconcileLessonElements(existingTopic, lesson);
  const resolved = resolveSceneBindings(normalizeElementsV2([...retained, ...reconciledLesson]));
  const validation = validateScene(resolved);
  const nextPages = currentDeck.pages.some((candidate) => candidate.id === page.id)
    ? currentDeck.pages.map((candidate) => (candidate.id === page.id ? { ...candidate, ...page } : candidate))
    : currentDeck.pages.concat([page]);
  return {
    elements: resolved,
    validation,
    createdIds: reconciledLesson.map((element) => element.id),
    viewport: frameTeachingScene(reconciledLesson, stageElement),
    lessonDeck: {
      pages: nextPages
        .map((candidate, index) => ({
          ...candidate,
          order: Number.isFinite(candidate.order) ? candidate.order : index,
        }))
        .sort((a, b) => a.order - b.order),
      currentPageId: page.id,
    },
    currentPage: page,
  };
}
