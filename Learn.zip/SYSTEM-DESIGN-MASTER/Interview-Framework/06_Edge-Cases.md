# Interview Framework — Edge Cases

> **Permanent Recall:** Interview-specific edge cases are situations that derail candidates but are **handleable** with the right strategies. This file covers: interviewer interruptions, not knowing the answer, ambiguous questions, realizing a flaw mid-interview, unknown technology, and time running out. For each: what happens, how it feels, and exactly what to do.

---

## Edge Case 1: Interviewer Interrupts Your Flow

### What Happens
You're in the middle of explaining the fan-out mechanism. The interviewer cuts in: "What about consistency when a user unfollows?"

### How It Feels
Disorienting. You lose your thread. You might feel defensive or rushed.

### Strategy
1. **Acknowledge:** *"Good point—let me address that."*
2. **Answer their question** concisely.
3. **Reconnect:** *"To finish the previous thought—[one sentence]. Now, for the unfollow case..."*
4. **Don't resist.** They're probing, not attacking. Answering well shows adaptability.

> **FAANG Tip:** Interruptions often mean they're interested. Treat them as collaboration, not sabotage.

---

## Edge Case 2: You Don't Know the Answer

### What Happens
Interviewer: "How does Kafka handle exactly-once semantics?" You've never dug into Kafka internals.

### How It Feels
Panic. Imposter syndrome. Temptation to fake it or say "I don't know" and stop.

### Strategy
1. **Don't fake it.** Wrong confidence is worse than honest uncertainty.
2. **Reason from first principles:** *"I'm not 100% sure about Kafka's implementation, but generally exactly-once requires idempotent producers and transactional commits. I'd assume Kafka uses something like that—I'd verify the docs."*
3. **Pivot to what you know:** *"What I do know is the trade-off: exactly-once adds latency and complexity vs at-least-once. For our use case..."*
4. **Offer to look it up:** *"In a real scenario, I'd check the documentation and confirm."*

### Script
- *"I haven't worked with that directly, but my understanding is [general principle]. I'd want to validate the specifics."*
- *"Let me reason from first principles: we need [X], so the solution likely involves [Y]. The exact implementation I'd need to look up."*

---

## Edge Case 3: The Question Is Ambiguous

### What Happens
"Design a notification system." Notifications how? Push? Email? In-app? All? Scale?

### How It Feels
Overwhelmed. Too many directions. Paralysis.

### Strategy
1. **Narrow it yourself:** *"Notification system could mean many things. I'll assume we're focusing on push notifications to mobile devices at moderate scale—say 10M DAU. Does that work, or should we include email/in-app too?"*
2. **State 2–3 assumptions** and ask for confirmation.
3. **Proceed.** Don't ask 10 more questions. Make reasonable choices and move on.

### Script
- *"There are a few ways to interpret this. I'll assume [X, Y, Z]. If that's off, you can correct me."*
- *"I'm scoping to [core use case] first. We can extend later."*

---

## Edge Case 4: You Realize Your Design Has a Flaw Mid-Interview

### What Happens
You're explaining the design. Suddenly you see: "Wait—that creates a race condition" or "That won't scale."

### How It Feels
Dread. Embarrassment. Temptation to hide it or hope they don't notice.

### Strategy
1. **Call it out immediately.** *"Actually, I just realized a problem—[describe flaw]. Let me correct that."*
2. **Fix it out loud:** *"The fix would be [approach]. So we'd need to [change X to Y]."*
3. **Don't over-apologize.** One correction is fine. Recovery shows maturity.

> **FAANG Tip:** Catching and fixing your own mistake often *improves* your score. It demonstrates self-awareness and rigor.

### Script
- *"Good catch—actually *I* just caught it. [Flaw]. The fix is [solution]. Let me update the diagram."*
- *"I misspoke earlier. The right approach is [X] because [reason]."*

---

## Edge Case 5: Interviewer Asks About a Technology You Haven't Used

### What Happens
"How would you use ZooKeeper for leader election?" You've never used ZooKeeper.

### How It Feels
Exposed. Like you're underqualified.

### Strategy
1. **Be honest:** *"I haven't used ZooKeeper in production, but I know it's a coordination service with a hierarchical key-value store and watchers."*
2. **Connect to what you know:** *"The concept maps to what I know about distributed consensus—we need a way for nodes to agree on who's the leader. ZooKeeper provides that via ephemeral nodes and watches. I'd need to look up the exact API."*
3. **Propose an alternative** if appropriate: *"Alternatively, we could use etcd or Consul for similar semantics. Have you used ZooKeeper in this context?"*

### Script
- *"I'm familiar with the concepts but haven't implemented it. From what I know, [general behavior]. I'd study the docs before implementing."*
- *"I haven't used [X], but [similar tech] works similarly—[brief explanation]."*

---

## Edge Case 6: Time Is Running Out

### What Happens
20 minutes left. You're still in high-level design. Deep dive hasn't started. Wrap-up is impossible at this rate.

### How It Feels
Rushed. Anxious. Temptation to speed-talk or give up on wrap-up.

### Strategy
1. **Acknowledge aloud:** *"We're running short on time. Let me prioritize."*
2. **Compress the current phase:** *"I'll summarize the remaining components quickly: [bullet points]."*
3. **Do a mini deep-dive:** Pick ONE critical component. Spend 5 minutes. Say "I'd go deeper on [X] given more time."
4. **Never skip wrap-up:** *"Quick wrap-up: bottleneck would be [X], we'd monitor [Y], future work includes [Z]."*
5. **Offer to continue:** *"If we had more time, I'd elaborate on [X]. Should I continue or is there something else you'd like to explore?"*

### Script
- *"We have about 10 minutes left. Let me do a focused deep-dive on [most critical component] and then wrap up."*
- *"I'll fast-forward through [less critical part] to get to [critical part] and wrap-up."*

---

## Edge Case 7: Interviewer Seems Uninterested or Cold

### What Happens
They're quiet. Minimal nods. Hard to read.

### How It Feels
Rejected. Like you're bombing.

### Strategy
1. **Don't assume.** Some interviewers are naturally reserved. It's not always about you.
2. **Keep going.** Maintain structure. Don't shrink or speed up nervously.
3. **Engage deliberately:** *"Does this direction make sense, or would you like me to focus elsewhere?"*
4. **Stay confident.** Your job is to demonstrate thinking. Their demeanor may not reflect your performance.

---

## Edge Case 8: You Blank on a Simple Concept

### What Happens
They ask "What's the difference between 301 and 302?" You know it's redirects but can't articulate.

### How It Feels
Mortifying. "I should know this."

### Strategy
1. **Buy time:** *"Let me think for a moment."* (5–10 seconds is fine.)
2. **State what you're sure of:** *"Both are redirects. 301 is permanent—browsers cache. 302 is temporary—they'll re-request."*
3. **If still stuck:** *"I'm drawing a blank on the exact semantics. I'd look it up—but the key for our design is whether we want caching of the redirect or not."*

---

## Summary Table

| Edge Case | Key Action |
|-----------|------------|
| **Interruption** | Acknowledge, answer, reconnect to your flow |
| **Don't know** | Reason from first principles; don't fake; offer to verify |
| **Ambiguous question** | Narrow scope with 2–3 assumptions; ask confirmation; proceed |
| **Design flaw** | Call it out; fix it; move on without over-apologizing |
| **Unknown tech** | Be honest; connect to concepts; propose alternatives |
| **Time running out** | Prioritize; compress; mini deep-dive; never skip wrap-up |
| **Cold interviewer** | Don't assume; keep structure; engage deliberately |
| **Blank on concept** | Buy time; state what you know; pivot to design impact |

---

## Universal Recovery Script

When anything goes wrong:

1. **Pause** (1–2 seconds)
2. **Acknowledge:** *"Good question"* / *"Let me think"* / *"I want to get this right"*
3. **Respond** with your best answer or a simplified version
4. **Recover:** *"If I had more time, I'd [elaborate]. Should I continue?"*
5. **Move forward.** Don't dwell.
