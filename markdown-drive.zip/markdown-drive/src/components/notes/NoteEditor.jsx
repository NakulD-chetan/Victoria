import { memo, useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import Image from '@tiptap/extension-image';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import { Table } from '@tiptap/extension-table';
import { TableRow } from '@tiptap/extension-table-row';
import { TableHeader } from '@tiptap/extension-table-header';
import { TableCell } from '@tiptap/extension-table-cell';
import CodeBlockLowlight from '@tiptap/extension-code-block-lowlight';
import { common, createLowlight } from 'lowlight';
import TurndownService from 'turndown';
import { gfm } from 'turndown-plugin-gfm';
import { marked } from 'marked';
import { DOMParser as PmDOMParser } from '@tiptap/pm/model';
import { useNotesStore } from '../../stores/notes-store';
import NotePreview from './NotePreview';

const lowlight = createLowlight(common);
function createCopyIcon() {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('width', '14');
  svg.setAttribute('height', '14');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2');
  const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  rect.setAttribute('x', '9'); rect.setAttribute('y', '9');
  rect.setAttribute('width', '10'); rect.setAttribute('height', '10');
  rect.setAttribute('rx', '2');
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('d', 'M15 9V7a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2');
  svg.append(rect, path);
  return svg;
}

function createCheckIcon() {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('width', '14');
  svg.setAttribute('height', '14');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2.2');
  const polyline = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
  polyline.setAttribute('points', '20 6 9 17 4 12');
  svg.append(polyline);
  return svg;
}

class CodeBlockPmView {
  constructor(pmNode, view, getPos) {
    this.node = pmNode;
    this.view = view;
    this.getPos = getPos;

    const language = pmNode.attrs.language || 'code';

    this.dom = document.createElement('div');
    this.dom.classList.add('sn-codeblock-nodeview');

    const header = document.createElement('div');
    header.classList.add('sn-codeblock__header');
    header.contentEditable = 'false';

    const langSpan = document.createElement('span');
    langSpan.classList.add('sn-codeblock__lang');
    langSpan.textContent = language;
    this.langSpan = langSpan;

    const actions = document.createElement('div');
    actions.classList.add('sn-codeblock__actions');

    const copyBtn = document.createElement('button');
    copyBtn.classList.add('sn-codeblock__btn', 'sn-codeblock__btn--icon');
    copyBtn.title = 'Copy code';
    copyBtn.appendChild(createCopyIcon());
    copyBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const text = this.node.textContent;
      navigator.clipboard.writeText(text).then(() => {
        copyBtn.innerHTML = '';
        copyBtn.appendChild(createCheckIcon());
        copyBtn.classList.add('sn-codeblock__btn--success');
        setTimeout(() => {
          copyBtn.innerHTML = '';
          copyBtn.appendChild(createCopyIcon());
          copyBtn.classList.remove('sn-codeblock__btn--success');
        }, 1600);
      }).catch(() => {});
    });

    actions.appendChild(copyBtn);
    header.append(langSpan, actions);

    this.contentDOM = document.createElement('pre');
    this.contentDOM.classList.add('sn-codeblock-nodeview__code');

    this.dom.append(header, this.contentDOM);
  }

  update(node) {
    if (node.type.name !== 'codeBlock') return false;
    this.node = node;
    const lang = node.attrs.language || 'code';
    this.langSpan.textContent = lang;
    return true;
  }

  selectNode() { this.dom.classList.add('ProseMirror-selectednode'); }
  deselectNode() { this.dom.classList.remove('ProseMirror-selectednode'); }
  stopEvent(event) { return event.target.closest('button') !== null; }
  ignoreMutation(mutation) {
    return !this.contentDOM.contains(mutation.target);
  }
}

const ModernCodeBlockLowlight = CodeBlockLowlight.extend({
  addNodeView() {
    return ({ node, view, getPos }) => new CodeBlockPmView(node, view, getPos);
  },
});

const turndown = new TurndownService({
  headingStyle: 'atx',
  codeBlockStyle: 'fenced',
  bulletListMarker: '-',
  emDelimiter: '*',
  strongDelimiter: '**',
});
turndown.use(gfm);
turndown.addRule('taskListItem', {
  filter: (node) => node.nodeName === 'LI' && node.getAttribute('data-type') === 'taskItem',
  replacement: (content, node) => {
    const checked = node.getAttribute('data-checked') === 'true';
    return `- [${checked ? 'x' : ' '}] ${content.trim()}\n`;
  },
});
turndown.addRule('strikethrough', {
  filter: ['s', 'del'],
  replacement: (content) => `~~${content}~~`,
});
turndown.addRule('fencedCodeBlockWithLanguage', {
  filter: (node) => node.nodeName === 'PRE' && node.firstChild?.nodeName === 'CODE',
  replacement: (_content, node) => {
    const codeNode = node.firstChild;
    const className = codeNode.getAttribute('class') || '';
    const langMatch = className.match(/language-([A-Za-z0-9_+-]+)/);
    const language = langMatch?.[1] || codeNode.getAttribute('data-language') || '';
    const code = (codeNode.textContent || '').replace(/\n$/, '');
    return `\n\n\`\`\`${language}\n${code}\n\`\`\`\n\n`;
  },
});

function htmlToMarkdown(html) {
  if (!html || html === '<p></p>') return '';
  return turndown.turndown(html).trim();
}

function markdownToHtml(md) {
  if (!md) return '';

  let processed = md.replace(
    /^- \[x\] (.+)$/gm,
    '<!--TASK_CHECKED-->$1<!--/TASK-->'
  ).replace(
    /^- \[ \] (.+)$/gm,
    '<!--TASK_UNCHECKED-->$1<!--/TASK-->'
  );

  let html = marked.parse(processed, { gfm: true, breaks: false });

  html = html.replace(
    /<!--TASK_CHECKED-->(.+?)<!--\/TASK-->/g,
    '<ul data-type="taskList"><li data-type="taskItem" data-checked="true"><label><input type="checkbox" checked><span></span></label><div>$1</div></li></ul>'
  ).replace(
    /<!--TASK_UNCHECKED-->(.+?)<!--\/TASK-->/g,
    '<ul data-type="taskList"><li data-type="taskItem" data-checked="false"><label><input type="checkbox"><span></span></label><div>$1</div></li></ul>'
  );

  return html;
}

function looksLikeMarkdown(text) {
  if (!text || text.length < 3) return false;
  if (/^```[\w+-]*\s*[\r\n][\s\S]*[\r\n]```/m.test(text)) return true;
  const patterns = [
    /^#{1,6}\s/m,
    /^```/m,
    /^\|.+\|/m,
    /^>\s/m,
    /^[-*+]\s/m,
    /^\d+\.\s/m,
    /\*\*.+\*\*/,
    /\[.+\]\(.+\)/,
    /^---$/m,
    /^- \[[ x]\]/m,
    /`[^`]+`/,
  ];
  let hits = 0;
  for (const p of patterns) {
    if (p.test(text)) hits++;
    if (hits >= 2) return true;
  }
  return hits >= 2 || /^#{1,3}\s.+/m.test(text);
}

function extractMermaidCode(text) {
  if (!text) return null;
  const fencedMatch = text.match(/^\s*```mermaid\s*[\r\n]+([\s\S]*?)\s*```\s*$/i);
  if (fencedMatch) return fencedMatch[1].trim();
  return null;
}

function looksLikeMermaid(text) {
  const direct = extractMermaidCode(text);
  if (direct) return true;

  const trimmed = text?.trim();
  if (!trimmed) return false;

  return /^(?:graph|flowchart|sequenceDiagram|classDiagram|stateDiagram(?:-v2)?|erDiagram|journey|gantt|pie|mindmap|timeline|gitGraph|quadrantChart|requirementDiagram|C4Context|C4Container|C4Component|C4Dynamic|C4Deployment|zenuml|block-beta)\b/m.test(trimmed);
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function insertHtmlSlice(view, html, fallbackText = '') {
  const wrapper = document.createElement('div');
  wrapper.innerHTML = html;
  try {
    const parser = PmDOMParser.fromSchema(view.state.schema);
    const slice = parser.parseSlice(wrapper);
    view.dispatch(view.state.tr.replaceSelection(slice));
    return true;
  } catch (e) {
    console.warn('Rich paste fallback:', e);
    if (fallbackText) {
      const textNode = view.state.schema.text(fallbackText);
      view.dispatch(view.state.tr.replaceSelectionWith(textNode));
      return true;
    }
    return false;
  }
}

const SLASH_ITEMS = [
  { title: 'Text', description: 'Plain text block', icon: 'T', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setParagraph().run(); } },
  { title: 'Heading 1', description: 'Large heading', icon: 'H1', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setHeading({ level: 1 }).run(); } },
  { title: 'Heading 2', description: 'Medium heading', icon: 'H2', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setHeading({ level: 2 }).run(); } },
  { title: 'Heading 3', description: 'Small heading', icon: 'H3', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setHeading({ level: 3 }).run(); } },
  { title: 'Bullet List', description: 'Unordered list', icon: '\u2022', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).toggleBulletList().run(); } },
  { title: 'Numbered List', description: 'Ordered list', icon: '1.', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).toggleOrderedList().run(); } },
  { title: 'Task List', description: 'Checklist with todos', icon: '\u2611', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).toggleTaskList().run(); } },
  { title: 'Code Block', description: 'Code with syntax highlighting', icon: '</>', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setCodeBlock().run(); } },
  { title: 'Blockquote', description: 'Quote block', icon: '\u201C', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setBlockquote().run(); } },
  { title: 'Divider', description: 'Horizontal separator', icon: '\u2500', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setHorizontalRule().run(); } },
  { title: 'Table', description: 'Insert a table', icon: '\u2592', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run(); } },
  { title: 'Image', description: 'Upload or paste an image', icon: '\uD83D\uDDBC', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).run(); document.getElementById('note-img-upload')?.click(); } },
  { title: 'Mermaid', description: 'Diagram with Mermaid syntax', icon: '\u25B6', command: ({ editor, range }) => { editor.chain().focus().deleteRange(range).setCodeBlock({ language: 'mermaid' }).insertContent('graph TD\n  A[Start] --> B[End]').run(); } },
];

function SlashCommandMenu({ items, selectedIndex, onSelect }) {
  return (
    <div className="slash-menu">
      {items.map((item, idx) => (
        <button
          key={item.title}
          className={`slash-menu__item ${idx === selectedIndex ? 'slash-menu__item--active' : ''}`}
          onClick={() => onSelect(idx)}
        >
          <span className="slash-menu__icon">{item.icon}</span>
          <div className="slash-menu__text">
            <span className="slash-menu__title">{item.title}</span>
            <span className="slash-menu__desc">{item.description}</span>
          </div>
        </button>
      ))}
    </div>
  );
}

async function uploadImage(file) {
  const formData = new FormData();
  formData.append('image', file);
  try {
    const token = localStorage.getItem('inkdrop-token');
    const headers = token ? { 'Authorization': `Bearer ${token}` } : {};
    const res = await fetch('/api/notes/upload-image', { method: 'POST', headers, body: formData });
    if (!res.ok) throw new Error('Upload failed');
    const data = await res.json();
    return data.url;
  } catch (e) {
    const reader = new FileReader();
    return new Promise((resolve) => {
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
  }
}

const NoteEditor = memo(function NoteEditor({ noteId }) {
  const notes = useNotesStore((s) => s.notes);
  const updateNote = useNotesStore((s) => s.updateNote);
  const addTagToNote = useNotesStore((s) => s.addTagToNote);
  const removeTagFromNote = useNotesStore((s) => s.removeTagFromNote);

  const note = notes.find((n) => n.id === noteId);
  const saveRef = useRef(null);
  const [title, setTitle] = useState('');
  const [tagInput, setTagInput] = useState('');
  const [slashOpen, setSlashOpen] = useState(false);
  const [slashPos, setSlashPos] = useState({ top: 0, left: 0 });
  const [slashFilter, setSlashFilter] = useState('');
  const [slashIdx, setSlashIdx] = useState(0);
  const [slashRange, setSlashRange] = useState(null);
  const [bubblePos, setBubblePos] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const imgInputRef = useRef(null);
  const lastNoteIdRef = useRef(null);

  const toggleFullscreen = useCallback(() => setIsFullscreen((f) => !f), []);

  const requestPreviewMode = useCallback((nextMode = null) => {
    const resolved = typeof nextMode === 'boolean' ? nextMode : !previewMode;
    setPreviewMode(resolved);
  }, [previewMode]);

  const filteredSlash = useMemo(() => {
    if (!slashFilter) return SLASH_ITEMS;
    const q = slashFilter.toLowerCase();
    return SLASH_ITEMS.filter(i => i.title.toLowerCase().includes(q));
  }, [slashFilter]);

  const extensions = useMemo(() => [
    StarterKit.configure({
      codeBlock: false,
      heading: { levels: [1, 2, 3] },
    }),
    Placeholder.configure({ placeholder: 'Type / for commands...' }),
    Image.configure({ inline: false, allowBase64: true }),
    TaskList,
    TaskItem.configure({ nested: true }),
    Underline,
    Link.configure({ openOnClick: false, autolink: true }),
    ModernCodeBlockLowlight.configure({ lowlight }),
    Table.configure({ resizable: true }),
    TableRow,
    TableHeader,
    TableCell,
  ], []);

  const saveBody = useCallback((html) => {
    if (!noteId) return;
    clearTimeout(saveRef.current);
    saveRef.current = setTimeout(() => {
      const md = htmlToMarkdown(html);
      updateNote(noteId, { body: md });
    }, 400);
  }, [noteId, updateNote]);

  const editor = useEditor({
    extensions,
    content: '',
    editorProps: {
      attributes: {
        class: 'sn-prose',
      },
      handleDOMEvents: {
        keydown: (view, event) => {
          if (slashOpen) {
            if (event.key === 'ArrowDown') {
              event.preventDefault();
              setSlashIdx(i => Math.min(i + 1, filteredSlash.length - 1));
              return true;
            }
            if (event.key === 'ArrowUp') {
              event.preventDefault();
              setSlashIdx(i => Math.max(i - 1, 0));
              return true;
            }
            if (event.key === 'Enter') {
              event.preventDefault();
              if (filteredSlash[slashIdx]) {
                filteredSlash[slashIdx].command({ editor: view.state, range: slashRange });
              }
              setSlashOpen(false);
              return true;
            }
            if (event.key === 'Escape') {
              event.preventDefault();
              setSlashOpen(false);
              return true;
            }
          }
          return false;
        },
      },
      handleDrop: (view, event) => {
        const files = event.dataTransfer?.files;
        if (files?.length) {
          for (const file of files) {
            if (file.type.startsWith('image/')) {
              event.preventDefault();
              uploadImage(file).then(url => {
                view.dispatch(view.state.tr.replaceSelectionWith(
                  view.state.schema.nodes.image.create({ src: url })
                ));
              });
              return true;
            }
          }
        }
        return false;
      },
      handlePaste: (view, event) => {
        const items = event.clipboardData?.items;
        if (items) {
          for (const item of items) {
            if (item.type.startsWith('image/')) {
              event.preventDefault();
              const file = item.getAsFile();
              if (file) {
                uploadImage(file).then(url => {
                  view.dispatch(view.state.tr.replaceSelectionWith(
                    view.state.schema.nodes.image.create({ src: url })
                  ));
                });
              }
              return true;
            }
          }
        }

        const plainText = event.clipboardData?.getData('text/plain');
        const hasHtml = event.clipboardData?.types?.includes('text/html');

        if (plainText && !hasHtml && looksLikeMermaid(plainText)) {
          event.preventDefault();
          const mermaidCode = extractMermaidCode(plainText) || plainText.trim();
          insertHtmlSlice(view, `<pre><code class="language-mermaid">${escapeHtml(mermaidCode)}</code></pre>`, mermaidCode);
          return true;
        }

        if (plainText && !hasHtml && looksLikeMarkdown(plainText)) {
          event.preventDefault();
          const html = markdownToHtml(plainText);
          insertHtmlSlice(view, html, plainText);
          return true;
        }

        return false;
      },
    },
    onSelectionUpdate: ({ editor: ed }) => {
      const { from, to } = ed.state.selection;
      if (from !== to && ed.view) {
        const coords = ed.view.coordsAtPos(from);
        const editorRect = ed.view.dom.closest('.ne-panel')?.getBoundingClientRect() || { top: 0, left: 0 };
        setBubblePos({ top: coords.top - editorRect.top - 44, left: coords.left - editorRect.left });
      } else {
        setBubblePos(null);
      }
    },
    onUpdate: ({ editor: ed }) => {
      const html = ed.getHTML();
      saveBody(html);

      const { from } = ed.state.selection;
      const textBefore = ed.state.doc.textBetween(Math.max(0, from - 20), from, '\n');
      const slashMatch = textBefore.match(/\/([a-zA-Z0-9]*)$/);

      if (slashMatch) {
        const coords = ed.view.coordsAtPos(from);
        const bodyEl = ed.view.dom.closest('.ne-body');
        const bodyRect = bodyEl?.getBoundingClientRect() || { top: 0, left: 0 };
        const scrollTop = bodyEl?.scrollTop || 0;
        setSlashPos({
          top: coords.bottom - bodyRect.top + scrollTop + 4,
          left: coords.left - bodyRect.left,
        });
        setSlashFilter(slashMatch[1]);
        setSlashIdx(0);
        setSlashRange({ from: from - slashMatch[0].length, to: from });
        setSlashOpen(true);
      } else {
        setSlashOpen(false);
      }
    },
  });

  useEffect(() => {
    if (note && editor && lastNoteIdRef.current !== noteId) {
      lastNoteIdRef.current = noteId;
      setTitle(note.title);
      const html = markdownToHtml(note.body);
      editor.commands.setContent(html);
    }
  }, [noteId, note, editor]);

  useEffect(() => {
    const handleFsKey = (e) => {
      if (e.key === 'F11') { e.preventDefault(); toggleFullscreen(); }
      if (e.key === 'Escape' && isFullscreen) { e.preventDefault(); setIsFullscreen(false); }
    };
    window.addEventListener('keydown', handleFsKey);
    return () => window.removeEventListener('keydown', handleFsKey);
  }, [toggleFullscreen, isFullscreen]);

  useEffect(() => {
    const handlePreviewToggle = (e) => {
      const next = typeof e?.detail?.preview === 'boolean' ? e.detail.preview : null;
      requestPreviewMode(next);
    };
    window.addEventListener('notes-toggle-preview', handlePreviewToggle);
    return () => window.removeEventListener('notes-toggle-preview', handlePreviewToggle);
  }, [requestPreviewMode]);

  useEffect(() => {
    const handleFullscreenToggle = (e) => {
      const targetNoteId = e?.detail?.noteId ?? null;
      if (targetNoteId && targetNoteId !== noteId) return;
      toggleFullscreen();
    };
    window.addEventListener('notes-toggle-fullscreen', handleFullscreenToggle);
    return () => window.removeEventListener('notes-toggle-fullscreen', handleFullscreenToggle);
  }, [noteId, toggleFullscreen]);

  const onTitle = useCallback((e) => {
    setTitle(e.target.value);
    updateNote(noteId, { title: e.target.value });
  }, [noteId, updateNote]);

  const onTagKey = (e) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      addTagToNote(noteId, tagInput.trim());
      setTagInput('');
    }
    if (e.key === 'Backspace' && !tagInput && note?.tags.length) {
      removeTagFromNote(noteId, note.tags[note.tags.length - 1]);
    }
  };

  const handleSlashSelect = useCallback((idx) => {
    if (filteredSlash[idx] && editor && slashRange) {
      filteredSlash[idx].command({ editor, range: slashRange });
    }
    setSlashOpen(false);
  }, [filteredSlash, editor, slashRange]);

  const handleImgUpload = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file || !editor) return;
    const url = await uploadImage(file);
    editor.chain().focus().setImage({ src: url }).run();
    e.target.value = '';
  }, [editor]);

  const handleCoverUpload = useCallback(async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = await uploadImage(file);
    updateNote(noteId, { coverImage: url });
    e.target.value = '';
  }, [noteId, updateNote]);

  const wordCount = useMemo(() => {
    if (!editor) return { w: 0, c: 0 };
    const text = editor.state.doc.textContent;
    return { w: text.trim() ? text.trim().split(/\s+/).length : 0, c: text.length };
  }, [editor?.state.doc.textContent]);

  if (!note) return null;

  return (
    <div className={`ne-panel${isFullscreen ? ' ne-panel--fullscreen' : ''}`}>
      {/* Cover Image */}
      {note.coverImage && (
        <div className="ne-cover" style={{ backgroundImage: `url(${note.coverImage})` }}>
          <label className="ne-cover__change">
            Change cover
            <input type="file" accept="image/*" hidden onChange={handleCoverUpload} />
          </label>
          <button className="ne-cover__remove" onClick={() => updateNote(noteId, { coverImage: null })}>Remove</button>
        </div>
      )}

      {/* Title */}
      <div className="ne-title-row">
        {!note.coverImage && (
          <label className="ne-add-cover">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            Add cover
            <input type="file" accept="image/*" hidden onChange={handleCoverUpload} />
          </label>
        )}
        <input
          className="ne-title"
          type="text"
          placeholder="Untitled"
          value={title}
          onChange={onTitle}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); editor?.commands.focus(); } }}
        />
      </div>

      {/* Tags */}
      <div className="ne-tagbar">
        {note.tags.map((t) => (
          <span key={t} className="ne-tagbar__tag">
            #{t}
            <button onClick={() => removeTagFromNote(noteId, t)}>&times;</button>
          </span>
        ))}
        <input
          className="ne-tagbar__input"
          placeholder={note.tags.length === 0 ? 'Add tag...' : ''}
          value={tagInput}
          onChange={(e) => setTagInput(e.target.value)}
          onKeyDown={onTagKey}
        />
      </div>

      {/* Floating toolbar on text selection */}
      {editor && bubblePos && (
        <div className="bubble-menu" style={{ position: 'absolute', top: bubblePos.top, left: bubblePos.left, zIndex: 50 }}>
          <button onClick={() => editor.chain().focus().toggleBold().run()} className={editor.isActive('bold') ? 'is-active' : ''}>
            <strong>B</strong>
          </button>
          <button onClick={() => editor.chain().focus().toggleItalic().run()} className={editor.isActive('italic') ? 'is-active' : ''}>
            <em>I</em>
          </button>
          <button onClick={() => editor.chain().focus().toggleUnderline().run()} className={editor.isActive('underline') ? 'is-active' : ''}>
            <u>U</u>
          </button>
          <button onClick={() => editor.chain().focus().toggleStrike().run()} className={editor.isActive('strike') ? 'is-active' : ''}>
            <s>S</s>
          </button>
          <button onClick={() => editor.chain().focus().toggleCode().run()} className={editor.isActive('code') ? 'is-active' : ''}>
            <code>&lt;/&gt;</code>
          </button>
          <button onClick={() => {
            const url = window.prompt('URL');
            if (url) editor.chain().focus().setLink({ href: url }).run();
          }} className={editor.isActive('link') ? 'is-active' : ''}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>
          </button>
        </div>
      )}

      {/* TipTap Editor or Preview */}
      <div className={`ne-body ${previewMode ? 'ne-body--preview' : 'ne-body--edit'}`}>
        {previewMode ? (
          <div className="ne-body__stage ne-body__stage--preview ne-preview-scroll">
            <NotePreview markdown={note.body} title={note.title} coverImage={note.coverImage} tags={note.tags} embedded />
          </div>
        ) : (
          <div className="ne-body__stage ne-body__stage--edit">
            <EditorContent editor={editor} className="ne-tiptap sn-content" />
            {slashOpen && filteredSlash.length > 0 && (
              <div className="slash-menu-wrapper" style={{ top: slashPos.top, left: slashPos.left }}>
                <SlashCommandMenu items={filteredSlash} selectedIndex={slashIdx} onSelect={handleSlashSelect} />
              </div>
            )}
          </div>
        )}
      </div>

      {/* Hidden file input for image uploads */}
      <input ref={imgInputRef} id="note-img-upload" type="file" accept="image/*" hidden onChange={handleImgUpload} />

      {/* Status bar */}
      <div className="ne-status">
        <span>{wordCount.w} words</span>
        <span>{wordCount.c} chars</span>
        <span style={{ flex: 1 }} />
        <span>{new Date(note.updatedAt).toLocaleTimeString()}</span>
      </div>
    </div>
  );
});

export default NoteEditor;
