# Heap — Interview Thinking

> **How to communicate your heap reasoning in FAANG interviews. Speak the language of tradeoffs, streaming, and pattern recognition.**

---

## "When I See Top-K, I Think Heap"

**Opening line:** *"This is a Top-K problem. I'll use a min-heap of size K to maintain the K largest elements. When a new element is larger than the smallest in our heap, we evict the smallest and add the new one."*

**Why this works:**
- Shows immediate pattern recognition
- Explains the invariant (heap = our K candidates)
- States the eviction rule clearly

---

## Why Heap Beats Sorting for Streaming Data

**Interviewer asks:** *"Why not just sort the array?"*

**Your answer:**
- *"If the data is static, we could sort in O(n log n) and take the last K elements. But if elements arrive one by one — a stream — we can't sort because we don't have all data upfront. A heap lets us process each element in O(log K) and maintain the top K at any moment. Total O(n log K), and we only use O(K) space."*

**Key phrases:**
- "Streaming" / "online" → heap
- "Static" / "all data known" → sort or quickselect are alternatives

---

## Two-Heap Median — Explanation Strategy

**Opening:** *"For median of a stream, I'll use two heaps. A max-heap for the left (smaller) half and a min-heap for the right (larger) half. The median is at the boundary — either the top of the larger heap or the average of both tops."*

**Walk through add:**
1. *"I add each number to the max-heap first."*
2. *"Then I balance: move the max of the left to the min-heap so all left ≤ all right."*
3. *"I keep the left heap size ≥ right so the median is always at max-heap.top() when odd."*

**Invariant to state:** *"All elements in the left heap are ≤ all elements in the right heap. The sizes differ by at most 1."*

---

## Merge K Sorted — Explanation Strategy

**Opening:** *"I'll use a min-heap to merge K lists. I put the first element of each list into the heap. Each time I pop the smallest — that's our next output — and push the next element from that list. It's like a tournament: we always pick the current smallest among all list heads."*

**Complexity:** *"We do O(N) pops, each O(log K). Total O(N log K) time, O(K) space for the heap."*

---

## Follow-Up Questions (Be Ready)

| Follow-Up | Your Answer |
|-----------|-------------|
| "What if K is very large, close to N?" | "Heap becomes O(n log n), same as sort. Quickselect could be O(n) average. For K ≈ N, sorting might be simpler." |
| "What if we need the result sorted?" | "Heap gives unsorted top-K. We can extract all and sort in O(K log K), or use a different approach." |
| "Can we do better than O(n log K)?" | "For static data, quickselect gives O(n) average for Kth largest. For streaming, O(n log K) is optimal with comparison-based heap." |
| "What about space?" | "Min-heap of size K uses O(K) space. If K is small, that's great. If K = n/2, we use O(n)." |
| "How do you handle duplicates?" | "Heap naturally handles them. If we have [5,5,5] and K=2, we keep two 5s. No special logic needed." |
| "What if K > N?" | "Return all elements. Heap size caps at N. Edge case to mention." |

---

## Communicating Tradeoffs

**Heap vs Quickselect:**

| | Heap | Quickselect |
|---|------|-------------|
| **When** | Streaming, or simple implementation | Static, need Kth only |
| **Time** | O(n log K) | O(n) average, O(n²) worst |
| **Space** | O(K) | O(1) |
| **Say** | "Heap is more predictable, no worst-case blowup" | "Quickselect is faster for static data" |

---

## Red Flags to Avoid

- **Don't say:** "I'll sort and take the last K" (without considering streaming)
- **Don't say:** "Max-heap for K largest" (wrong — min-heap for K largest)
- **Don't say:** "We need a max-heap" in Python without explaining the negation trick
- **Don't forget:** Edge cases (K=1, K=N, K>N, empty input)

---

## Interview Script: Top-K

1. *"I recognize this as a Top-K largest problem."*
2. *"I'll use a min-heap of size K. The root is the smallest of our K candidates."*
3. *"For each element: if heap size < K, push. Else if element > root, pop root and push element."*
4. *"At the end, the heap contains the K largest. Time O(n log K), space O(K)."*
5. *"Edge cases: K=0 return empty; K ≥ n return all."*

---

## Interview Script: Two-Heap Median

1. *"I'll maintain two heaps: max-heap for the smaller half, min-heap for the larger half."*
2. *"On add: push to max-heap, then move max to min-heap to balance. If left becomes smaller than right, move one back."*
3. *"Median: if odd count, top of larger heap. If even, average of both tops."*
4. *"Invariant: all left ≤ all right; sizes differ by at most 1."*

---

## FINAL MEMORY COMPRESSION BLOCK

```
OPENING:           "Top-K → min-heap of size K; evict when better arrives"
STREAMING:         "Can't sort stream; heap processes one-by-one"
TWO-HEAP:          "Split into left (max) and right (min); median at boundary"
MERGE K:           "Min-heap of list heads; pop smallest, push next"
TRADEOFF:          Heap = O(n log K), predictable; Quickselect = O(n) avg, static
FOLLOW-UP:         K≈N, sorted output, duplicates, K>N
RED FLAG:          Max-heap for K largest (wrong — use min-heap)
INTERVIEW LINE:    "For Top-K on streaming data, a min-heap of size K gives us
                    O(n log K) time and O(K) space — we only keep the best K."
```
