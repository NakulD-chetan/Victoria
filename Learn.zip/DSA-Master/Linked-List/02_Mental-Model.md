# Linked List — Mental Model

> **Permanent Recall:** "Think in pointers, not indices." Reversal = three-pointer dance. Cycle = fast catches slow. Middle = fast reaches end when slow is midway. Merge = zipper. Always draw before coding.

---

## How FAANG Engineers Think About Linked Lists

1. **Draw it** — sketch nodes and arrows before writing code
2. **Identify the pattern** — reversal? cycle? merge? two-pointer?
3. **Use dummy head** — eliminates 90% of edge cases
4. **Think in pointer rewiring** — you're rearranging arrows, not moving data

---

## The Core Mental Models

### 1. Reversal: "The Three-Pointer Dance"

**Mental model:** You're a train conductor reversing track direction. At each node, you redirect the arrow backward.

```
Step by step:
  prev=null, curr=1, next=?

  1 → 2 → 3 → null
  ↑
  curr

  Step 1: next = curr.next     (save 2)
          curr.next = prev     (1 → null)
          prev = curr          (prev = 1)
          curr = next          (curr = 2)

  null ← 1    2 → 3 → null
         ↑    ↑
        prev  curr

  Step 2: next = curr.next     (save 3)
          curr.next = prev     (2 → 1)
          prev = curr          (prev = 2)
          curr = next          (curr = 3)

  null ← 1 ← 2    3 → null
              ↑    ↑
             prev  curr

  Step 3: next = curr.next     (save null)
          curr.next = prev     (3 → 2)
          prev = curr          (prev = 3)
          curr = next          (curr = null)

  null ← 1 ← 2 ← 3
                   ↑
                  prev = new head
```

**Key insight:** At every step, you only need three variables: `prev`, `curr`, `next`.

---

### 2. Fast & Slow: "The Tortoise and the Hare"

**Mental model:** Two runners on a track. Slow moves 1 step, fast moves 2 steps.

#### Finding Middle

```
1 → 2 → 3 → 4 → 5 → null
S                           (slow)
F                           (fast)

Step 1: S=2, F=3
Step 2: S=3, F=5
Step 3: F.next=null → STOP. S=3 is middle.

  1 → 2 → 3 → 4 → 5 → null
          ↑
         slow (middle)
```

#### Detecting Cycle

```
1 → 2 → 3 → 4 → 5
              ↑       │
              └───────┘

S=1, F=1
S=2, F=3
S=3, F=5
S=4, F=4 ← MEET! Cycle exists.

Why? Fast gains 1 step per iteration. If cycle exists, fast laps slow.
```

**Key insight:** If there's a cycle, fast will always catch slow (like a faster runner lapping on a circular track).

---

### 3. Merge: "The Zipper"

**Mental model:** You're zipping two sorted decks of cards into one.

```
List A: 1 → 3 → 5
List B: 2 → 4 → 6

Compare heads:
  1 < 2 → take 1 → result: 1
  3 > 2 → take 2 → result: 1 → 2
  3 < 4 → take 3 → result: 1 → 2 → 3
  5 > 4 → take 4 → result: 1 → 2 → 3 → 4
  5 < 6 → take 5 → result: 1 → 2 → 3 → 4 → 5
  B left → take 6 → result: 1 → 2 → 3 → 4 → 5 → 6
```

**Key insight:** Always compare current heads of both lists. Attach smaller one and advance that list's pointer.

---

### 4. Dummy Head: "The Safety Net"

**Mental model:** A bouncer at the door. Not part of the party, but makes sure everyone enters smoothly.

```
Problem: Remove all nodes with value 1

Without dummy:
  head → [1] → [1] → [2] → [3]
  Head IS the node to remove! Special case needed.

With dummy:
  dummy → [1] → [1] → [2] → [3]
  prev = dummy
  curr = dummy.next
  
  Just check curr.val and skip: prev.next = curr.next
  No special case for head!
  
  Return dummy.next
```

---

### 5. In-Place Reversal of Sublist: "Partial Rewiring"

**Mental model:** Reverse only a section of the train. Disconnect, reverse, reconnect.

```
Reverse from position 2 to 4:

  1 → 2 → 3 → 4 → 5
  
  Identify: before=1, sublist=[2,3,4], after=5
  Reverse sublist: 4 → 3 → 2
  Reconnect: 1 → 4 → 3 → 2 → 5
```

---

## Decision Triggers (Quick Recognition)

---

## ASCII: Two-Pointer Gap Technique

```
Remove Nth from End (n=2):

  dummy → 1 → 2 → 3 → 4 → 5 → null
  
  Move fast n+1 steps ahead:
  slow = dummy
  fast = dummy
  fast moves 3 steps: fast → 3
  
  Move both until fast = null:
  slow=1, fast=4
  slow=2, fast=5
  slow=3, fast=null → STOP
  
  slow.next = slow.next.next (skip node 4)
  Result: 1 → 2 → 3 → 5
```

---

## ASCII: Cycle Entry Point

```
Why "reset to head" works:

  Entry point at distance 'a' from head.
  Meeting point at distance 'b' from entry.
  Cycle length = c.

  Slow traveled: a + b
  Fast traveled: a + b + k*c (k laps)
  
  2(a+b) = a + b + k*c
  a + b = k*c
  a = k*c - b
  
  So if one pointer starts at head, another at meeting point,
  both move 1 step — they meet at entry after 'a' steps.
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
REVERSAL: prev=null, curr=head; curr.next=prev, advance all three
FAST/SLOW: Middle(fast=end→slow=mid), Cycle(meet→reset→entry)
MERGE: Dummy head, compare heads, attach smaller, advance
DUMMY: Fake head → eliminates head edge cases → return dummy.next
NTH FROM END: Two pointers, n apart, move together
PALINDROME: Middle → reverse half → compare
ALWAYS: Draw the picture before coding
```

