# Design Rate Limiter — Design Template

> **Permanent Recall:** Rate limiter as **middleware / API gateway**; rules from YAML/JSON; **Redis** for distributed counting (INCR+EXPIRE for fixed, sorted sets for sliding log, **Lua scripts** for atomicity). Response headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`, `Retry-After`.

---

## High-Level Architecture

```
                    ┌──────────────────────────────────────────────────┐
                    │                   Load Balancer                    │
                    └─────────────────────────┬────────────────────────┘
                                              │
              ┌───────────────────────────────┼───────────────────────────────┐
              │                               │                               │
              ▼                               ▼                               ▼
    ┌─────────────────────┐         ┌─────────────────────┐         ┌─────────────────────┐
    │  API Gateway /      │         │  API Gateway /      │         │  API Gateway /      │
    │  App Server 1       │         │  App Server 2       │         │  App Server N       │
    │  ┌───────────────┐  │         │  ┌───────────────┐  │         │  ┌───────────────┐  │
    │  │ Rate Limiter  │  │         │  │ Rate Limiter  │  │         │  │ Rate Limiter  │  │
    │  │ Middleware    │  │         │  │ Middleware    │  │         │  │ Middleware    │  │
    │  └───────┬───────┘  │         │  └───────┬───────┘  │         │  └───────┬───────┘  │
    └──────────┼──────────┘         └──────────┼──────────┘         └──────────┼──────────┘
               │                               │                               │
               └───────────────────────────────┼───────────────────────────────┘
                                               │
                               ┌───────────────┴───────────────┐
                               │                               │
                               ▼                               ▼
                    ┌──────────────────┐             ┌──────────────────┐
                    │  Redis Cluster   │             │  Rules Config     │
                    │  (counting)      │             │  (YAML/JSON)      │
                    └──────────────────┘             └──────────────────┘
```

---

## Rules Engine (Config)

Example YAML:

```yaml
rules:
  - endpoint: "/api/search"
    limit: 100
    window: 60          # seconds
    by: ["user_id", "ip"]
  - endpoint: "/api/upload"
    limit: 10
    window: 60
    by: ["user_id"]
  - endpoint: "/api/admin/*"
    limit: 5
    window: 60
    by: ["user_id"]
```

| Field | Purpose |
|-------|---------|
| `endpoint` | Path or pattern to match |
| `limit` | Max requests in `window` |
| `window` | Time window in seconds |
| `by` | Identity dimensions: user_id, ip, api_key |

---

## Response Headers

| Header | Meaning |
|--------|---------|
| `X-RateLimit-Limit` | Max requests allowed in window |
| `X-RateLimit-Remaining` | How many left in current window |
| `X-RateLimit-Reset` | Unix timestamp when window resets |
| `Retry-After` | (On 429) Seconds until retry, or HTTP-date |

Example 200 response:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1647012345
```

Example 429 response:

```
HTTP/1.1 429 Too Many Requests
Retry-After: 42
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1647012345
```

---

## Algorithm Implementations

### Fixed Window (Redis INCR + EXPIRE)

**Key:** `ratelimit:{identity}:{endpoint}:{window_id}`  
**window_id:** e.g., `floor(now / 60)` for 60s windows

```python
def fixed_window_allow(identity, endpoint, limit, window_sec):
    key = f"ratelimit:{identity}:{endpoint}:{int(time.time() // window_sec)}"
    count = redis.incr(key)
    if count == 1:
        redis.expire(key, window_sec * 2)  # avoid key buildup
    return count <= limit
```

**Race condition:** Two requests can INCR before either sets EXPIRE. Use **Lua script** for atomicity.

---

### Fixed Window — Redis Lua (Atomic)

```lua
-- KEYS[1]: rate limit key
-- ARGV[1]: window TTL (seconds)
-- ARGV[2]: limit
local count = redis.call('INCR', KEYS[1])
if count == 1 then
    redis.call('EXPIRE', KEYS[1], ARGV[1])
end
if count > tonumber(ARGV[2]) then
    return {0, count}  -- denied, current count
else
    return {1, count}   -- allowed, current count
end
```

---

### Sliding Window Log (Redis Sorted Set)

**Key:** `ratelimit:sw:{identity}:{endpoint}`  
**Score:** timestamp  
**Member:** unique request id (or timestamp)

```lua
-- KEYS[1]: sorted set key
-- ARGV[1]: window start (now - window_sec) in ms
-- ARGV[2]: window_sec
-- ARGV[3]: limit
redis.call('ZREMRANGEBYSCORE', KEYS[1], 0, ARGV[1])  -- remove old
local count = redis.call('ZCARD', KEYS[1])
if count >= tonumber(ARGV[3]) then
    return {0, count}
end
redis.call('ZADD', KEYS[1], ARGV[2], ARGV[2])  -- add current (score=member=now_ms)
redis.call('EXPIRE', KEYS[1], ARGV[4])  -- TTL = window + buffer
return {1, count + 1}
```

---

### Sliding Window Counter (Approximation)

```python
def sliding_window_counter_allow(identity, endpoint, limit, window_sec):
    key = f"ratelimit:swc:{identity}:{endpoint}"
    now = time.time()
    window_start = now - window_sec
    pipeline = redis.pipeline()
    pipeline.zadd(key, {str(now): now})
    pipeline.zremrangebyscore(key, 0, window_start)
    pipeline.zcard(key)
    pipeline.expire(key, window_sec + 60)
    results = pipeline.execute()
    count = results[2]
    return count <= limit
```

Or use the weighted formula: `count = prev_count * (1 - elapsed/period) + curr_count` with two keys (prev/curr windows).

---

### Token Bucket (Redis Hash + Lua)

**Key:** `ratelimit:tb:{identity}:{endpoint}`  
**Hash fields:** `tokens` (float), `last_refill` (timestamp)

```lua
-- KEYS[1]: token bucket key
-- ARGV[1]: capacity
-- ARGV[2]: refill rate (tokens per second)
-- ARGV[3]: now (timestamp)
local data = redis.call('HMGET', KEYS[1], 'tokens', 'last_refill')
local tokens = tonumber(data[1]) or tonumber(ARGV[1])
local last = tonumber(data[2]) or tonumber(ARGV[3])
local now = tonumber(ARGV[3])
local elapsed = now - last
tokens = math.min(tonumber(ARGV[1]), tokens + elapsed * tonumber(ARGV[2]))
if tokens >= 1 then
    tokens = tokens - 1
    redis.call('HMSET', KEYS[1], 'tokens', tokens, 'last_refill', now)
    redis.call('EXPIRE', KEYS[1], 3600)
    return {1, tokens}  -- allowed
else
    redis.call('HMSET', KEYS[1], 'tokens', tokens, 'last_refill', now)
    redis.call('EXPIRE', KEYS[1], 3600)
    return {0, 0}  -- denied
end
```

---

## Distributed Challenges

### Race Conditions

| Problem | Solution |
|---------|----------|
| INCR then EXPIRE — another request can INCR before EXPIRE | Lua script: single atomic INCR + conditional EXPIRE |
| Read-modify-write (get count, incr, check) | Do everything in one Lua script |
| Multiple nodes writing same key | Redis is single-threaded per shard; Lua is atomic |

### Synchronization Across Nodes

- **Redis** is the source of truth; all nodes read/write same keys
- **No local cache** for the counter itself (or use short TTL + accept slight inconsistency)
- **Connection pooling** to Redis; avoid per-request connection overhead

### Clock Skew

- Use **Redis TIME** or **server timestamp** consistently
- Avoid mixing client-provided timestamps for window boundaries

---

## Key Format

| Algorithm | Key pattern | Example |
|-----------|-------------|---------|
| Fixed window | `ratelimit:{id}:{ep}:{window_id}` | `ratelimit:u123:/search:27361234` |
| Sliding log | `ratelimit:sw:{id}:{ep}` | `ratelimit:sw:u123:/search` |
| Token bucket | `ratelimit:tb:{id}:{ep}` | `ratelimit:tb:u123:/search` |

---

## Fail Open / Fail Closed Implementation

```python
def check_rate_limit(identity, endpoint):
    try:
        return redis_check(identity, endpoint)
    except RedisError:
        if config.fail_closed:
            return False  # reject
        else:
            return True   # allow (fail open)
```

---

## Monitoring

| Metric | Purpose |
|--------|---------|
| Rate limit hits (429s) per identity/endpoint | Detect abuse, tune limits |
| Redis latency | Ensure &lt;5ms overhead |
| Redis failure rate | Trigger fail-open/closed, alerting |
