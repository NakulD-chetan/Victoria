# Quick Revision — Core Concepts Cheat Sheet

> **Permanent Recall:** This is the comprehensive one-page-per-topic cheat sheet. Dense, fast-to-scan. Use for last-minute cramming before system design interviews. Each topic: 3–5 critical bullets, key table, #1 interview tip.

---

## 1. System Design Fundamentals

| Pillar | Components | Example |
|--------|-------------|---------|
| **Moving Data** | APIs, queues, CDN, LB | How does a tweet reach followers? |
| **Storing Data** | DB, cache, object storage, search | Where do user profiles live? |
| **Transforming Data** | App servers, workers, compute | Feed rankings, transcoding |

**Critical facts:**
- Three pillars: Move | Store | Transform
- Building blocks: Client, LB, App, Cache, DB, CDN, Queue
- Evolution: Single server → Cache → Replicas → Sharding → Queues → Microservices
- Functional = *what*; Non-functional = *how well* (latency, availability, scale)
- **Interview tip:** Ask DAU, read:write, latency target, constraints BEFORE drawing anything.

---

## 2. Scalability

| Type | What | When |
|------|------|------|
| **Vertical (up)** | Add CPU/RAM to one machine | Quick fix, low traffic |
| **Horizontal (out)** | Add more machines | Production, high traffic |

| Workload | Strategy |
|----------|----------|
| Read-heavy | Replicas + cache |
| Write-heavy | Sharding + async |
| Stateless | Trivial horizontal scale |
| Stateful | Session to Redis; avoid sticky sessions |

**Critical facts:**
- Stateless > stateful for app tier
- Bottleneck = slowest component; scale that first
- 1 server ≈ 1K QPS; Redis ≈ 100K; DB read ≈ 5K QPS
- Auto-scale by CPU, RPS, queue depth
- **Interview tip:** "I'll start vertical, then horizontal when we hit limits."

---

## 3. Load Balancing

| Layer | Sees | Use Case |
|------|------|----------|
| **L4** | IP, port | TCP/UDP, raw throughput |
| **L7** | HTTP, path, headers | APIs, microservices, routing |

| Algorithm | When |
|------------|------|
| **Round robin** | Stateless API |
| **IP hash / sticky** | Session affinity needed |
| **Consistent hashing** | Cache, minimize reshuffle |
| **Least connections** | Varying request duration |

**Critical facts:**
- Software LB (Nginx, ALB) for cloud-native; hardware for ultra-low latency
- Health checks: active (probe) vs passive (infer from failures)
- Cookie-based sticky sessions > IP hash (NAT breaks IP)
- **Interview tip:** "Stateless? Round robin. Cache/memcached? Consistent hashing."

---

## 4. Caching & CDN

| Strategy | Flow | Use Case |
|----------|------|----------|
| **Cache-aside** | App checks cache; on miss → DB → populate | Read-heavy, stale OK |
| **Write-through** | Write to cache + DB sync | Consistency needed |
| **Write-behind** | Write to cache; async to DB | Write burst |

| Level | Latency | Example |
|-------|---------|---------|
| L1/L2 | ns | CPU cache |
| Redis | ~1 ms | Hot data |
| CDN | ~20–50 ms | Static, global |

**Critical facts:**
- "Cache is a lie"—invalidation is hard; design it early
- TTL + eviction (LRU, LFU); cache stampede = lock/early expiry
- CDN: edge POPs, origin, pre-warm, invalidation API
- **Interview tip:** "Cache-aside for reads. Mention TTL, invalidation, stampede mitigation."

---

## 5. Database Design

| Type | ACID | Scaling | Use Case |
|------|------|---------|----------|
| **SQL** | Full | Vertical, shard complex | Banking, ERP, joins |
| **NoSQL** | BASE | Horizontal | Feeds, sessions, scale |

| NoSQL Family | Example | Best For |
|--------------|---------|----------|
| Key-value | Redis | Sessions, counters |
| Document | MongoDB | Flexible schema |
| Wide-column | Cassandra | High write, scale |
| Graph | Neo4j | Relations, traversals |

**Critical facts:**
- ACID: Atomicity, Consistency, Isolation, Durability
- Index: B-Tree (range), Hash (equality)
- Normalization vs denormalization trade-off
- **Interview tip:** "SQL when ACID + joins. NoSQL when scale-out + flexible schema."

---

## 6. Database Scaling

| Strategy | When | Trade-off |
|----------|------|-----------|
| **Read replicas** | Read-heavy | Replication lag, eventual |
| **Sharding** | Write-heavy, storage limits | Cross-shard joins expensive |
| **Connection pooling** | Connection exhaustion | Reduces per-process connections |

| Sharding Key | Pros | Cons |
|--------------|------|------|
| **Hash** | Even distribution | Range queries hard |
| **Range** | Range queries easy | Hotspots |
| **Directory** | Flexible | Extra lookup |

**Critical facts:**
- Try replicas, cache, federation before sharding
- Consistent hashing minimizes rebalance on add/remove
- Sync replication = strong consistency, higher latency
- **Interview tip:** "Shard by user_id for even distribution. Consistent hashing for minimal rebalance."

---

## 7. CAP Theorem

| Property | Meaning |
|----------|---------|
| **C**onsistency | Every read sees latest write |
| **A**vailability | Every request gets response |
| **P**artition Tolerance | Works despite network split |

| During partition | Choice |
|------------------|--------|
| **CP** | Refuse/block; consistency first |
| **AP** | Serve; may be stale |

| CP Systems | AP Systems |
|------------|------------|
| HBase, ZooKeeper | Cassandra, DynamoDB |

**Critical facts:**
- You pick **C or A during partition**; P is mandatory
- PACELC: No partition → Latency vs Consistency
- **Interview tip:** "Partition tolerance is inevitable. During partition: CP = block, AP = serve stale."

---

## 8. Availability & Reliability

| Term | Meaning |
|------|----------|
| **Availability** | System is up |
| **Reliability** | Correct when up |
| **Durability** | Data survives |

| Nines | Downtime/Year |
|------|---------------|
| 99% | 3.65 days |
| 99.9% | 8.76 hours |
| 99.99% | 52.6 min |
| 99.999% | 5.26 min |

**Critical facts:**
- SLA = contract; SLO = target; SLI = measurement
- Redundancy: N+1, active-active; failover: cold/warm/hot
- RPO = how much data loss; RTO = how long to recover
- **Interview tip:** "Availability ≠ reliability. 99.9% = three nines = 8.76 hr/year downtime."

---

## 9. API Design

| Style | Use Case |
|-------|----------|
| **REST** | CRUD, public APIs |
| **GraphQL** | Flexible queries, mobile |
| **gRPC** | Internal, streaming |

| Code | Meaning |
|------|---------|
| 401 | Unauthenticated |
| 403 | Forbidden (no permission) |
| 429 | Rate limited |

**Critical facts:**
- REST: resource nouns, HTTP verbs; stateless
- GraphQL: over/under-fetching solved; schema + resolvers
- gRPC: Protobuf, HTTP/2, streaming; internal services
- **Interview tip:** "429 + Retry-After for rate limit. 401 vs 403: auth vs authz."

---

## 10. Message Queues

| Model | Routing | Use Case |
|-------|---------|----------|
| **Point-to-point** | Queue, one consumer/msg | Task distribution |
| **Pub/sub** | Topic, fan-out | Event broadcasting |

| System | Strength |
|--------|----------|
| **Kafka** | Throughput, replay, partitions |
| **RabbitMQ** | Flexible routing, exchanges |
| **SQS** | Managed, at-least-once |

**Critical facts:**
- Delivery: at-least-once (retry), at-most-once, exactly-once (idempotency)
- Dead letter queue (DLQ) for failed messages
- CQRS, Event Sourcing, Saga for distributed transactions
- **Interview tip:** "Kafka for replay + ordering. DLQ for failed messages. Idempotent consumers."

---

## 11. Microservices

| Aspect | Monolith | Microservices |
|--------|----------|---------------|
| Deploy | All or nothing | Per service |
| Scale | Whole app | Per service |
| DB | Shared | DB per service |
| Fault | One bug = all down | Isolated |

**Critical facts:**
- API Gateway: routing, auth, rate limit
- Service discovery: Consul, Eureka, K8s DNS
- Circuit breaker, Saga for distributed tx
- Start monolith; extract when scaling/team size demands
- **Interview tip:** "DB per service; eventual consistency. Sync for simple; async for decoupling."

---

## 12. Distributed Systems

| Challenge | Reality |
|-----------|---------|
| Network | Unreliable, partitions |
| Latency | Never zero |
| Clocks | Skew, no global time |

| Consensus | Used By |
|------------|---------|
| Paxos | Chubby |
| Raft | etcd, Consul |
| Zab | ZooKeeper |

**Critical facts:**
- Eight fallacies: don't assume reliable network, zero latency
- Vector clocks, Lamport clocks for ordering without global time
- Leader election, distributed locks, heartbeats
- **Interview tip:** "Design for failure. Never assume 'it worked once.'"

---

## 13. Resilience Patterns

| Pattern | Purpose |
|---------|---------|
| **Circuit breaker** | Fail fast when dependency unhealthy |
| **Retry** | Exponential backoff + jitter |
| **Bulkhead** | Isolate failures |
| **Idempotency** | Safe retries |
| **Graceful degradation** | Fallbacks, feature flags |

**Critical facts:**
- Circuit: Closed → Open (fail) → Half-Open (test) → Closed
- Idempotency key for payments, writes
- Rate limiting: token bucket, sliding window
- **Interview tip:** "Circuit breaker = fuse. Too many failures → trip. Don't hammer failing service."

---

## 14. Back-of-Envelope

| Formula | Use |
|---------|-----|
| QPS | DAU × actions / 86400 |
| Peak QPS | 2–3× average |
| Storage | items × bytes × replication |
| Bandwidth | QPS × response_bytes × 8 |

| Component | Capacity |
|-----------|----------|
| Web server | ~1K QPS |
| DB read | ~5K QPS |
| Redis | ~100K QPS |
| Kafka partition | ~10–100K msg/s |

**Critical facts:**
- 86400 ≈ 100K sec/day
- 1M sec ≈ 12 days; 1B sec ≈ 32 years
- Powers of 2: 2^10=1KB, 2^20=1MB, 2^30=1GB, 2^40=1TB
- **Interview tip:** "Rough numbers beat silence. DAU × 10 / 100K ≈ read QPS for social."

---

## 15. Security

| Term | Meaning |
|------|---------|
| **AuthN** | Who are you? |
| **AuthZ** | What can you do? |

| Mechanism | Use |
|------------|-----|
| **OAuth 2.0** | Delegated auth |
| **JWT** | Stateless tokens |
| **bcrypt** | Password hashing |

**Critical facts:**
- HTTPS in transit; encrypt at rest
- Rate limit, input validation, CORS
- 401 unauthenticated; 403 forbidden
- **Interview tip:** "Auth tokens, HTTPS, rate limiting, input validation. Bcrypt for passwords."

---

## 16. Monitoring

| Pillar | Tool | Use |
|--------|------|-----|
| **Logs** | ELK | Debugging |
| **Metrics** | Prometheus | Dashboards |
| **Traces** | Jaeger | Request flow |

| Signal | What |
|--------|------|
| Latency | p50, p95, p99 |
| Traffic | RPS |
| Errors | 5xx rate |
| Saturation | CPU, queue depth |

**Critical facts:**
- SLI → SLO → SLA
- RED: Rate, Errors, Duration
- Health: liveness (am I up?) vs readiness (can I take traffic?)
- **Interview tip:** "Monitor latency p99, error rate, cache hit ratio. Alerts on thresholds."

---

**Prev: — | Next: [[02_Mental-Model]]**
