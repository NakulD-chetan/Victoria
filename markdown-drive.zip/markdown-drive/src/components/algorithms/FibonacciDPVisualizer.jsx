import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import DPCanvasBase from './canvas-bases/DPCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

function generateSteps(n) {
  const steps = [];
  const colLabels = Array.from({ length: n + 1 }, (_, i) => i);
  const dp = Array(n + 1).fill(null);

  const snap = (caption, arr, colors, hl, arrows) => {
    steps.push({
      caption,
      table: [arr.map((v) => (v == null ? null : v))],
      rowLabels: ['dp'],
      colLabels,
      cellColors: colors,
      arrows: arrows || [],
      highlight: hl,
    });
  };

  snap('Initialize dp table (empty)', [...dp], {}, null, []);
  dp[0] = 0;
  dp[1] = 1;
  snap('Base cases dp[0]=0, dp[1]=1', [...dp], { '0-0': 'filled', '0-1': 'filled' }, [0, 1], []);

  for (let i = 2; i <= n; i += 1) {
    const colors = {};
    colors[`0-${i}`] = 'current';
    colors[`0-${i - 1}`] = 'filled';
    colors[`0-${i - 2}`] = 'filled';
    snap(`Compute dp[${i}] from dp[${i - 1}] + dp[${i - 2}]`, [...dp], colors, [0, i], [
      { from: [0, i - 1], to: [0, i] },
      { from: [0, i - 2], to: [0, i] },
    ]);
    dp[i] = dp[i - 1] + dp[i - 2];
    const after = { ...colors, [`0-${i}`]: 'optimal' };
    snap(`dp[${i}] = ${dp[i]}`, [...dp], after, [0, i], []);
  }

  snap('Fibonacci DP complete', [...dp], Object.fromEntries([...Array(n + 1)].map((_, i) => [`0-${i}`, 'optimal'])), null, []);
  return steps;
}

export default function FibonacciDPVisualizer({ config }) {
  const n = 10;

  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps(n);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0', type: 'info', message: `Fibonacci DP up to ${n}` });
    canvasRef.current?.setState({
      table: [[null]],
      rowLabels: ['dp'],
      colLabels: [0],
      cellColors: {},
      arrows: [],
      highlight: null,
      caption: '1D Fibonacci',
    });
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    if (step.codeStep != null) store.setStep(step.codeStep);
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.caption || 'step' });
    canvasRef.current?.setState({
      table: step.table || [[null]],
      rowLabels: step.rowLabels || [],
      colLabels: step.colLabels || [],
      cellColors: step.cellColors || {},
      arrows: step.arrows || [],
      highlight: step.highlight || null,
      caption: step.caption || '',
    });
  }, []);

  const statsBuilder = useCallback(({ stepIndex, steps }) => [
    { label: 'Step', value: `${stepIndex + 1}/${steps.length}`, color: 'var(--accent-secondary)' },
  ], []);

  const safeConfig = {
    ...config,
    code: config?.code || { python: [], java: [], cpp: [] },
    meta: { ...config?.meta, languages: config?.meta?.languages || ['python'] },
  };

  return (
    <AlgoVisualizer
      config={safeConfig}
      canvas={DPCanvasBase}
      onInit={onInit}
      onStep={onStep}
      statsBuilder={statsBuilder}
    />
  );
}
