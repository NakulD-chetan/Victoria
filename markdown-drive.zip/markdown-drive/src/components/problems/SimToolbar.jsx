import { usePlaygroundStore } from '../../stores/playground-store';

export default function SimToolbar() {
  const simulating = usePlaygroundStore((s) => s.simulating);
  const speed = usePlaygroundStore((s) => s.speed);
  const toggleSimulation = usePlaygroundStore((s) => s.toggleSimulation);
  const resetSimulation = usePlaygroundStore((s) => s.resetSimulation);
  const setSpeed = usePlaygroundStore((s) => s.setSpeed);

  return (
    <div className="dc-sim-toolbar">
      <button
        onClick={toggleSimulation}
        className={`dc-sim-toolbar__btn ${simulating ? 'dc-sim-toolbar__btn--pause' : 'dc-sim-toolbar__btn--play'}`}
        title={simulating ? 'Pause (Space)' : 'Play (Space)'}
      >
        {simulating ? (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>
        ) : (
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        )}
      </button>
      <button onClick={resetSimulation} className="dc-sim-toolbar__btn dc-sim-toolbar__btn--reset" title="Reset">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
          <polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/>
        </svg>
      </button>
      <div className="dc-sim-toolbar__divider" />
      <div className="dc-sim-toolbar__speed">
        <input type="range" min="0.5" max="5" step="0.25" value={speed} onChange={(e) => setSpeed(+e.target.value)} className="dc-sim-toolbar__slider" />
        <span className="dc-sim-toolbar__speed-val">{speed}x</span>
      </div>
    </div>
  );
}
