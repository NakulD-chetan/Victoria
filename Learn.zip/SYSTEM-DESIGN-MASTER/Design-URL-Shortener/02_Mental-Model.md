# Design URL Shortener — Mental Model

> **Permanent Recall:** Think of URL shortener as three sub-problems: (1) **key generation**—unique, short, collision-free; (2) **storage**—mapping short→long, fast lookup; (3) **redirect**—resolve and forward with minimal latency. The **hash vs counter** debate is the key differentiator: hash = stateless but collisions; counter = no collisions but requires coordination.

---

## How to Think About This Design

**Core challenge:** Generate a unique short key, store the mapping, and serve redirects at massive scale with sub-100ms latency.

```
    LONG URL  ──►  KEY GENERATION  ──►  SHORT KEY (e.g., xyz7Ab)
                                              │
                                              ▼
    REDIRECT  ◄──  LOOKUP (Cache/DB)  ◄──  STORE MAPPING
```

---

## Decomposing into Sub-Problems

| Sub-problem | Question | Solution space |
|-------------|----------|----------------|
| **Key generation** | How do we get unique 6–7 char codes? | Hash (MD5/SHA + base62), counter + base62, pre-generated pool (KGS) |
| **Storage** | Where do we store short→long? | SQL (lookup by short_url), NoSQL (key-value), both |
| **Redirect** | How to serve <100ms? | Cache popular URLs (Redis), DB for cold |
| **Analytics** | How to count clicks? | Async logging, separate analytics service |

---

## Components You Need

```
┌─────────────┐   ┌─────────────┐   ┌──────────────────┐
│ API Servers │   │ Key Gen Svc │   │ Cache (Redis)    │
│ (shorten +  │   │ (hash/cntr/ │   │ popular URLs     │
│  redirect)  │   │  KGS)       │   │                  │
└──────┬──────┘   └──────┬──────┘   └────────┬─────────┘
       │                 │                   │
       └─────────────────┼───────────────────┘
                         ▼
                  ┌─────────────┐
                  │  Database   │
                  │ short→long  │
                  └─────────────┘
```

- **API Servers:** Stateless; handle POST /shorten, GET /:shortUrl
- **Key Generation Service:** Produces unique short codes
- **Cache:** Redis for hot redirect lookups
- **Database:** Persistent mapping; source of truth

---

## Hash vs Counter Mental Model

| Approach | How | Pros | Cons |
|----------|-----|------|------|
| **Hash (MD5/SHA + base62)** | Hash(long_url) → truncate → base62 | Stateless, same URL = same key | Collisions possible; must handle retry |
| **Counter + base62** | Auto-increment ID → base62 encode | No collisions, deterministic | Needs distributed ID (Zookeeper, DB sequence, Snowflake) |
| **Pre-generated pool (KGS)** | Background service fills pool of keys; API grabs | No collision, no blocking, scalable | Extra service; pool management |

> **FAANG Tip:** KGS (Key Generation Service) is the cleanest at scale—decouples key creation from request path. Mention hash collision handling if you propose hashing.

---

## Redirect Flow Mental Model

```
User GET /xyz7Ab
    │
    ├─► Cache hit?  →  Return 301/302 (fast path)
    │
    └─► Cache miss  →  DB lookup  →  Cache warm  →  Return 301/302
```

**301 vs 302:**
- **301 Moved Permanently:** Browser caches; future requests may not hit server → less traffic, less analytics
- **302 Found:** Server gets every redirect → full analytics, can change destination later

---

## 30-SECOND REVISION BOX

```
THREE PARTS: Key gen, storage, redirect
KEY GEN: Hash (collisions), Counter (needs coordination), KGS (best at scale)
REDIRECT: Cache first, DB fallback; 301 (cache) vs 302 (track)
COMPONENTS: API, KGS/hash, Redis, DB
```

---

**Prev: [[01_Concept]] | Next: [[03_Design-Template]]**
