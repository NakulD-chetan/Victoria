import { useEffect, useRef, useState } from 'react';
import { useNewCanvasStore } from '../state/store';

/**
 * Dev HUD. Enabled by setting `localStorage.setItem('nc:hud', '1')`.
 *
 * Shows: active tool, scene count, viewport, FPS, last render ms, and the
 * live count of elements (both committed and draft). This is the fastest
 * way to confirm that a drawn stroke actually hit the store.
 */
export default function HUD({ getEngine }) {
  const enabled = useIsHudEnabled();
  const [fps, setFps] = useState(0);
  const frames = useRef(0);
  const lastFpsTs = useRef(performance.now());

  const activeId = useNewCanvasStore((s) => s.activeId);
  const scene = useNewCanvasStore((s) => s.scenes[s.activeId]);
  const tool = useNewCanvasStore((s) => s.tool);

  useEffect(() => {
    if (!enabled) return;
    let raf;
    const tick = () => {
      frames.current += 1;
      const now = performance.now();
      if (now - lastFpsTs.current >= 500) {
        setFps(Math.round((frames.current * 1000) / (now - lastFpsTs.current)));
        frames.current = 0;
        lastFpsTs.current = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [enabled]);

  if (!enabled) return null;

  const engine = getEngine?.();
  const stats = engine?.getStats?.() || {};
  const draft = engine?.getDraft?.();
  const count = (scene?.elements || []).filter((e) => !e.isDeleted).length;
  const vp = scene?.viewport;

  return (
    <div className="nc-hud">
      <div>tool=<b>{tool}</b> fps=<b>{fps}</b> paintMs=<b>{(stats.paintMs || 0).toFixed(1)}</b></div>
      <div>scene=<b>{activeId?.slice(-6)}</b> elements=<b>{count}</b> draft=<b>{draft ? draft.type : '—'}</b></div>
      <div>zoom=<b>{(vp?.zoom || 1).toFixed(2)}</b> pan=<b>({(vp?.panX || 0).toFixed(0)}, {(vp?.panY || 0).toFixed(0)})</b></div>
    </div>
  );
}

function useIsHudEnabled() {
  const [enabled, setEnabled] = useState(() => {
    try { return localStorage.getItem('nc:hud') === '1'; } catch { return false; }
  });
  useEffect(() => {
    const onStorage = () => {
      try { setEnabled(localStorage.getItem('nc:hud') === '1'); } catch { /* noop */ }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, []);
  return enabled;
}
