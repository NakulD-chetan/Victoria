# Narrow vs Wide Transformations

This is one of the most fundamental concepts in Spark. It determines **how data moves** across the cluster and directly impacts performance.

---

## Narrow Transformations (No Shuffle — Fast)

A **narrow transformation** is one where each input partition produces data for **only one** output partition. Data stays on the same machine — no network transfer needed.

### Examples
- `filter()`
- `map()`
- `withColumn()`
- `select()`
- `flatMap()`
- `sample()`
- `union()`

### Why Narrow is Fast
- No network data transfer
- Runs in a single stage
- Processes data in memory
- Catalyst can pipeline multiple narrow ops together

### Visual

```
Partition 0 ──filter──> Partition 0'   (same executor, no movement)
Partition 1 ──filter──> Partition 1'
Partition 2 ──filter──> Partition 2'
```

> **Note on `union()`**: The PDF mentioned `union()` is narrow "only if partitioner preserved." This is misleading. In practice, `union()` is **always a narrow transformation** in Spark DataFrames — it simply concatenates partitions from both DataFrames without any shuffle. No data movement occurs.

---

## Wide Transformations (Shuffle Required — Slow)

A **wide transformation** is one where data from one partition may need to move to **many different** partitions. This requires **shuffling** data across the cluster.

### Examples
- `groupBy()`
- `join()` (except broadcast join)
- `distinct()`
- `repartition()`
- `orderBy()` / `sortBy()`
- `reduceByKey()`
- `countByKey()`

### Why Wide is Slow
- **Network transfer** — data moves between machines
- **Disk spill** — data is written to local disk during sort
- **Partition exchange** — all executors talk to all other executors
- **New stage created** — breaks the pipeline

### Visual

```
Partition 0 ──┐
Partition 1 ──┼── SHUFFLE ──> New Partition 0 (keys: a, b)
Partition 2 ──┘              New Partition 1 (keys: c, d)
```

---

## Shuffle Partitions

When Spark performs a wide transformation, it creates **shuffle partitions**.

**Default**: `spark.sql.shuffle.partitions = 200`

This means after every `groupBy()`, `join()`, etc., Spark creates 200 output partitions by default.

**Tuning tip**: Reduce for small datasets, increase for large ones:
```python
spark.conf.set("spark.sql.shuffle.partitions", "50")   # small data
spark.conf.set("spark.sql.shuffle.partitions", "1000")  # large data
```

---

## Simple Example to Understand Shuffle

Imagine 3 input partitions:
```
Partition 1 → {a1, b1, c1}
Partition 2 → {a2, b2, c2}
Partition 3 → {a3, b3, c3}
```

After `groupBy("column")`, Spark must put all `a*` records together, all `b*` together:
```
BEFORE (3 partitions, mixed keys):
  P1: [a1, b1, c1]
  P2: [a2, b2, c2]
  P3: [a3, b3, c3]

SHUFFLE (data moves across network):
  P1 sends a1→P4, b1→P5, c1→P6
  P2 sends a2→P4, b2→P5, c2→P6
  P3 sends a3→P4, b3→P5, c3→P6

AFTER (3 partitions, grouped by key):
  P4: [a1, a2, a3]  ← all 'a' keys together
  P5: [b1, b2, b3]  ← all 'b' keys together
  P6: [c1, c2, c3]  ← all 'c' keys together
```

This redistribution = **shuffle** = expensive.

---

## Quick Comparison

| Feature            | Narrow                 | Wide                        |
|--------------------|------------------------|-----------------------------|
| Data movement      | None                   | Across cluster (shuffle)    |
| Speed              | Fast                   | Slow                        |
| Stage impact       | Same stage (pipelined) | Creates new stage           |
| Network I/O        | Zero                   | Heavy                       |
| Examples           | filter, map, select    | groupBy, join, distinct     |
| Disk usage         | Minimal                | Shuffle files written       |

---

## Key Takeaway

> **Narrow** = data stays on the same executor, runs in one stage, fast.
> **Wide** = data must be redistributed across the cluster (shuffle), creates a new stage, slow.
> Minimize wide transformations to improve Spark performance.
