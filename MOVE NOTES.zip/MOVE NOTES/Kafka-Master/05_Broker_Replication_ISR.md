# 5. Broker Replication, ISR & Internals

> **Permanent Recall Note:** **Brokers** host **partition replicas**; exactly one **leader** serves client requests per partition. **ISR** is the set of followers “caught up” for durability semantics. **Unclean leader election** trades **availability** for **data loss** — know the story cold. Disk layout (**segments**, **indexes**) explains why Kafka is fast: **sequential writes** + **bounded random read** via indexes.

### The 10-Second Summary
- **Controller** (KRaft or broker-elected in ZK mode) manages **leader election**.
- **HW (high watermark)** — consumers only see up to replicated offset; **LEO** — log end.
- **`min.insync.replicas`** interacts with **`acks=all`** — producer failures if ISR shrinks.
- **Compaction** — log cleaner thread rewrites segments for **keyed** retention.

---

# 5.1 Broker Internals — Big Picture

```
┌─────────────────────────────────────────────────────────────┐
│  BROKER JVM                                                   │
│  • Socket server (acceptor + processors)                      │
│  • Replica manager (local logs + fetchers)                    │
│  • Controller (maybe — one active cluster controller)         │
│  • Group coordinator, transaction coordinator (partitioned)   │
│  • Log cleaner (compaction)                                   │
└─────────────────────────────────────────────────────────────┘
```

---

# 5.2 Controller Broker

- Maintains **metadata** (with KRaft quorum) — partition leadership, ISR lists.
- On broker failure → **elect new leaders** from ISR **preferably**.

💡 **Key Insight:** **Controller failover** must be fast — KRaft improves this vs older ZK paths.

---

# 5.3 Partition Leader Election

```
ISR = {1,2,3}
Leader 1 dies → elect from ISR (e.g. 2) → clients metadata refresh
```

⚠️ **Warning:** If **ISR** empty or **unclean** allowed — different story (see 5.6).

---

# 5.4 ISR Mechanism

- Followers **fetch** from leader; lag tracked.
- Fall **out of ISR** if too far behind (`replica.lag.time.max.ms` conceptually).

📏 **Golden Rule:** **acks=all** only as strong as **ISR size** and **min.insync.replicas**.

---

# 5.5 Unclean Leader Election

| Setting | Effect |
|---------|--------|
| `unclean.leader.election.enable=false` (recommended) | No leader outside ISR — **availability** hit vs **loss** |
| `true` | **Truncate** to not-in-sync replica — **data loss** risk |

🎯 **Interview Tip:** Say **unclean=false** for money paths; explain **CAP**-style trade-off in plain words.

---

# 5.6 min.insync.replicas

```properties
min.insync.replicas=2   # topic or broker default
```

- With **acks=all**, if ISR < **min.insync** → producer **error** — **prefer** temporary fail over silent loss.

---

# 5.7 High Watermark vs Log End Offset

```
Leader LEO: 10
Follower caught to 8 → HW might be 8 (all ISR replicated up to 8)
```

- **Consumers** typically read up to **HW** for committed replication story (implementation details — concept for interviews).

🧠 **Memory Trick:** **HW** = “safe visible frontier”; **LEO** = “leader’s tip.”

---

# 5.8 Replication Protocol (Simplified)

```
Leader append → followers fetch → advance HW when ISR caught up
```

🔄 **Trade-off:** More replicas ⇒ durability + **fetch load** on leader.

---

# 5.9 Broker Failure Scenarios

| Scenario | Symptom | Mitigation |
|----------|---------|------------|
| Follower slow | ISR shrink, under-replicated | disk/network tuning |
| Leader dies | Election, brief unavailability | RF≥3, client retries |
| Controller issue | Metadata delays | KRaft health, monitoring |

---

# 5.10 Disk Layout — Segments, Index, Timeindex

```
/var/kafka-logs/topic-0/
  00000000000000000000.log
  00000000000000000000.index
  00000000000000000000.timeindex
  ... next base offset ...
```

- **`.index`** — offset → file position (sparse).
- **`.timeindex`** — timestamp → offset for **time-based** retention seeks.

🏗️ **Production:** **JBOD** vs RAID trade-offs; **fsync** policy — OS crash scenarios.

---

# 5.11 Log Compaction Internals

- **Cleaner** thread duplicates live records to new segments; drops older duplicates for same key.
- **Tombstone** + retention allows **delete** semantics for keyed topics.

⚠️ **Warning:** Compaction **not instantaneous** — **dirty ratio**, **cleaner** backlog metrics matter.

---

# 5.12 Quotas & Throttling

```properties
# broker configs — principle: protect brokers from noisy clients
quota.window.size.seconds=1
```

- **Producer/consumer** byte rate and **request** rate quotas per **principal** or **client id**.

🔥 **Pro Tip:** Multi-tenant clusters **must** quota — or one bad job starves others.

---

# 5.13 CLI — Describe topic / ISR

```bash
kafka-topics.sh --bootstrap-server localhost:9092 --describe --topic orders
```

Look for **Leader**, **Replicas**, **Isr**.

---

# 5.14 Interview Questions & Answers

**Q: Under-replicated partition kya hota hai?**  
**A:** Leader exists but **not all replicas** caught up / alive — **UnderReplicatedPartitions** > 0.

**Q: min.insync=3 aur RF=3 — problem?**  
**A:** **Single** broker failure can drop ISR below 3 ⇒ **writes fail** with acks=all — design **2** for min.insync often.

**Q: Spark shuffle fault tolerance vs Kafka replication?**  
**A:** Different layers — Kafka **durability** of log; Spark **recomputes** tasks from lineage — [../spark/03_RDD_Lineage_Persistence.md](../spark/03_RDD_Lineage_Persistence.md).

**Q: Why segment files?**  
**A:** **Efficient retention** (delete whole files), bounded memory for indexes.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 5 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Leader per partition; ISR = durability quorum           │
│  🧠 HW vs LEO — visibility vs tip                         │
│  🧠 unclean election = availability vs loss                 │
│  🧠 Segments + indexes = fast log access                    │
│  ⚠️  min.insync + acks=all together — design as pair         │
│  🎯 Metrics: URP, ISR shrinks, offline replicas            │
└─────────────────────────────────────────────────────────────┘
```
