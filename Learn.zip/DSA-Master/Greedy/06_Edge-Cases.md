# Greedy — Edge Cases

> **Permanent Recall:** Empty input, single element, all overlap, all disjoint, same start/end, large N. Test these before submitting. FAANG interviews often include edge cases in test 2–3.

---

## Interval Problems

### 1. No Intervals (Empty Input)

```python
intervals = []
# Expected: 0 (max count) or [] (merge)
# Don't assume len >= 1
```

### 2. Single Interval

```python
intervals = [[1, 3]]
# Max non-overlapping: 1
# Merge: [[1, 3]]
# Rooms needed: 1
```

### 3. All Intervals Overlap

```python
intervals = [[1, 4], [2, 5], [3, 6]]
# Max non-overlapping: 1 (pick any one)
# Merge: [[1, 6]]
# Rooms needed: 3
```

### 4. All Intervals Disjoint

```python
intervals = [[1, 2], [3, 4], [5, 6]]
# Max non-overlapping: 3
# Merge: [[1, 2], [3, 4], [5, 6]]
# Rooms needed: 1
```

### 5. Same Start and End

```python
intervals = [[1, 1], [1, 1], [1, 1]]
# Max non-overlapping: 1 (or 3 if [1,1] doesn't "overlap" itself — check problem)
# Merge: [[1, 1]]
# Tie-breaking matters!
```

### 6. Intervals With Same Start

```python
intervals = [[1, 5], [1, 3], [1, 4]]
# Sort by end: [1,3], [1,4], [1,5]
# Max: 3 (all disjoint in time? No — overlapping!)
# Actually max non-overlapping = 1 (all overlap)
```

### 7. Intervals With Same End

```python
intervals = [[1, 5], [2, 5], [3, 5]]
# All end at 5. Pick one. Secondary sort by start.
```

---

## Jump Game

### 1. Single Element

```python
nums = [0]   # At last index → True
nums = [1]   # At last index → True
```

### 2. All Zeros Except Last

```python
nums = [0, 0, 0, 1]  # Cannot reach — stuck at 0
# max_reach stays 0 until index 3, but we never get there
```

### 3. First Element Zero (Length > 1)

```python
nums = [0, 1, 2]  # Cannot move from index 0 → False
```

### 4. Large Jump at Start

```python
nums = [100, 0, 0, 0]  # Jump to end in one step → True
```

### 5. Exactly Reach Last

```python
nums = [2, 1, 1, 0]  # Reach index 3 exactly → True
```

---

## Gas Station

### 1. Single Station

```python
gas = [5], cost = [4]  # Net positive → start at 0
gas = [5], cost = [6]  # Impossible → -1
```

### 2. Impossible Trip (Total Gas < Total Cost)

```python
gas = [1, 2], cost = [2, 3]  # sum(gas)=3, sum(cost)=5 → -1
```

### 3. All Same

```python
gas = [1, 1, 1], cost = [1, 1, 1]  # Net 0 each, start anywhere (0)
```

### 4. Only One Valid Start

```python
gas = [1, 2, 3, 4, 5], cost = [3, 4, 5, 1, 2]
# Net: [-2,-2,-2,3,3]. Must start at 3.
```

---

## Fractional Knapsack

### 1. Zero Capacity

```python
capacity = 0  # Return 0
```

### 2. Zero Weight Item

```python
# Avoid division by zero! value/weight when weight=0
# Typically problem doesn't allow, but check
```

### 3. Capacity Larger Than Total Weight

```python
# Take all items, return total value
```

---

## Large Input Sizes

| Problem | Constraint | Consideration |
|---------|------------|---------------|
| Intervals | n = 10^5 | Sort O(n log n) fine |
| Jump | n = 10^4 | O(n) scan fine |
| Gas | n = 10^5 | O(n) fine |
| Fractional | n = 10^3 | Sort + scan fine |

### Overflow (C++)

```cpp
// long long for cumulative sums if values large
long long total = 0;
```

---

## Edge Case Checklist

| Category | Test Cases |
|----------|------------|
| **Empty** | [], nums=[], gas=[] |
| **Single** | [[1,2]], [1], gas=[1], cost=[1] |
| **All same** | [[1,1],[1,1]], [0,0,0] |
| **Boundary** | [0], [1], capacity=0 |
| **Impossible** | Jump: [0,0,1], Gas: sum(gas)<sum(cost) |

---

## ASCII: Interval Edge Cases

```
Empty:        (nothing)
Single:       |----|
All overlap:  |------|
              |------|
              |------|
All disjoint: |--|  |--|  |--|
Same end:     |--|
              |----|
              |------|  (all end at same point)
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
INTERVALS: [], single, all overlap, all disjoint, same start/end
JUMP: [0], [1], [0,0,1], first is 0 with n>1
GAS: single, sum(gas)<sum(cost), all same
KNAPSACK: capacity=0, weight=0 (div by zero)
LARGE: O(n log n) sort + O(n) scan — usually fine
```
