import { useCallback } from 'react';
import AlgoVisualizer from './AlgoVisualizer';
import GridCanvasBase from './canvas-bases/GridCanvasBase';
import { useVisualizerStore } from '../../stores/algo-visualizer-store';

const N = 8;
const SOLUTION_COL = [0, 4, 7, 5, 2, 6, 1, 3];

function cloneBoard(b) {
  return b.map((r) => [...r]);
}

function generateSteps() {
  const steps = [];
  const board = Array.from({ length: N }, () => Array(N).fill(0));
  const cols = Array(N).fill(false);
  const d1 = Array(2 * N).fill(false);
  const d2 = Array(2 * N).fill(false);

  function conflict(c, r) {
    return cols[c] || d1[r + c] || d2[r - c + N - 1];
  }

  function dfs(r) {
    if (r === N) {
      steps.push({ type: 'done', msg: 'Valid placement for all rows', board: cloneBoard(board), path: [] });
      return true;
    }
    const prefer = SOLUTION_COL[r];
    const order = [];
    for (let c = 0; c < N; c++) if (c !== prefer) order.push(c);
    order.push(prefer);
    for (const c of order) {
      steps.push({ type: 'try', r, c, board: cloneBoard(board), path: [[r, c]] });
      if (conflict(c, r)) {
        steps.push({ type: 'conflict', r, c, board: cloneBoard(board), path: [[r, c]] });
        continue;
      }
      board[r][c] = 1;
      cols[c] = true;
      d1[r + c] = true;
      d2[r - c + N - 1] = true;
      steps.push({ type: 'place', r, c, board: cloneBoard(board), path: [[r, c]] });
      if (dfs(r + 1)) return true;
      board[r][c] = 0;
      cols[c] = false;
      d1[r + c] = false;
      d2[r - c + N - 1] = false;
      steps.push({ type: 'back', r, c, board: cloneBoard(board), path: [[r, c]] });
    }
    return false;
  }

  steps.push({ type: 'start', msg: '8-Queens: try columns, backtrack on conflict', board: cloneBoard(board), path: [] });
  dfs(0);
  return steps;
}

function paint(step) {
  const cellColors = {};
  const cellValues = {};
  const grid = Array.from({ length: N }, () => Array(N).fill('empty'));
  const b = step.board || [];
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const key = `${r}-${c}`;
      if (b[r] && b[r][c]) {
        cellValues[key] = '♛';
        cellColors[key] = 'placed';
        grid[r][c] = 'placed';
      }
    }
  }
  if (step.type === 'try' || step.type === 'conflict') {
    const key = `${step.r}-${step.c}`;
    if (!b[step.r]?.[step.c]) {
      cellColors[key] = step.type === 'conflict' ? 'conflict' : 'exploring';
      if (!cellValues[key]) cellValues[key] = '·';
    }
  }
  return {
    size: N,
    cols: N,
    grid,
    cellColors,
    cellValues,
    path: step.path || [],
  };
}

export default function NQueensVisualizer({ config }) {
  const onInit = useCallback((canvasRef) => {
    const steps = generateSteps();
    useVisualizerStore.getState().setArray([]);
    useVisualizerStore.getState().setSteps(steps);
    useVisualizerStore.getState().addLog({ time: '0s', type: 'info', message: '8×8 N-Queens with backtracking' });
    canvasRef.current?.setState(paint(steps[0]));
  }, []);

  const onStep = useCallback((step, canvasRef) => {
    const store = useVisualizerStore.getState();
    store.setStep(step);
    if (step.type === 'try') store.incComparisons();
    store.addLog({ time: `${store.stepIndex + 1}`, type: 'info', message: step.msg || step.type });
    if (step.type === 'back') canvasRef.current?.addAnim('backtrack', { r: step.r, c: step.c }, 320);
    canvasRef.current?.setState(paint(step));
  }, []);

  return <AlgoVisualizer config={config} canvas={GridCanvasBase} onInit={onInit} onStep={onStep} />;
}
