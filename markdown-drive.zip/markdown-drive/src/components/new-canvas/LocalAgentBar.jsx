import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { useNewCanvasStore } from './state/store';
import {
  cancelCanvasAgentRun,
  resumeCanvasAgentRun,
  runCanvasAgentTurn,
} from './agent/canvas-intents';
import { getAccessToken } from '../../lib/supabase';
import { isCanvasV3Enabled } from './canvas-v3/feature-flags';
import { normalizeTeachingDocumentV3 } from './canvas-v3/document';

const UI_STATE_KEY = 'new-canvas:agentbar-ui:v2';
const FALLBACK_MODEL = import.meta.env.VITE_CANVAS_AGENT_MODEL || 'nex-agi/nex-n2-pro:free';

const DEFAULT_MODELS = [
  { id: 'teacher-agent', name: FALLBACK_MODEL, provider: 'OpenRouter teacher planner' },
];

function readUiState() {
  if (typeof localStorage === 'undefined') return null;
  try {
    return JSON.parse(localStorage.getItem(UI_STATE_KEY) || 'null');
  } catch {
    return null;
  }
}

function writeUiState(next) {
  if (typeof localStorage === 'undefined') return;
  try {
    localStorage.setItem(UI_STATE_KEY, JSON.stringify(next));
  } catch {
    // ignore localStorage failures
  }
}

function clearUiState() {
  if (typeof localStorage === 'undefined') return;
  localStorage.removeItem(UI_STATE_KEY);
}

function makeTimelineLabel(event) {
  if (event.type === 'run_created') return 'Run created';
  if (event.type === 'plan_started') return 'Plan created';
  if (event.type === 'plan_step') return event.step?.title || 'Plan step';
  if (event.type === 'tool_call') return `Calling ${event.toolCall?.name}`;
  if (event.type === 'tool_result') return `Applied ${event.toolCall?.name}`;
  if (event.type === 'warning') return event.message || 'Validator warning';
  if (event.type === 'error') return event.message || 'Agent error';
  if (event.type === 'cancelled') return 'Run cancelled';
  if (event.type === 'done') return 'Canvas updated';
  if (event.type === 'status') return event.label || event.status || 'Working';
  if (event.type === 'memory.append_episode') return 'Saved to agent memory';
  if (event.type === 'storyboard_ready') return 'Teaching storyboard ready';
  if (event.type === 'slide_created') return 'Lesson slide created';
  if (event.type === 'validation_result') return 'Visual layout validated';
  if (event.type === 'repair_started') return 'Repairing visual layout';
  if (event.type === 'run_completed') return 'Teaching sequence ready';
  return event.eventName || event.type || 'Agent event';
}

function timestampLabel(ts) {
  try {
    return new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}

function pickRecorderMimeType() {
  if (typeof MediaRecorder === 'undefined') return '';
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/mp4',
    'audio/ogg;codecs=opus',
  ];
  return candidates.find((type) => MediaRecorder.isTypeSupported?.(type)) || '';
}

function buildVoicePromptGlossary() {
  return 'Technical glossary: Trie, Fenwick Tree, Segment Tree, Dijkstra, Bellman Ford, Kafka, Redis, CAP theorem, idempotency, sharding.';
}

function statusToFeedback(status, transcriptPreview) {
  if (status === 'listening') return 'Listening...';
  if (status === 'transcribing') return 'Transcribing voice...';
  if (status === 'planning') return 'Planning the canvas...';
  if (status === 'executing') return 'Building the workspace...';
  if (status === 'validating') return 'Validating and repairing...';
  if (status === 'resuming') return 'Resuming agent run...';
  if (status === 'done') return transcriptPreview || 'Canvas updated';
  if (status === 'cancelled') return 'Stopped';
  if (status === 'error') return transcriptPreview || 'Run failed';
  return '';
}

function LocalAgentBarImpl() {
  const activeId = useNewCanvasStore((s) => s.activeId);
  const scenes = useNewCanvasStore((s) => s.scenes);
  const selection = useNewCanvasStore((s) => s.selection);
  const setPinnedTarget = useNewCanvasStore((s) => s.setPinnedTarget);
  const clearPinnedTarget = useNewCanvasStore((s) => s.clearPinnedTarget);
  const setV3Playback = useNewCanvasStore((s) => s.setV3Playback);
  const [input, setInput] = useState('');
  const [models, setModels] = useState(DEFAULT_MODELS);
  const [currentModelId, setCurrentModelId] = useState(DEFAULT_MODELS[0].id);
  const [isModelMenuOpen, setIsModelMenuOpen] = useState(false);
  const [status, setStatus] = useState('idle');
  const [feedback, setFeedback] = useState('');
  const [timeline, setTimeline] = useState([]);
  const [messages, setMessages] = useState([]);
  const [planSteps, setPlanSteps] = useState([]);
  const [activeRunId, setActiveRunId] = useState(null);
  const [eventCount, setEventCount] = useState(0);
  const [voiceMeta, setVoiceMeta] = useState({ available: false, notes: [] });
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcriptPreview, setTranscriptPreview] = useState('');
  const textareaRef = useRef(null);
  const historyRef = useRef(null);
  const dropdownRef = useRef(null);
  const rootRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const mediaStreamRef = useRef(null);
  const audioChunksRef = useRef([]);
  const resumeRunRef = useRef(null);

  const currentModel = useMemo(
    () => models.find((model) => model.id === currentModelId) || models[0] || DEFAULT_MODELS[0],
    [currentModelId, models],
  );
  const activeScene = scenes[activeId] || null;
  const useV3 = isCanvasV3Enabled();
  const v3Document = normalizeTeachingDocumentV3(activeScene?.v3Document);
  const lessonDeck = useV3
    ? {
        pages: v3Document.lessonDeck.frames,
        currentPageId: v3Document.lessonDeck.currentFrameId,
      }
    : (activeScene?.lessonDeck || { pages: [], currentPageId: null });
  const currentPage = lessonDeck.pages.find((page) => page.id === lessonDeck.currentPageId)
    || lessonDeck.pages.at(-1)
    || null;
  const pinnedTarget = activeScene?.pinnedTarget || null;
  const selectedWidget = useMemo(() => {
    if (!activeScene) return null;
    const selectedIds = useV3 ? (activeScene.v3Selection || []) : [...selection];
    if (selectedIds.length !== 1) return null;
    const id = selectedIds[0];
    if (useV3) {
      const portal = v3Document.portals.find((candidate) => candidate.id === id);
      if (portal) {
        return {
          elementId: portal.id,
          widgetType: portal.type,
          title: portal.title || portal.type,
          role: portal.semanticId || 'code-editor',
          lessonPageId: portal.frameId || null,
        };
      }
      const element = v3Document.elements.find((candidate) => candidate.id === id && !candidate.isDeleted);
      if (!element) return null;
      const semanticNode = v3Document.semanticGraph.nodes.find((node) => node.elementIds?.includes(id));
      return {
        elementId: element.id,
        widgetType: element.type,
        title: semanticNode?.id || element.customData?.semanticRole || element.type,
        role: semanticNode?.role || element.customData?.semanticRole || 'general',
        lessonPageId: element.customData?.lessonFrameId || null,
      };
    }
    const element = activeScene.elements.find((candidate) => candidate.id === id && candidate.type === 'widget' && !candidate.isDeleted);
    if (!element) return null;
    return {
      elementId: element.id,
      widgetType: element.widgetType,
      title: element.widgetData?.title || element.widgetType,
      role: element.widgetData?.agentMeta?.semanticRole || 'general',
      lessonPageId: element.customData?.lessonPageId || null,
    };
  }, [activeScene, selection, useV3, v3Document]);

  const isBusy = ['planning', 'executing', 'validating', 'resuming', 'listening', 'transcribing', 'cancelling'].includes(status);
  const hasHistory = messages.length > 0 || planSteps.length > 0 || timeline.length > 0 || transcriptPreview;

  const resetUiState = () => {
    setMessages([]);
    setTimeline([]);
    setPlanSteps([]);
    setActiveRunId(null);
    setEventCount(0);
    setStatus('idle');
    setFeedback('');
    setTranscriptPreview('');
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const token = await getAccessToken();
        if (!token) return;
        const response = await fetch('/api/canvas-agent/meta', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!response.ok) throw new Error('Failed to load agent metadata');
        const meta = await response.json();
        if (cancelled) return;
        const loadedModels = [
          {
            id: 'teacher-agent',
            name: meta.model || FALLBACK_MODEL,
            provider: `${meta.provider || 'OpenRouter'} • ${meta.pipeline || 'teacher pipeline'}`,
          },
        ];
        setModels(loadedModels);
        setCurrentModelId(loadedModels[0].id);
        setVoiceMeta(meta.voice || { available: false, notes: [] });
      } catch {
        // keep fallback labels
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isModelMenuOpen) return undefined;
    const onDoc = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsModelMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [isModelMenuOpen]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    textarea.style.height = 'auto';
    textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
  }, [input]);

  useEffect(() => {
    const history = historyRef.current;
    if (!history) return;
    history.scrollTop = history.scrollHeight;
  }, [messages, timeline, planSteps, transcriptPreview]);

  useEffect(() => {
    return () => {
      mediaRecorderRef.current?.stop?.();
      mediaStreamRef.current?.getTracks?.().forEach((track) => track.stop());
    };
  }, []);

  useEffect(() => {
    if (!activeId) return;
    const saved = readUiState();
    if (!saved || saved.sceneId !== activeId) {
      resetUiState();
      return;
    }

    setMessages(saved.messages || []);
    setTimeline(saved.timeline || []);
    setPlanSteps(saved.planSteps || []);
    setActiveRunId(saved.runId || null);
    setEventCount(saved.eventCount || 0);
    setStatus(saved.status || 'idle');
    setFeedback(saved.feedback || '');
    setTranscriptPreview(saved.transcriptPreview || '');

    if (saved.runId && ['planning', 'executing', 'validating', 'resuming', 'cancelling'].includes(saved.status)) {
      const stageElement = rootRef.current?.closest('.nc-stage-wrap')?.querySelector('.nc-stage');
      setStatus('resuming');
      setFeedback('Resuming agent run...');
      resumeRunRef.current = saved.runId;
      resumeCanvasAgentRun(saved.runId, {
        store: useNewCanvasStore,
        stageElement,
        since: saved.eventCount || 0,
        onEvent: async (event, aggregate) => {
          handleRunEvent(event, aggregate);
        },
      }).then((result) => {
        if (result.ok) {
          setStatus('done');
          setFeedback(result.text || 'Canvas updated');
        } else {
          setStatus(result.text ? 'error' : 'cancelled');
          setFeedback(result.text || 'Run ended');
        }
      }).catch((err) => {
        setStatus('error');
        setFeedback(`Error: ${err.message}`);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeId]);

  useEffect(() => {
    if (!activeId) return;
    writeUiState({
      sceneId: activeId,
      runId: activeRunId,
      eventCount,
      status,
      feedback,
      transcriptPreview,
      messages,
      timeline: timeline.slice(-40),
      planSteps,
    });
  }, [activeId, activeRunId, eventCount, status, feedback, transcriptPreview, messages, timeline, planSteps]);

  const pushTimeline = (event, labelOverride) => {
    setTimeline((current) => current.concat([{
      id: event.id || `${Date.now()}-${current.length}`,
      label: labelOverride || makeTimelineLabel(event),
      type: event.type || event.eventName || 'message',
      at: event.createdAt || Date.now(),
    }]).slice(-50));
  };

  const handleRunEvent = (event, aggregate) => {
    setEventCount((count) => Math.max(count, aggregate?.eventCount || count + 1));

    if (event.type === 'plan_started') {
      setPlanSteps((event.plan?.steps || []).map((step, index) => ({
        id: step.id || `step-${index}`,
        label: step.title || step.expected_output || `Step ${index + 1}`,
        state: index === 0 ? 'active' : 'todo',
      })));
      setStatus('planning');
      setFeedback(statusToFeedback('planning'));
      pushTimeline(event, 'Plan ready');
      return;
    }

    if (event.type === 'status') {
      setStatus(event.status || 'executing');
      setFeedback(event.label || statusToFeedback(event.status));
      pushTimeline(event);
      return;
    }

    if (event.type === 'agent_text_delta') {
      setFeedback(statusToFeedback(status, event.content || 'Working...'));
      return;
    }

    if (event.type === 'tool_call') {
      setStatus('executing');
      setPlanSteps((current) => current.map((step, index) => {
        if (index < event.index) return { ...step, state: 'done' };
        if (index === event.index) return { ...step, state: 'active' };
        return step;
      }));
      pushTimeline(event);
      return;
    }

    if (event.type === 'tool_result') {
      pushTimeline(event);
      return;
    }

    if (event.type === 'warning') {
      setFeedback(event.message || 'Validator warning');
      pushTimeline(event);
      return;
    }

    if (event.type === 'memory.append_episode') {
      pushTimeline(event);
      return;
    }

    if ([
      'storyboard_ready',
      'slide_created',
      'beat_started',
      'element_revealed',
      'stroke_progress',
      'binding_created',
      'highlight_started',
      'typing_delta',
      'camera_transition',
      'validation_result',
      'repair_started',
      'run_completed',
    ].includes(event.type)) {
      pushTimeline(event);
      return;
    }

    if (event.type === 'done') {
      setStatus('done');
      setActiveRunId(aggregate?.runId || activeRunId);
      setFeedback(event.text || 'Canvas updated');
      setPlanSteps((current) => current.map((step) => ({ ...step, state: 'done' })));
      setMessages((current) => current.concat([{ id: event.id || 'assistant', role: 'assistant', text: event.text || 'Canvas updated' }]).slice(-8));
      pushTimeline(event);
      return;
    }

    if (event.type === 'cancelled') {
      setStatus('cancelled');
      setPlanSteps((current) => current.map((step) => ({ ...step, state: 'done' })));
      setFeedback('Stopped');
      pushTimeline(event);
      return;
    }

    if (event.type === 'error') {
      setStatus('error');
      setFeedback(`Error: ${event.message}`);
      pushTimeline(event);
    }
  };

  const submit = async () => {
    const trimmed = input.trim();
    if (!trimmed || isBusy) return;

    const stageElement = rootRef.current?.closest('.nc-stage-wrap')?.querySelector('.nc-stage');
    setInput('');
    setIsModelMenuOpen(false);
    setStatus('planning');
    setFeedback('Planning the canvas...');
    setTranscriptPreview('');
    setMessages((current) => current.concat([{ id: `msg-${Date.now()}`, role: 'user', text: trimmed }]).slice(-8));
    setTimeline([]);
    setPlanSteps([]);
    setEventCount(0);

    try {
      const result = await runCanvasAgentTurn([{ role: 'user', text: trimmed }], {
        store: useNewCanvasStore,
        stageElement,
        onEvent: async (event, aggregate) => {
          if (aggregate?.runId && aggregate.runId !== activeRunId) {
            setActiveRunId(aggregate.runId);
          }
          handleRunEvent(event, aggregate);
        },
      });

      setActiveRunId(result.runId);
      setEventCount(result.eventCount || 0);
      if (result.ok) {
        setStatus('done');
        setFeedback(result.text || 'Canvas updated');
      } else {
        setStatus(result.text ? 'error' : 'cancelled');
        setFeedback(result.text || 'Run ended');
      }
    } catch (err) {
      setStatus('error');
      setFeedback(`Error: ${err.message}`);
      setMessages((current) => current.concat([{ id: `err-${Date.now()}`, role: 'assistant', text: `Error: ${err.message}` }]).slice(-8));
    }
  };

  const stop = async () => {
    if (!activeRunId) return;
    setStatus('cancelling');
    setFeedback('Cancelling run...');
    try {
      await cancelCanvasAgentRun(activeRunId);
    } catch (err) {
      setStatus('error');
      setFeedback(`Error: ${err.message}`);
    }
  };

  const toggleRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop?.();
      return;
    }

    if (!voiceMeta?.available) {
      setFeedback(voiceMeta?.notes?.[0] || 'Local Whisper is not configured yet.');
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setFeedback('Voice recording is not supported in this browser.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      const mimeType = pickRecorderMimeType();
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      audioChunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data?.size) {
          audioChunksRef.current.push(event.data);
        }
      };
      recorder.onstop = async () => {
        setIsRecording(false);
        setStatus('transcribing');
        setIsTranscribing(true);
        setFeedback('Transcribing voice...');
        try {
          const type = recorder.mimeType || 'audio/webm';
          const extension = type.includes('mp4') ? 'm4a' : type.includes('ogg') ? 'ogg' : 'webm';
          const blob = new Blob(audioChunksRef.current, { type });
          const form = new FormData();
          form.append('audio', blob, `voice-input.${extension}`);
          form.append('prompt', buildVoicePromptGlossary());
          const token = await getAccessToken();
          if (!token) throw new Error('Sign in to use LocalAgent voice.');
          const response = await fetch('/api/canvas-agent/voice/transcriptions', {
            method: 'POST',
            headers: {
              Authorization: `Bearer ${token}`,
            },
            body: form,
          });
          const json = await response.json().catch(() => ({}));
          if (!response.ok) throw new Error(json.error || 'Voice transcription failed');
          setInput((current) => (current ? `${current} ${json.text || ''}`.trim() : (json.text || '')));
          setTranscriptPreview(json.text || '');
          setStatus('idle');
          setFeedback(json.text || 'Voice ready');
        } catch (err) {
          setStatus('error');
          setFeedback(`Error: ${err.message}`);
        } finally {
          setIsTranscribing(false);
          mediaStreamRef.current?.getTracks?.().forEach((track) => track.stop());
          mediaStreamRef.current = null;
          mediaRecorderRef.current = null;
          audioChunksRef.current = [];
        }
      };
      mediaRecorderRef.current = recorder;
      recorder.start();
      setIsRecording(true);
      setStatus('listening');
      setFeedback('Listening...');
    } catch (err) {
      setStatus('error');
      setFeedback(`Error: ${err.message}`);
    }
  };

  const voiceButtonLabel = isRecording ? 'Stop recording' : voiceMeta?.available ? 'Record voice' : 'Voice unavailable';
  const pinSelectedWidget = () => {
    if (!selectedWidget) return;
    setPinnedTarget(selectedWidget);
    setFeedback(`Pinned ${selectedWidget.title} for the next update.`);
  };

  const renderStepClass = (stateValue) => {
    if (stateValue === 'done') return 'nc-agentbar__step nc-agentbar__step--done';
    if (stateValue === 'active') return 'nc-agentbar__step nc-agentbar__step--active';
    return 'nc-agentbar__step';
  };

  const playback = useV3 ? v3Document.playback : null;
  const togglePlayback = () => {
    if (!playback) return;
    if (playback.status === 'playing') {
      setV3Playback({ status: 'paused' });
    } else if (playback.status === 'done') {
      setV3Playback({ status: 'playing', currentBeat: -1 });
    } else {
      setV3Playback({ status: 'playing' });
    }
  };
  const skipPlayback = () => {
    if (!playback) return;
    setV3Playback({
      status: 'done',
      currentBeat: Math.max(0, playback.totalBeats - 1),
    });
  };

  return (
    <div ref={rootRef} className="nc-agentbar" aria-label="LocalAgent AI bar">
      {feedback ? (
        <div className={`nc-agentbar__feedback${status === 'planning' || status === 'executing' || status === 'validating' || status === 'resuming' || isRecording || isTranscribing ? ' is-working' : ''}`} role="status">
          <span className="nc-agentbar__feedback-dot" aria-hidden />
          {feedback}
        </div>
      ) : null}

      {hasHistory ? (
        <div ref={historyRef} className="nc-agentbar__history">
          {messages.map((message) => (
            <div key={message.id} className={`nc-agentbar__message${message.role === 'user' ? ' nc-agentbar__message--user' : ''}`}>
              <div className="nc-agentbar__message-head">{message.role === 'user' ? 'You' : 'Teacher Agent'}</div>
              <div className="nc-agentbar__message-body">{message.text}</div>
            </div>
          ))}

          {transcriptPreview ? (
            <div className="nc-agentbar__message">
              <div className="nc-agentbar__message-head">Voice Transcript</div>
              <div className="nc-agentbar__message-body">{transcriptPreview}</div>
            </div>
          ) : null}

          {planSteps.length ? (
            <div className="nc-agentbar__message">
              <div className="nc-agentbar__message-head">Plan</div>
              <div className="nc-agentbar__steps">
                {planSteps.map((step) => (
                  <span key={step.id} className={renderStepClass(step.state)}>{step.label}</span>
                ))}
              </div>
            </div>
          ) : null}

          {timeline.length ? (
            <div className="nc-agentbar__message">
              <div className="nc-agentbar__message-head">Timeline</div>
              <div className="nc-agentbar__timeline">
                {timeline.map((item) => (
                  <div key={item.id} className={`nc-agentbar__timeline-item nc-agentbar__timeline-item--${item.type}`}>
                    <span className="nc-agentbar__timeline-time">{timestampLabel(item.at)}</span>
                    <span className="nc-agentbar__timeline-label">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      ) : null}

      <div className="nc-agentbar__shell">
        {(currentPage || pinnedTarget || selectedWidget) ? (
          <div className="nc-agentbar__context">
            {currentPage ? (
              <span className="nc-agentbar__chip">
                {`Slide ${currentPage.order + 1}: ${currentPage.title}`}
              </span>
            ) : null}
            {playback?.storyboardId ? (
              <>
                <button
                  type="button"
                  className="nc-agentbar__chip nc-agentbar__chip--action"
                  onClick={togglePlayback}
                >
                  {playback.status === 'playing'
                    ? 'Pause'
                    : playback.status === 'done'
                      ? 'Replay'
                      : 'Play'}
                </button>
                {playback.status !== 'done' ? (
                  <button
                    type="button"
                    className="nc-agentbar__chip nc-agentbar__chip--action"
                    onClick={skipPlayback}
                  >
                    Skip
                  </button>
                ) : null}
                <span className="nc-agentbar__chip">
                  {`${Math.min(playback.totalBeats, playback.currentBeat + 1)}/${playback.totalBeats} steps`}
                </span>
              </>
            ) : null}
            {pinnedTarget ? (
              <span className="nc-agentbar__chip nc-agentbar__chip--accent">
                {`Pinned: ${pinnedTarget.title || pinnedTarget.widgetType}`}
                <button type="button" className="nc-agentbar__chip-btn" onClick={clearPinnedTarget} aria-label="Clear pinned target">×</button>
              </span>
            ) : selectedWidget ? (
              <button type="button" className="nc-agentbar__chip nc-agentbar__chip--action" onClick={pinSelectedWidget}>
                {`Pin ${selectedWidget.title}`}
              </button>
            ) : null}
          </div>
        ) : null}
        <div className="chat-input-container">
          <div className="chat-input-wrapper">
            <div className={`chat-input-box ${isBusy ? 'processing' : ''}`}>
              <div
                className={`model-selector ${isModelMenuOpen ? 'active' : ''}`}
                onClick={() => {
                  if (models.length > 1) setIsModelMenuOpen((value) => !value);
                }}
                ref={dropdownRef}
                title={models.length > 1 ? 'Select LocalAgent model' : currentModel.provider}
              >
                <svg className="model-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <circle cx="12" cy="12" r="10" />
                  <path d="M12 6v6l4 2" />
                  <path d="M16.24 7.76l-4.24 4.24" strokeLinecap="round" />
                </svg>
                <span className="model-name">{currentModel.name}</span>
                <svg className={`dropdown-arrow ${isModelMenuOpen ? 'open' : ''}`} width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <polyline points="6 9 12 15 18 9" />
                </svg>

                {isModelMenuOpen && models.length > 1 && (
                  <div className="model-dropdown">
                    <div className="model-dropdown-header">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                        <circle cx="12" cy="12" r="10" />
                        <path d="M12 6v6l4 2" />
                      </svg>
                      Select Model ({models.length})
                    </div>
                    {models.map((model) => (
                      <div
                        key={model.id}
                        className={`model-dropdown-item ${model.id === currentModelId ? 'selected' : ''}`}
                        onClick={(event) => {
                          event.stopPropagation();
                          setCurrentModelId(model.id);
                          setIsModelMenuOpen(false);
                        }}
                      >
                        <div className="model-item-content">
                          <span className="model-item-name">{model.name}</span>
                          <span className="model-item-provider">{model.provider}</span>
                        </div>
                        {model.id === currentModelId ? (
                          <svg className="check-icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                            <polyline points="20 6 9 17 4 12" />
                          </svg>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <textarea
                ref={textareaRef}
                className="chat-input"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                placeholder="Ask the teacher to explain, practice, draw, or build a workspace..."
                rows={1}
                disabled={isBusy && !isRecording}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' && !event.shiftKey) {
                    event.preventDefault();
                    submit();
                  }
                }}
              />

              <button
                type="button"
                className={`nc-agentbar__voice-btn${isRecording ? ' is-recording' : ''}`}
                onClick={toggleRecording}
                disabled={isTranscribing}
                title={voiceButtonLabel}
                aria-label={voiceButtonLabel}
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M12 2a3 3 0 0 1 3 3v6a3 3 0 1 1-6 0V5a3 3 0 0 1 3-3z" />
                  <path d="M19 10v1a7 7 0 0 1-14 0v-1" />
                  <line x1="12" y1="19" x2="12" y2="22" />
                </svg>
              </button>

              <button
                type="button"
                className={`send-btn${isBusy ? ' stop-btn' : ''}`}
                onClick={isBusy ? stop : submit}
                disabled={!isBusy && !input.trim()}
                title={isBusy ? 'Stop' : 'Send message'}
              >
                {isBusy ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                    <rect x="6" y="6" width="12" height="12" rx="2" />
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <line x1="22" y1="2" x2="11" y2="13" />
                    <polygon points="22 2 15 22 11 13 2 9 22 2" />
                  </svg>
                )}
              </button>
            </div>

            <div className="chat-input-footer">
              <span className="disclaimer">
                Sessioned planner, validator, and canvas executor. Voice is local-first Whisper when configured.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default memo(LocalAgentBarImpl);
