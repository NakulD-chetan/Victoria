import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import { DPR } from '../../../lib/canvas/rough-helpers';

const PALETTE = {
  light: {
    bg: '#fafaf9',
    stroke: '#1c1917',
    cellDefault: '#e7e5e4',
    cellActive: '#a5d8ff',
    cellCompare: '#ffd43b',
    cellFound: '#b2f2bb',
    cellEliminated: '#fecdd3',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    dotGrid: '#e7e5e4',
  },
  dark: {
    bg: 'transparent',
    stroke: 'rgba(255,255,255,0.6)',
    cellDefault: 'rgba(255,255,255,0.08)',
    cellActive: '#1c4a6e',
    cellCompare: '#805b10',
    cellFound: '#1e5631',
    cellEliminated: '#4c1d1d',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    dotGrid: 'rgba(255,255,255,0.05)',
  },
};

const POINTER_COLORS = {
  lo: '#2f9e44',
  mid: '#1971c2',
  mid1: '#1971c2',
  mid2: '#1098ad',
  hi: '#e03131',
  probe: '#7c3aed',
  jump: '#f08c00',
  i: '#1098ad',
  bound: '#c2255c',
  j: '#5c940d',
};

function getPalette() {
  return document.documentElement.getAttribute('data-theme') === 'light' ? PALETTE.light : PALETTE.dark;
}

function cellFill(p, colorName) {
  const key = `cell${colorName.charAt(0).toUpperCase() + colorName.slice(1)}`;
  return p[key] || p.cellDefault;
}

function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}

const SearchCanvasBase = forwardRef(function SearchCanvasBase(_, ref) {
  const canvasRef = useRef(null);
  const stateRef = useRef({
    array: [],
    colors: {},
    pointers: {},
    target: 0,
    found: null,
  });
  const animsRef = useRef([]);
  const rafRef = useRef(null);

  const addAnim = useCallback((type, data = {}, dur = 520) => {
    animsRef.current.push({ type, data, t0: performance.now(), dur });
  }, []);

  const setState = useCallback((newState) => {
    Object.assign(stateRef.current, newState);
  }, []);

  useImperativeHandle(ref, () => ({ addAnim, setState }), [addAnim, setState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    const W = rect.width;
    const H = 340;
    canvas.width = W * DPR;
    canvas.height = H * DPR;
    canvas.style.width = `${W}px`;
    canvas.style.height = `${H}px`;
    const ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    function render() {
      const now = performance.now();
      const p = getPalette();
      const { array, colors, pointers, target, found } = stateRef.current;
      ctx.clearRect(0, 0, W, H);

      ctx.fillStyle = p.dotGrid;
      for (let gx = 20; gx < W; gx += 20) {
        for (let gy = 20; gy < H; gy += 20) {
          ctx.fillRect(gx, gy, 1.2, 1.2);
        }
      }

      const n = array?.length || 0;
      if (n === 0) {
        rafRef.current = requestAnimationFrame(render);
        return;
      }

      const padX = 24;
      const topBand = 44;
      const cellRowY = topBand + 28;
      const cellH = 44;
      const gap = Math.max(2, Math.min(5, (W - padX * 2) / n * 0.12));
      const cellW = Math.max(22, (W - padX * 2 - gap * (n - 1)) / n);
      const rowW = n * cellW + (n - 1) * gap;
      const startX = (W - rowW) / 2;

      ctx.fillStyle = p.textSecondary;
      ctx.font = '600 12px -apple-system, BlinkMacSystemFont, sans-serif';
      ctx.textAlign = 'left';
      ctx.textBaseline = 'middle';
      ctx.fillText(`Target: ${target}`, padX, 22);

      const lo = pointers.lo != null ? pointers.lo : null;
      const hi = pointers.hi != null ? pointers.hi : null;
      if (lo != null && hi != null && lo <= hi) {
        const wx = startX + lo * (cellW + gap) - 2;
        const ww = (hi - lo + 1) * cellW + (hi - lo) * gap + 4;
        ctx.strokeStyle = p.stroke;
        ctx.lineWidth = 1.5;
        ctx.setLineDash([6, 4]);
        ctx.strokeRect(wx, cellRowY - 4, ww, cellH + 8);
        ctx.setLineDash([]);
      }

      let flashAlpha = 0;
      for (const a of animsRef.current) {
        const t = Math.min((now - a.t0) / a.dur, 1);
        const e = easeOut(t);
        if (a.type === 'foundFlash') {
          flashAlpha = Math.max(flashAlpha, (1 - t) * 0.55 * e);
        } else if (a.type === 'notFoundFlash') {
          flashAlpha = Math.max(flashAlpha, (1 - t) * 0.45 * e);
        }
      }

      for (let i = 0; i < n; i++) {
        const x = startX + i * (cellW + gap);
        const y = cellRowY;
        const cname = colors[i] || 'default';
        ctx.fillStyle = cellFill(p, cname);
        ctx.strokeStyle = p.stroke;
        ctx.lineWidth = 1.4;
        ctx.beginPath();
        ctx.roundRect(x, y, cellW, cellH, 6);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = p.textPrimary;
        ctx.font = `600 ${Math.min(14, cellW * 0.38)}px ui-monospace, Consolas, monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(array[i]), x + cellW / 2, y + cellH / 2);

        ctx.fillStyle = p.textSecondary;
        ctx.font = '500 9px -apple-system, sans-serif';
        ctx.fillText(String(i), x + cellW / 2, y + cellH + 12);
      }

      if (flashAlpha > 0) {
        ctx.fillStyle = found
          ? `rgba(47, 158, 68, ${flashAlpha})`
          : `rgba(224, 49, 49, ${flashAlpha})`;
        ctx.fillRect(startX - 4, cellRowY - 8, rowW + 8, cellH + 16);
      }

      const pointerY = cellRowY + cellH + 36;
      const drawPointer = (name, idxOrFrac) => {
        if (idxOrFrac == null || Number.isNaN(idxOrFrac)) return;
        const frac = typeof idxOrFrac === 'number' ? idxOrFrac : Number(idxOrFrac);
        const cx = startX + frac * (cellW + gap) + cellW / 2;
        const col = POINTER_COLORS[name] || '#6366f1';
        ctx.fillStyle = col;
        ctx.beginPath();
        ctx.moveTo(cx, pointerY - 10);
        ctx.lineTo(cx - 6, pointerY);
        ctx.lineTo(cx + 6, pointerY);
        ctx.closePath();
        ctx.fill();
        ctx.font = 'bold 10px -apple-system, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        ctx.fillText(name, cx, pointerY + 2);
      };

      if (pointers) {
        if (pointers.lo != null) drawPointer('lo', pointers.lo);
        if (pointers.mid != null) drawPointer('mid', pointers.mid);
        if (pointers.mid1 != null) drawPointer('mid1', pointers.mid1);
        if (pointers.mid2 != null) drawPointer('mid2', pointers.mid2);
        if (pointers.hi != null) drawPointer('hi', pointers.hi);
        if (pointers.probe != null) drawPointer('probe', pointers.probe);
        if (pointers.left != null) drawPointer('left', pointers.left);
        if (pointers.right != null) drawPointer('right', pointers.right);
        if (pointers.jump != null) drawPointer('jump', pointers.jump);
        if (pointers.i != null) drawPointer('i', pointers.i);
        if (pointers.bound != null) drawPointer('bound', pointers.bound);
        if (pointers.j != null) drawPointer('j', pointers.j);
      }

      for (let i = animsRef.current.length - 1; i >= 0; i--) {
        if (now - animsRef.current[i].t0 >= animsRef.current[i].dur) {
          animsRef.current.splice(i, 1);
        }
      }

      rafRef.current = requestAnimationFrame(render);
    }

    rafRef.current = requestAnimationFrame(render);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, []);

  return <canvas ref={canvasRef} className="dc-algo-canvas" />;
});

export default SearchCanvasBase;
