import { EventEmitter } from 'events';
import { existsSync } from 'fs';
import { mkdir, readFile, unlink, writeFile } from 'fs/promises';
import { randomUUID } from 'crypto';
import { dirname, extname, resolve } from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';

import {
  createProviderChatCompletion,
  extractLatestUserText,
  extractMessageText,
  loadCanvasAgentProvider,
  normalizeMessages,
  streamProviderChatCompletion,
} from './canvas-agent-provider.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const RUNS_DIR = resolve(__dirname, 'uploads', '.inkdrop');
const RUNS_FILE = resolve(RUNS_DIR, 'canvas-agent-runs.json');
const DEFAULT_MAX_EVENTS = 500;
const DEFAULT_WHISPER_MODEL_CANDIDATES = [
  process.env.CANVAS_AGENT_WHISPER_MODEL_PATH,
  process.env.WHISPER_MODEL_PATH,
].filter(Boolean);
const DEFAULT_WHISPER_CLI_CANDIDATES = [
  process.env.CANVAS_AGENT_WHISPER_CLI_PATH,
  process.env.WHISPER_CLI_PATH,
  'whisper-cli',
].filter(Boolean);

const TOOL_FAMILIES = [
  'scene.inspect',
  'scene.find_widgets',
  'scene.relayout',
  'widget.create',
  'widget.update',
  'widget.move',
  'widget.delete_soft',
  'widget.focus',
  'shape.create',
  'connector.create',
  'note.create_or_update',
  'code.create_or_update',
  'sql.create_or_update',
  'json.create_or_update',
  'csv.create_or_update',
  'diagram.create_or_update',
  'datastructure.create_or_update',
  'teaching.compose',
  'animation.batch_move',
  'voice.transcribe_local',
  'memory.append_episode',
];

const DEFAULT_CANVAS_TOOLS = [
  {
    name: 'compose_teaching_scene',
    description: 'Compose a complete editable teaching scene. The canvas engine owns layout, routing, bindings, and overlap repair.',
    parameters: {
      type: 'object',
      properties: {
        topic: { type: 'string' },
        structure_type: { type: 'string', enum: ['array', 'tree', 'linked-list', 'stack', 'queue', 'hash-map'] },
        title: { type: 'string' },
        definition: { type: 'string' },
        values: { type: 'array', items: { type: 'string' } },
        include_code_editor: { type: 'boolean' },
        code_language: { type: 'string', enum: ['cpp', 'python', 'java', 'javascript'] },
        code_title: { type: 'string' },
        code: { type: 'string' },
        operation: { type: 'string' },
        callout: { type: 'string' },
      },
      required: ['topic', 'structure_type', 'title', 'definition', 'values'],
    },
  },
  {
    name: 'teach_concept',
    description: 'Create or update a teaching note on the canvas with a clear explanation.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        text: { type: 'string' },
        role: { type: 'string', enum: ['explanation', 'summary', 'comparison', 'roadmap', 'callout'] },
      },
      required: ['title', 'text'],
    },
  },
  {
    name: 'draw_flowchart',
    description: 'Create or update a Mermaid-based diagram or flowchart on the canvas.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        mermaid_code: { type: 'string' },
        role: { type: 'string', enum: ['diagram', 'architecture', 'flow', 'memory-map'] },
      },
      required: ['title', 'mermaid_code'],
    },
  },
  {
    name: 'show_data_structure',
    description: 'Create or update a visual data structure widget.',
    parameters: {
      type: 'object',
      properties: {
        type: { type: 'string', enum: ['array', 'tree', 'linked-list', 'stack', 'queue', 'hash-map'] },
        title: { type: 'string' },
        values: {
          type: 'array',
          items: { type: 'string' },
        },
        role: { type: 'string', enum: ['primary-structure', 'example-structure', 'comparison-structure'] },
      },
      required: ['type', 'title', 'values'],
    },
  },
  {
    name: 'write_code_example',
    description: 'Create or update a runnable code widget.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        language: { type: 'string', enum: ['cpp', 'python', 'java', 'javascript'] },
        code: { type: 'string' },
        live_typing: { type: 'boolean' },
        role: { type: 'string', enum: ['starter-code', 'solution-code', 'practice-code'] },
      },
      required: ['title', 'language', 'code'],
    },
  },
  {
    name: 'open_sql_workspace',
    description: 'Create or update a SQL practice workspace.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        dialect: { type: 'string', enum: ['sqlite', 'mysql', 'oracle'] },
        starter_query: { type: 'string' },
        role: { type: 'string', enum: ['sql-workspace', 'sql-solution'] },
      },
      required: ['title', 'dialect', 'starter_query'],
    },
  },
  {
    name: 'show_json_viewer',
    description: 'Create or update a JSON viewer widget.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        source: { type: 'string' },
        role: { type: 'string', enum: ['json-data', 'json-example'] },
      },
      required: ['title', 'source'],
    },
  },
  {
    name: 'show_csv_loader',
    description: 'Create or update a CSV loader widget.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        source: { type: 'string' },
        delimiter: { type: 'string', enum: ['auto', ',', '\\t', ';', '|'] },
        role: { type: 'string', enum: ['csv-data', 'csv-example'] },
      },
      required: ['title', 'source', 'delimiter'],
    },
  },
  {
    name: 'show_progress',
    description: 'Create or update a progress or roadmap widget.',
    parameters: {
      type: 'object',
      properties: {
        title: { type: 'string' },
        steps: { type: 'array', items: { type: 'string' } },
        currentStepIndex: { type: 'number' },
      },
      required: ['title', 'steps', 'currentStepIndex'],
    },
  },
  {
    name: 'create_text_callout',
    description: 'Create a canvas text callout for labels, reminders, or emphasis.',
    parameters: {
      type: 'object',
      properties: {
        text: { type: 'string' },
        role: { type: 'string', enum: ['label', 'callout', 'hint'] },
      },
      required: ['text'],
    },
  },
  {
    name: 'create_connector',
    description: 'Create a visual connector or arrow between two semantic canvas regions.',
    parameters: {
      type: 'object',
      properties: {
        from: { type: 'string' },
        to: { type: 'string' },
        label: { type: 'string' },
      },
      required: ['from', 'to'],
    },
  },
];

const PLANNER_SYSTEM_PROMPT = `You are CanvasTeacherPlanner, the planning subagent for a structured canvas-teaching runtime.

Return JSON only with this exact shape:
{
  "goal": "short goal",
  "intent": "teach|practice|system_design|data|workspace_setup|draw_visual|repair_existing_canvas",
  "teaching_strategy": "how the answer should teach visually",
  "layout_strategy": "where main widgets should appear",
  "risk_level": "low|medium|high",
  "completion_criteria": ["short criterion"],
  "reuse_candidates": [{"title":"...", "role":"...", "reason":"..."}],
  "steps": [
    {
      "id": "step-1",
      "title": "short title",
      "purpose": "why this matters",
      "tool_sequence": ["teach_concept"],
      "expected_output": "what appears on canvas"
    }
  ]
}

Rules:
- Prefer structured, editable canvas primitives over prose.
- Reuse existing widgets when titles or semantic roles match.
- If a pinned target exists, prefer updating that target instead of creating new content.
- If the scene already contains a lesson page and the user is asking the next step, prefer a new lesson page instead of rewriting the old one.
- Keep plans compact and uncluttered.
- For coding practice, include explanation plus runnable code.
- For system design, include notes plus diagram.
- For data-oriented asks, prefer the most specific data widget.
- For teaching arrays, trees, linked lists, stacks, queues, or hash maps, use compose_teaching_scene as one semantic composition.
- For concept teaching, prefer a layered layout: main idea, visual example, and quick takeaways.
- Keep related widgets in the same semantic cluster and preserve readable spatial layout.
- If the request can be repaired or updated in-place, say so in reuse_candidates.`;

const EXECUTOR_SYSTEM_PROMPT = `You are CanvasTeacherExecutor, a canvas-only agent that must produce visual, structured canvas outputs through tool calls.

Rules:
- The canvas is the main output surface.
- Prefer tool calls over long prose.
- Reuse or update matching widgets when possible.
- Respect pinned targets and current lesson-page context.
- Keep visible prose concise and teacher-like.
- When teaching a supported data structure, use compose_teaching_scene instead of assembling independently positioned widgets.
- Use create_text_callout sparingly to label important relationships.
- If there are 2 or more major widgets, it is good to create one or more connectors when it improves clarity.
- Do not output raw element arrays or implementation details.
- Never ask for permissions for normal canvas work.`;

const runs = new Map();
const runEmitters = new Map();
const runControllers = new Map();
let runsLoaded = false;
let persistPromise = Promise.resolve();

const ACTIVE_RUN_STATUSES = new Set(['queued', 'planning', 'executing', 'validating', 'cancelling']);

function safeJsonParse(value, fallback = null) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function clampEvents(events) {
  if (events.length <= DEFAULT_MAX_EVENTS) return events;
  return events.slice(events.length - DEFAULT_MAX_EVENTS);
}

function summarizePublicRun(run) {
  return {
    id: run.id,
    userId: run.userId,
    status: run.status,
    createdAt: run.createdAt,
    updatedAt: run.updatedAt,
    plan: run.plan,
    latestText: run.latestText,
    eventCount: run.events.length,
    events: run.events,
    finalDiff: run.finalDiff,
    failures: run.failures,
    meta: run.meta,
    stats: run.stats,
    reflectionNotes: run.reflectionNotes,
  };
}

async function ensureRunsLoaded() {
  if (runsLoaded) return;
  runsLoaded = true;
  await mkdir(RUNS_DIR, { recursive: true });
  if (!existsSync(RUNS_FILE)) return;
  try {
    const raw = await readFile(RUNS_FILE, 'utf8');
    const parsed = safeJsonParse(raw, []);
    for (const run of parsed) {
      runs.set(run.id, {
        ...run,
        events: Array.isArray(run.events) ? run.events : [],
        failures: Array.isArray(run.failures) ? run.failures : [],
        reflectionNotes: Array.isArray(run.reflectionNotes) ? run.reflectionNotes : [],
      });
    }
  } catch (err) {
    console.error('[Canvas Agent] failed to load runs:', err);
  }
}

function persistRunsSoon() {
  persistPromise = persistPromise
    .catch(() => {})
    .then(async () => {
      const serialized = JSON.stringify(
        [...runs.values()].map((run) => ({
          ...run,
          events: clampEvents(run.events),
        })),
        null,
        2,
      );
      await writeFile(RUNS_FILE, serialized, 'utf8');
    })
    .catch((err) => {
      console.error('[Canvas Agent] failed to persist runs:', err);
    });
}

function getRunEmitter(runId) {
  if (!runEmitters.has(runId)) {
    runEmitters.set(runId, new EventEmitter());
  }
  return runEmitters.get(runId);
}

function updateRun(runId, patch) {
  const current = runs.get(runId);
  if (!current) return null;
  const next = {
    ...current,
    ...patch,
    updatedAt: Date.now(),
  };
  runs.set(runId, next);
  persistRunsSoon();
  return next;
}

function appendRunEvent(runId, type, payload = {}) {
  const current = runs.get(runId);
  if (!current) return null;
  const event = {
    id: randomUUID(),
    type,
    createdAt: Date.now(),
    ...payload,
  };
  const nextEvents = clampEvents((current.events || []).concat([event]));
  updateRun(runId, { events: nextEvents });
  getRunEmitter(runId).emit('event', event);
  return event;
}

function createRunRecord({ userId, messages, sceneContext, tools, providerMeta, voiceMeta }) {
  const run = {
    id: randomUUID(),
    userId,
    status: 'queued',
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: normalizeMessages(messages),
    sceneContext,
    tools,
    plan: null,
    latestText: '',
    events: [],
    failures: [],
    reflectionNotes: [],
    finalDiff: null,
    stats: { created: 0, reused: 0, connectors: 0, textCallouts: 0 },
    meta: {
      provider: providerMeta.provider,
      model: providerMeta.model,
      source: providerMeta.source,
      voice: voiceMeta,
      runLimits: {
        maxEvents: DEFAULT_MAX_EVENTS,
      },
      sceneId: sceneContext?.sceneId || null,
    },
    cancelRequested: false,
  };
  runs.set(run.id, run);
  persistRunsSoon();
  return run;
}

function findActiveRunForScene(userId, sceneId) {
  if (!sceneId) return null;
  for (const run of runs.values()) {
    if (run.userId !== userId) continue;
    if (run.meta?.sceneId !== sceneId) continue;
    if (ACTIVE_RUN_STATUSES.has(run.status)) {
      return run;
    }
  }
  return null;
}

function inferIntent(query) {
  const text = String(query || '').toLowerCase();
  if (/(repair|fix|cleanup|improve layout|make it cleaner|rearrange)/.test(text)) return 'repair_existing_canvas';
  if (/(system design|architecture|high level design|hld|lld|scalab)/.test(text)) return 'system_design';
  if (/\b(json|payload|api response)\b/.test(text)) return 'data';
  if (/\bcsv\b|spreadsheet|table data/.test(text)) return 'data';
  if (/\b(sql|mysql|oracle|sqlite|query|database)\b/.test(text)) return 'workspace_setup';
  if (/\b(code|coding|practice|leetcode|implement|problem)\b/.test(text)) return 'practice';
  if (/\b(array|tree|linked list|stack|queue|hash map|hashmap)\b/.test(text)) return 'data';
  if (/\b(draw|diagram|visual|map|canvas)\b/.test(text)) return 'draw_visual';
  return 'teach';
}

function inferStructureType(query) {
  const lower = String(query || '').toLowerCase();
  if (lower.includes('linked list')) return 'linked-list';
  if (lower.includes('hash map') || lower.includes('hashmap')) return 'hash-map';
  if (lower.includes('stack')) return 'stack';
  if (lower.includes('queue')) return 'queue';
  if (lower.includes('tree')) return 'tree';
  return 'array';
}

function isTeachingStyleQuery(query) {
  return /\b(explain|teach|understand|intuition|why|how|revise|overview|notes?)\b/i.test(String(query || ''));
}

function inferTeachingFocus(query) {
  const lower = String(query || '').toLowerCase();
  if (/\b(delete|deletion|remove|pop)\b/.test(lower)) return 'deletion';
  if (/\b(insert|insertion|append|push)\b/.test(lower)) return 'insertion';
  if (/\b(memory|contiguous|address|cache)\b/.test(lower)) return 'memory';
  if (/\b(access|index|lookup|read)\b/.test(lower)) return 'access';
  return 'overview';
}

function wantsEditableCode(query) {
  return /\b(code|coding|implement|editor|practice|manual|type myself|write code)\b/i.test(String(query || ''));
}

function shouldAdvanceLessonPage(query, sceneContext) {
  if (sceneContext?.pinnedTarget?.elementId) return false;
  const pages = sceneContext?.lessonDeck?.pages || [];
  if (!pages.length) return false;
  const lower = String(query || '').toLowerCase();
  if (/\b(update|edit|refine|fix|change|improve|comment|rename|target|selected|this|that)\b/.test(lower)) return false;
  return /\b(next|now|then|after|how to|delete|deletion|insert|insertion|access|memory|code|implement|write)\b/.test(lower);
}

function pinnedWidgetType(sceneContext) {
  return sceneContext?.pinnedTarget?.widgetType || null;
}

function structureTeachingPackage(query) {
  const type = inferStructureType(query);
  const focus = inferTeachingFocus(query);
  if (type === 'tree') {
    return {
      title: 'Binary Tree',
      values: ['1', '2', '3', '4', '5', '6', '7'],
      explanation: 'A tree stores values in parent-child links, so we reason about levels, subtrees, and recursive structure.',
      takeaways: [
        'The root is the entry point.',
        'Each node can point to children.',
        'Traversals visit nodes in different orders.',
      ],
      callout: 'Think in parent-child relationships, not left-to-right indexing.',
      focus,
    };
  }
  if (type === 'stack') {
    return {
      title: 'Stack',
      values: ['5', '8', '13'],
      explanation: 'A stack follows Last In, First Out, which means the newest item is removed first.',
      takeaways: [
        'Push adds to the top.',
        'Pop removes from the top.',
        'Great for undo, recursion, and monotonic-stack problems.',
      ],
      callout: 'Only the top is directly accessible.',
      focus,
    };
  }
  if (type === 'queue') {
    return {
      title: 'Queue',
      values: ['A', 'B', 'C', 'D'],
      explanation: 'A queue follows First In, First Out, so items leave in the same order they arrive.',
      takeaways: [
        'Enqueue adds at the back.',
        'Dequeue removes from the front.',
        'Useful for BFS and scheduling.',
      ],
      callout: 'Front leaves first, back joins last.',
      focus,
    };
  }
  if (type === 'linked-list') {
    return {
      title: 'Linked List',
      values: ['10', '20', '30', '40'],
      explanation: 'A linked list stores values in nodes connected by pointers, so movement happens by following links one by one.',
      takeaways: [
        'Each node stores data plus a next reference.',
        'Insertion is flexible once you reach the position.',
        'Random access is slower than arrays.',
      ],
      callout: 'Traversal is sequential because nodes are linked, not indexed.',
      focus,
    };
  }
  if (type === 'hash-map') {
    return {
      title: 'Hash Map',
      values: ['name:Ada', 'lang:C++', 'level:advanced'],
      explanation: 'A hash map uses a hash function to place keys into buckets so lookups can be very fast on average.',
      takeaways: [
        'Keys map to values.',
        'Collisions must be handled carefully.',
        'Great for fast membership and counting.',
      ],
      callout: 'Fast average lookup comes from hashing, not ordering.',
      focus,
    };
  }
  return {
    title: 'Array',
    values: ['12', '7', '19', '4', '23'],
    explanation: 'An array stores elements in contiguous positions, so every value has a stable index and direct lookup is simple.',
    takeaways: [
      'Indexes start from a fixed position.',
      'Reading by index is fast.',
      'Insertion in the middle can require shifting elements.',
    ],
    callout: 'Index + contiguous storage is the big idea.',
    focus,
  };
}

function starterCodeForQuery(query) {
  const type = inferStructureType(query);
  if (type === 'array') {
    return {
      title: 'Array Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  vector<int> arr = {12, 7, 19, 4, 23};\n\n  // Try reading, updating, inserting, or deleting values.\n\n  return 0;\n}\n',
    };
  }
  if (type === 'stack') {
    return {
      title: 'Stack Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  stack<int> st;\n\n  // Try push, pop, and top here.\n\n  return 0;\n}\n',
    };
  }
  if (type === 'queue') {
    return {
      title: 'Queue Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  queue<int> q;\n\n  // Try enqueue, dequeue, and front here.\n\n  return 0;\n}\n',
    };
  }
  if (type === 'linked-list') {
    return {
      title: 'Linked List Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nstruct Node {\n  int value;\n  Node* next;\n};\n\nint main() {\n  // Build and traverse a linked list here.\n  return 0;\n}\n',
    };
  }
  if (type === 'tree') {
    return {
      title: 'Tree Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nstruct Node {\n  int value;\n  Node* left;\n  Node* right;\n};\n\nint main() {\n  // Build a tree and try a traversal here.\n  return 0;\n}\n',
    };
  }
  if (type === 'hash-map') {
    return {
      title: 'Hash Map Practice Editor',
      language: 'cpp',
      code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  unordered_map<string, int> counts;\n\n  // Try insert, lookup, and update here.\n\n  return 0;\n}\n',
    };
  }
  return {
    title: 'Starter Code',
    language: 'cpp',
    code: '#include <bits/stdc++.h>\nusing namespace std;\n\nint main() {\n  ios::sync_with_stdio(false);\n  cin.tie(nullptr);\n\n  return 0;\n}\n',
  };
}

function makeHumanReplaySummary(sceneContext) {
  const widgets = sceneContext?.widgets || [];
  if (!widgets.length) return 'Blank or mostly blank canvas.';
  return widgets
    .slice(0, 12)
    .map((widget) => `${widget.role || widget.kind || widget.type}: ${widget.title || widget.type}`)
    .join(' | ');
}

function buildSceneContextMessage(sceneContext) {
  const widgets = sceneContext?.widgets || [];
  const clusters = sceneContext?.clusters || [];
  const elements = sceneContext?.elements || [];
  const recentActions = sceneContext?.recentAgentActions || [];
  const lessonPages = sceneContext?.lessonDeck?.pages || [];
  const selection = sceneContext?.selectionContext || [];
  const pinnedTarget = sceneContext?.pinnedTarget || null;
  const lines = widgets.map((widget) => (
    `- ${widget.kind || widget.type} :: ${widget.title || 'Untitled'} role=${widget.role || 'general'} reuse=${widget.can_reuse ? 'yes' : 'no'} signature=${widget.content_signature || 'none'} @ (${Math.round(widget.x || 0)}, ${Math.round(widget.y || 0)})`
  ));
  return [
    `Viewport: zoom=${sceneContext?.viewport?.zoom || 1}, pan=(${sceneContext?.viewport?.panX || 0}, ${sceneContext?.viewport?.panY || 0})`,
    `Human replay summary: ${sceneContext?.humanReplaySummary || makeHumanReplaySummary(sceneContext)}`,
    lessonPages.length
      ? `Lesson pages:\n${lessonPages.map((page) => `- ${page.id} "${page.title}" topic=${page.topic} focus=${page.focus} order=${page.order}${sceneContext?.lessonDeck?.currentPageId === page.id ? ' current=yes' : ''}`).join('\n')}`
      : 'Lesson pages: none',
    pinnedTarget?.elementId
      ? `Pinned target: ${pinnedTarget.widgetType || 'widget'} "${pinnedTarget.title || pinnedTarget.elementId}" role=${pinnedTarget.role || 'general'} page=${pinnedTarget.lessonPageId || 'none'}`
      : 'Pinned target: none',
    selection.length
      ? `Current selection:\n${selection.map((widget) => `- ${widget.type} "${widget.title}" role=${widget.role || 'general'} page=${widget.lesson_page_id || 'none'}`).join('\n')}`
      : 'Current selection: none',
    clusters.length
      ? `Clusters:\n${clusters.map((cluster) => `- ${cluster.roles?.join('/') || 'general'} :: ${cluster.titles?.join(', ') || cluster.seed || cluster.id} size=${cluster.size || 0}`).join('\n')}`
      : 'Clusters: none',
    lines.length ? `Widgets:\n${lines.join('\n')}` : 'Widgets: none',
    elements.length
      ? `Scene graph:\n${elements.slice(0, 80).map((element) => (
        `- ${element.id} ${element.type} role=${element.role || 'general'} topic=${element.topic || 'none'} cluster=${element.cluster || 'none'} @ (${Math.round(element.x || 0)}, ${Math.round(element.y || 0)}, ${Math.round(element.w || 0)}x${Math.round(element.h || 0)}) bindings=${element.startBinding || '-'}->${element.endBinding || '-'}`
      )).join('\n')}`
      : 'Scene graph: empty',
    recentActions.length
      ? `Recent agent actions:\n${recentActions.map((action) => `- ${action.intent || 'teach'}: ${action.summary || action.goal || action.runId}`).join('\n')}`
      : 'Recent agent actions: none',
  ].join('\n\n');
}

function heuristicPlan(latestUserText, sceneContext) {
  const intent = inferIntent(latestUserText);
  const steps = [];

  if (intent === 'system_design') {
    steps.push(
      {
        id: 'step-1',
        title: 'Explain the architecture',
        purpose: 'Give the user a clear mental model.',
        tool_sequence: ['teach_concept', 'draw_flowchart'],
        expected_output: 'One note and one architecture diagram.',
      },
    );
  } else if (intent === 'practice') {
    steps.push(
      {
        id: 'step-1',
        title: 'Frame the problem',
        purpose: 'Make the practice task clear.',
        tool_sequence: ['teach_concept'],
        expected_output: 'A concise explanation note.',
      },
      {
        id: 'step-2',
        title: 'Create runnable code',
        purpose: 'Give the user a practical place to work.',
        tool_sequence: ['write_code_example'],
        expected_output: 'A code widget with starter code.',
      },
    );
  } else if (intent === 'workspace_setup') {
    steps.push(
      {
        id: 'step-1',
        title: 'Prepare a workspace',
        purpose: 'Give the user the right tool surface.',
        tool_sequence: ['open_sql_workspace'],
        expected_output: 'A SQL workspace.',
      },
    );
  } else if (intent === 'data') {
    steps.push(
      {
        id: 'step-1',
        title: 'Compose the visual lesson',
        purpose: 'Connect the definition, editable structure, operations, labels, and arrows in one validated scene.',
        tool_sequence: ['compose_teaching_scene'],
        expected_output: 'A complete non-overlapping teaching composition.',
      },
    );
  } else {
    steps.push(
      {
        id: 'step-1',
        title: 'Teach visually',
        purpose: 'Answer through the canvas.',
        tool_sequence: ['teach_concept'],
        expected_output: 'A clear note.',
      },
    );
  }

  return {
    goal: latestUserText || 'Help the user on the canvas.',
    intent,
    teaching_strategy: 'Prefer a small number of reusable visual teaching blocks.',
    layout_strategy: 'Keep the main explanation centered, working widgets to the right, and support visuals below.',
    risk_level: 'low',
    completion_criteria: ['The canvas shows a clear and reusable teaching setup.'],
    reuse_candidates: (sceneContext?.widgets || []).slice(0, 4).map((widget) => ({
      title: widget.title || widget.type,
      role: widget.role || 'general',
      reason: 'Existing widget may be reusable.',
    })),
    steps,
  };
}

function parsePlanResponse(text, fallbackPlan) {
  const stripped = String(text || '')
    .trim()
    .replace(/^```(?:json)?/i, '')
    .replace(/```$/i, '')
    .trim();
  const parsed = safeJsonParse(stripped);
  if (!parsed || typeof parsed !== 'object') return fallbackPlan;
  return {
    goal: parsed.goal || fallbackPlan.goal,
    intent: parsed.intent || fallbackPlan.intent,
    teaching_strategy: parsed.teaching_strategy || fallbackPlan.teaching_strategy,
    layout_strategy: parsed.layout_strategy || fallbackPlan.layout_strategy,
    risk_level: parsed.risk_level || fallbackPlan.risk_level,
    completion_criteria: Array.isArray(parsed.completion_criteria) ? parsed.completion_criteria : fallbackPlan.completion_criteria,
    reuse_candidates: Array.isArray(parsed.reuse_candidates) ? parsed.reuse_candidates : fallbackPlan.reuse_candidates,
    steps: Array.isArray(parsed.steps) && parsed.steps.length ? parsed.steps : fallbackPlan.steps,
  };
}

async function buildTeacherPlan(provider, messages, sceneContext, signal) {
  const latestUserText = extractLatestUserText(messages);
  const fallbackPlan = heuristicPlan(latestUserText, sceneContext);
  try {
    const response = await createProviderChatCompletion({
      provider,
      systemPrompt: PLANNER_SYSTEM_PROMPT,
      messages: normalizeMessages(messages).concat([
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: [
                buildSceneContextMessage(sceneContext),
                `Latest user request:\n${latestUserText || 'No text found.'}`,
              ].join('\n\n'),
            },
          ],
        },
      ]),
      maxTokens: Math.min(provider.maxTokens, 2000),
      temperature: 0,
      responseFormat: 'json_object',
      signal,
    });
    return parsePlanResponse(extractMessageText(response.message), fallbackPlan);
  } catch {
    return fallbackPlan;
  }
}

function coerceValues(values, fallback = []) {
  if (!Array.isArray(values)) return fallback;
  return values.map((value) => (typeof value === 'string' ? value : String(value ?? '')));
}

function semanticRoleForToolCall(name, args = {}) {
  if (args.role) return args.role;
  if (name === 'compose_teaching_scene') return 'teaching-composition';
  if (name === 'teach_concept') return 'explanation';
  if (name === 'draw_flowchart') return 'diagram';
  if (name === 'show_data_structure') return 'primary-structure';
  if (name === 'write_code_example') return 'practice-code';
  if (name === 'open_sql_workspace') return 'sql-workspace';
  if (name === 'show_json_viewer') return 'json-data';
  if (name === 'show_csv_loader') return 'csv-data';
  if (name === 'show_progress') return 'roadmap';
  if (name === 'create_text_callout') return 'callout';
  return 'general';
}

function normalizeTitle(title, fallback) {
  if (typeof title === 'string' && title.trim()) return title.trim();
  return fallback;
}

function signatureForContent(parts) {
  return String(parts.filter(Boolean).join('|'))
    .slice(0, 220)
    .toLowerCase();
}

function buildPlacementIntent(plan, call, semanticRole, index) {
  const intent = plan?.intent || 'teach';
  const clusterKey = `${intent}-workspace`;

  if (intent === 'practice') {
    if (call.name === 'teach_concept') {
      return { preferredZone: 'left-rail', relation: 'center', clusterKey, preserveCluster: true };
    }
    if (call.name === 'write_code_example') {
      return { preferredZone: 'right-rail', relation: 'rightOf', anchorRole: 'explanation', clusterKey, preserveCluster: true };
    }
    if (call.name === 'show_data_structure' || call.name === 'show_progress') {
      return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'explanation', clusterKey, preserveCluster: true };
    }
    if (call.name === 'draw_flowchart') {
      return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'practice-code', clusterKey, preserveCluster: true };
    }
  }

  if (intent === 'system_design') {
    if (call.name === 'teach_concept') {
      return { preferredZone: 'left-rail', relation: 'center', clusterKey, preserveCluster: true };
    }
    if (call.name === 'draw_flowchart') {
      return { preferredZone: 'right-rail', relation: 'rightOf', anchorRole: 'explanation', clusterKey, preserveCluster: true };
    }
    if (call.name === 'show_progress') {
      return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'diagram', clusterKey, preserveCluster: true };
    }
  }

  if (intent === 'data') {
    if (call.name === 'teach_concept') {
      if (semanticRole === 'summary' || semanticRole === 'callout') {
        return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'primary-structure', clusterKey, preserveCluster: true };
      }
      return { preferredZone: 'left-rail', relation: 'center', anchorRole: null, clusterKey, preserveCluster: true };
    }
    if (call.name === 'show_json_viewer' || call.name === 'show_csv_loader' || call.name === 'show_data_structure') {
      return { preferredZone: 'focus', relation: 'rightOf', anchorRole: 'explanation', clusterKey, preserveCluster: true };
    }
    if (call.name === 'create_text_callout') {
      return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'primary-structure', clusterKey, preserveCluster: true };
    }
  }

  if (intent === 'workspace_setup') {
    if (call.name === 'open_sql_workspace') {
      return { preferredZone: 'focus', relation: 'center', clusterKey, preserveCluster: true };
    }
  }

  if (call.name === 'draw_flowchart') {
    return { preferredZone: 'right-rail', relation: 'rightOf', anchorRole: 'explanation', clusterKey, preserveCluster: true };
  }

  if (call.name === 'write_code_example' || call.name === 'open_sql_workspace') {
    return { preferredZone: 'right-rail', relation: 'rightOf', anchorRole: 'explanation', clusterKey, preserveCluster: true };
  }

  if (call.name === 'show_progress' || call.name === 'create_text_callout') {
    return { preferredZone: 'bottom-support', relation: 'below', anchorRole: 'explanation', clusterKey, preserveCluster: true };
  }

  return {
    preferredZone: index === 0 ? 'focus' : 'bottom-support',
    relation: index === 0 ? 'center' : 'below',
    anchorRole: index === 0 ? null : 'explanation',
    clusterKey,
    preserveCluster: index > 0,
  };
}

function sanitizeToolCall(call, query) {
  const args = call?.args && typeof call.args === 'object'
    ? { ...call.args }
    : safeJsonParse(call?.args, {}) || {};

  if (call.name === 'compose_teaching_scene') {
    const pack = structureTeachingPackage(query);
    args.structure_type = ['array', 'tree', 'linked-list', 'stack', 'queue', 'hash-map'].includes(args.structure_type)
      ? args.structure_type
      : inferStructureType(query);
    args.topic = normalizeTitle(args.topic, args.structure_type);
    args.title = normalizeTitle(args.title, pack.title);
    args.definition = typeof args.definition === 'string' && args.definition.trim()
      ? args.definition.trim()
      : pack.explanation;
    args.values = coerceValues(args.values, pack.values);
    args.focus = ['overview', 'access', 'memory', 'insertion', 'deletion'].includes(args.focus)
      ? args.focus
      : pack.focus;
    args.operation = typeof args.operation === 'string' && args.operation.trim()
      ? args.operation.trim()
      : pack.takeaways[0];
    args.callout = typeof args.callout === 'string' && args.callout.trim()
      ? args.callout.trim()
      : pack.callout;
    args.include_code_editor = Boolean(args.include_code_editor);
    args.code_language = ['cpp', 'python', 'java', 'javascript'].includes(args.code_language)
      ? args.code_language
      : 'cpp';
    args.code_title = normalizeTitle(args.code_title, `${args.title} Code`);
    args.code = typeof args.code === 'string' ? args.code : '';
  } else if (call.name === 'teach_concept') {
    args.title = normalizeTitle(args.title, 'Explanation');
    args.text = typeof args.text === 'string' && args.text.trim()
      ? args.text
      : 'I added a concise teaching note on the canvas.';
  } else if (call.name === 'draw_flowchart') {
    args.title = normalizeTitle(args.title, 'Flowchart');
    args.mermaid_code = typeof args.mermaid_code === 'string' && args.mermaid_code.trim()
      ? args.mermaid_code
      : 'graph TD;\n  A-->B;';
    if (!/(graph|flowchart|sequenceDiagram|classDiagram|erDiagram|stateDiagram)/i.test(args.mermaid_code)) {
      args.mermaid_code = `graph TD;\n  Start["${args.title}"]-->End["Review"];`;
    }
  } else if (call.name === 'show_data_structure') {
    args.type = ['array', 'tree', 'linked-list', 'stack', 'queue', 'hash-map'].includes(args.type) ? args.type : 'array';
    args.title = normalizeTitle(args.title, args.type.replace(/-/g, ' '));
    args.values = coerceValues(args.values, ['10', '20', '30']);
  } else if (call.name === 'write_code_example') {
    const starter = starterCodeForQuery(query);
    args.title = normalizeTitle(args.title, starter.title);
    args.language = ['cpp', 'python', 'java', 'javascript'].includes(args.language) ? args.language : starter.language;
    args.code = typeof args.code === 'string' && args.code.trim()
      ? args.code
      : starter.code;
    args.live_typing = args.live_typing !== false;
  } else if (call.name === 'open_sql_workspace') {
    args.title = normalizeTitle(args.title, 'SQL Workspace');
    args.dialect = ['sqlite', 'mysql', 'oracle'].includes(args.dialect) ? args.dialect : 'sqlite';
    if (args.dialect === 'mysql' && !process.env.MYSQL_URL) {
      args.dialect = 'sqlite';
      args.starter_query = '-- MySQL URL not configured, using SQLite fallback.\nSELECT 1 AS example;';
    } else {
      args.starter_query = typeof args.starter_query === 'string' && args.starter_query.trim()
        ? args.starter_query
        : 'SELECT 1 AS example;';
    }
  } else if (call.name === 'show_json_viewer') {
    args.title = normalizeTitle(args.title, 'JSON Viewer');
    args.source = typeof args.source === 'string' && args.source.trim()
      ? args.source
      : '{\n  "message": "Paste JSON here"\n}';
    if (!safeJsonParse(args.source)) {
      args.source = JSON.stringify({ message: args.source }, null, 2);
    }
  } else if (call.name === 'show_csv_loader') {
    args.title = normalizeTitle(args.title, 'CSV Loader');
    args.delimiter = ['auto', ',', '\t', ';', '|', '\\t'].includes(args.delimiter) ? args.delimiter : 'auto';
    args.source = typeof args.source === 'string' && args.source.trim()
      ? args.source
      : 'name,score\nAda,100';
    if (!args.source.includes('\n')) {
      args.source = `value\n${args.source}`;
    }
  } else if (call.name === 'show_progress') {
    args.title = normalizeTitle(args.title, 'Plan');
    args.steps = coerceValues(args.steps, ['Plan', 'Build', 'Review']);
    args.currentStepIndex = Number.isFinite(Number(args.currentStepIndex)) ? Number(args.currentStepIndex) : 0;
  } else if (call.name === 'create_text_callout') {
    args.text = typeof args.text === 'string' && args.text.trim() ? args.text.trim() : `Focus: ${query || 'Important detail'}`;
  } else if (call.name === 'create_connector') {
    args.from = normalizeTitle(args.from, 'Explanation');
    args.to = normalizeTitle(args.to, 'Example');
    args.label = typeof args.label === 'string' ? args.label : '';
  }

  return {
    name: call.name,
    args,
  };
}

function buildFallbackToolCalls(query, plan) {
  const intent = plan?.intent || inferIntent(query);
  if (intent === 'system_design') {
    return [
      sanitizeToolCall({
        name: 'teach_concept',
        args: {
          title: 'System Design Overview',
          text: 'Break the system into clients, APIs, storage, caches, and background workers so the trade-offs stay visible.',
          role: 'summary',
        },
      }, query),
      sanitizeToolCall({
        name: 'draw_flowchart',
        args: {
          title: 'Architecture Flow',
          mermaid_code: 'graph TD;\n  Client-->API;\n  API-->Cache;\n  API-->DB;\n  API-->Queue;\n  Queue-->Worker;',
          role: 'architecture',
        },
      }, query),
    ];
  }

  if (intent === 'practice') {
    const calls = [];
    if (/\b(array|tree|linked list|stack|queue|hash map|hashmap)\b/i.test(String(query || '')) && (isTeachingStyleQuery(query) || wantsEditableCode(query))) {
      const pack = structureTeachingPackage(query);
      calls.push(sanitizeToolCall({
        name: 'compose_teaching_scene',
        args: {
          topic: inferStructureType(query),
          structure_type: inferStructureType(query),
          title: pack.title,
          definition: pack.explanation,
          values: pack.values,
          focus: pack.focus,
          operation: pack.takeaways[0],
          callout: pack.callout,
          include_code_editor: wantsEditableCode(query),
          code_language: 'cpp',
          code_title: `${pack.title} Code`,
          code: wantsEditableCode(query) ? starterCodeForQuery(query).code : '',
        },
      }, query));
    }
    if (!calls.length && !wantsEditableCode(query)) {
      calls.push(sanitizeToolCall({
        name: 'teach_concept',
        args: {
          title: 'Approach',
          text: 'Start from the problem goal, identify the core pattern, and test edge cases before coding.',
        },
      }, query));
    }
    if (!calls.some((call) => call.name === 'compose_teaching_scene' && call.args?.include_code_editor)) {
      calls.push(sanitizeToolCall({
        name: 'write_code_example',
        args: { live_typing: true },
      }, query));
    }
    return calls;
  }

  if (intent === 'workspace_setup') {
    return [
      sanitizeToolCall({
        name: 'open_sql_workspace',
        args: {
          title: 'SQL Workspace',
          dialect: /mysql/.test(String(query || '').toLowerCase()) ? 'mysql' : 'sqlite',
        },
      }, query),
    ];
  }

  if (intent === 'data') {
    const lower = String(query || '').toLowerCase();
    if (lower.includes('json')) {
      return [sanitizeToolCall({ name: 'show_json_viewer', args: { title: 'JSON Viewer' } }, query)];
    }
    if (lower.includes('csv')) {
      return [sanitizeToolCall({ name: 'show_csv_loader', args: { title: 'CSV Loader' } }, query)];
    }
    if (isTeachingStyleQuery(query)) {
      const pack = structureTeachingPackage(query);
      return [
        sanitizeToolCall({
          name: 'compose_teaching_scene',
          args: {
            topic: inferStructureType(query),
            structure_type: inferStructureType(query),
            title: pack.title,
            definition: pack.explanation,
            values: pack.values,
            focus: pack.focus,
            operation: pack.takeaways[0],
            callout: pack.callout,
            include_code_editor: wantsEditableCode(query),
            code_language: 'cpp',
            code_title: `${pack.title} Code`,
            code: wantsEditableCode(query) ? starterCodeForQuery(query).code : '',
          },
        }, query),
      ];
    }
    return [
      sanitizeToolCall({
        name: 'show_data_structure',
        args: {
          type: lower.includes('tree') ? 'tree' : lower.includes('linked list') ? 'linked-list' : lower.includes('stack') ? 'stack' : lower.includes('queue') ? 'queue' : lower.includes('hash') ? 'hash-map' : 'array',
          title: 'Data Structure',
          values: ['10', '20', '30', '40'],
        },
      }, query),
    ];
  }

  return [
    sanitizeToolCall({
      name: 'teach_concept',
      args: {
        title: 'Teaching Notes',
        text: 'I used the canvas to explain this clearly and keep the important ideas visible.',
      },
    }, query),
  ];
}

function normalizeToolCalls(rawCalls, tools, query, plan) {
  const allowed = new Set((tools || DEFAULT_CANVAS_TOOLS).map((tool) => tool.name));
  const cleaned = (rawCalls || [])
    .map((call) => ({
      name: call?.name || call?.function?.name || '',
      args: safeJsonParse(call?.function?.arguments || '{}', call?.args || {}),
    }))
    .filter((call) => allowed.has(call.name))
    .map((call) => sanitizeToolCall(call, query));

  if (cleaned.length) return cleaned;
  return buildFallbackToolCalls(query, plan);
}

function buildWidgetSceneOp(call, index, plan, sceneContext, query) {
  const args = call.args || {};
  const semanticRole = semanticRoleForToolCall(call.name, args);
  const placementIntent = buildPlacementIntent(plan, call, semanticRole, index);
  const pinnedTarget = sceneContext?.pinnedTarget || null;
  const currentPageId = sceneContext?.lessonDeck?.currentPageId || null;
  const pageMode = shouldAdvanceLessonPage(query, sceneContext) ? 'next' : 'current';

  if (call.name === 'compose_teaching_scene') {
    return {
      kind: 'compose_teaching_scene',
      topic: args.topic,
      structureType: args.structure_type,
      title: args.title,
      definition: args.definition,
      values: coerceValues(args.values, ['0', '1', '2', '3', '4']),
      focus: args.focus || 'overview',
      operation: args.operation || '',
      callout: args.callout || '',
      includeCodeEditor: Boolean(args.include_code_editor),
      codeLanguage: args.code_language || 'cpp',
      codeTitle: args.code_title || `${args.title} Code`,
      code: args.code || '',
      liveTyping: Boolean(args.include_code_editor),
      lessonPageId: pinnedTarget?.lessonPageId || currentPageId || null,
      pageMode,
      replaceExistingTopic: pageMode === 'current',
      importanceScore: 1,
    };
  }

  if (call.name === 'teach_concept') {
    return {
      kind: 'upsert_widget',
      widgetType: 'note',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        text: args.text,
      },
      targetElementId: pinnedTarget?.widgetType === 'note' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.text]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.95,
    };
  }

  if (call.name === 'draw_flowchart') {
    return {
      kind: 'upsert_widget',
      widgetType: 'mermaid-diagram',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        code: args.mermaid_code,
      },
      targetElementId: pinnedTarget?.widgetType === 'mermaid-diagram' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.mermaid_code]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.92,
    };
  }

  if (call.name === 'show_data_structure') {
    return {
      kind: 'upsert_widget',
      widgetType: args.type,
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        values: coerceValues(args.values, ['1', '2', '3']),
      },
      targetElementId: pinnedTarget?.widgetType === args.type ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, ...(args.values || [])]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.88,
    };
  }

  if (call.name === 'write_code_example') {
    return {
      kind: 'upsert_widget',
      widgetType: 'code',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        language: args.language,
        code: args.code,
        liveTyping: args.live_typing !== false,
      },
      targetElementId: pinnedTarget?.widgetType === 'code' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.language, args.code]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.93,
    };
  }

  if (call.name === 'open_sql_workspace') {
    return {
      kind: 'upsert_widget',
      widgetType: 'sql-pad',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        language: args.dialect,
        code: args.starter_query,
      },
      targetElementId: pinnedTarget?.widgetType === 'sql-pad' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.dialect, args.starter_query]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.89,
    };
  }

  if (call.name === 'show_json_viewer') {
    return {
      kind: 'upsert_widget',
      widgetType: 'json',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        source: args.source,
      },
      targetElementId: pinnedTarget?.widgetType === 'json' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.source]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.84,
    };
  }

  if (call.name === 'show_csv_loader') {
    return {
      kind: 'upsert_widget',
      widgetType: 'csv',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        source: args.source,
        delimiter: args.delimiter,
      },
      targetElementId: pinnedTarget?.widgetType === 'csv' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, args.source, args.delimiter]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.84,
    };
  }

  if (call.name === 'show_progress') {
    return {
      kind: 'upsert_widget',
      widgetType: 'progress',
      title: args.title,
      semanticRole,
      placementIntent,
      payload: {
        title: args.title,
        steps: coerceValues(args.steps, ['Plan', 'Build', 'Review']),
        currentStepIndex: Number.isFinite(Number(args.currentStepIndex)) ? Number(args.currentStepIndex) : 0,
      },
      targetElementId: pinnedTarget?.widgetType === 'progress' ? pinnedTarget.elementId : null,
      contentSignature: signatureForContent([args.title, ...(args.steps || [])]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.78,
    };
  }

  if (call.name === 'create_text_callout') {
    return {
      kind: 'create_text_callout',
      semanticRole,
      placementIntent,
      text: args.text,
      importanceScore: 0.7,
    };
  }

  if (call.name === 'create_connector') {
    return {
      kind: 'create_connector',
      connectorType: 'arrow',
      from: args.from,
      to: args.to,
      label: args.label || '',
      importanceScore: 0.64,
    };
  }

  return null;
}

function buildSceneOps(toolCalls, plan, sceneContext, query) {
  const sceneOps = [];
  const primaryWidgetOps = [];

  for (let index = 0; index < toolCalls.length; index += 1) {
    const op = buildWidgetSceneOp(toolCalls[index], index, plan, sceneContext, query);
    if (!op) continue;
    sceneOps.push(op);
    if (op.kind === 'upsert_widget') {
      primaryWidgetOps.push(op);
    }
  }

  if (primaryWidgetOps.length >= 2 && ['system_design', 'practice', 'teach', 'data'].includes(plan.intent)) {
    for (let index = 0; index < primaryWidgetOps.length - 1; index += 1) {
      const from = primaryWidgetOps[index];
      const to = primaryWidgetOps[index + 1];
      sceneOps.push({
        kind: 'create_connector',
        connectorType: 'arrow',
        from: from.semanticRole || from.title,
        to: to.semanticRole || to.title,
        label: '',
        importanceScore: 0.52,
      });
    }
  }

  return sceneOps;
}

function criticRepairSceneOps(sceneOps, sceneContext) {
  const failures = [];
  const repaired = [];
  const seenKeys = new Set();

  for (const op of sceneOps) {
    if (!op) continue;
    if (op.kind === 'upsert_widget') {
      const dedupeKey = `${op.widgetType}:${op.semanticRole}:${op.title}`.toLowerCase();
      if (seenKeys.has(dedupeKey)) {
        failures.push({ type: 'duplicate-widget-op', message: `Collapsed duplicate op for ${op.title}` });
        continue;
      }
      seenKeys.add(dedupeKey);

      if (op.widgetType === 'mermaid-diagram' && !/(graph|flowchart|sequenceDiagram|classDiagram|erDiagram|stateDiagram)/i.test(op.payload.code || '')) {
        failures.push({ type: 'invalid-mermaid', message: `Repaired Mermaid diagram for ${op.title}` });
        op.payload.code = `graph TD;\n  Start["${op.title}"]-->Review["Review"];`;
      }

      if (op.widgetType === 'json' && !safeJsonParse(op.payload.source)) {
        failures.push({ type: 'invalid-json', message: `Wrapped invalid JSON payload for ${op.title}` });
        op.payload.source = JSON.stringify({ message: op.payload.source }, null, 2);
      }

      if (op.widgetType === 'csv' && !String(op.payload.source || '').includes('\n')) {
        failures.push({ type: 'invalid-csv', message: `Added CSV header row for ${op.title}` });
        op.payload.source = `value\n${op.payload.source}`;
      }

      repaired.push(op);
      continue;
    }

    repaired.push(op);
  }

  if ((sceneContext?.widgets || []).length && !repaired.some((op) => op.kind === 'upsert_widget')) {
    const firstWidget = sceneContext.widgets[0];
    repaired.push({
      kind: 'upsert_widget',
      widgetType: firstWidget.type || 'note',
      title: firstWidget.title || 'Canvas Update',
      semanticRole: firstWidget.role || 'general',
      positionHint: { index: 0, column: 0, row: 0 },
      payload: {
        title: firstWidget.title || 'Canvas Update',
      },
      placementIntent: {
        preferredZone: 'focus',
        relation: 'center',
        anchorRole: firstWidget.role || 'general',
        clusterKey: `${firstWidget.role || 'general'}-workspace`,
        preserveCluster: true,
      },
      contentSignature: signatureForContent([firstWidget.title, firstWidget.role]),
      canReuse: true,
      canExpand: true,
      importanceScore: 0.5,
    });
    failures.push({ type: 'empty-op-repair', message: 'Added a safe reuse/update op to keep the run productive.' });
  }

  return { sceneOps: repaired, failures };
}

function computeStats(sceneOps, sceneContext) {
  const existingTitles = new Set((sceneContext?.widgets || []).map((widget) => `${widget.kind || widget.type}:${widget.title || widget.type}`.toLowerCase()));
  const stats = {
    created: 0,
    reused: 0,
    connectors: 0,
    textCallouts: 0,
  };

  for (const op of sceneOps) {
    if (op.kind === 'compose_teaching_scene') {
      stats.created += 1;
    } else if (op.kind === 'upsert_widget') {
      const key = `${op.widgetType}:${op.title}`.toLowerCase();
      if (existingTitles.has(key)) stats.reused += 1;
      else stats.created += 1;
    } else if (op.kind === 'create_connector') {
      stats.connectors += 1;
    } else if (op.kind === 'create_text_callout') {
      stats.textCallouts += 1;
    }
  }

  return stats;
}

function buildFinalDiff(sceneOps, stats) {
  return {
    summary: `${stats.created} created, ${stats.reused} reused, ${stats.connectors} connectors, ${stats.textCallouts} callouts`,
    sceneOps,
    stats,
  };
}

function buildExecutionMessages(messages, sceneContext, plan) {
  return normalizeMessages(messages).concat([
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: [
            buildSceneContextMessage(sceneContext),
            `Planner output:\n${JSON.stringify(plan, null, 2)}`,
            'Use the plan above and respond through tool calls. Reuse matching widgets whenever possible.',
          ].join('\n\n'),
        },
      ],
    },
  ]);
}

async function executeCanvasAgentRun(runId) {
  const run = runs.get(runId);
  if (!run) return;

  const controller = new AbortController();
  runControllers.set(runId, controller);

  const provider = await loadCanvasAgentProvider();
  updateRun(runId, {
    status: 'planning',
    meta: {
      ...run.meta,
      provider: provider.provider,
      model: provider.model,
      source: provider.source,
    },
  });

  appendRunEvent(runId, 'status', { status: 'planning', label: 'Planning the canvas response' });
  appendRunEvent(runId, 'memory.append_episode', {
    summary: `Canvas request: ${extractLatestUserText(run.messages) || 'Untitled request'}`,
  });

  try {
    const plan = await buildTeacherPlan(provider, run.messages, run.sceneContext, controller.signal);
    updateRun(runId, { plan });
    appendRunEvent(runId, 'plan_started', { plan });
    appendRunEvent(runId, 'storyboard_ready', {
      goal: plan.goal,
      intent: plan.intent,
      teachingStrategy: plan.teaching_strategy,
      steps: plan.steps,
    });

    for (let index = 0; index < plan.steps.length; index += 1) {
      appendRunEvent(runId, 'plan_step', {
        step: plan.steps[index],
        index,
        state: 'queued',
      });
    }

    if (runs.get(runId)?.cancelRequested) {
      throw new Error('Run cancelled');
    }

    updateRun(runId, { status: 'executing' });
    appendRunEvent(runId, 'status', { status: 'executing', label: 'Generating structured canvas actions' });

    const executionMessages = buildExecutionMessages(run.messages, run.sceneContext, plan);
    let executorResult = null;

    try {
      executorResult = await streamProviderChatCompletion({
        provider,
        systemPrompt: EXECUTOR_SYSTEM_PROMPT,
        messages: executionMessages,
        tools: run.tools,
        maxTokens: Math.min(provider.maxTokens, 3600),
        temperature: provider.temperature,
        signal: controller.signal,
        onTextDelta: async (delta, fullText) => {
          updateRun(runId, { latestText: fullText });
          appendRunEvent(runId, 'agent_text_delta', { delta, content: fullText });
        },
      });
    } catch (streamErr) {
      appendRunEvent(runId, 'warning', {
        message: `Streaming failed, falling back to a single completion: ${streamErr.message}`,
      });
      executorResult = await createProviderChatCompletion({
        provider,
        systemPrompt: EXECUTOR_SYSTEM_PROMPT,
        messages: executionMessages,
        tools: run.tools,
        maxTokens: Math.min(provider.maxTokens, 3600),
        temperature: provider.temperature,
        signal: controller.signal,
      });
      const fullText = extractMessageText(executorResult.message) || '';
      if (fullText) {
        updateRun(runId, { latestText: fullText });
        appendRunEvent(runId, 'agent_text_delta', { delta: fullText, content: fullText });
      }
    }

    if (runs.get(runId)?.cancelRequested) {
      throw new Error('Run cancelled');
    }

    const latestUserText = extractLatestUserText(run.messages);
    const rawToolCalls = (executorResult?.message?.tool_calls || []).map((toolCall) => ({
      name: toolCall?.function?.name || '',
      function: toolCall.function,
    }));
    const normalizedToolCalls = normalizeToolCalls(rawToolCalls, run.tools, latestUserText, plan);
    const sceneOps = buildSceneOps(normalizedToolCalls, plan, run.sceneContext, latestUserText);
    const critiqued = criticRepairSceneOps(sceneOps, run.sceneContext);
    const stats = computeStats(critiqued.sceneOps, run.sceneContext);
    const finalDiff = buildFinalDiff(critiqued.sceneOps, stats);
    const finalText = extractMessageText(executorResult.message) || plan.teaching_strategy || 'I updated the canvas.';

    updateRun(runId, {
      status: 'validating',
      latestText: finalText,
    });
    appendRunEvent(runId, 'status', { status: 'validating', label: 'Validating and repairing canvas actions' });
    appendRunEvent(runId, 'validation_result', {
      valid: critiqued.failures.length === 0,
      warnings: critiqued.failures,
    });

    if (critiqued.failures.length) {
      appendRunEvent(runId, 'repair_started', {
        failures: critiqued.failures,
      });
    }

    for (let index = 0; index < normalizedToolCalls.length; index += 1) {
      if (normalizedToolCalls[index].name === 'compose_teaching_scene') {
        appendRunEvent(runId, 'slide_created', {
          index,
          topic: normalizedToolCalls[index].args?.topic || 'lesson',
          title: normalizedToolCalls[index].args?.title || 'Lesson',
        });
        appendRunEvent(runId, 'beat_started', {
          index: 0,
          action: 'introduce',
        });
      }
      appendRunEvent(runId, 'tool_call', {
        toolCall: normalizedToolCalls[index],
        index,
      });
      appendRunEvent(runId, 'tool_result', {
        toolCall: normalizedToolCalls[index],
        index,
        sceneOps: critiqued.sceneOps.filter((op) => {
          if (normalizedToolCalls[index].name === 'compose_teaching_scene') return op.kind === 'compose_teaching_scene';
          if (normalizedToolCalls[index].name === 'teach_concept') return op.kind === 'upsert_widget' && op.widgetType === 'note';
          if (normalizedToolCalls[index].name === 'draw_flowchart') return op.kind === 'upsert_widget' && op.widgetType === 'mermaid-diagram';
          if (normalizedToolCalls[index].name === 'show_data_structure') return op.kind === 'upsert_widget' && op.semanticRole === semanticRoleForToolCall('show_data_structure', normalizedToolCalls[index].args);
          if (normalizedToolCalls[index].name === 'write_code_example') return op.kind === 'upsert_widget' && op.widgetType === 'code';
          if (normalizedToolCalls[index].name === 'open_sql_workspace') return op.kind === 'upsert_widget' && op.widgetType === 'sql-pad';
          if (normalizedToolCalls[index].name === 'show_json_viewer') return op.kind === 'upsert_widget' && op.widgetType === 'json';
          if (normalizedToolCalls[index].name === 'show_csv_loader') return op.kind === 'upsert_widget' && op.widgetType === 'csv';
          if (normalizedToolCalls[index].name === 'show_progress') return op.kind === 'upsert_widget' && op.widgetType === 'progress';
          if (normalizedToolCalls[index].name === 'create_text_callout') return op.kind === 'create_text_callout';
          if (normalizedToolCalls[index].name === 'create_connector') return op.kind === 'create_connector';
          return false;
        }),
      });
    }

    for (const failure of critiqued.failures) {
      appendRunEvent(runId, 'warning', {
        message: failure.message,
        failure,
      });
    }

    const reflectionNotes = critiqued.failures.map((failure) => `${failure.type}: ${failure.message}`);

    updateRun(runId, {
      status: 'done',
      latestText: finalText,
      failures: critiqued.failures,
      reflectionNotes,
      finalDiff,
      stats,
    });
    appendRunEvent(runId, 'run_completed', {
      text: finalText,
      stats,
      finalDiff,
    });
    appendRunEvent(runId, 'done', {
      text: finalText,
      plan,
      toolCalls: normalizedToolCalls,
      finalDiff,
      meta: runs.get(runId)?.meta,
      stats,
    });
  } catch (err) {
    const isCancelled = runs.get(runId)?.cancelRequested || err.name === 'AbortError' || /cancel/i.test(err.message);
    updateRun(runId, {
      status: isCancelled ? 'cancelled' : 'error',
    });
    appendRunEvent(runId, isCancelled ? 'cancelled' : 'error', {
      message: err.message,
    });
  } finally {
    runControllers.delete(runId);
  }
}

async function detectVoiceRuntime() {
  const availableCli = DEFAULT_WHISPER_CLI_CANDIDATES.find(Boolean) || null;
  const modelPath = DEFAULT_WHISPER_MODEL_CANDIDATES.find(Boolean) || null;
  const cliResolvable = availableCli && (availableCli.includes('/') ? existsSync(availableCli) : true);
  const modelAvailable = modelPath ? existsSync(modelPath) : false;
  const ffmpegPath = process.env.CANVAS_AGENT_FFMPEG_PATH || process.env.FFMPEG_PATH || null;
  const ffmpegAvailable = ffmpegPath ? existsSync(ffmpegPath) : false;

  return {
    available: Boolean(cliResolvable && modelAvailable),
    cliPath: cliResolvable ? availableCli : null,
    modelPath: modelAvailable ? modelPath : null,
    ffmpegAvailable,
    ffmpegPath: ffmpegAvailable ? ffmpegPath : null,
    mode: 'push-to-talk',
    locales: ['en-IN', 'hi-IN', 'hinglish'],
    notes: cliResolvable && modelAvailable
      ? ['Local whisper.cpp runtime detected.']
      : ['Install whisper.cpp and set CANVAS_AGENT_WHISPER_CLI_PATH plus CANVAS_AGENT_WHISPER_MODEL_PATH to enable local transcription.'],
  };
}

function getTempAudioPath(fileName) {
  const safeExt = extname(fileName || '').toLowerCase() || '.wav';
  return resolve(RUNS_DIR, `${randomUUID()}${safeExt}`);
}

function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });
    child.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error(stderr || `Command failed with exit code ${code}`));
    });
  });
}

export async function getCanvasAgentMeta() {
  await ensureRunsLoaded();
  const provider = await loadCanvasAgentProvider();
  const voice = await detectVoiceRuntime();
  return {
    provider: provider.provider,
    model: provider.model,
    source: provider.source,
    pipeline: 'sessioned-planner-executor-validator',
    toolFamilies: TOOL_FAMILIES,
    capabilities: {
      planning: true,
      multimodalInput: true,
      widgetReuse: true,
      sceneOps: true,
      voice: voice.available,
      durableRuns: true,
      streaming: true,
      lessonDeck: true,
      pinTargeting: true,
      liveTyping: true,
      storyboardPlayback: true,
      exactBindings: true,
      primitiveTeachingSlides: true,
    },
    sceneVersion: 'v3',
    voice,
  };
}

export async function getCanvasAgentVoiceMeta() {
  return detectVoiceRuntime();
}

export async function createCanvasAgentRun({ userId, messages, tools, sceneContext }) {
  await ensureRunsLoaded();
  const provider = await loadCanvasAgentProvider();
  const voiceMeta = await detectVoiceRuntime();
  const activeRun = findActiveRunForScene(userId, sceneContext?.sceneId || null);
  if (activeRun) {
    appendRunEvent(activeRun.id, 'status', {
      status: activeRun.status,
      label: 'Reusing active run for this canvas',
    });
    return {
      ...summarizePublicRun(activeRun),
      reusedExisting: true,
    };
  }
  const run = createRunRecord({
    userId,
    messages,
    tools: Array.isArray(tools) && tools.length ? tools : DEFAULT_CANVAS_TOOLS,
    sceneContext: {
      ...(sceneContext || {}),
      humanReplaySummary: sceneContext?.humanReplaySummary || makeHumanReplaySummary(sceneContext),
    },
    providerMeta: provider,
    voiceMeta,
  });
  appendRunEvent(run.id, 'run_created', {
    status: run.status,
  });
  void executeCanvasAgentRun(run.id);
  return summarizePublicRun(run);
}

export async function getCanvasAgentRun(runId) {
  await ensureRunsLoaded();
  const run = runs.get(runId);
  return run ? summarizePublicRun(run) : null;
}

export async function cancelCanvasAgentRun(runId) {
  await ensureRunsLoaded();
  const run = runs.get(runId);
  if (!run) return null;
  updateRun(runId, { cancelRequested: true, status: 'cancelling' });
  const controller = runControllers.get(runId);
  if (controller) controller.abort(new Error('Run cancelled'));
  appendRunEvent(runId, 'status', {
    status: 'cancelling',
    label: 'Cancelling run',
  });
  return summarizePublicRun(runs.get(runId));
}

export async function streamCanvasAgentRunEvents({ runId, res, since = 0, onClose }) {
  await ensureRunsLoaded();
  const run = runs.get(runId);
  if (!run) {
    res.statusCode = 404;
    res.end('Run not found');
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const writeEvent = (event) => {
    res.write(`event: ${event.type}\n`);
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  const startIndex = Number.isFinite(Number(since)) ? Number(since) : 0;
  run.events.slice(startIndex).forEach(writeEvent);

  if (['done', 'error', 'cancelled'].includes(run.status)) {
    res.end();
    return;
  }

  const emitter = getRunEmitter(runId);
  const keepAlive = setInterval(() => {
    res.write(': keep-alive\n\n');
  }, 15000);

  const listener = (event) => {
    writeEvent(event);
    if (['done', 'error', 'cancelled'].includes(event.type)) {
      cleanup();
      res.end();
    }
  };

  const cleanup = () => {
    clearInterval(keepAlive);
    emitter.off('event', listener);
    if (typeof onClose === 'function') onClose();
  };

  emitter.on('event', listener);
  res.on('close', cleanup);
}

export async function transcribeCanvasAgentAudio({ file, prompt }) {
  const voice = await detectVoiceRuntime();
  if (!voice.available) {
    const error = new Error('Local Whisper runtime is not configured.');
    error.statusCode = 503;
    throw error;
  }

  if (!file?.buffer?.length) {
    const error = new Error('Audio file is required.');
    error.statusCode = 400;
    throw error;
  }

  const ext = extname(file.originalname || '').toLowerCase();
  if (ext && ext !== '.wav') {
    const error = new Error('Only WAV audio is supported until ffmpeg is configured for local conversion.');
    error.statusCode = 415;
    throw error;
  }

  const tempAudioPath = getTempAudioPath(file.originalname || 'recording.wav');
  await writeFile(tempAudioPath, file.buffer);
  try {
    const args = [
      '-m',
      voice.modelPath,
      '-f',
      tempAudioPath,
      '-otxt',
    ];

    if (prompt) {
      args.push('-p', prompt);
    }

    const result = await runCommand(voice.cliPath, args);
    const transcript = result.stdout.trim() || result.stderr.trim();
    return {
      text: transcript,
      promptApplied: Boolean(prompt),
      voice,
    };
  } finally {
    await unlink(tempAudioPath).catch(() => {});
  }
}

export async function runCanvasTeacherAgent({ userId, messages, tools, sceneContext }) {
  const run = await createCanvasAgentRun({ userId, messages, tools, sceneContext });

  while (true) {
    const current = await getCanvasAgentRun(run.id);
    if (!current) throw new Error('Run disappeared before completion.');
    if (['done', 'error', 'cancelled'].includes(current.status)) {
      const doneEvent = [...current.events].reverse().find((event) => event.type === 'done');
      if (current.status === 'done' && doneEvent) {
        return {
          role: 'assistant',
          text: doneEvent.text,
          toolCalls: doneEvent.toolCalls,
          plan: doneEvent.plan,
          meta: doneEvent.meta,
          stats: doneEvent.stats,
          finalDiff: doneEvent.finalDiff,
          runId: current.id,
        };
      }
      throw new Error(current.events[current.events.length - 1]?.message || `Run ended with status ${current.status}`);
    }
    await new Promise((resolve) => setTimeout(resolve, 120));
  }
}
