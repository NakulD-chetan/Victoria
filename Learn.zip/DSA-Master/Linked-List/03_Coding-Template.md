# Linked List — Coding Template

> **Permanent Recall:** Master 8 templates: Node definition, Reverse, Fast/Slow (middle + cycle), Merge sorted, Remove Nth from end, Dummy head pattern, Reverse sublist, Reorder list. These cover 90% of FAANG linked list problems.

---

## Template 0: Node Definition

### Python

```python
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = valcurr
        self.next = next
```

### C++

```cpp
struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};
```

### Rust

```rust
#[derive(Debug)]
pub struct ListNode {
    pub val: i32,
    pub next: Option<Box<ListNode>>,
}

impl ListNode {
    pub fn new(val: i32) -> Self {
        ListNode { val, next: None }
    }
}
```

---

## Template 1: Reverse Linked List (Iterative)

### Python

```python
def reverse_list(head):
    prev = None
    curr = head
    while curr:
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node
    return prev
```

### C++

```cpp
ListNode* reverseList(ListNode* head) {
    ListNode* prev = nullptr;
    ListNode* curr = head;
    while (curr) {
        ListNode* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}
```

### Rust

```rust
pub fn reverse_list(head: Option<Box<ListNode>>) -> Option<Box<ListNode>> {
    let mut prev = None;
    let mut curr = head;
    while let Some(mut node) = curr {
        curr = node.next.take();
        node.next = prev;
        prev = Some(node);
    }
    prev
}
```

---

## Template 2: Reverse Linked List (Recursive)

### Python

```python
def reverse_list_recursive(head):
    if not head or not head.next:
        return head
    new_head = reverse_list_recursive(head.next)
    head.next.next = head
    head.next = None
    return new_head
```

### C++

```cpp
ListNode* reverseListRecursive(ListNode* head) {
    if (!head || !head->next) return head;
    ListNode* newHead = reverseListRecursive(head->next);
    head->next->next = head;
    head->next = nullptr;
    return newHead;
}
```

---

## Template 3: Find Middle (Fast & Slow)

### Python

```python
def find_middle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
    return slow  # middle (for odd: exact mid, for even: second mid)
```

### C++

```cpp
ListNode* findMiddle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}
```

### Rust

```rust
// Due to ownership rules, typically use length-based approach
// or work with references carefully
pub fn find_middle_index(head: &Option<Box<ListNode>>) -> usize {
    let mut len = 0;
    let mut curr = head;
    while let Some(node) = curr {
        len += 1;
        curr = &node.next;
    }
    len / 2
}
```

---

## Template 4: Detect Cycle (Floyd's Algorithm)

### Python

```python
def has_cycle(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            return True
    return False

def find_cycle_start(head):
    slow = fast = head
    while fast and fast.next:
        slow = slow.next
        fast = fast.next.next
        if slow == fast:
            slow = head
            while slow != fast:
                slow = slow.next
                fast = fast.next
            return slow
    return None
```

### C++

```cpp
bool hasCycle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) return true;
    }
    return false;
}

ListNode* detectCycle(ListNode* head) {
    ListNode* slow = head;
    ListNode* fast = head;
    while (fast && fast->next) {
        slow = slow->next;
        fast = fast->next->next;
        if (slow == fast) {
            slow = head;
            while (slow != fast) {
                slow = slow->next;
                fast = fast->next;
            }
            return slow;
        }
    }
    return nullptr;
}
```

---

## Template 5: Merge Two Sorted Lists

### Python

```python
def merge_two_lists(l1, l2):
    dummy = ListNode(0)
    curr = dummy
    while l1 and l2:
        if l1.val <= l2.val:
            curr.next = l1
            l1 = l1.next
        else:
            curr.next = l2
            l2 = l2.next
        curr = curr.next
    curr.next = l1 or l2
    return dummy.next
```

### C++

```cpp
ListNode* mergeTwoLists(ListNode* l1, ListNode* l2) {
    ListNode dummy(0);
    ListNode* curr = &dummy;
    while (l1 && l2) {
        if (l1->val <= l2->val) {
            curr->next = l1;
            l1 = l1->next;
        } else {
            curr->next = l2;
            l2 = l2->next;
        }
        curr = curr->next;
    }
    curr->next = l1 ? l1 : l2;
    return dummy.next;
}
```

### Rust

```rust
pub fn merge_two_lists(
    l1: Option<Box<ListNode>>,
    l2: Option<Box<ListNode>>,
) -> Option<Box<ListNode>> {
    match (l1, l2) {
        (None, None) => None,
        (Some(n), None) | (None, Some(n)) => Some(n),
        (Some(mut n1), Some(mut n2)) => {
            if n1.val <= n2.val {
                n1.next = merge_two_lists(n1.next, Some(n2));
                Some(n1)
            } else {
                n2.next = merge_two_lists(Some(n1), n2.next);
                Some(n2)
            }
        }
    }
}
```

---

## Template 6: Remove Nth Node From End

### Python

```python
def remove_nth_from_end(head, n):
    dummy = ListNode(0, head)
    slow = fast = dummy
    for _ in range(n + 1):
        fast = fast.next
    while fast:
        slow = slow.next
        fast = fast.next
    slow.next = slow.next.next
    return dummy.next
```

### C++

```cpp
ListNode* removeNthFromEnd(ListNode* head, int n) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* slow = &dummy;
    ListNode* fast = &dummy;
    for (int i = 0; i <= n; i++)
        fast = fast->next;
    while (fast) {
        slow = slow->next;
        fast = fast->next;
    }
    ListNode* toDelete = slow->next;
    slow->next = slow->next->next;
    delete toDelete;
    return dummy.next;
}
```

---

## Template 7: Reverse Sublist (Between Positions)

### Python

```python
def reverse_between(head, left, right):
    dummy = ListNode(0, head)
    prev = dummy
    for _ in range(left - 1):
        prev = prev.next
    
    curr = prev.next
    for _ in range(right - left):
        next_node = curr.next
        curr.next = next_node.next
        next_node.next = prev.next
        prev.next = next_node
    
    return dummy.next
```

### C++

```cpp
ListNode* reverseBetween(ListNode* head, int left, int right) {
    ListNode dummy(0);
    dummy.next = head;
    ListNode* prev = &dummy;
    for (int i = 0; i < left - 1; i++)
        prev = prev->next;
    
    ListNode* curr = prev->next;
    for (int i = 0; i < right - left; i++) {
        ListNode* nextNode = curr->next;
        curr->next = nextNode->next;
        nextNode->next = prev->next;
        prev->next = nextNode;
    }
    return dummy.next;
}
```

---

## Template 8: Reorder List (L0→Ln→L1→Ln-1→...)

### Python

```python
def reorder_list(head):
    if not head or not head.next:
        return
    
    # Step 1: Find middle
    slow = fast = head
    while fast.next and fast.next.next:
        slow = slow.next
        fast = fast.next.next
    
    # Step 2: Reverse second half
    second = slow.next
    slow.next = None
    prev = None
    while second:
        next_node = second.next
        second.next = prev
        prev = second
        second = next_node
    second = prev
    
    # Step 3: Interleave
    first = head
    while second:
        tmp1, tmp2 = first.next, second.next
        first.next = second
        second.next = tmp1
        first = tmp1
        second = tmp2
```

### C++

```cpp
void reorderList(ListNode* head) {
    if (!head || !head->next) return;
    
    // Find middle
    ListNode* slow = head;
    ListNode* fast = head;
    while (fast->next && fast->next->next) {
        slow = slow->next;
        fast = fast->next->next;
    }
    
    // Reverse second half
    ListNode* second = slow->next;
    slow->next = nullptr;
    ListNode* prev = nullptr;
    while (second) {
        ListNode* next = second->next;
        second->next = prev;
        prev = second;
        second = next;
    }
    second = prev;
    
    // Interleave
    ListNode* first = head;
    while (second) {
        ListNode* tmp1 = first->next;
        ListNode* tmp2 = second->next;
        first->next = second;
        second->next = tmp1;
        first = tmp1;
        second = tmp2;
    }
}
```

---

## Template 9: Merge K Sorted Lists (Divide & Conquer)

### Python

```python
def merge_k_lists(lists):
    if not lists:
        return None
    
    while len(lists) > 1:
        merged = []
        for i in range(0, len(lists), 2):
            l1 = lists[i]
            l2 = lists[i + 1] if i + 1 < len(lists) else None
            merged.append(merge_two_lists(l1, l2))
        lists = merged
    
    return lists[0]
```

### C++

```cpp
ListNode* mergeKLists(vector<ListNode*>& lists) {
    if (lists.empty()) return nullptr;
    int n = lists.size();
    while (n > 1) {
        for (int i = 0; i < n / 2; i++)
            lists[i] = mergeTwoLists(lists[i], lists[n - 1 - i]);
        n = (n + 1) / 2;
    }
    return lists[0];
}
```

---

## 30-Second Revision Box

```
┌──────────────────────────────────────────────────────────────┐
│  REVERSE:    prev=None, curr=head; rewire curr.next=prev    │
│  MIDDLE:     slow=fast=head; fast moves 2x                  │
│  CYCLE:      fast==slow → cycle; reset to head → entry      │
│  MERGE:      dummy head, compare, attach smaller            │
│  NTH END:    two ptrs, n+1 gap, move together               │
│  SUBLIST:    find prev, then repeatedly move next to front   │
│  REORDER:    middle → reverse half → interleave             │
│  MERGE K:    pairwise merge, divide & conquer O(N log k)    │
└──────────────────────────────────────────────────────────────┘
```

---

## Language Comparison


| Operation     | Python          | C++                 | Rust                              |
| ------------- | --------------- | ------------------- | --------------------------------- |
| Node creation | `ListNode(val)` | `new ListNode(val)` | `Box::new(ListNode::new(val))`    |
| Null check    | `if not node`   | `if (!node)`        | `if let Some(n) = node`           |
| Next access   | `node.next`     | `node->next`        | `node.next.take()` / `&node.next` |
| Memory        | GC handles      | Manual / smart ptr  | Ownership system                  |
| Difficulty    | Easy            | Medium              | Hard (ownership)                  |


---

## FINAL MEMORY COMPRESSION BLOCK

```
9 TEMPLATES: Node def, Reverse(iter), Reverse(recur), Middle,
             Cycle, Merge2, RemoveNth, ReverseSublist, Reorder
REVERSE: prev/curr/next dance — O(n) time O(1) space
FAST/SLOW: middle + cycle — most versatile pattern
MERGE: dummy + compare — foundation for merge K
NTH END: two-pointer gap technique
REORDER: combines middle + reverse + interleave (composite)
MERGE K: pairwise merge O(N log k)
```

