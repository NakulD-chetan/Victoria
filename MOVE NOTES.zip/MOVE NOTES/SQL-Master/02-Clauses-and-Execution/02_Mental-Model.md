# Clauses and Execution — Mental Model

---

## Assembly line

```
FROM/JOIN  →  WHERE  →  GROUP BY  →  HAVING  →  SELECT  →  ORDER  →  LIMIT
   ↑            ↑           ↑            ↑
 raw rows    row-level   buckets     group-level
```

**Analogy (Hinglish):** pehle **dhoodh lo** (`FROM`), **kaachra hatao** (`WHERE`), phir **dabboo mein baanto** (`GROUP BY`), phir **dabbo filter karo** (`HAVING`), phir **dikhao** (`SELECT`).

---

## Why WHERE ≠ window aliases

Window functions compute in `SELECT` phase; `WHERE` runs earlier → **no window in WHERE** (use subquery/CTE).

---

## NULL in predicates

- `WHERE col = NULL` is wrong → use `IS NULL`.
- Three-valued logic: `TRUE`, `FALSE`, **UNKNOWN** (often filtered out in `WHERE`).

---

*Next: [[03_Coding-Template]]*
