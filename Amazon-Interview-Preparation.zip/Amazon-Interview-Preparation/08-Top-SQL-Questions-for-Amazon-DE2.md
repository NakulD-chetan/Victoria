# Top SQL Questions for Amazon DE2 - Interview Answer Format

## One-Line Goal

Amazon DE2 SQL rounds test whether you can solve practical analytics and ETL problems with correct joins, clean window functions, and clear reasoning.

---

## How to Answer SQL Questions in Interviews

Use this structure:

1. Clarify table grain and expected output
2. Explain the pattern before writing SQL
3. Write the query cleanly
4. Mention edge cases
5. Mention performance or follow-up improvements

### Strong opening line

> "Before I write the query, I want to confirm the grain of each table and the exact output we want, because that affects join correctness and whether I should use aggregation or window functions."

---

## What Interviewers Usually Test

- joins
- `GROUP BY` and `HAVING`
- window functions
- deduplication
- ranking
- running totals
- date logic
- data quality checks

They care about:

- correctness
- readability
- edge cases
- performance awareness

---

## 1. Deduplicate Records

### Common prompt

Find the latest record for each `customer_id`.

### What to say first

> "This is a deduplication problem, so I would rank rows within each customer and keep only the latest one."

### Pattern

```sql
WITH ranked AS (
    SELECT
        customer_id,
        updated_at,
        status,
        ROW_NUMBER() OVER (
            PARTITION BY customer_id
            ORDER BY updated_at DESC
        ) AS rn
    FROM customer_status
)
SELECT
    customer_id,
    updated_at,
    status
FROM ranked
WHERE rn = 1;
```

### Follow-up points

- common in CDC and current-state tables
- ask what to do if timestamps tie

---

## 2. Top N Per Group

### Common prompt

Find the top 3 products by revenue in each category.

### What to say first

> "I would aggregate first, then rank within each category, and finally keep the top 3."

### Pattern

```sql
WITH revenue_by_product AS (
    SELECT
        category,
        product_id,
        SUM(revenue) AS total_revenue
    FROM sales
    GROUP BY category, product_id
),
ranked AS (
    SELECT
        category,
        product_id,
        total_revenue,
        DENSE_RANK() OVER (
            PARTITION BY category
            ORDER BY total_revenue DESC
        ) AS product_rank
    FROM revenue_by_product
)
SELECT
    category,
    product_id,
    total_revenue
FROM ranked
WHERE product_rank <= 3;
```

### Watch out

- `ROW_NUMBER()` vs `RANK()` vs `DENSE_RANK()`

---

## 3. Running Total

### Common prompt

Find daily revenue and cumulative revenue over time.

### What to say first

> "I would first aggregate at the day level, then use a running window sum ordered by date."

### Pattern

```sql
WITH daily AS (
    SELECT
        order_date,
        SUM(revenue) AS daily_revenue
    FROM orders
    GROUP BY order_date
)
SELECT
    order_date,
    daily_revenue,
    SUM(daily_revenue) OVER (
        ORDER BY order_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_revenue
FROM daily
ORDER BY order_date;
```

---

## 4. Rolling Average

### Common prompt

Compute a 7-day moving average of order count.

### What to say first

> "This is a window-frame problem. I would aggregate by day first, then average over the current day plus the previous 6 rows."

### Pattern

```sql
WITH daily_orders AS (
    SELECT
        order_date,
        COUNT(*) AS order_count
    FROM orders
    GROUP BY order_date
)
SELECT
    order_date,
    order_count,
    AVG(order_count) OVER (
        ORDER BY order_date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ) AS moving_avg_7d
FROM daily_orders
ORDER BY order_date;
```

---

## 5. Join Multiple Tables Correctly

### Common prompt

Find total revenue by customer segment.

### What to say first

> "Before writing the query, I would confirm the grain of `orders` and `customers`, then choose the join type based on whether unmatched customers should be kept."

### Pattern

```sql
SELECT
    c.segment,
    SUM(o.revenue) AS total_revenue
FROM orders o
JOIN customers c
    ON o.customer_id = c.customer_id
GROUP BY c.segment
ORDER BY total_revenue DESC;
```

### Watch out

- wrong join type
- row multiplication due to bad cardinality assumptions

---

## 6. Find Missing Records

### Common prompt

Find customers who placed no orders in the last 30 days.

### What to say first

> "This is an anti-join pattern, so I would left join the recent orders and keep rows where the join is missing."

### Pattern

```sql
SELECT
    c.customer_id
FROM customers c
LEFT JOIN orders o
    ON c.customer_id = o.customer_id
   AND o.order_date >= CURRENT_DATE - INTERVAL '30 days'
WHERE o.customer_id IS NULL;
```

---

## 7. Percent of Total

### Common prompt

Find each category's percent contribution to total revenue.

### What to say first

> "I would aggregate revenue per category and then divide by the grand total using a window over the full result set."

### Pattern

```sql
WITH category_revenue AS (
    SELECT
        category,
        SUM(revenue) AS total_revenue
    FROM sales
    GROUP BY category
)
SELECT
    category,
    total_revenue,
    100.0 * total_revenue / SUM(total_revenue) OVER () AS pct_of_total
FROM category_revenue
ORDER BY total_revenue DESC;
```

---

## 8. Sessionization

### Common prompt

Mark a new session if the gap between events is more than 30 minutes.

### What to say first

> "I would use `LAG()` to compare each event to the previous event for the same user, flag session boundaries, and then compute a running sum of those flags."

### Pattern

```sql
WITH ordered_events AS (
    SELECT
        user_id,
        event_time,
        LAG(event_time) OVER (
            PARTITION BY user_id
            ORDER BY event_time
        ) AS prev_event_time
    FROM events
),
flagged AS (
    SELECT
        user_id,
        event_time,
        CASE
            WHEN prev_event_time IS NULL THEN 1
            WHEN event_time > prev_event_time + INTERVAL '30 minutes' THEN 1
            ELSE 0
        END AS new_session_flag
    FROM ordered_events
),
sessionized AS (
    SELECT
        user_id,
        event_time,
        SUM(new_session_flag) OVER (
            PARTITION BY user_id
            ORDER BY event_time
            ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        ) AS session_id
    FROM flagged
)
SELECT *
FROM sessionized;
```

---

## 9. Data Quality Query

### Common prompt

Find duplicate `order_id` values.

### What to say first

> "This is a simple data quality check, so I would group by the key and filter groups with count greater than 1."

### Pattern

```sql
SELECT
    order_id,
    COUNT(*) AS duplicate_count
FROM orders
GROUP BY order_id
HAVING COUNT(*) > 1;
```

### Also common

- null checks
- invalid ranges
- orphan foreign keys
- volume drops

---

## 10. SCD Type 2 Logic

### Common prompt

Find the active record for each customer.

### What to say first

> "If this is an SCD Type 2 dimension, the active version is usually the record whose end date is null."

### Pattern

```sql
SELECT
    customer_id,
    customer_key,
    city,
    segment
FROM dim_customer
WHERE effective_to IS NULL;
```

### Follow-up they may ask

- how do you close the old row?
- how do you insert the new row?
- why use a surrogate key?

---

## Practice Questions

1. Find the second highest salary in each department
2. Find users active on 3 consecutive days
3. Find month-over-month growth in revenue
4. Find the latest status for each shipment
5. Find the percentage of failed jobs per pipeline
6. Find duplicate events received within 5 minutes
7. Find customers whose spend is above their segment average
8. Find top 5 sellers by region and month

---

## Common Mistakes

1. Using `WHERE` instead of `HAVING` after aggregation
2. Forgetting `PARTITION BY` in window functions
3. Misunderstanding table grain
4. Multiplying rows accidentally with joins
5. Ignoring ties
6. Ignoring null handling

---

## Performance Tips You Can Mention

- filter early where possible
- avoid unnecessary `SELECT *`
- aggregate before joining if it reduces data size
- know when a join can multiply rows
- explain assumptions when schema details are missing

---

## Interview Tips

- Talk through the pattern before writing the full SQL
- Clarify table grain first
- Mention edge cases like nulls, duplicates, ties, and missing dates
- If short on time, write the correct query first and optimize second

---

## Quick Revision (5 points)

1. Clarify table grain and desired output before writing SQL
2. Explain the pattern first, then write the query
3. `ROW_NUMBER()`, ranking, `LAG()`, and running windows are must-know
4. Good SQL answers handle joins, ties, duplicates, and nulls carefully
5. Explain your reasoning, not only the final query
