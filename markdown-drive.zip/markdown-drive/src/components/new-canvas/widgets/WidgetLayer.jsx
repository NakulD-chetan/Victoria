import { memo, useMemo, useCallback, useRef } from 'react';
import { useNewCanvasStore } from '../state/store';
import { screenFromWorld, worldFromClient } from '../engine/coords';
import { translateElement } from '../engine/hit-test';
import { resolveSceneBindings } from '../engine/binding-engine';
import CodeWidget from './CodeWidget';
import SqlPadWidget from './SqlPadWidget';
import NoteWidget from './NoteWidget';
import ArrayWidget from './ArrayWidget';
import AgentWidget from './AgentWidget';
import JsonViewerWidget from './JsonViewerWidget';
import CsvLoaderWidget from './CsvLoaderWidget';
import DataStructureWidget from './DataStructureWidget';
import MermaidWidget from './MermaidWidget';
import CalculatorWidget from './CalculatorWidget';
import FileConverterWidget from './FileConverterWidget';
import ProgressWidget from './ProgressWidget';
import { computeWidgetLayoutScale } from './widget-layout-scale';

/**
 * WidgetLayer positions widget DOM shells absolutely above the canvas.
 *
 * CRITICAL contract (pointer-events):
 *   - Layer root + shells use pointer-events: none so the canvas receives
 *     draws when the pointer is not on a real control.
 *   - Headers / editors opt in with pointer-events: auto (see new-canvas.css).
 *
 * Widget **move** is normally driven by the canvas select tool, but those
 * pointer events never reach the canvas when the user grabs the header
 * (DOM is above the canvas). So we bridge drags from [data-nc-drag-handle]
 * here — same math as select-tool move, only when tool === 'select'.
 */

const REGISTRY = {
  code: CodeWidget,
  'sql-pad': SqlPadWidget,
  note: NoteWidget,
  array: ArrayWidget,
  json: JsonViewerWidget,
  csv: CsvLoaderWidget,
  'linked-list': DataStructureWidget,
  stack: DataStructureWidget,
  queue: DataStructureWidget,
  tree: DataStructureWidget,
  'hash-map': DataStructureWidget,
  agent: AgentWidget,
  'mermaid-diagram': MermaidWidget,
  calculator: CalculatorWidget,
  'file-converter': FileConverterWidget,
  progress: ProgressWidget,
};

/** Clicks on these targets should not start a frame drag. */
function isInteractiveDragExclusion(target) {
  if (!target || !target.closest) return true;
  return !!target.closest(
    'button, select, input, textarea, a, summary, [contenteditable], .monaco-editor, .monaco-scrollable-element, .nc-note__swatch, .nc-agent__chip, .nc-agent__send',
  );
}

function WidgetShellItem({ el, Comp, viewport }) {
  const dragRef = useRef(null);
  const selection = useNewCanvasStore((s) => s.selection);
  const pinnedTarget = useNewCanvasStore((s) => s.scenes[s.activeId]?.pinnedTarget || null);
  const setPinnedTarget = useNewCanvasStore((s) => s.setPinnedTarget);
  const isSelected = selection?.has?.(el.id);
  const isPinned = pinnedTarget?.elementId === el.id;

  const onPointerDownCapture = useCallback(
    (e) => {
      if (e.button !== 0) return;
      const store = useNewCanvasStore.getState();
      if (store.tool !== 'select') return;
      if (isInteractiveDragExclusion(e.target)) return;
      if (!e.target.closest('[data-nc-drag-handle]')) return;

      const shell = e.currentTarget;
      const stage = shell.closest('.nc-stage');
      const canvasEl = stage?.querySelector('.nc-canvas--interactive');
      if (!canvasEl) return;

      const scene = store.scenes[store.activeId];
      if (!scene) return;
      const vp = scene.viewport || { zoom: 1, panX: 0, panY: 0 };

      const { x: wx0, y: wy0 } = worldFromClient(e.clientX, e.clientY, canvasEl, vp);

      const sel = store.selection;
      const ids = sel.has(el.id) && sel.size > 0 ? [...sel] : [el.id];
      const originals = new Map();
      for (const id of ids) {
        const elem = scene.elements.find((x) => x.id === id && !x.isDeleted);
        if (elem) originals.set(id, elem);
      }
      if (originals.size === 0) return;

      e.preventDefault();
      e.stopPropagation();
      shell.setPointerCapture(e.pointerId);

      if (!sel.has(el.id) || sel.size === 0) {
        store.setSelection(new Set([el.id]));
      }

      const preMoveElements = scene.elements;
      const pointerId = e.pointerId;
      const coalesceKey = `widget-drag:${[...originals.keys()].sort().join(',')}`;

      dragRef.current = { originals, wx0, wy0, preMoveElements, pointerId, coalesceKey };

      const onMove = (ev) => {
        const d = dragRef.current;
        if (!d || ev.pointerId !== d.pointerId) return;
        const st = useNewCanvasStore.getState();
        const sc = st.scenes[st.activeId];
        if (!sc) return;
        const v = sc.viewport || { zoom: 1, panX: 0, panY: 0 };
        const { x, y } = worldFromClient(ev.clientX, ev.clientY, canvasEl, v);
        const dx = x - d.wx0;
        const dy = y - d.wy0;
        const moved = sc.elements.map((elem) => {
          if (!d.originals.has(elem.id)) return elem;
          return translateElement(d.originals.get(elem.id), dx, dy);
        });
        const next = resolveSceneBindings(moved);
        st.commitElements(next, { transient: true, coalesceKey: d.coalesceKey });
      };

      const onUp = (ev) => {
        const d = dragRef.current;
        if (!d || ev.pointerId !== d.pointerId) return;
        dragRef.current = null;
        try {
          shell.releasePointerCapture(ev.pointerId);
        } catch (_) { /* ignore */ }
        shell.removeEventListener('pointermove', onMove);
        shell.removeEventListener('pointerup', onUp);
        shell.removeEventListener('pointercancel', onUp);
        const st = useNewCanvasStore.getState();
        const sc = st.scenes[st.activeId];
        if (sc) st.commitGesture(d.preMoveElements, sc.elements);
      };

      shell.addEventListener('pointermove', onMove);
      shell.addEventListener('pointerup', onUp);
      shell.addEventListener('pointercancel', onUp);
    },
    [el.id],
  );

  const topLeft = screenFromWorld(el.x, el.y, viewport);
  const layoutScale = useMemo(
    () => computeWidgetLayoutScale(el.widgetType, el.w, el.h),
    [el.widgetType, el.w, el.h],
  );

  return (
    <div
      className={`nc-widget-shell${el.widgetData?.agentSpawnId ? ' nc-widget-shell--spawn' : ''}${el.widgetData?.agentMoveId ? ' nc-widget-shell--agent-move' : ''}`}
      style={{
        position: 'absolute',
        left: topLeft.x,
        top: topLeft.y,
        width: el.w,
        height: el.h,
        transform: `scale(${viewport.zoom})`,
        transformOrigin: 'top left',
        pointerEvents: 'none',
        ['--nc-widget-scale']: String(layoutScale),
        ['--nc-widget-spawn-delay']: `${el.widgetData?.spawnDelayMs || 0}ms`,
        ['--nc-widget-move-delay']: `${el.widgetData?.moveDelayMs || 0}ms`,
      }}
      onPointerDownCapture={onPointerDownCapture}
    >
      {isSelected ? (
        <button
          type="button"
          className={`nc-widget-shell__pin${isPinned ? ' is-pinned' : ''}`}
          onPointerDown={(event) => {
            event.preventDefault();
            event.stopPropagation();
          }}
          onClick={(event) => {
            event.preventDefault();
            event.stopPropagation();
            setPinnedTarget({
              elementId: el.id,
              widgetType: el.widgetType,
              title: el.widgetData?.title || el.widgetType,
              role: el.widgetData?.agentMeta?.semanticRole || 'general',
              lessonPageId: el.customData?.lessonPageId || null,
            });
          }}
          title={isPinned ? 'Pinned for agent updates' : 'Pin for the next agent update'}
          aria-label={isPinned ? 'Pinned for agent updates' : 'Pin for the next agent update'}
        >
          {isPinned ? 'Pinned' : 'Pin'}
        </button>
      ) : null}
      <Comp element={el} />
    </div>
  );
}

function WidgetLayerImpl() {
  const scenes = useNewCanvasStore((s) => s.scenes);
  const activeId = useNewCanvasStore((s) => s.activeId);
  const scene = scenes[activeId];

  const { elements, viewport } = useMemo(
    () => ({
      elements: scene?.elements || [],
      viewport: scene?.viewport || { zoom: 1, panX: 0, panY: 0 },
    }),
    [scene],
  );

  return (
    <div className="nc-widget-layer" aria-hidden={false}>
      {elements.map((el) => {
        if (el.isDeleted || el.type !== 'widget') return null;
        const Comp = REGISTRY[el.widgetType];
        if (!Comp) return null;
        return <WidgetShellItem key={el.id} el={el} Comp={Comp} viewport={viewport} />;
      })}
    </div>
  );
}

export default memo(WidgetLayerImpl);
