let _seed = 1000;
export function nextSeed() { return _seed++; }
export function uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }

/** Neutrals that contrast with light vs dark app chrome (avoids #1e1e1e on dark bg). */
export function canvasStrokePalette(isDark) {
  return {
    stroke: isDark ? '#e2e8f0' : '#1e293b',
    text: isDark ? '#f1f5f9' : '#0f172a',
    muted: isDark ? '#94a3b8' : '#64748b',
  };
}

export function rect(x, y, w, h, opts = {}) {
  return {
    id: uid(), type: 'rectangle',
    x, y, width: w, height: h, angle: 0,
    strokeColor: opts.stroke || '#1e293b',
    backgroundColor: opts.bg || 'transparent',
    fillStyle: opts.fill || 'solid',
    strokeWidth: opts.sw || 1, strokeStyle: 'solid',
    roughness: opts.rough ?? 0, opacity: 100,
    roundness: opts.roundness ?? { type: 3, value: 4 },
    seed: nextSeed(), version: 1, versionNonce: nextSeed(),
    isDeleted: false, groupIds: opts.group ? [opts.group] : [],
    boundElements: null, updated: Date.now(), link: null, locked: false,
    frameId: null, index: null,
  };
}

export function text(x, y, content, opts = {}) {
  const fontSize = opts.fontSize || 16;
  return {
    id: uid(), type: 'text',
    x, y, width: content.length * fontSize * 0.55, height: fontSize * 1.4,
    angle: 0, strokeColor: opts.color || '#1e293b',
    backgroundColor: 'transparent', fillStyle: 'solid',
    strokeWidth: 1, strokeStyle: 'solid',
    roughness: 0, opacity: 100, roundness: null,
    seed: nextSeed(), version: 1, versionNonce: nextSeed(),
    isDeleted: false, groupIds: opts.group ? [opts.group] : [],
    boundElements: null, updated: Date.now(), link: null, locked: false,
    frameId: null, index: null,
    text: content, fontSize, fontFamily: 1,
    textAlign: opts.align || 'center', verticalAlign: 'middle',
    containerId: null, originalText: content, autoResize: true,
    lineHeight: 1.25,
  };
}

function arrow(points, opts = {}) {
  const [sx, sy] = points[0];
  const mappedPoints = points.map(([px, py]) => [px - sx, py - sy]);
  const last = mappedPoints[mappedPoints.length - 1];
  return {
    id: uid(), type: 'arrow',
    x: sx, y: sy, width: Math.abs(last[0]), height: Math.abs(last[1]),
    angle: 0, strokeColor: opts.stroke || '#1e293b',
    backgroundColor: 'transparent', fillStyle: 'solid',
    strokeWidth: opts.sw || 1, strokeStyle: 'solid',
    roughness: 0, opacity: 100, roundness: { type: 2 },
    seed: nextSeed(), version: 1, versionNonce: nextSeed(),
    isDeleted: false, groupIds: opts.group ? [opts.group] : [],
    boundElements: null, updated: Date.now(), link: null, locked: false,
    frameId: null, index: null,
    points: mappedPoints,
    lastCommittedPoint: null, startBinding: null, endBinding: null,
    startArrowhead: opts.startHead || null,
    endArrowhead: opts.endHead ?? 'arrow',
    elbowed: false,
  };
}

function line(points, opts = {}) {
  const [sx, sy] = points[0];
  const mappedPoints = points.map(([px, py]) => [px - sx, py - sy]);
  const last = mappedPoints[mappedPoints.length - 1];
  return {
    id: uid(), type: 'line',
    x: sx, y: sy, width: Math.abs(last[0]), height: Math.abs(last[1]),
    angle: 0, strokeColor: opts.stroke || '#aaa',
    backgroundColor: 'transparent', fillStyle: 'solid',
    strokeWidth: opts.sw || 1, strokeStyle: opts.lineStyle || 'solid',
    roughness: 0, opacity: 100, roundness: { type: 2 },
    seed: nextSeed(), version: 1, versionNonce: nextSeed(),
    isDeleted: false, groupIds: opts.group ? [opts.group] : [],
    boundElements: null, updated: Date.now(), link: null, locked: false,
    frameId: null, index: null,
    points: mappedPoints,
    lastCommittedPoint: null, startBinding: null, endBinding: null,
    startArrowhead: null, endArrowhead: null,
  };
}

export function makeArray(size = 5, palette = canvasStrokePalette(false)) {
  const { stroke, text, muted } = palette;
  const g = uid();
  const cellW = 66;
  const cellH = 45;
  const gap = 23;
  const padX = 27;
  const padTop = 24;
  const padBottom = 24;
  const outerW = padX * 2 + size * cellW + (size - 1) * gap;
  const outerH = padTop + cellH + padBottom;
  const values = Array.from({ length: size }, (_, i) => String((i + 1) * 10));
  const elements = [];
  elements.push(rect(0, 0, outerW, outerH, {
    group: g,
    bg: 'transparent',
    fill: 'solid',
    stroke,
    sw: 2,
    rough: 1,
    roundness: { type: 3 },
  }));
  for (let i = 0; i < size; i++) {
    const x = padX + i * (cellW + gap);
    const y = padTop;
    elements.push(rect(x, y, cellW, cellH, {
      group: g,
      bg: 'transparent',
      fill: 'solid',
      stroke,
      sw: 2,
      rough: 1,
      roundness: { type: 3 },
    }));
    elements.push(text(x + cellW / 2 - 8, y + 12, values[i], {
      group: g,
      fontSize: 18,
      color: text,
    }));
    elements.push(text(x + cellW / 2 - 3, y + cellH + 7, String(i), {
      group: g,
      fontSize: 11,
      color: muted,
    }));
  }
  return { elements, groupId: g, size };
}

export function makeLinkedList(size = 4) {
  const g = uid();
  const nodeW = 80, nodeH = 40, gap = 40;
  const elements = [];
  for (let i = 0; i < size; i++) {
    const x = i * (nodeW + gap);
    elements.push(rect(x, 0, nodeW, nodeH, { group: g, bg: '#b2f2bb', fill: 'solid', stroke: '#2f9e44' }));
    elements.push(text(x + 8, 10, 'data', { group: g, fontSize: 13, color: '#2f9e44' }));
    elements.push(line([[x + nodeW * 0.6, 0], [x + nodeW * 0.6, nodeH]], { group: g, stroke: '#2f9e44' }));
    if (i < size - 1) {
      elements.push(arrow([[x + nodeW, nodeH / 2], [x + nodeW + gap, nodeH / 2]], { group: g, stroke: '#2f9e44', sw: 1.5 }));
    }
  }
  const lastX = (size - 1) * (nodeW + gap) + nodeW + 10;
  elements.push(text(lastX, 8, 'null', { group: g, fontSize: 13, color: '#888' }));
  elements.push(text(0, -28, 'Linked List', { group: g, fontSize: 13, color: '#2f9e44', align: 'left' }));
  return { elements, groupId: g, size };
}

export function makeStack(size = 4) {
  const g = uid();
  const cellW = 80, cellH = 36;
  const elements = [];
  for (let i = 0; i < size; i++) {
    const y = i * cellH;
    elements.push(rect(0, y, cellW, cellH, { group: g, bg: '#d0bfff', fill: 'solid', stroke: '#6741d9' }));
    elements.push(text(16, y + 8, i === 0 ? 'top' : `item ${size - i}`, { group: g, fontSize: 13, color: '#6741d9' }));
  }
  elements.push(arrow([[cellW + 10, 18], [cellW + 50, 18]], { group: g, stroke: '#6741d9', startHead: 'arrow', endHead: null }));
  elements.push(text(cellW + 54, 8, 'push', { group: g, fontSize: 12, color: '#6741d9', align: 'left' }));
  elements.push(arrow([[cellW + 50, 36], [cellW + 10, 36]], { group: g, stroke: '#e8590c', endHead: null, startHead: 'arrow' }));
  elements.push(text(cellW + 54, 28, 'pop', { group: g, fontSize: 12, color: '#e8590c', align: 'left' }));
  elements.push(text(0, -28, 'Stack (LIFO)', { group: g, fontSize: 13, color: '#6741d9', align: 'left' }));
  return { elements, groupId: g, size };
}

export function makeQueue(size = 4) {
  const g = uid();
  const cellW = 60, cellH = 40;
  const elements = [];
  for (let i = 0; i < size; i++) {
    const x = i * cellW;
    elements.push(rect(x, 0, cellW, cellH, { group: g, bg: '#ffec99', fill: 'solid', stroke: '#f08c00' }));
    elements.push(text(x + 8, 10, 'item', { group: g, fontSize: 13, color: '#f08c00' }));
  }
  elements.push(arrow([[-50, cellH / 2], [-4, cellH / 2]], { group: g, stroke: '#2f9e44', sw: 1.5 }));
  elements.push(text(-80, 8, 'enq', { group: g, fontSize: 12, color: '#2f9e44', align: 'left' }));
  const endX = size * cellW;
  elements.push(arrow([[endX + 4, cellH / 2], [endX + 50, cellH / 2]], { group: g, stroke: '#e03131', sw: 1.5 }));
  elements.push(text(endX + 54, 8, 'deq', { group: g, fontSize: 12, color: '#e03131', align: 'left' }));
  elements.push(text(0, -28, 'Queue (FIFO)', { group: g, fontSize: 13, color: '#f08c00', align: 'left' }));
  return { elements, groupId: g, size };
}

export function makeBinaryTree(depth = 3) {
  const g = uid();
  const r = 24, gapX = 70, gapY = 70;
  const elements = [];

  const nodeCount = Math.pow(2, depth) - 1;
  const nodes = [];
  function buildLevel(level, x, xSpread) {
    if (level >= depth) return;
    const y = level * gapY;
    const idx = nodes.length;
    nodes.push({ x, y, label: String(idx + 1) });
    const leftIdx = nodes.length;
    buildLevel(level + 1, x - xSpread / 2, xSpread / 2);
    const rightIdx = nodes.length;
    buildLevel(level + 1, x + xSpread / 2, xSpread / 2);
    if (leftIdx < nodes.length) {
      elements.push(arrow([[x, y + r], [nodes[leftIdx].x, nodes[leftIdx].y - r + 4]], { group: g, stroke: '#1971c2', sw: 1.5, endHead: 'arrow' }));
    }
    if (rightIdx < nodes.length) {
      elements.push(arrow([[x, y + r], [nodes[rightIdx].x, nodes[rightIdx].y - r + 4]], { group: g, stroke: '#1971c2', sw: 1.5, endHead: 'arrow' }));
    }
  }
  buildLevel(0, 0, gapX * 2);

  for (const n of nodes) {
    elements.push({
      id: uid(), type: 'ellipse',
      x: n.x - r, y: n.y - r, width: r * 2, height: r * 2, angle: 0,
      strokeColor: '#1971c2', backgroundColor: '#a5d8ff', fillStyle: 'solid',
      strokeWidth: 1, strokeStyle: 'solid', roughness: 0, opacity: 100,
      roundness: null, seed: nextSeed(), version: 1, versionNonce: nextSeed(),
      isDeleted: false, groupIds: [g], boundElements: null,
      updated: Date.now(), link: null, locked: false, frameId: null, index: null,
    });
    elements.push(text(n.x - 6, n.y - 9, n.label, { group: g, fontSize: 16, color: '#1971c2' }));
  }
  const minX = Math.min(...nodes.map((n) => n.x));
  elements.push(text(minX - r, -r - 30, 'Binary Tree', { group: g, fontSize: 13, color: '#1971c2', align: 'left' }));
  return { elements, groupId: g, size: depth };
}

export function makeHashTable(buckets = 4) {
  const g = uid();
  const bW = 60, bH = 36, chainW = 56, chainH = 30, gap = 12;
  const elements = [];
  for (let i = 0; i < buckets; i++) {
    const y = i * (bH + gap);
    elements.push(rect(0, y, bW, bH, { group: g, bg: '#ffc9c9', fill: 'solid', stroke: '#e03131' }));
    elements.push(text(10, y + 8, `[${i}]`, { group: g, fontSize: 13, color: '#e03131' }));
    const chains = i % 2 === 0 ? 2 : 1;
    for (let c = 0; c < chains; c++) {
      const cx = bW + gap + c * (chainW + gap + 20);
      elements.push(rect(cx, y + 3, chainW, chainH, { group: g, bg: '#a5d8ff', fill: 'solid', stroke: '#1971c2' }));
      elements.push(text(cx + 4, y + 9, 'val', { group: g, fontSize: 12, color: '#1971c2' }));
      if (c === 0) {
        elements.push(arrow([[bW, y + bH / 2], [cx, y + bH / 2]], { group: g, stroke: '#888', sw: 1 }));
      } else {
        const prevEnd = bW + gap + (c - 1) * (chainW + gap + 20) + chainW;
        elements.push(arrow([[prevEnd, y + bH / 2], [cx, y + bH / 2]], { group: g, stroke: '#888', sw: 1 }));
      }
    }
  }
  elements.push(text(0, -28, 'Hash Table', { group: g, fontSize: 13, color: '#e03131', align: 'left' }));
  return { elements, groupId: g, size: buckets };
}

export const DS_SHAPES = [
  { id: 'ds-array',       name: 'Array',       defaultSize: 5, minSize: 1, maxSize: 20, make: (n, palette) => makeArray(n || 5, palette ?? canvasStrokePalette(false)) },
  { id: 'ds-linked-list', name: 'Linked List',  defaultSize: 4, minSize: 1, maxSize: 15, make: (n) => makeLinkedList(n || 4) },
  { id: 'ds-stack',       name: 'Stack',        defaultSize: 4, minSize: 1, maxSize: 12, make: (n) => makeStack(n || 4) },
  { id: 'ds-queue',       name: 'Queue',        defaultSize: 4, minSize: 1, maxSize: 12, make: (n) => makeQueue(n || 4) },
  { id: 'ds-binary-tree', name: 'Tree',         defaultSize: 3, minSize: 2, maxSize: 5,  make: (n) => makeBinaryTree(n || 3) },
  { id: 'ds-hash-table',  name: 'Hash Map',     defaultSize: 4, minSize: 2, maxSize: 10, make: (n) => makeHashTable(n || 4) },
];
