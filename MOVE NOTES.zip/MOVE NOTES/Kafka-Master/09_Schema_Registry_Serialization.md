# 9. Schema Registry & Serialization

> **Permanent Recall Note:** **Schema evolution** prevents **silent breakage** when producers and consumers upgrade at different times. **Confluent Schema Registry** stores **Avro/Protobuf/JSON Schema** definitions; **Schema ID** is embedded in messages (**bytes 1+4** magic+id convention). Data Engineers own **compatibility** rules, **subject** naming, and **broker** validation (when enabled). Spark reads Avro/JSON with **schema** — tie to [../spark/09_Storage_Catalog_Table_Formats.md](../spark/09_Storage_Catalog_Table_Formats.md) mentally.

### The 10-Second Summary
- **Why:** **Contract** between teams — **fail fast** on incompatible changes.
- **Compatibility:** **Backward** (new schema reads old data), **Forward**, **Full**.
- **Wire format:** serializer hits Registry → **ID** + **payload**.
- **Subjects:** `TopicNameStrategy` vs `RecordNameStrategy` — affects **evolution** lines.

---

# 9.1 Why Schema Management Matters

```
Without registry:
  producer changes field type → consumer silently misreads → bad data in lake

With registry:
  incompatible change → registration fails → CI/CD blocked
```

💡 **Key Insight:** **Data contracts** are **as important** as API contracts.

---

# 9.2 Confluent Schema Registry — Architecture

```
┌─────────────┐    register/get schema ID    ┌──────────────────┐
│  Producer   │  ─────────────────────────► │ Schema Registry │
└─────────────┘                             └────────┬─────────┘
       │                                              │
       │ produce [magic][id][payload]                 │
       ▼                                              ▼
┌─────────────────────────────────────────────────────────────┐
│  Kafka Topic                                                 │
└─────────────────────────────────────────────────────────────┘
       │                                              │
       ▼                                              │
┌─────────────┐    fetch schema by id                 │
│  Consumer   │  ◄───────────────────────────────────┘
└─────────────┘
```

---

# 9.3 Schema Evolution Modes

| Mode | Meaning |
|------|---------|
| **Backward** | New schema can read **old** data |
| **Forward** | Old schema can read **new** data |
| **Full** | Both **backward** and **forward** |

📏 **Golden Rule:** Default **backward** is common — **consumers deploy first** (or use **compatible** readers).

---

# 9.4 Avro vs Protobuf vs JSON Schema

| Format | Pros | Cons |
|--------|------|------|
| **Avro** | Compact, Kafka ecosystem default | Schema required for read |
| **Protobuf** | Cross-language, gRPC synergy | Tooling varies |
| **JSON Schema** | Human readable | Larger on wire |

---

# 9.5 Serializer / Deserializer (SerDe)

```java
props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
    "io.confluent.kafka.serializers.KafkaAvroSerializer");
props.put("schema.registry.url", "http://localhost:8081");
```

---

# 9.6 Schema ID in Message Header

- **Confluent wire format:** `0x0` magic byte + **4-byte schema ID** + Avro payload.
- **Newer:** **schema ID in header** optional patterns — know vendor **wire format**.

---

# 9.7 Subject Naming Strategies

| Strategy | Subject name |
|----------|--------------|
| **TopicNameStrategy** | `topic-value`, `topic-key` |
| **RecordNameStrategy** | `package.RecordName` |

⚠️ **Warning:** Changing strategy breaks **lineage** — treat as **migration**.

---

# 9.8 Schema Validation at Broker Level

| Feature | Role |
|---------|------|
| **Confluent Server Broker** | Reject **bad** payloads per registered schema |

**OSS Kafka** — typically **no** built-in Registry validation without **extensions**.

---

# 9.9 Best Practices for Schema Design

- Prefer **optional** fields with **defaults** for **backward** compatibility.
- **Never** rename without **alias** tricks — **Avro** specifics.
- **Version** in **CI** — **register** schemas in **pipeline**.

🔥 **Pro Tip:** **Compatibility** tests in **PR** — `maven`/`gradle` plugins or **Confluent** tools.

---

# 9.10 Example — Compatible Add Field (Avro mental)

```json
{
  "type": "record",
  "name": "Order",
  "fields": [
    {"name": "id", "type": "string"},
    {"name": "amount", "type": "double"},
    {"name": "currency", "type": "string", "default": "USD"}
  ]
}
```

---

# 9.11 Protobuf & JSON Schema Notes

- **Protobuf** — **field numbers** never reuse; **reserved** for deleted tags.
- **JSON Schema** — **additionalProperties** control for strict pipelines.

---

# 9.12 Multi-Data Center Registry Patterns

- **Single** global Registry with **caching** vs **per DC** with **sync** — **compatibility** must stay **central** in governance story.

---

# 9.13 Spark + Avro + Registry (Conceptual)

- Use **spark-avro** / vendor packages; pass **schema** from Registry in **driver** for **batch** jobs.
- **Streaming** — same **deserializer** story; **checkpoint** offsets separately.

Cross-ref: [../spark/04_DataFrame_Dataset_Catalyst.md](../spark/04_DataFrame_Dataset_Catalyst.md) for **schema** in DataFrames.

---

# 9.14 Troubleshooting SerDe Failures

| Symptom | Likely cause |
|---------|----------------|
| **Unknown magic byte** | Wrong **wire format** / not Confluent |
| **Unknown schema id** | Registry **mismatch** / wrong **URL** |
| **Incompatible schema** | Evolution **rule** violated |

---

# 9.15 Interview Questions & Answers

**Q: Backward compatible example?**  
**A:** **Add** optional field with **default** — old reader ignores new fields.

**Q: Breaking change?**  
**A:** **Remove** required field, **change** type without **union** — fails compatibility checks.

**Q: Schema ID kyun bhejte hain?**  
**A:** **Compact** — consumer **fetches** schema from Registry by ID — **no** embed full schema every message.

**Q: Spark read Avro from Kafka?**  
**A:** Use **from_avro** / **confluent** packages — **schema** from Registry or **inline**.

---

## 🧠 End-of-Chapter Memory Notes

```
┌─────────────────────────────────────────────────────────────┐
│  CHAPTER 9 — QUICK RECALL                                  │
├─────────────────────────────────────────────────────────────┤
│  🧠 Registry = contract store; evolution rules = safety    │
│  🧠 Backward/Forward/Full — pick deployment order          │
│  🧠 Subject naming = affects compatibility scope           │
│  🧠 Wire format magic + schema id + payload               │
│  ⚠️  Renaming fields = breaking without careful Avro       │
│  🎯 CI check schema compatibility before deploy            │
└─────────────────────────────────────────────────────────────┘
```
