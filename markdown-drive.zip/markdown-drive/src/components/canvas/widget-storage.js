/**
 * Per-canvas widget persistence (localStorage).
 * Keys are scoped by canvas name so new/switched canvases do not share widgets.
 */

function prefix(canvasName) {
  const n = canvasName || 'Untitled Canvas';
  return `cv-w:${encodeURIComponent(n)}`;
}

export function registryKey(canvasName) {
  return `${prefix(canvasName)}:registry`;
}

export function dataKey(canvasName, widgetId) {
  return `${prefix(canvasName)}:d:${widgetId}`;
}

export function loadWidgetsFromStorage(canvasName) {
  const name = canvasName || 'Untitled Canvas';
  try {
    const raw = localStorage.getItem(registryKey(name));
    if (!raw) return new Map();
    const list = JSON.parse(raw);
    const map = new Map();
    for (const entry of list) {
      const dataRaw = localStorage.getItem(dataKey(name, entry.id));
      const data = dataRaw ? JSON.parse(dataRaw) : {};
      map.set(entry.id, {
        type: entry.type,
        worldX: entry.worldX,
        worldY: entry.worldY,
        w: entry.w,
        h: entry.h,
        data,
      });
    }
    return map;
  } catch {
    return new Map();
  }
}

export function saveWidgetRegistry(canvasName, widgetGroups) {
  const name = canvasName || 'Untitled Canvas';
  try {
    const list = [];
    for (const [id, info] of widgetGroups) {
      list.push({ id, type: info.type, worldX: info.worldX, worldY: info.worldY, w: info.w, h: info.h });
    }
    localStorage.setItem(registryKey(name), JSON.stringify(list));
  } catch { /* quota */ }
}

export function saveWidgetData(canvasName, id, data) {
  try {
    localStorage.setItem(dataKey(canvasName || 'Untitled Canvas', id), JSON.stringify(data));
  } catch { /* quota */ }
}

export function removeWidgetStorage(canvasName, id) {
  try {
    localStorage.removeItem(dataKey(canvasName || 'Untitled Canvas', id));
  } catch { /* ignore */ }
}

/** Remove all widget data for a canvas (when canvas is deleted) */
export function destroyWidgetStorageForCanvas(canvasName) {
  const name = canvasName || 'Untitled Canvas';
  try {
    const raw = localStorage.getItem(registryKey(name));
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list)) {
        for (const e of list) {
          if (e?.id) localStorage.removeItem(dataKey(name, e.id));
        }
      }
    }
    localStorage.removeItem(registryKey(name));
  } catch { /* ignore */ }
}

/** When renaming a canvas in the sidebar */
export function renameWidgetStorageCanvas(oldName, newName) {
  if (!oldName || !newName || oldName === newName) return;
  try {
    const raw = localStorage.getItem(registryKey(oldName));
    if (!raw) return;
    const list = JSON.parse(raw);
    if (!Array.isArray(list)) return;
    for (const e of list) {
      if (!e?.id) continue;
      const d = localStorage.getItem(dataKey(oldName, e.id));
      if (d) {
        localStorage.setItem(dataKey(newName, e.id), d);
        localStorage.removeItem(dataKey(oldName, e.id));
      }
    }
    localStorage.setItem(registryKey(newName), raw);
    localStorage.removeItem(registryKey(oldName));
  } catch { /* ignore */ }
}
