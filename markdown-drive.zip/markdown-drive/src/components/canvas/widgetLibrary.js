export const WIDGET_DIMS = {
  compiler: { w: 420, h: 320, minW: 300, minH: 200 },
  note:     { w: 320, h: 220, minW: 200, minH: 120 },
  /* h includes toolbar (≈36) + body strip (74 at scale 1) */
  array:    { w: 440, h: 110, minW: 220, minH: 100 },
};

export const WIDGET_SHAPES = [
  { id: 'widget-compiler', name: 'Code Compiler', type: 'compiler' },
  { id: 'widget-note',     name: 'Sticky Note',   type: 'note' },
  { id: 'widget-array',    name: 'Array',         type: 'array' },
];

export function createDefaultWidgetData(type) {
  if (type === 'array') {
    return {
      items: ['10', '20', '30', '40', '50'],
    };
  }
  return {};
}
