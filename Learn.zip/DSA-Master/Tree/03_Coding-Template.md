# Tree — Coding Templates

> Copy-paste ready. Every template here is directly derived from the lecture. Adapt data types and logic as needed.

---

## 1. Node Structure

```cpp
// C++ — from lecture: struct Node { Node *left; int data; Node *right; }
struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) : data(val), left(nullptr), right(nullptr) {}
};
```

```python
# Python
class Node:
    def __init__(self, val):
        self.data = val
        self.left = None
        self.right = None
```

---

## 2. Tree Traversals

### Pre-order (Root → Left → Right)

```cpp
void preorder(Node* ptr) {
    if (ptr == nullptr) return;
    cout << ptr->data << " ";   // PRINT FIRST (before going to children)
    preorder(ptr->left);
    preorder(ptr->right);
}
```

```python
def preorder(node):
    if node is None:
        return
    print(node.data, end=" ")   # print first
    preorder(node.left)
    preorder(node.right)
```

### In-order (Left → Root → Right)

```cpp
void inorder(Node* ptr) {
    if (ptr == nullptr) return;
    inorder(ptr->left);
    cout << ptr->data << " ";   // PRINT IN MIDDLE
    inorder(ptr->right);
}
```

```python
def inorder(node):
    if node is None:
        return
    inorder(node.left)
    print(node.data, end=" ")   # print in middle
    inorder(node.right)
```

### Post-order (Left → Right → Root)

```cpp
void postorder(Node* ptr) {
    if (ptr == nullptr) return;
    postorder(ptr->left);
    postorder(ptr->right);
    cout << ptr->data << " ";   // PRINT LAST (after both children)
}
```

```python
def postorder(node):
    if node is None:
        return
    postorder(node.left)
    postorder(node.right)
    print(node.data, end=" ")   # print last
```

### Level-order / BFS (Uses Queue)

```cpp
// C++ — from lecture code
void levelOrder(Node* root) {
    if (root == nullptr) return;

    queue<Node*> q;
    q.push(root);

    while (!q.empty()) {
        Node* ptr = q.front();
        q.pop();
        cout << ptr->data << " ";
        if (ptr->left != nullptr)  q.push(ptr->left);
        if (ptr->right != nullptr) q.push(ptr->right);
    }
}
```

```python
from collections import deque

def level_order(root):
    if not root:
        return
    q = deque([root])
    while q:
        node = q.popleft()
        print(node.data, end=" ")
        if node.left:  q.append(node.left)
        if node.right: q.append(node.right)
```

### Level-order with Level Tracking (for level-by-level output)

```python
def level_order_by_level(root):
    if not root:
        return []
    result = []
    q = deque([root])
    while q:
        level_size = len(q)
        level = []
        for _ in range(level_size):
            node = q.popleft()
            level.append(node.data)
            if node.left:  q.append(node.left)
            if node.right: q.append(node.right)
        result.append(level)
    return result
```

---

## 3. Common Tree Functions (From Lecture)

### Height of Tree (Bottom-Up)

```cpp
int height(Node* ptr) {
    if (ptr == nullptr) return -1;   // -1 so leaf node has height 0
    int left_h  = height(ptr->left);
    int right_h = height(ptr->right);
    return 1 + max(left_h, right_h);
}
```

```python
def height(node):
    if node is None:
        return -1
    return 1 + max(height(node.left), height(node.right))
```

### Count Total Nodes

```python
def count_nodes(node):
    if node is None:
        return 0
    return 1 + count_nodes(node.left) + count_nodes(node.right)
```

### Count Leaf Nodes

```python
def count_leaves(node):
    if node is None:
        return 0
    if node.left is None and node.right is None:
        return 1   # this IS a leaf
    return count_leaves(node.left) + count_leaves(node.right)
```

### Count Non-Leaf Nodes (From Lecture: CountNonLeaf function)

```cpp
int countNonLeaf(Node* ptr) {
    if (ptr == nullptr) return 0;
    if (ptr->left == nullptr && ptr->right == nullptr) return 0;  // leaf
    return 1 + countNonLeaf(ptr->left) + countNonLeaf(ptr->right);
}
```

### Print Nodes at Distance K from Root (From Lecture)

```python
def print_at_k(node, k):
    if node is None:
        return
    if k == 0:
        print(node.data)
        return
    print_at_k(node.left,  k - 1)   # pass k-1 downward (Top-Down)
    print_at_k(node.right, k - 1)
```

### Mirror / Invert a Tree

```python
def mirror(node):
    if node is None:
        return None
    node.left, node.right = mirror(node.right), mirror(node.left)
    return node
```

### Diameter of Tree (Longest path between any two nodes)

```python
diameter = [0]

def height_for_diameter(node):
    if node is None:
        return -1
    left_h  = height_for_diameter(node.left)
    right_h = height_for_diameter(node.right)
    # diameter through this node = left_h + right_h + 2
    diameter[0] = max(diameter[0], left_h + right_h + 2)
    return 1 + max(left_h, right_h)

def diameter_of_tree(root):
    height_for_diameter(root)
    return diameter[0]
```

---

## 4. BST Operations

### BST Search

```cpp
Node* search(Node* root, int key) {
    if (root == nullptr || root->data == key)
        return root;
    if (key < root->data)
        return search(root->left, key);   // go left
    else
        return search(root->right, key);  // go right
}
```

```python
def search_bst(node, key):
    if node is None or node.data == key:
        return node
    if key < node.data:
        return search_bst(node.left, key)
    return search_bst(node.right, key)
```

### BST Insert

```python
def insert_bst(node, key):
    if node is None:
        return Node(key)
    if key < node.data:
        node.left = insert_bst(node.left, key)
    elif key > node.data:
        node.right = insert_bst(node.right, key)
    return node   # return unchanged if key already exists
```

### BST Delete

```python
def delete_bst(node, key):
    if node is None:
        return None
    if key < node.data:
        node.left = delete_bst(node.left, key)
    elif key > node.data:
        node.right = delete_bst(node.right, key)
    else:
        # Node found — 3 cases:
        if node.left is None:   # Case 1: no left child
            return node.right
        if node.right is None:  # Case 2: no right child
            return node.left
        # Case 3: has both children → replace with inorder successor
        successor = find_min(node.right)
        node.data = successor.data
        node.right = delete_bst(node.right, successor.data)
    return node

def find_min(node):
    while node.left:
        node = node.left
    return node
```

---

## 5. AVL Tree — Balance Factor & Rotation

### Get Balance Factor

```python
def get_height(node):
    if node is None:
        return -1
    return node.height

def get_balance(node):
    if node is None:
        return 0
    return get_height(node.left) - get_height(node.right)
```

### Right Rotation (LL Case)

```
   z (BF=-2)                y
    \          →           / \
     y (BF=-1)            z   x
      \
       x
```

```python
def right_rotate(z):
    y = z.left
    T3 = y.right

    y.right = z
    z.left = T3

    z.height = 1 + max(get_height(z.left), get_height(z.right))
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    return y
```

### Left Rotation (RR Case)

```python
def left_rotate(z):
    y = z.right
    T2 = y.left

    y.left = z
    z.right = T2

    z.height = 1 + max(get_height(z.left), get_height(z.right))
    y.height = 1 + max(get_height(y.left), get_height(y.right))
    return y
```

---

## 6. Heap — Array Implementation

```python
class MaxHeap:
    def __init__(self):
        self.heap = []

    def parent(self, i):    return (i - 1) // 2
    def left(self, i):      return 2 * i + 1
    def right(self, i):     return 2 * i + 2

    def insert(self, val):
        self.heap.append(val)          # Step 1: Add at end (CBT property)
        i = len(self.heap) - 1
        while i > 0 and self.heap[self.parent(i)] < self.heap[i]:
            # Swap with parent (heapify up)
            self.heap[i], self.heap[self.parent(i)] = self.heap[self.parent(i)], self.heap[i]
            i = self.parent(i)

    def extract_max(self):
        if not self.heap: return None
        max_val = self.heap[0]
        self.heap[0] = self.heap[-1]   # Move last to root
        self.heap.pop()
        self._heapify_down(0)
        return max_val

    def _heapify_down(self, i):
        n = len(self.heap)
        largest = i
        l, r = self.left(i), self.right(i)
        if l < n and self.heap[l] > self.heap[largest]: largest = l
        if r < n and self.heap[r] > self.heap[largest]: largest = r
        if largest != i:
            self.heap[i], self.heap[largest] = self.heap[largest], self.heap[i]
            self._heapify_down(largest)
```

### Python Built-in Heap (heapq — Min Heap by default)

```python
import heapq

# Min Heap
heap = []
heapq.heappush(heap, 5)
heapq.heappush(heap, 3)
min_val = heapq.heappop(heap)    # returns 3

# Max Heap (negate values)
heapq.heappush(heap, -10)
max_val = -heapq.heappop(heap)   # returns 10

# Heapify an existing list
arr = [5, 3, 8, 1]
heapq.heapify(arr)               # O(n) — converts to min heap in place
```

---

## 7. Construct Tree from Traversals

### From Inorder + Preorder

```python
def build_from_pre_in(preorder, inorder):
    if not preorder or not inorder:
        return None
    root_val = preorder[0]            # First of preorder = root
    root = Node(root_val)
    mid = inorder.index(root_val)     # Split point in inorder

    root.left  = build_from_pre_in(preorder[1:mid+1], inorder[:mid])
    root.right = build_from_pre_in(preorder[mid+1:],  inorder[mid+1:])
    return root
```

### From Inorder + Postorder

```python
def build_from_post_in(postorder, inorder):
    if not postorder or not inorder:
        return None
    root_val = postorder[-1]          # LAST of postorder = root
    root = Node(root_val)
    mid = inorder.index(root_val)

    root.left  = build_from_post_in(postorder[:mid],  inorder[:mid])
    root.right = build_from_post_in(postorder[mid:-1], inorder[mid+1:])
    return root
```
