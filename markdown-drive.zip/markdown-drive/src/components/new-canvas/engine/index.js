import { createRenderer } from './renderer';
import { createScheduler } from './scheduler';
import { zoomAtScreenPoint } from './coords';
import { penTool, highlighterTool } from './tools/pen';
import { rectTool, ellipseTool, lineTool, arrowTool } from './tools/shapes';
import { textTool } from './tools/text';
import { eraserTool } from './tools/eraser';
import { selectTool } from './tools/select';
import { panTool } from './tools/pan';
import { laserTool } from './tools/laser';
import { widgetTools } from './tools/widget-place';

/**
 * createEngine — binds a React stage to the rendering+input pipeline.
 *
 *   createEngine({ staticEl, interactiveEl, hostEl, store, getTheme })
 *
 * The engine:
 *   - owns the renderer + scheduler
 *   - owns transient (non-persistent) state: draft element, marquee rect
 *   - forwards pointer events to the active tool
 *   - implements viewport globals (wheel zoom, pinch, space-pan, middle-pan)
 *   - keeps a subscription to the store so commits trigger static-layer repaints
 *   - exposes `destroy()` to unbind everything (component unmount)
 */

const TOOLS = {
  pen: penTool,
  highlighter: highlighterTool,
  rect: rectTool,
  ellipse: ellipseTool,
  line: lineTool,
  arrow: arrowTool,
  text: textTool,
  eraser: eraserTool,
  select: selectTool,
  pan: panTool,
  laser: laserTool,
  ...widgetTools,
};

export function createEngine({ staticEl, interactiveEl, inkEl, hostEl, store, getTheme }) {
  let draft = null;
  let marquee = null;
  let spaceHeld = false;
  let panOverride = null;  // { sx, sy, startPanX, startPanY, zoom, pointerId }
  const eraserTrail = [];
  // `ctx._laser` will be lazily created by the laser tool itself.

  const getScene = () => {
    const s = store.getState();
    return s.scenes[s.activeId];
  };
  const getVp = () => getScene()?.viewport;

  const renderer = createRenderer({
    staticEl,
    interactiveEl,
    inkEl,
    getScene,
    getDraft: () => draft,
    getSelection: () => store.getState().selection,
    getMarquee: () => marquee,
    getLaser: () => ctx._laser,
    getEraserTrail: () => eraserTrail,
    getTheme,
  });

  const scheduler = createScheduler((dirty) => renderer.paint(dirty));

  function setDraft(d)   { draft = d; }
  function setMarquee(m) { marquee = m; }

  const ctx = {
    canvasEl: interactiveEl,
    hostEl,
    store,
    getVp,
    getScene,
    getDraft: () => draft,
    setDraft,
    getMarquee: () => marquee,
    setMarquee,
    getEraserTrail: () => eraserTrail,
    markDirty: (level) => scheduler.markDirty(level),
    setViewport: (vp) => store.getState().setViewport(vp),
    commit(updater) {
      store.getState().commitElements(updater);
    },
    commitTransient(nextElements, coalesceKey) {
      store.getState().commitElements(nextElements, { transient: true, coalesceKey });
    },
    commitFinal(nextElements) {
      store.getState().commitElements(nextElements);
    },
    /**
     * Finalize a transient gesture as a single undoable entry. Pass the
     * element array captured at pointerdown as `prev`, and the final
     * element array as `next`.
     */
    commitGesture(prev, next) {
      store.getState().commitGesture(prev, next);
    },
  };

  /* ── resize observer ───────────────────────────────────────── */

  const ro = new ResizeObserver(() => {
    const rect = hostEl.getBoundingClientRect();
    renderer.resize(rect.width, rect.height);
    scheduler.markDirty(2);
  });
  ro.observe(hostEl);

  /* ── store subscription (for static layer repaints) ───────── */

  let lastElements = getScene()?.elements;
  let lastVpSig = '';
  const vpSig = (vp) => (vp ? `${vp.zoom}|${vp.panX}|${vp.panY}` : '');
  const unsubStore = store.subscribe((s) => {
    const sc = s.scenes[s.activeId];
    if (!sc) return;
    const sig = vpSig(sc.viewport);
    if (sc.elements !== lastElements) {
      lastElements = sc.elements;
      lastVpSig = sig;
      scheduler.markDirty(2);
    } else if (sig !== lastVpSig) {
      // Pan/zoom from UI (dock, etc.) — static layer MUST repaint with the new
      // transform; dirty(1) only refreshed the overlay and left committed art
      // stuck on the old viewport (felt like broken mouse / out-of-sync draw).
      lastVpSig = sig;
      scheduler.markDirty(2);
    } else {
      scheduler.markDirty(1);
    }
  });

  /* ── pointer routing ───────────────────────────────────────── */

  function activeTool() {
    return TOOLS[store.getState().tool] || selectTool;
  }

  function beginPanOverride(ev) {
    const vp = getVp();
    interactiveEl.setPointerCapture?.(ev.pointerId);
    panOverride = {
      sx: ev.clientX, sy: ev.clientY,
      startPanX: vp.panX, startPanY: vp.panY,
      zoom: vp.zoom, pointerId: ev.pointerId,
    };
    interactiveEl.style.cursor = 'grabbing';
  }

  function onPointerDown(ev) {
    // middle-click or space-held = pan override
    if (ev.button === 1 || (ev.button === 0 && spaceHeld)) {
      ev.preventDefault();
      beginPanOverride(ev);
      return;
    }
    activeTool().onPointerDown?.(ctx, ev);
  }

  function onPointerMove(ev) {
    if (panOverride) {
      const p = panOverride;
      const dx = (ev.clientX - p.sx) / p.zoom;
      const dy = (ev.clientY - p.sy) / p.zoom;
      store.getState().setViewport({ zoom: p.zoom, panX: p.startPanX + dx, panY: p.startPanY + dy });
      scheduler.markDirty(2);
      return;
    }
    activeTool().onPointerMove?.(ctx, ev);
  }

  function onPointerUp(ev) {
    if (panOverride && panOverride.pointerId === ev.pointerId) {
      panOverride = null;
      interactiveEl.style.cursor = '';
      return;
    }
    activeTool().onPointerUp?.(ctx, ev);
  }

  function onPointerCancel() {
    if (panOverride) { panOverride = null; interactiveEl.style.cursor = ''; }
    activeTool().onCancel?.(ctx);
  }

  function onWheel(ev) {
    ev.preventDefault();
    const vp = getVp();
    const rect = interactiveEl.getBoundingClientRect();
    const sx = ev.clientX - rect.left;
    const sy = ev.clientY - rect.top;

    // Trackpad pinch-zoom fires wheel with ctrlKey=true. Regular scrolls
    // pan — matches Figma/Excalidraw ergonomics.
    if (ev.ctrlKey || ev.metaKey) {
      const factor = Math.exp(-ev.deltaY * 0.01);
      const next = zoomAtScreenPoint(vp, sx, sy, vp.zoom * factor);
      store.getState().setViewport(next);
    } else {
      // pan (2-finger scroll). deltaX/deltaY are in pixels; divide by zoom
      // so the pan feels the same at any zoom level.
      store.getState().setViewport({
        zoom: vp.zoom,
        panX: vp.panX - ev.deltaX / vp.zoom,
        panY: vp.panY - ev.deltaY / vp.zoom,
      });
    }
    scheduler.markDirty(2);
  }

  /* ── keyboard (shortcuts + space-pan) ──────────────────────── */

  function isEditableTarget(ev) {
    const t = ev?.target;
    if (t && typeof t === 'object') {
      const tag = t.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return true;
      if (t.isContentEditable) return true;
      if (typeof t.closest === 'function' && t.closest('.monaco-editor, .monaco-mouse-cursor-text')) return true;
    }
    const ae = typeof document !== 'undefined' ? document.activeElement : null;
    if (ae && typeof ae.closest === 'function' && ae.closest('.monaco-editor, .monaco-mouse-cursor-text')) {
      return true;
    }
    return false;
  }

  function onKeyDown(ev) {
    if (isEditableTarget(ev)) return;
    if (ev.code === 'Space') { spaceHeld = true; interactiveEl.style.cursor = 'grab'; }
    if ((ev.ctrlKey || ev.metaKey) && !ev.shiftKey && ev.key.toLowerCase() === 'z') {
      ev.preventDefault(); store.getState().undo();
    } else if ((ev.ctrlKey || ev.metaKey) && (ev.key === 'y' || (ev.shiftKey && ev.key.toLowerCase() === 'z'))) {
      ev.preventDefault(); store.getState().redo();
    } else if (ev.key === 'Delete' || ev.key === 'Backspace') {
      const sel = store.getState().selection;
      if (sel.size > 0) {
        ev.preventDefault();
        store.getState().commitElements((els) => els.map((e) => sel.has(e.id) ? { ...e, isDeleted: true } : e));
        store.getState().clearSelection();
      }
    } else if (ev.key === 'Escape') {
      if (draft) { activeTool().onCancel?.(ctx); draft = null; scheduler.markDirty(2); }
      store.getState().clearSelection();
    }

    // tool shortcuts
    const k = ev.key.toLowerCase();
    const map = { v: 'select', p: 'pen', e: 'eraser', r: 'rect', o: 'ellipse', l: 'line', a: 'arrow', t: 'text', h: 'highlighter', k: 'laser' };
    if (!ev.ctrlKey && !ev.metaKey && !ev.altKey && map[k]) {
      store.getState().setTool(map[k]);
    }
  }

  function onKeyUp(ev) {
    if (ev.code === 'Space') { spaceHeld = false; interactiveEl.style.cursor = ''; }
  }

  /* ── bind listeners ───────────────────────────────────────── */

  interactiveEl.addEventListener('pointerdown', onPointerDown);
  interactiveEl.addEventListener('pointermove', onPointerMove);
  interactiveEl.addEventListener('pointerup', onPointerUp);
  interactiveEl.addEventListener('pointercancel', onPointerCancel);
  /* NOTE: we intentionally do NOT listen to `pointerleave` — with
   * setPointerCapture active it still fires when the cursor exits the
   * element, and cancelling on leave would corrupt strokes that finish
   * outside the canvas (e.g. flicking past the edge). */
  interactiveEl.addEventListener('wheel', onWheel, { passive: false });
  // prevent the browser from eating right-click during draw tests
  interactiveEl.addEventListener('contextmenu', (e) => e.preventDefault());
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);

  // kick first paint
  const rect = hostEl.getBoundingClientRect();
  renderer.resize(rect.width, rect.height);
  scheduler.markDirty(2);

  return {
    destroy() {
      ro.disconnect();
      unsubStore();
      interactiveEl.removeEventListener('pointerdown', onPointerDown);
      interactiveEl.removeEventListener('pointermove', onPointerMove);
      interactiveEl.removeEventListener('pointerup', onPointerUp);
      interactiveEl.removeEventListener('pointercancel', onPointerCancel);
      interactiveEl.removeEventListener('wheel', onWheel);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      scheduler.cancel();
    },
    getStats: () => scheduler.stats(),
    getDraft: () => draft,
  };
}
