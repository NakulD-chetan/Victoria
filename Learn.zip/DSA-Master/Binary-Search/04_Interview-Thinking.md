# Binary Search — Interview Thinking

> **How to think, communicate, and reason about binary search in a FAANG interview. How interviewers expect you to identify it, explain monotonicity, and justify complexity.**

---

## The FAANG Interview Flow (Step by Step)

### Phase 1: Understand (2-3 minutes)

**What the interviewer expects you to do:**

- Read the problem carefully
- Ask clarifying questions
- Identify if data is sorted or if answer space is monotonic

**What to say:**

> "Let me confirm: Is the array sorted? Can it be empty? For the answer, what's the range of possible values? Are we looking for any occurrence or the first/last?"

**Why this matters:** Binary search has strict requirements. Clarifying early prevents wrong approaches.

### Phase 2: Identify the Pattern (1-2 minutes)

**What to say when you recognize standard binary search:**

> "The array is sorted, so we can exploit that structure. Instead of linear scan O(n), we can halve the search space each step for O(log n)."

**What to say when you recognize binary search on answer:**

> "The problem asks for the minimum [capacity/speed/limit] such that a condition holds. If X works, any value larger than X also works — the answer space is monotonic. I'll binary search on the answer."

**Do NOT say:** "I'll use binary search" without explaining WHY it applies.

### Phase 3: Explain Approach Before Coding (2-3 minutes)

**Structure your explanation:**

1. **State the search space:**
  > "The answer lies in range [lo, hi]. For standard BS, that's indices 0 to n-1. For BS on answer, that's [minPossible, maxPossible]."
2. **Explain the decision rule:**
  > "At each step, I check the middle element. Based on the comparison [or condition], I can discard either the left or right half."
3. **Explain monotonicity (critical for BS on answer):**
  > "The key insight is monotonicity: if capacity C works, capacity C+1 works. So there's a clear boundary — everything below fails, everything above succeeds."
4. **State complexity:**
  > "Each step halves the space, so we do O(log n) iterations. The check per iteration is O(n) [or whatever], giving O(n log n) total."

---

## How to Communicate "The Search Space is Monotonic"

**This is the phrase interviewers listen for.**

### The 30-Second Monotonicity Pitch

> "The answer space has a monotonic property. For any value X, we can compute whether the condition is satisfied. And crucially: if X works, then X+1, X+2... all work [or vice versa]. So there's a single boundary. Binary search finds that boundary in O(log range) steps."

### Example Pitches

**Capacity to ship packages:**

> "If we can ship with capacity 50 in 5 days, we can definitely ship with capacity 60. The 'works' function is monotonic — there's a minimum capacity below which we fail, above which we succeed. I'll binary search on capacity."

**Koko eating bananas:**

> "If Koko can finish in 8 hours with speed 5, she can finish in 8 hours with speed 6. Monotonic. I'll binary search on the eating speed."

**Minimum in rotated array:**

> "The array has two sorted segments. The minimum is at the pivot. When we compare with the right end, we can tell which half contains the pivot — that's our monotonic split."

---

## How to Explain Binary Search on Answer

**Interviewers often ask: "Why binary search? The array isn't sorted."**

**Your response:**

> "The array doesn't need to be sorted. We're not binary searching the array — we're binary searching the *answer*. The possible answers form a range, say 1 to 10^9. For each candidate answer X, we can check in O(n) whether it works. And because of monotonicity — if X works, X+1 works — we can binary search. We test O(log 10^9) ≈ 30 values instead of trying all 10^9."

---

## Time Complexity Justification

### Standard Binary Search

> "We start with n elements. Each comparison eliminates half. After k steps, we have n/2^k elements. When n/2^k = 1, we're done. So k = log₂(n). Total: O(log n)."

### Binary Search on Answer

> "The answer range is R = hi - lo + 1. We do O(log R) iterations. Each iteration runs a check — for capacity problems, that's O(n) to simulate. Total: O(n log R). If R is 10^9, log R is about 30, so we do 30 × n work."

### When to Mention

- Always state complexity before coding
- If interviewer asks "can we do better?" — for comparison-based search on sorted data, O(log n) is optimal (information-theoretic lower bound)

---

## Follow-Up Questions (and How to Answer)

### "Can you do better than O(log n)?"

> "For comparison-based search on sorted data, O(log n) is optimal. We need at least log n comparisons to distinguish among n possibilities. If we have additional structure — like knowing the distribution — interpolation search can average O(log log n), but that's rarely asked."

### "What if there are duplicates?"

> "Standard binary search might return any occurrence. If we need the first occurrence, we use lower bound — when we find a match, we don't return immediately; we search left for an earlier match. That's bisect_left. For last occurrence, bisect_right minus 1."

### "What if the array is rotated?"

> "We can still binary search. We check which half is sorted by comparing with the endpoints. The target must be in the sorted half if it's within that range, otherwise in the other half. Same O(log n)."

### "What about integer overflow in mid calculation?"

> "We use mid = lo + (hi - lo) / 2 instead of (lo + hi) / 2. When lo and hi are large — say 10^9 — lo + hi can overflow. The alternative form is safe."

### "How do you avoid infinite loops?"

> "We ensure the search space shrinks every iteration. For 'find first true', we use hi = mid (mid might be answer) and lo = mid + 1. For 'find last true', we use lo = mid and hi = mid - 1, but we must use ceiling for mid: mid = lo + (hi - lo + 1) / 2, otherwise when lo and hi are adjacent, mid equals lo and we get stuck."

---

## Red Flags Interviewers Watch For


| Red Flag                                  | What It Signals            | Better Approach                              |
| ----------------------------------------- | -------------------------- | -------------------------------------------- |
| Using `(lo + hi) / 2`                     | Doesn't know overflow risk | "I use lo + (hi - lo) / 2 to avoid overflow" |
| Can't explain why BS applies              | Memorized, not understood  | "The space is monotonic because..."          |
| `lo = mid` and `hi = mid`                 | Infinite loop risk         | Always advance one boundary past mid         |
| Returning mid without verifying           | Off-by-one in edge cases   | "Let me verify the final lo/hi"              |
| Not handling empty array                  | Incomplete                 | "First I check for empty input"              |
| Saying "binary searc h" for non-monotonic | Wrong pattern              | Clarify monotonicity first                   |


---

## The Golden Communication Framework

```
┌─────────────────────────────────────────────────────────┐
│  STEP 1: CLARIFY      "Is the array sorted? Range?"    │
│  STEP 2: IDENTIFY     "This suggests binary search     │
│                        because [sorted / monotonic]"   │
│  STEP 3: MONOTONICITY "If X works, X+1 works — clear   │
│                        boundary to find"               │
│  STEP 4: SEARCH SPACE "We'll search [lo, hi]"          │
│  STEP 5: DECISION     "At mid, we [compare/check],     │
│                        then discard one half"         │
│  STEP 6: COMPLEXITY   "O(log n) or O(n log R)"        │
│  STEP 7: CODE         Write template, adapt condition │
│  STEP 8: TEST         Trace with small example        │
│  STEP 9: EDGE CASES   "Empty? Single element? Not found"│
└─────────────────────────────────────────────────────────┘
```

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Binary Search Interview
CLARIFY:            Sorted? Empty? First/last occurrence?
IDENTIFY:           Sorted array OR "min/max X such that..."
MONOTONICITY:       "If X works, X+1 works" — say this!
BS ON ANSWER:       "We're searching the answer, not the array"
COMPLEXITY:         O(log n) standard, O(n log R) on answer
OVERFLOW:           mid = lo + (hi - lo) / 2
INFINITE LOOP:      One boundary must move past mid
INTERVIEW LINE:     "The answer space is monotonic — there's a
                     clear boundary. I'll binary search to find it."
```

