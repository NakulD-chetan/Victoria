# Aggregates and GROUP BY — Mental Model

---

## Buckets

```
Rows  →  [GROUP BY key]  →  buckets  →  one output row per bucket
```

**HAVING** = “which buckets to keep after aggregation.”

---

## WHERE vs HAVING (again)

- **WHERE:** throws rows **out of the bucket** before aggregation.
- **HAVING:** throws **whole buckets** away after aggregation.

---

## DISTINCT vs GROUP BY

- **DISTINCT:** dedupe **result** rows.
- **GROUP BY:** explicit **aggregation** grouping — can attach aggregates.

Often overlap for “unique keys,” but **GROUP BY** is the aggregation primitive.

---

*Next: [[03_Coding-Template]]*
