# How Amazon S3 Works — Deep Level 2: Byte-by-Byte Internals

> **Permanent Recall:** S3 is an object store where metadata (key→location mapping) and data (actual bytes) live on separate planes. At the byte level: client sends HTTP PUT with AWS Signature V4 (HMAC-SHA256 chain over canonical request) → S3 frontend parses headers → data split into chunks, erasure-coded via Reed-Solomon (e.g., 8 data + 4 parity shards across AZs) → ShardStore appends to LSM tree (MemTable → SSTable flush → compaction) on HDDs → metadata index updated in a distributed KV store → checksum (SHA-256 + CRC32-C) verified at every boundary. GET requests hit metadata cache (RAM) → parallel reads from multiple disks/AZs → fragments reassembled → streamed to client via chunked Transfer-Encoding over HTTP/2.

> Companion to: [02-How-Amazon-S3-Works-In-Depth.md](02-How-Amazon-S3-Works-In-Depth.md)

---

## S3 REST API — Wire Format at the Byte Level

S3 speaks HTTP. Every PUT, GET, DELETE is a standard HTTP request. But underneath the simplicity is a carefully structured binary exchange.

### PUT Object — Raw Bytes on the Wire

```
S3 PUT REQUEST (HTTP/1.1, uploading "vacation.jpg" to "my-photos" bucket):

  PUT /vacation.jpg HTTP/1.1\r\n                           ← Request line
  Host: my-photos.s3.us-east-1.amazonaws.com\r\n           ← Virtual-hosted bucket
  Content-Length: 3342816\r\n                               ← 3.2 MB file
  Content-Type: image/jpeg\r\n
  Content-MD5: rL0Y20zC+Fzt72VPzMSk2A==\r\n                ← Base64(MD5(body))
  x-amz-content-sha256: e3b0c44298fc1c14...\r\n            ← SHA-256 hex of body
  x-amz-date: 20260329T120000Z\r\n                         ← ISO 8601 timestamp
  x-amz-storage-class: STANDARD\r\n                        ← Storage tier
  x-amz-meta-photographer: chetan\r\n                      ← Custom metadata
  Authorization: AWS4-HMAC-SHA256 Credential=AKIAIOSFODNN7EXAMPLE/
    20260329/us-east-1/s3/aws4_request,
    SignedHeaders=content-length;content-type;host;x-amz-content-sha256;
    x-amz-date;x-amz-meta-photographer;x-amz-storage-class,
    Signature=fe5f80f77d5fa3beca038a248ff027d0445342fe2855ddc963176630326f1024\r\n
  \r\n                                                      ← End of headers
  [3,342,816 bytes of JPEG data]                            ← Body

BYTE-LEVEL BREAKDOWN:
  "PUT " = 0x50 0x55 0x54 0x20                    (4 bytes)
  "/vacation.jpg" = 14 bytes ASCII
  " HTTP/1.1\r\n" = 11 bytes
  All headers combined: ~650 bytes
  Body: 3,342,816 bytes
  ─────────────────────────
  Total on wire: ~3,343,480 bytes

  Headers are ~0.02% of total. For a 10 KB file, headers are ~6%.
  This is why S3 has a per-request cost — small files = expensive overhead.

S3 PUT RESPONSE:

  HTTP/1.1 200 OK\r\n
  x-amz-id-2: LriYPLdmOdAiIfgSm/F1YsViT1LW94/xUQxMsF7xiEb1a0wiIOIxl+zbwZ163pt7\r\n
  x-amz-request-id: 0A49CE4060975EAC\r\n            ← Request trace ID
  ETag: "d41d8cd98f00b204e9800998ecf8427e"\r\n       ← MD5 of stored object
  x-amz-server-side-encryption: AES256\r\n           ← Encrypted at rest
  \r\n
  (empty body for PUT responses)

  THE ETag:
    For single-part upload: ETag = MD5 of the object bytes
      MD5("vacation.jpg bytes") = d41d8cd98f00b204e9800998ecf8427e
    For multipart upload: ETag = MD5(concat(MD5(part1), MD5(part2), ...)) + "-" + part_count
      Example: "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6-3" (3 parts)
    Client can verify: compute MD5 locally, compare with ETag
```

### Path-Style vs Virtual-Hosted-Style URLs

```
TWO WAYS TO ADDRESS S3 BUCKETS:

  Path-style (deprecated for new buckets):
    https://s3.us-east-1.amazonaws.com/my-photos/vacation.jpg
    ───────────────────────────────────┬────────┬─────────────
                                   S3 endpoint  bucket  key

  Virtual-hosted-style (current standard):
    https://my-photos.s3.us-east-1.amazonaws.com/vacation.jpg
    ────────┬────────────────────────────────────┬────────────
         bucket.s3.region.amazonaws.com          key

WHY DOES THIS MATTER AT THE NETWORK LEVEL?

  Virtual-hosted-style:
    DNS resolves: my-photos.s3.us-east-1.amazonaws.com → IP
    TLS SNI (Server Name Indication): "my-photos.s3.us-east-1.amazonaws.com"
    S3 frontend extracts bucket from the Host header
    → Can route to the correct partition BEFORE reading the full URL

  Path-style:
    DNS resolves: s3.us-east-1.amazonaws.com → IP
    Must read the URL path to determine bucket
    → Routing decision delayed

  At billions of requests/day, this difference matters for load balancing.
```

---

## AWS Signature V4 — Authentication Byte by Byte

Every S3 request must prove "I am who I say I am." This is done via HMAC-SHA256, never sending the secret key over the wire.

```
SIGNATURE V4 — STEP-BY-STEP CRYPTOGRAPHIC CHAIN:

═══════════════════════════════════════════════════════════════
STEP 1: CANONICAL REQUEST (normalize the HTTP request)
═══════════════════════════════════════════════════════════════

  canonical_request =
    "PUT\n"                                        ← HTTP method
    "/vacation.jpg\n"                              ← URI-encoded path
    "\n"                                           ← Query string (empty)
    "content-length:3342816\n"                     ← Sorted headers (lowercase)
    "content-type:image/jpeg\n"
    "host:my-photos.s3.us-east-1.amazonaws.com\n"
    "x-amz-content-sha256:e3b0c44298fc1c14...\n"
    "x-amz-date:20260329T120000Z\n"
    "\n"                                           ← Blank line
    "content-length;content-type;host;"            ← Signed header names
    "x-amz-content-sha256;x-amz-date\n"
    "e3b0c44298fc1c149afbf4c8996fb924..."          ← SHA-256 of body

  hashed_canonical = SHA256(canonical_request)
    = "7344ae5b7ee6c3e7e6b0fe0640412a37625d1fbfff95aeac396d882"  (64 hex chars)

═══════════════════════════════════════════════════════════════
STEP 2: STRING TO SIGN
═══════════════════════════════════════════════════════════════

  string_to_sign =
    "AWS4-HMAC-SHA256\n"                           ← Algorithm
    "20260329T120000Z\n"                           ← Timestamp
    "20260329/us-east-1/s3/aws4_request\n"         ← Credential scope
    "7344ae5b7ee6c3e7e6b0fe0640412a..."            ← Hashed canonical request

═══════════════════════════════════════════════════════════════
STEP 3: SIGNING KEY (4-layer HMAC chain)
═══════════════════════════════════════════════════════════════

  kSecret  = "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"  ← Your secret
  kDate    = HMAC-SHA256("AWS4" + kSecret, "20260329")
             = 32 bytes: 0x546F... (binary, not hex)
  kRegion  = HMAC-SHA256(kDate,   "us-east-1")
             = 32 bytes: 0x8A1C...
  kService = HMAC-SHA256(kRegion, "s3")
             = 32 bytes: 0xF3E2...
  kSigning = HMAC-SHA256(kService, "aws4_request")
             = 32 bytes: 0xC4AF...

  WHY 4 LAYERS?
    Each layer scopes the key to: date → region → service → purpose
    If someone intercepts a request signed for "us-east-1/s3",
    they CANNOT use that signature for "eu-west-1/dynamodb"
    The key is valid for exactly ONE day, ONE region, ONE service

═══════════════════════════════════════════════════════════════
STEP 4: FINAL SIGNATURE
═══════════════════════════════════════════════════════════════

  signature = HMAC-SHA256(kSigning, string_to_sign)
    = "fe5f80f77d5fa3beca038a248ff027d0445342fe2855ddc963176630326f1024"
    (32 bytes = 64 hex characters)

  This goes into the Authorization header:
    Authorization: AWS4-HMAC-SHA256
      Credential=AKIAIOSFODNN7EXAMPLE/20260329/us-east-1/s3/aws4_request,
      SignedHeaders=content-length;content-type;host;x-amz-content-sha256;x-amz-date,
      Signature=fe5f80f77d5fa3beca038a248ff027d0445342fe2855ddc963176630326f1024

BYTE COST OF AUTHENTICATION:
  Authorization header: ~350 bytes
  x-amz-content-sha256 header: ~80 bytes (64 hex chars + header name)
  x-amz-date header: ~30 bytes
  Total auth overhead per request: ~460 bytes
  
  SHA-256 of body (for PUT):
    3.2 MB file → SHA-256 processes 64-byte blocks
    3,342,816 / 64 = 52,232 compression rounds
    On modern CPU (SHA-NI instructions): ~2 GB/s
    Time: ~1.6 ms for a 3.2 MB file

SECURITY PROPERTIES:
  Secret key NEVER leaves the client (only HMAC derivatives sent)
  Request is tamper-proof (changing ANY header invalidates signature)
  Replay window: ±15 minutes (x-amz-date checked by server)
  Body integrity: SHA-256 in signature covers every byte of payload
```

---

## Pre-Signed URLs — Byte-Level Construction

```
PRE-SIGNED URL — HOW TEMPORARY ACCESS WORKS:

  Instead of signing via Authorization header, the signature is
  embedded in the URL query string.

  Generated URL:
    https://my-photos.s3.us-east-1.amazonaws.com/vacation.jpg
      ?X-Amz-Algorithm=AWS4-HMAC-SHA256
      &X-Amz-Credential=AKIAIOSFODNN7EXAMPLE/20260329/us-east-1/s3/aws4_request
      &X-Amz-Date=20260329T120000Z
      &X-Amz-Expires=3600                     ← Valid for 1 hour (seconds)
      &X-Amz-SignedHeaders=host
      &X-Amz-Signature=fe5f80f77d5fa3beca038a248ff027d0445342fe285...

  BYTE BREAKDOWN:
    Base URL:        ~60 bytes
    Query params:    ~380 bytes
    Total:           ~440 bytes

  WHAT'S DIFFERENT FROM NORMAL AUTH:
    x-amz-content-sha256 = "UNSIGNED-PAYLOAD" (body NOT signed)
    X-Amz-Expires = included in canonical request (controls TTL)
    Anyone with the URL can access the object — no AWS credentials needed

  AFTER EXPIRATION (X-Amz-Expires seconds later):
    S3 checks: current_time > (X-Amz-Date + X-Amz-Expires)?
    If yes → 403 Forbidden: "Request has expired"
    The URL is cryptographically bound to the timestamp
    Cannot extend expiry without the secret key

  MAX EXPIRY:
    STS/IAM role credentials: max 12 hours (43200 seconds)
    IAM user credentials: max 7 days (604800 seconds)
```

---

## Erasure Coding — The Math at Byte Level

S3 doesn't make 3 full copies like most systems. It uses Reed-Solomon erasure coding to get the same (better) durability at ~1.5× storage instead of 3×.

```
REED-SOLOMON ERASURE CODING — HOW IT WORKS:

  Configuration: k=8 data shards, m=4 parity shards (8+4 scheme)
  → Can lose ANY 4 of 12 shards and still reconstruct ALL data

═══════════════════════════════════════════════════════════════
STEP 1: SPLIT OBJECT INTO DATA SHARDS
═══════════════════════════════════════════════════════════════

  Object: "vacation.jpg" = 3,342,816 bytes (3.2 MB)
  
  Split into k=8 equal data shards:
    Shard D0: bytes[0 .. 417,851]          = 417,852 bytes
    Shard D1: bytes[417,852 .. 835,703]    = 417,852 bytes
    Shard D2: bytes[835,704 .. 1,253,555]  = 417,852 bytes
    Shard D3: bytes[1,253,556 .. 1,671,407]= 417,852 bytes
    Shard D4: bytes[1,671,408 .. 2,089,259]= 417,852 bytes
    Shard D5: bytes[2,089,260 .. 2,507,111]= 417,852 bytes
    Shard D6: bytes[2,507,112 .. 2,924,963]= 417,852 bytes
    Shard D7: bytes[2,924,964 .. 3,342,815]= 417,852 bytes

  (Last shard zero-padded if not evenly divisible)

═══════════════════════════════════════════════════════════════
STEP 2: COMPUTE PARITY SHARDS (Galois Field arithmetic)
═══════════════════════════════════════════════════════════════

  Reed-Solomon operates over GF(2^8) — a "Galois Field" of 256 elements
  Every byte (0x00 to 0xFF) is an element in this field

  Encoding matrix (Vandermonde or Cauchy):
    ┌                                        ┐   ┌────┐   ┌────┐
    │ 1  0  0  0  0  0  0  0 │ ← identity    │   │ D0 │   │ D0 │
    │ 0  1  0  0  0  0  0  0 │   (data shards│   │ D1 │   │ D1 │
    │ 0  0  1  0  0  0  0  0 │    pass thru)  │   │ D2 │   │ D2 │
    │ 0  0  0  1  0  0  0  0 │               │   │ D3 │   │ D3 │
    │ 0  0  0  0  1  0  0  0 │               │ × │ D4 │ = │ D4 │
    │ 0  0  0  0  0  1  0  0 │               │   │ D5 │   │ D5 │
    │ 0  0  0  0  0  0  1  0 │               │   │ D6 │   │ D6 │
    │ 0  0  0  0  0  0  0  1 │               │   │ D7 │   │ D7 │
    │ a  b  c  d  e  f  g  h │ ← parity rows │   └────┘   │ P0 │
    │ i  j  k  l  m  n  o  p │               │             │ P1 │
    │ q  r  s  t  u  v  w  x │               │             │ P2 │
    │ y  z  A  B  C  D  E  F │               │             │ P3 │
    └                                        ┘             └────┘

  Each parity byte = XOR-based linear combination of data bytes
  in GF(2^8): P0[i] = a·D0[i] ⊕ b·D1[i] ⊕ ... ⊕ h·D7[i]

  GF(2^8) multiplication:
    Multiply two bytes using polynomial arithmetic modulo x^8 + x^4 + x^3 + x + 1
    (irreducible polynomial 0x11B for AES-standard GF)
    Example: 0x53 × 0xCA = 0x01 in GF(2^8)
    Implemented via lookup tables (256 × 256 = 64 KB) or SIMD instructions

═══════════════════════════════════════════════════════════════
STEP 3: DISTRIBUTE SHARDS ACROSS AVAILABILITY ZONES
═══════════════════════════════════════════════════════════════

  12 shards distributed across ≥3 AZs:
    AZ-a (data center 1): D0, D1, D4, D5       (4 shards)
    AZ-b (data center 2): D2, D3, D6, D7       (4 shards)
    AZ-c (data center 3): P0, P1, P2, P3       (4 shards)

  Can survive:
    - 1 entire AZ destroyed:     4 shards lost, 8 remain ✓ (need 8)
    - 2 AZs destroyed:           8 shards lost, 4 remain ✗ (need 8)
    - Any 4 individual disk failures: 4 lost, 8 remain ✓

═══════════════════════════════════════════════════════════════
STEP 4: RECONSTRUCTION (when shards are lost)
═══════════════════════════════════════════════════════════════

  Say D2 and D5 are lost (disks failed).
  We have: D0, D1, D3, D4, D6, D7, P0, P1, P2, P3 (10 shards)
  Need at least k=8 shards to reconstruct.

  1. Pick any 8 surviving shards (e.g., D0,D1,D3,D4,D6,D7,P0,P1)
  2. Extract the 8 corresponding ROWS from the encoding matrix
  3. Invert this 8×8 sub-matrix (in GF(2^8))
  4. Multiply: inverted_matrix × surviving_shards = all 8 data shards
  
  Matrix inversion in GF(2^8):
    8×8 matrix: 64 elements, each 1 byte
    Gaussian elimination: O(k^3) = O(512) GF multiplications
    Time: ~microseconds (trivial)
    
  Actual reconstruction bottleneck: DISK I/O to read 8 shards
    8 × 417,852 bytes = 3.3 MB read from 8 different disks
    Parallel: ~10-15 ms (HDD seek + transfer)
    → Reconstruction is I/O bound, not CPU bound

STORAGE EFFICIENCY COMPARISON:
  ┌────────────────────┬──────────────┬─────────────┬───────────────┐
  │ Strategy           │ Storage Cost │ Durability  │ Fault Tolerance│
  ├────────────────────┼──────────────┼─────────────┼───────────────┤
  │ 3× replication     │ 3.0×         │ 99.9999%    │ 2 copies lost │
  │ Erasure 4+2        │ 1.5×         │ 99.9999%    │ 2 shards lost │
  │ Erasure 8+4 (S3)   │ 1.5×         │ 99.999999999│ 4 shards lost │
  │ Erasure 10+4       │ 1.4×         │ 99.999999999│ 4 shards lost │
  │ Erasure 16+4       │ 1.25×        │ 99.999999999│ 4 shards lost │
  └────────────────────┴──────────────┴─────────────┴───────────────┘

  S3 at exabyte scale:
    3× replication: 3 EB storage needed, ~$60M/month (HDD)
    Erasure 8+4:    1.5 EB needed,       ~$30M/month
    Savings: $30M/month = $360M/year
```

---

## Checksums — Integrity Verification at Every Boundary

```
S3 CHECKSUM CHAIN — TRUST NOTHING, VERIFY EVERYTHING:

  ┌──────────┐  SHA-256   ┌──────────┐  CRC32-C   ┌──────────┐
  │ Client   │ ─────────→ │ S3       │ ──────────→│ Disk     │
  │          │  (in-flight)│ Frontend │ (at-rest)  │ (shard)  │
  └──────────┘            └──────────┘            └──────────┘

LAYER 1 — CLIENT TO S3 (in-flight integrity):

  x-amz-content-sha256 header:
    Client computes: SHA-256 of entire request body
    Sends as hex string: "e3b0c44298fc1c149afbf4c8996fb924..."
    S3 computes: SHA-256 of received bytes
    Comparison: if mismatch → 400 BadDigest (data corrupted in transit)

  Content-MD5 header (optional but recommended):
    Client: Base64(MD5(body))
    MD5 output: 16 bytes = 128 bits
    Base64 encoded: 24 characters
    Example: "rL0Y20zC+Fzt72VPzMSk2A=="

  HTTP chunked transfer with trailing checksum (newer):
    Client sends body in chunks, each with its own CRC32-C
    Final chunk: CRC32-C of entire body
    Allows streaming uploads without buffering entire file

LAYER 2 — WITHIN S3 (shard integrity):

  Each shard stored with its own CRC32-C:
    ┌─────────────────────────────────────────────┐
    │ Shard on disk:                               │
    │   [4 bytes: CRC32-C] [N bytes: shard data]  │
    │                                              │
    │ CRC32-C:                                     │
    │   32-bit checksum, hardware-accelerated      │
    │   Intel SSE4.2 crc32 instruction             │
    │   Speed: ~30 GB/s per core                   │
    │   For 417 KB shard: ~14 ns to verify         │
    └─────────────────────────────────────────────┘

  WHY CRC32-C (not MD5 or SHA-256)?
    CRC32-C:  4 bytes, hardware-accelerated, ~30 GB/s    ← at-rest checks
    MD5:      16 bytes, no HW accel,         ~500 MB/s   ← legacy
    SHA-256:  32 bytes, HW accel (SHA-NI),   ~2 GB/s     ← security-critical
    
    At-rest integrity doesn't need cryptographic strength,
    just bit-flip detection. CRC32-C is 15× faster.

LAYER 3 — BACKGROUND SCRUBBING (continuous verification):

  S3 continuously reads and verifies shards in the background:
    1. Read shard bytes from disk
    2. Recompute CRC32-C
    3. Compare with stored CRC32-C
    4. If mismatch → shard is corrupt
    5. Reconstruct from remaining shards (erasure coding)
    6. Write new healthy shard to a different disk
    7. Log the event (bit-rot detection metrics)

  Scrubbing rate: every shard verified every ~90 days
  At 1 billion shards: ~11 million verifications per day
  Each verification: read ~500 KB + CRC compute = ~50 μs CPU, ~5 ms disk
```

---

## ShardStore & LSM Trees — On-Disk Binary Format

S3's ShardStore uses a Log-Structured Merge tree. Here's what it looks like at the byte level.

```
LSM TREE — ON-DISK FORMAT:

═══════════════════════════════════════════════════════════════
MEMTABLE (in RAM) — Write Destination
═══════════════════════════════════════════════════════════════

  Data structure: Red-Black Tree or Skip List (sorted by key)
  Typical size: 64-256 MB before flush

  Each entry:
    ┌──────────────────────────────────────────────────────────┐
    │ key_length   (4 bytes, uint32)                           │
    │ key          (variable bytes)                            │
    │   = bucket + "/" + object_key + "/" + shard_id            │
    │   Example: "my-photos/vacation.jpg/shard-03"             │
    │   Typical: 50-200 bytes                                  │
    │ value_length (4 bytes, uint32)                           │
    │ value        (variable bytes)                            │
    │   = actual shard data (e.g., 417,852 bytes)              │
    │ timestamp    (8 bytes, uint64)                           │
    │   = nanosecond-precision write time                      │
    │ type         (1 byte)                                    │
    │   = 0x01 (PUT) or 0x02 (DELETE/tombstone)               │
    └──────────────────────────────────────────────────────────┘

  WRITE-AHEAD LOG (WAL):
    Before writing to MemTable, entry is appended to WAL on disk
    Sequential write only — fast even on HDD
    If node crashes, replay WAL to recover MemTable
    
    WAL entry: [4B length][entry bytes][4B CRC32-C]
    WAL is truncated after MemTable flushes to SSTable

═══════════════════════════════════════════════════════════════
SSTABLE (Sorted String Table) — On-Disk Immutable File
═══════════════════════════════════════════════════════════════

  When MemTable hits threshold → flush to disk as SSTable:

  ┌──────────────────────────────────────────────────────────────┐
  │ SSTable FILE LAYOUT:                                          │
  │                                                              │
  │ ┌──────────────────────────────────────────────────────────┐ │
  │ │ DATA BLOCKS (default 4 KB each):                         │ │
  │ │   Block 0: [entry, entry, entry, ...]                   │ │
  │ │   Block 1: [entry, entry, entry, ...]                   │ │
  │ │   Block 2: [entry, entry, entry, ...]                   │ │
  │ │   ... (sorted by key)                                   │ │
  │ │   Block N: [entry, entry, entry, ...]                   │ │
  │ │                                                          │ │
  │ │   Each block:                                            │ │
  │ │     [entries][block_type: 1B][crc32: 4B]                │ │
  │ │     block_type: 0x00=uncompressed, 0x01=snappy,         │ │
  │ │                 0x02=zstd, 0x03=lz4                     │ │
  │ └──────────────────────────────────────────────────────────┘ │
  │ ┌──────────────────────────────────────────────────────────┐ │
  │ │ META BLOCKS:                                              │ │
  │ │   Bloom filter block (see below)                         │ │
  │ │   Statistics block (min/max key, entry count, sizes)     │ │
  │ └──────────────────────────────────────────────────────────┘ │
  │ ┌──────────────────────────────────────────────────────────┐ │
  │ │ INDEX BLOCK:                                              │ │
  │ │   [last_key_of_block_0, offset_0, size_0]               │ │
  │ │   [last_key_of_block_1, offset_1, size_1]               │ │
  │ │   ...                                                    │ │
  │ │   [last_key_of_block_N, offset_N, size_N]               │ │
  │ │   (binary-searchable to find which block has your key)   │ │
  │ └──────────────────────────────────────────────────────────┘ │
  │ ┌──────────────────────────────────────────────────────────┐ │
  │ │ FOOTER (48 bytes, fixed):                                 │ │
  │ │   meta_index_offset  (8 bytes)                           │ │
  │ │   meta_index_size    (8 bytes)                           │ │
  │ │   index_offset       (8 bytes)                           │ │
  │ │   index_size         (8 bytes)                           │ │
  │ │   version            (4 bytes)                           │ │
  │ │   magic_number       (8 bytes) = 0x88E241B785F4CFF7     │ │
  │ │   footer_checksum    (4 bytes, CRC32-C)                  │ │
  │ └──────────────────────────────────────────────────────────┘ │
  └──────────────────────────────────────────────────────────────┘

  READING A KEY FROM SSTABLE:
    1. Read footer (last 48 bytes) → find index block offset
    2. Read index block → binary search for target key's data block
    3. Read data block (4 KB) → sequential scan for exact key
    Total: 2-3 disk I/Os (footer cached in RAM, so usually 1-2)

═══════════════════════════════════════════════════════════════
COMPACTION — MERGING SSTables
═══════════════════════════════════════════════════════════════

  Level 0:  [SST_5] [SST_4] [SST_3]     ← freshly flushed, may overlap
  Level 1:  [SST_merged_1]               ← non-overlapping key ranges
  Level 2:  [SST_big_1] [SST_big_2]     ← larger, non-overlapping
  Level 3:  [SST_huge_1] [SST_huge_2] [SST_huge_3]

  Each level is ~10× larger than the previous.
  Level 0: ~256 MB, Level 1: ~2.5 GB, Level 2: ~25 GB, Level 3: ~250 GB

  COMPACTION PROCESS:
    1. Pick SSTables to merge (e.g., all Level 0 → Level 1)
    2. Open all input SSTables, merge-sort by key
    3. Write new SSTable(s) at the target level
    4. Delete old SSTables

  I/O PATTERN:
    All reads: sequential (scan through input SSTables)
    All writes: sequential (write output SSTable)
    HDD-friendly! No random I/O at any point.

  WRITE AMPLIFICATION:
    One write to MemTable → flushed to Level 0 → compacted to Level 1
    → compacted to Level 2 → compacted to Level 3
    Each byte is rewritten ~4-10× over its lifetime
    Trade-off: more disk writes, but reads are fast (fewer SSTables to check)
```

---

## Bloom Filters — Bit-Level Internals

```
BLOOM FILTER — THE "DEFINITELY NOT HERE" DATA STRUCTURE:

  PROBLEM: Reading from an LSM tree might check 20+ SSTables.
  Each check = 1 disk I/O on HDD = 10 ms.
  20 SSTables × 10 ms = 200 ms per read. Unacceptable.

  SOLUTION: Each SSTable has a Bloom filter (tiny, in RAM).
  Bloom filter says "this key is NOT in this SSTable" → skip it!
  Reduces disk reads from 20 to 1-2.

═══════════════════════════════════════════════════════════════
BIT ARRAY STRUCTURE
═══════════════════════════════════════════════════════════════

  Bloom filter = bit array of m bits, initially all zeros.
  Uses k independent hash functions.

  Example: m = 80 bits (10 bytes), k = 3 hash functions

  Insert key "my-photos/vacation.jpg/shard-03":
    h1("my-photos/vacation.jpg/shard-03") % 80 = 12  → set bit 12
    h2("my-photos/vacation.jpg/shard-03") % 80 = 47  → set bit 47
    h3("my-photos/vacation.jpg/shard-03") % 80 = 71  → set bit 71

  Bit array after insertion:
    Position:  0         1         2         3         4         5         6         7
    Bit:       00000000  00000100  00000000  00000000  00000000  10000000  00000000  00000001
                                ↑ bit 12                     ↑ bit 47              ↑ bit 71

  Check key "my-photos/birthday.jpg/shard-01":
    h1 % 80 = 12  → bit 12 is SET ✓
    h2 % 80 = 33  → bit 33 is NOT SET ✗
    → Key is DEFINITELY NOT in this SSTable. Skip it!

  Check key "my-photos/vacation.jpg/shard-03":
    h1 % 80 = 12  → SET ✓
    h2 % 80 = 47  → SET ✓
    h3 % 80 = 71  → SET ✓
    → Key MIGHT be here. Read the SSTable to confirm.

═══════════════════════════════════════════════════════════════
SIZING AND FALSE POSITIVE RATES
═══════════════════════════════════════════════════════════════

  False positive rate = (1 - e^(-kn/m))^k
    n = number of entries in SSTable
    m = number of bits in filter
    k = number of hash functions

  PRACTICAL SIZES:
  ┌──────────────┬──────────┬────────┬───────────────────────┐
  │ Entries (n)  │ Bits (m) │ k      │ False Positive Rate   │
  ├──────────────┼──────────┼────────┼───────────────────────┤
  │ 100,000      │ 1.2 MB   │ 7      │ 1%                    │
  │ 100,000      │ 960 KB   │ 10     │ 0.1%                  │
  │ 1,000,000    │ 12 MB    │ 7      │ 1%                    │
  │ 1,000,000    │ 9.6 MB   │ 10     │ 0.1%                  │
  └──────────────┴──────────┴────────┴───────────────────────┘

  ~10 bits per entry = 1% false positive rate
  SSTable with 100K entries: Bloom filter = 120 KB (fits in L2 cache!)

  AT S3 SCALE:
    Billions of SSTables × average 120 KB filter = ~120 TB of Bloom filters
    Stored in RAM across thousands of storage nodes
    Avoids billions of unnecessary disk reads per day

HASH FUNCTIONS (practical implementation):
  Don't use k independent hash functions (expensive).
  Use double hashing with MurmurHash3:
    h(i) = h1 + i × h2   (for i = 0, 1, ..., k-1)
    h1 = MurmurHash3_upper64(key)
    h2 = MurmurHash3_lower64(key)
  One hash call gives you k probe positions!
```

---

## Multipart Upload — Byte-Level Protocol

For objects larger than ~100 MB, S3 uses multipart upload: split the file into parts, upload in parallel, assemble on the server.

```
MULTIPART UPLOAD — THREE-PHASE PROTOCOL:

═══════════════════════════════════════════════════════════════
PHASE 1: INITIATE (get an upload ID)
═══════════════════════════════════════════════════════════════

  Request:
    POST /vacation-4k.mp4?uploads HTTP/1.1
    Host: my-videos.s3.us-east-1.amazonaws.com
    Content-Type: video/mp4

  Response:
    <?xml version="1.0" encoding="UTF-8"?>
    <InitiateMultipartUploadResult>
      <Bucket>my-videos</Bucket>
      <Key>vacation-4k.mp4</Key>
      <UploadId>VXBsb2FkIElEIGZvciB...</UploadId>
    </InitiateMultipartUploadResult>

  UploadId: ~80 bytes, opaque server-generated token
  S3 creates a metadata entry: "pending multipart for this key"

═══════════════════════════════════════════════════════════════
PHASE 2: UPLOAD PARTS (parallel, any order)
═══════════════════════════════════════════════════════════════

  File: vacation-4k.mp4 = 2,147,483,648 bytes (2 GB)
  Split into parts of 256 MB each = 8 parts

  Each part upload:
    PUT /vacation-4k.mp4?partNumber=3&uploadId=VXBsb2FkI... HTTP/1.1
    Content-Length: 268435456
    Content-MD5: dGhpcyBpcyBhIHRlc3Q=
    
    [268,435,456 bytes of video data]

  Response per part:
    HTTP/1.1 200 OK
    ETag: "7778aef83f66abc1fa1e8477f296d394"    ← MD5 of this part

  PARALLEL UPLOAD MATH:
    Sequential (1 stream × 100 Mbps):
      2 GB / 12.5 MB/s = 160 seconds

    Parallel (8 streams × 100 Mbps each, or 1 stream × 800 Mbps):
      256 MB / 12.5 MB/s = 20 seconds per part (all in parallel)
      + overhead = ~25 seconds total
      6.4× faster!

  PART CONSTRAINTS:
    Minimum part size: 5 MB (except last part)
    Maximum part size: 5 GB
    Maximum parts: 10,000
    Maximum object size: 5 TB (10,000 × 5 GB)
    Minimum part number: 1
    Maximum part number: 10,000

═══════════════════════════════════════════════════════════════
PHASE 3: COMPLETE (assemble the parts)
═══════════════════════════════════════════════════════════════

  Request:
    POST /vacation-4k.mp4?uploadId=VXBsb2FkI... HTTP/1.1
    
    <CompleteMultipartUpload>
      <Part>
        <PartNumber>1</PartNumber>
        <ETag>"a54357aff0632cce46d942af68356b38"</ETag>
      </Part>
      <Part>
        <PartNumber>2</PartNumber>
        <ETag>"0c78aef83f66abc1fa1e8477f296d394"</ETag>
      </Part>
      ... (all 8 parts)
    </CompleteMultipartUpload>

  S3 BACKEND OPERATIONS:
    1. Verify all part ETags match stored part ETags
    2. Verify parts are contiguous (no gaps in part numbers)
    3. Update metadata: link all shards into one logical object
    4. Compute final ETag: MD5(MD5(part1) + MD5(part2) + ...) + "-8"
    5. Apply erasure coding to each part independently
    6. Delete "pending multipart" metadata entry
    7. Object is now readable

  COST OF MULTIPART:
    Initiate: 1 API call ($0.000005)
    Upload: 8 API calls ($0.000040)
    Complete: 1 API call ($0.000005)
    Total: 10 API calls = $0.00005
    + storage cost of the 2 GB × 1.5× erasure = 3 GB stored

ABORT MULTIPART (cleanup orphaned uploads):
    DELETE /vacation-4k.mp4?uploadId=VXBsb2FkI... HTTP/1.1
    → Deletes all uploaded parts, frees storage
    
    S3 Lifecycle rule can auto-abort after N days:
    { "AbortIncompleteMultipartUpload": { "DaysAfterInitiation": 7 } }
    This prevents "ghost" uploads from consuming storage indefinitely.
```

---

## GET Object — The Read Path at Byte Level

```
COMPLETE GET FLOW — READING "vacation.jpg":

═══════════════════════════════════════════════════════════════
STEP 1 — DNS + TCP + TLS (connection setup)
═══════════════════════════════════════════════════════════════

  DNS: my-photos.s3.us-east-1.amazonaws.com → 52.216.100.XXX
    S3 DNS returns different IPs to distribute load
    TTL: 5 seconds (very short — enables rapid failover)
    Route 53 + anycast: picks nearest S3 frontend

  TCP: 3-way handshake (SYN → SYN+ACK → ACK)
    Time: ~1 ms (same region), ~50-100 ms (cross-continent)

  TLS 1.3: 1-RTT handshake (ClientHello → ServerHello+Finished)
    S3 supports TLS 1.2 and 1.3
    Cipher: TLS_AES_256_GCM_SHA384 (most common for S3)
    Time: ~1-2 ms (same region)

  Total connection setup: ~3 ms (same region), ~150 ms (cross-continent)
  With HTTP/2 + connection reuse: 0 ms for subsequent requests

═══════════════════════════════════════════════════════════════
STEP 2 — HTTP REQUEST
═══════════════════════════════════════════════════════════════

  GET /vacation.jpg HTTP/1.1\r\n
  Host: my-photos.s3.us-east-1.amazonaws.com\r\n
  Authorization: AWS4-HMAC-SHA256 ...\r\n
  x-amz-content-sha256: e3b0c44298fc1c149afbf4c8996fb924...\r\n
  x-amz-date: 20260329T120500Z\r\n
  Range: bytes=0-1048575\r\n          ← Optional: first 1 MB only
  If-None-Match: "d41d8cd98f00b204"\r\n  ← Conditional: return 304 if unchanged
  \r\n

  Wire size: ~500 bytes (all headers, no body for GET)

═══════════════════════════════════════════════════════════════
STEP 3 — S3 FRONTEND PROCESSING
═══════════════════════════════════════════════════════════════

  1. Parse HTTP headers                        ~10 μs
  2. Verify Signature V4:
     - Reconstruct canonical request           ~5 μs
     - Compute signing key (4 HMAC-SHA256)     ~20 μs
     - Verify final signature                  ~5 μs
     Total auth: ~30 μs
  3. Check bucket policy + IAM:
     - In-memory policy cache hit              ~5 μs
     - Cache miss → DynamoDB lookup            ~2-5 ms
  4. Rate limiting check                       ~1 μs
  5. Route to correct internal partition       ~1 μs

═══════════════════════════════════════════════════════════════
STEP 4 — METADATA LOOKUP
═══════════════════════════════════════════════════════════════

  Key: "my-photos/vacation.jpg"
  
  Metadata cache (RAM):
    Distributed hash table across metadata fleet
    Cache hit rate: ~99% for recently accessed objects
    Hit: return shard locations in ~100 μs

  Cache miss → metadata store (persistent KV):
    Read from LSM-tree-backed storage
    Bloom filter check: ~200 ns
    SSTable lookup: 1-2 disk I/Os = ~10-20 ms (HDD)
    
  Metadata record returned:
    ┌──────────────────────────────────────────────────────────┐
    │ object_key:    "my-photos/vacation.jpg"                  │
    │ version_id:    "3HL4kqtJlcpXroDTDmJ+rmSpXd3dIbrHY"     │
    │ size:          3,342,816 bytes                           │
    │ content_type:  "image/jpeg"                              │
    │ etag:          "d41d8cd98f00b204e9800998ecf8427e"        │
    │ storage_class: STANDARD                                  │
    │ encryption:    AES-256 (SSE-S3)                          │
    │ erasure_scheme: 8+4 Reed-Solomon                         │
    │ shard_map:                                               │
    │   D0: {node: sn-1042, disk: /dev/sdf, offset: 0x3A120} │
    │   D1: {node: sn-1087, disk: /dev/sdg, offset: 0x7F340} │
    │   D2: {node: sn-2015, disk: /dev/sde, offset: 0x12680} │
    │   D3: {node: sn-2044, disk: /dev/sdf, offset: 0xAB910} │
    │   D4: {node: sn-1042, disk: /dev/sdh, offset: 0x55C40} │
    │   D5: {node: sn-3001, disk: /dev/sdf, offset: 0x89120} │
    │   D6: {node: sn-3022, disk: /dev/sdg, offset: 0xCD560} │
    │   D7: {node: sn-2015, disk: /dev/sdh, offset: 0xE1A80} │
    │   P0-P3: {nodes: sn-3044, sn-3067, ...}                │
    │ user_metadata:                                           │
    │   x-amz-meta-photographer: "chetan"                     │
    │ checksums:                                               │
    │   sha256: "a7ffc6f8bf1ed76651c14756a061d662..."         │
    │   per_shard_crc32c: [0x4F5C2A1B, 0x7D3E8C0A, ...]     │
    └──────────────────────────────────────────────────────────┘

═══════════════════════════════════════════════════════════════
STEP 5 — PARALLEL SHARD READS
═══════════════════════════════════════════════════════════════

  Need k=8 data shards. Read from all 8 data shard locations in parallel.
  (Parity shards only read if a data shard is missing or slow.)

  For each shard read (on the storage node):
    1. Find shard in local LSM tree                    ~10-50 μs
    2. Read shard data from HDD (417 KB)               ~5-10 ms
       HDD: seek 5 ms + transfer 417KB at 200 MB/s    = ~7 ms
    3. Verify CRC32-C                                  ~14 ns
    4. Decrypt (AES-256-GCM, hardware AES-NI)          ~100 μs
    5. Send shard bytes to S3 frontend via internal network

  All 8 reads happen in parallel:
    Latency = max(all 8 shard reads) = ~7-15 ms
    (slowest disk determines overall latency)

  TAIL LATENCY OPTIMIZATION:
    S3 sends read requests to data shards AND 1-2 parity shards
    Uses whichever k=8 respond first
    If one HDD is slow, parity shard fills the gap
    This is called "hedged requests" or "speculative reads"
    Reduces p99 latency from ~50ms to ~15ms

═══════════════════════════════════════════════════════════════
STEP 6 — REASSEMBLE AND STREAM TO CLIENT
═══════════════════════════════════════════════════════════════

  S3 frontend receives 8 shard payloads:
    D0 (417,852 B) + D1 (417,852 B) + ... + D7 (417,852 B)
    Concatenate in order → original object (3,342,816 bytes)

  Stream to client as HTTP response:
    HTTP/1.1 200 OK\r\n
    Content-Type: image/jpeg\r\n
    Content-Length: 3342816\r\n
    ETag: "d41d8cd98f00b204e9800998ecf8427e"\r\n
    Last-Modified: Sat, 29 Mar 2026 10:00:00 GMT\r\n
    x-amz-server-side-encryption: AES256\r\n
    Accept-Ranges: bytes\r\n
    \r\n
    [3,342,816 bytes of JPEG data, streamed as shards arrive]

  STREAMING (not buffering):
    S3 starts sending response as soon as first shard arrives
    Don't wait for all 8 — send shard D0 bytes immediately
    Client receives a smooth stream of bytes
    Time to first byte: ~10-15 ms
    Time to last byte: ~15-25 ms (3.2 MB at internal network speeds)

═══════════════════════════════════════════════════════════════
COMPLETE TIMING BREAKDOWN
═══════════════════════════════════════════════════════════════

  DNS lookup:            0-5 ms   (cached after first request)
  TCP handshake:         1-2 ms   (same region)
  TLS handshake:         1-2 ms   (TLS 1.3, 1-RTT)
  Request transmission:  <1 ms    (500 bytes)
  Auth verification:     ~30 μs
  Metadata lookup:       0.1-5 ms (cache hit vs miss)
  Parallel shard reads:  7-15 ms  (HDD dominant)
  Decryption:            ~0.1 ms  (AES-NI hardware)
  Response streaming:    5-15 ms  (network transfer)
  ────────────────────────────────────────
  TOTAL (first request):  ~20-50 ms
  TOTAL (warm connection): ~10-25 ms (skip DNS/TCP/TLS)

  S3 SLA: first-byte latency ≤100 ms for STANDARD (p99)
  Actual p50: ~15 ms, p99: ~50 ms (same region)
```

---

## Server-Side Encryption — Byte-Level Cryptography

```
S3 SERVER-SIDE ENCRYPTION (SSE-S3, the default):

  Algorithm: AES-256-GCM (Galois/Counter Mode)
  Key hierarchy: envelope encryption (2 layers)

  ┌──────────────────────────────────────────────────────────┐
  │ KEY HIERARCHY:                                            │
  │                                                          │
  │ Root Key (AWS KMS)                                       │
  │   ↓ encrypts                                             │
  │ Bucket Key (rotated periodically)                        │
  │   ↓ encrypts                                             │
  │ Data Encryption Key (DEK) — unique per object            │
  │   ↓ encrypts                                             │
  │ Object Data (your bytes)                                 │
  └──────────────────────────────────────────────────────────┘

  FOR EACH OBJECT:
    1. Generate random DEK: 32 bytes (256 bits) of cryptographic randomness
    2. Generate random IV: 12 bytes (96 bits) — nonce for GCM
    3. Encrypt: AES-256-GCM(DEK, IV, shard_data) → ciphertext + 16-byte auth tag
    4. Encrypt DEK with bucket key: AES-256-GCM(bucket_key, DEK) → encrypted_DEK
    5. Store alongside shard: [encrypted_DEK (48B) | IV (12B) | ciphertext | tag (16B)]

  AES-256-GCM BYTE-LEVEL:
    ┌──────────────────────────────────────────────────────────┐
    │ Encrypted shard on disk:                                  │
    │                                                          │
    │ [encrypted_DEK: 48 bytes]  ← DEK encrypted by bucket key │
    │ [IV: 12 bytes]             ← nonce, unique per encryption │
    │ [ciphertext: 417,852 bytes] ← AES-256-GCM encrypted data │
    │ [auth_tag: 16 bytes]        ← integrity + authenticity    │
    │                                                          │
    │ Total overhead per shard: 76 bytes                        │
    │ 76 / 417,852 = 0.018% overhead — negligible              │
    └──────────────────────────────────────────────────────────┘

  PERFORMANCE (Intel AES-NI hardware acceleration):
    AES-256-GCM encrypt: ~5-10 GB/s per core
    Decrypt: ~5-10 GB/s per core
    For 417 KB shard: ~40-80 μs
    Encryption adds <0.1 ms to request latency

  WHY GCM (not CBC)?
    GCM = Galois/Counter Mode:
      - Authenticated encryption (integrity + confidentiality in one pass)
      - Parallelizable (each 16-byte block encrypts independently)
      - Hardware-accelerated (AES-NI + PCLMULQDQ for GHASH)
    CBC = Cipher Block Chaining:
      - NOT authenticated (need separate HMAC)
      - Sequential (each block depends on previous)
      - 2× slower in practice
```

---

## Range Requests — Byte-Level Random Access

```
RANGE REQUESTS — READ ANY BYTE RANGE OF AN OBJECT:

  Request:
    GET /vacation-4k.mp4 HTTP/1.1
    Range: bytes=1048576-2097151       ← Read bytes 1 MB to 2 MB

  Response:
    HTTP/1.1 206 Partial Content
    Content-Range: bytes 1048576-2097151/2147483648
    Content-Length: 1048576
    [1,048,576 bytes of video data]

HOW S3 SERVES A RANGE REQUEST EFFICIENTLY:

  Object: 2 GB video, erasure coded 8+4
  Each data shard: 256 MB

  Range requested: bytes 1,048,576 to 2,097,151 (1 MB chunk)

  1. Which shards contain this range?
     byte 1,048,576 / 256 MB per shard = shard index 0 (first 256 MB)
     byte 2,097,151 / 256 MB per shard = shard index 0 (still first shard)
     → Only need to read from shard D0!

  2. Offset within shard D0:
     byte 1,048,576 within the object = byte 1,048,576 within shard D0
     Read bytes [1,048,576 .. 2,097,151] from shard D0

  3. Only 1 shard read instead of 8!
     Latency: ~5-10 ms (single HDD read)
     vs. full object read: 7-15 ms (8 parallel reads)

  RANGE REQUEST ACROSS SHARD BOUNDARIES:
    Range: bytes 250,000,000 to 260,000,000 (10 MB spanning shard boundary)
    Shard D0: bytes 0..268,435,455 → read bytes 250M to end of shard
    Shard D1: bytes 268,435,456..536,870,911 → read bytes 0 to 1.5M mark
    → 2 shard reads in parallel

USE CASES:
  Video streaming: browser requests 2 MB chunks as user watches
  PDF viewer: download page 50 without loading pages 1-49
  S3 Select: push SQL query to storage, read only matching byte ranges
  Resumable downloads: interrupted at byte 500,000 → resume from 500,001
```

---

## S3 Consistency Model — Byte-Level Guarantees

```
S3 STRONG CONSISTENCY (since December 2020):

  BEFORE (eventual consistency):
    PUT vacation.jpg          → 200 OK
    GET vacation.jpg          → 404 Not Found (stale cache!)
    Wait 1-2 seconds...
    GET vacation.jpg          → 200 OK (propagation delay)

  NOW (strong read-after-write):
    PUT vacation.jpg          → 200 OK
    GET vacation.jpg          → 200 OK (immediately, guaranteed)

HOW STRONG CONSISTENCY IS ACHIEVED:

  S3 metadata uses a consensus-based replication protocol:

  ┌──────────────────────────────────────────────────────────┐
  │ PUT vacation.jpg:                                        │
  │                                                          │
  │ 1. Write data shards to storage nodes (erasure coded)   │
  │ 2. Write metadata to PRIMARY metadata node              │
  │ 3. Replicate metadata to SECONDARY metadata nodes       │
  │ 4. Wait for MAJORITY acknowledgment (quorum write)      │
  │    - 3 metadata replicas: need 2/3 to ACK              │
  │ 5. Return 200 OK to client                              │
  │                                                          │
  │ GET vacation.jpg:                                        │
  │                                                          │
  │ 1. Read from metadata node                               │
  │ 2. If node has the write (majority committed) → return  │
  │ 3. If node is stale → redirect to fresh node            │
  │                                                          │
  │ Consistency guarantee:                                   │
  │   Any GET after a successful PUT sees the new data      │
  │   Any LIST after a successful PUT includes the new key  │
  └──────────────────────────────────────────────────────────┘

  COST OF STRONG CONSISTENCY:
    Old (eventual):  metadata write = 1 node, return fast
    New (strong):    metadata write = wait for 2/3 nodes
    Additional latency: ~1-3 ms per write (quorum round-trip)
    Amazon measured: <1% latency increase at the p50
```

---

## Storage Classes — What Changes at the Byte Level

```
STORAGE CLASS DIFFERENCES (under the hood):

  ┌────────────────────┬──────────────┬──────────────┬──────────────────┐
  │ Class              │ Erasure Code │ Storage Media │ Retrieval        │
  ├────────────────────┼──────────────┼──────────────┼──────────────────┤
  │ STANDARD           │ 8+4 (3 AZs) │ HDD (online) │ Immediate        │
  │ STANDARD-IA        │ 8+4 (3 AZs) │ HDD (online) │ Immediate        │
  │ ONE ZONE-IA        │ 8+4 (1 AZ)  │ HDD (online) │ Immediate        │
  │ GLACIER INSTANT    │ 8+4 (3 AZs) │ HDD (online) │ Immediate        │
  │ GLACIER FLEXIBLE   │ varies       │ Tape/offline │ 1-12 hours       │
  │ GLACIER DEEP       │ varies       │ Tape/offline │ 12-48 hours      │
  └────────────────────┴──────────────┴──────────────┴──────────────────┘

  STANDARD vs STANDARD-IA (Infrequent Access):
    Same erasure coding, same HDDs, same durability
    Difference: PRICING MODEL only
      Standard: $0.023/GB/month, $0.0004/1000 GETs
      IA:       $0.0125/GB/month, $0.001/1000 GETs (cheaper storage, pricier reads)
    The bits on disk are identical!
    S3 just charges you differently based on the metadata tag.

  GLACIER FLEXIBLE/DEEP — ACTUALLY DIFFERENT:
    Data may be on magnetic tape (not spinning disk)
    Tape robots physically load cartridges into tape drives
    Tape seek: ~30-60 seconds (robot + tape positioning)
    Sequential tape read: ~200-400 MB/s (fast once positioned)
    
    "Expedited retrieval" (1-5 min): data was pre-staged on disk cache
    "Standard retrieval" (3-5 hours): tape robot queue
    "Bulk retrieval" (5-12 hours): lowest priority, cheapest

  INTELLIGENT-TIERING (automated):
    S3 monitors access patterns per object:
      Accessed in last 30 days    → Frequent Access tier
      Not accessed for 30 days    → Infrequent Access tier  
      Not accessed for 90 days    → Archive Instant tier
      Not accessed for 180 days   → Archive tier (optional)
    
    Metadata tag updated automatically, no data movement needed
    (Data only moves to tape for Archive/Deep Archive)
    Monitoring cost: $0.0025 per 1000 objects/month
```

---

## The Complete PUT Journey — End to End

```
COMPLETE LIFECYCLE: Client uploads "report.pdf" (10 MB) to S3

═══════════════════════════════════════════════════════════════
STEP 1 — CLIENT PREPARES REQUEST
═══════════════════════════════════════════════════════════════

  Compute SHA-256 of report.pdf (10,485,760 bytes):
    Process 64-byte blocks: 10,485,760 / 64 = 163,840 rounds
    SHA-256 hardware (SHA-NI): ~5 ms
    Result: "8d7a4c2f1e3b5a6d9c0f2e4a..."  (64 hex chars)

  Compute Content-MD5:
    MD5(report.pdf) = 16 bytes → Base64 → "dGhpcyBpcyBhIHRlc3Q="
    Time: ~3 ms (no hardware acceleration)

  Build Signature V4:
    Canonical request → string to sign → 4-layer HMAC
    Time: ~0.1 ms

═══════════════════════════════════════════════════════════════
STEP 2 — TCP + TLS + HTTP
═══════════════════════════════════════════════════════════════

  DNS: docs-bucket.s3.us-east-1.amazonaws.com → 52.216.X.X    1 ms
  TCP 3-way handshake: SYN → SYN+ACK → ACK                    1 ms
  TLS 1.3: ClientHello → ServerHello → Finished                2 ms
  HTTP PUT headers: ~700 bytes                                  <1 ms
  HTTP PUT body: 10,485,760 bytes
    At 1 Gbps: 10 MB / 125 MB/s = ~80 ms
    TCP slow start + congestion: ~100 ms realistic

═══════════════════════════════════════════════════════════════
STEP 3 — S3 FRONTEND RECEIVES
═══════════════════════════════════════════════════════════════

  Verify Signature V4:                           30 μs
  Compute SHA-256 of received body:              5 ms
  Compare with x-amz-content-sha256 header:      1 μs
    Match → body integrity confirmed
    Mismatch → 400 BadDigest (data corrupted in transit)
  
  Check IAM/bucket policy:                       5-50 μs
  Check storage class, encryption settings:      1 μs

═══════════════════════════════════════════════════════════════
STEP 4 — ERASURE CODING
═══════════════════════════════════════════════════════════════

  Split 10 MB into k=8 data shards:
    Each shard: 10,485,760 / 8 = 1,310,720 bytes (~1.25 MB)

  Compute m=4 parity shards (Reed-Solomon GF(2^8)):
    8 data shards → 4 parity shards
    Matrix multiplication in GF(2^8): 12 × 1,310,720 byte operations
    With SIMD (AVX2/AVX-512): ~2-5 ms for 10 MB
    Total: 12 shards × 1.25 MB = 15 MB stored (1.5× overhead)

═══════════════════════════════════════════════════════════════
STEP 5 — ENCRYPT EACH SHARD
═══════════════════════════════════════════════════════════════

  For each of 12 shards:
    Generate DEK: 32 random bytes
    Generate IV: 12 random bytes
    AES-256-GCM encrypt shard (1.25 MB):
      Hardware AES-NI: ~0.1 ms per shard × 12 = ~1.2 ms total
    Encrypt DEK with bucket key: ~10 μs
    Prepend: [encrypted_DEK(48B) | IV(12B)] + append [auth_tag(16B)]

═══════════════════════════════════════════════════════════════
STEP 6 — WRITE SHARDS TO STORAGE NODES
═══════════════════════════════════════════════════════════════

  12 shards sent to 12 different storage nodes (across 3 AZs):
    Network transfer (internal): ~0.5-1 ms per shard (parallel)
    Storage node writes to ShardStore (LSM MemTable): ~0.1 ms each
    All writes parallel: total ~1-2 ms

  Each storage node:
    1. Append to WAL (sequential HDD write): ~2 ms
    2. Write to MemTable (RAM): ~10 μs
    3. ACK to S3 frontend

  Wait for all 12 shards written:
    Latency = max(12 parallel writes) = ~3-5 ms

═══════════════════════════════════════════════════════════════
STEP 7 — WRITE METADATA (with strong consistency)
═══════════════════════════════════════════════════════════════

  Metadata record:
    key: "docs-bucket/report.pdf"
    value: {shard_map, checksums, encryption_keys, size, etag, ...}
    Size: ~500 bytes

  Write to metadata quorum (3 replicas, wait for 2):
    Metadata node 1 (primary): write → ACK         1-2 ms
    Metadata node 2 (secondary): replicate → ACK   1-2 ms
    Metadata node 3 (secondary): replicate → (async, don't wait)
    Quorum latency: ~2-3 ms

═══════════════════════════════════════════════════════════════
STEP 8 — RETURN SUCCESS TO CLIENT
═══════════════════════════════════════════════════════════════

  HTTP/1.1 200 OK\r\n
  ETag: "d41d8cd98f00b204e9800998ecf8427e"\r\n
  x-amz-server-side-encryption: AES256\r\n
  x-amz-request-id: 0A49CE4060975EAC\r\n
  \r\n

═══════════════════════════════════════════════════════════════
COMPLETE TIMING SUMMARY
═══════════════════════════════════════════════════════════════

  Client SHA-256 + MD5 + signing:     8 ms
  DNS + TCP + TLS:                    4 ms
  Upload 10 MB body:                  100 ms     ← DOMINANT (network)
  S3 auth + integrity check:          5 ms
  Erasure coding:                     3 ms
  Encryption:                         1 ms
  Shard writes (12 parallel):         5 ms
  Metadata quorum write:              3 ms
  Response to client:                 1 ms
  ─────────────────────────────────────────
  TOTAL:                              ~130 ms

  For a 100 KB file:  ~15-25 ms  (no network transfer bottleneck)
  For a 1 GB file:    ~8-12 s    (network-dominated)
  For a 5 TB file:    multipart, ~40-60 min at 1 Gbps
```

---

## 30-Second Revision Box

```
WIRE FORMAT: standard HTTP/1.1 or HTTP/2 with AWS Signature V4 (4-layer
  HMAC-SHA256: secret → date → region → service → signing_key). ~460 bytes
  auth overhead per request. Body integrity: SHA-256 in-flight, CRC32-C at-rest.

ERASURE CODING: Reed-Solomon over GF(2^8). Split into k data + m parity shards.
  S3 uses 8+4: can lose any 4 of 12 shards. 1.5× storage (vs 3× for replication).
  Shards spread across ≥3 AZs. Reconstruction: invert 8×8 GF matrix → I/O bound.

ON-DISK: ShardStore uses LSM tree. Write to MemTable (RAM) → flush as SSTable
  (sorted, immutable, block-compressed) → background compaction merges levels.
  All I/O is sequential → HDD-friendly. Bloom filters (10 bits/key, 1% FP) skip
  irrelevant SSTables. SSTable footer (48B) + index block + data blocks (4KB each).

CHECKSUMS: 3 layers. Client SHA-256 in-flight → S3 CRC32-C per shard at-rest
  (hardware SSE4.2, 30 GB/s) → background scrubbing every ~90 days.

ENCRYPTION: AES-256-GCM per shard. Envelope encryption: root key → bucket key
  → per-object DEK. Hardware AES-NI: 5-10 GB/s. Overhead: 76 bytes per shard.

MULTIPART: InitiateUpload → UploadParts (parallel, 5MB-5GB each, max 10K parts)
  → CompleteUpload. Max object: 5 TB. ETag = MD5(concat(part_MD5s))-N.

CONSISTENCY: strong read-after-write via quorum metadata writes (2/3 replicas
  ACK before returning 200). <1% latency increase over eventual consistency.

LATENCY: GET first-byte ~15-50ms (metadata cache hit + parallel HDD reads).
  PUT 10 MB ~130ms (network-dominated). Hedged reads to parity shards cut p99.
```

---

## Revision Flashcards

**Q: How does AWS Signature V4 work without sending the secret key?**
A: The client computes a 4-layer HMAC-SHA256 chain: secret → date → region → service → signing_key. The signing_key signs the canonical request. The server, knowing the same secret, independently derives the same signing_key and verifies the signature. The secret never appears in the HTTP request.

**Q: Why does S3 use erasure coding instead of replication?**
A: Erasure coding (8+4 Reed-Solomon) stores 1.5× the original data and tolerates 4 shard failures. Replication stores 3× and tolerates 2 failures. At exabyte scale, erasure coding saves hundreds of millions of dollars per year in storage costs while providing better durability.

**Q: What is GF(2^8) and why does erasure coding use it?**
A: Galois Field of 256 elements where every byte (0x00-0xFF) is a valid element. Arithmetic (add = XOR, multiply via lookup tables) is exact with no rounding errors and stays within 1 byte. This lets Reed-Solomon encode/decode using simple byte operations at hardware-accelerated speeds.

**Q: How does S3's LSM tree make HDDs fast?**
A: All writes go to RAM (MemTable) first, then flush as sorted immutable files (SSTables) to disk sequentially. Compaction merges SSTables via sequential reads and writes. No random I/O at any point. Bloom filters skip irrelevant SSTables during reads, reducing disk I/O from ~20 to 1-2 reads.

**Q: Why does S3 use CRC32-C at rest but SHA-256 in flight?**
A: CRC32-C runs at 30 GB/s via hardware SSE4.2 instructions — perfect for continuous background scrubbing of billions of shards. SHA-256 provides cryptographic integrity (tamper detection) for data in transit but is slower at ~2 GB/s. Different threat models call for different checksum strengths.

**Q: How does S3 achieve strong consistency?**
A: Metadata writes use quorum replication — the PUT returns 200 only after 2 of 3 metadata replicas acknowledge. Subsequent GETs are guaranteed to see the write because they read from nodes that participated in the quorum. This adds ~1-3ms latency compared to the old eventual consistency model.

**Q: What happens during a range request across shard boundaries?**
A: S3 calculates which shards contain the requested byte range. If the range spans a shard boundary, only the 2 affected shards are read in parallel (not all 8). This makes byte-range reads for video streaming extremely efficient — typically 1-2 disk reads instead of 8.

---

**Prev: [[02-How-Amazon-S3-Works-In-Depth]] | Next: [[03-How-Amazon-Lambda-Works-In-Depth]]**
