# Resilience Patterns — Interview Thinking

> **Permanent Recall:** Discuss resilience proactively when designing systems. Bring up circuit breakers for dependency failures, rate limiting for abuse/quotas, chaos engineering when asked about testing. Answer "what happens when X fails?" with a clear strategy: fail fast, fallback, degrade gracefully. Demonstrate production awareness—not just theory.

---

## How to Discuss Resilience in Interviews

**Trigger phrases:** "Design a system that...", "How do you handle failures?", "What happens when the database goes down?"

**Response structure:**
1. **Acknowledge** — "Failures are guaranteed; we need to design for them."
2. **Layers** — "I'd apply defense in depth: rate limit, timeout, circuit breaker, retry, bulkhead."
3. **Specifics** — Pick 2–3 patterns and explain *why* for this design.
4. **Trade-offs** — "Circuit breaker adds latency on open; we'd use a fallback."

> **FAANG Tip:** Don't wait for "resilience" to be mentioned. When designing any distributed system, weave in: "We'd add circuit breakers for external APIs," or "Rate limiting at the API gateway."

---

## When to Bring Up Circuit Breakers

**Natural insertion points:**
- "We call Payment API / Auth Service / Recommendation service..."
- "There are multiple microservices..."
- "We have external third-party dependencies..."

**Sample line:** "Since we depend on the Payment API, we'd wrap those calls in a circuit breaker. If it's failing, we fail fast and return a cached/fallback response rather than timing out and blocking our threads."

---

## Rate Limiting Conversation

**Interview flow:**
1. **Problem:** "How do we prevent abuse / ensure fair usage / control costs?"
2. **Solution:** "Rate limiting at the gateway. Token bucket or sliding window—token bucket if we want burst allowance."
3. **Implementation:** "Redis for distributed state; key by user ID or API key."
4. **Response:** "429 Too Many Requests with Retry-After header."

**Follow-up ready:** "Different tiers: free 100/min, paid 1000/min. Per-user and per-IP limits for abuse."

---

## Demonstrating Chaos Engineering Awareness

**When to mention:** "How do you test failover?" / "How do you know the system is resilient?"

**Answer structure:**
- "Chaos engineering—intentionally inject failures in production-like environments."
- "Netflix Chaos Monkey: randomly terminate instances; we verify the system recovers."
- "Game days: planned exercises, e.g., kill an AZ, simulate DB failover."
- "Fault injection: add latency, error rates, network partitions."

> **FAANG Tip:** "We don't just hope it works—we break it on purpose to validate. Chaos Monkey for instances; Chaos Kong for AZ failure."

---

## How to Answer "What Happens When X Fails?"

**Template:**
1. **Identify impact** — "If the Payment API fails, checkout breaks."
2. **Immediate response** — "Circuit breaker opens after N failures; we stop calling it."
3. **Fallback** — "Return 'Payment temporarily unavailable' or cached last-known state."
4. **Recovery** — "After timeout, we try a few test requests (Half-Open). If they succeed, we close the circuit."
5. **Prevention** — "We'd also have bulkheads so Payment API failure doesn't starve Search threads."

**Example:** "When the DB fails: connection pool exhausts, circuit breaker trips, we serve from cache where possible, return 503 for writes. Read replicas might still be up for reads."

---

## Presenting Graceful Degradation Strategy

**Structure:**
1. **Define critical path** — "Core: login, cart, checkout. Non-core: recommendations, reviews."
2. **Fallback hierarchy** — "Recommendations down → hide section or show popular items from cache."
3. **Feature flags** — "We can disable non-critical features under load."
4. **User communication** — "Show 'Some features temporarily limited' vs full outage."

**Sample:** "We'd rank features by criticality. Payment, auth—no degradation. Recommendations—cache or hide. Analytics—async, can lag. We'd use feature flags to toggle in emergencies."

---

## Bulletproof Failure Answer Template

When asked "What happens when X fails?" use this structure:

1. **Detect** — "We'd have health checks and circuit breaker monitoring failure rate."
2. **Contain** — "Circuit breaker opens; we stop calling the dependency."
3. **Fallback** — "We return cached data / default / 503 with Retry-After."
4. **Isolate** — "Bulkhead ensures other services aren't affected."
5. **Recover** — "After timeout, Half-Open tests; if successful, we resume."
6. **Communicate** — "User sees 'Temporarily unavailable' or partial data."

---

## Proactive Resilience Phrases

Use these to demonstrate depth:
- "We'd add circuit breakers for external APIs to fail fast."
- "Rate limiting at the gateway—token bucket for burst allowance."
- "Idempotency keys for any write—payment, order creation."
- "Exponential backoff with jitter to avoid retry storms."
- "Chaos engineering—we break it on purpose to validate."

---

## What Interviewers Listen For

| They Want to Hear | Avoid Saying |
|-------------------|--------------|
| "Circuit breaker to fail fast" | "We'd retry until it works" |
| "Idempotency for writes" | "Retries are safe" |
| "Exponential backoff" | "We retry 3 times immediately" |
| "Graceful degradation" | "System goes down" |
| "Chaos engineering" | "We test in staging only" |

---

## Handling Follow-Up "What If?"

**"What if the circuit breaker is stuck open?"** — "We'd have health checks; after timeout we enter Half-Open and test. Monitoring alerts if open too long."

**"What if rate limiting blocks legitimate traffic?"** — "We'd tune limits based on normal traffic; use different tiers; allow burst for token bucket; return 429 with Retry-After so clients can retry."

**"What if fallback data is stale?"** — "We'd show 'Last updated X min ago' or similar; set TTL on cached fallback; prioritize correctness for critical paths."

---

## Closing Strong

End resilience discussions with: "We'd layer these patterns—rate limit, timeout, circuit breaker, retry with backoff, idempotency for writes, and graceful degradation. Plus monitoring to tune and alert." Shows systems thinking.

---

## Resilience in System Design Interviews

When designing any distributed system (chat, URL shortener, payment, etc.), allocate 2–3 minutes to resilience. Mention: "For resilience we'd add circuit breakers for external calls, rate limiting at the gateway, timeouts, retries with backoff for transient errors, and idempotency for any writes." Interviewers notice the completeness.

---

## 30-SECOND REVISION BOX

```
DISCUSS RESILIENCE: proactively when designing
CIRCUIT BREAKER: mention when discussing dependencies
RATE LIMITING: abuse, quotas, cost control
CHAOS: Chaos Monkey, game days, fault injection
"X FAILS?": impact → circuit breaker → fallback → recovery
GRACEFUL DEGRADATION: critical path vs optional; feature flags
```

---

**Prev: [[03_Design-Template]] | Next: [[05_Common-Mistakes]]**
