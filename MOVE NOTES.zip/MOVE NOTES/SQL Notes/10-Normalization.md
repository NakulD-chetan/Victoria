# Normalization — Complete Guide

> **Normalization = Database ko organize karo taaki redundancy (duplicate data) kam ho aur anomalies na aayein.**
> Yeh topic **theory interviews** mein 100% puchha jaata hai — 1NF, 2NF, 3NF, BCNF samajhna zaroori hai!

---

## Why Normalization?

### Problem: Unnormalized Table (Redundancy Issues)

```
Table: student_courses (UNNORMALIZED)
+----+---------+---------+----------+-------------+-------------+
| id | name    | phone   | course   | instructor  | inst_phone  |
+----+---------+---------+----------+-------------+-------------+
| 1  | Rahul   | 9876543 | SQL      | Prof. Gupta | 1111111111  |
| 1  | Rahul   | 9876543 | Python   | Prof. Verma | 2222222222  |
| 2  | Priya   | 9876544 | SQL      | Prof. Gupta | 1111111111  |
| 2  | Priya   | 9876544 | Java     | Prof. Singh | 3333333333  |
| 3  | Amit    | 9876545 | Python   | Prof. Verma | 2222222222  |
+----+---------+---------+----------+-------------+-------------+
```

### 3 Types of Anomalies:

| Anomaly | Problem | Example |
|---------|---------|---------|
| **Insertion Anomaly** | Naya data insert karne mein dikkat | Naya course add karna hai but koi student enroll nahi hua — row kaise banayein? |
| **Update Anomaly** | Ek jagah update kiya, doosri jagah purana reh gaya | Prof. Gupta ka phone change hua → 2 rows mein update karna padega. Ek miss ho gaya toh inconsistency! |
| **Deletion Anomaly** | Data delete karte waqt useful data bhi chala jaata hai | Amit ka record delete kiya → Prof. Verma ka phone number bhi chala gaya! |

> **Normalization ka goal:** In teeno anomalies ko **eliminate** karna!

---

## Functional Dependency (FD) — Pehle Yeh Samjho!

> **Definition:** X → Y means "X functionally determines Y" — agar X ki value pata hai, toh Y ki value uniquely determine ho jaati hai.

```
Student ID → Student Name        (ID se naam pata chal jaata hai)
{Student ID, Course} → Grade     (Student + Course milke Grade determine karte hain)
Course → Instructor              (Har course ka ek instructor hai)
```

### Types of FDs:

| Type | Meaning | Example |
|------|---------|---------|
| **Full FD** | Puri key pe depend karta hai | `{Student, Course} → Grade` |
| **Partial FD** | Key ke PART pe depend karta hai | `Student → Name` (sirf student se determine, course ki zaroorat nahi) |
| **Transitive FD** | A → B → C (indirect dependency) | `Student → Department → HOD` |

---

## Normal Forms — Step by Step

```
Unnormalized → 1NF → 2NF → 3NF → BCNF → 4NF → 5NF
                 ↑      ↑      ↑      ↑
              Most interviews mein yahan tak puchha jaata hai
```

---

## 1NF — First Normal Form

> **Rule:** Har cell mein **sirf ek atomic (single) value** honi chahiye. No multi-valued attributes, no repeating groups.

### Before 1NF (violating):

```
+----+---------+------------------+
| id | name    | phones           |
+----+---------+------------------+
| 1  | Rahul   | 9876543, 9876544 |  ← Multiple values in 1 cell! ❌
| 2  | Priya   | 9876545          |
+----+---------+------------------+
```

### After 1NF:

```
+----+---------+---------+
| id | name    | phone   |
+----+---------+---------+
| 1  | Rahul   | 9876543 |  ← 1 value per cell ✅
| 1  | Rahul   | 9876544 |
| 2  | Priya   | 9876545 |
+----+---------+---------+
```

> **1NF Rules:**
> 1. Har column mein **atomic values** (single, indivisible)
> 2. Har column ka **same data type**
> 3. Har column ka **unique naam**
> 4. **Order matter nahi karta** (rows/columns ka)

---

## 2NF — Second Normal Form

> **Rule:** 1NF mein ho + **No Partial Dependencies** (non-key attributes should depend on the WHOLE primary key, not just part of it).

> **2NF sirf tab relevant hai jab Composite Primary Key ho!** Single column PK mein partial dependency possible nahi hai.

### Before 2NF (Partial Dependency):

```
Primary Key: {student_id, course_id}

+------------+-----------+-------+---------+--------------+
| student_id | course_id | grade | stu_name| course_name  |
+------------+-----------+-------+---------+--------------+
| 1          | C101      | A     | Rahul   | SQL          |
| 1          | C102      | B     | Rahul   | Python       |
| 2          | C101      | A+    | Priya   | SQL          |
+------------+-----------+-------+---------+--------------+

Partial Dependencies:
  student_id → stu_name     (sirf part of PK se determine ho raha!)
  course_id  → course_name  (sirf part of PK se determine ho raha!)
  {student_id, course_id} → grade  (full PK — yeh ok hai)
```

### After 2NF (Split into 3 tables):

```
Table: students              Table: courses              Table: enrollments
+------------+---------+     +-----------+-------------+  +------------+-----------+-------+
| student_id | stu_name|     | course_id | course_name |  | student_id | course_id | grade |
+------------+---------+     +-----------+-------------+  +------------+-----------+-------+
| 1          | Rahul   |     | C101      | SQL         |  | 1          | C101      | A     |
| 2          | Priya   |     | C102      | Python      |  | 1          | C102      | B     |
+------------+---------+     +-----------+-------------+  | 2          | C101      | A+    |
                                                          +------------+-----------+-------+
```

> **2NF Summary:** Partial dependency hatao → table split karo!

---

## 3NF — Third Normal Form

> **Rule:** 2NF mein ho + **No Transitive Dependencies** (non-key attribute should not depend on another non-key attribute).

### Before 3NF (Transitive Dependency):

```
Table: employees
+--------+---------+--------+-----------+
| emp_id | name    | dept   | dept_head |
+--------+---------+--------+-----------+
| 1      | Rahul   | IT     | Mr. Kumar |
| 2      | Priya   | HR     | Mrs. Shah |
| 3      | Amit    | IT     | Mr. Kumar |
+--------+---------+--------+-----------+

Dependencies:
  emp_id → dept          (Direct — OK)
  emp_id → dept_head     (Wait... yeh indirect hai!)
  dept   → dept_head     (Transitive: emp_id → dept → dept_head)
```

> **Problem:** dept_head **emp_id** pe depend nahi karta — **dept** pe depend karta hai.
> emp_id → dept → dept_head = **Transitive Dependency** = 3NF violation!

### After 3NF:

```
Table: employees             Table: departments
+--------+---------+--------+ +--------+-----------+
| emp_id | name    | dept   | | dept   | dept_head |
+--------+---------+--------+ +--------+-----------+
| 1      | Rahul   | IT     | | IT     | Mr. Kumar |
| 2      | Priya   | HR     | | HR     | Mrs. Shah |
| 3      | Amit    | IT     | +--------+-----------+
+--------+---------+--------+
```

> **3NF Summary:** Transitive dependency hatao → non-key attributes sirf key pe depend karein!

---

## BCNF — Boyce-Codd Normal Form (Strong 3NF)

> **Rule:** 3NF mein ho + **Every determinant must be a candidate key.**

> BCNF = "stricter" version of 3NF. 3NF ke baad bhi kuch rare cases mein anomaly aa sakti hai — BCNF solve karta hai.

### Before BCNF:

```
Table: teaching
+---------+----------+--------+
| student | subject  | teacher|
+---------+----------+--------+
| Rahul   | SQL      | Gupta  |
| Priya   | SQL      | Verma  |
| Rahul   | Python   | Verma  |
+---------+----------+--------+

Primary Key: {student, subject}
FDs:
  {student, subject} → teacher   (PK determines teacher)
  teacher → subject               (Each teacher teaches ONE subject)
```

> **Problem:** `teacher → subject` — teacher is a determinant, but teacher is NOT a candidate key! BCNF violation.

### After BCNF:

```
Table: teacher_subject        Table: student_teacher
+---------+----------+        +---------+---------+
| teacher | subject  |        | student | teacher |
+---------+----------+        +---------+---------+
| Gupta   | SQL      |        | Rahul   | Gupta   |
| Verma   | Python   |        | Priya   | Verma   |
+---------+----------+        | Rahul   | Verma   |
                              +---------+---------+
```

---

## 4NF — Fourth Normal Form

> **Rule:** BCNF mein ho + **No Multi-Valued Dependencies (MVD).**

```
Before 4NF:
+---------+----------+---------+
| student | hobby    | course  |
+---------+----------+---------+
| Rahul   | Cricket  | SQL     |
| Rahul   | Cricket  | Python  |
| Rahul   | Music    | SQL     |
| Rahul   | Music    | Python  |
+---------+----------+---------+

Problem: hobby aur course INDEPENDENT hain — but har combination store karna pad raha hai.

After 4NF (split):
student_hobby              student_course
+---------+----------+     +---------+--------+
| student | hobby    |     | student | course |
+---------+----------+     +---------+--------+
| Rahul   | Cricket  |     | Rahul   | SQL    |
| Rahul   | Music    |     | Rahul   | Python |
+---------+----------+     +---------+--------+
```

---

## Normal Forms Summary Table

| NF | Rule | Eliminates |
|----|------|-----------|
| **1NF** | Atomic values, no repeating groups | Multi-valued cells |
| **2NF** | 1NF + No partial dependency | Part-of-key dependency |
| **3NF** | 2NF + No transitive dependency | Non-key → non-key dependency |
| **BCNF** | 3NF + Every determinant is candidate key | Non-CK determinants |
| **4NF** | BCNF + No multi-valued dependency | Independent multi-valued attributes |

> **Interview Short Answer:**
> - **1NF** → Atomic values
> - **2NF** → Full dependency on WHOLE key
> - **3NF** → Direct dependency on key (no transitive)
> - **BCNF** → Every determinant is a candidate key

---

## Denormalization — Kab Normalize Mat Karo?

> **Definition:** Intentionally adding redundancy back to improve READ performance.

| Normalization | Denormalization |
|--------------|-----------------|
| Redundancy hatao | Redundancy wapas daalo |
| Write fast, Read slow | Read fast, Write slow |
| Data integrity strong | Data integrity risk |
| OLTP systems | OLAP/Analytics/Reporting |
| Multiple JOINs | Fewer JOINs |

> **Kab Denormalize karo?**
> - Reporting/Analytics database (read-heavy)
> - Agar bahut zyada JOINs slow kar rahe hain
> - Caching layers mein
> - Data Warehouse (Star Schema, Snowflake Schema)

---

## Quick Memory Card

| Term | One Line | Trick |
|------|----------|-------|
| 1NF | Atomic values only | "Ek cell, ek value" |
| 2NF | No partial dependency | "Poori key pe depend karo" |
| 3NF | No transitive dependency | "Directly key pe depend karo" |
| BCNF | Determinant = Candidate Key | "Strong 3NF" |
| Partial FD | Part of PK se determine | Only with composite keys |
| Transitive FD | A → B → C | Indirect dependency |
| Anomaly | Insert/Update/Delete problem | Normalization se fix hota hai |
| Denormalization | Intentional redundancy | Performance ke liye |

> **Trick to Remember NFs:**
> "**The Key** (1NF: atomic), **The Whole Key** (2NF: full dependency), **And Nothing But The Key** (3NF: no transitive), **So Help Me Codd** (BCNF)"

---

*Notes Source: Database Normalization Theory + Interview preparation material*
