# Sliding Window — Concept

> **Permanent Recall:** Sliding Window maintains a dynamic range [left, right] over a contiguous subarray/substring. Instead of recalculating from scratch for every window position, you **add** the new element entering the window and **remove** the element leaving. This converts O(n·k) brute force into O(n). Two variants: Fixed-size (window size known) and Variable-size (window size determined by constraint). FAANG tests this in 25%+ of array/string rounds.

---

## Core Idea (2 Lines)

**Maintain a window [left, right] that slides across data. Expand right to explore, shrink left to satisfy constraints. Never re-examine elements you've already processed.**

---

## Intuition

Imagine you're looking through a **physical window on a moving train**. You see a portion of the landscape at any time. As the train moves forward, new scenery enters from the right and old scenery exits from the left. You never go back to re-examine what's already passed.

```
Array:  [2, 1, 5, 1, 3, 2]

Brute Force: Check EVERY subarray → O(n²) or O(n·k)
  [2]  [2,1]  [2,1,5]  [2,1,5,1]  ...  re-examining everything

Sliding Window: Maintain running state, slide forward → O(n)
  [2, 1, 5]  →  remove 2, add 1  →  [1, 5, 1]  →  remove 1, add 3  →  [5, 1, 3]
   sum=8          sum=8-2+1=7          sum=7         sum=7-1+3=9
```

The key insight: **each element enters the window exactly once and leaves exactly once** → O(n) total work.

---

## Why Brute Force Fails


| Approach       | What It Does                                            | Time            | Problem                                                   |
| -------------- | ------------------------------------------------------- | --------------- | --------------------------------------------------------- |
| Brute Force    | For each start index, iterate through all valid windows | O(n²) or O(n·k) | Redundant computation — recalculates overlapping portions |
| Sliding Window | Maintains running state, incrementally updates          | O(n)            | None — optimal                                            |


**The redundancy:** When you shift a window by 1 position, only 1 element enters and 1 leaves. But brute force recalculates ALL k elements. That's (k-1) wasted operations per shift.

```
Brute Force recalculates everything:
  Window [2,1,5] → sum = 2+1+5 = 8    (3 additions)
  Window [1,5,1] → sum = 1+5+1 = 7    (3 additions)  ← Wasted! 1+5 already known

Sliding Window reuses work:
  Window [2,1,5] → sum = 8
  Window [1,5,1] → sum = 8 - 2 + 1 = 7  (1 subtraction + 1 addition)
```

---

## Optimization Reasoning

### Fixed-Size Window

- Window size `k` is given
- Maintain running aggregate (sum, max, count)
- Slide: `add arr[right]`, `remove arr[right - k]`
- O(n) time, O(1) space

### Variable-Size Window

- Window size is NOT given — determined by a **constraint**
- Expand right to explore possibilities
- Shrink left when constraint is violated
- Track best valid window seen so far
- O(n) time (each element enters/exits at most once)

```mermaid
flowchart TD
    A[left = 0] --> B[for right in 0..n]
    B --> C[ADD arr right to window state]
    C --> D{WINDOW\nINVALID?}
    D -- Yes --> E[REMOVE arr left from state]
    E --> F[left += 1]
    F --> D
    D -- No --> G[UPDATE answer with current window]
    G --> B

    style A fill:#339af0,color:#fff
    style D fill:#fcc419,color:#000
    style G fill:#51cf66,color:#fff
```



ASCII fallback

```
VARIABLE WINDOW FRAMEWORK:
┌──────────────────────────────────────────────┐
│  left = 0                                    │
│  for right in range(n):                      │
│      ADD arr[right] to window state          │
│      while WINDOW IS INVALID:                │
│          REMOVE arr[left] from window state  │
│          left += 1                           │
│      UPDATE answer with current window       │
└──────────────────────────────────────────────┘
```



---

## Time Complexity Intuition

- **O(n)** — NOT O(n²) despite the nested while loop
- Why? `left` pointer only moves forward. Over the entire algorithm, `left` moves at most `n` times total
- Each element: added once (when `right` reaches it), removed once (when `left` passes it)
- Total operations: 2n → O(n)

**Space:** O(1) for sum-based windows. O(k) or O(alphabet) if using hash maps for character frequency.

---

## When NOT to Use This Pattern


| Scenario                                               | Why Not                                     | Use Instead                    |
| ------------------------------------------------------ | ------------------------------------------- | ------------------------------ |
| Non-contiguous elements needed                         | Window requires contiguous range            | Two Pointers, DP               |
| Need to consider ALL subsets                           | Window only tracks contiguous subarrays     | Backtracking, Bit Manipulation |
| Array is not ordered AND you need sorted access        | Window doesn't maintain order               | Heap, Sorted Set               |
| Problem involves pairs/triplets at arbitrary positions | Window restricts to adjacent elements       | Hash Map, Two Pointers         |
| Negative numbers with "sum ≥ target" constraint        | Shrinking left may increase sum (negatives) | Prefix Sum + Binary Search     |
| Need minimum subarray with negative values             | Window shrink direction unclear             | Deque-based or DP              |


### The Negative Number Trap

**Critical FAANG catch:** Variable sliding window for sum-based problems assumes that **adding elements increases the sum** and **removing elements decreases the sum**. With negative numbers, this assumption breaks:

```
arr = [2, -1, 3, -2, 4], target = 3

Sliding window may miss valid windows because shrinking left
could INCREASE the sum (by removing a negative number)
```

**Golden Rule:** Sliding window for sum constraints works reliably only with **non-negative values** (or when the problem guarantees this).

---

## Two Types Decision Table


| Signal                               | Fixed Window    | Variable Window |
| ------------------------------------ | --------------- | --------------- |
| "subarray of size k"                 | ✅               |                 |
| "maximum/minimum of size k"          | ✅               |                 |
| "longest/shortest subarray where..." |                 | ✅               |
| "minimum window containing..."       |                 | ✅               |
| Window size given explicitly         | ✅               |                 |
| Window size depends on content       |                 | ✅               |
| "at most k distinct"                 |                 | ✅               |
| "sum equals/exceeds target"          | Could be either | ✅ usually       |


---

## Golden Rules

1. **If you see "contiguous subarray/substring" + optimization → think Sliding Window**
2. **Fixed window = size given; Variable window = size found**
3. **Left pointer ONLY moves forward — never backward**
4. **Each element touched at most twice (enter + exit) → O(n)**
5. **Negative numbers break sum-based variable windows**
6. **Window state must be cheaply updatable (add/remove in O(1))**

---

## FINAL MEMORY COMPRESSION BLOCK

```
PATTERN NAME:       Sliding Window
WHEN TO USE:        Contiguous subarray/substring optimization
CORE IDEA:          Maintain [left, right] range, slide forward, never re-examine
MOVEMENT RULE:      Expand right always; shrink left when constraint violated
TIME COMPLEXITY:    O(n) — each element enters and exits window once
SPACE COMPLEXITY:   O(1) to O(k) depending on window state
INTERVIEW LINE:     "I'll use a sliding window to avoid redundant computation
                     by maintaining a running state as I expand and contract
                     the window boundaries."
```

---

## 30-SECOND REVISION BOX

```
WINDOW = [left...right] contiguous range
FIXED:    size given → slide (add right, remove left-k)
VARIABLE: size found → expand right, shrink left when invalid
O(n):     each element enters once, exits once = 2n operations
NEGATIVES BREAK sum-based variable windows
LEFT NEVER GOES BACKWARD
```

