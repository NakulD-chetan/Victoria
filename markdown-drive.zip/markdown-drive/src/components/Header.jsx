import { memo, useState, useRef, useEffect } from 'react';
import { firebaseLogout } from './AuthGate';

const Header = memo(function Header({ theme, onThemeToggle, onMenuClick, onChatToggle, chatOpen, selectedFile, selectedFolder, onHome, user, isPremium, onOpenPremium, onOpenReferral }) {
  const [profileOpen, setProfileOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    if (!profileOpen) return;
    const handleClick = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [profileOpen]);

  const userPhoto = user?.photoURL;
  const userName = user?.name || user?.displayName || 'User';
  const userEmail = user?.email;
  const initials = userName.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);

  return (
    <header className="header">
      <div className="header__left">
        <button className="header__menu-btn" onClick={onMenuClick}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="3" y1="6" x2="21" y2="6" />
            <line x1="3" y1="12" x2="21" y2="12" />
            <line x1="3" y1="18" x2="21" y2="18" />
          </svg>
        </button>
        <button className="header__brand" onClick={onHome} style={{ cursor: 'pointer', background: 'none', border: 'none', padding: 0 }}>
          <svg width="20" height="20" viewBox="0 0 100 100" className="header__logo">
            <defs>
              <linearGradient id="headerGrad" x1="0.15" y1="0.1" x2="0.85" y2="0.9">
                <stop offset="0%" stopColor="#6366F1" />
                <stop offset="100%" stopColor="#10B981" />
              </linearGradient>
            </defs>
            <path d="M50 5 C50 5 78 38 78 58 C78 73 65 85 50 85 C35 85 22 73 22 58 C22 38 50 5 50 5Z" fill="url(#headerGrad)" />
            <rect x="35" y="49" width="30" height="3" rx="1.5" fill="white" opacity="0.92" />
            <rect x="35" y="59" width="22" height="3" rx="1.5" fill="white" opacity="0.65" />
          </svg>
          <span className="header__title">InkDrop</span>
        </button>
      </div>

      <div className="header__center">
        {selectedFile && selectedFolder && (
          <div className="header__breadcrumb">
            {selectedFolder.split('/').map((seg, i, arr) => (
              <span key={i}>
                <span className="header__breadcrumb-folder">{seg}</span>
                {i < arr.length - 1 && (
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
                )}
              </span>
            ))}
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6" /></svg>
            <span className="header__breadcrumb-file">{selectedFile}</span>
          </div>
        )}
      </div>

      <div className="header__right">
        {!isPremium && (
          <button className="header__btn header__upgrade-btn" onClick={onOpenPremium}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            <span>Pro</span>
          </button>
        )}
        <button className={`header__btn ${chatOpen ? 'header__btn--active' : ''}`} onClick={onChatToggle}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
          <span>Chat</span>
        </button>
        <button className="header__btn header__theme-btn" onClick={onThemeToggle} data-theme-toggle>
          {theme === 'dark' ? (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="12" cy="12" r="5" />
              <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
            </svg>
          ) : (
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
            </svg>
          )}
        </button>

        <div className="header__profile" ref={dropdownRef}>
          <button className="header__avatar-btn" onClick={() => setProfileOpen(prev => !prev)}>
            {userPhoto ? (
              <img src={userPhoto} alt={userName} className="header__avatar-img" referrerPolicy="no-referrer" />
            ) : (
              <span className="header__avatar-fallback">{initials}</span>
            )}
            {isPremium && <span className="header__pro-dot" />}
          </button>

          {profileOpen && (
            <div className="header__dropdown">
              <div className="header__dropdown-header">
                <div className="header__dropdown-avatar-wrap">
                  {userPhoto ? (
                    <img src={userPhoto} alt={userName} className="header__dropdown-avatar" referrerPolicy="no-referrer" />
                  ) : (
                    <span className="header__dropdown-avatar-fallback">{initials}</span>
                  )}
                </div>
                <div className="header__dropdown-info">
                  <span className="header__dropdown-name">
                    {userName}
                    {isPremium && <span className="header__dropdown-pro-badge">PRO</span>}
                  </span>
                  {userEmail && <span className="header__dropdown-email">{userEmail}</span>}
                </div>
              </div>
              <div className="header__dropdown-divider" />

              {!isPremium && (
                <button className="header__dropdown-item header__dropdown-item--upgrade" onClick={() => { setProfileOpen(false); onOpenPremium?.(); }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                  <span>Upgrade to Pro</span>
                </button>
              )}

              <button className="header__dropdown-item" onClick={() => { setProfileOpen(false); onOpenReferral?.(); }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                </svg>
                <span>Refer & Earn</span>
              </button>

              <div className="header__dropdown-divider" />
              <button className="header__dropdown-item header__dropdown-item--danger" onClick={() => { setProfileOpen(false); firebaseLogout(); }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
                <span>Sign out</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
});

export default Header;
