# Aggregates and GROUP BY — Coding Templates

---

## Basic aggregation

```sql
SELECT dept_id,
       COUNT(*) AS emp_cnt,
       AVG(salary) AS avg_sal
FROM employees
WHERE active
GROUP BY dept_id
HAVING COUNT(*) >= 3;
```

---

## COUNT DISTINCT

```sql
SELECT DATE(order_ts) AS d, COUNT(DISTINCT user_id) AS dau
FROM events
GROUP BY 1;
```

---

## ROLLUP example

```sql
SELECT COALESCE(region, 'ALL') AS region,
       COALESCE(city, 'ALL') AS city,
       SUM(sales) AS revenue
FROM store_sales
GROUP BY ROLLUP (region, city);
```

---

## Safe revenue per order (avoid line-item inflation)

```sql
SELECT DATE(o.order_ts) AS d, SUM(o.amount) AS revenue
FROM orders o
GROUP BY 1;
-- join line items only when metric needs item-level detail
```

---

*Next: [[04_Interview-Thinking]]*
