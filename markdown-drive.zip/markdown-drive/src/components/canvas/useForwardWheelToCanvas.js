import { useEffect } from 'react';

/**
 * Forward wheel/trackpad gestures from a widget overlay element onto the
 * Excalidraw canvas so two-finger pan and pinch-zoom behave the same as when
 * the cursor is over empty canvas / a shape.
 *
 * Why: widget overlays are siblings of <Excalidraw/> in the DOM, so wheel
 * events fired on Monaco / overlay panels never bubble up to the Excalidraw
 * canvas (it isn't an ancestor). We re-dispatch a synthetic WheelEvent on
 * the Excalidraw canvas to drive its native pan/zoom handlers.
 *
 * Uses a non-passive native listener so we can preventDefault() and stop
 * Monaco / the browser from also consuming the gesture.
 */
export function useForwardWheelToCanvas(rootRef) {
  useEffect(() => {
    const el = rootRef.current;
    if (!el) return undefined;

    const onWheel = (e) => {
      const canvas = document.querySelector('canvas.excalidraw__canvas');
      if (!canvas) return;

      /* Avoid double-handling if the event somehow originated on the canvas already. */
      if (canvas.contains(e.target)) return;

      e.preventDefault();
      e.stopPropagation();

      const forwarded = new WheelEvent('wheel', {
        deltaX: e.deltaX,
        deltaY: e.deltaY,
        deltaZ: e.deltaZ,
        deltaMode: e.deltaMode,
        clientX: e.clientX,
        clientY: e.clientY,
        screenX: e.screenX,
        screenY: e.screenY,
        ctrlKey: e.ctrlKey,
        shiftKey: e.shiftKey,
        altKey: e.altKey,
        metaKey: e.metaKey,
        button: e.button,
        buttons: e.buttons,
        bubbles: true,
        cancelable: true,
        composed: true,
        view: window,
      });

      canvas.dispatchEvent(forwarded);
    };

    el.addEventListener('wheel', onWheel, { passive: false, capture: true });
    return () => el.removeEventListener('wheel', onWheel, { capture: true });
  }, [rootRef]);
}
