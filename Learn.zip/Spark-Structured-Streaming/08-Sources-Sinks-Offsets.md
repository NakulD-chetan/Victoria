# Sources, Sinks & Offset Management

Structured Streaming **reads** from **sources** and **writes** to **sinks**. Progress is tracked via **offsets** (or equivalent cursor semantics). This note summarizes categories and responsibilities—without binding to a single connector version.

---

## 1. Source Categories

| Category | Examples | Offset concept |
| -------- | -------- | -------------- |
| **Message queue** | Kafka, Kinesis | Partition + sequence offset / shard iterator |
| **Files** | Parquet/JSON/CSV under a directory | **File path + position**; tracks **which files** are **stable** and consumed |
| **Socket** | TCP text socket | Test-only; fragile—no durable replay semantics |

**Replayability:** Queues with durable logs enable **exactly-once** alignment with checkpoints; raw sockets do not.

---

## 2. File Source Semantics (Conceptual)

Spark watches a directory (often with **structured** schema inference options). New **files** appear as new data. Offsets track processed files and read positions.

**Requirements for correctness:**

- Files should appear **atomically** (write to temp, rename)—**not** partial visible files.
- **Late arriving files** in event-time pipelines still need **watermarks** in the query, not only file arrival order.

---

## 3. Kafka Source (Conceptual)

Typical configuration dimensions:

| Dimension | Role |
| --------- | ---- |
| **Subscribe mode** | Topics vs pattern |
| **Starting offsets** | Latest, earliest, specific JSON map |
| **Consumer identity** | Group id semantics interact with checkpoint—**checkpoint wins** for Structured Streaming progress |
| **Security** | TLS/SASL as required |

The **checkpoint** stores processed offsets **per partition**; restarting resumes from there.

---

## 4. Sink Categories

| Sink type | Characteristics |
| --------- | --------------- |
| **Console / memory** | Debugging; not for production |
| **Parquet/ORC/CSV file sink** | Partition directories; file commit protocols per Spark version |
| **Kafka sink** | Topic routing; delivery semantics depend on producer settings |
| **Foreach / foreachBatch** | Custom logic—**you** implement transactional/idempotent writes |
| **Delta Lake / Lakehouse tables** | Transaction logs enable **ACID** merges—popular for exactly-once patterns |

---

## 5. Offset Commit Alignment

A **micro-batch** is logically **committed** when:

- Processing **succeeds**, **and**
- Metadata allows advancing offsets **without** losing consistency.

Misalignment (sink wrote but checkpoint did not, or reverse) creates **duplicates** or **gaps**. Managed sinks integrate to minimize this; **foreachBatch** requires discipline.

---

## 6. Multiple Streams

Each **StreamingQuery** has its **own** checkpoint directory. Independent queries compose **at-least-once** across queries unless you implement **distributed transactions**—usually avoided—via careful sink design.

---

## 7. Key Takeaways

1. **Offsets** are the **cursor** of infinite input—checkpoint stores authoritative progress.
2. **Sources** differ in **replay** and **ordering** guarantees—design watermarks accordingly.
3. **Sinks** determine whether **end-to-end** guarantees hold in practice.
4. Treat **file arrival** and **event time** as **orthogonal** concerns.

---
