import { create } from 'zustand';
import { getAuthHeaders } from '../components/AuthGate';
import { getActiveVaultId, onVaultChange } from './vault-store';
import { useWorkspaceStore } from './workspace-store';

const STORAGE_KEY_BASE = 'inkdrop-notes-data';

/* Per-vault storage key. The default vault keeps using the legacy flat
 * key so existing data is preserved without a migration. */
function storageKeyFor(vaultId) {
  const id = vaultId || getActiveVaultId();
  return id === 'default' ? STORAGE_KEY_BASE : `${STORAGE_KEY_BASE}:${id}`;
}
function cloudUrlFor(vaultId) {
  const id = vaultId || getActiveVaultId();
  return id === 'default' ? '/api/notes/sync' : `/api/notes/sync?vault=${encodeURIComponent(id)}`;
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 9);
}

/** Walk workspace tree (same shape as workspace-store) for tab reconciliation. */
function workspaceFindPane(node, paneId) {
  if (!node) return null;
  if (node.type === 'pane') return node.pane.id === paneId ? node : null;
  return workspaceFindPane(node.a, paneId) || workspaceFindPane(node.b, paneId);
}

function collectWorkspaceTabsInOrder(node, out, seen) {
  if (!node) return;
  if (node.type === 'pane') {
    for (const t of node.pane.tabs) {
      if (!seen.has(t)) {
        seen.add(t);
        out.push(t);
      }
    }
    return;
  }
  collectWorkspaceTabsInOrder(node.a, out, seen);
  collectWorkspaceTabsInOrder(node.b, out, seen);
}

function findPanePreferringTab(root, tabId, preferPaneId) {
  if (preferPaneId) {
    const pref = workspaceFindPane(root, preferPaneId);
    if (pref?.pane.tabs.includes(tabId)) return preferPaneId;
  }
  function walk(n) {
    if (!n) return null;
    if (n.type === 'pane') return n.pane.tabs.includes(tabId) ? n.pane.id : null;
    return walk(n.a) || walk(n.b);
  }
  return walk(root);
}

function loadFromStorage(vaultId) {
  try {
    const raw = localStorage.getItem(storageKeyFor(vaultId));
    if (!raw) return null;
    return JSON.parse(raw);
  } catch { return null; }
}

function saveToStorage(state, vaultId) {
  try {
    localStorage.setItem(storageKeyFor(vaultId), JSON.stringify({
      notebooks: state.notebooks,
      notes: state.notes,
      tags: state.tags,
    }));
  } catch (e) { console.error('Notes save failed:', e); }
}

let _cloudSaveTimer = null;
let _cloudSaving = false;
const CLOUD_DEBOUNCE_MS = 3000;

async function saveToCloud(state, vaultId) {
  if (_cloudSaving) return;
  _cloudSaving = true;
  try {
    useNotesStore.getState()._setSyncStatus('syncing');
    const payload = {
      notebooks: state.notebooks,
      notes: state.notes,
      tags: state.tags,
    };
    const res = await fetch(cloudUrlFor(vaultId), {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      const data = await res.json();
      useNotesStore.getState()._setSyncStatus('saved');
      useNotesStore.getState()._setLastSyncedAt(data.updatedAt);
    } else {
      useNotesStore.getState()._setSyncStatus('error');
    }
  } catch (e) {
    console.error('[Notes Cloud] save error:', e);
    useNotesStore.getState()._setSyncStatus('error');
  } finally {
    _cloudSaving = false;
  }
}

function debouncedCloudSave(state) {
  if (_cloudSaveTimer) clearTimeout(_cloudSaveTimer);
  useNotesStore.getState()._setSyncStatus('pending');
  const vaultId = getActiveVaultId();
  _cloudSaveTimer = setTimeout(() => saveToCloud(state, vaultId), CLOUD_DEBOUNCE_MS);
}

function persistState(state) {
  saveToStorage(state);
  debouncedCloudSave(state);
}

async function loadFromCloud(vaultId) {
  try {
    const res = await fetch(cloudUrlFor(vaultId), { headers: getAuthHeaders() });
    if (!res.ok) return null;
    const json = await res.json();
    if (!json.exists || !json.data) return null;
    return json.data;
  } catch (e) {
    console.error('[Notes Cloud] load error:', e);
    return null;
  }
}

const stored = loadFromStorage();

const DEFAULT_NOTEBOOK = {
  id: 'default',
  title: 'MY_DATA',
  parentId: null,
  icon: '\uD83D\uDCD3',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

function createStarterFolder(parentId) {
  const now = new Date().toISOString();
  return {
    id: 'starter-hello-folder',
    title: 'Hello',
    parentId,
    icon: '\uD83D\uDCC1',
    createdAt: now,
    updatedAt: now,
  };
}

function createWelcomeNote(notebookId) {
  const now = new Date().toISOString();
  return {
    id: 'welcome-note',
    title: 'Welcome',
    body: [
      '# Welcome',
      '',
      'This is your new vault.',
      '',
      'Make a note of something, create a link, or try the Importer!',
      '',
      "When you're ready, delete this note and make the vault your own.",
    ].join('\n'),
    notebookId,
    tags: [],
    isTodo: false,
    todoCompleted: false,
    isPinned: false,
    coverImage: null,
    createdAt: now,
    updatedAt: now,
  };
}

function ensureVaultData(data) {
  let notebooks = data?.notebooks?.length ? data.notebooks : [DEFAULT_NOTEBOOK];
  if (!data?.notes?.length && notebooks.length === 1) {
    const first = notebooks[0];
    if (first.id === 'default' || first.title === 'My Notebook' || first.title === 'MY_DATA') {
      notebooks = [{ ...first, title: 'MY_DATA' }];
    }
  }
  let notes = data?.notes?.length ? data.notes : [createWelcomeNote(notebooks[0].id)];

  const root = notebooks.find((nb) => nb.id === 'default') || notebooks[0];
  const hasStarterFolder = notebooks.some((nb) => nb.id === 'starter-hello-folder');
  const onlyStarterWelcome = notes.length === 1
    && notes[0].id === 'welcome-note'
    && (notes[0].notebookId === root.id || notes[0].notebookId === 'default');

  if (root && onlyStarterWelcome) {
    if (!hasStarterFolder) {
      notebooks = [...notebooks, createStarterFolder(root.id)];
    }
    notes = [{ ...notes[0], notebookId: 'starter-hello-folder' }];
  }

  const tags = data?.tags || [];
  return { notebooks, notes, tags };
}

const initialData = ensureVaultData(stored);

export const useNotesStore = create((set, get) => ({
  notebooks: initialData.notebooks,
  notes: initialData.notes,
  tags: initialData.tags,

  syncStatus: 'idle',
  lastSyncedAt: null,
  cloudLoaded: false,

  selectedNotebookId: null,
  selectedNoteId: null,
  searchQuery: '',
  sortField: 'updatedAt',
  sortReverse: true,
  viewMode: 'list',
  editorMode: 'split',
  sidebarCollapsed: false,
  noteListCollapsed: false,

  openTabs: [],
  activeTabId: null,

  _setSyncStatus: (s) => set({ syncStatus: s }),
  _setLastSyncedAt: (t) => set({ lastSyncedAt: t }),

  loadFromCloud: async () => {
    const cloud = await loadFromCloud();
    if (!cloud) {
      set({ cloudLoaded: true });
      return;
    }
    const local = loadFromStorage();
    const cloudTime = cloud._updatedAt ? new Date(cloud._updatedAt).getTime() : 0;
    const localNotes = local?.notes || [];
    const cloudNotes = cloud.notes || [];
    if (cloudNotes.length >= localNotes.length || cloudTime > Date.now() - 60000) {
      const seeded = ensureVaultData(cloud);
      set({
        notebooks: seeded.notebooks,
        notes: seeded.notes,
        tags: seeded.tags,
        cloudLoaded: true,
        syncStatus: 'saved',
        lastSyncedAt: cloud._updatedAt,
      });
      saveToStorage(seeded);
    } else {
      set({ cloudLoaded: true });
      debouncedCloudSave({ notebooks: get().notebooks, notes: get().notes, tags: get().tags });
    }
  },

  setSelectedNotebookId: (id) => set({ selectedNotebookId: id, selectedNoteId: null }),
  setSelectedNoteId: (id) => set({ selectedNoteId: id }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setSortField: (f) => set({ sortField: f }),
  setSortReverse: (r) => set({ sortReverse: r }),
  setViewMode: (m) => set({ viewMode: m }),
  setEditorMode: (m) => set({ editorMode: m }),
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  toggleNoteList: () => set((s) => ({ noteListCollapsed: !s.noteListCollapsed })),

  openNoteInTab: (noteId) => {
    /* Multi-pane: workspace owns tab lists per pane; keep notes-store in sync. */
    try {
      useWorkspaceStore.getState().openTabInFocusedPane(noteId);
    } catch { /* not yet initialised (SSR / tests) */ }
    get().reconcileOpenTabsFromWorkspace();
  },

  reconcileOpenTabsFromWorkspace: () => {
    try {
      const { root, focusedPaneId } = useWorkspaceStore.getState();
      const ordered = [];
      collectWorkspaceTabsInOrder(root, ordered, new Set());
      const focusedNode = focusedPaneId ? workspaceFindPane(root, focusedPaneId) : null;
      let activeTabId = focusedNode?.pane.activeTabId ?? null;
      if (!activeTabId && ordered.length) activeTabId = ordered[ordered.length - 1];
      set({ openTabs: ordered, activeTabId, selectedNoteId: activeTabId });
    } catch {
      /* workspace not ready */
    }
  },

  setActiveTab: (id) => set({ activeTabId: id, selectedNoteId: id }),
  closeTab: (id) => {
    try {
      const ws = useWorkspaceStore.getState();
      const paneId = findPanePreferringTab(ws.root, id, ws.focusedPaneId);
      if (paneId) ws.closeTabInPane(paneId, id);
    } catch { /* workspace unavailable */ }
    get().reconcileOpenTabsFromWorkspace();
  },

  // ── Notebook CRUD ──
  createNotebook: (title, parentId = null, icon = '\uD83D\uDCD3') => {
    const nb = {
      id: generateId(),
      title,
      parentId,
      icon,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    set((s) => {
      const next = { ...s, notebooks: [...s.notebooks, nb] };
      persistState(next);
      return next;
    });
    return nb.id;
  },

  updateNotebook: (id, updates) => {
    set((s) => {
      const next = {
        ...s,
        notebooks: s.notebooks.map((nb) =>
          nb.id === id ? { ...nb, ...updates, updatedAt: new Date().toISOString() } : nb
        ),
      };
      persistState(next);
      return next;
    });
  },

  deleteNotebook: (id) => {
    set((s) => {
      const idsToDelete = new Set();
      const collectChildren = (parentId) => {
        idsToDelete.add(parentId);
        s.notebooks.filter((nb) => nb.parentId === parentId).forEach((nb) => collectChildren(nb.id));
      };
      collectChildren(id);

      const next = {
        ...s,
        notebooks: s.notebooks.filter((nb) => !idsToDelete.has(nb.id)),
        notes: s.notes.filter((n) => !idsToDelete.has(n.notebookId)),
        selectedNotebookId: s.selectedNotebookId === id ? null : s.selectedNotebookId,
        selectedNoteId: idsToDelete.has(s.notes.find((n) => n.id === s.selectedNoteId)?.notebookId)
          ? null : s.selectedNoteId,
      };
      persistState(next);
      return next;
    });
  },

  // ── Note CRUD ──
  createNote: (notebookId, overrides = {}) => {
    const nbId = notebookId || get().selectedNotebookId || get().notebooks[0]?.id;
    if (!nbId) return null;
    const now = new Date().toISOString();
    const note = {
      id: generateId(),
      title: '',
      body: '',
      notebookId: nbId,
      tags: [],
      isTodo: false,
      todoCompleted: false,
      isPinned: false,
      coverImage: null,
      createdAt: now,
      updatedAt: now,
      ...overrides,
    };
    set((s) => {
      const next = { ...s, notes: [note, ...s.notes], selectedNoteId: note.id };
      persistState(next);
      return next;
    });
    return note.id;
  },

  updateNote: (id, updates) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === id ? { ...n, ...updates, updatedAt: new Date().toISOString() } : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  deleteNote: (id) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.filter((n) => n.id !== id),
        selectedNoteId: s.selectedNoteId === id ? null : s.selectedNoteId,
      };
      persistState(next);
      return next;
    });
  },

  duplicateNote: (id) => {
    const state = get();
    const source = state.notes.find((n) => n.id === id);
    if (!source) return null;
    const now = new Date().toISOString();
    const dup = {
      ...source,
      id: generateId(),
      title: source.title + ' (copy)',
      createdAt: now,
      updatedAt: now,
    };
    set((s) => {
      const next = { ...s, notes: [dup, ...s.notes], selectedNoteId: dup.id };
      persistState(next);
      return next;
    });
    return dup.id;
  },

  moveNote: (noteId, targetNotebookId) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === noteId ? { ...n, notebookId: targetNotebookId, updatedAt: new Date().toISOString() } : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  /* Move a folder (notebook) under a new parent. Rejects same-id, current
     parent (no-op), and any descendant of the source (cycle guard). */
  moveNotebook: (notebookId, parentId) => {
    if (notebookId === parentId) return;
    const state = get();
    const nb = state.notebooks.find((n) => n.id === notebookId);
    if (!nb) return;
    const newParent = parentId || null;
    if ((nb.parentId || null) === newParent) return;

    if (newParent) {
      const descendants = new Set([notebookId]);
      let changed = true;
      while (changed) {
        changed = false;
        for (const candidate of state.notebooks) {
          if (!descendants.has(candidate.id) && candidate.parentId && descendants.has(candidate.parentId)) {
            descendants.add(candidate.id);
            changed = true;
          }
        }
      }
      if (descendants.has(newParent)) return;
    }

    set((s) => {
      const next = {
        ...s,
        notebooks: s.notebooks.map((n) =>
          n.id === notebookId ? { ...n, parentId: newParent, updatedAt: new Date().toISOString() } : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  toggleTodo: (id) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === id ? { ...n, todoCompleted: !n.todoCompleted, updatedAt: new Date().toISOString() } : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  togglePin: (id) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === id ? { ...n, isPinned: !n.isPinned, updatedAt: new Date().toISOString() } : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  // ── Tags ──
  addTag: (name) => {
    const tag = { id: generateId(), name: name.trim().toLowerCase() };
    set((s) => {
      if (s.tags.some((t) => t.name === tag.name)) return s;
      const next = { ...s, tags: [...s.tags, tag] };
      persistState(next);
      return next;
    });
    return tag;
  },

  deleteTag: (tagName) => {
    set((s) => {
      const next = {
        ...s,
        tags: s.tags.filter((t) => t.name !== tagName),
        notes: s.notes.map((n) => ({
          ...n,
          tags: n.tags.filter((t) => t !== tagName),
        })),
      };
      persistState(next);
      return next;
    });
  },

  addTagToNote: (noteId, tagName) => {
    const name = tagName.trim().toLowerCase();
    set((s) => {
      if (!s.tags.some((t) => t.name === name)) {
        s.tags = [...s.tags, { id: generateId(), name }];
      }
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === noteId && !n.tags.includes(name)
            ? { ...n, tags: [...n.tags, name], updatedAt: new Date().toISOString() }
            : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  removeTagFromNote: (noteId, tagName) => {
    set((s) => {
      const next = {
        ...s,
        notes: s.notes.map((n) =>
          n.id === noteId
            ? { ...n, tags: n.tags.filter((t) => t !== tagName), updatedAt: new Date().toISOString() }
            : n
        ),
      };
      persistState(next);
      return next;
    });
  },

  // ── Selectors (computed) ──
  getNotebook: (id) => get().notebooks.find((nb) => nb.id === id),
  getNote: (id) => get().notes.find((n) => n.id === id),

  getFilteredNotes: () => {
    const { notes, selectedNotebookId, searchQuery, sortField, sortReverse } = get();
    let filtered = notes;

    if (selectedNotebookId === '__all__') {
      // show all
    } else if (selectedNotebookId === '__todo__') {
      filtered = filtered.filter((n) => n.isTodo);
    } else if (selectedNotebookId?.startsWith('tag:')) {
      const tagName = selectedNotebookId.slice(4);
      filtered = filtered.filter((n) => n.tags.includes(tagName));
    } else if (selectedNotebookId) {
      filtered = filtered.filter((n) => n.notebookId === selectedNotebookId);
    }

    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (n) => n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q)
      );
    }

    const pinned = filtered.filter((n) => n.isPinned);
    const unpinned = filtered.filter((n) => !n.isPinned);

    const sortFn = (a, b) => {
      let cmp = 0;
      if (sortField === 'title') {
        cmp = a.title.localeCompare(b.title);
      } else if (sortField === 'createdAt') {
        cmp = new Date(a.createdAt) - new Date(b.createdAt);
      } else {
        cmp = new Date(a.updatedAt) - new Date(b.updatedAt);
      }
      return sortReverse ? -cmp : cmp;
    };

    pinned.sort(sortFn);
    unpinned.sort(sortFn);
    return [...pinned, ...unpinned];
  },

  getNotebookTree: () => {
    const { notebooks } = get();
    const buildTree = (parentId) =>
      notebooks
        .filter((nb) => nb.parentId === parentId)
        .map((nb) => ({ ...nb, children: buildTree(nb.id) }));
    return buildTree(null);
  },

  getNotebookNoteCount: (id) => {
    const { notes, notebooks } = get();
    const ids = new Set();
    const collect = (parentId) => {
      ids.add(parentId);
      notebooks.filter((nb) => nb.parentId === parentId).forEach((nb) => collect(nb.id));
    };
    collect(id);
    return notes.filter((n) => ids.has(n.notebookId)).length;
  },

  getAllTags: () => {
    const { notes } = get();
    const tagCounts = {};
    notes.forEach((n) => n.tags.forEach((t) => { tagCounts[t] = (tagCounts[t] || 0) + 1; }));
    return Object.entries(tagCounts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  },

  exportNote: (id) => {
    const note = get().notes.find((n) => n.id === id);
    if (!note) return;
    const content = `# ${note.title}\n\n${note.body}`;
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${note.title || 'untitled'}.md`;
    a.click();
    URL.revokeObjectURL(url);
  },

  importMarkdown: (notebookId, filename, content) => {
    const title = filename.replace(/\.md$/i, '');
    get().createNote(notebookId, { title, body: content });
  },

  /* Called when the active vault changes. Swaps in local state for the
   * new vault synchronously (for snappy UI), then hydrates from cloud in
   * the background. Also resets transient UI like open tabs / selection. */
  reloadForVault: async (newVaultId) => {
    /* Cancel any pending cloud save for the OLD vault so we don't
     * accidentally write its payload to the NEW vault's path. */
    if (_cloudSaveTimer) {
      clearTimeout(_cloudSaveTimer);
      _cloudSaveTimer = null;
    }
    const local = loadFromStorage(newVaultId);
    const seeded = ensureVaultData(local);
    set({
      notebooks: seeded.notebooks,
      notes: seeded.notes,
      tags: seeded.tags,
      selectedNotebookId: null,
      selectedNoteId: null,
      searchQuery: '',
      openTabs: [],
      activeTabId: null,
      cloudLoaded: false,
      syncStatus: 'idle',
      lastSyncedAt: null,
    });
    /* If nothing was persisted locally yet for this vault, seed the
     * cloud immediately so a subsequent device sees the welcome note. */
    if (!local) {
      saveToStorage(seeded, newVaultId);
      saveToCloud(seeded, newVaultId);
    }
    const cloud = await loadFromCloud(newVaultId);
    if (cloud) {
      const merged = ensureVaultData(cloud);
      set({
        notebooks: merged.notebooks,
        notes: merged.notes,
        tags: merged.tags,
        cloudLoaded: true,
        syncStatus: 'saved',
        lastSyncedAt: cloud._updatedAt || null,
      });
      saveToStorage(merged, newVaultId);
    } else {
      set({ cloudLoaded: true });
    }
  },
}));

/* Subscribe to vault switches. Lives at module scope so it is registered
 * exactly once regardless of React remounts. */
if (typeof window !== 'undefined') {
  onVaultChange((nextId) => {
    useNotesStore.getState().reloadForVault(nextId);
  });
}
