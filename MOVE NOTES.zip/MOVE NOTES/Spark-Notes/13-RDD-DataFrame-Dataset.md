# RDD vs DataFrame vs Dataset

Spark offers three abstractions for working with distributed data. Each was introduced in a different version and has different trade-offs.

---

## 1. RDD (Resilient Distributed Dataset)

**Introduced in**: Spark 1.0 (the original API)

RDD is the **lowest-level** API — an immutable, distributed collection of objects.

### Characteristics
- **No schema** — data is unstructured (just objects/tuples)
- **No automatic optimization** — Catalyst Optimizer does NOT work on RDDs
- **Functional-style** transformations: `map`, `filter`, `reduceByKey`, `flatMap`
- **Full control** over partitions and data placement
- **Fault tolerant** through lineage (DAG remembers how to recompute lost partitions)

### Example
```python
rdd = sc.textFile("data.txt")
words = rdd.flatMap(lambda line: line.split(" "))
counts = words.map(lambda w: (w, 1)).reduceByKey(lambda a, b: a + b)
counts.collect()
```

### Pros
- Complete control over data and partitions
- Works for any type of data (not just tabular)
- Good for complex custom logic that doesn't fit SQL patterns

### Cons
- No automatic optimization (you must optimize manually)
- Verbose and harder to debug
- Slower than DataFrame for most analytics workloads
- No schema enforcement

### When to Use RDD
- Complex transformations not expressible in SQL/DataFrame API
- Working with unstructured data (text, binary)
- Need fine-grained control over partitioning
- Legacy codebases

---

## 2. DataFrame

**Introduced in**: Spark 1.3

DataFrame is a **high-level API** built on top of RDDs — think of it as a distributed SQL table with named columns and types.

### Characteristics
- **Has schema** (columns + data types)
- **Optimized by Catalyst** (predicate pushdown, column pruning, join reordering)
- **Optimized by Tungsten** (off-heap memory, codegen)
- Supports **SQL queries** directly
- **Lazy evaluation**

### Example
```python
df = spark.read.csv("data.csv", header=True, inferSchema=True)
result = df.filter(col("age") > 30).groupBy("city").count()
result.show()
```

### Pros
- Highly optimized — Catalyst + Tungsten make it 10–100x faster than RDD
- Easy SQL-like syntax
- Built-in support for reading/writing Parquet, JSON, CSV, JDBC, etc.
- Integrated with Spark ML, Structured Streaming

### Cons
- Less control over low-level operations
- Errors caught at **runtime** (not compile time) — e.g., misspelled column names

### When to Use DataFrame
- SQL-style analytics, ETL, reporting
- Reading structured/semi-structured files
- Most modern Spark workloads — this is the **recommended API**

---

## 3. Dataset

**Introduced in**: Spark 1.6

Dataset is a **type-safe** version of DataFrame — adds compile-time type checking.

### Characteristics
- Combines RDD's type safety + DataFrame's optimization
- **Compile-time checks** — errors caught before runtime
- Available **only in Scala and Java** (not in PySpark — Python is dynamically typed)

### Example (Scala)
```scala
case class Person(name: String, age: Int, city: String)
val ds: Dataset[Person] = spark.read.csv("data.csv").as[Person]
val result = ds.filter(_.age > 30).groupByKey(_.city).count()
```

### Pros
- Type-safe — compiler catches schema errors
- Optimized by Catalyst (unlike RDD)
- Good for complex domain models

### Cons
- More verbose (need case classes / POJOs)
- Not available in PySpark
- Slightly slower than DataFrame due to type encoding/decoding

### When to Use Dataset
- Scala/Java projects that need compile-time safety
- Complex domain models with strong typing requirements

---

## Quick Comparison

| Feature            | RDD              | DataFrame          | Dataset            |
|--------------------|------------------|--------------------|--------------------|
| Introduced         | Spark 1.0        | Spark 1.3          | Spark 1.6          |
| Schema             | No               | Yes                | Yes                |
| Type Safety        | Yes (compile)    | No (runtime)       | Yes (compile)      |
| Optimization       | None             | Catalyst + Tungsten| Catalyst + Tungsten|
| API Style          | Functional       | SQL-like           | Functional + SQL   |
| Language Support   | All              | All                | Scala/Java only    |
| Performance        | Slowest          | Fastest            | Fast               |
| Best For           | Custom logic     | Analytics/ETL      | Typed analytics    |

---

## Important Relationship

```
         Dataset[Row] = DataFrame
              |
    Dataset[T] = Typed Dataset (Scala/Java only)
              |
     RDD = Low-level (no optimization)
```

In Spark 2.0+, **DataFrame is actually `Dataset[Row]`** — a Dataset of untyped rows. So internally, they use the same engine.

---

## Key Takeaway

> For PySpark: Use **DataFrame** for everything — it gives you Catalyst + Tungsten optimization.
> Avoid RDD unless you have a specific need for low-level control.
> Dataset is relevant only in Scala/Java for compile-time type safety.
