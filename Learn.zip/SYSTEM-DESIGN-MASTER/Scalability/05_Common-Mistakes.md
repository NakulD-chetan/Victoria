# Scalability — Common Mistakes

> **Permanent Recall:** The top scaling mistakes: premature optimization, scaling without measuring, ignoring the database bottleneck, stateful servers, synchronous everything, ignoring cost, over-sharding too early, cache invalidation bugs, single-region deployment, and not planning for failure. Avoid these and you'll stand out in FAANG interviews.

---

## Top 10 Scaling Mistakes

| # | Mistake | Impact | Fix |
|---|---------|--------|-----|
| 1 | **Premature optimization** | Wasted effort on non-bottlenecks; complex code for no gain | Measure first; scale what's slow |
| 2 | **Scaling without measuring** | Scale the wrong thing; overspend; miss real bottleneck | Profile, monitor, then scale |
| 3 | **Ignoring database as bottleneck** | App tier scales but DB saturates; system still slow | Add replicas, cache, shard when needed |
| 4 | **Stateful servers** | Can't add/remove servers; sticky sessions; single points of failure | Stateless design; externalize state (Redis, DB) |
| 5 | **Synchronous everything** | One slow call blocks entire request; cascade failures | Async where possible; timeouts; circuit breakers |
| 6 | **Not considering cost** | "Just add 1000 servers" — budget explosion | Right-size; cache to reduce load; spot instances |
| 7 | **Over-sharding too early** | Complexity before need; cross-shard queries; rebalancing pain | Exhaust replicas + cache first; shard when necessary |
| 8 | **Ignoring cache invalidation** | Stale data; bugs; inconsistent UX | TTL + invalidation on write; document the strategy |
| 9 | **Single region deployment** | No disaster recovery; high latency for distant users | Multi-region when needed; plan failover |
| 10 | **Not planning for failure during scale** | Scale event causes outages (thundering herd, cold start) | Graceful degradation; canary deploys; feature flags |

---

## Mistake 1: Premature Optimization

**What happens:** Team adds Kubernetes, microservices, and sharding before validating the need.

**Fix:** Start with a simple design. Add complexity only when metrics show a bottleneck.

> **FAANG Tip:** "We should measure before we scale. I'd add APM and identify the actual bottleneck."

---

## Mistake 2: Scaling Without Measuring

**What happens:** CPU at 20%, but team adds servers. Real bottleneck: DB connection pool exhausted.

**Fix:** Use profiling (APM, traces), monitor DB, cache, and network. Scale the limiting factor.

---

## Mistake 3: Ignoring Database as Bottleneck

**What happens:** 100 app servers, 1 database. DB becomes the choke point.

**Fix:** Read replicas for reads. Connection pooling. Cache. Sharding for write-heavy workloads.

---

## Mistake 4: Stateful Servers

**What happens:** Sessions in server memory. One server dies → users logged out. Can't scale out without session migration.

**Fix:** Stateless app tier. Sessions in Redis or DB. Or JWT in client.

---

## Mistake 5: Synchronous Everything

**What happens:** Request calls A → B → C → D in sequence. D is slow → entire request blocked. Chain of timeouts.

**Fix:** Async for non-critical path (email, analytics). Timeouts and circuit breakers. Parallel calls where possible.

---

## Mistake 6: Not Considering Cost

**What happens:** "Scale to 1M RPS" → 1000 servers × $500/month = $500K/month. Unnecessary if caching could cut 90% of load.

**Fix:** Cache aggressively. Right-size instances. Spot/preemptible for batch. Cost as a design constraint.

---

## Mistake 7: Over-Sharding Too Early

**What happens:** 10 shards from day one. Cross-shard queries needed. Rebalancing nightmare. Team can't operate it.

**Fix:** Start with one DB + replicas. Shard only when single primary can't handle writes or data volume.

---

## Mistake 8: Ignoring Cache Invalidation

**What happens:** User updates profile; cache still has old data. User sees stale info. "Cache invalidation is hard" — and often wrong.

**Fix:** Invalidate on write (delete key or update). TTL as safety net. Document invalidation strategy. Consider write-through for critical data.

---

## Mistake 9: Single Region Deployment

**What happens:** Region goes down → total outage. Users far from region suffer high latency.

**Fix:** Multi-region when HA or latency matters. Active-passive or active-active. Plan failover and data replication.

---

## Mistake 10: Not Planning for Failure During Scaling

**What happens:** Black Friday scale-up. New instances have cold caches → thundering herd to DB. Or deployment during scale event causes cascading failures.

**Fix:** Canary deployments. Gradual traffic shift. Warm caches before cutover. Circuit breakers. Load test at scale.

---

## Quick Recognition: Am I Making These Mistakes?

| Symptom | Likely Mistake |
|---------|----------------|
| Scaling app servers but latency unchanged | #3 — DB bottleneck |
| Can't roll out new version without downtime | #4 — Stateful servers |
| One slow dependency kills entire API | #5 — Synchronous chain |
| "We need to scale" but no metrics | #2 — Scaling without measuring |
| Sharding from day one, team struggling | #7 — Over-sharding |
| Users see old data after update | #8 — Cache invalidation |

---

## Quick Memory Card

```
1. PREMATURE:    Measure first
2. NO MEASURE:   Profile, monitor, then scale
3. DB IGNORED:   Replicas, cache, shard
4. STATEFUL:     Externalize state; stateless app
5. SYNC CHAIN:   Async, timeouts, circuit breakers
6. NO COST:      Cache, right-size, spot
7. OVER-SHARD:   Replicas first; shard when needed
8. CACHE INV:    Invalidate on write; TTL
9. SINGLE REG:   Multi-region for HA
10. NO FAILURE:  Canary, warm cache, load test
```

---

**Next: [[06_Edge-Cases]]**
