# Python Memory Model — Objects, References, GC

> *"Everything is an object"* — Python data model headline

This deep note gives a CPython-centric high-level picture: every value is an object, **reference counting**, **garbage collection** (cycles), `id()` and `is`, **string interning**, **small integer caching**, **mutability vs immutability**. Interview questions in [[17-Python-FAANG-Interview-Must-Know]] make more sense with this background.

---

## 1. Everything is an object

- `int`, `str`, `function`, `class`, `type` — all **objects**
- Every object has:
  - **Identity** — `id()` (in CPython often address-like)
  - **Type** — `type(obj)`
  - **Value** — `==` / `__eq__`

```python
type(1) is int
type(int) is type
```

**Interview Tip:** `type` is itself an object — `type(type) is type`.

---

## 2. Names refer to objects — assignment = rebind

```python
a = [1, 2]
b = a
b.append(3)
print(a)  # [1,2,3]
```

- **Assignment does not copy** — it binds a reference
- Immutable case:

```python
x = 10
y = x
x = x + 1   # new int, y still 10
```

---

## 3. Reference counting

CPython — every object has a **refcount**. Zero → dealloc (typical).

```python
import sys
a = object()
sys.getrefcount(a)  # temporary +1 — debugging only
```

**Interview Tip:** Cycles — refcount alone is not enough → cycle GC.

---

## 4. Cyclic garbage — generational GC

- `a` ↔ `b` references — refcount can stay stuck
- **gc** module — cycle collection

```python
import gc
gc.collect()
```

**Watch Out!** `__del__` + cycles — messy; prefer context managers / `weakref`.

---

## 5. `id()` and `is`

- `is` — same object?
- `==` — same value?

```python
a = "hello"
b = "hello"
a is b  # often True — implementation detail
```

**Always:** `x is None`, `x is True` — PEP 8.

---

## 6. String interning

- Some literals are interned — **don't assume portable behavior**
- Compare with `==`

```python
a = "".join(["h", "i"])
b = "hi"
a == b   # True
a is b   # often False
```

---

## 7. Small integer caching

CPython often reuses **-5 .. 256**:

```python
a = 256; b = 256
# a is b often True
```

**Style:** compare ints with `==`.

---

## 8. Mutability vs immutability

| Immutable | Mutable |
|-----------|---------|
| `int`, `float`, `str`, `tuple` (if contents immutable), `frozenset` | `list`, `dict`, `set` |

- Mutable default argument trap
- Tuple with list inside — outer immutable, **inner** mutable

```python
t = ([1],)
t[0].append(2)
```

**Watch Out!** Mutable → usually **unhashable** — not valid as `set`/`dict` key.

---

## 9. Copy semantics

```python
import copy
a = [[1]]
b = list(a)      # shallow
c = copy.deepcopy(a)
```

---

## 10. `weakref` — teaser

Circular structures / caches — weak references let the GC collect objects — advanced topic.

---

## 11. `sys.intern` — explicit string intern

```python
import sys
a = sys.intern("very_long_shared_key")
b = sys.intern("very_long_shared_key")
a is b  # True — saves memory if many duplicates
```

**Watch Out!** Only for **long-lived** strings — micro-optimization.

---

## 12. Container aliasing — interview story

```python
d = {"nums": [1, 2]}
copy_d = dict(d)        # shallow
copy_d["nums"].append(3)
d["nums"]               # [1,2,3] — inner list shared
```

Same lesson as [[17-Python-FAANG-Interview-Must-Know]] shallow copy.

---

## Quick Memory Card

```
+------------------------------------------+
| OBJECT MODEL                              |
| - identity (id), type, value (==)        |
+------------------------------------------+
| ASSIGNMENT                                |
| - name binds — not C++ value copy        |
+------------------------------------------+
| REFCOUNT + GC                             |
| - cycles need generational GC            |
+------------------------------------------+
| is vs ==                                  |
| - None/True/False → is                   |
+------------------------------------------+
| INTERNING / INT CACHE                     |
| - implementation — don't rely            |
+------------------------------------------+
| MUTABLE vs IMMUTABLE                      |
| - hashability, shared refs               |
+------------------------------------------+
| COPY                                      |
| - shallow vs deep                        |
+------------------------------------------+
```

---

*Back to index: [[00-Index]] | Interview: [[17-Python-FAANG-Interview-Must-Know]]*
