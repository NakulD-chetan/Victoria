# Spark & PySpark Concepts — Complete Notes

These notes are created from the "spark pyspark concepts" PDF with corrections, deeper explanations, and easy language.

---

## Table of Contents

| #  | Topic                                    | File                                      |
|----|------------------------------------------|-------------------------------------------|
| 01 | Spark Architecture                       | [01-Spark-Architecture.md](01-Spark-Architecture.md)                   |
| 02 | DAG, Stages, and Tasks                   | [02-DAG-Stages-Tasks.md](02-DAG-Stages-Tasks.md)                     |
| 03 | Lazy Evaluation                          | [03-Lazy-Evaluation.md](03-Lazy-Evaluation.md)                       |
| 04 | Narrow vs Wide Transformations           | [04-Narrow-vs-Wide-Transformations.md](04-Narrow-vs-Wide-Transformations.md) |
| 05 | Memory Management (Deep Dive)            | [05-Memory-Management-Deep-Dive.md](05-Memory-Management-Deep-Dive.md)   |
| 05D| Memory Internals (ULTRA DEEP Analysis)   | [05_Deep_Spark_Memory_Internals.md](05_Deep_Spark_Memory_Internals.md)   |
| 06 | Partitioning and Bucketing               | [06-Partitioning-and-Bucketing.md](06-Partitioning-and-Bucketing.md)     |
| 07 | Joins in Spark                           | [07-Joins-in-Spark.md](07-Joins-in-Spark.md)                         |
| 08 | Cache and Persist                        | [08-Cache-and-Persist.md](08-Cache-and-Persist.md)                     |
| 09 | Repartition and Coalesce                 | [09-Repartition-and-Coalesce.md](09-Repartition-and-Coalesce.md)       |
| 10 | Catalyst Optimizer and Tungsten          | [10-Catalyst-Optimizer-and-Tungsten.md](10-Catalyst-Optimizer-and-Tungsten.md) |
| 11 | Shuffle (Deep Dive)                      | [11-Shuffle-Deep-Dive.md](11-Shuffle-Deep-Dive.md)                     |
| 12 | Shuffle Partitions Tuning                | [12-Shuffle-Partitions-Tuning.md](12-Shuffle-Partitions-Tuning.md)     |
| 13 | RDD vs DataFrame vs Dataset             | [13-RDD-DataFrame-Dataset.md](13-RDD-DataFrame-Dataset.md)             |
| 14 | DStream vs Structured Streaming          | [14-Streaming-DStream-vs-Structured.md](14-Streaming-DStream-vs-Structured.md) |
| 15 | Serialization (Java vs Kryo)             | [15-Serialization-Java-vs-Kryo.md](15-Serialization-Java-vs-Kryo.md)   |
| 16 | Data Skew and Fixes                      | [16-Data-Skew-and-Fixes.md](16-Data-Skew-and-Fixes.md)                 |
| 17 | map, flatMap, mapPartitions              | [17-Map-FlatMap-MapPartitions.md](17-Map-FlatMap-MapPartitions.md)     |
| 18 | File Formats (Parquet, ORC, Avro)        | [18-File-Formats-Parquet-ORC-Avro.md](18-File-Formats-Parquet-ORC-Avro.md) |

---

## Corrections Made from Original PDF

1. **Stage count example (Topic 02)**: The PDF showed 3 stages for a simple read + filter + groupBy pipeline, contradicting its own golden rule. The correct answer is **2 stages** (narrow ops are pipelined with read, not separated).

2. **union() classification (Topic 04)**: The PDF said union() is narrow "only if partitioner preserved." In reality, `union()` is **always a narrow transformation** in DataFrame API — it concatenates partitions without shuffling.

3. **Broadcast join limit (Topic 07)**: The PDF mentioned broadcast can handle tables up to "10 GB, practically 2 GB" in one section and "10 MB" in another. The default threshold is **10 MB**, configurable up to ~**2 GB** (Java byte array limit). 10 GB is incorrect.

---

## Recommended Reading Order

**Beginner**: Start with 01 → 02 → 03 → 04 → 13

**Intermediate**: Then 05 → 06 → 07 → 08 → 09

**Advanced**: Then 10 → 11 → 12 → 14 → 15 → 16 → 17 → 18
