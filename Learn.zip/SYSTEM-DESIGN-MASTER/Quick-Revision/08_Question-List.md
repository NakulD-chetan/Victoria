# Quick Revision — Study Plans

> **Permanent Recall:** Study plans for different timelines. What to review, order, time allocation. Use Quick-Revision + design problems for last-minute prep.

---

## 3 Days Before Interview

| Day | Focus | Files to Study | Time |
|-----|-------|----------------|------|
| **Day 1** | Quick Revision + 2 design problems | 01_Concept, 02_Mental-Model, 03_Design-Template, 04_Interview-Thinking, 05_Common-Mistakes, 07_Tricks | 4 hr |
| **Day 2** | Deep dive 2 problems | URL Shortener, Twitter Feed (full notes) | 4 hr |
| **Day 3** | Mock + review | 06_Edge-Cases, 08_Question-List; 1–2 timed mocks | 4 hr |

**Design problems to cover:** URL Shortener, Twitter Feed

---

## 1 Week Plan

| Day | Focus | Files / Topics | Time |
|-----|-------|----------------|------|
| **1** | Quick Revision (all 8 files) | 01–08 in order | 3 hr |
| **2** | Core concepts deep | Scalability, Load Balancing, Caching, CAP | 3 hr |
| **3** | Databases + APIs | Database Design, Scaling, API Design | 3 hr |
| **4** | Design problems 1–3 | URL Shortener, Twitter, Rate Limiter | 4 hr |
| **5** | Design problems 4–5 | WhatsApp, Distributed Cache | 4 hr |
| **6** | Design problems 6–7 | Notification System, Uber | 4 hr |
| **7** | Mock + wrap-up | YouTube, Google Docs; timed mock | 4 hr |

**Design problems:** 8 (URL Shortener, Twitter, Rate Limiter, WhatsApp, Cache, Notification, Uber, YouTube/Google Docs)

---

## 2 Week Plan

| Week | Focus | Topics |
|------|-------|--------|
| **Week 1** | Core concepts | All 16 topics from 01_Concept; Mental models; Design template |
| **Week 2** | Design problems + practice | 8 design problems; 2–3 timed mocks |

**Day-by-day (Week 1):**
- Mon: Fundamentals, Scalability, Load Balancing
- Tue: Caching, Database Design, Database Scaling
- Wed: CAP, Availability, API Design
- Thu: Message Queues, Microservices, Distributed Systems
- Fri: Resilience, Back-of-Envelope, Security, Monitoring
- Sat: Mental models, Design template, Interview thinking
- Sun: Common mistakes, Tricks, Edge cases

**Day-by-day (Week 2):**
- Mon–Tue: URL Shortener, Twitter, Instagram, WhatsApp
- Wed–Thu: YouTube, Uber, Notification, Rate Limiter
- Fri: Distributed Cache, Google Docs
- Sat–Sun: Timed mocks (2–3), review weak areas

---

## 1 Month Plan

| Week | Focus |
|------|-------|
| **1** | Full concept coverage (all 16 topics) |
| **2** | 8 design problems (deep) |
| **3** | 5 more design problems + company-specific |
| **4** | Practice with timer; weak area review |

**Design problems (12–15):** URL Shortener, Twitter, Instagram, WhatsApp, YouTube, Uber, Notification, Rate Limiter, Distributed Cache, Google Docs, Search Autocomplete, E-commerce, Dropbox (pick based on target company)

**Time per topic:** ~1–2 hr for concepts; ~2–3 hr per design problem (read + draw + practice)

---

## 3 Month Plan (Deep Mastery)

| Month | Focus |
|------|-------|
| **1** | All concepts (deep); 8 core design problems |
| **2** | 10 more design problems; expert topics (consensus, multi-region) |
| **3** | Company-specific; 10+ timed mocks; weak area mastery |

**Expert topics:** Raft/Paxos, distributed transactions, multi-region DB, global rate limiter, GFS-style systems

**Practice:** 2–3 mocks per week in month 2–3

---

## Order of Study (Quick Reference)

| Priority | Files |
|----------|-------|
| **First** | 01_Concept, 04_Interview-Thinking, 05_Common-Mistakes, 07_Tricks |
| **Second** | 02_Mental-Model, 03_Design-Template, 06_Edge-Cases |
| **Third** | 08_Question-List (this file) |

---

## Top 10 Design Problems (Must Know)

| # | Problem | Category |
|---|---------|----------|
| 1 | URL Shortener | Infrastructure |
| 2 | Twitter Feed | Social |
| 3 | Rate Limiter | Infrastructure |
| 4 | Chat (WhatsApp) | Real-time |
| 5 | Distributed Cache | Infrastructure |
| 6 | Notification System | Notification |
| 7 | YouTube / Netflix | Media |
| 8 | Uber | Geospatial |
| 9 | Instagram | Social |
| 10 | Google Docs | Collaborative |

---

## Company-Specific Hints

| Company | Likely Questions |
|---------|------------------|
| **Google** | Search, YouTube, GFS, Distributed Cache, Docs |
| **Meta** | News Feed, WhatsApp, Instagram, Chat |
| **Amazon** | E-commerce, Notification, Cache, Rate Limiter |
| **Netflix** | Streaming, CDN, Recommendation |
| **Uber** | Uber, Rate Limiter, Notification |
| **Microsoft** | Chat, Cache, Video Conferencing |

---

**Prev: [[07_Tricks-and-Recognition]] | Back: [[01_Concept]]**
