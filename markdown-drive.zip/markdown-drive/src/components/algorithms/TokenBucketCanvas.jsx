import { useEffect, useRef, useCallback, useImperativeHandle, forwardRef } from 'react';
import rough from 'roughjs';
import { useAlgorithmStore } from '../../stores/algorithm-store';
import { FONT_HAND, FONT_MONO, DPR, clearCache } from '../../lib/canvas/rough-helpers';

const shapeCache = {};
function cacheShape(key, w, h, drawFn) {
  if (shapeCache[key]) return shapeCache[key];
  const c = document.createElement('canvas');
  c.width = w * DPR; c.height = h * DPR;
  const cx = c.getContext('2d');
  cx.scale(DPR, DPR);
  drawFn(rough.canvas(c), cx);
  shapeCache[key] = c;
  return c;
}
function clearShapeCache() { Object.keys(shapeCache).forEach((k) => delete shapeCache[k]); }

const PALETTE = {
  light: {
    dotGrid: '#e7e5e4',
    stroke: '#1c1917',
    textPrimary: '#1c1917',
    textSecondary: '#78716c',
    textRate: '#1971c2',
    sourceFill: '#a5d8ff',
    clientFill: '#d0bfff',
    serverFill: '#b2f2bb',
    bucketStroke: '#1c1917',
    bucketRim: '#1c1917',
    arrowStroke: '#78716c',
    emptyToken: '#d6d3d1',
    waterFill: 'rgba(166,216,249,0.32)',
    waterStroke: 'rgba(25,113,194,0.25)',
    pipeStroke: '#1c1917',
    statusFull: '#2f9e44',
    statusEmpty: '#e03131',
    statusNormal: '#78716c',
  },
  dark: {
    dotGrid: 'rgba(255,255,255,0.07)',
    stroke: 'rgba(255,255,255,0.6)',
    textPrimary: '#e7e5e4',
    textSecondary: '#a8a29e',
    textRate: '#74c0fc',
    sourceFill: '#1c4a6e',
    clientFill: '#3b2e6e',
    serverFill: '#1e5631',
    bucketStroke: 'rgba(255,255,255,0.55)',
    bucketRim: 'rgba(255,255,255,0.45)',
    arrowStroke: '#a8a29e',
    emptyToken: 'rgba(255,255,255,0.15)',
    waterFill: 'rgba(100,180,255,0.15)',
    waterStroke: 'rgba(100,180,255,0.25)',
    pipeStroke: 'rgba(255,255,255,0.45)',
    statusFull: '#51cf66',
    statusEmpty: '#ff6b6b',
    statusNormal: '#a8a29e',
  },
};

function getThemePalette() {
  const t = document.documentElement.getAttribute('data-theme');
  return t === 'light' ? PALETTE.light : PALETTE.dark;
}

const TokenBucketCanvas = forwardRef(function TokenBucketCanvas({ bucketRef }, ref) {
  const canvasRef = useRef(null);
  const animsRef = useRef([]);
  const lastWholeRef = useRef(10);
  const wRef = useRef(0);
  const hRef = useRef(0);
  const lastThemeRef = useRef('');

  const capacity = useAlgorithmStore((s) => s.capacity);
  const refillRate = useAlgorithmStore((s) => s.refillRate);

  const addAnim = useCallback((type, dur = 700, delay = 0) => {
    animsRef.current.push({ type, t0: performance.now(), dur, delay });
  }, []);

  useImperativeHandle(ref, () => ({ addAnim }), [addAnim]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let animId;

    function resize() {
      const rect = canvas.getBoundingClientRect();
      wRef.current = rect.width; hRef.current = rect.height;
      canvas.width = rect.width * DPR; canvas.height = rect.height * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      clearShapeCache(); clearCache();
      lastThemeRef.current = '';
    }
    resize();
    window.addEventListener('resize', resize);

    function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

    function L() {
      const W = wRef.current, cx = W / 2;
      return {
        source: { x: cx - 75, y: 14, w: 150, h: 48 },
        pipeTop: { x: cx, y: 62 }, pipeBot: { x: cx, y: 120 },
        bucket: { x: cx - 90, y: 120, w: 180, h: 205, cx },
        bucketBot: { lx: cx - 70, rx: cx + 70, y: 325 },
        client: { x: 30, y: 195, w: 120, h: 80 },
        server: { x: W - 150, y: 195, w: 120, h: 80 },
        arrowReqStart: { x: 150, y: 235 }, arrowReqEnd: { x: cx - 90, y: 235 },
        arrowResStart: { x: cx + 90, y: 235 }, arrowResEnd: { x: W - 150, y: 235 },
      };
    }

    function drawBox(key, x, y, w, h, opts) {
      const img = cacheShape(key, w + 4, h + 4, (rc) => {
        rc.rectangle(2, 2, w, h, { roughness: 1.6, bowing: 1.2, strokeWidth: 2.2, ...opts });
      });
      ctx.drawImage(img, x - 2, y - 2, w + 4, h + 4);
    }

    function drawBucket(key, l, pal) {
      const bw = l.bucket.w + 20, bh = l.bucket.h + 10;
      const img = cacheShape(key, bw, bh, (rc) => {
        const topL = 10, topR = l.bucket.w + 10;
        const botL = 10 + (l.bucket.w - (l.bucketBot.rx - l.bucketBot.lx)) / 2;
        const botR = botL + (l.bucketBot.rx - l.bucketBot.lx);
        const h2 = l.bucket.h + 5;
        rc.polygon([[topL, 5], [topR, 5], [botR, h2], [botL, h2]], { seed: 1, roughness: 1.8, bowing: 1, stroke: pal.bucketStroke, strokeWidth: 2.8 });
        rc.line(topL - 12, 5, topR + 12, 5, { seed: 77, roughness: 1.5, strokeWidth: 4, stroke: pal.bucketRim });
      });
      ctx.drawImage(img, l.bucket.x - 10, l.bucket.y - 5, bw, bh);
    }

    function drawPipe(key, l, pal) {
      const pw = 30, ph = l.pipeBot.y - l.pipeTop.y + 10;
      const img = cacheShape(key, pw, ph, (rc) => {
        rc.line(8, 0, 8, ph, { seed: 30, roughness: 1.2, strokeWidth: 2, stroke: pal.pipeStroke });
        rc.line(22, 0, 22, ph, { seed: 31, roughness: 1.2, strokeWidth: 2, stroke: pal.pipeStroke });
      });
      ctx.drawImage(img, l.pipeTop.x - 15, l.pipeTop.y, pw, ph);
    }

    function drawArrowLine(key, x1, y1, x2, pal) {
      const pad = 20, w = Math.abs(x2 - x1) + pad * 2, h = 30;
      const img = cacheShape(key, w, h, (rc) => {
        rc.line(pad, h / 2, w - pad, h / 2, { seed: 50, roughness: 1.5, strokeWidth: 1.8, stroke: pal.arrowStroke });
        const tipX = w - pad, tipY = h / 2;
        rc.line(tipX - 12, tipY - 7, tipX, tipY, { seed: 51, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
        rc.line(tipX - 12, tipY + 7, tipX, tipY, { seed: 52, roughness: 1, strokeWidth: 1.8, stroke: pal.arrowStroke });
      });
      ctx.drawImage(img, Math.min(x1, x2) - pad, y1 - 15, w, h);
    }

    function drawToken(variant, filled, pal) {
      const key = `tok-${variant}-${filled}`, s = 30;
      return cacheShape(key, s, s, (rc) => {
        if (filled) {
          rc.circle(s / 2, s / 2, s - 4, { seed: 200 + variant, roughness: 1, fill: '#ffd43b', fillStyle: 'solid', stroke: '#e8590c', strokeWidth: 2 });
        } else {
          rc.circle(s / 2, s / 2, s - 4, { seed: 200 + variant, roughness: 1, stroke: pal.emptyToken, strokeWidth: 1.2 });
        }
      });
    }

    function tokenPositions(l) {
      const cap = bucketRef.current.capacity;
      const cols = Math.min(5, cap), rows = Math.ceil(cap / cols);
      const areaW = (l.bucketBot.rx - l.bucketBot.lx) * 0.85;
      const areaH = l.bucket.h * 0.7;
      const startY = l.bucket.y + l.bucket.h - 18;
      const cxB = l.bucket.cx;
      const gapX = areaW / (cols + 1), gapY = areaH / (rows + 0.5);
      const positions = [];
      for (let i = 0; i < cap; i++) {
        const row = Math.floor(i / cols), col = i % cols;
        const rowCount = Math.min(cols, cap - row * cols);
        const rowW = rowCount * gapX;
        const rowStartX = cxB - rowW / 2 + gapX / 2;
        positions.push({ x: rowStartX + col * gapX, y: startY - row * gapY });
      }
      return positions;
    }

    function render(now) {
      const W = wRef.current, H = hRef.current;
      ctx.clearRect(0, 0, W, H);
      ctx.textBaseline = 'middle';
      const l = L();
      const bucket = bucketRef.current;

      const curTheme = document.documentElement.getAttribute('data-theme') || 'dark';
      if (curTheme !== lastThemeRef.current) {
        clearShapeCache(); clearCache();
        lastThemeRef.current = curTheme;
      }
      const pal = getThemePalette();

      ctx.fillStyle = pal.dotGrid;
      for (let gx = 20; gx < W; gx += 20)
        for (let gy = 20; gy < H; gy += 20)
          ctx.fillRect(gx, gy, 1.5, 1.5);

      const prevWhole = lastWholeRef.current;
      bucket.refill(now);
      const newWhole = Math.floor(bucket.tokens);
      if (newWhole > prevWhole) {
        for (let i = 0; i < newWhole - prevWhole; i++) addAnim('drop', 550, i * 100);
      }
      lastWholeRef.current = newWhole;

      drawBox('source', l.source.x, l.source.y, l.source.w, l.source.h, { fill: pal.sourceFill, fillStyle: 'hachure', hachureGap: 6, seed: 2, stroke: pal.stroke });
      drawPipe('pipe', l, pal);
      drawBucket('bucket', l, pal);
      drawBox('client', l.client.x, l.client.y, l.client.w, l.client.h, { fill: pal.clientFill, fillStyle: 'hachure', hachureGap: 6, seed: 3, stroke: pal.stroke });
      drawBox('server', l.server.x, l.server.y, l.server.w, l.server.h, { fill: pal.serverFill, fillStyle: 'hachure', hachureGap: 6, seed: 4, stroke: pal.stroke });
      drawArrowLine('arr-req', l.arrowReqStart.x, l.arrowReqStart.y, l.arrowReqEnd.x, pal);
      drawArrowLine('arr-res', l.arrowResStart.x, l.arrowResStart.y, l.arrowResEnd.x, pal);

      const fillPct = bucket.tokens / bucket.capacity;
      const bTopL = l.bucket.x, bTopR = l.bucket.x + l.bucket.w;
      const bBotL = l.bucketBot.lx, bBotR = l.bucketBot.rx;
      const bTop = l.bucket.y + 3, bBot = l.bucketBot.y;
      const waterTop = bBot - (bBot - bTop) * fillPct;
      const frac = (waterTop - bTop) / (bBot - bTop);
      const wlL = bTopL + (bBotL - bTopL) * frac;
      const wlR = bTopR + (bBotR - bTopR) * frac;
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(bTopL, bTop); ctx.lineTo(bTopR, bTop);
      ctx.lineTo(bBotR, bBot); ctx.lineTo(bBotL, bBot);
      ctx.closePath(); ctx.clip();
      ctx.fillStyle = pal.waterFill;
      ctx.fillRect(bBotL - 20, waterTop, bBotR - bBotL + 40, bBot - waterTop + 5);
      ctx.strokeStyle = pal.waterStroke; ctx.lineWidth = 2;
      ctx.beginPath();
      for (let wx = wlL - 5; wx <= wlR + 5; wx += 1) {
        const wy = waterTop + Math.sin((wx + now * 0.002) * 0.08) * 3;
        wx === wlL - 5 ? ctx.moveTo(wx, wy) : ctx.lineTo(wx, wy);
      }
      ctx.stroke();
      ctx.restore();

      const positions = tokenPositions(l);
      const filled = Math.floor(bucket.tokens);
      const cap = bucket.capacity;
      for (let i = 0; i < cap; i++) {
        const p = positions[i];
        ctx.drawImage(drawToken(i % 7, i < filled, pal), p.x - 15, p.y - 15, 30, 30);
      }

      ctx.fillStyle = pal.textPrimary; ctx.font = `600 16px ${FONT_HAND}`; ctx.textAlign = 'center';
      ctx.fillText('Token Source', l.source.x + l.source.w / 2, l.source.y + l.source.h / 2 - 6);
      ctx.font = `13px ${FONT_MONO}`; ctx.fillStyle = pal.textRate;
      ctx.fillText(`+${bucket.rate}/sec`, l.source.x + l.source.w / 2, l.source.y + l.source.h / 2 + 12);
      ctx.fillStyle = pal.textPrimary; ctx.font = `600 15px ${FONT_HAND}`;
      ctx.fillText('Client', l.client.x + l.client.w / 2, l.client.y + l.client.h / 2);
      ctx.fillText('Server', l.server.x + l.server.w / 2, l.server.y + l.server.h / 2);
      ctx.font = `800 36px ${FONT_MONO}`; ctx.fillStyle = pal.textPrimary;
      ctx.fillText(String(Math.floor(bucket.tokens)), l.bucket.cx, l.bucket.y + 52);
      ctx.font = `14px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText(`/ ${cap} tokens`, l.bucket.cx, l.bucket.y + 76);
      ctx.font = `13px ${FONT_HAND}`; ctx.fillStyle = pal.textSecondary;
      ctx.fillText('request', (l.arrowReqStart.x + l.arrowReqEnd.x) / 2, l.arrowReqStart.y - 18);
      ctx.fillText('response', (l.arrowResStart.x + l.arrowResEnd.x) / 2, l.arrowResStart.y - 18);
      ctx.font = `12px ${FONT_HAND}`; ctx.textAlign = 'left';
      ctx.fillText(`capacity = ${cap}`, l.bucket.x + l.bucket.w + 14, l.bucket.y + 30);
      ctx.fillText(`rate = ${bucket.rate}/s`, l.bucket.x + l.bucket.w + 14, l.bucket.y + 50);
      ctx.textAlign = 'center'; ctx.font = `700 14px ${FONT_HAND}`;
      if (bucket.tokens >= bucket.capacity) { ctx.fillStyle = pal.statusFull; ctx.fillText('Bucket Full \u2014 Ready for burst!', l.bucket.cx, l.bucketBot.y + 20); }
      else if (bucket.tokens < 1) { ctx.fillStyle = pal.statusEmpty; ctx.fillText('Bucket Empty \u2014 Throttled!', l.bucket.cx, l.bucketBot.y + 20); }
      else { ctx.fillStyle = pal.statusNormal; ctx.fillText('Accepting requests...', l.bucket.cx, l.bucketBot.y + 20); }

      const anims = animsRef.current;
      for (let i = anims.length - 1; i >= 0; i--) {
        const a = anims[i];
        const delay = a.delay || 0;
        const elapsed = now - a.t0 - delay;
        if (elapsed < 0) continue;
        const t = Math.min(elapsed / a.dur, 1);
        if (a.type === 'drop') {
          const dx = l.pipeTop.x + Math.sin(a.t0) * 6;
          const dy = l.pipeTop.y + t * (l.bucket.y + 40 - l.pipeTop.y);
          const sz = 10 * (1 - t * 0.3);
          ctx.beginPath(); ctx.arc(dx, dy, sz, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255,212,59,${1 - t * 0.5})`; ctx.fill();
          ctx.strokeStyle = '#e8590c'; ctx.lineWidth = 1.5; ctx.stroke();
        }
        if (a.type === 'req-allow') {
          const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
          if (t < 0.5) { const p = t / 0.5; const px = sx + (ex - sx) * easeOut(p); ctx.beginPath(); ctx.arc(px, sy, 8, 0, Math.PI * 2); ctx.fillStyle = 'rgba(25,113,194,0.7)'; ctx.fill(); }
          else { const p = (t - 0.5) / 0.5; const sx2 = l.arrowResStart.x, ex2 = l.arrowResEnd.x; const px = sx2 + (ex2 - sx2) * easeOut(p); ctx.beginPath(); ctx.arc(px, l.arrowResStart.y, 7, 0, Math.PI * 2); ctx.fillStyle = 'rgba(47,158,68,0.8)'; ctx.fill(); }
          if (t > 0.3 && t < 0.7) { ctx.font = `800 28px ${FONT_HAND}`; ctx.fillStyle = pal.statusFull; ctx.textAlign = 'center'; ctx.globalAlpha = Math.min(1 - Math.abs(t - 0.5) / 0.2, 1); ctx.fillText('\u2713', l.bucket.cx, l.bucket.y - 10); ctx.globalAlpha = 1; }
        }
        if (a.type === 'req-deny') {
          const sx = l.arrowReqStart.x, sy = l.arrowReqStart.y, ex = l.arrowReqEnd.x;
          if (t < 0.4) { const p = t / 0.4; const px = sx + (ex - sx) * easeOut(p); ctx.beginPath(); ctx.arc(px, sy, 8, 0, Math.PI * 2); ctx.fillStyle = 'rgba(224,49,49,0.7)'; ctx.fill(); }
          else if (t < 0.6) { const bT = (t - 0.4) / 0.2; const px = ex - bT * 30; ctx.beginPath(); ctx.arc(px, sy, 8 * (1 - bT * 0.3), 0, Math.PI * 2); ctx.fillStyle = `rgba(224,49,49,${1 - bT * 0.5})`; ctx.fill(); }
          if (t > 0.25 && t < 0.85) { ctx.font = `800 32px ${FONT_HAND}`; ctx.fillStyle = pal.statusEmpty; ctx.textAlign = 'center'; ctx.globalAlpha = Math.max(t < 0.55 ? 1 : 1 - (t - 0.55) / 0.3, 0); ctx.fillText('\u2717', l.bucket.cx, l.bucket.y - 10); ctx.globalAlpha = 1; }
        }
        if (t >= 1) anims.splice(i, 1);
      }
      animId = requestAnimationFrame(render);
    }
    animId = requestAnimationFrame(render);
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', resize); };
  }, [bucketRef, addAnim]);

  useEffect(() => { clearShapeCache(); clearCache(); lastThemeRef.current = ''; }, [capacity, refillRate]);

  return (
    <div className="dc-canvas-wrap">
      <canvas ref={canvasRef} className="dc-canvas" style={{ height: 420 }} />
    </div>
  );
});

export default TokenBucketCanvas;
